const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4e1655,_0x5194b6){if(!_0x4e1655)throw ot(_0x5194b6);},ot=function(_0x576e7f){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x576e7f);},Wr=function(_0x56abbe){const _0x43387a=[];let _0x5a6b07=0x0;for(let _0x1bfa96=0x0;_0x1bfa96<_0x56abbe['length'];_0x1bfa96++){let _0x59f070=_0x56abbe['charCodeAt'](_0x1bfa96);_0x59f070<0x80?_0x43387a[_0x5a6b07++]=_0x59f070:_0x59f070<0x800?(_0x43387a[_0x5a6b07++]=_0x59f070>>0x6|0xc0,_0x43387a[_0x5a6b07++]=_0x59f070&0x3f|0x80):(_0x59f070&0xfc00)===0xd800&&_0x1bfa96+0x1<_0x56abbe['length']&&(_0x56abbe['charCodeAt'](_0x1bfa96+0x1)&0xfc00)===0xdc00?(_0x59f070=0x10000+((_0x59f070&0x3ff)<<0xa)+(_0x56abbe['charCodeAt'](++_0x1bfa96)&0x3ff),_0x43387a[_0x5a6b07++]=_0x59f070>>0x12|0xf0,_0x43387a[_0x5a6b07++]=_0x59f070>>0xc&0x3f|0x80,_0x43387a[_0x5a6b07++]=_0x59f070>>0x6&0x3f|0x80,_0x43387a[_0x5a6b07++]=_0x59f070&0x3f|0x80):(_0x43387a[_0x5a6b07++]=_0x59f070>>0xc|0xe0,_0x43387a[_0x5a6b07++]=_0x59f070>>0x6&0x3f|0x80,_0x43387a[_0x5a6b07++]=_0x59f070&0x3f|0x80);}return _0x43387a;},Za=function(_0x244feb){const _0x2d18bd=[];let _0x6c26d6=0x0,_0x4a8701=0x0;for(;_0x6c26d6<_0x244feb['length'];){const _0x51a0da=_0x244feb[_0x6c26d6++];if(_0x51a0da<0x80)_0x2d18bd[_0x4a8701++]=String['fromCharCode'](_0x51a0da);else{if(_0x51a0da>0xbf&&_0x51a0da<0xe0){const _0x14eda4=_0x244feb[_0x6c26d6++];_0x2d18bd[_0x4a8701++]=String['fromCharCode']((_0x51a0da&0x1f)<<0x6|_0x14eda4&0x3f);}else{if(_0x51a0da>0xef&&_0x51a0da<0x16d){const _0x547fc4=_0x244feb[_0x6c26d6++],_0x365d35=_0x244feb[_0x6c26d6++],_0x309f9f=_0x244feb[_0x6c26d6++],_0x350c4a=((_0x51a0da&0x7)<<0x12|(_0x547fc4&0x3f)<<0xc|(_0x365d35&0x3f)<<0x6|_0x309f9f&0x3f)-0x10000;_0x2d18bd[_0x4a8701++]=String['fromCharCode'](0xd800+(_0x350c4a>>0xa)),_0x2d18bd[_0x4a8701++]=String['fromCharCode'](0xdc00+(_0x350c4a&0x3ff));}else{const _0x4b51ab=_0x244feb[_0x6c26d6++],_0x145bd8=_0x244feb[_0x6c26d6++];_0x2d18bd[_0x4a8701++]=String['fromCharCode']((_0x51a0da&0xf)<<0xc|(_0x4b51ab&0x3f)<<0x6|_0x145bd8&0x3f);}}}}return _0x2d18bd['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x5b411b,_0x46ce25){if(!Array['isArray'](_0x5b411b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3f94aa=_0x46ce25?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x179a66=[];for(let _0x45774a=0x0;_0x45774a<_0x5b411b['length'];_0x45774a+=0x3){const _0x48b75e=_0x5b411b[_0x45774a],_0x6dc48a=_0x45774a+0x1<_0x5b411b['length'],_0x128a5e=_0x6dc48a?_0x5b411b[_0x45774a+0x1]:0x0,_0x165ccd=_0x45774a+0x2<_0x5b411b['length'],_0x309477=_0x165ccd?_0x5b411b[_0x45774a+0x2]:0x0,_0x4b51d2=_0x48b75e>>0x2,_0x1aa1c5=(_0x48b75e&0x3)<<0x4|_0x128a5e>>0x4;let _0x4988c4=(_0x128a5e&0xf)<<0x2|_0x309477>>0x6,_0x4ddb87=_0x309477&0x3f;_0x165ccd||(_0x4ddb87=0x40,_0x6dc48a||(_0x4988c4=0x40)),_0x179a66['push'](_0x3f94aa[_0x4b51d2],_0x3f94aa[_0x1aa1c5],_0x3f94aa[_0x4988c4],_0x3f94aa[_0x4ddb87]);}return _0x179a66['join']('');},'encodeString'(_0x24be89,_0x1d7b36){return this['HAS_NATIVE_SUPPORT']&&!_0x1d7b36?btoa(_0x24be89):this['encodeByteArray'](Wr(_0x24be89),_0x1d7b36);},'decodeString'(_0x520367,_0x3bbca1){return this['HAS_NATIVE_SUPPORT']&&!_0x3bbca1?atob(_0x520367):Za(this['decodeStringToByteArray'](_0x520367,_0x3bbca1));},'decodeStringToByteArray'(_0x315ee7,_0x20345d){this['init_']();const _0x66cb0f=_0x20345d?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3af115=[];for(let _0x5f17a7=0x0;_0x5f17a7<_0x315ee7['length'];){const _0x1465d8=_0x66cb0f[_0x315ee7['charAt'](_0x5f17a7++)],_0x4a66cb=_0x5f17a7<_0x315ee7['length']?_0x66cb0f[_0x315ee7['charAt'](_0x5f17a7)]:0x0;++_0x5f17a7;const _0x57faf1=_0x5f17a7<_0x315ee7['length']?_0x66cb0f[_0x315ee7['charAt'](_0x5f17a7)]:0x40;++_0x5f17a7;const _0x5559dd=_0x5f17a7<_0x315ee7['length']?_0x66cb0f[_0x315ee7['charAt'](_0x5f17a7)]:0x40;if(++_0x5f17a7,_0x1465d8==null||_0x4a66cb==null||_0x57faf1==null||_0x5559dd==null)throw new ec();const _0xca455f=_0x1465d8<<0x2|_0x4a66cb>>0x4;if(_0x3af115['push'](_0xca455f),_0x57faf1!==0x40){const _0x56150e=_0x4a66cb<<0x4&0xf0|_0x57faf1>>0x2;if(_0x3af115['push'](_0x56150e),_0x5559dd!==0x40){const _0x345774=_0x57faf1<<0x6&0xc0|_0x5559dd;_0x3af115['push'](_0x345774);}}}return _0x3af115;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x333b7d=0x0;_0x333b7d<this['ENCODED_VALS']['length'];_0x333b7d++)this['byteToCharMap_'][_0x333b7d]=this['ENCODED_VALS']['charAt'](_0x333b7d),this['charToByteMap_'][this['byteToCharMap_'][_0x333b7d]]=_0x333b7d,this['byteToCharMapWebSafe_'][_0x333b7d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x333b7d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x333b7d]]=_0x333b7d,_0x333b7d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x333b7d)]=_0x333b7d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x333b7d)]=_0x333b7d);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x15740d){const _0x412700=Wr(_0x15740d);return Di['encodeByteArray'](_0x412700,!0x0);},an=function(_0x53b2f2){return Br(_0x53b2f2)['replace'](/\./g,'');},cn=function(_0x231679){try{return Di['decodeString'](_0x231679,!0x0);}catch(_0x6f94a1){console['error']('base64Decode\x20failed:\x20',_0x6f94a1);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x4ceaf7){return Vr(void 0x0,_0x4ceaf7);}function Vr(_0x3ed5a9,_0x49a4a2){if(!(_0x49a4a2 instanceof Object))return _0x49a4a2;switch(_0x49a4a2['constructor']){case Date:const _0x565f95=_0x49a4a2;return new Date(_0x565f95['getTime']());case Object:_0x3ed5a9===void 0x0&&(_0x3ed5a9={});break;case Array:_0x3ed5a9=[];break;default:return _0x49a4a2;}for(const _0x428ee4 in _0x49a4a2)!_0x49a4a2['hasOwnProperty'](_0x428ee4)||!nc(_0x428ee4)||(_0x3ed5a9[_0x428ee4]=Vr(_0x3ed5a9[_0x428ee4],_0x49a4a2[_0x428ee4]));return _0x3ed5a9;}function nc(_0x40d42b){return _0x40d42b!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x248bc9=As['__FIREBASE_DEFAULTS__'];if(_0x248bc9)return JSON['parse'](_0x248bc9);},oc=()=>{if(typeof document>'u')return;let _0xaa6f1e;try{_0xaa6f1e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4f0bf7=_0xaa6f1e&&cn(_0xaa6f1e[0x1]);return _0x4f0bf7&&JSON['parse'](_0x4f0bf7);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x518602){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x518602);return;}},Hr=_0x349e70=>{var _0x156782,_0x14b77c;return(_0x14b77c=(_0x156782=Mi())==null?void 0x0:_0x156782['emulatorHosts'])==null?void 0x0:_0x14b77c[_0x349e70];},ac=_0x32c1e6=>{const _0x292fe1=Hr(_0x32c1e6);if(!_0x292fe1)return;const _0x3afc0c=_0x292fe1['lastIndexOf'](':');if(_0x3afc0c<=0x0||_0x3afc0c+0x1===_0x292fe1['length'])throw new Error('Invalid\x20host\x20'+_0x292fe1+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1ff9e7=parseInt(_0x292fe1['substring'](_0x3afc0c+0x1),0xa);return _0x292fe1[0x0]==='['?[_0x292fe1['substring'](0x1,_0x3afc0c-0x1),_0x1ff9e7]:[_0x292fe1['substring'](0x0,_0x3afc0c),_0x1ff9e7];},$r=()=>{var _0x5c261b;return(_0x5c261b=Mi())==null?void 0x0:_0x5c261b['config'];},Gr=_0xc987dd=>{var _0x3e02d9;return(_0x3e02d9=Mi())==null?void 0x0:_0x3e02d9['_'+_0xc987dd];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xdd5cbf,_0x47caee)=>{this['resolve']=_0xdd5cbf,this['reject']=_0x47caee;});}['wrapCallback'](_0xf137e1){return(_0x28f414,_0x392d7c)=>{_0x28f414?this['reject'](_0x28f414):this['resolve'](_0x392d7c),typeof _0xf137e1=='function'&&(this['promise']['catch'](()=>{}),_0xf137e1['length']===0x1?_0xf137e1(_0x28f414):_0xf137e1(_0x28f414,_0x392d7c));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x38851c,_0x1ca91f){if(_0x38851c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3d024e={'alg':'none','type':'JWT'},_0x5a73b0=_0x1ca91f||'demo-project',_0x3d0cc5=_0x38851c['iat']||0x0,_0xc30220=_0x38851c['sub']||_0x38851c['user_id'];if(!_0xc30220)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x520e50={'iss':'https://securetoken.google.com/'+_0x5a73b0,'aud':_0x5a73b0,'iat':_0x3d0cc5,'exp':_0x3d0cc5+0xe10,'auth_time':_0x3d0cc5,'sub':_0xc30220,'user_id':_0xc30220,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x38851c};return[an(JSON['stringify'](_0x3d024e)),an(JSON['stringify'](_0x520e50)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0xf7bb7a=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xf7bb7a=='object'&&_0xf7bb7a['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x20bde2=W();return _0x20bde2['indexOf']('MSIE\x20')>=0x0||_0x20bde2['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x263350,_0x575006)=>{try{let _0x597804=!0x0;const _0x81f66c='validate-browser-context-for-indexeddb-analytics-module',_0x4de012=self['indexedDB']['open'](_0x81f66c);_0x4de012['onsuccess']=()=>{_0x4de012['result']['close'](),_0x597804||self['indexedDB']['deleteDatabase'](_0x81f66c),_0x263350(!0x0);},_0x4de012['onupgradeneeded']=()=>{_0x597804=!0x1;},_0x4de012['onerror']=()=>{var _0x4eef63;_0x575006(((_0x4eef63=_0x4de012['error'])==null?void 0x0:_0x4eef63['message'])||'');};}catch(_0x162a4c){_0x575006(_0x162a4c);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x4f2033,_0x31583b,_0x1ab67f){super(_0x31583b),this['code']=_0x4f2033,this['customData']=_0x1ab67f,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x116d97,_0xaa23fd,_0x174406){this['service']=_0x116d97,this['serviceName']=_0xaa23fd,this['errors']=_0x174406;}['create'](_0x3c2707,..._0x21842a){const _0x39d41e=_0x21842a[0x0]||{},_0x3bd340=this['service']+'/'+_0x3c2707,_0x54f509=this['errors'][_0x3c2707],_0x1218bc=_0x54f509?gc(_0x54f509,_0x39d41e):'Error',_0x3bcc59=this['serviceName']+':\x20'+_0x1218bc+'\x20('+_0x3bd340+').';return new Se(_0x3bd340,_0x3bcc59,_0x39d41e);}}function gc(_0x4de83c,_0x107300){return _0x4de83c['replace'](mc,(_0xcd6ed4,_0x18e3e4)=>{const _0x151f96=_0x107300[_0x18e3e4];return _0x151f96!=null?String(_0x151f96):'<'+_0x18e3e4+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x405687){return JSON['parse'](_0x405687);}function O(_0x3f1851){return JSON['stringify'](_0x3f1851);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xb3eb91){let _0x216f9a={},_0x3422b2={},_0x5d17d4={},_0x51b6ed='';try{const _0x24340b=_0xb3eb91['split']('.');_0x216f9a=bt(cn(_0x24340b[0x0])||''),_0x3422b2=bt(cn(_0x24340b[0x1])||''),_0x51b6ed=_0x24340b[0x2],_0x5d17d4=_0x3422b2['d']||{},delete _0x3422b2['d'];}catch{}return{'header':_0x216f9a,'claims':_0x3422b2,'data':_0x5d17d4,'signature':_0x51b6ed};},yc=function(_0x36b973){const _0x485688=zr(_0x36b973),_0x14595c=_0x485688['claims'];return!!_0x14595c&&typeof _0x14595c=='object'&&_0x14595c['hasOwnProperty']('iat');},vc=function(_0x5b7df4){const _0x1cfae5=zr(_0x5b7df4)['claims'];return typeof _0x1cfae5=='object'&&_0x1cfae5['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x19fa2b,_0x5d8916){return Object['prototype']['hasOwnProperty']['call'](_0x19fa2b,_0x5d8916);}function Oe(_0x59841f,_0xf9b42e){if(Object['prototype']['hasOwnProperty']['call'](_0x59841f,_0xf9b42e))return _0x59841f[_0xf9b42e];}function hi(_0x52e51c){for(const _0x39f82b in _0x52e51c)if(Object['prototype']['hasOwnProperty']['call'](_0x52e51c,_0x39f82b))return!0x1;return!0x0;}function ln(_0x543d36,_0x262727,_0x39ecf7){const _0x3c65bb={};for(const _0x591f16 in _0x543d36)Object['prototype']['hasOwnProperty']['call'](_0x543d36,_0x591f16)&&(_0x3c65bb[_0x591f16]=_0x262727['call'](_0x39ecf7,_0x543d36[_0x591f16],_0x591f16,_0x543d36));return _0x3c65bb;}function De(_0x4dc898,_0x3c131d){if(_0x4dc898===_0x3c131d)return!0x0;const _0x12402d=Object['keys'](_0x4dc898),_0x3ffaf3=Object['keys'](_0x3c131d);for(const _0x208f20 of _0x12402d){if(!_0x3ffaf3['includes'](_0x208f20))return!0x1;const _0x3201c4=_0x4dc898[_0x208f20],_0x2edbb4=_0x3c131d[_0x208f20];if(ks(_0x3201c4)&&ks(_0x2edbb4)){if(!De(_0x3201c4,_0x2edbb4))return!0x1;}else{if(_0x3201c4!==_0x2edbb4)return!0x1;}}for(const _0x101ac1 of _0x3ffaf3)if(!_0x12402d['includes'](_0x101ac1))return!0x1;return!0x0;}function ks(_0x169d63){return _0x169d63!==null&&typeof _0x169d63=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5303a8){const _0x7776c5=[];for(const [_0x91cc83,_0x223edd]of Object['entries'](_0x5303a8))Array['isArray'](_0x223edd)?_0x223edd['forEach'](_0xc04530=>{_0x7776c5['push'](encodeURIComponent(_0x91cc83)+'='+encodeURIComponent(_0xc04530));}):_0x7776c5['push'](encodeURIComponent(_0x91cc83)+'='+encodeURIComponent(_0x223edd));return _0x7776c5['length']?'&'+_0x7776c5['join']('&'):'';}function yt(_0x13a910){const _0x51b9fe={};return _0x13a910['replace'](/^\?/,'')['split']('&')['forEach'](_0x5954e2=>{if(_0x5954e2){const [_0x366fc3,_0x5dfb03]=_0x5954e2['split']('=');_0x51b9fe[decodeURIComponent(_0x366fc3)]=decodeURIComponent(_0x5dfb03);}}),_0x51b9fe;}function vt(_0x52e609){const _0x476c5f=_0x52e609['indexOf']('?');if(!_0x476c5f)return'';const _0x577271=_0x52e609['indexOf']('#',_0x476c5f);return _0x52e609['substring'](_0x476c5f,_0x577271>0x0?_0x577271:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x58c249=0x1;_0x58c249<this['blockSize'];++_0x58c249)this['pad_'][_0x58c249]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x116aaa,_0x57761a){_0x57761a||(_0x57761a=0x0);const _0x4f7b01=this['W_'];if(typeof _0x116aaa=='string'){for(let _0x1e200d=0x0;_0x1e200d<0x10;_0x1e200d++)_0x4f7b01[_0x1e200d]=_0x116aaa['charCodeAt'](_0x57761a)<<0x18|_0x116aaa['charCodeAt'](_0x57761a+0x1)<<0x10|_0x116aaa['charCodeAt'](_0x57761a+0x2)<<0x8|_0x116aaa['charCodeAt'](_0x57761a+0x3),_0x57761a+=0x4;}else{for(let _0x37cc18=0x0;_0x37cc18<0x10;_0x37cc18++)_0x4f7b01[_0x37cc18]=_0x116aaa[_0x57761a]<<0x18|_0x116aaa[_0x57761a+0x1]<<0x10|_0x116aaa[_0x57761a+0x2]<<0x8|_0x116aaa[_0x57761a+0x3],_0x57761a+=0x4;}for(let _0x1e8b1e=0x10;_0x1e8b1e<0x50;_0x1e8b1e++){const _0x36c5c2=_0x4f7b01[_0x1e8b1e-0x3]^_0x4f7b01[_0x1e8b1e-0x8]^_0x4f7b01[_0x1e8b1e-0xe]^_0x4f7b01[_0x1e8b1e-0x10];_0x4f7b01[_0x1e8b1e]=(_0x36c5c2<<0x1|_0x36c5c2>>>0x1f)&0xffffffff;}let _0x42429d=this['chain_'][0x0],_0x2169aa=this['chain_'][0x1],_0x37e85f=this['chain_'][0x2],_0x46d586=this['chain_'][0x3],_0x35a574=this['chain_'][0x4],_0x41f78d,_0x5cbc94;for(let _0x40d779=0x0;_0x40d779<0x50;_0x40d779++){_0x40d779<0x28?_0x40d779<0x14?(_0x41f78d=_0x46d586^_0x2169aa&(_0x37e85f^_0x46d586),_0x5cbc94=0x5a827999):(_0x41f78d=_0x2169aa^_0x37e85f^_0x46d586,_0x5cbc94=0x6ed9eba1):_0x40d779<0x3c?(_0x41f78d=_0x2169aa&_0x37e85f|_0x46d586&(_0x2169aa|_0x37e85f),_0x5cbc94=0x8f1bbcdc):(_0x41f78d=_0x2169aa^_0x37e85f^_0x46d586,_0x5cbc94=0xca62c1d6);const _0x7dbb25=(_0x42429d<<0x5|_0x42429d>>>0x1b)+_0x41f78d+_0x35a574+_0x5cbc94+_0x4f7b01[_0x40d779]&0xffffffff;_0x35a574=_0x46d586,_0x46d586=_0x37e85f,_0x37e85f=(_0x2169aa<<0x1e|_0x2169aa>>>0x2)&0xffffffff,_0x2169aa=_0x42429d,_0x42429d=_0x7dbb25;}this['chain_'][0x0]=this['chain_'][0x0]+_0x42429d&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2169aa&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x37e85f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x46d586&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x35a574&0xffffffff;}['update'](_0x133ee6,_0xf0c7ef){if(_0x133ee6==null)return;_0xf0c7ef===void 0x0&&(_0xf0c7ef=_0x133ee6['length']);const _0x2da69c=_0xf0c7ef-this['blockSize'];let _0x5e60b6=0x0;const _0x164c05=this['buf_'];let _0x5127a9=this['inbuf_'];for(;_0x5e60b6<_0xf0c7ef;){if(_0x5127a9===0x0){for(;_0x5e60b6<=_0x2da69c;)this['compress_'](_0x133ee6,_0x5e60b6),_0x5e60b6+=this['blockSize'];}if(typeof _0x133ee6=='string'){for(;_0x5e60b6<_0xf0c7ef;)if(_0x164c05[_0x5127a9]=_0x133ee6['charCodeAt'](_0x5e60b6),++_0x5127a9,++_0x5e60b6,_0x5127a9===this['blockSize']){this['compress_'](_0x164c05),_0x5127a9=0x0;break;}}else{for(;_0x5e60b6<_0xf0c7ef;)if(_0x164c05[_0x5127a9]=_0x133ee6[_0x5e60b6],++_0x5127a9,++_0x5e60b6,_0x5127a9===this['blockSize']){this['compress_'](_0x164c05),_0x5127a9=0x0;break;}}}this['inbuf_']=_0x5127a9,this['total_']+=_0xf0c7ef;}['digest'](){const _0x3deaa7=[];let _0x3a9d00=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x32b2b5=this['blockSize']-0x1;_0x32b2b5>=0x38;_0x32b2b5--)this['buf_'][_0x32b2b5]=_0x3a9d00&0xff,_0x3a9d00/=0x100;this['compress_'](this['buf_']);let _0x35335b=0x0;for(let _0x5aee1b=0x0;_0x5aee1b<0x5;_0x5aee1b++)for(let _0x32715c=0x18;_0x32715c>=0x0;_0x32715c-=0x8)_0x3deaa7[_0x35335b]=this['chain_'][_0x5aee1b]>>_0x32715c&0xff,++_0x35335b;return _0x3deaa7;}}function Ic(_0x3109d8,_0xd159b7){const _0x4f5a00=new wc(_0x3109d8,_0xd159b7);return _0x4f5a00['subscribe']['bind'](_0x4f5a00);}class wc{constructor(_0x577584,_0x590539){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x590539,this['task']['then'](()=>{_0x577584(this);})['catch'](_0x9f4952=>{this['error'](_0x9f4952);});}['next'](_0x495d04){this['forEachObserver'](_0x4f344b=>{_0x4f344b['next'](_0x495d04);});}['error'](_0x5c31ba){this['forEachObserver'](_0x550720=>{_0x550720['error'](_0x5c31ba);}),this['close'](_0x5c31ba);}['complete'](){this['forEachObserver'](_0x102e8e=>{_0x102e8e['complete']();}),this['close']();}['subscribe'](_0x23671f,_0x4f0abe,_0x23207f){let _0x3b0461;if(_0x23671f===void 0x0&&_0x4f0abe===void 0x0&&_0x23207f===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x23671f,['next','error','complete'])?_0x3b0461=_0x23671f:_0x3b0461={'next':_0x23671f,'error':_0x4f0abe,'complete':_0x23207f},_0x3b0461['next']===void 0x0&&(_0x3b0461['next']=Qn),_0x3b0461['error']===void 0x0&&(_0x3b0461['error']=Qn),_0x3b0461['complete']===void 0x0&&(_0x3b0461['complete']=Qn);const _0x50c032=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3b0461['error'](this['finalError']):_0x3b0461['complete']();}catch{}}),this['observers']['push'](_0x3b0461),_0x50c032;}['unsubscribeOne'](_0x361020){this['observers']===void 0x0||this['observers'][_0x361020]===void 0x0||(delete this['observers'][_0x361020],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1d6b86){if(!this['finalized']){for(let _0x3c45e7=0x0;_0x3c45e7<this['observers']['length'];_0x3c45e7++)this['sendOne'](_0x3c45e7,_0x1d6b86);}}['sendOne'](_0x2f3bf7,_0xb44933){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2f3bf7]!==void 0x0)try{_0xb44933(this['observers'][_0x2f3bf7]);}catch(_0x24e468){typeof console<'u'&&console['error']&&console['error'](_0x24e468);}});}['close'](_0x46923e){this['finalized']||(this['finalized']=!0x0,_0x46923e!==void 0x0&&(this['finalError']=_0x46923e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0xb27c94,_0xdcb026){if(typeof _0xb27c94!='object'||_0xb27c94===null)return!0x1;for(const _0x18a4b8 of _0xdcb026)if(_0x18a4b8 in _0xb27c94&&typeof _0xb27c94[_0x18a4b8]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x5d9e89,_0x5414b7){return _0x5d9e89+'\x20failed:\x20'+_0x5414b7+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x5b872c){const _0x45b695=[];let _0x3b160f=0x0;for(let _0x40a5e3=0x0;_0x40a5e3<_0x5b872c['length'];_0x40a5e3++){let _0x320ca5=_0x5b872c['charCodeAt'](_0x40a5e3);if(_0x320ca5>=0xd800&&_0x320ca5<=0xdbff){const _0x33c948=_0x320ca5-0xd800;_0x40a5e3++,f(_0x40a5e3<_0x5b872c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x314b2a=_0x5b872c['charCodeAt'](_0x40a5e3)-0xdc00;_0x320ca5=0x10000+(_0x33c948<<0xa)+_0x314b2a;}_0x320ca5<0x80?_0x45b695[_0x3b160f++]=_0x320ca5:_0x320ca5<0x800?(_0x45b695[_0x3b160f++]=_0x320ca5>>0x6|0xc0,_0x45b695[_0x3b160f++]=_0x320ca5&0x3f|0x80):_0x320ca5<0x10000?(_0x45b695[_0x3b160f++]=_0x320ca5>>0xc|0xe0,_0x45b695[_0x3b160f++]=_0x320ca5>>0x6&0x3f|0x80,_0x45b695[_0x3b160f++]=_0x320ca5&0x3f|0x80):(_0x45b695[_0x3b160f++]=_0x320ca5>>0x12|0xf0,_0x45b695[_0x3b160f++]=_0x320ca5>>0xc&0x3f|0x80,_0x45b695[_0x3b160f++]=_0x320ca5>>0x6&0x3f|0x80,_0x45b695[_0x3b160f++]=_0x320ca5&0x3f|0x80);}return _0x45b695;},Pn=function(_0x18fd55){let _0x8bb90b=0x0;for(let _0x1df4aa=0x0;_0x1df4aa<_0x18fd55['length'];_0x1df4aa++){const _0x575867=_0x18fd55['charCodeAt'](_0x1df4aa);_0x575867<0x80?_0x8bb90b++:_0x575867<0x800?_0x8bb90b+=0x2:_0x575867>=0xd800&&_0x575867<=0xdbff?(_0x8bb90b+=0x4,_0x1df4aa++):_0x8bb90b+=0x3;}return _0x8bb90b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x3b1936){return _0x3b1936&&_0x3b1936['_delegate']?_0x3b1936['_delegate']:_0x3b1936;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0xeee13b){try{return(_0xeee13b['startsWith']('http://')||_0xeee13b['startsWith']('https://')?new URL(_0xeee13b)['hostname']:_0xeee13b)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x474f45){return(await fetch(_0x474f45,{'credentials':'include'}))['ok'];}class Me{constructor(_0x47fc11,_0x5ea8dc,_0x22bcd5){this['name']=_0x47fc11,this['instanceFactory']=_0x5ea8dc,this['type']=_0x22bcd5,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3ecbf2){return this['instantiationMode']=_0x3ecbf2,this;}['setMultipleInstances'](_0x507329){return this['multipleInstances']=_0x507329,this;}['setServiceProps'](_0x4bdfdc){return this['serviceProps']=_0x4bdfdc,this;}['setInstanceCreatedCallback'](_0x1ae654){return this['onInstanceCreated']=_0x1ae654,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x514392,_0x559f02){this['name']=_0x514392,this['container']=_0x559f02,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x526bb4){const _0x2d76d0=this['normalizeInstanceIdentifier'](_0x526bb4);if(!this['instancesDeferred']['has'](_0x2d76d0)){const _0x14b922=new Ve();if(this['instancesDeferred']['set'](_0x2d76d0,_0x14b922),this['isInitialized'](_0x2d76d0)||this['shouldAutoInitialize']())try{const _0x672d68=this['getOrInitializeService']({'instanceIdentifier':_0x2d76d0});_0x672d68&&_0x14b922['resolve'](_0x672d68);}catch{}}return this['instancesDeferred']['get'](_0x2d76d0)['promise'];}['getImmediate'](_0x4701ac){const _0x3222fb=this['normalizeInstanceIdentifier'](_0x4701ac==null?void 0x0:_0x4701ac['identifier']),_0x243fa1=(_0x4701ac==null?void 0x0:_0x4701ac['optional'])??!0x1;if(this['isInitialized'](_0x3222fb)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3222fb});}catch(_0x2d8533){if(_0x243fa1)return null;throw _0x2d8533;}else{if(_0x243fa1)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x435f6f){if(_0x435f6f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x435f6f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x435f6f,!!this['shouldAutoInitialize']()){if(Rc(_0x435f6f))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5b3601,_0x1b2970]of this['instancesDeferred']['entries']()){const _0x2ea4e7=this['normalizeInstanceIdentifier'](_0x5b3601);try{const _0x12472c=this['getOrInitializeService']({'instanceIdentifier':_0x2ea4e7});_0x1b2970['resolve'](_0x12472c);}catch{}}}}['clearInstance'](_0x1c8b0d=ke){this['instancesDeferred']['delete'](_0x1c8b0d),this['instancesOptions']['delete'](_0x1c8b0d),this['instances']['delete'](_0x1c8b0d);}async['delete'](){const _0x4eeaa2=Array['from'](this['instances']['values']());await Promise['all']([..._0x4eeaa2['filter'](_0x3b32e9=>'INTERNAL'in _0x3b32e9)['map'](_0x3ea96f=>_0x3ea96f['INTERNAL']['delete']()),..._0x4eeaa2['filter'](_0xb3b838=>'_delete'in _0xb3b838)['map'](_0x2beb41=>_0x2beb41['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4d36b5=ke){return this['instances']['has'](_0x4d36b5);}['getOptions'](_0x143045=ke){return this['instancesOptions']['get'](_0x143045)||{};}['initialize'](_0xd5a113={}){const {options:_0x1af98d={}}=_0xd5a113,_0x1774ae=this['normalizeInstanceIdentifier'](_0xd5a113['instanceIdentifier']);if(this['isInitialized'](_0x1774ae))throw Error(this['name']+'('+_0x1774ae+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x110c8c=this['getOrInitializeService']({'instanceIdentifier':_0x1774ae,'options':_0x1af98d});for(const [_0x319667,_0x45ff2e]of this['instancesDeferred']['entries']()){const _0x2b1667=this['normalizeInstanceIdentifier'](_0x319667);_0x1774ae===_0x2b1667&&_0x45ff2e['resolve'](_0x110c8c);}return _0x110c8c;}['onInit'](_0x9cb5f2,_0x530b1c){const _0x456202=this['normalizeInstanceIdentifier'](_0x530b1c),_0x5423ab=this['onInitCallbacks']['get'](_0x456202)??new Set();_0x5423ab['add'](_0x9cb5f2),this['onInitCallbacks']['set'](_0x456202,_0x5423ab);const _0x30e5a4=this['instances']['get'](_0x456202);return _0x30e5a4&&_0x9cb5f2(_0x30e5a4,_0x456202),()=>{_0x5423ab['delete'](_0x9cb5f2);};}['invokeOnInitCallbacks'](_0x4d4262,_0x57b7a0){const _0x321df7=this['onInitCallbacks']['get'](_0x57b7a0);if(_0x321df7){for(const _0x57bc71 of _0x321df7)try{_0x57bc71(_0x4d4262,_0x57b7a0);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5bca2e,options:_0x4f00d6={}}){let _0x5a71ab=this['instances']['get'](_0x5bca2e);if(!_0x5a71ab&&this['component']&&(_0x5a71ab=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5bca2e),'options':_0x4f00d6}),this['instances']['set'](_0x5bca2e,_0x5a71ab),this['instancesOptions']['set'](_0x5bca2e,_0x4f00d6),this['invokeOnInitCallbacks'](_0x5a71ab,_0x5bca2e),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5bca2e,_0x5a71ab);}catch{}return _0x5a71ab||null;}['normalizeInstanceIdentifier'](_0x4b0d32=ke){return this['component']?this['component']['multipleInstances']?_0x4b0d32:ke:_0x4b0d32;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x355134){return _0x355134===ke?void 0x0:_0x355134;}function Rc(_0x5cd149){return _0x5cd149['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x227734){this['name']=_0x227734,this['providers']=new Map();}['addComponent'](_0x240bea){const _0x3dc036=this['getProvider'](_0x240bea['name']);if(_0x3dc036['isComponentSet']())throw new Error('Component\x20'+_0x240bea['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3dc036['setComponent'](_0x240bea);}['addOrOverwriteComponent'](_0x1e25ff){this['getProvider'](_0x1e25ff['name'])['isComponentSet']()&&this['providers']['delete'](_0x1e25ff['name']),this['addComponent'](_0x1e25ff);}['getProvider'](_0x14787e){if(this['providers']['has'](_0x14787e))return this['providers']['get'](_0x14787e);const _0x3d22c2=new Sc(_0x14787e,this);return this['providers']['set'](_0x14787e,_0x3d22c2),_0x3d22c2;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x165556){_0x165556[_0x165556['DEBUG']=0x0]='DEBUG',_0x165556[_0x165556['VERBOSE']=0x1]='VERBOSE',_0x165556[_0x165556['INFO']=0x2]='INFO',_0x165556[_0x165556['WARN']=0x3]='WARN',_0x165556[_0x165556['ERROR']=0x4]='ERROR',_0x165556[_0x165556['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x272f16,_0x5bff60,..._0x157b04)=>{if(_0x5bff60<_0x272f16['logLevel'])return;const _0x106c49=new Date()['toISOString'](),_0x50fc1e=Pc[_0x5bff60];if(_0x50fc1e)console[_0x50fc1e]('['+_0x106c49+']\x20\x20'+_0x272f16['name']+':',..._0x157b04);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5bff60+')');};class xi{constructor(_0x2c7642){this['name']=_0x2c7642,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2ff629){if(!(_0x2ff629 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2ff629+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2ff629;}['setLogLevel'](_0x4b9ffc){this['_logLevel']=typeof _0x4b9ffc=='string'?kc[_0x4b9ffc]:_0x4b9ffc;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x29998b){if(typeof _0x29998b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x29998b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1fb717){this['_userLogHandler']=_0x1fb717;}['debug'](..._0x4358b9){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4358b9),this['_logHandler'](this,T['DEBUG'],..._0x4358b9);}['log'](..._0x525a3c){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x525a3c),this['_logHandler'](this,T['VERBOSE'],..._0x525a3c);}['info'](..._0x44c475){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x44c475),this['_logHandler'](this,T['INFO'],..._0x44c475);}['warn'](..._0x5de6db){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x5de6db),this['_logHandler'](this,T['WARN'],..._0x5de6db);}['error'](..._0x3cce0a){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3cce0a),this['_logHandler'](this,T['ERROR'],..._0x3cce0a);}}const Dc=(_0x1c5096,_0x36e2df)=>_0x36e2df['some'](_0xc29c48=>_0x1c5096 instanceof _0xc29c48);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x114dc7){const _0x15abc0=new Promise((_0x1771b3,_0x4d77e7)=>{const _0x4c1842=()=>{_0x114dc7['removeEventListener']('success',_0x1b6b2e),_0x114dc7['removeEventListener']('error',_0x16891f);},_0x1b6b2e=()=>{_0x1771b3(_e(_0x114dc7['result'])),_0x4c1842();},_0x16891f=()=>{_0x4d77e7(_0x114dc7['error']),_0x4c1842();};_0x114dc7['addEventListener']('success',_0x1b6b2e),_0x114dc7['addEventListener']('error',_0x16891f);});return _0x15abc0['then'](_0x2e811c=>{_0x2e811c instanceof IDBCursor&&Kr['set'](_0x2e811c,_0x114dc7);})['catch'](()=>{}),Fi['set'](_0x15abc0,_0x114dc7),_0x15abc0;}function Fc(_0x29941e){if(ui['has'](_0x29941e))return;const _0x2e1d1e=new Promise((_0x3bcbf,_0x383eb9)=>{const _0x477402=()=>{_0x29941e['removeEventListener']('complete',_0x1505e8),_0x29941e['removeEventListener']('error',_0x3de0e4),_0x29941e['removeEventListener']('abort',_0x3de0e4);},_0x1505e8=()=>{_0x3bcbf(),_0x477402();},_0x3de0e4=()=>{_0x383eb9(_0x29941e['error']||new DOMException('AbortError','AbortError')),_0x477402();};_0x29941e['addEventListener']('complete',_0x1505e8),_0x29941e['addEventListener']('error',_0x3de0e4),_0x29941e['addEventListener']('abort',_0x3de0e4);});ui['set'](_0x29941e,_0x2e1d1e);}let di={'get'(_0x5e64bb,_0x5648c4,_0x38cf4c){if(_0x5e64bb instanceof IDBTransaction){if(_0x5648c4==='done')return ui['get'](_0x5e64bb);if(_0x5648c4==='objectStoreNames')return _0x5e64bb['objectStoreNames']||Yr['get'](_0x5e64bb);if(_0x5648c4==='store')return _0x38cf4c['objectStoreNames'][0x1]?void 0x0:_0x38cf4c['objectStore'](_0x38cf4c['objectStoreNames'][0x0]);}return _e(_0x5e64bb[_0x5648c4]);},'set'(_0x30e26d,_0x58bf73,_0x5b911e){return _0x30e26d[_0x58bf73]=_0x5b911e,!0x0;},'has'(_0x2385bc,_0x30e8a6){return _0x2385bc instanceof IDBTransaction&&(_0x30e8a6==='done'||_0x30e8a6==='store')?!0x0:_0x30e8a6 in _0x2385bc;}};function Uc(_0x8cc97d){di=_0x8cc97d(di);}function Wc(_0xc18ba6){return _0xc18ba6===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2ef886,..._0x1d81dc){const _0x62b115=_0xc18ba6['call'](Xn(this),_0x2ef886,..._0x1d81dc);return Yr['set'](_0x62b115,_0x2ef886['sort']?_0x2ef886['sort']():[_0x2ef886]),_e(_0x62b115);}:Lc()['includes'](_0xc18ba6)?function(..._0x2c371f){return _0xc18ba6['apply'](Xn(this),_0x2c371f),_e(Kr['get'](this));}:function(..._0x2b6471){return _e(_0xc18ba6['apply'](Xn(this),_0x2b6471));};}function Bc(_0x2df5b8){return typeof _0x2df5b8=='function'?Wc(_0x2df5b8):(_0x2df5b8 instanceof IDBTransaction&&Fc(_0x2df5b8),Dc(_0x2df5b8,Mc())?new Proxy(_0x2df5b8,di):_0x2df5b8);}function _e(_0x40f83f){if(_0x40f83f instanceof IDBRequest)return xc(_0x40f83f);if(Jn['has'](_0x40f83f))return Jn['get'](_0x40f83f);const _0x2c89cd=Bc(_0x40f83f);return _0x2c89cd!==_0x40f83f&&(Jn['set'](_0x40f83f,_0x2c89cd),Fi['set'](_0x2c89cd,_0x40f83f)),_0x2c89cd;}const Xn=_0x51f152=>Fi['get'](_0x51f152);function Vc(_0x31d4d3,_0xc39d46,{blocked:_0xc6aa54,upgrade:_0x15df14,blocking:_0x394756,terminated:_0x13a43e}={}){const _0x5179cb=indexedDB['open'](_0x31d4d3,_0xc39d46),_0x1c08f3=_e(_0x5179cb);return _0x15df14&&_0x5179cb['addEventListener']('upgradeneeded',_0x2eb41c=>{_0x15df14(_e(_0x5179cb['result']),_0x2eb41c['oldVersion'],_0x2eb41c['newVersion'],_e(_0x5179cb['transaction']),_0x2eb41c);}),_0xc6aa54&&_0x5179cb['addEventListener']('blocked',_0x668a66=>_0xc6aa54(_0x668a66['oldVersion'],_0x668a66['newVersion'],_0x668a66)),_0x1c08f3['then'](_0x540eed=>{_0x13a43e&&_0x540eed['addEventListener']('close',()=>_0x13a43e()),_0x394756&&_0x540eed['addEventListener']('versionchange',_0x3b2edd=>_0x394756(_0x3b2edd['oldVersion'],_0x3b2edd['newVersion'],_0x3b2edd));})['catch'](()=>{}),_0x1c08f3;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x50a40b,_0x160604){if(!(_0x50a40b instanceof IDBDatabase&&!(_0x160604 in _0x50a40b)&&typeof _0x160604=='string'))return;if(Zn['get'](_0x160604))return Zn['get'](_0x160604);const _0x174213=_0x160604['replace'](/FromIndex$/,''),_0x4f03d9=_0x160604!==_0x174213,_0x1a91c5=$c['includes'](_0x174213);if(!(_0x174213 in(_0x4f03d9?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1a91c5||Hc['includes'](_0x174213)))return;const _0xb0d5fa=async function(_0x5cfa3c,..._0x12797a){const _0x2624a9=this['transaction'](_0x5cfa3c,_0x1a91c5?'readwrite':'readonly');let _0x2ee2af=_0x2624a9['store'];return _0x4f03d9&&(_0x2ee2af=_0x2ee2af['index'](_0x12797a['shift']())),(await Promise['all']([_0x2ee2af[_0x174213](..._0x12797a),_0x1a91c5&&_0x2624a9['done']]))[0x0];};return Zn['set'](_0x160604,_0xb0d5fa),_0xb0d5fa;}Uc(_0x450bfe=>({..._0x450bfe,'get':(_0x49c38a,_0xee71bd,_0x3a35f8)=>Os(_0x49c38a,_0xee71bd)||_0x450bfe['get'](_0x49c38a,_0xee71bd,_0x3a35f8),'has':(_0x4edf54,_0x17b757)=>!!Os(_0x4edf54,_0x17b757)||_0x450bfe['has'](_0x4edf54,_0x17b757)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x327668){this['container']=_0x327668;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2d7ce5=>{if(qc(_0x2d7ce5)){const _0x1103b7=_0x2d7ce5['getImmediate']();return _0x1103b7['library']+'/'+_0x1103b7['version'];}else return null;})['filter'](_0x110b9f=>_0x110b9f)['join']('\x20');}}function qc(_0x1dbd2b){const _0x301455=_0x1dbd2b['getComponent']();return(_0x301455==null?void 0x0:_0x301455['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x1e033d,_0x1df6c4){try{_0x1e033d['container']['addComponent'](_0x1df6c4);}catch(_0xba7478){re['debug']('Component\x20'+_0x1df6c4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1e033d['name'],_0xba7478);}}function et(_0x4dd234){const _0x54a3d0=_0x4dd234['name'];if(gi['has'](_0x54a3d0))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x54a3d0+'.'),!0x1;gi['set'](_0x54a3d0,_0x4dd234);for(const _0x538a26 of Le['values']())Ms(_0x538a26,_0x4dd234);for(const _0x20b2ac of _i['values']())Ms(_0x20b2ac,_0x4dd234);return!0x0;}function Ui(_0x2a26eb,_0x36d5b0){const _0x4f937c=_0x2a26eb['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4f937c&&_0x4f937c['triggerHeartbeat'](),_0x2a26eb['container']['getProvider'](_0x36d5b0);}function H(_0x245b87){return _0x245b87==null?!0x1:_0x245b87['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x33ff3b,_0x257f41,_0x34ed2e){this['_isDeleted']=!0x1,this['_options']={..._0x33ff3b},this['_config']={..._0x257f41},this['_name']=_0x257f41['name'],this['_automaticDataCollectionEnabled']=_0x257f41['automaticDataCollectionEnabled'],this['_container']=_0x34ed2e,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x52eadd){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x52eadd;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x16703f){this['_isDeleted']=_0x16703f;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0xa15aeb,_0x5e5356={}){let _0x4235e6=_0xa15aeb;typeof _0x5e5356!='object'&&(_0x5e5356={'name':_0x5e5356});const _0x3f8a05={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x5e5356},_0xc3d95d=_0x3f8a05['name'];if(typeof _0xc3d95d!='string'||!_0xc3d95d)throw ge['create']('bad-app-name',{'appName':String(_0xc3d95d)});if(_0x4235e6||(_0x4235e6=$r()),!_0x4235e6)throw ge['create']('no-options');const _0x771e67=Le['get'](_0xc3d95d);if(_0x771e67){if(De(_0x4235e6,_0x771e67['options'])&&De(_0x3f8a05,_0x771e67['config']))return _0x771e67;throw ge['create']('duplicate-app',{'appName':_0xc3d95d});}const _0x316f2e=new Ac(_0xc3d95d);for(const _0x114504 of gi['values']())_0x316f2e['addComponent'](_0x114504);const _0x397f4d=new Il(_0x4235e6,_0x3f8a05,_0x316f2e);return Le['set'](_0xc3d95d,_0x397f4d),_0x397f4d;}function Qr(_0x438c07=pi){const _0x46496f=Le['get'](_0x438c07);if(!_0x46496f&&_0x438c07===pi&&$r())return wl();if(!_0x46496f)throw ge['create']('no-app',{'appName':_0x438c07});return _0x46496f;}function l_(){return Array['from'](Le['values']());}async function h_(_0xc61425){let _0x1b6518=!0x1;const _0x57ba73=_0xc61425['name'];Le['has'](_0x57ba73)?(_0x1b6518=!0x0,Le['delete'](_0x57ba73)):_i['has'](_0x57ba73)&&_0xc61425['decRefCount']()<=0x0&&(_i['delete'](_0x57ba73),_0x1b6518=!0x0),_0x1b6518&&(await Promise['all'](_0xc61425['container']['getProviders']()['map'](_0x563ae1=>_0x563ae1['delete']())),_0xc61425['isDeleted']=!0x0);}function me(_0x38c8de,_0x1a4434,_0xaf825a){let _0x1b9287=vl[_0x38c8de]??_0x38c8de;_0xaf825a&&(_0x1b9287+='-'+_0xaf825a);const _0x2e21bb=_0x1b9287['match'](/\s|\//),_0x32e1a1=_0x1a4434['match'](/\s|\//);if(_0x2e21bb||_0x32e1a1){const _0x36d1f9=['Unable\x20to\x20register\x20library\x20\x22'+_0x1b9287+'\x22\x20with\x20version\x20\x22'+_0x1a4434+'\x22:'];_0x2e21bb&&_0x36d1f9['push']('library\x20name\x20\x22'+_0x1b9287+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2e21bb&&_0x32e1a1&&_0x36d1f9['push']('and'),_0x32e1a1&&_0x36d1f9['push']('version\x20name\x20\x22'+_0x1a4434+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x36d1f9['join']('\x20'));return;}et(new Me(_0x1b9287+'-version',()=>({'library':_0x1b9287,'version':_0x1a4434}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1fb58e,_0x2d0de8)=>{switch(_0x2d0de8){case 0x0:try{_0x1fb58e['createObjectStore'](Rt);}catch(_0x17d296){console['warn'](_0x17d296);}}}})['catch'](_0x48e215=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x48e215['message']});})),ei;}async function Sl(_0x28933d){try{const _0x3d3252=(await Jr())['transaction'](Rt),_0x1338e2=await _0x3d3252['objectStore'](Rt)['get'](Xr(_0x28933d));return await _0x3d3252['done'],_0x1338e2;}catch(_0x32cdf6){if(_0x32cdf6 instanceof Se)re['warn'](_0x32cdf6['message']);else{const _0xac7c9a=ge['create']('idb-get',{'originalErrorMessage':_0x32cdf6==null?void 0x0:_0x32cdf6['message']});re['warn'](_0xac7c9a['message']);}}}async function Ls(_0x27f4d5,_0xc2f868){try{const _0x419d8c=(await Jr())['transaction'](Rt,'readwrite');await _0x419d8c['objectStore'](Rt)['put'](_0xc2f868,Xr(_0x27f4d5)),await _0x419d8c['done'];}catch(_0x3ee540){if(_0x3ee540 instanceof Se)re['warn'](_0x3ee540['message']);else{const _0x1f7431=ge['create']('idb-set',{'originalErrorMessage':_0x3ee540==null?void 0x0:_0x3ee540['message']});re['warn'](_0x1f7431['message']);}}}function Xr(_0x5c4bbd){return _0x5c4bbd['name']+'!'+_0x5c4bbd['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x13fa02){this['container']=_0x13fa02,this['_heartbeatsCache']=null;const _0x35282b=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x35282b),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1ab04c=>(this['_heartbeatsCache']=_0x1ab04c,_0x1ab04c));}async['triggerHeartbeat'](){var _0x3d8940,_0x309d08;try{const _0x2bf5fc=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x28c3d7=xs();if(((_0x3d8940=this['_heartbeatsCache'])==null?void 0x0:_0x3d8940['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x309d08=this['_heartbeatsCache'])==null?void 0x0:_0x309d08['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x28c3d7||this['_heartbeatsCache']['heartbeats']['some'](_0x12116e=>_0x12116e['date']===_0x28c3d7))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x28c3d7,'agent':_0x2bf5fc}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1df456=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1df456,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x29517c){re['warn'](_0x29517c);}}async['getHeartbeatsHeader'](){var _0x3ac290;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3ac290=this['_heartbeatsCache'])==null?void 0x0:_0x3ac290['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x423366=xs(),{heartbeatsToSend:_0x23b33c,unsentEntries:_0xaa1d02}=kl(this['_heartbeatsCache']['heartbeats']),_0x10632d=an(JSON['stringify']({'version':0x2,'heartbeats':_0x23b33c}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x423366,_0xaa1d02['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xaa1d02,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x10632d;}catch(_0x218fa9){return re['warn'](_0x218fa9),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x22e79d,_0x23c1d0=bl){const _0x2e43e4=[];let _0x28d196=_0x22e79d['slice']();for(const _0x36f37f of _0x22e79d){const _0x47c7cf=_0x2e43e4['find'](_0x50ea7d=>_0x50ea7d['agent']===_0x36f37f['agent']);if(_0x47c7cf){if(_0x47c7cf['dates']['push'](_0x36f37f['date']),Fs(_0x2e43e4)>_0x23c1d0){_0x47c7cf['dates']['pop']();break;}}else{if(_0x2e43e4['push']({'agent':_0x36f37f['agent'],'dates':[_0x36f37f['date']]}),Fs(_0x2e43e4)>_0x23c1d0){_0x2e43e4['pop']();break;}}_0x28d196=_0x28d196['slice'](0x1);}return{'heartbeatsToSend':_0x2e43e4,'unsentEntries':_0x28d196};}class Nl{constructor(_0x45dec9){this['app']=_0x45dec9,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4563f0=await Sl(this['app']);return _0x4563f0!=null&&_0x4563f0['heartbeats']?_0x4563f0:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x21e310){if(await this['_canUseIndexedDBPromise']){const _0x52d745=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x21e310['lastSentHeartbeatDate']??_0x52d745['lastSentHeartbeatDate'],'heartbeats':_0x21e310['heartbeats']});}else return;}async['add'](_0x22ef4){if(await this['_canUseIndexedDBPromise']){const _0x49a7b6=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x22ef4['lastSentHeartbeatDate']??_0x49a7b6['lastSentHeartbeatDate'],'heartbeats':[..._0x49a7b6['heartbeats'],..._0x22ef4['heartbeats']]});}else return;}}function Fs(_0x2839a5){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x2839a5}))['length'];}function Pl(_0x809012){if(_0x809012['length']===0x0)return-0x1;let _0x519849=0x0,_0x12e2b5=_0x809012[0x0]['date'];for(let _0x2c424f=0x1;_0x2c424f<_0x809012['length'];_0x2c424f++)_0x809012[_0x2c424f]['date']<_0x12e2b5&&(_0x12e2b5=_0x809012[_0x2c424f]['date'],_0x519849=_0x2c424f);return _0x519849;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x41785f){et(new Me('platform-logger',_0x2746ec=>new Gc(_0x2746ec),'PRIVATE')),et(new Me('heartbeat',_0x1171cd=>new Al(_0x1171cd),'PRIVATE')),me(fi,Ds,_0x41785f),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x175d59){Zr=_0x175d59;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x5a444d){this['domStorage_']=_0x5a444d,this['prefix_']='firebase:';}['set'](_0x3e6918,_0x38244c){_0x38244c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3e6918)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3e6918),O(_0x38244c));}['get'](_0x102598){const _0x4858cb=this['domStorage_']['getItem'](this['prefixedName_'](_0x102598));return _0x4858cb==null?null:bt(_0x4858cb);}['remove'](_0x954bf){this['domStorage_']['removeItem'](this['prefixedName_'](_0x954bf));}['prefixedName_'](_0x511695){return this['prefix_']+_0x511695;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x586d02,_0x34b7bc){_0x34b7bc==null?delete this['cache_'][_0x586d02]:this['cache_'][_0x586d02]=_0x34b7bc;}['get'](_0x2a5345){return Y(this['cache_'],_0x2a5345)?this['cache_'][_0x2a5345]:null;}['remove'](_0x27f535){delete this['cache_'][_0x27f535];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x39d31e){try{if(typeof window<'u'&&typeof window[_0x39d31e]<'u'){const _0x34d7bc=window[_0x39d31e];return _0x34d7bc['setItem']('firebase:sentinel','cache'),_0x34d7bc['removeItem']('firebase:sentinel'),new xl(_0x34d7bc);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x22c8b3=0x1;return function(){return _0x22c8b3++;};}()),no=function(_0x4197cb){const _0x535612=Tc(_0x4197cb),_0x36f25c=new Ec();_0x36f25c['update'](_0x535612);const _0x384178=_0x36f25c['digest']();return Di['encodeByteArray'](_0x384178);},Bt=function(..._0x3833c4){let _0x21880d='';for(let _0x265c06=0x0;_0x265c06<_0x3833c4['length'];_0x265c06++){const _0x10d4e0=_0x3833c4[_0x265c06];Array['isArray'](_0x10d4e0)||_0x10d4e0&&typeof _0x10d4e0=='object'&&typeof _0x10d4e0['length']=='number'?_0x21880d+=Bt['apply'](null,_0x10d4e0):typeof _0x10d4e0=='object'?_0x21880d+=O(_0x10d4e0):_0x21880d+=_0x10d4e0,_0x21880d+='\x20';}return _0x21880d;};let Et=null,Vs=!0x0;const Wl=function(_0x387d2e,_0x349046){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5f30b1){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x2a1a86=Bt['apply'](null,_0x5f30b1);Et(_0x2a1a86);}},Vt=function(_0xd826f){return function(..._0x4f6b7e){L(_0xd826f,..._0x4f6b7e);};},mi=function(..._0x1fc42d){const _0xccd33c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x1fc42d);Qe['error'](_0xccd33c);},oe=function(..._0x9db7ed){const _0xeb77a8='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x9db7ed);throw Qe['error'](_0xeb77a8),new Error(_0xeb77a8);},U=function(..._0x1a6edf){const _0x19ef0a='FIREBASE\x20WARNING:\x20'+Bt(..._0x1a6edf);Qe['warn'](_0x19ef0a);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x549b8e){return typeof _0x549b8e=='number'&&(_0x549b8e!==_0x549b8e||_0x549b8e===Number['POSITIVE_INFINITY']||_0x549b8e===Number['NEGATIVE_INFINITY']);},Vl=function(_0x11d33d){if(document['readyState']==='complete')_0x11d33d();else{let _0x4e8db8=!0x1;const _0x41ecd6=function(){if(!document['body']){setTimeout(_0x41ecd6,Math['floor'](0xa));return;}_0x4e8db8||(_0x4e8db8=!0x0,_0x11d33d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x41ecd6,!0x1),window['addEventListener']('load',_0x41ecd6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x41ecd6();}),window['attachEvent']('onload',_0x41ecd6));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x44538e,_0x2a1957){if(_0x44538e===_0x2a1957)return 0x0;if(_0x44538e===xe||_0x2a1957===Ie)return-0x1;if(_0x2a1957===xe||_0x44538e===Ie)return 0x1;{const _0x20db31=Hs(_0x44538e),_0x446226=Hs(_0x2a1957);return _0x20db31!==null?_0x446226!==null?_0x20db31-_0x446226===0x0?_0x44538e['length']-_0x2a1957['length']:_0x20db31-_0x446226:-0x1:_0x446226!==null?0x1:_0x44538e<_0x2a1957?-0x1:0x1;}},Hl=function(_0x192140,_0x1355fd){return _0x192140===_0x1355fd?0x0:_0x192140<_0x1355fd?-0x1:0x1;},pt=function(_0x25bef3,_0x538f53){if(_0x538f53&&_0x25bef3 in _0x538f53)return _0x538f53[_0x25bef3];throw new Error('Missing\x20required\x20key\x20('+_0x25bef3+')\x20in\x20object:\x20'+O(_0x538f53));},Bi=function(_0x4df8c9){if(typeof _0x4df8c9!='object'||_0x4df8c9===null)return O(_0x4df8c9);const _0x175258=[];for(const _0x98aea4 in _0x4df8c9)_0x175258['push'](_0x98aea4);_0x175258['sort']();let _0x37b852='{';for(let _0x1f9637=0x0;_0x1f9637<_0x175258['length'];_0x1f9637++)_0x1f9637!==0x0&&(_0x37b852+=','),_0x37b852+=O(_0x175258[_0x1f9637]),_0x37b852+=':',_0x37b852+=Bi(_0x4df8c9[_0x175258[_0x1f9637]]);return _0x37b852+='}',_0x37b852;},io=function(_0x48ef5f,_0x4b21b5){const _0x276c3e=_0x48ef5f['length'];if(_0x276c3e<=_0x4b21b5)return[_0x48ef5f];const _0x2ff2d1=[];for(let _0x5c389c=0x0;_0x5c389c<_0x276c3e;_0x5c389c+=_0x4b21b5)_0x5c389c+_0x4b21b5>_0x276c3e?_0x2ff2d1['push'](_0x48ef5f['substring'](_0x5c389c,_0x276c3e)):_0x2ff2d1['push'](_0x48ef5f['substring'](_0x5c389c,_0x5c389c+_0x4b21b5));return _0x2ff2d1;};function x(_0x4b25b3,_0xd579cb){for(const _0x27ce48 in _0x4b25b3)_0x4b25b3['hasOwnProperty'](_0x27ce48)&&_0xd579cb(_0x27ce48,_0x4b25b3[_0x27ce48]);}const so=function(_0x216cad){f(!Wi(_0x216cad),'Invalid\x20JSON\x20number');const _0x24afae=0xb,_0xf01a48=0x34,_0x5e628e=(0x1<<_0x24afae-0x1)-0x1;let _0x409a4b,_0x52f4b2,_0x4a80db,_0x1b606c,_0x299583;_0x216cad===0x0?(_0x52f4b2=0x0,_0x4a80db=0x0,_0x409a4b=0x1/_0x216cad===-0x1/0x0?0x1:0x0):(_0x409a4b=_0x216cad<0x0,_0x216cad=Math['abs'](_0x216cad),_0x216cad>=Math['pow'](0x2,0x1-_0x5e628e)?(_0x1b606c=Math['min'](Math['floor'](Math['log'](_0x216cad)/Math['LN2']),_0x5e628e),_0x52f4b2=_0x1b606c+_0x5e628e,_0x4a80db=Math['round'](_0x216cad*Math['pow'](0x2,_0xf01a48-_0x1b606c)-Math['pow'](0x2,_0xf01a48))):(_0x52f4b2=0x0,_0x4a80db=Math['round'](_0x216cad/Math['pow'](0x2,0x1-_0x5e628e-_0xf01a48))));const _0x4939f5=[];for(_0x299583=_0xf01a48;_0x299583;_0x299583-=0x1)_0x4939f5['push'](_0x4a80db%0x2?0x1:0x0),_0x4a80db=Math['floor'](_0x4a80db/0x2);for(_0x299583=_0x24afae;_0x299583;_0x299583-=0x1)_0x4939f5['push'](_0x52f4b2%0x2?0x1:0x0),_0x52f4b2=Math['floor'](_0x52f4b2/0x2);_0x4939f5['push'](_0x409a4b?0x1:0x0),_0x4939f5['reverse']();const _0x4e7b32=_0x4939f5['join']('');let _0x4fa6d1='';for(_0x299583=0x0;_0x299583<0x40;_0x299583+=0x8){let _0x464e1e=parseInt(_0x4e7b32['substr'](_0x299583,0x8),0x2)['toString'](0x10);_0x464e1e['length']===0x1&&(_0x464e1e='0'+_0x464e1e),_0x4fa6d1=_0x4fa6d1+_0x464e1e;}return _0x4fa6d1['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x4785ba,_0x20d973){let _0x9acf5e='Unknown\x20Error';_0x4785ba==='too_big'?_0x9acf5e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4785ba==='permission_denied'?_0x9acf5e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4785ba==='unavailable'&&(_0x9acf5e='The\x20service\x20is\x20unavailable');const _0x5dbde6=new Error(_0x4785ba+'\x20at\x20'+_0x20d973['_path']['toString']()+':\x20'+_0x9acf5e);return _0x5dbde6['code']=_0x4785ba['toUpperCase'](),_0x5dbde6;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x4c4bbe){if(zl['test'](_0x4c4bbe)){const _0xc829c9=Number(_0x4c4bbe);if(_0xc829c9>=jl&&_0xc829c9<=Kl)return _0xc829c9;}return null;},lt=function(_0x2f4440){try{_0x2f4440();}catch(_0x247c9f){setTimeout(()=>{const _0x7b8a18=_0x247c9f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x7b8a18),_0x247c9f;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x592fe5,_0x36b27f){const _0xf719bf=setTimeout(_0x592fe5,_0x36b27f);return typeof _0xf719bf=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xf719bf):typeof _0xf719bf=='object'&&_0xf719bf['unref']&&_0xf719bf['unref'](),_0xf719bf;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x48d11c,_0x34cbc3){this['appCheckProvider']=_0x34cbc3,this['appName']=_0x48d11c['name'],H(_0x48d11c)&&_0x48d11c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x48d11c['settings']['appCheckToken']),this['appCheck']=_0x34cbc3==null?void 0x0:_0x34cbc3['getImmediate']({'optional':!0x0}),this['appCheck']||_0x34cbc3==null||_0x34cbc3['get']()['then'](_0x3127e2=>this['appCheck']=_0x3127e2);}['getToken'](_0xc5f3c9){if(this['serverAppAppCheckToken']){if(_0xc5f3c9)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xc5f3c9):new Promise((_0x3ec189,_0x34cc8a)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xc5f3c9)['then'](_0x3ec189,_0x34cc8a):_0x3ec189(null);},0x0);});}['addTokenChangeListener'](_0x218218){var _0x87c670;(_0x87c670=this['appCheckProvider'])==null||_0x87c670['get']()['then'](_0x4d044e=>_0x4d044e['addTokenListener'](_0x218218));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x3240d7,_0x215118,_0xa42b75){this['appName_']=_0x3240d7,this['firebaseOptions_']=_0x215118,this['authProvider_']=_0xa42b75,this['auth_']=null,this['auth_']=_0xa42b75['getImmediate']({'optional':!0x0}),this['auth_']||_0xa42b75['onInit'](_0x5ab643=>this['auth_']=_0x5ab643);}['getToken'](_0x32c8c1){return this['auth_']?this['auth_']['getToken'](_0x32c8c1)['catch'](_0x2fb36b=>_0x2fb36b&&_0x2fb36b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2fb36b)):new Promise((_0x450f9e,_0x5b250a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x32c8c1)['then'](_0x450f9e,_0x5b250a):_0x450f9e(null);},0x0);});}['addTokenChangeListener'](_0x195e5d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x195e5d):this['authProvider_']['get']()['then'](_0x1c7f93=>_0x1c7f93['addAuthTokenListener'](_0x195e5d));}['removeTokenChangeListener'](_0x3750fd){this['authProvider_']['get']()['then'](_0x4e10b4=>_0x4e10b4['removeAuthTokenListener'](_0x3750fd));}['notifyForInvalidToken'](){let _0x2c29ed='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2c29ed+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2c29ed+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2c29ed+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2c29ed);}}class tn{constructor(_0x2c77f7){this['accessToken']=_0x2c77f7;}['getToken'](_0x180509){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x391c35){_0x391c35(this['accessToken']);}['removeTokenChangeListener'](_0x16f3df){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x35ef49,_0x57c437,_0x6ff315,_0x1997fa,_0x74656a=!0x1,_0x57e580='',_0x35e7c8=!0x1,_0x5309e8=!0x1,_0x30139b=null){this['secure']=_0x57c437,this['namespace']=_0x6ff315,this['webSocketOnly']=_0x1997fa,this['nodeAdmin']=_0x74656a,this['persistenceKey']=_0x57e580,this['includeNamespaceInQueryParams']=_0x35e7c8,this['isUsingEmulator']=_0x5309e8,this['emulatorOptions']=_0x30139b,this['_host']=_0x35ef49['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x35ef49)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x484660){_0x484660!==this['internalHost']&&(this['internalHost']=_0x484660,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x50e277=this['toURLString']();return this['persistenceKey']&&(_0x50e277+='<'+this['persistenceKey']+'>'),_0x50e277;}['toURLString'](){const _0x17cdea=this['secure']?'https://':'http://',_0x20656b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x17cdea+this['host']+'/'+_0x20656b;}}function Xl(_0x463641){return _0x463641['host']!==_0x463641['internalHost']||_0x463641['isCustomHost']()||_0x463641['includeNamespaceInQueryParams'];}function go(_0x350b24,_0x41915d,_0x550399){f(typeof _0x41915d=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x550399=='object','typeof\x20params\x20must\x20==\x20object');let _0x20f249;if(_0x41915d===fo)_0x20f249=(_0x350b24['secure']?'wss://':'ws://')+_0x350b24['internalHost']+'/.ws?';else{if(_0x41915d===po)_0x20f249=(_0x350b24['secure']?'https://':'http://')+_0x350b24['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x41915d);}Xl(_0x350b24)&&(_0x550399['ns']=_0x350b24['namespace']);const _0x58ad21=[];return x(_0x550399,(_0x33572e,_0x43c2bf)=>{_0x58ad21['push'](_0x33572e+'='+_0x43c2bf);}),_0x20f249+_0x58ad21['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5ddfd3,_0x45517e=0x1){Y(this['counters_'],_0x5ddfd3)||(this['counters_'][_0x5ddfd3]=0x0),this['counters_'][_0x5ddfd3]+=_0x45517e;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x127e98){const _0x2ae038=_0x127e98['toString']();return ti[_0x2ae038]||(ti[_0x2ae038]=new Zl()),ti[_0x2ae038];}function eh(_0x170fa0,_0xc50ff0){const _0x5a58b7=_0x170fa0['toString']();return ni[_0x5a58b7]||(ni[_0x5a58b7]=_0xc50ff0()),ni[_0x5a58b7];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x53be61){this['onMessage_']=_0x53be61,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x46df34,_0x519020){this['closeAfterResponse']=_0x46df34,this['onClose']=_0x519020,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1dfbbd,_0x117f0f){for(this['pendingResponses'][_0x1dfbbd]=_0x117f0f;this['pendingResponses'][this['currentResponseNum']];){const _0x3ebfe4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5a29b0=0x0;_0x5a29b0<_0x3ebfe4['length'];++_0x5a29b0)_0x3ebfe4[_0x5a29b0]&&lt(()=>{this['onMessage_'](_0x3ebfe4[_0x5a29b0]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1dc957,_0x457904,_0x57d5c6,_0x41cdde,_0x9d1bf5,_0x4f98c5,_0x1800f7){this['connId']=_0x1dc957,this['repoInfo']=_0x457904,this['applicationId']=_0x57d5c6,this['appCheckToken']=_0x41cdde,this['authToken']=_0x9d1bf5,this['transportSessionId']=_0x4f98c5,this['lastSessionId']=_0x1800f7,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1dc957),this['stats_']=Hi(_0x457904),this['urlFn']=_0x5d5bb0=>(this['appCheckToken']&&(_0x5d5bb0[yi]=this['appCheckToken']),go(_0x457904,po,_0x5d5bb0));}['open'](_0x42dcd6,_0x246517){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x246517,this['myPacketOrderer']=new th(_0x42dcd6),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3a7d3c)=>{const [_0x37606e,_0x2443d2,_0x8e5363,_0x5728cd,_0x41a16a]=_0x3a7d3c;if(this['incrementIncomingBytes_'](_0x3a7d3c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x37606e===$s)this['id']=_0x2443d2,this['password']=_0x8e5363;else{if(_0x37606e===nh)_0x2443d2?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2443d2,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x37606e);}}},(..._0x42852c)=>{const [_0x547d87,_0x23b810]=_0x42852c;this['incrementIncomingBytes_'](_0x42852c),this['myPacketOrderer']['handleResponse'](_0x547d87,_0x23b810);},()=>{this['onClosed_']();},this['urlFn']);const _0xb3930e={};_0xb3930e[$s]='t',_0xb3930e[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xb3930e[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xb3930e[ro]=Vi,this['transportSessionId']&&(_0xb3930e[oo]=this['transportSessionId']),this['lastSessionId']&&(_0xb3930e[ho]=this['lastSessionId']),this['applicationId']&&(_0xb3930e[uo]=this['applicationId']),this['appCheckToken']&&(_0xb3930e[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xb3930e[ao]=co);const _0x4429a4=this['urlFn'](_0xb3930e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4429a4),this['scriptTagHolder']['addTag'](_0x4429a4,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x15c26c){const _0x371594=O(_0x15c26c);this['bytesSent']+=_0x371594['length'],this['stats_']['incrementCounter']('bytes_sent',_0x371594['length']);const _0x27714e=Br(_0x371594),_0x31631e=io(_0x27714e,hh);for(let _0x29e738=0x0;_0x29e738<_0x31631e['length'];_0x29e738++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x31631e['length'],_0x31631e[_0x29e738]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4db745,_0x4e3e24){this['myDisconnFrame']=document['createElement']('iframe');const _0x3ec6b7={};_0x3ec6b7[lh]='t',_0x3ec6b7[mo]=_0x4db745,_0x3ec6b7[yo]=_0x4e3e24,this['myDisconnFrame']['src']=this['urlFn'](_0x3ec6b7),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x50d195){const _0x421e97=O(_0x50d195)['length'];this['bytesReceived']+=_0x421e97,this['stats_']['incrementCounter']('bytes_received',_0x421e97);}}class $i{constructor(_0x2aa077,_0x11296a,_0x1ea78e,_0x336d38){this['onDisconnect']=_0x1ea78e,this['urlFn']=_0x336d38,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x2aa077,window[sh+this['uniqueCallbackIdentifier']]=_0x11296a,this['myIFrame']=$i['createIFrame_']();let _0x34df6b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x34df6b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x393585='<html><body>'+_0x34df6b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x393585),this['myIFrame']['doc']['close']();}catch(_0xd3b5ec){L('frame\x20writing\x20exception'),_0xd3b5ec['stack']&&L(_0xd3b5ec['stack']),L(_0xd3b5ec);}}}static['createIFrame_'](){const _0x55abd7=document['createElement']('iframe');if(_0x55abd7['style']['display']='none',document['body']){document['body']['appendChild'](_0x55abd7);try{_0x55abd7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x321308=document['domain'];_0x55abd7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x321308+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x55abd7['contentDocument']?_0x55abd7['doc']=_0x55abd7['contentDocument']:_0x55abd7['contentWindow']?_0x55abd7['doc']=_0x55abd7['contentWindow']['document']:_0x55abd7['document']&&(_0x55abd7['doc']=_0x55abd7['document']),_0x55abd7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4ca5ec=this['onDisconnect'];_0x4ca5ec&&(this['onDisconnect']=null,_0x4ca5ec());}['startLongPoll'](_0x371d01,_0x4498e1){for(this['myID']=_0x371d01,this['myPW']=_0x4498e1,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x8ac461={};_0x8ac461[mo]=this['myID'],_0x8ac461[yo]=this['myPW'],_0x8ac461[vo]=this['currentSerial'];let _0x58a50e=this['urlFn'](_0x8ac461),_0x3ef62b='',_0x216368=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x3ef62b['length']<=Eo;){const _0xe7aa1e=this['pendingSegs']['shift']();_0x3ef62b=_0x3ef62b+'&'+oh+_0x216368+'='+_0xe7aa1e['seg']+'&'+ah+_0x216368+'='+_0xe7aa1e['ts']+'&'+ch+_0x216368+'='+_0xe7aa1e['d'],_0x216368++;}return _0x58a50e=_0x58a50e+_0x3ef62b,this['addLongPollTag_'](_0x58a50e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4ec323,_0xb48f6a,_0x4c0091){this['pendingSegs']['push']({'seg':_0x4ec323,'ts':_0xb48f6a,'d':_0x4c0091}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xd2e3d1,_0x651107){this['outstandingRequests']['add'](_0x651107);const _0x1fb0a2=()=>{this['outstandingRequests']['delete'](_0x651107),this['newRequest_']();},_0x4e9d6e=setTimeout(_0x1fb0a2,Math['floor'](uh)),_0x1e07aa=()=>{clearTimeout(_0x4e9d6e),_0x1fb0a2();};this['addTag'](_0xd2e3d1,_0x1e07aa);}['addTag'](_0x2fb915,_0x4b3eeb){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1fd2e5=this['myIFrame']['doc']['createElement']('script');_0x1fd2e5['type']='text/javascript',_0x1fd2e5['async']=!0x0,_0x1fd2e5['src']=_0x2fb915,_0x1fd2e5['onload']=_0x1fd2e5['onreadystatechange']=function(){const _0x286b18=_0x1fd2e5['readyState'];(!_0x286b18||_0x286b18==='loaded'||_0x286b18==='complete')&&(_0x1fd2e5['onload']=_0x1fd2e5['onreadystatechange']=null,_0x1fd2e5['parentNode']&&_0x1fd2e5['parentNode']['removeChild'](_0x1fd2e5),_0x4b3eeb());},_0x1fd2e5['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2fb915),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1fd2e5);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1fdffa,_0xd2f1fa,_0x613673,_0x371e1e,_0x5e8d6a,_0x33bd81,_0x4b2bd5){this['connId']=_0x1fdffa,this['applicationId']=_0x613673,this['appCheckToken']=_0x371e1e,this['authToken']=_0x5e8d6a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0xd2f1fa),this['connURL']=G['connectionURL_'](_0xd2f1fa,_0x33bd81,_0x4b2bd5,_0x371e1e,_0x613673),this['nodeAdmin']=_0xd2f1fa['nodeAdmin'];}static['connectionURL_'](_0x406fb6,_0x39d87a,_0x46cfab,_0x16d82d,_0x3db579){const _0x2bf77b={};return _0x2bf77b[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2bf77b[ao]=co),_0x39d87a&&(_0x2bf77b[oo]=_0x39d87a),_0x46cfab&&(_0x2bf77b[ho]=_0x46cfab),_0x16d82d&&(_0x2bf77b[yi]=_0x16d82d),_0x3db579&&(_0x2bf77b[uo]=_0x3db579),go(_0x406fb6,fo,_0x2bf77b);}['open'](_0xf04e75,_0x5bd69f){this['onDisconnect']=_0x5bd69f,this['onMessage']=_0xf04e75,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x439641;dc(),this['mySock']=new hn(this['connURL'],[],_0x439641);}catch(_0x2d1cdf){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x199c67=_0x2d1cdf['message']||_0x2d1cdf['data'];_0x199c67&&this['log_'](_0x199c67),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x330ca9=>{this['handleIncomingFrame'](_0x330ca9);},this['mySock']['onerror']=_0x391c21=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xfd29d5=_0x391c21['message']||_0x391c21['data'];_0xfd29d5&&this['log_'](_0xfd29d5),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3b367f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2b7bc9=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1aed6f=navigator['userAgent']['match'](_0x2b7bc9);_0x1aed6f&&_0x1aed6f['length']>0x1&&parseFloat(_0x1aed6f[0x1])<4.4&&(_0x3b367f=!0x0);}return!_0x3b367f&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x36abc4){if(this['frames']['push'](_0x36abc4),this['frames']['length']===this['totalFrames']){const _0x8a5bd=this['frames']['join']('');this['frames']=null;const _0x395abc=bt(_0x8a5bd);this['onMessage'](_0x395abc);}}['handleNewFrameCount_'](_0x16b11a){this['totalFrames']=_0x16b11a,this['frames']=[];}['extractFrameCount_'](_0x558e55){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x558e55['length']<=0x6){const _0xb21f32=Number(_0x558e55);if(!isNaN(_0xb21f32))return this['handleNewFrameCount_'](_0xb21f32),null;}return this['handleNewFrameCount_'](0x1),_0x558e55;}['handleIncomingFrame'](_0x4d65d7){if(this['mySock']===null)return;const _0x92a8c3=_0x4d65d7['data'];if(this['bytesReceived']+=_0x92a8c3['length'],this['stats_']['incrementCounter']('bytes_received',_0x92a8c3['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x92a8c3);else{const _0x445c1f=this['extractFrameCount_'](_0x92a8c3);_0x445c1f!==null&&this['appendFrame_'](_0x445c1f);}}['send'](_0x9203dd){this['resetKeepAlive']();const _0x933613=O(_0x9203dd);this['bytesSent']+=_0x933613['length'],this['stats_']['incrementCounter']('bytes_sent',_0x933613['length']);const _0x2a2c32=io(_0x933613,fh);_0x2a2c32['length']>0x1&&this['sendString_'](String(_0x2a2c32['length']));for(let _0x1e33b7=0x0;_0x1e33b7<_0x2a2c32['length'];_0x1e33b7++)this['sendString_'](_0x2a2c32[_0x1e33b7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0xa65ae1){try{this['mySock']['send'](_0xa65ae1);}catch(_0x176b03){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x176b03['message']||_0x176b03['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1e1b99){this['initTransports_'](_0x1e1b99);}['initTransports_'](_0x5174d4){const _0xf498b6=G&&G['isAvailable']();let _0x136f22=_0xf498b6&&!G['previouslyFailed']();if(_0x5174d4['webSocketOnly']&&(_0xf498b6||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x136f22=!0x0),_0x136f22)this['transports_']=[G];else{const _0x404f59=this['transports_']=[];for(const _0x40c983 of At['ALL_TRANSPORTS'])_0x40c983&&_0x40c983['isAvailable']()&&_0x404f59['push'](_0x40c983);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0xff3532,_0x142610,_0x4ebf9b,_0xb54cd0,_0x557409,_0x1478a4,_0x1ea6ad,_0x25a809,_0x2f0582,_0x1d334e){this['id']=_0xff3532,this['repoInfo_']=_0x142610,this['applicationId_']=_0x4ebf9b,this['appCheckToken_']=_0xb54cd0,this['authToken_']=_0x557409,this['onMessage_']=_0x1478a4,this['onReady_']=_0x1ea6ad,this['onDisconnect_']=_0x25a809,this['onKill_']=_0x2f0582,this['lastSessionId']=_0x1d334e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x142610),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x43fedc=this['transportManager_']['initialTransport']();this['conn_']=new _0x43fedc(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x43fedc['responsesRequiredToBeHealthy']||0x0;const _0x4f9b5d=this['connReceiver_'](this['conn_']),_0x157d82=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4f9b5d,_0x157d82);},Math['floor'](0x0));const _0x34633c=_0x43fedc['healthyTimeout']||0x0;_0x34633c>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x34633c)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x461c10){return _0x3c0d74=>{_0x461c10===this['conn_']?this['onConnectionLost_'](_0x3c0d74):_0x461c10===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x59af4d){return _0x208fb1=>{this['state_']!==0x2&&(_0x59af4d===this['rx_']?this['onPrimaryMessageReceived_'](_0x208fb1):_0x59af4d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x208fb1):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x19ff34){const _0x1e6a0e={'t':'d','d':_0x19ff34};this['sendData_'](_0x1e6a0e);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x132f26){if(ii in _0x132f26){const _0x243b01=_0x132f26[ii];_0x243b01===js?this['upgradeIfSecondaryHealthy_']():_0x243b01===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x243b01===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x5e42f5){const _0x52c03c=pt('t',_0x5e42f5),_0x2cc83f=pt('d',_0x5e42f5);if(_0x52c03c==='c')this['onSecondaryControl_'](_0x2cc83f);else{if(_0x52c03c==='d')this['pendingDataMessages']['push'](_0x2cc83f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x52c03c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x537c1d){const _0x2a1bfb=pt('t',_0x537c1d),_0x427451=pt('d',_0x537c1d);_0x2a1bfb==='c'?this['onControl_'](_0x427451):_0x2a1bfb==='d'&&this['onDataMessage_'](_0x427451);}['onDataMessage_'](_0x40c388){this['onPrimaryResponse_'](),this['onMessage_'](_0x40c388);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5c57f4){const _0x414e17=pt(ii,_0x5c57f4);if(Gs in _0x5c57f4){const _0x30f720=_0x5c57f4[Gs];if(_0x414e17===Ih){const _0x40bdd3={..._0x30f720};this['repoInfo_']['isUsingEmulator']&&(_0x40bdd3['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x40bdd3);}else{if(_0x414e17===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2e9509=0x0;_0x2e9509<this['pendingDataMessages']['length'];++_0x2e9509)this['onDataMessage_'](this['pendingDataMessages'][_0x2e9509]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x414e17===vh?this['onConnectionShutdown_'](_0x30f720):_0x414e17===qs?this['onReset_'](_0x30f720):_0x414e17===Eh?mi('Server\x20Error:\x20'+_0x30f720):_0x414e17===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x414e17);}}}['onHandshake_'](_0x3f318b){const _0x67e3f8=_0x3f318b['ts'],_0x1b52c8=_0x3f318b['v'],_0x59d158=_0x3f318b['h'];this['sessionId']=_0x3f318b['s'],this['repoInfo_']['host']=_0x59d158,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x67e3f8),Vi!==_0x1b52c8&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1e3b14=this['transportManager_']['upgradeTransport']();_0x1e3b14&&this['startUpgrade_'](_0x1e3b14);}['startUpgrade_'](_0x573bc0){this['secondaryConn_']=new _0x573bc0(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x573bc0['responsesRequiredToBeHealthy']||0x0;const _0x1ff9ac=this['connReceiver_'](this['secondaryConn_']),_0x7bea9b=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1ff9ac,_0x7bea9b),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x377a00){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x377a00),this['repoInfo_']['host']=_0x377a00,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x52b02e,_0xe6298a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x52b02e,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xe6298a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x49717f=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x49717f||this['rx_']===_0x49717f)&&this['close']();}['onConnectionLost_'](_0x18e12){this['conn_']=null,!_0x18e12&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3f9719){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3f9719),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x6d7eca){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x6d7eca);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x17404d,_0x29aa29,_0x553274,_0xfdf2a6){}['merge'](_0x181fce,_0xce42ea,_0x542f7b,_0x5a45cd){}['refreshAuthToken'](_0xba20bc){}['refreshAppCheckToken'](_0x1057c9){}['onDisconnectPut'](_0x4025ab,_0x252dc1,_0x17860b){}['onDisconnectMerge'](_0x32ebd0,_0x1e525a,_0xc9efe0){}['onDisconnectCancel'](_0x3234ea,_0x5c2c97){}['reportStats'](_0x3e1374){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x33539b){this['allowedEvents_']=_0x33539b,this['listeners_']={},f(Array['isArray'](_0x33539b)&&_0x33539b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1331e8,..._0x40bf69){if(Array['isArray'](this['listeners_'][_0x1331e8])){const _0x2fe03a=[...this['listeners_'][_0x1331e8]];for(let _0x358bac=0x0;_0x358bac<_0x2fe03a['length'];_0x358bac++)_0x2fe03a[_0x358bac]['callback']['apply'](_0x2fe03a[_0x358bac]['context'],_0x40bf69);}}['on'](_0x21f9cb,_0x24d460,_0x4e66b3){this['validateEventType_'](_0x21f9cb),this['listeners_'][_0x21f9cb]=this['listeners_'][_0x21f9cb]||[],this['listeners_'][_0x21f9cb]['push']({'callback':_0x24d460,'context':_0x4e66b3});const _0x48e578=this['getInitialEvent'](_0x21f9cb);_0x48e578&&_0x24d460['apply'](_0x4e66b3,_0x48e578);}['off'](_0x6099fc,_0x5e5a6f,_0x599a54){this['validateEventType_'](_0x6099fc);const _0xdc65fa=this['listeners_'][_0x6099fc]||[];for(let _0x3f1f14=0x0;_0x3f1f14<_0xdc65fa['length'];_0x3f1f14++)if(_0xdc65fa[_0x3f1f14]['callback']===_0x5e5a6f&&(!_0x599a54||_0x599a54===_0xdc65fa[_0x3f1f14]['context'])){_0xdc65fa['splice'](_0x3f1f14,0x1);return;}}['validateEventType_'](_0x1eb2d2){f(this['allowedEvents_']['find'](_0x1b4da0=>_0x1b4da0===_0x1eb2d2),'Unknown\x20event:\x20'+_0x1eb2d2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5517af){return f(_0x5517af==='online','Unknown\x20event\x20type:\x20'+_0x5517af),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x2259a7,_0x566089){if(_0x566089===void 0x0){this['pieces_']=_0x2259a7['split']('/');let _0x222aaf=0x0;for(let _0x1b6862=0x0;_0x1b6862<this['pieces_']['length'];_0x1b6862++)this['pieces_'][_0x1b6862]['length']>0x0&&(this['pieces_'][_0x222aaf]=this['pieces_'][_0x1b6862],_0x222aaf++);this['pieces_']['length']=_0x222aaf,this['pieceNum_']=0x0;}else this['pieces_']=_0x2259a7,this['pieceNum_']=_0x566089;}['toString'](){let _0x1e2f9e='';for(let _0x10be42=this['pieceNum_'];_0x10be42<this['pieces_']['length'];_0x10be42++)this['pieces_'][_0x10be42]!==''&&(_0x1e2f9e+='/'+this['pieces_'][_0x10be42]);return _0x1e2f9e||'/';}}function w(){return new C('');}function y(_0x269619){return _0x269619['pieceNum_']>=_0x269619['pieces_']['length']?null:_0x269619['pieces_'][_0x269619['pieceNum_']];}function we(_0x3e6029){return _0x3e6029['pieces_']['length']-_0x3e6029['pieceNum_'];}function b(_0x304455){let _0x50443b=_0x304455['pieceNum_'];return _0x50443b<_0x304455['pieces_']['length']&&_0x50443b++,new C(_0x304455['pieces_'],_0x50443b);}function Gi(_0x52fbc9){return _0x52fbc9['pieceNum_']<_0x52fbc9['pieces_']['length']?_0x52fbc9['pieces_'][_0x52fbc9['pieces_']['length']-0x1]:null;}function Ch(_0x551b36){let _0x5d9d23='';for(let _0x31a513=_0x551b36['pieceNum_'];_0x31a513<_0x551b36['pieces_']['length'];_0x31a513++)_0x551b36['pieces_'][_0x31a513]!==''&&(_0x5d9d23+='/'+encodeURIComponent(String(_0x551b36['pieces_'][_0x31a513])));return _0x5d9d23||'/';}function kt(_0x434237,_0x457145=0x0){return _0x434237['pieces_']['slice'](_0x434237['pieceNum_']+_0x457145);}function To(_0x3b73ec){if(_0x3b73ec['pieceNum_']>=_0x3b73ec['pieces_']['length'])return null;const _0x2b624=[];for(let _0xa86d5f=_0x3b73ec['pieceNum_'];_0xa86d5f<_0x3b73ec['pieces_']['length']-0x1;_0xa86d5f++)_0x2b624['push'](_0x3b73ec['pieces_'][_0xa86d5f]);return new C(_0x2b624,0x0);}function A(_0x20c11c,_0x3c1d02){const _0x593d81=[];for(let _0x59a8dc=_0x20c11c['pieceNum_'];_0x59a8dc<_0x20c11c['pieces_']['length'];_0x59a8dc++)_0x593d81['push'](_0x20c11c['pieces_'][_0x59a8dc]);if(_0x3c1d02 instanceof C){for(let _0x527d62=_0x3c1d02['pieceNum_'];_0x527d62<_0x3c1d02['pieces_']['length'];_0x527d62++)_0x593d81['push'](_0x3c1d02['pieces_'][_0x527d62]);}else{const _0x25755d=_0x3c1d02['split']('/');for(let _0x190e4a=0x0;_0x190e4a<_0x25755d['length'];_0x190e4a++)_0x25755d[_0x190e4a]['length']>0x0&&_0x593d81['push'](_0x25755d[_0x190e4a]);}return new C(_0x593d81,0x0);}function v(_0x306eea){return _0x306eea['pieceNum_']>=_0x306eea['pieces_']['length'];}function F(_0x26338d,_0x48f9de){const _0x4facc1=y(_0x26338d),_0x578283=y(_0x48f9de);if(_0x4facc1===null)return _0x48f9de;if(_0x4facc1===_0x578283)return F(b(_0x26338d),b(_0x48f9de));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x48f9de+')\x20is\x20not\x20within\x20outerPath\x20('+_0x26338d+')');}function Th(_0x25a313,_0x21fa33){const _0x39421e=kt(_0x25a313,0x0),_0x483d2a=kt(_0x21fa33,0x0);for(let _0x3080e7=0x0;_0x3080e7<_0x39421e['length']&&_0x3080e7<_0x483d2a['length'];_0x3080e7++){const _0x658739=He(_0x39421e[_0x3080e7],_0x483d2a[_0x3080e7]);if(_0x658739!==0x0)return _0x658739;}return _0x39421e['length']===_0x483d2a['length']?0x0:_0x39421e['length']<_0x483d2a['length']?-0x1:0x1;}function qi(_0x38e699,_0x119614){if(we(_0x38e699)!==we(_0x119614))return!0x1;for(let _0x4362e4=_0x38e699['pieceNum_'],_0x45ea5a=_0x119614['pieceNum_'];_0x4362e4<=_0x38e699['pieces_']['length'];_0x4362e4++,_0x45ea5a++)if(_0x38e699['pieces_'][_0x4362e4]!==_0x119614['pieces_'][_0x45ea5a])return!0x1;return!0x0;}function $(_0x2bebd6,_0x513240){let _0x14e507=_0x2bebd6['pieceNum_'],_0x26ad7a=_0x513240['pieceNum_'];if(we(_0x2bebd6)>we(_0x513240))return!0x1;for(;_0x14e507<_0x2bebd6['pieces_']['length'];){if(_0x2bebd6['pieces_'][_0x14e507]!==_0x513240['pieces_'][_0x26ad7a])return!0x1;++_0x14e507,++_0x26ad7a;}return!0x0;}class Sh{constructor(_0x295b2f,_0x1f83d2){this['errorPrefix_']=_0x1f83d2,this['parts_']=kt(_0x295b2f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x29ad8b=0x0;_0x29ad8b<this['parts_']['length'];_0x29ad8b++)this['byteLength_']+=Pn(this['parts_'][_0x29ad8b]);So(this);}}function bh(_0xb1992a,_0x11483b){_0xb1992a['parts_']['length']>0x0&&(_0xb1992a['byteLength_']+=0x1),_0xb1992a['parts_']['push'](_0x11483b),_0xb1992a['byteLength_']+=Pn(_0x11483b),So(_0xb1992a);}function Rh(_0x27c53d){const _0x23b200=_0x27c53d['parts_']['pop']();_0x27c53d['byteLength_']-=Pn(_0x23b200),_0x27c53d['parts_']['length']>0x0&&(_0x27c53d['byteLength_']-=0x1);}function So(_0x50918b){if(_0x50918b['byteLength_']>Js)throw new Error(_0x50918b['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x50918b['byteLength_']+').');if(_0x50918b['parts_']['length']>Qs)throw new Error(_0x50918b['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x50918b));}function Ne(_0x27794b){return _0x27794b['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x27794b['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x10f240,_0x304665;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x304665='visibilitychange',_0x10f240='hidden'):typeof document['mozHidden']<'u'?(_0x304665='mozvisibilitychange',_0x10f240='mozHidden'):typeof document['msHidden']<'u'?(_0x304665='msvisibilitychange',_0x10f240='msHidden'):typeof document['webkitHidden']<'u'&&(_0x304665='webkitvisibilitychange',_0x10f240='webkitHidden')),this['visible_']=!0x0,_0x304665&&document['addEventListener'](_0x304665,()=>{const _0x50a10b=!document[_0x10f240];_0x50a10b!==this['visible_']&&(this['visible_']=_0x50a10b,this['trigger']('visible',_0x50a10b));},!0x1);}['getInitialEvent'](_0x25dd4d){return f(_0x25dd4d==='visible','Unknown\x20event\x20type:\x20'+_0x25dd4d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x33f8b3,_0x53a2a6,_0x443a1e,_0x3f38e6,_0x3662f7,_0x4901bf,_0x1b064d,_0x598aa1){if(super(),this['repoInfo_']=_0x33f8b3,this['applicationId_']=_0x53a2a6,this['onDataUpdate_']=_0x443a1e,this['onConnectStatus_']=_0x3f38e6,this['onServerInfoUpdate_']=_0x3662f7,this['authTokenProvider_']=_0x4901bf,this['appCheckTokenProvider_']=_0x1b064d,this['authOverride_']=_0x598aa1,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x598aa1)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x33f8b3['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xb31f4d,_0x429946,_0x224530){const _0x4186d4=++this['requestNumber_'],_0x17ac2d={'r':_0x4186d4,'a':_0xb31f4d,'b':_0x429946};this['log_'](O(_0x17ac2d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x17ac2d),_0x224530&&(this['requestCBHash_'][_0x4186d4]=_0x224530);}['get'](_0xc45b78){this['initConnection_']();const _0x2f7ee3=new Ve(),_0x226c4e={'action':'g','request':{'p':_0xc45b78['_path']['toString'](),'q':_0xc45b78['_queryObject']},'onComplete':_0x4c4d65=>{const _0x5d29bf=_0x4c4d65['d'];_0x4c4d65['s']==='ok'?_0x2f7ee3['resolve'](_0x5d29bf):_0x2f7ee3['reject'](_0x5d29bf);}};this['outstandingGets_']['push'](_0x226c4e),this['outstandingGetCount_']++;const _0x452693=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x452693),_0x2f7ee3['promise'];}['listen'](_0x4cd21b,_0x5307e3,_0x298635,_0x4278b4){this['initConnection_']();const _0x5b4360=_0x4cd21b['_queryIdentifier'],_0x3e89a5=_0x4cd21b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e89a5+'\x20'+_0x5b4360),this['listens']['has'](_0x3e89a5)||this['listens']['set'](_0x3e89a5,new Map()),f(_0x4cd21b['_queryParams']['isDefault']()||!_0x4cd21b['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3e89a5)['has'](_0x5b4360),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x523509={'onComplete':_0x4278b4,'hashFn':_0x5307e3,'query':_0x4cd21b,'tag':_0x298635};this['listens']['get'](_0x3e89a5)['set'](_0x5b4360,_0x523509),this['connected_']&&this['sendListen_'](_0x523509);}['sendGet_'](_0x54d68e){const _0x55742d=this['outstandingGets_'][_0x54d68e];this['sendRequest']('g',_0x55742d['request'],_0x31f1aa=>{delete this['outstandingGets_'][_0x54d68e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x55742d['onComplete']&&_0x55742d['onComplete'](_0x31f1aa);});}['sendListen_'](_0x344b7b){const _0x15ebaa=_0x344b7b['query'],_0x6d7d55=_0x15ebaa['_path']['toString'](),_0x273994=_0x15ebaa['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x6d7d55+'\x20for\x20'+_0x273994);const _0xdf46a5={'p':_0x6d7d55},_0x19330a='q';_0x344b7b['tag']&&(_0xdf46a5['q']=_0x15ebaa['_queryObject'],_0xdf46a5['t']=_0x344b7b['tag']),_0xdf46a5['h']=_0x344b7b['hashFn'](),this['sendRequest'](_0x19330a,_0xdf46a5,_0x34da00=>{const _0xee91c7=_0x34da00['d'],_0x3bfeb8=_0x34da00['s'];ie['warnOnListenWarnings_'](_0xee91c7,_0x15ebaa),(this['listens']['get'](_0x6d7d55)&&this['listens']['get'](_0x6d7d55)['get'](_0x273994))===_0x344b7b&&(this['log_']('listen\x20response',_0x34da00),_0x3bfeb8!=='ok'&&this['removeListen_'](_0x6d7d55,_0x273994),_0x344b7b['onComplete']&&_0x344b7b['onComplete'](_0x3bfeb8,_0xee91c7));});}static['warnOnListenWarnings_'](_0x2986ba,_0xd265a6){if(_0x2986ba&&typeof _0x2986ba=='object'&&Y(_0x2986ba,'w')){const _0x49f7dc=Oe(_0x2986ba,'w');if(Array['isArray'](_0x49f7dc)&&~_0x49f7dc['indexOf']('no_index')){const _0x405374='\x22.indexOn\x22:\x20\x22'+_0xd265a6['_queryParams']['getIndex']()['toString']()+'\x22',_0x4c21d0=_0xd265a6['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x405374+'\x20at\x20'+_0x4c21d0+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x52e668){this['authToken_']=_0x52e668,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x52e668);}['reduceReconnectDelayIfAdminCredential_'](_0x2895ea){(_0x2895ea&&_0x2895ea['length']===0x28||vc(_0x2895ea))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4236e8){this['appCheckToken_']=_0x4236e8,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4c16c2=this['authToken_'],_0x202789=yc(_0x4c16c2)?'auth':'gauth',_0x6d55cf={'cred':_0x4c16c2};this['authOverride_']===null?_0x6d55cf['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x6d55cf['authvar']=this['authOverride_']),this['sendRequest'](_0x202789,_0x6d55cf,_0x52e8b0=>{const _0x52e389=_0x52e8b0['s'],_0x5af4f8=_0x52e8b0['d']||'error';this['authToken_']===_0x4c16c2&&(_0x52e389==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x52e389,_0x5af4f8));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x40da66=>{const _0x3740aa=_0x40da66['s'],_0x2f7447=_0x40da66['d']||'error';_0x3740aa==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3740aa,_0x2f7447);});}['unlisten'](_0x573893,_0xea3304){const _0x4766fb=_0x573893['_path']['toString'](),_0x54d895=_0x573893['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4766fb+'\x20'+_0x54d895),f(_0x573893['_queryParams']['isDefault']()||!_0x573893['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4766fb,_0x54d895)&&this['connected_']&&this['sendUnlisten_'](_0x4766fb,_0x54d895,_0x573893['_queryObject'],_0xea3304);}['sendUnlisten_'](_0x36e7c4,_0x476c57,_0x1e4657,_0x4e6c33){this['log_']('Unlisten\x20on\x20'+_0x36e7c4+'\x20for\x20'+_0x476c57);const _0x207e48={'p':_0x36e7c4},_0x247b9f='n';_0x4e6c33&&(_0x207e48['q']=_0x1e4657,_0x207e48['t']=_0x4e6c33),this['sendRequest'](_0x247b9f,_0x207e48);}['onDisconnectPut'](_0x167428,_0x4bcbce,_0x5df4da){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x167428,_0x4bcbce,_0x5df4da):this['onDisconnectRequestQueue_']['push']({'pathString':_0x167428,'action':'o','data':_0x4bcbce,'onComplete':_0x5df4da});}['onDisconnectMerge'](_0x4443c6,_0x183cc5,_0x3df582){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4443c6,_0x183cc5,_0x3df582):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4443c6,'action':'om','data':_0x183cc5,'onComplete':_0x3df582});}['onDisconnectCancel'](_0x217ab4,_0x5304a7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x217ab4,null,_0x5304a7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x217ab4,'action':'oc','data':null,'onComplete':_0x5304a7});}['sendOnDisconnect_'](_0x51dff3,_0x42cf3e,_0x5a9517,_0x4fba7c){const _0x170408={'p':_0x42cf3e,'d':_0x5a9517};this['log_']('onDisconnect\x20'+_0x51dff3,_0x170408),this['sendRequest'](_0x51dff3,_0x170408,_0x1f633e=>{_0x4fba7c&&setTimeout(()=>{_0x4fba7c(_0x1f633e['s'],_0x1f633e['d']);},Math['floor'](0x0));});}['put'](_0x209f75,_0xc830f4,_0x55b292,_0x2957d6){this['putInternal']('p',_0x209f75,_0xc830f4,_0x55b292,_0x2957d6);}['merge'](_0x54fed1,_0x5888fe,_0x856165,_0x49c2e2){this['putInternal']('m',_0x54fed1,_0x5888fe,_0x856165,_0x49c2e2);}['putInternal'](_0x49abcd,_0x25244e,_0x3efcc5,_0x45997f,_0x5bd106){this['initConnection_']();const _0x8352f8={'p':_0x25244e,'d':_0x3efcc5};_0x5bd106!==void 0x0&&(_0x8352f8['h']=_0x5bd106),this['outstandingPuts_']['push']({'action':_0x49abcd,'request':_0x8352f8,'onComplete':_0x45997f}),this['outstandingPutCount_']++;const _0x3b22aa=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3b22aa):this['log_']('Buffering\x20put:\x20'+_0x25244e);}['sendPut_'](_0x4caa0d){const _0x191e3c=this['outstandingPuts_'][_0x4caa0d]['action'],_0x3d64e5=this['outstandingPuts_'][_0x4caa0d]['request'],_0x11ab57=this['outstandingPuts_'][_0x4caa0d]['onComplete'];this['outstandingPuts_'][_0x4caa0d]['queued']=this['connected_'],this['sendRequest'](_0x191e3c,_0x3d64e5,_0x5d7cbe=>{this['log_'](_0x191e3c+'\x20response',_0x5d7cbe),delete this['outstandingPuts_'][_0x4caa0d],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x11ab57&&_0x11ab57(_0x5d7cbe['s'],_0x5d7cbe['d']);});}['reportStats'](_0x523021){if(this['connected_']){const _0x3bc5b6={'c':_0x523021};this['log_']('reportStats',_0x3bc5b6),this['sendRequest']('s',_0x3bc5b6,_0x1d4099=>{if(_0x1d4099['s']!=='ok'){const _0x25d949=_0x1d4099['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x25d949);}});}}['onDataMessage_'](_0x340dbb){if('r'in _0x340dbb){this['log_']('from\x20server:\x20'+O(_0x340dbb));const _0x5101bc=_0x340dbb['r'],_0x48b29e=this['requestCBHash_'][_0x5101bc];_0x48b29e&&(delete this['requestCBHash_'][_0x5101bc],_0x48b29e(_0x340dbb['b']));}else{if('error'in _0x340dbb)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x340dbb['error'];'a'in _0x340dbb&&this['onDataPush_'](_0x340dbb['a'],_0x340dbb['b']);}}['onDataPush_'](_0x56964d,_0x204ba6){this['log_']('handleServerMessage',_0x56964d,_0x204ba6),_0x56964d==='d'?this['onDataUpdate_'](_0x204ba6['p'],_0x204ba6['d'],!0x1,_0x204ba6['t']):_0x56964d==='m'?this['onDataUpdate_'](_0x204ba6['p'],_0x204ba6['d'],!0x0,_0x204ba6['t']):_0x56964d==='c'?this['onListenRevoked_'](_0x204ba6['p'],_0x204ba6['q']):_0x56964d==='ac'?this['onAuthRevoked_'](_0x204ba6['s'],_0x204ba6['d']):_0x56964d==='apc'?this['onAppCheckRevoked_'](_0x204ba6['s'],_0x204ba6['d']):_0x56964d==='sd'?this['onSecurityDebugPacket_'](_0x204ba6):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x56964d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3d662b,_0x29aa4f){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3d662b),this['lastSessionId']=_0x29aa4f,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x594268){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x594268));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0xea37bb){_0xea37bb&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0xea37bb;}['onOnline_'](_0x1a6ca2){_0x1a6ca2?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x26c0a1=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x27b573=Math['max'](0x0,this['reconnectDelay_']-_0x26c0a1);_0x27b573=Math['random']()*_0x27b573,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x27b573+'ms'),this['scheduleConnect_'](_0x27b573),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5915cc=this['onDataMessage_']['bind'](this),_0x5171a4=this['onReady_']['bind'](this),_0x336ce7=this['onRealtimeDisconnect_']['bind'](this),_0x20dbf1=this['id']+':'+ie['nextConnectionId_']++,_0x1a394b=this['lastSessionId'];let _0x351868=!0x1,_0x4621e6=null;const _0x11ac5f=function(){_0x4621e6?_0x4621e6['close']():(_0x351868=!0x0,_0x336ce7());},_0x422d7a=function(_0x86e1cc){f(_0x4621e6,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4621e6['sendRequest'](_0x86e1cc);};this['realtime_']={'close':_0x11ac5f,'sendRequest':_0x422d7a};const _0x2ca23d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x26cdee,_0x3011c9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2ca23d),this['appCheckTokenProvider_']['getToken'](_0x2ca23d)]);_0x351868?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x26cdee&&_0x26cdee['accessToken'],this['appCheckToken_']=_0x3011c9&&_0x3011c9['token'],_0x4621e6=new wh(_0x20dbf1,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5915cc,_0x5171a4,_0x336ce7,_0x300e01=>{U(_0x300e01+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x1a394b));}catch(_0x29571a){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x29571a),_0x351868||(this['repoInfo_']['nodeAdmin']&&U(_0x29571a),_0x11ac5f());}}}['interrupt'](_0x35e9ba){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x35e9ba),this['interruptReasons_'][_0x35e9ba]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x509523){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x509523),delete this['interruptReasons_'][_0x509523],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xc6e338){const _0x103c12=_0xc6e338-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x103c12});}['cancelSentTransactions_'](){for(let _0x3e595b=0x0;_0x3e595b<this['outstandingPuts_']['length'];_0x3e595b++){const _0x42110c=this['outstandingPuts_'][_0x3e595b];_0x42110c&&'h'in _0x42110c['request']&&_0x42110c['queued']&&(_0x42110c['onComplete']&&_0x42110c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3e595b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3fa80a,_0x70560e){let _0x5b8220;_0x70560e?_0x5b8220=_0x70560e['map'](_0x5acdd2=>Bi(_0x5acdd2))['join']('$'):_0x5b8220='default';const _0x10ca5e=this['removeListen_'](_0x3fa80a,_0x5b8220);_0x10ca5e&&_0x10ca5e['onComplete']&&_0x10ca5e['onComplete']('permission_denied');}['removeListen_'](_0x197ec5,_0x4bb15b){const _0x47f554=new C(_0x197ec5)['toString']();let _0x214341;if(this['listens']['has'](_0x47f554)){const _0x1eb671=this['listens']['get'](_0x47f554);_0x214341=_0x1eb671['get'](_0x4bb15b),_0x1eb671['delete'](_0x4bb15b),_0x1eb671['size']===0x0&&this['listens']['delete'](_0x47f554);}else _0x214341=void 0x0;return _0x214341;}['onAuthRevoked_'](_0x10b284,_0x7cfdb0){L('Auth\x20token\x20revoked:\x20'+_0x10b284+'/'+_0x7cfdb0),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x10b284==='invalid_token'||_0x10b284==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x51f0a0,_0x4adbd6){L('App\x20check\x20token\x20revoked:\x20'+_0x51f0a0+'/'+_0x4adbd6),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x51f0a0==='invalid_token'||_0x51f0a0==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2e5ae9){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2e5ae9):'msg'in _0x2e5ae9&&console['log']('FIREBASE:\x20'+_0x2e5ae9['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1746d9 of this['listens']['values']())for(const _0x13f001 of _0x1746d9['values']())this['sendListen_'](_0x13f001);for(let _0x4415ff=0x0;_0x4415ff<this['outstandingPuts_']['length'];_0x4415ff++)this['outstandingPuts_'][_0x4415ff]&&this['sendPut_'](_0x4415ff);for(;this['onDisconnectRequestQueue_']['length'];){const _0x57b1c0=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x57b1c0['action'],_0x57b1c0['pathString'],_0x57b1c0['data'],_0x57b1c0['onComplete']);}for(let _0x2b8f80=0x0;_0x2b8f80<this['outstandingGets_']['length'];_0x2b8f80++)this['outstandingGets_'][_0x2b8f80]&&this['sendGet_'](_0x2b8f80);}['sendConnectStats_'](){const _0x244b5b={};let _0x274d69='js';_0x244b5b['sdk.'+_0x274d69+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x244b5b['framework.cordova']=0x1:qr()&&(_0x244b5b['framework.reactnative']=0x1),this['reportStats'](_0x244b5b);}['shouldReconnect_'](){const _0x51f8f3=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x51f8f3;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2087d0,_0x436dce){this['name']=_0x2087d0,this['node']=_0x436dce;}static['Wrap'](_0x5ae858,_0x545a79){return new E(_0x5ae858,_0x545a79);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x33b17c,_0x5c77cf){const _0x2efc26=new E(xe,_0x33b17c),_0x32deb9=new E(xe,_0x5c77cf);return this['compare'](_0x2efc26,_0x32deb9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0xe9b5d3){Xt=_0xe9b5d3;}['compare'](_0x1b6b4c,_0xe6c101){return He(_0x1b6b4c['name'],_0xe6c101['name']);}['isDefinedOn'](_0x3d8691){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1ad259,_0x284da){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x580162,_0x23ae0f){return f(typeof _0x580162=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x580162,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0xf97603,_0x511d2f,_0x3622ee,_0x119c32,_0x6e1c6f=null){this['isReverse_']=_0x119c32,this['resultGenerator_']=_0x6e1c6f,this['nodeStack_']=[];let _0x4fb4b2=0x1;for(;!_0xf97603['isEmpty']();)if(_0xf97603=_0xf97603,_0x4fb4b2=_0x511d2f?_0x3622ee(_0xf97603['key'],_0x511d2f):0x1,_0x119c32&&(_0x4fb4b2*=-0x1),_0x4fb4b2<0x0)this['isReverse_']?_0xf97603=_0xf97603['left']:_0xf97603=_0xf97603['right'];else{if(_0x4fb4b2===0x0){this['nodeStack_']['push'](_0xf97603);break;}else this['nodeStack_']['push'](_0xf97603),this['isReverse_']?_0xf97603=_0xf97603['right']:_0xf97603=_0xf97603['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5a8ba2=this['nodeStack_']['pop'](),_0x4e7f34;if(this['resultGenerator_']?_0x4e7f34=this['resultGenerator_'](_0x5a8ba2['key'],_0x5a8ba2['value']):_0x4e7f34={'key':_0x5a8ba2['key'],'value':_0x5a8ba2['value']},this['isReverse_']){for(_0x5a8ba2=_0x5a8ba2['left'];!_0x5a8ba2['isEmpty']();)this['nodeStack_']['push'](_0x5a8ba2),_0x5a8ba2=_0x5a8ba2['right'];}else{for(_0x5a8ba2=_0x5a8ba2['right'];!_0x5a8ba2['isEmpty']();)this['nodeStack_']['push'](_0x5a8ba2),_0x5a8ba2=_0x5a8ba2['left'];}return _0x4e7f34;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xfe7ad7=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xfe7ad7['key'],_0xfe7ad7['value']):{'key':_0xfe7ad7['key'],'value':_0xfe7ad7['value']};}}class M{constructor(_0x3b83e6,_0xfe9539,_0xea3067,_0x315b85,_0xc6391a){this['key']=_0x3b83e6,this['value']=_0xfe9539,this['color']=_0xea3067??M['RED'],this['left']=_0x315b85??B['EMPTY_NODE'],this['right']=_0xc6391a??B['EMPTY_NODE'];}['copy'](_0x272260,_0x48bb51,_0x188520,_0x9c80f6,_0x319e97){return new M(_0x272260??this['key'],_0x48bb51??this['value'],_0x188520??this['color'],_0x9c80f6??this['left'],_0x319e97??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x102a73){return this['left']['inorderTraversal'](_0x102a73)||!!_0x102a73(this['key'],this['value'])||this['right']['inorderTraversal'](_0x102a73);}['reverseTraversal'](_0x510f8e){return this['right']['reverseTraversal'](_0x510f8e)||_0x510f8e(this['key'],this['value'])||this['left']['reverseTraversal'](_0x510f8e);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2cc3bf,_0x42f181,_0x4101fa){let _0x5e8f0a=this;const _0x55957a=_0x4101fa(_0x2cc3bf,_0x5e8f0a['key']);return _0x55957a<0x0?_0x5e8f0a=_0x5e8f0a['copy'](null,null,null,_0x5e8f0a['left']['insert'](_0x2cc3bf,_0x42f181,_0x4101fa),null):_0x55957a===0x0?_0x5e8f0a=_0x5e8f0a['copy'](null,_0x42f181,null,null,null):_0x5e8f0a=_0x5e8f0a['copy'](null,null,null,null,_0x5e8f0a['right']['insert'](_0x2cc3bf,_0x42f181,_0x4101fa)),_0x5e8f0a['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1f2060=this;return!_0x1f2060['left']['isRed_']()&&!_0x1f2060['left']['left']['isRed_']()&&(_0x1f2060=_0x1f2060['moveRedLeft_']()),_0x1f2060=_0x1f2060['copy'](null,null,null,_0x1f2060['left']['removeMin_'](),null),_0x1f2060['fixUp_']();}['remove'](_0x57e9ae,_0x53ae2a){let _0x40d488,_0x467923;if(_0x40d488=this,_0x53ae2a(_0x57e9ae,_0x40d488['key'])<0x0)!_0x40d488['left']['isEmpty']()&&!_0x40d488['left']['isRed_']()&&!_0x40d488['left']['left']['isRed_']()&&(_0x40d488=_0x40d488['moveRedLeft_']()),_0x40d488=_0x40d488['copy'](null,null,null,_0x40d488['left']['remove'](_0x57e9ae,_0x53ae2a),null);else{if(_0x40d488['left']['isRed_']()&&(_0x40d488=_0x40d488['rotateRight_']()),!_0x40d488['right']['isEmpty']()&&!_0x40d488['right']['isRed_']()&&!_0x40d488['right']['left']['isRed_']()&&(_0x40d488=_0x40d488['moveRedRight_']()),_0x53ae2a(_0x57e9ae,_0x40d488['key'])===0x0){if(_0x40d488['right']['isEmpty']())return B['EMPTY_NODE'];_0x467923=_0x40d488['right']['min_'](),_0x40d488=_0x40d488['copy'](_0x467923['key'],_0x467923['value'],null,null,_0x40d488['right']['removeMin_']());}_0x40d488=_0x40d488['copy'](null,null,null,null,_0x40d488['right']['remove'](_0x57e9ae,_0x53ae2a));}return _0x40d488['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x287dcc=this;return _0x287dcc['right']['isRed_']()&&!_0x287dcc['left']['isRed_']()&&(_0x287dcc=_0x287dcc['rotateLeft_']()),_0x287dcc['left']['isRed_']()&&_0x287dcc['left']['left']['isRed_']()&&(_0x287dcc=_0x287dcc['rotateRight_']()),_0x287dcc['left']['isRed_']()&&_0x287dcc['right']['isRed_']()&&(_0x287dcc=_0x287dcc['colorFlip_']()),_0x287dcc;}['moveRedLeft_'](){let _0x3133ba=this['colorFlip_']();return _0x3133ba['right']['left']['isRed_']()&&(_0x3133ba=_0x3133ba['copy'](null,null,null,null,_0x3133ba['right']['rotateRight_']()),_0x3133ba=_0x3133ba['rotateLeft_'](),_0x3133ba=_0x3133ba['colorFlip_']()),_0x3133ba;}['moveRedRight_'](){let _0x339876=this['colorFlip_']();return _0x339876['left']['left']['isRed_']()&&(_0x339876=_0x339876['rotateRight_'](),_0x339876=_0x339876['colorFlip_']()),_0x339876;}['rotateLeft_'](){const _0x4eff00=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4eff00,null);}['rotateRight_'](){const _0x39172f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x39172f);}['colorFlip_'](){const _0x24b4ae=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x21718d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x24b4ae,_0x21718d);}['checkMaxDepth_'](){const _0x126ac5=this['check_']();return Math['pow'](0x2,_0x126ac5)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x405fcd=this['left']['check_']();if(_0x405fcd!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x405fcd+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x438ee1,_0x42569d,_0x42069f,_0x2cac0b,_0x3d4f3c){return this;}['insert'](_0x5efea1,_0x518f09,_0x2cb684){return new M(_0x5efea1,_0x518f09,null);}['remove'](_0x3c5801,_0x7e67c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1d3e0f){return!0x1;}['reverseTraversal'](_0x3344de){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x25a325,_0x5281d0=B['EMPTY_NODE']){this['comparator_']=_0x25a325,this['root_']=_0x5281d0;}['insert'](_0x50537f,_0x1ab403){return new B(this['comparator_'],this['root_']['insert'](_0x50537f,_0x1ab403,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x52cc02){return new B(this['comparator_'],this['root_']['remove'](_0x52cc02,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x58de7d){let _0x379bfd,_0x4cd6b9=this['root_'];for(;!_0x4cd6b9['isEmpty']();){if(_0x379bfd=this['comparator_'](_0x58de7d,_0x4cd6b9['key']),_0x379bfd===0x0)return _0x4cd6b9['value'];_0x379bfd<0x0?_0x4cd6b9=_0x4cd6b9['left']:_0x379bfd>0x0&&(_0x4cd6b9=_0x4cd6b9['right']);}return null;}['getPredecessorKey'](_0x49e420){let _0x46d207,_0x47ce7a=this['root_'],_0xd0dba0=null;for(;!_0x47ce7a['isEmpty']();)if(_0x46d207=this['comparator_'](_0x49e420,_0x47ce7a['key']),_0x46d207===0x0){if(_0x47ce7a['left']['isEmpty']())return _0xd0dba0?_0xd0dba0['key']:null;for(_0x47ce7a=_0x47ce7a['left'];!_0x47ce7a['right']['isEmpty']();)_0x47ce7a=_0x47ce7a['right'];return _0x47ce7a['key'];}else _0x46d207<0x0?_0x47ce7a=_0x47ce7a['left']:_0x46d207>0x0&&(_0xd0dba0=_0x47ce7a,_0x47ce7a=_0x47ce7a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x34008d){return this['root_']['inorderTraversal'](_0x34008d);}['reverseTraversal'](_0x52b61a){return this['root_']['reverseTraversal'](_0x52b61a);}['getIterator'](_0x2d640e){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x2d640e);}['getIteratorFrom'](_0x3b58af,_0x31ef75){return new Zt(this['root_'],_0x3b58af,this['comparator_'],!0x1,_0x31ef75);}['getReverseIteratorFrom'](_0x236b49,_0x3dd320){return new Zt(this['root_'],_0x236b49,this['comparator_'],!0x0,_0x3dd320);}['getReverseIterator'](_0x4891b2){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x4891b2);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xdc6be2,_0x330982){return He(_0xdc6be2['name'],_0x330982['name']);}function ji(_0x13df2a,_0x4f1442){return He(_0x13df2a,_0x4f1442);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x119a86){vi=_0x119a86;}const Ro=function(_0x476581){return typeof _0x476581=='number'?'number:'+so(_0x476581):'string:'+_0x476581;},Ao=function(_0x2c5117){if(_0x2c5117['isLeafNode']()){const _0x4be2a0=_0x2c5117['val']();f(typeof _0x4be2a0=='string'||typeof _0x4be2a0=='number'||typeof _0x4be2a0=='object'&&Y(_0x4be2a0,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2c5117===vi||_0x2c5117['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2c5117===vi||_0x2c5117['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3211ef){er=_0x3211ef;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x9f4ac3,_0x434964=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x9f4ac3,this['priorityNode_']=_0x434964,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x19c8c9){return new D(this['value_'],_0x19c8c9);}['getImmediateChild'](_0x274705){return _0x274705==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5504ea){return v(_0x5504ea)?this:y(_0x5504ea)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x248179,_0x922dae){return null;}['updateImmediateChild'](_0x48d2b8,_0x48e871){return _0x48d2b8==='.priority'?this['updatePriority'](_0x48e871):_0x48e871['isEmpty']()&&_0x48d2b8!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x48d2b8,_0x48e871)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x40e75c,_0x5ae606){const _0x17d0b0=y(_0x40e75c);return _0x17d0b0===null?_0x5ae606:_0x5ae606['isEmpty']()&&_0x17d0b0!=='.priority'?this:(f(_0x17d0b0!=='.priority'||we(_0x40e75c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x17d0b0,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x40e75c),_0x5ae606)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2b47a7,_0x196bfa){return!0x1;}['val'](_0x2efda9){return _0x2efda9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5bfdf7='';this['priorityNode_']['isEmpty']()||(_0x5bfdf7+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2c53b8=typeof this['value_'];_0x5bfdf7+=_0x2c53b8+':',_0x2c53b8==='number'?_0x5bfdf7+=so(this['value_']):_0x5bfdf7+=this['value_'],this['lazyHash_']=no(_0x5bfdf7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1a4a10){return _0x1a4a10===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1a4a10 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1a4a10['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1a4a10));}['compareToLeafNode_'](_0x16f3d1){const _0x7fa46=typeof _0x16f3d1['value_'],_0x24a2cd=typeof this['value_'],_0x2bbef3=D['VALUE_TYPE_ORDER']['indexOf'](_0x7fa46),_0x473ef8=D['VALUE_TYPE_ORDER']['indexOf'](_0x24a2cd);return f(_0x2bbef3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x7fa46),f(_0x473ef8>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x24a2cd),_0x2bbef3===_0x473ef8?_0x24a2cd==='object'?0x0:this['value_']<_0x16f3d1['value_']?-0x1:this['value_']===_0x16f3d1['value_']?0x0:0x1:_0x473ef8-_0x2bbef3;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1140a6){if(_0x1140a6===this)return!0x0;if(_0x1140a6['isLeafNode']()){const _0x44ec20=_0x1140a6;return this['value_']===_0x44ec20['value_']&&this['priorityNode_']['equals'](_0x44ec20['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x360140){ko=_0x360140;}function xh(_0x298886){No=_0x298886;}class Fh extends On{['compare'](_0x1da75a,_0x3b5be0){const _0x27bb7a=_0x1da75a['node']['getPriority'](),_0x4dedd6=_0x3b5be0['node']['getPriority'](),_0x82682e=_0x27bb7a['compareTo'](_0x4dedd6);return _0x82682e===0x0?He(_0x1da75a['name'],_0x3b5be0['name']):_0x82682e;}['isDefinedOn'](_0xcecd6a){return!_0xcecd6a['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x40e023,_0x5b45f0){return!_0x40e023['getPriority']()['equals'](_0x5b45f0['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x56d24e,_0x196367){const _0x1008fc=ko(_0x56d24e);return new E(_0x196367,new D('[PRIORITY-POST]',_0x1008fc));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x17aba3){const _0x51cfbf=_0x4c53f7=>parseInt(Math['log'](_0x4c53f7)/Uh,0xa),_0x46d538=_0x4a448a=>parseInt(Array(_0x4a448a+0x1)['join']('1'),0x2);this['count']=_0x51cfbf(_0x17aba3+0x1),this['current_']=this['count']-0x1;const _0x3f07ce=_0x46d538(this['count']);this['bits_']=_0x17aba3+0x1&_0x3f07ce;}['nextBitIsOne'](){const _0x213731=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x213731;}}const dn=function(_0x491b68,_0xea248a,_0x34cba6,_0x2b0b37){_0x491b68['sort'](_0xea248a);const _0x2249ff=function(_0x379cba,_0x13b1de){const _0x13dfb7=_0x13b1de-_0x379cba;let _0x5cc008,_0x2ee06c;if(_0x13dfb7===0x0)return null;if(_0x13dfb7===0x1)return _0x5cc008=_0x491b68[_0x379cba],_0x2ee06c=_0x34cba6?_0x34cba6(_0x5cc008):_0x5cc008,new M(_0x2ee06c,_0x5cc008['node'],M['BLACK'],null,null);{const _0x2c0306=parseInt(_0x13dfb7/0x2,0xa)+_0x379cba,_0x34806c=_0x2249ff(_0x379cba,_0x2c0306),_0x2e2ef5=_0x2249ff(_0x2c0306+0x1,_0x13b1de);return _0x5cc008=_0x491b68[_0x2c0306],_0x2ee06c=_0x34cba6?_0x34cba6(_0x5cc008):_0x5cc008,new M(_0x2ee06c,_0x5cc008['node'],M['BLACK'],_0x34806c,_0x2e2ef5);}},_0x38b574=function(_0x493ee1){let _0x59854a=null,_0x57bd7f=null,_0x1e5e46=_0x491b68['length'];const _0x1ab858=function(_0x5b8574,_0x313c13){const _0x3ab4a6=_0x1e5e46-_0x5b8574,_0x46ad96=_0x1e5e46;_0x1e5e46-=_0x5b8574;const _0x123b29=_0x2249ff(_0x3ab4a6+0x1,_0x46ad96),_0x262422=_0x491b68[_0x3ab4a6],_0x490c40=_0x34cba6?_0x34cba6(_0x262422):_0x262422;_0x33c753(new M(_0x490c40,_0x262422['node'],_0x313c13,null,_0x123b29));},_0x33c753=function(_0x219441){_0x59854a?(_0x59854a['left']=_0x219441,_0x59854a=_0x219441):(_0x57bd7f=_0x219441,_0x59854a=_0x219441);};for(let _0x48d319=0x0;_0x48d319<_0x493ee1['count'];++_0x48d319){const _0x47279c=_0x493ee1['nextBitIsOne'](),_0xd1c6a7=Math['pow'](0x2,_0x493ee1['count']-(_0x48d319+0x1));_0x47279c?_0x1ab858(_0xd1c6a7,M['BLACK']):(_0x1ab858(_0xd1c6a7,M['BLACK']),_0x1ab858(_0xd1c6a7,M['RED']));}return _0x57bd7f;},_0x372a92=new Wh(_0x491b68['length']),_0x45d708=_0x38b574(_0x372a92);return new B(_0x2b0b37||_0xea248a,_0x45d708);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5d45e7,_0x35bf96){this['indexes_']=_0x5d45e7,this['indexSet_']=_0x35bf96;}['get'](_0x194fa2){const _0x439996=Oe(this['indexes_'],_0x194fa2);if(!_0x439996)throw new Error('No\x20index\x20defined\x20for\x20'+_0x194fa2);return _0x439996 instanceof B?_0x439996:null;}['hasIndex'](_0x1e0530){return Y(this['indexSet_'],_0x1e0530['toString']());}['addIndex'](_0x21df27,_0x548e3f){f(_0x21df27!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x34add0=[];let _0x119d31=!0x1;const _0x10dd31=_0x548e3f['getIterator'](E['Wrap']);let _0x5c619b=_0x10dd31['getNext']();for(;_0x5c619b;)_0x119d31=_0x119d31||_0x21df27['isDefinedOn'](_0x5c619b['node']),_0x34add0['push'](_0x5c619b),_0x5c619b=_0x10dd31['getNext']();let _0x551507;_0x119d31?_0x551507=dn(_0x34add0,_0x21df27['getCompare']()):_0x551507=je;const _0x51c457=_0x21df27['toString'](),_0x5b0f57={...this['indexSet_']};_0x5b0f57[_0x51c457]=_0x21df27;const _0x4d976f={...this['indexes_']};return _0x4d976f[_0x51c457]=_0x551507,new ee(_0x4d976f,_0x5b0f57);}['addToIndexes'](_0x1838c3,_0xc2e442){const _0x523624=ln(this['indexes_'],(_0x4fb6b7,_0x40af27)=>{const _0x124ab5=Oe(this['indexSet_'],_0x40af27);if(f(_0x124ab5,'Missing\x20index\x20implementation\x20for\x20'+_0x40af27),_0x4fb6b7===je){if(_0x124ab5['isDefinedOn'](_0x1838c3['node'])){const _0x75c113=[],_0x1b3af5=_0xc2e442['getIterator'](E['Wrap']);let _0x5ab907=_0x1b3af5['getNext']();for(;_0x5ab907;)_0x5ab907['name']!==_0x1838c3['name']&&_0x75c113['push'](_0x5ab907),_0x5ab907=_0x1b3af5['getNext']();return _0x75c113['push'](_0x1838c3),dn(_0x75c113,_0x124ab5['getCompare']());}else return je;}else{const _0x3d3f45=_0xc2e442['get'](_0x1838c3['name']);let _0x3c9346=_0x4fb6b7;return _0x3d3f45&&(_0x3c9346=_0x3c9346['remove'](new E(_0x1838c3['name'],_0x3d3f45))),_0x3c9346['insert'](_0x1838c3,_0x1838c3['node']);}});return new ee(_0x523624,this['indexSet_']);}['removeFromIndexes'](_0x385560,_0x1b8e44){const _0x48775d=ln(this['indexes_'],_0x49ad45=>{if(_0x49ad45===je)return _0x49ad45;{const _0x1f73d2=_0x1b8e44['get'](_0x385560['name']);return _0x1f73d2?_0x49ad45['remove'](new E(_0x385560['name'],_0x1f73d2)):_0x49ad45;}});return new ee(_0x48775d,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3415d0,_0xc9a75b,_0x456d8f){this['children_']=_0x3415d0,this['priorityNode_']=_0xc9a75b,this['indexMap_']=_0x456d8f,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x2d99de){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2d99de,this['indexMap_']);}['getImmediateChild'](_0x514a21){if(_0x514a21==='.priority')return this['getPriority']();{const _0x17670f=this['children_']['get'](_0x514a21);return _0x17670f===null?gt:_0x17670f;}}['getChild'](_0x291636){const _0xdd0426=y(_0x291636);return _0xdd0426===null?this:this['getImmediateChild'](_0xdd0426)['getChild'](b(_0x291636));}['hasChild'](_0x329484){return this['children_']['get'](_0x329484)!==null;}['updateImmediateChild'](_0x471de3,_0x360601){if(f(_0x360601,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x471de3==='.priority')return this['updatePriority'](_0x360601);{const _0x460b18=new E(_0x471de3,_0x360601);let _0x1be091,_0x4cf2a3;_0x360601['isEmpty']()?(_0x1be091=this['children_']['remove'](_0x471de3),_0x4cf2a3=this['indexMap_']['removeFromIndexes'](_0x460b18,this['children_'])):(_0x1be091=this['children_']['insert'](_0x471de3,_0x360601),_0x4cf2a3=this['indexMap_']['addToIndexes'](_0x460b18,this['children_']));const _0x18d8ca=_0x1be091['isEmpty']()?gt:this['priorityNode_'];return new g(_0x1be091,_0x18d8ca,_0x4cf2a3);}}['updateChild'](_0x5d5625,_0xd1d441){const _0x585e54=y(_0x5d5625);if(_0x585e54===null)return _0xd1d441;{f(y(_0x5d5625)!=='.priority'||we(_0x5d5625)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xdea777=this['getImmediateChild'](_0x585e54)['updateChild'](b(_0x5d5625),_0xd1d441);return this['updateImmediateChild'](_0x585e54,_0xdea777);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2e7429){if(this['isEmpty']())return null;const _0x88314a={};let _0x11cbf9=0x0,_0x29684f=0x0,_0x55af62=!0x0;if(this['forEachChild'](R,(_0x8b0843,_0x51af0a)=>{_0x88314a[_0x8b0843]=_0x51af0a['val'](_0x2e7429),_0x11cbf9++,_0x55af62&&g['INTEGER_REGEXP_']['test'](_0x8b0843)?_0x29684f=Math['max'](_0x29684f,Number(_0x8b0843)):_0x55af62=!0x1;}),!_0x2e7429&&_0x55af62&&_0x29684f<0x2*_0x11cbf9){const _0x212dda=[];for(const _0x23646a in _0x88314a)_0x212dda[_0x23646a]=_0x88314a[_0x23646a];return _0x212dda;}else return _0x2e7429&&!this['getPriority']()['isEmpty']()&&(_0x88314a['.priority']=this['getPriority']()['val']()),_0x88314a;}['hash'](){if(this['lazyHash_']===null){let _0x7a2890='';this['getPriority']()['isEmpty']()||(_0x7a2890+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4b78fa,_0x453c69)=>{const _0x542831=_0x453c69['hash']();_0x542831!==''&&(_0x7a2890+=':'+_0x4b78fa+':'+_0x542831);}),this['lazyHash_']=_0x7a2890===''?'':no(_0x7a2890);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1441e3,_0x3bbca7,_0x35388e){const _0x544069=this['resolveIndex_'](_0x35388e);if(_0x544069){const _0x59594d=_0x544069['getPredecessorKey'](new E(_0x1441e3,_0x3bbca7));return _0x59594d?_0x59594d['name']:null;}else return this['children_']['getPredecessorKey'](_0x1441e3);}['getFirstChildName'](_0x237257){const _0x34d7e0=this['resolveIndex_'](_0x237257);if(_0x34d7e0){const _0xc40be0=_0x34d7e0['minKey']();return _0xc40be0&&_0xc40be0['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xd3bd62){const _0x544d78=this['getFirstChildName'](_0xd3bd62);return _0x544d78?new E(_0x544d78,this['children_']['get'](_0x544d78)):null;}['getLastChildName'](_0x57f474){const _0x4f5132=this['resolveIndex_'](_0x57f474);if(_0x4f5132){const _0x102c7a=_0x4f5132['maxKey']();return _0x102c7a&&_0x102c7a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xb2068b){const _0x44b032=this['getLastChildName'](_0xb2068b);return _0x44b032?new E(_0x44b032,this['children_']['get'](_0x44b032)):null;}['forEachChild'](_0x564fc7,_0x4d1242){const _0x55995f=this['resolveIndex_'](_0x564fc7);return _0x55995f?_0x55995f['inorderTraversal'](_0x4eb83b=>_0x4d1242(_0x4eb83b['name'],_0x4eb83b['node'])):this['children_']['inorderTraversal'](_0x4d1242);}['getIterator'](_0x568a4a){return this['getIteratorFrom'](_0x568a4a['minPost'](),_0x568a4a);}['getIteratorFrom'](_0x1a2141,_0x131bad){const _0x3c5e39=this['resolveIndex_'](_0x131bad);if(_0x3c5e39)return _0x3c5e39['getIteratorFrom'](_0x1a2141,_0x1d9079=>_0x1d9079);{const _0x251bda=this['children_']['getIteratorFrom'](_0x1a2141['name'],E['Wrap']);let _0x3ba34f=_0x251bda['peek']();for(;_0x3ba34f!=null&&_0x131bad['compare'](_0x3ba34f,_0x1a2141)<0x0;)_0x251bda['getNext'](),_0x3ba34f=_0x251bda['peek']();return _0x251bda;}}['getReverseIterator'](_0x34b6ba){return this['getReverseIteratorFrom'](_0x34b6ba['maxPost'](),_0x34b6ba);}['getReverseIteratorFrom'](_0x45f1c9,_0x24c7b1){const _0x1974af=this['resolveIndex_'](_0x24c7b1);if(_0x1974af)return _0x1974af['getReverseIteratorFrom'](_0x45f1c9,_0x24dd98=>_0x24dd98);{const _0x10d3a5=this['children_']['getReverseIteratorFrom'](_0x45f1c9['name'],E['Wrap']);let _0x1197b6=_0x10d3a5['peek']();for(;_0x1197b6!=null&&_0x24c7b1['compare'](_0x1197b6,_0x45f1c9)>0x0;)_0x10d3a5['getNext'](),_0x1197b6=_0x10d3a5['peek']();return _0x10d3a5;}}['compareTo'](_0x1fdad5){return this['isEmpty']()?_0x1fdad5['isEmpty']()?0x0:-0x1:_0x1fdad5['isLeafNode']()||_0x1fdad5['isEmpty']()?0x1:_0x1fdad5===Ht?-0x1:0x0;}['withIndex'](_0x133227){if(_0x133227===ye||this['indexMap_']['hasIndex'](_0x133227))return this;{const _0x1b377c=this['indexMap_']['addIndex'](_0x133227,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1b377c);}}['isIndexed'](_0xb91173){return _0xb91173===ye||this['indexMap_']['hasIndex'](_0xb91173);}['equals'](_0x33f128){if(_0x33f128===this)return!0x0;if(_0x33f128['isLeafNode']())return!0x1;{const _0x34b418=_0x33f128;if(this['getPriority']()['equals'](_0x34b418['getPriority']())){if(this['children_']['count']()===_0x34b418['children_']['count']()){const _0x154716=this['getIterator'](R),_0x195409=_0x34b418['getIterator'](R);let _0x45dc24=_0x154716['getNext'](),_0x1424d1=_0x195409['getNext']();for(;_0x45dc24&&_0x1424d1;){if(_0x45dc24['name']!==_0x1424d1['name']||!_0x45dc24['node']['equals'](_0x1424d1['node']))return!0x1;_0x45dc24=_0x154716['getNext'](),_0x1424d1=_0x195409['getNext']();}return _0x45dc24===null&&_0x1424d1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x18c03f){return _0x18c03f===ye?null:this['indexMap_']['get'](_0x18c03f['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x1b13df){return _0x1b13df===this?0x0:0x1;}['equals'](_0x153175){return _0x153175===this;}['getPriority'](){return this;}['getImmediateChild'](_0x55dfa3){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x76de0e,_0x325656=null){if(_0x76de0e===null)return g['EMPTY_NODE'];if(typeof _0x76de0e=='object'&&'.priority'in _0x76de0e&&(_0x325656=_0x76de0e['.priority']),f(_0x325656===null||typeof _0x325656=='string'||typeof _0x325656=='number'||typeof _0x325656=='object'&&'.sv'in _0x325656,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x325656),typeof _0x76de0e=='object'&&'.value'in _0x76de0e&&_0x76de0e['.value']!==null&&(_0x76de0e=_0x76de0e['.value']),typeof _0x76de0e!='object'||'.sv'in _0x76de0e){const _0x53891d=_0x76de0e;return new D(_0x53891d,N(_0x325656));}if(!(_0x76de0e instanceof Array)&&Vh){const _0xc28692=[];let _0x514382=!0x1;if(x(_0x76de0e,(_0x4a007f,_0x4ae568)=>{if(_0x4a007f['substring'](0x0,0x1)!=='.'){const _0x2fb170=N(_0x4ae568);_0x2fb170['isEmpty']()||(_0x514382=_0x514382||!_0x2fb170['getPriority']()['isEmpty'](),_0xc28692['push'](new E(_0x4a007f,_0x2fb170)));}}),_0xc28692['length']===0x0)return g['EMPTY_NODE'];const _0x2aac48=dn(_0xc28692,Dh,_0x3016a2=>_0x3016a2['name'],ji);if(_0x514382){const _0x270487=dn(_0xc28692,R['getCompare']());return new g(_0x2aac48,N(_0x325656),new ee({'.priority':_0x270487},{'.priority':R}));}else return new g(_0x2aac48,N(_0x325656),ee['Default']);}else{let _0x4f8531=g['EMPTY_NODE'];return x(_0x76de0e,(_0x1090c8,_0x572b16)=>{if(Y(_0x76de0e,_0x1090c8)&&_0x1090c8['substring'](0x0,0x1)!=='.'){const _0x32215d=N(_0x572b16);(_0x32215d['isLeafNode']()||!_0x32215d['isEmpty']())&&(_0x4f8531=_0x4f8531['updateImmediateChild'](_0x1090c8,_0x32215d));}}),_0x4f8531['updatePriority'](N(_0x325656));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x34e225){super(),this['indexPath_']=_0x34e225,f(!v(_0x34e225)&&y(_0x34e225)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x541c99){return _0x541c99['getChild'](this['indexPath_']);}['isDefinedOn'](_0x91f182){return!_0x91f182['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x10cade,_0x5cbc15){const _0x162596=this['extractChild'](_0x10cade['node']),_0x2489c6=this['extractChild'](_0x5cbc15['node']),_0x29699f=_0x162596['compareTo'](_0x2489c6);return _0x29699f===0x0?He(_0x10cade['name'],_0x5cbc15['name']):_0x29699f;}['makePost'](_0x23d528,_0x1cf9df){const _0x4df6d7=N(_0x23d528),_0x3df9c4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4df6d7);return new E(_0x1cf9df,_0x3df9c4);}['maxPost'](){const _0x23dc5f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x23dc5f);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x748092,_0x3b7d87){const _0x55e8b1=_0x748092['node']['compareTo'](_0x3b7d87['node']);return _0x55e8b1===0x0?He(_0x748092['name'],_0x3b7d87['name']):_0x55e8b1;}['isDefinedOn'](_0x5b7ce1){return!0x0;}['indexedValueChanged'](_0x4384bf,_0xe8d2e5){return!_0x4384bf['equals'](_0xe8d2e5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x42e96a,_0x14621d){const _0x1e0787=N(_0x42e96a);return new E(_0x14621d,_0x1e0787);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5dbce1){return{'type':'value','snapshotNode':_0x5dbce1};}function tt(_0x510445,_0x3b5b1a){return{'type':'child_added','snapshotNode':_0x3b5b1a,'childName':_0x510445};}function Nt(_0x4fde20,_0x419d91){return{'type':'child_removed','snapshotNode':_0x419d91,'childName':_0x4fde20};}function Pt(_0x5886b9,_0x48e5ed,_0x3513d3){return{'type':'child_changed','snapshotNode':_0x48e5ed,'childName':_0x5886b9,'oldSnap':_0x3513d3};}function $h(_0x54cd3a,_0x55d37e){return{'type':'child_moved','snapshotNode':_0x55d37e,'childName':_0x54cd3a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x4c54f4){this['index_']=_0x4c54f4;}['updateChild'](_0x1f7bfe,_0x4fccce,_0xeccea6,_0x15561b,_0x2f6086,_0x2b2ff4){f(_0x1f7bfe['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2bc587=_0x1f7bfe['getImmediateChild'](_0x4fccce);return _0x2bc587['getChild'](_0x15561b)['equals'](_0xeccea6['getChild'](_0x15561b))&&_0x2bc587['isEmpty']()===_0xeccea6['isEmpty']()||(_0x2b2ff4!=null&&(_0xeccea6['isEmpty']()?_0x1f7bfe['hasChild'](_0x4fccce)?_0x2b2ff4['trackChildChange'](Nt(_0x4fccce,_0x2bc587)):f(_0x1f7bfe['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2bc587['isEmpty']()?_0x2b2ff4['trackChildChange'](tt(_0x4fccce,_0xeccea6)):_0x2b2ff4['trackChildChange'](Pt(_0x4fccce,_0xeccea6,_0x2bc587))),_0x1f7bfe['isLeafNode']()&&_0xeccea6['isEmpty']())?_0x1f7bfe:_0x1f7bfe['updateImmediateChild'](_0x4fccce,_0xeccea6)['withIndex'](this['index_']);}['updateFullNode'](_0x864e3b,_0x8cbf62,_0x2eaf47){return _0x2eaf47!=null&&(_0x864e3b['isLeafNode']()||_0x864e3b['forEachChild'](R,(_0x1c7840,_0xfaa24a)=>{_0x8cbf62['hasChild'](_0x1c7840)||_0x2eaf47['trackChildChange'](Nt(_0x1c7840,_0xfaa24a));}),_0x8cbf62['isLeafNode']()||_0x8cbf62['forEachChild'](R,(_0x4a6ebb,_0xb19b30)=>{if(_0x864e3b['hasChild'](_0x4a6ebb)){const _0x950bc1=_0x864e3b['getImmediateChild'](_0x4a6ebb);_0x950bc1['equals'](_0xb19b30)||_0x2eaf47['trackChildChange'](Pt(_0x4a6ebb,_0xb19b30,_0x950bc1));}else _0x2eaf47['trackChildChange'](tt(_0x4a6ebb,_0xb19b30));})),_0x8cbf62['withIndex'](this['index_']);}['updatePriority'](_0x2840bb,_0x73d697){return _0x2840bb['isEmpty']()?g['EMPTY_NODE']:_0x2840bb['updatePriority'](_0x73d697);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x38f4b5){this['indexedFilter_']=new Yi(_0x38f4b5['getIndex']()),this['index_']=_0x38f4b5['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x38f4b5),this['endPost_']=Ot['getEndPost_'](_0x38f4b5),this['startIsInclusive_']=!_0x38f4b5['startAfterSet_'],this['endIsInclusive_']=!_0x38f4b5['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5308b5){const _0x3c6c26=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5308b5)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5308b5)<0x0,_0x2b3883=this['endIsInclusive_']?this['index_']['compare'](_0x5308b5,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5308b5,this['getEndPost']())<0x0;return _0x3c6c26&&_0x2b3883;}['updateChild'](_0x57690a,_0x365fbe,_0xca3ad,_0x37e992,_0x430eb1,_0x1cd21f){return this['matches'](new E(_0x365fbe,_0xca3ad))||(_0xca3ad=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x57690a,_0x365fbe,_0xca3ad,_0x37e992,_0x430eb1,_0x1cd21f);}['updateFullNode'](_0x6ec21d,_0x2d097a,_0x367af1){_0x2d097a['isLeafNode']()&&(_0x2d097a=g['EMPTY_NODE']);let _0x82c618=_0x2d097a['withIndex'](this['index_']);_0x82c618=_0x82c618['updatePriority'](g['EMPTY_NODE']);const _0x55d0b0=this;return _0x2d097a['forEachChild'](R,(_0x52964f,_0x8e1dc1)=>{_0x55d0b0['matches'](new E(_0x52964f,_0x8e1dc1))||(_0x82c618=_0x82c618['updateImmediateChild'](_0x52964f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x6ec21d,_0x82c618,_0x367af1);}['updatePriority'](_0x4f26f4,_0x2b2069){return _0x4f26f4;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5e65c4){if(_0x5e65c4['hasStart']()){const _0x3b5cce=_0x5e65c4['getIndexStartName']();return _0x5e65c4['getIndex']()['makePost'](_0x5e65c4['getIndexStartValue'](),_0x3b5cce);}else return _0x5e65c4['getIndex']()['minPost']();}static['getEndPost_'](_0x59a35e){if(_0x59a35e['hasEnd']()){const _0x4df9a3=_0x59a35e['getIndexEndName']();return _0x59a35e['getIndex']()['makePost'](_0x59a35e['getIndexEndValue'](),_0x4df9a3);}else return _0x59a35e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x59387e){this['withinDirectionalStart']=_0x2fc84b=>this['reverse_']?this['withinEndPost'](_0x2fc84b):this['withinStartPost'](_0x2fc84b),this['withinDirectionalEnd']=_0x2e6779=>this['reverse_']?this['withinStartPost'](_0x2e6779):this['withinEndPost'](_0x2e6779),this['withinStartPost']=_0x46b00a=>{const _0x574dde=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x46b00a);return this['startIsInclusive_']?_0x574dde<=0x0:_0x574dde<0x0;},this['withinEndPost']=_0x1df9c0=>{const _0x6dc3f8=this['index_']['compare'](_0x1df9c0,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x6dc3f8<=0x0:_0x6dc3f8<0x0;},this['rangedFilter_']=new Ot(_0x59387e),this['index_']=_0x59387e['getIndex'](),this['limit_']=_0x59387e['getLimit'](),this['reverse_']=!_0x59387e['isViewFromLeft'](),this['startIsInclusive_']=!_0x59387e['startAfterSet_'],this['endIsInclusive_']=!_0x59387e['endBeforeSet_'];}['updateChild'](_0x5c317e,_0x45f20d,_0x2b99d1,_0x3bee33,_0x44c6a0,_0x1bbba1){return this['rangedFilter_']['matches'](new E(_0x45f20d,_0x2b99d1))||(_0x2b99d1=g['EMPTY_NODE']),_0x5c317e['getImmediateChild'](_0x45f20d)['equals'](_0x2b99d1)?_0x5c317e:_0x5c317e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5c317e,_0x45f20d,_0x2b99d1,_0x3bee33,_0x44c6a0,_0x1bbba1):this['fullLimitUpdateChild_'](_0x5c317e,_0x45f20d,_0x2b99d1,_0x44c6a0,_0x1bbba1);}['updateFullNode'](_0x25d6cb,_0x32c8cd,_0x212b7c){let _0x464019;if(_0x32c8cd['isLeafNode']()||_0x32c8cd['isEmpty']())_0x464019=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x32c8cd['numChildren']()&&_0x32c8cd['isIndexed'](this['index_'])){_0x464019=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4ad20d;this['reverse_']?_0x4ad20d=_0x32c8cd['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4ad20d=_0x32c8cd['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xb971a3=0x0;for(;_0x4ad20d['hasNext']()&&_0xb971a3<this['limit_'];){const _0xef6c3d=_0x4ad20d['getNext']();if(this['withinDirectionalStart'](_0xef6c3d)){if(this['withinDirectionalEnd'](_0xef6c3d))_0x464019=_0x464019['updateImmediateChild'](_0xef6c3d['name'],_0xef6c3d['node']),_0xb971a3++;else break;}else continue;}}else{_0x464019=_0x32c8cd['withIndex'](this['index_']),_0x464019=_0x464019['updatePriority'](g['EMPTY_NODE']);let _0x56c8b3;this['reverse_']?_0x56c8b3=_0x464019['getReverseIterator'](this['index_']):_0x56c8b3=_0x464019['getIterator'](this['index_']);let _0x4f4a0d=0x0;for(;_0x56c8b3['hasNext']();){const _0x34c6c0=_0x56c8b3['getNext']();_0x4f4a0d<this['limit_']&&this['withinDirectionalStart'](_0x34c6c0)&&this['withinDirectionalEnd'](_0x34c6c0)?_0x4f4a0d++:_0x464019=_0x464019['updateImmediateChild'](_0x34c6c0['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x25d6cb,_0x464019,_0x212b7c);}['updatePriority'](_0x496ce5,_0x56d44c){return _0x496ce5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3e8fe6,_0x4b8812,_0x59c8d4,_0x540ada,_0x440823){let _0x364346;if(this['reverse_']){const _0x370c67=this['index_']['getCompare']();_0x364346=(_0x53f99b,_0x46f2a0)=>_0x370c67(_0x46f2a0,_0x53f99b);}else _0x364346=this['index_']['getCompare']();const _0x1b0499=_0x3e8fe6;f(_0x1b0499['numChildren']()===this['limit_'],'');const _0x5f195b=new E(_0x4b8812,_0x59c8d4),_0x2eba30=this['reverse_']?_0x1b0499['getFirstChild'](this['index_']):_0x1b0499['getLastChild'](this['index_']),_0x36d829=this['rangedFilter_']['matches'](_0x5f195b);if(_0x1b0499['hasChild'](_0x4b8812)){const _0x3ddd7d=_0x1b0499['getImmediateChild'](_0x4b8812);let _0x318056=_0x540ada['getChildAfterChild'](this['index_'],_0x2eba30,this['reverse_']);for(;_0x318056!=null&&(_0x318056['name']===_0x4b8812||_0x1b0499['hasChild'](_0x318056['name']));)_0x318056=_0x540ada['getChildAfterChild'](this['index_'],_0x318056,this['reverse_']);const _0x387fae=_0x318056==null?0x1:_0x364346(_0x318056,_0x5f195b);if(_0x36d829&&!_0x59c8d4['isEmpty']()&&_0x387fae>=0x0)return _0x440823!=null&&_0x440823['trackChildChange'](Pt(_0x4b8812,_0x59c8d4,_0x3ddd7d)),_0x1b0499['updateImmediateChild'](_0x4b8812,_0x59c8d4);{_0x440823!=null&&_0x440823['trackChildChange'](Nt(_0x4b8812,_0x3ddd7d));const _0x4c6445=_0x1b0499['updateImmediateChild'](_0x4b8812,g['EMPTY_NODE']);return _0x318056!=null&&this['rangedFilter_']['matches'](_0x318056)?(_0x440823!=null&&_0x440823['trackChildChange'](tt(_0x318056['name'],_0x318056['node'])),_0x4c6445['updateImmediateChild'](_0x318056['name'],_0x318056['node'])):_0x4c6445;}}else return _0x59c8d4['isEmpty']()?_0x3e8fe6:_0x36d829&&_0x364346(_0x2eba30,_0x5f195b)>=0x0?(_0x440823!=null&&(_0x440823['trackChildChange'](Nt(_0x2eba30['name'],_0x2eba30['node'])),_0x440823['trackChildChange'](tt(_0x4b8812,_0x59c8d4))),_0x1b0499['updateImmediateChild'](_0x4b8812,_0x59c8d4)['updateImmediateChild'](_0x2eba30['name'],g['EMPTY_NODE'])):_0x3e8fe6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xf4d928=new Qi();return _0xf4d928['limitSet_']=this['limitSet_'],_0xf4d928['limit_']=this['limit_'],_0xf4d928['startSet_']=this['startSet_'],_0xf4d928['startAfterSet_']=this['startAfterSet_'],_0xf4d928['indexStartValue_']=this['indexStartValue_'],_0xf4d928['startNameSet_']=this['startNameSet_'],_0xf4d928['indexStartName_']=this['indexStartName_'],_0xf4d928['endSet_']=this['endSet_'],_0xf4d928['endBeforeSet_']=this['endBeforeSet_'],_0xf4d928['indexEndValue_']=this['indexEndValue_'],_0xf4d928['endNameSet_']=this['endNameSet_'],_0xf4d928['indexEndName_']=this['indexEndName_'],_0xf4d928['index_']=this['index_'],_0xf4d928['viewFrom_']=this['viewFrom_'],_0xf4d928;}}function qh(_0x574485){return _0x574485['loadsAllData']()?new Yi(_0x574485['getIndex']()):_0x574485['hasLimit']()?new Gh(_0x574485):new Ot(_0x574485);}function zh(_0x42817f,_0x3afe3d){const _0x1a8bce=_0x42817f['copy']();return _0x1a8bce['limitSet_']=!0x0,_0x1a8bce['limit_']=_0x3afe3d,_0x1a8bce['viewFrom_']='l',_0x1a8bce;}function jh(_0x4fa61e,_0x5c03a7,_0x406e8f){const _0x3c0d0f=_0x4fa61e['copy']();return _0x3c0d0f['startSet_']=!0x0,_0x5c03a7===void 0x0&&(_0x5c03a7=null),_0x3c0d0f['indexStartValue_']=_0x5c03a7,_0x406e8f!=null?(_0x3c0d0f['startNameSet_']=!0x0,_0x3c0d0f['indexStartName_']=_0x406e8f):(_0x3c0d0f['startNameSet_']=!0x1,_0x3c0d0f['indexStartName_']=''),_0x3c0d0f;}function Kh(_0x572e4d,_0x725da8,_0x5eae91){const _0x23fed5=_0x572e4d['copy']();return _0x23fed5['endSet_']=!0x0,_0x725da8===void 0x0&&(_0x725da8=null),_0x23fed5['indexEndValue_']=_0x725da8,_0x5eae91!==void 0x0?(_0x23fed5['endNameSet_']=!0x0,_0x23fed5['indexEndName_']=_0x5eae91):(_0x23fed5['endNameSet_']=!0x1,_0x23fed5['indexEndName_']=''),_0x23fed5;}function Do(_0x2cb9ca,_0x26d9f8){const _0x5d03d6=_0x2cb9ca['copy']();return _0x5d03d6['index_']=_0x26d9f8,_0x5d03d6;}function tr(_0x5a0811){const _0x51a2a8={};if(_0x5a0811['isDefault']())return _0x51a2a8;let _0x32da14;if(_0x5a0811['index_']===R?_0x32da14='$priority':_0x5a0811['index_']===Po?_0x32da14='$value':_0x5a0811['index_']===ye?_0x32da14='$key':(f(_0x5a0811['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x32da14=_0x5a0811['index_']['toString']()),_0x51a2a8['orderBy']=O(_0x32da14),_0x5a0811['startSet_']){const _0x3f8e89=_0x5a0811['startAfterSet_']?'startAfter':'startAt';_0x51a2a8[_0x3f8e89]=O(_0x5a0811['indexStartValue_']),_0x5a0811['startNameSet_']&&(_0x51a2a8[_0x3f8e89]+=','+O(_0x5a0811['indexStartName_']));}if(_0x5a0811['endSet_']){const _0x3380ae=_0x5a0811['endBeforeSet_']?'endBefore':'endAt';_0x51a2a8[_0x3380ae]=O(_0x5a0811['indexEndValue_']),_0x5a0811['endNameSet_']&&(_0x51a2a8[_0x3380ae]+=','+O(_0x5a0811['indexEndName_']));}return _0x5a0811['limitSet_']&&(_0x5a0811['isViewFromLeft']()?_0x51a2a8['limitToFirst']=_0x5a0811['limit_']:_0x51a2a8['limitToLast']=_0x5a0811['limit_']),_0x51a2a8;}function nr(_0x506384){const _0x4e045={};if(_0x506384['startSet_']&&(_0x4e045['sp']=_0x506384['indexStartValue_'],_0x506384['startNameSet_']&&(_0x4e045['sn']=_0x506384['indexStartName_']),_0x4e045['sin']=!_0x506384['startAfterSet_']),_0x506384['endSet_']&&(_0x4e045['ep']=_0x506384['indexEndValue_'],_0x506384['endNameSet_']&&(_0x4e045['en']=_0x506384['indexEndName_']),_0x4e045['ein']=!_0x506384['endBeforeSet_']),_0x506384['limitSet_']){_0x4e045['l']=_0x506384['limit_'];let _0x2af370=_0x506384['viewFrom_'];_0x2af370===''&&(_0x506384['isViewFromLeft']()?_0x2af370='l':_0x2af370='r'),_0x4e045['vf']=_0x2af370;}return _0x506384['index_']!==R&&(_0x4e045['i']=_0x506384['index_']['toString']()),_0x4e045;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2b94f2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x16eef7,_0x3a16f9){return _0x3a16f9!==void 0x0?'tag$'+_0x3a16f9:(f(_0x16eef7['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x16eef7['_path']['toString']());}constructor(_0x202f3e,_0x533100,_0x484ffb,_0x569e91){super(),this['repoInfo_']=_0x202f3e,this['onDataUpdate_']=_0x533100,this['authTokenProvider_']=_0x484ffb,this['appCheckTokenProvider_']=_0x569e91,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x580507,_0x53353f,_0x5436f4,_0x542332){const _0x53634b=_0x580507['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x53634b+'\x20'+_0x580507['_queryIdentifier']);const _0x92a423=fn['getListenId_'](_0x580507,_0x5436f4),_0x66763a={};this['listens_'][_0x92a423]=_0x66763a;const _0x3d975b=tr(_0x580507['_queryParams']);this['restRequest_'](_0x53634b+'.json',_0x3d975b,(_0x1ffec4,_0x3840d5)=>{let _0x1deb05=_0x3840d5;if(_0x1ffec4===0x194&&(_0x1deb05=null,_0x1ffec4=null),_0x1ffec4===null&&this['onDataUpdate_'](_0x53634b,_0x1deb05,!0x1,_0x5436f4),Oe(this['listens_'],_0x92a423)===_0x66763a){let _0x5ede23;_0x1ffec4?_0x1ffec4===0x191?_0x5ede23='permission_denied':_0x5ede23='rest_error:'+_0x1ffec4:_0x5ede23='ok',_0x542332(_0x5ede23,null);}});}['unlisten'](_0x3384d0,_0x447161){const _0xdb495d=fn['getListenId_'](_0x3384d0,_0x447161);delete this['listens_'][_0xdb495d];}['get'](_0xf43990){const _0x554983=tr(_0xf43990['_queryParams']),_0x44f3bd=_0xf43990['_path']['toString'](),_0x5b8b0a=new Ve();return this['restRequest_'](_0x44f3bd+'.json',_0x554983,(_0x30d3db,_0x44760d)=>{let _0x5141a4=_0x44760d;_0x30d3db===0x194&&(_0x5141a4=null,_0x30d3db=null),_0x30d3db===null?(this['onDataUpdate_'](_0x44f3bd,_0x5141a4,!0x1,null),_0x5b8b0a['resolve'](_0x5141a4)):_0x5b8b0a['reject'](new Error(_0x5141a4));}),_0x5b8b0a['promise'];}['refreshAuthToken'](_0x4dfea2){}['restRequest_'](_0x4efb55,_0x5a336e={},_0x4e6a46){return _0x5a336e['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4eef27,_0x1b6b0f])=>{_0x4eef27&&_0x4eef27['accessToken']&&(_0x5a336e['auth']=_0x4eef27['accessToken']),_0x1b6b0f&&_0x1b6b0f['token']&&(_0x5a336e['ac']=_0x1b6b0f['token']);const _0x53d78d=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4efb55+'?ns='+this['repoInfo_']['namespace']+at(_0x5a336e);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x53d78d);const _0x107129=new XMLHttpRequest();_0x107129['onreadystatechange']=()=>{if(_0x4e6a46&&_0x107129['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x53d78d+'\x20received.\x20status:',_0x107129['status'],'response:',_0x107129['responseText']);let _0x20e400=null;if(_0x107129['status']>=0xc8&&_0x107129['status']<0x12c){try{_0x20e400=bt(_0x107129['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x53d78d+':\x20'+_0x107129['responseText']);}_0x4e6a46(null,_0x20e400);}else _0x107129['status']!==0x191&&_0x107129['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x53d78d+'\x20Status:\x20'+_0x107129['status']),_0x4e6a46(_0x107129['status']);_0x4e6a46=null;}},_0x107129['open']('GET',_0x53d78d,!0x0),_0x107129['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x290951){return this['rootNode_']['getChild'](_0x290951);}['updateSnapshot'](_0x310d8b,_0x297013){this['rootNode_']=this['rootNode_']['updateChild'](_0x310d8b,_0x297013);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x70ece8,_0x541b79,_0x45137b){if(v(_0x541b79))_0x70ece8['value']=_0x45137b,_0x70ece8['children']['clear']();else{if(_0x70ece8['value']!==null)_0x70ece8['value']=_0x70ece8['value']['updateChild'](_0x541b79,_0x45137b);else{const _0x1c5176=y(_0x541b79);_0x70ece8['children']['has'](_0x1c5176)||_0x70ece8['children']['set'](_0x1c5176,pn());const _0x5be029=_0x70ece8['children']['get'](_0x1c5176);_0x541b79=b(_0x541b79),Mo(_0x5be029,_0x541b79,_0x45137b);}}}function Ei(_0x291ae1,_0xd48b91,_0x29c286){_0x291ae1['value']!==null?_0x29c286(_0xd48b91,_0x291ae1['value']):Qh(_0x291ae1,(_0x464afa,_0x23d302)=>{const _0x13b1fc=new C(_0xd48b91['toString']()+'/'+_0x464afa);Ei(_0x23d302,_0x13b1fc,_0x29c286);});}function Qh(_0x1b460e,_0x2161ae){_0x1b460e['children']['forEach']((_0x28dc81,_0x228602)=>{_0x2161ae(_0x228602,_0x28dc81);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x249ac4){this['collection_']=_0x249ac4,this['last_']=null;}['get'](){const _0x53fb66=this['collection_']['get'](),_0x3ce7cd={..._0x53fb66};return this['last_']&&x(this['last_'],(_0x5683b3,_0x3b700c)=>{_0x3ce7cd[_0x5683b3]=_0x3ce7cd[_0x5683b3]-_0x3b700c;}),this['last_']=_0x53fb66,_0x3ce7cd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0xfb697f,_0x3c6aba){this['server_']=_0x3c6aba,this['statsToReport_']={},this['statsListener_']=new Jh(_0xfb697f);const _0x5822ef=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x5822ef));}['reportStats_'](){const _0x341fbf=this['statsListener_']['get'](),_0x453243={};let _0x27d141=!0x1;x(_0x341fbf,(_0x24910c,_0x31a1e3)=>{_0x31a1e3>0x0&&Y(this['statsToReport_'],_0x24910c)&&(_0x453243[_0x24910c]=_0x31a1e3,_0x27d141=!0x0);}),_0x27d141&&this['server_']['reportStats'](_0x453243),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x2b68ae){_0x2b68ae[_0x2b68ae['OVERWRITE']=0x0]='OVERWRITE',_0x2b68ae[_0x2b68ae['MERGE']=0x1]='MERGE',_0x2b68ae[_0x2b68ae['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2b68ae[_0x2b68ae['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2e90da){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2e90da,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3e01d3,_0x3b44c8,_0x2d51c5){this['path']=_0x3e01d3,this['affectedTree']=_0x3b44c8,this['revert']=_0x2d51c5,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x545843){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x14afd4=this['affectedTree']['subtree'](new C(_0x545843));return new _n(w(),_0x14afd4,this['revert']);}}else return f(y(this['path'])===_0x545843,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x23e867,_0x21d6d7){this['source']=_0x23e867,this['path']=_0x21d6d7,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x2c7e60){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x506f06,_0x103b03,_0x43452f){this['source']=_0x506f06,this['path']=_0x103b03,this['snap']=_0x43452f,this['type']=q['OVERWRITE'];}['operationForChild'](_0x559723){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x559723)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x12d9a8,_0xa6220d,_0x257c7f){this['source']=_0x12d9a8,this['path']=_0xa6220d,this['children']=_0x257c7f,this['type']=q['MERGE'];}['operationForChild'](_0x1c1aeb){if(v(this['path'])){const _0x1afcec=this['children']['subtree'](new C(_0x1c1aeb));return _0x1afcec['isEmpty']()?null:_0x1afcec['value']?new Fe(this['source'],w(),_0x1afcec['value']):new nt(this['source'],w(),_0x1afcec);}else return f(y(this['path'])===_0x1c1aeb,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x4c7137,_0x381f90,_0x583dfc){this['node_']=_0x4c7137,this['fullyInitialized_']=_0x381f90,this['filtered_']=_0x583dfc;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x215ee9){if(v(_0x215ee9))return this['isFullyInitialized']()&&!this['filtered_'];const _0x47750c=y(_0x215ee9);return this['isCompleteForChild'](_0x47750c);}['isCompleteForChild'](_0x5cf712){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5cf712);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4f8d84){this['query_']=_0x4f8d84,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x13f79a,_0xdcce14,_0xddce91,_0x357ef1){const _0x5cb323=[],_0x4089ed=[];return _0xdcce14['forEach'](_0x5cc7e3=>{_0x5cc7e3['type']==='child_changed'&&_0x13f79a['index_']['indexedValueChanged'](_0x5cc7e3['oldSnap'],_0x5cc7e3['snapshotNode'])&&_0x4089ed['push']($h(_0x5cc7e3['childName'],_0x5cc7e3['snapshotNode']));}),mt(_0x13f79a,_0x5cb323,'child_removed',_0xdcce14,_0x357ef1,_0xddce91),mt(_0x13f79a,_0x5cb323,'child_added',_0xdcce14,_0x357ef1,_0xddce91),mt(_0x13f79a,_0x5cb323,'child_moved',_0x4089ed,_0x357ef1,_0xddce91),mt(_0x13f79a,_0x5cb323,'child_changed',_0xdcce14,_0x357ef1,_0xddce91),mt(_0x13f79a,_0x5cb323,'value',_0xdcce14,_0x357ef1,_0xddce91),_0x5cb323;}function mt(_0x6b2f72,_0x57b58c,_0x3f7cca,_0x1cdf72,_0x428287,_0x1f1ed4){const _0x588db6=_0x1cdf72['filter'](_0xf8126c=>_0xf8126c['type']===_0x3f7cca);_0x588db6['sort']((_0x286d73,_0x544632)=>su(_0x6b2f72,_0x286d73,_0x544632)),_0x588db6['forEach'](_0x10cb4e=>{const _0xe485fc=iu(_0x6b2f72,_0x10cb4e,_0x1f1ed4);_0x428287['forEach'](_0x2857cf=>{_0x2857cf['respondsTo'](_0x10cb4e['type'])&&_0x57b58c['push'](_0x2857cf['createEvent'](_0xe485fc,_0x6b2f72['query_']));});});}function iu(_0x3718f0,_0x165be9,_0x36b821){return _0x165be9['type']==='value'||_0x165be9['type']==='child_removed'||(_0x165be9['prevName']=_0x36b821['getPredecessorChildName'](_0x165be9['childName'],_0x165be9['snapshotNode'],_0x3718f0['index_'])),_0x165be9;}function su(_0x155732,_0x380d69,_0x69404d){if(_0x380d69['childName']==null||_0x69404d['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0xae8f4b=new E(_0x380d69['childName'],_0x380d69['snapshotNode']),_0x4f2b9a=new E(_0x69404d['childName'],_0x69404d['snapshotNode']);return _0x155732['index_']['compare'](_0xae8f4b,_0x4f2b9a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x321003,_0x19e379){return{'eventCache':_0x321003,'serverCache':_0x19e379};}function wt(_0x24ce11,_0x132914,_0xa173cb,_0x1c64cb){return Dn(new Ce(_0x132914,_0xa173cb,_0x1c64cb),_0x24ce11['serverCache']);}function Lo(_0x2c3667,_0x4df819,_0xcfa106,_0xac3178){return Dn(_0x2c3667['eventCache'],new Ce(_0x4df819,_0xcfa106,_0xac3178));}function gn(_0x3727a8){return _0x3727a8['eventCache']['isFullyInitialized']()?_0x3727a8['eventCache']['getNode']():null;}function Ue(_0xf00059){return _0xf00059['serverCache']['isFullyInitialized']()?_0xf00059['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x455e65){let _0xa88e2e=new S(null);return x(_0x455e65,(_0xc3345c,_0x31e34c)=>{_0xa88e2e=_0xa88e2e['set'](new C(_0xc3345c),_0x31e34c);}),_0xa88e2e;}constructor(_0x2d5abd,_0x4d08b2=ru()){this['value']=_0x2d5abd,this['children']=_0x4d08b2;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xdf9aa,_0x1b0309){if(this['value']!=null&&_0x1b0309(this['value']))return{'path':w(),'value':this['value']};if(v(_0xdf9aa))return null;{const _0x4d189a=y(_0xdf9aa),_0x414caa=this['children']['get'](_0x4d189a);if(_0x414caa!==null){const _0x1c2f34=_0x414caa['findRootMostMatchingPathAndValue'](b(_0xdf9aa),_0x1b0309);return _0x1c2f34!=null?{'path':A(new C(_0x4d189a),_0x1c2f34['path']),'value':_0x1c2f34['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xd0fdeb){return this['findRootMostMatchingPathAndValue'](_0xd0fdeb,()=>!0x0);}['subtree'](_0xb886cc){if(v(_0xb886cc))return this;{const _0x25b0aa=y(_0xb886cc),_0x3b2efc=this['children']['get'](_0x25b0aa);return _0x3b2efc!==null?_0x3b2efc['subtree'](b(_0xb886cc)):new S(null);}}['set'](_0x32362f,_0x56c32c){if(v(_0x32362f))return new S(_0x56c32c,this['children']);{const _0xefac48=y(_0x32362f),_0x28b334=(this['children']['get'](_0xefac48)||new S(null))['set'](b(_0x32362f),_0x56c32c),_0x5c861e=this['children']['insert'](_0xefac48,_0x28b334);return new S(this['value'],_0x5c861e);}}['remove'](_0x225297){if(v(_0x225297))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x406afe=y(_0x225297),_0x442ad0=this['children']['get'](_0x406afe);if(_0x442ad0){const _0x3d3164=_0x442ad0['remove'](b(_0x225297));let _0x463206;return _0x3d3164['isEmpty']()?_0x463206=this['children']['remove'](_0x406afe):_0x463206=this['children']['insert'](_0x406afe,_0x3d3164),this['value']===null&&_0x463206['isEmpty']()?new S(null):new S(this['value'],_0x463206);}else return this;}}['get'](_0x135eea){if(v(_0x135eea))return this['value'];{const _0x4f37c5=y(_0x135eea),_0x25a4f2=this['children']['get'](_0x4f37c5);return _0x25a4f2?_0x25a4f2['get'](b(_0x135eea)):null;}}['setTree'](_0x374196,_0x1cc676){if(v(_0x374196))return _0x1cc676;{const _0x5d9498=y(_0x374196),_0x5bf4fc=(this['children']['get'](_0x5d9498)||new S(null))['setTree'](b(_0x374196),_0x1cc676);let _0x581fc6;return _0x5bf4fc['isEmpty']()?_0x581fc6=this['children']['remove'](_0x5d9498):_0x581fc6=this['children']['insert'](_0x5d9498,_0x5bf4fc),new S(this['value'],_0x581fc6);}}['fold'](_0x3c654d){return this['fold_'](w(),_0x3c654d);}['fold_'](_0x26be47,_0x196494){const _0x2334a0={};return this['children']['inorderTraversal']((_0x383137,_0x411a49)=>{_0x2334a0[_0x383137]=_0x411a49['fold_'](A(_0x26be47,_0x383137),_0x196494);}),_0x196494(_0x26be47,this['value'],_0x2334a0);}['findOnPath'](_0x5865ab,_0x488bda){return this['findOnPath_'](_0x5865ab,w(),_0x488bda);}['findOnPath_'](_0x2a2f98,_0xdf6dd3,_0x407d41){const _0x5b3c43=this['value']?_0x407d41(_0xdf6dd3,this['value']):!0x1;if(_0x5b3c43)return _0x5b3c43;if(v(_0x2a2f98))return null;{const _0x4bd691=y(_0x2a2f98),_0x427bba=this['children']['get'](_0x4bd691);return _0x427bba?_0x427bba['findOnPath_'](b(_0x2a2f98),A(_0xdf6dd3,_0x4bd691),_0x407d41):null;}}['foreachOnPath'](_0x493d0b,_0x1ce317){return this['foreachOnPath_'](_0x493d0b,w(),_0x1ce317);}['foreachOnPath_'](_0x130331,_0x101764,_0x9c6b97){if(v(_0x130331))return this;{this['value']&&_0x9c6b97(_0x101764,this['value']);const _0x1fcab6=y(_0x130331),_0x32cc69=this['children']['get'](_0x1fcab6);return _0x32cc69?_0x32cc69['foreachOnPath_'](b(_0x130331),A(_0x101764,_0x1fcab6),_0x9c6b97):new S(null);}}['foreach'](_0x40509f){this['foreach_'](w(),_0x40509f);}['foreach_'](_0xe8339d,_0x3f7b6a){this['children']['inorderTraversal']((_0x2d9522,_0x4509ad)=>{_0x4509ad['foreach_'](A(_0xe8339d,_0x2d9522),_0x3f7b6a);}),this['value']&&_0x3f7b6a(_0xe8339d,this['value']);}['foreachChild'](_0x577e47){this['children']['inorderTraversal']((_0x2be72c,_0x5d2e4b)=>{_0x5d2e4b['value']&&_0x577e47(_0x2be72c,_0x5d2e4b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0xa97895){this['writeTree_']=_0xa97895;}static['empty'](){return new j(new S(null));}}function Ct(_0xe28d54,_0x28346b,_0x496cc0){if(v(_0x28346b))return new j(new S(_0x496cc0));{const _0x412ed7=_0xe28d54['writeTree_']['findRootMostValueAndPath'](_0x28346b);if(_0x412ed7!=null){const _0x719432=_0x412ed7['path'];let _0x4353a8=_0x412ed7['value'];const _0x333d63=F(_0x719432,_0x28346b);return _0x4353a8=_0x4353a8['updateChild'](_0x333d63,_0x496cc0),new j(_0xe28d54['writeTree_']['set'](_0x719432,_0x4353a8));}else{const _0x5a3777=new S(_0x496cc0),_0x154d3c=_0xe28d54['writeTree_']['setTree'](_0x28346b,_0x5a3777);return new j(_0x154d3c);}}}function Ii(_0x59d580,_0x44194a,_0x1ced33){let _0x796fc5=_0x59d580;return x(_0x1ced33,(_0x2cfac3,_0x891e87)=>{_0x796fc5=Ct(_0x796fc5,A(_0x44194a,_0x2cfac3),_0x891e87);}),_0x796fc5;}function sr(_0x230000,_0x43fbfb){if(v(_0x43fbfb))return j['empty']();{const _0x57c917=_0x230000['writeTree_']['setTree'](_0x43fbfb,new S(null));return new j(_0x57c917);}}function wi(_0x3e2d99,_0x351c36){return $e(_0x3e2d99,_0x351c36)!=null;}function $e(_0x719a5d,_0x5c0539){const _0x55623e=_0x719a5d['writeTree_']['findRootMostValueAndPath'](_0x5c0539);return _0x55623e!=null?_0x719a5d['writeTree_']['get'](_0x55623e['path'])['getChild'](F(_0x55623e['path'],_0x5c0539)):null;}function rr(_0x4ab214){const _0x279680=[],_0x1241f7=_0x4ab214['writeTree_']['value'];return _0x1241f7!=null?_0x1241f7['isLeafNode']()||_0x1241f7['forEachChild'](R,(_0x594d99,_0x252af3)=>{_0x279680['push'](new E(_0x594d99,_0x252af3));}):_0x4ab214['writeTree_']['children']['inorderTraversal']((_0xf81bd1,_0xc91de6)=>{_0xc91de6['value']!=null&&_0x279680['push'](new E(_0xf81bd1,_0xc91de6['value']));}),_0x279680;}function ve(_0x203ca2,_0x4a61ae){if(v(_0x4a61ae))return _0x203ca2;{const _0x1288f3=$e(_0x203ca2,_0x4a61ae);return _0x1288f3!=null?new j(new S(_0x1288f3)):new j(_0x203ca2['writeTree_']['subtree'](_0x4a61ae));}}function Ci(_0x42ee4c){return _0x42ee4c['writeTree_']['isEmpty']();}function it(_0x1b4cfa,_0x549f29){return xo(w(),_0x1b4cfa['writeTree_'],_0x549f29);}function xo(_0x136c8a,_0x35932e,_0x2c6f41){if(_0x35932e['value']!=null)return _0x2c6f41['updateChild'](_0x136c8a,_0x35932e['value']);{let _0x241de3=null;return _0x35932e['children']['inorderTraversal']((_0x1e94e2,_0x89a53b)=>{_0x1e94e2==='.priority'?(f(_0x89a53b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x241de3=_0x89a53b['value']):_0x2c6f41=xo(A(_0x136c8a,_0x1e94e2),_0x89a53b,_0x2c6f41);}),!_0x2c6f41['getChild'](_0x136c8a)['isEmpty']()&&_0x241de3!==null&&(_0x2c6f41=_0x2c6f41['updateChild'](A(_0x136c8a,'.priority'),_0x241de3)),_0x2c6f41;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x594be6,_0x3c142d){return Bo(_0x3c142d,_0x594be6);}function ou(_0x5eaea7,_0x2e039a,_0x4545f6,_0x572606,_0xd0c9c5){f(_0x572606>_0x5eaea7['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xd0c9c5===void 0x0&&(_0xd0c9c5=!0x0),_0x5eaea7['allWrites']['push']({'path':_0x2e039a,'snap':_0x4545f6,'writeId':_0x572606,'visible':_0xd0c9c5}),_0xd0c9c5&&(_0x5eaea7['visibleWrites']=Ct(_0x5eaea7['visibleWrites'],_0x2e039a,_0x4545f6)),_0x5eaea7['lastWriteId']=_0x572606;}function au(_0x28cea7,_0x3389e8,_0x3d4d55,_0x26deff){f(_0x26deff>_0x28cea7['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x28cea7['allWrites']['push']({'path':_0x3389e8,'children':_0x3d4d55,'writeId':_0x26deff,'visible':!0x0}),_0x28cea7['visibleWrites']=Ii(_0x28cea7['visibleWrites'],_0x3389e8,_0x3d4d55),_0x28cea7['lastWriteId']=_0x26deff;}function cu(_0x1d1239,_0x2a97b8){for(let _0x40dca9=0x0;_0x40dca9<_0x1d1239['allWrites']['length'];_0x40dca9++){const _0x15e057=_0x1d1239['allWrites'][_0x40dca9];if(_0x15e057['writeId']===_0x2a97b8)return _0x15e057;}return null;}function lu(_0x26df4c,_0x1d7d5d){const _0x1554bb=_0x26df4c['allWrites']['findIndex'](_0x31ac9f=>_0x31ac9f['writeId']===_0x1d7d5d);f(_0x1554bb>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x470b44=_0x26df4c['allWrites'][_0x1554bb];_0x26df4c['allWrites']['splice'](_0x1554bb,0x1);let _0x145104=_0x470b44['visible'],_0x1feef7=!0x1,_0x39c8dd=_0x26df4c['allWrites']['length']-0x1;for(;_0x145104&&_0x39c8dd>=0x0;){const _0x48e6e3=_0x26df4c['allWrites'][_0x39c8dd];_0x48e6e3['visible']&&(_0x39c8dd>=_0x1554bb&&hu(_0x48e6e3,_0x470b44['path'])?_0x145104=!0x1:$(_0x470b44['path'],_0x48e6e3['path'])&&(_0x1feef7=!0x0)),_0x39c8dd--;}if(_0x145104){if(_0x1feef7)return uu(_0x26df4c),!0x0;if(_0x470b44['snap'])_0x26df4c['visibleWrites']=sr(_0x26df4c['visibleWrites'],_0x470b44['path']);else{const _0x5d84cb=_0x470b44['children'];x(_0x5d84cb,_0x4f5ce4=>{_0x26df4c['visibleWrites']=sr(_0x26df4c['visibleWrites'],A(_0x470b44['path'],_0x4f5ce4));});}return!0x0;}else return!0x1;}function hu(_0x3d350a,_0x52ff4d){if(_0x3d350a['snap'])return $(_0x3d350a['path'],_0x52ff4d);for(const _0x38ba02 in _0x3d350a['children'])if(_0x3d350a['children']['hasOwnProperty'](_0x38ba02)&&$(A(_0x3d350a['path'],_0x38ba02),_0x52ff4d))return!0x0;return!0x1;}function uu(_0x4abac0){_0x4abac0['visibleWrites']=Fo(_0x4abac0['allWrites'],du,w()),_0x4abac0['allWrites']['length']>0x0?_0x4abac0['lastWriteId']=_0x4abac0['allWrites'][_0x4abac0['allWrites']['length']-0x1]['writeId']:_0x4abac0['lastWriteId']=-0x1;}function du(_0x385068){return _0x385068['visible'];}function Fo(_0x16f561,_0x1aa090,_0x1f3ea5){let _0x5b7855=j['empty']();for(let _0x3ed245=0x0;_0x3ed245<_0x16f561['length'];++_0x3ed245){const _0x2a8c01=_0x16f561[_0x3ed245];if(_0x1aa090(_0x2a8c01)){const _0x5ad496=_0x2a8c01['path'];let _0x31c709;if(_0x2a8c01['snap'])$(_0x1f3ea5,_0x5ad496)?(_0x31c709=F(_0x1f3ea5,_0x5ad496),_0x5b7855=Ct(_0x5b7855,_0x31c709,_0x2a8c01['snap'])):$(_0x5ad496,_0x1f3ea5)&&(_0x31c709=F(_0x5ad496,_0x1f3ea5),_0x5b7855=Ct(_0x5b7855,w(),_0x2a8c01['snap']['getChild'](_0x31c709)));else{if(_0x2a8c01['children']){if($(_0x1f3ea5,_0x5ad496))_0x31c709=F(_0x1f3ea5,_0x5ad496),_0x5b7855=Ii(_0x5b7855,_0x31c709,_0x2a8c01['children']);else{if($(_0x5ad496,_0x1f3ea5)){if(_0x31c709=F(_0x5ad496,_0x1f3ea5),v(_0x31c709))_0x5b7855=Ii(_0x5b7855,w(),_0x2a8c01['children']);else{const _0x34d30b=Oe(_0x2a8c01['children'],y(_0x31c709));if(_0x34d30b){const _0x20354b=_0x34d30b['getChild'](b(_0x31c709));_0x5b7855=Ct(_0x5b7855,w(),_0x20354b);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5b7855;}function Uo(_0x5ecffa,_0x2be6e0,_0x5f3af3,_0x3756c,_0x361291){if(!_0x3756c&&!_0x361291){const _0x2b16e5=$e(_0x5ecffa['visibleWrites'],_0x2be6e0);if(_0x2b16e5!=null)return _0x2b16e5;{const _0x34fe1c=ve(_0x5ecffa['visibleWrites'],_0x2be6e0);if(Ci(_0x34fe1c))return _0x5f3af3;if(_0x5f3af3==null&&!wi(_0x34fe1c,w()))return null;{const _0x4e378b=_0x5f3af3||g['EMPTY_NODE'];return it(_0x34fe1c,_0x4e378b);}}}else{const _0x331fe3=ve(_0x5ecffa['visibleWrites'],_0x2be6e0);if(!_0x361291&&Ci(_0x331fe3))return _0x5f3af3;if(!_0x361291&&_0x5f3af3==null&&!wi(_0x331fe3,w()))return null;{const _0x486278=function(_0x38a75b){return(_0x38a75b['visible']||_0x361291)&&(!_0x3756c||!~_0x3756c['indexOf'](_0x38a75b['writeId']))&&($(_0x38a75b['path'],_0x2be6e0)||$(_0x2be6e0,_0x38a75b['path']));},_0x2393eb=Fo(_0x5ecffa['allWrites'],_0x486278,_0x2be6e0),_0x2d209=_0x5f3af3||g['EMPTY_NODE'];return it(_0x2393eb,_0x2d209);}}}function fu(_0x3b4384,_0x5a4460,_0x3a812b){let _0x207a9f=g['EMPTY_NODE'];const _0x2dca12=$e(_0x3b4384['visibleWrites'],_0x5a4460);if(_0x2dca12)return _0x2dca12['isLeafNode']()||_0x2dca12['forEachChild'](R,(_0x566d7a,_0x9bf5d6)=>{_0x207a9f=_0x207a9f['updateImmediateChild'](_0x566d7a,_0x9bf5d6);}),_0x207a9f;if(_0x3a812b){const _0x3fff26=ve(_0x3b4384['visibleWrites'],_0x5a4460);return _0x3a812b['forEachChild'](R,(_0x7c1f17,_0x503c11)=>{const _0x20c538=it(ve(_0x3fff26,new C(_0x7c1f17)),_0x503c11);_0x207a9f=_0x207a9f['updateImmediateChild'](_0x7c1f17,_0x20c538);}),rr(_0x3fff26)['forEach'](_0x4f1701=>{_0x207a9f=_0x207a9f['updateImmediateChild'](_0x4f1701['name'],_0x4f1701['node']);}),_0x207a9f;}else{const _0x315325=ve(_0x3b4384['visibleWrites'],_0x5a4460);return rr(_0x315325)['forEach'](_0x1472c5=>{_0x207a9f=_0x207a9f['updateImmediateChild'](_0x1472c5['name'],_0x1472c5['node']);}),_0x207a9f;}}function pu(_0x4fda40,_0x2474c1,_0x4379ec,_0x2c8c22,_0x4ea383){f(_0x2c8c22||_0x4ea383,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x411d8e=A(_0x2474c1,_0x4379ec);if(wi(_0x4fda40['visibleWrites'],_0x411d8e))return null;{const _0x4b3b71=ve(_0x4fda40['visibleWrites'],_0x411d8e);return Ci(_0x4b3b71)?_0x4ea383['getChild'](_0x4379ec):it(_0x4b3b71,_0x4ea383['getChild'](_0x4379ec));}}function _u(_0x8610e3,_0x59d171,_0x16569,_0xfa713a){const _0x136a57=A(_0x59d171,_0x16569),_0x523431=$e(_0x8610e3['visibleWrites'],_0x136a57);if(_0x523431!=null)return _0x523431;if(_0xfa713a['isCompleteForChild'](_0x16569)){const _0x678ae4=ve(_0x8610e3['visibleWrites'],_0x136a57);return it(_0x678ae4,_0xfa713a['getNode']()['getImmediateChild'](_0x16569));}else return null;}function gu(_0x343b14,_0x3ece63){return $e(_0x343b14['visibleWrites'],_0x3ece63);}function mu(_0x42cdf9,_0x511b13,_0x251dc0,_0x476154,_0x422f00,_0x138ee1,_0x12ebc0){let _0x4669d8;const _0x203c0f=ve(_0x42cdf9['visibleWrites'],_0x511b13),_0x323a8e=$e(_0x203c0f,w());if(_0x323a8e!=null)_0x4669d8=_0x323a8e;else{if(_0x251dc0!=null)_0x4669d8=it(_0x203c0f,_0x251dc0);else return[];}if(_0x4669d8=_0x4669d8['withIndex'](_0x12ebc0),!_0x4669d8['isEmpty']()&&!_0x4669d8['isLeafNode']()){const _0x344ab6=[],_0x5d270c=_0x12ebc0['getCompare'](),_0x5add12=_0x138ee1?_0x4669d8['getReverseIteratorFrom'](_0x476154,_0x12ebc0):_0x4669d8['getIteratorFrom'](_0x476154,_0x12ebc0);let _0x16e17f=_0x5add12['getNext']();for(;_0x16e17f&&_0x344ab6['length']<_0x422f00;)_0x5d270c(_0x16e17f,_0x476154)!==0x0&&_0x344ab6['push'](_0x16e17f),_0x16e17f=_0x5add12['getNext']();return _0x344ab6;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x42ab84,_0x5133aa,_0xefe13d,_0x2db9d6){return Uo(_0x42ab84['writeTree'],_0x42ab84['treePath'],_0x5133aa,_0xefe13d,_0x2db9d6);}function es(_0x1a323e,_0x1ce590){return fu(_0x1a323e['writeTree'],_0x1a323e['treePath'],_0x1ce590);}function or(_0x14c2dc,_0x152506,_0x3f796f,_0x2718a7){return pu(_0x14c2dc['writeTree'],_0x14c2dc['treePath'],_0x152506,_0x3f796f,_0x2718a7);}function yn(_0x46fdc6,_0x48a165){return gu(_0x46fdc6['writeTree'],A(_0x46fdc6['treePath'],_0x48a165));}function vu(_0x48f371,_0x3badc7,_0x553dfb,_0x1a5288,_0x10e728,_0x422045){return mu(_0x48f371['writeTree'],_0x48f371['treePath'],_0x3badc7,_0x553dfb,_0x1a5288,_0x10e728,_0x422045);}function ts(_0x58d1fe,_0x12ce7d,_0x23db80){return _u(_0x58d1fe['writeTree'],_0x58d1fe['treePath'],_0x12ce7d,_0x23db80);}function Wo(_0x5bd3d8,_0x3ac8b0){return Bo(A(_0x5bd3d8['treePath'],_0x3ac8b0),_0x5bd3d8['writeTree']);}function Bo(_0x4200c6,_0x1448fd){return{'treePath':_0x4200c6,'writeTree':_0x1448fd};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4cc0f3){const _0x2714a1=_0x4cc0f3['type'],_0x26c0ac=_0x4cc0f3['childName'];f(_0x2714a1==='child_added'||_0x2714a1==='child_changed'||_0x2714a1==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x26c0ac!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x195a9b=this['changeMap']['get'](_0x26c0ac);if(_0x195a9b){const _0x599c7e=_0x195a9b['type'];if(_0x2714a1==='child_added'&&_0x599c7e==='child_removed')this['changeMap']['set'](_0x26c0ac,Pt(_0x26c0ac,_0x4cc0f3['snapshotNode'],_0x195a9b['snapshotNode']));else{if(_0x2714a1==='child_removed'&&_0x599c7e==='child_added')this['changeMap']['delete'](_0x26c0ac);else{if(_0x2714a1==='child_removed'&&_0x599c7e==='child_changed')this['changeMap']['set'](_0x26c0ac,Nt(_0x26c0ac,_0x195a9b['oldSnap']));else{if(_0x2714a1==='child_changed'&&_0x599c7e==='child_added')this['changeMap']['set'](_0x26c0ac,tt(_0x26c0ac,_0x4cc0f3['snapshotNode']));else{if(_0x2714a1==='child_changed'&&_0x599c7e==='child_changed')this['changeMap']['set'](_0x26c0ac,Pt(_0x26c0ac,_0x4cc0f3['snapshotNode'],_0x195a9b['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x4cc0f3+'\x20occurred\x20after\x20'+_0x195a9b);}}}}}else this['changeMap']['set'](_0x26c0ac,_0x4cc0f3);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x211929){return null;}['getChildAfterChild'](_0x277126,_0x8ec272,_0x8b4532){return null;}}const Vo=new Iu();class ns{constructor(_0x550477,_0x1b3767,_0x461d52=null){this['writes_']=_0x550477,this['viewCache_']=_0x1b3767,this['optCompleteServerCache_']=_0x461d52;}['getCompleteChild'](_0x33c7b0){const _0x390b84=this['viewCache_']['eventCache'];if(_0x390b84['isCompleteForChild'](_0x33c7b0))return _0x390b84['getNode']()['getImmediateChild'](_0x33c7b0);{const _0x26043e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x33c7b0,_0x26043e);}}['getChildAfterChild'](_0x1889bd,_0x125522,_0x32a969){const _0x3f471f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5a23d4=vu(this['writes_'],_0x3f471f,_0x125522,0x1,_0x32a969,_0x1889bd);return _0x5a23d4['length']===0x0?null:_0x5a23d4[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x8ed8f6){return{'filter':_0x8ed8f6};}function Cu(_0x53c034,_0x8839f5){f(_0x8839f5['eventCache']['getNode']()['isIndexed'](_0x53c034['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x8839f5['serverCache']['getNode']()['isIndexed'](_0x53c034['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x2af483,_0xd5ec4c,_0x149615,_0x38fbdd,_0x19a3d5){const _0x405cf8=new Eu();let _0x58b6e7,_0x10c33a;if(_0x149615['type']===q['OVERWRITE']){const _0x4eb97f=_0x149615;_0x4eb97f['source']['fromUser']?_0x58b6e7=Ti(_0x2af483,_0xd5ec4c,_0x4eb97f['path'],_0x4eb97f['snap'],_0x38fbdd,_0x19a3d5,_0x405cf8):(f(_0x4eb97f['source']['fromServer'],'Unknown\x20source.'),_0x10c33a=_0x4eb97f['source']['tagged']||_0xd5ec4c['serverCache']['isFiltered']()&&!v(_0x4eb97f['path']),_0x58b6e7=vn(_0x2af483,_0xd5ec4c,_0x4eb97f['path'],_0x4eb97f['snap'],_0x38fbdd,_0x19a3d5,_0x10c33a,_0x405cf8));}else{if(_0x149615['type']===q['MERGE']){const _0x2de168=_0x149615;_0x2de168['source']['fromUser']?_0x58b6e7=bu(_0x2af483,_0xd5ec4c,_0x2de168['path'],_0x2de168['children'],_0x38fbdd,_0x19a3d5,_0x405cf8):(f(_0x2de168['source']['fromServer'],'Unknown\x20source.'),_0x10c33a=_0x2de168['source']['tagged']||_0xd5ec4c['serverCache']['isFiltered'](),_0x58b6e7=Si(_0x2af483,_0xd5ec4c,_0x2de168['path'],_0x2de168['children'],_0x38fbdd,_0x19a3d5,_0x10c33a,_0x405cf8));}else{if(_0x149615['type']===q['ACK_USER_WRITE']){const _0x23e544=_0x149615;_0x23e544['revert']?_0x58b6e7=ku(_0x2af483,_0xd5ec4c,_0x23e544['path'],_0x38fbdd,_0x19a3d5,_0x405cf8):_0x58b6e7=Ru(_0x2af483,_0xd5ec4c,_0x23e544['path'],_0x23e544['affectedTree'],_0x38fbdd,_0x19a3d5,_0x405cf8);}else{if(_0x149615['type']===q['LISTEN_COMPLETE'])_0x58b6e7=Au(_0x2af483,_0xd5ec4c,_0x149615['path'],_0x38fbdd,_0x405cf8);else throw ot('Unknown\x20operation\x20type:\x20'+_0x149615['type']);}}}const _0xc3d8cc=_0x405cf8['getChanges']();return Su(_0xd5ec4c,_0x58b6e7,_0xc3d8cc),{'viewCache':_0x58b6e7,'changes':_0xc3d8cc};}function Su(_0x26d497,_0x8010d7,_0x3586b7){const _0x57edd5=_0x8010d7['eventCache'];if(_0x57edd5['isFullyInitialized']()){const _0x5683f6=_0x57edd5['getNode']()['isLeafNode']()||_0x57edd5['getNode']()['isEmpty'](),_0x511051=gn(_0x26d497);(_0x3586b7['length']>0x0||!_0x26d497['eventCache']['isFullyInitialized']()||_0x5683f6&&!_0x57edd5['getNode']()['equals'](_0x511051)||!_0x57edd5['getNode']()['getPriority']()['equals'](_0x511051['getPriority']()))&&_0x3586b7['push'](Oo(gn(_0x8010d7)));}}function Ho(_0x513ceb,_0xf5c323,_0x4b5404,_0x5e2825,_0x51f7e6,_0x512722){const _0x592db0=_0xf5c323['eventCache'];if(yn(_0x5e2825,_0x4b5404)!=null)return _0xf5c323;{let _0x13ccad,_0x36c761;if(v(_0x4b5404)){if(f(_0xf5c323['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xf5c323['serverCache']['isFiltered']()){const _0x558e10=Ue(_0xf5c323),_0x1c829e=_0x558e10 instanceof g?_0x558e10:g['EMPTY_NODE'],_0x697520=es(_0x5e2825,_0x1c829e);_0x13ccad=_0x513ceb['filter']['updateFullNode'](_0xf5c323['eventCache']['getNode'](),_0x697520,_0x512722);}else{const _0x22ebcb=mn(_0x5e2825,Ue(_0xf5c323));_0x13ccad=_0x513ceb['filter']['updateFullNode'](_0xf5c323['eventCache']['getNode'](),_0x22ebcb,_0x512722);}}else{const _0x2e2efc=y(_0x4b5404);if(_0x2e2efc==='.priority'){f(we(_0x4b5404)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2f217b=_0x592db0['getNode']();_0x36c761=_0xf5c323['serverCache']['getNode']();const _0x455e18=or(_0x5e2825,_0x4b5404,_0x2f217b,_0x36c761);_0x455e18!=null?_0x13ccad=_0x513ceb['filter']['updatePriority'](_0x2f217b,_0x455e18):_0x13ccad=_0x592db0['getNode']();}else{const _0xf35c7f=b(_0x4b5404);let _0x19a431;if(_0x592db0['isCompleteForChild'](_0x2e2efc)){_0x36c761=_0xf5c323['serverCache']['getNode']();const _0x105169=or(_0x5e2825,_0x4b5404,_0x592db0['getNode'](),_0x36c761);_0x105169!=null?_0x19a431=_0x592db0['getNode']()['getImmediateChild'](_0x2e2efc)['updateChild'](_0xf35c7f,_0x105169):_0x19a431=_0x592db0['getNode']()['getImmediateChild'](_0x2e2efc);}else _0x19a431=ts(_0x5e2825,_0x2e2efc,_0xf5c323['serverCache']);_0x19a431!=null?_0x13ccad=_0x513ceb['filter']['updateChild'](_0x592db0['getNode'](),_0x2e2efc,_0x19a431,_0xf35c7f,_0x51f7e6,_0x512722):_0x13ccad=_0x592db0['getNode']();}}return wt(_0xf5c323,_0x13ccad,_0x592db0['isFullyInitialized']()||v(_0x4b5404),_0x513ceb['filter']['filtersNodes']());}}function vn(_0x35d20e,_0x55be17,_0x54ef27,_0x489aea,_0x208996,_0x5350dc,_0x99aa7f,_0x7c19d0){const _0x39e8ac=_0x55be17['serverCache'];let _0x1e5b12;const _0x1cf317=_0x99aa7f?_0x35d20e['filter']:_0x35d20e['filter']['getIndexedFilter']();if(v(_0x54ef27))_0x1e5b12=_0x1cf317['updateFullNode'](_0x39e8ac['getNode'](),_0x489aea,null);else{if(_0x1cf317['filtersNodes']()&&!_0x39e8ac['isFiltered']()){const _0x4ae4cb=_0x39e8ac['getNode']()['updateChild'](_0x54ef27,_0x489aea);_0x1e5b12=_0x1cf317['updateFullNode'](_0x39e8ac['getNode'](),_0x4ae4cb,null);}else{const _0x48ac6e=y(_0x54ef27);if(!_0x39e8ac['isCompleteForPath'](_0x54ef27)&&we(_0x54ef27)>0x1)return _0x55be17;const _0x18cdac=b(_0x54ef27),_0x2b5903=_0x39e8ac['getNode']()['getImmediateChild'](_0x48ac6e)['updateChild'](_0x18cdac,_0x489aea);_0x48ac6e==='.priority'?_0x1e5b12=_0x1cf317['updatePriority'](_0x39e8ac['getNode'](),_0x2b5903):_0x1e5b12=_0x1cf317['updateChild'](_0x39e8ac['getNode'](),_0x48ac6e,_0x2b5903,_0x18cdac,Vo,null);}}const _0x316f87=Lo(_0x55be17,_0x1e5b12,_0x39e8ac['isFullyInitialized']()||v(_0x54ef27),_0x1cf317['filtersNodes']()),_0x228160=new ns(_0x208996,_0x316f87,_0x5350dc);return Ho(_0x35d20e,_0x316f87,_0x54ef27,_0x208996,_0x228160,_0x7c19d0);}function Ti(_0x189873,_0x2c45ed,_0x31c924,_0x3d164e,_0x196d90,_0x1f4514,_0xbd192f){const _0x3c1f6f=_0x2c45ed['eventCache'];let _0x207616,_0x10e5f5;const _0x2cab07=new ns(_0x196d90,_0x2c45ed,_0x1f4514);if(v(_0x31c924))_0x10e5f5=_0x189873['filter']['updateFullNode'](_0x2c45ed['eventCache']['getNode'](),_0x3d164e,_0xbd192f),_0x207616=wt(_0x2c45ed,_0x10e5f5,!0x0,_0x189873['filter']['filtersNodes']());else{const _0x1cc1fb=y(_0x31c924);if(_0x1cc1fb==='.priority')_0x10e5f5=_0x189873['filter']['updatePriority'](_0x2c45ed['eventCache']['getNode'](),_0x3d164e),_0x207616=wt(_0x2c45ed,_0x10e5f5,_0x3c1f6f['isFullyInitialized'](),_0x3c1f6f['isFiltered']());else{const _0x27b7de=b(_0x31c924),_0x4c3666=_0x3c1f6f['getNode']()['getImmediateChild'](_0x1cc1fb);let _0x2ce8a5;if(v(_0x27b7de))_0x2ce8a5=_0x3d164e;else{const _0x5b92d5=_0x2cab07['getCompleteChild'](_0x1cc1fb);_0x5b92d5!=null?Gi(_0x27b7de)==='.priority'&&_0x5b92d5['getChild'](To(_0x27b7de))['isEmpty']()?_0x2ce8a5=_0x5b92d5:_0x2ce8a5=_0x5b92d5['updateChild'](_0x27b7de,_0x3d164e):_0x2ce8a5=g['EMPTY_NODE'];}if(_0x4c3666['equals'](_0x2ce8a5))_0x207616=_0x2c45ed;else{const _0x2321e5=_0x189873['filter']['updateChild'](_0x3c1f6f['getNode'](),_0x1cc1fb,_0x2ce8a5,_0x27b7de,_0x2cab07,_0xbd192f);_0x207616=wt(_0x2c45ed,_0x2321e5,_0x3c1f6f['isFullyInitialized'](),_0x189873['filter']['filtersNodes']());}}}return _0x207616;}function ar(_0x3b6a89,_0x39d913){return _0x3b6a89['eventCache']['isCompleteForChild'](_0x39d913);}function bu(_0x37fcd5,_0x9c2d37,_0x35c798,_0x5b84eb,_0x5b5578,_0x189bd3,_0x242450){let _0x48a56c=_0x9c2d37;return _0x5b84eb['foreach']((_0x14ecf5,_0x162d95)=>{const _0xf2406c=A(_0x35c798,_0x14ecf5);ar(_0x9c2d37,y(_0xf2406c))&&(_0x48a56c=Ti(_0x37fcd5,_0x48a56c,_0xf2406c,_0x162d95,_0x5b5578,_0x189bd3,_0x242450));}),_0x5b84eb['foreach']((_0x55f032,_0x525088)=>{const _0x100e8a=A(_0x35c798,_0x55f032);ar(_0x9c2d37,y(_0x100e8a))||(_0x48a56c=Ti(_0x37fcd5,_0x48a56c,_0x100e8a,_0x525088,_0x5b5578,_0x189bd3,_0x242450));}),_0x48a56c;}function cr(_0x22a24e,_0x1b17cf,_0x329ebc){return _0x329ebc['foreach']((_0x1f2f42,_0x5be6a1)=>{_0x1b17cf=_0x1b17cf['updateChild'](_0x1f2f42,_0x5be6a1);}),_0x1b17cf;}function Si(_0x211154,_0x34de5a,_0x212286,_0x81d7c5,_0x1891e,_0x32ab34,_0x143c99,_0x313b20){if(_0x34de5a['serverCache']['getNode']()['isEmpty']()&&!_0x34de5a['serverCache']['isFullyInitialized']())return _0x34de5a;let _0x29b470=_0x34de5a,_0x2346ec;v(_0x212286)?_0x2346ec=_0x81d7c5:_0x2346ec=new S(null)['setTree'](_0x212286,_0x81d7c5);const _0x5ed4f7=_0x34de5a['serverCache']['getNode']();return _0x2346ec['children']['inorderTraversal']((_0x304390,_0x23e160)=>{if(_0x5ed4f7['hasChild'](_0x304390)){const _0x398471=_0x34de5a['serverCache']['getNode']()['getImmediateChild'](_0x304390),_0x228b18=cr(_0x211154,_0x398471,_0x23e160);_0x29b470=vn(_0x211154,_0x29b470,new C(_0x304390),_0x228b18,_0x1891e,_0x32ab34,_0x143c99,_0x313b20);}}),_0x2346ec['children']['inorderTraversal']((_0x4a9514,_0x5ebf27)=>{const _0x28e532=!_0x34de5a['serverCache']['isCompleteForChild'](_0x4a9514)&&_0x5ebf27['value']===null;if(!_0x5ed4f7['hasChild'](_0x4a9514)&&!_0x28e532){const _0x20f7f5=_0x34de5a['serverCache']['getNode']()['getImmediateChild'](_0x4a9514),_0x5a6051=cr(_0x211154,_0x20f7f5,_0x5ebf27);_0x29b470=vn(_0x211154,_0x29b470,new C(_0x4a9514),_0x5a6051,_0x1891e,_0x32ab34,_0x143c99,_0x313b20);}}),_0x29b470;}function Ru(_0x570cbd,_0x4eeda1,_0x33d312,_0x2264dd,_0x27d016,_0x201b18,_0x172bbb){if(yn(_0x27d016,_0x33d312)!=null)return _0x4eeda1;const _0x2dba18=_0x4eeda1['serverCache']['isFiltered'](),_0x1dbc34=_0x4eeda1['serverCache'];if(_0x2264dd['value']!=null){if(v(_0x33d312)&&_0x1dbc34['isFullyInitialized']()||_0x1dbc34['isCompleteForPath'](_0x33d312))return vn(_0x570cbd,_0x4eeda1,_0x33d312,_0x1dbc34['getNode']()['getChild'](_0x33d312),_0x27d016,_0x201b18,_0x2dba18,_0x172bbb);if(v(_0x33d312)){let _0x54cf60=new S(null);return _0x1dbc34['getNode']()['forEachChild'](ye,(_0x426f90,_0x4636ec)=>{_0x54cf60=_0x54cf60['set'](new C(_0x426f90),_0x4636ec);}),Si(_0x570cbd,_0x4eeda1,_0x33d312,_0x54cf60,_0x27d016,_0x201b18,_0x2dba18,_0x172bbb);}else return _0x4eeda1;}else{let _0x307fca=new S(null);return _0x2264dd['foreach']((_0x2d1bb3,_0x3268a1)=>{const _0x1f3d38=A(_0x33d312,_0x2d1bb3);_0x1dbc34['isCompleteForPath'](_0x1f3d38)&&(_0x307fca=_0x307fca['set'](_0x2d1bb3,_0x1dbc34['getNode']()['getChild'](_0x1f3d38)));}),Si(_0x570cbd,_0x4eeda1,_0x33d312,_0x307fca,_0x27d016,_0x201b18,_0x2dba18,_0x172bbb);}}function Au(_0x476763,_0x5884e6,_0x540eb9,_0x3e39bb,_0x5ed3ce){const _0x3fccc5=_0x5884e6['serverCache'],_0x545b6f=Lo(_0x5884e6,_0x3fccc5['getNode'](),_0x3fccc5['isFullyInitialized']()||v(_0x540eb9),_0x3fccc5['isFiltered']());return Ho(_0x476763,_0x545b6f,_0x540eb9,_0x3e39bb,Vo,_0x5ed3ce);}function ku(_0x3cc98d,_0x44299f,_0x5823b2,_0x2355e0,_0x5757c0,_0x419852){let _0x5cd759;if(yn(_0x2355e0,_0x5823b2)!=null)return _0x44299f;{const _0x492b3f=new ns(_0x2355e0,_0x44299f,_0x5757c0),_0x3ae1a7=_0x44299f['eventCache']['getNode']();let _0x2f7dd5;if(v(_0x5823b2)||y(_0x5823b2)==='.priority'){let _0x3ebf24;if(_0x44299f['serverCache']['isFullyInitialized']())_0x3ebf24=mn(_0x2355e0,Ue(_0x44299f));else{const _0x23ae7b=_0x44299f['serverCache']['getNode']();f(_0x23ae7b instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3ebf24=es(_0x2355e0,_0x23ae7b);}_0x3ebf24=_0x3ebf24,_0x2f7dd5=_0x3cc98d['filter']['updateFullNode'](_0x3ae1a7,_0x3ebf24,_0x419852);}else{const _0xa7849=y(_0x5823b2);let _0x503d1c=ts(_0x2355e0,_0xa7849,_0x44299f['serverCache']);_0x503d1c==null&&_0x44299f['serverCache']['isCompleteForChild'](_0xa7849)&&(_0x503d1c=_0x3ae1a7['getImmediateChild'](_0xa7849)),_0x503d1c!=null?_0x2f7dd5=_0x3cc98d['filter']['updateChild'](_0x3ae1a7,_0xa7849,_0x503d1c,b(_0x5823b2),_0x492b3f,_0x419852):_0x44299f['eventCache']['getNode']()['hasChild'](_0xa7849)?_0x2f7dd5=_0x3cc98d['filter']['updateChild'](_0x3ae1a7,_0xa7849,g['EMPTY_NODE'],b(_0x5823b2),_0x492b3f,_0x419852):_0x2f7dd5=_0x3ae1a7,_0x2f7dd5['isEmpty']()&&_0x44299f['serverCache']['isFullyInitialized']()&&(_0x5cd759=mn(_0x2355e0,Ue(_0x44299f)),_0x5cd759['isLeafNode']()&&(_0x2f7dd5=_0x3cc98d['filter']['updateFullNode'](_0x2f7dd5,_0x5cd759,_0x419852)));}return _0x5cd759=_0x44299f['serverCache']['isFullyInitialized']()||yn(_0x2355e0,w())!=null,wt(_0x44299f,_0x2f7dd5,_0x5cd759,_0x3cc98d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0xb8a564,_0x123005){this['query_']=_0xb8a564,this['eventRegistrations_']=[];const _0x2a7eb4=this['query_']['_queryParams'],_0x42f1eb=new Yi(_0x2a7eb4['getIndex']()),_0x35dd32=qh(_0x2a7eb4);this['processor_']=wu(_0x35dd32);const _0x172b29=_0x123005['serverCache'],_0x36e2a2=_0x123005['eventCache'],_0x729941=_0x42f1eb['updateFullNode'](g['EMPTY_NODE'],_0x172b29['getNode'](),null),_0x3bcf51=_0x35dd32['updateFullNode'](g['EMPTY_NODE'],_0x36e2a2['getNode'](),null),_0x5e113d=new Ce(_0x729941,_0x172b29['isFullyInitialized'](),_0x42f1eb['filtersNodes']()),_0x188699=new Ce(_0x3bcf51,_0x36e2a2['isFullyInitialized'](),_0x35dd32['filtersNodes']());this['viewCache_']=Dn(_0x188699,_0x5e113d),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x1df209){return _0x1df209['viewCache_']['serverCache']['getNode']();}function Ou(_0x17a388){return gn(_0x17a388['viewCache_']);}function Du(_0xff9478,_0xe684b2){const _0x4bbf81=Ue(_0xff9478['viewCache_']);return _0x4bbf81&&(_0xff9478['query']['_queryParams']['loadsAllData']()||!v(_0xe684b2)&&!_0x4bbf81['getImmediateChild'](y(_0xe684b2))['isEmpty']())?_0x4bbf81['getChild'](_0xe684b2):null;}function lr(_0x4bf7ab){return _0x4bf7ab['eventRegistrations_']['length']===0x0;}function Mu(_0x1a66b0,_0x8bcf2f){_0x1a66b0['eventRegistrations_']['push'](_0x8bcf2f);}function hr(_0x3f49a6,_0x2c362d,_0x1957ac){const _0x4f3e97=[];if(_0x1957ac){f(_0x2c362d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3bdeea=_0x3f49a6['query']['_path'];_0x3f49a6['eventRegistrations_']['forEach'](_0x2ac9f1=>{const _0x480513=_0x2ac9f1['createCancelEvent'](_0x1957ac,_0x3bdeea);_0x480513&&_0x4f3e97['push'](_0x480513);});}if(_0x2c362d){let _0x554301=[];for(let _0x11fde0=0x0;_0x11fde0<_0x3f49a6['eventRegistrations_']['length'];++_0x11fde0){const _0x150600=_0x3f49a6['eventRegistrations_'][_0x11fde0];if(!_0x150600['matches'](_0x2c362d))_0x554301['push'](_0x150600);else{if(_0x2c362d['hasAnyCallback']()){_0x554301=_0x554301['concat'](_0x3f49a6['eventRegistrations_']['slice'](_0x11fde0+0x1));break;}}}_0x3f49a6['eventRegistrations_']=_0x554301;}else _0x3f49a6['eventRegistrations_']=[];return _0x4f3e97;}function ur(_0x5484cf,_0xee87f8,_0x245747,_0x1e28f8){_0xee87f8['type']===q['MERGE']&&_0xee87f8['source']['queryId']!==null&&(f(Ue(_0x5484cf['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x5484cf['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3dc96f=_0x5484cf['viewCache_'],_0x360281=Tu(_0x5484cf['processor_'],_0x3dc96f,_0xee87f8,_0x245747,_0x1e28f8);return Cu(_0x5484cf['processor_'],_0x360281['viewCache']),f(_0x360281['viewCache']['serverCache']['isFullyInitialized']()||!_0x3dc96f['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5484cf['viewCache_']=_0x360281['viewCache'],$o(_0x5484cf,_0x360281['changes'],_0x360281['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x43fdcf,_0x35f9c9){const _0x2ba8c1=_0x43fdcf['viewCache_']['eventCache'],_0x72d292=[];return _0x2ba8c1['getNode']()['isLeafNode']()||_0x2ba8c1['getNode']()['forEachChild'](R,(_0x5b4246,_0x319039)=>{_0x72d292['push'](tt(_0x5b4246,_0x319039));}),_0x2ba8c1['isFullyInitialized']()&&_0x72d292['push'](Oo(_0x2ba8c1['getNode']())),$o(_0x43fdcf,_0x72d292,_0x2ba8c1['getNode'](),_0x35f9c9);}function $o(_0x5bed32,_0x2f7634,_0x3a3b99,_0x5c0f83){const _0x2ac2a0=_0x5c0f83?[_0x5c0f83]:_0x5bed32['eventRegistrations_'];return nu(_0x5bed32['eventGenerator_'],_0x2f7634,_0x3a3b99,_0x2ac2a0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x1d6a30){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x1d6a30;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x589a53){return _0x589a53['views']['size']===0x0;}function is(_0x4d9e13,_0x3beb5b,_0x21ae54,_0x33b483){const _0x20d57f=_0x3beb5b['source']['queryId'];if(_0x20d57f!==null){const _0x1db476=_0x4d9e13['views']['get'](_0x20d57f);return f(_0x1db476!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x1db476,_0x3beb5b,_0x21ae54,_0x33b483);}else{let _0x4d9d07=[];for(const _0x1fd6ec of _0x4d9e13['views']['values']())_0x4d9d07=_0x4d9d07['concat'](ur(_0x1fd6ec,_0x3beb5b,_0x21ae54,_0x33b483));return _0x4d9d07;}}function qo(_0x39c521,_0x2be2f6,_0x447b19,_0xa89392,_0x50faf0){const _0x419c9c=_0x2be2f6['_queryIdentifier'],_0x2a7852=_0x39c521['views']['get'](_0x419c9c);if(!_0x2a7852){let _0x398f47=mn(_0x447b19,_0x50faf0?_0xa89392:null),_0x216689=!0x1;_0x398f47?_0x216689=!0x0:_0xa89392 instanceof g?(_0x398f47=es(_0x447b19,_0xa89392),_0x216689=!0x1):(_0x398f47=g['EMPTY_NODE'],_0x216689=!0x1);const _0x277e1d=Dn(new Ce(_0x398f47,_0x216689,!0x1),new Ce(_0xa89392,_0x50faf0,!0x1));return new Nu(_0x2be2f6,_0x277e1d);}return _0x2a7852;}function Wu(_0x20f03d,_0xab6394,_0x59e226,_0x358e4a,_0x2a2991,_0x2940c2){const _0x123987=qo(_0x20f03d,_0xab6394,_0x358e4a,_0x2a2991,_0x2940c2);return _0x20f03d['views']['has'](_0xab6394['_queryIdentifier'])||_0x20f03d['views']['set'](_0xab6394['_queryIdentifier'],_0x123987),Mu(_0x123987,_0x59e226),Lu(_0x123987,_0x59e226);}function Bu(_0x3338e2,_0x3157ba,_0x2cee13,_0x41d139){const _0x3bbec3=_0x3157ba['_queryIdentifier'],_0x5dca33=[];let _0x1f2d22=[];const _0x3d9480=Te(_0x3338e2);if(_0x3bbec3==='default'){for(const [_0x2ce1b3,_0x310c4d]of _0x3338e2['views']['entries']())_0x1f2d22=_0x1f2d22['concat'](hr(_0x310c4d,_0x2cee13,_0x41d139)),lr(_0x310c4d)&&(_0x3338e2['views']['delete'](_0x2ce1b3),_0x310c4d['query']['_queryParams']['loadsAllData']()||_0x5dca33['push'](_0x310c4d['query']));}else{const _0x5dffce=_0x3338e2['views']['get'](_0x3bbec3);_0x5dffce&&(_0x1f2d22=_0x1f2d22['concat'](hr(_0x5dffce,_0x2cee13,_0x41d139)),lr(_0x5dffce)&&(_0x3338e2['views']['delete'](_0x3bbec3),_0x5dffce['query']['_queryParams']['loadsAllData']()||_0x5dca33['push'](_0x5dffce['query'])));}return _0x3d9480&&!Te(_0x3338e2)&&_0x5dca33['push'](new(Fu())(_0x3157ba['_repo'],_0x3157ba['_path'])),{'removed':_0x5dca33,'events':_0x1f2d22};}function zo(_0x3611bc){const _0x8dc841=[];for(const _0x3b2eaa of _0x3611bc['views']['values']())_0x3b2eaa['query']['_queryParams']['loadsAllData']()||_0x8dc841['push'](_0x3b2eaa);return _0x8dc841;}function Ee(_0x163bd6,_0x3c7ac1){let _0x1c8042=null;for(const _0x1c053d of _0x163bd6['views']['values']())_0x1c8042=_0x1c8042||Du(_0x1c053d,_0x3c7ac1);return _0x1c8042;}function jo(_0x2cb189,_0x13aed7){if(_0x13aed7['_queryParams']['loadsAllData']())return Ln(_0x2cb189);{const _0x37e575=_0x13aed7['_queryIdentifier'];return _0x2cb189['views']['get'](_0x37e575);}}function Ko(_0x36de8d,_0x5d7c8d){return jo(_0x36de8d,_0x5d7c8d)!=null;}function Te(_0x3a92b4){return Ln(_0x3a92b4)!=null;}function Ln(_0x2dde7a){for(const _0xeaa845 of _0x2dde7a['views']['values']())if(_0xeaa845['query']['_queryParams']['loadsAllData']())return _0xeaa845;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1f3365){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1f3365;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x31372a){this['listenProvider_']=_0x31372a,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x292305,_0x555372,_0x9ac38e,_0x353751,_0x3bb9a5){return ou(_0x292305['pendingWriteTree_'],_0x555372,_0x9ac38e,_0x353751,_0x3bb9a5),_0x3bb9a5?ht(_0x292305,new Fe(Ji(),_0x555372,_0x9ac38e)):[];}function Gu(_0x2260a7,_0x3758d5,_0xf650e,_0x5dfd70){au(_0x2260a7['pendingWriteTree_'],_0x3758d5,_0xf650e,_0x5dfd70);const _0x49e417=S['fromObject'](_0xf650e);return ht(_0x2260a7,new nt(Ji(),_0x3758d5,_0x49e417));}function pe(_0x2a95b0,_0xde94b0,_0x5be1f6=!0x1){const _0x18d1ce=cu(_0x2a95b0['pendingWriteTree_'],_0xde94b0);if(lu(_0x2a95b0['pendingWriteTree_'],_0xde94b0)){let _0x916bdb=new S(null);return _0x18d1ce['snap']!=null?_0x916bdb=_0x916bdb['set'](w(),!0x0):x(_0x18d1ce['children'],_0x5ce698=>{_0x916bdb=_0x916bdb['set'](new C(_0x5ce698),!0x0);}),ht(_0x2a95b0,new _n(_0x18d1ce['path'],_0x916bdb,_0x5be1f6));}else return[];}function $t(_0x2bb9e8,_0x2ca423,_0x5146b7){return ht(_0x2bb9e8,new Fe(Xi(),_0x2ca423,_0x5146b7));}function qu(_0x1572b2,_0x5e7789,_0x2a9e5e){const _0x212b8a=S['fromObject'](_0x2a9e5e);return ht(_0x1572b2,new nt(Xi(),_0x5e7789,_0x212b8a));}function zu(_0x5b122e,_0x3cd5b8){return ht(_0x5b122e,new Dt(Xi(),_0x3cd5b8));}function ju(_0x15c1d7,_0x12f3cf,_0x2f0101){const _0x307036=rs(_0x15c1d7,_0x2f0101);if(_0x307036){const _0xfedd43=os(_0x307036),_0x32a4da=_0xfedd43['path'],_0x2e7363=_0xfedd43['queryId'],_0x30cc98=F(_0x32a4da,_0x12f3cf),_0x7f069f=new Dt(Zi(_0x2e7363),_0x30cc98);return as(_0x15c1d7,_0x32a4da,_0x7f069f);}else return[];}function wn(_0x3e3942,_0x3c232a,_0x5a218f,_0x1aeb83,_0x4c99a8=!0x1){const _0xacc96e=_0x3c232a['_path'],_0x465e74=_0x3e3942['syncPointTree_']['get'](_0xacc96e);let _0x8e29e0=[];if(_0x465e74&&(_0x3c232a['_queryIdentifier']==='default'||Ko(_0x465e74,_0x3c232a))){const _0x39043c=Bu(_0x465e74,_0x3c232a,_0x5a218f,_0x1aeb83);Uu(_0x465e74)&&(_0x3e3942['syncPointTree_']=_0x3e3942['syncPointTree_']['remove'](_0xacc96e));const _0x659b95=_0x39043c['removed'];if(_0x8e29e0=_0x39043c['events'],!_0x4c99a8){const _0x1a93c4=_0x659b95['findIndex'](_0x549e80=>_0x549e80['_queryParams']['loadsAllData']())!==-0x1,_0x3db439=_0x3e3942['syncPointTree_']['findOnPath'](_0xacc96e,(_0x371866,_0x51cbc8)=>Te(_0x51cbc8));if(_0x1a93c4&&!_0x3db439){const _0x296b90=_0x3e3942['syncPointTree_']['subtree'](_0xacc96e);if(!_0x296b90['isEmpty']()){const _0x35e3e3=Qu(_0x296b90);for(let _0x18f345=0x0;_0x18f345<_0x35e3e3['length'];++_0x18f345){const _0x490000=_0x35e3e3[_0x18f345],_0xdda54=_0x490000['query'],_0x4d628e=Xo(_0x3e3942,_0x490000);_0x3e3942['listenProvider_']['startListening'](Tt(_0xdda54),Mt(_0x3e3942,_0xdda54),_0x4d628e['hashFn'],_0x4d628e['onComplete']);}}}!_0x3db439&&_0x659b95['length']>0x0&&!_0x1aeb83&&(_0x1a93c4?_0x3e3942['listenProvider_']['stopListening'](Tt(_0x3c232a),null):_0x659b95['forEach'](_0x3e8b74=>{const _0x592e24=_0x3e3942['queryToTagMap']['get'](Fn(_0x3e8b74));_0x3e3942['listenProvider_']['stopListening'](Tt(_0x3e8b74),_0x592e24);}));}Ju(_0x3e3942,_0x659b95);}return _0x8e29e0;}function Yo(_0x1d8d1,_0x35cca3,_0x2573b0,_0x1bcf35){const _0x12d9b0=rs(_0x1d8d1,_0x1bcf35);if(_0x12d9b0!=null){const _0x10c4f2=os(_0x12d9b0),_0x59ab6d=_0x10c4f2['path'],_0x58df3c=_0x10c4f2['queryId'],_0x3e2958=F(_0x59ab6d,_0x35cca3),_0x2d540a=new Fe(Zi(_0x58df3c),_0x3e2958,_0x2573b0);return as(_0x1d8d1,_0x59ab6d,_0x2d540a);}else return[];}function Ku(_0x6bdf9b,_0x422c25,_0x4a01e9,_0x39fd2b){const _0x48e2e9=rs(_0x6bdf9b,_0x39fd2b);if(_0x48e2e9){const _0x424008=os(_0x48e2e9),_0x2700d2=_0x424008['path'],_0x28c1f3=_0x424008['queryId'],_0x166249=F(_0x2700d2,_0x422c25),_0x21806b=S['fromObject'](_0x4a01e9),_0x826c9a=new nt(Zi(_0x28c1f3),_0x166249,_0x21806b);return as(_0x6bdf9b,_0x2700d2,_0x826c9a);}else return[];}function bi(_0x19ede8,_0x43394c,_0x204fb5,_0xc73f50=!0x1){const _0x1ab4ff=_0x43394c['_path'];let _0x4df935=null,_0x5ddfe6=!0x1;_0x19ede8['syncPointTree_']['foreachOnPath'](_0x1ab4ff,(_0x565439,_0x233904)=>{const _0x4bec27=F(_0x565439,_0x1ab4ff);_0x4df935=_0x4df935||Ee(_0x233904,_0x4bec27),_0x5ddfe6=_0x5ddfe6||Te(_0x233904);});let _0x55c39d=_0x19ede8['syncPointTree_']['get'](_0x1ab4ff);_0x55c39d?(_0x5ddfe6=_0x5ddfe6||Te(_0x55c39d),_0x4df935=_0x4df935||Ee(_0x55c39d,w())):(_0x55c39d=new Go(),_0x19ede8['syncPointTree_']=_0x19ede8['syncPointTree_']['set'](_0x1ab4ff,_0x55c39d));let _0x36ead2;_0x4df935!=null?_0x36ead2=!0x0:(_0x36ead2=!0x1,_0x4df935=g['EMPTY_NODE'],_0x19ede8['syncPointTree_']['subtree'](_0x1ab4ff)['foreachChild']((_0x2e2471,_0x1bd920)=>{const _0x3e9900=Ee(_0x1bd920,w());_0x3e9900&&(_0x4df935=_0x4df935['updateImmediateChild'](_0x2e2471,_0x3e9900));}));const _0x2189ec=Ko(_0x55c39d,_0x43394c);if(!_0x2189ec&&!_0x43394c['_queryParams']['loadsAllData']()){const _0x472290=Fn(_0x43394c);f(!_0x19ede8['queryToTagMap']['has'](_0x472290),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3fb4a4=Xu();_0x19ede8['queryToTagMap']['set'](_0x472290,_0x3fb4a4),_0x19ede8['tagToQueryMap']['set'](_0x3fb4a4,_0x472290);}const _0x2dc541=Mn(_0x19ede8['pendingWriteTree_'],_0x1ab4ff);let _0x463e1a=Wu(_0x55c39d,_0x43394c,_0x204fb5,_0x2dc541,_0x4df935,_0x36ead2);if(!_0x2189ec&&!_0x5ddfe6&&!_0xc73f50){const _0x1bfefd=jo(_0x55c39d,_0x43394c);_0x463e1a=_0x463e1a['concat'](Zu(_0x19ede8,_0x43394c,_0x1bfefd));}return _0x463e1a;}function xn(_0x382660,_0x2f2804,_0x46dc5e){const _0x397b84=_0x382660['pendingWriteTree_'],_0x1a4d46=_0x382660['syncPointTree_']['findOnPath'](_0x2f2804,(_0x4f99f2,_0x1f2be1)=>{const _0x1367b3=F(_0x4f99f2,_0x2f2804),_0x5641f0=Ee(_0x1f2be1,_0x1367b3);if(_0x5641f0)return _0x5641f0;});return Uo(_0x397b84,_0x2f2804,_0x1a4d46,_0x46dc5e,!0x0);}function Yu(_0xed7fb5,_0x4992a3){const _0x1a6c6f=_0x4992a3['_path'];let _0x234856=null;_0xed7fb5['syncPointTree_']['foreachOnPath'](_0x1a6c6f,(_0x17d177,_0x2220ce)=>{const _0x395803=F(_0x17d177,_0x1a6c6f);_0x234856=_0x234856||Ee(_0x2220ce,_0x395803);});let _0x4bb98e=_0xed7fb5['syncPointTree_']['get'](_0x1a6c6f);_0x4bb98e?_0x234856=_0x234856||Ee(_0x4bb98e,w()):(_0x4bb98e=new Go(),_0xed7fb5['syncPointTree_']=_0xed7fb5['syncPointTree_']['set'](_0x1a6c6f,_0x4bb98e));const _0x588d67=_0x234856!=null,_0x2af21b=_0x588d67?new Ce(_0x234856,!0x0,!0x1):null,_0x12176d=Mn(_0xed7fb5['pendingWriteTree_'],_0x4992a3['_path']),_0x452a51=qo(_0x4bb98e,_0x4992a3,_0x12176d,_0x588d67?_0x2af21b['getNode']():g['EMPTY_NODE'],_0x588d67);return Ou(_0x452a51);}function ht(_0x140271,_0x1ece95){return Qo(_0x1ece95,_0x140271['syncPointTree_'],null,Mn(_0x140271['pendingWriteTree_'],w()));}function Qo(_0x40f37a,_0x20acdc,_0x3821b1,_0x4e30bb){if(v(_0x40f37a['path']))return Jo(_0x40f37a,_0x20acdc,_0x3821b1,_0x4e30bb);{const _0x2bec23=_0x20acdc['get'](w());_0x3821b1==null&&_0x2bec23!=null&&(_0x3821b1=Ee(_0x2bec23,w()));let _0x158ed4=[];const _0x520301=y(_0x40f37a['path']),_0x379a3e=_0x40f37a['operationForChild'](_0x520301),_0x42f1ce=_0x20acdc['children']['get'](_0x520301);if(_0x42f1ce&&_0x379a3e){const _0xbf48c5=_0x3821b1?_0x3821b1['getImmediateChild'](_0x520301):null,_0x2bd450=Wo(_0x4e30bb,_0x520301);_0x158ed4=_0x158ed4['concat'](Qo(_0x379a3e,_0x42f1ce,_0xbf48c5,_0x2bd450));}return _0x2bec23&&(_0x158ed4=_0x158ed4['concat'](is(_0x2bec23,_0x40f37a,_0x4e30bb,_0x3821b1))),_0x158ed4;}}function Jo(_0x27ecdb,_0x449471,_0x4ef1b3,_0x231e86){const _0x229057=_0x449471['get'](w());_0x4ef1b3==null&&_0x229057!=null&&(_0x4ef1b3=Ee(_0x229057,w()));let _0x3f3893=[];return _0x449471['children']['inorderTraversal']((_0x366141,_0x87ed80)=>{const _0x4cf20d=_0x4ef1b3?_0x4ef1b3['getImmediateChild'](_0x366141):null,_0x1b1c6a=Wo(_0x231e86,_0x366141),_0x4c7203=_0x27ecdb['operationForChild'](_0x366141);_0x4c7203&&(_0x3f3893=_0x3f3893['concat'](Jo(_0x4c7203,_0x87ed80,_0x4cf20d,_0x1b1c6a)));}),_0x229057&&(_0x3f3893=_0x3f3893['concat'](is(_0x229057,_0x27ecdb,_0x231e86,_0x4ef1b3))),_0x3f3893;}function Xo(_0x4a9404,_0x5c2786){const _0x3069c7=_0x5c2786['query'],_0x13f174=Mt(_0x4a9404,_0x3069c7);return{'hashFn':()=>(Pu(_0x5c2786)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x47efa3=>{if(_0x47efa3==='ok')return _0x13f174?ju(_0x4a9404,_0x3069c7['_path'],_0x13f174):zu(_0x4a9404,_0x3069c7['_path']);{const _0x5c52ae=ql(_0x47efa3,_0x3069c7);return wn(_0x4a9404,_0x3069c7,null,_0x5c52ae);}}};}function Mt(_0x1c6c6d,_0x5e7ad2){const _0x54ecb1=Fn(_0x5e7ad2);return _0x1c6c6d['queryToTagMap']['get'](_0x54ecb1);}function Fn(_0x24c5b4){return _0x24c5b4['_path']['toString']()+'$'+_0x24c5b4['_queryIdentifier'];}function rs(_0x3a7894,_0x4e954c){return _0x3a7894['tagToQueryMap']['get'](_0x4e954c);}function os(_0xf0f871){const _0x2576b4=_0xf0f871['indexOf']('$');return f(_0x2576b4!==-0x1&&_0x2576b4<_0xf0f871['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xf0f871['substr'](_0x2576b4+0x1),'path':new C(_0xf0f871['substr'](0x0,_0x2576b4))};}function as(_0x153787,_0x335140,_0x46bbde){const _0x361e3b=_0x153787['syncPointTree_']['get'](_0x335140);f(_0x361e3b,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3890c4=Mn(_0x153787['pendingWriteTree_'],_0x335140);return is(_0x361e3b,_0x46bbde,_0x3890c4,null);}function Qu(_0x3b24a8){return _0x3b24a8['fold']((_0x5f4dba,_0x2fd44f,_0x2f7191)=>{if(_0x2fd44f&&Te(_0x2fd44f))return[Ln(_0x2fd44f)];{let _0x3a90e2=[];return _0x2fd44f&&(_0x3a90e2=zo(_0x2fd44f)),x(_0x2f7191,(_0x353a78,_0x1b1c1e)=>{_0x3a90e2=_0x3a90e2['concat'](_0x1b1c1e);}),_0x3a90e2;}});}function Tt(_0x543079){return _0x543079['_queryParams']['loadsAllData']()&&!_0x543079['_queryParams']['isDefault']()?new(Hu())(_0x543079['_repo'],_0x543079['_path']):_0x543079;}function Ju(_0x11c9c6,_0x1e107b){for(let _0x5f5150=0x0;_0x5f5150<_0x1e107b['length'];++_0x5f5150){const _0x351de6=_0x1e107b[_0x5f5150];if(!_0x351de6['_queryParams']['loadsAllData']()){const _0x374fa3=Fn(_0x351de6),_0x116926=_0x11c9c6['queryToTagMap']['get'](_0x374fa3);_0x11c9c6['queryToTagMap']['delete'](_0x374fa3),_0x11c9c6['tagToQueryMap']['delete'](_0x116926);}}}function Xu(){return $u++;}function Zu(_0x1c7256,_0x21742c,_0x58aae6){const _0x3d32bf=_0x21742c['_path'],_0x429819=Mt(_0x1c7256,_0x21742c),_0x480c10=Xo(_0x1c7256,_0x58aae6),_0x6c0467=_0x1c7256['listenProvider_']['startListening'](Tt(_0x21742c),_0x429819,_0x480c10['hashFn'],_0x480c10['onComplete']),_0x1ec24f=_0x1c7256['syncPointTree_']['subtree'](_0x3d32bf);if(_0x429819)f(!Te(_0x1ec24f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x10eb25=_0x1ec24f['fold']((_0x294f03,_0x34b528,_0x211cee)=>{if(!v(_0x294f03)&&_0x34b528&&Te(_0x34b528))return[Ln(_0x34b528)['query']];{let _0x5c4909=[];return _0x34b528&&(_0x5c4909=_0x5c4909['concat'](zo(_0x34b528)['map'](_0x49e8c2=>_0x49e8c2['query']))),x(_0x211cee,(_0x25c209,_0x2c72af)=>{_0x5c4909=_0x5c4909['concat'](_0x2c72af);}),_0x5c4909;}});for(let _0xa20ae4=0x0;_0xa20ae4<_0x10eb25['length'];++_0xa20ae4){const _0x481732=_0x10eb25[_0xa20ae4];_0x1c7256['listenProvider_']['stopListening'](Tt(_0x481732),Mt(_0x1c7256,_0x481732));}}return _0x6c0467;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x6ecfef){this['node_']=_0x6ecfef;}['getImmediateChild'](_0x10c9ac){const _0x30db6e=this['node_']['getImmediateChild'](_0x10c9ac);return new cs(_0x30db6e);}['node'](){return this['node_'];}}class ls{constructor(_0x107aa2,_0x84efc3){this['syncTree_']=_0x107aa2,this['path_']=_0x84efc3;}['getImmediateChild'](_0x396b48){const _0x385343=A(this['path_'],_0x396b48);return new ls(this['syncTree_'],_0x385343);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x1f54af){return _0x1f54af=_0x1f54af||{},_0x1f54af['timestamp']=_0x1f54af['timestamp']||new Date()['getTime'](),_0x1f54af;},fr=function(_0x27d422,_0x1c9a1c,_0x40d569){if(!_0x27d422||typeof _0x27d422!='object')return _0x27d422;if(f('.sv'in _0x27d422,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x27d422['.sv']=='string')return td(_0x27d422['.sv'],_0x1c9a1c,_0x40d569);if(typeof _0x27d422['.sv']=='object')return nd(_0x27d422['.sv'],_0x1c9a1c);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x27d422,null,0x2));},td=function(_0xbc56bf,_0x9c72c5,_0x1e786a){switch(_0xbc56bf){case'timestamp':return _0x1e786a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xbc56bf);}},nd=function(_0x554f90,_0x4cc828,_0x5123fb){_0x554f90['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x554f90,null,0x2));const _0x4723d8=_0x554f90['increment'];typeof _0x4723d8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4723d8);const _0x196da8=_0x4cc828['node']();if(f(_0x196da8!==null&&typeof _0x196da8<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x196da8['isLeafNode']())return _0x4723d8;const _0x40244c=_0x196da8['getValue']();return typeof _0x40244c!='number'?_0x4723d8:_0x40244c+_0x4723d8;},Zo=function(_0xe46d88,_0xc48e26,_0x2f802c,_0x21e522){return us(_0xc48e26,new ls(_0x2f802c,_0xe46d88),_0x21e522);},hs=function(_0x4b5c53,_0x41da68,_0x5100ed){return us(_0x4b5c53,new cs(_0x41da68),_0x5100ed);};function us(_0x22739c,_0x1a844d,_0x528fe9){const _0x2e4465=_0x22739c['getPriority']()['val'](),_0x16dc99=fr(_0x2e4465,_0x1a844d['getImmediateChild']('.priority'),_0x528fe9);let _0x1dee95;if(_0x22739c['isLeafNode']()){const _0x183e5f=_0x22739c,_0x4d22e2=fr(_0x183e5f['getValue'](),_0x1a844d,_0x528fe9);return _0x4d22e2!==_0x183e5f['getValue']()||_0x16dc99!==_0x183e5f['getPriority']()['val']()?new D(_0x4d22e2,N(_0x16dc99)):_0x22739c;}else{const _0x5a0e6a=_0x22739c;return _0x1dee95=_0x5a0e6a,_0x16dc99!==_0x5a0e6a['getPriority']()['val']()&&(_0x1dee95=_0x1dee95['updatePriority'](new D(_0x16dc99))),_0x5a0e6a['forEachChild'](R,(_0x127d68,_0x15a8ae)=>{const _0x4dd4d5=us(_0x15a8ae,_0x1a844d['getImmediateChild'](_0x127d68),_0x528fe9);_0x4dd4d5!==_0x15a8ae&&(_0x1dee95=_0x1dee95['updateImmediateChild'](_0x127d68,_0x4dd4d5));}),_0x1dee95;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x400c1a='',_0x3e9806=null,_0x171b19={'children':{},'childCount':0x0}){this['name']=_0x400c1a,this['parent']=_0x3e9806,this['node']=_0x171b19;}}function Un(_0x43a0b2,_0xdd3f5f){let _0xe0eac0=_0xdd3f5f instanceof C?_0xdd3f5f:new C(_0xdd3f5f),_0x426452=_0x43a0b2,_0x107667=y(_0xe0eac0);for(;_0x107667!==null;){const _0x26f6ee=Oe(_0x426452['node']['children'],_0x107667)||{'children':{},'childCount':0x0};_0x426452=new ds(_0x107667,_0x426452,_0x26f6ee),_0xe0eac0=b(_0xe0eac0),_0x107667=y(_0xe0eac0);}return _0x426452;}function Ge(_0x3519cf){return _0x3519cf['node']['value'];}function fs(_0x393e61,_0x194a2e){_0x393e61['node']['value']=_0x194a2e,Ri(_0x393e61);}function ea(_0x1b2013){return _0x1b2013['node']['childCount']>0x0;}function id(_0x4c2764){return Ge(_0x4c2764)===void 0x0&&!ea(_0x4c2764);}function Wn(_0x471cb5,_0x4274db){x(_0x471cb5['node']['children'],(_0x388c2e,_0x2fd94e)=>{_0x4274db(new ds(_0x388c2e,_0x471cb5,_0x2fd94e));});}function ta(_0x44c03a,_0xdaffe3,_0x34e00c,_0x550df6){_0x34e00c&&_0xdaffe3(_0x44c03a),Wn(_0x44c03a,_0x5f0936=>{ta(_0x5f0936,_0xdaffe3,!0x0);});}function sd(_0x222b4e,_0x38d6ce,_0x40345f){let _0x4e3ef8=_0x222b4e['parent'];for(;_0x4e3ef8!==null;){if(_0x38d6ce(_0x4e3ef8))return!0x0;_0x4e3ef8=_0x4e3ef8['parent'];}return!0x1;}function Gt(_0x461e99){return new C(_0x461e99['parent']===null?_0x461e99['name']:Gt(_0x461e99['parent'])+'/'+_0x461e99['name']);}function Ri(_0x530c50){_0x530c50['parent']!==null&&rd(_0x530c50['parent'],_0x530c50['name'],_0x530c50);}function rd(_0x3eb287,_0x81928b,_0xe4726){const _0x4aaef4=id(_0xe4726),_0x56a406=Y(_0x3eb287['node']['children'],_0x81928b);_0x4aaef4&&_0x56a406?(delete _0x3eb287['node']['children'][_0x81928b],_0x3eb287['node']['childCount']--,Ri(_0x3eb287)):!_0x4aaef4&&!_0x56a406&&(_0x3eb287['node']['children'][_0x81928b]=_0xe4726['node'],_0x3eb287['node']['childCount']++,Ri(_0x3eb287));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0xb117d5){return typeof _0xb117d5=='string'&&_0xb117d5['length']!==0x0&&!od['test'](_0xb117d5);},na=function(_0x292765){return typeof _0x292765=='string'&&_0x292765['length']!==0x0&&!ad['test'](_0x292765);},cd=function(_0x2902ba){return _0x2902ba&&(_0x2902ba=_0x2902ba['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x2902ba);},Cn=function(_0x6996aa){return _0x6996aa===null||typeof _0x6996aa=='string'||typeof _0x6996aa=='number'&&!Wi(_0x6996aa)||_0x6996aa&&typeof _0x6996aa=='object'&&Y(_0x6996aa,'.sv');},qt=function(_0x520081,_0x98ce49,_0x5d51ea,_0x54b90b){_0x54b90b&&_0x98ce49===void 0x0||zt(Nn(_0x520081,'value'),_0x98ce49,_0x5d51ea);},zt=function(_0x3706af,_0x399b35,_0x180c85){const _0x13d232=_0x180c85 instanceof C?new Sh(_0x180c85,_0x3706af):_0x180c85;if(_0x399b35===void 0x0)throw new Error(_0x3706af+'contains\x20undefined\x20'+Ne(_0x13d232));if(typeof _0x399b35=='function')throw new Error(_0x3706af+'contains\x20a\x20function\x20'+Ne(_0x13d232)+'\x20with\x20contents\x20=\x20'+_0x399b35['toString']());if(Wi(_0x399b35))throw new Error(_0x3706af+'contains\x20'+_0x399b35['toString']()+'\x20'+Ne(_0x13d232));if(typeof _0x399b35=='string'&&_0x399b35['length']>oi/0x3&&Pn(_0x399b35)>oi)throw new Error(_0x3706af+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x13d232)+'\x20(\x27'+_0x399b35['substring'](0x0,0x32)+'...\x27)');if(_0x399b35&&typeof _0x399b35=='object'){let _0x344f39=!0x1,_0x42756a=!0x1;if(x(_0x399b35,(_0x1f0cf8,_0x2422ce)=>{if(_0x1f0cf8==='.value')_0x344f39=!0x0;else{if(_0x1f0cf8!=='.priority'&&_0x1f0cf8!=='.sv'&&(_0x42756a=!0x0,!ps(_0x1f0cf8)))throw new Error(_0x3706af+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1f0cf8+')\x20'+Ne(_0x13d232)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x13d232,_0x1f0cf8),zt(_0x3706af,_0x2422ce,_0x13d232),Rh(_0x13d232);}),_0x344f39&&_0x42756a)throw new Error(_0x3706af+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x13d232)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x5390ec,_0x240816){let _0x35a289,_0x319e9a;for(_0x35a289=0x0;_0x35a289<_0x240816['length'];_0x35a289++){_0x319e9a=_0x240816[_0x35a289];const _0x19fad9=kt(_0x319e9a);for(let _0x1b5d17=0x0;_0x1b5d17<_0x19fad9['length'];_0x1b5d17++)if(!(_0x19fad9[_0x1b5d17]==='.priority'&&_0x1b5d17===_0x19fad9['length']-0x1)){if(!ps(_0x19fad9[_0x1b5d17]))throw new Error(_0x5390ec+'contains\x20an\x20invalid\x20key\x20('+_0x19fad9[_0x1b5d17]+')\x20in\x20path\x20'+_0x319e9a['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x240816['sort'](Th);let _0xe6ea73=null;for(_0x35a289=0x0;_0x35a289<_0x240816['length'];_0x35a289++){if(_0x319e9a=_0x240816[_0x35a289],_0xe6ea73!==null&&$(_0xe6ea73,_0x319e9a))throw new Error(_0x5390ec+'contains\x20a\x20path\x20'+_0xe6ea73['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x319e9a['toString']());_0xe6ea73=_0x319e9a;}},hd=function(_0x4338c8,_0x290c18,_0x47a821,_0x1de8b1){const _0x13f6ad=Nn(_0x4338c8,'values');if(!(_0x290c18&&typeof _0x290c18=='object')||Array['isArray'](_0x290c18))throw new Error(_0x13f6ad+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3fe22a=[];x(_0x290c18,(_0xd4d630,_0x5c0f14)=>{const _0x47e88a=new C(_0xd4d630);if(zt(_0x13f6ad,_0x5c0f14,A(_0x47a821,_0x47e88a)),Gi(_0x47e88a)==='.priority'&&!Cn(_0x5c0f14))throw new Error(_0x13f6ad+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x47e88a['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3fe22a['push'](_0x47e88a);}),ld(_0x13f6ad,_0x3fe22a);},_s=function(_0x41ea46,_0x5a5968,_0x17cf26,_0x3b018d){if(!na(_0x17cf26))throw new Error(Nn(_0x41ea46,_0x5a5968)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x17cf26+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x46e39f,_0x2402e5,_0x49358b,_0x5d2f77){_0x49358b&&(_0x49358b=_0x49358b['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x46e39f,_0x2402e5,_0x49358b);},gs=function(_0x496a7b,_0x312df9){if(y(_0x312df9)==='.info')throw new Error(_0x496a7b+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x4b60dc,_0x9b8b42){const _0x2fcc2b=_0x9b8b42['path']['toString']();if(typeof _0x9b8b42['repoInfo']['host']!='string'||_0x9b8b42['repoInfo']['host']['length']===0x0||!ps(_0x9b8b42['repoInfo']['namespace'])&&_0x9b8b42['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2fcc2b['length']!==0x0&&!cd(_0x2fcc2b))throw new Error(Nn(_0x4b60dc,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x1103f0,_0x573826){let _0x55ae7e=null;for(let _0x4e5fe3=0x0;_0x4e5fe3<_0x573826['length'];_0x4e5fe3++){const _0x32839d=_0x573826[_0x4e5fe3],_0x133f1c=_0x32839d['getPath']();_0x55ae7e!==null&&!qi(_0x133f1c,_0x55ae7e['path'])&&(_0x1103f0['eventLists_']['push'](_0x55ae7e),_0x55ae7e=null),_0x55ae7e===null&&(_0x55ae7e={'events':[],'path':_0x133f1c}),_0x55ae7e['events']['push'](_0x32839d);}_0x55ae7e&&_0x1103f0['eventLists_']['push'](_0x55ae7e);}function ia(_0x201e34,_0x363ba1,_0x574fe3){Bn(_0x201e34,_0x574fe3),sa(_0x201e34,_0x316288=>qi(_0x316288,_0x363ba1));}function V(_0x385570,_0x420214,_0x28f042){Bn(_0x385570,_0x28f042),sa(_0x385570,_0x402ac3=>$(_0x402ac3,_0x420214)||$(_0x420214,_0x402ac3));}function sa(_0x13b8e1,_0x5103f8){_0x13b8e1['recursionDepth_']++;let _0x109d00=!0x0;for(let _0x58fe8b=0x0;_0x58fe8b<_0x13b8e1['eventLists_']['length'];_0x58fe8b++){const _0x33dd11=_0x13b8e1['eventLists_'][_0x58fe8b];if(_0x33dd11){const _0x1a8c70=_0x33dd11['path'];_0x5103f8(_0x1a8c70)?(pd(_0x13b8e1['eventLists_'][_0x58fe8b]),_0x13b8e1['eventLists_'][_0x58fe8b]=null):_0x109d00=!0x1;}}_0x109d00&&(_0x13b8e1['eventLists_']=[]),_0x13b8e1['recursionDepth_']--;}function pd(_0xa498b8){for(let _0x1f296a=0x0;_0x1f296a<_0xa498b8['events']['length'];_0x1f296a++){const _0x206773=_0xa498b8['events'][_0x1f296a];if(_0x206773!==null){_0xa498b8['events'][_0x1f296a]=null;const _0x18578e=_0x206773['getEventRunner']();Et&&L('event:\x20'+_0x206773['toString']()),lt(_0x18578e);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x1ef71f,_0x5a4be3,_0x1fab2d,_0x193671){this['repoInfo_']=_0x1ef71f,this['forceRestClient_']=_0x5a4be3,this['authTokenProvider_']=_0x1fab2d,this['appCheckProvider_']=_0x193671,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x510e0f,_0x52ded4,_0xe6386){if(_0x510e0f['stats_']=Hi(_0x510e0f['repoInfo_']),_0x510e0f['forceRestClient_']||Yl())_0x510e0f['server_']=new fn(_0x510e0f['repoInfo_'],(_0x54103a,_0x2cf111,_0x3bcab7,_0x32dd8e)=>{pr(_0x510e0f,_0x54103a,_0x2cf111,_0x3bcab7,_0x32dd8e);},_0x510e0f['authTokenProvider_'],_0x510e0f['appCheckProvider_']),setTimeout(()=>_r(_0x510e0f,!0x0),0x0);else{if(typeof _0xe6386<'u'&&_0xe6386!==null){if(typeof _0xe6386!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xe6386);}catch(_0x310f06){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x310f06);}}_0x510e0f['persistentConnection_']=new ie(_0x510e0f['repoInfo_'],_0x52ded4,(_0x18cd47,_0x403baa,_0x5887ee,_0x31d44c)=>{pr(_0x510e0f,_0x18cd47,_0x403baa,_0x5887ee,_0x31d44c);},_0x2d92f2=>{_r(_0x510e0f,_0x2d92f2);},_0x26d168=>{yd(_0x510e0f,_0x26d168);},_0x510e0f['authTokenProvider_'],_0x510e0f['appCheckProvider_'],_0xe6386),_0x510e0f['server_']=_0x510e0f['persistentConnection_'];}_0x510e0f['authTokenProvider_']['addTokenChangeListener'](_0x4e1e03=>{_0x510e0f['server_']['refreshAuthToken'](_0x4e1e03);}),_0x510e0f['appCheckProvider_']['addTokenChangeListener'](_0x4b0190=>{_0x510e0f['server_']['refreshAppCheckToken'](_0x4b0190['token']);}),_0x510e0f['statsReporter_']=eh(_0x510e0f['repoInfo_'],()=>new eu(_0x510e0f['stats_'],_0x510e0f['server_'])),_0x510e0f['infoData_']=new Yh(),_0x510e0f['infoSyncTree_']=new dr({'startListening':(_0x5bbcc5,_0x4a4f87,_0x33358b,_0x4c911d)=>{let _0x35a796=[];const _0x48c2ab=_0x510e0f['infoData_']['getNode'](_0x5bbcc5['_path']);return _0x48c2ab['isEmpty']()||(_0x35a796=$t(_0x510e0f['infoSyncTree_'],_0x5bbcc5['_path'],_0x48c2ab),setTimeout(()=>{_0x4c911d('ok');},0x0)),_0x35a796;},'stopListening':()=>{}}),ms(_0x510e0f,'connected',!0x1),_0x510e0f['serverSyncTree_']=new dr({'startListening':(_0x4d9494,_0x7db116,_0x5f4adb,_0x1c5482)=>(_0x510e0f['server_']['listen'](_0x4d9494,_0x5f4adb,_0x7db116,(_0x5980b6,_0x3e0aa9)=>{const _0x9f5941=_0x1c5482(_0x5980b6,_0x3e0aa9);V(_0x510e0f['eventQueue_'],_0x4d9494['_path'],_0x9f5941);}),[]),'stopListening':(_0x141641,_0x732380)=>{_0x510e0f['server_']['unlisten'](_0x141641,_0x732380);}});}function oa(_0x3a1458){const _0x379d0a=_0x3a1458['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x379d0a;}function jt(_0x47e94e){return ed({'timestamp':oa(_0x47e94e)});}function pr(_0x4dd679,_0x8e9a8,_0xcfb09c,_0x597683,_0x361fbb){_0x4dd679['dataUpdateCount']++;const _0x4e46a0=new C(_0x8e9a8);_0xcfb09c=_0x4dd679['interceptServerDataCallback_']?_0x4dd679['interceptServerDataCallback_'](_0x8e9a8,_0xcfb09c):_0xcfb09c;let _0xc0cf8b=[];if(_0x361fbb){if(_0x597683){const _0x40de5d=ln(_0xcfb09c,_0x135fc0=>N(_0x135fc0));_0xc0cf8b=Ku(_0x4dd679['serverSyncTree_'],_0x4e46a0,_0x40de5d,_0x361fbb);}else{const _0xfaa5d9=N(_0xcfb09c);_0xc0cf8b=Yo(_0x4dd679['serverSyncTree_'],_0x4e46a0,_0xfaa5d9,_0x361fbb);}}else{if(_0x597683){const _0x108bec=ln(_0xcfb09c,_0x163b08=>N(_0x163b08));_0xc0cf8b=qu(_0x4dd679['serverSyncTree_'],_0x4e46a0,_0x108bec);}else{const _0x8278a4=N(_0xcfb09c);_0xc0cf8b=$t(_0x4dd679['serverSyncTree_'],_0x4e46a0,_0x8278a4);}}let _0x27379f=_0x4e46a0;_0xc0cf8b['length']>0x0&&(_0x27379f=st(_0x4dd679,_0x4e46a0)),V(_0x4dd679['eventQueue_'],_0x27379f,_0xc0cf8b);}function _r(_0x4964c0,_0x332b33){ms(_0x4964c0,'connected',_0x332b33),_0x332b33===!0x1&&wd(_0x4964c0);}function yd(_0x2d6d05,_0xcbc3a8){x(_0xcbc3a8,(_0x43e00d,_0x5e57d1)=>{ms(_0x2d6d05,_0x43e00d,_0x5e57d1);});}function ms(_0x5e22a9,_0x58013c,_0x565044){const _0x143440=new C('/.info/'+_0x58013c),_0x92519d=N(_0x565044);_0x5e22a9['infoData_']['updateSnapshot'](_0x143440,_0x92519d);const _0x226e11=$t(_0x5e22a9['infoSyncTree_'],_0x143440,_0x92519d);V(_0x5e22a9['eventQueue_'],_0x143440,_0x226e11);}function Vn(_0x4f569a){return _0x4f569a['nextWriteId_']++;}function vd(_0x275e8e,_0x2eb9a9,_0x21e171){const _0xdcc269=Yu(_0x275e8e['serverSyncTree_'],_0x2eb9a9);return _0xdcc269!=null?Promise['resolve'](_0xdcc269):_0x275e8e['server_']['get'](_0x2eb9a9)['then'](_0x51c107=>{const _0x1bd93c=N(_0x51c107)['withIndex'](_0x2eb9a9['_queryParams']['getIndex']());bi(_0x275e8e['serverSyncTree_'],_0x2eb9a9,_0x21e171,!0x0);let _0x191f39;if(_0x2eb9a9['_queryParams']['loadsAllData']())_0x191f39=$t(_0x275e8e['serverSyncTree_'],_0x2eb9a9['_path'],_0x1bd93c);else{const _0x4858fc=Mt(_0x275e8e['serverSyncTree_'],_0x2eb9a9);_0x191f39=Yo(_0x275e8e['serverSyncTree_'],_0x2eb9a9['_path'],_0x1bd93c,_0x4858fc);}return V(_0x275e8e['eventQueue_'],_0x2eb9a9['_path'],_0x191f39),wn(_0x275e8e['serverSyncTree_'],_0x2eb9a9,_0x21e171,null,!0x0),_0x1bd93c;},_0x27ebcd=>(ut(_0x275e8e,'get\x20for\x20query\x20'+O(_0x2eb9a9)+'\x20failed:\x20'+_0x27ebcd),Promise['reject'](new Error(_0x27ebcd))));}function Ed(_0x1aac6e,_0x41fed9,_0x570f2c,_0x4f8400,_0x8499d3){ut(_0x1aac6e,'set',{'path':_0x41fed9['toString'](),'value':_0x570f2c,'priority':_0x4f8400});const _0x3199b5=jt(_0x1aac6e),_0x3513d8=N(_0x570f2c,_0x4f8400),_0x1d3716=xn(_0x1aac6e['serverSyncTree_'],_0x41fed9),_0x49f32c=hs(_0x3513d8,_0x1d3716,_0x3199b5),_0x2c0586=Vn(_0x1aac6e),_0x4d0898=ss(_0x1aac6e['serverSyncTree_'],_0x41fed9,_0x49f32c,_0x2c0586,!0x0);Bn(_0x1aac6e['eventQueue_'],_0x4d0898),_0x1aac6e['server_']['put'](_0x41fed9['toString'](),_0x3513d8['val'](!0x0),(_0xd2387f,_0x23bb59)=>{const _0x225975=_0xd2387f==='ok';_0x225975||U('set\x20at\x20'+_0x41fed9+'\x20failed:\x20'+_0xd2387f);const _0x19a922=pe(_0x1aac6e['serverSyncTree_'],_0x2c0586,!_0x225975);V(_0x1aac6e['eventQueue_'],_0x41fed9,_0x19a922),Ai(_0x1aac6e,_0x8499d3,_0xd2387f,_0x23bb59);});const _0x39f098=vs(_0x1aac6e,_0x41fed9);st(_0x1aac6e,_0x39f098),V(_0x1aac6e['eventQueue_'],_0x39f098,[]);}function Id(_0x57fcbd,_0x5b4c26,_0x3605ac,_0x3b7e40){ut(_0x57fcbd,'update',{'path':_0x5b4c26['toString'](),'value':_0x3605ac});let _0x380c3=!0x0;const _0x388079=jt(_0x57fcbd),_0x52c097={};if(x(_0x3605ac,(_0x4c0c11,_0x370f04)=>{_0x380c3=!0x1,_0x52c097[_0x4c0c11]=Zo(A(_0x5b4c26,_0x4c0c11),N(_0x370f04),_0x57fcbd['serverSyncTree_'],_0x388079);}),_0x380c3)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x57fcbd,_0x3b7e40,'ok',void 0x0);else{const _0x14fb38=Vn(_0x57fcbd),_0x5dce4e=Gu(_0x57fcbd['serverSyncTree_'],_0x5b4c26,_0x52c097,_0x14fb38);Bn(_0x57fcbd['eventQueue_'],_0x5dce4e),_0x57fcbd['server_']['merge'](_0x5b4c26['toString'](),_0x3605ac,(_0x4d28a7,_0x3af9a1)=>{const _0x26d42f=_0x4d28a7==='ok';_0x26d42f||U('update\x20at\x20'+_0x5b4c26+'\x20failed:\x20'+_0x4d28a7);const _0x586920=pe(_0x57fcbd['serverSyncTree_'],_0x14fb38,!_0x26d42f),_0x476c76=_0x586920['length']>0x0?st(_0x57fcbd,_0x5b4c26):_0x5b4c26;V(_0x57fcbd['eventQueue_'],_0x476c76,_0x586920),Ai(_0x57fcbd,_0x3b7e40,_0x4d28a7,_0x3af9a1);}),x(_0x3605ac,_0x2a4fdb=>{const _0x389ffe=vs(_0x57fcbd,A(_0x5b4c26,_0x2a4fdb));st(_0x57fcbd,_0x389ffe);}),V(_0x57fcbd['eventQueue_'],_0x5b4c26,[]);}}function wd(_0x1a2b6f){ut(_0x1a2b6f,'onDisconnectEvents');const _0x57d0b1=jt(_0x1a2b6f),_0x2da292=pn();Ei(_0x1a2b6f['onDisconnect_'],w(),(_0x302ae1,_0x3d979e)=>{const _0x180a5e=Zo(_0x302ae1,_0x3d979e,_0x1a2b6f['serverSyncTree_'],_0x57d0b1);Mo(_0x2da292,_0x302ae1,_0x180a5e);});let _0x6004bd=[];Ei(_0x2da292,w(),(_0x138233,_0x5c5d60)=>{_0x6004bd=_0x6004bd['concat']($t(_0x1a2b6f['serverSyncTree_'],_0x138233,_0x5c5d60));const _0x448a48=vs(_0x1a2b6f,_0x138233);st(_0x1a2b6f,_0x448a48);}),_0x1a2b6f['onDisconnect_']=pn(),V(_0x1a2b6f['eventQueue_'],w(),_0x6004bd);}function Cd(_0x449988,_0x3792e1,_0x4e0f89){let _0x47b940;y(_0x3792e1['_path'])==='.info'?_0x47b940=bi(_0x449988['infoSyncTree_'],_0x3792e1,_0x4e0f89):_0x47b940=bi(_0x449988['serverSyncTree_'],_0x3792e1,_0x4e0f89),ia(_0x449988['eventQueue_'],_0x3792e1['_path'],_0x47b940);}function Td(_0x1a6be7,_0x20049c,_0x1ac632){let _0x2171bc;y(_0x20049c['_path'])==='.info'?_0x2171bc=wn(_0x1a6be7['infoSyncTree_'],_0x20049c,_0x1ac632):_0x2171bc=wn(_0x1a6be7['serverSyncTree_'],_0x20049c,_0x1ac632),ia(_0x1a6be7['eventQueue_'],_0x20049c['_path'],_0x2171bc);}function aa(_0x554063){_0x554063['persistentConnection_']&&_0x554063['persistentConnection_']['interrupt'](ra);}function Sd(_0x49a487){_0x49a487['persistentConnection_']&&_0x49a487['persistentConnection_']['resume'](ra);}function ut(_0x1dfba3,..._0x55a16e){let _0xff876='';_0x1dfba3['persistentConnection_']&&(_0xff876=_0x1dfba3['persistentConnection_']['id']+':'),L(_0xff876,..._0x55a16e);}function Ai(_0x560855,_0x41f3af,_0x49edda,_0x59ac8b){_0x41f3af&&lt(()=>{if(_0x49edda==='ok')_0x41f3af(null);else{const _0x1171bc=(_0x49edda||'error')['toUpperCase']();let _0x1616fe=_0x1171bc;_0x59ac8b&&(_0x1616fe+=':\x20'+_0x59ac8b);const _0x766ce6=new Error(_0x1616fe);_0x766ce6['code']=_0x1171bc,_0x41f3af(_0x766ce6);}});}function bd(_0x414f25,_0x310390,_0x495b99,_0x32ad10,_0x41d081,_0x148911){ut(_0x414f25,'transaction\x20on\x20'+_0x310390);const _0x6928a={'path':_0x310390,'update':_0x495b99,'onComplete':_0x32ad10,'status':null,'order':to(),'applyLocally':_0x148911,'retryCount':0x0,'unwatcher':_0x41d081,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2cb2f4=ys(_0x414f25,_0x310390,void 0x0);_0x6928a['currentInputSnapshot']=_0x2cb2f4;const _0x56f099=_0x6928a['update'](_0x2cb2f4['val']());if(_0x56f099===void 0x0)_0x6928a['unwatcher'](),_0x6928a['currentOutputSnapshotRaw']=null,_0x6928a['currentOutputSnapshotResolved']=null,_0x6928a['onComplete']&&_0x6928a['onComplete'](null,!0x1,_0x6928a['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x56f099,_0x6928a['path']),_0x6928a['status']=0x0;const _0x3f467c=Un(_0x414f25['transactionQueueTree_'],_0x310390),_0xd89bb1=Ge(_0x3f467c)||[];_0xd89bb1['push'](_0x6928a),fs(_0x3f467c,_0xd89bb1);let _0x406621;typeof _0x56f099=='object'&&_0x56f099!==null&&Y(_0x56f099,'.priority')?(_0x406621=Oe(_0x56f099,'.priority'),f(Cn(_0x406621),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x406621=(xn(_0x414f25['serverSyncTree_'],_0x310390)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4bc86a=jt(_0x414f25),_0x59ccaa=N(_0x56f099,_0x406621),_0xa38704=hs(_0x59ccaa,_0x2cb2f4,_0x4bc86a);_0x6928a['currentOutputSnapshotRaw']=_0x59ccaa,_0x6928a['currentOutputSnapshotResolved']=_0xa38704,_0x6928a['currentWriteId']=Vn(_0x414f25);const _0xbf0c46=ss(_0x414f25['serverSyncTree_'],_0x310390,_0xa38704,_0x6928a['currentWriteId'],_0x6928a['applyLocally']);V(_0x414f25['eventQueue_'],_0x310390,_0xbf0c46),Hn(_0x414f25,_0x414f25['transactionQueueTree_']);}}function ys(_0x9a1f,_0x43a27a,_0x4e88f8){return xn(_0x9a1f['serverSyncTree_'],_0x43a27a,_0x4e88f8)||g['EMPTY_NODE'];}function Hn(_0x14b6d6,_0x186f37=_0x14b6d6['transactionQueueTree_']){if(_0x186f37||$n(_0x14b6d6,_0x186f37),Ge(_0x186f37)){const _0x42f59e=la(_0x14b6d6,_0x186f37);f(_0x42f59e['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x42f59e['every'](_0x25845e=>_0x25845e['status']===0x0)&&Rd(_0x14b6d6,Gt(_0x186f37),_0x42f59e);}else ea(_0x186f37)&&Wn(_0x186f37,_0x16fe8f=>{Hn(_0x14b6d6,_0x16fe8f);});}function Rd(_0x4df4e8,_0x5868bc,_0xf053fc){const _0x5149f0=_0xf053fc['map'](_0x59d671=>_0x59d671['currentWriteId']),_0x46d628=ys(_0x4df4e8,_0x5868bc,_0x5149f0);let _0x4fea58=_0x46d628;const _0x408c92=_0x46d628['hash']();for(let _0x23f073=0x0;_0x23f073<_0xf053fc['length'];_0x23f073++){const _0x27d1db=_0xf053fc[_0x23f073];f(_0x27d1db['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x27d1db['status']=0x1,_0x27d1db['retryCount']++;const _0x24e279=F(_0x5868bc,_0x27d1db['path']);_0x4fea58=_0x4fea58['updateChild'](_0x24e279,_0x27d1db['currentOutputSnapshotRaw']);}const _0x573430=_0x4fea58['val'](!0x0),_0x15ceb8=_0x5868bc;_0x4df4e8['server_']['put'](_0x15ceb8['toString'](),_0x573430,_0x4af421=>{ut(_0x4df4e8,'transaction\x20put\x20response',{'path':_0x15ceb8['toString'](),'status':_0x4af421});let _0x40fa77=[];if(_0x4af421==='ok'){const _0x8275af=[];for(let _0x5f219b=0x0;_0x5f219b<_0xf053fc['length'];_0x5f219b++)_0xf053fc[_0x5f219b]['status']=0x2,_0x40fa77=_0x40fa77['concat'](pe(_0x4df4e8['serverSyncTree_'],_0xf053fc[_0x5f219b]['currentWriteId'])),_0xf053fc[_0x5f219b]['onComplete']&&_0x8275af['push'](()=>_0xf053fc[_0x5f219b]['onComplete'](null,!0x0,_0xf053fc[_0x5f219b]['currentOutputSnapshotResolved'])),_0xf053fc[_0x5f219b]['unwatcher']();$n(_0x4df4e8,Un(_0x4df4e8['transactionQueueTree_'],_0x5868bc)),Hn(_0x4df4e8,_0x4df4e8['transactionQueueTree_']),V(_0x4df4e8['eventQueue_'],_0x5868bc,_0x40fa77);for(let _0x16a335=0x0;_0x16a335<_0x8275af['length'];_0x16a335++)lt(_0x8275af[_0x16a335]);}else{if(_0x4af421==='datastale'){for(let _0x47cab2=0x0;_0x47cab2<_0xf053fc['length'];_0x47cab2++)_0xf053fc[_0x47cab2]['status']===0x3?_0xf053fc[_0x47cab2]['status']=0x4:_0xf053fc[_0x47cab2]['status']=0x0;}else{U('transaction\x20at\x20'+_0x15ceb8['toString']()+'\x20failed:\x20'+_0x4af421);for(let _0x58118f=0x0;_0x58118f<_0xf053fc['length'];_0x58118f++)_0xf053fc[_0x58118f]['status']=0x4,_0xf053fc[_0x58118f]['abortReason']=_0x4af421;}st(_0x4df4e8,_0x5868bc);}},_0x408c92);}function st(_0x4585d9,_0x3cfd25){const _0x519e9c=ca(_0x4585d9,_0x3cfd25),_0x28c5ee=Gt(_0x519e9c),_0x523f1a=la(_0x4585d9,_0x519e9c);return Ad(_0x4585d9,_0x523f1a,_0x28c5ee),_0x28c5ee;}function Ad(_0x518dcb,_0x374569,_0x379527){if(_0x374569['length']===0x0)return;const _0x38263e=[];let _0x52e717=[];const _0x9b3a9=_0x374569['filter'](_0x135e85=>_0x135e85['status']===0x0)['map'](_0x496dc7=>_0x496dc7['currentWriteId']);for(let _0x495198=0x0;_0x495198<_0x374569['length'];_0x495198++){const _0x36c0ff=_0x374569[_0x495198],_0x19e007=F(_0x379527,_0x36c0ff['path']);let _0x5d9eeb=!0x1,_0x112b77;if(f(_0x19e007!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x36c0ff['status']===0x4)_0x5d9eeb=!0x0,_0x112b77=_0x36c0ff['abortReason'],_0x52e717=_0x52e717['concat'](pe(_0x518dcb['serverSyncTree_'],_0x36c0ff['currentWriteId'],!0x0));else{if(_0x36c0ff['status']===0x0){if(_0x36c0ff['retryCount']>=_d)_0x5d9eeb=!0x0,_0x112b77='maxretry',_0x52e717=_0x52e717['concat'](pe(_0x518dcb['serverSyncTree_'],_0x36c0ff['currentWriteId'],!0x0));else{const _0x295719=ys(_0x518dcb,_0x36c0ff['path'],_0x9b3a9);_0x36c0ff['currentInputSnapshot']=_0x295719;const _0xe72e42=_0x374569[_0x495198]['update'](_0x295719['val']());if(_0xe72e42!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xe72e42,_0x36c0ff['path']);let _0x160ffc=N(_0xe72e42);typeof _0xe72e42=='object'&&_0xe72e42!=null&&Y(_0xe72e42,'.priority')||(_0x160ffc=_0x160ffc['updatePriority'](_0x295719['getPriority']()));const _0xf9fa26=_0x36c0ff['currentWriteId'],_0x4c8625=jt(_0x518dcb),_0xf0918=hs(_0x160ffc,_0x295719,_0x4c8625);_0x36c0ff['currentOutputSnapshotRaw']=_0x160ffc,_0x36c0ff['currentOutputSnapshotResolved']=_0xf0918,_0x36c0ff['currentWriteId']=Vn(_0x518dcb),_0x9b3a9['splice'](_0x9b3a9['indexOf'](_0xf9fa26),0x1),_0x52e717=_0x52e717['concat'](ss(_0x518dcb['serverSyncTree_'],_0x36c0ff['path'],_0xf0918,_0x36c0ff['currentWriteId'],_0x36c0ff['applyLocally'])),_0x52e717=_0x52e717['concat'](pe(_0x518dcb['serverSyncTree_'],_0xf9fa26,!0x0));}else _0x5d9eeb=!0x0,_0x112b77='nodata',_0x52e717=_0x52e717['concat'](pe(_0x518dcb['serverSyncTree_'],_0x36c0ff['currentWriteId'],!0x0));}}}V(_0x518dcb['eventQueue_'],_0x379527,_0x52e717),_0x52e717=[],_0x5d9eeb&&(_0x374569[_0x495198]['status']=0x2,function(_0x2a837b){setTimeout(_0x2a837b,Math['floor'](0x0));}(_0x374569[_0x495198]['unwatcher']),_0x374569[_0x495198]['onComplete']&&(_0x112b77==='nodata'?_0x38263e['push'](()=>_0x374569[_0x495198]['onComplete'](null,!0x1,_0x374569[_0x495198]['currentInputSnapshot'])):_0x38263e['push'](()=>_0x374569[_0x495198]['onComplete'](new Error(_0x112b77),!0x1,null))));}$n(_0x518dcb,_0x518dcb['transactionQueueTree_']);for(let _0x1f0580=0x0;_0x1f0580<_0x38263e['length'];_0x1f0580++)lt(_0x38263e[_0x1f0580]);Hn(_0x518dcb,_0x518dcb['transactionQueueTree_']);}function ca(_0x3f1b8b,_0xdd01ed){let _0x1cd1c8,_0x1c7934=_0x3f1b8b['transactionQueueTree_'];for(_0x1cd1c8=y(_0xdd01ed);_0x1cd1c8!==null&&Ge(_0x1c7934)===void 0x0;)_0x1c7934=Un(_0x1c7934,_0x1cd1c8),_0xdd01ed=b(_0xdd01ed),_0x1cd1c8=y(_0xdd01ed);return _0x1c7934;}function la(_0x150627,_0x35ca2a){const _0x4c29b3=[];return ha(_0x150627,_0x35ca2a,_0x4c29b3),_0x4c29b3['sort']((_0x2f2007,_0x2f932a)=>_0x2f2007['order']-_0x2f932a['order']),_0x4c29b3;}function ha(_0x19f8e9,_0x1ef87a,_0x46f8e8){const _0x1d0e8c=Ge(_0x1ef87a);if(_0x1d0e8c){for(let _0x5c642c=0x0;_0x5c642c<_0x1d0e8c['length'];_0x5c642c++)_0x46f8e8['push'](_0x1d0e8c[_0x5c642c]);}Wn(_0x1ef87a,_0x130e65=>{ha(_0x19f8e9,_0x130e65,_0x46f8e8);});}function $n(_0x3f1d9,_0x2d7f6c){const _0x16541f=Ge(_0x2d7f6c);if(_0x16541f){let _0x41a484=0x0;for(let _0x59d06c=0x0;_0x59d06c<_0x16541f['length'];_0x59d06c++)_0x16541f[_0x59d06c]['status']!==0x2&&(_0x16541f[_0x41a484]=_0x16541f[_0x59d06c],_0x41a484++);_0x16541f['length']=_0x41a484,fs(_0x2d7f6c,_0x16541f['length']>0x0?_0x16541f:void 0x0);}Wn(_0x2d7f6c,_0x3050c1=>{$n(_0x3f1d9,_0x3050c1);});}function vs(_0x23da0e,_0x42eb53){const _0x5d0b91=Gt(ca(_0x23da0e,_0x42eb53)),_0xfb42a7=Un(_0x23da0e['transactionQueueTree_'],_0x42eb53);return sd(_0xfb42a7,_0x1596bd=>{ai(_0x23da0e,_0x1596bd);}),ai(_0x23da0e,_0xfb42a7),ta(_0xfb42a7,_0x103106=>{ai(_0x23da0e,_0x103106);}),_0x5d0b91;}function ai(_0x228445,_0x5b1672){const _0x2a09fd=Ge(_0x5b1672);if(_0x2a09fd){const _0x49ff55=[];let _0x59742e=[],_0x33c8d5=-0x1;for(let _0x126897=0x0;_0x126897<_0x2a09fd['length'];_0x126897++)_0x2a09fd[_0x126897]['status']===0x3||(_0x2a09fd[_0x126897]['status']===0x1?(f(_0x33c8d5===_0x126897-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x33c8d5=_0x126897,_0x2a09fd[_0x126897]['status']=0x3,_0x2a09fd[_0x126897]['abortReason']='set'):(f(_0x2a09fd[_0x126897]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2a09fd[_0x126897]['unwatcher'](),_0x59742e=_0x59742e['concat'](pe(_0x228445['serverSyncTree_'],_0x2a09fd[_0x126897]['currentWriteId'],!0x0)),_0x2a09fd[_0x126897]['onComplete']&&_0x49ff55['push'](_0x2a09fd[_0x126897]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x33c8d5===-0x1?fs(_0x5b1672,void 0x0):_0x2a09fd['length']=_0x33c8d5+0x1,V(_0x228445['eventQueue_'],Gt(_0x5b1672),_0x59742e);for(let _0x282d0e=0x0;_0x282d0e<_0x49ff55['length'];_0x282d0e++)lt(_0x49ff55[_0x282d0e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x2d0ac4){let _0x4dfe3e='';const _0x98dc5f=_0x2d0ac4['split']('/');for(let _0x5da8a5=0x0;_0x5da8a5<_0x98dc5f['length'];_0x5da8a5++)if(_0x98dc5f[_0x5da8a5]['length']>0x0){let _0x59962c=_0x98dc5f[_0x5da8a5];try{_0x59962c=decodeURIComponent(_0x59962c['replace'](/\+/g,'\x20'));}catch{}_0x4dfe3e+='/'+_0x59962c;}return _0x4dfe3e;}function Nd(_0x4baec0){const _0x5c7f83={};_0x4baec0['charAt'](0x0)==='?'&&(_0x4baec0=_0x4baec0['substring'](0x1));for(const _0x22d0ab of _0x4baec0['split']('&')){if(_0x22d0ab['length']===0x0)continue;const _0x54ec59=_0x22d0ab['split']('=');_0x54ec59['length']===0x2?_0x5c7f83[decodeURIComponent(_0x54ec59[0x0])]=decodeURIComponent(_0x54ec59[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x22d0ab+'\x27\x20in\x20query\x20\x27'+_0x4baec0+'\x27');}return _0x5c7f83;}const gr=function(_0x34ab00,_0x2fdfb2){const _0x460cea=Pd(_0x34ab00),_0x4d4646=_0x460cea['namespace'];_0x460cea['domain']==='firebase.com'&&oe(_0x460cea['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4d4646||_0x4d4646==='undefined')&&_0x460cea['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x460cea['secure']||Bl();const _0x580267=_0x460cea['scheme']==='ws'||_0x460cea['scheme']==='wss';return{'repoInfo':new _o(_0x460cea['host'],_0x460cea['secure'],_0x4d4646,_0x580267,_0x2fdfb2,'',_0x4d4646!==_0x460cea['subdomain']),'path':new C(_0x460cea['pathString'])};},Pd=function(_0x2f94d4){let _0x3571fe='',_0x4c48ee='',_0x215051='',_0x42fdaf='',_0x4b6b59='',_0x33125b=!0x0,_0x5c3d95='https',_0x2d6381=0x1bb;if(typeof _0x2f94d4=='string'){let _0x378a35=_0x2f94d4['indexOf']('//');_0x378a35>=0x0&&(_0x5c3d95=_0x2f94d4['substring'](0x0,_0x378a35-0x1),_0x2f94d4=_0x2f94d4['substring'](_0x378a35+0x2));let _0x140e7e=_0x2f94d4['indexOf']('/');_0x140e7e===-0x1&&(_0x140e7e=_0x2f94d4['length']);let _0x3ec6d7=_0x2f94d4['indexOf']('?');_0x3ec6d7===-0x1&&(_0x3ec6d7=_0x2f94d4['length']),_0x3571fe=_0x2f94d4['substring'](0x0,Math['min'](_0x140e7e,_0x3ec6d7)),_0x140e7e<_0x3ec6d7&&(_0x42fdaf=kd(_0x2f94d4['substring'](_0x140e7e,_0x3ec6d7)));const _0x36c00c=Nd(_0x2f94d4['substring'](Math['min'](_0x2f94d4['length'],_0x3ec6d7)));_0x378a35=_0x3571fe['indexOf'](':'),_0x378a35>=0x0?(_0x33125b=_0x5c3d95==='https'||_0x5c3d95==='wss',_0x2d6381=parseInt(_0x3571fe['substring'](_0x378a35+0x1),0xa)):_0x378a35=_0x3571fe['length'];const _0x4a1e86=_0x3571fe['slice'](0x0,_0x378a35);if(_0x4a1e86['toLowerCase']()==='localhost')_0x4c48ee='localhost';else{if(_0x4a1e86['split']('.')['length']<=0x2)_0x4c48ee=_0x4a1e86;else{const _0x41960e=_0x3571fe['indexOf']('.');_0x215051=_0x3571fe['substring'](0x0,_0x41960e)['toLowerCase'](),_0x4c48ee=_0x3571fe['substring'](_0x41960e+0x1),_0x4b6b59=_0x215051;}}'ns'in _0x36c00c&&(_0x4b6b59=_0x36c00c['ns']);}return{'host':_0x3571fe,'port':_0x2d6381,'domain':_0x4c48ee,'subdomain':_0x215051,'secure':_0x33125b,'scheme':_0x5c3d95,'pathString':_0x42fdaf,'namespace':_0x4b6b59};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x2ea972=0x0;const _0xaa7bbb=[];return function(_0x21a5f0){const _0x5d5e9c=_0x21a5f0===_0x2ea972;_0x2ea972=_0x21a5f0;let _0x138a58;const _0x514a9e=new Array(0x8);for(_0x138a58=0x7;_0x138a58>=0x0;_0x138a58--)_0x514a9e[_0x138a58]=mr['charAt'](_0x21a5f0%0x40),_0x21a5f0=Math['floor'](_0x21a5f0/0x40);f(_0x21a5f0===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4bf856=_0x514a9e['join']('');if(_0x5d5e9c){for(_0x138a58=0xb;_0x138a58>=0x0&&_0xaa7bbb[_0x138a58]===0x3f;_0x138a58--)_0xaa7bbb[_0x138a58]=0x0;_0xaa7bbb[_0x138a58]++;}else{for(_0x138a58=0x0;_0x138a58<0xc;_0x138a58++)_0xaa7bbb[_0x138a58]=Math['floor'](Math['random']()*0x40);}for(_0x138a58=0x0;_0x138a58<0xc;_0x138a58++)_0x4bf856+=mr['charAt'](_0xaa7bbb[_0x138a58]);return f(_0x4bf856['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4bf856;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0xb093b0,_0x4a1137,_0x52bca1,_0x37ad74){this['eventType']=_0xb093b0,this['eventRegistration']=_0x4a1137,this['snapshot']=_0x52bca1,this['prevName']=_0x37ad74;}['getPath'](){const _0x11fab5=this['snapshot']['ref'];return this['eventType']==='value'?_0x11fab5['_path']:_0x11fab5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x17dc07,_0x55a62f,_0x18c667){this['eventRegistration']=_0x17dc07,this['error']=_0x55a62f,this['path']=_0x18c667;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x491161,_0x186d50){this['snapshotCallback']=_0x491161,this['cancelCallback']=_0x186d50;}['onValue'](_0x50e25b,_0x4095e7){this['snapshotCallback']['call'](null,_0x50e25b,_0x4095e7);}['onCancel'](_0x248da4){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x248da4);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1acfc3){return this['snapshotCallback']===_0x1acfc3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1acfc3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1acfc3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3aec0a,_0x4e36f7,_0x11225c,_0x3a70f0){this['_repo']=_0x3aec0a,this['_path']=_0x4e36f7,this['_queryParams']=_0x11225c,this['_orderByCalled']=_0x3a70f0;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4d2bd5=nr(this['_queryParams']),_0x5a60b7=Bi(_0x4d2bd5);return _0x5a60b7==='{}'?'default':_0x5a60b7;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x1be21f){if(_0x1be21f=k(_0x1be21f),!(_0x1be21f instanceof be))return!0x1;const _0x570feb=this['_repo']===_0x1be21f['_repo'],_0x9ad884=qi(this['_path'],_0x1be21f['_path']),_0x35635d=this['_queryIdentifier']===_0x1be21f['_queryIdentifier'];return _0x570feb&&_0x9ad884&&_0x35635d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x2ef998,_0x4cb728){if(_0x2ef998['_orderByCalled']===!0x0)throw new Error(_0x4cb728+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x469516){let _0x1425cf=null,_0x48e235=null;if(_0x469516['hasStart']()&&(_0x1425cf=_0x469516['getIndexStartValue']()),_0x469516['hasEnd']()&&(_0x48e235=_0x469516['getIndexEndValue']()),_0x469516['getIndex']()===ye){const _0x5297f6='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3a1780='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x469516['hasStart']()){if(_0x469516['getIndexStartName']()!==xe)throw new Error(_0x5297f6);if(typeof _0x1425cf!='string')throw new Error(_0x3a1780);}if(_0x469516['hasEnd']()){if(_0x469516['getIndexEndName']()!==Ie)throw new Error(_0x5297f6);if(typeof _0x48e235!='string')throw new Error(_0x3a1780);}}else{if(_0x469516['getIndex']()===R){if(_0x1425cf!=null&&!Cn(_0x1425cf)||_0x48e235!=null&&!Cn(_0x48e235))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x469516['getIndex']()instanceof Ki||_0x469516['getIndex']()===Po,'unknown\x20index\x20type.'),_0x1425cf!=null&&typeof _0x1425cf=='object'||_0x48e235!=null&&typeof _0x48e235=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x333e18){if(_0x333e18['hasStart']()&&_0x333e18['hasEnd']()&&_0x333e18['hasLimit']()&&!_0x333e18['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x29f08b,_0x2437b0){super(_0x29f08b,_0x2437b0,new Qi(),!0x1);}get['parent'](){const _0x1d03ba=To(this['_path']);return _0x1d03ba===null?null:new Z(this['_repo'],_0x1d03ba);}get['root'](){let _0x4e6c93=this;for(;_0x4e6c93['parent']!==null;)_0x4e6c93=_0x4e6c93['parent'];return _0x4e6c93;}}class rt{constructor(_0x210853,_0x1ee831,_0x4caff6){this['_node']=_0x210853,this['ref']=_0x1ee831,this['_index']=_0x4caff6;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4d33b5){const _0x11bbe7=new C(_0x4d33b5),_0x485810=Lt(this['ref'],_0x4d33b5);return new rt(this['_node']['getChild'](_0x11bbe7),_0x485810,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x223f91){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4e0593,_0x4ad824)=>_0x223f91(new rt(_0x4ad824,Lt(this['ref'],_0x4e0593),R)));}['hasChild'](_0x4df9ac){const _0x304b6f=new C(_0x4df9ac);return!this['_node']['getChild'](_0x304b6f)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x3290f5,_0x2bcff0){return _0x3290f5=k(_0x3290f5),_0x3290f5['_checkNotDeleted']('ref'),_0x2bcff0!==void 0x0?Lt(_0x3290f5['_root'],_0x2bcff0):_0x3290f5['_root'];}function Lt(_0x52278c,_0x55d164){return _0x52278c=k(_0x52278c),y(_0x52278c['_path'])===null?ud('child','path',_0x55d164):_s('child','path',_0x55d164),new Z(_0x52278c['_repo'],A(_0x52278c['_path'],_0x55d164));}function d_(_0x48b2bd,_0x360e50){_0x48b2bd=k(_0x48b2bd),gs('push',_0x48b2bd['_path']),qt('push',_0x360e50,_0x48b2bd['_path'],!0x0);const _0x52b550=oa(_0x48b2bd['_repo']),_0x286d19=Od(_0x52b550),_0x363306=Lt(_0x48b2bd,_0x286d19),_0x30fc8a=Lt(_0x48b2bd,_0x286d19);let _0x44cb1e;return _0x360e50!=null?_0x44cb1e=Ld(_0x30fc8a,_0x360e50)['then'](()=>_0x30fc8a):_0x44cb1e=Promise['resolve'](_0x30fc8a),_0x363306['then']=_0x44cb1e['then']['bind'](_0x44cb1e),_0x363306['catch']=_0x44cb1e['then']['bind'](_0x44cb1e,void 0x0),_0x363306;}function Ld(_0x16e88d,_0x399280){_0x16e88d=k(_0x16e88d),gs('set',_0x16e88d['_path']),qt('set',_0x399280,_0x16e88d['_path'],!0x1);const _0x1a4c74=new Ve();return Ed(_0x16e88d['_repo'],_0x16e88d['_path'],_0x399280,null,_0x1a4c74['wrapCallback'](()=>{})),_0x1a4c74['promise'];}function f_(_0x4202fc,_0x1f9983){hd('update',_0x1f9983,_0x4202fc['_path']);const _0x5d8972=new Ve();return Id(_0x4202fc['_repo'],_0x4202fc['_path'],_0x1f9983,_0x5d8972['wrapCallback'](()=>{})),_0x5d8972['promise'];}function p_(_0x22e575){_0x22e575=k(_0x22e575);const _0x28e2d3=new ua(()=>{}),_0x54c4e3=new qn(_0x28e2d3);return vd(_0x22e575['_repo'],_0x22e575,_0x54c4e3)['then'](_0x2a0220=>new rt(_0x2a0220,new Z(_0x22e575['_repo'],_0x22e575['_path']),_0x22e575['_queryParams']['getIndex']()));}class qn{constructor(_0x5a6fed){this['callbackContext']=_0x5a6fed;}['respondsTo'](_0x195c88){return _0x195c88==='value';}['createEvent'](_0xc86999,_0xbfe224){const _0x58d435=_0xbfe224['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0xc86999['snapshotNode'],new Z(_0xbfe224['_repo'],_0xbfe224['_path']),_0x58d435));}['getEventRunner'](_0x338402){return _0x338402['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x338402['error']):()=>this['callbackContext']['onValue'](_0x338402['snapshot'],null);}['createCancelEvent'](_0x5c7103,_0x1840a7){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x5c7103,_0x1840a7):null;}['matches'](_0x4e10ea){return _0x4e10ea instanceof qn?!_0x4e10ea['callbackContext']||!this['callbackContext']?!0x0:_0x4e10ea['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x55e43e,_0xc90632,_0xd40b59,_0x55014c,_0x373abd){const _0x2c843c=new ua(_0xd40b59,void 0x0),_0x54509d=new qn(_0x2c843c);return Cd(_0x55e43e['_repo'],_0x55e43e,_0x54509d),()=>Td(_0x55e43e['_repo'],_0x55e43e,_0x54509d);}function Fd(_0x5627d3,_0x1c0a73,_0x48f7cd,_0x43e3a0){return xd(_0x5627d3,'value',_0x1c0a73);}class dt{}class pa extends dt{constructor(_0x2e524d,_0xdbe0a6){super(),this['_value']=_0x2e524d,this['_key']=_0xdbe0a6,this['type']='endAt';}['_apply'](_0x5aafb2){qt('endAt',this['_value'],_0x5aafb2['_path'],!0x0);const _0xaa86b4=Kh(_0x5aafb2['_queryParams'],this['_value'],this['_key']);if(fa(_0xaa86b4),Gn(_0xaa86b4),_0x5aafb2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x5aafb2['_repo'],_0x5aafb2['_path'],_0xaa86b4,_0x5aafb2['_orderByCalled']);}}function __(_0x78d596,_0x4c7d0f){return new pa(_0x78d596,_0x4c7d0f);}class _a extends dt{constructor(_0x40bbe6,_0x7c7c92){super(),this['_value']=_0x40bbe6,this['_key']=_0x7c7c92,this['type']='startAt';}['_apply'](_0x4e5e41){qt('startAt',this['_value'],_0x4e5e41['_path'],!0x0);const _0x4b8a66=jh(_0x4e5e41['_queryParams'],this['_value'],this['_key']);if(fa(_0x4b8a66),Gn(_0x4b8a66),_0x4e5e41['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4e5e41['_repo'],_0x4e5e41['_path'],_0x4b8a66,_0x4e5e41['_orderByCalled']);}}function g_(_0x260c4d=null,_0x470064){return new _a(_0x260c4d,_0x470064);}class Ud extends dt{constructor(_0x5bfc73){super(),this['_limit']=_0x5bfc73,this['type']='limitToFirst';}['_apply'](_0x5e7c76){if(_0x5e7c76['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5e7c76['_repo'],_0x5e7c76['_path'],zh(_0x5e7c76['_queryParams'],this['_limit']),_0x5e7c76['_orderByCalled']);}}function m_(_0x573f87){if(Math['floor'](_0x573f87)!==_0x573f87||_0x573f87<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x573f87);}class Wd extends dt{constructor(_0x360575){super(),this['_path']=_0x360575,this['type']='orderByChild';}['_apply'](_0x35e7d4){da(_0x35e7d4,'orderByChild');const _0x401e94=new C(this['_path']);if(v(_0x401e94))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x187ed7=new Ki(_0x401e94),_0xd173d1=Do(_0x35e7d4['_queryParams'],_0x187ed7);return Gn(_0xd173d1),new be(_0x35e7d4['_repo'],_0x35e7d4['_path'],_0xd173d1,!0x0);}}function y_(_0x2529b8){if(_0x2529b8==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2529b8==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2529b8==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2529b8),new Wd(_0x2529b8);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2c8dc1){da(_0x2c8dc1,'orderByKey');const _0x734495=Do(_0x2c8dc1['_queryParams'],ye);return Gn(_0x734495),new be(_0x2c8dc1['_repo'],_0x2c8dc1['_path'],_0x734495,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x4b47d8,_0x3a1098){super(),this['_value']=_0x4b47d8,this['_key']=_0x3a1098,this['type']='equalTo';}['_apply'](_0x365e66){if(qt('equalTo',this['_value'],_0x365e66['_path'],!0x1),_0x365e66['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x365e66['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x365e66));}}function E_(_0x421140,_0x4fd712){return new Vd(_0x421140,_0x4fd712);}function I_(_0xd61cd2,..._0xc7dc00){let _0xcb63bb=k(_0xd61cd2);for(const _0x441b85 of _0xc7dc00)_0xcb63bb=_0x441b85['_apply'](_0xcb63bb);return _0xcb63bb;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x368dea,_0x51d1fc,_0x3d2fbf,_0x1aa5d2){const _0x4daf39=_0x51d1fc['lastIndexOf'](':'),_0x191801=_0x51d1fc['substring'](0x0,_0x4daf39),_0x160c54=Wt(_0x191801);_0x368dea['repoInfo_']=new _o(_0x51d1fc,_0x160c54,_0x368dea['repoInfo_']['namespace'],_0x368dea['repoInfo_']['webSocketOnly'],_0x368dea['repoInfo_']['nodeAdmin'],_0x368dea['repoInfo_']['persistenceKey'],_0x368dea['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3d2fbf),_0x1aa5d2&&(_0x368dea['authTokenProvider_']=_0x1aa5d2);}function qd(_0x2e5749,_0x4ba68b,_0x3d2bb5,_0x1a66e7,_0x5b51a3){let _0x36353c=_0x1a66e7||_0x2e5749['options']['databaseURL'];_0x36353c===void 0x0&&(_0x2e5749['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2e5749['options']['projectId']),_0x36353c=_0x2e5749['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x163b40=gr(_0x36353c,_0x5b51a3),_0x26541b=_0x163b40['repoInfo'],_0x498ac4;typeof process<'u'&&Us&&(_0x498ac4=Us[Hd]),_0x498ac4?(_0x36353c='http://'+_0x498ac4+'?ns='+_0x26541b['namespace'],_0x163b40=gr(_0x36353c,_0x5b51a3),_0x26541b=_0x163b40['repoInfo']):_0x163b40['repoInfo']['secure'];const _0x33ed9b=new Jl(_0x2e5749['name'],_0x2e5749['options'],_0x4ba68b);dd('Invalid\x20Firebase\x20Database\x20URL',_0x163b40),v(_0x163b40['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x17a502=jd(_0x26541b,_0x2e5749,_0x33ed9b,new Ql(_0x2e5749,_0x3d2bb5));return new Kd(_0x17a502,_0x2e5749);}function zd(_0x1aec53,_0x335c07){const _0x215879=ki[_0x335c07];(!_0x215879||_0x215879[_0x1aec53['key']]!==_0x1aec53)&&oe('Database\x20'+_0x335c07+'('+_0x1aec53['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x1aec53),delete _0x215879[_0x1aec53['key']];}function jd(_0x109856,_0x257310,_0x3ba19d,_0x37327b){let _0x4dcb56=ki[_0x257310['name']];_0x4dcb56||(_0x4dcb56={},ki[_0x257310['name']]=_0x4dcb56);let _0x575b08=_0x4dcb56[_0x109856['toURLString']()];return _0x575b08&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x575b08=new gd(_0x109856,$d,_0x3ba19d,_0x37327b),_0x4dcb56[_0x109856['toURLString']()]=_0x575b08,_0x575b08;}class Kd{constructor(_0xa2059c,_0x41cc08){this['_repoInternal']=_0xa2059c,this['app']=_0x41cc08,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2cd487){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x2cd487+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x182757=Qr(),_0x18ca4b){const _0x3d34cf=Ui(_0x182757,'database')['getImmediate']({'identifier':_0x18ca4b});if(!_0x3d34cf['_instanceStarted']){const _0x474ad9=ac('database');_0x474ad9&&Yd(_0x3d34cf,..._0x474ad9);}return _0x3d34cf;}function Yd(_0x4eca6d,_0x358f44,_0x5b0527,_0x377e0c={}){_0x4eca6d=k(_0x4eca6d),_0x4eca6d['_checkNotDeleted']('useEmulator');const _0x4887aa=_0x358f44+':'+_0x5b0527,_0x12f1b6=_0x4eca6d['_repoInternal'];if(_0x4eca6d['_instanceStarted']){if(_0x4887aa===_0x4eca6d['_repoInternal']['repoInfo_']['host']&&De(_0x377e0c,_0x12f1b6['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x394d42;if(_0x12f1b6['repoInfo_']['nodeAdmin'])_0x377e0c['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x394d42=new tn(tn['OWNER']);else{if(_0x377e0c['mockUserToken']){const _0x11cac3=typeof _0x377e0c['mockUserToken']=='string'?_0x377e0c['mockUserToken']:cc(_0x377e0c['mockUserToken'],_0x4eca6d['app']['options']['projectId']);_0x394d42=new tn(_0x11cac3);}}Wt(_0x358f44)&&jr(_0x358f44),Gd(_0x12f1b6,_0x4887aa,_0x377e0c,_0x394d42);}function C_(_0x35e961){_0x35e961=k(_0x35e961),_0x35e961['_checkNotDeleted']('goOffline'),aa(_0x35e961['_repo']);}function T_(_0x442421){_0x442421=k(_0x442421),_0x442421['_checkNotDeleted']('goOnline'),Sd(_0x442421['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x368a51){Ll(ct),et(new Me('database',(_0x3aa928,{instanceIdentifier:_0x42f0f5})=>{const _0x5970b9=_0x3aa928['getProvider']('app')['getImmediate'](),_0x39ae7a=_0x3aa928['getProvider']('auth-internal'),_0x54944b=_0x3aa928['getProvider']('app-check-internal');return qd(_0x5970b9,_0x39ae7a,_0x54944b,_0x42f0f5);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x368a51),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x2e30c8,_0x2d82fd){this['committed']=_0x2e30c8,this['snapshot']=_0x2d82fd;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x312151,_0x236e23,_0x5114e7){if(_0x312151=k(_0x312151),gs('Reference.transaction',_0x312151['_path']),_0x312151['key']==='.length'||_0x312151['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x312151['key']+'\x20is\x20a\x20read-only\x20object.';const _0x400578=!0x0,_0x3ddc3d=new Ve(),_0x5d92c8=(_0x22f0a8,_0x2660ab,_0x1d00cc)=>{let _0x70dc5f=null;_0x22f0a8?_0x3ddc3d['reject'](_0x22f0a8):(_0x70dc5f=new rt(_0x1d00cc,new Z(_0x312151['_repo'],_0x312151['_path']),R),_0x3ddc3d['resolve'](new Xd(_0x2660ab,_0x70dc5f)));},_0x4e7d5d=Fd(_0x312151,()=>{});return bd(_0x312151['_repo'],_0x312151['_path'],_0x236e23,_0x5d92c8,_0x4e7d5d,_0x400578),_0x3ddc3d['promise'];}ie['prototype']['simpleListen']=function(_0x2bd398,_0xd17eca){this['sendRequest']('q',{'p':_0x2bd398},_0xd17eca);},ie['prototype']['echo']=function(_0xebeb4f,_0x5d79dc){this['sendRequest']('echo',{'d':_0xebeb4f},_0x5d79dc);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x2714ab,..._0x2e7e7e){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x2714ab,..._0x2e7e7e);}function nn(_0x498b72,..._0x3fea69){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x498b72,..._0x3fea69);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5b829f,..._0xb29f93){throw Es(_0x5b829f,..._0xb29f93);}function J(_0x57c397,..._0x3c5ab2){return Es(_0x57c397,..._0x3c5ab2);}function ya(_0x562101,_0x41b185,_0x3d964b){const _0x10009d={...Zd(),[_0x41b185]:_0x3d964b};return new Ut('auth','Firebase',_0x10009d)['create'](_0x41b185,{'appName':_0x562101['name']});}function se(_0x157ed1){return ya(_0x157ed1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x6f9ed5,..._0x3efd04){if(typeof _0x6f9ed5!='string'){const _0x5e904d=_0x3efd04[0x0],_0x152c5d=[..._0x3efd04['slice'](0x1)];return _0x152c5d[0x0]&&(_0x152c5d[0x0]['appName']=_0x6f9ed5['name']),_0x6f9ed5['_errorFactory']['create'](_0x5e904d,..._0x152c5d);}return ma['create'](_0x6f9ed5,..._0x3efd04);}function m(_0x425b39,_0x4f2586,..._0x1b23c5){if(!_0x425b39)throw Es(_0x4f2586,..._0x1b23c5);}function te(_0x5d2a94){const _0x339c5f='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5d2a94;throw nn(_0x339c5f),new Error(_0x339c5f);}function ae(_0x336eeb,_0xff996c){_0x336eeb||te(_0xff996c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x49f41c;return typeof self<'u'&&((_0x49f41c=self['location'])==null?void 0x0:_0x49f41c['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x46bc35;return typeof self<'u'&&((_0x46bc35=self['location'])==null?void 0x0:_0x46bc35['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x1603c2=navigator;return _0x1603c2['languages']&&_0x1603c2['languages'][0x0]||_0x1603c2['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3124ee,_0x18c480){this['shortDelay']=_0x3124ee,this['longDelay']=_0x18c480,ae(_0x18c480>_0x3124ee,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x402284,_0x44bfe9){ae(_0x402284['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x39c6c3}=_0x402284['emulator'];return _0x44bfe9?''+_0x39c6c3+(_0x44bfe9['startsWith']('/')?_0x44bfe9['slice'](0x1):_0x44bfe9):_0x39c6c3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x118f0e,_0x501cc4,_0x58977f){this['fetchImpl']=_0x118f0e,_0x501cc4&&(this['headersImpl']=_0x501cc4),_0x58977f&&(this['responseImpl']=_0x58977f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x30bffc,_0x10248b){return _0x30bffc['tenantId']&&!_0x10248b['tenantId']?{..._0x10248b,'tenantId':_0x30bffc['tenantId']}:_0x10248b;}async function Ae(_0x1fcd3b,_0x5bf892,_0x1a887b,_0x7c3a24,_0x72c55b={}){return Ea(_0x1fcd3b,_0x72c55b,async()=>{let _0x5202c1={},_0x1d2944={};_0x7c3a24&&(_0x5bf892==='GET'?_0x1d2944=_0x7c3a24:_0x5202c1={'body':JSON['stringify'](_0x7c3a24)});const _0x3154b5=at({..._0x1d2944,'key':_0x1fcd3b['config']['apiKey']})['slice'](0x1),_0x1ff762=await _0x1fcd3b['_getAdditionalHeaders']();_0x1ff762['Content-Type']='application/json',_0x1fcd3b['languageCode']&&(_0x1ff762['X-Firebase-Locale']=_0x1fcd3b['languageCode']);const _0xb2b46b={'method':_0x5bf892,'headers':_0x1ff762,..._0x5202c1};return lc()||(_0xb2b46b['referrerPolicy']='strict-origin-when-cross-origin'),_0x1fcd3b['emulatorConfig']&&Wt(_0x1fcd3b['emulatorConfig']['host'])&&(_0xb2b46b['credentials']='include'),va['fetch']()(await Ia(_0x1fcd3b,_0x1fcd3b['config']['apiHost'],_0x1a887b,_0x3154b5),_0xb2b46b);});}async function Ea(_0x4111e0,_0xb72acd,_0x1629e6){_0x4111e0['_canInitEmulator']=!0x1;const _0x115fbe={...rf,..._0xb72acd};try{const _0x13f18e=new lf(_0x4111e0),_0x14962a=await Promise['race']([_0x1629e6(),_0x13f18e['promise']]);_0x13f18e['clearNetworkTimeout']();const _0x434d44=await _0x14962a['json']();if('needConfirmation'in _0x434d44)throw en(_0x4111e0,'account-exists-with-different-credential',_0x434d44);if(_0x14962a['ok']&&!('errorMessage'in _0x434d44))return _0x434d44;{const _0x22ad17=_0x14962a['ok']?_0x434d44['errorMessage']:_0x434d44['error']['message'],[_0x2982a9,_0x506b66]=_0x22ad17['split']('\x20:\x20');if(_0x2982a9==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4111e0,'credential-already-in-use',_0x434d44);if(_0x2982a9==='EMAIL_EXISTS')throw en(_0x4111e0,'email-already-in-use',_0x434d44);if(_0x2982a9==='USER_DISABLED')throw en(_0x4111e0,'user-disabled',_0x434d44);const _0x215ae2=_0x115fbe[_0x2982a9]||_0x2982a9['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x506b66)throw ya(_0x4111e0,_0x215ae2,_0x506b66);K(_0x4111e0,_0x215ae2);}}catch(_0x1f2a44){if(_0x1f2a44 instanceof Se)throw _0x1f2a44;K(_0x4111e0,'network-request-failed',{'message':String(_0x1f2a44)});}}async function Yt(_0x13d6d5,_0x42c8ce,_0x2b7644,_0x879390,_0x3bdb4d={}){const _0x36da92=await Ae(_0x13d6d5,_0x42c8ce,_0x2b7644,_0x879390,_0x3bdb4d);return'mfaPendingCredential'in _0x36da92&&K(_0x13d6d5,'multi-factor-auth-required',{'_serverResponse':_0x36da92}),_0x36da92;}async function Ia(_0x54e66e,_0x5d3671,_0x2a66f3,_0x489c0e){const _0x543bcf=''+_0x5d3671+_0x2a66f3+'?'+_0x489c0e,_0x1ee2bb=_0x54e66e,_0x5b200b=_0x1ee2bb['config']['emulator']?Is(_0x54e66e['config'],_0x543bcf):_0x54e66e['config']['apiScheme']+'://'+_0x543bcf;return of['includes'](_0x2a66f3)&&(await _0x1ee2bb['_persistenceManagerAvailable'],_0x1ee2bb['_getPersistenceType']()==='COOKIE')?_0x1ee2bb['_getPersistence']()['_getFinalTarget'](_0x5b200b)['toString']():_0x5b200b;}function cf(_0x5ef86c){switch(_0x5ef86c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x58814d){this['auth']=_0x58814d,this['timer']=null,this['promise']=new Promise((_0x3bea8f,_0x3055a5)=>{this['timer']=setTimeout(()=>_0x3055a5(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4bb620,_0x4d9f07,_0x11bb03){const _0x2a6030={'appName':_0x4bb620['name']};_0x11bb03['email']&&(_0x2a6030['email']=_0x11bb03['email']),_0x11bb03['phoneNumber']&&(_0x2a6030['phoneNumber']=_0x11bb03['phoneNumber']);const _0x577317=J(_0x4bb620,_0x4d9f07,_0x2a6030);return _0x577317['customData']['_tokenResponse']=_0x11bb03,_0x577317;}function vr(_0x5e95b9){return _0x5e95b9!==void 0x0&&_0x5e95b9['enterprise']!==void 0x0;}class hf{constructor(_0x3d8236){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3d8236['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3d8236['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3d8236['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x413784){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x18987a of this['recaptchaEnforcementState'])if(_0x18987a['provider']&&_0x18987a['provider']===_0x413784)return cf(_0x18987a['enforcementState']);return null;}['isProviderEnabled'](_0x26fc54){return this['getProviderEnforcementState'](_0x26fc54)==='ENFORCE'||this['getProviderEnforcementState'](_0x26fc54)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x167b09,_0x818614){return Ae(_0x167b09,'GET','/v2/recaptchaConfig',Re(_0x167b09,_0x818614));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x643f,_0x4538c0){return Ae(_0x643f,'POST','/v1/accounts:delete',_0x4538c0);}async function Sn(_0x3e21e3,_0x807ff0){return Ae(_0x3e21e3,'POST','/v1/accounts:lookup',_0x807ff0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x225156){if(_0x225156)try{const _0x37b1a5=new Date(Number(_0x225156));if(!isNaN(_0x37b1a5['getTime']()))return _0x37b1a5['toUTCString']();}catch{}}async function ff(_0x1e596f,_0x464775=!0x1){const _0x5014f9=k(_0x1e596f),_0x395d1b=await _0x5014f9['getIdToken'](_0x464775),_0x246e90=ws(_0x395d1b);m(_0x246e90&&_0x246e90['exp']&&_0x246e90['auth_time']&&_0x246e90['iat'],_0x5014f9['auth'],'internal-error');const _0x50f163=typeof _0x246e90['firebase']=='object'?_0x246e90['firebase']:void 0x0,_0x725431=_0x50f163==null?void 0x0:_0x50f163['sign_in_provider'];return{'claims':_0x246e90,'token':_0x395d1b,'authTime':St(ci(_0x246e90['auth_time'])),'issuedAtTime':St(ci(_0x246e90['iat'])),'expirationTime':St(ci(_0x246e90['exp'])),'signInProvider':_0x725431||null,'signInSecondFactor':(_0x50f163==null?void 0x0:_0x50f163['sign_in_second_factor'])||null};}function ci(_0x188642){return Number(_0x188642)*0x3e8;}function ws(_0x1470dc){const [_0x36cf2c,_0x155759,_0x475dcd]=_0x1470dc['split']('.');if(_0x36cf2c===void 0x0||_0x155759===void 0x0||_0x475dcd===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x11371c=cn(_0x155759);return _0x11371c?JSON['parse'](_0x11371c):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x455e74){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x455e74==null?void 0x0:_0x455e74['toString']()),null;}}function Er(_0x587059){const _0x16f470=ws(_0x587059);return m(_0x16f470,'internal-error'),m(typeof _0x16f470['exp']<'u','internal-error'),m(typeof _0x16f470['iat']<'u','internal-error'),Number(_0x16f470['exp'])-Number(_0x16f470['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x3a6be8,_0x3c4614,_0x3d80d1=!0x1){if(_0x3d80d1)return _0x3c4614;try{return await _0x3c4614;}catch(_0x12630b){throw _0x12630b instanceof Se&&pf(_0x12630b)&&_0x3a6be8['auth']['currentUser']===_0x3a6be8&&await _0x3a6be8['auth']['signOut'](),_0x12630b;}}function pf({code:_0x5c1564}){return _0x5c1564==='auth/user-disabled'||_0x5c1564==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x210c15){this['user']=_0x210c15,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x93841){if(_0x93841){const _0x25eed4=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x25eed4;}else{this['errorBackoff']=0x7530;const _0x6b1b8f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x6b1b8f);}}['schedule'](_0xf08e6=!0x1){if(!this['isRunning'])return;const _0x502d98=this['getInterval'](_0xf08e6);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x502d98);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5e2d69){(_0x5e2d69==null?void 0x0:_0x5e2d69['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5c20f4,_0x8289d1){this['createdAt']=_0x5c20f4,this['lastLoginAt']=_0x8289d1,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x153e05){this['createdAt']=_0x153e05['createdAt'],this['lastLoginAt']=_0x153e05['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5b02dd){var _0x1c2180;const _0x9af40e=_0x5b02dd['auth'],_0x434e91=await _0x5b02dd['getIdToken'](),_0x2cf3bd=await xt(_0x5b02dd,Sn(_0x9af40e,{'idToken':_0x434e91}));m(_0x2cf3bd==null?void 0x0:_0x2cf3bd['users']['length'],_0x9af40e,'internal-error');const _0x1d3495=_0x2cf3bd['users'][0x0];_0x5b02dd['_notifyReloadListener'](_0x1d3495);const _0x24a036=(_0x1c2180=_0x1d3495['providerUserInfo'])!=null&&_0x1c2180['length']?wa(_0x1d3495['providerUserInfo']):[],_0x6fc5af=mf(_0x5b02dd['providerData'],_0x24a036),_0x4a657b=_0x5b02dd['isAnonymous'],_0x11204c=!(_0x5b02dd['email']&&_0x1d3495['passwordHash'])&&!(_0x6fc5af!=null&&_0x6fc5af['length']),_0x41c539=_0x4a657b?_0x11204c:!0x1,_0x275723={'uid':_0x1d3495['localId'],'displayName':_0x1d3495['displayName']||null,'photoURL':_0x1d3495['photoUrl']||null,'email':_0x1d3495['email']||null,'emailVerified':_0x1d3495['emailVerified']||!0x1,'phoneNumber':_0x1d3495['phoneNumber']||null,'tenantId':_0x1d3495['tenantId']||null,'providerData':_0x6fc5af,'metadata':new Pi(_0x1d3495['createdAt'],_0x1d3495['lastLoginAt']),'isAnonymous':_0x41c539};Object['assign'](_0x5b02dd,_0x275723);}async function gf(_0x14357a){const _0x2a2b95=k(_0x14357a);await bn(_0x2a2b95),await _0x2a2b95['auth']['_persistUserIfCurrent'](_0x2a2b95),_0x2a2b95['auth']['_notifyListenersIfCurrent'](_0x2a2b95);}function mf(_0x586048,_0x1a0e39){return[..._0x586048['filter'](_0x46e750=>!_0x1a0e39['some'](_0x2b2d6b=>_0x2b2d6b['providerId']===_0x46e750['providerId'])),..._0x1a0e39];}function wa(_0x557dc3){return _0x557dc3['map'](({providerId:_0x4c8d7e,..._0x530055})=>({'providerId':_0x4c8d7e,'uid':_0x530055['rawId']||'','displayName':_0x530055['displayName']||null,'email':_0x530055['email']||null,'phoneNumber':_0x530055['phoneNumber']||null,'photoURL':_0x530055['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x15f66a,_0x5001a3){const _0x18ef0a=await Ea(_0x15f66a,{},async()=>{const _0x30d405=at({'grant_type':'refresh_token','refresh_token':_0x5001a3})['slice'](0x1),{tokenApiHost:_0x1dd481,apiKey:_0x1d2838}=_0x15f66a['config'],_0x3ae531=await Ia(_0x15f66a,_0x1dd481,'/v1/token','key='+_0x1d2838),_0x5944c4=await _0x15f66a['_getAdditionalHeaders']();_0x5944c4['Content-Type']='application/x-www-form-urlencoded';const _0x1fddb3={'method':'POST','headers':_0x5944c4,'body':_0x30d405};return _0x15f66a['emulatorConfig']&&Wt(_0x15f66a['emulatorConfig']['host'])&&(_0x1fddb3['credentials']='include'),va['fetch']()(_0x3ae531,_0x1fddb3);});return{'accessToken':_0x18ef0a['access_token'],'expiresIn':_0x18ef0a['expires_in'],'refreshToken':_0x18ef0a['refresh_token']};}async function vf(_0x4600f4,_0x33a637){return Ae(_0x4600f4,'POST','/v2/accounts:revokeToken',Re(_0x4600f4,_0x33a637));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x311659){m(_0x311659['idToken'],'internal-error'),m(typeof _0x311659['idToken']<'u','internal-error'),m(typeof _0x311659['refreshToken']<'u','internal-error');const _0x4a2d2c='expiresIn'in _0x311659&&typeof _0x311659['expiresIn']<'u'?Number(_0x311659['expiresIn']):Er(_0x311659['idToken']);this['updateTokensAndExpiration'](_0x311659['idToken'],_0x311659['refreshToken'],_0x4a2d2c);}['updateFromIdToken'](_0x1ecf46){m(_0x1ecf46['length']!==0x0,'internal-error');const _0x4f00f6=Er(_0x1ecf46);this['updateTokensAndExpiration'](_0x1ecf46,null,_0x4f00f6);}async['getToken'](_0x5126e5,_0xa67ed3=!0x1){return!_0xa67ed3&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5126e5,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5126e5,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1592f0,_0x2b188c){const {accessToken:_0x2ffb65,refreshToken:_0x45230,expiresIn:_0x53ede3}=await yf(_0x1592f0,_0x2b188c);this['updateTokensAndExpiration'](_0x2ffb65,_0x45230,Number(_0x53ede3));}['updateTokensAndExpiration'](_0x421638,_0xd8cdb6,_0x445642){this['refreshToken']=_0xd8cdb6||null,this['accessToken']=_0x421638||null,this['expirationTime']=Date['now']()+_0x445642*0x3e8;}static['fromJSON'](_0x1b25ee,_0x792747){const {refreshToken:_0x177bf6,accessToken:_0x3c72e0,expirationTime:_0x1a8933}=_0x792747,_0x325259=new Je();return _0x177bf6&&(m(typeof _0x177bf6=='string','internal-error',{'appName':_0x1b25ee}),_0x325259['refreshToken']=_0x177bf6),_0x3c72e0&&(m(typeof _0x3c72e0=='string','internal-error',{'appName':_0x1b25ee}),_0x325259['accessToken']=_0x3c72e0),_0x1a8933&&(m(typeof _0x1a8933=='number','internal-error',{'appName':_0x1b25ee}),_0x325259['expirationTime']=_0x1a8933),_0x325259;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5ba12f){this['accessToken']=_0x5ba12f['accessToken'],this['refreshToken']=_0x5ba12f['refreshToken'],this['expirationTime']=_0x5ba12f['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5b57d0,_0x21619a){m(typeof _0x5b57d0=='string'||typeof _0x5b57d0>'u','internal-error',{'appName':_0x21619a});}class z{constructor({uid:_0x27bf0e,auth:_0x57ced8,stsTokenManager:_0x220163,..._0x381774}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x27bf0e,this['auth']=_0x57ced8,this['stsTokenManager']=_0x220163,this['accessToken']=_0x220163['accessToken'],this['displayName']=_0x381774['displayName']||null,this['email']=_0x381774['email']||null,this['emailVerified']=_0x381774['emailVerified']||!0x1,this['phoneNumber']=_0x381774['phoneNumber']||null,this['photoURL']=_0x381774['photoURL']||null,this['isAnonymous']=_0x381774['isAnonymous']||!0x1,this['tenantId']=_0x381774['tenantId']||null,this['providerData']=_0x381774['providerData']?[..._0x381774['providerData']]:[],this['metadata']=new Pi(_0x381774['createdAt']||void 0x0,_0x381774['lastLoginAt']||void 0x0);}async['getIdToken'](_0x106efb){const _0x2bdc16=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x106efb));return m(_0x2bdc16,this['auth'],'internal-error'),this['accessToken']!==_0x2bdc16&&(this['accessToken']=_0x2bdc16,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2bdc16;}['getIdTokenResult'](_0x45cd61){return ff(this,_0x45cd61);}['reload'](){return gf(this);}['_assign'](_0xcec370){this!==_0xcec370&&(m(this['uid']===_0xcec370['uid'],this['auth'],'internal-error'),this['displayName']=_0xcec370['displayName'],this['photoURL']=_0xcec370['photoURL'],this['email']=_0xcec370['email'],this['emailVerified']=_0xcec370['emailVerified'],this['phoneNumber']=_0xcec370['phoneNumber'],this['isAnonymous']=_0xcec370['isAnonymous'],this['tenantId']=_0xcec370['tenantId'],this['providerData']=_0xcec370['providerData']['map'](_0x43c16a=>({..._0x43c16a})),this['metadata']['_copy'](_0xcec370['metadata']),this['stsTokenManager']['_assign'](_0xcec370['stsTokenManager']));}['_clone'](_0x681b7d){const _0x2e9c77=new z({...this,'auth':_0x681b7d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2e9c77['metadata']['_copy'](this['metadata']),_0x2e9c77;}['_onReload'](_0x73493){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x73493,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2953a6){this['reloadListener']?this['reloadListener'](_0x2953a6):this['reloadUserInfo']=_0x2953a6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x58b0d6,_0x2d3570=!0x1){let _0x516da7=!0x1;_0x58b0d6['idToken']&&_0x58b0d6['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x58b0d6),_0x516da7=!0x0),_0x2d3570&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x516da7&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2a5fa6=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2a5fa6})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x56045b=>({..._0x56045b})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x50abfd,_0x2a0bdd){const _0x4d6bd8=_0x2a0bdd['displayName']??void 0x0,_0x47c0e8=_0x2a0bdd['email']??void 0x0,_0x1e01fb=_0x2a0bdd['phoneNumber']??void 0x0,_0x40c92d=_0x2a0bdd['photoURL']??void 0x0,_0x2b1eaf=_0x2a0bdd['tenantId']??void 0x0,_0x4b498a=_0x2a0bdd['_redirectEventId']??void 0x0,_0x468686=_0x2a0bdd['createdAt']??void 0x0,_0x54a48c=_0x2a0bdd['lastLoginAt']??void 0x0,{uid:_0x2ff2bc,emailVerified:_0x3890e3,isAnonymous:_0x186dae,providerData:_0x33f80f,stsTokenManager:_0x4db35a}=_0x2a0bdd;m(_0x2ff2bc&&_0x4db35a,_0x50abfd,'internal-error');const _0x315c71=Je['fromJSON'](this['name'],_0x4db35a);m(typeof _0x2ff2bc=='string',_0x50abfd,'internal-error'),ce(_0x4d6bd8,_0x50abfd['name']),ce(_0x47c0e8,_0x50abfd['name']),m(typeof _0x3890e3=='boolean',_0x50abfd,'internal-error'),m(typeof _0x186dae=='boolean',_0x50abfd,'internal-error'),ce(_0x1e01fb,_0x50abfd['name']),ce(_0x40c92d,_0x50abfd['name']),ce(_0x2b1eaf,_0x50abfd['name']),ce(_0x4b498a,_0x50abfd['name']),ce(_0x468686,_0x50abfd['name']),ce(_0x54a48c,_0x50abfd['name']);const _0x4bf762=new z({'uid':_0x2ff2bc,'auth':_0x50abfd,'email':_0x47c0e8,'emailVerified':_0x3890e3,'displayName':_0x4d6bd8,'isAnonymous':_0x186dae,'photoURL':_0x40c92d,'phoneNumber':_0x1e01fb,'tenantId':_0x2b1eaf,'stsTokenManager':_0x315c71,'createdAt':_0x468686,'lastLoginAt':_0x54a48c});return _0x33f80f&&Array['isArray'](_0x33f80f)&&(_0x4bf762['providerData']=_0x33f80f['map'](_0x47672e=>({..._0x47672e}))),_0x4b498a&&(_0x4bf762['_redirectEventId']=_0x4b498a),_0x4bf762;}static async['_fromIdTokenResponse'](_0x164bb4,_0x288eea,_0x30fdfa=!0x1){const _0x3a6624=new Je();_0x3a6624['updateFromServerResponse'](_0x288eea);const _0x328b81=new z({'uid':_0x288eea['localId'],'auth':_0x164bb4,'stsTokenManager':_0x3a6624,'isAnonymous':_0x30fdfa});return await bn(_0x328b81),_0x328b81;}static async['_fromGetAccountInfoResponse'](_0x330f27,_0x546f58,_0x2c744c){const _0x169b09=_0x546f58['users'][0x0];m(_0x169b09['localId']!==void 0x0,'internal-error');const _0x2aff1c=_0x169b09['providerUserInfo']!==void 0x0?wa(_0x169b09['providerUserInfo']):[],_0x978cba=!(_0x169b09['email']&&_0x169b09['passwordHash'])&&!(_0x2aff1c!=null&&_0x2aff1c['length']),_0x4e0cce=new Je();_0x4e0cce['updateFromIdToken'](_0x2c744c);const _0xd7b6fb=new z({'uid':_0x169b09['localId'],'auth':_0x330f27,'stsTokenManager':_0x4e0cce,'isAnonymous':_0x978cba}),_0x305ee4={'uid':_0x169b09['localId'],'displayName':_0x169b09['displayName']||null,'photoURL':_0x169b09['photoUrl']||null,'email':_0x169b09['email']||null,'emailVerified':_0x169b09['emailVerified']||!0x1,'phoneNumber':_0x169b09['phoneNumber']||null,'tenantId':_0x169b09['tenantId']||null,'providerData':_0x2aff1c,'metadata':new Pi(_0x169b09['createdAt'],_0x169b09['lastLoginAt']),'isAnonymous':!(_0x169b09['email']&&_0x169b09['passwordHash'])&&!(_0x2aff1c!=null&&_0x2aff1c['length'])};return Object['assign'](_0xd7b6fb,_0x305ee4),_0xd7b6fb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x3151a6){ae(_0x3151a6 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5af31b=Ir['get'](_0x3151a6);return _0x5af31b?(ae(_0x5af31b instanceof _0x3151a6,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5af31b):(_0x5af31b=new _0x3151a6(),Ir['set'](_0x3151a6,_0x5af31b),_0x5af31b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x263c46,_0x3bb89e){this['storage'][_0x263c46]=_0x3bb89e;}async['_get'](_0x2e4426){const _0x4d9ca5=this['storage'][_0x2e4426];return _0x4d9ca5===void 0x0?null:_0x4d9ca5;}async['_remove'](_0x46a666){delete this['storage'][_0x46a666];}['_addListener'](_0x37f465,_0x349821){}['_removeListener'](_0x231291,_0x22afc7){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0xfdb15c,_0x5d9217,_0x5946ad){return'firebase:'+_0xfdb15c+':'+_0x5d9217+':'+_0x5946ad;}class Xe{constructor(_0x2fbd0b,_0x12a079,_0x3864cd){this['persistence']=_0x2fbd0b,this['auth']=_0x12a079,this['userKey']=_0x3864cd;const {config:_0x5f5687,name:_0x469fca}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x5f5687['apiKey'],_0x469fca),this['fullPersistenceKey']=sn('persistence',_0x5f5687['apiKey'],_0x469fca),this['boundEventHandler']=_0x12a079['_onStorageEvent']['bind'](_0x12a079),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x503bf4){return this['persistence']['_set'](this['fullUserKey'],_0x503bf4['toJSON']());}async['getCurrentUser'](){const _0x4b7cb2=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4b7cb2)return null;if(typeof _0x4b7cb2=='string'){const _0x1ff4f8=await Sn(this['auth'],{'idToken':_0x4b7cb2})['catch'](()=>{});return _0x1ff4f8?z['_fromGetAccountInfoResponse'](this['auth'],_0x1ff4f8,_0x4b7cb2):null;}return z['_fromJSON'](this['auth'],_0x4b7cb2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x20ac91){if(this['persistence']===_0x20ac91)return;const _0x50064a=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x20ac91,_0x50064a)return this['setCurrentUser'](_0x50064a);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x35a2a6,_0x5c0061,_0x641cf9='authUser'){if(!_0x5c0061['length'])return new Xe(ne(wr),_0x35a2a6,_0x641cf9);const _0x25751f=(await Promise['all'](_0x5c0061['map'](async _0x1f95e5=>{if(await _0x1f95e5['_isAvailable']())return _0x1f95e5;})))['filter'](_0x47bf0f=>_0x47bf0f);let _0x463217=_0x25751f[0x0]||ne(wr);const _0x51cc00=sn(_0x641cf9,_0x35a2a6['config']['apiKey'],_0x35a2a6['name']);let _0x113c48=null;for(const _0xc38cad of _0x5c0061)try{const _0x368a9a=await _0xc38cad['_get'](_0x51cc00);if(_0x368a9a){let _0x1373a5;if(typeof _0x368a9a=='string'){const _0x2dfd6d=await Sn(_0x35a2a6,{'idToken':_0x368a9a})['catch'](()=>{});if(!_0x2dfd6d)break;_0x1373a5=await z['_fromGetAccountInfoResponse'](_0x35a2a6,_0x2dfd6d,_0x368a9a);}else _0x1373a5=z['_fromJSON'](_0x35a2a6,_0x368a9a);_0xc38cad!==_0x463217&&(_0x113c48=_0x1373a5),_0x463217=_0xc38cad;break;}}catch{}const _0x30258c=_0x25751f['filter'](_0x46fc64=>_0x46fc64['_shouldAllowMigration']);return!_0x463217['_shouldAllowMigration']||!_0x30258c['length']?new Xe(_0x463217,_0x35a2a6,_0x641cf9):(_0x463217=_0x30258c[0x0],_0x113c48&&await _0x463217['_set'](_0x51cc00,_0x113c48['toJSON']()),await Promise['all'](_0x5c0061['map'](async _0x309b78=>{if(_0x309b78!==_0x463217)try{await _0x309b78['_remove'](_0x51cc00);}catch{}})),new Xe(_0x463217,_0x35a2a6,_0x641cf9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x56131a){const _0x6d97cc=_0x56131a['toLowerCase']();if(_0x6d97cc['includes']('opera/')||_0x6d97cc['includes']('opr/')||_0x6d97cc['includes']('opios/'))return'Opera';if(Ra(_0x6d97cc))return'IEMobile';if(_0x6d97cc['includes']('msie')||_0x6d97cc['includes']('trident/'))return'IE';if(_0x6d97cc['includes']('edge/'))return'Edge';if(Ta(_0x6d97cc))return'Firefox';if(_0x6d97cc['includes']('silk/'))return'Silk';if(ka(_0x6d97cc))return'Blackberry';if(Na(_0x6d97cc))return'Webos';if(Sa(_0x6d97cc))return'Safari';if((_0x6d97cc['includes']('chrome/')||ba(_0x6d97cc))&&!_0x6d97cc['includes']('edge/'))return'Chrome';if(Aa(_0x6d97cc))return'Android';{const _0x41417a=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5b8f48=_0x56131a['match'](_0x41417a);if((_0x5b8f48==null?void 0x0:_0x5b8f48['length'])===0x2)return _0x5b8f48[0x1];}return'Other';}function Ta(_0x134987=W()){return/firefox\//i['test'](_0x134987);}function Sa(_0x2e1d43=W()){const _0xb35ab=_0x2e1d43['toLowerCase']();return _0xb35ab['includes']('safari/')&&!_0xb35ab['includes']('chrome/')&&!_0xb35ab['includes']('crios/')&&!_0xb35ab['includes']('android');}function ba(_0x372c62=W()){return/crios\//i['test'](_0x372c62);}function Ra(_0x382e4a=W()){return/iemobile/i['test'](_0x382e4a);}function Aa(_0x113ace=W()){return/android/i['test'](_0x113ace);}function ka(_0x37ad4e=W()){return/blackberry/i['test'](_0x37ad4e);}function Na(_0x6c8e1c=W()){return/webos/i['test'](_0x6c8e1c);}function Cs(_0x189369=W()){return/iphone|ipad|ipod/i['test'](_0x189369)||/macintosh/i['test'](_0x189369)&&/mobile/i['test'](_0x189369);}function Ef(_0x21927d=W()){var _0x2d5cb2;return Cs(_0x21927d)&&!!((_0x2d5cb2=window['navigator'])!=null&&_0x2d5cb2['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5c08b7=W()){return Cs(_0x5c08b7)||Aa(_0x5c08b7)||Na(_0x5c08b7)||ka(_0x5c08b7)||/windows phone/i['test'](_0x5c08b7)||Ra(_0x5c08b7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x44b530,_0x186a52=[]){let _0x3f57c4;switch(_0x44b530){case'Browser':_0x3f57c4=Cr(W());break;case'Worker':_0x3f57c4=Cr(W())+'-'+_0x44b530;break;default:_0x3f57c4=_0x44b530;}const _0x4582a6=_0x186a52['length']?_0x186a52['join'](','):'FirebaseCore-web';return _0x3f57c4+'/JsCore/'+ct+'/'+_0x4582a6;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2b42ad){this['auth']=_0x2b42ad,this['queue']=[];}['pushCallback'](_0x18e9ce,_0x3bd311){const _0x1804a5=_0x48d1dc=>new Promise((_0x45fa5c,_0x3c5b55)=>{try{const _0x1119b8=_0x18e9ce(_0x48d1dc);_0x45fa5c(_0x1119b8);}catch(_0x4a7553){_0x3c5b55(_0x4a7553);}});_0x1804a5['onAbort']=_0x3bd311,this['queue']['push'](_0x1804a5);const _0x5a7746=this['queue']['length']-0x1;return()=>{this['queue'][_0x5a7746]=()=>Promise['resolve']();};}async['runMiddleware'](_0x34968b){if(this['auth']['currentUser']===_0x34968b)return;const _0x15429a=[];try{for(const _0x5879d6 of this['queue'])await _0x5879d6(_0x34968b),_0x5879d6['onAbort']&&_0x15429a['push'](_0x5879d6['onAbort']);}catch(_0x5e20c3){_0x15429a['reverse']();for(const _0x4fe090 of _0x15429a)try{_0x4fe090();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5e20c3==null?void 0x0:_0x5e20c3['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5b066f,_0x2d9249={}){return Ae(_0x5b066f,'GET','/v2/passwordPolicy',Re(_0x5b066f,_0x2d9249));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x25e9af){var _0x3f175d;const _0x2b8680=_0x25e9af['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2b8680['minPasswordLength']??Tf,_0x2b8680['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2b8680['maxPasswordLength']),_0x2b8680['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2b8680['containsLowercaseCharacter']),_0x2b8680['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2b8680['containsUppercaseCharacter']),_0x2b8680['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2b8680['containsNumericCharacter']),_0x2b8680['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2b8680['containsNonAlphanumericCharacter']),this['enforcementState']=_0x25e9af['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3f175d=_0x25e9af['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3f175d['join'](''))??'',this['forceUpgradeOnSignin']=_0x25e9af['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x25e9af['schemaVersion'];}['validatePassword'](_0x226566){const _0xea2e43={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x226566,_0xea2e43),this['validatePasswordCharacterOptions'](_0x226566,_0xea2e43),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['meetsMinPasswordLength']??!0x0),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['meetsMaxPasswordLength']??!0x0),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['containsLowercaseLetter']??!0x0),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['containsUppercaseLetter']??!0x0),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['containsNumericCharacter']??!0x0),_0xea2e43['isValid']&&(_0xea2e43['isValid']=_0xea2e43['containsNonAlphanumericCharacter']??!0x0),_0xea2e43;}['validatePasswordLengthOptions'](_0x5c6dec,_0x446d74){const _0x1e3e08=this['customStrengthOptions']['minPasswordLength'],_0x36c5f6=this['customStrengthOptions']['maxPasswordLength'];_0x1e3e08&&(_0x446d74['meetsMinPasswordLength']=_0x5c6dec['length']>=_0x1e3e08),_0x36c5f6&&(_0x446d74['meetsMaxPasswordLength']=_0x5c6dec['length']<=_0x36c5f6);}['validatePasswordCharacterOptions'](_0x315523,_0x3d8f8b){this['updatePasswordCharacterOptionsStatuses'](_0x3d8f8b,!0x1,!0x1,!0x1,!0x1);let _0x5cbafd;for(let _0x545e5b=0x0;_0x545e5b<_0x315523['length'];_0x545e5b++)_0x5cbafd=_0x315523['charAt'](_0x545e5b),this['updatePasswordCharacterOptionsStatuses'](_0x3d8f8b,_0x5cbafd>='a'&&_0x5cbafd<='z',_0x5cbafd>='A'&&_0x5cbafd<='Z',_0x5cbafd>='0'&&_0x5cbafd<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5cbafd));}['updatePasswordCharacterOptionsStatuses'](_0x127103,_0x98915d,_0x1cf442,_0x3d5aa4,_0x4ee820){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x127103['containsLowercaseLetter']||(_0x127103['containsLowercaseLetter']=_0x98915d)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x127103['containsUppercaseLetter']||(_0x127103['containsUppercaseLetter']=_0x1cf442)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x127103['containsNumericCharacter']||(_0x127103['containsNumericCharacter']=_0x3d5aa4)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x127103['containsNonAlphanumericCharacter']||(_0x127103['containsNonAlphanumericCharacter']=_0x4ee820));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3b5833,_0x32bf01,_0x551456,_0x182123){this['app']=_0x3b5833,this['heartbeatServiceProvider']=_0x32bf01,this['appCheckServiceProvider']=_0x551456,this['config']=_0x182123,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3b5833['name'],this['clientVersion']=_0x182123['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4540af=>this['_resolvePersistenceManagerAvailable']=_0x4540af);}['_initializeWithPersistence'](_0x2499f2,_0x24b01e){return _0x24b01e&&(this['_popupRedirectResolver']=ne(_0x24b01e)),this['_initializationPromise']=this['queue'](async()=>{var _0x1a2cb8,_0x4498a4,_0x20cd69;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x2499f2),(_0x1a2cb8=this['_resolvePersistenceManagerAvailable'])==null||_0x1a2cb8['call'](this),!this['_deleted'])){if((_0x4498a4=this['_popupRedirectResolver'])!=null&&_0x4498a4['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x24b01e),this['lastNotifiedUid']=((_0x20cd69=this['currentUser'])==null?void 0x0:_0x20cd69['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1899b9=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1899b9)){if(this['currentUser']&&_0x1899b9&&this['currentUser']['uid']===_0x1899b9['uid']){this['_currentUser']['_assign'](_0x1899b9),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1899b9,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5a1f00){try{const _0x4d4752=await Sn(this,{'idToken':_0x5a1f00}),_0x403814=await z['_fromGetAccountInfoResponse'](this,_0x4d4752,_0x5a1f00);await this['directlySetCurrentUser'](_0x403814);}catch(_0x113947){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x113947),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x435388){var _0x51f645;if(H(this['app'])){const _0x54dd05=this['app']['settings']['authIdToken'];return _0x54dd05?new Promise(_0x48559b=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x54dd05)['then'](_0x48559b,_0x48559b));}):this['directlySetCurrentUser'](null);}const _0x4bac52=await this['assertedPersistence']['getCurrentUser']();let _0x534f16=_0x4bac52,_0x2a9949=!0x1;if(_0x435388&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5ea092=(_0x51f645=this['redirectUser'])==null?void 0x0:_0x51f645['_redirectEventId'],_0x2efb9d=_0x534f16==null?void 0x0:_0x534f16['_redirectEventId'],_0x1f8f45=await this['tryRedirectSignIn'](_0x435388);(!_0x5ea092||_0x5ea092===_0x2efb9d)&&(_0x1f8f45!=null&&_0x1f8f45['user'])&&(_0x534f16=_0x1f8f45['user'],_0x2a9949=!0x0);}if(!_0x534f16)return this['directlySetCurrentUser'](null);if(!_0x534f16['_redirectEventId']){if(_0x2a9949)try{await this['beforeStateQueue']['runMiddleware'](_0x534f16);}catch(_0x4b1915){_0x534f16=_0x4bac52,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4b1915));}return _0x534f16?this['reloadAndSetCurrentUserOrClear'](_0x534f16):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x534f16['_redirectEventId']?this['directlySetCurrentUser'](_0x534f16):this['reloadAndSetCurrentUserOrClear'](_0x534f16);}async['tryRedirectSignIn'](_0x3246d3){let _0x4bd39c=null;try{_0x4bd39c=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3246d3,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4bd39c;}async['reloadAndSetCurrentUserOrClear'](_0x2f0893){try{await bn(_0x2f0893);}catch(_0x9715ae){if((_0x9715ae==null?void 0x0:_0x9715ae['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2f0893);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x38f9c6){if(H(this['app']))return Promise['reject'](se(this));const _0x267119=_0x38f9c6?k(_0x38f9c6):null;return _0x267119&&m(_0x267119['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x267119&&_0x267119['_clone'](this));}async['_updateCurrentUser'](_0x2839e4,_0x4371b2=!0x1){if(!this['_deleted'])return _0x2839e4&&m(this['tenantId']===_0x2839e4['tenantId'],this,'tenant-id-mismatch'),_0x4371b2||await this['beforeStateQueue']['runMiddleware'](_0x2839e4),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2839e4),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x267520){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x267520));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1d6143){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x82260b=this['_getPasswordPolicyInternal']();return _0x82260b['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x82260b['validatePassword'](_0x1d6143);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x20f877=await Cf(this),_0x4d04f4=new Sf(_0x20f877);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4d04f4:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4d04f4;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1ea2ca){this['_errorFactory']=new Ut('auth','Firebase',_0x1ea2ca());}['onAuthStateChanged'](_0x4d91be,_0x17efbf,_0x3be850){return this['registerStateListener'](this['authStateSubscription'],_0x4d91be,_0x17efbf,_0x3be850);}['beforeAuthStateChanged'](_0x1086f8,_0x25fbd6){return this['beforeStateQueue']['pushCallback'](_0x1086f8,_0x25fbd6);}['onIdTokenChanged'](_0x1e37fd,_0x3acc9e,_0x214213){return this['registerStateListener'](this['idTokenSubscription'],_0x1e37fd,_0x3acc9e,_0x214213);}['authStateReady'](){return new Promise((_0x4a6c07,_0x21e9b8)=>{if(this['currentUser'])_0x4a6c07();else{const _0x256a29=this['onAuthStateChanged'](()=>{_0x256a29(),_0x4a6c07();},_0x21e9b8);}});}async['revokeAccessToken'](_0x398524){if(this['currentUser']){const _0x23eb3e=await this['currentUser']['getIdToken'](),_0x32a50a={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x398524,'idToken':_0x23eb3e};this['tenantId']!=null&&(_0x32a50a['tenantId']=this['tenantId']),await vf(this,_0x32a50a);}}['toJSON'](){var _0x2f3b37;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2f3b37=this['_currentUser'])==null?void 0x0:_0x2f3b37['toJSON']()};}async['_setRedirectUser'](_0x5031fa,_0x3de479){const _0x59dd08=await this['getOrInitRedirectPersistenceManager'](_0x3de479);return _0x5031fa===null?_0x59dd08['removeCurrentUser']():_0x59dd08['setCurrentUser'](_0x5031fa);}async['getOrInitRedirectPersistenceManager'](_0x36ff18){if(!this['redirectPersistenceManager']){const _0x4377a7=_0x36ff18&&ne(_0x36ff18)||this['_popupRedirectResolver'];m(_0x4377a7,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4377a7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x14922c){var _0x3d0ed3,_0x4559af;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3d0ed3=this['_currentUser'])==null?void 0x0:_0x3d0ed3['_redirectEventId'])===_0x14922c?this['_currentUser']:((_0x4559af=this['redirectUser'])==null?void 0x0:_0x4559af['_redirectEventId'])===_0x14922c?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x542eee){if(_0x542eee===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x542eee));}['_notifyListenersIfCurrent'](_0x2b9b34){_0x2b9b34===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x20537d;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x22dc59=((_0x20537d=this['currentUser'])==null?void 0x0:_0x20537d['uid'])??null;this['lastNotifiedUid']!==_0x22dc59&&(this['lastNotifiedUid']=_0x22dc59,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5b87bf,_0x41fc22,_0x191975,_0x1af430){if(this['_deleted'])return()=>{};const _0x548556=typeof _0x41fc22=='function'?_0x41fc22:_0x41fc22['next']['bind'](_0x41fc22);let _0x49ed36=!0x1;const _0x42ef8f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x42ef8f,this,'internal-error'),_0x42ef8f['then'](()=>{_0x49ed36||_0x548556(this['currentUser']);}),typeof _0x41fc22=='function'){const _0x71d4e1=_0x5b87bf['addObserver'](_0x41fc22,_0x191975,_0x1af430);return()=>{_0x49ed36=!0x0,_0x71d4e1();};}else{const _0x358d84=_0x5b87bf['addObserver'](_0x41fc22);return()=>{_0x49ed36=!0x0,_0x358d84();};}}async['directlySetCurrentUser'](_0x4c8c94){this['currentUser']&&this['currentUser']!==_0x4c8c94&&this['_currentUser']['_stopProactiveRefresh'](),_0x4c8c94&&this['isProactiveRefreshEnabled']&&_0x4c8c94['_startProactiveRefresh'](),this['currentUser']=_0x4c8c94,_0x4c8c94?await this['assertedPersistence']['setCurrentUser'](_0x4c8c94):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5ef081){return this['operations']=this['operations']['then'](_0x5ef081,_0x5ef081),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4e9e86){!_0x4e9e86||this['frameworks']['includes'](_0x4e9e86)||(this['frameworks']['push'](_0x4e9e86),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x198df3;const _0x5f3f48={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5f3f48['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4a51cc=await((_0x198df3=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x198df3['getHeartbeatsHeader']());_0x4a51cc&&(_0x5f3f48['X-Firebase-Client']=_0x4a51cc);const _0x39da54=await this['_getAppCheckToken']();return _0x39da54&&(_0x5f3f48['X-Firebase-AppCheck']=_0x39da54),_0x5f3f48;}async['_getAppCheckToken'](){var _0x3ef461;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xc396ac=await((_0x3ef461=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3ef461['getToken']());return _0xc396ac!=null&&_0xc396ac['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xc396ac['error']),_0xc396ac==null?void 0x0:_0xc396ac['token'];}}function qe(_0x285661){return k(_0x285661);}class Tr{constructor(_0x3e8ee9){this['auth']=_0x3e8ee9,this['observer']=null,this['addObserver']=Ic(_0x8e7588=>this['observer']=_0x8e7588);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x1e2c00){zn=_0x1e2c00;}function Da(_0x5df427){return zn['loadJS'](_0x5df427);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x27d4bf){return'__'+_0x27d4bf+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x5710b7){_0x5710b7();}['execute'](_0x2937f8,_0x5a0b4b){return Promise['resolve']('token');}['render'](_0x375da5,_0x5e97e2){return'';}}class Of{['ready'](_0x5f0c84){_0x5f0c84();}['execute'](_0x164d45,_0x464ee5){return Promise['resolve']('token');}['render'](_0x52cc93,_0x182ee9){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0xd9a01e){this['type']=Df,this['auth']=qe(_0xd9a01e);}async['verify'](_0x288923='verify',_0x2eb2a1=!0x1){async function _0x10059e(_0x240f93){if(!_0x2eb2a1){if(_0x240f93['tenantId']==null&&_0x240f93['_agentRecaptchaConfig']!=null)return _0x240f93['_agentRecaptchaConfig']['siteKey'];if(_0x240f93['tenantId']!=null&&_0x240f93['_tenantRecaptchaConfigs'][_0x240f93['tenantId']]!==void 0x0)return _0x240f93['_tenantRecaptchaConfigs'][_0x240f93['tenantId']]['siteKey'];}return new Promise(async(_0x50439d,_0x37224c)=>{uf(_0x240f93,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x8dccd7=>{if(_0x8dccd7['recaptchaKey']===void 0x0)_0x37224c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x454301=new hf(_0x8dccd7);return _0x240f93['tenantId']==null?_0x240f93['_agentRecaptchaConfig']=_0x454301:_0x240f93['_tenantRecaptchaConfigs'][_0x240f93['tenantId']]=_0x454301,_0x50439d(_0x454301['siteKey']);}})['catch'](_0x5c2cc9=>{_0x37224c(_0x5c2cc9);});});}function _0x372abd(_0x20e775,_0x1fb7a3,_0x42a587){const _0x3a4522=window['grecaptcha'];vr(_0x3a4522)?_0x3a4522['enterprise']['ready'](()=>{_0x3a4522['enterprise']['execute'](_0x20e775,{'action':_0x288923})['then'](_0x5eba7b=>{_0x1fb7a3(_0x5eba7b);})['catch'](()=>{_0x1fb7a3(Ma);});}):_0x42a587(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x349c88,_0x2ee66c)=>{_0x10059e(this['auth'])['then'](async _0x4149e6=>{if(!_0x2eb2a1&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x372abd(_0x4149e6,_0x349c88,_0x2ee66c);else{if(typeof window>'u'){_0x2ee66c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2336ef=Af();_0x2336ef['length']!==0x0&&(_0x2336ef+=_0x4149e6+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0xffc4f7;(_0xffc4f7=le['scriptInjectionDeferred'])==null||_0xffc4f7['resolve']();},Da(_0x2336ef)['then'](()=>{var _0x57dff6;return(_0x57dff6=le['scriptInjectionDeferred'])==null?void 0x0:_0x57dff6['promise'];})['then'](()=>{_0x372abd(_0x4149e6,_0x349c88,_0x2ee66c);})['catch'](_0x29b554=>{_0x2ee66c(_0x29b554);});}})['catch'](_0x29a05e=>{_0x2ee66c(_0x29a05e);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1a6b10,_0x347f95,_0x1ab5dd,_0x1bfb38=!0x1,_0x585fcd=!0x1){const _0x4e5b83=new le(_0x1a6b10);let _0x5a4770;if(_0x585fcd)_0x5a4770=Ma;else try{_0x5a4770=await _0x4e5b83['verify'](_0x1ab5dd);}catch{_0x5a4770=await _0x4e5b83['verify'](_0x1ab5dd,!0x0);}const _0x32d6dc={..._0x347f95};if(_0x1ab5dd==='mfaSmsEnrollment'||_0x1ab5dd==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x32d6dc){const _0x53db54=_0x32d6dc['phoneEnrollmentInfo']['phoneNumber'],_0x961a6d=_0x32d6dc['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x32d6dc,{'phoneEnrollmentInfo':{'phoneNumber':_0x53db54,'recaptchaToken':_0x961a6d,'captchaResponse':_0x5a4770,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x32d6dc){const _0x19fbc7=_0x32d6dc['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x32d6dc,{'phoneSignInInfo':{'recaptchaToken':_0x19fbc7,'captchaResponse':_0x5a4770,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x32d6dc;}return _0x1bfb38?Object['assign'](_0x32d6dc,{'captchaResp':_0x5a4770}):Object['assign'](_0x32d6dc,{'captchaResponse':_0x5a4770}),Object['assign'](_0x32d6dc,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x32d6dc,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x32d6dc;}async function Oi(_0xa7b86e,_0x318ea4,_0x47ea63,_0x47287b,_0x484fe2){var _0x3fe18c;if((_0x3fe18c=_0xa7b86e['_getRecaptchaConfig']())!=null&&_0x3fe18c['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1c978c=await br(_0xa7b86e,_0x318ea4,_0x47ea63,_0x47ea63==='getOobCode');return _0x47287b(_0xa7b86e,_0x1c978c);}else return _0x47287b(_0xa7b86e,_0x318ea4)['catch'](async _0x488955=>{if(_0x488955['code']==='auth/missing-recaptcha-token'){console['log'](_0x47ea63+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x18d236=await br(_0xa7b86e,_0x318ea4,_0x47ea63,_0x47ea63==='getOobCode');return _0x47287b(_0xa7b86e,_0x18d236);}else return Promise['reject'](_0x488955);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x902c07,_0x3f79f8){const _0x24ef9e=Ui(_0x902c07,'auth');if(_0x24ef9e['isInitialized']()){const _0x400501=_0x24ef9e['getImmediate'](),_0x36fd9c=_0x24ef9e['getOptions']();if(De(_0x36fd9c,_0x3f79f8??{}))return _0x400501;K(_0x400501,'already-initialized');}return _0x24ef9e['initialize']({'options':_0x3f79f8});}function Lf(_0x129cd9,_0x2a5eaa){const _0x3147c9=(_0x2a5eaa==null?void 0x0:_0x2a5eaa['persistence'])||[],_0x619d2=(Array['isArray'](_0x3147c9)?_0x3147c9:[_0x3147c9])['map'](ne);_0x2a5eaa!=null&&_0x2a5eaa['errorMap']&&_0x129cd9['_updateErrorMap'](_0x2a5eaa['errorMap']),_0x129cd9['_initializeWithPersistence'](_0x619d2,_0x2a5eaa==null?void 0x0:_0x2a5eaa['popupRedirectResolver']);}function xf(_0x262b3a,_0x250bcf,_0x40356a){const _0x4cb2e0=qe(_0x262b3a);m(/^https?:\/\//['test'](_0x250bcf),_0x4cb2e0,'invalid-emulator-scheme');const _0x4efd72=!0x1,_0x4273df=La(_0x250bcf),{host:_0x1d5fa2,port:_0x5286b6}=Ff(_0x250bcf),_0x51fc6e=_0x5286b6===null?'':':'+_0x5286b6,_0x351fb9={'url':_0x4273df+'//'+_0x1d5fa2+_0x51fc6e+'/'},_0x36bcfe=Object['freeze']({'host':_0x1d5fa2,'port':_0x5286b6,'protocol':_0x4273df['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4efd72})});if(!_0x4cb2e0['_canInitEmulator']){m(_0x4cb2e0['config']['emulator']&&_0x4cb2e0['emulatorConfig'],_0x4cb2e0,'emulator-config-failed'),m(De(_0x351fb9,_0x4cb2e0['config']['emulator'])&&De(_0x36bcfe,_0x4cb2e0['emulatorConfig']),_0x4cb2e0,'emulator-config-failed');return;}_0x4cb2e0['config']['emulator']=_0x351fb9,_0x4cb2e0['emulatorConfig']=_0x36bcfe,_0x4cb2e0['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x1d5fa2)?jr(_0x4273df+'//'+_0x1d5fa2+_0x51fc6e):Uf();}function La(_0xbcb7b1){const _0x545447=_0xbcb7b1['indexOf'](':');return _0x545447<0x0?'':_0xbcb7b1['substr'](0x0,_0x545447+0x1);}function Ff(_0x4c940d){const _0x2f15cf=La(_0x4c940d),_0x19ed49=/(\/\/)?([^?#/]+)/['exec'](_0x4c940d['substr'](_0x2f15cf['length']));if(!_0x19ed49)return{'host':'','port':null};const _0x86c5d9=_0x19ed49[0x2]['split']('@')['pop']()||'',_0x349810=/^(\[[^\]]+\])(:|$)/['exec'](_0x86c5d9);if(_0x349810){const _0x150393=_0x349810[0x1];return{'host':_0x150393,'port':Rr(_0x86c5d9['substr'](_0x150393['length']+0x1))};}else{const [_0x2651a8,_0x1ed6a2]=_0x86c5d9['split'](':');return{'host':_0x2651a8,'port':Rr(_0x1ed6a2)};}}function Rr(_0x24facd){if(!_0x24facd)return null;const _0x2d4667=Number(_0x24facd);return isNaN(_0x2d4667)?null:_0x2d4667;}function Uf(){function _0x3cb787(){const _0x2522e0=document['createElement']('p'),_0xc8a03=_0x2522e0['style'];_0x2522e0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xc8a03['position']='fixed',_0xc8a03['width']='100%',_0xc8a03['backgroundColor']='#ffffff',_0xc8a03['border']='.1em\x20solid\x20#000000',_0xc8a03['color']='#b50000',_0xc8a03['bottom']='0px',_0xc8a03['left']='0px',_0xc8a03['margin']='0px',_0xc8a03['zIndex']='10000',_0xc8a03['textAlign']='center',_0x2522e0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2522e0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3cb787):_0x3cb787());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x3870a2,_0x1bca8e){this['providerId']=_0x3870a2,this['signInMethod']=_0x1bca8e;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3954b7){return te('not\x20implemented');}['_linkToIdToken'](_0x54c789,_0xe9485f){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xee5f1e){return te('not\x20implemented');}}async function Wf(_0x21d7ac,_0x497038){return Ae(_0x21d7ac,'POST','/v1/accounts:signUp',_0x497038);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x124d08,_0x228981){return Yt(_0x124d08,'POST','/v1/accounts:signInWithPassword',Re(_0x124d08,_0x228981));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x3fb60f,_0x1f467e){return Yt(_0x3fb60f,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3fb60f,_0x1f467e));}async function Hf(_0x462494,_0x294a63){return Yt(_0x462494,'POST','/v1/accounts:signInWithEmailLink',Re(_0x462494,_0x294a63));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x4cad51,_0x1d2494,_0x5ee5b8,_0x40835b=null){super('password',_0x5ee5b8),this['_email']=_0x4cad51,this['_password']=_0x1d2494,this['_tenantId']=_0x40835b;}static['_fromEmailAndPassword'](_0x435edb,_0x5f15e7){return new Ft(_0x435edb,_0x5f15e7,'password');}static['_fromEmailAndCode'](_0x4f120c,_0x324911,_0x5b7209=null){return new Ft(_0x4f120c,_0x324911,'emailLink',_0x5b7209);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x640f18){const _0x229312=typeof _0x640f18=='string'?JSON['parse'](_0x640f18):_0x640f18;if(_0x229312!=null&&_0x229312['email']&&(_0x229312!=null&&_0x229312['password'])){if(_0x229312['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x229312['email'],_0x229312['password']);if(_0x229312['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x229312['email'],_0x229312['password'],_0x229312['tenantId']);}return null;}async['_getIdTokenResponse'](_0x178f86){switch(this['signInMethod']){case'password':const _0x9d2b56={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x178f86,_0x9d2b56,'signInWithPassword',Bf);case'emailLink':return Vf(_0x178f86,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x178f86,'internal-error');}}async['_linkToIdToken'](_0x3a4e99,_0x103c8b){switch(this['signInMethod']){case'password':const _0x3a53fa={'idToken':_0x103c8b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3a4e99,_0x3a53fa,'signUpPassword',Wf);case'emailLink':return Hf(_0x3a4e99,{'idToken':_0x103c8b,'email':this['_email'],'oobCode':this['_password']});default:K(_0x3a4e99,'internal-error');}}['_getReauthenticationResolver'](_0x353c74){return this['_getIdTokenResponse'](_0x353c74);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x13069f,_0x253188){return Yt(_0x13069f,'POST','/v1/accounts:signInWithIdp',Re(_0x13069f,_0x253188));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x692cd2){const _0x4255da=new We(_0x692cd2['providerId'],_0x692cd2['signInMethod']);return _0x692cd2['idToken']||_0x692cd2['accessToken']?(_0x692cd2['idToken']&&(_0x4255da['idToken']=_0x692cd2['idToken']),_0x692cd2['accessToken']&&(_0x4255da['accessToken']=_0x692cd2['accessToken']),_0x692cd2['nonce']&&!_0x692cd2['pendingToken']&&(_0x4255da['nonce']=_0x692cd2['nonce']),_0x692cd2['pendingToken']&&(_0x4255da['pendingToken']=_0x692cd2['pendingToken'])):_0x692cd2['oauthToken']&&_0x692cd2['oauthTokenSecret']?(_0x4255da['accessToken']=_0x692cd2['oauthToken'],_0x4255da['secret']=_0x692cd2['oauthTokenSecret']):K('argument-error'),_0x4255da;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3f28a9){const _0x561988=typeof _0x3f28a9=='string'?JSON['parse'](_0x3f28a9):_0x3f28a9,{providerId:_0x1bcba7,signInMethod:_0x218dc9,..._0x137803}=_0x561988;if(!_0x1bcba7||!_0x218dc9)return null;const _0x61f00b=new We(_0x1bcba7,_0x218dc9);return _0x61f00b['idToken']=_0x137803['idToken']||void 0x0,_0x61f00b['accessToken']=_0x137803['accessToken']||void 0x0,_0x61f00b['secret']=_0x137803['secret'],_0x61f00b['nonce']=_0x137803['nonce'],_0x61f00b['pendingToken']=_0x137803['pendingToken']||null,_0x61f00b;}['_getIdTokenResponse'](_0x4c70ca){const _0x48dd2b=this['buildRequest']();return Ze(_0x4c70ca,_0x48dd2b);}['_linkToIdToken'](_0x1fcbde,_0x31a5d4){const _0x24cef0=this['buildRequest']();return _0x24cef0['idToken']=_0x31a5d4,Ze(_0x1fcbde,_0x24cef0);}['_getReauthenticationResolver'](_0x53ff08){const _0x27cd02=this['buildRequest']();return _0x27cd02['autoCreate']=!0x1,Ze(_0x53ff08,_0x27cd02);}['buildRequest'](){const _0x461b40={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x461b40['pendingToken']=this['pendingToken'];else{const _0x5b9007={};this['idToken']&&(_0x5b9007['id_token']=this['idToken']),this['accessToken']&&(_0x5b9007['access_token']=this['accessToken']),this['secret']&&(_0x5b9007['oauth_token_secret']=this['secret']),_0x5b9007['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5b9007['nonce']=this['nonce']),_0x461b40['postBody']=at(_0x5b9007);}return _0x461b40;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1eaed0){switch(_0x1eaed0){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x4bc9ec){const _0x53d364=yt(vt(_0x4bc9ec))['link'],_0x2f9710=_0x53d364?yt(vt(_0x53d364))['deep_link_id']:null,_0x1ea1be=yt(vt(_0x4bc9ec))['deep_link_id'];return(_0x1ea1be?yt(vt(_0x1ea1be))['link']:null)||_0x1ea1be||_0x2f9710||_0x53d364||_0x4bc9ec;}class Ss{constructor(_0x4767de){const _0x596825=yt(vt(_0x4767de)),_0x4745c1=_0x596825['apiKey']??null,_0x5e87cd=_0x596825['oobCode']??null,_0x1ee60a=Gf(_0x596825['mode']??null);m(_0x4745c1&&_0x5e87cd&&_0x1ee60a,'argument-error'),this['apiKey']=_0x4745c1,this['operation']=_0x1ee60a,this['code']=_0x5e87cd,this['continueUrl']=_0x596825['continueUrl']??null,this['languageCode']=_0x596825['lang']??null,this['tenantId']=_0x596825['tenantId']??null;}static['parseLink'](_0x431564){const _0x5b4c4a=qf(_0x431564);try{return new Ss(_0x5b4c4a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4a0666,_0x451798){return Ft['_fromEmailAndPassword'](_0x4a0666,_0x451798);}static['credentialWithLink'](_0x6edf79,_0x4b454e){const _0x32c927=Ss['parseLink'](_0x4b454e);return m(_0x32c927,'argument-error'),Ft['_fromEmailAndCode'](_0x6edf79,_0x32c927['code'],_0x32c927['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5345ac){this['providerId']=_0x5345ac,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x218f91){this['defaultLanguageCode']=_0x218f91;}['setCustomParameters'](_0x49c355){return this['customParameters']=_0x49c355,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2eefdf){return this['scopes']['includes'](_0x2eefdf)||this['scopes']['push'](_0x2eefdf),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x523ddb){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x523ddb});}static['credentialFromResult'](_0x48bf4c){return he['credentialFromTaggedObject'](_0x48bf4c);}static['credentialFromError'](_0x494962){return he['credentialFromTaggedObject'](_0x494962['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x101bff}){if(!_0x101bff||!('oauthAccessToken'in _0x101bff)||!_0x101bff['oauthAccessToken'])return null;try{return he['credential'](_0x101bff['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xa1934c,_0x97dba){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xa1934c,'accessToken':_0x97dba});}static['credentialFromResult'](_0x1ed922){return ue['credentialFromTaggedObject'](_0x1ed922);}static['credentialFromError'](_0x374dbb){return ue['credentialFromTaggedObject'](_0x374dbb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47a562}){if(!_0x47a562)return null;const {oauthIdToken:_0x463450,oauthAccessToken:_0x3c6424}=_0x47a562;if(!_0x463450&&!_0x3c6424)return null;try{return ue['credential'](_0x463450,_0x3c6424);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x53b59e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x53b59e});}static['credentialFromResult'](_0x15581f){return de['credentialFromTaggedObject'](_0x15581f);}static['credentialFromError'](_0x3bcbca){return de['credentialFromTaggedObject'](_0x3bcbca['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1792f6}){if(!_0x1792f6||!('oauthAccessToken'in _0x1792f6)||!_0x1792f6['oauthAccessToken'])return null;try{return de['credential'](_0x1792f6['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x57a87f,_0x35650b){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x57a87f,'oauthTokenSecret':_0x35650b});}static['credentialFromResult'](_0x5b62b7){return fe['credentialFromTaggedObject'](_0x5b62b7);}static['credentialFromError'](_0x34402a){return fe['credentialFromTaggedObject'](_0x34402a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x276985}){if(!_0x276985)return null;const {oauthAccessToken:_0x1a6f66,oauthTokenSecret:_0x51bf0e}=_0x276985;if(!_0x1a6f66||!_0x51bf0e)return null;try{return fe['credential'](_0x1a6f66,_0x51bf0e);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x1b169c,_0x2f13bd){return Yt(_0x1b169c,'POST','/v1/accounts:signUp',Re(_0x1b169c,_0x2f13bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3057fd){this['user']=_0x3057fd['user'],this['providerId']=_0x3057fd['providerId'],this['_tokenResponse']=_0x3057fd['_tokenResponse'],this['operationType']=_0x3057fd['operationType'];}static async['_fromIdTokenResponse'](_0x57ed30,_0x480d1f,_0x13bb13,_0x43e7e7=!0x1){const _0x2af86b=await z['_fromIdTokenResponse'](_0x57ed30,_0x13bb13,_0x43e7e7),_0x22bd2a=Ar(_0x13bb13);return new Be({'user':_0x2af86b,'providerId':_0x22bd2a,'_tokenResponse':_0x13bb13,'operationType':_0x480d1f});}static async['_forOperation'](_0x154959,_0x4af866,_0x44f233){await _0x154959['_updateTokensIfNecessary'](_0x44f233,!0x0);const _0x5234e4=Ar(_0x44f233);return new Be({'user':_0x154959,'providerId':_0x5234e4,'_tokenResponse':_0x44f233,'operationType':_0x4af866});}}function Ar(_0x218459){return _0x218459['providerId']?_0x218459['providerId']:'phoneNumber'in _0x218459?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xabbef1,_0x515220,_0xc36d03,_0x2b5587){super(_0x515220['code'],_0x515220['message']),this['operationType']=_0xc36d03,this['user']=_0x2b5587,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xabbef1['name'],'tenantId':_0xabbef1['tenantId']??void 0x0,'_serverResponse':_0x515220['customData']['_serverResponse'],'operationType':_0xc36d03};}static['_fromErrorAndOperation'](_0x3d2fc4,_0x44e21e,_0x14e923,_0x46bd99){return new Rn(_0x3d2fc4,_0x44e21e,_0x14e923,_0x46bd99);}}function Fa(_0x3fc434,_0x938c7e,_0x245ec3,_0x5105b0){return(_0x938c7e==='reauthenticate'?_0x245ec3['_getReauthenticationResolver'](_0x3fc434):_0x245ec3['_getIdTokenResponse'](_0x3fc434))['catch'](_0x3e7997=>{throw _0x3e7997['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3fc434,_0x3e7997,_0x938c7e,_0x5105b0):_0x3e7997;});}async function jf(_0x103d0b,_0x4e60f5,_0x86be81=!0x1){const _0x3d0a85=await xt(_0x103d0b,_0x4e60f5['_linkToIdToken'](_0x103d0b['auth'],await _0x103d0b['getIdToken']()),_0x86be81);return Be['_forOperation'](_0x103d0b,'link',_0x3d0a85);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x17a487,_0x39fd4c,_0x12e7c6=!0x1){const {auth:_0x1eb32d}=_0x17a487;if(H(_0x1eb32d['app']))return Promise['reject'](se(_0x1eb32d));const _0x5355e8='reauthenticate';try{const _0x1a19de=await xt(_0x17a487,Fa(_0x1eb32d,_0x5355e8,_0x39fd4c,_0x17a487),_0x12e7c6);m(_0x1a19de['idToken'],_0x1eb32d,'internal-error');const _0x38baa6=ws(_0x1a19de['idToken']);m(_0x38baa6,_0x1eb32d,'internal-error');const {sub:_0x2b05ae}=_0x38baa6;return m(_0x17a487['uid']===_0x2b05ae,_0x1eb32d,'user-mismatch'),Be['_forOperation'](_0x17a487,_0x5355e8,_0x1a19de);}catch(_0x3274c0){throw(_0x3274c0==null?void 0x0:_0x3274c0['code'])==='auth/user-not-found'&&K(_0x1eb32d,'user-mismatch'),_0x3274c0;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x27fddf,_0x6dc5b1,_0x3f0cce=!0x1){if(H(_0x27fddf['app']))return Promise['reject'](se(_0x27fddf));const _0x23d73b='signIn',_0x479d5f=await Fa(_0x27fddf,_0x23d73b,_0x6dc5b1),_0x1a1da8=await Be['_fromIdTokenResponse'](_0x27fddf,_0x23d73b,_0x479d5f);return _0x3f0cce||await _0x27fddf['_updateCurrentUser'](_0x1a1da8['user']),_0x1a1da8;}async function Yf(_0x5df7e9,_0x64827){return Ua(qe(_0x5df7e9),_0x64827);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x5ad2d4){const _0x3bd7e6=qe(_0x5ad2d4);_0x3bd7e6['_getPasswordPolicyInternal']()&&await _0x3bd7e6['_updatePasswordPolicy']();}async function R_(_0x250f6d,_0x3691b8,_0x29dc09){if(H(_0x250f6d['app']))return Promise['reject'](se(_0x250f6d));const _0xebef4d=qe(_0x250f6d),_0x5da784=await Oi(_0xebef4d,{'returnSecureToken':!0x0,'email':_0x3691b8,'password':_0x29dc09,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x255f86=>{throw _0x255f86['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x250f6d),_0x255f86;}),_0x441ab4=await Be['_fromIdTokenResponse'](_0xebef4d,'signIn',_0x5da784);return await _0xebef4d['_updateCurrentUser'](_0x441ab4['user']),_0x441ab4;}function A_(_0x636d28,_0x4397cc,_0x2b7efe){return H(_0x636d28['app'])?Promise['reject'](se(_0x636d28)):Yf(k(_0x636d28),ft['credential'](_0x4397cc,_0x2b7efe))['catch'](async _0x3f771c=>{throw _0x3f771c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x636d28),_0x3f771c;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x523d99,_0x41acfa){return k(_0x523d99)['setPersistence'](_0x41acfa);}function Qf(_0x2dbdb8,_0x48e099,_0xad8170,_0xdbf2b4){return k(_0x2dbdb8)['onIdTokenChanged'](_0x48e099,_0xad8170,_0xdbf2b4);}function Jf(_0x2e840d,_0x12f480,_0x31ac56){return k(_0x2e840d)['beforeAuthStateChanged'](_0x12f480,_0x31ac56);}function N_(_0x55011d,_0x3146f4,_0x35ae1,_0xcf71a4){return k(_0x55011d)['onAuthStateChanged'](_0x3146f4,_0x35ae1,_0xcf71a4);}function P_(_0x284bd8){return k(_0x284bd8)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5b5d28,_0x294378){this['storageRetriever']=_0x5b5d28,this['type']=_0x294378;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2e0cf3,_0x37e4e5){return this['storage']['setItem'](_0x2e0cf3,JSON['stringify'](_0x37e4e5)),Promise['resolve']();}['_get'](_0x3c7fb5){const _0x5311c2=this['storage']['getItem'](_0x3c7fb5);return Promise['resolve'](_0x5311c2?JSON['parse'](_0x5311c2):null);}['_remove'](_0xe0d507){return this['storage']['removeItem'](_0xe0d507),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1521b5,_0x99b652)=>this['onStorageEvent'](_0x1521b5,_0x99b652),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2412a4){for(const _0x15deef of Object['keys'](this['listeners'])){const _0x38d41c=this['storage']['getItem'](_0x15deef),_0x34c6b2=this['localCache'][_0x15deef];_0x38d41c!==_0x34c6b2&&_0x2412a4(_0x15deef,_0x34c6b2,_0x38d41c);}}['onStorageEvent'](_0x3f8cb9,_0x1451f9=!0x1){if(!_0x3f8cb9['key']){this['forAllChangedKeys']((_0x454287,_0x19fe0a,_0x2cb796)=>{this['notifyListeners'](_0x454287,_0x2cb796);});return;}const _0x22cad4=_0x3f8cb9['key'];_0x1451f9?this['detachListener']():this['stopPolling']();const _0x438343=()=>{const _0x391532=this['storage']['getItem'](_0x22cad4);!_0x1451f9&&this['localCache'][_0x22cad4]===_0x391532||this['notifyListeners'](_0x22cad4,_0x391532);},_0x3d2bc7=this['storage']['getItem'](_0x22cad4);If()&&_0x3d2bc7!==_0x3f8cb9['newValue']&&_0x3f8cb9['newValue']!==_0x3f8cb9['oldValue']?setTimeout(_0x438343,Zf):_0x438343();}['notifyListeners'](_0x43fe14,_0x2298c2){this['localCache'][_0x43fe14]=_0x2298c2;const _0x1757fe=this['listeners'][_0x43fe14];if(_0x1757fe){for(const _0x30910d of Array['from'](_0x1757fe))_0x30910d(_0x2298c2&&JSON['parse'](_0x2298c2));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1665f8,_0x2088dd,_0x2168e7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1665f8,'oldValue':_0x2088dd,'newValue':_0x2168e7}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x527a9c,_0x49b599){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x527a9c]||(this['listeners'][_0x527a9c]=new Set(),this['localCache'][_0x527a9c]=this['storage']['getItem'](_0x527a9c)),this['listeners'][_0x527a9c]['add'](_0x49b599);}['_removeListener'](_0x4313c1,_0x360802){this['listeners'][_0x4313c1]&&(this['listeners'][_0x4313c1]['delete'](_0x360802),this['listeners'][_0x4313c1]['size']===0x0&&delete this['listeners'][_0x4313c1]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x38fd3c,_0x4614f8){await super['_set'](_0x38fd3c,_0x4614f8),this['localCache'][_0x38fd3c]=JSON['stringify'](_0x4614f8);}async['_get'](_0x1cd302){const _0x303e4c=await super['_get'](_0x1cd302);return this['localCache'][_0x1cd302]=JSON['stringify'](_0x303e4c),_0x303e4c;}async['_remove'](_0x562dce){await super['_remove'](_0x562dce),delete this['localCache'][_0x562dce];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xe181e9,_0x101b78){}['_removeListener'](_0x5738fc,_0x28a278){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x166db6){return Promise['all'](_0x166db6['map'](async _0x484aac=>{try{return{'fulfilled':!0x0,'value':await _0x484aac};}catch(_0x246679){return{'fulfilled':!0x1,'reason':_0x246679};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x2e7af0){this['eventTarget']=_0x2e7af0,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x106f51){const _0x3e575b=this['receivers']['find'](_0x3a38a6=>_0x3a38a6['isListeningto'](_0x106f51));if(_0x3e575b)return _0x3e575b;const _0x5c4d86=new jn(_0x106f51);return this['receivers']['push'](_0x5c4d86),_0x5c4d86;}['isListeningto'](_0x3fe9f1){return this['eventTarget']===_0x3fe9f1;}async['handleEvent'](_0x562207){const _0x43c878=_0x562207,{eventId:_0x490813,eventType:_0x5f52ec,data:_0xe49c1b}=_0x43c878['data'],_0x296a85=this['handlersMap'][_0x5f52ec];if(!(_0x296a85!=null&&_0x296a85['size']))return;_0x43c878['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x490813,'eventType':_0x5f52ec});const _0x2e745d=Array['from'](_0x296a85)['map'](async _0x5b867d=>_0x5b867d(_0x43c878['origin'],_0xe49c1b)),_0x56fbc5=await tp(_0x2e745d);_0x43c878['ports'][0x0]['postMessage']({'status':'done','eventId':_0x490813,'eventType':_0x5f52ec,'response':_0x56fbc5});}['_subscribe'](_0x29e3da,_0x46f6a4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x29e3da]||(this['handlersMap'][_0x29e3da]=new Set()),this['handlersMap'][_0x29e3da]['add'](_0x46f6a4);}['_unsubscribe'](_0xe966df,_0x1fab94){this['handlersMap'][_0xe966df]&&_0x1fab94&&this['handlersMap'][_0xe966df]['delete'](_0x1fab94),(!_0x1fab94||this['handlersMap'][_0xe966df]['size']===0x0)&&delete this['handlersMap'][_0xe966df],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x2611bc='',_0x1eede8=0xa){let _0xe37504='';for(let _0xb12cab=0x0;_0xb12cab<_0x1eede8;_0xb12cab++)_0xe37504+=Math['floor'](Math['random']()*0xa);return _0x2611bc+_0xe37504;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0xc3d9ab){this['target']=_0xc3d9ab,this['handlers']=new Set();}['removeMessageHandler'](_0x286b99){_0x286b99['messageChannel']&&(_0x286b99['messageChannel']['port1']['removeEventListener']('message',_0x286b99['onMessage']),_0x286b99['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x286b99);}async['_send'](_0x254b60,_0x4b7730,_0x47e887=0x32){const _0x19e12e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x19e12e)throw new Error('connection_unavailable');let _0x148d20,_0x20c178;return new Promise((_0x55ea1c,_0x51d0e3)=>{const _0x4f2a2f=bs('',0x14);_0x19e12e['port1']['start']();const _0x2106ca=setTimeout(()=>{_0x51d0e3(new Error('unsupported_event'));},_0x47e887);_0x20c178={'messageChannel':_0x19e12e,'onMessage'(_0x5c67a2){const _0x5f1acd=_0x5c67a2;if(_0x5f1acd['data']['eventId']===_0x4f2a2f)switch(_0x5f1acd['data']['status']){case'ack':clearTimeout(_0x2106ca),_0x148d20=setTimeout(()=>{_0x51d0e3(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x148d20),_0x55ea1c(_0x5f1acd['data']['response']);break;default:clearTimeout(_0x2106ca),clearTimeout(_0x148d20),_0x51d0e3(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x20c178),_0x19e12e['port1']['addEventListener']('message',_0x20c178['onMessage']),this['target']['postMessage']({'eventType':_0x254b60,'eventId':_0x4f2a2f,'data':_0x4b7730},[_0x19e12e['port2']]);})['finally'](()=>{_0x20c178&&this['removeMessageHandler'](_0x20c178);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x53f399){X()['location']['href']=_0x53f399;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x32b780;return((_0x32b780=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x32b780['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x2fcbf8){this['request']=_0x2fcbf8;}['toPromise'](){return new Promise((_0x1a9fcd,_0x11fb32)=>{this['request']['addEventListener']('success',()=>{_0x1a9fcd(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x11fb32(this['request']['error']);});});}}function Kn(_0x289a7b,_0x39c49a){return _0x289a7b['transaction']([kn],_0x39c49a?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x476ccb=indexedDB['deleteDatabase'](qa);return new Jt(_0x476ccb)['toPromise']();}function ja(){const _0x576ed0=indexedDB['open'](qa,ap);return new Promise((_0x179253,_0x43f2a2)=>{_0x576ed0['addEventListener']('error',()=>{_0x43f2a2(_0x576ed0['error']);}),_0x576ed0['addEventListener']('upgradeneeded',()=>{const _0x1bb343=_0x576ed0['result'];try{_0x1bb343['createObjectStore'](kn,{'keyPath':za});}catch(_0x7712d9){_0x43f2a2(_0x7712d9);}}),_0x576ed0['addEventListener']('success',async()=>{const _0x16911e=_0x576ed0['result'];_0x16911e['objectStoreNames']['contains'](kn)?_0x179253(_0x16911e):(_0x16911e['close'](),await cp(),_0x179253(await ja()));});});}async function kr(_0x29764a,_0x6a79bd,_0x47f8ee){const _0x125b63=Kn(_0x29764a,!0x0)['put']({[za]:_0x6a79bd,'value':_0x47f8ee});return new Jt(_0x125b63)['toPromise']();}async function lp(_0x412273,_0x238095){const _0x34ef43=Kn(_0x412273,!0x1)['get'](_0x238095),_0x4efe71=await new Jt(_0x34ef43)['toPromise']();return _0x4efe71===void 0x0?null:_0x4efe71['value'];}function Nr(_0x26565c,_0x39adfd){const _0x434a5d=Kn(_0x26565c,!0x0)['delete'](_0x39adfd);return new Jt(_0x434a5d)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2fed03){let _0x33d7be=0x0;for(;;)try{const _0x542703=await this['_openDb']();return await _0x2fed03(_0x542703);}catch(_0x6766fd){if(_0x33d7be++>up)throw _0x6766fd;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3cfc7e,_0x12ddbc)=>({'keyProcessed':(await this['_poll']())['includes'](_0x12ddbc['key'])})),this['receiver']['_subscribe']('ping',async(_0x14da61,_0x5e9a4c)=>['keyChanged']);}async['initializeSender'](){var _0x40a93e,_0x22fba3;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0xa58173=await this['sender']['_send']('ping',{},0x320);_0xa58173&&(_0x40a93e=_0xa58173[0x0])!=null&&_0x40a93e['fulfilled']&&(_0x22fba3=_0xa58173[0x0])!=null&&_0x22fba3['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1c12a9){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1c12a9},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x14426b=>{await kr(_0x14426b,An,'1'),await Nr(_0x14426b,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2a639b){this['pendingWrites']++;try{await _0x2a639b();}finally{this['pendingWrites']--;}}async['_set'](_0x1062dc,_0x13e210){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x43e75e=>kr(_0x43e75e,_0x1062dc,_0x13e210)),this['localCache'][_0x1062dc]=_0x13e210,this['notifyServiceWorker'](_0x1062dc)));}async['_get'](_0x17b504){const _0x34b7f8=await this['_withRetries'](_0x4861a5=>lp(_0x4861a5,_0x17b504));return this['localCache'][_0x17b504]=_0x34b7f8,_0x34b7f8;}async['_remove'](_0x2f02af){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x35c566=>Nr(_0x35c566,_0x2f02af)),delete this['localCache'][_0x2f02af],this['notifyServiceWorker'](_0x2f02af)));}async['_poll'](){const _0x45a2a5=await this['_withRetries'](_0x462284=>{const _0x5d324c=Kn(_0x462284,!0x1)['getAll']();return new Jt(_0x5d324c)['toPromise']();});if(!_0x45a2a5)return[];if(this['pendingWrites']!==0x0)return[];const _0x5e4c07=[],_0x2ddcd5=new Set();if(_0x45a2a5['length']!==0x0){for(const {fbase_key:_0x4b4bdd,value:_0x381450}of _0x45a2a5)_0x2ddcd5['add'](_0x4b4bdd),JSON['stringify'](this['localCache'][_0x4b4bdd])!==JSON['stringify'](_0x381450)&&(this['notifyListeners'](_0x4b4bdd,_0x381450),_0x5e4c07['push'](_0x4b4bdd));}for(const _0x3b6357 of Object['keys'](this['localCache']))this['localCache'][_0x3b6357]&&!_0x2ddcd5['has'](_0x3b6357)&&(this['notifyListeners'](_0x3b6357,null),_0x5e4c07['push'](_0x3b6357));return _0x5e4c07;}['notifyListeners'](_0x59946f,_0x8e48f9){this['localCache'][_0x59946f]=_0x8e48f9;const _0x209b9d=this['listeners'][_0x59946f];if(_0x209b9d){for(const _0x19aca2 of Array['from'](_0x209b9d))_0x19aca2(_0x8e48f9);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4b23a1,_0x1fc815){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4b23a1]||(this['listeners'][_0x4b23a1]=new Set(),this['_get'](_0x4b23a1)),this['listeners'][_0x4b23a1]['add'](_0x1fc815);}['_removeListener'](_0x23347d,_0xf0aeae){this['listeners'][_0x23347d]&&(this['listeners'][_0x23347d]['delete'](_0xf0aeae),this['listeners'][_0x23347d]['size']===0x0&&delete this['listeners'][_0x23347d]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x577370,_0x455798){return _0x455798?ne(_0x455798):(m(_0x577370['_popupRedirectResolver'],_0x577370,'argument-error'),_0x577370['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x467eab){super('custom','custom'),this['params']=_0x467eab;}['_getIdTokenResponse'](_0x33f05a){return Ze(_0x33f05a,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5975dd,_0x19e3db){return Ze(_0x5975dd,this['_buildIdpRequest'](_0x19e3db));}['_getReauthenticationResolver'](_0x32e554){return Ze(_0x32e554,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2db2c0){const _0xa0ca7e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2db2c0&&(_0xa0ca7e['idToken']=_0x2db2c0),_0xa0ca7e;}}function pp(_0x5b03b2){return Ua(_0x5b03b2['auth'],new Rs(_0x5b03b2),_0x5b03b2['bypassAuthState']);}function _p(_0x4215ad){const {auth:_0x49a7bc,user:_0x31766f}=_0x4215ad;return m(_0x31766f,_0x49a7bc,'internal-error'),Kf(_0x31766f,new Rs(_0x4215ad),_0x4215ad['bypassAuthState']);}async function gp(_0xa6b334){const {auth:_0x467c40,user:_0x3b706a}=_0xa6b334;return m(_0x3b706a,_0x467c40,'internal-error'),jf(_0x3b706a,new Rs(_0xa6b334),_0xa6b334['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x19fd41,_0x4c0276,_0x7a7b74,_0x38d72f,_0x5d357d=!0x1){this['auth']=_0x19fd41,this['resolver']=_0x7a7b74,this['user']=_0x38d72f,this['bypassAuthState']=_0x5d357d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4c0276)?_0x4c0276:[_0x4c0276];}['execute'](){return new Promise(async(_0x262976,_0x1f28ad)=>{this['pendingPromise']={'resolve':_0x262976,'reject':_0x1f28ad};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x383963){this['reject'](_0x383963);}});}async['onAuthEvent'](_0xa8c33e){const {urlResponse:_0xd4b4b1,sessionId:_0x373ce9,postBody:_0x2bebaf,tenantId:_0x596658,error:_0x265038,type:_0x1d26b6}=_0xa8c33e;if(_0x265038){this['reject'](_0x265038);return;}const _0x10a60b={'auth':this['auth'],'requestUri':_0xd4b4b1,'sessionId':_0x373ce9,'tenantId':_0x596658||void 0x0,'postBody':_0x2bebaf||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1d26b6)(_0x10a60b));}catch(_0x4e86d1){this['reject'](_0x4e86d1);}}['onError'](_0x4aa921){this['reject'](_0x4aa921);}['getIdpTask'](_0x20e13e){switch(_0x20e13e){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x159a84){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x159a84),this['unregisterAndCleanUp']();}['reject'](_0x4a3ed2){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4a3ed2),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x11e3d5,_0x4c1908,_0x6a3d58,_0x3d98fc,_0x548bda){super(_0x11e3d5,_0x4c1908,_0x3d98fc,_0x548bda),this['provider']=_0x6a3d58,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x1580f7=await this['execute']();return m(_0x1580f7,this['auth'],'internal-error'),_0x1580f7;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1e8cfa=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1e8cfa),this['authWindow']['associatedEvent']=_0x1e8cfa,this['resolver']['_originValidation'](this['auth'])['catch'](_0x91b2a8=>{this['reject'](_0x91b2a8);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1a7e70=>{_0x1a7e70||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x526247;return((_0x526247=this['authWindow'])==null?void 0x0:_0x526247['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x391538=()=>{var _0x4bd4a4,_0x102aef;if((_0x102aef=(_0x4bd4a4=this['authWindow'])==null?void 0x0:_0x4bd4a4['window'])!=null&&_0x102aef['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x391538,mp['get']());};_0x391538();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x36e7f2,_0x6c19c4,_0x2a221c=!0x1){super(_0x36e7f2,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x6c19c4,void 0x0,_0x2a221c),this['eventId']=null;}async['execute'](){let _0xa05e09=rn['get'](this['auth']['_key']());if(!_0xa05e09){try{const _0x14b3ff=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0xa05e09=()=>Promise['resolve'](_0x14b3ff);}catch(_0x4f4ba8){_0xa05e09=()=>Promise['reject'](_0x4f4ba8);}rn['set'](this['auth']['_key'](),_0xa05e09);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xa05e09();}async['onAuthEvent'](_0xa1f870){if(_0xa1f870['type']==='signInViaRedirect')return super['onAuthEvent'](_0xa1f870);if(_0xa1f870['type']==='unknown'){this['resolve'](null);return;}if(_0xa1f870['eventId']){const _0x2b0f59=await this['auth']['_redirectUserForId'](_0xa1f870['eventId']);if(_0x2b0f59)return this['user']=_0x2b0f59,super['onAuthEvent'](_0xa1f870);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x20b288,_0x16b5ae){const _0x1893a8=Cp(_0x16b5ae),_0x3ccd48=wp(_0x20b288);if(!await _0x3ccd48['_isAvailable']())return!0x1;const _0x3a926e=await _0x3ccd48['_get'](_0x1893a8)==='true';return await _0x3ccd48['_remove'](_0x1893a8),_0x3a926e;}function Ip(_0x18f550,_0x38e7bf){rn['set'](_0x18f550['_key'](),_0x38e7bf);}function wp(_0x1e69e9){return ne(_0x1e69e9['_redirectPersistence']);}function Cp(_0x556c62){return sn(yp,_0x556c62['config']['apiKey'],_0x556c62['name']);}async function Tp(_0x5a9c66,_0x136bb8,_0x56d29a=!0x1){if(H(_0x5a9c66['app']))return Promise['reject'](se(_0x5a9c66));const _0x44ddf8=qe(_0x5a9c66),_0x2154e2=fp(_0x44ddf8,_0x136bb8),_0x373a58=await new vp(_0x44ddf8,_0x2154e2,_0x56d29a)['execute']();return _0x373a58&&!_0x56d29a&&(delete _0x373a58['user']['_redirectEventId'],await _0x44ddf8['_persistUserIfCurrent'](_0x373a58['user']),await _0x44ddf8['_setRedirectUser'](null,_0x136bb8)),_0x373a58;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4f19eb){this['auth']=_0x4f19eb,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x47ca5a){this['consumers']['add'](_0x47ca5a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x47ca5a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x47ca5a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x124296){this['consumers']['delete'](_0x124296);}['onEvent'](_0x1f3f64){if(this['hasEventBeenHandled'](_0x1f3f64))return!0x1;let _0x240264=!0x1;return this['consumers']['forEach'](_0xd8b973=>{this['isEventForConsumer'](_0x1f3f64,_0xd8b973)&&(_0x240264=!0x0,this['sendToConsumer'](_0x1f3f64,_0xd8b973),this['saveEventToCache'](_0x1f3f64));}),this['hasHandledPotentialRedirect']||!Rp(_0x1f3f64)||(this['hasHandledPotentialRedirect']=!0x0,_0x240264||(this['queuedRedirectEvent']=_0x1f3f64,_0x240264=!0x0)),_0x240264;}['sendToConsumer'](_0x5a9ffa,_0x4f8620){var _0x1097e3;if(_0x5a9ffa['error']&&!Qa(_0x5a9ffa)){const _0x42ace8=((_0x1097e3=_0x5a9ffa['error']['code'])==null?void 0x0:_0x1097e3['split']('auth/')[0x1])||'internal-error';_0x4f8620['onError'](J(this['auth'],_0x42ace8));}else _0x4f8620['onAuthEvent'](_0x5a9ffa);}['isEventForConsumer'](_0x54f766,_0x364ff9){const _0x2fe341=_0x364ff9['eventId']===null||!!_0x54f766['eventId']&&_0x54f766['eventId']===_0x364ff9['eventId'];return _0x364ff9['filter']['includes'](_0x54f766['type'])&&_0x2fe341;}['hasEventBeenHandled'](_0x3cb345){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x3cb345));}['saveEventToCache'](_0x3bbe9c){this['cachedEventUids']['add'](Pr(_0x3bbe9c)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x3c031d){return[_0x3c031d['type'],_0x3c031d['eventId'],_0x3c031d['sessionId'],_0x3c031d['tenantId']]['filter'](_0xdb8852=>_0xdb8852)['join']('-');}function Qa({type:_0x4c151a,error:_0x49dcf8}){return _0x4c151a==='unknown'&&(_0x49dcf8==null?void 0x0:_0x49dcf8['code'])==='auth/no-auth-event';}function Rp(_0x4d02da){switch(_0x4d02da['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4d02da);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x375d37,_0x32b49e={}){return Ae(_0x375d37,'GET','/v1/projects',_0x32b49e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x1cb292){if(_0x1cb292['config']['emulator'])return;const {authorizedDomains:_0x4fe966}=await Ap(_0x1cb292);for(const _0x47ccdb of _0x4fe966)try{if(Op(_0x47ccdb))return;}catch{}K(_0x1cb292,'unauthorized-domain');}function Op(_0x22b5be){const _0x20e113=Ni(),{protocol:_0xa326f7,hostname:_0x542b65}=new URL(_0x20e113);if(_0x22b5be['startsWith']('chrome-extension://')){const _0x48bf52=new URL(_0x22b5be);return _0x48bf52['hostname']===''&&_0x542b65===''?_0xa326f7==='chrome-extension:'&&_0x22b5be['replace']('chrome-extension://','')===_0x20e113['replace']('chrome-extension://',''):_0xa326f7==='chrome-extension:'&&_0x48bf52['hostname']===_0x542b65;}if(!Np['test'](_0xa326f7))return!0x1;if(kp['test'](_0x22b5be))return _0x542b65===_0x22b5be;const _0x374bb1=_0x22b5be['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x374bb1+'|'+_0x374bb1+')$','i')['test'](_0x542b65);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x4674d4=X()['___jsl'];if(_0x4674d4!=null&&_0x4674d4['H']){for(const _0xeb2567 of Object['keys'](_0x4674d4['H']))if(_0x4674d4['H'][_0xeb2567]['r']=_0x4674d4['H'][_0xeb2567]['r']||[],_0x4674d4['H'][_0xeb2567]['L']=_0x4674d4['H'][_0xeb2567]['L']||[],_0x4674d4['H'][_0xeb2567]['r']=[..._0x4674d4['H'][_0xeb2567]['L']],_0x4674d4['CP']){for(let _0x384876=0x0;_0x384876<_0x4674d4['CP']['length'];_0x384876++)_0x4674d4['CP'][_0x384876]=null;}}}function Mp(_0x1d5618){return new Promise((_0xa818f1,_0x624b02)=>{var _0x67da59,_0x372894,_0x44f89e;function _0x300326(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xa818f1(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x624b02(J(_0x1d5618,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x372894=(_0x67da59=X()['gapi'])==null?void 0x0:_0x67da59['iframes'])!=null&&_0x372894['Iframe'])_0xa818f1(gapi['iframes']['getContext']());else{if((_0x44f89e=X()['gapi'])!=null&&_0x44f89e['load'])_0x300326();else{const _0x235b71=Nf('iframefcb');return X()[_0x235b71]=()=>{gapi['load']?_0x300326():_0x624b02(J(_0x1d5618,'network-request-failed'));},Da(kf()+'?onload='+_0x235b71)['catch'](_0x38698a=>_0x624b02(_0x38698a));}}})['catch'](_0x3973f5=>{throw on=null,_0x3973f5;});}let on=null;function Lp(_0x5d0108){return on=on||Mp(_0x5d0108),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x5e35dc){const _0x2a9b33=_0x5e35dc['config'];m(_0x2a9b33['authDomain'],_0x5e35dc,'auth-domain-config-required');const _0xbdbd66=_0x2a9b33['emulator']?Is(_0x2a9b33,Up):'https://'+_0x5e35dc['config']['authDomain']+'/'+Fp,_0x262e39={'apiKey':_0x2a9b33['apiKey'],'appName':_0x5e35dc['name'],'v':ct},_0x4ffe9c=Bp['get'](_0x5e35dc['config']['apiHost']);_0x4ffe9c&&(_0x262e39['eid']=_0x4ffe9c);const _0x4d661b=_0x5e35dc['_getFrameworks']();return _0x4d661b['length']&&(_0x262e39['fw']=_0x4d661b['join'](',')),_0xbdbd66+'?'+at(_0x262e39)['slice'](0x1);}async function Hp(_0x5bbffa){const _0x31f626=await Lp(_0x5bbffa),_0x4e62fc=X()['gapi'];return m(_0x4e62fc,_0x5bbffa,'internal-error'),_0x31f626['open']({'where':document['body'],'url':Vp(_0x5bbffa),'messageHandlersFilter':_0x4e62fc['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x20445c=>new Promise(async(_0x11810f,_0x138da3)=>{await _0x20445c['restyle']({'setHideOnLeave':!0x1});const _0x8c40f3=J(_0x5bbffa,'network-request-failed'),_0x703f4c=X()['setTimeout'](()=>{_0x138da3(_0x8c40f3);},xp['get']());function _0xc74e16(){X()['clearTimeout'](_0x703f4c),_0x11810f(_0x20445c);}_0x20445c['ping'](_0xc74e16)['then'](_0xc74e16,()=>{_0x138da3(_0x8c40f3);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x5afa6f){this['window']=_0x5afa6f,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x45e346,_0x53e792,_0x42beac,_0x3d7cf1=Gp,_0xdabd46=qp){const _0x2e6ab2=Math['max']((window['screen']['availHeight']-_0xdabd46)/0x2,0x0)['toString'](),_0x318508=Math['max']((window['screen']['availWidth']-_0x3d7cf1)/0x2,0x0)['toString']();let _0x1340bb='';const _0x3ba8e1={...$p,'width':_0x3d7cf1['toString'](),'height':_0xdabd46['toString'](),'top':_0x2e6ab2,'left':_0x318508},_0x307cca=W()['toLowerCase']();_0x42beac&&(_0x1340bb=ba(_0x307cca)?zp:_0x42beac),Ta(_0x307cca)&&(_0x53e792=_0x53e792||jp,_0x3ba8e1['scrollbars']='yes');const _0x35d843=Object['entries'](_0x3ba8e1)['reduce']((_0x1c6bb6,[_0x5eeb15,_0x1d9e69])=>''+_0x1c6bb6+_0x5eeb15+'='+_0x1d9e69+',','');if(Ef(_0x307cca)&&_0x1340bb!=='_self')return Yp(_0x53e792||'',_0x1340bb),new Dr(null);const _0x32d568=window['open'](_0x53e792||'',_0x1340bb,_0x35d843);m(_0x32d568,_0x45e346,'popup-blocked');try{_0x32d568['focus']();}catch{}return new Dr(_0x32d568);}function Yp(_0x111aa0,_0x236d33){const _0x3291b8=document['createElement']('a');_0x3291b8['href']=_0x111aa0,_0x3291b8['target']=_0x236d33;const _0x2b76b3=document['createEvent']('MouseEvent');_0x2b76b3['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3291b8['dispatchEvent'](_0x2b76b3);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x53d90f,_0x5bf958,_0x28262d,_0x5efdf4,_0xd0cb3d,_0x562d21){m(_0x53d90f['config']['authDomain'],_0x53d90f,'auth-domain-config-required'),m(_0x53d90f['config']['apiKey'],_0x53d90f,'invalid-api-key');const _0x2f5ea4={'apiKey':_0x53d90f['config']['apiKey'],'appName':_0x53d90f['name'],'authType':_0x28262d,'redirectUrl':_0x5efdf4,'v':ct,'eventId':_0xd0cb3d};if(_0x5bf958 instanceof xa){_0x5bf958['setDefaultLanguage'](_0x53d90f['languageCode']),_0x2f5ea4['providerId']=_0x5bf958['providerId']||'',hi(_0x5bf958['getCustomParameters']())||(_0x2f5ea4['customParameters']=JSON['stringify'](_0x5bf958['getCustomParameters']()));for(const [_0x3063ad,_0x4ff39b]of Object['entries']({}))_0x2f5ea4[_0x3063ad]=_0x4ff39b;}if(_0x5bf958 instanceof Qt){const _0x10d994=_0x5bf958['getScopes']()['filter'](_0xf091fb=>_0xf091fb!=='');_0x10d994['length']>0x0&&(_0x2f5ea4['scopes']=_0x10d994['join'](','));}_0x53d90f['tenantId']&&(_0x2f5ea4['tid']=_0x53d90f['tenantId']);const _0x1d018e=_0x2f5ea4;for(const _0x2d7dd6 of Object['keys'](_0x1d018e))_0x1d018e[_0x2d7dd6]===void 0x0&&delete _0x1d018e[_0x2d7dd6];const _0x4f5f17=await _0x53d90f['_getAppCheckToken'](),_0x2dd1d5=_0x4f5f17?'#'+Xp+'='+encodeURIComponent(_0x4f5f17):'';return Zp(_0x53d90f)+'?'+at(_0x1d018e)['slice'](0x1)+_0x2dd1d5;}function Zp({config:_0x241497}){return _0x241497['emulator']?Is(_0x241497,Jp):'https://'+_0x241497['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x103236,_0x4ebb04,_0x5b61c1,_0x2487dc){var _0x105dfb;ae((_0x105dfb=this['eventManagers'][_0x103236['_key']()])==null?void 0x0:_0x105dfb['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4c2303=await Mr(_0x103236,_0x4ebb04,_0x5b61c1,Ni(),_0x2487dc);return Kp(_0x103236,_0x4c2303,bs());}async['_openRedirect'](_0x5b9125,_0x4dcd35,_0x262a73,_0x1540f8){await this['_originValidation'](_0x5b9125);const _0x4631dc=await Mr(_0x5b9125,_0x4dcd35,_0x262a73,Ni(),_0x1540f8);return ip(_0x4631dc),new Promise(()=>{});}['_initialize'](_0x4fdf0a){const _0x384a50=_0x4fdf0a['_key']();if(this['eventManagers'][_0x384a50]){const {manager:_0x9e4f81,promise:_0x2300aa}=this['eventManagers'][_0x384a50];return _0x9e4f81?Promise['resolve'](_0x9e4f81):(ae(_0x2300aa,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2300aa);}const _0x25b013=this['initAndGetManager'](_0x4fdf0a);return this['eventManagers'][_0x384a50]={'promise':_0x25b013},_0x25b013['catch'](()=>{delete this['eventManagers'][_0x384a50];}),_0x25b013;}async['initAndGetManager'](_0x3fa349){const _0x1eb038=await Hp(_0x3fa349),_0x114f65=new bp(_0x3fa349);return _0x1eb038['register']('authEvent',_0x1b235f=>(m(_0x1b235f==null?void 0x0:_0x1b235f['authEvent'],_0x3fa349,'invalid-auth-event'),{'status':_0x114f65['onEvent'](_0x1b235f['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3fa349['_key']()]={'manager':_0x114f65},this['iframes'][_0x3fa349['_key']()]=_0x1eb038,_0x114f65;}['_isIframeWebStorageSupported'](_0x5b60a3,_0x3d910f){this['iframes'][_0x5b60a3['_key']()]['send'](li,{'type':li},_0x2c92bb=>{var _0xa800d5;const _0x32baad=(_0xa800d5=_0x2c92bb==null?void 0x0:_0x2c92bb[0x0])==null?void 0x0:_0xa800d5[li];_0x32baad!==void 0x0&&_0x3d910f(!!_0x32baad),K(_0x5b60a3,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x14cfa1){const _0x4d637d=_0x14cfa1['_key']();return this['originValidationPromises'][_0x4d637d]||(this['originValidationPromises'][_0x4d637d]=Pp(_0x14cfa1)),this['originValidationPromises'][_0x4d637d];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x3156b9){this['auth']=_0x3156b9,this['internalListeners']=new Map();}['getUid'](){var _0x583001;return this['assertAuthConfigured'](),((_0x583001=this['auth']['currentUser'])==null?void 0x0:_0x583001['uid'])||null;}async['getToken'](_0x130391){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x130391)}:null;}['addAuthTokenListener'](_0x28a30a){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x28a30a))return;const _0x49a03b=this['auth']['onIdTokenChanged'](_0x4d6dc3=>{_0x28a30a((_0x4d6dc3==null?void 0x0:_0x4d6dc3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x28a30a,_0x49a03b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x47fc2c){this['assertAuthConfigured']();const _0x553845=this['internalListeners']['get'](_0x47fc2c);_0x553845&&(this['internalListeners']['delete'](_0x47fc2c),_0x553845(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x3ebe18){switch(_0x3ebe18){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x19a1ef){et(new Me('auth',(_0x1f46e5,{options:_0x4b9ff6})=>{const _0x18b19c=_0x1f46e5['getProvider']('app')['getImmediate'](),_0xd66096=_0x1f46e5['getProvider']('heartbeat'),_0x33cf8d=_0x1f46e5['getProvider']('app-check-internal'),{apiKey:_0x1fcb3e,authDomain:_0x40d5c8}=_0x18b19c['options'];m(_0x1fcb3e&&!_0x1fcb3e['includes'](':'),'invalid-api-key',{'appName':_0x18b19c['name']});const _0x2d9be1={'apiKey':_0x1fcb3e,'authDomain':_0x40d5c8,'clientPlatform':_0x19a1ef,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x19a1ef)},_0x55a1ae=new bf(_0x18b19c,_0xd66096,_0x33cf8d,_0x2d9be1);return Lf(_0x55a1ae,_0x4b9ff6),_0x55a1ae;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x213f1b,_0x1219d2,_0x392683)=>{_0x213f1b['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x2ee8cf=>{const _0x508944=qe(_0x2ee8cf['getProvider']('auth')['getImmediate']());return(_0x5109d4=>new n_(_0x5109d4))(_0x508944);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x19a1ef)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x320317=>async _0x24769d=>{const _0x1b0a77=_0x24769d&&await _0x24769d['getIdTokenResult'](),_0x40d890=_0x1b0a77&&(new Date()['getTime']()-Date['parse'](_0x1b0a77['issuedAtTime']))/0x3e8;if(_0x40d890&&_0x40d890>o_)return;const _0x286ab0=_0x1b0a77==null?void 0x0:_0x1b0a77['token'];Fr!==_0x286ab0&&(Fr=_0x286ab0,await fetch(_0x320317,{'method':_0x286ab0?'POST':'DELETE','headers':_0x286ab0?{'Authorization':'Bearer\x20'+_0x286ab0}:{}}));};function O_(_0x51de7e=Qr()){const _0x341c57=Ui(_0x51de7e,'auth');if(_0x341c57['isInitialized']())return _0x341c57['getImmediate']();const _0x56d0a0=Mf(_0x51de7e,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2a4764=Gr('authTokenSyncURL');if(_0x2a4764&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xaf5a74=new URL(_0x2a4764,location['origin']);if(location['origin']===_0xaf5a74['origin']){const _0x3090ca=a_(_0xaf5a74['toString']());Jf(_0x56d0a0,_0x3090ca,()=>_0x3090ca(_0x56d0a0['currentUser'])),Qf(_0x56d0a0,_0x156223=>_0x3090ca(_0x156223));}}const _0x38c887=Hr('auth');return _0x38c887&&xf(_0x56d0a0,'http://'+_0x38c887),_0x56d0a0;}function c_(){var _0x2181fc;return((_0x2181fc=document['getElementsByTagName']('head'))==null?void 0x0:_0x2181fc[0x0])??document;}Rf({'loadJS'(_0x3e0aee){return new Promise((_0x4a4b57,_0x3099f1)=>{const _0x2089ea=document['createElement']('script');_0x2089ea['setAttribute']('src',_0x3e0aee),_0x2089ea['onload']=_0x4a4b57,_0x2089ea['onerror']=_0x51fa28=>{const _0x24f1ea=J('internal-error');_0x24f1ea['customData']=_0x51fa28,_0x3099f1(_0x24f1ea);},_0x2089ea['type']='text/javascript',_0x2089ea['charset']='UTF-8',c_()['appendChild'](_0x2089ea);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};