const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x310725,_0x302f38){if(!_0x310725)throw ot(_0x302f38);},ot=function(_0x331818){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x331818);},Wr=function(_0x4233a8){const _0x23ddb7=[];let _0x3a5501=0x0;for(let _0x28ce71=0x0;_0x28ce71<_0x4233a8['length'];_0x28ce71++){let _0x2eae06=_0x4233a8['charCodeAt'](_0x28ce71);_0x2eae06<0x80?_0x23ddb7[_0x3a5501++]=_0x2eae06:_0x2eae06<0x800?(_0x23ddb7[_0x3a5501++]=_0x2eae06>>0x6|0xc0,_0x23ddb7[_0x3a5501++]=_0x2eae06&0x3f|0x80):(_0x2eae06&0xfc00)===0xd800&&_0x28ce71+0x1<_0x4233a8['length']&&(_0x4233a8['charCodeAt'](_0x28ce71+0x1)&0xfc00)===0xdc00?(_0x2eae06=0x10000+((_0x2eae06&0x3ff)<<0xa)+(_0x4233a8['charCodeAt'](++_0x28ce71)&0x3ff),_0x23ddb7[_0x3a5501++]=_0x2eae06>>0x12|0xf0,_0x23ddb7[_0x3a5501++]=_0x2eae06>>0xc&0x3f|0x80,_0x23ddb7[_0x3a5501++]=_0x2eae06>>0x6&0x3f|0x80,_0x23ddb7[_0x3a5501++]=_0x2eae06&0x3f|0x80):(_0x23ddb7[_0x3a5501++]=_0x2eae06>>0xc|0xe0,_0x23ddb7[_0x3a5501++]=_0x2eae06>>0x6&0x3f|0x80,_0x23ddb7[_0x3a5501++]=_0x2eae06&0x3f|0x80);}return _0x23ddb7;},Za=function(_0x2dd4dd){const _0x11e018=[];let _0x42f67f=0x0,_0x491b51=0x0;for(;_0x42f67f<_0x2dd4dd['length'];){const _0x307631=_0x2dd4dd[_0x42f67f++];if(_0x307631<0x80)_0x11e018[_0x491b51++]=String['fromCharCode'](_0x307631);else{if(_0x307631>0xbf&&_0x307631<0xe0){const _0x28bab6=_0x2dd4dd[_0x42f67f++];_0x11e018[_0x491b51++]=String['fromCharCode']((_0x307631&0x1f)<<0x6|_0x28bab6&0x3f);}else{if(_0x307631>0xef&&_0x307631<0x16d){const _0x36ef14=_0x2dd4dd[_0x42f67f++],_0x46f6a0=_0x2dd4dd[_0x42f67f++],_0x561c6f=_0x2dd4dd[_0x42f67f++],_0x4cb6c2=((_0x307631&0x7)<<0x12|(_0x36ef14&0x3f)<<0xc|(_0x46f6a0&0x3f)<<0x6|_0x561c6f&0x3f)-0x10000;_0x11e018[_0x491b51++]=String['fromCharCode'](0xd800+(_0x4cb6c2>>0xa)),_0x11e018[_0x491b51++]=String['fromCharCode'](0xdc00+(_0x4cb6c2&0x3ff));}else{const _0x48a66f=_0x2dd4dd[_0x42f67f++],_0x4aebae=_0x2dd4dd[_0x42f67f++];_0x11e018[_0x491b51++]=String['fromCharCode']((_0x307631&0xf)<<0xc|(_0x48a66f&0x3f)<<0x6|_0x4aebae&0x3f);}}}}return _0x11e018['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xab0b47,_0x2d55f7){if(!Array['isArray'](_0xab0b47))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x352b23=_0x2d55f7?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x42c900=[];for(let _0x5b6a3b=0x0;_0x5b6a3b<_0xab0b47['length'];_0x5b6a3b+=0x3){const _0xbb42ac=_0xab0b47[_0x5b6a3b],_0x4257ba=_0x5b6a3b+0x1<_0xab0b47['length'],_0x1c725c=_0x4257ba?_0xab0b47[_0x5b6a3b+0x1]:0x0,_0xf757e1=_0x5b6a3b+0x2<_0xab0b47['length'],_0x70b45c=_0xf757e1?_0xab0b47[_0x5b6a3b+0x2]:0x0,_0x1a4734=_0xbb42ac>>0x2,_0x5d1ca2=(_0xbb42ac&0x3)<<0x4|_0x1c725c>>0x4;let _0x3edd28=(_0x1c725c&0xf)<<0x2|_0x70b45c>>0x6,_0x1a38c3=_0x70b45c&0x3f;_0xf757e1||(_0x1a38c3=0x40,_0x4257ba||(_0x3edd28=0x40)),_0x42c900['push'](_0x352b23[_0x1a4734],_0x352b23[_0x5d1ca2],_0x352b23[_0x3edd28],_0x352b23[_0x1a38c3]);}return _0x42c900['join']('');},'encodeString'(_0x8c7146,_0x331445){return this['HAS_NATIVE_SUPPORT']&&!_0x331445?btoa(_0x8c7146):this['encodeByteArray'](Wr(_0x8c7146),_0x331445);},'decodeString'(_0x4857be,_0x37bca7){return this['HAS_NATIVE_SUPPORT']&&!_0x37bca7?atob(_0x4857be):Za(this['decodeStringToByteArray'](_0x4857be,_0x37bca7));},'decodeStringToByteArray'(_0x28f4eb,_0x519ed5){this['init_']();const _0x5c6178=_0x519ed5?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x489a8c=[];for(let _0x115115=0x0;_0x115115<_0x28f4eb['length'];){const _0x214e12=_0x5c6178[_0x28f4eb['charAt'](_0x115115++)],_0x1a3fc0=_0x115115<_0x28f4eb['length']?_0x5c6178[_0x28f4eb['charAt'](_0x115115)]:0x0;++_0x115115;const _0x32add0=_0x115115<_0x28f4eb['length']?_0x5c6178[_0x28f4eb['charAt'](_0x115115)]:0x40;++_0x115115;const _0x4ab6d7=_0x115115<_0x28f4eb['length']?_0x5c6178[_0x28f4eb['charAt'](_0x115115)]:0x40;if(++_0x115115,_0x214e12==null||_0x1a3fc0==null||_0x32add0==null||_0x4ab6d7==null)throw new ec();const _0x3e2e63=_0x214e12<<0x2|_0x1a3fc0>>0x4;if(_0x489a8c['push'](_0x3e2e63),_0x32add0!==0x40){const _0x4077f3=_0x1a3fc0<<0x4&0xf0|_0x32add0>>0x2;if(_0x489a8c['push'](_0x4077f3),_0x4ab6d7!==0x40){const _0x25ddbf=_0x32add0<<0x6&0xc0|_0x4ab6d7;_0x489a8c['push'](_0x25ddbf);}}}return _0x489a8c;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x434515=0x0;_0x434515<this['ENCODED_VALS']['length'];_0x434515++)this['byteToCharMap_'][_0x434515]=this['ENCODED_VALS']['charAt'](_0x434515),this['charToByteMap_'][this['byteToCharMap_'][_0x434515]]=_0x434515,this['byteToCharMapWebSafe_'][_0x434515]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x434515),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x434515]]=_0x434515,_0x434515>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x434515)]=_0x434515,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x434515)]=_0x434515);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x5a5141){const _0x5577e3=Wr(_0x5a5141);return Di['encodeByteArray'](_0x5577e3,!0x0);},an=function(_0x1e2dc8){return Br(_0x1e2dc8)['replace'](/\./g,'');},cn=function(_0x3a1e39){try{return Di['decodeString'](_0x3a1e39,!0x0);}catch(_0x166aea){console['error']('base64Decode\x20failed:\x20',_0x166aea);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x5427f1){return Vr(void 0x0,_0x5427f1);}function Vr(_0x3512ca,_0x175954){if(!(_0x175954 instanceof Object))return _0x175954;switch(_0x175954['constructor']){case Date:const _0x1d2dfd=_0x175954;return new Date(_0x1d2dfd['getTime']());case Object:_0x3512ca===void 0x0&&(_0x3512ca={});break;case Array:_0x3512ca=[];break;default:return _0x175954;}for(const _0x53b482 in _0x175954)!_0x175954['hasOwnProperty'](_0x53b482)||!nc(_0x53b482)||(_0x3512ca[_0x53b482]=Vr(_0x3512ca[_0x53b482],_0x175954[_0x53b482]));return _0x3512ca;}function nc(_0xbeac3c){return _0xbeac3c!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x1fc582=As['__FIREBASE_DEFAULTS__'];if(_0x1fc582)return JSON['parse'](_0x1fc582);},oc=()=>{if(typeof document>'u')return;let _0x254324;try{_0x254324=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5b7233=_0x254324&&cn(_0x254324[0x1]);return _0x5b7233&&JSON['parse'](_0x5b7233);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x1b5570){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1b5570);return;}},Hr=_0x272660=>{var _0x5363bc,_0x245d54;return(_0x245d54=(_0x5363bc=Mi())==null?void 0x0:_0x5363bc['emulatorHosts'])==null?void 0x0:_0x245d54[_0x272660];},ac=_0x406bc4=>{const _0x27495b=Hr(_0x406bc4);if(!_0x27495b)return;const _0x38490c=_0x27495b['lastIndexOf'](':');if(_0x38490c<=0x0||_0x38490c+0x1===_0x27495b['length'])throw new Error('Invalid\x20host\x20'+_0x27495b+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5a2689=parseInt(_0x27495b['substring'](_0x38490c+0x1),0xa);return _0x27495b[0x0]==='['?[_0x27495b['substring'](0x1,_0x38490c-0x1),_0x5a2689]:[_0x27495b['substring'](0x0,_0x38490c),_0x5a2689];},$r=()=>{var _0x48757c;return(_0x48757c=Mi())==null?void 0x0:_0x48757c['config'];},Gr=_0x461c74=>{var _0x3f7896;return(_0x3f7896=Mi())==null?void 0x0:_0x3f7896['_'+_0x461c74];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x453554,_0x2953a4)=>{this['resolve']=_0x453554,this['reject']=_0x2953a4;});}['wrapCallback'](_0x12b75c){return(_0xa732ca,_0x477a76)=>{_0xa732ca?this['reject'](_0xa732ca):this['resolve'](_0x477a76),typeof _0x12b75c=='function'&&(this['promise']['catch'](()=>{}),_0x12b75c['length']===0x1?_0x12b75c(_0xa732ca):_0x12b75c(_0xa732ca,_0x477a76));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x45e57b,_0x166080){if(_0x45e57b['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x31afc8={'alg':'none','type':'JWT'},_0x464566=_0x166080||'demo-project',_0x4cca86=_0x45e57b['iat']||0x0,_0x7731e=_0x45e57b['sub']||_0x45e57b['user_id'];if(!_0x7731e)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x19c20f={'iss':'https://securetoken.google.com/'+_0x464566,'aud':_0x464566,'iat':_0x4cca86,'exp':_0x4cca86+0xe10,'auth_time':_0x4cca86,'sub':_0x7731e,'user_id':_0x7731e,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x45e57b};return[an(JSON['stringify'](_0x31afc8)),an(JSON['stringify'](_0x19c20f)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x16e180=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x16e180=='object'&&_0x16e180['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x2c3b26=W();return _0x2c3b26['indexOf']('MSIE\x20')>=0x0||_0x2c3b26['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x30ecdc,_0x44643d)=>{try{let _0x3e25c4=!0x0;const _0x1371a0='validate-browser-context-for-indexeddb-analytics-module',_0x3fe6c9=self['indexedDB']['open'](_0x1371a0);_0x3fe6c9['onsuccess']=()=>{_0x3fe6c9['result']['close'](),_0x3e25c4||self['indexedDB']['deleteDatabase'](_0x1371a0),_0x30ecdc(!0x0);},_0x3fe6c9['onupgradeneeded']=()=>{_0x3e25c4=!0x1;},_0x3fe6c9['onerror']=()=>{var _0x88bdf8;_0x44643d(((_0x88bdf8=_0x3fe6c9['error'])==null?void 0x0:_0x88bdf8['message'])||'');};}catch(_0x41add7){_0x44643d(_0x41add7);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x59192e,_0x30bf47,_0x528acc){super(_0x30bf47),this['code']=_0x59192e,this['customData']=_0x528acc,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2137fd,_0x5f531b,_0x5b6789){this['service']=_0x2137fd,this['serviceName']=_0x5f531b,this['errors']=_0x5b6789;}['create'](_0x384592,..._0x1bd183){const _0x349253=_0x1bd183[0x0]||{},_0x1087bf=this['service']+'/'+_0x384592,_0x34a11f=this['errors'][_0x384592],_0x59fb6a=_0x34a11f?gc(_0x34a11f,_0x349253):'Error',_0x51e573=this['serviceName']+':\x20'+_0x59fb6a+'\x20('+_0x1087bf+').';return new Se(_0x1087bf,_0x51e573,_0x349253);}}function gc(_0x3356f8,_0x3ed518){return _0x3356f8['replace'](mc,(_0x37ce66,_0x35a8f5)=>{const _0x1e702d=_0x3ed518[_0x35a8f5];return _0x1e702d!=null?String(_0x1e702d):'<'+_0x35a8f5+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x104dee){return JSON['parse'](_0x104dee);}function O(_0x2dc845){return JSON['stringify'](_0x2dc845);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x447a3c){let _0x4f3349={},_0x423edd={},_0x580930={},_0x31459a='';try{const _0x30a867=_0x447a3c['split']('.');_0x4f3349=bt(cn(_0x30a867[0x0])||''),_0x423edd=bt(cn(_0x30a867[0x1])||''),_0x31459a=_0x30a867[0x2],_0x580930=_0x423edd['d']||{},delete _0x423edd['d'];}catch{}return{'header':_0x4f3349,'claims':_0x423edd,'data':_0x580930,'signature':_0x31459a};},yc=function(_0xdd9208){const _0x3bd0cd=zr(_0xdd9208),_0x451f79=_0x3bd0cd['claims'];return!!_0x451f79&&typeof _0x451f79=='object'&&_0x451f79['hasOwnProperty']('iat');},vc=function(_0x25f03b){const _0x1b5adc=zr(_0x25f03b)['claims'];return typeof _0x1b5adc=='object'&&_0x1b5adc['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x56de7f,_0x2186e1){return Object['prototype']['hasOwnProperty']['call'](_0x56de7f,_0x2186e1);}function Oe(_0x124b2d,_0x241174){if(Object['prototype']['hasOwnProperty']['call'](_0x124b2d,_0x241174))return _0x124b2d[_0x241174];}function hi(_0x5c894c){for(const _0x56de16 in _0x5c894c)if(Object['prototype']['hasOwnProperty']['call'](_0x5c894c,_0x56de16))return!0x1;return!0x0;}function ln(_0x12b10b,_0x512ec2,_0x1e9a5b){const _0x333e14={};for(const _0x3e1ac9 in _0x12b10b)Object['prototype']['hasOwnProperty']['call'](_0x12b10b,_0x3e1ac9)&&(_0x333e14[_0x3e1ac9]=_0x512ec2['call'](_0x1e9a5b,_0x12b10b[_0x3e1ac9],_0x3e1ac9,_0x12b10b));return _0x333e14;}function De(_0x40de29,_0x1f39f3){if(_0x40de29===_0x1f39f3)return!0x0;const _0x25dfeb=Object['keys'](_0x40de29),_0x3fe75f=Object['keys'](_0x1f39f3);for(const _0x27c83b of _0x25dfeb){if(!_0x3fe75f['includes'](_0x27c83b))return!0x1;const _0x495d64=_0x40de29[_0x27c83b],_0x1a4c71=_0x1f39f3[_0x27c83b];if(ks(_0x495d64)&&ks(_0x1a4c71)){if(!De(_0x495d64,_0x1a4c71))return!0x1;}else{if(_0x495d64!==_0x1a4c71)return!0x1;}}for(const _0x1750d5 of _0x3fe75f)if(!_0x25dfeb['includes'](_0x1750d5))return!0x1;return!0x0;}function ks(_0xcac8e3){return _0xcac8e3!==null&&typeof _0xcac8e3=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0xa7cbf5){const _0x2f7a1a=[];for(const [_0x43ca96,_0x444c35]of Object['entries'](_0xa7cbf5))Array['isArray'](_0x444c35)?_0x444c35['forEach'](_0x40d76b=>{_0x2f7a1a['push'](encodeURIComponent(_0x43ca96)+'='+encodeURIComponent(_0x40d76b));}):_0x2f7a1a['push'](encodeURIComponent(_0x43ca96)+'='+encodeURIComponent(_0x444c35));return _0x2f7a1a['length']?'&'+_0x2f7a1a['join']('&'):'';}function yt(_0x13ab35){const _0x333054={};return _0x13ab35['replace'](/^\?/,'')['split']('&')['forEach'](_0x18d4a1=>{if(_0x18d4a1){const [_0x23c2a1,_0x10381d]=_0x18d4a1['split']('=');_0x333054[decodeURIComponent(_0x23c2a1)]=decodeURIComponent(_0x10381d);}}),_0x333054;}function vt(_0x5d57a3){const _0x595948=_0x5d57a3['indexOf']('?');if(!_0x595948)return'';const _0x40a6ee=_0x5d57a3['indexOf']('#',_0x595948);return _0x5d57a3['substring'](_0x595948,_0x40a6ee>0x0?_0x40a6ee:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xa5bfbb=0x1;_0xa5bfbb<this['blockSize'];++_0xa5bfbb)this['pad_'][_0xa5bfbb]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4663a6,_0x328c76){_0x328c76||(_0x328c76=0x0);const _0x4c51fd=this['W_'];if(typeof _0x4663a6=='string'){for(let _0x51e77d=0x0;_0x51e77d<0x10;_0x51e77d++)_0x4c51fd[_0x51e77d]=_0x4663a6['charCodeAt'](_0x328c76)<<0x18|_0x4663a6['charCodeAt'](_0x328c76+0x1)<<0x10|_0x4663a6['charCodeAt'](_0x328c76+0x2)<<0x8|_0x4663a6['charCodeAt'](_0x328c76+0x3),_0x328c76+=0x4;}else{for(let _0x42ef0d=0x0;_0x42ef0d<0x10;_0x42ef0d++)_0x4c51fd[_0x42ef0d]=_0x4663a6[_0x328c76]<<0x18|_0x4663a6[_0x328c76+0x1]<<0x10|_0x4663a6[_0x328c76+0x2]<<0x8|_0x4663a6[_0x328c76+0x3],_0x328c76+=0x4;}for(let _0x256350=0x10;_0x256350<0x50;_0x256350++){const _0x5380ee=_0x4c51fd[_0x256350-0x3]^_0x4c51fd[_0x256350-0x8]^_0x4c51fd[_0x256350-0xe]^_0x4c51fd[_0x256350-0x10];_0x4c51fd[_0x256350]=(_0x5380ee<<0x1|_0x5380ee>>>0x1f)&0xffffffff;}let _0x2a5995=this['chain_'][0x0],_0x43c7fa=this['chain_'][0x1],_0x52054c=this['chain_'][0x2],_0x413b16=this['chain_'][0x3],_0x1b4cdf=this['chain_'][0x4],_0x32b85f,_0x453deb;for(let _0x31f9f7=0x0;_0x31f9f7<0x50;_0x31f9f7++){_0x31f9f7<0x28?_0x31f9f7<0x14?(_0x32b85f=_0x413b16^_0x43c7fa&(_0x52054c^_0x413b16),_0x453deb=0x5a827999):(_0x32b85f=_0x43c7fa^_0x52054c^_0x413b16,_0x453deb=0x6ed9eba1):_0x31f9f7<0x3c?(_0x32b85f=_0x43c7fa&_0x52054c|_0x413b16&(_0x43c7fa|_0x52054c),_0x453deb=0x8f1bbcdc):(_0x32b85f=_0x43c7fa^_0x52054c^_0x413b16,_0x453deb=0xca62c1d6);const _0x255425=(_0x2a5995<<0x5|_0x2a5995>>>0x1b)+_0x32b85f+_0x1b4cdf+_0x453deb+_0x4c51fd[_0x31f9f7]&0xffffffff;_0x1b4cdf=_0x413b16,_0x413b16=_0x52054c,_0x52054c=(_0x43c7fa<<0x1e|_0x43c7fa>>>0x2)&0xffffffff,_0x43c7fa=_0x2a5995,_0x2a5995=_0x255425;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2a5995&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x43c7fa&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52054c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x413b16&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1b4cdf&0xffffffff;}['update'](_0x5b5c23,_0x59bb00){if(_0x5b5c23==null)return;_0x59bb00===void 0x0&&(_0x59bb00=_0x5b5c23['length']);const _0x475ef8=_0x59bb00-this['blockSize'];let _0x512ef0=0x0;const _0x4c4059=this['buf_'];let _0x120d6c=this['inbuf_'];for(;_0x512ef0<_0x59bb00;){if(_0x120d6c===0x0){for(;_0x512ef0<=_0x475ef8;)this['compress_'](_0x5b5c23,_0x512ef0),_0x512ef0+=this['blockSize'];}if(typeof _0x5b5c23=='string'){for(;_0x512ef0<_0x59bb00;)if(_0x4c4059[_0x120d6c]=_0x5b5c23['charCodeAt'](_0x512ef0),++_0x120d6c,++_0x512ef0,_0x120d6c===this['blockSize']){this['compress_'](_0x4c4059),_0x120d6c=0x0;break;}}else{for(;_0x512ef0<_0x59bb00;)if(_0x4c4059[_0x120d6c]=_0x5b5c23[_0x512ef0],++_0x120d6c,++_0x512ef0,_0x120d6c===this['blockSize']){this['compress_'](_0x4c4059),_0x120d6c=0x0;break;}}}this['inbuf_']=_0x120d6c,this['total_']+=_0x59bb00;}['digest'](){const _0x68643e=[];let _0x351b92=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x39e4c3=this['blockSize']-0x1;_0x39e4c3>=0x38;_0x39e4c3--)this['buf_'][_0x39e4c3]=_0x351b92&0xff,_0x351b92/=0x100;this['compress_'](this['buf_']);let _0x1c7cea=0x0;for(let _0xa1d012=0x0;_0xa1d012<0x5;_0xa1d012++)for(let _0x5dd0b8=0x18;_0x5dd0b8>=0x0;_0x5dd0b8-=0x8)_0x68643e[_0x1c7cea]=this['chain_'][_0xa1d012]>>_0x5dd0b8&0xff,++_0x1c7cea;return _0x68643e;}}function Ic(_0x4363d4,_0x1c2575){const _0x2422d1=new wc(_0x4363d4,_0x1c2575);return _0x2422d1['subscribe']['bind'](_0x2422d1);}class wc{constructor(_0x2e941f,_0x194cca){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x194cca,this['task']['then'](()=>{_0x2e941f(this);})['catch'](_0x44ef3c=>{this['error'](_0x44ef3c);});}['next'](_0x421649){this['forEachObserver'](_0x3f2ad8=>{_0x3f2ad8['next'](_0x421649);});}['error'](_0x110085){this['forEachObserver'](_0x43fbf3=>{_0x43fbf3['error'](_0x110085);}),this['close'](_0x110085);}['complete'](){this['forEachObserver'](_0x4dbecd=>{_0x4dbecd['complete']();}),this['close']();}['subscribe'](_0x16fabf,_0x5ed4e2,_0x17e8b3){let _0x43d9e4;if(_0x16fabf===void 0x0&&_0x5ed4e2===void 0x0&&_0x17e8b3===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x16fabf,['next','error','complete'])?_0x43d9e4=_0x16fabf:_0x43d9e4={'next':_0x16fabf,'error':_0x5ed4e2,'complete':_0x17e8b3},_0x43d9e4['next']===void 0x0&&(_0x43d9e4['next']=Qn),_0x43d9e4['error']===void 0x0&&(_0x43d9e4['error']=Qn),_0x43d9e4['complete']===void 0x0&&(_0x43d9e4['complete']=Qn);const _0x476f58=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x43d9e4['error'](this['finalError']):_0x43d9e4['complete']();}catch{}}),this['observers']['push'](_0x43d9e4),_0x476f58;}['unsubscribeOne'](_0x3a0b25){this['observers']===void 0x0||this['observers'][_0x3a0b25]===void 0x0||(delete this['observers'][_0x3a0b25],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x33a742){if(!this['finalized']){for(let _0xd44674=0x0;_0xd44674<this['observers']['length'];_0xd44674++)this['sendOne'](_0xd44674,_0x33a742);}}['sendOne'](_0x2fec50,_0x2f07ad){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2fec50]!==void 0x0)try{_0x2f07ad(this['observers'][_0x2fec50]);}catch(_0x391090){typeof console<'u'&&console['error']&&console['error'](_0x391090);}});}['close'](_0x1751df){this['finalized']||(this['finalized']=!0x0,_0x1751df!==void 0x0&&(this['finalError']=_0x1751df),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3ca9cb,_0x36bdbc){if(typeof _0x3ca9cb!='object'||_0x3ca9cb===null)return!0x1;for(const _0x4fc754 of _0x36bdbc)if(_0x4fc754 in _0x3ca9cb&&typeof _0x3ca9cb[_0x4fc754]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x5edab0,_0x36573f){return _0x5edab0+'\x20failed:\x20'+_0x36573f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x46aa7f){const _0x2f1e18=[];let _0x50229c=0x0;for(let _0x44000c=0x0;_0x44000c<_0x46aa7f['length'];_0x44000c++){let _0x5488fc=_0x46aa7f['charCodeAt'](_0x44000c);if(_0x5488fc>=0xd800&&_0x5488fc<=0xdbff){const _0x3b52b2=_0x5488fc-0xd800;_0x44000c++,f(_0x44000c<_0x46aa7f['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x40927d=_0x46aa7f['charCodeAt'](_0x44000c)-0xdc00;_0x5488fc=0x10000+(_0x3b52b2<<0xa)+_0x40927d;}_0x5488fc<0x80?_0x2f1e18[_0x50229c++]=_0x5488fc:_0x5488fc<0x800?(_0x2f1e18[_0x50229c++]=_0x5488fc>>0x6|0xc0,_0x2f1e18[_0x50229c++]=_0x5488fc&0x3f|0x80):_0x5488fc<0x10000?(_0x2f1e18[_0x50229c++]=_0x5488fc>>0xc|0xe0,_0x2f1e18[_0x50229c++]=_0x5488fc>>0x6&0x3f|0x80,_0x2f1e18[_0x50229c++]=_0x5488fc&0x3f|0x80):(_0x2f1e18[_0x50229c++]=_0x5488fc>>0x12|0xf0,_0x2f1e18[_0x50229c++]=_0x5488fc>>0xc&0x3f|0x80,_0x2f1e18[_0x50229c++]=_0x5488fc>>0x6&0x3f|0x80,_0x2f1e18[_0x50229c++]=_0x5488fc&0x3f|0x80);}return _0x2f1e18;},Pn=function(_0xd6fbc1){let _0x2dc56f=0x0;for(let _0x2814e9=0x0;_0x2814e9<_0xd6fbc1['length'];_0x2814e9++){const _0x92f237=_0xd6fbc1['charCodeAt'](_0x2814e9);_0x92f237<0x80?_0x2dc56f++:_0x92f237<0x800?_0x2dc56f+=0x2:_0x92f237>=0xd800&&_0x92f237<=0xdbff?(_0x2dc56f+=0x4,_0x2814e9++):_0x2dc56f+=0x3;}return _0x2dc56f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4ce645){return _0x4ce645&&_0x4ce645['_delegate']?_0x4ce645['_delegate']:_0x4ce645;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x34feb3){try{return(_0x34feb3['startsWith']('http://')||_0x34feb3['startsWith']('https://')?new URL(_0x34feb3)['hostname']:_0x34feb3)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x106c95){return(await fetch(_0x106c95,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4e5fcc,_0x353652,_0x3702b4){this['name']=_0x4e5fcc,this['instanceFactory']=_0x353652,this['type']=_0x3702b4,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x58110a){return this['instantiationMode']=_0x58110a,this;}['setMultipleInstances'](_0x458c22){return this['multipleInstances']=_0x458c22,this;}['setServiceProps'](_0x9bddb9){return this['serviceProps']=_0x9bddb9,this;}['setInstanceCreatedCallback'](_0xb5592d){return this['onInstanceCreated']=_0xb5592d,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x34bd56,_0x22b6d9){this['name']=_0x34bd56,this['container']=_0x22b6d9,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3d9e91){const _0x568ccc=this['normalizeInstanceIdentifier'](_0x3d9e91);if(!this['instancesDeferred']['has'](_0x568ccc)){const _0x19142a=new Ve();if(this['instancesDeferred']['set'](_0x568ccc,_0x19142a),this['isInitialized'](_0x568ccc)||this['shouldAutoInitialize']())try{const _0x41f8af=this['getOrInitializeService']({'instanceIdentifier':_0x568ccc});_0x41f8af&&_0x19142a['resolve'](_0x41f8af);}catch{}}return this['instancesDeferred']['get'](_0x568ccc)['promise'];}['getImmediate'](_0x1dadd1){const _0x3564b3=this['normalizeInstanceIdentifier'](_0x1dadd1==null?void 0x0:_0x1dadd1['identifier']),_0x414279=(_0x1dadd1==null?void 0x0:_0x1dadd1['optional'])??!0x1;if(this['isInitialized'](_0x3564b3)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3564b3});}catch(_0x1907d5){if(_0x414279)return null;throw _0x1907d5;}else{if(_0x414279)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2668b9){if(_0x2668b9['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2668b9['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2668b9,!!this['shouldAutoInitialize']()){if(Rc(_0x2668b9))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1d1022,_0x31fd4a]of this['instancesDeferred']['entries']()){const _0x2d25ae=this['normalizeInstanceIdentifier'](_0x1d1022);try{const _0x12dc60=this['getOrInitializeService']({'instanceIdentifier':_0x2d25ae});_0x31fd4a['resolve'](_0x12dc60);}catch{}}}}['clearInstance'](_0x302e9b=ke){this['instancesDeferred']['delete'](_0x302e9b),this['instancesOptions']['delete'](_0x302e9b),this['instances']['delete'](_0x302e9b);}async['delete'](){const _0x297278=Array['from'](this['instances']['values']());await Promise['all']([..._0x297278['filter'](_0x437e2d=>'INTERNAL'in _0x437e2d)['map'](_0x4742fe=>_0x4742fe['INTERNAL']['delete']()),..._0x297278['filter'](_0x1f2af7=>'_delete'in _0x1f2af7)['map'](_0x2f50b5=>_0x2f50b5['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2526f0=ke){return this['instances']['has'](_0x2526f0);}['getOptions'](_0x4d0689=ke){return this['instancesOptions']['get'](_0x4d0689)||{};}['initialize'](_0x435ccf={}){const {options:_0x4adab1={}}=_0x435ccf,_0xe5f97=this['normalizeInstanceIdentifier'](_0x435ccf['instanceIdentifier']);if(this['isInitialized'](_0xe5f97))throw Error(this['name']+'('+_0xe5f97+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x256f67=this['getOrInitializeService']({'instanceIdentifier':_0xe5f97,'options':_0x4adab1});for(const [_0x545e30,_0x171065]of this['instancesDeferred']['entries']()){const _0x4fc768=this['normalizeInstanceIdentifier'](_0x545e30);_0xe5f97===_0x4fc768&&_0x171065['resolve'](_0x256f67);}return _0x256f67;}['onInit'](_0xda391a,_0x2f6629){const _0x2e1b5b=this['normalizeInstanceIdentifier'](_0x2f6629),_0x41c791=this['onInitCallbacks']['get'](_0x2e1b5b)??new Set();_0x41c791['add'](_0xda391a),this['onInitCallbacks']['set'](_0x2e1b5b,_0x41c791);const _0x2e5b60=this['instances']['get'](_0x2e1b5b);return _0x2e5b60&&_0xda391a(_0x2e5b60,_0x2e1b5b),()=>{_0x41c791['delete'](_0xda391a);};}['invokeOnInitCallbacks'](_0x2d9575,_0x71ab61){const _0x583b05=this['onInitCallbacks']['get'](_0x71ab61);if(_0x583b05){for(const _0x28304d of _0x583b05)try{_0x28304d(_0x2d9575,_0x71ab61);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x406f29,options:_0x42c0d9={}}){let _0x1467f6=this['instances']['get'](_0x406f29);if(!_0x1467f6&&this['component']&&(_0x1467f6=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x406f29),'options':_0x42c0d9}),this['instances']['set'](_0x406f29,_0x1467f6),this['instancesOptions']['set'](_0x406f29,_0x42c0d9),this['invokeOnInitCallbacks'](_0x1467f6,_0x406f29),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x406f29,_0x1467f6);}catch{}return _0x1467f6||null;}['normalizeInstanceIdentifier'](_0x3c5caf=ke){return this['component']?this['component']['multipleInstances']?_0x3c5caf:ke:_0x3c5caf;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x436645){return _0x436645===ke?void 0x0:_0x436645;}function Rc(_0x4bb07f){return _0x4bb07f['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x7c86b2){this['name']=_0x7c86b2,this['providers']=new Map();}['addComponent'](_0x1e5d04){const _0x55d75b=this['getProvider'](_0x1e5d04['name']);if(_0x55d75b['isComponentSet']())throw new Error('Component\x20'+_0x1e5d04['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x55d75b['setComponent'](_0x1e5d04);}['addOrOverwriteComponent'](_0x580019){this['getProvider'](_0x580019['name'])['isComponentSet']()&&this['providers']['delete'](_0x580019['name']),this['addComponent'](_0x580019);}['getProvider'](_0x31366c){if(this['providers']['has'](_0x31366c))return this['providers']['get'](_0x31366c);const _0x5e275c=new Sc(_0x31366c,this);return this['providers']['set'](_0x31366c,_0x5e275c),_0x5e275c;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4a7dc9){_0x4a7dc9[_0x4a7dc9['DEBUG']=0x0]='DEBUG',_0x4a7dc9[_0x4a7dc9['VERBOSE']=0x1]='VERBOSE',_0x4a7dc9[_0x4a7dc9['INFO']=0x2]='INFO',_0x4a7dc9[_0x4a7dc9['WARN']=0x3]='WARN',_0x4a7dc9[_0x4a7dc9['ERROR']=0x4]='ERROR',_0x4a7dc9[_0x4a7dc9['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x5f0f99,_0x3a7c53,..._0x19a3a5)=>{if(_0x3a7c53<_0x5f0f99['logLevel'])return;const _0x2785d5=new Date()['toISOString'](),_0xdc157b=Pc[_0x3a7c53];if(_0xdc157b)console[_0xdc157b]('['+_0x2785d5+']\x20\x20'+_0x5f0f99['name']+':',..._0x19a3a5);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3a7c53+')');};class xi{constructor(_0x30cdf3){this['name']=_0x30cdf3,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2ebd42){if(!(_0x2ebd42 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2ebd42+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2ebd42;}['setLogLevel'](_0xf27321){this['_logLevel']=typeof _0xf27321=='string'?kc[_0xf27321]:_0xf27321;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x158ed4){if(typeof _0x158ed4!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x158ed4;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1c8852){this['_userLogHandler']=_0x1c8852;}['debug'](..._0x2bbe71){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2bbe71),this['_logHandler'](this,T['DEBUG'],..._0x2bbe71);}['log'](..._0x389028){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x389028),this['_logHandler'](this,T['VERBOSE'],..._0x389028);}['info'](..._0x5a9f10){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5a9f10),this['_logHandler'](this,T['INFO'],..._0x5a9f10);}['warn'](..._0x541110){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x541110),this['_logHandler'](this,T['WARN'],..._0x541110);}['error'](..._0x5d9fbf){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5d9fbf),this['_logHandler'](this,T['ERROR'],..._0x5d9fbf);}}const Dc=(_0x49fd8f,_0x525fbd)=>_0x525fbd['some'](_0x7b4b21=>_0x49fd8f instanceof _0x7b4b21);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0xea4ac3){const _0x9690d4=new Promise((_0x4f821e,_0x407ece)=>{const _0x5608c7=()=>{_0xea4ac3['removeEventListener']('success',_0x2db0db),_0xea4ac3['removeEventListener']('error',_0x544990);},_0x2db0db=()=>{_0x4f821e(_e(_0xea4ac3['result'])),_0x5608c7();},_0x544990=()=>{_0x407ece(_0xea4ac3['error']),_0x5608c7();};_0xea4ac3['addEventListener']('success',_0x2db0db),_0xea4ac3['addEventListener']('error',_0x544990);});return _0x9690d4['then'](_0x5f459e=>{_0x5f459e instanceof IDBCursor&&Kr['set'](_0x5f459e,_0xea4ac3);})['catch'](()=>{}),Fi['set'](_0x9690d4,_0xea4ac3),_0x9690d4;}function Fc(_0x5daa16){if(ui['has'](_0x5daa16))return;const _0x12865c=new Promise((_0x5b4196,_0x5a65d7)=>{const _0x4fdc62=()=>{_0x5daa16['removeEventListener']('complete',_0x2a24b9),_0x5daa16['removeEventListener']('error',_0xb9535),_0x5daa16['removeEventListener']('abort',_0xb9535);},_0x2a24b9=()=>{_0x5b4196(),_0x4fdc62();},_0xb9535=()=>{_0x5a65d7(_0x5daa16['error']||new DOMException('AbortError','AbortError')),_0x4fdc62();};_0x5daa16['addEventListener']('complete',_0x2a24b9),_0x5daa16['addEventListener']('error',_0xb9535),_0x5daa16['addEventListener']('abort',_0xb9535);});ui['set'](_0x5daa16,_0x12865c);}let di={'get'(_0x1a2863,_0xeff534,_0x56e8d5){if(_0x1a2863 instanceof IDBTransaction){if(_0xeff534==='done')return ui['get'](_0x1a2863);if(_0xeff534==='objectStoreNames')return _0x1a2863['objectStoreNames']||Yr['get'](_0x1a2863);if(_0xeff534==='store')return _0x56e8d5['objectStoreNames'][0x1]?void 0x0:_0x56e8d5['objectStore'](_0x56e8d5['objectStoreNames'][0x0]);}return _e(_0x1a2863[_0xeff534]);},'set'(_0x73ced0,_0x17dfde,_0x4ac6fc){return _0x73ced0[_0x17dfde]=_0x4ac6fc,!0x0;},'has'(_0x556cc8,_0x503fdc){return _0x556cc8 instanceof IDBTransaction&&(_0x503fdc==='done'||_0x503fdc==='store')?!0x0:_0x503fdc in _0x556cc8;}};function Uc(_0x27342c){di=_0x27342c(di);}function Wc(_0x3c0be8){return _0x3c0be8===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x561681,..._0x2a2552){const _0x1f0723=_0x3c0be8['call'](Xn(this),_0x561681,..._0x2a2552);return Yr['set'](_0x1f0723,_0x561681['sort']?_0x561681['sort']():[_0x561681]),_e(_0x1f0723);}:Lc()['includes'](_0x3c0be8)?function(..._0xbf1bd3){return _0x3c0be8['apply'](Xn(this),_0xbf1bd3),_e(Kr['get'](this));}:function(..._0x3389ae){return _e(_0x3c0be8['apply'](Xn(this),_0x3389ae));};}function Bc(_0x546906){return typeof _0x546906=='function'?Wc(_0x546906):(_0x546906 instanceof IDBTransaction&&Fc(_0x546906),Dc(_0x546906,Mc())?new Proxy(_0x546906,di):_0x546906);}function _e(_0x15c344){if(_0x15c344 instanceof IDBRequest)return xc(_0x15c344);if(Jn['has'](_0x15c344))return Jn['get'](_0x15c344);const _0xa69f16=Bc(_0x15c344);return _0xa69f16!==_0x15c344&&(Jn['set'](_0x15c344,_0xa69f16),Fi['set'](_0xa69f16,_0x15c344)),_0xa69f16;}const Xn=_0x36e2f9=>Fi['get'](_0x36e2f9);function Vc(_0x9207b9,_0x4a6014,{blocked:_0x555fae,upgrade:_0x205b83,blocking:_0x295463,terminated:_0x23006d}={}){const _0xa058ad=indexedDB['open'](_0x9207b9,_0x4a6014),_0x12d09f=_e(_0xa058ad);return _0x205b83&&_0xa058ad['addEventListener']('upgradeneeded',_0x45778d=>{_0x205b83(_e(_0xa058ad['result']),_0x45778d['oldVersion'],_0x45778d['newVersion'],_e(_0xa058ad['transaction']),_0x45778d);}),_0x555fae&&_0xa058ad['addEventListener']('blocked',_0x12e256=>_0x555fae(_0x12e256['oldVersion'],_0x12e256['newVersion'],_0x12e256)),_0x12d09f['then'](_0x164efc=>{_0x23006d&&_0x164efc['addEventListener']('close',()=>_0x23006d()),_0x295463&&_0x164efc['addEventListener']('versionchange',_0x5343bb=>_0x295463(_0x5343bb['oldVersion'],_0x5343bb['newVersion'],_0x5343bb));})['catch'](()=>{}),_0x12d09f;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0xd9c594,_0x1ce0c5){if(!(_0xd9c594 instanceof IDBDatabase&&!(_0x1ce0c5 in _0xd9c594)&&typeof _0x1ce0c5=='string'))return;if(Zn['get'](_0x1ce0c5))return Zn['get'](_0x1ce0c5);const _0x521b72=_0x1ce0c5['replace'](/FromIndex$/,''),_0x4ff54b=_0x1ce0c5!==_0x521b72,_0x35376d=$c['includes'](_0x521b72);if(!(_0x521b72 in(_0x4ff54b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x35376d||Hc['includes'](_0x521b72)))return;const _0x169962=async function(_0x567b3c,..._0x35d1ef){const _0x2e092c=this['transaction'](_0x567b3c,_0x35376d?'readwrite':'readonly');let _0x52996e=_0x2e092c['store'];return _0x4ff54b&&(_0x52996e=_0x52996e['index'](_0x35d1ef['shift']())),(await Promise['all']([_0x52996e[_0x521b72](..._0x35d1ef),_0x35376d&&_0x2e092c['done']]))[0x0];};return Zn['set'](_0x1ce0c5,_0x169962),_0x169962;}Uc(_0xa9369c=>({..._0xa9369c,'get':(_0x1d348d,_0xec77cb,_0x50ad3e)=>Os(_0x1d348d,_0xec77cb)||_0xa9369c['get'](_0x1d348d,_0xec77cb,_0x50ad3e),'has':(_0x4dad90,_0x3a70a4)=>!!Os(_0x4dad90,_0x3a70a4)||_0xa9369c['has'](_0x4dad90,_0x3a70a4)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x5641bc){this['container']=_0x5641bc;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xde0da2=>{if(qc(_0xde0da2)){const _0x10de5a=_0xde0da2['getImmediate']();return _0x10de5a['library']+'/'+_0x10de5a['version'];}else return null;})['filter'](_0x1c346a=>_0x1c346a)['join']('\x20');}}function qc(_0x53c107){const _0x59215b=_0x53c107['getComponent']();return(_0x59215b==null?void 0x0:_0x59215b['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0xf0ab64,_0x5d1f91){try{_0xf0ab64['container']['addComponent'](_0x5d1f91);}catch(_0x4236c1){re['debug']('Component\x20'+_0x5d1f91['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xf0ab64['name'],_0x4236c1);}}function et(_0x4199ed){const _0x2a7da4=_0x4199ed['name'];if(gi['has'](_0x2a7da4))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2a7da4+'.'),!0x1;gi['set'](_0x2a7da4,_0x4199ed);for(const _0x2dd7f3 of Le['values']())Ms(_0x2dd7f3,_0x4199ed);for(const _0x53f6c3 of _i['values']())Ms(_0x53f6c3,_0x4199ed);return!0x0;}function Ui(_0x60204d,_0x5574d1){const _0x362baf=_0x60204d['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x362baf&&_0x362baf['triggerHeartbeat'](),_0x60204d['container']['getProvider'](_0x5574d1);}function H(_0x16cf93){return _0x16cf93==null?!0x1:_0x16cf93['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x9d0f69,_0xd3feb,_0x25b024){this['_isDeleted']=!0x1,this['_options']={..._0x9d0f69},this['_config']={..._0xd3feb},this['_name']=_0xd3feb['name'],this['_automaticDataCollectionEnabled']=_0xd3feb['automaticDataCollectionEnabled'],this['_container']=_0x25b024,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xda65bd){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xda65bd;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x406fac){this['_isDeleted']=_0x406fac;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x11ddaf,_0x50cc9f={}){let _0x6561da=_0x11ddaf;typeof _0x50cc9f!='object'&&(_0x50cc9f={'name':_0x50cc9f});const _0x24cb00={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x50cc9f},_0x31ade4=_0x24cb00['name'];if(typeof _0x31ade4!='string'||!_0x31ade4)throw ge['create']('bad-app-name',{'appName':String(_0x31ade4)});if(_0x6561da||(_0x6561da=$r()),!_0x6561da)throw ge['create']('no-options');const _0x52ce4e=Le['get'](_0x31ade4);if(_0x52ce4e){if(De(_0x6561da,_0x52ce4e['options'])&&De(_0x24cb00,_0x52ce4e['config']))return _0x52ce4e;throw ge['create']('duplicate-app',{'appName':_0x31ade4});}const _0x55b4be=new Ac(_0x31ade4);for(const _0x2023d8 of gi['values']())_0x55b4be['addComponent'](_0x2023d8);const _0x4f345b=new Il(_0x6561da,_0x24cb00,_0x55b4be);return Le['set'](_0x31ade4,_0x4f345b),_0x4f345b;}function Qr(_0x193209=pi){const _0x114b55=Le['get'](_0x193209);if(!_0x114b55&&_0x193209===pi&&$r())return wl();if(!_0x114b55)throw ge['create']('no-app',{'appName':_0x193209});return _0x114b55;}function l_(){return Array['from'](Le['values']());}async function h_(_0xf39739){let _0x5f4f07=!0x1;const _0x6cf6cc=_0xf39739['name'];Le['has'](_0x6cf6cc)?(_0x5f4f07=!0x0,Le['delete'](_0x6cf6cc)):_i['has'](_0x6cf6cc)&&_0xf39739['decRefCount']()<=0x0&&(_i['delete'](_0x6cf6cc),_0x5f4f07=!0x0),_0x5f4f07&&(await Promise['all'](_0xf39739['container']['getProviders']()['map'](_0x153ee5=>_0x153ee5['delete']())),_0xf39739['isDeleted']=!0x0);}function me(_0xcaad4d,_0x2679d5,_0x4d38aa){let _0x37b109=vl[_0xcaad4d]??_0xcaad4d;_0x4d38aa&&(_0x37b109+='-'+_0x4d38aa);const _0xa00679=_0x37b109['match'](/\s|\//),_0x424ea1=_0x2679d5['match'](/\s|\//);if(_0xa00679||_0x424ea1){const _0x36441d=['Unable\x20to\x20register\x20library\x20\x22'+_0x37b109+'\x22\x20with\x20version\x20\x22'+_0x2679d5+'\x22:'];_0xa00679&&_0x36441d['push']('library\x20name\x20\x22'+_0x37b109+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xa00679&&_0x424ea1&&_0x36441d['push']('and'),_0x424ea1&&_0x36441d['push']('version\x20name\x20\x22'+_0x2679d5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x36441d['join']('\x20'));return;}et(new Me(_0x37b109+'-version',()=>({'library':_0x37b109,'version':_0x2679d5}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3d00d9,_0x3a003f)=>{switch(_0x3a003f){case 0x0:try{_0x3d00d9['createObjectStore'](Rt);}catch(_0x26ea88){console['warn'](_0x26ea88);}}}})['catch'](_0x1ce8a7=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1ce8a7['message']});})),ei;}async function Sl(_0x1ca276){try{const _0x244480=(await Jr())['transaction'](Rt),_0x4f47b3=await _0x244480['objectStore'](Rt)['get'](Xr(_0x1ca276));return await _0x244480['done'],_0x4f47b3;}catch(_0x8caada){if(_0x8caada instanceof Se)re['warn'](_0x8caada['message']);else{const _0x11c8cd=ge['create']('idb-get',{'originalErrorMessage':_0x8caada==null?void 0x0:_0x8caada['message']});re['warn'](_0x11c8cd['message']);}}}async function Ls(_0x21c261,_0x1f92e9){try{const _0x51b40d=(await Jr())['transaction'](Rt,'readwrite');await _0x51b40d['objectStore'](Rt)['put'](_0x1f92e9,Xr(_0x21c261)),await _0x51b40d['done'];}catch(_0x524b5a){if(_0x524b5a instanceof Se)re['warn'](_0x524b5a['message']);else{const _0x276fe8=ge['create']('idb-set',{'originalErrorMessage':_0x524b5a==null?void 0x0:_0x524b5a['message']});re['warn'](_0x276fe8['message']);}}}function Xr(_0x4a7747){return _0x4a7747['name']+'!'+_0x4a7747['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x3a9349){this['container']=_0x3a9349,this['_heartbeatsCache']=null;const _0x413596=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x413596),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2923da=>(this['_heartbeatsCache']=_0x2923da,_0x2923da));}async['triggerHeartbeat'](){var _0x31f2f1,_0x24702a;try{const _0xce9d4f=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3eb0ae=xs();if(((_0x31f2f1=this['_heartbeatsCache'])==null?void 0x0:_0x31f2f1['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x24702a=this['_heartbeatsCache'])==null?void 0x0:_0x24702a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3eb0ae||this['_heartbeatsCache']['heartbeats']['some'](_0x32bf58=>_0x32bf58['date']===_0x3eb0ae))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3eb0ae,'agent':_0xce9d4f}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x2e6136=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2e6136,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2d018b){re['warn'](_0x2d018b);}}async['getHeartbeatsHeader'](){var _0x4339a6;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4339a6=this['_heartbeatsCache'])==null?void 0x0:_0x4339a6['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x17b23b=xs(),{heartbeatsToSend:_0x2c7153,unsentEntries:_0x7787fc}=kl(this['_heartbeatsCache']['heartbeats']),_0x1caf0d=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2c7153}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x17b23b,_0x7787fc['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x7787fc,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1caf0d;}catch(_0xde4219){return re['warn'](_0xde4219),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x1ac8fc,_0x7eb85c=bl){const _0x495da1=[];let _0x4677d1=_0x1ac8fc['slice']();for(const _0x4c1bbf of _0x1ac8fc){const _0x2d402c=_0x495da1['find'](_0x56c357=>_0x56c357['agent']===_0x4c1bbf['agent']);if(_0x2d402c){if(_0x2d402c['dates']['push'](_0x4c1bbf['date']),Fs(_0x495da1)>_0x7eb85c){_0x2d402c['dates']['pop']();break;}}else{if(_0x495da1['push']({'agent':_0x4c1bbf['agent'],'dates':[_0x4c1bbf['date']]}),Fs(_0x495da1)>_0x7eb85c){_0x495da1['pop']();break;}}_0x4677d1=_0x4677d1['slice'](0x1);}return{'heartbeatsToSend':_0x495da1,'unsentEntries':_0x4677d1};}class Nl{constructor(_0x532217){this['app']=_0x532217,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x28a8ec=await Sl(this['app']);return _0x28a8ec!=null&&_0x28a8ec['heartbeats']?_0x28a8ec:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4f4139){if(await this['_canUseIndexedDBPromise']){const _0x310a7b=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4f4139['lastSentHeartbeatDate']??_0x310a7b['lastSentHeartbeatDate'],'heartbeats':_0x4f4139['heartbeats']});}else return;}async['add'](_0x50ae3a){if(await this['_canUseIndexedDBPromise']){const _0x169363=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x50ae3a['lastSentHeartbeatDate']??_0x169363['lastSentHeartbeatDate'],'heartbeats':[..._0x169363['heartbeats'],..._0x50ae3a['heartbeats']]});}else return;}}function Fs(_0x27232b){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x27232b}))['length'];}function Pl(_0x509703){if(_0x509703['length']===0x0)return-0x1;let _0x517706=0x0,_0x3ee191=_0x509703[0x0]['date'];for(let _0x4db37e=0x1;_0x4db37e<_0x509703['length'];_0x4db37e++)_0x509703[_0x4db37e]['date']<_0x3ee191&&(_0x3ee191=_0x509703[_0x4db37e]['date'],_0x517706=_0x4db37e);return _0x517706;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0xc9ad69){et(new Me('platform-logger',_0xb8b43e=>new Gc(_0xb8b43e),'PRIVATE')),et(new Me('heartbeat',_0x356b11=>new Al(_0x356b11),'PRIVATE')),me(fi,Ds,_0xc9ad69),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x14f6d9){Zr=_0x14f6d9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x347422){this['domStorage_']=_0x347422,this['prefix_']='firebase:';}['set'](_0x261e24,_0x23b605){_0x23b605==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x261e24)):this['domStorage_']['setItem'](this['prefixedName_'](_0x261e24),O(_0x23b605));}['get'](_0x13aa35){const _0x30acde=this['domStorage_']['getItem'](this['prefixedName_'](_0x13aa35));return _0x30acde==null?null:bt(_0x30acde);}['remove'](_0x1bfdec){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1bfdec));}['prefixedName_'](_0x8dcc67){return this['prefix_']+_0x8dcc67;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x18d57e,_0x37c16d){_0x37c16d==null?delete this['cache_'][_0x18d57e]:this['cache_'][_0x18d57e]=_0x37c16d;}['get'](_0x5a94a1){return Y(this['cache_'],_0x5a94a1)?this['cache_'][_0x5a94a1]:null;}['remove'](_0xf5a5ce){delete this['cache_'][_0xf5a5ce];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5ba7f7){try{if(typeof window<'u'&&typeof window[_0x5ba7f7]<'u'){const _0x1fa9b7=window[_0x5ba7f7];return _0x1fa9b7['setItem']('firebase:sentinel','cache'),_0x1fa9b7['removeItem']('firebase:sentinel'),new xl(_0x1fa9b7);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0xad2eb4=0x1;return function(){return _0xad2eb4++;};}()),no=function(_0x42cc44){const _0x26336f=Tc(_0x42cc44),_0x5be59c=new Ec();_0x5be59c['update'](_0x26336f);const _0x2edb7b=_0x5be59c['digest']();return Di['encodeByteArray'](_0x2edb7b);},Bt=function(..._0x38085e){let _0x156286='';for(let _0x1a846a=0x0;_0x1a846a<_0x38085e['length'];_0x1a846a++){const _0x5c93b8=_0x38085e[_0x1a846a];Array['isArray'](_0x5c93b8)||_0x5c93b8&&typeof _0x5c93b8=='object'&&typeof _0x5c93b8['length']=='number'?_0x156286+=Bt['apply'](null,_0x5c93b8):typeof _0x5c93b8=='object'?_0x156286+=O(_0x5c93b8):_0x156286+=_0x5c93b8,_0x156286+='\x20';}return _0x156286;};let Et=null,Vs=!0x0;const Wl=function(_0x54eb54,_0xb8c24e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x28ccfc){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3f9f09=Bt['apply'](null,_0x28ccfc);Et(_0x3f9f09);}},Vt=function(_0x47a52b){return function(..._0x51dbc5){L(_0x47a52b,..._0x51dbc5);};},mi=function(..._0x5a230c){const _0x2cc58e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x5a230c);Qe['error'](_0x2cc58e);},oe=function(..._0x1dd3f0){const _0x25de1a='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x1dd3f0);throw Qe['error'](_0x25de1a),new Error(_0x25de1a);},U=function(..._0x5bf6fb){const _0x3adc6f='FIREBASE\x20WARNING:\x20'+Bt(..._0x5bf6fb);Qe['warn'](_0x3adc6f);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x12cd3f){return typeof _0x12cd3f=='number'&&(_0x12cd3f!==_0x12cd3f||_0x12cd3f===Number['POSITIVE_INFINITY']||_0x12cd3f===Number['NEGATIVE_INFINITY']);},Vl=function(_0xda1717){if(document['readyState']==='complete')_0xda1717();else{let _0x2d5fbc=!0x1;const _0x452adb=function(){if(!document['body']){setTimeout(_0x452adb,Math['floor'](0xa));return;}_0x2d5fbc||(_0x2d5fbc=!0x0,_0xda1717());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x452adb,!0x1),window['addEventListener']('load',_0x452adb,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x452adb();}),window['attachEvent']('onload',_0x452adb));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x18bd5d,_0x1ac35b){if(_0x18bd5d===_0x1ac35b)return 0x0;if(_0x18bd5d===xe||_0x1ac35b===Ie)return-0x1;if(_0x1ac35b===xe||_0x18bd5d===Ie)return 0x1;{const _0x75f778=Hs(_0x18bd5d),_0x40a83c=Hs(_0x1ac35b);return _0x75f778!==null?_0x40a83c!==null?_0x75f778-_0x40a83c===0x0?_0x18bd5d['length']-_0x1ac35b['length']:_0x75f778-_0x40a83c:-0x1:_0x40a83c!==null?0x1:_0x18bd5d<_0x1ac35b?-0x1:0x1;}},Hl=function(_0x584746,_0x251352){return _0x584746===_0x251352?0x0:_0x584746<_0x251352?-0x1:0x1;},pt=function(_0x5b1d94,_0x46ee02){if(_0x46ee02&&_0x5b1d94 in _0x46ee02)return _0x46ee02[_0x5b1d94];throw new Error('Missing\x20required\x20key\x20('+_0x5b1d94+')\x20in\x20object:\x20'+O(_0x46ee02));},Bi=function(_0x4e4120){if(typeof _0x4e4120!='object'||_0x4e4120===null)return O(_0x4e4120);const _0x5d0ff0=[];for(const _0x3affdc in _0x4e4120)_0x5d0ff0['push'](_0x3affdc);_0x5d0ff0['sort']();let _0x4a8281='{';for(let _0x49bfed=0x0;_0x49bfed<_0x5d0ff0['length'];_0x49bfed++)_0x49bfed!==0x0&&(_0x4a8281+=','),_0x4a8281+=O(_0x5d0ff0[_0x49bfed]),_0x4a8281+=':',_0x4a8281+=Bi(_0x4e4120[_0x5d0ff0[_0x49bfed]]);return _0x4a8281+='}',_0x4a8281;},io=function(_0x246fda,_0x38e151){const _0x1f12e7=_0x246fda['length'];if(_0x1f12e7<=_0x38e151)return[_0x246fda];const _0x4f7626=[];for(let _0x3f29b2=0x0;_0x3f29b2<_0x1f12e7;_0x3f29b2+=_0x38e151)_0x3f29b2+_0x38e151>_0x1f12e7?_0x4f7626['push'](_0x246fda['substring'](_0x3f29b2,_0x1f12e7)):_0x4f7626['push'](_0x246fda['substring'](_0x3f29b2,_0x3f29b2+_0x38e151));return _0x4f7626;};function x(_0x11e775,_0x4ace7a){for(const _0x27e8b2 in _0x11e775)_0x11e775['hasOwnProperty'](_0x27e8b2)&&_0x4ace7a(_0x27e8b2,_0x11e775[_0x27e8b2]);}const so=function(_0x599244){f(!Wi(_0x599244),'Invalid\x20JSON\x20number');const _0x2377ff=0xb,_0x32a3db=0x34,_0x5dbb98=(0x1<<_0x2377ff-0x1)-0x1;let _0x4af96c,_0x4e7058,_0x41e5b9,_0x4e0bf2,_0x1489cc;_0x599244===0x0?(_0x4e7058=0x0,_0x41e5b9=0x0,_0x4af96c=0x1/_0x599244===-0x1/0x0?0x1:0x0):(_0x4af96c=_0x599244<0x0,_0x599244=Math['abs'](_0x599244),_0x599244>=Math['pow'](0x2,0x1-_0x5dbb98)?(_0x4e0bf2=Math['min'](Math['floor'](Math['log'](_0x599244)/Math['LN2']),_0x5dbb98),_0x4e7058=_0x4e0bf2+_0x5dbb98,_0x41e5b9=Math['round'](_0x599244*Math['pow'](0x2,_0x32a3db-_0x4e0bf2)-Math['pow'](0x2,_0x32a3db))):(_0x4e7058=0x0,_0x41e5b9=Math['round'](_0x599244/Math['pow'](0x2,0x1-_0x5dbb98-_0x32a3db))));const _0x2dc960=[];for(_0x1489cc=_0x32a3db;_0x1489cc;_0x1489cc-=0x1)_0x2dc960['push'](_0x41e5b9%0x2?0x1:0x0),_0x41e5b9=Math['floor'](_0x41e5b9/0x2);for(_0x1489cc=_0x2377ff;_0x1489cc;_0x1489cc-=0x1)_0x2dc960['push'](_0x4e7058%0x2?0x1:0x0),_0x4e7058=Math['floor'](_0x4e7058/0x2);_0x2dc960['push'](_0x4af96c?0x1:0x0),_0x2dc960['reverse']();const _0x42b444=_0x2dc960['join']('');let _0x496184='';for(_0x1489cc=0x0;_0x1489cc<0x40;_0x1489cc+=0x8){let _0x2345db=parseInt(_0x42b444['substr'](_0x1489cc,0x8),0x2)['toString'](0x10);_0x2345db['length']===0x1&&(_0x2345db='0'+_0x2345db),_0x496184=_0x496184+_0x2345db;}return _0x496184['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x3b880f,_0x33b347){let _0x2c2e42='Unknown\x20Error';_0x3b880f==='too_big'?_0x2c2e42='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3b880f==='permission_denied'?_0x2c2e42='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3b880f==='unavailable'&&(_0x2c2e42='The\x20service\x20is\x20unavailable');const _0x4d6a31=new Error(_0x3b880f+'\x20at\x20'+_0x33b347['_path']['toString']()+':\x20'+_0x2c2e42);return _0x4d6a31['code']=_0x3b880f['toUpperCase'](),_0x4d6a31;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x45b085){if(zl['test'](_0x45b085)){const _0x2125da=Number(_0x45b085);if(_0x2125da>=jl&&_0x2125da<=Kl)return _0x2125da;}return null;},lt=function(_0x549677){try{_0x549677();}catch(_0x2bfc40){setTimeout(()=>{const _0x49ad4a=_0x2bfc40['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x49ad4a),_0x2bfc40;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x47e3cb,_0x378e83){const _0x2c5b36=setTimeout(_0x47e3cb,_0x378e83);return typeof _0x2c5b36=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2c5b36):typeof _0x2c5b36=='object'&&_0x2c5b36['unref']&&_0x2c5b36['unref'](),_0x2c5b36;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x11928b,_0x4597f6){this['appCheckProvider']=_0x4597f6,this['appName']=_0x11928b['name'],H(_0x11928b)&&_0x11928b['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x11928b['settings']['appCheckToken']),this['appCheck']=_0x4597f6==null?void 0x0:_0x4597f6['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4597f6==null||_0x4597f6['get']()['then'](_0x2219b4=>this['appCheck']=_0x2219b4);}['getToken'](_0x97b9fb){if(this['serverAppAppCheckToken']){if(_0x97b9fb)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x97b9fb):new Promise((_0x6ffb36,_0x222ef6)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x97b9fb)['then'](_0x6ffb36,_0x222ef6):_0x6ffb36(null);},0x0);});}['addTokenChangeListener'](_0x420f93){var _0x3c7916;(_0x3c7916=this['appCheckProvider'])==null||_0x3c7916['get']()['then'](_0x541377=>_0x541377['addTokenListener'](_0x420f93));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4d9f29,_0x23cda9,_0x4b9e97){this['appName_']=_0x4d9f29,this['firebaseOptions_']=_0x23cda9,this['authProvider_']=_0x4b9e97,this['auth_']=null,this['auth_']=_0x4b9e97['getImmediate']({'optional':!0x0}),this['auth_']||_0x4b9e97['onInit'](_0x1e0fdb=>this['auth_']=_0x1e0fdb);}['getToken'](_0x116022){return this['auth_']?this['auth_']['getToken'](_0x116022)['catch'](_0x152dfc=>_0x152dfc&&_0x152dfc['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x152dfc)):new Promise((_0x45fb78,_0x1a6dd0)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x116022)['then'](_0x45fb78,_0x1a6dd0):_0x45fb78(null);},0x0);});}['addTokenChangeListener'](_0x38e3a6){this['auth_']?this['auth_']['addAuthTokenListener'](_0x38e3a6):this['authProvider_']['get']()['then'](_0x303d03=>_0x303d03['addAuthTokenListener'](_0x38e3a6));}['removeTokenChangeListener'](_0x67d505){this['authProvider_']['get']()['then'](_0x298dc0=>_0x298dc0['removeAuthTokenListener'](_0x67d505));}['notifyForInvalidToken'](){let _0x52b2df='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x52b2df+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x52b2df+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x52b2df+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x52b2df);}}class tn{constructor(_0x52cb91){this['accessToken']=_0x52cb91;}['getToken'](_0x9353b4){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x12bf18){_0x12bf18(this['accessToken']);}['removeTokenChangeListener'](_0x21c801){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x17c02e,_0x2329ba,_0x5e062f,_0xd4a8be,_0x19506b=!0x1,_0x549a4c='',_0x30e646=!0x1,_0x11839a=!0x1,_0x3b94e1=null){this['secure']=_0x2329ba,this['namespace']=_0x5e062f,this['webSocketOnly']=_0xd4a8be,this['nodeAdmin']=_0x19506b,this['persistenceKey']=_0x549a4c,this['includeNamespaceInQueryParams']=_0x30e646,this['isUsingEmulator']=_0x11839a,this['emulatorOptions']=_0x3b94e1,this['_host']=_0x17c02e['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x17c02e)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x57a8e8){_0x57a8e8!==this['internalHost']&&(this['internalHost']=_0x57a8e8,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1e88cd=this['toURLString']();return this['persistenceKey']&&(_0x1e88cd+='<'+this['persistenceKey']+'>'),_0x1e88cd;}['toURLString'](){const _0x4dd371=this['secure']?'https://':'http://',_0x597428=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4dd371+this['host']+'/'+_0x597428;}}function Xl(_0x299707){return _0x299707['host']!==_0x299707['internalHost']||_0x299707['isCustomHost']()||_0x299707['includeNamespaceInQueryParams'];}function go(_0x8c8042,_0x46b528,_0x5c7860){f(typeof _0x46b528=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5c7860=='object','typeof\x20params\x20must\x20==\x20object');let _0x3ff25f;if(_0x46b528===fo)_0x3ff25f=(_0x8c8042['secure']?'wss://':'ws://')+_0x8c8042['internalHost']+'/.ws?';else{if(_0x46b528===po)_0x3ff25f=(_0x8c8042['secure']?'https://':'http://')+_0x8c8042['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x46b528);}Xl(_0x8c8042)&&(_0x5c7860['ns']=_0x8c8042['namespace']);const _0x4006cc=[];return x(_0x5c7860,(_0x182633,_0x1b93fd)=>{_0x4006cc['push'](_0x182633+'='+_0x1b93fd);}),_0x3ff25f+_0x4006cc['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x1c2091,_0x1c195a=0x1){Y(this['counters_'],_0x1c2091)||(this['counters_'][_0x1c2091]=0x0),this['counters_'][_0x1c2091]+=_0x1c195a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x487777){const _0x1f47ac=_0x487777['toString']();return ti[_0x1f47ac]||(ti[_0x1f47ac]=new Zl()),ti[_0x1f47ac];}function eh(_0x1abc5d,_0xc2051f){const _0xab7e5f=_0x1abc5d['toString']();return ni[_0xab7e5f]||(ni[_0xab7e5f]=_0xc2051f()),ni[_0xab7e5f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x47be22){this['onMessage_']=_0x47be22,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x51782f,_0x5dc718){this['closeAfterResponse']=_0x51782f,this['onClose']=_0x5dc718,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xe5c870,_0x3379aa){for(this['pendingResponses'][_0xe5c870]=_0x3379aa;this['pendingResponses'][this['currentResponseNum']];){const _0x4c1c18=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x46302f=0x0;_0x46302f<_0x4c1c18['length'];++_0x46302f)_0x4c1c18[_0x46302f]&&lt(()=>{this['onMessage_'](_0x4c1c18[_0x46302f]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x4c616c,_0x294e73,_0x44b222,_0x11f560,_0x3274d1,_0x5828b7,_0xa70a92){this['connId']=_0x4c616c,this['repoInfo']=_0x294e73,this['applicationId']=_0x44b222,this['appCheckToken']=_0x11f560,this['authToken']=_0x3274d1,this['transportSessionId']=_0x5828b7,this['lastSessionId']=_0xa70a92,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x4c616c),this['stats_']=Hi(_0x294e73),this['urlFn']=_0x28d98a=>(this['appCheckToken']&&(_0x28d98a[yi]=this['appCheckToken']),go(_0x294e73,po,_0x28d98a));}['open'](_0x511777,_0x12e322){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x12e322,this['myPacketOrderer']=new th(_0x511777),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0xf3b62b)=>{const [_0x5ab2b6,_0x15074c,_0x13c6fa,_0xa4a753,_0x37f0c9]=_0xf3b62b;if(this['incrementIncomingBytes_'](_0xf3b62b),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5ab2b6===$s)this['id']=_0x15074c,this['password']=_0x13c6fa;else{if(_0x5ab2b6===nh)_0x15074c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x15074c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5ab2b6);}}},(..._0x1a209c)=>{const [_0x8e63a1,_0x464b06]=_0x1a209c;this['incrementIncomingBytes_'](_0x1a209c),this['myPacketOrderer']['handleResponse'](_0x8e63a1,_0x464b06);},()=>{this['onClosed_']();},this['urlFn']);const _0x1a309c={};_0x1a309c[$s]='t',_0x1a309c[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1a309c[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1a309c[ro]=Vi,this['transportSessionId']&&(_0x1a309c[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1a309c[ho]=this['lastSessionId']),this['applicationId']&&(_0x1a309c[uo]=this['applicationId']),this['appCheckToken']&&(_0x1a309c[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1a309c[ao]=co);const _0x25686a=this['urlFn'](_0x1a309c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x25686a),this['scriptTagHolder']['addTag'](_0x25686a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2d3dc7){const _0x337e3a=O(_0x2d3dc7);this['bytesSent']+=_0x337e3a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x337e3a['length']);const _0x33d31d=Br(_0x337e3a),_0x3498c2=io(_0x33d31d,hh);for(let _0x384ea2=0x0;_0x384ea2<_0x3498c2['length'];_0x384ea2++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3498c2['length'],_0x3498c2[_0x384ea2]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x238c7e,_0x10be2f){this['myDisconnFrame']=document['createElement']('iframe');const _0xfbb1bf={};_0xfbb1bf[lh]='t',_0xfbb1bf[mo]=_0x238c7e,_0xfbb1bf[yo]=_0x10be2f,this['myDisconnFrame']['src']=this['urlFn'](_0xfbb1bf),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5e4106){const _0x16cb22=O(_0x5e4106)['length'];this['bytesReceived']+=_0x16cb22,this['stats_']['incrementCounter']('bytes_received',_0x16cb22);}}class $i{constructor(_0x546fa8,_0x597f24,_0x5a976f,_0x3370e9){this['onDisconnect']=_0x5a976f,this['urlFn']=_0x3370e9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x546fa8,window[sh+this['uniqueCallbackIdentifier']]=_0x597f24,this['myIFrame']=$i['createIFrame_']();let _0x2f0b40='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2f0b40='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x580519='<html><body>'+_0x2f0b40+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x580519),this['myIFrame']['doc']['close']();}catch(_0xbd398e){L('frame\x20writing\x20exception'),_0xbd398e['stack']&&L(_0xbd398e['stack']),L(_0xbd398e);}}}static['createIFrame_'](){const _0x1339ef=document['createElement']('iframe');if(_0x1339ef['style']['display']='none',document['body']){document['body']['appendChild'](_0x1339ef);try{_0x1339ef['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x41abef=document['domain'];_0x1339ef['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x41abef+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1339ef['contentDocument']?_0x1339ef['doc']=_0x1339ef['contentDocument']:_0x1339ef['contentWindow']?_0x1339ef['doc']=_0x1339ef['contentWindow']['document']:_0x1339ef['document']&&(_0x1339ef['doc']=_0x1339ef['document']),_0x1339ef;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1ff55e=this['onDisconnect'];_0x1ff55e&&(this['onDisconnect']=null,_0x1ff55e());}['startLongPoll'](_0x14c060,_0x5c0c29){for(this['myID']=_0x14c060,this['myPW']=_0x5c0c29,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2fb7ba={};_0x2fb7ba[mo]=this['myID'],_0x2fb7ba[yo]=this['myPW'],_0x2fb7ba[vo]=this['currentSerial'];let _0x4f117b=this['urlFn'](_0x2fb7ba),_0x2c6575='',_0xfee4a2=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2c6575['length']<=Eo;){const _0x2bf9ab=this['pendingSegs']['shift']();_0x2c6575=_0x2c6575+'&'+oh+_0xfee4a2+'='+_0x2bf9ab['seg']+'&'+ah+_0xfee4a2+'='+_0x2bf9ab['ts']+'&'+ch+_0xfee4a2+'='+_0x2bf9ab['d'],_0xfee4a2++;}return _0x4f117b=_0x4f117b+_0x2c6575,this['addLongPollTag_'](_0x4f117b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x534a24,_0xac5017,_0x1a391f){this['pendingSegs']['push']({'seg':_0x534a24,'ts':_0xac5017,'d':_0x1a391f}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x551453,_0x2faeb9){this['outstandingRequests']['add'](_0x2faeb9);const _0xfe1024=()=>{this['outstandingRequests']['delete'](_0x2faeb9),this['newRequest_']();},_0x237030=setTimeout(_0xfe1024,Math['floor'](uh)),_0x30f75a=()=>{clearTimeout(_0x237030),_0xfe1024();};this['addTag'](_0x551453,_0x30f75a);}['addTag'](_0x474058,_0x18cb95){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2a3903=this['myIFrame']['doc']['createElement']('script');_0x2a3903['type']='text/javascript',_0x2a3903['async']=!0x0,_0x2a3903['src']=_0x474058,_0x2a3903['onload']=_0x2a3903['onreadystatechange']=function(){const _0x28cebc=_0x2a3903['readyState'];(!_0x28cebc||_0x28cebc==='loaded'||_0x28cebc==='complete')&&(_0x2a3903['onload']=_0x2a3903['onreadystatechange']=null,_0x2a3903['parentNode']&&_0x2a3903['parentNode']['removeChild'](_0x2a3903),_0x18cb95());},_0x2a3903['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x474058),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2a3903);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1590b0,_0x38c4c7,_0x4c8cbf,_0x39525b,_0x32fc00,_0x2580e3,_0x143b01){this['connId']=_0x1590b0,this['applicationId']=_0x4c8cbf,this['appCheckToken']=_0x39525b,this['authToken']=_0x32fc00,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x38c4c7),this['connURL']=G['connectionURL_'](_0x38c4c7,_0x2580e3,_0x143b01,_0x39525b,_0x4c8cbf),this['nodeAdmin']=_0x38c4c7['nodeAdmin'];}static['connectionURL_'](_0x4d1e87,_0xe6353b,_0x232554,_0x26897b,_0x36ba97){const _0x1cbd7b={};return _0x1cbd7b[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1cbd7b[ao]=co),_0xe6353b&&(_0x1cbd7b[oo]=_0xe6353b),_0x232554&&(_0x1cbd7b[ho]=_0x232554),_0x26897b&&(_0x1cbd7b[yi]=_0x26897b),_0x36ba97&&(_0x1cbd7b[uo]=_0x36ba97),go(_0x4d1e87,fo,_0x1cbd7b);}['open'](_0x8d2b18,_0x567bec){this['onDisconnect']=_0x567bec,this['onMessage']=_0x8d2b18,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x12c245;dc(),this['mySock']=new hn(this['connURL'],[],_0x12c245);}catch(_0x3fe79b){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2f2f15=_0x3fe79b['message']||_0x3fe79b['data'];_0x2f2f15&&this['log_'](_0x2f2f15),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x142bec=>{this['handleIncomingFrame'](_0x142bec);},this['mySock']['onerror']=_0x2a0815=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xd2ecf4=_0x2a0815['message']||_0x2a0815['data'];_0xd2ecf4&&this['log_'](_0xd2ecf4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x19efe9=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xf3098=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4f70b0=navigator['userAgent']['match'](_0xf3098);_0x4f70b0&&_0x4f70b0['length']>0x1&&parseFloat(_0x4f70b0[0x1])<4.4&&(_0x19efe9=!0x0);}return!_0x19efe9&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x34e186){if(this['frames']['push'](_0x34e186),this['frames']['length']===this['totalFrames']){const _0x421c6c=this['frames']['join']('');this['frames']=null;const _0x28fc08=bt(_0x421c6c);this['onMessage'](_0x28fc08);}}['handleNewFrameCount_'](_0x3086e6){this['totalFrames']=_0x3086e6,this['frames']=[];}['extractFrameCount_'](_0x29ce21){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x29ce21['length']<=0x6){const _0x5f4fbb=Number(_0x29ce21);if(!isNaN(_0x5f4fbb))return this['handleNewFrameCount_'](_0x5f4fbb),null;}return this['handleNewFrameCount_'](0x1),_0x29ce21;}['handleIncomingFrame'](_0x3376db){if(this['mySock']===null)return;const _0x5a19ff=_0x3376db['data'];if(this['bytesReceived']+=_0x5a19ff['length'],this['stats_']['incrementCounter']('bytes_received',_0x5a19ff['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5a19ff);else{const _0x54a2dc=this['extractFrameCount_'](_0x5a19ff);_0x54a2dc!==null&&this['appendFrame_'](_0x54a2dc);}}['send'](_0x102f92){this['resetKeepAlive']();const _0x2081ea=O(_0x102f92);this['bytesSent']+=_0x2081ea['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2081ea['length']);const _0x4dd53b=io(_0x2081ea,fh);_0x4dd53b['length']>0x1&&this['sendString_'](String(_0x4dd53b['length']));for(let _0x11594b=0x0;_0x11594b<_0x4dd53b['length'];_0x11594b++)this['sendString_'](_0x4dd53b[_0x11594b]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x4d6399){try{this['mySock']['send'](_0x4d6399);}catch(_0x3f6912){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3f6912['message']||_0x3f6912['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1374ea){this['initTransports_'](_0x1374ea);}['initTransports_'](_0x170baf){const _0x4d88a0=G&&G['isAvailable']();let _0x589e05=_0x4d88a0&&!G['previouslyFailed']();if(_0x170baf['webSocketOnly']&&(_0x4d88a0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x589e05=!0x0),_0x589e05)this['transports_']=[G];else{const _0x1e021d=this['transports_']=[];for(const _0x4faaa4 of At['ALL_TRANSPORTS'])_0x4faaa4&&_0x4faaa4['isAvailable']()&&_0x1e021d['push'](_0x4faaa4);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x3db4c8,_0x2bb569,_0x1f89c3,_0x22d2fb,_0x20619c,_0x170e8c,_0x26235e,_0x33c82c,_0x386b30,_0x550dad){this['id']=_0x3db4c8,this['repoInfo_']=_0x2bb569,this['applicationId_']=_0x1f89c3,this['appCheckToken_']=_0x22d2fb,this['authToken_']=_0x20619c,this['onMessage_']=_0x170e8c,this['onReady_']=_0x26235e,this['onDisconnect_']=_0x33c82c,this['onKill_']=_0x386b30,this['lastSessionId']=_0x550dad,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x2bb569),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xab2893=this['transportManager_']['initialTransport']();this['conn_']=new _0xab2893(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xab2893['responsesRequiredToBeHealthy']||0x0;const _0x299fca=this['connReceiver_'](this['conn_']),_0x3303b4=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x299fca,_0x3303b4);},Math['floor'](0x0));const _0x44a8b8=_0xab2893['healthyTimeout']||0x0;_0x44a8b8>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x44a8b8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2aab0d){return _0x109c7e=>{_0x2aab0d===this['conn_']?this['onConnectionLost_'](_0x109c7e):_0x2aab0d===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1e4e24){return _0x114077=>{this['state_']!==0x2&&(_0x1e4e24===this['rx_']?this['onPrimaryMessageReceived_'](_0x114077):_0x1e4e24===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x114077):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4c017d){const _0x5cf54f={'t':'d','d':_0x4c017d};this['sendData_'](_0x5cf54f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xbdd2d9){if(ii in _0xbdd2d9){const _0x11b1a9=_0xbdd2d9[ii];_0x11b1a9===js?this['upgradeIfSecondaryHealthy_']():_0x11b1a9===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x11b1a9===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x100b5b){const _0x83e4f0=pt('t',_0x100b5b),_0x357417=pt('d',_0x100b5b);if(_0x83e4f0==='c')this['onSecondaryControl_'](_0x357417);else{if(_0x83e4f0==='d')this['pendingDataMessages']['push'](_0x357417);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x83e4f0);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x25390c){const _0x424a24=pt('t',_0x25390c),_0x2613c4=pt('d',_0x25390c);_0x424a24==='c'?this['onControl_'](_0x2613c4):_0x424a24==='d'&&this['onDataMessage_'](_0x2613c4);}['onDataMessage_'](_0x557265){this['onPrimaryResponse_'](),this['onMessage_'](_0x557265);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x59d75f){const _0x6f9020=pt(ii,_0x59d75f);if(Gs in _0x59d75f){const _0x254820=_0x59d75f[Gs];if(_0x6f9020===Ih){const _0x3272fa={..._0x254820};this['repoInfo_']['isUsingEmulator']&&(_0x3272fa['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3272fa);}else{if(_0x6f9020===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2ef3a6=0x0;_0x2ef3a6<this['pendingDataMessages']['length'];++_0x2ef3a6)this['onDataMessage_'](this['pendingDataMessages'][_0x2ef3a6]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x6f9020===vh?this['onConnectionShutdown_'](_0x254820):_0x6f9020===qs?this['onReset_'](_0x254820):_0x6f9020===Eh?mi('Server\x20Error:\x20'+_0x254820):_0x6f9020===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x6f9020);}}}['onHandshake_'](_0x42d0d4){const _0x36c77c=_0x42d0d4['ts'],_0x439140=_0x42d0d4['v'],_0x4afd7f=_0x42d0d4['h'];this['sessionId']=_0x42d0d4['s'],this['repoInfo_']['host']=_0x4afd7f,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x36c77c),Vi!==_0x439140&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x6b94a=this['transportManager_']['upgradeTransport']();_0x6b94a&&this['startUpgrade_'](_0x6b94a);}['startUpgrade_'](_0x37a1d7){this['secondaryConn_']=new _0x37a1d7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x37a1d7['responsesRequiredToBeHealthy']||0x0;const _0x47d912=this['connReceiver_'](this['secondaryConn_']),_0x2bf8de=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x47d912,_0x2bf8de),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x15148a){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x15148a),this['repoInfo_']['host']=_0x15148a,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5917be,_0x14b637){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5917be,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x14b637,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x11b282=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x11b282||this['rx_']===_0x11b282)&&this['close']();}['onConnectionLost_'](_0x46e639){this['conn_']=null,!_0x46e639&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5088fa){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5088fa),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2e45d8){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2e45d8);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x5e5674,_0x36a46e,_0xda9da1,_0x18f53f){}['merge'](_0x3fc200,_0x296ba5,_0x1ef68c,_0x1d498d){}['refreshAuthToken'](_0x5acb9d){}['refreshAppCheckToken'](_0x475e79){}['onDisconnectPut'](_0x222caa,_0x288727,_0x52d658){}['onDisconnectMerge'](_0x3badd3,_0x416652,_0x50ed52){}['onDisconnectCancel'](_0x116507,_0x39bcc0){}['reportStats'](_0x3a3bda){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0xb180e7){this['allowedEvents_']=_0xb180e7,this['listeners_']={},f(Array['isArray'](_0xb180e7)&&_0xb180e7['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x23ff68,..._0x4a2b98){if(Array['isArray'](this['listeners_'][_0x23ff68])){const _0x162be7=[...this['listeners_'][_0x23ff68]];for(let _0x2b6deb=0x0;_0x2b6deb<_0x162be7['length'];_0x2b6deb++)_0x162be7[_0x2b6deb]['callback']['apply'](_0x162be7[_0x2b6deb]['context'],_0x4a2b98);}}['on'](_0xb14f2,_0x319d3c,_0x1130a6){this['validateEventType_'](_0xb14f2),this['listeners_'][_0xb14f2]=this['listeners_'][_0xb14f2]||[],this['listeners_'][_0xb14f2]['push']({'callback':_0x319d3c,'context':_0x1130a6});const _0x5bbbe8=this['getInitialEvent'](_0xb14f2);_0x5bbbe8&&_0x319d3c['apply'](_0x1130a6,_0x5bbbe8);}['off'](_0x2b2c4c,_0x325b49,_0xe17494){this['validateEventType_'](_0x2b2c4c);const _0x69f08=this['listeners_'][_0x2b2c4c]||[];for(let _0x15afa1=0x0;_0x15afa1<_0x69f08['length'];_0x15afa1++)if(_0x69f08[_0x15afa1]['callback']===_0x325b49&&(!_0xe17494||_0xe17494===_0x69f08[_0x15afa1]['context'])){_0x69f08['splice'](_0x15afa1,0x1);return;}}['validateEventType_'](_0x5b15f5){f(this['allowedEvents_']['find'](_0x5278ed=>_0x5278ed===_0x5b15f5),'Unknown\x20event:\x20'+_0x5b15f5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2d2a4a){return f(_0x2d2a4a==='online','Unknown\x20event\x20type:\x20'+_0x2d2a4a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x792353,_0x58926e){if(_0x58926e===void 0x0){this['pieces_']=_0x792353['split']('/');let _0x3891e3=0x0;for(let _0x3d16a0=0x0;_0x3d16a0<this['pieces_']['length'];_0x3d16a0++)this['pieces_'][_0x3d16a0]['length']>0x0&&(this['pieces_'][_0x3891e3]=this['pieces_'][_0x3d16a0],_0x3891e3++);this['pieces_']['length']=_0x3891e3,this['pieceNum_']=0x0;}else this['pieces_']=_0x792353,this['pieceNum_']=_0x58926e;}['toString'](){let _0x17acc5='';for(let _0x2a5584=this['pieceNum_'];_0x2a5584<this['pieces_']['length'];_0x2a5584++)this['pieces_'][_0x2a5584]!==''&&(_0x17acc5+='/'+this['pieces_'][_0x2a5584]);return _0x17acc5||'/';}}function w(){return new C('');}function y(_0x5b9520){return _0x5b9520['pieceNum_']>=_0x5b9520['pieces_']['length']?null:_0x5b9520['pieces_'][_0x5b9520['pieceNum_']];}function we(_0xb545d9){return _0xb545d9['pieces_']['length']-_0xb545d9['pieceNum_'];}function b(_0x2f2c33){let _0x3463d5=_0x2f2c33['pieceNum_'];return _0x3463d5<_0x2f2c33['pieces_']['length']&&_0x3463d5++,new C(_0x2f2c33['pieces_'],_0x3463d5);}function Gi(_0x134a49){return _0x134a49['pieceNum_']<_0x134a49['pieces_']['length']?_0x134a49['pieces_'][_0x134a49['pieces_']['length']-0x1]:null;}function Ch(_0x323359){let _0x17fe09='';for(let _0x3f2799=_0x323359['pieceNum_'];_0x3f2799<_0x323359['pieces_']['length'];_0x3f2799++)_0x323359['pieces_'][_0x3f2799]!==''&&(_0x17fe09+='/'+encodeURIComponent(String(_0x323359['pieces_'][_0x3f2799])));return _0x17fe09||'/';}function kt(_0x20bb7b,_0x305d5b=0x0){return _0x20bb7b['pieces_']['slice'](_0x20bb7b['pieceNum_']+_0x305d5b);}function To(_0x411c28){if(_0x411c28['pieceNum_']>=_0x411c28['pieces_']['length'])return null;const _0x22ae1a=[];for(let _0x46a11e=_0x411c28['pieceNum_'];_0x46a11e<_0x411c28['pieces_']['length']-0x1;_0x46a11e++)_0x22ae1a['push'](_0x411c28['pieces_'][_0x46a11e]);return new C(_0x22ae1a,0x0);}function A(_0x2e3e7c,_0x26e4e9){const _0x1a6145=[];for(let _0xdeb0b2=_0x2e3e7c['pieceNum_'];_0xdeb0b2<_0x2e3e7c['pieces_']['length'];_0xdeb0b2++)_0x1a6145['push'](_0x2e3e7c['pieces_'][_0xdeb0b2]);if(_0x26e4e9 instanceof C){for(let _0x3f627f=_0x26e4e9['pieceNum_'];_0x3f627f<_0x26e4e9['pieces_']['length'];_0x3f627f++)_0x1a6145['push'](_0x26e4e9['pieces_'][_0x3f627f]);}else{const _0x3c6364=_0x26e4e9['split']('/');for(let _0x171ff7=0x0;_0x171ff7<_0x3c6364['length'];_0x171ff7++)_0x3c6364[_0x171ff7]['length']>0x0&&_0x1a6145['push'](_0x3c6364[_0x171ff7]);}return new C(_0x1a6145,0x0);}function v(_0x52f271){return _0x52f271['pieceNum_']>=_0x52f271['pieces_']['length'];}function F(_0x490aae,_0x20739d){const _0xf3ac59=y(_0x490aae),_0x375491=y(_0x20739d);if(_0xf3ac59===null)return _0x20739d;if(_0xf3ac59===_0x375491)return F(b(_0x490aae),b(_0x20739d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x20739d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x490aae+')');}function Th(_0x55f764,_0x130596){const _0x760774=kt(_0x55f764,0x0),_0x15303b=kt(_0x130596,0x0);for(let _0x27bb71=0x0;_0x27bb71<_0x760774['length']&&_0x27bb71<_0x15303b['length'];_0x27bb71++){const _0x551da3=He(_0x760774[_0x27bb71],_0x15303b[_0x27bb71]);if(_0x551da3!==0x0)return _0x551da3;}return _0x760774['length']===_0x15303b['length']?0x0:_0x760774['length']<_0x15303b['length']?-0x1:0x1;}function qi(_0x3eb2b2,_0x345c20){if(we(_0x3eb2b2)!==we(_0x345c20))return!0x1;for(let _0x3d0aa6=_0x3eb2b2['pieceNum_'],_0x2b40a0=_0x345c20['pieceNum_'];_0x3d0aa6<=_0x3eb2b2['pieces_']['length'];_0x3d0aa6++,_0x2b40a0++)if(_0x3eb2b2['pieces_'][_0x3d0aa6]!==_0x345c20['pieces_'][_0x2b40a0])return!0x1;return!0x0;}function $(_0x572b5a,_0x565ab9){let _0x1354ad=_0x572b5a['pieceNum_'],_0x240353=_0x565ab9['pieceNum_'];if(we(_0x572b5a)>we(_0x565ab9))return!0x1;for(;_0x1354ad<_0x572b5a['pieces_']['length'];){if(_0x572b5a['pieces_'][_0x1354ad]!==_0x565ab9['pieces_'][_0x240353])return!0x1;++_0x1354ad,++_0x240353;}return!0x0;}class Sh{constructor(_0x327d8d,_0x1850d0){this['errorPrefix_']=_0x1850d0,this['parts_']=kt(_0x327d8d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x174ee3=0x0;_0x174ee3<this['parts_']['length'];_0x174ee3++)this['byteLength_']+=Pn(this['parts_'][_0x174ee3]);So(this);}}function bh(_0x470264,_0x411f61){_0x470264['parts_']['length']>0x0&&(_0x470264['byteLength_']+=0x1),_0x470264['parts_']['push'](_0x411f61),_0x470264['byteLength_']+=Pn(_0x411f61),So(_0x470264);}function Rh(_0x3c1eda){const _0x32cf0d=_0x3c1eda['parts_']['pop']();_0x3c1eda['byteLength_']-=Pn(_0x32cf0d),_0x3c1eda['parts_']['length']>0x0&&(_0x3c1eda['byteLength_']-=0x1);}function So(_0x1695f7){if(_0x1695f7['byteLength_']>Js)throw new Error(_0x1695f7['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x1695f7['byteLength_']+').');if(_0x1695f7['parts_']['length']>Qs)throw new Error(_0x1695f7['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x1695f7));}function Ne(_0x3350d0){return _0x3350d0['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3350d0['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3cca04,_0x3e10c0;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3e10c0='visibilitychange',_0x3cca04='hidden'):typeof document['mozHidden']<'u'?(_0x3e10c0='mozvisibilitychange',_0x3cca04='mozHidden'):typeof document['msHidden']<'u'?(_0x3e10c0='msvisibilitychange',_0x3cca04='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3e10c0='webkitvisibilitychange',_0x3cca04='webkitHidden')),this['visible_']=!0x0,_0x3e10c0&&document['addEventListener'](_0x3e10c0,()=>{const _0x236834=!document[_0x3cca04];_0x236834!==this['visible_']&&(this['visible_']=_0x236834,this['trigger']('visible',_0x236834));},!0x1);}['getInitialEvent'](_0x2aa7a5){return f(_0x2aa7a5==='visible','Unknown\x20event\x20type:\x20'+_0x2aa7a5),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0xe5b6cb,_0x1f1fc5,_0x344cda,_0x386e3b,_0x303b42,_0x1592e0,_0x5266c7,_0x45c0fe){if(super(),this['repoInfo_']=_0xe5b6cb,this['applicationId_']=_0x1f1fc5,this['onDataUpdate_']=_0x344cda,this['onConnectStatus_']=_0x386e3b,this['onServerInfoUpdate_']=_0x303b42,this['authTokenProvider_']=_0x1592e0,this['appCheckTokenProvider_']=_0x5266c7,this['authOverride_']=_0x45c0fe,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x45c0fe)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0xe5b6cb['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x148f86,_0x1621d8,_0x43d1bd){const _0x376ba1=++this['requestNumber_'],_0xa103ee={'r':_0x376ba1,'a':_0x148f86,'b':_0x1621d8};this['log_'](O(_0xa103ee)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xa103ee),_0x43d1bd&&(this['requestCBHash_'][_0x376ba1]=_0x43d1bd);}['get'](_0x2a70c9){this['initConnection_']();const _0x4e88e6=new Ve(),_0x2a4eab={'action':'g','request':{'p':_0x2a70c9['_path']['toString'](),'q':_0x2a70c9['_queryObject']},'onComplete':_0xcc5536=>{const _0x1a5986=_0xcc5536['d'];_0xcc5536['s']==='ok'?_0x4e88e6['resolve'](_0x1a5986):_0x4e88e6['reject'](_0x1a5986);}};this['outstandingGets_']['push'](_0x2a4eab),this['outstandingGetCount_']++;const _0x1757e8=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1757e8),_0x4e88e6['promise'];}['listen'](_0x353ad1,_0x3b0fdb,_0x2a9f40,_0x5720ff){this['initConnection_']();const _0x5b62b6=_0x353ad1['_queryIdentifier'],_0x36b290=_0x353ad1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x36b290+'\x20'+_0x5b62b6),this['listens']['has'](_0x36b290)||this['listens']['set'](_0x36b290,new Map()),f(_0x353ad1['_queryParams']['isDefault']()||!_0x353ad1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x36b290)['has'](_0x5b62b6),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2dccba={'onComplete':_0x5720ff,'hashFn':_0x3b0fdb,'query':_0x353ad1,'tag':_0x2a9f40};this['listens']['get'](_0x36b290)['set'](_0x5b62b6,_0x2dccba),this['connected_']&&this['sendListen_'](_0x2dccba);}['sendGet_'](_0x165150){const _0x407d23=this['outstandingGets_'][_0x165150];this['sendRequest']('g',_0x407d23['request'],_0x298b80=>{delete this['outstandingGets_'][_0x165150],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x407d23['onComplete']&&_0x407d23['onComplete'](_0x298b80);});}['sendListen_'](_0x1e0c27){const _0xb0e08d=_0x1e0c27['query'],_0x37c112=_0xb0e08d['_path']['toString'](),_0x1ecc78=_0xb0e08d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x37c112+'\x20for\x20'+_0x1ecc78);const _0x5e62ee={'p':_0x37c112},_0x2262c5='q';_0x1e0c27['tag']&&(_0x5e62ee['q']=_0xb0e08d['_queryObject'],_0x5e62ee['t']=_0x1e0c27['tag']),_0x5e62ee['h']=_0x1e0c27['hashFn'](),this['sendRequest'](_0x2262c5,_0x5e62ee,_0x3b0570=>{const _0x3ad870=_0x3b0570['d'],_0x3915eb=_0x3b0570['s'];ie['warnOnListenWarnings_'](_0x3ad870,_0xb0e08d),(this['listens']['get'](_0x37c112)&&this['listens']['get'](_0x37c112)['get'](_0x1ecc78))===_0x1e0c27&&(this['log_']('listen\x20response',_0x3b0570),_0x3915eb!=='ok'&&this['removeListen_'](_0x37c112,_0x1ecc78),_0x1e0c27['onComplete']&&_0x1e0c27['onComplete'](_0x3915eb,_0x3ad870));});}static['warnOnListenWarnings_'](_0x408a95,_0x4eb489){if(_0x408a95&&typeof _0x408a95=='object'&&Y(_0x408a95,'w')){const _0x1452b6=Oe(_0x408a95,'w');if(Array['isArray'](_0x1452b6)&&~_0x1452b6['indexOf']('no_index')){const _0x1e8b13='\x22.indexOn\x22:\x20\x22'+_0x4eb489['_queryParams']['getIndex']()['toString']()+'\x22',_0x4b8aa8=_0x4eb489['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1e8b13+'\x20at\x20'+_0x4b8aa8+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x51ae13){this['authToken_']=_0x51ae13,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x51ae13);}['reduceReconnectDelayIfAdminCredential_'](_0x2754a5){(_0x2754a5&&_0x2754a5['length']===0x28||vc(_0x2754a5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x2291de){this['appCheckToken_']=_0x2291de,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5c3561=this['authToken_'],_0x3432b7=yc(_0x5c3561)?'auth':'gauth',_0xb77f2f={'cred':_0x5c3561};this['authOverride_']===null?_0xb77f2f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xb77f2f['authvar']=this['authOverride_']),this['sendRequest'](_0x3432b7,_0xb77f2f,_0xd07367=>{const _0x6b6688=_0xd07367['s'],_0x126808=_0xd07367['d']||'error';this['authToken_']===_0x5c3561&&(_0x6b6688==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x6b6688,_0x126808));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5aa287=>{const _0x174f2a=_0x5aa287['s'],_0x4e2393=_0x5aa287['d']||'error';_0x174f2a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x174f2a,_0x4e2393);});}['unlisten'](_0x48d3c9,_0x317130){const _0x5ceded=_0x48d3c9['_path']['toString'](),_0x3d2e82=_0x48d3c9['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5ceded+'\x20'+_0x3d2e82),f(_0x48d3c9['_queryParams']['isDefault']()||!_0x48d3c9['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5ceded,_0x3d2e82)&&this['connected_']&&this['sendUnlisten_'](_0x5ceded,_0x3d2e82,_0x48d3c9['_queryObject'],_0x317130);}['sendUnlisten_'](_0x9c5461,_0xc0a682,_0x39ab22,_0x452779){this['log_']('Unlisten\x20on\x20'+_0x9c5461+'\x20for\x20'+_0xc0a682);const _0xeae17={'p':_0x9c5461},_0x74ba45='n';_0x452779&&(_0xeae17['q']=_0x39ab22,_0xeae17['t']=_0x452779),this['sendRequest'](_0x74ba45,_0xeae17);}['onDisconnectPut'](_0x4e9f50,_0x36c22e,_0x17aa70){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4e9f50,_0x36c22e,_0x17aa70):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4e9f50,'action':'o','data':_0x36c22e,'onComplete':_0x17aa70});}['onDisconnectMerge'](_0x1fe9ea,_0x12a2a6,_0x1a2b4a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1fe9ea,_0x12a2a6,_0x1a2b4a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1fe9ea,'action':'om','data':_0x12a2a6,'onComplete':_0x1a2b4a});}['onDisconnectCancel'](_0x4ef1d0,_0x41fe76){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4ef1d0,null,_0x41fe76):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4ef1d0,'action':'oc','data':null,'onComplete':_0x41fe76});}['sendOnDisconnect_'](_0x39f6af,_0x176f36,_0xf33452,_0x53484c){const _0x3ef00f={'p':_0x176f36,'d':_0xf33452};this['log_']('onDisconnect\x20'+_0x39f6af,_0x3ef00f),this['sendRequest'](_0x39f6af,_0x3ef00f,_0x195a42=>{_0x53484c&&setTimeout(()=>{_0x53484c(_0x195a42['s'],_0x195a42['d']);},Math['floor'](0x0));});}['put'](_0x49f4bc,_0x5581ea,_0x4a11f8,_0x4479c6){this['putInternal']('p',_0x49f4bc,_0x5581ea,_0x4a11f8,_0x4479c6);}['merge'](_0x52598e,_0xcb0c2b,_0x5f4531,_0x2fbe91){this['putInternal']('m',_0x52598e,_0xcb0c2b,_0x5f4531,_0x2fbe91);}['putInternal'](_0x5e1966,_0x1e664f,_0x21551b,_0x47d74d,_0x517fb1){this['initConnection_']();const _0x4fa039={'p':_0x1e664f,'d':_0x21551b};_0x517fb1!==void 0x0&&(_0x4fa039['h']=_0x517fb1),this['outstandingPuts_']['push']({'action':_0x5e1966,'request':_0x4fa039,'onComplete':_0x47d74d}),this['outstandingPutCount_']++;const _0x39bb4c=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x39bb4c):this['log_']('Buffering\x20put:\x20'+_0x1e664f);}['sendPut_'](_0x491997){const _0x1450f8=this['outstandingPuts_'][_0x491997]['action'],_0x14b970=this['outstandingPuts_'][_0x491997]['request'],_0x2c36d6=this['outstandingPuts_'][_0x491997]['onComplete'];this['outstandingPuts_'][_0x491997]['queued']=this['connected_'],this['sendRequest'](_0x1450f8,_0x14b970,_0x3f7ea6=>{this['log_'](_0x1450f8+'\x20response',_0x3f7ea6),delete this['outstandingPuts_'][_0x491997],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2c36d6&&_0x2c36d6(_0x3f7ea6['s'],_0x3f7ea6['d']);});}['reportStats'](_0x29b6d1){if(this['connected_']){const _0x5e1530={'c':_0x29b6d1};this['log_']('reportStats',_0x5e1530),this['sendRequest']('s',_0x5e1530,_0x5489f5=>{if(_0x5489f5['s']!=='ok'){const _0x3a0c93=_0x5489f5['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3a0c93);}});}}['onDataMessage_'](_0x136226){if('r'in _0x136226){this['log_']('from\x20server:\x20'+O(_0x136226));const _0x3e9894=_0x136226['r'],_0x248c42=this['requestCBHash_'][_0x3e9894];_0x248c42&&(delete this['requestCBHash_'][_0x3e9894],_0x248c42(_0x136226['b']));}else{if('error'in _0x136226)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x136226['error'];'a'in _0x136226&&this['onDataPush_'](_0x136226['a'],_0x136226['b']);}}['onDataPush_'](_0x458769,_0xd37a46){this['log_']('handleServerMessage',_0x458769,_0xd37a46),_0x458769==='d'?this['onDataUpdate_'](_0xd37a46['p'],_0xd37a46['d'],!0x1,_0xd37a46['t']):_0x458769==='m'?this['onDataUpdate_'](_0xd37a46['p'],_0xd37a46['d'],!0x0,_0xd37a46['t']):_0x458769==='c'?this['onListenRevoked_'](_0xd37a46['p'],_0xd37a46['q']):_0x458769==='ac'?this['onAuthRevoked_'](_0xd37a46['s'],_0xd37a46['d']):_0x458769==='apc'?this['onAppCheckRevoked_'](_0xd37a46['s'],_0xd37a46['d']):_0x458769==='sd'?this['onSecurityDebugPacket_'](_0xd37a46):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x458769)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x572034,_0x2bf5df){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x572034),this['lastSessionId']=_0x2bf5df,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x193c61){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x193c61));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2f3223){_0x2f3223&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2f3223;}['onOnline_'](_0x45be08){_0x45be08?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x577b17=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xfd7c53=Math['max'](0x0,this['reconnectDelay_']-_0x577b17);_0xfd7c53=Math['random']()*_0xfd7c53,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xfd7c53+'ms'),this['scheduleConnect_'](_0xfd7c53),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x280479=this['onDataMessage_']['bind'](this),_0x21085c=this['onReady_']['bind'](this),_0x49564a=this['onRealtimeDisconnect_']['bind'](this),_0x2cac7f=this['id']+':'+ie['nextConnectionId_']++,_0x26f9e3=this['lastSessionId'];let _0x3726b1=!0x1,_0x465baa=null;const _0x2a5fef=function(){_0x465baa?_0x465baa['close']():(_0x3726b1=!0x0,_0x49564a());},_0x3409f3=function(_0x2ba232){f(_0x465baa,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x465baa['sendRequest'](_0x2ba232);};this['realtime_']={'close':_0x2a5fef,'sendRequest':_0x3409f3};const _0x5326ea=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1f319c,_0x1c6211]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5326ea),this['appCheckTokenProvider_']['getToken'](_0x5326ea)]);_0x3726b1?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1f319c&&_0x1f319c['accessToken'],this['appCheckToken_']=_0x1c6211&&_0x1c6211['token'],_0x465baa=new wh(_0x2cac7f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x280479,_0x21085c,_0x49564a,_0x52f2f7=>{U(_0x52f2f7+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x26f9e3));}catch(_0x2576ac){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2576ac),_0x3726b1||(this['repoInfo_']['nodeAdmin']&&U(_0x2576ac),_0x2a5fef());}}}['interrupt'](_0x1c23c5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1c23c5),this['interruptReasons_'][_0x1c23c5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x21ebb6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x21ebb6),delete this['interruptReasons_'][_0x21ebb6],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x17abf0){const _0x31237b=_0x17abf0-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x31237b});}['cancelSentTransactions_'](){for(let _0x153697=0x0;_0x153697<this['outstandingPuts_']['length'];_0x153697++){const _0x92b9ee=this['outstandingPuts_'][_0x153697];_0x92b9ee&&'h'in _0x92b9ee['request']&&_0x92b9ee['queued']&&(_0x92b9ee['onComplete']&&_0x92b9ee['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x153697],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x265b9c,_0x4bbd37){let _0x3d1f38;_0x4bbd37?_0x3d1f38=_0x4bbd37['map'](_0xde3666=>Bi(_0xde3666))['join']('$'):_0x3d1f38='default';const _0xe1db62=this['removeListen_'](_0x265b9c,_0x3d1f38);_0xe1db62&&_0xe1db62['onComplete']&&_0xe1db62['onComplete']('permission_denied');}['removeListen_'](_0x5d4946,_0x12d181){const _0x1f51b1=new C(_0x5d4946)['toString']();let _0x524976;if(this['listens']['has'](_0x1f51b1)){const _0x3aa00f=this['listens']['get'](_0x1f51b1);_0x524976=_0x3aa00f['get'](_0x12d181),_0x3aa00f['delete'](_0x12d181),_0x3aa00f['size']===0x0&&this['listens']['delete'](_0x1f51b1);}else _0x524976=void 0x0;return _0x524976;}['onAuthRevoked_'](_0x45fe63,_0x342911){L('Auth\x20token\x20revoked:\x20'+_0x45fe63+'/'+_0x342911),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x45fe63==='invalid_token'||_0x45fe63==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x17a26a,_0xae0190){L('App\x20check\x20token\x20revoked:\x20'+_0x17a26a+'/'+_0xae0190),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x17a26a==='invalid_token'||_0x17a26a==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3f43df){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3f43df):'msg'in _0x3f43df&&console['log']('FIREBASE:\x20'+_0x3f43df['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x55648d of this['listens']['values']())for(const _0x1d36fb of _0x55648d['values']())this['sendListen_'](_0x1d36fb);for(let _0xd280b6=0x0;_0xd280b6<this['outstandingPuts_']['length'];_0xd280b6++)this['outstandingPuts_'][_0xd280b6]&&this['sendPut_'](_0xd280b6);for(;this['onDisconnectRequestQueue_']['length'];){const _0x52de21=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x52de21['action'],_0x52de21['pathString'],_0x52de21['data'],_0x52de21['onComplete']);}for(let _0x642c57=0x0;_0x642c57<this['outstandingGets_']['length'];_0x642c57++)this['outstandingGets_'][_0x642c57]&&this['sendGet_'](_0x642c57);}['sendConnectStats_'](){const _0x262e89={};let _0x44a4e4='js';_0x262e89['sdk.'+_0x44a4e4+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x262e89['framework.cordova']=0x1:qr()&&(_0x262e89['framework.reactnative']=0x1),this['reportStats'](_0x262e89);}['shouldReconnect_'](){const _0x51ee0c=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x51ee0c;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3b7bf7,_0x55de34){this['name']=_0x3b7bf7,this['node']=_0x55de34;}static['Wrap'](_0x9895ed,_0x568f58){return new E(_0x9895ed,_0x568f58);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1c55a4,_0x4c7d92){const _0x4b8523=new E(xe,_0x1c55a4),_0x4a9c11=new E(xe,_0x4c7d92);return this['compare'](_0x4b8523,_0x4a9c11)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x28fd66){Xt=_0x28fd66;}['compare'](_0x51271a,_0x106c10){return He(_0x51271a['name'],_0x106c10['name']);}['isDefinedOn'](_0x561289){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x39fcda,_0x44e484){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x13dc23,_0x590d5a){return f(typeof _0x13dc23=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x13dc23,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x49e76d,_0x2fb5ea,_0x3721ba,_0x5bd09d,_0x4289bf=null){this['isReverse_']=_0x5bd09d,this['resultGenerator_']=_0x4289bf,this['nodeStack_']=[];let _0x3fb049=0x1;for(;!_0x49e76d['isEmpty']();)if(_0x49e76d=_0x49e76d,_0x3fb049=_0x2fb5ea?_0x3721ba(_0x49e76d['key'],_0x2fb5ea):0x1,_0x5bd09d&&(_0x3fb049*=-0x1),_0x3fb049<0x0)this['isReverse_']?_0x49e76d=_0x49e76d['left']:_0x49e76d=_0x49e76d['right'];else{if(_0x3fb049===0x0){this['nodeStack_']['push'](_0x49e76d);break;}else this['nodeStack_']['push'](_0x49e76d),this['isReverse_']?_0x49e76d=_0x49e76d['right']:_0x49e76d=_0x49e76d['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x48dc4f=this['nodeStack_']['pop'](),_0x222102;if(this['resultGenerator_']?_0x222102=this['resultGenerator_'](_0x48dc4f['key'],_0x48dc4f['value']):_0x222102={'key':_0x48dc4f['key'],'value':_0x48dc4f['value']},this['isReverse_']){for(_0x48dc4f=_0x48dc4f['left'];!_0x48dc4f['isEmpty']();)this['nodeStack_']['push'](_0x48dc4f),_0x48dc4f=_0x48dc4f['right'];}else{for(_0x48dc4f=_0x48dc4f['right'];!_0x48dc4f['isEmpty']();)this['nodeStack_']['push'](_0x48dc4f),_0x48dc4f=_0x48dc4f['left'];}return _0x222102;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x213042=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x213042['key'],_0x213042['value']):{'key':_0x213042['key'],'value':_0x213042['value']};}}class M{constructor(_0x38d2e4,_0x5f03f3,_0x2d4128,_0x4fddab,_0x416a40){this['key']=_0x38d2e4,this['value']=_0x5f03f3,this['color']=_0x2d4128??M['RED'],this['left']=_0x4fddab??B['EMPTY_NODE'],this['right']=_0x416a40??B['EMPTY_NODE'];}['copy'](_0x236992,_0x9ce4ca,_0x1a3245,_0x32b976,_0x133f5d){return new M(_0x236992??this['key'],_0x9ce4ca??this['value'],_0x1a3245??this['color'],_0x32b976??this['left'],_0x133f5d??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x21197b){return this['left']['inorderTraversal'](_0x21197b)||!!_0x21197b(this['key'],this['value'])||this['right']['inorderTraversal'](_0x21197b);}['reverseTraversal'](_0xd855ba){return this['right']['reverseTraversal'](_0xd855ba)||_0xd855ba(this['key'],this['value'])||this['left']['reverseTraversal'](_0xd855ba);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x207843,_0x1721c4,_0xd1d22a){let _0x39954e=this;const _0x3ad49e=_0xd1d22a(_0x207843,_0x39954e['key']);return _0x3ad49e<0x0?_0x39954e=_0x39954e['copy'](null,null,null,_0x39954e['left']['insert'](_0x207843,_0x1721c4,_0xd1d22a),null):_0x3ad49e===0x0?_0x39954e=_0x39954e['copy'](null,_0x1721c4,null,null,null):_0x39954e=_0x39954e['copy'](null,null,null,null,_0x39954e['right']['insert'](_0x207843,_0x1721c4,_0xd1d22a)),_0x39954e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x51ff02=this;return!_0x51ff02['left']['isRed_']()&&!_0x51ff02['left']['left']['isRed_']()&&(_0x51ff02=_0x51ff02['moveRedLeft_']()),_0x51ff02=_0x51ff02['copy'](null,null,null,_0x51ff02['left']['removeMin_'](),null),_0x51ff02['fixUp_']();}['remove'](_0x1a2335,_0x10af34){let _0x2c5f04,_0x1da512;if(_0x2c5f04=this,_0x10af34(_0x1a2335,_0x2c5f04['key'])<0x0)!_0x2c5f04['left']['isEmpty']()&&!_0x2c5f04['left']['isRed_']()&&!_0x2c5f04['left']['left']['isRed_']()&&(_0x2c5f04=_0x2c5f04['moveRedLeft_']()),_0x2c5f04=_0x2c5f04['copy'](null,null,null,_0x2c5f04['left']['remove'](_0x1a2335,_0x10af34),null);else{if(_0x2c5f04['left']['isRed_']()&&(_0x2c5f04=_0x2c5f04['rotateRight_']()),!_0x2c5f04['right']['isEmpty']()&&!_0x2c5f04['right']['isRed_']()&&!_0x2c5f04['right']['left']['isRed_']()&&(_0x2c5f04=_0x2c5f04['moveRedRight_']()),_0x10af34(_0x1a2335,_0x2c5f04['key'])===0x0){if(_0x2c5f04['right']['isEmpty']())return B['EMPTY_NODE'];_0x1da512=_0x2c5f04['right']['min_'](),_0x2c5f04=_0x2c5f04['copy'](_0x1da512['key'],_0x1da512['value'],null,null,_0x2c5f04['right']['removeMin_']());}_0x2c5f04=_0x2c5f04['copy'](null,null,null,null,_0x2c5f04['right']['remove'](_0x1a2335,_0x10af34));}return _0x2c5f04['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4ad20e=this;return _0x4ad20e['right']['isRed_']()&&!_0x4ad20e['left']['isRed_']()&&(_0x4ad20e=_0x4ad20e['rotateLeft_']()),_0x4ad20e['left']['isRed_']()&&_0x4ad20e['left']['left']['isRed_']()&&(_0x4ad20e=_0x4ad20e['rotateRight_']()),_0x4ad20e['left']['isRed_']()&&_0x4ad20e['right']['isRed_']()&&(_0x4ad20e=_0x4ad20e['colorFlip_']()),_0x4ad20e;}['moveRedLeft_'](){let _0x3ed9e0=this['colorFlip_']();return _0x3ed9e0['right']['left']['isRed_']()&&(_0x3ed9e0=_0x3ed9e0['copy'](null,null,null,null,_0x3ed9e0['right']['rotateRight_']()),_0x3ed9e0=_0x3ed9e0['rotateLeft_'](),_0x3ed9e0=_0x3ed9e0['colorFlip_']()),_0x3ed9e0;}['moveRedRight_'](){let _0x4f0da3=this['colorFlip_']();return _0x4f0da3['left']['left']['isRed_']()&&(_0x4f0da3=_0x4f0da3['rotateRight_'](),_0x4f0da3=_0x4f0da3['colorFlip_']()),_0x4f0da3;}['rotateLeft_'](){const _0x3ab969=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3ab969,null);}['rotateRight_'](){const _0x308748=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x308748);}['colorFlip_'](){const _0x2fc729=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x81a1e1=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2fc729,_0x81a1e1);}['checkMaxDepth_'](){const _0x81874e=this['check_']();return Math['pow'](0x2,_0x81874e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xe6e59d=this['left']['check_']();if(_0xe6e59d!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xe6e59d+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x2d9b9e,_0x55382d,_0x4e838c,_0x130d03,_0x8fcfc0){return this;}['insert'](_0x1ffe61,_0x1de7fb,_0x57055a){return new M(_0x1ffe61,_0x1de7fb,null);}['remove'](_0x315902,_0x2733ca){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2b05bf){return!0x1;}['reverseTraversal'](_0x3e0e1d){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x178b95,_0x22ffa8=B['EMPTY_NODE']){this['comparator_']=_0x178b95,this['root_']=_0x22ffa8;}['insert'](_0x5a3f20,_0x1b7dd8){return new B(this['comparator_'],this['root_']['insert'](_0x5a3f20,_0x1b7dd8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1b3676){return new B(this['comparator_'],this['root_']['remove'](_0x1b3676,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x57f5d4){let _0x2b60d1,_0x39487f=this['root_'];for(;!_0x39487f['isEmpty']();){if(_0x2b60d1=this['comparator_'](_0x57f5d4,_0x39487f['key']),_0x2b60d1===0x0)return _0x39487f['value'];_0x2b60d1<0x0?_0x39487f=_0x39487f['left']:_0x2b60d1>0x0&&(_0x39487f=_0x39487f['right']);}return null;}['getPredecessorKey'](_0x3b51ca){let _0x15c430,_0xbb02de=this['root_'],_0x2f0dbf=null;for(;!_0xbb02de['isEmpty']();)if(_0x15c430=this['comparator_'](_0x3b51ca,_0xbb02de['key']),_0x15c430===0x0){if(_0xbb02de['left']['isEmpty']())return _0x2f0dbf?_0x2f0dbf['key']:null;for(_0xbb02de=_0xbb02de['left'];!_0xbb02de['right']['isEmpty']();)_0xbb02de=_0xbb02de['right'];return _0xbb02de['key'];}else _0x15c430<0x0?_0xbb02de=_0xbb02de['left']:_0x15c430>0x0&&(_0x2f0dbf=_0xbb02de,_0xbb02de=_0xbb02de['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1b930d){return this['root_']['inorderTraversal'](_0x1b930d);}['reverseTraversal'](_0x294448){return this['root_']['reverseTraversal'](_0x294448);}['getIterator'](_0x74cb98){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x74cb98);}['getIteratorFrom'](_0x286849,_0x2fe846){return new Zt(this['root_'],_0x286849,this['comparator_'],!0x1,_0x2fe846);}['getReverseIteratorFrom'](_0x5cd013,_0x14c634){return new Zt(this['root_'],_0x5cd013,this['comparator_'],!0x0,_0x14c634);}['getReverseIterator'](_0x2e7af3){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x2e7af3);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xda95c6,_0x352cb3){return He(_0xda95c6['name'],_0x352cb3['name']);}function ji(_0xa8686b,_0x47d945){return He(_0xa8686b,_0x47d945);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5a6d55){vi=_0x5a6d55;}const Ro=function(_0x2cbc4d){return typeof _0x2cbc4d=='number'?'number:'+so(_0x2cbc4d):'string:'+_0x2cbc4d;},Ao=function(_0xf1f0b2){if(_0xf1f0b2['isLeafNode']()){const _0x1df58b=_0xf1f0b2['val']();f(typeof _0x1df58b=='string'||typeof _0x1df58b=='number'||typeof _0x1df58b=='object'&&Y(_0x1df58b,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xf1f0b2===vi||_0xf1f0b2['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xf1f0b2===vi||_0xf1f0b2['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5d5a79){er=_0x5d5a79;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x50c64e,_0x5c4d88=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x50c64e,this['priorityNode_']=_0x5c4d88,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x40c9e0){return new D(this['value_'],_0x40c9e0);}['getImmediateChild'](_0xa0247d){return _0xa0247d==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x421258){return v(_0x421258)?this:y(_0x421258)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x17ec44,_0x5bcd7a){return null;}['updateImmediateChild'](_0x7e9221,_0x3faf54){return _0x7e9221==='.priority'?this['updatePriority'](_0x3faf54):_0x3faf54['isEmpty']()&&_0x7e9221!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x7e9221,_0x3faf54)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2b5a0b,_0x1eb952){const _0x4724a5=y(_0x2b5a0b);return _0x4724a5===null?_0x1eb952:_0x1eb952['isEmpty']()&&_0x4724a5!=='.priority'?this:(f(_0x4724a5!=='.priority'||we(_0x2b5a0b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4724a5,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2b5a0b),_0x1eb952)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1ef4c2,_0x17fd73){return!0x1;}['val'](_0x30e4f6){return _0x30e4f6&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x32d469='';this['priorityNode_']['isEmpty']()||(_0x32d469+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x344c31=typeof this['value_'];_0x32d469+=_0x344c31+':',_0x344c31==='number'?_0x32d469+=so(this['value_']):_0x32d469+=this['value_'],this['lazyHash_']=no(_0x32d469);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x49305a){return _0x49305a===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x49305a instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x49305a['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x49305a));}['compareToLeafNode_'](_0x3aff36){const _0x768ce=typeof _0x3aff36['value_'],_0x5be2e6=typeof this['value_'],_0x405c13=D['VALUE_TYPE_ORDER']['indexOf'](_0x768ce),_0x4ce8fd=D['VALUE_TYPE_ORDER']['indexOf'](_0x5be2e6);return f(_0x405c13>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x768ce),f(_0x4ce8fd>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5be2e6),_0x405c13===_0x4ce8fd?_0x5be2e6==='object'?0x0:this['value_']<_0x3aff36['value_']?-0x1:this['value_']===_0x3aff36['value_']?0x0:0x1:_0x4ce8fd-_0x405c13;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2ebf7d){if(_0x2ebf7d===this)return!0x0;if(_0x2ebf7d['isLeafNode']()){const _0x386b32=_0x2ebf7d;return this['value_']===_0x386b32['value_']&&this['priorityNode_']['equals'](_0x386b32['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3b9ad1){ko=_0x3b9ad1;}function xh(_0x1358ab){No=_0x1358ab;}class Fh extends On{['compare'](_0x156836,_0x4f0cdb){const _0x2256ca=_0x156836['node']['getPriority'](),_0x1b0875=_0x4f0cdb['node']['getPriority'](),_0xf40de=_0x2256ca['compareTo'](_0x1b0875);return _0xf40de===0x0?He(_0x156836['name'],_0x4f0cdb['name']):_0xf40de;}['isDefinedOn'](_0x4b7762){return!_0x4b7762['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4d4708,_0x176ceb){return!_0x4d4708['getPriority']()['equals'](_0x176ceb['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1fbcaf,_0x3dd2d9){const _0x4bf1cd=ko(_0x1fbcaf);return new E(_0x3dd2d9,new D('[PRIORITY-POST]',_0x4bf1cd));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4cece4){const _0x40db9c=_0x2d2b6c=>parseInt(Math['log'](_0x2d2b6c)/Uh,0xa),_0x1f59b8=_0x459b09=>parseInt(Array(_0x459b09+0x1)['join']('1'),0x2);this['count']=_0x40db9c(_0x4cece4+0x1),this['current_']=this['count']-0x1;const _0x5f2314=_0x1f59b8(this['count']);this['bits_']=_0x4cece4+0x1&_0x5f2314;}['nextBitIsOne'](){const _0x2d9692=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2d9692;}}const dn=function(_0x16d2a8,_0x40b292,_0x5a93d9,_0x557c2e){_0x16d2a8['sort'](_0x40b292);const _0x2260db=function(_0x435d64,_0x29621a){const _0x155851=_0x29621a-_0x435d64;let _0x45f6a8,_0x4199b7;if(_0x155851===0x0)return null;if(_0x155851===0x1)return _0x45f6a8=_0x16d2a8[_0x435d64],_0x4199b7=_0x5a93d9?_0x5a93d9(_0x45f6a8):_0x45f6a8,new M(_0x4199b7,_0x45f6a8['node'],M['BLACK'],null,null);{const _0x33c8da=parseInt(_0x155851/0x2,0xa)+_0x435d64,_0x5f59c7=_0x2260db(_0x435d64,_0x33c8da),_0x4eca32=_0x2260db(_0x33c8da+0x1,_0x29621a);return _0x45f6a8=_0x16d2a8[_0x33c8da],_0x4199b7=_0x5a93d9?_0x5a93d9(_0x45f6a8):_0x45f6a8,new M(_0x4199b7,_0x45f6a8['node'],M['BLACK'],_0x5f59c7,_0x4eca32);}},_0x1bfc57=function(_0x2bcee3){let _0xd4dda7=null,_0x26b854=null,_0x279326=_0x16d2a8['length'];const _0x24292f=function(_0x2139b9,_0x3f0934){const _0x3fbe02=_0x279326-_0x2139b9,_0x549379=_0x279326;_0x279326-=_0x2139b9;const _0x2aec8b=_0x2260db(_0x3fbe02+0x1,_0x549379),_0x35012a=_0x16d2a8[_0x3fbe02],_0x7b2573=_0x5a93d9?_0x5a93d9(_0x35012a):_0x35012a;_0x1defa0(new M(_0x7b2573,_0x35012a['node'],_0x3f0934,null,_0x2aec8b));},_0x1defa0=function(_0x1ac608){_0xd4dda7?(_0xd4dda7['left']=_0x1ac608,_0xd4dda7=_0x1ac608):(_0x26b854=_0x1ac608,_0xd4dda7=_0x1ac608);};for(let _0x51c288=0x0;_0x51c288<_0x2bcee3['count'];++_0x51c288){const _0x35b09b=_0x2bcee3['nextBitIsOne'](),_0x44f3bb=Math['pow'](0x2,_0x2bcee3['count']-(_0x51c288+0x1));_0x35b09b?_0x24292f(_0x44f3bb,M['BLACK']):(_0x24292f(_0x44f3bb,M['BLACK']),_0x24292f(_0x44f3bb,M['RED']));}return _0x26b854;},_0x1db6ff=new Wh(_0x16d2a8['length']),_0x223f6a=_0x1bfc57(_0x1db6ff);return new B(_0x557c2e||_0x40b292,_0x223f6a);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x1467bf,_0x2f2e74){this['indexes_']=_0x1467bf,this['indexSet_']=_0x2f2e74;}['get'](_0x593330){const _0x50382f=Oe(this['indexes_'],_0x593330);if(!_0x50382f)throw new Error('No\x20index\x20defined\x20for\x20'+_0x593330);return _0x50382f instanceof B?_0x50382f:null;}['hasIndex'](_0x139251){return Y(this['indexSet_'],_0x139251['toString']());}['addIndex'](_0xf711df,_0x35f8ad){f(_0xf711df!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1603a9=[];let _0x482287=!0x1;const _0x103a59=_0x35f8ad['getIterator'](E['Wrap']);let _0xbc01f9=_0x103a59['getNext']();for(;_0xbc01f9;)_0x482287=_0x482287||_0xf711df['isDefinedOn'](_0xbc01f9['node']),_0x1603a9['push'](_0xbc01f9),_0xbc01f9=_0x103a59['getNext']();let _0x43d42d;_0x482287?_0x43d42d=dn(_0x1603a9,_0xf711df['getCompare']()):_0x43d42d=je;const _0x48c510=_0xf711df['toString'](),_0x284a98={...this['indexSet_']};_0x284a98[_0x48c510]=_0xf711df;const _0x3c1833={...this['indexes_']};return _0x3c1833[_0x48c510]=_0x43d42d,new ee(_0x3c1833,_0x284a98);}['addToIndexes'](_0xbbe5ba,_0x339411){const _0x2eeaf8=ln(this['indexes_'],(_0x62f491,_0xe2cc7f)=>{const _0x124517=Oe(this['indexSet_'],_0xe2cc7f);if(f(_0x124517,'Missing\x20index\x20implementation\x20for\x20'+_0xe2cc7f),_0x62f491===je){if(_0x124517['isDefinedOn'](_0xbbe5ba['node'])){const _0x19d526=[],_0x1c0fba=_0x339411['getIterator'](E['Wrap']);let _0x219ea8=_0x1c0fba['getNext']();for(;_0x219ea8;)_0x219ea8['name']!==_0xbbe5ba['name']&&_0x19d526['push'](_0x219ea8),_0x219ea8=_0x1c0fba['getNext']();return _0x19d526['push'](_0xbbe5ba),dn(_0x19d526,_0x124517['getCompare']());}else return je;}else{const _0x1da65c=_0x339411['get'](_0xbbe5ba['name']);let _0x4da3b1=_0x62f491;return _0x1da65c&&(_0x4da3b1=_0x4da3b1['remove'](new E(_0xbbe5ba['name'],_0x1da65c))),_0x4da3b1['insert'](_0xbbe5ba,_0xbbe5ba['node']);}});return new ee(_0x2eeaf8,this['indexSet_']);}['removeFromIndexes'](_0x38a524,_0x19cdcb){const _0x4e32ce=ln(this['indexes_'],_0x585287=>{if(_0x585287===je)return _0x585287;{const _0x48e453=_0x19cdcb['get'](_0x38a524['name']);return _0x48e453?_0x585287['remove'](new E(_0x38a524['name'],_0x48e453)):_0x585287;}});return new ee(_0x4e32ce,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0xb3b57e,_0x392409,_0x2a6d94){this['children_']=_0xb3b57e,this['priorityNode_']=_0x392409,this['indexMap_']=_0x2a6d94,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x11f730){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x11f730,this['indexMap_']);}['getImmediateChild'](_0x504c20){if(_0x504c20==='.priority')return this['getPriority']();{const _0x2dd122=this['children_']['get'](_0x504c20);return _0x2dd122===null?gt:_0x2dd122;}}['getChild'](_0x232a15){const _0x59a5f0=y(_0x232a15);return _0x59a5f0===null?this:this['getImmediateChild'](_0x59a5f0)['getChild'](b(_0x232a15));}['hasChild'](_0x35542c){return this['children_']['get'](_0x35542c)!==null;}['updateImmediateChild'](_0x748800,_0xa377cd){if(f(_0xa377cd,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x748800==='.priority')return this['updatePriority'](_0xa377cd);{const _0xf572e5=new E(_0x748800,_0xa377cd);let _0x4b758d,_0x406d0c;_0xa377cd['isEmpty']()?(_0x4b758d=this['children_']['remove'](_0x748800),_0x406d0c=this['indexMap_']['removeFromIndexes'](_0xf572e5,this['children_'])):(_0x4b758d=this['children_']['insert'](_0x748800,_0xa377cd),_0x406d0c=this['indexMap_']['addToIndexes'](_0xf572e5,this['children_']));const _0x30822f=_0x4b758d['isEmpty']()?gt:this['priorityNode_'];return new g(_0x4b758d,_0x30822f,_0x406d0c);}}['updateChild'](_0x143f06,_0x5c7beb){const _0x516bf7=y(_0x143f06);if(_0x516bf7===null)return _0x5c7beb;{f(y(_0x143f06)!=='.priority'||we(_0x143f06)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x372f90=this['getImmediateChild'](_0x516bf7)['updateChild'](b(_0x143f06),_0x5c7beb);return this['updateImmediateChild'](_0x516bf7,_0x372f90);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xa5c89d){if(this['isEmpty']())return null;const _0x27315d={};let _0x9808d5=0x0,_0x2e658b=0x0,_0x50b873=!0x0;if(this['forEachChild'](R,(_0x33a914,_0x1a6c01)=>{_0x27315d[_0x33a914]=_0x1a6c01['val'](_0xa5c89d),_0x9808d5++,_0x50b873&&g['INTEGER_REGEXP_']['test'](_0x33a914)?_0x2e658b=Math['max'](_0x2e658b,Number(_0x33a914)):_0x50b873=!0x1;}),!_0xa5c89d&&_0x50b873&&_0x2e658b<0x2*_0x9808d5){const _0x24f911=[];for(const _0x60d388 in _0x27315d)_0x24f911[_0x60d388]=_0x27315d[_0x60d388];return _0x24f911;}else return _0xa5c89d&&!this['getPriority']()['isEmpty']()&&(_0x27315d['.priority']=this['getPriority']()['val']()),_0x27315d;}['hash'](){if(this['lazyHash_']===null){let _0x52609d='';this['getPriority']()['isEmpty']()||(_0x52609d+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x33ff18,_0x2b3359)=>{const _0xa6f827=_0x2b3359['hash']();_0xa6f827!==''&&(_0x52609d+=':'+_0x33ff18+':'+_0xa6f827);}),this['lazyHash_']=_0x52609d===''?'':no(_0x52609d);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3a7e81,_0x25dff1,_0x574908){const _0x5d4d6a=this['resolveIndex_'](_0x574908);if(_0x5d4d6a){const _0x257935=_0x5d4d6a['getPredecessorKey'](new E(_0x3a7e81,_0x25dff1));return _0x257935?_0x257935['name']:null;}else return this['children_']['getPredecessorKey'](_0x3a7e81);}['getFirstChildName'](_0x3eafbe){const _0x221c7a=this['resolveIndex_'](_0x3eafbe);if(_0x221c7a){const _0x255aa8=_0x221c7a['minKey']();return _0x255aa8&&_0x255aa8['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x45fd4b){const _0x2d510e=this['getFirstChildName'](_0x45fd4b);return _0x2d510e?new E(_0x2d510e,this['children_']['get'](_0x2d510e)):null;}['getLastChildName'](_0x1c014b){const _0x37d20f=this['resolveIndex_'](_0x1c014b);if(_0x37d20f){const _0x273429=_0x37d20f['maxKey']();return _0x273429&&_0x273429['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x46f977){const _0x2792f7=this['getLastChildName'](_0x46f977);return _0x2792f7?new E(_0x2792f7,this['children_']['get'](_0x2792f7)):null;}['forEachChild'](_0x4c6faf,_0x3f405f){const _0x585160=this['resolveIndex_'](_0x4c6faf);return _0x585160?_0x585160['inorderTraversal'](_0xd476b8=>_0x3f405f(_0xd476b8['name'],_0xd476b8['node'])):this['children_']['inorderTraversal'](_0x3f405f);}['getIterator'](_0x4be9dc){return this['getIteratorFrom'](_0x4be9dc['minPost'](),_0x4be9dc);}['getIteratorFrom'](_0xf1c8f8,_0x27005c){const _0xbbd98b=this['resolveIndex_'](_0x27005c);if(_0xbbd98b)return _0xbbd98b['getIteratorFrom'](_0xf1c8f8,_0x10ca8d=>_0x10ca8d);{const _0x52412e=this['children_']['getIteratorFrom'](_0xf1c8f8['name'],E['Wrap']);let _0x26cbd7=_0x52412e['peek']();for(;_0x26cbd7!=null&&_0x27005c['compare'](_0x26cbd7,_0xf1c8f8)<0x0;)_0x52412e['getNext'](),_0x26cbd7=_0x52412e['peek']();return _0x52412e;}}['getReverseIterator'](_0x2d2c76){return this['getReverseIteratorFrom'](_0x2d2c76['maxPost'](),_0x2d2c76);}['getReverseIteratorFrom'](_0x1b4d78,_0x3e28e6){const _0x2441b0=this['resolveIndex_'](_0x3e28e6);if(_0x2441b0)return _0x2441b0['getReverseIteratorFrom'](_0x1b4d78,_0x47cdd1=>_0x47cdd1);{const _0x3304ae=this['children_']['getReverseIteratorFrom'](_0x1b4d78['name'],E['Wrap']);let _0x2bca29=_0x3304ae['peek']();for(;_0x2bca29!=null&&_0x3e28e6['compare'](_0x2bca29,_0x1b4d78)>0x0;)_0x3304ae['getNext'](),_0x2bca29=_0x3304ae['peek']();return _0x3304ae;}}['compareTo'](_0x30bab8){return this['isEmpty']()?_0x30bab8['isEmpty']()?0x0:-0x1:_0x30bab8['isLeafNode']()||_0x30bab8['isEmpty']()?0x1:_0x30bab8===Ht?-0x1:0x0;}['withIndex'](_0x45ac03){if(_0x45ac03===ye||this['indexMap_']['hasIndex'](_0x45ac03))return this;{const _0x2c8638=this['indexMap_']['addIndex'](_0x45ac03,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2c8638);}}['isIndexed'](_0x15f82d){return _0x15f82d===ye||this['indexMap_']['hasIndex'](_0x15f82d);}['equals'](_0x4ef153){if(_0x4ef153===this)return!0x0;if(_0x4ef153['isLeafNode']())return!0x1;{const _0x2d2ba8=_0x4ef153;if(this['getPriority']()['equals'](_0x2d2ba8['getPriority']())){if(this['children_']['count']()===_0x2d2ba8['children_']['count']()){const _0x66939=this['getIterator'](R),_0x3c49d0=_0x2d2ba8['getIterator'](R);let _0x428fbe=_0x66939['getNext'](),_0x159e50=_0x3c49d0['getNext']();for(;_0x428fbe&&_0x159e50;){if(_0x428fbe['name']!==_0x159e50['name']||!_0x428fbe['node']['equals'](_0x159e50['node']))return!0x1;_0x428fbe=_0x66939['getNext'](),_0x159e50=_0x3c49d0['getNext']();}return _0x428fbe===null&&_0x159e50===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xc940d3){return _0xc940d3===ye?null:this['indexMap_']['get'](_0xc940d3['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x181118){return _0x181118===this?0x0:0x1;}['equals'](_0x432a82){return _0x432a82===this;}['getPriority'](){return this;}['getImmediateChild'](_0xdece60){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5030e0,_0x4c70be=null){if(_0x5030e0===null)return g['EMPTY_NODE'];if(typeof _0x5030e0=='object'&&'.priority'in _0x5030e0&&(_0x4c70be=_0x5030e0['.priority']),f(_0x4c70be===null||typeof _0x4c70be=='string'||typeof _0x4c70be=='number'||typeof _0x4c70be=='object'&&'.sv'in _0x4c70be,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4c70be),typeof _0x5030e0=='object'&&'.value'in _0x5030e0&&_0x5030e0['.value']!==null&&(_0x5030e0=_0x5030e0['.value']),typeof _0x5030e0!='object'||'.sv'in _0x5030e0){const _0x47f2f6=_0x5030e0;return new D(_0x47f2f6,N(_0x4c70be));}if(!(_0x5030e0 instanceof Array)&&Vh){const _0x289200=[];let _0xf4c69a=!0x1;if(x(_0x5030e0,(_0x406f52,_0x1b0a23)=>{if(_0x406f52['substring'](0x0,0x1)!=='.'){const _0xcf79db=N(_0x1b0a23);_0xcf79db['isEmpty']()||(_0xf4c69a=_0xf4c69a||!_0xcf79db['getPriority']()['isEmpty'](),_0x289200['push'](new E(_0x406f52,_0xcf79db)));}}),_0x289200['length']===0x0)return g['EMPTY_NODE'];const _0x1368c6=dn(_0x289200,Dh,_0x2f5879=>_0x2f5879['name'],ji);if(_0xf4c69a){const _0x1b5c42=dn(_0x289200,R['getCompare']());return new g(_0x1368c6,N(_0x4c70be),new ee({'.priority':_0x1b5c42},{'.priority':R}));}else return new g(_0x1368c6,N(_0x4c70be),ee['Default']);}else{let _0x2b638a=g['EMPTY_NODE'];return x(_0x5030e0,(_0x21813f,_0x2001ce)=>{if(Y(_0x5030e0,_0x21813f)&&_0x21813f['substring'](0x0,0x1)!=='.'){const _0x18ad43=N(_0x2001ce);(_0x18ad43['isLeafNode']()||!_0x18ad43['isEmpty']())&&(_0x2b638a=_0x2b638a['updateImmediateChild'](_0x21813f,_0x18ad43));}}),_0x2b638a['updatePriority'](N(_0x4c70be));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x4b2705){super(),this['indexPath_']=_0x4b2705,f(!v(_0x4b2705)&&y(_0x4b2705)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x496110){return _0x496110['getChild'](this['indexPath_']);}['isDefinedOn'](_0x533e2){return!_0x533e2['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5510c6,_0x308723){const _0x16ab72=this['extractChild'](_0x5510c6['node']),_0x4f34fc=this['extractChild'](_0x308723['node']),_0x3e4180=_0x16ab72['compareTo'](_0x4f34fc);return _0x3e4180===0x0?He(_0x5510c6['name'],_0x308723['name']):_0x3e4180;}['makePost'](_0x45ffba,_0x134114){const _0x39cfe3=N(_0x45ffba),_0x2fdb29=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x39cfe3);return new E(_0x134114,_0x2fdb29);}['maxPost'](){const _0x5f287b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x5f287b);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x59df59,_0x2caafe){const _0x2e699f=_0x59df59['node']['compareTo'](_0x2caafe['node']);return _0x2e699f===0x0?He(_0x59df59['name'],_0x2caafe['name']):_0x2e699f;}['isDefinedOn'](_0x365b93){return!0x0;}['indexedValueChanged'](_0x47526c,_0x2227ad){return!_0x47526c['equals'](_0x2227ad);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1baaa2,_0x19669f){const _0x89b84b=N(_0x1baaa2);return new E(_0x19669f,_0x89b84b);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x34e913){return{'type':'value','snapshotNode':_0x34e913};}function tt(_0xe983d5,_0x155195){return{'type':'child_added','snapshotNode':_0x155195,'childName':_0xe983d5};}function Nt(_0x19d8d8,_0xe1fd98){return{'type':'child_removed','snapshotNode':_0xe1fd98,'childName':_0x19d8d8};}function Pt(_0x55f118,_0x21f7a2,_0x5f5625){return{'type':'child_changed','snapshotNode':_0x21f7a2,'childName':_0x55f118,'oldSnap':_0x5f5625};}function $h(_0x513012,_0x2329b2){return{'type':'child_moved','snapshotNode':_0x2329b2,'childName':_0x513012};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x2a48cb){this['index_']=_0x2a48cb;}['updateChild'](_0x32e094,_0x3a1501,_0x17163c,_0x2e1d5b,_0x407c9b,_0x4f2411){f(_0x32e094['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5f2eeb=_0x32e094['getImmediateChild'](_0x3a1501);return _0x5f2eeb['getChild'](_0x2e1d5b)['equals'](_0x17163c['getChild'](_0x2e1d5b))&&_0x5f2eeb['isEmpty']()===_0x17163c['isEmpty']()||(_0x4f2411!=null&&(_0x17163c['isEmpty']()?_0x32e094['hasChild'](_0x3a1501)?_0x4f2411['trackChildChange'](Nt(_0x3a1501,_0x5f2eeb)):f(_0x32e094['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5f2eeb['isEmpty']()?_0x4f2411['trackChildChange'](tt(_0x3a1501,_0x17163c)):_0x4f2411['trackChildChange'](Pt(_0x3a1501,_0x17163c,_0x5f2eeb))),_0x32e094['isLeafNode']()&&_0x17163c['isEmpty']())?_0x32e094:_0x32e094['updateImmediateChild'](_0x3a1501,_0x17163c)['withIndex'](this['index_']);}['updateFullNode'](_0x1fcaef,_0x26387f,_0x388497){return _0x388497!=null&&(_0x1fcaef['isLeafNode']()||_0x1fcaef['forEachChild'](R,(_0x2a7cc1,_0x4ec726)=>{_0x26387f['hasChild'](_0x2a7cc1)||_0x388497['trackChildChange'](Nt(_0x2a7cc1,_0x4ec726));}),_0x26387f['isLeafNode']()||_0x26387f['forEachChild'](R,(_0x432ca1,_0xe95748)=>{if(_0x1fcaef['hasChild'](_0x432ca1)){const _0x351168=_0x1fcaef['getImmediateChild'](_0x432ca1);_0x351168['equals'](_0xe95748)||_0x388497['trackChildChange'](Pt(_0x432ca1,_0xe95748,_0x351168));}else _0x388497['trackChildChange'](tt(_0x432ca1,_0xe95748));})),_0x26387f['withIndex'](this['index_']);}['updatePriority'](_0x3a2284,_0x34d4dc){return _0x3a2284['isEmpty']()?g['EMPTY_NODE']:_0x3a2284['updatePriority'](_0x34d4dc);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2ae511){this['indexedFilter_']=new Yi(_0x2ae511['getIndex']()),this['index_']=_0x2ae511['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2ae511),this['endPost_']=Ot['getEndPost_'](_0x2ae511),this['startIsInclusive_']=!_0x2ae511['startAfterSet_'],this['endIsInclusive_']=!_0x2ae511['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x16d346){const _0x5a5698=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x16d346)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x16d346)<0x0,_0x2e05f5=this['endIsInclusive_']?this['index_']['compare'](_0x16d346,this['getEndPost']())<=0x0:this['index_']['compare'](_0x16d346,this['getEndPost']())<0x0;return _0x5a5698&&_0x2e05f5;}['updateChild'](_0x113439,_0x1215db,_0x54102a,_0x3cfdd8,_0x17b41b,_0x31b855){return this['matches'](new E(_0x1215db,_0x54102a))||(_0x54102a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x113439,_0x1215db,_0x54102a,_0x3cfdd8,_0x17b41b,_0x31b855);}['updateFullNode'](_0x294667,_0x355f2c,_0x54d482){_0x355f2c['isLeafNode']()&&(_0x355f2c=g['EMPTY_NODE']);let _0x3ecfde=_0x355f2c['withIndex'](this['index_']);_0x3ecfde=_0x3ecfde['updatePriority'](g['EMPTY_NODE']);const _0x1b2b24=this;return _0x355f2c['forEachChild'](R,(_0x38984d,_0x10ac27)=>{_0x1b2b24['matches'](new E(_0x38984d,_0x10ac27))||(_0x3ecfde=_0x3ecfde['updateImmediateChild'](_0x38984d,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x294667,_0x3ecfde,_0x54d482);}['updatePriority'](_0x583fb4,_0x31a379){return _0x583fb4;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1bb225){if(_0x1bb225['hasStart']()){const _0x53e431=_0x1bb225['getIndexStartName']();return _0x1bb225['getIndex']()['makePost'](_0x1bb225['getIndexStartValue'](),_0x53e431);}else return _0x1bb225['getIndex']()['minPost']();}static['getEndPost_'](_0xa98388){if(_0xa98388['hasEnd']()){const _0x209559=_0xa98388['getIndexEndName']();return _0xa98388['getIndex']()['makePost'](_0xa98388['getIndexEndValue'](),_0x209559);}else return _0xa98388['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x1e0768){this['withinDirectionalStart']=_0x4bf127=>this['reverse_']?this['withinEndPost'](_0x4bf127):this['withinStartPost'](_0x4bf127),this['withinDirectionalEnd']=_0x377dcc=>this['reverse_']?this['withinStartPost'](_0x377dcc):this['withinEndPost'](_0x377dcc),this['withinStartPost']=_0x576eb7=>{const _0x2bb1b9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x576eb7);return this['startIsInclusive_']?_0x2bb1b9<=0x0:_0x2bb1b9<0x0;},this['withinEndPost']=_0x406e8a=>{const _0x149549=this['index_']['compare'](_0x406e8a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x149549<=0x0:_0x149549<0x0;},this['rangedFilter_']=new Ot(_0x1e0768),this['index_']=_0x1e0768['getIndex'](),this['limit_']=_0x1e0768['getLimit'](),this['reverse_']=!_0x1e0768['isViewFromLeft'](),this['startIsInclusive_']=!_0x1e0768['startAfterSet_'],this['endIsInclusive_']=!_0x1e0768['endBeforeSet_'];}['updateChild'](_0x56793f,_0x147761,_0x4f5026,_0x16b7df,_0x43743c,_0x5ea4a6){return this['rangedFilter_']['matches'](new E(_0x147761,_0x4f5026))||(_0x4f5026=g['EMPTY_NODE']),_0x56793f['getImmediateChild'](_0x147761)['equals'](_0x4f5026)?_0x56793f:_0x56793f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x56793f,_0x147761,_0x4f5026,_0x16b7df,_0x43743c,_0x5ea4a6):this['fullLimitUpdateChild_'](_0x56793f,_0x147761,_0x4f5026,_0x43743c,_0x5ea4a6);}['updateFullNode'](_0x22c9c9,_0x131973,_0x1c83a3){let _0x24ba72;if(_0x131973['isLeafNode']()||_0x131973['isEmpty']())_0x24ba72=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x131973['numChildren']()&&_0x131973['isIndexed'](this['index_'])){_0x24ba72=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x6f3ad9;this['reverse_']?_0x6f3ad9=_0x131973['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x6f3ad9=_0x131973['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x431ca3=0x0;for(;_0x6f3ad9['hasNext']()&&_0x431ca3<this['limit_'];){const _0x389045=_0x6f3ad9['getNext']();if(this['withinDirectionalStart'](_0x389045)){if(this['withinDirectionalEnd'](_0x389045))_0x24ba72=_0x24ba72['updateImmediateChild'](_0x389045['name'],_0x389045['node']),_0x431ca3++;else break;}else continue;}}else{_0x24ba72=_0x131973['withIndex'](this['index_']),_0x24ba72=_0x24ba72['updatePriority'](g['EMPTY_NODE']);let _0x5139e9;this['reverse_']?_0x5139e9=_0x24ba72['getReverseIterator'](this['index_']):_0x5139e9=_0x24ba72['getIterator'](this['index_']);let _0x4e49c8=0x0;for(;_0x5139e9['hasNext']();){const _0x5bdc82=_0x5139e9['getNext']();_0x4e49c8<this['limit_']&&this['withinDirectionalStart'](_0x5bdc82)&&this['withinDirectionalEnd'](_0x5bdc82)?_0x4e49c8++:_0x24ba72=_0x24ba72['updateImmediateChild'](_0x5bdc82['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x22c9c9,_0x24ba72,_0x1c83a3);}['updatePriority'](_0x44ae64,_0x1f472d){return _0x44ae64;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x6c6d43,_0x56669d,_0x1bfdc2,_0x5bf402,_0x53395a){let _0x188bd4;if(this['reverse_']){const _0x6073d0=this['index_']['getCompare']();_0x188bd4=(_0x588c66,_0x21e935)=>_0x6073d0(_0x21e935,_0x588c66);}else _0x188bd4=this['index_']['getCompare']();const _0x3eaad2=_0x6c6d43;f(_0x3eaad2['numChildren']()===this['limit_'],'');const _0x3ba812=new E(_0x56669d,_0x1bfdc2),_0xae41a9=this['reverse_']?_0x3eaad2['getFirstChild'](this['index_']):_0x3eaad2['getLastChild'](this['index_']),_0x343bb8=this['rangedFilter_']['matches'](_0x3ba812);if(_0x3eaad2['hasChild'](_0x56669d)){const _0x1bc3a1=_0x3eaad2['getImmediateChild'](_0x56669d);let _0x1266ab=_0x5bf402['getChildAfterChild'](this['index_'],_0xae41a9,this['reverse_']);for(;_0x1266ab!=null&&(_0x1266ab['name']===_0x56669d||_0x3eaad2['hasChild'](_0x1266ab['name']));)_0x1266ab=_0x5bf402['getChildAfterChild'](this['index_'],_0x1266ab,this['reverse_']);const _0x25ddae=_0x1266ab==null?0x1:_0x188bd4(_0x1266ab,_0x3ba812);if(_0x343bb8&&!_0x1bfdc2['isEmpty']()&&_0x25ddae>=0x0)return _0x53395a!=null&&_0x53395a['trackChildChange'](Pt(_0x56669d,_0x1bfdc2,_0x1bc3a1)),_0x3eaad2['updateImmediateChild'](_0x56669d,_0x1bfdc2);{_0x53395a!=null&&_0x53395a['trackChildChange'](Nt(_0x56669d,_0x1bc3a1));const _0xfdf6a3=_0x3eaad2['updateImmediateChild'](_0x56669d,g['EMPTY_NODE']);return _0x1266ab!=null&&this['rangedFilter_']['matches'](_0x1266ab)?(_0x53395a!=null&&_0x53395a['trackChildChange'](tt(_0x1266ab['name'],_0x1266ab['node'])),_0xfdf6a3['updateImmediateChild'](_0x1266ab['name'],_0x1266ab['node'])):_0xfdf6a3;}}else return _0x1bfdc2['isEmpty']()?_0x6c6d43:_0x343bb8&&_0x188bd4(_0xae41a9,_0x3ba812)>=0x0?(_0x53395a!=null&&(_0x53395a['trackChildChange'](Nt(_0xae41a9['name'],_0xae41a9['node'])),_0x53395a['trackChildChange'](tt(_0x56669d,_0x1bfdc2))),_0x3eaad2['updateImmediateChild'](_0x56669d,_0x1bfdc2)['updateImmediateChild'](_0xae41a9['name'],g['EMPTY_NODE'])):_0x6c6d43;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x94fd=new Qi();return _0x94fd['limitSet_']=this['limitSet_'],_0x94fd['limit_']=this['limit_'],_0x94fd['startSet_']=this['startSet_'],_0x94fd['startAfterSet_']=this['startAfterSet_'],_0x94fd['indexStartValue_']=this['indexStartValue_'],_0x94fd['startNameSet_']=this['startNameSet_'],_0x94fd['indexStartName_']=this['indexStartName_'],_0x94fd['endSet_']=this['endSet_'],_0x94fd['endBeforeSet_']=this['endBeforeSet_'],_0x94fd['indexEndValue_']=this['indexEndValue_'],_0x94fd['endNameSet_']=this['endNameSet_'],_0x94fd['indexEndName_']=this['indexEndName_'],_0x94fd['index_']=this['index_'],_0x94fd['viewFrom_']=this['viewFrom_'],_0x94fd;}}function qh(_0x55e9f7){return _0x55e9f7['loadsAllData']()?new Yi(_0x55e9f7['getIndex']()):_0x55e9f7['hasLimit']()?new Gh(_0x55e9f7):new Ot(_0x55e9f7);}function zh(_0x61be2,_0x5d65d4){const _0x3256c8=_0x61be2['copy']();return _0x3256c8['limitSet_']=!0x0,_0x3256c8['limit_']=_0x5d65d4,_0x3256c8['viewFrom_']='l',_0x3256c8;}function jh(_0x4b8b6f,_0x49c458,_0x2e6bb1){const _0x4b4016=_0x4b8b6f['copy']();return _0x4b4016['startSet_']=!0x0,_0x49c458===void 0x0&&(_0x49c458=null),_0x4b4016['indexStartValue_']=_0x49c458,_0x2e6bb1!=null?(_0x4b4016['startNameSet_']=!0x0,_0x4b4016['indexStartName_']=_0x2e6bb1):(_0x4b4016['startNameSet_']=!0x1,_0x4b4016['indexStartName_']=''),_0x4b4016;}function Kh(_0x3c570e,_0x1d520c,_0x130da8){const _0x2f0549=_0x3c570e['copy']();return _0x2f0549['endSet_']=!0x0,_0x1d520c===void 0x0&&(_0x1d520c=null),_0x2f0549['indexEndValue_']=_0x1d520c,_0x130da8!==void 0x0?(_0x2f0549['endNameSet_']=!0x0,_0x2f0549['indexEndName_']=_0x130da8):(_0x2f0549['endNameSet_']=!0x1,_0x2f0549['indexEndName_']=''),_0x2f0549;}function Do(_0x26a002,_0x20aa92){const _0x42e76b=_0x26a002['copy']();return _0x42e76b['index_']=_0x20aa92,_0x42e76b;}function tr(_0x10f107){const _0x1ff1af={};if(_0x10f107['isDefault']())return _0x1ff1af;let _0x11aa7f;if(_0x10f107['index_']===R?_0x11aa7f='$priority':_0x10f107['index_']===Po?_0x11aa7f='$value':_0x10f107['index_']===ye?_0x11aa7f='$key':(f(_0x10f107['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x11aa7f=_0x10f107['index_']['toString']()),_0x1ff1af['orderBy']=O(_0x11aa7f),_0x10f107['startSet_']){const _0x52217d=_0x10f107['startAfterSet_']?'startAfter':'startAt';_0x1ff1af[_0x52217d]=O(_0x10f107['indexStartValue_']),_0x10f107['startNameSet_']&&(_0x1ff1af[_0x52217d]+=','+O(_0x10f107['indexStartName_']));}if(_0x10f107['endSet_']){const _0x334ea0=_0x10f107['endBeforeSet_']?'endBefore':'endAt';_0x1ff1af[_0x334ea0]=O(_0x10f107['indexEndValue_']),_0x10f107['endNameSet_']&&(_0x1ff1af[_0x334ea0]+=','+O(_0x10f107['indexEndName_']));}return _0x10f107['limitSet_']&&(_0x10f107['isViewFromLeft']()?_0x1ff1af['limitToFirst']=_0x10f107['limit_']:_0x1ff1af['limitToLast']=_0x10f107['limit_']),_0x1ff1af;}function nr(_0x486c7a){const _0x1e7567={};if(_0x486c7a['startSet_']&&(_0x1e7567['sp']=_0x486c7a['indexStartValue_'],_0x486c7a['startNameSet_']&&(_0x1e7567['sn']=_0x486c7a['indexStartName_']),_0x1e7567['sin']=!_0x486c7a['startAfterSet_']),_0x486c7a['endSet_']&&(_0x1e7567['ep']=_0x486c7a['indexEndValue_'],_0x486c7a['endNameSet_']&&(_0x1e7567['en']=_0x486c7a['indexEndName_']),_0x1e7567['ein']=!_0x486c7a['endBeforeSet_']),_0x486c7a['limitSet_']){_0x1e7567['l']=_0x486c7a['limit_'];let _0x3a249b=_0x486c7a['viewFrom_'];_0x3a249b===''&&(_0x486c7a['isViewFromLeft']()?_0x3a249b='l':_0x3a249b='r'),_0x1e7567['vf']=_0x3a249b;}return _0x486c7a['index_']!==R&&(_0x1e7567['i']=_0x486c7a['index_']['toString']()),_0x1e7567;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x143cfd){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3ff1a1,_0x1a8b5a){return _0x1a8b5a!==void 0x0?'tag$'+_0x1a8b5a:(f(_0x3ff1a1['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3ff1a1['_path']['toString']());}constructor(_0xa6c051,_0x15fd5e,_0x11e564,_0x1265a1){super(),this['repoInfo_']=_0xa6c051,this['onDataUpdate_']=_0x15fd5e,this['authTokenProvider_']=_0x11e564,this['appCheckTokenProvider_']=_0x1265a1,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4bc829,_0x5e4822,_0x509e51,_0x4f8bf4){const _0x39e72b=_0x4bc829['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x39e72b+'\x20'+_0x4bc829['_queryIdentifier']);const _0x112f30=fn['getListenId_'](_0x4bc829,_0x509e51),_0x13b077={};this['listens_'][_0x112f30]=_0x13b077;const _0x7e68d1=tr(_0x4bc829['_queryParams']);this['restRequest_'](_0x39e72b+'.json',_0x7e68d1,(_0x55fb64,_0x50172b)=>{let _0x339f78=_0x50172b;if(_0x55fb64===0x194&&(_0x339f78=null,_0x55fb64=null),_0x55fb64===null&&this['onDataUpdate_'](_0x39e72b,_0x339f78,!0x1,_0x509e51),Oe(this['listens_'],_0x112f30)===_0x13b077){let _0x4103be;_0x55fb64?_0x55fb64===0x191?_0x4103be='permission_denied':_0x4103be='rest_error:'+_0x55fb64:_0x4103be='ok',_0x4f8bf4(_0x4103be,null);}});}['unlisten'](_0x3eea82,_0x11caa9){const _0x843b16=fn['getListenId_'](_0x3eea82,_0x11caa9);delete this['listens_'][_0x843b16];}['get'](_0x4fba3d){const _0x7cd210=tr(_0x4fba3d['_queryParams']),_0x1eed46=_0x4fba3d['_path']['toString'](),_0x991015=new Ve();return this['restRequest_'](_0x1eed46+'.json',_0x7cd210,(_0x5a8bd0,_0x423545)=>{let _0x1e240e=_0x423545;_0x5a8bd0===0x194&&(_0x1e240e=null,_0x5a8bd0=null),_0x5a8bd0===null?(this['onDataUpdate_'](_0x1eed46,_0x1e240e,!0x1,null),_0x991015['resolve'](_0x1e240e)):_0x991015['reject'](new Error(_0x1e240e));}),_0x991015['promise'];}['refreshAuthToken'](_0x94985c){}['restRequest_'](_0x220f12,_0x3e49e8={},_0x5e83d5){return _0x3e49e8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1b7401,_0x40b73d])=>{_0x1b7401&&_0x1b7401['accessToken']&&(_0x3e49e8['auth']=_0x1b7401['accessToken']),_0x40b73d&&_0x40b73d['token']&&(_0x3e49e8['ac']=_0x40b73d['token']);const _0x5ef8b9=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x220f12+'?ns='+this['repoInfo_']['namespace']+at(_0x3e49e8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5ef8b9);const _0x135968=new XMLHttpRequest();_0x135968['onreadystatechange']=()=>{if(_0x5e83d5&&_0x135968['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5ef8b9+'\x20received.\x20status:',_0x135968['status'],'response:',_0x135968['responseText']);let _0x208c01=null;if(_0x135968['status']>=0xc8&&_0x135968['status']<0x12c){try{_0x208c01=bt(_0x135968['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5ef8b9+':\x20'+_0x135968['responseText']);}_0x5e83d5(null,_0x208c01);}else _0x135968['status']!==0x191&&_0x135968['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5ef8b9+'\x20Status:\x20'+_0x135968['status']),_0x5e83d5(_0x135968['status']);_0x5e83d5=null;}},_0x135968['open']('GET',_0x5ef8b9,!0x0),_0x135968['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x133463){return this['rootNode_']['getChild'](_0x133463);}['updateSnapshot'](_0x3e33b2,_0x7a0c6){this['rootNode_']=this['rootNode_']['updateChild'](_0x3e33b2,_0x7a0c6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x345c86,_0x50aa78,_0x4b5b8e){if(v(_0x50aa78))_0x345c86['value']=_0x4b5b8e,_0x345c86['children']['clear']();else{if(_0x345c86['value']!==null)_0x345c86['value']=_0x345c86['value']['updateChild'](_0x50aa78,_0x4b5b8e);else{const _0x55f4fa=y(_0x50aa78);_0x345c86['children']['has'](_0x55f4fa)||_0x345c86['children']['set'](_0x55f4fa,pn());const _0x345bfb=_0x345c86['children']['get'](_0x55f4fa);_0x50aa78=b(_0x50aa78),Mo(_0x345bfb,_0x50aa78,_0x4b5b8e);}}}function Ei(_0x2fd883,_0x1d07c5,_0x2528e3){_0x2fd883['value']!==null?_0x2528e3(_0x1d07c5,_0x2fd883['value']):Qh(_0x2fd883,(_0x9e46c6,_0x5d8765)=>{const _0x46f473=new C(_0x1d07c5['toString']()+'/'+_0x9e46c6);Ei(_0x5d8765,_0x46f473,_0x2528e3);});}function Qh(_0xaeca53,_0x3f0ff3){_0xaeca53['children']['forEach']((_0x408d76,_0x475fc6)=>{_0x3f0ff3(_0x475fc6,_0x408d76);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x557769){this['collection_']=_0x557769,this['last_']=null;}['get'](){const _0x545f79=this['collection_']['get'](),_0x2e43f5={..._0x545f79};return this['last_']&&x(this['last_'],(_0xa4b277,_0x16aac5)=>{_0x2e43f5[_0xa4b277]=_0x2e43f5[_0xa4b277]-_0x16aac5;}),this['last_']=_0x545f79,_0x2e43f5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3e7424,_0x233963){this['server_']=_0x233963,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3e7424);const _0x2984cd=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2984cd));}['reportStats_'](){const _0x5daf1d=this['statsListener_']['get'](),_0x434deb={};let _0x329b5b=!0x1;x(_0x5daf1d,(_0x53e018,_0x564cb6)=>{_0x564cb6>0x0&&Y(this['statsToReport_'],_0x53e018)&&(_0x434deb[_0x53e018]=_0x564cb6,_0x329b5b=!0x0);}),_0x329b5b&&this['server_']['reportStats'](_0x434deb),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x1b2797){_0x1b2797[_0x1b2797['OVERWRITE']=0x0]='OVERWRITE',_0x1b2797[_0x1b2797['MERGE']=0x1]='MERGE',_0x1b2797[_0x1b2797['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1b2797[_0x1b2797['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x579898){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x579898,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x30fc7b,_0x51ea5f,_0x2ad85f){this['path']=_0x30fc7b,this['affectedTree']=_0x51ea5f,this['revert']=_0x2ad85f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x26ed98){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4d6004=this['affectedTree']['subtree'](new C(_0x26ed98));return new _n(w(),_0x4d6004,this['revert']);}}else return f(y(this['path'])===_0x26ed98,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0xd1d75c,_0x54cff2){this['source']=_0xd1d75c,this['path']=_0x54cff2,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4f9485){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x4c6bdc,_0x175109,_0x14190a){this['source']=_0x4c6bdc,this['path']=_0x175109,this['snap']=_0x14190a,this['type']=q['OVERWRITE'];}['operationForChild'](_0x42611c){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x42611c)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x1a6653,_0x432722,_0x2f91f8){this['source']=_0x1a6653,this['path']=_0x432722,this['children']=_0x2f91f8,this['type']=q['MERGE'];}['operationForChild'](_0x302a01){if(v(this['path'])){const _0x40a76d=this['children']['subtree'](new C(_0x302a01));return _0x40a76d['isEmpty']()?null:_0x40a76d['value']?new Fe(this['source'],w(),_0x40a76d['value']):new nt(this['source'],w(),_0x40a76d);}else return f(y(this['path'])===_0x302a01,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x882e6b,_0x4bdadc,_0x363e74){this['node_']=_0x882e6b,this['fullyInitialized_']=_0x4bdadc,this['filtered_']=_0x363e74;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1def3f){if(v(_0x1def3f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x22ed41=y(_0x1def3f);return this['isCompleteForChild'](_0x22ed41);}['isCompleteForChild'](_0x2b795f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2b795f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x14e249){this['query_']=_0x14e249,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x51a1c6,_0x3eb875,_0x5ed42b,_0x5cb122){const _0xc71e71=[],_0x31c0c7=[];return _0x3eb875['forEach'](_0x593f24=>{_0x593f24['type']==='child_changed'&&_0x51a1c6['index_']['indexedValueChanged'](_0x593f24['oldSnap'],_0x593f24['snapshotNode'])&&_0x31c0c7['push']($h(_0x593f24['childName'],_0x593f24['snapshotNode']));}),mt(_0x51a1c6,_0xc71e71,'child_removed',_0x3eb875,_0x5cb122,_0x5ed42b),mt(_0x51a1c6,_0xc71e71,'child_added',_0x3eb875,_0x5cb122,_0x5ed42b),mt(_0x51a1c6,_0xc71e71,'child_moved',_0x31c0c7,_0x5cb122,_0x5ed42b),mt(_0x51a1c6,_0xc71e71,'child_changed',_0x3eb875,_0x5cb122,_0x5ed42b),mt(_0x51a1c6,_0xc71e71,'value',_0x3eb875,_0x5cb122,_0x5ed42b),_0xc71e71;}function mt(_0x558334,_0x1a05ab,_0x5e71d1,_0x433c4e,_0x340af7,_0x9146e3){const _0x1a82fe=_0x433c4e['filter'](_0x358f1a=>_0x358f1a['type']===_0x5e71d1);_0x1a82fe['sort']((_0x2dc5d8,_0x2b3f90)=>su(_0x558334,_0x2dc5d8,_0x2b3f90)),_0x1a82fe['forEach'](_0x46efaf=>{const _0x2038d8=iu(_0x558334,_0x46efaf,_0x9146e3);_0x340af7['forEach'](_0x565289=>{_0x565289['respondsTo'](_0x46efaf['type'])&&_0x1a05ab['push'](_0x565289['createEvent'](_0x2038d8,_0x558334['query_']));});});}function iu(_0x5d639f,_0x5a6d7b,_0x240f2e){return _0x5a6d7b['type']==='value'||_0x5a6d7b['type']==='child_removed'||(_0x5a6d7b['prevName']=_0x240f2e['getPredecessorChildName'](_0x5a6d7b['childName'],_0x5a6d7b['snapshotNode'],_0x5d639f['index_'])),_0x5a6d7b;}function su(_0x202778,_0x9ead89,_0x494d3e){if(_0x9ead89['childName']==null||_0x494d3e['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3c131b=new E(_0x9ead89['childName'],_0x9ead89['snapshotNode']),_0x476a79=new E(_0x494d3e['childName'],_0x494d3e['snapshotNode']);return _0x202778['index_']['compare'](_0x3c131b,_0x476a79);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x29131a,_0x40575c){return{'eventCache':_0x29131a,'serverCache':_0x40575c};}function wt(_0x38ff6c,_0x2cbd23,_0x2d62e5,_0x5ad24a){return Dn(new Ce(_0x2cbd23,_0x2d62e5,_0x5ad24a),_0x38ff6c['serverCache']);}function Lo(_0xd23181,_0x55caea,_0xa65501,_0x184473){return Dn(_0xd23181['eventCache'],new Ce(_0x55caea,_0xa65501,_0x184473));}function gn(_0x1887e2){return _0x1887e2['eventCache']['isFullyInitialized']()?_0x1887e2['eventCache']['getNode']():null;}function Ue(_0x3686f7){return _0x3686f7['serverCache']['isFullyInitialized']()?_0x3686f7['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x59f91c){let _0x5ba944=new S(null);return x(_0x59f91c,(_0x3a5f32,_0x2e2375)=>{_0x5ba944=_0x5ba944['set'](new C(_0x3a5f32),_0x2e2375);}),_0x5ba944;}constructor(_0x577781,_0x1417d6=ru()){this['value']=_0x577781,this['children']=_0x1417d6;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x241f90,_0x10d7f0){if(this['value']!=null&&_0x10d7f0(this['value']))return{'path':w(),'value':this['value']};if(v(_0x241f90))return null;{const _0x16f1bd=y(_0x241f90),_0x2dc4d0=this['children']['get'](_0x16f1bd);if(_0x2dc4d0!==null){const _0xf9e28b=_0x2dc4d0['findRootMostMatchingPathAndValue'](b(_0x241f90),_0x10d7f0);return _0xf9e28b!=null?{'path':A(new C(_0x16f1bd),_0xf9e28b['path']),'value':_0xf9e28b['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4d0377){return this['findRootMostMatchingPathAndValue'](_0x4d0377,()=>!0x0);}['subtree'](_0x2d1859){if(v(_0x2d1859))return this;{const _0x1a14ef=y(_0x2d1859),_0x3969bb=this['children']['get'](_0x1a14ef);return _0x3969bb!==null?_0x3969bb['subtree'](b(_0x2d1859)):new S(null);}}['set'](_0x1a5c44,_0x4245d9){if(v(_0x1a5c44))return new S(_0x4245d9,this['children']);{const _0xd04fdf=y(_0x1a5c44),_0x2a223a=(this['children']['get'](_0xd04fdf)||new S(null))['set'](b(_0x1a5c44),_0x4245d9),_0x4563c3=this['children']['insert'](_0xd04fdf,_0x2a223a);return new S(this['value'],_0x4563c3);}}['remove'](_0x25c9ad){if(v(_0x25c9ad))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x1349f2=y(_0x25c9ad),_0x5684e1=this['children']['get'](_0x1349f2);if(_0x5684e1){const _0x42c81f=_0x5684e1['remove'](b(_0x25c9ad));let _0x220c73;return _0x42c81f['isEmpty']()?_0x220c73=this['children']['remove'](_0x1349f2):_0x220c73=this['children']['insert'](_0x1349f2,_0x42c81f),this['value']===null&&_0x220c73['isEmpty']()?new S(null):new S(this['value'],_0x220c73);}else return this;}}['get'](_0x3f5c02){if(v(_0x3f5c02))return this['value'];{const _0x433161=y(_0x3f5c02),_0x539efc=this['children']['get'](_0x433161);return _0x539efc?_0x539efc['get'](b(_0x3f5c02)):null;}}['setTree'](_0x1563f2,_0x24eeef){if(v(_0x1563f2))return _0x24eeef;{const _0x541cfc=y(_0x1563f2),_0x3c7b9d=(this['children']['get'](_0x541cfc)||new S(null))['setTree'](b(_0x1563f2),_0x24eeef);let _0x4a0eaa;return _0x3c7b9d['isEmpty']()?_0x4a0eaa=this['children']['remove'](_0x541cfc):_0x4a0eaa=this['children']['insert'](_0x541cfc,_0x3c7b9d),new S(this['value'],_0x4a0eaa);}}['fold'](_0x452664){return this['fold_'](w(),_0x452664);}['fold_'](_0x270dcb,_0x29878a){const _0xa85199={};return this['children']['inorderTraversal']((_0x1fcffb,_0x903476)=>{_0xa85199[_0x1fcffb]=_0x903476['fold_'](A(_0x270dcb,_0x1fcffb),_0x29878a);}),_0x29878a(_0x270dcb,this['value'],_0xa85199);}['findOnPath'](_0x504caf,_0x3894ee){return this['findOnPath_'](_0x504caf,w(),_0x3894ee);}['findOnPath_'](_0x31166d,_0x438fb7,_0x1035ea){const _0x56248c=this['value']?_0x1035ea(_0x438fb7,this['value']):!0x1;if(_0x56248c)return _0x56248c;if(v(_0x31166d))return null;{const _0x272f36=y(_0x31166d),_0x207840=this['children']['get'](_0x272f36);return _0x207840?_0x207840['findOnPath_'](b(_0x31166d),A(_0x438fb7,_0x272f36),_0x1035ea):null;}}['foreachOnPath'](_0x440f03,_0x1e76e0){return this['foreachOnPath_'](_0x440f03,w(),_0x1e76e0);}['foreachOnPath_'](_0x33ef08,_0x3d9293,_0x1b48e1){if(v(_0x33ef08))return this;{this['value']&&_0x1b48e1(_0x3d9293,this['value']);const _0x26a183=y(_0x33ef08),_0x234e52=this['children']['get'](_0x26a183);return _0x234e52?_0x234e52['foreachOnPath_'](b(_0x33ef08),A(_0x3d9293,_0x26a183),_0x1b48e1):new S(null);}}['foreach'](_0x319b6e){this['foreach_'](w(),_0x319b6e);}['foreach_'](_0x36b454,_0x313a00){this['children']['inorderTraversal']((_0x2cb2fe,_0x5c63fd)=>{_0x5c63fd['foreach_'](A(_0x36b454,_0x2cb2fe),_0x313a00);}),this['value']&&_0x313a00(_0x36b454,this['value']);}['foreachChild'](_0x306e6c){this['children']['inorderTraversal']((_0x322887,_0x191c6d)=>{_0x191c6d['value']&&_0x306e6c(_0x322887,_0x191c6d['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x35e704){this['writeTree_']=_0x35e704;}static['empty'](){return new j(new S(null));}}function Ct(_0x23011e,_0x526f4c,_0x29883d){if(v(_0x526f4c))return new j(new S(_0x29883d));{const _0x3a721f=_0x23011e['writeTree_']['findRootMostValueAndPath'](_0x526f4c);if(_0x3a721f!=null){const _0x33095b=_0x3a721f['path'];let _0x4c91da=_0x3a721f['value'];const _0x22f21b=F(_0x33095b,_0x526f4c);return _0x4c91da=_0x4c91da['updateChild'](_0x22f21b,_0x29883d),new j(_0x23011e['writeTree_']['set'](_0x33095b,_0x4c91da));}else{const _0x1d2df2=new S(_0x29883d),_0x9f6e42=_0x23011e['writeTree_']['setTree'](_0x526f4c,_0x1d2df2);return new j(_0x9f6e42);}}}function Ii(_0x458c9d,_0x20eed7,_0x4e842e){let _0x1b4526=_0x458c9d;return x(_0x4e842e,(_0x557bd5,_0x41e490)=>{_0x1b4526=Ct(_0x1b4526,A(_0x20eed7,_0x557bd5),_0x41e490);}),_0x1b4526;}function sr(_0x40a925,_0x4e2487){if(v(_0x4e2487))return j['empty']();{const _0x27077c=_0x40a925['writeTree_']['setTree'](_0x4e2487,new S(null));return new j(_0x27077c);}}function wi(_0x50d843,_0x5d1701){return $e(_0x50d843,_0x5d1701)!=null;}function $e(_0x5bc4e2,_0x1e5b49){const _0x2b48e5=_0x5bc4e2['writeTree_']['findRootMostValueAndPath'](_0x1e5b49);return _0x2b48e5!=null?_0x5bc4e2['writeTree_']['get'](_0x2b48e5['path'])['getChild'](F(_0x2b48e5['path'],_0x1e5b49)):null;}function rr(_0x1a7221){const _0x1c368c=[],_0x20c574=_0x1a7221['writeTree_']['value'];return _0x20c574!=null?_0x20c574['isLeafNode']()||_0x20c574['forEachChild'](R,(_0x9da313,_0x31a026)=>{_0x1c368c['push'](new E(_0x9da313,_0x31a026));}):_0x1a7221['writeTree_']['children']['inorderTraversal']((_0x417d06,_0x1bdd50)=>{_0x1bdd50['value']!=null&&_0x1c368c['push'](new E(_0x417d06,_0x1bdd50['value']));}),_0x1c368c;}function ve(_0x35ae5e,_0x4bb2f5){if(v(_0x4bb2f5))return _0x35ae5e;{const _0x3b147c=$e(_0x35ae5e,_0x4bb2f5);return _0x3b147c!=null?new j(new S(_0x3b147c)):new j(_0x35ae5e['writeTree_']['subtree'](_0x4bb2f5));}}function Ci(_0x248e8c){return _0x248e8c['writeTree_']['isEmpty']();}function it(_0x20873e,_0x24472e){return xo(w(),_0x20873e['writeTree_'],_0x24472e);}function xo(_0x37a33e,_0x4227e5,_0x5703d7){if(_0x4227e5['value']!=null)return _0x5703d7['updateChild'](_0x37a33e,_0x4227e5['value']);{let _0x594a83=null;return _0x4227e5['children']['inorderTraversal']((_0x40f56a,_0x2ef347)=>{_0x40f56a==='.priority'?(f(_0x2ef347['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x594a83=_0x2ef347['value']):_0x5703d7=xo(A(_0x37a33e,_0x40f56a),_0x2ef347,_0x5703d7);}),!_0x5703d7['getChild'](_0x37a33e)['isEmpty']()&&_0x594a83!==null&&(_0x5703d7=_0x5703d7['updateChild'](A(_0x37a33e,'.priority'),_0x594a83)),_0x5703d7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3aa703,_0x40d65e){return Bo(_0x40d65e,_0x3aa703);}function ou(_0x5959a6,_0x83e734,_0xb33074,_0x143a37,_0x1321dd){f(_0x143a37>_0x5959a6['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1321dd===void 0x0&&(_0x1321dd=!0x0),_0x5959a6['allWrites']['push']({'path':_0x83e734,'snap':_0xb33074,'writeId':_0x143a37,'visible':_0x1321dd}),_0x1321dd&&(_0x5959a6['visibleWrites']=Ct(_0x5959a6['visibleWrites'],_0x83e734,_0xb33074)),_0x5959a6['lastWriteId']=_0x143a37;}function au(_0x5ad641,_0x2f60bb,_0x162753,_0x56bf60){f(_0x56bf60>_0x5ad641['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5ad641['allWrites']['push']({'path':_0x2f60bb,'children':_0x162753,'writeId':_0x56bf60,'visible':!0x0}),_0x5ad641['visibleWrites']=Ii(_0x5ad641['visibleWrites'],_0x2f60bb,_0x162753),_0x5ad641['lastWriteId']=_0x56bf60;}function cu(_0x2ff8e8,_0x461d30){for(let _0xdb1bba=0x0;_0xdb1bba<_0x2ff8e8['allWrites']['length'];_0xdb1bba++){const _0x4ef7eb=_0x2ff8e8['allWrites'][_0xdb1bba];if(_0x4ef7eb['writeId']===_0x461d30)return _0x4ef7eb;}return null;}function lu(_0x2c6bb4,_0x616643){const _0x1d701d=_0x2c6bb4['allWrites']['findIndex'](_0x17c28f=>_0x17c28f['writeId']===_0x616643);f(_0x1d701d>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xd9f8a5=_0x2c6bb4['allWrites'][_0x1d701d];_0x2c6bb4['allWrites']['splice'](_0x1d701d,0x1);let _0x42ffa5=_0xd9f8a5['visible'],_0x4d18ed=!0x1,_0x473d5f=_0x2c6bb4['allWrites']['length']-0x1;for(;_0x42ffa5&&_0x473d5f>=0x0;){const _0x6840d9=_0x2c6bb4['allWrites'][_0x473d5f];_0x6840d9['visible']&&(_0x473d5f>=_0x1d701d&&hu(_0x6840d9,_0xd9f8a5['path'])?_0x42ffa5=!0x1:$(_0xd9f8a5['path'],_0x6840d9['path'])&&(_0x4d18ed=!0x0)),_0x473d5f--;}if(_0x42ffa5){if(_0x4d18ed)return uu(_0x2c6bb4),!0x0;if(_0xd9f8a5['snap'])_0x2c6bb4['visibleWrites']=sr(_0x2c6bb4['visibleWrites'],_0xd9f8a5['path']);else{const _0x46f7fa=_0xd9f8a5['children'];x(_0x46f7fa,_0xbcdd59=>{_0x2c6bb4['visibleWrites']=sr(_0x2c6bb4['visibleWrites'],A(_0xd9f8a5['path'],_0xbcdd59));});}return!0x0;}else return!0x1;}function hu(_0x36e0d8,_0x2a28e4){if(_0x36e0d8['snap'])return $(_0x36e0d8['path'],_0x2a28e4);for(const _0x3a9b3e in _0x36e0d8['children'])if(_0x36e0d8['children']['hasOwnProperty'](_0x3a9b3e)&&$(A(_0x36e0d8['path'],_0x3a9b3e),_0x2a28e4))return!0x0;return!0x1;}function uu(_0x325d66){_0x325d66['visibleWrites']=Fo(_0x325d66['allWrites'],du,w()),_0x325d66['allWrites']['length']>0x0?_0x325d66['lastWriteId']=_0x325d66['allWrites'][_0x325d66['allWrites']['length']-0x1]['writeId']:_0x325d66['lastWriteId']=-0x1;}function du(_0x4fc35d){return _0x4fc35d['visible'];}function Fo(_0x5f7f6c,_0x64b863,_0x9037f){let _0x24cd29=j['empty']();for(let _0xb16947=0x0;_0xb16947<_0x5f7f6c['length'];++_0xb16947){const _0x5ecc53=_0x5f7f6c[_0xb16947];if(_0x64b863(_0x5ecc53)){const _0x5340e5=_0x5ecc53['path'];let _0x320d13;if(_0x5ecc53['snap'])$(_0x9037f,_0x5340e5)?(_0x320d13=F(_0x9037f,_0x5340e5),_0x24cd29=Ct(_0x24cd29,_0x320d13,_0x5ecc53['snap'])):$(_0x5340e5,_0x9037f)&&(_0x320d13=F(_0x5340e5,_0x9037f),_0x24cd29=Ct(_0x24cd29,w(),_0x5ecc53['snap']['getChild'](_0x320d13)));else{if(_0x5ecc53['children']){if($(_0x9037f,_0x5340e5))_0x320d13=F(_0x9037f,_0x5340e5),_0x24cd29=Ii(_0x24cd29,_0x320d13,_0x5ecc53['children']);else{if($(_0x5340e5,_0x9037f)){if(_0x320d13=F(_0x5340e5,_0x9037f),v(_0x320d13))_0x24cd29=Ii(_0x24cd29,w(),_0x5ecc53['children']);else{const _0x39fe1f=Oe(_0x5ecc53['children'],y(_0x320d13));if(_0x39fe1f){const _0x506808=_0x39fe1f['getChild'](b(_0x320d13));_0x24cd29=Ct(_0x24cd29,w(),_0x506808);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x24cd29;}function Uo(_0x4dc1ef,_0x26554e,_0x42df51,_0x23babf,_0x2bb0a5){if(!_0x23babf&&!_0x2bb0a5){const _0x3f3fb7=$e(_0x4dc1ef['visibleWrites'],_0x26554e);if(_0x3f3fb7!=null)return _0x3f3fb7;{const _0x1bf9f3=ve(_0x4dc1ef['visibleWrites'],_0x26554e);if(Ci(_0x1bf9f3))return _0x42df51;if(_0x42df51==null&&!wi(_0x1bf9f3,w()))return null;{const _0x29cb5f=_0x42df51||g['EMPTY_NODE'];return it(_0x1bf9f3,_0x29cb5f);}}}else{const _0x3f6dc7=ve(_0x4dc1ef['visibleWrites'],_0x26554e);if(!_0x2bb0a5&&Ci(_0x3f6dc7))return _0x42df51;if(!_0x2bb0a5&&_0x42df51==null&&!wi(_0x3f6dc7,w()))return null;{const _0x2737f8=function(_0x5cb712){return(_0x5cb712['visible']||_0x2bb0a5)&&(!_0x23babf||!~_0x23babf['indexOf'](_0x5cb712['writeId']))&&($(_0x5cb712['path'],_0x26554e)||$(_0x26554e,_0x5cb712['path']));},_0x550eab=Fo(_0x4dc1ef['allWrites'],_0x2737f8,_0x26554e),_0x45dee5=_0x42df51||g['EMPTY_NODE'];return it(_0x550eab,_0x45dee5);}}}function fu(_0x49294c,_0x3fc5ec,_0x2cbca6){let _0xa0b5e1=g['EMPTY_NODE'];const _0x25a0c9=$e(_0x49294c['visibleWrites'],_0x3fc5ec);if(_0x25a0c9)return _0x25a0c9['isLeafNode']()||_0x25a0c9['forEachChild'](R,(_0x18bd4d,_0x22f196)=>{_0xa0b5e1=_0xa0b5e1['updateImmediateChild'](_0x18bd4d,_0x22f196);}),_0xa0b5e1;if(_0x2cbca6){const _0x239f71=ve(_0x49294c['visibleWrites'],_0x3fc5ec);return _0x2cbca6['forEachChild'](R,(_0x3dbfbd,_0x24df7e)=>{const _0x4e5ea1=it(ve(_0x239f71,new C(_0x3dbfbd)),_0x24df7e);_0xa0b5e1=_0xa0b5e1['updateImmediateChild'](_0x3dbfbd,_0x4e5ea1);}),rr(_0x239f71)['forEach'](_0x445c39=>{_0xa0b5e1=_0xa0b5e1['updateImmediateChild'](_0x445c39['name'],_0x445c39['node']);}),_0xa0b5e1;}else{const _0x71fd56=ve(_0x49294c['visibleWrites'],_0x3fc5ec);return rr(_0x71fd56)['forEach'](_0x3b12fe=>{_0xa0b5e1=_0xa0b5e1['updateImmediateChild'](_0x3b12fe['name'],_0x3b12fe['node']);}),_0xa0b5e1;}}function pu(_0x8a18cb,_0x49051d,_0x181780,_0x35a049,_0x584d6a){f(_0x35a049||_0x584d6a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3469a7=A(_0x49051d,_0x181780);if(wi(_0x8a18cb['visibleWrites'],_0x3469a7))return null;{const _0x2b0d7e=ve(_0x8a18cb['visibleWrites'],_0x3469a7);return Ci(_0x2b0d7e)?_0x584d6a['getChild'](_0x181780):it(_0x2b0d7e,_0x584d6a['getChild'](_0x181780));}}function _u(_0x3f4891,_0x23cb3b,_0x3638bd,_0x44b4dd){const _0x3ddb57=A(_0x23cb3b,_0x3638bd),_0x8f3ce4=$e(_0x3f4891['visibleWrites'],_0x3ddb57);if(_0x8f3ce4!=null)return _0x8f3ce4;if(_0x44b4dd['isCompleteForChild'](_0x3638bd)){const _0x1ed46d=ve(_0x3f4891['visibleWrites'],_0x3ddb57);return it(_0x1ed46d,_0x44b4dd['getNode']()['getImmediateChild'](_0x3638bd));}else return null;}function gu(_0x58b21e,_0xe2eb28){return $e(_0x58b21e['visibleWrites'],_0xe2eb28);}function mu(_0x1d6566,_0x5722e2,_0x4ae30c,_0xe20a6d,_0x378d52,_0x38be5b,_0x26a103){let _0x9c0ae7;const _0x25ed11=ve(_0x1d6566['visibleWrites'],_0x5722e2),_0x3a61ee=$e(_0x25ed11,w());if(_0x3a61ee!=null)_0x9c0ae7=_0x3a61ee;else{if(_0x4ae30c!=null)_0x9c0ae7=it(_0x25ed11,_0x4ae30c);else return[];}if(_0x9c0ae7=_0x9c0ae7['withIndex'](_0x26a103),!_0x9c0ae7['isEmpty']()&&!_0x9c0ae7['isLeafNode']()){const _0x2812d5=[],_0x37e269=_0x26a103['getCompare'](),_0x2d4557=_0x38be5b?_0x9c0ae7['getReverseIteratorFrom'](_0xe20a6d,_0x26a103):_0x9c0ae7['getIteratorFrom'](_0xe20a6d,_0x26a103);let _0x5ded5b=_0x2d4557['getNext']();for(;_0x5ded5b&&_0x2812d5['length']<_0x378d52;)_0x37e269(_0x5ded5b,_0xe20a6d)!==0x0&&_0x2812d5['push'](_0x5ded5b),_0x5ded5b=_0x2d4557['getNext']();return _0x2812d5;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x188703,_0x1e358b,_0x6134e7,_0x13c3cf){return Uo(_0x188703['writeTree'],_0x188703['treePath'],_0x1e358b,_0x6134e7,_0x13c3cf);}function es(_0x3354be,_0x1661ae){return fu(_0x3354be['writeTree'],_0x3354be['treePath'],_0x1661ae);}function or(_0x5d6e68,_0x3599dc,_0x52928d,_0x2a11b6){return pu(_0x5d6e68['writeTree'],_0x5d6e68['treePath'],_0x3599dc,_0x52928d,_0x2a11b6);}function yn(_0x390151,_0x4e4baf){return gu(_0x390151['writeTree'],A(_0x390151['treePath'],_0x4e4baf));}function vu(_0x2af5e1,_0x477023,_0x215acd,_0x39ae1b,_0x1a4921,_0x3e1031){return mu(_0x2af5e1['writeTree'],_0x2af5e1['treePath'],_0x477023,_0x215acd,_0x39ae1b,_0x1a4921,_0x3e1031);}function ts(_0x3b65ea,_0x3e6504,_0x45beab){return _u(_0x3b65ea['writeTree'],_0x3b65ea['treePath'],_0x3e6504,_0x45beab);}function Wo(_0x148182,_0x3e47c8){return Bo(A(_0x148182['treePath'],_0x3e47c8),_0x148182['writeTree']);}function Bo(_0x514a51,_0x17a85b){return{'treePath':_0x514a51,'writeTree':_0x17a85b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2648f7){const _0x123548=_0x2648f7['type'],_0x58b63c=_0x2648f7['childName'];f(_0x123548==='child_added'||_0x123548==='child_changed'||_0x123548==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x58b63c!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4809b5=this['changeMap']['get'](_0x58b63c);if(_0x4809b5){const _0x53c715=_0x4809b5['type'];if(_0x123548==='child_added'&&_0x53c715==='child_removed')this['changeMap']['set'](_0x58b63c,Pt(_0x58b63c,_0x2648f7['snapshotNode'],_0x4809b5['snapshotNode']));else{if(_0x123548==='child_removed'&&_0x53c715==='child_added')this['changeMap']['delete'](_0x58b63c);else{if(_0x123548==='child_removed'&&_0x53c715==='child_changed')this['changeMap']['set'](_0x58b63c,Nt(_0x58b63c,_0x4809b5['oldSnap']));else{if(_0x123548==='child_changed'&&_0x53c715==='child_added')this['changeMap']['set'](_0x58b63c,tt(_0x58b63c,_0x2648f7['snapshotNode']));else{if(_0x123548==='child_changed'&&_0x53c715==='child_changed')this['changeMap']['set'](_0x58b63c,Pt(_0x58b63c,_0x2648f7['snapshotNode'],_0x4809b5['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x2648f7+'\x20occurred\x20after\x20'+_0x4809b5);}}}}}else this['changeMap']['set'](_0x58b63c,_0x2648f7);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x68a21c){return null;}['getChildAfterChild'](_0x3f4e8e,_0x33ce6b,_0x2512c5){return null;}}const Vo=new Iu();class ns{constructor(_0x1aea48,_0x43145e,_0x1019e4=null){this['writes_']=_0x1aea48,this['viewCache_']=_0x43145e,this['optCompleteServerCache_']=_0x1019e4;}['getCompleteChild'](_0x357938){const _0x235bf7=this['viewCache_']['eventCache'];if(_0x235bf7['isCompleteForChild'](_0x357938))return _0x235bf7['getNode']()['getImmediateChild'](_0x357938);{const _0x531c89=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x357938,_0x531c89);}}['getChildAfterChild'](_0x3b5111,_0x4a2833,_0x314e65){const _0x22fc2e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x46931a=vu(this['writes_'],_0x22fc2e,_0x4a2833,0x1,_0x314e65,_0x3b5111);return _0x46931a['length']===0x0?null:_0x46931a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1a609e){return{'filter':_0x1a609e};}function Cu(_0x5cc0d8,_0x12c286){f(_0x12c286['eventCache']['getNode']()['isIndexed'](_0x5cc0d8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x12c286['serverCache']['getNode']()['isIndexed'](_0x5cc0d8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x135bba,_0xb1b86d,_0x5e6704,_0x3b3bca,_0x21eb24){const _0x27e051=new Eu();let _0x5bc3da,_0x4ecc67;if(_0x5e6704['type']===q['OVERWRITE']){const _0x10f8eb=_0x5e6704;_0x10f8eb['source']['fromUser']?_0x5bc3da=Ti(_0x135bba,_0xb1b86d,_0x10f8eb['path'],_0x10f8eb['snap'],_0x3b3bca,_0x21eb24,_0x27e051):(f(_0x10f8eb['source']['fromServer'],'Unknown\x20source.'),_0x4ecc67=_0x10f8eb['source']['tagged']||_0xb1b86d['serverCache']['isFiltered']()&&!v(_0x10f8eb['path']),_0x5bc3da=vn(_0x135bba,_0xb1b86d,_0x10f8eb['path'],_0x10f8eb['snap'],_0x3b3bca,_0x21eb24,_0x4ecc67,_0x27e051));}else{if(_0x5e6704['type']===q['MERGE']){const _0x1f17a1=_0x5e6704;_0x1f17a1['source']['fromUser']?_0x5bc3da=bu(_0x135bba,_0xb1b86d,_0x1f17a1['path'],_0x1f17a1['children'],_0x3b3bca,_0x21eb24,_0x27e051):(f(_0x1f17a1['source']['fromServer'],'Unknown\x20source.'),_0x4ecc67=_0x1f17a1['source']['tagged']||_0xb1b86d['serverCache']['isFiltered'](),_0x5bc3da=Si(_0x135bba,_0xb1b86d,_0x1f17a1['path'],_0x1f17a1['children'],_0x3b3bca,_0x21eb24,_0x4ecc67,_0x27e051));}else{if(_0x5e6704['type']===q['ACK_USER_WRITE']){const _0x71a3ab=_0x5e6704;_0x71a3ab['revert']?_0x5bc3da=ku(_0x135bba,_0xb1b86d,_0x71a3ab['path'],_0x3b3bca,_0x21eb24,_0x27e051):_0x5bc3da=Ru(_0x135bba,_0xb1b86d,_0x71a3ab['path'],_0x71a3ab['affectedTree'],_0x3b3bca,_0x21eb24,_0x27e051);}else{if(_0x5e6704['type']===q['LISTEN_COMPLETE'])_0x5bc3da=Au(_0x135bba,_0xb1b86d,_0x5e6704['path'],_0x3b3bca,_0x27e051);else throw ot('Unknown\x20operation\x20type:\x20'+_0x5e6704['type']);}}}const _0x2045c7=_0x27e051['getChanges']();return Su(_0xb1b86d,_0x5bc3da,_0x2045c7),{'viewCache':_0x5bc3da,'changes':_0x2045c7};}function Su(_0x155232,_0x483c40,_0x2c6d99){const _0x4ea647=_0x483c40['eventCache'];if(_0x4ea647['isFullyInitialized']()){const _0x6357e3=_0x4ea647['getNode']()['isLeafNode']()||_0x4ea647['getNode']()['isEmpty'](),_0x3a7c02=gn(_0x155232);(_0x2c6d99['length']>0x0||!_0x155232['eventCache']['isFullyInitialized']()||_0x6357e3&&!_0x4ea647['getNode']()['equals'](_0x3a7c02)||!_0x4ea647['getNode']()['getPriority']()['equals'](_0x3a7c02['getPriority']()))&&_0x2c6d99['push'](Oo(gn(_0x483c40)));}}function Ho(_0x46853f,_0x660916,_0x4f9409,_0x16d216,_0x37e18d,_0x35d024){const _0x12ba21=_0x660916['eventCache'];if(yn(_0x16d216,_0x4f9409)!=null)return _0x660916;{let _0x34998d,_0x1fe808;if(v(_0x4f9409)){if(f(_0x660916['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x660916['serverCache']['isFiltered']()){const _0x56ea2c=Ue(_0x660916),_0x1a57a4=_0x56ea2c instanceof g?_0x56ea2c:g['EMPTY_NODE'],_0xff6cac=es(_0x16d216,_0x1a57a4);_0x34998d=_0x46853f['filter']['updateFullNode'](_0x660916['eventCache']['getNode'](),_0xff6cac,_0x35d024);}else{const _0x34b028=mn(_0x16d216,Ue(_0x660916));_0x34998d=_0x46853f['filter']['updateFullNode'](_0x660916['eventCache']['getNode'](),_0x34b028,_0x35d024);}}else{const _0x2e2bba=y(_0x4f9409);if(_0x2e2bba==='.priority'){f(we(_0x4f9409)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x425b31=_0x12ba21['getNode']();_0x1fe808=_0x660916['serverCache']['getNode']();const _0x3a0d98=or(_0x16d216,_0x4f9409,_0x425b31,_0x1fe808);_0x3a0d98!=null?_0x34998d=_0x46853f['filter']['updatePriority'](_0x425b31,_0x3a0d98):_0x34998d=_0x12ba21['getNode']();}else{const _0x4ebd90=b(_0x4f9409);let _0x5d474a;if(_0x12ba21['isCompleteForChild'](_0x2e2bba)){_0x1fe808=_0x660916['serverCache']['getNode']();const _0x137986=or(_0x16d216,_0x4f9409,_0x12ba21['getNode'](),_0x1fe808);_0x137986!=null?_0x5d474a=_0x12ba21['getNode']()['getImmediateChild'](_0x2e2bba)['updateChild'](_0x4ebd90,_0x137986):_0x5d474a=_0x12ba21['getNode']()['getImmediateChild'](_0x2e2bba);}else _0x5d474a=ts(_0x16d216,_0x2e2bba,_0x660916['serverCache']);_0x5d474a!=null?_0x34998d=_0x46853f['filter']['updateChild'](_0x12ba21['getNode'](),_0x2e2bba,_0x5d474a,_0x4ebd90,_0x37e18d,_0x35d024):_0x34998d=_0x12ba21['getNode']();}}return wt(_0x660916,_0x34998d,_0x12ba21['isFullyInitialized']()||v(_0x4f9409),_0x46853f['filter']['filtersNodes']());}}function vn(_0x3a8675,_0xebe00f,_0x5323c3,_0x3fac1d,_0x3efda0,_0x238e22,_0x4fac89,_0x373cbc){const _0x265942=_0xebe00f['serverCache'];let _0x27a215;const _0x5d2f92=_0x4fac89?_0x3a8675['filter']:_0x3a8675['filter']['getIndexedFilter']();if(v(_0x5323c3))_0x27a215=_0x5d2f92['updateFullNode'](_0x265942['getNode'](),_0x3fac1d,null);else{if(_0x5d2f92['filtersNodes']()&&!_0x265942['isFiltered']()){const _0x5b66c8=_0x265942['getNode']()['updateChild'](_0x5323c3,_0x3fac1d);_0x27a215=_0x5d2f92['updateFullNode'](_0x265942['getNode'](),_0x5b66c8,null);}else{const _0x5d664e=y(_0x5323c3);if(!_0x265942['isCompleteForPath'](_0x5323c3)&&we(_0x5323c3)>0x1)return _0xebe00f;const _0x387808=b(_0x5323c3),_0x535aa3=_0x265942['getNode']()['getImmediateChild'](_0x5d664e)['updateChild'](_0x387808,_0x3fac1d);_0x5d664e==='.priority'?_0x27a215=_0x5d2f92['updatePriority'](_0x265942['getNode'](),_0x535aa3):_0x27a215=_0x5d2f92['updateChild'](_0x265942['getNode'](),_0x5d664e,_0x535aa3,_0x387808,Vo,null);}}const _0x3b550e=Lo(_0xebe00f,_0x27a215,_0x265942['isFullyInitialized']()||v(_0x5323c3),_0x5d2f92['filtersNodes']()),_0x319de8=new ns(_0x3efda0,_0x3b550e,_0x238e22);return Ho(_0x3a8675,_0x3b550e,_0x5323c3,_0x3efda0,_0x319de8,_0x373cbc);}function Ti(_0x4d579d,_0x4a903a,_0x4dc20c,_0x5a8959,_0x20b85e,_0x3f1409,_0x490f10){const _0x4f438b=_0x4a903a['eventCache'];let _0x55ce2b,_0x2896ed;const _0x45a783=new ns(_0x20b85e,_0x4a903a,_0x3f1409);if(v(_0x4dc20c))_0x2896ed=_0x4d579d['filter']['updateFullNode'](_0x4a903a['eventCache']['getNode'](),_0x5a8959,_0x490f10),_0x55ce2b=wt(_0x4a903a,_0x2896ed,!0x0,_0x4d579d['filter']['filtersNodes']());else{const _0x336e1a=y(_0x4dc20c);if(_0x336e1a==='.priority')_0x2896ed=_0x4d579d['filter']['updatePriority'](_0x4a903a['eventCache']['getNode'](),_0x5a8959),_0x55ce2b=wt(_0x4a903a,_0x2896ed,_0x4f438b['isFullyInitialized'](),_0x4f438b['isFiltered']());else{const _0x10892e=b(_0x4dc20c),_0x42c729=_0x4f438b['getNode']()['getImmediateChild'](_0x336e1a);let _0x5853e7;if(v(_0x10892e))_0x5853e7=_0x5a8959;else{const _0x3d4d70=_0x45a783['getCompleteChild'](_0x336e1a);_0x3d4d70!=null?Gi(_0x10892e)==='.priority'&&_0x3d4d70['getChild'](To(_0x10892e))['isEmpty']()?_0x5853e7=_0x3d4d70:_0x5853e7=_0x3d4d70['updateChild'](_0x10892e,_0x5a8959):_0x5853e7=g['EMPTY_NODE'];}if(_0x42c729['equals'](_0x5853e7))_0x55ce2b=_0x4a903a;else{const _0x243fd2=_0x4d579d['filter']['updateChild'](_0x4f438b['getNode'](),_0x336e1a,_0x5853e7,_0x10892e,_0x45a783,_0x490f10);_0x55ce2b=wt(_0x4a903a,_0x243fd2,_0x4f438b['isFullyInitialized'](),_0x4d579d['filter']['filtersNodes']());}}}return _0x55ce2b;}function ar(_0x3e0bfc,_0x41602a){return _0x3e0bfc['eventCache']['isCompleteForChild'](_0x41602a);}function bu(_0x452834,_0x390ace,_0x3fa91e,_0x3aa968,_0x457453,_0x406ef8,_0x28a5ed){let _0x537d7d=_0x390ace;return _0x3aa968['foreach']((_0x5ccff3,_0x5d0288)=>{const _0x2b36af=A(_0x3fa91e,_0x5ccff3);ar(_0x390ace,y(_0x2b36af))&&(_0x537d7d=Ti(_0x452834,_0x537d7d,_0x2b36af,_0x5d0288,_0x457453,_0x406ef8,_0x28a5ed));}),_0x3aa968['foreach']((_0x9fd14,_0x519372)=>{const _0x2d0972=A(_0x3fa91e,_0x9fd14);ar(_0x390ace,y(_0x2d0972))||(_0x537d7d=Ti(_0x452834,_0x537d7d,_0x2d0972,_0x519372,_0x457453,_0x406ef8,_0x28a5ed));}),_0x537d7d;}function cr(_0x5480af,_0x250614,_0x34974e){return _0x34974e['foreach']((_0x284189,_0x444ce2)=>{_0x250614=_0x250614['updateChild'](_0x284189,_0x444ce2);}),_0x250614;}function Si(_0x5c529f,_0x206ce8,_0x58de7d,_0x52a994,_0x29fb2f,_0x2e28b0,_0x21f582,_0x3a32a9){if(_0x206ce8['serverCache']['getNode']()['isEmpty']()&&!_0x206ce8['serverCache']['isFullyInitialized']())return _0x206ce8;let _0x5e4d5b=_0x206ce8,_0x4db7f8;v(_0x58de7d)?_0x4db7f8=_0x52a994:_0x4db7f8=new S(null)['setTree'](_0x58de7d,_0x52a994);const _0x2e4e64=_0x206ce8['serverCache']['getNode']();return _0x4db7f8['children']['inorderTraversal']((_0x2a425b,_0x14fde3)=>{if(_0x2e4e64['hasChild'](_0x2a425b)){const _0x620c6b=_0x206ce8['serverCache']['getNode']()['getImmediateChild'](_0x2a425b),_0x151db5=cr(_0x5c529f,_0x620c6b,_0x14fde3);_0x5e4d5b=vn(_0x5c529f,_0x5e4d5b,new C(_0x2a425b),_0x151db5,_0x29fb2f,_0x2e28b0,_0x21f582,_0x3a32a9);}}),_0x4db7f8['children']['inorderTraversal']((_0x3b4eb3,_0x58b177)=>{const _0x3b0150=!_0x206ce8['serverCache']['isCompleteForChild'](_0x3b4eb3)&&_0x58b177['value']===null;if(!_0x2e4e64['hasChild'](_0x3b4eb3)&&!_0x3b0150){const _0x164029=_0x206ce8['serverCache']['getNode']()['getImmediateChild'](_0x3b4eb3),_0x2415eb=cr(_0x5c529f,_0x164029,_0x58b177);_0x5e4d5b=vn(_0x5c529f,_0x5e4d5b,new C(_0x3b4eb3),_0x2415eb,_0x29fb2f,_0x2e28b0,_0x21f582,_0x3a32a9);}}),_0x5e4d5b;}function Ru(_0xea3a4f,_0x578764,_0x53d11e,_0x142afb,_0x5634eb,_0x4354c7,_0x5dd38e){if(yn(_0x5634eb,_0x53d11e)!=null)return _0x578764;const _0x1d42b3=_0x578764['serverCache']['isFiltered'](),_0x1ee487=_0x578764['serverCache'];if(_0x142afb['value']!=null){if(v(_0x53d11e)&&_0x1ee487['isFullyInitialized']()||_0x1ee487['isCompleteForPath'](_0x53d11e))return vn(_0xea3a4f,_0x578764,_0x53d11e,_0x1ee487['getNode']()['getChild'](_0x53d11e),_0x5634eb,_0x4354c7,_0x1d42b3,_0x5dd38e);if(v(_0x53d11e)){let _0x527ad0=new S(null);return _0x1ee487['getNode']()['forEachChild'](ye,(_0x253300,_0x47b882)=>{_0x527ad0=_0x527ad0['set'](new C(_0x253300),_0x47b882);}),Si(_0xea3a4f,_0x578764,_0x53d11e,_0x527ad0,_0x5634eb,_0x4354c7,_0x1d42b3,_0x5dd38e);}else return _0x578764;}else{let _0xd7daaa=new S(null);return _0x142afb['foreach']((_0x4f5294,_0x297541)=>{const _0x3264aa=A(_0x53d11e,_0x4f5294);_0x1ee487['isCompleteForPath'](_0x3264aa)&&(_0xd7daaa=_0xd7daaa['set'](_0x4f5294,_0x1ee487['getNode']()['getChild'](_0x3264aa)));}),Si(_0xea3a4f,_0x578764,_0x53d11e,_0xd7daaa,_0x5634eb,_0x4354c7,_0x1d42b3,_0x5dd38e);}}function Au(_0x226f0a,_0xc44f3e,_0x568ad0,_0xbd6944,_0x20347c){const _0x6488c1=_0xc44f3e['serverCache'],_0x50d30a=Lo(_0xc44f3e,_0x6488c1['getNode'](),_0x6488c1['isFullyInitialized']()||v(_0x568ad0),_0x6488c1['isFiltered']());return Ho(_0x226f0a,_0x50d30a,_0x568ad0,_0xbd6944,Vo,_0x20347c);}function ku(_0x1e4a16,_0x136882,_0x45c18a,_0x247a44,_0x5d24c5,_0x2781d2){let _0xfb3606;if(yn(_0x247a44,_0x45c18a)!=null)return _0x136882;{const _0xa78bad=new ns(_0x247a44,_0x136882,_0x5d24c5),_0x516377=_0x136882['eventCache']['getNode']();let _0x366220;if(v(_0x45c18a)||y(_0x45c18a)==='.priority'){let _0x5bc35b;if(_0x136882['serverCache']['isFullyInitialized']())_0x5bc35b=mn(_0x247a44,Ue(_0x136882));else{const _0xc8a1e9=_0x136882['serverCache']['getNode']();f(_0xc8a1e9 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5bc35b=es(_0x247a44,_0xc8a1e9);}_0x5bc35b=_0x5bc35b,_0x366220=_0x1e4a16['filter']['updateFullNode'](_0x516377,_0x5bc35b,_0x2781d2);}else{const _0x524367=y(_0x45c18a);let _0x310676=ts(_0x247a44,_0x524367,_0x136882['serverCache']);_0x310676==null&&_0x136882['serverCache']['isCompleteForChild'](_0x524367)&&(_0x310676=_0x516377['getImmediateChild'](_0x524367)),_0x310676!=null?_0x366220=_0x1e4a16['filter']['updateChild'](_0x516377,_0x524367,_0x310676,b(_0x45c18a),_0xa78bad,_0x2781d2):_0x136882['eventCache']['getNode']()['hasChild'](_0x524367)?_0x366220=_0x1e4a16['filter']['updateChild'](_0x516377,_0x524367,g['EMPTY_NODE'],b(_0x45c18a),_0xa78bad,_0x2781d2):_0x366220=_0x516377,_0x366220['isEmpty']()&&_0x136882['serverCache']['isFullyInitialized']()&&(_0xfb3606=mn(_0x247a44,Ue(_0x136882)),_0xfb3606['isLeafNode']()&&(_0x366220=_0x1e4a16['filter']['updateFullNode'](_0x366220,_0xfb3606,_0x2781d2)));}return _0xfb3606=_0x136882['serverCache']['isFullyInitialized']()||yn(_0x247a44,w())!=null,wt(_0x136882,_0x366220,_0xfb3606,_0x1e4a16['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x4ed832,_0xd4644f){this['query_']=_0x4ed832,this['eventRegistrations_']=[];const _0xbc1ae5=this['query_']['_queryParams'],_0x122791=new Yi(_0xbc1ae5['getIndex']()),_0x1c4cf2=qh(_0xbc1ae5);this['processor_']=wu(_0x1c4cf2);const _0x443231=_0xd4644f['serverCache'],_0x22bb78=_0xd4644f['eventCache'],_0x569492=_0x122791['updateFullNode'](g['EMPTY_NODE'],_0x443231['getNode'](),null),_0x4252b3=_0x1c4cf2['updateFullNode'](g['EMPTY_NODE'],_0x22bb78['getNode'](),null),_0x4ff413=new Ce(_0x569492,_0x443231['isFullyInitialized'](),_0x122791['filtersNodes']()),_0x53ff4a=new Ce(_0x4252b3,_0x22bb78['isFullyInitialized'](),_0x1c4cf2['filtersNodes']());this['viewCache_']=Dn(_0x53ff4a,_0x4ff413),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4c6529){return _0x4c6529['viewCache_']['serverCache']['getNode']();}function Ou(_0x4676c0){return gn(_0x4676c0['viewCache_']);}function Du(_0x7e09f,_0x4bca07){const _0x4981e6=Ue(_0x7e09f['viewCache_']);return _0x4981e6&&(_0x7e09f['query']['_queryParams']['loadsAllData']()||!v(_0x4bca07)&&!_0x4981e6['getImmediateChild'](y(_0x4bca07))['isEmpty']())?_0x4981e6['getChild'](_0x4bca07):null;}function lr(_0xb6ea41){return _0xb6ea41['eventRegistrations_']['length']===0x0;}function Mu(_0x4eb711,_0x30464d){_0x4eb711['eventRegistrations_']['push'](_0x30464d);}function hr(_0x3f34ad,_0x2b9127,_0x2422fe){const _0x5baa96=[];if(_0x2422fe){f(_0x2b9127==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x19f72c=_0x3f34ad['query']['_path'];_0x3f34ad['eventRegistrations_']['forEach'](_0x366d4b=>{const _0x5becdb=_0x366d4b['createCancelEvent'](_0x2422fe,_0x19f72c);_0x5becdb&&_0x5baa96['push'](_0x5becdb);});}if(_0x2b9127){let _0x39e925=[];for(let _0x43d3c5=0x0;_0x43d3c5<_0x3f34ad['eventRegistrations_']['length'];++_0x43d3c5){const _0x2dadf2=_0x3f34ad['eventRegistrations_'][_0x43d3c5];if(!_0x2dadf2['matches'](_0x2b9127))_0x39e925['push'](_0x2dadf2);else{if(_0x2b9127['hasAnyCallback']()){_0x39e925=_0x39e925['concat'](_0x3f34ad['eventRegistrations_']['slice'](_0x43d3c5+0x1));break;}}}_0x3f34ad['eventRegistrations_']=_0x39e925;}else _0x3f34ad['eventRegistrations_']=[];return _0x5baa96;}function ur(_0x1e48af,_0x1821fd,_0xda524e,_0x15f7a5){_0x1821fd['type']===q['MERGE']&&_0x1821fd['source']['queryId']!==null&&(f(Ue(_0x1e48af['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x1e48af['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x592f2d=_0x1e48af['viewCache_'],_0x4ed900=Tu(_0x1e48af['processor_'],_0x592f2d,_0x1821fd,_0xda524e,_0x15f7a5);return Cu(_0x1e48af['processor_'],_0x4ed900['viewCache']),f(_0x4ed900['viewCache']['serverCache']['isFullyInitialized']()||!_0x592f2d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1e48af['viewCache_']=_0x4ed900['viewCache'],$o(_0x1e48af,_0x4ed900['changes'],_0x4ed900['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x23ab16,_0x34d732){const _0x2c2b23=_0x23ab16['viewCache_']['eventCache'],_0x4ce1c4=[];return _0x2c2b23['getNode']()['isLeafNode']()||_0x2c2b23['getNode']()['forEachChild'](R,(_0x56082c,_0x41a243)=>{_0x4ce1c4['push'](tt(_0x56082c,_0x41a243));}),_0x2c2b23['isFullyInitialized']()&&_0x4ce1c4['push'](Oo(_0x2c2b23['getNode']())),$o(_0x23ab16,_0x4ce1c4,_0x2c2b23['getNode'](),_0x34d732);}function $o(_0x257170,_0x24eb3b,_0x109ec5,_0x28b29d){const _0x1b6501=_0x28b29d?[_0x28b29d]:_0x257170['eventRegistrations_'];return nu(_0x257170['eventGenerator_'],_0x24eb3b,_0x109ec5,_0x1b6501);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xa664d2){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xa664d2;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x4556f2){return _0x4556f2['views']['size']===0x0;}function is(_0x1e15ee,_0x2a8399,_0x496d48,_0x1ca6f){const _0x53a783=_0x2a8399['source']['queryId'];if(_0x53a783!==null){const _0xcfcb24=_0x1e15ee['views']['get'](_0x53a783);return f(_0xcfcb24!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xcfcb24,_0x2a8399,_0x496d48,_0x1ca6f);}else{let _0x20c470=[];for(const _0x3e378f of _0x1e15ee['views']['values']())_0x20c470=_0x20c470['concat'](ur(_0x3e378f,_0x2a8399,_0x496d48,_0x1ca6f));return _0x20c470;}}function qo(_0xdab0cb,_0x5abbcb,_0x1aa891,_0x12c67f,_0x5dec63){const _0x7994ef=_0x5abbcb['_queryIdentifier'],_0x4cd272=_0xdab0cb['views']['get'](_0x7994ef);if(!_0x4cd272){let _0x3f0566=mn(_0x1aa891,_0x5dec63?_0x12c67f:null),_0x3fa08d=!0x1;_0x3f0566?_0x3fa08d=!0x0:_0x12c67f instanceof g?(_0x3f0566=es(_0x1aa891,_0x12c67f),_0x3fa08d=!0x1):(_0x3f0566=g['EMPTY_NODE'],_0x3fa08d=!0x1);const _0x15b706=Dn(new Ce(_0x3f0566,_0x3fa08d,!0x1),new Ce(_0x12c67f,_0x5dec63,!0x1));return new Nu(_0x5abbcb,_0x15b706);}return _0x4cd272;}function Wu(_0x5bd2c4,_0x1f6258,_0x308633,_0x189d71,_0xb8d9fd,_0x107315){const _0x5cc376=qo(_0x5bd2c4,_0x1f6258,_0x189d71,_0xb8d9fd,_0x107315);return _0x5bd2c4['views']['has'](_0x1f6258['_queryIdentifier'])||_0x5bd2c4['views']['set'](_0x1f6258['_queryIdentifier'],_0x5cc376),Mu(_0x5cc376,_0x308633),Lu(_0x5cc376,_0x308633);}function Bu(_0x2be1f1,_0x207157,_0x2bb6f6,_0x178c3e){const _0x4265a2=_0x207157['_queryIdentifier'],_0x419d57=[];let _0x169808=[];const _0x30bc0b=Te(_0x2be1f1);if(_0x4265a2==='default'){for(const [_0x19d5c7,_0x141dd2]of _0x2be1f1['views']['entries']())_0x169808=_0x169808['concat'](hr(_0x141dd2,_0x2bb6f6,_0x178c3e)),lr(_0x141dd2)&&(_0x2be1f1['views']['delete'](_0x19d5c7),_0x141dd2['query']['_queryParams']['loadsAllData']()||_0x419d57['push'](_0x141dd2['query']));}else{const _0x409bca=_0x2be1f1['views']['get'](_0x4265a2);_0x409bca&&(_0x169808=_0x169808['concat'](hr(_0x409bca,_0x2bb6f6,_0x178c3e)),lr(_0x409bca)&&(_0x2be1f1['views']['delete'](_0x4265a2),_0x409bca['query']['_queryParams']['loadsAllData']()||_0x419d57['push'](_0x409bca['query'])));}return _0x30bc0b&&!Te(_0x2be1f1)&&_0x419d57['push'](new(Fu())(_0x207157['_repo'],_0x207157['_path'])),{'removed':_0x419d57,'events':_0x169808};}function zo(_0x20b91d){const _0x594960=[];for(const _0x3ca9f0 of _0x20b91d['views']['values']())_0x3ca9f0['query']['_queryParams']['loadsAllData']()||_0x594960['push'](_0x3ca9f0);return _0x594960;}function Ee(_0x49f1ad,_0x70e6f){let _0x83c097=null;for(const _0x62f82d of _0x49f1ad['views']['values']())_0x83c097=_0x83c097||Du(_0x62f82d,_0x70e6f);return _0x83c097;}function jo(_0x526de2,_0x524f25){if(_0x524f25['_queryParams']['loadsAllData']())return Ln(_0x526de2);{const _0x14f2b7=_0x524f25['_queryIdentifier'];return _0x526de2['views']['get'](_0x14f2b7);}}function Ko(_0xce7712,_0x253f08){return jo(_0xce7712,_0x253f08)!=null;}function Te(_0x44f46b){return Ln(_0x44f46b)!=null;}function Ln(_0x92f490){for(const _0x5dad81 of _0x92f490['views']['values']())if(_0x5dad81['query']['_queryParams']['loadsAllData']())return _0x5dad81;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x497fc3){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x497fc3;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x4a8adc){this['listenProvider_']=_0x4a8adc,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x47838d,_0x567931,_0x313c7b,_0x300cdf,_0xa7d64d){return ou(_0x47838d['pendingWriteTree_'],_0x567931,_0x313c7b,_0x300cdf,_0xa7d64d),_0xa7d64d?ht(_0x47838d,new Fe(Ji(),_0x567931,_0x313c7b)):[];}function Gu(_0x1aa7d4,_0x491360,_0x2ad93c,_0x451916){au(_0x1aa7d4['pendingWriteTree_'],_0x491360,_0x2ad93c,_0x451916);const _0x2796e4=S['fromObject'](_0x2ad93c);return ht(_0x1aa7d4,new nt(Ji(),_0x491360,_0x2796e4));}function pe(_0x4a5b3f,_0x2d378b,_0x31bf64=!0x1){const _0x3b969c=cu(_0x4a5b3f['pendingWriteTree_'],_0x2d378b);if(lu(_0x4a5b3f['pendingWriteTree_'],_0x2d378b)){let _0x3b3007=new S(null);return _0x3b969c['snap']!=null?_0x3b3007=_0x3b3007['set'](w(),!0x0):x(_0x3b969c['children'],_0x419334=>{_0x3b3007=_0x3b3007['set'](new C(_0x419334),!0x0);}),ht(_0x4a5b3f,new _n(_0x3b969c['path'],_0x3b3007,_0x31bf64));}else return[];}function $t(_0x11f3c8,_0x4386e0,_0x4099c5){return ht(_0x11f3c8,new Fe(Xi(),_0x4386e0,_0x4099c5));}function qu(_0x54b6d6,_0x96e155,_0x223842){const _0xdbfeaa=S['fromObject'](_0x223842);return ht(_0x54b6d6,new nt(Xi(),_0x96e155,_0xdbfeaa));}function zu(_0x960f3d,_0x3e2f79){return ht(_0x960f3d,new Dt(Xi(),_0x3e2f79));}function ju(_0x4be87b,_0x4ff031,_0x23d076){const _0x36c89b=rs(_0x4be87b,_0x23d076);if(_0x36c89b){const _0x868e72=os(_0x36c89b),_0x21b1ad=_0x868e72['path'],_0x4aac46=_0x868e72['queryId'],_0x41a27a=F(_0x21b1ad,_0x4ff031),_0xad9265=new Dt(Zi(_0x4aac46),_0x41a27a);return as(_0x4be87b,_0x21b1ad,_0xad9265);}else return[];}function wn(_0x399b06,_0x5600bf,_0x1789ed,_0x56fb48,_0x1c742f=!0x1){const _0x30b359=_0x5600bf['_path'],_0x1ebb82=_0x399b06['syncPointTree_']['get'](_0x30b359);let _0x313504=[];if(_0x1ebb82&&(_0x5600bf['_queryIdentifier']==='default'||Ko(_0x1ebb82,_0x5600bf))){const _0x3d2130=Bu(_0x1ebb82,_0x5600bf,_0x1789ed,_0x56fb48);Uu(_0x1ebb82)&&(_0x399b06['syncPointTree_']=_0x399b06['syncPointTree_']['remove'](_0x30b359));const _0x56e62d=_0x3d2130['removed'];if(_0x313504=_0x3d2130['events'],!_0x1c742f){const _0xdace25=_0x56e62d['findIndex'](_0x29c2bb=>_0x29c2bb['_queryParams']['loadsAllData']())!==-0x1,_0x272a98=_0x399b06['syncPointTree_']['findOnPath'](_0x30b359,(_0x2a705,_0x31d68b)=>Te(_0x31d68b));if(_0xdace25&&!_0x272a98){const _0x10ba16=_0x399b06['syncPointTree_']['subtree'](_0x30b359);if(!_0x10ba16['isEmpty']()){const _0x11a51f=Qu(_0x10ba16);for(let _0x3ed246=0x0;_0x3ed246<_0x11a51f['length'];++_0x3ed246){const _0x2487ad=_0x11a51f[_0x3ed246],_0x533754=_0x2487ad['query'],_0xc09c6a=Xo(_0x399b06,_0x2487ad);_0x399b06['listenProvider_']['startListening'](Tt(_0x533754),Mt(_0x399b06,_0x533754),_0xc09c6a['hashFn'],_0xc09c6a['onComplete']);}}}!_0x272a98&&_0x56e62d['length']>0x0&&!_0x56fb48&&(_0xdace25?_0x399b06['listenProvider_']['stopListening'](Tt(_0x5600bf),null):_0x56e62d['forEach'](_0x39e737=>{const _0x4666fb=_0x399b06['queryToTagMap']['get'](Fn(_0x39e737));_0x399b06['listenProvider_']['stopListening'](Tt(_0x39e737),_0x4666fb);}));}Ju(_0x399b06,_0x56e62d);}return _0x313504;}function Yo(_0xbcb581,_0x376d84,_0x1aec69,_0xbbd2aa){const _0x4aacb4=rs(_0xbcb581,_0xbbd2aa);if(_0x4aacb4!=null){const _0x5f0ff4=os(_0x4aacb4),_0x592aa6=_0x5f0ff4['path'],_0x26e667=_0x5f0ff4['queryId'],_0x4af866=F(_0x592aa6,_0x376d84),_0x4b4e9e=new Fe(Zi(_0x26e667),_0x4af866,_0x1aec69);return as(_0xbcb581,_0x592aa6,_0x4b4e9e);}else return[];}function Ku(_0x15b05b,_0x1b26a9,_0xfff906,_0x7ddc9b){const _0x8ab553=rs(_0x15b05b,_0x7ddc9b);if(_0x8ab553){const _0x3dc491=os(_0x8ab553),_0x29c4b8=_0x3dc491['path'],_0x1f78c4=_0x3dc491['queryId'],_0x304681=F(_0x29c4b8,_0x1b26a9),_0x3220ee=S['fromObject'](_0xfff906),_0x1d2b12=new nt(Zi(_0x1f78c4),_0x304681,_0x3220ee);return as(_0x15b05b,_0x29c4b8,_0x1d2b12);}else return[];}function bi(_0x237aaa,_0x3aaee3,_0x3bd3f4,_0x4936e6=!0x1){const _0x2ce308=_0x3aaee3['_path'];let _0x3a7f59=null,_0xc3c214=!0x1;_0x237aaa['syncPointTree_']['foreachOnPath'](_0x2ce308,(_0x5f26bd,_0x41e338)=>{const _0x5ce944=F(_0x5f26bd,_0x2ce308);_0x3a7f59=_0x3a7f59||Ee(_0x41e338,_0x5ce944),_0xc3c214=_0xc3c214||Te(_0x41e338);});let _0x3be419=_0x237aaa['syncPointTree_']['get'](_0x2ce308);_0x3be419?(_0xc3c214=_0xc3c214||Te(_0x3be419),_0x3a7f59=_0x3a7f59||Ee(_0x3be419,w())):(_0x3be419=new Go(),_0x237aaa['syncPointTree_']=_0x237aaa['syncPointTree_']['set'](_0x2ce308,_0x3be419));let _0x546e82;_0x3a7f59!=null?_0x546e82=!0x0:(_0x546e82=!0x1,_0x3a7f59=g['EMPTY_NODE'],_0x237aaa['syncPointTree_']['subtree'](_0x2ce308)['foreachChild']((_0xb3afb1,_0x3fe663)=>{const _0x3ec426=Ee(_0x3fe663,w());_0x3ec426&&(_0x3a7f59=_0x3a7f59['updateImmediateChild'](_0xb3afb1,_0x3ec426));}));const _0x34f49a=Ko(_0x3be419,_0x3aaee3);if(!_0x34f49a&&!_0x3aaee3['_queryParams']['loadsAllData']()){const _0x352cb5=Fn(_0x3aaee3);f(!_0x237aaa['queryToTagMap']['has'](_0x352cb5),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3ed8d6=Xu();_0x237aaa['queryToTagMap']['set'](_0x352cb5,_0x3ed8d6),_0x237aaa['tagToQueryMap']['set'](_0x3ed8d6,_0x352cb5);}const _0x3ac816=Mn(_0x237aaa['pendingWriteTree_'],_0x2ce308);let _0x23ffb4=Wu(_0x3be419,_0x3aaee3,_0x3bd3f4,_0x3ac816,_0x3a7f59,_0x546e82);if(!_0x34f49a&&!_0xc3c214&&!_0x4936e6){const _0x3ffb87=jo(_0x3be419,_0x3aaee3);_0x23ffb4=_0x23ffb4['concat'](Zu(_0x237aaa,_0x3aaee3,_0x3ffb87));}return _0x23ffb4;}function xn(_0x20a793,_0x2684f7,_0x304274){const _0x4a75fb=_0x20a793['pendingWriteTree_'],_0x492dc4=_0x20a793['syncPointTree_']['findOnPath'](_0x2684f7,(_0xcd7560,_0x500ec3)=>{const _0x54c122=F(_0xcd7560,_0x2684f7),_0x3d6582=Ee(_0x500ec3,_0x54c122);if(_0x3d6582)return _0x3d6582;});return Uo(_0x4a75fb,_0x2684f7,_0x492dc4,_0x304274,!0x0);}function Yu(_0x21aaf4,_0x8eb1f8){const _0x434d16=_0x8eb1f8['_path'];let _0x38c8aa=null;_0x21aaf4['syncPointTree_']['foreachOnPath'](_0x434d16,(_0x4de666,_0x45e198)=>{const _0x3347f7=F(_0x4de666,_0x434d16);_0x38c8aa=_0x38c8aa||Ee(_0x45e198,_0x3347f7);});let _0x272de0=_0x21aaf4['syncPointTree_']['get'](_0x434d16);_0x272de0?_0x38c8aa=_0x38c8aa||Ee(_0x272de0,w()):(_0x272de0=new Go(),_0x21aaf4['syncPointTree_']=_0x21aaf4['syncPointTree_']['set'](_0x434d16,_0x272de0));const _0x502883=_0x38c8aa!=null,_0x2271a2=_0x502883?new Ce(_0x38c8aa,!0x0,!0x1):null,_0x879510=Mn(_0x21aaf4['pendingWriteTree_'],_0x8eb1f8['_path']),_0x5a572e=qo(_0x272de0,_0x8eb1f8,_0x879510,_0x502883?_0x2271a2['getNode']():g['EMPTY_NODE'],_0x502883);return Ou(_0x5a572e);}function ht(_0x3e7833,_0x42f0d7){return Qo(_0x42f0d7,_0x3e7833['syncPointTree_'],null,Mn(_0x3e7833['pendingWriteTree_'],w()));}function Qo(_0x320fc9,_0xcb8d83,_0x25bc2f,_0x57244b){if(v(_0x320fc9['path']))return Jo(_0x320fc9,_0xcb8d83,_0x25bc2f,_0x57244b);{const _0x5f3b00=_0xcb8d83['get'](w());_0x25bc2f==null&&_0x5f3b00!=null&&(_0x25bc2f=Ee(_0x5f3b00,w()));let _0x390213=[];const _0x130375=y(_0x320fc9['path']),_0x17f46e=_0x320fc9['operationForChild'](_0x130375),_0x23272d=_0xcb8d83['children']['get'](_0x130375);if(_0x23272d&&_0x17f46e){const _0x50bb76=_0x25bc2f?_0x25bc2f['getImmediateChild'](_0x130375):null,_0x3787ea=Wo(_0x57244b,_0x130375);_0x390213=_0x390213['concat'](Qo(_0x17f46e,_0x23272d,_0x50bb76,_0x3787ea));}return _0x5f3b00&&(_0x390213=_0x390213['concat'](is(_0x5f3b00,_0x320fc9,_0x57244b,_0x25bc2f))),_0x390213;}}function Jo(_0x2d9c5b,_0x4e4946,_0x34b515,_0x103b11){const _0x380d8c=_0x4e4946['get'](w());_0x34b515==null&&_0x380d8c!=null&&(_0x34b515=Ee(_0x380d8c,w()));let _0x5561aa=[];return _0x4e4946['children']['inorderTraversal']((_0x4735f7,_0x2efc92)=>{const _0x52d0ec=_0x34b515?_0x34b515['getImmediateChild'](_0x4735f7):null,_0x2f32f6=Wo(_0x103b11,_0x4735f7),_0x4b6962=_0x2d9c5b['operationForChild'](_0x4735f7);_0x4b6962&&(_0x5561aa=_0x5561aa['concat'](Jo(_0x4b6962,_0x2efc92,_0x52d0ec,_0x2f32f6)));}),_0x380d8c&&(_0x5561aa=_0x5561aa['concat'](is(_0x380d8c,_0x2d9c5b,_0x103b11,_0x34b515))),_0x5561aa;}function Xo(_0x460980,_0x65c40f){const _0x4ade7a=_0x65c40f['query'],_0x2856da=Mt(_0x460980,_0x4ade7a);return{'hashFn':()=>(Pu(_0x65c40f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2864a1=>{if(_0x2864a1==='ok')return _0x2856da?ju(_0x460980,_0x4ade7a['_path'],_0x2856da):zu(_0x460980,_0x4ade7a['_path']);{const _0x35d3f1=ql(_0x2864a1,_0x4ade7a);return wn(_0x460980,_0x4ade7a,null,_0x35d3f1);}}};}function Mt(_0x3348fc,_0x2b574f){const _0x206c75=Fn(_0x2b574f);return _0x3348fc['queryToTagMap']['get'](_0x206c75);}function Fn(_0x5286c9){return _0x5286c9['_path']['toString']()+'$'+_0x5286c9['_queryIdentifier'];}function rs(_0x203009,_0x4f0c33){return _0x203009['tagToQueryMap']['get'](_0x4f0c33);}function os(_0x59b796){const _0x3b4d2d=_0x59b796['indexOf']('$');return f(_0x3b4d2d!==-0x1&&_0x3b4d2d<_0x59b796['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x59b796['substr'](_0x3b4d2d+0x1),'path':new C(_0x59b796['substr'](0x0,_0x3b4d2d))};}function as(_0x545b88,_0x4a0f3c,_0x2c4e73){const _0x108f1d=_0x545b88['syncPointTree_']['get'](_0x4a0f3c);f(_0x108f1d,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x111fbc=Mn(_0x545b88['pendingWriteTree_'],_0x4a0f3c);return is(_0x108f1d,_0x2c4e73,_0x111fbc,null);}function Qu(_0x43f74f){return _0x43f74f['fold']((_0xe6c67e,_0x48a3e5,_0x31f40b)=>{if(_0x48a3e5&&Te(_0x48a3e5))return[Ln(_0x48a3e5)];{let _0x698e74=[];return _0x48a3e5&&(_0x698e74=zo(_0x48a3e5)),x(_0x31f40b,(_0x3aece5,_0x4a9b71)=>{_0x698e74=_0x698e74['concat'](_0x4a9b71);}),_0x698e74;}});}function Tt(_0x15d114){return _0x15d114['_queryParams']['loadsAllData']()&&!_0x15d114['_queryParams']['isDefault']()?new(Hu())(_0x15d114['_repo'],_0x15d114['_path']):_0x15d114;}function Ju(_0x3f2f89,_0x595cb4){for(let _0x43161d=0x0;_0x43161d<_0x595cb4['length'];++_0x43161d){const _0x4719ec=_0x595cb4[_0x43161d];if(!_0x4719ec['_queryParams']['loadsAllData']()){const _0x3a202e=Fn(_0x4719ec),_0x41cda4=_0x3f2f89['queryToTagMap']['get'](_0x3a202e);_0x3f2f89['queryToTagMap']['delete'](_0x3a202e),_0x3f2f89['tagToQueryMap']['delete'](_0x41cda4);}}}function Xu(){return $u++;}function Zu(_0x58a5a9,_0x21d028,_0x9ff001){const _0x5575d1=_0x21d028['_path'],_0x2b9289=Mt(_0x58a5a9,_0x21d028),_0x4b7b32=Xo(_0x58a5a9,_0x9ff001),_0x20cb35=_0x58a5a9['listenProvider_']['startListening'](Tt(_0x21d028),_0x2b9289,_0x4b7b32['hashFn'],_0x4b7b32['onComplete']),_0x13032d=_0x58a5a9['syncPointTree_']['subtree'](_0x5575d1);if(_0x2b9289)f(!Te(_0x13032d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x291fd5=_0x13032d['fold']((_0x152909,_0x50d73d,_0x3ef97c)=>{if(!v(_0x152909)&&_0x50d73d&&Te(_0x50d73d))return[Ln(_0x50d73d)['query']];{let _0x5bf816=[];return _0x50d73d&&(_0x5bf816=_0x5bf816['concat'](zo(_0x50d73d)['map'](_0x2bc4ef=>_0x2bc4ef['query']))),x(_0x3ef97c,(_0x6f1acb,_0x13f710)=>{_0x5bf816=_0x5bf816['concat'](_0x13f710);}),_0x5bf816;}});for(let _0x575f75=0x0;_0x575f75<_0x291fd5['length'];++_0x575f75){const _0x4c5515=_0x291fd5[_0x575f75];_0x58a5a9['listenProvider_']['stopListening'](Tt(_0x4c5515),Mt(_0x58a5a9,_0x4c5515));}}return _0x20cb35;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x476d8e){this['node_']=_0x476d8e;}['getImmediateChild'](_0x3875b0){const _0x1d9ccd=this['node_']['getImmediateChild'](_0x3875b0);return new cs(_0x1d9ccd);}['node'](){return this['node_'];}}class ls{constructor(_0xf1347a,_0x17e1cb){this['syncTree_']=_0xf1347a,this['path_']=_0x17e1cb;}['getImmediateChild'](_0x15ad39){const _0x440e6e=A(this['path_'],_0x15ad39);return new ls(this['syncTree_'],_0x440e6e);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x3ba9e3){return _0x3ba9e3=_0x3ba9e3||{},_0x3ba9e3['timestamp']=_0x3ba9e3['timestamp']||new Date()['getTime'](),_0x3ba9e3;},fr=function(_0x232f25,_0x5091b0,_0x1aa4c1){if(!_0x232f25||typeof _0x232f25!='object')return _0x232f25;if(f('.sv'in _0x232f25,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x232f25['.sv']=='string')return td(_0x232f25['.sv'],_0x5091b0,_0x1aa4c1);if(typeof _0x232f25['.sv']=='object')return nd(_0x232f25['.sv'],_0x5091b0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x232f25,null,0x2));},td=function(_0xb86b71,_0x1f7a53,_0x39352e){switch(_0xb86b71){case'timestamp':return _0x39352e['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xb86b71);}},nd=function(_0x150bcc,_0x1587f7,_0x30f29e){_0x150bcc['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x150bcc,null,0x2));const _0xb00d33=_0x150bcc['increment'];typeof _0xb00d33!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xb00d33);const _0x2708e8=_0x1587f7['node']();if(f(_0x2708e8!==null&&typeof _0x2708e8<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2708e8['isLeafNode']())return _0xb00d33;const _0x4f417c=_0x2708e8['getValue']();return typeof _0x4f417c!='number'?_0xb00d33:_0x4f417c+_0xb00d33;},Zo=function(_0x4f3d50,_0x462743,_0x84c534,_0x1d36f8){return us(_0x462743,new ls(_0x84c534,_0x4f3d50),_0x1d36f8);},hs=function(_0x50e27e,_0x5f2e16,_0x306a6e){return us(_0x50e27e,new cs(_0x5f2e16),_0x306a6e);};function us(_0x368e6a,_0x3a8202,_0x5b994e){const _0x18b397=_0x368e6a['getPriority']()['val'](),_0x51a7f0=fr(_0x18b397,_0x3a8202['getImmediateChild']('.priority'),_0x5b994e);let _0x48cae8;if(_0x368e6a['isLeafNode']()){const _0x5b24c4=_0x368e6a,_0x293c8e=fr(_0x5b24c4['getValue'](),_0x3a8202,_0x5b994e);return _0x293c8e!==_0x5b24c4['getValue']()||_0x51a7f0!==_0x5b24c4['getPriority']()['val']()?new D(_0x293c8e,N(_0x51a7f0)):_0x368e6a;}else{const _0x48bc05=_0x368e6a;return _0x48cae8=_0x48bc05,_0x51a7f0!==_0x48bc05['getPriority']()['val']()&&(_0x48cae8=_0x48cae8['updatePriority'](new D(_0x51a7f0))),_0x48bc05['forEachChild'](R,(_0x435ef1,_0x4b2bcf)=>{const _0x3c0757=us(_0x4b2bcf,_0x3a8202['getImmediateChild'](_0x435ef1),_0x5b994e);_0x3c0757!==_0x4b2bcf&&(_0x48cae8=_0x48cae8['updateImmediateChild'](_0x435ef1,_0x3c0757));}),_0x48cae8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3dab55='',_0x502fb0=null,_0xd7a164={'children':{},'childCount':0x0}){this['name']=_0x3dab55,this['parent']=_0x502fb0,this['node']=_0xd7a164;}}function Un(_0x5cbaff,_0x15d3f4){let _0x4bb230=_0x15d3f4 instanceof C?_0x15d3f4:new C(_0x15d3f4),_0x2e82b9=_0x5cbaff,_0xcb6bad=y(_0x4bb230);for(;_0xcb6bad!==null;){const _0x1d317d=Oe(_0x2e82b9['node']['children'],_0xcb6bad)||{'children':{},'childCount':0x0};_0x2e82b9=new ds(_0xcb6bad,_0x2e82b9,_0x1d317d),_0x4bb230=b(_0x4bb230),_0xcb6bad=y(_0x4bb230);}return _0x2e82b9;}function Ge(_0x1fd689){return _0x1fd689['node']['value'];}function fs(_0x1f59fb,_0x3ba65d){_0x1f59fb['node']['value']=_0x3ba65d,Ri(_0x1f59fb);}function ea(_0x4ae43b){return _0x4ae43b['node']['childCount']>0x0;}function id(_0x5cbaf0){return Ge(_0x5cbaf0)===void 0x0&&!ea(_0x5cbaf0);}function Wn(_0x6ee735,_0x2987c6){x(_0x6ee735['node']['children'],(_0x4489b5,_0xbccc5e)=>{_0x2987c6(new ds(_0x4489b5,_0x6ee735,_0xbccc5e));});}function ta(_0x33ac98,_0x541045,_0x580067,_0x4e4232){_0x580067&&_0x541045(_0x33ac98),Wn(_0x33ac98,_0x337f85=>{ta(_0x337f85,_0x541045,!0x0);});}function sd(_0xe49226,_0x465439,_0x1a60e3){let _0x4b73f0=_0xe49226['parent'];for(;_0x4b73f0!==null;){if(_0x465439(_0x4b73f0))return!0x0;_0x4b73f0=_0x4b73f0['parent'];}return!0x1;}function Gt(_0x5eee1d){return new C(_0x5eee1d['parent']===null?_0x5eee1d['name']:Gt(_0x5eee1d['parent'])+'/'+_0x5eee1d['name']);}function Ri(_0x36330c){_0x36330c['parent']!==null&&rd(_0x36330c['parent'],_0x36330c['name'],_0x36330c);}function rd(_0x50cf54,_0x4846fa,_0x12ba06){const _0x1c0e00=id(_0x12ba06),_0x266437=Y(_0x50cf54['node']['children'],_0x4846fa);_0x1c0e00&&_0x266437?(delete _0x50cf54['node']['children'][_0x4846fa],_0x50cf54['node']['childCount']--,Ri(_0x50cf54)):!_0x1c0e00&&!_0x266437&&(_0x50cf54['node']['children'][_0x4846fa]=_0x12ba06['node'],_0x50cf54['node']['childCount']++,Ri(_0x50cf54));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2995de){return typeof _0x2995de=='string'&&_0x2995de['length']!==0x0&&!od['test'](_0x2995de);},na=function(_0x23a19a){return typeof _0x23a19a=='string'&&_0x23a19a['length']!==0x0&&!ad['test'](_0x23a19a);},cd=function(_0x1ac2fe){return _0x1ac2fe&&(_0x1ac2fe=_0x1ac2fe['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1ac2fe);},Cn=function(_0x136645){return _0x136645===null||typeof _0x136645=='string'||typeof _0x136645=='number'&&!Wi(_0x136645)||_0x136645&&typeof _0x136645=='object'&&Y(_0x136645,'.sv');},qt=function(_0x4f4a7a,_0xc65294,_0x51f93c,_0x574b9e){_0x574b9e&&_0xc65294===void 0x0||zt(Nn(_0x4f4a7a,'value'),_0xc65294,_0x51f93c);},zt=function(_0x48faac,_0x7100ad,_0x342819){const _0x4c5d4b=_0x342819 instanceof C?new Sh(_0x342819,_0x48faac):_0x342819;if(_0x7100ad===void 0x0)throw new Error(_0x48faac+'contains\x20undefined\x20'+Ne(_0x4c5d4b));if(typeof _0x7100ad=='function')throw new Error(_0x48faac+'contains\x20a\x20function\x20'+Ne(_0x4c5d4b)+'\x20with\x20contents\x20=\x20'+_0x7100ad['toString']());if(Wi(_0x7100ad))throw new Error(_0x48faac+'contains\x20'+_0x7100ad['toString']()+'\x20'+Ne(_0x4c5d4b));if(typeof _0x7100ad=='string'&&_0x7100ad['length']>oi/0x3&&Pn(_0x7100ad)>oi)throw new Error(_0x48faac+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4c5d4b)+'\x20(\x27'+_0x7100ad['substring'](0x0,0x32)+'...\x27)');if(_0x7100ad&&typeof _0x7100ad=='object'){let _0x2aba6d=!0x1,_0x72dcc4=!0x1;if(x(_0x7100ad,(_0x4c466e,_0x1519ee)=>{if(_0x4c466e==='.value')_0x2aba6d=!0x0;else{if(_0x4c466e!=='.priority'&&_0x4c466e!=='.sv'&&(_0x72dcc4=!0x0,!ps(_0x4c466e)))throw new Error(_0x48faac+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4c466e+')\x20'+Ne(_0x4c5d4b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4c5d4b,_0x4c466e),zt(_0x48faac,_0x1519ee,_0x4c5d4b),Rh(_0x4c5d4b);}),_0x2aba6d&&_0x72dcc4)throw new Error(_0x48faac+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4c5d4b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x12f043,_0x31c5d5){let _0x45c3e4,_0x1bb868;for(_0x45c3e4=0x0;_0x45c3e4<_0x31c5d5['length'];_0x45c3e4++){_0x1bb868=_0x31c5d5[_0x45c3e4];const _0x35e084=kt(_0x1bb868);for(let _0x3b886a=0x0;_0x3b886a<_0x35e084['length'];_0x3b886a++)if(!(_0x35e084[_0x3b886a]==='.priority'&&_0x3b886a===_0x35e084['length']-0x1)){if(!ps(_0x35e084[_0x3b886a]))throw new Error(_0x12f043+'contains\x20an\x20invalid\x20key\x20('+_0x35e084[_0x3b886a]+')\x20in\x20path\x20'+_0x1bb868['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x31c5d5['sort'](Th);let _0x4a0879=null;for(_0x45c3e4=0x0;_0x45c3e4<_0x31c5d5['length'];_0x45c3e4++){if(_0x1bb868=_0x31c5d5[_0x45c3e4],_0x4a0879!==null&&$(_0x4a0879,_0x1bb868))throw new Error(_0x12f043+'contains\x20a\x20path\x20'+_0x4a0879['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1bb868['toString']());_0x4a0879=_0x1bb868;}},hd=function(_0x2bc009,_0x388fbc,_0x2ff56d,_0x13ea30){const _0x34bf33=Nn(_0x2bc009,'values');if(!(_0x388fbc&&typeof _0x388fbc=='object')||Array['isArray'](_0x388fbc))throw new Error(_0x34bf33+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4423d6=[];x(_0x388fbc,(_0x544e28,_0x1c48fc)=>{const _0x10e2b2=new C(_0x544e28);if(zt(_0x34bf33,_0x1c48fc,A(_0x2ff56d,_0x10e2b2)),Gi(_0x10e2b2)==='.priority'&&!Cn(_0x1c48fc))throw new Error(_0x34bf33+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x10e2b2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4423d6['push'](_0x10e2b2);}),ld(_0x34bf33,_0x4423d6);},_s=function(_0x136d95,_0x38f92b,_0x3f80da,_0x4eb76f){if(!na(_0x3f80da))throw new Error(Nn(_0x136d95,_0x38f92b)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3f80da+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x51f643,_0x22c2e6,_0x599fc8,_0x163ddd){_0x599fc8&&(_0x599fc8=_0x599fc8['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x51f643,_0x22c2e6,_0x599fc8);},gs=function(_0xb46a97,_0x20b272){if(y(_0x20b272)==='.info')throw new Error(_0xb46a97+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x52186e,_0x42dceb){const _0x37f904=_0x42dceb['path']['toString']();if(typeof _0x42dceb['repoInfo']['host']!='string'||_0x42dceb['repoInfo']['host']['length']===0x0||!ps(_0x42dceb['repoInfo']['namespace'])&&_0x42dceb['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x37f904['length']!==0x0&&!cd(_0x37f904))throw new Error(Nn(_0x52186e,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x42e38e,_0x64ae0b){let _0x2ee4e1=null;for(let _0x248d74=0x0;_0x248d74<_0x64ae0b['length'];_0x248d74++){const _0x5c3b5a=_0x64ae0b[_0x248d74],_0x7a331e=_0x5c3b5a['getPath']();_0x2ee4e1!==null&&!qi(_0x7a331e,_0x2ee4e1['path'])&&(_0x42e38e['eventLists_']['push'](_0x2ee4e1),_0x2ee4e1=null),_0x2ee4e1===null&&(_0x2ee4e1={'events':[],'path':_0x7a331e}),_0x2ee4e1['events']['push'](_0x5c3b5a);}_0x2ee4e1&&_0x42e38e['eventLists_']['push'](_0x2ee4e1);}function ia(_0x396f19,_0x44540d,_0x3e6839){Bn(_0x396f19,_0x3e6839),sa(_0x396f19,_0x5e96fe=>qi(_0x5e96fe,_0x44540d));}function V(_0x40f18e,_0x99fa98,_0xabe14a){Bn(_0x40f18e,_0xabe14a),sa(_0x40f18e,_0x3bcb5c=>$(_0x3bcb5c,_0x99fa98)||$(_0x99fa98,_0x3bcb5c));}function sa(_0x253338,_0x12b4cf){_0x253338['recursionDepth_']++;let _0x24dd05=!0x0;for(let _0x2de7e8=0x0;_0x2de7e8<_0x253338['eventLists_']['length'];_0x2de7e8++){const _0x59d124=_0x253338['eventLists_'][_0x2de7e8];if(_0x59d124){const _0x3ba061=_0x59d124['path'];_0x12b4cf(_0x3ba061)?(pd(_0x253338['eventLists_'][_0x2de7e8]),_0x253338['eventLists_'][_0x2de7e8]=null):_0x24dd05=!0x1;}}_0x24dd05&&(_0x253338['eventLists_']=[]),_0x253338['recursionDepth_']--;}function pd(_0x381097){for(let _0x261593=0x0;_0x261593<_0x381097['events']['length'];_0x261593++){const _0x18e839=_0x381097['events'][_0x261593];if(_0x18e839!==null){_0x381097['events'][_0x261593]=null;const _0x2cc654=_0x18e839['getEventRunner']();Et&&L('event:\x20'+_0x18e839['toString']()),lt(_0x2cc654);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0xa561e3,_0x46aa4c,_0x4770b9,_0x603f64){this['repoInfo_']=_0xa561e3,this['forceRestClient_']=_0x46aa4c,this['authTokenProvider_']=_0x4770b9,this['appCheckProvider_']=_0x603f64,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0xfcab19,_0x219c4c,_0x19f070){if(_0xfcab19['stats_']=Hi(_0xfcab19['repoInfo_']),_0xfcab19['forceRestClient_']||Yl())_0xfcab19['server_']=new fn(_0xfcab19['repoInfo_'],(_0x529c52,_0x5a1839,_0x40082d,_0x379534)=>{pr(_0xfcab19,_0x529c52,_0x5a1839,_0x40082d,_0x379534);},_0xfcab19['authTokenProvider_'],_0xfcab19['appCheckProvider_']),setTimeout(()=>_r(_0xfcab19,!0x0),0x0);else{if(typeof _0x19f070<'u'&&_0x19f070!==null){if(typeof _0x19f070!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x19f070);}catch(_0x52e236){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x52e236);}}_0xfcab19['persistentConnection_']=new ie(_0xfcab19['repoInfo_'],_0x219c4c,(_0x9582ab,_0x1e0d9e,_0x433a8d,_0x217ddd)=>{pr(_0xfcab19,_0x9582ab,_0x1e0d9e,_0x433a8d,_0x217ddd);},_0x5da3f=>{_r(_0xfcab19,_0x5da3f);},_0xb28dd6=>{yd(_0xfcab19,_0xb28dd6);},_0xfcab19['authTokenProvider_'],_0xfcab19['appCheckProvider_'],_0x19f070),_0xfcab19['server_']=_0xfcab19['persistentConnection_'];}_0xfcab19['authTokenProvider_']['addTokenChangeListener'](_0x3e7fce=>{_0xfcab19['server_']['refreshAuthToken'](_0x3e7fce);}),_0xfcab19['appCheckProvider_']['addTokenChangeListener'](_0x20eec4=>{_0xfcab19['server_']['refreshAppCheckToken'](_0x20eec4['token']);}),_0xfcab19['statsReporter_']=eh(_0xfcab19['repoInfo_'],()=>new eu(_0xfcab19['stats_'],_0xfcab19['server_'])),_0xfcab19['infoData_']=new Yh(),_0xfcab19['infoSyncTree_']=new dr({'startListening':(_0x5e961d,_0x19f4e3,_0xf6e72e,_0x2aa90b)=>{let _0x230415=[];const _0x5d7a53=_0xfcab19['infoData_']['getNode'](_0x5e961d['_path']);return _0x5d7a53['isEmpty']()||(_0x230415=$t(_0xfcab19['infoSyncTree_'],_0x5e961d['_path'],_0x5d7a53),setTimeout(()=>{_0x2aa90b('ok');},0x0)),_0x230415;},'stopListening':()=>{}}),ms(_0xfcab19,'connected',!0x1),_0xfcab19['serverSyncTree_']=new dr({'startListening':(_0x264b7e,_0x7f4414,_0x49587b,_0x46e5c6)=>(_0xfcab19['server_']['listen'](_0x264b7e,_0x49587b,_0x7f4414,(_0x152d42,_0x5bf5eb)=>{const _0x1e8b2f=_0x46e5c6(_0x152d42,_0x5bf5eb);V(_0xfcab19['eventQueue_'],_0x264b7e['_path'],_0x1e8b2f);}),[]),'stopListening':(_0x1f5ae8,_0x3d8200)=>{_0xfcab19['server_']['unlisten'](_0x1f5ae8,_0x3d8200);}});}function oa(_0x451cc2){const _0x5aea23=_0x451cc2['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5aea23;}function jt(_0x480875){return ed({'timestamp':oa(_0x480875)});}function pr(_0x32d6ac,_0x219cff,_0x5b5335,_0x8c8313,_0x1d413e){_0x32d6ac['dataUpdateCount']++;const _0x3b6bf0=new C(_0x219cff);_0x5b5335=_0x32d6ac['interceptServerDataCallback_']?_0x32d6ac['interceptServerDataCallback_'](_0x219cff,_0x5b5335):_0x5b5335;let _0x49a1fb=[];if(_0x1d413e){if(_0x8c8313){const _0x1336d6=ln(_0x5b5335,_0xe180ad=>N(_0xe180ad));_0x49a1fb=Ku(_0x32d6ac['serverSyncTree_'],_0x3b6bf0,_0x1336d6,_0x1d413e);}else{const _0x5ce542=N(_0x5b5335);_0x49a1fb=Yo(_0x32d6ac['serverSyncTree_'],_0x3b6bf0,_0x5ce542,_0x1d413e);}}else{if(_0x8c8313){const _0x34c1dc=ln(_0x5b5335,_0x5ef9fa=>N(_0x5ef9fa));_0x49a1fb=qu(_0x32d6ac['serverSyncTree_'],_0x3b6bf0,_0x34c1dc);}else{const _0x1dfb5c=N(_0x5b5335);_0x49a1fb=$t(_0x32d6ac['serverSyncTree_'],_0x3b6bf0,_0x1dfb5c);}}let _0x5db537=_0x3b6bf0;_0x49a1fb['length']>0x0&&(_0x5db537=st(_0x32d6ac,_0x3b6bf0)),V(_0x32d6ac['eventQueue_'],_0x5db537,_0x49a1fb);}function _r(_0x30f310,_0x599fcf){ms(_0x30f310,'connected',_0x599fcf),_0x599fcf===!0x1&&wd(_0x30f310);}function yd(_0x31857b,_0x2658b4){x(_0x2658b4,(_0x4b0726,_0x4aa82a)=>{ms(_0x31857b,_0x4b0726,_0x4aa82a);});}function ms(_0x35b0af,_0x49ded4,_0xcb807){const _0x599786=new C('/.info/'+_0x49ded4),_0x865c17=N(_0xcb807);_0x35b0af['infoData_']['updateSnapshot'](_0x599786,_0x865c17);const _0x330049=$t(_0x35b0af['infoSyncTree_'],_0x599786,_0x865c17);V(_0x35b0af['eventQueue_'],_0x599786,_0x330049);}function Vn(_0x58db99){return _0x58db99['nextWriteId_']++;}function vd(_0x42dac5,_0x205459,_0x45021a){const _0x11fd4a=Yu(_0x42dac5['serverSyncTree_'],_0x205459);return _0x11fd4a!=null?Promise['resolve'](_0x11fd4a):_0x42dac5['server_']['get'](_0x205459)['then'](_0xaba359=>{const _0x2319bd=N(_0xaba359)['withIndex'](_0x205459['_queryParams']['getIndex']());bi(_0x42dac5['serverSyncTree_'],_0x205459,_0x45021a,!0x0);let _0x3e012c;if(_0x205459['_queryParams']['loadsAllData']())_0x3e012c=$t(_0x42dac5['serverSyncTree_'],_0x205459['_path'],_0x2319bd);else{const _0x4184f0=Mt(_0x42dac5['serverSyncTree_'],_0x205459);_0x3e012c=Yo(_0x42dac5['serverSyncTree_'],_0x205459['_path'],_0x2319bd,_0x4184f0);}return V(_0x42dac5['eventQueue_'],_0x205459['_path'],_0x3e012c),wn(_0x42dac5['serverSyncTree_'],_0x205459,_0x45021a,null,!0x0),_0x2319bd;},_0x5e670c=>(ut(_0x42dac5,'get\x20for\x20query\x20'+O(_0x205459)+'\x20failed:\x20'+_0x5e670c),Promise['reject'](new Error(_0x5e670c))));}function Ed(_0x4b6a58,_0x6f372b,_0x1b2081,_0x3c4fbc,_0x2da3c6){ut(_0x4b6a58,'set',{'path':_0x6f372b['toString'](),'value':_0x1b2081,'priority':_0x3c4fbc});const _0x74a250=jt(_0x4b6a58),_0x53e11f=N(_0x1b2081,_0x3c4fbc),_0x13d9b8=xn(_0x4b6a58['serverSyncTree_'],_0x6f372b),_0x361a51=hs(_0x53e11f,_0x13d9b8,_0x74a250),_0x3767f0=Vn(_0x4b6a58),_0x5b9a4a=ss(_0x4b6a58['serverSyncTree_'],_0x6f372b,_0x361a51,_0x3767f0,!0x0);Bn(_0x4b6a58['eventQueue_'],_0x5b9a4a),_0x4b6a58['server_']['put'](_0x6f372b['toString'](),_0x53e11f['val'](!0x0),(_0x3a6a6c,_0x15e919)=>{const _0x47c7e8=_0x3a6a6c==='ok';_0x47c7e8||U('set\x20at\x20'+_0x6f372b+'\x20failed:\x20'+_0x3a6a6c);const _0x5d6015=pe(_0x4b6a58['serverSyncTree_'],_0x3767f0,!_0x47c7e8);V(_0x4b6a58['eventQueue_'],_0x6f372b,_0x5d6015),Ai(_0x4b6a58,_0x2da3c6,_0x3a6a6c,_0x15e919);});const _0x56a875=vs(_0x4b6a58,_0x6f372b);st(_0x4b6a58,_0x56a875),V(_0x4b6a58['eventQueue_'],_0x56a875,[]);}function Id(_0x500b83,_0x14ad7f,_0x5802fd,_0x479765){ut(_0x500b83,'update',{'path':_0x14ad7f['toString'](),'value':_0x5802fd});let _0x5a52c9=!0x0;const _0x5274df=jt(_0x500b83),_0x52730f={};if(x(_0x5802fd,(_0x5584a9,_0x41e128)=>{_0x5a52c9=!0x1,_0x52730f[_0x5584a9]=Zo(A(_0x14ad7f,_0x5584a9),N(_0x41e128),_0x500b83['serverSyncTree_'],_0x5274df);}),_0x5a52c9)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x500b83,_0x479765,'ok',void 0x0);else{const _0x430a0a=Vn(_0x500b83),_0x19f663=Gu(_0x500b83['serverSyncTree_'],_0x14ad7f,_0x52730f,_0x430a0a);Bn(_0x500b83['eventQueue_'],_0x19f663),_0x500b83['server_']['merge'](_0x14ad7f['toString'](),_0x5802fd,(_0x1e6e6c,_0x3d68e1)=>{const _0x4d66fb=_0x1e6e6c==='ok';_0x4d66fb||U('update\x20at\x20'+_0x14ad7f+'\x20failed:\x20'+_0x1e6e6c);const _0x4d9cc4=pe(_0x500b83['serverSyncTree_'],_0x430a0a,!_0x4d66fb),_0x28a92e=_0x4d9cc4['length']>0x0?st(_0x500b83,_0x14ad7f):_0x14ad7f;V(_0x500b83['eventQueue_'],_0x28a92e,_0x4d9cc4),Ai(_0x500b83,_0x479765,_0x1e6e6c,_0x3d68e1);}),x(_0x5802fd,_0x1afe6e=>{const _0x1a019e=vs(_0x500b83,A(_0x14ad7f,_0x1afe6e));st(_0x500b83,_0x1a019e);}),V(_0x500b83['eventQueue_'],_0x14ad7f,[]);}}function wd(_0x3a4e7e){ut(_0x3a4e7e,'onDisconnectEvents');const _0x2689e9=jt(_0x3a4e7e),_0x539333=pn();Ei(_0x3a4e7e['onDisconnect_'],w(),(_0x1f783e,_0x1d5f91)=>{const _0x390c94=Zo(_0x1f783e,_0x1d5f91,_0x3a4e7e['serverSyncTree_'],_0x2689e9);Mo(_0x539333,_0x1f783e,_0x390c94);});let _0x5cc87d=[];Ei(_0x539333,w(),(_0x45af2f,_0x545879)=>{_0x5cc87d=_0x5cc87d['concat']($t(_0x3a4e7e['serverSyncTree_'],_0x45af2f,_0x545879));const _0x36b40b=vs(_0x3a4e7e,_0x45af2f);st(_0x3a4e7e,_0x36b40b);}),_0x3a4e7e['onDisconnect_']=pn(),V(_0x3a4e7e['eventQueue_'],w(),_0x5cc87d);}function Cd(_0x321754,_0x15fa80,_0x4976bc){let _0x4f411d;y(_0x15fa80['_path'])==='.info'?_0x4f411d=bi(_0x321754['infoSyncTree_'],_0x15fa80,_0x4976bc):_0x4f411d=bi(_0x321754['serverSyncTree_'],_0x15fa80,_0x4976bc),ia(_0x321754['eventQueue_'],_0x15fa80['_path'],_0x4f411d);}function Td(_0x4aef11,_0x2a6b05,_0x27b187){let _0x4b4635;y(_0x2a6b05['_path'])==='.info'?_0x4b4635=wn(_0x4aef11['infoSyncTree_'],_0x2a6b05,_0x27b187):_0x4b4635=wn(_0x4aef11['serverSyncTree_'],_0x2a6b05,_0x27b187),ia(_0x4aef11['eventQueue_'],_0x2a6b05['_path'],_0x4b4635);}function aa(_0x4f00f8){_0x4f00f8['persistentConnection_']&&_0x4f00f8['persistentConnection_']['interrupt'](ra);}function Sd(_0x594074){_0x594074['persistentConnection_']&&_0x594074['persistentConnection_']['resume'](ra);}function ut(_0x121aeb,..._0x41b7aa){let _0xeb939='';_0x121aeb['persistentConnection_']&&(_0xeb939=_0x121aeb['persistentConnection_']['id']+':'),L(_0xeb939,..._0x41b7aa);}function Ai(_0x39ed4c,_0x480d42,_0x3cb2aa,_0x420b0d){_0x480d42&&lt(()=>{if(_0x3cb2aa==='ok')_0x480d42(null);else{const _0x5788e7=(_0x3cb2aa||'error')['toUpperCase']();let _0x4d6ef1=_0x5788e7;_0x420b0d&&(_0x4d6ef1+=':\x20'+_0x420b0d);const _0x1ce84e=new Error(_0x4d6ef1);_0x1ce84e['code']=_0x5788e7,_0x480d42(_0x1ce84e);}});}function bd(_0x55bf21,_0x30cd6f,_0x4e39da,_0x21c959,_0x4f6a8b,_0x116854){ut(_0x55bf21,'transaction\x20on\x20'+_0x30cd6f);const _0xcf0038={'path':_0x30cd6f,'update':_0x4e39da,'onComplete':_0x21c959,'status':null,'order':to(),'applyLocally':_0x116854,'retryCount':0x0,'unwatcher':_0x4f6a8b,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4c169f=ys(_0x55bf21,_0x30cd6f,void 0x0);_0xcf0038['currentInputSnapshot']=_0x4c169f;const _0x42436c=_0xcf0038['update'](_0x4c169f['val']());if(_0x42436c===void 0x0)_0xcf0038['unwatcher'](),_0xcf0038['currentOutputSnapshotRaw']=null,_0xcf0038['currentOutputSnapshotResolved']=null,_0xcf0038['onComplete']&&_0xcf0038['onComplete'](null,!0x1,_0xcf0038['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x42436c,_0xcf0038['path']),_0xcf0038['status']=0x0;const _0x2756a7=Un(_0x55bf21['transactionQueueTree_'],_0x30cd6f),_0x14ce80=Ge(_0x2756a7)||[];_0x14ce80['push'](_0xcf0038),fs(_0x2756a7,_0x14ce80);let _0x49c06b;typeof _0x42436c=='object'&&_0x42436c!==null&&Y(_0x42436c,'.priority')?(_0x49c06b=Oe(_0x42436c,'.priority'),f(Cn(_0x49c06b),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x49c06b=(xn(_0x55bf21['serverSyncTree_'],_0x30cd6f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x592019=jt(_0x55bf21),_0x3cc4b9=N(_0x42436c,_0x49c06b),_0x144e5e=hs(_0x3cc4b9,_0x4c169f,_0x592019);_0xcf0038['currentOutputSnapshotRaw']=_0x3cc4b9,_0xcf0038['currentOutputSnapshotResolved']=_0x144e5e,_0xcf0038['currentWriteId']=Vn(_0x55bf21);const _0x1e4f8f=ss(_0x55bf21['serverSyncTree_'],_0x30cd6f,_0x144e5e,_0xcf0038['currentWriteId'],_0xcf0038['applyLocally']);V(_0x55bf21['eventQueue_'],_0x30cd6f,_0x1e4f8f),Hn(_0x55bf21,_0x55bf21['transactionQueueTree_']);}}function ys(_0x4d8349,_0x1c0889,_0x22cc7a){return xn(_0x4d8349['serverSyncTree_'],_0x1c0889,_0x22cc7a)||g['EMPTY_NODE'];}function Hn(_0x5e900f,_0xc6a421=_0x5e900f['transactionQueueTree_']){if(_0xc6a421||$n(_0x5e900f,_0xc6a421),Ge(_0xc6a421)){const _0x1dc7ec=la(_0x5e900f,_0xc6a421);f(_0x1dc7ec['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1dc7ec['every'](_0x241a4b=>_0x241a4b['status']===0x0)&&Rd(_0x5e900f,Gt(_0xc6a421),_0x1dc7ec);}else ea(_0xc6a421)&&Wn(_0xc6a421,_0x1417ab=>{Hn(_0x5e900f,_0x1417ab);});}function Rd(_0xe74f76,_0x4b3b5d,_0x261156){const _0x38f0b8=_0x261156['map'](_0x5a3127=>_0x5a3127['currentWriteId']),_0x64ef73=ys(_0xe74f76,_0x4b3b5d,_0x38f0b8);let _0x154472=_0x64ef73;const _0x2eaeba=_0x64ef73['hash']();for(let _0x3fa257=0x0;_0x3fa257<_0x261156['length'];_0x3fa257++){const _0x28c92d=_0x261156[_0x3fa257];f(_0x28c92d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x28c92d['status']=0x1,_0x28c92d['retryCount']++;const _0x5c0ec1=F(_0x4b3b5d,_0x28c92d['path']);_0x154472=_0x154472['updateChild'](_0x5c0ec1,_0x28c92d['currentOutputSnapshotRaw']);}const _0x2dec9a=_0x154472['val'](!0x0),_0x4cf926=_0x4b3b5d;_0xe74f76['server_']['put'](_0x4cf926['toString'](),_0x2dec9a,_0x42dbb5=>{ut(_0xe74f76,'transaction\x20put\x20response',{'path':_0x4cf926['toString'](),'status':_0x42dbb5});let _0x289e7e=[];if(_0x42dbb5==='ok'){const _0x4c9075=[];for(let _0x3a9de8=0x0;_0x3a9de8<_0x261156['length'];_0x3a9de8++)_0x261156[_0x3a9de8]['status']=0x2,_0x289e7e=_0x289e7e['concat'](pe(_0xe74f76['serverSyncTree_'],_0x261156[_0x3a9de8]['currentWriteId'])),_0x261156[_0x3a9de8]['onComplete']&&_0x4c9075['push'](()=>_0x261156[_0x3a9de8]['onComplete'](null,!0x0,_0x261156[_0x3a9de8]['currentOutputSnapshotResolved'])),_0x261156[_0x3a9de8]['unwatcher']();$n(_0xe74f76,Un(_0xe74f76['transactionQueueTree_'],_0x4b3b5d)),Hn(_0xe74f76,_0xe74f76['transactionQueueTree_']),V(_0xe74f76['eventQueue_'],_0x4b3b5d,_0x289e7e);for(let _0x5766c=0x0;_0x5766c<_0x4c9075['length'];_0x5766c++)lt(_0x4c9075[_0x5766c]);}else{if(_0x42dbb5==='datastale'){for(let _0xeb60a5=0x0;_0xeb60a5<_0x261156['length'];_0xeb60a5++)_0x261156[_0xeb60a5]['status']===0x3?_0x261156[_0xeb60a5]['status']=0x4:_0x261156[_0xeb60a5]['status']=0x0;}else{U('transaction\x20at\x20'+_0x4cf926['toString']()+'\x20failed:\x20'+_0x42dbb5);for(let _0x342ec2=0x0;_0x342ec2<_0x261156['length'];_0x342ec2++)_0x261156[_0x342ec2]['status']=0x4,_0x261156[_0x342ec2]['abortReason']=_0x42dbb5;}st(_0xe74f76,_0x4b3b5d);}},_0x2eaeba);}function st(_0x1147b2,_0x4b714e){const _0x268c6f=ca(_0x1147b2,_0x4b714e),_0x450522=Gt(_0x268c6f),_0x284595=la(_0x1147b2,_0x268c6f);return Ad(_0x1147b2,_0x284595,_0x450522),_0x450522;}function Ad(_0x316a43,_0x4ff646,_0x32865c){if(_0x4ff646['length']===0x0)return;const _0xe4ecf2=[];let _0x5d4bbb=[];const _0x607a2f=_0x4ff646['filter'](_0x3f2d78=>_0x3f2d78['status']===0x0)['map'](_0x1e342c=>_0x1e342c['currentWriteId']);for(let _0x37b697=0x0;_0x37b697<_0x4ff646['length'];_0x37b697++){const _0x3e441c=_0x4ff646[_0x37b697],_0x50be91=F(_0x32865c,_0x3e441c['path']);let _0x27c361=!0x1,_0x319237;if(f(_0x50be91!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3e441c['status']===0x4)_0x27c361=!0x0,_0x319237=_0x3e441c['abortReason'],_0x5d4bbb=_0x5d4bbb['concat'](pe(_0x316a43['serverSyncTree_'],_0x3e441c['currentWriteId'],!0x0));else{if(_0x3e441c['status']===0x0){if(_0x3e441c['retryCount']>=_d)_0x27c361=!0x0,_0x319237='maxretry',_0x5d4bbb=_0x5d4bbb['concat'](pe(_0x316a43['serverSyncTree_'],_0x3e441c['currentWriteId'],!0x0));else{const _0x24d35d=ys(_0x316a43,_0x3e441c['path'],_0x607a2f);_0x3e441c['currentInputSnapshot']=_0x24d35d;const _0x202f6a=_0x4ff646[_0x37b697]['update'](_0x24d35d['val']());if(_0x202f6a!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x202f6a,_0x3e441c['path']);let _0x5f429b=N(_0x202f6a);typeof _0x202f6a=='object'&&_0x202f6a!=null&&Y(_0x202f6a,'.priority')||(_0x5f429b=_0x5f429b['updatePriority'](_0x24d35d['getPriority']()));const _0x2de753=_0x3e441c['currentWriteId'],_0x2af3e9=jt(_0x316a43),_0x5562af=hs(_0x5f429b,_0x24d35d,_0x2af3e9);_0x3e441c['currentOutputSnapshotRaw']=_0x5f429b,_0x3e441c['currentOutputSnapshotResolved']=_0x5562af,_0x3e441c['currentWriteId']=Vn(_0x316a43),_0x607a2f['splice'](_0x607a2f['indexOf'](_0x2de753),0x1),_0x5d4bbb=_0x5d4bbb['concat'](ss(_0x316a43['serverSyncTree_'],_0x3e441c['path'],_0x5562af,_0x3e441c['currentWriteId'],_0x3e441c['applyLocally'])),_0x5d4bbb=_0x5d4bbb['concat'](pe(_0x316a43['serverSyncTree_'],_0x2de753,!0x0));}else _0x27c361=!0x0,_0x319237='nodata',_0x5d4bbb=_0x5d4bbb['concat'](pe(_0x316a43['serverSyncTree_'],_0x3e441c['currentWriteId'],!0x0));}}}V(_0x316a43['eventQueue_'],_0x32865c,_0x5d4bbb),_0x5d4bbb=[],_0x27c361&&(_0x4ff646[_0x37b697]['status']=0x2,function(_0x45aa94){setTimeout(_0x45aa94,Math['floor'](0x0));}(_0x4ff646[_0x37b697]['unwatcher']),_0x4ff646[_0x37b697]['onComplete']&&(_0x319237==='nodata'?_0xe4ecf2['push'](()=>_0x4ff646[_0x37b697]['onComplete'](null,!0x1,_0x4ff646[_0x37b697]['currentInputSnapshot'])):_0xe4ecf2['push'](()=>_0x4ff646[_0x37b697]['onComplete'](new Error(_0x319237),!0x1,null))));}$n(_0x316a43,_0x316a43['transactionQueueTree_']);for(let _0xda4e20=0x0;_0xda4e20<_0xe4ecf2['length'];_0xda4e20++)lt(_0xe4ecf2[_0xda4e20]);Hn(_0x316a43,_0x316a43['transactionQueueTree_']);}function ca(_0x18af45,_0x3e26a6){let _0x409832,_0x4b1ab4=_0x18af45['transactionQueueTree_'];for(_0x409832=y(_0x3e26a6);_0x409832!==null&&Ge(_0x4b1ab4)===void 0x0;)_0x4b1ab4=Un(_0x4b1ab4,_0x409832),_0x3e26a6=b(_0x3e26a6),_0x409832=y(_0x3e26a6);return _0x4b1ab4;}function la(_0x59e8fb,_0x55c3aa){const _0x431702=[];return ha(_0x59e8fb,_0x55c3aa,_0x431702),_0x431702['sort']((_0x512e4b,_0x4ab8d4)=>_0x512e4b['order']-_0x4ab8d4['order']),_0x431702;}function ha(_0xd9a34e,_0x2cd1ea,_0x364692){const _0x445161=Ge(_0x2cd1ea);if(_0x445161){for(let _0x3c4e8d=0x0;_0x3c4e8d<_0x445161['length'];_0x3c4e8d++)_0x364692['push'](_0x445161[_0x3c4e8d]);}Wn(_0x2cd1ea,_0x91af7=>{ha(_0xd9a34e,_0x91af7,_0x364692);});}function $n(_0x359fa7,_0x5d711d){const _0x5841a3=Ge(_0x5d711d);if(_0x5841a3){let _0x731559=0x0;for(let _0x387f5b=0x0;_0x387f5b<_0x5841a3['length'];_0x387f5b++)_0x5841a3[_0x387f5b]['status']!==0x2&&(_0x5841a3[_0x731559]=_0x5841a3[_0x387f5b],_0x731559++);_0x5841a3['length']=_0x731559,fs(_0x5d711d,_0x5841a3['length']>0x0?_0x5841a3:void 0x0);}Wn(_0x5d711d,_0x274f2c=>{$n(_0x359fa7,_0x274f2c);});}function vs(_0x154c56,_0x587c81){const _0x5b77c4=Gt(ca(_0x154c56,_0x587c81)),_0x50cf58=Un(_0x154c56['transactionQueueTree_'],_0x587c81);return sd(_0x50cf58,_0x849e27=>{ai(_0x154c56,_0x849e27);}),ai(_0x154c56,_0x50cf58),ta(_0x50cf58,_0x3be333=>{ai(_0x154c56,_0x3be333);}),_0x5b77c4;}function ai(_0x3d0819,_0x25a12d){const _0x318f8a=Ge(_0x25a12d);if(_0x318f8a){const _0x549acf=[];let _0x1d76c4=[],_0x14bb99=-0x1;for(let _0x91e52a=0x0;_0x91e52a<_0x318f8a['length'];_0x91e52a++)_0x318f8a[_0x91e52a]['status']===0x3||(_0x318f8a[_0x91e52a]['status']===0x1?(f(_0x14bb99===_0x91e52a-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x14bb99=_0x91e52a,_0x318f8a[_0x91e52a]['status']=0x3,_0x318f8a[_0x91e52a]['abortReason']='set'):(f(_0x318f8a[_0x91e52a]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x318f8a[_0x91e52a]['unwatcher'](),_0x1d76c4=_0x1d76c4['concat'](pe(_0x3d0819['serverSyncTree_'],_0x318f8a[_0x91e52a]['currentWriteId'],!0x0)),_0x318f8a[_0x91e52a]['onComplete']&&_0x549acf['push'](_0x318f8a[_0x91e52a]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x14bb99===-0x1?fs(_0x25a12d,void 0x0):_0x318f8a['length']=_0x14bb99+0x1,V(_0x3d0819['eventQueue_'],Gt(_0x25a12d),_0x1d76c4);for(let _0x1c1991=0x0;_0x1c1991<_0x549acf['length'];_0x1c1991++)lt(_0x549acf[_0x1c1991]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x1852e3){let _0x107405='';const _0x28e2cb=_0x1852e3['split']('/');for(let _0x304970=0x0;_0x304970<_0x28e2cb['length'];_0x304970++)if(_0x28e2cb[_0x304970]['length']>0x0){let _0x39fe79=_0x28e2cb[_0x304970];try{_0x39fe79=decodeURIComponent(_0x39fe79['replace'](/\+/g,'\x20'));}catch{}_0x107405+='/'+_0x39fe79;}return _0x107405;}function Nd(_0x302642){const _0x4e2fe1={};_0x302642['charAt'](0x0)==='?'&&(_0x302642=_0x302642['substring'](0x1));for(const _0x3edb67 of _0x302642['split']('&')){if(_0x3edb67['length']===0x0)continue;const _0x2866e5=_0x3edb67['split']('=');_0x2866e5['length']===0x2?_0x4e2fe1[decodeURIComponent(_0x2866e5[0x0])]=decodeURIComponent(_0x2866e5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3edb67+'\x27\x20in\x20query\x20\x27'+_0x302642+'\x27');}return _0x4e2fe1;}const gr=function(_0x49d831,_0x37e072){const _0x978b35=Pd(_0x49d831),_0x322266=_0x978b35['namespace'];_0x978b35['domain']==='firebase.com'&&oe(_0x978b35['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x322266||_0x322266==='undefined')&&_0x978b35['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x978b35['secure']||Bl();const _0x59ee0d=_0x978b35['scheme']==='ws'||_0x978b35['scheme']==='wss';return{'repoInfo':new _o(_0x978b35['host'],_0x978b35['secure'],_0x322266,_0x59ee0d,_0x37e072,'',_0x322266!==_0x978b35['subdomain']),'path':new C(_0x978b35['pathString'])};},Pd=function(_0x458361){let _0x53ed30='',_0x304680='',_0x273cf7='',_0xe85b80='',_0xdb28f0='',_0x2db7b5=!0x0,_0x1d8930='https',_0x478852=0x1bb;if(typeof _0x458361=='string'){let _0x198c9d=_0x458361['indexOf']('//');_0x198c9d>=0x0&&(_0x1d8930=_0x458361['substring'](0x0,_0x198c9d-0x1),_0x458361=_0x458361['substring'](_0x198c9d+0x2));let _0x5a41c6=_0x458361['indexOf']('/');_0x5a41c6===-0x1&&(_0x5a41c6=_0x458361['length']);let _0x547f26=_0x458361['indexOf']('?');_0x547f26===-0x1&&(_0x547f26=_0x458361['length']),_0x53ed30=_0x458361['substring'](0x0,Math['min'](_0x5a41c6,_0x547f26)),_0x5a41c6<_0x547f26&&(_0xe85b80=kd(_0x458361['substring'](_0x5a41c6,_0x547f26)));const _0x4dbe1a=Nd(_0x458361['substring'](Math['min'](_0x458361['length'],_0x547f26)));_0x198c9d=_0x53ed30['indexOf'](':'),_0x198c9d>=0x0?(_0x2db7b5=_0x1d8930==='https'||_0x1d8930==='wss',_0x478852=parseInt(_0x53ed30['substring'](_0x198c9d+0x1),0xa)):_0x198c9d=_0x53ed30['length'];const _0x3f33f5=_0x53ed30['slice'](0x0,_0x198c9d);if(_0x3f33f5['toLowerCase']()==='localhost')_0x304680='localhost';else{if(_0x3f33f5['split']('.')['length']<=0x2)_0x304680=_0x3f33f5;else{const _0x5ab810=_0x53ed30['indexOf']('.');_0x273cf7=_0x53ed30['substring'](0x0,_0x5ab810)['toLowerCase'](),_0x304680=_0x53ed30['substring'](_0x5ab810+0x1),_0xdb28f0=_0x273cf7;}}'ns'in _0x4dbe1a&&(_0xdb28f0=_0x4dbe1a['ns']);}return{'host':_0x53ed30,'port':_0x478852,'domain':_0x304680,'subdomain':_0x273cf7,'secure':_0x2db7b5,'scheme':_0x1d8930,'pathString':_0xe85b80,'namespace':_0xdb28f0};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x4c31da=0x0;const _0x5a72c8=[];return function(_0x434a13){const _0x3ca0c2=_0x434a13===_0x4c31da;_0x4c31da=_0x434a13;let _0x219d21;const _0x5e7472=new Array(0x8);for(_0x219d21=0x7;_0x219d21>=0x0;_0x219d21--)_0x5e7472[_0x219d21]=mr['charAt'](_0x434a13%0x40),_0x434a13=Math['floor'](_0x434a13/0x40);f(_0x434a13===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x494ea7=_0x5e7472['join']('');if(_0x3ca0c2){for(_0x219d21=0xb;_0x219d21>=0x0&&_0x5a72c8[_0x219d21]===0x3f;_0x219d21--)_0x5a72c8[_0x219d21]=0x0;_0x5a72c8[_0x219d21]++;}else{for(_0x219d21=0x0;_0x219d21<0xc;_0x219d21++)_0x5a72c8[_0x219d21]=Math['floor'](Math['random']()*0x40);}for(_0x219d21=0x0;_0x219d21<0xc;_0x219d21++)_0x494ea7+=mr['charAt'](_0x5a72c8[_0x219d21]);return f(_0x494ea7['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x494ea7;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x4b94d4,_0x227968,_0x293fc7,_0xfe6f38){this['eventType']=_0x4b94d4,this['eventRegistration']=_0x227968,this['snapshot']=_0x293fc7,this['prevName']=_0xfe6f38;}['getPath'](){const _0x346714=this['snapshot']['ref'];return this['eventType']==='value'?_0x346714['_path']:_0x346714['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x2ae48d,_0x264d17,_0x6c49f6){this['eventRegistration']=_0x2ae48d,this['error']=_0x264d17,this['path']=_0x6c49f6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x50181b,_0x5c99b7){this['snapshotCallback']=_0x50181b,this['cancelCallback']=_0x5c99b7;}['onValue'](_0x163a37,_0x4a2a77){this['snapshotCallback']['call'](null,_0x163a37,_0x4a2a77);}['onCancel'](_0x1631b5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1631b5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x29debc){return this['snapshotCallback']===_0x29debc['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x29debc['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x29debc['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4a3594,_0xc37e3,_0xfe9c59,_0x451546){this['_repo']=_0x4a3594,this['_path']=_0xc37e3,this['_queryParams']=_0xfe9c59,this['_orderByCalled']=_0x451546;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x165b47=nr(this['_queryParams']),_0x3c277e=Bi(_0x165b47);return _0x3c277e==='{}'?'default':_0x3c277e;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x289fcc){if(_0x289fcc=k(_0x289fcc),!(_0x289fcc instanceof be))return!0x1;const _0x4cf603=this['_repo']===_0x289fcc['_repo'],_0x447656=qi(this['_path'],_0x289fcc['_path']),_0x3e1c4e=this['_queryIdentifier']===_0x289fcc['_queryIdentifier'];return _0x4cf603&&_0x447656&&_0x3e1c4e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x400c0f,_0x10f4d1){if(_0x400c0f['_orderByCalled']===!0x0)throw new Error(_0x10f4d1+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x39cc9b){let _0x169f0c=null,_0x59d900=null;if(_0x39cc9b['hasStart']()&&(_0x169f0c=_0x39cc9b['getIndexStartValue']()),_0x39cc9b['hasEnd']()&&(_0x59d900=_0x39cc9b['getIndexEndValue']()),_0x39cc9b['getIndex']()===ye){const _0x243540='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3541e9='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x39cc9b['hasStart']()){if(_0x39cc9b['getIndexStartName']()!==xe)throw new Error(_0x243540);if(typeof _0x169f0c!='string')throw new Error(_0x3541e9);}if(_0x39cc9b['hasEnd']()){if(_0x39cc9b['getIndexEndName']()!==Ie)throw new Error(_0x243540);if(typeof _0x59d900!='string')throw new Error(_0x3541e9);}}else{if(_0x39cc9b['getIndex']()===R){if(_0x169f0c!=null&&!Cn(_0x169f0c)||_0x59d900!=null&&!Cn(_0x59d900))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x39cc9b['getIndex']()instanceof Ki||_0x39cc9b['getIndex']()===Po,'unknown\x20index\x20type.'),_0x169f0c!=null&&typeof _0x169f0c=='object'||_0x59d900!=null&&typeof _0x59d900=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x41fc01){if(_0x41fc01['hasStart']()&&_0x41fc01['hasEnd']()&&_0x41fc01['hasLimit']()&&!_0x41fc01['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x59f7b7,_0x4d9c26){super(_0x59f7b7,_0x4d9c26,new Qi(),!0x1);}get['parent'](){const _0x55bf7c=To(this['_path']);return _0x55bf7c===null?null:new Z(this['_repo'],_0x55bf7c);}get['root'](){let _0x525b70=this;for(;_0x525b70['parent']!==null;)_0x525b70=_0x525b70['parent'];return _0x525b70;}}class rt{constructor(_0x2f064b,_0x39a977,_0xd782a0){this['_node']=_0x2f064b,this['ref']=_0x39a977,this['_index']=_0xd782a0;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3d3d7a){const _0x2d5720=new C(_0x3d3d7a),_0x513a8a=Lt(this['ref'],_0x3d3d7a);return new rt(this['_node']['getChild'](_0x2d5720),_0x513a8a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5fc122){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2cc8b2,_0x49455e)=>_0x5fc122(new rt(_0x49455e,Lt(this['ref'],_0x2cc8b2),R)));}['hasChild'](_0x54ea14){const _0x469e87=new C(_0x54ea14);return!this['_node']['getChild'](_0x469e87)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x5ef886,_0x52e01a){return _0x5ef886=k(_0x5ef886),_0x5ef886['_checkNotDeleted']('ref'),_0x52e01a!==void 0x0?Lt(_0x5ef886['_root'],_0x52e01a):_0x5ef886['_root'];}function Lt(_0xa787e4,_0x1fb059){return _0xa787e4=k(_0xa787e4),y(_0xa787e4['_path'])===null?ud('child','path',_0x1fb059):_s('child','path',_0x1fb059),new Z(_0xa787e4['_repo'],A(_0xa787e4['_path'],_0x1fb059));}function d_(_0x490830,_0x807960){_0x490830=k(_0x490830),gs('push',_0x490830['_path']),qt('push',_0x807960,_0x490830['_path'],!0x0);const _0x50225c=oa(_0x490830['_repo']),_0x6954d1=Od(_0x50225c),_0x92ff4c=Lt(_0x490830,_0x6954d1),_0x4ba5fa=Lt(_0x490830,_0x6954d1);let _0x5edebb;return _0x807960!=null?_0x5edebb=Ld(_0x4ba5fa,_0x807960)['then'](()=>_0x4ba5fa):_0x5edebb=Promise['resolve'](_0x4ba5fa),_0x92ff4c['then']=_0x5edebb['then']['bind'](_0x5edebb),_0x92ff4c['catch']=_0x5edebb['then']['bind'](_0x5edebb,void 0x0),_0x92ff4c;}function Ld(_0x686dd,_0x287080){_0x686dd=k(_0x686dd),gs('set',_0x686dd['_path']),qt('set',_0x287080,_0x686dd['_path'],!0x1);const _0x1eece8=new Ve();return Ed(_0x686dd['_repo'],_0x686dd['_path'],_0x287080,null,_0x1eece8['wrapCallback'](()=>{})),_0x1eece8['promise'];}function f_(_0x41245e,_0x4669c9){hd('update',_0x4669c9,_0x41245e['_path']);const _0x51b98e=new Ve();return Id(_0x41245e['_repo'],_0x41245e['_path'],_0x4669c9,_0x51b98e['wrapCallback'](()=>{})),_0x51b98e['promise'];}function p_(_0x2e4efb){_0x2e4efb=k(_0x2e4efb);const _0x103334=new ua(()=>{}),_0x3de8a9=new qn(_0x103334);return vd(_0x2e4efb['_repo'],_0x2e4efb,_0x3de8a9)['then'](_0x31e08e=>new rt(_0x31e08e,new Z(_0x2e4efb['_repo'],_0x2e4efb['_path']),_0x2e4efb['_queryParams']['getIndex']()));}class qn{constructor(_0x437b9c){this['callbackContext']=_0x437b9c;}['respondsTo'](_0xe593f9){return _0xe593f9==='value';}['createEvent'](_0x173b5c,_0x7559f){const _0x2d4cc9=_0x7559f['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x173b5c['snapshotNode'],new Z(_0x7559f['_repo'],_0x7559f['_path']),_0x2d4cc9));}['getEventRunner'](_0x52b405){return _0x52b405['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x52b405['error']):()=>this['callbackContext']['onValue'](_0x52b405['snapshot'],null);}['createCancelEvent'](_0x6aba0,_0x2aadd8){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x6aba0,_0x2aadd8):null;}['matches'](_0x4632a8){return _0x4632a8 instanceof qn?!_0x4632a8['callbackContext']||!this['callbackContext']?!0x0:_0x4632a8['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4a6b1e,_0x217106,_0x11a69c,_0x13c5c2,_0x570770){const _0x344a3b=new ua(_0x11a69c,void 0x0),_0x19fbd4=new qn(_0x344a3b);return Cd(_0x4a6b1e['_repo'],_0x4a6b1e,_0x19fbd4),()=>Td(_0x4a6b1e['_repo'],_0x4a6b1e,_0x19fbd4);}function Fd(_0x4ef4f9,_0x56e5cb,_0x47e656,_0x393132){return xd(_0x4ef4f9,'value',_0x56e5cb);}class dt{}class pa extends dt{constructor(_0x57f600,_0x15d247){super(),this['_value']=_0x57f600,this['_key']=_0x15d247,this['type']='endAt';}['_apply'](_0x18b85e){qt('endAt',this['_value'],_0x18b85e['_path'],!0x0);const _0x1fd5fe=Kh(_0x18b85e['_queryParams'],this['_value'],this['_key']);if(fa(_0x1fd5fe),Gn(_0x1fd5fe),_0x18b85e['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x18b85e['_repo'],_0x18b85e['_path'],_0x1fd5fe,_0x18b85e['_orderByCalled']);}}function __(_0x25efe8,_0x21c796){return new pa(_0x25efe8,_0x21c796);}class _a extends dt{constructor(_0x9aeba4,_0x2d7d17){super(),this['_value']=_0x9aeba4,this['_key']=_0x2d7d17,this['type']='startAt';}['_apply'](_0x1f59fa){qt('startAt',this['_value'],_0x1f59fa['_path'],!0x0);const _0x380830=jh(_0x1f59fa['_queryParams'],this['_value'],this['_key']);if(fa(_0x380830),Gn(_0x380830),_0x1f59fa['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1f59fa['_repo'],_0x1f59fa['_path'],_0x380830,_0x1f59fa['_orderByCalled']);}}function g_(_0x35443b=null,_0x458891){return new _a(_0x35443b,_0x458891);}class Ud extends dt{constructor(_0xffcc1a){super(),this['_limit']=_0xffcc1a,this['type']='limitToFirst';}['_apply'](_0x2396e2){if(_0x2396e2['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2396e2['_repo'],_0x2396e2['_path'],zh(_0x2396e2['_queryParams'],this['_limit']),_0x2396e2['_orderByCalled']);}}function m_(_0x367f15){if(Math['floor'](_0x367f15)!==_0x367f15||_0x367f15<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x367f15);}class Wd extends dt{constructor(_0x1f56fb){super(),this['_path']=_0x1f56fb,this['type']='orderByChild';}['_apply'](_0x3667e6){da(_0x3667e6,'orderByChild');const _0x5bdbe8=new C(this['_path']);if(v(_0x5bdbe8))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x44c011=new Ki(_0x5bdbe8),_0x2588f1=Do(_0x3667e6['_queryParams'],_0x44c011);return Gn(_0x2588f1),new be(_0x3667e6['_repo'],_0x3667e6['_path'],_0x2588f1,!0x0);}}function y_(_0x680d1a){if(_0x680d1a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x680d1a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x680d1a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x680d1a),new Wd(_0x680d1a);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x73d0a4){da(_0x73d0a4,'orderByKey');const _0x3f4765=Do(_0x73d0a4['_queryParams'],ye);return Gn(_0x3f4765),new be(_0x73d0a4['_repo'],_0x73d0a4['_path'],_0x3f4765,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x110e90,_0x31944f){super(),this['_value']=_0x110e90,this['_key']=_0x31944f,this['type']='equalTo';}['_apply'](_0x1481a6){if(qt('equalTo',this['_value'],_0x1481a6['_path'],!0x1),_0x1481a6['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1481a6['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x1481a6));}}function E_(_0x5d140b,_0x45428e){return new Vd(_0x5d140b,_0x45428e);}function I_(_0xd2011d,..._0x655291){let _0x545426=k(_0xd2011d);for(const _0x22f154 of _0x655291)_0x545426=_0x22f154['_apply'](_0x545426);return _0x545426;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0xc0251,_0x3cc3c0,_0x2fc320,_0x4830e4){const _0x1c2123=_0x3cc3c0['lastIndexOf'](':'),_0x568734=_0x3cc3c0['substring'](0x0,_0x1c2123),_0xb9b74a=Wt(_0x568734);_0xc0251['repoInfo_']=new _o(_0x3cc3c0,_0xb9b74a,_0xc0251['repoInfo_']['namespace'],_0xc0251['repoInfo_']['webSocketOnly'],_0xc0251['repoInfo_']['nodeAdmin'],_0xc0251['repoInfo_']['persistenceKey'],_0xc0251['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2fc320),_0x4830e4&&(_0xc0251['authTokenProvider_']=_0x4830e4);}function qd(_0x488851,_0x56f357,_0x58f6dd,_0x28b2d8,_0x2181c7){let _0x4fea76=_0x28b2d8||_0x488851['options']['databaseURL'];_0x4fea76===void 0x0&&(_0x488851['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x488851['options']['projectId']),_0x4fea76=_0x488851['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3f1c76=gr(_0x4fea76,_0x2181c7),_0x5a2074=_0x3f1c76['repoInfo'],_0x357b9d;typeof process<'u'&&Us&&(_0x357b9d=Us[Hd]),_0x357b9d?(_0x4fea76='http://'+_0x357b9d+'?ns='+_0x5a2074['namespace'],_0x3f1c76=gr(_0x4fea76,_0x2181c7),_0x5a2074=_0x3f1c76['repoInfo']):_0x3f1c76['repoInfo']['secure'];const _0x2379e1=new Jl(_0x488851['name'],_0x488851['options'],_0x56f357);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3f1c76),v(_0x3f1c76['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x42a93a=jd(_0x5a2074,_0x488851,_0x2379e1,new Ql(_0x488851,_0x58f6dd));return new Kd(_0x42a93a,_0x488851);}function zd(_0x26b159,_0x4e408d){const _0x416083=ki[_0x4e408d];(!_0x416083||_0x416083[_0x26b159['key']]!==_0x26b159)&&oe('Database\x20'+_0x4e408d+'('+_0x26b159['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x26b159),delete _0x416083[_0x26b159['key']];}function jd(_0x34648c,_0xf785b8,_0x416f17,_0x4ba3a8){let _0x372778=ki[_0xf785b8['name']];_0x372778||(_0x372778={},ki[_0xf785b8['name']]=_0x372778);let _0x456616=_0x372778[_0x34648c['toURLString']()];return _0x456616&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x456616=new gd(_0x34648c,$d,_0x416f17,_0x4ba3a8),_0x372778[_0x34648c['toURLString']()]=_0x456616,_0x456616;}class Kd{constructor(_0x3d38d2,_0x3cf454){this['_repoInternal']=_0x3d38d2,this['app']=_0x3cf454,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x43e99f){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x43e99f+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x2a71b2=Qr(),_0x4aa4db){const _0x6987a7=Ui(_0x2a71b2,'database')['getImmediate']({'identifier':_0x4aa4db});if(!_0x6987a7['_instanceStarted']){const _0x153cc8=ac('database');_0x153cc8&&Yd(_0x6987a7,..._0x153cc8);}return _0x6987a7;}function Yd(_0x1f59b7,_0x33f034,_0x6f641,_0x1f4350={}){_0x1f59b7=k(_0x1f59b7),_0x1f59b7['_checkNotDeleted']('useEmulator');const _0xc171=_0x33f034+':'+_0x6f641,_0x214efc=_0x1f59b7['_repoInternal'];if(_0x1f59b7['_instanceStarted']){if(_0xc171===_0x1f59b7['_repoInternal']['repoInfo_']['host']&&De(_0x1f4350,_0x214efc['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x274949;if(_0x214efc['repoInfo_']['nodeAdmin'])_0x1f4350['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x274949=new tn(tn['OWNER']);else{if(_0x1f4350['mockUserToken']){const _0x5376ea=typeof _0x1f4350['mockUserToken']=='string'?_0x1f4350['mockUserToken']:cc(_0x1f4350['mockUserToken'],_0x1f59b7['app']['options']['projectId']);_0x274949=new tn(_0x5376ea);}}Wt(_0x33f034)&&jr(_0x33f034),Gd(_0x214efc,_0xc171,_0x1f4350,_0x274949);}function C_(_0x3dadcf){_0x3dadcf=k(_0x3dadcf),_0x3dadcf['_checkNotDeleted']('goOffline'),aa(_0x3dadcf['_repo']);}function T_(_0x5053b0){_0x5053b0=k(_0x5053b0),_0x5053b0['_checkNotDeleted']('goOnline'),Sd(_0x5053b0['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x21beaf){Ll(ct),et(new Me('database',(_0x44ca55,{instanceIdentifier:_0x4ed46a})=>{const _0x281591=_0x44ca55['getProvider']('app')['getImmediate'](),_0x5d2d1f=_0x44ca55['getProvider']('auth-internal'),_0x444c6d=_0x44ca55['getProvider']('app-check-internal');return qd(_0x281591,_0x5d2d1f,_0x444c6d,_0x4ed46a);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x21beaf),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1b189a,_0x510497){this['committed']=_0x1b189a,this['snapshot']=_0x510497;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x21abbe,_0x4e6ba,_0x407d14){if(_0x21abbe=k(_0x21abbe),gs('Reference.transaction',_0x21abbe['_path']),_0x21abbe['key']==='.length'||_0x21abbe['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x21abbe['key']+'\x20is\x20a\x20read-only\x20object.';const _0x298a29=!0x0,_0x1f3a63=new Ve(),_0x384983=(_0x346558,_0x3e7706,_0x2ffb63)=>{let _0x158641=null;_0x346558?_0x1f3a63['reject'](_0x346558):(_0x158641=new rt(_0x2ffb63,new Z(_0x21abbe['_repo'],_0x21abbe['_path']),R),_0x1f3a63['resolve'](new Xd(_0x3e7706,_0x158641)));},_0x1c3e31=Fd(_0x21abbe,()=>{});return bd(_0x21abbe['_repo'],_0x21abbe['_path'],_0x4e6ba,_0x384983,_0x1c3e31,_0x298a29),_0x1f3a63['promise'];}ie['prototype']['simpleListen']=function(_0x538541,_0x2ae3c7){this['sendRequest']('q',{'p':_0x538541},_0x2ae3c7);},ie['prototype']['echo']=function(_0x5a8161,_0x280cde){this['sendRequest']('echo',{'d':_0x5a8161},_0x280cde);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x48762e,..._0x3e6a4b){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x48762e,..._0x3e6a4b);}function nn(_0x38d0bb,..._0x2cb9f7){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x38d0bb,..._0x2cb9f7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x54a3fd,..._0x73554d){throw Es(_0x54a3fd,..._0x73554d);}function J(_0xa0c196,..._0x50f6e8){return Es(_0xa0c196,..._0x50f6e8);}function ya(_0x7712ac,_0x1d85e9,_0x6b3877){const _0x49594f={...Zd(),[_0x1d85e9]:_0x6b3877};return new Ut('auth','Firebase',_0x49594f)['create'](_0x1d85e9,{'appName':_0x7712ac['name']});}function se(_0x1affd9){return ya(_0x1affd9,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x45abd9,..._0x3399da){if(typeof _0x45abd9!='string'){const _0x4defc0=_0x3399da[0x0],_0x431afa=[..._0x3399da['slice'](0x1)];return _0x431afa[0x0]&&(_0x431afa[0x0]['appName']=_0x45abd9['name']),_0x45abd9['_errorFactory']['create'](_0x4defc0,..._0x431afa);}return ma['create'](_0x45abd9,..._0x3399da);}function m(_0x10ee4f,_0x187efe,..._0x164d6d){if(!_0x10ee4f)throw Es(_0x187efe,..._0x164d6d);}function te(_0xf160c2){const _0x1a6d17='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0xf160c2;throw nn(_0x1a6d17),new Error(_0x1a6d17);}function ae(_0x229708,_0x573ad2){_0x229708||te(_0x573ad2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x3a420e;return typeof self<'u'&&((_0x3a420e=self['location'])==null?void 0x0:_0x3a420e['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x47021e;return typeof self<'u'&&((_0x47021e=self['location'])==null?void 0x0:_0x47021e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x43e76e=navigator;return _0x43e76e['languages']&&_0x43e76e['languages'][0x0]||_0x43e76e['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xca9180,_0x4a99cd){this['shortDelay']=_0xca9180,this['longDelay']=_0x4a99cd,ae(_0x4a99cd>_0xca9180,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x124518,_0x112562){ae(_0x124518['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xbc5f6a}=_0x124518['emulator'];return _0x112562?''+_0xbc5f6a+(_0x112562['startsWith']('/')?_0x112562['slice'](0x1):_0x112562):_0xbc5f6a;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1b5eec,_0x3e6013,_0x5e3dd4){this['fetchImpl']=_0x1b5eec,_0x3e6013&&(this['headersImpl']=_0x3e6013),_0x5e3dd4&&(this['responseImpl']=_0x5e3dd4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x2bfba2,_0x2f6f94){return _0x2bfba2['tenantId']&&!_0x2f6f94['tenantId']?{..._0x2f6f94,'tenantId':_0x2bfba2['tenantId']}:_0x2f6f94;}async function Ae(_0x45ed80,_0x298f24,_0x514646,_0x5af145,_0x5511fe={}){return Ea(_0x45ed80,_0x5511fe,async()=>{let _0x3b8575={},_0x3ba623={};_0x5af145&&(_0x298f24==='GET'?_0x3ba623=_0x5af145:_0x3b8575={'body':JSON['stringify'](_0x5af145)});const _0x5eed62=at({..._0x3ba623,'key':_0x45ed80['config']['apiKey']})['slice'](0x1),_0x5d9ca1=await _0x45ed80['_getAdditionalHeaders']();_0x5d9ca1['Content-Type']='application/json',_0x45ed80['languageCode']&&(_0x5d9ca1['X-Firebase-Locale']=_0x45ed80['languageCode']);const _0x40fe10={'method':_0x298f24,'headers':_0x5d9ca1,..._0x3b8575};return lc()||(_0x40fe10['referrerPolicy']='strict-origin-when-cross-origin'),_0x45ed80['emulatorConfig']&&Wt(_0x45ed80['emulatorConfig']['host'])&&(_0x40fe10['credentials']='include'),va['fetch']()(await Ia(_0x45ed80,_0x45ed80['config']['apiHost'],_0x514646,_0x5eed62),_0x40fe10);});}async function Ea(_0x1c8238,_0x1b75dc,_0x2fe146){_0x1c8238['_canInitEmulator']=!0x1;const _0x5b6a7d={...rf,..._0x1b75dc};try{const _0x14ce0a=new lf(_0x1c8238),_0x12c885=await Promise['race']([_0x2fe146(),_0x14ce0a['promise']]);_0x14ce0a['clearNetworkTimeout']();const _0x31fc8f=await _0x12c885['json']();if('needConfirmation'in _0x31fc8f)throw en(_0x1c8238,'account-exists-with-different-credential',_0x31fc8f);if(_0x12c885['ok']&&!('errorMessage'in _0x31fc8f))return _0x31fc8f;{const _0x3a685d=_0x12c885['ok']?_0x31fc8f['errorMessage']:_0x31fc8f['error']['message'],[_0x15ddd4,_0x5a90ec]=_0x3a685d['split']('\x20:\x20');if(_0x15ddd4==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1c8238,'credential-already-in-use',_0x31fc8f);if(_0x15ddd4==='EMAIL_EXISTS')throw en(_0x1c8238,'email-already-in-use',_0x31fc8f);if(_0x15ddd4==='USER_DISABLED')throw en(_0x1c8238,'user-disabled',_0x31fc8f);const _0x5779c1=_0x5b6a7d[_0x15ddd4]||_0x15ddd4['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5a90ec)throw ya(_0x1c8238,_0x5779c1,_0x5a90ec);K(_0x1c8238,_0x5779c1);}}catch(_0x4248ee){if(_0x4248ee instanceof Se)throw _0x4248ee;K(_0x1c8238,'network-request-failed',{'message':String(_0x4248ee)});}}async function Yt(_0xef67b4,_0x1afc15,_0xeb4fd3,_0x59d49f,_0x53991f={}){const _0x3a2d3b=await Ae(_0xef67b4,_0x1afc15,_0xeb4fd3,_0x59d49f,_0x53991f);return'mfaPendingCredential'in _0x3a2d3b&&K(_0xef67b4,'multi-factor-auth-required',{'_serverResponse':_0x3a2d3b}),_0x3a2d3b;}async function Ia(_0x26d84d,_0x28f075,_0x3a6e16,_0x49848f){const _0x391102=''+_0x28f075+_0x3a6e16+'?'+_0x49848f,_0x4b99f0=_0x26d84d,_0x2431d3=_0x4b99f0['config']['emulator']?Is(_0x26d84d['config'],_0x391102):_0x26d84d['config']['apiScheme']+'://'+_0x391102;return of['includes'](_0x3a6e16)&&(await _0x4b99f0['_persistenceManagerAvailable'],_0x4b99f0['_getPersistenceType']()==='COOKIE')?_0x4b99f0['_getPersistence']()['_getFinalTarget'](_0x2431d3)['toString']():_0x2431d3;}function cf(_0x2507e6){switch(_0x2507e6){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x499435){this['auth']=_0x499435,this['timer']=null,this['promise']=new Promise((_0x2853f4,_0xa4cde6)=>{this['timer']=setTimeout(()=>_0xa4cde6(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0xad70bb,_0x27699b,_0x2953a2){const _0x3db0b5={'appName':_0xad70bb['name']};_0x2953a2['email']&&(_0x3db0b5['email']=_0x2953a2['email']),_0x2953a2['phoneNumber']&&(_0x3db0b5['phoneNumber']=_0x2953a2['phoneNumber']);const _0x3612ec=J(_0xad70bb,_0x27699b,_0x3db0b5);return _0x3612ec['customData']['_tokenResponse']=_0x2953a2,_0x3612ec;}function vr(_0x1fc1af){return _0x1fc1af!==void 0x0&&_0x1fc1af['enterprise']!==void 0x0;}class hf{constructor(_0x48afb2){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x48afb2['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x48afb2['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x48afb2['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1ef7e5){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x38a8f6 of this['recaptchaEnforcementState'])if(_0x38a8f6['provider']&&_0x38a8f6['provider']===_0x1ef7e5)return cf(_0x38a8f6['enforcementState']);return null;}['isProviderEnabled'](_0x37fdd4){return this['getProviderEnforcementState'](_0x37fdd4)==='ENFORCE'||this['getProviderEnforcementState'](_0x37fdd4)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x368391,_0x56994d){return Ae(_0x368391,'GET','/v2/recaptchaConfig',Re(_0x368391,_0x56994d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x5ac461,_0x593bcb){return Ae(_0x5ac461,'POST','/v1/accounts:delete',_0x593bcb);}async function Sn(_0x5733db,_0x4ac618){return Ae(_0x5733db,'POST','/v1/accounts:lookup',_0x4ac618);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x4c956a){if(_0x4c956a)try{const _0x2a9258=new Date(Number(_0x4c956a));if(!isNaN(_0x2a9258['getTime']()))return _0x2a9258['toUTCString']();}catch{}}async function ff(_0x31bd3f,_0x382816=!0x1){const _0x45e4ef=k(_0x31bd3f),_0x57bb50=await _0x45e4ef['getIdToken'](_0x382816),_0x2fcf2d=ws(_0x57bb50);m(_0x2fcf2d&&_0x2fcf2d['exp']&&_0x2fcf2d['auth_time']&&_0x2fcf2d['iat'],_0x45e4ef['auth'],'internal-error');const _0x241ae1=typeof _0x2fcf2d['firebase']=='object'?_0x2fcf2d['firebase']:void 0x0,_0x4bcd4a=_0x241ae1==null?void 0x0:_0x241ae1['sign_in_provider'];return{'claims':_0x2fcf2d,'token':_0x57bb50,'authTime':St(ci(_0x2fcf2d['auth_time'])),'issuedAtTime':St(ci(_0x2fcf2d['iat'])),'expirationTime':St(ci(_0x2fcf2d['exp'])),'signInProvider':_0x4bcd4a||null,'signInSecondFactor':(_0x241ae1==null?void 0x0:_0x241ae1['sign_in_second_factor'])||null};}function ci(_0x5ea6e3){return Number(_0x5ea6e3)*0x3e8;}function ws(_0x55d4e7){const [_0xf2ad3e,_0x6df94f,_0x6aed01]=_0x55d4e7['split']('.');if(_0xf2ad3e===void 0x0||_0x6df94f===void 0x0||_0x6aed01===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3a0978=cn(_0x6df94f);return _0x3a0978?JSON['parse'](_0x3a0978):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x1a3d99){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x1a3d99==null?void 0x0:_0x1a3d99['toString']()),null;}}function Er(_0x123dc2){const _0x38aa46=ws(_0x123dc2);return m(_0x38aa46,'internal-error'),m(typeof _0x38aa46['exp']<'u','internal-error'),m(typeof _0x38aa46['iat']<'u','internal-error'),Number(_0x38aa46['exp'])-Number(_0x38aa46['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x195789,_0x30ecdf,_0x1e155f=!0x1){if(_0x1e155f)return _0x30ecdf;try{return await _0x30ecdf;}catch(_0x41bbd8){throw _0x41bbd8 instanceof Se&&pf(_0x41bbd8)&&_0x195789['auth']['currentUser']===_0x195789&&await _0x195789['auth']['signOut'](),_0x41bbd8;}}function pf({code:_0x26baa8}){return _0x26baa8==='auth/user-disabled'||_0x26baa8==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x15b4b1){this['user']=_0x15b4b1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1f6229){if(_0x1f6229){const _0x5e0026=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5e0026;}else{this['errorBackoff']=0x7530;const _0x1ded6f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1ded6f);}}['schedule'](_0x363eeb=!0x1){if(!this['isRunning'])return;const _0x2552e2=this['getInterval'](_0x363eeb);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2552e2);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2bf226){(_0x2bf226==null?void 0x0:_0x2bf226['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x3f1d36,_0x60ea48){this['createdAt']=_0x3f1d36,this['lastLoginAt']=_0x60ea48,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x3f14d1){this['createdAt']=_0x3f14d1['createdAt'],this['lastLoginAt']=_0x3f14d1['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x2c156a){var _0x2db35a;const _0x287271=_0x2c156a['auth'],_0x3e2a59=await _0x2c156a['getIdToken'](),_0x42ed52=await xt(_0x2c156a,Sn(_0x287271,{'idToken':_0x3e2a59}));m(_0x42ed52==null?void 0x0:_0x42ed52['users']['length'],_0x287271,'internal-error');const _0x213964=_0x42ed52['users'][0x0];_0x2c156a['_notifyReloadListener'](_0x213964);const _0x8a3dc2=(_0x2db35a=_0x213964['providerUserInfo'])!=null&&_0x2db35a['length']?wa(_0x213964['providerUserInfo']):[],_0x594ad3=mf(_0x2c156a['providerData'],_0x8a3dc2),_0x5a8900=_0x2c156a['isAnonymous'],_0x538153=!(_0x2c156a['email']&&_0x213964['passwordHash'])&&!(_0x594ad3!=null&&_0x594ad3['length']),_0x1db536=_0x5a8900?_0x538153:!0x1,_0x2bf4ec={'uid':_0x213964['localId'],'displayName':_0x213964['displayName']||null,'photoURL':_0x213964['photoUrl']||null,'email':_0x213964['email']||null,'emailVerified':_0x213964['emailVerified']||!0x1,'phoneNumber':_0x213964['phoneNumber']||null,'tenantId':_0x213964['tenantId']||null,'providerData':_0x594ad3,'metadata':new Pi(_0x213964['createdAt'],_0x213964['lastLoginAt']),'isAnonymous':_0x1db536};Object['assign'](_0x2c156a,_0x2bf4ec);}async function gf(_0x3b5058){const _0xa041fe=k(_0x3b5058);await bn(_0xa041fe),await _0xa041fe['auth']['_persistUserIfCurrent'](_0xa041fe),_0xa041fe['auth']['_notifyListenersIfCurrent'](_0xa041fe);}function mf(_0x2a9d15,_0xcccd39){return[..._0x2a9d15['filter'](_0x4ece58=>!_0xcccd39['some'](_0x161261=>_0x161261['providerId']===_0x4ece58['providerId'])),..._0xcccd39];}function wa(_0x54de89){return _0x54de89['map'](({providerId:_0x188c5c,..._0x26d6df})=>({'providerId':_0x188c5c,'uid':_0x26d6df['rawId']||'','displayName':_0x26d6df['displayName']||null,'email':_0x26d6df['email']||null,'phoneNumber':_0x26d6df['phoneNumber']||null,'photoURL':_0x26d6df['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x20e065,_0x4203b4){const _0x274223=await Ea(_0x20e065,{},async()=>{const _0x15ec02=at({'grant_type':'refresh_token','refresh_token':_0x4203b4})['slice'](0x1),{tokenApiHost:_0x496147,apiKey:_0xd1de}=_0x20e065['config'],_0x3f257d=await Ia(_0x20e065,_0x496147,'/v1/token','key='+_0xd1de),_0x2ccd12=await _0x20e065['_getAdditionalHeaders']();_0x2ccd12['Content-Type']='application/x-www-form-urlencoded';const _0x17d21f={'method':'POST','headers':_0x2ccd12,'body':_0x15ec02};return _0x20e065['emulatorConfig']&&Wt(_0x20e065['emulatorConfig']['host'])&&(_0x17d21f['credentials']='include'),va['fetch']()(_0x3f257d,_0x17d21f);});return{'accessToken':_0x274223['access_token'],'expiresIn':_0x274223['expires_in'],'refreshToken':_0x274223['refresh_token']};}async function vf(_0x4be345,_0x370ac0){return Ae(_0x4be345,'POST','/v2/accounts:revokeToken',Re(_0x4be345,_0x370ac0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x531b26){m(_0x531b26['idToken'],'internal-error'),m(typeof _0x531b26['idToken']<'u','internal-error'),m(typeof _0x531b26['refreshToken']<'u','internal-error');const _0x11ed4a='expiresIn'in _0x531b26&&typeof _0x531b26['expiresIn']<'u'?Number(_0x531b26['expiresIn']):Er(_0x531b26['idToken']);this['updateTokensAndExpiration'](_0x531b26['idToken'],_0x531b26['refreshToken'],_0x11ed4a);}['updateFromIdToken'](_0x13e031){m(_0x13e031['length']!==0x0,'internal-error');const _0x45d1c2=Er(_0x13e031);this['updateTokensAndExpiration'](_0x13e031,null,_0x45d1c2);}async['getToken'](_0x12a382,_0x1ccfd0=!0x1){return!_0x1ccfd0&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x12a382,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x12a382,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x50cef2,_0x3580b2){const {accessToken:_0x261af8,refreshToken:_0xa6639f,expiresIn:_0x215232}=await yf(_0x50cef2,_0x3580b2);this['updateTokensAndExpiration'](_0x261af8,_0xa6639f,Number(_0x215232));}['updateTokensAndExpiration'](_0x5e71ce,_0x350007,_0x4c01c8){this['refreshToken']=_0x350007||null,this['accessToken']=_0x5e71ce||null,this['expirationTime']=Date['now']()+_0x4c01c8*0x3e8;}static['fromJSON'](_0x110082,_0x15d396){const {refreshToken:_0x37a0b6,accessToken:_0x53adc6,expirationTime:_0x97d78b}=_0x15d396,_0xf6dd21=new Je();return _0x37a0b6&&(m(typeof _0x37a0b6=='string','internal-error',{'appName':_0x110082}),_0xf6dd21['refreshToken']=_0x37a0b6),_0x53adc6&&(m(typeof _0x53adc6=='string','internal-error',{'appName':_0x110082}),_0xf6dd21['accessToken']=_0x53adc6),_0x97d78b&&(m(typeof _0x97d78b=='number','internal-error',{'appName':_0x110082}),_0xf6dd21['expirationTime']=_0x97d78b),_0xf6dd21;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4eaeb3){this['accessToken']=_0x4eaeb3['accessToken'],this['refreshToken']=_0x4eaeb3['refreshToken'],this['expirationTime']=_0x4eaeb3['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x430d26,_0xf50776){m(typeof _0x430d26=='string'||typeof _0x430d26>'u','internal-error',{'appName':_0xf50776});}class z{constructor({uid:_0x134364,auth:_0x1b5bb2,stsTokenManager:_0x3a1aa3,..._0x4a0248}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x134364,this['auth']=_0x1b5bb2,this['stsTokenManager']=_0x3a1aa3,this['accessToken']=_0x3a1aa3['accessToken'],this['displayName']=_0x4a0248['displayName']||null,this['email']=_0x4a0248['email']||null,this['emailVerified']=_0x4a0248['emailVerified']||!0x1,this['phoneNumber']=_0x4a0248['phoneNumber']||null,this['photoURL']=_0x4a0248['photoURL']||null,this['isAnonymous']=_0x4a0248['isAnonymous']||!0x1,this['tenantId']=_0x4a0248['tenantId']||null,this['providerData']=_0x4a0248['providerData']?[..._0x4a0248['providerData']]:[],this['metadata']=new Pi(_0x4a0248['createdAt']||void 0x0,_0x4a0248['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2eb022){const _0x5f5d9a=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2eb022));return m(_0x5f5d9a,this['auth'],'internal-error'),this['accessToken']!==_0x5f5d9a&&(this['accessToken']=_0x5f5d9a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5f5d9a;}['getIdTokenResult'](_0x107c44){return ff(this,_0x107c44);}['reload'](){return gf(this);}['_assign'](_0x5f40d3){this!==_0x5f40d3&&(m(this['uid']===_0x5f40d3['uid'],this['auth'],'internal-error'),this['displayName']=_0x5f40d3['displayName'],this['photoURL']=_0x5f40d3['photoURL'],this['email']=_0x5f40d3['email'],this['emailVerified']=_0x5f40d3['emailVerified'],this['phoneNumber']=_0x5f40d3['phoneNumber'],this['isAnonymous']=_0x5f40d3['isAnonymous'],this['tenantId']=_0x5f40d3['tenantId'],this['providerData']=_0x5f40d3['providerData']['map'](_0x4094aa=>({..._0x4094aa})),this['metadata']['_copy'](_0x5f40d3['metadata']),this['stsTokenManager']['_assign'](_0x5f40d3['stsTokenManager']));}['_clone'](_0x5e1152){const _0x5c2182=new z({...this,'auth':_0x5e1152,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5c2182['metadata']['_copy'](this['metadata']),_0x5c2182;}['_onReload'](_0x1da399){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1da399,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xf27a6f){this['reloadListener']?this['reloadListener'](_0xf27a6f):this['reloadUserInfo']=_0xf27a6f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3b775e,_0x4db290=!0x1){let _0x5aa1d1=!0x1;_0x3b775e['idToken']&&_0x3b775e['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3b775e),_0x5aa1d1=!0x0),_0x4db290&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5aa1d1&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x5f1bf7=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x5f1bf7})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x52940a=>({..._0x52940a})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x45ee13,_0x46659a){const _0x417b8b=_0x46659a['displayName']??void 0x0,_0xa15260=_0x46659a['email']??void 0x0,_0x46e47a=_0x46659a['phoneNumber']??void 0x0,_0xc549b5=_0x46659a['photoURL']??void 0x0,_0x2f3fa0=_0x46659a['tenantId']??void 0x0,_0x216ed4=_0x46659a['_redirectEventId']??void 0x0,_0x1425da=_0x46659a['createdAt']??void 0x0,_0xbe219e=_0x46659a['lastLoginAt']??void 0x0,{uid:_0x47daba,emailVerified:_0x336980,isAnonymous:_0x53a417,providerData:_0x58a982,stsTokenManager:_0x168627}=_0x46659a;m(_0x47daba&&_0x168627,_0x45ee13,'internal-error');const _0x170755=Je['fromJSON'](this['name'],_0x168627);m(typeof _0x47daba=='string',_0x45ee13,'internal-error'),ce(_0x417b8b,_0x45ee13['name']),ce(_0xa15260,_0x45ee13['name']),m(typeof _0x336980=='boolean',_0x45ee13,'internal-error'),m(typeof _0x53a417=='boolean',_0x45ee13,'internal-error'),ce(_0x46e47a,_0x45ee13['name']),ce(_0xc549b5,_0x45ee13['name']),ce(_0x2f3fa0,_0x45ee13['name']),ce(_0x216ed4,_0x45ee13['name']),ce(_0x1425da,_0x45ee13['name']),ce(_0xbe219e,_0x45ee13['name']);const _0x2fcc6d=new z({'uid':_0x47daba,'auth':_0x45ee13,'email':_0xa15260,'emailVerified':_0x336980,'displayName':_0x417b8b,'isAnonymous':_0x53a417,'photoURL':_0xc549b5,'phoneNumber':_0x46e47a,'tenantId':_0x2f3fa0,'stsTokenManager':_0x170755,'createdAt':_0x1425da,'lastLoginAt':_0xbe219e});return _0x58a982&&Array['isArray'](_0x58a982)&&(_0x2fcc6d['providerData']=_0x58a982['map'](_0x5befa3=>({..._0x5befa3}))),_0x216ed4&&(_0x2fcc6d['_redirectEventId']=_0x216ed4),_0x2fcc6d;}static async['_fromIdTokenResponse'](_0x5914eb,_0x2580d5,_0xf40505=!0x1){const _0x282d89=new Je();_0x282d89['updateFromServerResponse'](_0x2580d5);const _0x486aac=new z({'uid':_0x2580d5['localId'],'auth':_0x5914eb,'stsTokenManager':_0x282d89,'isAnonymous':_0xf40505});return await bn(_0x486aac),_0x486aac;}static async['_fromGetAccountInfoResponse'](_0x20cf76,_0x118925,_0x12d0ac){const _0x48fcef=_0x118925['users'][0x0];m(_0x48fcef['localId']!==void 0x0,'internal-error');const _0x314cea=_0x48fcef['providerUserInfo']!==void 0x0?wa(_0x48fcef['providerUserInfo']):[],_0x586397=!(_0x48fcef['email']&&_0x48fcef['passwordHash'])&&!(_0x314cea!=null&&_0x314cea['length']),_0x11e420=new Je();_0x11e420['updateFromIdToken'](_0x12d0ac);const _0x5bc396=new z({'uid':_0x48fcef['localId'],'auth':_0x20cf76,'stsTokenManager':_0x11e420,'isAnonymous':_0x586397}),_0x312af1={'uid':_0x48fcef['localId'],'displayName':_0x48fcef['displayName']||null,'photoURL':_0x48fcef['photoUrl']||null,'email':_0x48fcef['email']||null,'emailVerified':_0x48fcef['emailVerified']||!0x1,'phoneNumber':_0x48fcef['phoneNumber']||null,'tenantId':_0x48fcef['tenantId']||null,'providerData':_0x314cea,'metadata':new Pi(_0x48fcef['createdAt'],_0x48fcef['lastLoginAt']),'isAnonymous':!(_0x48fcef['email']&&_0x48fcef['passwordHash'])&&!(_0x314cea!=null&&_0x314cea['length'])};return Object['assign'](_0x5bc396,_0x312af1),_0x5bc396;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x1e2bd3){ae(_0x1e2bd3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5b295a=Ir['get'](_0x1e2bd3);return _0x5b295a?(ae(_0x5b295a instanceof _0x1e2bd3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5b295a):(_0x5b295a=new _0x1e2bd3(),Ir['set'](_0x1e2bd3,_0x5b295a),_0x5b295a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x322c54,_0x54c88b){this['storage'][_0x322c54]=_0x54c88b;}async['_get'](_0x56e300){const _0x171d2d=this['storage'][_0x56e300];return _0x171d2d===void 0x0?null:_0x171d2d;}async['_remove'](_0x590eab){delete this['storage'][_0x590eab];}['_addListener'](_0xda7559,_0x1ff104){}['_removeListener'](_0xb42a2,_0x1b765c){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x49e4d0,_0x9cea2e,_0x26ecf4){return'firebase:'+_0x49e4d0+':'+_0x9cea2e+':'+_0x26ecf4;}class Xe{constructor(_0x89cc26,_0x1c59b5,_0x3bfffd){this['persistence']=_0x89cc26,this['auth']=_0x1c59b5,this['userKey']=_0x3bfffd;const {config:_0x15ea3b,name:_0x415dc5}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x15ea3b['apiKey'],_0x415dc5),this['fullPersistenceKey']=sn('persistence',_0x15ea3b['apiKey'],_0x415dc5),this['boundEventHandler']=_0x1c59b5['_onStorageEvent']['bind'](_0x1c59b5),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x23514e){return this['persistence']['_set'](this['fullUserKey'],_0x23514e['toJSON']());}async['getCurrentUser'](){const _0x1e6d38=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1e6d38)return null;if(typeof _0x1e6d38=='string'){const _0x2ee18d=await Sn(this['auth'],{'idToken':_0x1e6d38})['catch'](()=>{});return _0x2ee18d?z['_fromGetAccountInfoResponse'](this['auth'],_0x2ee18d,_0x1e6d38):null;}return z['_fromJSON'](this['auth'],_0x1e6d38);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x104552){if(this['persistence']===_0x104552)return;const _0x3bd7ac=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x104552,_0x3bd7ac)return this['setCurrentUser'](_0x3bd7ac);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x177330,_0xf94b08,_0x6a2e10='authUser'){if(!_0xf94b08['length'])return new Xe(ne(wr),_0x177330,_0x6a2e10);const _0x683d7f=(await Promise['all'](_0xf94b08['map'](async _0x1c7284=>{if(await _0x1c7284['_isAvailable']())return _0x1c7284;})))['filter'](_0x3ef29a=>_0x3ef29a);let _0x336a83=_0x683d7f[0x0]||ne(wr);const _0x43ec5b=sn(_0x6a2e10,_0x177330['config']['apiKey'],_0x177330['name']);let _0x118ddb=null;for(const _0x5d3050 of _0xf94b08)try{const _0x3e6940=await _0x5d3050['_get'](_0x43ec5b);if(_0x3e6940){let _0x3d39cc;if(typeof _0x3e6940=='string'){const _0x2f820e=await Sn(_0x177330,{'idToken':_0x3e6940})['catch'](()=>{});if(!_0x2f820e)break;_0x3d39cc=await z['_fromGetAccountInfoResponse'](_0x177330,_0x2f820e,_0x3e6940);}else _0x3d39cc=z['_fromJSON'](_0x177330,_0x3e6940);_0x5d3050!==_0x336a83&&(_0x118ddb=_0x3d39cc),_0x336a83=_0x5d3050;break;}}catch{}const _0x7af41a=_0x683d7f['filter'](_0x1f2e18=>_0x1f2e18['_shouldAllowMigration']);return!_0x336a83['_shouldAllowMigration']||!_0x7af41a['length']?new Xe(_0x336a83,_0x177330,_0x6a2e10):(_0x336a83=_0x7af41a[0x0],_0x118ddb&&await _0x336a83['_set'](_0x43ec5b,_0x118ddb['toJSON']()),await Promise['all'](_0xf94b08['map'](async _0x120133=>{if(_0x120133!==_0x336a83)try{await _0x120133['_remove'](_0x43ec5b);}catch{}})),new Xe(_0x336a83,_0x177330,_0x6a2e10));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x2628d8){const _0x57a198=_0x2628d8['toLowerCase']();if(_0x57a198['includes']('opera/')||_0x57a198['includes']('opr/')||_0x57a198['includes']('opios/'))return'Opera';if(Ra(_0x57a198))return'IEMobile';if(_0x57a198['includes']('msie')||_0x57a198['includes']('trident/'))return'IE';if(_0x57a198['includes']('edge/'))return'Edge';if(Ta(_0x57a198))return'Firefox';if(_0x57a198['includes']('silk/'))return'Silk';if(ka(_0x57a198))return'Blackberry';if(Na(_0x57a198))return'Webos';if(Sa(_0x57a198))return'Safari';if((_0x57a198['includes']('chrome/')||ba(_0x57a198))&&!_0x57a198['includes']('edge/'))return'Chrome';if(Aa(_0x57a198))return'Android';{const _0xd76402=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xecd40a=_0x2628d8['match'](_0xd76402);if((_0xecd40a==null?void 0x0:_0xecd40a['length'])===0x2)return _0xecd40a[0x1];}return'Other';}function Ta(_0x18c5e4=W()){return/firefox\//i['test'](_0x18c5e4);}function Sa(_0x7e5843=W()){const _0x37597b=_0x7e5843['toLowerCase']();return _0x37597b['includes']('safari/')&&!_0x37597b['includes']('chrome/')&&!_0x37597b['includes']('crios/')&&!_0x37597b['includes']('android');}function ba(_0x48c582=W()){return/crios\//i['test'](_0x48c582);}function Ra(_0x4ae4fa=W()){return/iemobile/i['test'](_0x4ae4fa);}function Aa(_0x480b92=W()){return/android/i['test'](_0x480b92);}function ka(_0x4ee1f1=W()){return/blackberry/i['test'](_0x4ee1f1);}function Na(_0x1390d9=W()){return/webos/i['test'](_0x1390d9);}function Cs(_0x486e0f=W()){return/iphone|ipad|ipod/i['test'](_0x486e0f)||/macintosh/i['test'](_0x486e0f)&&/mobile/i['test'](_0x486e0f);}function Ef(_0x59d31f=W()){var _0x385bae;return Cs(_0x59d31f)&&!!((_0x385bae=window['navigator'])!=null&&_0x385bae['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x22a984=W()){return Cs(_0x22a984)||Aa(_0x22a984)||Na(_0x22a984)||ka(_0x22a984)||/windows phone/i['test'](_0x22a984)||Ra(_0x22a984);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x4382bf,_0x5c8554=[]){let _0x54d062;switch(_0x4382bf){case'Browser':_0x54d062=Cr(W());break;case'Worker':_0x54d062=Cr(W())+'-'+_0x4382bf;break;default:_0x54d062=_0x4382bf;}const _0x3eba99=_0x5c8554['length']?_0x5c8554['join'](','):'FirebaseCore-web';return _0x54d062+'/JsCore/'+ct+'/'+_0x3eba99;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x423d69){this['auth']=_0x423d69,this['queue']=[];}['pushCallback'](_0x2372f5,_0x5283d2){const _0xd4cfff=_0x5b0df5=>new Promise((_0x1ae5f8,_0x12c224)=>{try{const _0x373687=_0x2372f5(_0x5b0df5);_0x1ae5f8(_0x373687);}catch(_0x251c82){_0x12c224(_0x251c82);}});_0xd4cfff['onAbort']=_0x5283d2,this['queue']['push'](_0xd4cfff);const _0x39b1bd=this['queue']['length']-0x1;return()=>{this['queue'][_0x39b1bd]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3789b5){if(this['auth']['currentUser']===_0x3789b5)return;const _0x5ec330=[];try{for(const _0x45d28c of this['queue'])await _0x45d28c(_0x3789b5),_0x45d28c['onAbort']&&_0x5ec330['push'](_0x45d28c['onAbort']);}catch(_0xb91f9d){_0x5ec330['reverse']();for(const _0xf424f9 of _0x5ec330)try{_0xf424f9();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xb91f9d==null?void 0x0:_0xb91f9d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x1ea312,_0x326f92={}){return Ae(_0x1ea312,'GET','/v2/passwordPolicy',Re(_0x1ea312,_0x326f92));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x1cd83d){var _0x1da7f8;const _0x3e6e7a=_0x1cd83d['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3e6e7a['minPasswordLength']??Tf,_0x3e6e7a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3e6e7a['maxPasswordLength']),_0x3e6e7a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3e6e7a['containsLowercaseCharacter']),_0x3e6e7a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3e6e7a['containsUppercaseCharacter']),_0x3e6e7a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3e6e7a['containsNumericCharacter']),_0x3e6e7a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3e6e7a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1cd83d['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1da7f8=_0x1cd83d['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1da7f8['join'](''))??'',this['forceUpgradeOnSignin']=_0x1cd83d['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1cd83d['schemaVersion'];}['validatePassword'](_0x1d1c15){const _0x14addb={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1d1c15,_0x14addb),this['validatePasswordCharacterOptions'](_0x1d1c15,_0x14addb),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['meetsMinPasswordLength']??!0x0),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['meetsMaxPasswordLength']??!0x0),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['containsLowercaseLetter']??!0x0),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['containsUppercaseLetter']??!0x0),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['containsNumericCharacter']??!0x0),_0x14addb['isValid']&&(_0x14addb['isValid']=_0x14addb['containsNonAlphanumericCharacter']??!0x0),_0x14addb;}['validatePasswordLengthOptions'](_0x5b6c1d,_0x54e3db){const _0x3f5759=this['customStrengthOptions']['minPasswordLength'],_0x4cf395=this['customStrengthOptions']['maxPasswordLength'];_0x3f5759&&(_0x54e3db['meetsMinPasswordLength']=_0x5b6c1d['length']>=_0x3f5759),_0x4cf395&&(_0x54e3db['meetsMaxPasswordLength']=_0x5b6c1d['length']<=_0x4cf395);}['validatePasswordCharacterOptions'](_0x5c4f6f,_0x39aa07){this['updatePasswordCharacterOptionsStatuses'](_0x39aa07,!0x1,!0x1,!0x1,!0x1);let _0x4e7ce7;for(let _0x8275c4=0x0;_0x8275c4<_0x5c4f6f['length'];_0x8275c4++)_0x4e7ce7=_0x5c4f6f['charAt'](_0x8275c4),this['updatePasswordCharacterOptionsStatuses'](_0x39aa07,_0x4e7ce7>='a'&&_0x4e7ce7<='z',_0x4e7ce7>='A'&&_0x4e7ce7<='Z',_0x4e7ce7>='0'&&_0x4e7ce7<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4e7ce7));}['updatePasswordCharacterOptionsStatuses'](_0x5092f8,_0x3a60fd,_0x5cc8b4,_0x5c8e1f,_0x3f7251){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5092f8['containsLowercaseLetter']||(_0x5092f8['containsLowercaseLetter']=_0x3a60fd)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5092f8['containsUppercaseLetter']||(_0x5092f8['containsUppercaseLetter']=_0x5cc8b4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5092f8['containsNumericCharacter']||(_0x5092f8['containsNumericCharacter']=_0x5c8e1f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5092f8['containsNonAlphanumericCharacter']||(_0x5092f8['containsNonAlphanumericCharacter']=_0x3f7251));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3db2e9,_0x5145c6,_0x5d7823,_0x4c3a30){this['app']=_0x3db2e9,this['heartbeatServiceProvider']=_0x5145c6,this['appCheckServiceProvider']=_0x5d7823,this['config']=_0x4c3a30,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3db2e9['name'],this['clientVersion']=_0x4c3a30['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x337c6d=>this['_resolvePersistenceManagerAvailable']=_0x337c6d);}['_initializeWithPersistence'](_0x3560df,_0x1c072c){return _0x1c072c&&(this['_popupRedirectResolver']=ne(_0x1c072c)),this['_initializationPromise']=this['queue'](async()=>{var _0x1736e1,_0x448b42,_0x2cb666;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x3560df),(_0x1736e1=this['_resolvePersistenceManagerAvailable'])==null||_0x1736e1['call'](this),!this['_deleted'])){if((_0x448b42=this['_popupRedirectResolver'])!=null&&_0x448b42['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1c072c),this['lastNotifiedUid']=((_0x2cb666=this['currentUser'])==null?void 0x0:_0x2cb666['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2ebe27=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2ebe27)){if(this['currentUser']&&_0x2ebe27&&this['currentUser']['uid']===_0x2ebe27['uid']){this['_currentUser']['_assign'](_0x2ebe27),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2ebe27,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2c5d23){try{const _0x3fe193=await Sn(this,{'idToken':_0x2c5d23}),_0xc71076=await z['_fromGetAccountInfoResponse'](this,_0x3fe193,_0x2c5d23);await this['directlySetCurrentUser'](_0xc71076);}catch(_0x53b6b6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x53b6b6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4f74e7){var _0x4d14d2;if(H(this['app'])){const _0x4e62b1=this['app']['settings']['authIdToken'];return _0x4e62b1?new Promise(_0x368d63=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4e62b1)['then'](_0x368d63,_0x368d63));}):this['directlySetCurrentUser'](null);}const _0x32d7ba=await this['assertedPersistence']['getCurrentUser']();let _0x844381=_0x32d7ba,_0x42a861=!0x1;if(_0x4f74e7&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1a7c57=(_0x4d14d2=this['redirectUser'])==null?void 0x0:_0x4d14d2['_redirectEventId'],_0x591c0b=_0x844381==null?void 0x0:_0x844381['_redirectEventId'],_0x5b1f85=await this['tryRedirectSignIn'](_0x4f74e7);(!_0x1a7c57||_0x1a7c57===_0x591c0b)&&(_0x5b1f85!=null&&_0x5b1f85['user'])&&(_0x844381=_0x5b1f85['user'],_0x42a861=!0x0);}if(!_0x844381)return this['directlySetCurrentUser'](null);if(!_0x844381['_redirectEventId']){if(_0x42a861)try{await this['beforeStateQueue']['runMiddleware'](_0x844381);}catch(_0x377cbd){_0x844381=_0x32d7ba,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x377cbd));}return _0x844381?this['reloadAndSetCurrentUserOrClear'](_0x844381):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x844381['_redirectEventId']?this['directlySetCurrentUser'](_0x844381):this['reloadAndSetCurrentUserOrClear'](_0x844381);}async['tryRedirectSignIn'](_0x4ffcbe){let _0xb37e25=null;try{_0xb37e25=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4ffcbe,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xb37e25;}async['reloadAndSetCurrentUserOrClear'](_0x450869){try{await bn(_0x450869);}catch(_0x471a62){if((_0x471a62==null?void 0x0:_0x471a62['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x450869);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x122cd6){if(H(this['app']))return Promise['reject'](se(this));const _0x31139a=_0x122cd6?k(_0x122cd6):null;return _0x31139a&&m(_0x31139a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x31139a&&_0x31139a['_clone'](this));}async['_updateCurrentUser'](_0x392691,_0x32a770=!0x1){if(!this['_deleted'])return _0x392691&&m(this['tenantId']===_0x392691['tenantId'],this,'tenant-id-mismatch'),_0x32a770||await this['beforeStateQueue']['runMiddleware'](_0x392691),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x392691),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x25a16b){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x25a16b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5c5222){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2745c0=this['_getPasswordPolicyInternal']();return _0x2745c0['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2745c0['validatePassword'](_0x5c5222);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x33ef60=await Cf(this),_0x3f36ff=new Sf(_0x33ef60);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3f36ff:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3f36ff;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3552b4){this['_errorFactory']=new Ut('auth','Firebase',_0x3552b4());}['onAuthStateChanged'](_0x16d0e5,_0x15b6fb,_0xb12d5f){return this['registerStateListener'](this['authStateSubscription'],_0x16d0e5,_0x15b6fb,_0xb12d5f);}['beforeAuthStateChanged'](_0x4975f6,_0x3e8a74){return this['beforeStateQueue']['pushCallback'](_0x4975f6,_0x3e8a74);}['onIdTokenChanged'](_0x12962d,_0x583c82,_0x196cea){return this['registerStateListener'](this['idTokenSubscription'],_0x12962d,_0x583c82,_0x196cea);}['authStateReady'](){return new Promise((_0x5dc329,_0x43cf12)=>{if(this['currentUser'])_0x5dc329();else{const _0x4aea09=this['onAuthStateChanged'](()=>{_0x4aea09(),_0x5dc329();},_0x43cf12);}});}async['revokeAccessToken'](_0x376b79){if(this['currentUser']){const _0x538af5=await this['currentUser']['getIdToken'](),_0x4ad664={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x376b79,'idToken':_0x538af5};this['tenantId']!=null&&(_0x4ad664['tenantId']=this['tenantId']),await vf(this,_0x4ad664);}}['toJSON'](){var _0x206d36;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x206d36=this['_currentUser'])==null?void 0x0:_0x206d36['toJSON']()};}async['_setRedirectUser'](_0x57a962,_0x23fd49){const _0x50570f=await this['getOrInitRedirectPersistenceManager'](_0x23fd49);return _0x57a962===null?_0x50570f['removeCurrentUser']():_0x50570f['setCurrentUser'](_0x57a962);}async['getOrInitRedirectPersistenceManager'](_0x525203){if(!this['redirectPersistenceManager']){const _0x161c03=_0x525203&&ne(_0x525203)||this['_popupRedirectResolver'];m(_0x161c03,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x161c03['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2f42d2){var _0x55ca3a,_0x1614bd;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x55ca3a=this['_currentUser'])==null?void 0x0:_0x55ca3a['_redirectEventId'])===_0x2f42d2?this['_currentUser']:((_0x1614bd=this['redirectUser'])==null?void 0x0:_0x1614bd['_redirectEventId'])===_0x2f42d2?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4b1ea1){if(_0x4b1ea1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4b1ea1));}['_notifyListenersIfCurrent'](_0x207620){_0x207620===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3040bc;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x43774a=((_0x3040bc=this['currentUser'])==null?void 0x0:_0x3040bc['uid'])??null;this['lastNotifiedUid']!==_0x43774a&&(this['lastNotifiedUid']=_0x43774a,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x54fbe4,_0x4b4fda,_0x54598d,_0x2fe4d9){if(this['_deleted'])return()=>{};const _0x2718f1=typeof _0x4b4fda=='function'?_0x4b4fda:_0x4b4fda['next']['bind'](_0x4b4fda);let _0x2d468d=!0x1;const _0x55847a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x55847a,this,'internal-error'),_0x55847a['then'](()=>{_0x2d468d||_0x2718f1(this['currentUser']);}),typeof _0x4b4fda=='function'){const _0x1625d2=_0x54fbe4['addObserver'](_0x4b4fda,_0x54598d,_0x2fe4d9);return()=>{_0x2d468d=!0x0,_0x1625d2();};}else{const _0x5e4eff=_0x54fbe4['addObserver'](_0x4b4fda);return()=>{_0x2d468d=!0x0,_0x5e4eff();};}}async['directlySetCurrentUser'](_0x3feba3){this['currentUser']&&this['currentUser']!==_0x3feba3&&this['_currentUser']['_stopProactiveRefresh'](),_0x3feba3&&this['isProactiveRefreshEnabled']&&_0x3feba3['_startProactiveRefresh'](),this['currentUser']=_0x3feba3,_0x3feba3?await this['assertedPersistence']['setCurrentUser'](_0x3feba3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3a5426){return this['operations']=this['operations']['then'](_0x3a5426,_0x3a5426),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x589b1a){!_0x589b1a||this['frameworks']['includes'](_0x589b1a)||(this['frameworks']['push'](_0x589b1a),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5a6589;const _0x5da751={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5da751['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x44bd97=await((_0x5a6589=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a6589['getHeartbeatsHeader']());_0x44bd97&&(_0x5da751['X-Firebase-Client']=_0x44bd97);const _0x5c55df=await this['_getAppCheckToken']();return _0x5c55df&&(_0x5da751['X-Firebase-AppCheck']=_0x5c55df),_0x5da751;}async['_getAppCheckToken'](){var _0x5c78a7;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5c7b3f=await((_0x5c78a7=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5c78a7['getToken']());return _0x5c7b3f!=null&&_0x5c7b3f['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5c7b3f['error']),_0x5c7b3f==null?void 0x0:_0x5c7b3f['token'];}}function qe(_0x4b0886){return k(_0x4b0886);}class Tr{constructor(_0x148876){this['auth']=_0x148876,this['observer']=null,this['addObserver']=Ic(_0x1be535=>this['observer']=_0x1be535);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xf138fd){zn=_0xf138fd;}function Da(_0x5a9b46){return zn['loadJS'](_0x5a9b46);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1b3204){return'__'+_0x1b3204+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x55e354){_0x55e354();}['execute'](_0x43857e,_0x26e855){return Promise['resolve']('token');}['render'](_0x4e127a,_0x3dfb6b){return'';}}class Of{['ready'](_0x147cd8){_0x147cd8();}['execute'](_0xbbfc7b,_0x2b2322){return Promise['resolve']('token');}['render'](_0x30d7ec,_0x19029b){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5320b6){this['type']=Df,this['auth']=qe(_0x5320b6);}async['verify'](_0x55a2a2='verify',_0x3cb6eb=!0x1){async function _0x26f585(_0x49801a){if(!_0x3cb6eb){if(_0x49801a['tenantId']==null&&_0x49801a['_agentRecaptchaConfig']!=null)return _0x49801a['_agentRecaptchaConfig']['siteKey'];if(_0x49801a['tenantId']!=null&&_0x49801a['_tenantRecaptchaConfigs'][_0x49801a['tenantId']]!==void 0x0)return _0x49801a['_tenantRecaptchaConfigs'][_0x49801a['tenantId']]['siteKey'];}return new Promise(async(_0x1d29cd,_0x526345)=>{uf(_0x49801a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x44a78d=>{if(_0x44a78d['recaptchaKey']===void 0x0)_0x526345(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2ef254=new hf(_0x44a78d);return _0x49801a['tenantId']==null?_0x49801a['_agentRecaptchaConfig']=_0x2ef254:_0x49801a['_tenantRecaptchaConfigs'][_0x49801a['tenantId']]=_0x2ef254,_0x1d29cd(_0x2ef254['siteKey']);}})['catch'](_0x23c54d=>{_0x526345(_0x23c54d);});});}function _0x177b75(_0x3099c8,_0x4ab655,_0x576262){const _0xc31e83=window['grecaptcha'];vr(_0xc31e83)?_0xc31e83['enterprise']['ready'](()=>{_0xc31e83['enterprise']['execute'](_0x3099c8,{'action':_0x55a2a2})['then'](_0x17f268=>{_0x4ab655(_0x17f268);})['catch'](()=>{_0x4ab655(Ma);});}):_0x576262(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1a8fc4,_0x2eb730)=>{_0x26f585(this['auth'])['then'](async _0x4b194b=>{if(!_0x3cb6eb&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x177b75(_0x4b194b,_0x1a8fc4,_0x2eb730);else{if(typeof window>'u'){_0x2eb730(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x31b902=Af();_0x31b902['length']!==0x0&&(_0x31b902+=_0x4b194b+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0xcaba38;(_0xcaba38=le['scriptInjectionDeferred'])==null||_0xcaba38['resolve']();},Da(_0x31b902)['then'](()=>{var _0x1bd529;return(_0x1bd529=le['scriptInjectionDeferred'])==null?void 0x0:_0x1bd529['promise'];})['then'](()=>{_0x177b75(_0x4b194b,_0x1a8fc4,_0x2eb730);})['catch'](_0x8fcfbe=>{_0x2eb730(_0x8fcfbe);});}})['catch'](_0x13c8d0=>{_0x2eb730(_0x13c8d0);});});}}le['scriptInjectionDeferred']=null;async function br(_0x194e6f,_0x2919ac,_0x2ed712,_0x3b6398=!0x1,_0x245395=!0x1){const _0x2bfb73=new le(_0x194e6f);let _0x44b35b;if(_0x245395)_0x44b35b=Ma;else try{_0x44b35b=await _0x2bfb73['verify'](_0x2ed712);}catch{_0x44b35b=await _0x2bfb73['verify'](_0x2ed712,!0x0);}const _0x38606f={..._0x2919ac};if(_0x2ed712==='mfaSmsEnrollment'||_0x2ed712==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x38606f){const _0x3da857=_0x38606f['phoneEnrollmentInfo']['phoneNumber'],_0xb9716c=_0x38606f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x38606f,{'phoneEnrollmentInfo':{'phoneNumber':_0x3da857,'recaptchaToken':_0xb9716c,'captchaResponse':_0x44b35b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x38606f){const _0x27b25a=_0x38606f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x38606f,{'phoneSignInInfo':{'recaptchaToken':_0x27b25a,'captchaResponse':_0x44b35b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x38606f;}return _0x3b6398?Object['assign'](_0x38606f,{'captchaResp':_0x44b35b}):Object['assign'](_0x38606f,{'captchaResponse':_0x44b35b}),Object['assign'](_0x38606f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x38606f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x38606f;}async function Oi(_0x263d69,_0x59ec9e,_0x1dab28,_0x9c0d,_0x15f683){var _0x2d9362;if((_0x2d9362=_0x263d69['_getRecaptchaConfig']())!=null&&_0x2d9362['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xbe9ebb=await br(_0x263d69,_0x59ec9e,_0x1dab28,_0x1dab28==='getOobCode');return _0x9c0d(_0x263d69,_0xbe9ebb);}else return _0x9c0d(_0x263d69,_0x59ec9e)['catch'](async _0x27f65c=>{if(_0x27f65c['code']==='auth/missing-recaptcha-token'){console['log'](_0x1dab28+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5e8986=await br(_0x263d69,_0x59ec9e,_0x1dab28,_0x1dab28==='getOobCode');return _0x9c0d(_0x263d69,_0x5e8986);}else return Promise['reject'](_0x27f65c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x24ee49,_0xe4c666){const _0x11b9af=Ui(_0x24ee49,'auth');if(_0x11b9af['isInitialized']()){const _0x3ddd9f=_0x11b9af['getImmediate'](),_0x2ddd18=_0x11b9af['getOptions']();if(De(_0x2ddd18,_0xe4c666??{}))return _0x3ddd9f;K(_0x3ddd9f,'already-initialized');}return _0x11b9af['initialize']({'options':_0xe4c666});}function Lf(_0x5a31c1,_0x4db980){const _0x247fe4=(_0x4db980==null?void 0x0:_0x4db980['persistence'])||[],_0x3b75a7=(Array['isArray'](_0x247fe4)?_0x247fe4:[_0x247fe4])['map'](ne);_0x4db980!=null&&_0x4db980['errorMap']&&_0x5a31c1['_updateErrorMap'](_0x4db980['errorMap']),_0x5a31c1['_initializeWithPersistence'](_0x3b75a7,_0x4db980==null?void 0x0:_0x4db980['popupRedirectResolver']);}function xf(_0x59d9be,_0x1de54b,_0x5b7d07){const _0x4aac79=qe(_0x59d9be);m(/^https?:\/\//['test'](_0x1de54b),_0x4aac79,'invalid-emulator-scheme');const _0x5319dc=!0x1,_0x1c2f55=La(_0x1de54b),{host:_0x140315,port:_0x28dc21}=Ff(_0x1de54b),_0x110f39=_0x28dc21===null?'':':'+_0x28dc21,_0x3051fc={'url':_0x1c2f55+'//'+_0x140315+_0x110f39+'/'},_0xcfb51d=Object['freeze']({'host':_0x140315,'port':_0x28dc21,'protocol':_0x1c2f55['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5319dc})});if(!_0x4aac79['_canInitEmulator']){m(_0x4aac79['config']['emulator']&&_0x4aac79['emulatorConfig'],_0x4aac79,'emulator-config-failed'),m(De(_0x3051fc,_0x4aac79['config']['emulator'])&&De(_0xcfb51d,_0x4aac79['emulatorConfig']),_0x4aac79,'emulator-config-failed');return;}_0x4aac79['config']['emulator']=_0x3051fc,_0x4aac79['emulatorConfig']=_0xcfb51d,_0x4aac79['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x140315)?jr(_0x1c2f55+'//'+_0x140315+_0x110f39):Uf();}function La(_0x4783e8){const _0x5bb17e=_0x4783e8['indexOf'](':');return _0x5bb17e<0x0?'':_0x4783e8['substr'](0x0,_0x5bb17e+0x1);}function Ff(_0x4c2c22){const _0x295343=La(_0x4c2c22),_0x4ed980=/(\/\/)?([^?#/]+)/['exec'](_0x4c2c22['substr'](_0x295343['length']));if(!_0x4ed980)return{'host':'','port':null};const _0x5821ff=_0x4ed980[0x2]['split']('@')['pop']()||'',_0x5d62fc=/^(\[[^\]]+\])(:|$)/['exec'](_0x5821ff);if(_0x5d62fc){const _0x2a118a=_0x5d62fc[0x1];return{'host':_0x2a118a,'port':Rr(_0x5821ff['substr'](_0x2a118a['length']+0x1))};}else{const [_0x4bb2ba,_0x3ba43a]=_0x5821ff['split'](':');return{'host':_0x4bb2ba,'port':Rr(_0x3ba43a)};}}function Rr(_0x1e6a90){if(!_0x1e6a90)return null;const _0x364d40=Number(_0x1e6a90);return isNaN(_0x364d40)?null:_0x364d40;}function Uf(){function _0x1a2215(){const _0x2f12d4=document['createElement']('p'),_0x1a5375=_0x2f12d4['style'];_0x2f12d4['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1a5375['position']='fixed',_0x1a5375['width']='100%',_0x1a5375['backgroundColor']='#ffffff',_0x1a5375['border']='.1em\x20solid\x20#000000',_0x1a5375['color']='#b50000',_0x1a5375['bottom']='0px',_0x1a5375['left']='0px',_0x1a5375['margin']='0px',_0x1a5375['zIndex']='10000',_0x1a5375['textAlign']='center',_0x2f12d4['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2f12d4);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1a2215):_0x1a2215());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x324bce,_0x212270){this['providerId']=_0x324bce,this['signInMethod']=_0x212270;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4e1b43){return te('not\x20implemented');}['_linkToIdToken'](_0x555bd3,_0x213862){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x139f34){return te('not\x20implemented');}}async function Wf(_0x304efc,_0x32ac81){return Ae(_0x304efc,'POST','/v1/accounts:signUp',_0x32ac81);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2f49b7,_0x5777a9){return Yt(_0x2f49b7,'POST','/v1/accounts:signInWithPassword',Re(_0x2f49b7,_0x5777a9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x49aefa,_0xc84cc0){return Yt(_0x49aefa,'POST','/v1/accounts:signInWithEmailLink',Re(_0x49aefa,_0xc84cc0));}async function Hf(_0x25157f,_0x5dc936){return Yt(_0x25157f,'POST','/v1/accounts:signInWithEmailLink',Re(_0x25157f,_0x5dc936));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x18a2eb,_0x53d9df,_0x1dbe13,_0x4698db=null){super('password',_0x1dbe13),this['_email']=_0x18a2eb,this['_password']=_0x53d9df,this['_tenantId']=_0x4698db;}static['_fromEmailAndPassword'](_0x47c77c,_0x226c6e){return new Ft(_0x47c77c,_0x226c6e,'password');}static['_fromEmailAndCode'](_0x16b2be,_0x39bd9a,_0x9c1b9b=null){return new Ft(_0x16b2be,_0x39bd9a,'emailLink',_0x9c1b9b);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x446768){const _0x10a876=typeof _0x446768=='string'?JSON['parse'](_0x446768):_0x446768;if(_0x10a876!=null&&_0x10a876['email']&&(_0x10a876!=null&&_0x10a876['password'])){if(_0x10a876['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x10a876['email'],_0x10a876['password']);if(_0x10a876['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x10a876['email'],_0x10a876['password'],_0x10a876['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1d47fb){switch(this['signInMethod']){case'password':const _0x34d236={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1d47fb,_0x34d236,'signInWithPassword',Bf);case'emailLink':return Vf(_0x1d47fb,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x1d47fb,'internal-error');}}async['_linkToIdToken'](_0x1cb70e,_0x459e50){switch(this['signInMethod']){case'password':const _0x54264b={'idToken':_0x459e50,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1cb70e,_0x54264b,'signUpPassword',Wf);case'emailLink':return Hf(_0x1cb70e,{'idToken':_0x459e50,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1cb70e,'internal-error');}}['_getReauthenticationResolver'](_0x3d9e3b){return this['_getIdTokenResponse'](_0x3d9e3b);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3c548c,_0x52a5ad){return Yt(_0x3c548c,'POST','/v1/accounts:signInWithIdp',Re(_0x3c548c,_0x52a5ad));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1661c5){const _0x9ef06=new We(_0x1661c5['providerId'],_0x1661c5['signInMethod']);return _0x1661c5['idToken']||_0x1661c5['accessToken']?(_0x1661c5['idToken']&&(_0x9ef06['idToken']=_0x1661c5['idToken']),_0x1661c5['accessToken']&&(_0x9ef06['accessToken']=_0x1661c5['accessToken']),_0x1661c5['nonce']&&!_0x1661c5['pendingToken']&&(_0x9ef06['nonce']=_0x1661c5['nonce']),_0x1661c5['pendingToken']&&(_0x9ef06['pendingToken']=_0x1661c5['pendingToken'])):_0x1661c5['oauthToken']&&_0x1661c5['oauthTokenSecret']?(_0x9ef06['accessToken']=_0x1661c5['oauthToken'],_0x9ef06['secret']=_0x1661c5['oauthTokenSecret']):K('argument-error'),_0x9ef06;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x47e792){const _0x4f6419=typeof _0x47e792=='string'?JSON['parse'](_0x47e792):_0x47e792,{providerId:_0x416b66,signInMethod:_0x3ed079,..._0x5b75da}=_0x4f6419;if(!_0x416b66||!_0x3ed079)return null;const _0x320ab3=new We(_0x416b66,_0x3ed079);return _0x320ab3['idToken']=_0x5b75da['idToken']||void 0x0,_0x320ab3['accessToken']=_0x5b75da['accessToken']||void 0x0,_0x320ab3['secret']=_0x5b75da['secret'],_0x320ab3['nonce']=_0x5b75da['nonce'],_0x320ab3['pendingToken']=_0x5b75da['pendingToken']||null,_0x320ab3;}['_getIdTokenResponse'](_0x39e959){const _0x1b40d6=this['buildRequest']();return Ze(_0x39e959,_0x1b40d6);}['_linkToIdToken'](_0x4d0122,_0x1d2fe8){const _0x45fed0=this['buildRequest']();return _0x45fed0['idToken']=_0x1d2fe8,Ze(_0x4d0122,_0x45fed0);}['_getReauthenticationResolver'](_0x2c39d0){const _0x214627=this['buildRequest']();return _0x214627['autoCreate']=!0x1,Ze(_0x2c39d0,_0x214627);}['buildRequest'](){const _0x3b5962={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3b5962['pendingToken']=this['pendingToken'];else{const _0x315e17={};this['idToken']&&(_0x315e17['id_token']=this['idToken']),this['accessToken']&&(_0x315e17['access_token']=this['accessToken']),this['secret']&&(_0x315e17['oauth_token_secret']=this['secret']),_0x315e17['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x315e17['nonce']=this['nonce']),_0x3b5962['postBody']=at(_0x315e17);}return _0x3b5962;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x32bc89){switch(_0x32bc89){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2d92dc){const _0xc5ca0c=yt(vt(_0x2d92dc))['link'],_0x2d1b4c=_0xc5ca0c?yt(vt(_0xc5ca0c))['deep_link_id']:null,_0x39cf03=yt(vt(_0x2d92dc))['deep_link_id'];return(_0x39cf03?yt(vt(_0x39cf03))['link']:null)||_0x39cf03||_0x2d1b4c||_0xc5ca0c||_0x2d92dc;}class Ss{constructor(_0x49488b){const _0x346465=yt(vt(_0x49488b)),_0x24398a=_0x346465['apiKey']??null,_0x39c9fa=_0x346465['oobCode']??null,_0x329d3c=Gf(_0x346465['mode']??null);m(_0x24398a&&_0x39c9fa&&_0x329d3c,'argument-error'),this['apiKey']=_0x24398a,this['operation']=_0x329d3c,this['code']=_0x39c9fa,this['continueUrl']=_0x346465['continueUrl']??null,this['languageCode']=_0x346465['lang']??null,this['tenantId']=_0x346465['tenantId']??null;}static['parseLink'](_0x3bd995){const _0x52a1c9=qf(_0x3bd995);try{return new Ss(_0x52a1c9);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x33c4a9,_0x837c28){return Ft['_fromEmailAndPassword'](_0x33c4a9,_0x837c28);}static['credentialWithLink'](_0x218970,_0x550e0d){const _0x1fe44b=Ss['parseLink'](_0x550e0d);return m(_0x1fe44b,'argument-error'),Ft['_fromEmailAndCode'](_0x218970,_0x1fe44b['code'],_0x1fe44b['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x1ad39d){this['providerId']=_0x1ad39d,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x59ff31){this['defaultLanguageCode']=_0x59ff31;}['setCustomParameters'](_0x1be1b9){return this['customParameters']=_0x1be1b9,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x53cf1e){return this['scopes']['includes'](_0x53cf1e)||this['scopes']['push'](_0x53cf1e),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x1cc761){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1cc761});}static['credentialFromResult'](_0xda22b4){return he['credentialFromTaggedObject'](_0xda22b4);}static['credentialFromError'](_0x543594){return he['credentialFromTaggedObject'](_0x543594['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x183a6c}){if(!_0x183a6c||!('oauthAccessToken'in _0x183a6c)||!_0x183a6c['oauthAccessToken'])return null;try{return he['credential'](_0x183a6c['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5e5d0b,_0x7900bc){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5e5d0b,'accessToken':_0x7900bc});}static['credentialFromResult'](_0x5b8e22){return ue['credentialFromTaggedObject'](_0x5b8e22);}static['credentialFromError'](_0x5022ba){return ue['credentialFromTaggedObject'](_0x5022ba['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x127d06}){if(!_0x127d06)return null;const {oauthIdToken:_0x32619e,oauthAccessToken:_0x1d0d27}=_0x127d06;if(!_0x32619e&&!_0x1d0d27)return null;try{return ue['credential'](_0x32619e,_0x1d0d27);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3ebe7b){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3ebe7b});}static['credentialFromResult'](_0x4c808a){return de['credentialFromTaggedObject'](_0x4c808a);}static['credentialFromError'](_0x36132f){return de['credentialFromTaggedObject'](_0x36132f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4207b0}){if(!_0x4207b0||!('oauthAccessToken'in _0x4207b0)||!_0x4207b0['oauthAccessToken'])return null;try{return de['credential'](_0x4207b0['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x1345f5,_0x5aaa5c){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1345f5,'oauthTokenSecret':_0x5aaa5c});}static['credentialFromResult'](_0xf2be9f){return fe['credentialFromTaggedObject'](_0xf2be9f);}static['credentialFromError'](_0x378659){return fe['credentialFromTaggedObject'](_0x378659['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x23b6db}){if(!_0x23b6db)return null;const {oauthAccessToken:_0x46381b,oauthTokenSecret:_0x5ca430}=_0x23b6db;if(!_0x46381b||!_0x5ca430)return null;try{return fe['credential'](_0x46381b,_0x5ca430);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x87e61c,_0x4a4c9a){return Yt(_0x87e61c,'POST','/v1/accounts:signUp',Re(_0x87e61c,_0x4a4c9a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4d0d4c){this['user']=_0x4d0d4c['user'],this['providerId']=_0x4d0d4c['providerId'],this['_tokenResponse']=_0x4d0d4c['_tokenResponse'],this['operationType']=_0x4d0d4c['operationType'];}static async['_fromIdTokenResponse'](_0x400ee5,_0x610e54,_0x33f274,_0x1cf787=!0x1){const _0x5d7d93=await z['_fromIdTokenResponse'](_0x400ee5,_0x33f274,_0x1cf787),_0x355774=Ar(_0x33f274);return new Be({'user':_0x5d7d93,'providerId':_0x355774,'_tokenResponse':_0x33f274,'operationType':_0x610e54});}static async['_forOperation'](_0x2cff10,_0x4944a2,_0x26e1de){await _0x2cff10['_updateTokensIfNecessary'](_0x26e1de,!0x0);const _0x2a0997=Ar(_0x26e1de);return new Be({'user':_0x2cff10,'providerId':_0x2a0997,'_tokenResponse':_0x26e1de,'operationType':_0x4944a2});}}function Ar(_0x5df90c){return _0x5df90c['providerId']?_0x5df90c['providerId']:'phoneNumber'in _0x5df90c?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5cc723,_0x18d4f8,_0x5c527a,_0x3a7655){super(_0x18d4f8['code'],_0x18d4f8['message']),this['operationType']=_0x5c527a,this['user']=_0x3a7655,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5cc723['name'],'tenantId':_0x5cc723['tenantId']??void 0x0,'_serverResponse':_0x18d4f8['customData']['_serverResponse'],'operationType':_0x5c527a};}static['_fromErrorAndOperation'](_0xe7cfd2,_0x4cdc38,_0x3a1e2a,_0x21d49b){return new Rn(_0xe7cfd2,_0x4cdc38,_0x3a1e2a,_0x21d49b);}}function Fa(_0x58b035,_0x386b52,_0x3ea4c7,_0x2c7114){return(_0x386b52==='reauthenticate'?_0x3ea4c7['_getReauthenticationResolver'](_0x58b035):_0x3ea4c7['_getIdTokenResponse'](_0x58b035))['catch'](_0x1c4c69=>{throw _0x1c4c69['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x58b035,_0x1c4c69,_0x386b52,_0x2c7114):_0x1c4c69;});}async function jf(_0x324df1,_0x1c4fe5,_0x150238=!0x1){const _0x1d46f5=await xt(_0x324df1,_0x1c4fe5['_linkToIdToken'](_0x324df1['auth'],await _0x324df1['getIdToken']()),_0x150238);return Be['_forOperation'](_0x324df1,'link',_0x1d46f5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x36ef8a,_0x4f0138,_0x5b7b27=!0x1){const {auth:_0x33e0a4}=_0x36ef8a;if(H(_0x33e0a4['app']))return Promise['reject'](se(_0x33e0a4));const _0x3d0ec7='reauthenticate';try{const _0xf0440c=await xt(_0x36ef8a,Fa(_0x33e0a4,_0x3d0ec7,_0x4f0138,_0x36ef8a),_0x5b7b27);m(_0xf0440c['idToken'],_0x33e0a4,'internal-error');const _0x25f90c=ws(_0xf0440c['idToken']);m(_0x25f90c,_0x33e0a4,'internal-error');const {sub:_0x47cb28}=_0x25f90c;return m(_0x36ef8a['uid']===_0x47cb28,_0x33e0a4,'user-mismatch'),Be['_forOperation'](_0x36ef8a,_0x3d0ec7,_0xf0440c);}catch(_0x31d4e9){throw(_0x31d4e9==null?void 0x0:_0x31d4e9['code'])==='auth/user-not-found'&&K(_0x33e0a4,'user-mismatch'),_0x31d4e9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x499f36,_0x4ef04f,_0x19b8ef=!0x1){if(H(_0x499f36['app']))return Promise['reject'](se(_0x499f36));const _0x2f999a='signIn',_0x503d66=await Fa(_0x499f36,_0x2f999a,_0x4ef04f),_0x57c6c1=await Be['_fromIdTokenResponse'](_0x499f36,_0x2f999a,_0x503d66);return _0x19b8ef||await _0x499f36['_updateCurrentUser'](_0x57c6c1['user']),_0x57c6c1;}async function Yf(_0x1b638c,_0x3fde9a){return Ua(qe(_0x1b638c),_0x3fde9a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x419b2a){const _0x3b0bf7=qe(_0x419b2a);_0x3b0bf7['_getPasswordPolicyInternal']()&&await _0x3b0bf7['_updatePasswordPolicy']();}async function R_(_0x13bef5,_0x5eccec,_0x1bec03){if(H(_0x13bef5['app']))return Promise['reject'](se(_0x13bef5));const _0x569297=qe(_0x13bef5),_0x22ffc9=await Oi(_0x569297,{'returnSecureToken':!0x0,'email':_0x5eccec,'password':_0x1bec03,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x24eb71=>{throw _0x24eb71['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x13bef5),_0x24eb71;}),_0x127df0=await Be['_fromIdTokenResponse'](_0x569297,'signIn',_0x22ffc9);return await _0x569297['_updateCurrentUser'](_0x127df0['user']),_0x127df0;}function A_(_0x38adf8,_0x5b0b89,_0x1e8a06){return H(_0x38adf8['app'])?Promise['reject'](se(_0x38adf8)):Yf(k(_0x38adf8),ft['credential'](_0x5b0b89,_0x1e8a06))['catch'](async _0x5bd4c7=>{throw _0x5bd4c7['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x38adf8),_0x5bd4c7;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0xd7531e,_0x385491){return k(_0xd7531e)['setPersistence'](_0x385491);}function Qf(_0x28e604,_0x316309,_0x3eb44b,_0x9d4ff3){return k(_0x28e604)['onIdTokenChanged'](_0x316309,_0x3eb44b,_0x9d4ff3);}function Jf(_0x48b6e7,_0x47e7e2,_0x4ba775){return k(_0x48b6e7)['beforeAuthStateChanged'](_0x47e7e2,_0x4ba775);}function N_(_0xe4de2f,_0x508f63,_0x325f67,_0x2a4e09){return k(_0xe4de2f)['onAuthStateChanged'](_0x508f63,_0x325f67,_0x2a4e09);}function P_(_0x18d0d3){return k(_0x18d0d3)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5bc011,_0x13a432){this['storageRetriever']=_0x5bc011,this['type']=_0x13a432;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x29533f,_0x477511){return this['storage']['setItem'](_0x29533f,JSON['stringify'](_0x477511)),Promise['resolve']();}['_get'](_0x2691e7){const _0x29b57f=this['storage']['getItem'](_0x2691e7);return Promise['resolve'](_0x29b57f?JSON['parse'](_0x29b57f):null);}['_remove'](_0x169f02){return this['storage']['removeItem'](_0x169f02),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5e85f1,_0x2eff39)=>this['onStorageEvent'](_0x5e85f1,_0x2eff39),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2f164a){for(const _0x3f294d of Object['keys'](this['listeners'])){const _0x3cde14=this['storage']['getItem'](_0x3f294d),_0x4d674a=this['localCache'][_0x3f294d];_0x3cde14!==_0x4d674a&&_0x2f164a(_0x3f294d,_0x4d674a,_0x3cde14);}}['onStorageEvent'](_0x549751,_0x2cb7a7=!0x1){if(!_0x549751['key']){this['forAllChangedKeys']((_0x40e310,_0x338994,_0x3f8d95)=>{this['notifyListeners'](_0x40e310,_0x3f8d95);});return;}const _0x1baadc=_0x549751['key'];_0x2cb7a7?this['detachListener']():this['stopPolling']();const _0x51f5f3=()=>{const _0x1cac70=this['storage']['getItem'](_0x1baadc);!_0x2cb7a7&&this['localCache'][_0x1baadc]===_0x1cac70||this['notifyListeners'](_0x1baadc,_0x1cac70);},_0x2efc9e=this['storage']['getItem'](_0x1baadc);If()&&_0x2efc9e!==_0x549751['newValue']&&_0x549751['newValue']!==_0x549751['oldValue']?setTimeout(_0x51f5f3,Zf):_0x51f5f3();}['notifyListeners'](_0x174b2b,_0x37eeaa){this['localCache'][_0x174b2b]=_0x37eeaa;const _0x30b5f5=this['listeners'][_0x174b2b];if(_0x30b5f5){for(const _0x371683 of Array['from'](_0x30b5f5))_0x371683(_0x37eeaa&&JSON['parse'](_0x37eeaa));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2319e2,_0x27ddd9,_0x573fee)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2319e2,'oldValue':_0x27ddd9,'newValue':_0x573fee}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x14301f,_0x4597de){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x14301f]||(this['listeners'][_0x14301f]=new Set(),this['localCache'][_0x14301f]=this['storage']['getItem'](_0x14301f)),this['listeners'][_0x14301f]['add'](_0x4597de);}['_removeListener'](_0x1d4249,_0x3e67bc){this['listeners'][_0x1d4249]&&(this['listeners'][_0x1d4249]['delete'](_0x3e67bc),this['listeners'][_0x1d4249]['size']===0x0&&delete this['listeners'][_0x1d4249]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4fb7f5,_0x3f5f01){await super['_set'](_0x4fb7f5,_0x3f5f01),this['localCache'][_0x4fb7f5]=JSON['stringify'](_0x3f5f01);}async['_get'](_0x59762e){const _0x6a8902=await super['_get'](_0x59762e);return this['localCache'][_0x59762e]=JSON['stringify'](_0x6a8902),_0x6a8902;}async['_remove'](_0x446f39){await super['_remove'](_0x446f39),delete this['localCache'][_0x446f39];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x19f4eb,_0xfab67d){}['_removeListener'](_0x5046f6,_0x164de9){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4aa845){return Promise['all'](_0x4aa845['map'](async _0x10a40a=>{try{return{'fulfilled':!0x0,'value':await _0x10a40a};}catch(_0x2df446){return{'fulfilled':!0x1,'reason':_0x2df446};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1e8e7a){this['eventTarget']=_0x1e8e7a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x58a68c){const _0x28b6bc=this['receivers']['find'](_0x1a6234=>_0x1a6234['isListeningto'](_0x58a68c));if(_0x28b6bc)return _0x28b6bc;const _0x4e3688=new jn(_0x58a68c);return this['receivers']['push'](_0x4e3688),_0x4e3688;}['isListeningto'](_0x2b59f2){return this['eventTarget']===_0x2b59f2;}async['handleEvent'](_0x376dcd){const _0x1d7eed=_0x376dcd,{eventId:_0x225b8d,eventType:_0x516ea3,data:_0x303f2a}=_0x1d7eed['data'],_0x2fbbf5=this['handlersMap'][_0x516ea3];if(!(_0x2fbbf5!=null&&_0x2fbbf5['size']))return;_0x1d7eed['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x225b8d,'eventType':_0x516ea3});const _0x494a91=Array['from'](_0x2fbbf5)['map'](async _0x321656=>_0x321656(_0x1d7eed['origin'],_0x303f2a)),_0x253ea5=await tp(_0x494a91);_0x1d7eed['ports'][0x0]['postMessage']({'status':'done','eventId':_0x225b8d,'eventType':_0x516ea3,'response':_0x253ea5});}['_subscribe'](_0x56c871,_0x525311){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x56c871]||(this['handlersMap'][_0x56c871]=new Set()),this['handlersMap'][_0x56c871]['add'](_0x525311);}['_unsubscribe'](_0x12470c,_0x1041ef){this['handlersMap'][_0x12470c]&&_0x1041ef&&this['handlersMap'][_0x12470c]['delete'](_0x1041ef),(!_0x1041ef||this['handlersMap'][_0x12470c]['size']===0x0)&&delete this['handlersMap'][_0x12470c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x2ed5e7='',_0x1ddc59=0xa){let _0x47fb77='';for(let _0x213265=0x0;_0x213265<_0x1ddc59;_0x213265++)_0x47fb77+=Math['floor'](Math['random']()*0xa);return _0x2ed5e7+_0x47fb77;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x3f16ec){this['target']=_0x3f16ec,this['handlers']=new Set();}['removeMessageHandler'](_0x4c9ad7){_0x4c9ad7['messageChannel']&&(_0x4c9ad7['messageChannel']['port1']['removeEventListener']('message',_0x4c9ad7['onMessage']),_0x4c9ad7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4c9ad7);}async['_send'](_0x29abb3,_0x415216,_0x571fe8=0x32){const _0x3921cb=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3921cb)throw new Error('connection_unavailable');let _0x2569e1,_0x3b2fff;return new Promise((_0x155b12,_0x11c07d)=>{const _0x347d53=bs('',0x14);_0x3921cb['port1']['start']();const _0x25b3c2=setTimeout(()=>{_0x11c07d(new Error('unsupported_event'));},_0x571fe8);_0x3b2fff={'messageChannel':_0x3921cb,'onMessage'(_0xac479d){const _0x500cc9=_0xac479d;if(_0x500cc9['data']['eventId']===_0x347d53)switch(_0x500cc9['data']['status']){case'ack':clearTimeout(_0x25b3c2),_0x2569e1=setTimeout(()=>{_0x11c07d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2569e1),_0x155b12(_0x500cc9['data']['response']);break;default:clearTimeout(_0x25b3c2),clearTimeout(_0x2569e1),_0x11c07d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3b2fff),_0x3921cb['port1']['addEventListener']('message',_0x3b2fff['onMessage']),this['target']['postMessage']({'eventType':_0x29abb3,'eventId':_0x347d53,'data':_0x415216},[_0x3921cb['port2']]);})['finally'](()=>{_0x3b2fff&&this['removeMessageHandler'](_0x3b2fff);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x4b5996){X()['location']['href']=_0x4b5996;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x329b4b;return((_0x329b4b=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x329b4b['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x465edc){this['request']=_0x465edc;}['toPromise'](){return new Promise((_0x3de2d7,_0x4da142)=>{this['request']['addEventListener']('success',()=>{_0x3de2d7(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4da142(this['request']['error']);});});}}function Kn(_0x4c7714,_0x2c2145){return _0x4c7714['transaction']([kn],_0x2c2145?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x55a5a8=indexedDB['deleteDatabase'](qa);return new Jt(_0x55a5a8)['toPromise']();}function ja(){const _0x46c42a=indexedDB['open'](qa,ap);return new Promise((_0x22aa2c,_0x18a5ae)=>{_0x46c42a['addEventListener']('error',()=>{_0x18a5ae(_0x46c42a['error']);}),_0x46c42a['addEventListener']('upgradeneeded',()=>{const _0x1009b3=_0x46c42a['result'];try{_0x1009b3['createObjectStore'](kn,{'keyPath':za});}catch(_0x5670d8){_0x18a5ae(_0x5670d8);}}),_0x46c42a['addEventListener']('success',async()=>{const _0x4a676b=_0x46c42a['result'];_0x4a676b['objectStoreNames']['contains'](kn)?_0x22aa2c(_0x4a676b):(_0x4a676b['close'](),await cp(),_0x22aa2c(await ja()));});});}async function kr(_0x3b9fd2,_0x601e6,_0x35070d){const _0x52672=Kn(_0x3b9fd2,!0x0)['put']({[za]:_0x601e6,'value':_0x35070d});return new Jt(_0x52672)['toPromise']();}async function lp(_0xac9d6,_0x213ca8){const _0x2033aa=Kn(_0xac9d6,!0x1)['get'](_0x213ca8),_0x5e94db=await new Jt(_0x2033aa)['toPromise']();return _0x5e94db===void 0x0?null:_0x5e94db['value'];}function Nr(_0x1d67ec,_0x1aac48){const _0x577162=Kn(_0x1d67ec,!0x0)['delete'](_0x1aac48);return new Jt(_0x577162)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x521c24){let _0x541352=0x0;for(;;)try{const _0x1de5ca=await this['_openDb']();return await _0x521c24(_0x1de5ca);}catch(_0x9f7daa){if(_0x541352++>up)throw _0x9f7daa;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x58e0b1,_0x3b7512)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3b7512['key'])})),this['receiver']['_subscribe']('ping',async(_0x42d2bf,_0x5b59b8)=>['keyChanged']);}async['initializeSender'](){var _0x208485,_0x32234f;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x125a60=await this['sender']['_send']('ping',{},0x320);_0x125a60&&(_0x208485=_0x125a60[0x0])!=null&&_0x208485['fulfilled']&&(_0x32234f=_0x125a60[0x0])!=null&&_0x32234f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x28bab9){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x28bab9},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x39ec36=>{await kr(_0x39ec36,An,'1'),await Nr(_0x39ec36,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1c3de9){this['pendingWrites']++;try{await _0x1c3de9();}finally{this['pendingWrites']--;}}async['_set'](_0x490a4c,_0x14c367){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2e1aa1=>kr(_0x2e1aa1,_0x490a4c,_0x14c367)),this['localCache'][_0x490a4c]=_0x14c367,this['notifyServiceWorker'](_0x490a4c)));}async['_get'](_0x3306af){const _0x27ca5e=await this['_withRetries'](_0x4c4539=>lp(_0x4c4539,_0x3306af));return this['localCache'][_0x3306af]=_0x27ca5e,_0x27ca5e;}async['_remove'](_0x1b4532){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5e175d=>Nr(_0x5e175d,_0x1b4532)),delete this['localCache'][_0x1b4532],this['notifyServiceWorker'](_0x1b4532)));}async['_poll'](){const _0x584a8d=await this['_withRetries'](_0x117f0a=>{const _0xba3835=Kn(_0x117f0a,!0x1)['getAll']();return new Jt(_0xba3835)['toPromise']();});if(!_0x584a8d)return[];if(this['pendingWrites']!==0x0)return[];const _0xe8e32c=[],_0x37f36d=new Set();if(_0x584a8d['length']!==0x0){for(const {fbase_key:_0x39838e,value:_0x18b5cf}of _0x584a8d)_0x37f36d['add'](_0x39838e),JSON['stringify'](this['localCache'][_0x39838e])!==JSON['stringify'](_0x18b5cf)&&(this['notifyListeners'](_0x39838e,_0x18b5cf),_0xe8e32c['push'](_0x39838e));}for(const _0x23fee3 of Object['keys'](this['localCache']))this['localCache'][_0x23fee3]&&!_0x37f36d['has'](_0x23fee3)&&(this['notifyListeners'](_0x23fee3,null),_0xe8e32c['push'](_0x23fee3));return _0xe8e32c;}['notifyListeners'](_0x32ed36,_0x36ce32){this['localCache'][_0x32ed36]=_0x36ce32;const _0x1bad60=this['listeners'][_0x32ed36];if(_0x1bad60){for(const _0x5b360b of Array['from'](_0x1bad60))_0x5b360b(_0x36ce32);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x240325,_0x5d2a58){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x240325]||(this['listeners'][_0x240325]=new Set(),this['_get'](_0x240325)),this['listeners'][_0x240325]['add'](_0x5d2a58);}['_removeListener'](_0xf7e683,_0x1b1194){this['listeners'][_0xf7e683]&&(this['listeners'][_0xf7e683]['delete'](_0x1b1194),this['listeners'][_0xf7e683]['size']===0x0&&delete this['listeners'][_0xf7e683]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x5b9551,_0x39e655){return _0x39e655?ne(_0x39e655):(m(_0x5b9551['_popupRedirectResolver'],_0x5b9551,'argument-error'),_0x5b9551['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x18239a){super('custom','custom'),this['params']=_0x18239a;}['_getIdTokenResponse'](_0x26ef2b){return Ze(_0x26ef2b,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5e3476,_0x5c70d4){return Ze(_0x5e3476,this['_buildIdpRequest'](_0x5c70d4));}['_getReauthenticationResolver'](_0x3ebe44){return Ze(_0x3ebe44,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x18ad17){const _0x2f4bdf={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x18ad17&&(_0x2f4bdf['idToken']=_0x18ad17),_0x2f4bdf;}}function pp(_0x4024af){return Ua(_0x4024af['auth'],new Rs(_0x4024af),_0x4024af['bypassAuthState']);}function _p(_0x19835e){const {auth:_0x8916d,user:_0x5621f1}=_0x19835e;return m(_0x5621f1,_0x8916d,'internal-error'),Kf(_0x5621f1,new Rs(_0x19835e),_0x19835e['bypassAuthState']);}async function gp(_0x2148cf){const {auth:_0x90df66,user:_0x1d08c5}=_0x2148cf;return m(_0x1d08c5,_0x90df66,'internal-error'),jf(_0x1d08c5,new Rs(_0x2148cf),_0x2148cf['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x1c968e,_0x20b544,_0xb75bba,_0xdaab21,_0x1aa8bb=!0x1){this['auth']=_0x1c968e,this['resolver']=_0xb75bba,this['user']=_0xdaab21,this['bypassAuthState']=_0x1aa8bb,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x20b544)?_0x20b544:[_0x20b544];}['execute'](){return new Promise(async(_0x5b8e08,_0x6bc988)=>{this['pendingPromise']={'resolve':_0x5b8e08,'reject':_0x6bc988};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5d44ba){this['reject'](_0x5d44ba);}});}async['onAuthEvent'](_0x312bdc){const {urlResponse:_0x1db405,sessionId:_0x3b58b5,postBody:_0x430410,tenantId:_0x572c97,error:_0x552125,type:_0x396407}=_0x312bdc;if(_0x552125){this['reject'](_0x552125);return;}const _0x564a1a={'auth':this['auth'],'requestUri':_0x1db405,'sessionId':_0x3b58b5,'tenantId':_0x572c97||void 0x0,'postBody':_0x430410||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x396407)(_0x564a1a));}catch(_0x366333){this['reject'](_0x366333);}}['onError'](_0x34c06b){this['reject'](_0x34c06b);}['getIdpTask'](_0x400bc6){switch(_0x400bc6){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x412d83){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x412d83),this['unregisterAndCleanUp']();}['reject'](_0x393dff){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x393dff),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x5f50df,_0x41a6d0,_0x14626e,_0x3d8188,_0x2c5eb7){super(_0x5f50df,_0x41a6d0,_0x3d8188,_0x2c5eb7),this['provider']=_0x14626e,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x56a7d6=await this['execute']();return m(_0x56a7d6,this['auth'],'internal-error'),_0x56a7d6;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3c9741=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3c9741),this['authWindow']['associatedEvent']=_0x3c9741,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4eee99=>{this['reject'](_0x4eee99);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x12a084=>{_0x12a084||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4e8f2e;return((_0x4e8f2e=this['authWindow'])==null?void 0x0:_0x4e8f2e['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x403651=()=>{var _0x210dcd,_0x1a1b7e;if((_0x1a1b7e=(_0x210dcd=this['authWindow'])==null?void 0x0:_0x210dcd['window'])!=null&&_0x1a1b7e['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x403651,mp['get']());};_0x403651();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x4625b5,_0x473a3b,_0x3f24c4=!0x1){super(_0x4625b5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x473a3b,void 0x0,_0x3f24c4),this['eventId']=null;}async['execute'](){let _0x7c188d=rn['get'](this['auth']['_key']());if(!_0x7c188d){try{const _0x2d9546=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x7c188d=()=>Promise['resolve'](_0x2d9546);}catch(_0xb28924){_0x7c188d=()=>Promise['reject'](_0xb28924);}rn['set'](this['auth']['_key'](),_0x7c188d);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x7c188d();}async['onAuthEvent'](_0xba0e6f){if(_0xba0e6f['type']==='signInViaRedirect')return super['onAuthEvent'](_0xba0e6f);if(_0xba0e6f['type']==='unknown'){this['resolve'](null);return;}if(_0xba0e6f['eventId']){const _0x2290f6=await this['auth']['_redirectUserForId'](_0xba0e6f['eventId']);if(_0x2290f6)return this['user']=_0x2290f6,super['onAuthEvent'](_0xba0e6f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x378b82,_0x1cccbb){const _0x6507a=Cp(_0x1cccbb),_0x4c5efd=wp(_0x378b82);if(!await _0x4c5efd['_isAvailable']())return!0x1;const _0x307844=await _0x4c5efd['_get'](_0x6507a)==='true';return await _0x4c5efd['_remove'](_0x6507a),_0x307844;}function Ip(_0x2ebbe4,_0x2a0e22){rn['set'](_0x2ebbe4['_key'](),_0x2a0e22);}function wp(_0x3e2f4a){return ne(_0x3e2f4a['_redirectPersistence']);}function Cp(_0xecf896){return sn(yp,_0xecf896['config']['apiKey'],_0xecf896['name']);}async function Tp(_0x45c36d,_0x1b36f2,_0xdf9888=!0x1){if(H(_0x45c36d['app']))return Promise['reject'](se(_0x45c36d));const _0x5a2ef7=qe(_0x45c36d),_0x42bfca=fp(_0x5a2ef7,_0x1b36f2),_0x236f25=await new vp(_0x5a2ef7,_0x42bfca,_0xdf9888)['execute']();return _0x236f25&&!_0xdf9888&&(delete _0x236f25['user']['_redirectEventId'],await _0x5a2ef7['_persistUserIfCurrent'](_0x236f25['user']),await _0x5a2ef7['_setRedirectUser'](null,_0x1b36f2)),_0x236f25;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x49df8f){this['auth']=_0x49df8f,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x596128){this['consumers']['add'](_0x596128),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x596128)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x596128),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3770a6){this['consumers']['delete'](_0x3770a6);}['onEvent'](_0x598947){if(this['hasEventBeenHandled'](_0x598947))return!0x1;let _0x5bec46=!0x1;return this['consumers']['forEach'](_0x21a0fc=>{this['isEventForConsumer'](_0x598947,_0x21a0fc)&&(_0x5bec46=!0x0,this['sendToConsumer'](_0x598947,_0x21a0fc),this['saveEventToCache'](_0x598947));}),this['hasHandledPotentialRedirect']||!Rp(_0x598947)||(this['hasHandledPotentialRedirect']=!0x0,_0x5bec46||(this['queuedRedirectEvent']=_0x598947,_0x5bec46=!0x0)),_0x5bec46;}['sendToConsumer'](_0x51b025,_0x57e59d){var _0x10b771;if(_0x51b025['error']&&!Qa(_0x51b025)){const _0x306a12=((_0x10b771=_0x51b025['error']['code'])==null?void 0x0:_0x10b771['split']('auth/')[0x1])||'internal-error';_0x57e59d['onError'](J(this['auth'],_0x306a12));}else _0x57e59d['onAuthEvent'](_0x51b025);}['isEventForConsumer'](_0x4a0ed0,_0xd403bd){const _0x6560d7=_0xd403bd['eventId']===null||!!_0x4a0ed0['eventId']&&_0x4a0ed0['eventId']===_0xd403bd['eventId'];return _0xd403bd['filter']['includes'](_0x4a0ed0['type'])&&_0x6560d7;}['hasEventBeenHandled'](_0x4ffa99){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x4ffa99));}['saveEventToCache'](_0x553995){this['cachedEventUids']['add'](Pr(_0x553995)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x44d380){return[_0x44d380['type'],_0x44d380['eventId'],_0x44d380['sessionId'],_0x44d380['tenantId']]['filter'](_0x118fe8=>_0x118fe8)['join']('-');}function Qa({type:_0x757414,error:_0x5bc6c4}){return _0x757414==='unknown'&&(_0x5bc6c4==null?void 0x0:_0x5bc6c4['code'])==='auth/no-auth-event';}function Rp(_0x318c7a){switch(_0x318c7a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x318c7a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4d15af,_0x47bb1d={}){return Ae(_0x4d15af,'GET','/v1/projects',_0x47bb1d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3202bd){if(_0x3202bd['config']['emulator'])return;const {authorizedDomains:_0xbae196}=await Ap(_0x3202bd);for(const _0x3e93ce of _0xbae196)try{if(Op(_0x3e93ce))return;}catch{}K(_0x3202bd,'unauthorized-domain');}function Op(_0xe12da6){const _0x13ad74=Ni(),{protocol:_0x2ed589,hostname:_0x594940}=new URL(_0x13ad74);if(_0xe12da6['startsWith']('chrome-extension://')){const _0x53277e=new URL(_0xe12da6);return _0x53277e['hostname']===''&&_0x594940===''?_0x2ed589==='chrome-extension:'&&_0xe12da6['replace']('chrome-extension://','')===_0x13ad74['replace']('chrome-extension://',''):_0x2ed589==='chrome-extension:'&&_0x53277e['hostname']===_0x594940;}if(!Np['test'](_0x2ed589))return!0x1;if(kp['test'](_0xe12da6))return _0x594940===_0xe12da6;const _0x245954=_0xe12da6['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x245954+'|'+_0x245954+')$','i')['test'](_0x594940);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x52a03c=X()['___jsl'];if(_0x52a03c!=null&&_0x52a03c['H']){for(const _0x957851 of Object['keys'](_0x52a03c['H']))if(_0x52a03c['H'][_0x957851]['r']=_0x52a03c['H'][_0x957851]['r']||[],_0x52a03c['H'][_0x957851]['L']=_0x52a03c['H'][_0x957851]['L']||[],_0x52a03c['H'][_0x957851]['r']=[..._0x52a03c['H'][_0x957851]['L']],_0x52a03c['CP']){for(let _0x4725d7=0x0;_0x4725d7<_0x52a03c['CP']['length'];_0x4725d7++)_0x52a03c['CP'][_0x4725d7]=null;}}}function Mp(_0x85f36b){return new Promise((_0x3e2259,_0x35b84a)=>{var _0x1d3612,_0x3a5b2a,_0x43a747;function _0x3d01e9(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3e2259(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x35b84a(J(_0x85f36b,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x3a5b2a=(_0x1d3612=X()['gapi'])==null?void 0x0:_0x1d3612['iframes'])!=null&&_0x3a5b2a['Iframe'])_0x3e2259(gapi['iframes']['getContext']());else{if((_0x43a747=X()['gapi'])!=null&&_0x43a747['load'])_0x3d01e9();else{const _0x690033=Nf('iframefcb');return X()[_0x690033]=()=>{gapi['load']?_0x3d01e9():_0x35b84a(J(_0x85f36b,'network-request-failed'));},Da(kf()+'?onload='+_0x690033)['catch'](_0x3bd6f6=>_0x35b84a(_0x3bd6f6));}}})['catch'](_0x35ed7c=>{throw on=null,_0x35ed7c;});}let on=null;function Lp(_0x4b676e){return on=on||Mp(_0x4b676e),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0xb82019){const _0x4e5a12=_0xb82019['config'];m(_0x4e5a12['authDomain'],_0xb82019,'auth-domain-config-required');const _0x28805c=_0x4e5a12['emulator']?Is(_0x4e5a12,Up):'https://'+_0xb82019['config']['authDomain']+'/'+Fp,_0x43ca48={'apiKey':_0x4e5a12['apiKey'],'appName':_0xb82019['name'],'v':ct},_0x38983a=Bp['get'](_0xb82019['config']['apiHost']);_0x38983a&&(_0x43ca48['eid']=_0x38983a);const _0x52671d=_0xb82019['_getFrameworks']();return _0x52671d['length']&&(_0x43ca48['fw']=_0x52671d['join'](',')),_0x28805c+'?'+at(_0x43ca48)['slice'](0x1);}async function Hp(_0xd00e49){const _0x59a3e2=await Lp(_0xd00e49),_0x823857=X()['gapi'];return m(_0x823857,_0xd00e49,'internal-error'),_0x59a3e2['open']({'where':document['body'],'url':Vp(_0xd00e49),'messageHandlersFilter':_0x823857['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5ecdfe=>new Promise(async(_0x3b3bab,_0x2df403)=>{await _0x5ecdfe['restyle']({'setHideOnLeave':!0x1});const _0x2c99c7=J(_0xd00e49,'network-request-failed'),_0x22fdea=X()['setTimeout'](()=>{_0x2df403(_0x2c99c7);},xp['get']());function _0x39eef1(){X()['clearTimeout'](_0x22fdea),_0x3b3bab(_0x5ecdfe);}_0x5ecdfe['ping'](_0x39eef1)['then'](_0x39eef1,()=>{_0x2df403(_0x2c99c7);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x2ba267){this['window']=_0x2ba267,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x5c2e1b,_0x13c1a0,_0x337836,_0x33ef87=Gp,_0x196094=qp){const _0x20fd50=Math['max']((window['screen']['availHeight']-_0x196094)/0x2,0x0)['toString'](),_0x4aa08e=Math['max']((window['screen']['availWidth']-_0x33ef87)/0x2,0x0)['toString']();let _0x549362='';const _0x4ed8a0={...$p,'width':_0x33ef87['toString'](),'height':_0x196094['toString'](),'top':_0x20fd50,'left':_0x4aa08e},_0x11601e=W()['toLowerCase']();_0x337836&&(_0x549362=ba(_0x11601e)?zp:_0x337836),Ta(_0x11601e)&&(_0x13c1a0=_0x13c1a0||jp,_0x4ed8a0['scrollbars']='yes');const _0x4b4b2a=Object['entries'](_0x4ed8a0)['reduce']((_0x421bca,[_0x1e51bd,_0x1340cd])=>''+_0x421bca+_0x1e51bd+'='+_0x1340cd+',','');if(Ef(_0x11601e)&&_0x549362!=='_self')return Yp(_0x13c1a0||'',_0x549362),new Dr(null);const _0x38e973=window['open'](_0x13c1a0||'',_0x549362,_0x4b4b2a);m(_0x38e973,_0x5c2e1b,'popup-blocked');try{_0x38e973['focus']();}catch{}return new Dr(_0x38e973);}function Yp(_0x3a09a6,_0x4ae32d){const _0xa02c53=document['createElement']('a');_0xa02c53['href']=_0x3a09a6,_0xa02c53['target']=_0x4ae32d;const _0x24c38e=document['createEvent']('MouseEvent');_0x24c38e['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xa02c53['dispatchEvent'](_0x24c38e);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x53e4a1,_0x4930bb,_0x34419d,_0x2c9931,_0x295868,_0x379f85){m(_0x53e4a1['config']['authDomain'],_0x53e4a1,'auth-domain-config-required'),m(_0x53e4a1['config']['apiKey'],_0x53e4a1,'invalid-api-key');const _0x3bdbc2={'apiKey':_0x53e4a1['config']['apiKey'],'appName':_0x53e4a1['name'],'authType':_0x34419d,'redirectUrl':_0x2c9931,'v':ct,'eventId':_0x295868};if(_0x4930bb instanceof xa){_0x4930bb['setDefaultLanguage'](_0x53e4a1['languageCode']),_0x3bdbc2['providerId']=_0x4930bb['providerId']||'',hi(_0x4930bb['getCustomParameters']())||(_0x3bdbc2['customParameters']=JSON['stringify'](_0x4930bb['getCustomParameters']()));for(const [_0x5605cd,_0x1fb1a6]of Object['entries']({}))_0x3bdbc2[_0x5605cd]=_0x1fb1a6;}if(_0x4930bb instanceof Qt){const _0x238d78=_0x4930bb['getScopes']()['filter'](_0x36d649=>_0x36d649!=='');_0x238d78['length']>0x0&&(_0x3bdbc2['scopes']=_0x238d78['join'](','));}_0x53e4a1['tenantId']&&(_0x3bdbc2['tid']=_0x53e4a1['tenantId']);const _0x554f74=_0x3bdbc2;for(const _0x455920 of Object['keys'](_0x554f74))_0x554f74[_0x455920]===void 0x0&&delete _0x554f74[_0x455920];const _0x2de300=await _0x53e4a1['_getAppCheckToken'](),_0x41ae75=_0x2de300?'#'+Xp+'='+encodeURIComponent(_0x2de300):'';return Zp(_0x53e4a1)+'?'+at(_0x554f74)['slice'](0x1)+_0x41ae75;}function Zp({config:_0x2781a3}){return _0x2781a3['emulator']?Is(_0x2781a3,Jp):'https://'+_0x2781a3['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x40b093,_0x301e3a,_0x3bcf25,_0x541ab8){var _0x50d3cc;ae((_0x50d3cc=this['eventManagers'][_0x40b093['_key']()])==null?void 0x0:_0x50d3cc['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2fe4a0=await Mr(_0x40b093,_0x301e3a,_0x3bcf25,Ni(),_0x541ab8);return Kp(_0x40b093,_0x2fe4a0,bs());}async['_openRedirect'](_0x3f58a8,_0x3d5c1e,_0x275ad3,_0x112ec7){await this['_originValidation'](_0x3f58a8);const _0x28aa79=await Mr(_0x3f58a8,_0x3d5c1e,_0x275ad3,Ni(),_0x112ec7);return ip(_0x28aa79),new Promise(()=>{});}['_initialize'](_0x285597){const _0x3d010b=_0x285597['_key']();if(this['eventManagers'][_0x3d010b]){const {manager:_0x16aab3,promise:_0x41b7e1}=this['eventManagers'][_0x3d010b];return _0x16aab3?Promise['resolve'](_0x16aab3):(ae(_0x41b7e1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x41b7e1);}const _0x3cdc7e=this['initAndGetManager'](_0x285597);return this['eventManagers'][_0x3d010b]={'promise':_0x3cdc7e},_0x3cdc7e['catch'](()=>{delete this['eventManagers'][_0x3d010b];}),_0x3cdc7e;}async['initAndGetManager'](_0x5b5e7b){const _0x349c96=await Hp(_0x5b5e7b),_0x41491d=new bp(_0x5b5e7b);return _0x349c96['register']('authEvent',_0x11894c=>(m(_0x11894c==null?void 0x0:_0x11894c['authEvent'],_0x5b5e7b,'invalid-auth-event'),{'status':_0x41491d['onEvent'](_0x11894c['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5b5e7b['_key']()]={'manager':_0x41491d},this['iframes'][_0x5b5e7b['_key']()]=_0x349c96,_0x41491d;}['_isIframeWebStorageSupported'](_0x25935d,_0x45ccb){this['iframes'][_0x25935d['_key']()]['send'](li,{'type':li},_0x4b48b7=>{var _0x42101c;const _0x134711=(_0x42101c=_0x4b48b7==null?void 0x0:_0x4b48b7[0x0])==null?void 0x0:_0x42101c[li];_0x134711!==void 0x0&&_0x45ccb(!!_0x134711),K(_0x25935d,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x10c27d){const _0x1110c4=_0x10c27d['_key']();return this['originValidationPromises'][_0x1110c4]||(this['originValidationPromises'][_0x1110c4]=Pp(_0x10c27d)),this['originValidationPromises'][_0x1110c4];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x444809){this['auth']=_0x444809,this['internalListeners']=new Map();}['getUid'](){var _0x6d00d7;return this['assertAuthConfigured'](),((_0x6d00d7=this['auth']['currentUser'])==null?void 0x0:_0x6d00d7['uid'])||null;}async['getToken'](_0x263d52){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x263d52)}:null;}['addAuthTokenListener'](_0x132a4b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x132a4b))return;const _0x1671d4=this['auth']['onIdTokenChanged'](_0x3ab5b=>{_0x132a4b((_0x3ab5b==null?void 0x0:_0x3ab5b['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x132a4b,_0x1671d4),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x19a2f9){this['assertAuthConfigured']();const _0x1d6c9b=this['internalListeners']['get'](_0x19a2f9);_0x1d6c9b&&(this['internalListeners']['delete'](_0x19a2f9),_0x1d6c9b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x49ddab){switch(_0x49ddab){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x191a80){et(new Me('auth',(_0x12a561,{options:_0x549690})=>{const _0x36da9f=_0x12a561['getProvider']('app')['getImmediate'](),_0x2560da=_0x12a561['getProvider']('heartbeat'),_0x559186=_0x12a561['getProvider']('app-check-internal'),{apiKey:_0x1432b3,authDomain:_0x184050}=_0x36da9f['options'];m(_0x1432b3&&!_0x1432b3['includes'](':'),'invalid-api-key',{'appName':_0x36da9f['name']});const _0x157807={'apiKey':_0x1432b3,'authDomain':_0x184050,'clientPlatform':_0x191a80,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x191a80)},_0x133211=new bf(_0x36da9f,_0x2560da,_0x559186,_0x157807);return Lf(_0x133211,_0x549690),_0x133211;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2eb2b1,_0x4a43b5,_0x32656e)=>{_0x2eb2b1['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1c7dee=>{const _0x57aa36=qe(_0x1c7dee['getProvider']('auth')['getImmediate']());return(_0x31851a=>new n_(_0x31851a))(_0x57aa36);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x191a80)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1e13bd=>async _0x1a93f0=>{const _0x65064d=_0x1a93f0&&await _0x1a93f0['getIdTokenResult'](),_0xa4e59e=_0x65064d&&(new Date()['getTime']()-Date['parse'](_0x65064d['issuedAtTime']))/0x3e8;if(_0xa4e59e&&_0xa4e59e>o_)return;const _0x5ab163=_0x65064d==null?void 0x0:_0x65064d['token'];Fr!==_0x5ab163&&(Fr=_0x5ab163,await fetch(_0x1e13bd,{'method':_0x5ab163?'POST':'DELETE','headers':_0x5ab163?{'Authorization':'Bearer\x20'+_0x5ab163}:{}}));};function O_(_0x38398c=Qr()){const _0x323e38=Ui(_0x38398c,'auth');if(_0x323e38['isInitialized']())return _0x323e38['getImmediate']();const _0x14a303=Mf(_0x38398c,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x1211c8=Gr('authTokenSyncURL');if(_0x1211c8&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x459da8=new URL(_0x1211c8,location['origin']);if(location['origin']===_0x459da8['origin']){const _0x54f686=a_(_0x459da8['toString']());Jf(_0x14a303,_0x54f686,()=>_0x54f686(_0x14a303['currentUser'])),Qf(_0x14a303,_0xe52d70=>_0x54f686(_0xe52d70));}}const _0x5f55a6=Hr('auth');return _0x5f55a6&&xf(_0x14a303,'http://'+_0x5f55a6),_0x14a303;}function c_(){var _0x47f35b;return((_0x47f35b=document['getElementsByTagName']('head'))==null?void 0x0:_0x47f35b[0x0])??document;}Rf({'loadJS'(_0x291c32){return new Promise((_0x160e39,_0x4bbd79)=>{const _0xdcb435=document['createElement']('script');_0xdcb435['setAttribute']('src',_0x291c32),_0xdcb435['onload']=_0x160e39,_0xdcb435['onerror']=_0x37cb93=>{const _0x272545=J('internal-error');_0x272545['customData']=_0x37cb93,_0x4bbd79(_0x272545);},_0xdcb435['type']='text/javascript',_0xdcb435['charset']='UTF-8',c_()['appendChild'](_0xdcb435);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};