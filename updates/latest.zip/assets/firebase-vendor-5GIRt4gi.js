const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3bc79a,_0x2bbd3a){if(!_0x3bc79a)throw ot(_0x2bbd3a);},ot=function(_0x146aa3){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x146aa3);},Wr=function(_0x5e399b){const _0x35dbbe=[];let _0x1ad91b=0x0;for(let _0x13b7fe=0x0;_0x13b7fe<_0x5e399b['length'];_0x13b7fe++){let _0x261f9b=_0x5e399b['charCodeAt'](_0x13b7fe);_0x261f9b<0x80?_0x35dbbe[_0x1ad91b++]=_0x261f9b:_0x261f9b<0x800?(_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0x6|0xc0,_0x35dbbe[_0x1ad91b++]=_0x261f9b&0x3f|0x80):(_0x261f9b&0xfc00)===0xd800&&_0x13b7fe+0x1<_0x5e399b['length']&&(_0x5e399b['charCodeAt'](_0x13b7fe+0x1)&0xfc00)===0xdc00?(_0x261f9b=0x10000+((_0x261f9b&0x3ff)<<0xa)+(_0x5e399b['charCodeAt'](++_0x13b7fe)&0x3ff),_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0x12|0xf0,_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0xc&0x3f|0x80,_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0x6&0x3f|0x80,_0x35dbbe[_0x1ad91b++]=_0x261f9b&0x3f|0x80):(_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0xc|0xe0,_0x35dbbe[_0x1ad91b++]=_0x261f9b>>0x6&0x3f|0x80,_0x35dbbe[_0x1ad91b++]=_0x261f9b&0x3f|0x80);}return _0x35dbbe;},Za=function(_0x39c3d6){const _0x426a84=[];let _0x163c03=0x0,_0x299dae=0x0;for(;_0x163c03<_0x39c3d6['length'];){const _0x1583b4=_0x39c3d6[_0x163c03++];if(_0x1583b4<0x80)_0x426a84[_0x299dae++]=String['fromCharCode'](_0x1583b4);else{if(_0x1583b4>0xbf&&_0x1583b4<0xe0){const _0x1195d7=_0x39c3d6[_0x163c03++];_0x426a84[_0x299dae++]=String['fromCharCode']((_0x1583b4&0x1f)<<0x6|_0x1195d7&0x3f);}else{if(_0x1583b4>0xef&&_0x1583b4<0x16d){const _0x421f1e=_0x39c3d6[_0x163c03++],_0x2d80d9=_0x39c3d6[_0x163c03++],_0x5abb33=_0x39c3d6[_0x163c03++],_0x2a3072=((_0x1583b4&0x7)<<0x12|(_0x421f1e&0x3f)<<0xc|(_0x2d80d9&0x3f)<<0x6|_0x5abb33&0x3f)-0x10000;_0x426a84[_0x299dae++]=String['fromCharCode'](0xd800+(_0x2a3072>>0xa)),_0x426a84[_0x299dae++]=String['fromCharCode'](0xdc00+(_0x2a3072&0x3ff));}else{const _0x39fe3d=_0x39c3d6[_0x163c03++],_0x795258=_0x39c3d6[_0x163c03++];_0x426a84[_0x299dae++]=String['fromCharCode']((_0x1583b4&0xf)<<0xc|(_0x39fe3d&0x3f)<<0x6|_0x795258&0x3f);}}}}return _0x426a84['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2f9905,_0x187829){if(!Array['isArray'](_0x2f9905))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1de569=_0x187829?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3f4810=[];for(let _0x16531e=0x0;_0x16531e<_0x2f9905['length'];_0x16531e+=0x3){const _0x31ef97=_0x2f9905[_0x16531e],_0x55bade=_0x16531e+0x1<_0x2f9905['length'],_0x169263=_0x55bade?_0x2f9905[_0x16531e+0x1]:0x0,_0x2ac212=_0x16531e+0x2<_0x2f9905['length'],_0x2b6ed0=_0x2ac212?_0x2f9905[_0x16531e+0x2]:0x0,_0x2e047f=_0x31ef97>>0x2,_0x3eeced=(_0x31ef97&0x3)<<0x4|_0x169263>>0x4;let _0x598af4=(_0x169263&0xf)<<0x2|_0x2b6ed0>>0x6,_0x2a22aa=_0x2b6ed0&0x3f;_0x2ac212||(_0x2a22aa=0x40,_0x55bade||(_0x598af4=0x40)),_0x3f4810['push'](_0x1de569[_0x2e047f],_0x1de569[_0x3eeced],_0x1de569[_0x598af4],_0x1de569[_0x2a22aa]);}return _0x3f4810['join']('');},'encodeString'(_0x2d3d7e,_0x2a3d90){return this['HAS_NATIVE_SUPPORT']&&!_0x2a3d90?btoa(_0x2d3d7e):this['encodeByteArray'](Wr(_0x2d3d7e),_0x2a3d90);},'decodeString'(_0x11a90c,_0x4a21da){return this['HAS_NATIVE_SUPPORT']&&!_0x4a21da?atob(_0x11a90c):Za(this['decodeStringToByteArray'](_0x11a90c,_0x4a21da));},'decodeStringToByteArray'(_0x23df1b,_0x6f9fd9){this['init_']();const _0x333ae7=_0x6f9fd9?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x57df5d=[];for(let _0x37e7f5=0x0;_0x37e7f5<_0x23df1b['length'];){const _0x46d19c=_0x333ae7[_0x23df1b['charAt'](_0x37e7f5++)],_0xc18403=_0x37e7f5<_0x23df1b['length']?_0x333ae7[_0x23df1b['charAt'](_0x37e7f5)]:0x0;++_0x37e7f5;const _0x43d0a5=_0x37e7f5<_0x23df1b['length']?_0x333ae7[_0x23df1b['charAt'](_0x37e7f5)]:0x40;++_0x37e7f5;const _0x14f914=_0x37e7f5<_0x23df1b['length']?_0x333ae7[_0x23df1b['charAt'](_0x37e7f5)]:0x40;if(++_0x37e7f5,_0x46d19c==null||_0xc18403==null||_0x43d0a5==null||_0x14f914==null)throw new ec();const _0x385f07=_0x46d19c<<0x2|_0xc18403>>0x4;if(_0x57df5d['push'](_0x385f07),_0x43d0a5!==0x40){const _0x5c50f7=_0xc18403<<0x4&0xf0|_0x43d0a5>>0x2;if(_0x57df5d['push'](_0x5c50f7),_0x14f914!==0x40){const _0x3abf68=_0x43d0a5<<0x6&0xc0|_0x14f914;_0x57df5d['push'](_0x3abf68);}}}return _0x57df5d;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2ea1e7=0x0;_0x2ea1e7<this['ENCODED_VALS']['length'];_0x2ea1e7++)this['byteToCharMap_'][_0x2ea1e7]=this['ENCODED_VALS']['charAt'](_0x2ea1e7),this['charToByteMap_'][this['byteToCharMap_'][_0x2ea1e7]]=_0x2ea1e7,this['byteToCharMapWebSafe_'][_0x2ea1e7]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2ea1e7),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2ea1e7]]=_0x2ea1e7,_0x2ea1e7>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2ea1e7)]=_0x2ea1e7,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2ea1e7)]=_0x2ea1e7);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x2d5ae4){const _0x1220fa=Wr(_0x2d5ae4);return Di['encodeByteArray'](_0x1220fa,!0x0);},an=function(_0x2f7939){return Br(_0x2f7939)['replace'](/\./g,'');},cn=function(_0xb703d5){try{return Di['decodeString'](_0xb703d5,!0x0);}catch(_0x95f8c0){console['error']('base64Decode\x20failed:\x20',_0x95f8c0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3c6667){return Vr(void 0x0,_0x3c6667);}function Vr(_0x5004fd,_0x2b673d){if(!(_0x2b673d instanceof Object))return _0x2b673d;switch(_0x2b673d['constructor']){case Date:const _0x46e144=_0x2b673d;return new Date(_0x46e144['getTime']());case Object:_0x5004fd===void 0x0&&(_0x5004fd={});break;case Array:_0x5004fd=[];break;default:return _0x2b673d;}for(const _0x3bdbe8 in _0x2b673d)!_0x2b673d['hasOwnProperty'](_0x3bdbe8)||!nc(_0x3bdbe8)||(_0x5004fd[_0x3bdbe8]=Vr(_0x5004fd[_0x3bdbe8],_0x2b673d[_0x3bdbe8]));return _0x5004fd;}function nc(_0x2fe235){return _0x2fe235!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x5d0f4b=As['__FIREBASE_DEFAULTS__'];if(_0x5d0f4b)return JSON['parse'](_0x5d0f4b);},oc=()=>{if(typeof document>'u')return;let _0x2932b5;try{_0x2932b5=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3acd0d=_0x2932b5&&cn(_0x2932b5[0x1]);return _0x3acd0d&&JSON['parse'](_0x3acd0d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x43c66d){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x43c66d);return;}},Hr=_0x2ddebc=>{var _0x20805a,_0x9979aa;return(_0x9979aa=(_0x20805a=Mi())==null?void 0x0:_0x20805a['emulatorHosts'])==null?void 0x0:_0x9979aa[_0x2ddebc];},ac=_0x48b8ac=>{const _0x1db959=Hr(_0x48b8ac);if(!_0x1db959)return;const _0xd6b6c2=_0x1db959['lastIndexOf'](':');if(_0xd6b6c2<=0x0||_0xd6b6c2+0x1===_0x1db959['length'])throw new Error('Invalid\x20host\x20'+_0x1db959+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1eb928=parseInt(_0x1db959['substring'](_0xd6b6c2+0x1),0xa);return _0x1db959[0x0]==='['?[_0x1db959['substring'](0x1,_0xd6b6c2-0x1),_0x1eb928]:[_0x1db959['substring'](0x0,_0xd6b6c2),_0x1eb928];},$r=()=>{var _0x1fcdb3;return(_0x1fcdb3=Mi())==null?void 0x0:_0x1fcdb3['config'];},Gr=_0x1011da=>{var _0x458767;return(_0x458767=Mi())==null?void 0x0:_0x458767['_'+_0x1011da];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x11b842,_0x1480ef)=>{this['resolve']=_0x11b842,this['reject']=_0x1480ef;});}['wrapCallback'](_0x3914a6){return(_0x40bfa1,_0x215ab7)=>{_0x40bfa1?this['reject'](_0x40bfa1):this['resolve'](_0x215ab7),typeof _0x3914a6=='function'&&(this['promise']['catch'](()=>{}),_0x3914a6['length']===0x1?_0x3914a6(_0x40bfa1):_0x3914a6(_0x40bfa1,_0x215ab7));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x77542c,_0x42d10a){if(_0x77542c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x466919={'alg':'none','type':'JWT'},_0x9185d2=_0x42d10a||'demo-project',_0x4ac2b6=_0x77542c['iat']||0x0,_0x3b828b=_0x77542c['sub']||_0x77542c['user_id'];if(!_0x3b828b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x27d105={'iss':'https://securetoken.google.com/'+_0x9185d2,'aud':_0x9185d2,'iat':_0x4ac2b6,'exp':_0x4ac2b6+0xe10,'auth_time':_0x4ac2b6,'sub':_0x3b828b,'user_id':_0x3b828b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x77542c};return[an(JSON['stringify'](_0x466919)),an(JSON['stringify'](_0x27d105)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x94969f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x94969f=='object'&&_0x94969f['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1da527=W();return _0x1da527['indexOf']('MSIE\x20')>=0x0||_0x1da527['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x1c8333,_0xcd5ab1)=>{try{let _0x552609=!0x0;const _0x387dbd='validate-browser-context-for-indexeddb-analytics-module',_0x2aaf28=self['indexedDB']['open'](_0x387dbd);_0x2aaf28['onsuccess']=()=>{_0x2aaf28['result']['close'](),_0x552609||self['indexedDB']['deleteDatabase'](_0x387dbd),_0x1c8333(!0x0);},_0x2aaf28['onupgradeneeded']=()=>{_0x552609=!0x1;},_0x2aaf28['onerror']=()=>{var _0x51a248;_0xcd5ab1(((_0x51a248=_0x2aaf28['error'])==null?void 0x0:_0x51a248['message'])||'');};}catch(_0x38d00a){_0xcd5ab1(_0x38d00a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x58c336,_0x43747a,_0x5168c6){super(_0x43747a),this['code']=_0x58c336,this['customData']=_0x5168c6,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4b7b31,_0x19b815,_0x8ea2d){this['service']=_0x4b7b31,this['serviceName']=_0x19b815,this['errors']=_0x8ea2d;}['create'](_0x6121f9,..._0x5f3315){const _0x33fdcb=_0x5f3315[0x0]||{},_0x558329=this['service']+'/'+_0x6121f9,_0x4c0982=this['errors'][_0x6121f9],_0x33eb51=_0x4c0982?gc(_0x4c0982,_0x33fdcb):'Error',_0x49f6af=this['serviceName']+':\x20'+_0x33eb51+'\x20('+_0x558329+').';return new Se(_0x558329,_0x49f6af,_0x33fdcb);}}function gc(_0x1537f1,_0x55482d){return _0x1537f1['replace'](mc,(_0x200bfe,_0x5e4253)=>{const _0x5c2939=_0x55482d[_0x5e4253];return _0x5c2939!=null?String(_0x5c2939):'<'+_0x5e4253+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x48dd81){return JSON['parse'](_0x48dd81);}function O(_0xf6d8d7){return JSON['stringify'](_0xf6d8d7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x20b126){let _0x3c4f93={},_0x4eda1f={},_0x3d4978={},_0x3aec64='';try{const _0x5452b8=_0x20b126['split']('.');_0x3c4f93=bt(cn(_0x5452b8[0x0])||''),_0x4eda1f=bt(cn(_0x5452b8[0x1])||''),_0x3aec64=_0x5452b8[0x2],_0x3d4978=_0x4eda1f['d']||{},delete _0x4eda1f['d'];}catch{}return{'header':_0x3c4f93,'claims':_0x4eda1f,'data':_0x3d4978,'signature':_0x3aec64};},yc=function(_0x6d4c81){const _0x27b574=zr(_0x6d4c81),_0x277294=_0x27b574['claims'];return!!_0x277294&&typeof _0x277294=='object'&&_0x277294['hasOwnProperty']('iat');},vc=function(_0xb70557){const _0x51e71d=zr(_0xb70557)['claims'];return typeof _0x51e71d=='object'&&_0x51e71d['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x333b93,_0x1909d3){return Object['prototype']['hasOwnProperty']['call'](_0x333b93,_0x1909d3);}function Oe(_0x2a960e,_0x1c4500){if(Object['prototype']['hasOwnProperty']['call'](_0x2a960e,_0x1c4500))return _0x2a960e[_0x1c4500];}function hi(_0x5c3211){for(const _0x128484 in _0x5c3211)if(Object['prototype']['hasOwnProperty']['call'](_0x5c3211,_0x128484))return!0x1;return!0x0;}function ln(_0x6d25f9,_0x3aab85,_0x4823ca){const _0xff92b4={};for(const _0x4686c8 in _0x6d25f9)Object['prototype']['hasOwnProperty']['call'](_0x6d25f9,_0x4686c8)&&(_0xff92b4[_0x4686c8]=_0x3aab85['call'](_0x4823ca,_0x6d25f9[_0x4686c8],_0x4686c8,_0x6d25f9));return _0xff92b4;}function De(_0x56eefc,_0x216a31){if(_0x56eefc===_0x216a31)return!0x0;const _0x3fa384=Object['keys'](_0x56eefc),_0x378935=Object['keys'](_0x216a31);for(const _0x18c654 of _0x3fa384){if(!_0x378935['includes'](_0x18c654))return!0x1;const _0x4be1be=_0x56eefc[_0x18c654],_0x59b3f1=_0x216a31[_0x18c654];if(ks(_0x4be1be)&&ks(_0x59b3f1)){if(!De(_0x4be1be,_0x59b3f1))return!0x1;}else{if(_0x4be1be!==_0x59b3f1)return!0x1;}}for(const _0x2964d6 of _0x378935)if(!_0x3fa384['includes'](_0x2964d6))return!0x1;return!0x0;}function ks(_0x2c9a8e){return _0x2c9a8e!==null&&typeof _0x2c9a8e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x588d0a){const _0x52149c=[];for(const [_0x9f7b2e,_0x3244c0]of Object['entries'](_0x588d0a))Array['isArray'](_0x3244c0)?_0x3244c0['forEach'](_0x15f404=>{_0x52149c['push'](encodeURIComponent(_0x9f7b2e)+'='+encodeURIComponent(_0x15f404));}):_0x52149c['push'](encodeURIComponent(_0x9f7b2e)+'='+encodeURIComponent(_0x3244c0));return _0x52149c['length']?'&'+_0x52149c['join']('&'):'';}function yt(_0x407155){const _0x765b29={};return _0x407155['replace'](/^\?/,'')['split']('&')['forEach'](_0x41fc64=>{if(_0x41fc64){const [_0x6c054f,_0x51bee1]=_0x41fc64['split']('=');_0x765b29[decodeURIComponent(_0x6c054f)]=decodeURIComponent(_0x51bee1);}}),_0x765b29;}function vt(_0x1c6933){const _0x497e03=_0x1c6933['indexOf']('?');if(!_0x497e03)return'';const _0xfcd218=_0x1c6933['indexOf']('#',_0x497e03);return _0x1c6933['substring'](_0x497e03,_0xfcd218>0x0?_0xfcd218:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5307f2=0x1;_0x5307f2<this['blockSize'];++_0x5307f2)this['pad_'][_0x5307f2]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2bbd28,_0x517835){_0x517835||(_0x517835=0x0);const _0x21c847=this['W_'];if(typeof _0x2bbd28=='string'){for(let _0x36d579=0x0;_0x36d579<0x10;_0x36d579++)_0x21c847[_0x36d579]=_0x2bbd28['charCodeAt'](_0x517835)<<0x18|_0x2bbd28['charCodeAt'](_0x517835+0x1)<<0x10|_0x2bbd28['charCodeAt'](_0x517835+0x2)<<0x8|_0x2bbd28['charCodeAt'](_0x517835+0x3),_0x517835+=0x4;}else{for(let _0x2aee28=0x0;_0x2aee28<0x10;_0x2aee28++)_0x21c847[_0x2aee28]=_0x2bbd28[_0x517835]<<0x18|_0x2bbd28[_0x517835+0x1]<<0x10|_0x2bbd28[_0x517835+0x2]<<0x8|_0x2bbd28[_0x517835+0x3],_0x517835+=0x4;}for(let _0x477b71=0x10;_0x477b71<0x50;_0x477b71++){const _0x4fd9fe=_0x21c847[_0x477b71-0x3]^_0x21c847[_0x477b71-0x8]^_0x21c847[_0x477b71-0xe]^_0x21c847[_0x477b71-0x10];_0x21c847[_0x477b71]=(_0x4fd9fe<<0x1|_0x4fd9fe>>>0x1f)&0xffffffff;}let _0x5caed9=this['chain_'][0x0],_0x1eb9df=this['chain_'][0x1],_0x4c81c0=this['chain_'][0x2],_0x47872a=this['chain_'][0x3],_0x4d349a=this['chain_'][0x4],_0x33b2d9,_0xf79eac;for(let _0x32cc0a=0x0;_0x32cc0a<0x50;_0x32cc0a++){_0x32cc0a<0x28?_0x32cc0a<0x14?(_0x33b2d9=_0x47872a^_0x1eb9df&(_0x4c81c0^_0x47872a),_0xf79eac=0x5a827999):(_0x33b2d9=_0x1eb9df^_0x4c81c0^_0x47872a,_0xf79eac=0x6ed9eba1):_0x32cc0a<0x3c?(_0x33b2d9=_0x1eb9df&_0x4c81c0|_0x47872a&(_0x1eb9df|_0x4c81c0),_0xf79eac=0x8f1bbcdc):(_0x33b2d9=_0x1eb9df^_0x4c81c0^_0x47872a,_0xf79eac=0xca62c1d6);const _0x258a56=(_0x5caed9<<0x5|_0x5caed9>>>0x1b)+_0x33b2d9+_0x4d349a+_0xf79eac+_0x21c847[_0x32cc0a]&0xffffffff;_0x4d349a=_0x47872a,_0x47872a=_0x4c81c0,_0x4c81c0=(_0x1eb9df<<0x1e|_0x1eb9df>>>0x2)&0xffffffff,_0x1eb9df=_0x5caed9,_0x5caed9=_0x258a56;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5caed9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1eb9df&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4c81c0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x47872a&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4d349a&0xffffffff;}['update'](_0x34eeb0,_0x579417){if(_0x34eeb0==null)return;_0x579417===void 0x0&&(_0x579417=_0x34eeb0['length']);const _0x481206=_0x579417-this['blockSize'];let _0x17860d=0x0;const _0x44c247=this['buf_'];let _0x29b3bc=this['inbuf_'];for(;_0x17860d<_0x579417;){if(_0x29b3bc===0x0){for(;_0x17860d<=_0x481206;)this['compress_'](_0x34eeb0,_0x17860d),_0x17860d+=this['blockSize'];}if(typeof _0x34eeb0=='string'){for(;_0x17860d<_0x579417;)if(_0x44c247[_0x29b3bc]=_0x34eeb0['charCodeAt'](_0x17860d),++_0x29b3bc,++_0x17860d,_0x29b3bc===this['blockSize']){this['compress_'](_0x44c247),_0x29b3bc=0x0;break;}}else{for(;_0x17860d<_0x579417;)if(_0x44c247[_0x29b3bc]=_0x34eeb0[_0x17860d],++_0x29b3bc,++_0x17860d,_0x29b3bc===this['blockSize']){this['compress_'](_0x44c247),_0x29b3bc=0x0;break;}}}this['inbuf_']=_0x29b3bc,this['total_']+=_0x579417;}['digest'](){const _0x4ce358=[];let _0x553cb1=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4e37a9=this['blockSize']-0x1;_0x4e37a9>=0x38;_0x4e37a9--)this['buf_'][_0x4e37a9]=_0x553cb1&0xff,_0x553cb1/=0x100;this['compress_'](this['buf_']);let _0x2b5f4a=0x0;for(let _0x36d9f0=0x0;_0x36d9f0<0x5;_0x36d9f0++)for(let _0x4aaf2c=0x18;_0x4aaf2c>=0x0;_0x4aaf2c-=0x8)_0x4ce358[_0x2b5f4a]=this['chain_'][_0x36d9f0]>>_0x4aaf2c&0xff,++_0x2b5f4a;return _0x4ce358;}}function Ic(_0x3df597,_0x5f4dd9){const _0x4fb52f=new wc(_0x3df597,_0x5f4dd9);return _0x4fb52f['subscribe']['bind'](_0x4fb52f);}class wc{constructor(_0x50bd96,_0x39d75d){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x39d75d,this['task']['then'](()=>{_0x50bd96(this);})['catch'](_0x2a2c4f=>{this['error'](_0x2a2c4f);});}['next'](_0x363d41){this['forEachObserver'](_0x94a489=>{_0x94a489['next'](_0x363d41);});}['error'](_0x6b1880){this['forEachObserver'](_0x6c8e9d=>{_0x6c8e9d['error'](_0x6b1880);}),this['close'](_0x6b1880);}['complete'](){this['forEachObserver'](_0x1f8793=>{_0x1f8793['complete']();}),this['close']();}['subscribe'](_0x300f52,_0x2cf427,_0x362939){let _0x3c5a20;if(_0x300f52===void 0x0&&_0x2cf427===void 0x0&&_0x362939===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x300f52,['next','error','complete'])?_0x3c5a20=_0x300f52:_0x3c5a20={'next':_0x300f52,'error':_0x2cf427,'complete':_0x362939},_0x3c5a20['next']===void 0x0&&(_0x3c5a20['next']=Qn),_0x3c5a20['error']===void 0x0&&(_0x3c5a20['error']=Qn),_0x3c5a20['complete']===void 0x0&&(_0x3c5a20['complete']=Qn);const _0x29a150=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3c5a20['error'](this['finalError']):_0x3c5a20['complete']();}catch{}}),this['observers']['push'](_0x3c5a20),_0x29a150;}['unsubscribeOne'](_0x35c91f){this['observers']===void 0x0||this['observers'][_0x35c91f]===void 0x0||(delete this['observers'][_0x35c91f],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x10815f){if(!this['finalized']){for(let _0x2fe562=0x0;_0x2fe562<this['observers']['length'];_0x2fe562++)this['sendOne'](_0x2fe562,_0x10815f);}}['sendOne'](_0xa30a67,_0x5b7441){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xa30a67]!==void 0x0)try{_0x5b7441(this['observers'][_0xa30a67]);}catch(_0x42fb56){typeof console<'u'&&console['error']&&console['error'](_0x42fb56);}});}['close'](_0x267157){this['finalized']||(this['finalized']=!0x0,_0x267157!==void 0x0&&(this['finalError']=_0x267157),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1f3f30,_0x394f08){if(typeof _0x1f3f30!='object'||_0x1f3f30===null)return!0x1;for(const _0x3b63e3 of _0x394f08)if(_0x3b63e3 in _0x1f3f30&&typeof _0x1f3f30[_0x3b63e3]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x1503f9,_0x14c018){return _0x1503f9+'\x20failed:\x20'+_0x14c018+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x5c5795){const _0x129a19=[];let _0x400ebb=0x0;for(let _0x3da60d=0x0;_0x3da60d<_0x5c5795['length'];_0x3da60d++){let _0x1510d8=_0x5c5795['charCodeAt'](_0x3da60d);if(_0x1510d8>=0xd800&&_0x1510d8<=0xdbff){const _0x71d899=_0x1510d8-0xd800;_0x3da60d++,f(_0x3da60d<_0x5c5795['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5102c2=_0x5c5795['charCodeAt'](_0x3da60d)-0xdc00;_0x1510d8=0x10000+(_0x71d899<<0xa)+_0x5102c2;}_0x1510d8<0x80?_0x129a19[_0x400ebb++]=_0x1510d8:_0x1510d8<0x800?(_0x129a19[_0x400ebb++]=_0x1510d8>>0x6|0xc0,_0x129a19[_0x400ebb++]=_0x1510d8&0x3f|0x80):_0x1510d8<0x10000?(_0x129a19[_0x400ebb++]=_0x1510d8>>0xc|0xe0,_0x129a19[_0x400ebb++]=_0x1510d8>>0x6&0x3f|0x80,_0x129a19[_0x400ebb++]=_0x1510d8&0x3f|0x80):(_0x129a19[_0x400ebb++]=_0x1510d8>>0x12|0xf0,_0x129a19[_0x400ebb++]=_0x1510d8>>0xc&0x3f|0x80,_0x129a19[_0x400ebb++]=_0x1510d8>>0x6&0x3f|0x80,_0x129a19[_0x400ebb++]=_0x1510d8&0x3f|0x80);}return _0x129a19;},Pn=function(_0x5941c6){let _0xfd50e7=0x0;for(let _0x58ee2c=0x0;_0x58ee2c<_0x5941c6['length'];_0x58ee2c++){const _0x371f7d=_0x5941c6['charCodeAt'](_0x58ee2c);_0x371f7d<0x80?_0xfd50e7++:_0x371f7d<0x800?_0xfd50e7+=0x2:_0x371f7d>=0xd800&&_0x371f7d<=0xdbff?(_0xfd50e7+=0x4,_0x58ee2c++):_0xfd50e7+=0x3;}return _0xfd50e7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x1de3e7){return _0x1de3e7&&_0x1de3e7['_delegate']?_0x1de3e7['_delegate']:_0x1de3e7;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x9a912d){try{return(_0x9a912d['startsWith']('http://')||_0x9a912d['startsWith']('https://')?new URL(_0x9a912d)['hostname']:_0x9a912d)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x49a315){return(await fetch(_0x49a315,{'credentials':'include'}))['ok'];}class Me{constructor(_0x2caa6d,_0x4baa04,_0x2e60fb){this['name']=_0x2caa6d,this['instanceFactory']=_0x4baa04,this['type']=_0x2e60fb,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4bdc38){return this['instantiationMode']=_0x4bdc38,this;}['setMultipleInstances'](_0x53b37a){return this['multipleInstances']=_0x53b37a,this;}['setServiceProps'](_0x2ff919){return this['serviceProps']=_0x2ff919,this;}['setInstanceCreatedCallback'](_0x232c5e){return this['onInstanceCreated']=_0x232c5e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4c51da,_0x3515e3){this['name']=_0x4c51da,this['container']=_0x3515e3,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x59735f){const _0x24ca0f=this['normalizeInstanceIdentifier'](_0x59735f);if(!this['instancesDeferred']['has'](_0x24ca0f)){const _0xf80138=new Ve();if(this['instancesDeferred']['set'](_0x24ca0f,_0xf80138),this['isInitialized'](_0x24ca0f)||this['shouldAutoInitialize']())try{const _0x53c565=this['getOrInitializeService']({'instanceIdentifier':_0x24ca0f});_0x53c565&&_0xf80138['resolve'](_0x53c565);}catch{}}return this['instancesDeferred']['get'](_0x24ca0f)['promise'];}['getImmediate'](_0x41a34b){const _0xcd076c=this['normalizeInstanceIdentifier'](_0x41a34b==null?void 0x0:_0x41a34b['identifier']),_0x5aab9c=(_0x41a34b==null?void 0x0:_0x41a34b['optional'])??!0x1;if(this['isInitialized'](_0xcd076c)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xcd076c});}catch(_0x206a64){if(_0x5aab9c)return null;throw _0x206a64;}else{if(_0x5aab9c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x317d9c){if(_0x317d9c['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x317d9c['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x317d9c,!!this['shouldAutoInitialize']()){if(Rc(_0x317d9c))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x211c1c,_0x192a12]of this['instancesDeferred']['entries']()){const _0x5a4208=this['normalizeInstanceIdentifier'](_0x211c1c);try{const _0x440cce=this['getOrInitializeService']({'instanceIdentifier':_0x5a4208});_0x192a12['resolve'](_0x440cce);}catch{}}}}['clearInstance'](_0x2b9436=ke){this['instancesDeferred']['delete'](_0x2b9436),this['instancesOptions']['delete'](_0x2b9436),this['instances']['delete'](_0x2b9436);}async['delete'](){const _0x47e7fd=Array['from'](this['instances']['values']());await Promise['all']([..._0x47e7fd['filter'](_0x1ab7b9=>'INTERNAL'in _0x1ab7b9)['map'](_0x46da81=>_0x46da81['INTERNAL']['delete']()),..._0x47e7fd['filter'](_0x253db8=>'_delete'in _0x253db8)['map'](_0xbefee3=>_0xbefee3['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2b960f=ke){return this['instances']['has'](_0x2b960f);}['getOptions'](_0x41170e=ke){return this['instancesOptions']['get'](_0x41170e)||{};}['initialize'](_0x49d668={}){const {options:_0x1f72ef={}}=_0x49d668,_0x427de0=this['normalizeInstanceIdentifier'](_0x49d668['instanceIdentifier']);if(this['isInitialized'](_0x427de0))throw Error(this['name']+'('+_0x427de0+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x353d5a=this['getOrInitializeService']({'instanceIdentifier':_0x427de0,'options':_0x1f72ef});for(const [_0x1266c9,_0x3e686b]of this['instancesDeferred']['entries']()){const _0x25009c=this['normalizeInstanceIdentifier'](_0x1266c9);_0x427de0===_0x25009c&&_0x3e686b['resolve'](_0x353d5a);}return _0x353d5a;}['onInit'](_0x457536,_0x1476a4){const _0x45d67f=this['normalizeInstanceIdentifier'](_0x1476a4),_0x269240=this['onInitCallbacks']['get'](_0x45d67f)??new Set();_0x269240['add'](_0x457536),this['onInitCallbacks']['set'](_0x45d67f,_0x269240);const _0xf5c3e7=this['instances']['get'](_0x45d67f);return _0xf5c3e7&&_0x457536(_0xf5c3e7,_0x45d67f),()=>{_0x269240['delete'](_0x457536);};}['invokeOnInitCallbacks'](_0x3d0f8e,_0x42415f){const _0x1efa75=this['onInitCallbacks']['get'](_0x42415f);if(_0x1efa75){for(const _0x528d69 of _0x1efa75)try{_0x528d69(_0x3d0f8e,_0x42415f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x512ac1,options:_0x4074a5={}}){let _0x16b5aa=this['instances']['get'](_0x512ac1);if(!_0x16b5aa&&this['component']&&(_0x16b5aa=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x512ac1),'options':_0x4074a5}),this['instances']['set'](_0x512ac1,_0x16b5aa),this['instancesOptions']['set'](_0x512ac1,_0x4074a5),this['invokeOnInitCallbacks'](_0x16b5aa,_0x512ac1),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x512ac1,_0x16b5aa);}catch{}return _0x16b5aa||null;}['normalizeInstanceIdentifier'](_0x265c0e=ke){return this['component']?this['component']['multipleInstances']?_0x265c0e:ke:_0x265c0e;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2098ca){return _0x2098ca===ke?void 0x0:_0x2098ca;}function Rc(_0x35fbe9){return _0x35fbe9['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4c99f0){this['name']=_0x4c99f0,this['providers']=new Map();}['addComponent'](_0xc0bce7){const _0x723b98=this['getProvider'](_0xc0bce7['name']);if(_0x723b98['isComponentSet']())throw new Error('Component\x20'+_0xc0bce7['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x723b98['setComponent'](_0xc0bce7);}['addOrOverwriteComponent'](_0x4fbd0c){this['getProvider'](_0x4fbd0c['name'])['isComponentSet']()&&this['providers']['delete'](_0x4fbd0c['name']),this['addComponent'](_0x4fbd0c);}['getProvider'](_0x28235b){if(this['providers']['has'](_0x28235b))return this['providers']['get'](_0x28235b);const _0x1ba9ac=new Sc(_0x28235b,this);return this['providers']['set'](_0x28235b,_0x1ba9ac),_0x1ba9ac;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x355636){_0x355636[_0x355636['DEBUG']=0x0]='DEBUG',_0x355636[_0x355636['VERBOSE']=0x1]='VERBOSE',_0x355636[_0x355636['INFO']=0x2]='INFO',_0x355636[_0x355636['WARN']=0x3]='WARN',_0x355636[_0x355636['ERROR']=0x4]='ERROR',_0x355636[_0x355636['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x26c800,_0x2cd107,..._0x5710ab)=>{if(_0x2cd107<_0x26c800['logLevel'])return;const _0xe85e37=new Date()['toISOString'](),_0x402254=Pc[_0x2cd107];if(_0x402254)console[_0x402254]('['+_0xe85e37+']\x20\x20'+_0x26c800['name']+':',..._0x5710ab);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2cd107+')');};class xi{constructor(_0x3008b2){this['name']=_0x3008b2,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2f33bb){if(!(_0x2f33bb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2f33bb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2f33bb;}['setLogLevel'](_0x3d2d06){this['_logLevel']=typeof _0x3d2d06=='string'?kc[_0x3d2d06]:_0x3d2d06;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x541ae8){if(typeof _0x541ae8!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x541ae8;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1d29aa){this['_userLogHandler']=_0x1d29aa;}['debug'](..._0x2a9bbe){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2a9bbe),this['_logHandler'](this,T['DEBUG'],..._0x2a9bbe);}['log'](..._0x478ec7){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x478ec7),this['_logHandler'](this,T['VERBOSE'],..._0x478ec7);}['info'](..._0xab288){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xab288),this['_logHandler'](this,T['INFO'],..._0xab288);}['warn'](..._0x1078c3){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1078c3),this['_logHandler'](this,T['WARN'],..._0x1078c3);}['error'](..._0x1d6089){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1d6089),this['_logHandler'](this,T['ERROR'],..._0x1d6089);}}const Dc=(_0x2955b4,_0x9c632d)=>_0x9c632d['some'](_0x3b5581=>_0x2955b4 instanceof _0x3b5581);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2097c9){const _0x492380=new Promise((_0x991d78,_0x2e6ecd)=>{const _0x4d8599=()=>{_0x2097c9['removeEventListener']('success',_0x5c1cdd),_0x2097c9['removeEventListener']('error',_0x2ccc08);},_0x5c1cdd=()=>{_0x991d78(_e(_0x2097c9['result'])),_0x4d8599();},_0x2ccc08=()=>{_0x2e6ecd(_0x2097c9['error']),_0x4d8599();};_0x2097c9['addEventListener']('success',_0x5c1cdd),_0x2097c9['addEventListener']('error',_0x2ccc08);});return _0x492380['then'](_0x1137da=>{_0x1137da instanceof IDBCursor&&Kr['set'](_0x1137da,_0x2097c9);})['catch'](()=>{}),Fi['set'](_0x492380,_0x2097c9),_0x492380;}function Fc(_0x1fc536){if(ui['has'](_0x1fc536))return;const _0xe4182d=new Promise((_0xf9fe00,_0x28c2e6)=>{const _0x3de3df=()=>{_0x1fc536['removeEventListener']('complete',_0x289862),_0x1fc536['removeEventListener']('error',_0x5a3a5c),_0x1fc536['removeEventListener']('abort',_0x5a3a5c);},_0x289862=()=>{_0xf9fe00(),_0x3de3df();},_0x5a3a5c=()=>{_0x28c2e6(_0x1fc536['error']||new DOMException('AbortError','AbortError')),_0x3de3df();};_0x1fc536['addEventListener']('complete',_0x289862),_0x1fc536['addEventListener']('error',_0x5a3a5c),_0x1fc536['addEventListener']('abort',_0x5a3a5c);});ui['set'](_0x1fc536,_0xe4182d);}let di={'get'(_0x3be332,_0x20e780,_0x532b51){if(_0x3be332 instanceof IDBTransaction){if(_0x20e780==='done')return ui['get'](_0x3be332);if(_0x20e780==='objectStoreNames')return _0x3be332['objectStoreNames']||Yr['get'](_0x3be332);if(_0x20e780==='store')return _0x532b51['objectStoreNames'][0x1]?void 0x0:_0x532b51['objectStore'](_0x532b51['objectStoreNames'][0x0]);}return _e(_0x3be332[_0x20e780]);},'set'(_0x26ee3e,_0x243217,_0x523b94){return _0x26ee3e[_0x243217]=_0x523b94,!0x0;},'has'(_0x481099,_0x5dbe69){return _0x481099 instanceof IDBTransaction&&(_0x5dbe69==='done'||_0x5dbe69==='store')?!0x0:_0x5dbe69 in _0x481099;}};function Uc(_0xc9fe52){di=_0xc9fe52(di);}function Wc(_0x215de4){return _0x215de4===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x57f8af,..._0x50dcd8){const _0x308289=_0x215de4['call'](Xn(this),_0x57f8af,..._0x50dcd8);return Yr['set'](_0x308289,_0x57f8af['sort']?_0x57f8af['sort']():[_0x57f8af]),_e(_0x308289);}:Lc()['includes'](_0x215de4)?function(..._0x4b7fce){return _0x215de4['apply'](Xn(this),_0x4b7fce),_e(Kr['get'](this));}:function(..._0x323ea4){return _e(_0x215de4['apply'](Xn(this),_0x323ea4));};}function Bc(_0x57cc12){return typeof _0x57cc12=='function'?Wc(_0x57cc12):(_0x57cc12 instanceof IDBTransaction&&Fc(_0x57cc12),Dc(_0x57cc12,Mc())?new Proxy(_0x57cc12,di):_0x57cc12);}function _e(_0x4891a4){if(_0x4891a4 instanceof IDBRequest)return xc(_0x4891a4);if(Jn['has'](_0x4891a4))return Jn['get'](_0x4891a4);const _0x569828=Bc(_0x4891a4);return _0x569828!==_0x4891a4&&(Jn['set'](_0x4891a4,_0x569828),Fi['set'](_0x569828,_0x4891a4)),_0x569828;}const Xn=_0x27645f=>Fi['get'](_0x27645f);function Vc(_0x3b238b,_0x3ff60e,{blocked:_0xa75cbb,upgrade:_0x3a7e26,blocking:_0x119513,terminated:_0x3424c9}={}){const _0x1ca33a=indexedDB['open'](_0x3b238b,_0x3ff60e),_0x494af3=_e(_0x1ca33a);return _0x3a7e26&&_0x1ca33a['addEventListener']('upgradeneeded',_0x5414ac=>{_0x3a7e26(_e(_0x1ca33a['result']),_0x5414ac['oldVersion'],_0x5414ac['newVersion'],_e(_0x1ca33a['transaction']),_0x5414ac);}),_0xa75cbb&&_0x1ca33a['addEventListener']('blocked',_0x3c5801=>_0xa75cbb(_0x3c5801['oldVersion'],_0x3c5801['newVersion'],_0x3c5801)),_0x494af3['then'](_0xe2885e=>{_0x3424c9&&_0xe2885e['addEventListener']('close',()=>_0x3424c9()),_0x119513&&_0xe2885e['addEventListener']('versionchange',_0x14bcaa=>_0x119513(_0x14bcaa['oldVersion'],_0x14bcaa['newVersion'],_0x14bcaa));})['catch'](()=>{}),_0x494af3;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x448bf2,_0x23bdd2){if(!(_0x448bf2 instanceof IDBDatabase&&!(_0x23bdd2 in _0x448bf2)&&typeof _0x23bdd2=='string'))return;if(Zn['get'](_0x23bdd2))return Zn['get'](_0x23bdd2);const _0x325460=_0x23bdd2['replace'](/FromIndex$/,''),_0x3949d8=_0x23bdd2!==_0x325460,_0x1abcef=$c['includes'](_0x325460);if(!(_0x325460 in(_0x3949d8?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1abcef||Hc['includes'](_0x325460)))return;const _0x2a040e=async function(_0x227550,..._0x421cda){const _0x21d072=this['transaction'](_0x227550,_0x1abcef?'readwrite':'readonly');let _0x9d3722=_0x21d072['store'];return _0x3949d8&&(_0x9d3722=_0x9d3722['index'](_0x421cda['shift']())),(await Promise['all']([_0x9d3722[_0x325460](..._0x421cda),_0x1abcef&&_0x21d072['done']]))[0x0];};return Zn['set'](_0x23bdd2,_0x2a040e),_0x2a040e;}Uc(_0x1f77e2=>({..._0x1f77e2,'get':(_0x49f5df,_0x25b301,_0x4e3701)=>Os(_0x49f5df,_0x25b301)||_0x1f77e2['get'](_0x49f5df,_0x25b301,_0x4e3701),'has':(_0x368d97,_0x43d153)=>!!Os(_0x368d97,_0x43d153)||_0x1f77e2['has'](_0x368d97,_0x43d153)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x2f8a07){this['container']=_0x2f8a07;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xc1786c=>{if(qc(_0xc1786c)){const _0x521572=_0xc1786c['getImmediate']();return _0x521572['library']+'/'+_0x521572['version'];}else return null;})['filter'](_0x240d88=>_0x240d88)['join']('\x20');}}function qc(_0x25b316){const _0x4d1942=_0x25b316['getComponent']();return(_0x4d1942==null?void 0x0:_0x4d1942['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x317cd6,_0x1bc37f){try{_0x317cd6['container']['addComponent'](_0x1bc37f);}catch(_0x35cb74){re['debug']('Component\x20'+_0x1bc37f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x317cd6['name'],_0x35cb74);}}function et(_0x37bb3a){const _0x5d20fa=_0x37bb3a['name'];if(gi['has'](_0x5d20fa))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5d20fa+'.'),!0x1;gi['set'](_0x5d20fa,_0x37bb3a);for(const _0x271d74 of Le['values']())Ms(_0x271d74,_0x37bb3a);for(const _0x268d6a of _i['values']())Ms(_0x268d6a,_0x37bb3a);return!0x0;}function Ui(_0x1526b5,_0x24c334){const _0x19663a=_0x1526b5['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x19663a&&_0x19663a['triggerHeartbeat'](),_0x1526b5['container']['getProvider'](_0x24c334);}function H(_0xf537b6){return _0xf537b6==null?!0x1:_0xf537b6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x129186,_0x38a77b,_0x5c5190){this['_isDeleted']=!0x1,this['_options']={..._0x129186},this['_config']={..._0x38a77b},this['_name']=_0x38a77b['name'],this['_automaticDataCollectionEnabled']=_0x38a77b['automaticDataCollectionEnabled'],this['_container']=_0x5c5190,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1c46b4){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1c46b4;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x169939){this['_isDeleted']=_0x169939;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x372c51,_0x37ce29={}){let _0x5de6a2=_0x372c51;typeof _0x37ce29!='object'&&(_0x37ce29={'name':_0x37ce29});const _0x535029={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x37ce29},_0x159549=_0x535029['name'];if(typeof _0x159549!='string'||!_0x159549)throw ge['create']('bad-app-name',{'appName':String(_0x159549)});if(_0x5de6a2||(_0x5de6a2=$r()),!_0x5de6a2)throw ge['create']('no-options');const _0x538f41=Le['get'](_0x159549);if(_0x538f41){if(De(_0x5de6a2,_0x538f41['options'])&&De(_0x535029,_0x538f41['config']))return _0x538f41;throw ge['create']('duplicate-app',{'appName':_0x159549});}const _0x56de07=new Ac(_0x159549);for(const _0x2b706c of gi['values']())_0x56de07['addComponent'](_0x2b706c);const _0x328495=new Il(_0x5de6a2,_0x535029,_0x56de07);return Le['set'](_0x159549,_0x328495),_0x328495;}function Qr(_0x545bfb=pi){const _0x553ffa=Le['get'](_0x545bfb);if(!_0x553ffa&&_0x545bfb===pi&&$r())return wl();if(!_0x553ffa)throw ge['create']('no-app',{'appName':_0x545bfb});return _0x553ffa;}function l_(){return Array['from'](Le['values']());}async function h_(_0x1d956e){let _0x33f1d7=!0x1;const _0x78a0e3=_0x1d956e['name'];Le['has'](_0x78a0e3)?(_0x33f1d7=!0x0,Le['delete'](_0x78a0e3)):_i['has'](_0x78a0e3)&&_0x1d956e['decRefCount']()<=0x0&&(_i['delete'](_0x78a0e3),_0x33f1d7=!0x0),_0x33f1d7&&(await Promise['all'](_0x1d956e['container']['getProviders']()['map'](_0x37b656=>_0x37b656['delete']())),_0x1d956e['isDeleted']=!0x0);}function me(_0x1520f8,_0xc795ec,_0x2d06f5){let _0x5ac31f=vl[_0x1520f8]??_0x1520f8;_0x2d06f5&&(_0x5ac31f+='-'+_0x2d06f5);const _0x920ee7=_0x5ac31f['match'](/\s|\//),_0x2d96f6=_0xc795ec['match'](/\s|\//);if(_0x920ee7||_0x2d96f6){const _0xac2f36=['Unable\x20to\x20register\x20library\x20\x22'+_0x5ac31f+'\x22\x20with\x20version\x20\x22'+_0xc795ec+'\x22:'];_0x920ee7&&_0xac2f36['push']('library\x20name\x20\x22'+_0x5ac31f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x920ee7&&_0x2d96f6&&_0xac2f36['push']('and'),_0x2d96f6&&_0xac2f36['push']('version\x20name\x20\x22'+_0xc795ec+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0xac2f36['join']('\x20'));return;}et(new Me(_0x5ac31f+'-version',()=>({'library':_0x5ac31f,'version':_0xc795ec}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x50436c,_0x38b68b)=>{switch(_0x38b68b){case 0x0:try{_0x50436c['createObjectStore'](Rt);}catch(_0x59df12){console['warn'](_0x59df12);}}}})['catch'](_0x131906=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x131906['message']});})),ei;}async function Sl(_0x11ea85){try{const _0x47a3e8=(await Jr())['transaction'](Rt),_0x199a35=await _0x47a3e8['objectStore'](Rt)['get'](Xr(_0x11ea85));return await _0x47a3e8['done'],_0x199a35;}catch(_0x37f5bd){if(_0x37f5bd instanceof Se)re['warn'](_0x37f5bd['message']);else{const _0x15c337=ge['create']('idb-get',{'originalErrorMessage':_0x37f5bd==null?void 0x0:_0x37f5bd['message']});re['warn'](_0x15c337['message']);}}}async function Ls(_0x389688,_0x4de596){try{const _0x4efb8c=(await Jr())['transaction'](Rt,'readwrite');await _0x4efb8c['objectStore'](Rt)['put'](_0x4de596,Xr(_0x389688)),await _0x4efb8c['done'];}catch(_0x154b6b){if(_0x154b6b instanceof Se)re['warn'](_0x154b6b['message']);else{const _0x242222=ge['create']('idb-set',{'originalErrorMessage':_0x154b6b==null?void 0x0:_0x154b6b['message']});re['warn'](_0x242222['message']);}}}function Xr(_0x4c8ae1){return _0x4c8ae1['name']+'!'+_0x4c8ae1['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x96ad78){this['container']=_0x96ad78,this['_heartbeatsCache']=null;const _0x2bc3bf=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2bc3bf),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3f5c8e=>(this['_heartbeatsCache']=_0x3f5c8e,_0x3f5c8e));}async['triggerHeartbeat'](){var _0x57b3a9,_0x4c3a31;try{const _0x4daed8=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1c039a=xs();if(((_0x57b3a9=this['_heartbeatsCache'])==null?void 0x0:_0x57b3a9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4c3a31=this['_heartbeatsCache'])==null?void 0x0:_0x4c3a31['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1c039a||this['_heartbeatsCache']['heartbeats']['some'](_0xfe1d44=>_0xfe1d44['date']===_0x1c039a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1c039a,'agent':_0x4daed8}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x4fcb8e=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4fcb8e,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5ac55a){re['warn'](_0x5ac55a);}}async['getHeartbeatsHeader'](){var _0x1cdc42;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1cdc42=this['_heartbeatsCache'])==null?void 0x0:_0x1cdc42['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4f02d1=xs(),{heartbeatsToSend:_0x1d5037,unsentEntries:_0xc08354}=kl(this['_heartbeatsCache']['heartbeats']),_0x4c3e53=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1d5037}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4f02d1,_0xc08354['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xc08354,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4c3e53;}catch(_0x2fc15a){return re['warn'](_0x2fc15a),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x6af0ba,_0x37eabc=bl){const _0x1f1477=[];let _0x6ac27f=_0x6af0ba['slice']();for(const _0x4bf425 of _0x6af0ba){const _0x4d9bfd=_0x1f1477['find'](_0x53d586=>_0x53d586['agent']===_0x4bf425['agent']);if(_0x4d9bfd){if(_0x4d9bfd['dates']['push'](_0x4bf425['date']),Fs(_0x1f1477)>_0x37eabc){_0x4d9bfd['dates']['pop']();break;}}else{if(_0x1f1477['push']({'agent':_0x4bf425['agent'],'dates':[_0x4bf425['date']]}),Fs(_0x1f1477)>_0x37eabc){_0x1f1477['pop']();break;}}_0x6ac27f=_0x6ac27f['slice'](0x1);}return{'heartbeatsToSend':_0x1f1477,'unsentEntries':_0x6ac27f};}class Nl{constructor(_0x53381b){this['app']=_0x53381b,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4da2ab=await Sl(this['app']);return _0x4da2ab!=null&&_0x4da2ab['heartbeats']?_0x4da2ab:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1387e2){if(await this['_canUseIndexedDBPromise']){const _0x30dd15=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1387e2['lastSentHeartbeatDate']??_0x30dd15['lastSentHeartbeatDate'],'heartbeats':_0x1387e2['heartbeats']});}else return;}async['add'](_0x396b9f){if(await this['_canUseIndexedDBPromise']){const _0x1fa307=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x396b9f['lastSentHeartbeatDate']??_0x1fa307['lastSentHeartbeatDate'],'heartbeats':[..._0x1fa307['heartbeats'],..._0x396b9f['heartbeats']]});}else return;}}function Fs(_0x3dd1ec){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x3dd1ec}))['length'];}function Pl(_0x4a1d48){if(_0x4a1d48['length']===0x0)return-0x1;let _0x50f40d=0x0,_0x825985=_0x4a1d48[0x0]['date'];for(let _0x23ec95=0x1;_0x23ec95<_0x4a1d48['length'];_0x23ec95++)_0x4a1d48[_0x23ec95]['date']<_0x825985&&(_0x825985=_0x4a1d48[_0x23ec95]['date'],_0x50f40d=_0x23ec95);return _0x50f40d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4ddda2){et(new Me('platform-logger',_0x276ea2=>new Gc(_0x276ea2),'PRIVATE')),et(new Me('heartbeat',_0x27bc12=>new Al(_0x27bc12),'PRIVATE')),me(fi,Ds,_0x4ddda2),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0xc9c857){Zr=_0xc9c857;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x250547){this['domStorage_']=_0x250547,this['prefix_']='firebase:';}['set'](_0x4ca155,_0x315c50){_0x315c50==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4ca155)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4ca155),O(_0x315c50));}['get'](_0x2caea2){const _0x2831fa=this['domStorage_']['getItem'](this['prefixedName_'](_0x2caea2));return _0x2831fa==null?null:bt(_0x2831fa);}['remove'](_0x349f83){this['domStorage_']['removeItem'](this['prefixedName_'](_0x349f83));}['prefixedName_'](_0x2fe33b){return this['prefix_']+_0x2fe33b;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1ca8a3,_0x4910ee){_0x4910ee==null?delete this['cache_'][_0x1ca8a3]:this['cache_'][_0x1ca8a3]=_0x4910ee;}['get'](_0x11ef68){return Y(this['cache_'],_0x11ef68)?this['cache_'][_0x11ef68]:null;}['remove'](_0x5c9c77){delete this['cache_'][_0x5c9c77];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x2c8b28){try{if(typeof window<'u'&&typeof window[_0x2c8b28]<'u'){const _0x4627c3=window[_0x2c8b28];return _0x4627c3['setItem']('firebase:sentinel','cache'),_0x4627c3['removeItem']('firebase:sentinel'),new xl(_0x4627c3);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x5194e4=0x1;return function(){return _0x5194e4++;};}()),no=function(_0x566d25){const _0x333109=Tc(_0x566d25),_0x23277a=new Ec();_0x23277a['update'](_0x333109);const _0x1ac1fd=_0x23277a['digest']();return Di['encodeByteArray'](_0x1ac1fd);},Bt=function(..._0x4d04c4){let _0x33b28b='';for(let _0x3bf271=0x0;_0x3bf271<_0x4d04c4['length'];_0x3bf271++){const _0x3749ca=_0x4d04c4[_0x3bf271];Array['isArray'](_0x3749ca)||_0x3749ca&&typeof _0x3749ca=='object'&&typeof _0x3749ca['length']=='number'?_0x33b28b+=Bt['apply'](null,_0x3749ca):typeof _0x3749ca=='object'?_0x33b28b+=O(_0x3749ca):_0x33b28b+=_0x3749ca,_0x33b28b+='\x20';}return _0x33b28b;};let Et=null,Vs=!0x0;const Wl=function(_0x104319,_0x37bf6f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x35919a){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x4c990b=Bt['apply'](null,_0x35919a);Et(_0x4c990b);}},Vt=function(_0x237b0f){return function(..._0x168e69){L(_0x237b0f,..._0x168e69);};},mi=function(..._0x270599){const _0xeed887='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x270599);Qe['error'](_0xeed887);},oe=function(..._0x11c255){const _0x4ee9bb='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x11c255);throw Qe['error'](_0x4ee9bb),new Error(_0x4ee9bb);},U=function(..._0x58c426){const _0x1c2631='FIREBASE\x20WARNING:\x20'+Bt(..._0x58c426);Qe['warn'](_0x1c2631);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x29813e){return typeof _0x29813e=='number'&&(_0x29813e!==_0x29813e||_0x29813e===Number['POSITIVE_INFINITY']||_0x29813e===Number['NEGATIVE_INFINITY']);},Vl=function(_0x2db4e8){if(document['readyState']==='complete')_0x2db4e8();else{let _0xda97d3=!0x1;const _0x118c3d=function(){if(!document['body']){setTimeout(_0x118c3d,Math['floor'](0xa));return;}_0xda97d3||(_0xda97d3=!0x0,_0x2db4e8());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x118c3d,!0x1),window['addEventListener']('load',_0x118c3d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x118c3d();}),window['attachEvent']('onload',_0x118c3d));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2ac294,_0x2c99a2){if(_0x2ac294===_0x2c99a2)return 0x0;if(_0x2ac294===xe||_0x2c99a2===Ie)return-0x1;if(_0x2c99a2===xe||_0x2ac294===Ie)return 0x1;{const _0x3953dd=Hs(_0x2ac294),_0x1af2b1=Hs(_0x2c99a2);return _0x3953dd!==null?_0x1af2b1!==null?_0x3953dd-_0x1af2b1===0x0?_0x2ac294['length']-_0x2c99a2['length']:_0x3953dd-_0x1af2b1:-0x1:_0x1af2b1!==null?0x1:_0x2ac294<_0x2c99a2?-0x1:0x1;}},Hl=function(_0xd71509,_0x2e1125){return _0xd71509===_0x2e1125?0x0:_0xd71509<_0x2e1125?-0x1:0x1;},pt=function(_0x54919b,_0x5ccf9d){if(_0x5ccf9d&&_0x54919b in _0x5ccf9d)return _0x5ccf9d[_0x54919b];throw new Error('Missing\x20required\x20key\x20('+_0x54919b+')\x20in\x20object:\x20'+O(_0x5ccf9d));},Bi=function(_0x813f64){if(typeof _0x813f64!='object'||_0x813f64===null)return O(_0x813f64);const _0xe1038=[];for(const _0x56f0b9 in _0x813f64)_0xe1038['push'](_0x56f0b9);_0xe1038['sort']();let _0x1e44d7='{';for(let _0x58c020=0x0;_0x58c020<_0xe1038['length'];_0x58c020++)_0x58c020!==0x0&&(_0x1e44d7+=','),_0x1e44d7+=O(_0xe1038[_0x58c020]),_0x1e44d7+=':',_0x1e44d7+=Bi(_0x813f64[_0xe1038[_0x58c020]]);return _0x1e44d7+='}',_0x1e44d7;},io=function(_0x1ae7e8,_0x1eee56){const _0x20b9b4=_0x1ae7e8['length'];if(_0x20b9b4<=_0x1eee56)return[_0x1ae7e8];const _0x18f662=[];for(let _0x115d78=0x0;_0x115d78<_0x20b9b4;_0x115d78+=_0x1eee56)_0x115d78+_0x1eee56>_0x20b9b4?_0x18f662['push'](_0x1ae7e8['substring'](_0x115d78,_0x20b9b4)):_0x18f662['push'](_0x1ae7e8['substring'](_0x115d78,_0x115d78+_0x1eee56));return _0x18f662;};function x(_0x5735b4,_0x4d72db){for(const _0xa4713d in _0x5735b4)_0x5735b4['hasOwnProperty'](_0xa4713d)&&_0x4d72db(_0xa4713d,_0x5735b4[_0xa4713d]);}const so=function(_0x2707ac){f(!Wi(_0x2707ac),'Invalid\x20JSON\x20number');const _0x538f77=0xb,_0x2fa397=0x34,_0x5e4a7e=(0x1<<_0x538f77-0x1)-0x1;let _0x225337,_0x2f9690,_0x1df145,_0x5e1ee0,_0x331265;_0x2707ac===0x0?(_0x2f9690=0x0,_0x1df145=0x0,_0x225337=0x1/_0x2707ac===-0x1/0x0?0x1:0x0):(_0x225337=_0x2707ac<0x0,_0x2707ac=Math['abs'](_0x2707ac),_0x2707ac>=Math['pow'](0x2,0x1-_0x5e4a7e)?(_0x5e1ee0=Math['min'](Math['floor'](Math['log'](_0x2707ac)/Math['LN2']),_0x5e4a7e),_0x2f9690=_0x5e1ee0+_0x5e4a7e,_0x1df145=Math['round'](_0x2707ac*Math['pow'](0x2,_0x2fa397-_0x5e1ee0)-Math['pow'](0x2,_0x2fa397))):(_0x2f9690=0x0,_0x1df145=Math['round'](_0x2707ac/Math['pow'](0x2,0x1-_0x5e4a7e-_0x2fa397))));const _0x56a8ec=[];for(_0x331265=_0x2fa397;_0x331265;_0x331265-=0x1)_0x56a8ec['push'](_0x1df145%0x2?0x1:0x0),_0x1df145=Math['floor'](_0x1df145/0x2);for(_0x331265=_0x538f77;_0x331265;_0x331265-=0x1)_0x56a8ec['push'](_0x2f9690%0x2?0x1:0x0),_0x2f9690=Math['floor'](_0x2f9690/0x2);_0x56a8ec['push'](_0x225337?0x1:0x0),_0x56a8ec['reverse']();const _0x3ed861=_0x56a8ec['join']('');let _0x5a8b81='';for(_0x331265=0x0;_0x331265<0x40;_0x331265+=0x8){let _0x111978=parseInt(_0x3ed861['substr'](_0x331265,0x8),0x2)['toString'](0x10);_0x111978['length']===0x1&&(_0x111978='0'+_0x111978),_0x5a8b81=_0x5a8b81+_0x111978;}return _0x5a8b81['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x53ee30,_0x1f94ac){let _0x44f653='Unknown\x20Error';_0x53ee30==='too_big'?_0x44f653='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x53ee30==='permission_denied'?_0x44f653='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x53ee30==='unavailable'&&(_0x44f653='The\x20service\x20is\x20unavailable');const _0x49b7cc=new Error(_0x53ee30+'\x20at\x20'+_0x1f94ac['_path']['toString']()+':\x20'+_0x44f653);return _0x49b7cc['code']=_0x53ee30['toUpperCase'](),_0x49b7cc;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x5bf0e2){if(zl['test'](_0x5bf0e2)){const _0x44aeb3=Number(_0x5bf0e2);if(_0x44aeb3>=jl&&_0x44aeb3<=Kl)return _0x44aeb3;}return null;},lt=function(_0x3b23c6){try{_0x3b23c6();}catch(_0x5bc3bf){setTimeout(()=>{const _0x2831ae=_0x5bc3bf['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2831ae),_0x5bc3bf;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0xb324fb,_0x19e0f1){const _0x35f099=setTimeout(_0xb324fb,_0x19e0f1);return typeof _0x35f099=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x35f099):typeof _0x35f099=='object'&&_0x35f099['unref']&&_0x35f099['unref'](),_0x35f099;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xf7939f,_0xf1c2d7){this['appCheckProvider']=_0xf1c2d7,this['appName']=_0xf7939f['name'],H(_0xf7939f)&&_0xf7939f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xf7939f['settings']['appCheckToken']),this['appCheck']=_0xf1c2d7==null?void 0x0:_0xf1c2d7['getImmediate']({'optional':!0x0}),this['appCheck']||_0xf1c2d7==null||_0xf1c2d7['get']()['then'](_0x20a680=>this['appCheck']=_0x20a680);}['getToken'](_0x3f8c50){if(this['serverAppAppCheckToken']){if(_0x3f8c50)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3f8c50):new Promise((_0x4fc32a,_0xa3be65)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3f8c50)['then'](_0x4fc32a,_0xa3be65):_0x4fc32a(null);},0x0);});}['addTokenChangeListener'](_0x46c7e6){var _0x28a25f;(_0x28a25f=this['appCheckProvider'])==null||_0x28a25f['get']()['then'](_0x2091c7=>_0x2091c7['addTokenListener'](_0x46c7e6));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x22d987,_0xb6b33b,_0x5cfde0){this['appName_']=_0x22d987,this['firebaseOptions_']=_0xb6b33b,this['authProvider_']=_0x5cfde0,this['auth_']=null,this['auth_']=_0x5cfde0['getImmediate']({'optional':!0x0}),this['auth_']||_0x5cfde0['onInit'](_0xe15f09=>this['auth_']=_0xe15f09);}['getToken'](_0x34b24b){return this['auth_']?this['auth_']['getToken'](_0x34b24b)['catch'](_0x4f22ed=>_0x4f22ed&&_0x4f22ed['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4f22ed)):new Promise((_0x2538ff,_0x431b21)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x34b24b)['then'](_0x2538ff,_0x431b21):_0x2538ff(null);},0x0);});}['addTokenChangeListener'](_0x3de610){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3de610):this['authProvider_']['get']()['then'](_0x130716=>_0x130716['addAuthTokenListener'](_0x3de610));}['removeTokenChangeListener'](_0x328d2d){this['authProvider_']['get']()['then'](_0x57a582=>_0x57a582['removeAuthTokenListener'](_0x328d2d));}['notifyForInvalidToken'](){let _0x5279b7='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5279b7+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5279b7+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5279b7+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5279b7);}}class tn{constructor(_0x474a13){this['accessToken']=_0x474a13;}['getToken'](_0x14d309){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x50ff9a){_0x50ff9a(this['accessToken']);}['removeTokenChangeListener'](_0x5dd412){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x4688b6,_0x437848,_0x554639,_0x210360,_0x2b6079=!0x1,_0x4f5439='',_0x1bf2c3=!0x1,_0x244cb0=!0x1,_0x4b8c51=null){this['secure']=_0x437848,this['namespace']=_0x554639,this['webSocketOnly']=_0x210360,this['nodeAdmin']=_0x2b6079,this['persistenceKey']=_0x4f5439,this['includeNamespaceInQueryParams']=_0x1bf2c3,this['isUsingEmulator']=_0x244cb0,this['emulatorOptions']=_0x4b8c51,this['_host']=_0x4688b6['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x4688b6)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x9e9085){_0x9e9085!==this['internalHost']&&(this['internalHost']=_0x9e9085,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x9dc167=this['toURLString']();return this['persistenceKey']&&(_0x9dc167+='<'+this['persistenceKey']+'>'),_0x9dc167;}['toURLString'](){const _0x57334e=this['secure']?'https://':'http://',_0x11a8d5=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x57334e+this['host']+'/'+_0x11a8d5;}}function Xl(_0x18dd54){return _0x18dd54['host']!==_0x18dd54['internalHost']||_0x18dd54['isCustomHost']()||_0x18dd54['includeNamespaceInQueryParams'];}function go(_0x2c4bbb,_0x410d29,_0xc4e21a){f(typeof _0x410d29=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xc4e21a=='object','typeof\x20params\x20must\x20==\x20object');let _0x2a06fa;if(_0x410d29===fo)_0x2a06fa=(_0x2c4bbb['secure']?'wss://':'ws://')+_0x2c4bbb['internalHost']+'/.ws?';else{if(_0x410d29===po)_0x2a06fa=(_0x2c4bbb['secure']?'https://':'http://')+_0x2c4bbb['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x410d29);}Xl(_0x2c4bbb)&&(_0xc4e21a['ns']=_0x2c4bbb['namespace']);const _0x3a9d2e=[];return x(_0xc4e21a,(_0x43dfc1,_0x38231f)=>{_0x3a9d2e['push'](_0x43dfc1+'='+_0x38231f);}),_0x2a06fa+_0x3a9d2e['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x513660,_0x21e9f8=0x1){Y(this['counters_'],_0x513660)||(this['counters_'][_0x513660]=0x0),this['counters_'][_0x513660]+=_0x21e9f8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x1b3d9e){const _0x8600e2=_0x1b3d9e['toString']();return ti[_0x8600e2]||(ti[_0x8600e2]=new Zl()),ti[_0x8600e2];}function eh(_0x215f43,_0x402ed7){const _0x20796b=_0x215f43['toString']();return ni[_0x20796b]||(ni[_0x20796b]=_0x402ed7()),ni[_0x20796b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x3e0996){this['onMessage_']=_0x3e0996,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3df43e,_0x25f683){this['closeAfterResponse']=_0x3df43e,this['onClose']=_0x25f683,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x592f51,_0x1c208e){for(this['pendingResponses'][_0x592f51]=_0x1c208e;this['pendingResponses'][this['currentResponseNum']];){const _0x77a3c4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x59855b=0x0;_0x59855b<_0x77a3c4['length'];++_0x59855b)_0x77a3c4[_0x59855b]&&lt(()=>{this['onMessage_'](_0x77a3c4[_0x59855b]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x19a9f7,_0x575740,_0xa7ce8,_0x53ce38,_0x2a4b0c,_0x558b20,_0x159fc6){this['connId']=_0x19a9f7,this['repoInfo']=_0x575740,this['applicationId']=_0xa7ce8,this['appCheckToken']=_0x53ce38,this['authToken']=_0x2a4b0c,this['transportSessionId']=_0x558b20,this['lastSessionId']=_0x159fc6,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x19a9f7),this['stats_']=Hi(_0x575740),this['urlFn']=_0x1a37ca=>(this['appCheckToken']&&(_0x1a37ca[yi]=this['appCheckToken']),go(_0x575740,po,_0x1a37ca));}['open'](_0x2eb391,_0x47bfc8){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x47bfc8,this['myPacketOrderer']=new th(_0x2eb391),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3a94a6)=>{const [_0x165ad0,_0x2ba8ff,_0x25a660,_0x2e3818,_0x50c23e]=_0x3a94a6;if(this['incrementIncomingBytes_'](_0x3a94a6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x165ad0===$s)this['id']=_0x2ba8ff,this['password']=_0x25a660;else{if(_0x165ad0===nh)_0x2ba8ff?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2ba8ff,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x165ad0);}}},(..._0x22b5cb)=>{const [_0x3fd89f,_0x2d3f6f]=_0x22b5cb;this['incrementIncomingBytes_'](_0x22b5cb),this['myPacketOrderer']['handleResponse'](_0x3fd89f,_0x2d3f6f);},()=>{this['onClosed_']();},this['urlFn']);const _0x10e5cf={};_0x10e5cf[$s]='t',_0x10e5cf[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x10e5cf[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x10e5cf[ro]=Vi,this['transportSessionId']&&(_0x10e5cf[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x10e5cf[ho]=this['lastSessionId']),this['applicationId']&&(_0x10e5cf[uo]=this['applicationId']),this['appCheckToken']&&(_0x10e5cf[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x10e5cf[ao]=co);const _0x717da=this['urlFn'](_0x10e5cf);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x717da),this['scriptTagHolder']['addTag'](_0x717da,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x19f65a){const _0x1ac1ea=O(_0x19f65a);this['bytesSent']+=_0x1ac1ea['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1ac1ea['length']);const _0x62e432=Br(_0x1ac1ea),_0x23c0c1=io(_0x62e432,hh);for(let _0x39c40e=0x0;_0x39c40e<_0x23c0c1['length'];_0x39c40e++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x23c0c1['length'],_0x23c0c1[_0x39c40e]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3c3283,_0x1084c4){this['myDisconnFrame']=document['createElement']('iframe');const _0x2b46b1={};_0x2b46b1[lh]='t',_0x2b46b1[mo]=_0x3c3283,_0x2b46b1[yo]=_0x1084c4,this['myDisconnFrame']['src']=this['urlFn'](_0x2b46b1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x163dd2){const _0x5274b6=O(_0x163dd2)['length'];this['bytesReceived']+=_0x5274b6,this['stats_']['incrementCounter']('bytes_received',_0x5274b6);}}class $i{constructor(_0x6b3fbb,_0x417c96,_0x5bf4ec,_0x5ebae6){this['onDisconnect']=_0x5bf4ec,this['urlFn']=_0x5ebae6,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x6b3fbb,window[sh+this['uniqueCallbackIdentifier']]=_0x417c96,this['myIFrame']=$i['createIFrame_']();let _0x55ffa4='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x55ffa4='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x19f7bb='<html><body>'+_0x55ffa4+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x19f7bb),this['myIFrame']['doc']['close']();}catch(_0x16e243){L('frame\x20writing\x20exception'),_0x16e243['stack']&&L(_0x16e243['stack']),L(_0x16e243);}}}static['createIFrame_'](){const _0xd5f6ab=document['createElement']('iframe');if(_0xd5f6ab['style']['display']='none',document['body']){document['body']['appendChild'](_0xd5f6ab);try{_0xd5f6ab['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2788d5=document['domain'];_0xd5f6ab['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2788d5+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xd5f6ab['contentDocument']?_0xd5f6ab['doc']=_0xd5f6ab['contentDocument']:_0xd5f6ab['contentWindow']?_0xd5f6ab['doc']=_0xd5f6ab['contentWindow']['document']:_0xd5f6ab['document']&&(_0xd5f6ab['doc']=_0xd5f6ab['document']),_0xd5f6ab;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x56203a=this['onDisconnect'];_0x56203a&&(this['onDisconnect']=null,_0x56203a());}['startLongPoll'](_0x4ab1ef,_0x217e37){for(this['myID']=_0x4ab1ef,this['myPW']=_0x217e37,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1e6ea9={};_0x1e6ea9[mo]=this['myID'],_0x1e6ea9[yo]=this['myPW'],_0x1e6ea9[vo]=this['currentSerial'];let _0x2eaf45=this['urlFn'](_0x1e6ea9),_0x25b6c2='',_0x515901=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x25b6c2['length']<=Eo;){const _0x53a92f=this['pendingSegs']['shift']();_0x25b6c2=_0x25b6c2+'&'+oh+_0x515901+'='+_0x53a92f['seg']+'&'+ah+_0x515901+'='+_0x53a92f['ts']+'&'+ch+_0x515901+'='+_0x53a92f['d'],_0x515901++;}return _0x2eaf45=_0x2eaf45+_0x25b6c2,this['addLongPollTag_'](_0x2eaf45,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x43fb04,_0x11f031,_0x4915fe){this['pendingSegs']['push']({'seg':_0x43fb04,'ts':_0x11f031,'d':_0x4915fe}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x35c372,_0x5c2d6d){this['outstandingRequests']['add'](_0x5c2d6d);const _0x21ebea=()=>{this['outstandingRequests']['delete'](_0x5c2d6d),this['newRequest_']();},_0x471bf7=setTimeout(_0x21ebea,Math['floor'](uh)),_0x3fbee4=()=>{clearTimeout(_0x471bf7),_0x21ebea();};this['addTag'](_0x35c372,_0x3fbee4);}['addTag'](_0x4fff32,_0x56a007){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x21475a=this['myIFrame']['doc']['createElement']('script');_0x21475a['type']='text/javascript',_0x21475a['async']=!0x0,_0x21475a['src']=_0x4fff32,_0x21475a['onload']=_0x21475a['onreadystatechange']=function(){const _0x250efd=_0x21475a['readyState'];(!_0x250efd||_0x250efd==='loaded'||_0x250efd==='complete')&&(_0x21475a['onload']=_0x21475a['onreadystatechange']=null,_0x21475a['parentNode']&&_0x21475a['parentNode']['removeChild'](_0x21475a),_0x56a007());},_0x21475a['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4fff32),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x21475a);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x35eb07,_0x544c6b,_0x6a6aaf,_0x5b9035,_0x148fca,_0x53797e,_0x30e4fa){this['connId']=_0x35eb07,this['applicationId']=_0x6a6aaf,this['appCheckToken']=_0x5b9035,this['authToken']=_0x148fca,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x544c6b),this['connURL']=G['connectionURL_'](_0x544c6b,_0x53797e,_0x30e4fa,_0x5b9035,_0x6a6aaf),this['nodeAdmin']=_0x544c6b['nodeAdmin'];}static['connectionURL_'](_0x2d730b,_0x204331,_0x26cdbc,_0x4d35ab,_0x2e3cb8){const _0x4cb251={};return _0x4cb251[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4cb251[ao]=co),_0x204331&&(_0x4cb251[oo]=_0x204331),_0x26cdbc&&(_0x4cb251[ho]=_0x26cdbc),_0x4d35ab&&(_0x4cb251[yi]=_0x4d35ab),_0x2e3cb8&&(_0x4cb251[uo]=_0x2e3cb8),go(_0x2d730b,fo,_0x4cb251);}['open'](_0xa52ae9,_0x18cf08){this['onDisconnect']=_0x18cf08,this['onMessage']=_0xa52ae9,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0xedc4c6;dc(),this['mySock']=new hn(this['connURL'],[],_0xedc4c6);}catch(_0x2e479a){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1a3349=_0x2e479a['message']||_0x2e479a['data'];_0x1a3349&&this['log_'](_0x1a3349),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3f9619=>{this['handleIncomingFrame'](_0x3f9619);},this['mySock']['onerror']=_0x5c0c9d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x45f622=_0x5c0c9d['message']||_0x5c0c9d['data'];_0x45f622&&this['log_'](_0x45f622),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x35957d=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x50f506=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2f48fa=navigator['userAgent']['match'](_0x50f506);_0x2f48fa&&_0x2f48fa['length']>0x1&&parseFloat(_0x2f48fa[0x1])<4.4&&(_0x35957d=!0x0);}return!_0x35957d&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4d204e){if(this['frames']['push'](_0x4d204e),this['frames']['length']===this['totalFrames']){const _0x428a91=this['frames']['join']('');this['frames']=null;const _0xc2af55=bt(_0x428a91);this['onMessage'](_0xc2af55);}}['handleNewFrameCount_'](_0x2d781c){this['totalFrames']=_0x2d781c,this['frames']=[];}['extractFrameCount_'](_0xff4e2a){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xff4e2a['length']<=0x6){const _0x4845ae=Number(_0xff4e2a);if(!isNaN(_0x4845ae))return this['handleNewFrameCount_'](_0x4845ae),null;}return this['handleNewFrameCount_'](0x1),_0xff4e2a;}['handleIncomingFrame'](_0x46112a){if(this['mySock']===null)return;const _0x39c6e1=_0x46112a['data'];if(this['bytesReceived']+=_0x39c6e1['length'],this['stats_']['incrementCounter']('bytes_received',_0x39c6e1['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x39c6e1);else{const _0x5e1896=this['extractFrameCount_'](_0x39c6e1);_0x5e1896!==null&&this['appendFrame_'](_0x5e1896);}}['send'](_0x31f06b){this['resetKeepAlive']();const _0x558039=O(_0x31f06b);this['bytesSent']+=_0x558039['length'],this['stats_']['incrementCounter']('bytes_sent',_0x558039['length']);const _0x1509b0=io(_0x558039,fh);_0x1509b0['length']>0x1&&this['sendString_'](String(_0x1509b0['length']));for(let _0x6a7e74=0x0;_0x6a7e74<_0x1509b0['length'];_0x6a7e74++)this['sendString_'](_0x1509b0[_0x6a7e74]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x4fe025){try{this['mySock']['send'](_0x4fe025);}catch(_0x22b4d0){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x22b4d0['message']||_0x22b4d0['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2f19d0){this['initTransports_'](_0x2f19d0);}['initTransports_'](_0x228f5c){const _0x4dd5cc=G&&G['isAvailable']();let _0x39566f=_0x4dd5cc&&!G['previouslyFailed']();if(_0x228f5c['webSocketOnly']&&(_0x4dd5cc||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x39566f=!0x0),_0x39566f)this['transports_']=[G];else{const _0x1b7c26=this['transports_']=[];for(const _0x392993 of At['ALL_TRANSPORTS'])_0x392993&&_0x392993['isAvailable']()&&_0x1b7c26['push'](_0x392993);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x272bc7,_0x108dcd,_0x46aaa7,_0x5a3a1f,_0x9e365,_0x17c8e8,_0x56f969,_0x5a3338,_0x2b5a5e,_0x25d4a9){this['id']=_0x272bc7,this['repoInfo_']=_0x108dcd,this['applicationId_']=_0x46aaa7,this['appCheckToken_']=_0x5a3a1f,this['authToken_']=_0x9e365,this['onMessage_']=_0x17c8e8,this['onReady_']=_0x56f969,this['onDisconnect_']=_0x5a3338,this['onKill_']=_0x2b5a5e,this['lastSessionId']=_0x25d4a9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x108dcd),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x46dba0=this['transportManager_']['initialTransport']();this['conn_']=new _0x46dba0(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x46dba0['responsesRequiredToBeHealthy']||0x0;const _0x2d5f1a=this['connReceiver_'](this['conn_']),_0x54e91c=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2d5f1a,_0x54e91c);},Math['floor'](0x0));const _0x48f69d=_0x46dba0['healthyTimeout']||0x0;_0x48f69d>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x48f69d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x44de66){return _0x16897f=>{_0x44de66===this['conn_']?this['onConnectionLost_'](_0x16897f):_0x44de66===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x323ffa){return _0x1c9175=>{this['state_']!==0x2&&(_0x323ffa===this['rx_']?this['onPrimaryMessageReceived_'](_0x1c9175):_0x323ffa===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1c9175):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xdd4470){const _0x397a9a={'t':'d','d':_0xdd4470};this['sendData_'](_0x397a9a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x56438a){if(ii in _0x56438a){const _0x44ad49=_0x56438a[ii];_0x44ad49===js?this['upgradeIfSecondaryHealthy_']():_0x44ad49===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x44ad49===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4219e5){const _0x42f953=pt('t',_0x4219e5),_0x1d3b7b=pt('d',_0x4219e5);if(_0x42f953==='c')this['onSecondaryControl_'](_0x1d3b7b);else{if(_0x42f953==='d')this['pendingDataMessages']['push'](_0x1d3b7b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x42f953);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x37edff){const _0x231dce=pt('t',_0x37edff),_0x569847=pt('d',_0x37edff);_0x231dce==='c'?this['onControl_'](_0x569847):_0x231dce==='d'&&this['onDataMessage_'](_0x569847);}['onDataMessage_'](_0x409338){this['onPrimaryResponse_'](),this['onMessage_'](_0x409338);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x336e59){const _0x225119=pt(ii,_0x336e59);if(Gs in _0x336e59){const _0x2ecf1e=_0x336e59[Gs];if(_0x225119===Ih){const _0x1309fa={..._0x2ecf1e};this['repoInfo_']['isUsingEmulator']&&(_0x1309fa['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1309fa);}else{if(_0x225119===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4dade7=0x0;_0x4dade7<this['pendingDataMessages']['length'];++_0x4dade7)this['onDataMessage_'](this['pendingDataMessages'][_0x4dade7]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x225119===vh?this['onConnectionShutdown_'](_0x2ecf1e):_0x225119===qs?this['onReset_'](_0x2ecf1e):_0x225119===Eh?mi('Server\x20Error:\x20'+_0x2ecf1e):_0x225119===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x225119);}}}['onHandshake_'](_0x364126){const _0x271b73=_0x364126['ts'],_0xfbe03b=_0x364126['v'],_0x2d6013=_0x364126['h'];this['sessionId']=_0x364126['s'],this['repoInfo_']['host']=_0x2d6013,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x271b73),Vi!==_0xfbe03b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x127fa1=this['transportManager_']['upgradeTransport']();_0x127fa1&&this['startUpgrade_'](_0x127fa1);}['startUpgrade_'](_0x16157e){this['secondaryConn_']=new _0x16157e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x16157e['responsesRequiredToBeHealthy']||0x0;const _0x442c14=this['connReceiver_'](this['secondaryConn_']),_0x507ae0=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x442c14,_0x507ae0),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x46f08c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x46f08c),this['repoInfo_']['host']=_0x46f08c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x15e3eb,_0x27ec62){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x15e3eb,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x27ec62,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x54c075=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x54c075||this['rx_']===_0x54c075)&&this['close']();}['onConnectionLost_'](_0x21bc2f){this['conn_']=null,!_0x21bc2f&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5be0ea){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5be0ea),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2afe6c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2afe6c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x5461a1,_0x3f4aa1,_0x4d1109,_0x3105ac){}['merge'](_0x35f761,_0x566b1b,_0x3b9be4,_0x45491d){}['refreshAuthToken'](_0x2850fe){}['refreshAppCheckToken'](_0x3cb68c){}['onDisconnectPut'](_0x5f5769,_0xa6cac2,_0x2a8ab7){}['onDisconnectMerge'](_0x4ddbf4,_0x41c52a,_0x197282){}['onDisconnectCancel'](_0x3e9182,_0x45a91c){}['reportStats'](_0x368c49){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x594345){this['allowedEvents_']=_0x594345,this['listeners_']={},f(Array['isArray'](_0x594345)&&_0x594345['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x305735,..._0x52a2ca){if(Array['isArray'](this['listeners_'][_0x305735])){const _0x5a2bdd=[...this['listeners_'][_0x305735]];for(let _0x5e07b0=0x0;_0x5e07b0<_0x5a2bdd['length'];_0x5e07b0++)_0x5a2bdd[_0x5e07b0]['callback']['apply'](_0x5a2bdd[_0x5e07b0]['context'],_0x52a2ca);}}['on'](_0x56dc05,_0x419409,_0x1f9bb6){this['validateEventType_'](_0x56dc05),this['listeners_'][_0x56dc05]=this['listeners_'][_0x56dc05]||[],this['listeners_'][_0x56dc05]['push']({'callback':_0x419409,'context':_0x1f9bb6});const _0x202bdb=this['getInitialEvent'](_0x56dc05);_0x202bdb&&_0x419409['apply'](_0x1f9bb6,_0x202bdb);}['off'](_0x5eea4a,_0x5469d9,_0x2d0282){this['validateEventType_'](_0x5eea4a);const _0x4c719e=this['listeners_'][_0x5eea4a]||[];for(let _0x43af12=0x0;_0x43af12<_0x4c719e['length'];_0x43af12++)if(_0x4c719e[_0x43af12]['callback']===_0x5469d9&&(!_0x2d0282||_0x2d0282===_0x4c719e[_0x43af12]['context'])){_0x4c719e['splice'](_0x43af12,0x1);return;}}['validateEventType_'](_0x396d13){f(this['allowedEvents_']['find'](_0x23b1a6=>_0x23b1a6===_0x396d13),'Unknown\x20event:\x20'+_0x396d13);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4e6eb6){return f(_0x4e6eb6==='online','Unknown\x20event\x20type:\x20'+_0x4e6eb6),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x56c5cb,_0x11e8a5){if(_0x11e8a5===void 0x0){this['pieces_']=_0x56c5cb['split']('/');let _0x29ea57=0x0;for(let _0x34c37e=0x0;_0x34c37e<this['pieces_']['length'];_0x34c37e++)this['pieces_'][_0x34c37e]['length']>0x0&&(this['pieces_'][_0x29ea57]=this['pieces_'][_0x34c37e],_0x29ea57++);this['pieces_']['length']=_0x29ea57,this['pieceNum_']=0x0;}else this['pieces_']=_0x56c5cb,this['pieceNum_']=_0x11e8a5;}['toString'](){let _0x458c55='';for(let _0x161b34=this['pieceNum_'];_0x161b34<this['pieces_']['length'];_0x161b34++)this['pieces_'][_0x161b34]!==''&&(_0x458c55+='/'+this['pieces_'][_0x161b34]);return _0x458c55||'/';}}function w(){return new C('');}function y(_0x16ea5a){return _0x16ea5a['pieceNum_']>=_0x16ea5a['pieces_']['length']?null:_0x16ea5a['pieces_'][_0x16ea5a['pieceNum_']];}function we(_0x4cf4f4){return _0x4cf4f4['pieces_']['length']-_0x4cf4f4['pieceNum_'];}function b(_0x26426d){let _0x3a8662=_0x26426d['pieceNum_'];return _0x3a8662<_0x26426d['pieces_']['length']&&_0x3a8662++,new C(_0x26426d['pieces_'],_0x3a8662);}function Gi(_0x3c0a7c){return _0x3c0a7c['pieceNum_']<_0x3c0a7c['pieces_']['length']?_0x3c0a7c['pieces_'][_0x3c0a7c['pieces_']['length']-0x1]:null;}function Ch(_0x3e6d8d){let _0x4bf683='';for(let _0x17ab82=_0x3e6d8d['pieceNum_'];_0x17ab82<_0x3e6d8d['pieces_']['length'];_0x17ab82++)_0x3e6d8d['pieces_'][_0x17ab82]!==''&&(_0x4bf683+='/'+encodeURIComponent(String(_0x3e6d8d['pieces_'][_0x17ab82])));return _0x4bf683||'/';}function kt(_0x34c363,_0x57f848=0x0){return _0x34c363['pieces_']['slice'](_0x34c363['pieceNum_']+_0x57f848);}function To(_0x24763f){if(_0x24763f['pieceNum_']>=_0x24763f['pieces_']['length'])return null;const _0x4d37db=[];for(let _0x3420ac=_0x24763f['pieceNum_'];_0x3420ac<_0x24763f['pieces_']['length']-0x1;_0x3420ac++)_0x4d37db['push'](_0x24763f['pieces_'][_0x3420ac]);return new C(_0x4d37db,0x0);}function A(_0x3d42b5,_0x2d7a9a){const _0x596aef=[];for(let _0x33b4d4=_0x3d42b5['pieceNum_'];_0x33b4d4<_0x3d42b5['pieces_']['length'];_0x33b4d4++)_0x596aef['push'](_0x3d42b5['pieces_'][_0x33b4d4]);if(_0x2d7a9a instanceof C){for(let _0x26d220=_0x2d7a9a['pieceNum_'];_0x26d220<_0x2d7a9a['pieces_']['length'];_0x26d220++)_0x596aef['push'](_0x2d7a9a['pieces_'][_0x26d220]);}else{const _0xdea2b7=_0x2d7a9a['split']('/');for(let _0x1c1ae8=0x0;_0x1c1ae8<_0xdea2b7['length'];_0x1c1ae8++)_0xdea2b7[_0x1c1ae8]['length']>0x0&&_0x596aef['push'](_0xdea2b7[_0x1c1ae8]);}return new C(_0x596aef,0x0);}function v(_0x532219){return _0x532219['pieceNum_']>=_0x532219['pieces_']['length'];}function F(_0x3ce4c4,_0x2fcbb4){const _0x3b73ac=y(_0x3ce4c4),_0x3fe108=y(_0x2fcbb4);if(_0x3b73ac===null)return _0x2fcbb4;if(_0x3b73ac===_0x3fe108)return F(b(_0x3ce4c4),b(_0x2fcbb4));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2fcbb4+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3ce4c4+')');}function Th(_0x5b2dca,_0x38ffb7){const _0x52c106=kt(_0x5b2dca,0x0),_0x3aec9d=kt(_0x38ffb7,0x0);for(let _0x49e8b8=0x0;_0x49e8b8<_0x52c106['length']&&_0x49e8b8<_0x3aec9d['length'];_0x49e8b8++){const _0x115cda=He(_0x52c106[_0x49e8b8],_0x3aec9d[_0x49e8b8]);if(_0x115cda!==0x0)return _0x115cda;}return _0x52c106['length']===_0x3aec9d['length']?0x0:_0x52c106['length']<_0x3aec9d['length']?-0x1:0x1;}function qi(_0x1b23ba,_0x6bf37f){if(we(_0x1b23ba)!==we(_0x6bf37f))return!0x1;for(let _0x2a527b=_0x1b23ba['pieceNum_'],_0x4cc14e=_0x6bf37f['pieceNum_'];_0x2a527b<=_0x1b23ba['pieces_']['length'];_0x2a527b++,_0x4cc14e++)if(_0x1b23ba['pieces_'][_0x2a527b]!==_0x6bf37f['pieces_'][_0x4cc14e])return!0x1;return!0x0;}function $(_0x437f89,_0x4c1910){let _0x99c159=_0x437f89['pieceNum_'],_0x542065=_0x4c1910['pieceNum_'];if(we(_0x437f89)>we(_0x4c1910))return!0x1;for(;_0x99c159<_0x437f89['pieces_']['length'];){if(_0x437f89['pieces_'][_0x99c159]!==_0x4c1910['pieces_'][_0x542065])return!0x1;++_0x99c159,++_0x542065;}return!0x0;}class Sh{constructor(_0x50e424,_0x46d8f0){this['errorPrefix_']=_0x46d8f0,this['parts_']=kt(_0x50e424,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x53beb8=0x0;_0x53beb8<this['parts_']['length'];_0x53beb8++)this['byteLength_']+=Pn(this['parts_'][_0x53beb8]);So(this);}}function bh(_0x38ec66,_0x3bbb1f){_0x38ec66['parts_']['length']>0x0&&(_0x38ec66['byteLength_']+=0x1),_0x38ec66['parts_']['push'](_0x3bbb1f),_0x38ec66['byteLength_']+=Pn(_0x3bbb1f),So(_0x38ec66);}function Rh(_0x3453cc){const _0x1902b9=_0x3453cc['parts_']['pop']();_0x3453cc['byteLength_']-=Pn(_0x1902b9),_0x3453cc['parts_']['length']>0x0&&(_0x3453cc['byteLength_']-=0x1);}function So(_0x15d776){if(_0x15d776['byteLength_']>Js)throw new Error(_0x15d776['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x15d776['byteLength_']+').');if(_0x15d776['parts_']['length']>Qs)throw new Error(_0x15d776['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x15d776));}function Ne(_0x1eb56f){return _0x1eb56f['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1eb56f['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x35f745,_0x566d05;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x566d05='visibilitychange',_0x35f745='hidden'):typeof document['mozHidden']<'u'?(_0x566d05='mozvisibilitychange',_0x35f745='mozHidden'):typeof document['msHidden']<'u'?(_0x566d05='msvisibilitychange',_0x35f745='msHidden'):typeof document['webkitHidden']<'u'&&(_0x566d05='webkitvisibilitychange',_0x35f745='webkitHidden')),this['visible_']=!0x0,_0x566d05&&document['addEventListener'](_0x566d05,()=>{const _0x49f3a2=!document[_0x35f745];_0x49f3a2!==this['visible_']&&(this['visible_']=_0x49f3a2,this['trigger']('visible',_0x49f3a2));},!0x1);}['getInitialEvent'](_0x153ceb){return f(_0x153ceb==='visible','Unknown\x20event\x20type:\x20'+_0x153ceb),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x57535b,_0x26845d,_0x24d7a9,_0xad21fc,_0x2d956e,_0x127b37,_0xae94e,_0x2fa293){if(super(),this['repoInfo_']=_0x57535b,this['applicationId_']=_0x26845d,this['onDataUpdate_']=_0x24d7a9,this['onConnectStatus_']=_0xad21fc,this['onServerInfoUpdate_']=_0x2d956e,this['authTokenProvider_']=_0x127b37,this['appCheckTokenProvider_']=_0xae94e,this['authOverride_']=_0x2fa293,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2fa293)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x57535b['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x35fced,_0x4a7b0e,_0x5aa777){const _0x31bc70=++this['requestNumber_'],_0x39c83c={'r':_0x31bc70,'a':_0x35fced,'b':_0x4a7b0e};this['log_'](O(_0x39c83c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x39c83c),_0x5aa777&&(this['requestCBHash_'][_0x31bc70]=_0x5aa777);}['get'](_0x3e434e){this['initConnection_']();const _0x3921f1=new Ve(),_0x2a894f={'action':'g','request':{'p':_0x3e434e['_path']['toString'](),'q':_0x3e434e['_queryObject']},'onComplete':_0x20362f=>{const _0x32fa3e=_0x20362f['d'];_0x20362f['s']==='ok'?_0x3921f1['resolve'](_0x32fa3e):_0x3921f1['reject'](_0x32fa3e);}};this['outstandingGets_']['push'](_0x2a894f),this['outstandingGetCount_']++;const _0x3a9e55=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3a9e55),_0x3921f1['promise'];}['listen'](_0xcc0385,_0x2fee1a,_0x5079f8,_0x1f0c5d){this['initConnection_']();const _0x4655e7=_0xcc0385['_queryIdentifier'],_0x10923=_0xcc0385['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x10923+'\x20'+_0x4655e7),this['listens']['has'](_0x10923)||this['listens']['set'](_0x10923,new Map()),f(_0xcc0385['_queryParams']['isDefault']()||!_0xcc0385['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x10923)['has'](_0x4655e7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5af2a8={'onComplete':_0x1f0c5d,'hashFn':_0x2fee1a,'query':_0xcc0385,'tag':_0x5079f8};this['listens']['get'](_0x10923)['set'](_0x4655e7,_0x5af2a8),this['connected_']&&this['sendListen_'](_0x5af2a8);}['sendGet_'](_0x3a5d3){const _0xe966c8=this['outstandingGets_'][_0x3a5d3];this['sendRequest']('g',_0xe966c8['request'],_0x53dce2=>{delete this['outstandingGets_'][_0x3a5d3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xe966c8['onComplete']&&_0xe966c8['onComplete'](_0x53dce2);});}['sendListen_'](_0x57bd0a){const _0x18a073=_0x57bd0a['query'],_0x37bbb0=_0x18a073['_path']['toString'](),_0xc45dc6=_0x18a073['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x37bbb0+'\x20for\x20'+_0xc45dc6);const _0x329784={'p':_0x37bbb0},_0x2a1d9d='q';_0x57bd0a['tag']&&(_0x329784['q']=_0x18a073['_queryObject'],_0x329784['t']=_0x57bd0a['tag']),_0x329784['h']=_0x57bd0a['hashFn'](),this['sendRequest'](_0x2a1d9d,_0x329784,_0x5b2d39=>{const _0x17185=_0x5b2d39['d'],_0x3b883c=_0x5b2d39['s'];ie['warnOnListenWarnings_'](_0x17185,_0x18a073),(this['listens']['get'](_0x37bbb0)&&this['listens']['get'](_0x37bbb0)['get'](_0xc45dc6))===_0x57bd0a&&(this['log_']('listen\x20response',_0x5b2d39),_0x3b883c!=='ok'&&this['removeListen_'](_0x37bbb0,_0xc45dc6),_0x57bd0a['onComplete']&&_0x57bd0a['onComplete'](_0x3b883c,_0x17185));});}static['warnOnListenWarnings_'](_0x5e3072,_0x15fc6a){if(_0x5e3072&&typeof _0x5e3072=='object'&&Y(_0x5e3072,'w')){const _0x30e774=Oe(_0x5e3072,'w');if(Array['isArray'](_0x30e774)&&~_0x30e774['indexOf']('no_index')){const _0x15af76='\x22.indexOn\x22:\x20\x22'+_0x15fc6a['_queryParams']['getIndex']()['toString']()+'\x22',_0x37e22b=_0x15fc6a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x15af76+'\x20at\x20'+_0x37e22b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4581d5){this['authToken_']=_0x4581d5,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4581d5);}['reduceReconnectDelayIfAdminCredential_'](_0x219483){(_0x219483&&_0x219483['length']===0x28||vc(_0x219483))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1b6a85){this['appCheckToken_']=_0x1b6a85,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x31f5e8=this['authToken_'],_0x1236b8=yc(_0x31f5e8)?'auth':'gauth',_0x3ca18b={'cred':_0x31f5e8};this['authOverride_']===null?_0x3ca18b['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3ca18b['authvar']=this['authOverride_']),this['sendRequest'](_0x1236b8,_0x3ca18b,_0x34163c=>{const _0x608de7=_0x34163c['s'],_0xb45b4a=_0x34163c['d']||'error';this['authToken_']===_0x31f5e8&&(_0x608de7==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x608de7,_0xb45b4a));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x42c144=>{const _0x27197c=_0x42c144['s'],_0x2809a3=_0x42c144['d']||'error';_0x27197c==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x27197c,_0x2809a3);});}['unlisten'](_0x39dbf7,_0x1e8a56){const _0x379dc1=_0x39dbf7['_path']['toString'](),_0x1f7d38=_0x39dbf7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x379dc1+'\x20'+_0x1f7d38),f(_0x39dbf7['_queryParams']['isDefault']()||!_0x39dbf7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x379dc1,_0x1f7d38)&&this['connected_']&&this['sendUnlisten_'](_0x379dc1,_0x1f7d38,_0x39dbf7['_queryObject'],_0x1e8a56);}['sendUnlisten_'](_0x2a6225,_0x513b22,_0x747f29,_0x55bad9){this['log_']('Unlisten\x20on\x20'+_0x2a6225+'\x20for\x20'+_0x513b22);const _0x4b49c5={'p':_0x2a6225},_0x457853='n';_0x55bad9&&(_0x4b49c5['q']=_0x747f29,_0x4b49c5['t']=_0x55bad9),this['sendRequest'](_0x457853,_0x4b49c5);}['onDisconnectPut'](_0x1a4968,_0x11f531,_0x2ad0a9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1a4968,_0x11f531,_0x2ad0a9):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1a4968,'action':'o','data':_0x11f531,'onComplete':_0x2ad0a9});}['onDisconnectMerge'](_0x394fc0,_0x317289,_0x3b6a6b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x394fc0,_0x317289,_0x3b6a6b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x394fc0,'action':'om','data':_0x317289,'onComplete':_0x3b6a6b});}['onDisconnectCancel'](_0xe2965f,_0x46bed7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xe2965f,null,_0x46bed7):this['onDisconnectRequestQueue_']['push']({'pathString':_0xe2965f,'action':'oc','data':null,'onComplete':_0x46bed7});}['sendOnDisconnect_'](_0x279f01,_0x45aff5,_0x4d1f0c,_0x59346e){const _0x2b38f6={'p':_0x45aff5,'d':_0x4d1f0c};this['log_']('onDisconnect\x20'+_0x279f01,_0x2b38f6),this['sendRequest'](_0x279f01,_0x2b38f6,_0x54ae6e=>{_0x59346e&&setTimeout(()=>{_0x59346e(_0x54ae6e['s'],_0x54ae6e['d']);},Math['floor'](0x0));});}['put'](_0x383684,_0x5b3e67,_0x7c9e9d,_0xc06cb5){this['putInternal']('p',_0x383684,_0x5b3e67,_0x7c9e9d,_0xc06cb5);}['merge'](_0x118ee0,_0x34850c,_0x5579fa,_0x10a072){this['putInternal']('m',_0x118ee0,_0x34850c,_0x5579fa,_0x10a072);}['putInternal'](_0x36fb72,_0x5086ad,_0x256fe4,_0x5549ee,_0xe0845a){this['initConnection_']();const _0xa01773={'p':_0x5086ad,'d':_0x256fe4};_0xe0845a!==void 0x0&&(_0xa01773['h']=_0xe0845a),this['outstandingPuts_']['push']({'action':_0x36fb72,'request':_0xa01773,'onComplete':_0x5549ee}),this['outstandingPutCount_']++;const _0x45abf6=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x45abf6):this['log_']('Buffering\x20put:\x20'+_0x5086ad);}['sendPut_'](_0x3f60ce){const _0x1078eb=this['outstandingPuts_'][_0x3f60ce]['action'],_0x3bac73=this['outstandingPuts_'][_0x3f60ce]['request'],_0x1da20f=this['outstandingPuts_'][_0x3f60ce]['onComplete'];this['outstandingPuts_'][_0x3f60ce]['queued']=this['connected_'],this['sendRequest'](_0x1078eb,_0x3bac73,_0x5ad38c=>{this['log_'](_0x1078eb+'\x20response',_0x5ad38c),delete this['outstandingPuts_'][_0x3f60ce],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1da20f&&_0x1da20f(_0x5ad38c['s'],_0x5ad38c['d']);});}['reportStats'](_0x48f92a){if(this['connected_']){const _0x463667={'c':_0x48f92a};this['log_']('reportStats',_0x463667),this['sendRequest']('s',_0x463667,_0x2f06b3=>{if(_0x2f06b3['s']!=='ok'){const _0x5aadcb=_0x2f06b3['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5aadcb);}});}}['onDataMessage_'](_0x5061a8){if('r'in _0x5061a8){this['log_']('from\x20server:\x20'+O(_0x5061a8));const _0x43dae1=_0x5061a8['r'],_0x564c31=this['requestCBHash_'][_0x43dae1];_0x564c31&&(delete this['requestCBHash_'][_0x43dae1],_0x564c31(_0x5061a8['b']));}else{if('error'in _0x5061a8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5061a8['error'];'a'in _0x5061a8&&this['onDataPush_'](_0x5061a8['a'],_0x5061a8['b']);}}['onDataPush_'](_0x5066c3,_0x92e2a8){this['log_']('handleServerMessage',_0x5066c3,_0x92e2a8),_0x5066c3==='d'?this['onDataUpdate_'](_0x92e2a8['p'],_0x92e2a8['d'],!0x1,_0x92e2a8['t']):_0x5066c3==='m'?this['onDataUpdate_'](_0x92e2a8['p'],_0x92e2a8['d'],!0x0,_0x92e2a8['t']):_0x5066c3==='c'?this['onListenRevoked_'](_0x92e2a8['p'],_0x92e2a8['q']):_0x5066c3==='ac'?this['onAuthRevoked_'](_0x92e2a8['s'],_0x92e2a8['d']):_0x5066c3==='apc'?this['onAppCheckRevoked_'](_0x92e2a8['s'],_0x92e2a8['d']):_0x5066c3==='sd'?this['onSecurityDebugPacket_'](_0x92e2a8):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5066c3)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x17cd2d,_0x3123b5){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x17cd2d),this['lastSessionId']=_0x3123b5,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x57d610){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x57d610));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x184322){_0x184322&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x184322;}['onOnline_'](_0x5f4c37){_0x5f4c37?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2f682d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x28929f=Math['max'](0x0,this['reconnectDelay_']-_0x2f682d);_0x28929f=Math['random']()*_0x28929f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x28929f+'ms'),this['scheduleConnect_'](_0x28929f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x493eb=this['onDataMessage_']['bind'](this),_0x3d083f=this['onReady_']['bind'](this),_0x1c20af=this['onRealtimeDisconnect_']['bind'](this),_0x4f2272=this['id']+':'+ie['nextConnectionId_']++,_0x3a58fb=this['lastSessionId'];let _0x4e1a7a=!0x1,_0x15307e=null;const _0x44d37c=function(){_0x15307e?_0x15307e['close']():(_0x4e1a7a=!0x0,_0x1c20af());},_0x30b827=function(_0x3e77df){f(_0x15307e,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x15307e['sendRequest'](_0x3e77df);};this['realtime_']={'close':_0x44d37c,'sendRequest':_0x30b827};const _0x278f32=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5477f1,_0x52a024]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x278f32),this['appCheckTokenProvider_']['getToken'](_0x278f32)]);_0x4e1a7a?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5477f1&&_0x5477f1['accessToken'],this['appCheckToken_']=_0x52a024&&_0x52a024['token'],_0x15307e=new wh(_0x4f2272,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x493eb,_0x3d083f,_0x1c20af,_0x258422=>{U(_0x258422+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x3a58fb));}catch(_0x1d5557){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1d5557),_0x4e1a7a||(this['repoInfo_']['nodeAdmin']&&U(_0x1d5557),_0x44d37c());}}}['interrupt'](_0x3bafd3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3bafd3),this['interruptReasons_'][_0x3bafd3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5700ea){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5700ea),delete this['interruptReasons_'][_0x5700ea],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x43b7db){const _0x2d5f95=_0x43b7db-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2d5f95});}['cancelSentTransactions_'](){for(let _0x4277db=0x0;_0x4277db<this['outstandingPuts_']['length'];_0x4277db++){const _0x2fe2e0=this['outstandingPuts_'][_0x4277db];_0x2fe2e0&&'h'in _0x2fe2e0['request']&&_0x2fe2e0['queued']&&(_0x2fe2e0['onComplete']&&_0x2fe2e0['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4277db],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x41c5cb,_0x331d20){let _0xbcf44c;_0x331d20?_0xbcf44c=_0x331d20['map'](_0x1ce12d=>Bi(_0x1ce12d))['join']('$'):_0xbcf44c='default';const _0x3e85d0=this['removeListen_'](_0x41c5cb,_0xbcf44c);_0x3e85d0&&_0x3e85d0['onComplete']&&_0x3e85d0['onComplete']('permission_denied');}['removeListen_'](_0x2f751b,_0x1ef4fd){const _0x9c72c5=new C(_0x2f751b)['toString']();let _0x24b612;if(this['listens']['has'](_0x9c72c5)){const _0x1f1436=this['listens']['get'](_0x9c72c5);_0x24b612=_0x1f1436['get'](_0x1ef4fd),_0x1f1436['delete'](_0x1ef4fd),_0x1f1436['size']===0x0&&this['listens']['delete'](_0x9c72c5);}else _0x24b612=void 0x0;return _0x24b612;}['onAuthRevoked_'](_0x16dfca,_0x14b244){L('Auth\x20token\x20revoked:\x20'+_0x16dfca+'/'+_0x14b244),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x16dfca==='invalid_token'||_0x16dfca==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x45cbd7,_0x5cb051){L('App\x20check\x20token\x20revoked:\x20'+_0x45cbd7+'/'+_0x5cb051),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x45cbd7==='invalid_token'||_0x45cbd7==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x6cce59){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x6cce59):'msg'in _0x6cce59&&console['log']('FIREBASE:\x20'+_0x6cce59['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x47785b of this['listens']['values']())for(const _0x54a8a7 of _0x47785b['values']())this['sendListen_'](_0x54a8a7);for(let _0x2e5aff=0x0;_0x2e5aff<this['outstandingPuts_']['length'];_0x2e5aff++)this['outstandingPuts_'][_0x2e5aff]&&this['sendPut_'](_0x2e5aff);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1c9769=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1c9769['action'],_0x1c9769['pathString'],_0x1c9769['data'],_0x1c9769['onComplete']);}for(let _0x3b022b=0x0;_0x3b022b<this['outstandingGets_']['length'];_0x3b022b++)this['outstandingGets_'][_0x3b022b]&&this['sendGet_'](_0x3b022b);}['sendConnectStats_'](){const _0x1a4acd={};let _0x138572='js';_0x1a4acd['sdk.'+_0x138572+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1a4acd['framework.cordova']=0x1:qr()&&(_0x1a4acd['framework.reactnative']=0x1),this['reportStats'](_0x1a4acd);}['shouldReconnect_'](){const _0x48734e=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x48734e;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4ef81d,_0xfc1e64){this['name']=_0x4ef81d,this['node']=_0xfc1e64;}static['Wrap'](_0x5ccd4b,_0x28d29c){return new E(_0x5ccd4b,_0x28d29c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x50f5f4,_0xe21804){const _0x34ed60=new E(xe,_0x50f5f4),_0x1f7935=new E(xe,_0xe21804);return this['compare'](_0x34ed60,_0x1f7935)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1e2313){Xt=_0x1e2313;}['compare'](_0x460fbd,_0x31eb26){return He(_0x460fbd['name'],_0x31eb26['name']);}['isDefinedOn'](_0x31e386){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2c9ec0,_0xef4ab){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3ed60d,_0x414f3f){return f(typeof _0x3ed60d=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3ed60d,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x271dff,_0x4c16a6,_0x4b77ee,_0x7bcec6,_0x1e5845=null){this['isReverse_']=_0x7bcec6,this['resultGenerator_']=_0x1e5845,this['nodeStack_']=[];let _0x1760e9=0x1;for(;!_0x271dff['isEmpty']();)if(_0x271dff=_0x271dff,_0x1760e9=_0x4c16a6?_0x4b77ee(_0x271dff['key'],_0x4c16a6):0x1,_0x7bcec6&&(_0x1760e9*=-0x1),_0x1760e9<0x0)this['isReverse_']?_0x271dff=_0x271dff['left']:_0x271dff=_0x271dff['right'];else{if(_0x1760e9===0x0){this['nodeStack_']['push'](_0x271dff);break;}else this['nodeStack_']['push'](_0x271dff),this['isReverse_']?_0x271dff=_0x271dff['right']:_0x271dff=_0x271dff['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3eaabe=this['nodeStack_']['pop'](),_0x2cdf58;if(this['resultGenerator_']?_0x2cdf58=this['resultGenerator_'](_0x3eaabe['key'],_0x3eaabe['value']):_0x2cdf58={'key':_0x3eaabe['key'],'value':_0x3eaabe['value']},this['isReverse_']){for(_0x3eaabe=_0x3eaabe['left'];!_0x3eaabe['isEmpty']();)this['nodeStack_']['push'](_0x3eaabe),_0x3eaabe=_0x3eaabe['right'];}else{for(_0x3eaabe=_0x3eaabe['right'];!_0x3eaabe['isEmpty']();)this['nodeStack_']['push'](_0x3eaabe),_0x3eaabe=_0x3eaabe['left'];}return _0x2cdf58;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1860eb=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1860eb['key'],_0x1860eb['value']):{'key':_0x1860eb['key'],'value':_0x1860eb['value']};}}class M{constructor(_0x5c76d7,_0xf58ac9,_0xa01461,_0x8eab1f,_0x32d50d){this['key']=_0x5c76d7,this['value']=_0xf58ac9,this['color']=_0xa01461??M['RED'],this['left']=_0x8eab1f??B['EMPTY_NODE'],this['right']=_0x32d50d??B['EMPTY_NODE'];}['copy'](_0x10673f,_0x1a1e26,_0x3bf655,_0x41957d,_0x37a75c){return new M(_0x10673f??this['key'],_0x1a1e26??this['value'],_0x3bf655??this['color'],_0x41957d??this['left'],_0x37a75c??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4f10d1){return this['left']['inorderTraversal'](_0x4f10d1)||!!_0x4f10d1(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4f10d1);}['reverseTraversal'](_0x5128ab){return this['right']['reverseTraversal'](_0x5128ab)||_0x5128ab(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5128ab);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4322f0,_0x3ffeab,_0x56b7ea){let _0xb7219a=this;const _0x2c4d00=_0x56b7ea(_0x4322f0,_0xb7219a['key']);return _0x2c4d00<0x0?_0xb7219a=_0xb7219a['copy'](null,null,null,_0xb7219a['left']['insert'](_0x4322f0,_0x3ffeab,_0x56b7ea),null):_0x2c4d00===0x0?_0xb7219a=_0xb7219a['copy'](null,_0x3ffeab,null,null,null):_0xb7219a=_0xb7219a['copy'](null,null,null,null,_0xb7219a['right']['insert'](_0x4322f0,_0x3ffeab,_0x56b7ea)),_0xb7219a['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3800e2=this;return!_0x3800e2['left']['isRed_']()&&!_0x3800e2['left']['left']['isRed_']()&&(_0x3800e2=_0x3800e2['moveRedLeft_']()),_0x3800e2=_0x3800e2['copy'](null,null,null,_0x3800e2['left']['removeMin_'](),null),_0x3800e2['fixUp_']();}['remove'](_0xff3979,_0x4b0e3f){let _0x17e788,_0x30b540;if(_0x17e788=this,_0x4b0e3f(_0xff3979,_0x17e788['key'])<0x0)!_0x17e788['left']['isEmpty']()&&!_0x17e788['left']['isRed_']()&&!_0x17e788['left']['left']['isRed_']()&&(_0x17e788=_0x17e788['moveRedLeft_']()),_0x17e788=_0x17e788['copy'](null,null,null,_0x17e788['left']['remove'](_0xff3979,_0x4b0e3f),null);else{if(_0x17e788['left']['isRed_']()&&(_0x17e788=_0x17e788['rotateRight_']()),!_0x17e788['right']['isEmpty']()&&!_0x17e788['right']['isRed_']()&&!_0x17e788['right']['left']['isRed_']()&&(_0x17e788=_0x17e788['moveRedRight_']()),_0x4b0e3f(_0xff3979,_0x17e788['key'])===0x0){if(_0x17e788['right']['isEmpty']())return B['EMPTY_NODE'];_0x30b540=_0x17e788['right']['min_'](),_0x17e788=_0x17e788['copy'](_0x30b540['key'],_0x30b540['value'],null,null,_0x17e788['right']['removeMin_']());}_0x17e788=_0x17e788['copy'](null,null,null,null,_0x17e788['right']['remove'](_0xff3979,_0x4b0e3f));}return _0x17e788['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x450cc5=this;return _0x450cc5['right']['isRed_']()&&!_0x450cc5['left']['isRed_']()&&(_0x450cc5=_0x450cc5['rotateLeft_']()),_0x450cc5['left']['isRed_']()&&_0x450cc5['left']['left']['isRed_']()&&(_0x450cc5=_0x450cc5['rotateRight_']()),_0x450cc5['left']['isRed_']()&&_0x450cc5['right']['isRed_']()&&(_0x450cc5=_0x450cc5['colorFlip_']()),_0x450cc5;}['moveRedLeft_'](){let _0x1560ca=this['colorFlip_']();return _0x1560ca['right']['left']['isRed_']()&&(_0x1560ca=_0x1560ca['copy'](null,null,null,null,_0x1560ca['right']['rotateRight_']()),_0x1560ca=_0x1560ca['rotateLeft_'](),_0x1560ca=_0x1560ca['colorFlip_']()),_0x1560ca;}['moveRedRight_'](){let _0x22efb7=this['colorFlip_']();return _0x22efb7['left']['left']['isRed_']()&&(_0x22efb7=_0x22efb7['rotateRight_'](),_0x22efb7=_0x22efb7['colorFlip_']()),_0x22efb7;}['rotateLeft_'](){const _0x303f16=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x303f16,null);}['rotateRight_'](){const _0x578eae=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x578eae);}['colorFlip_'](){const _0x92547a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3c9881=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x92547a,_0x3c9881);}['checkMaxDepth_'](){const _0xa8da6e=this['check_']();return Math['pow'](0x2,_0xa8da6e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x36a7d7=this['left']['check_']();if(_0x36a7d7!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x36a7d7+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x439989,_0x5c3f45,_0x528702,_0xbedaca,_0x36f2b0){return this;}['insert'](_0x2b1c6f,_0x2c3eda,_0x25b539){return new M(_0x2b1c6f,_0x2c3eda,null);}['remove'](_0x35f148,_0x32a34c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x159cfe){return!0x1;}['reverseTraversal'](_0x579044){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2e0e91,_0x2d136e=B['EMPTY_NODE']){this['comparator_']=_0x2e0e91,this['root_']=_0x2d136e;}['insert'](_0x3d1bf4,_0x2665ba){return new B(this['comparator_'],this['root_']['insert'](_0x3d1bf4,_0x2665ba,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1df2e1){return new B(this['comparator_'],this['root_']['remove'](_0x1df2e1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x58b280){let _0x351db5,_0x3709ce=this['root_'];for(;!_0x3709ce['isEmpty']();){if(_0x351db5=this['comparator_'](_0x58b280,_0x3709ce['key']),_0x351db5===0x0)return _0x3709ce['value'];_0x351db5<0x0?_0x3709ce=_0x3709ce['left']:_0x351db5>0x0&&(_0x3709ce=_0x3709ce['right']);}return null;}['getPredecessorKey'](_0x2f3a08){let _0x3ddb31,_0x185462=this['root_'],_0x32d34f=null;for(;!_0x185462['isEmpty']();)if(_0x3ddb31=this['comparator_'](_0x2f3a08,_0x185462['key']),_0x3ddb31===0x0){if(_0x185462['left']['isEmpty']())return _0x32d34f?_0x32d34f['key']:null;for(_0x185462=_0x185462['left'];!_0x185462['right']['isEmpty']();)_0x185462=_0x185462['right'];return _0x185462['key'];}else _0x3ddb31<0x0?_0x185462=_0x185462['left']:_0x3ddb31>0x0&&(_0x32d34f=_0x185462,_0x185462=_0x185462['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x11662f){return this['root_']['inorderTraversal'](_0x11662f);}['reverseTraversal'](_0x514b8d){return this['root_']['reverseTraversal'](_0x514b8d);}['getIterator'](_0x5a1cba){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x5a1cba);}['getIteratorFrom'](_0x39921d,_0x126964){return new Zt(this['root_'],_0x39921d,this['comparator_'],!0x1,_0x126964);}['getReverseIteratorFrom'](_0x109905,_0x400f71){return new Zt(this['root_'],_0x109905,this['comparator_'],!0x0,_0x400f71);}['getReverseIterator'](_0x47342b){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x47342b);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x15788c,_0x1328e0){return He(_0x15788c['name'],_0x1328e0['name']);}function ji(_0x4a1a93,_0x508363){return He(_0x4a1a93,_0x508363);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x484ec7){vi=_0x484ec7;}const Ro=function(_0x28ff7e){return typeof _0x28ff7e=='number'?'number:'+so(_0x28ff7e):'string:'+_0x28ff7e;},Ao=function(_0x3a838f){if(_0x3a838f['isLeafNode']()){const _0x180884=_0x3a838f['val']();f(typeof _0x180884=='string'||typeof _0x180884=='number'||typeof _0x180884=='object'&&Y(_0x180884,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3a838f===vi||_0x3a838f['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3a838f===vi||_0x3a838f['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x4b410f){er=_0x4b410f;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x13dd1f,_0x52d48e=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x13dd1f,this['priorityNode_']=_0x52d48e,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5af277){return new D(this['value_'],_0x5af277);}['getImmediateChild'](_0xc818db){return _0xc818db==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3895af){return v(_0x3895af)?this:y(_0x3895af)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4dcd0c,_0x251ef6){return null;}['updateImmediateChild'](_0x2c0dba,_0x171d45){return _0x2c0dba==='.priority'?this['updatePriority'](_0x171d45):_0x171d45['isEmpty']()&&_0x2c0dba!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2c0dba,_0x171d45)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2e780e,_0x476389){const _0x4061ae=y(_0x2e780e);return _0x4061ae===null?_0x476389:_0x476389['isEmpty']()&&_0x4061ae!=='.priority'?this:(f(_0x4061ae!=='.priority'||we(_0x2e780e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4061ae,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2e780e),_0x476389)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x55bc34,_0x47506d){return!0x1;}['val'](_0x51bcfa){return _0x51bcfa&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2f5a9f='';this['priorityNode_']['isEmpty']()||(_0x2f5a9f+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2da421=typeof this['value_'];_0x2f5a9f+=_0x2da421+':',_0x2da421==='number'?_0x2f5a9f+=so(this['value_']):_0x2f5a9f+=this['value_'],this['lazyHash_']=no(_0x2f5a9f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x56f2d1){return _0x56f2d1===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x56f2d1 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x56f2d1['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x56f2d1));}['compareToLeafNode_'](_0x340765){const _0x43053b=typeof _0x340765['value_'],_0x4a1d09=typeof this['value_'],_0x1f49b6=D['VALUE_TYPE_ORDER']['indexOf'](_0x43053b),_0x525cf1=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a1d09);return f(_0x1f49b6>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x43053b),f(_0x525cf1>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a1d09),_0x1f49b6===_0x525cf1?_0x4a1d09==='object'?0x0:this['value_']<_0x340765['value_']?-0x1:this['value_']===_0x340765['value_']?0x0:0x1:_0x525cf1-_0x1f49b6;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4c5268){if(_0x4c5268===this)return!0x0;if(_0x4c5268['isLeafNode']()){const _0x3aac6a=_0x4c5268;return this['value_']===_0x3aac6a['value_']&&this['priorityNode_']['equals'](_0x3aac6a['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1582dd){ko=_0x1582dd;}function xh(_0x25ea2f){No=_0x25ea2f;}class Fh extends On{['compare'](_0xe99a39,_0x3d67de){const _0x358928=_0xe99a39['node']['getPriority'](),_0x1cca26=_0x3d67de['node']['getPriority'](),_0x219549=_0x358928['compareTo'](_0x1cca26);return _0x219549===0x0?He(_0xe99a39['name'],_0x3d67de['name']):_0x219549;}['isDefinedOn'](_0x4dc440){return!_0x4dc440['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4ea1fc,_0x23d0b6){return!_0x4ea1fc['getPriority']()['equals'](_0x23d0b6['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x395dbc,_0x47f929){const _0x13c0d1=ko(_0x395dbc);return new E(_0x47f929,new D('[PRIORITY-POST]',_0x13c0d1));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x201eca){const _0xd3efd8=_0x24365c=>parseInt(Math['log'](_0x24365c)/Uh,0xa),_0x4533e5=_0x1e889d=>parseInt(Array(_0x1e889d+0x1)['join']('1'),0x2);this['count']=_0xd3efd8(_0x201eca+0x1),this['current_']=this['count']-0x1;const _0x5f3be5=_0x4533e5(this['count']);this['bits_']=_0x201eca+0x1&_0x5f3be5;}['nextBitIsOne'](){const _0x4dfff0=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4dfff0;}}const dn=function(_0x534efc,_0x54dfc3,_0x476fb7,_0xc8b16){_0x534efc['sort'](_0x54dfc3);const _0x1aac87=function(_0x568598,_0x5a6757){const _0x5f04ef=_0x5a6757-_0x568598;let _0x17179e,_0x4b62e3;if(_0x5f04ef===0x0)return null;if(_0x5f04ef===0x1)return _0x17179e=_0x534efc[_0x568598],_0x4b62e3=_0x476fb7?_0x476fb7(_0x17179e):_0x17179e,new M(_0x4b62e3,_0x17179e['node'],M['BLACK'],null,null);{const _0x381ddb=parseInt(_0x5f04ef/0x2,0xa)+_0x568598,_0xca5b30=_0x1aac87(_0x568598,_0x381ddb),_0x1e9c76=_0x1aac87(_0x381ddb+0x1,_0x5a6757);return _0x17179e=_0x534efc[_0x381ddb],_0x4b62e3=_0x476fb7?_0x476fb7(_0x17179e):_0x17179e,new M(_0x4b62e3,_0x17179e['node'],M['BLACK'],_0xca5b30,_0x1e9c76);}},_0x25c53d=function(_0x2db66d){let _0x493586=null,_0x1bf41a=null,_0x16bd8d=_0x534efc['length'];const _0x334525=function(_0x8b54ac,_0x17bc9e){const _0xa9eae9=_0x16bd8d-_0x8b54ac,_0x1ba5e4=_0x16bd8d;_0x16bd8d-=_0x8b54ac;const _0x4d9ec5=_0x1aac87(_0xa9eae9+0x1,_0x1ba5e4),_0x2b6dd0=_0x534efc[_0xa9eae9],_0x2db9b9=_0x476fb7?_0x476fb7(_0x2b6dd0):_0x2b6dd0;_0x3b3c48(new M(_0x2db9b9,_0x2b6dd0['node'],_0x17bc9e,null,_0x4d9ec5));},_0x3b3c48=function(_0x399e6b){_0x493586?(_0x493586['left']=_0x399e6b,_0x493586=_0x399e6b):(_0x1bf41a=_0x399e6b,_0x493586=_0x399e6b);};for(let _0x2f5cda=0x0;_0x2f5cda<_0x2db66d['count'];++_0x2f5cda){const _0x43e4bc=_0x2db66d['nextBitIsOne'](),_0x46bd3c=Math['pow'](0x2,_0x2db66d['count']-(_0x2f5cda+0x1));_0x43e4bc?_0x334525(_0x46bd3c,M['BLACK']):(_0x334525(_0x46bd3c,M['BLACK']),_0x334525(_0x46bd3c,M['RED']));}return _0x1bf41a;},_0x454386=new Wh(_0x534efc['length']),_0x134ae8=_0x25c53d(_0x454386);return new B(_0xc8b16||_0x54dfc3,_0x134ae8);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x4858a5,_0x27f8ba){this['indexes_']=_0x4858a5,this['indexSet_']=_0x27f8ba;}['get'](_0x4b3740){const _0x39e423=Oe(this['indexes_'],_0x4b3740);if(!_0x39e423)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4b3740);return _0x39e423 instanceof B?_0x39e423:null;}['hasIndex'](_0x4ba51d){return Y(this['indexSet_'],_0x4ba51d['toString']());}['addIndex'](_0x2784ff,_0x36560e){f(_0x2784ff!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x13605d=[];let _0xe896b=!0x1;const _0x5eee71=_0x36560e['getIterator'](E['Wrap']);let _0x1986cd=_0x5eee71['getNext']();for(;_0x1986cd;)_0xe896b=_0xe896b||_0x2784ff['isDefinedOn'](_0x1986cd['node']),_0x13605d['push'](_0x1986cd),_0x1986cd=_0x5eee71['getNext']();let _0x5ee0ce;_0xe896b?_0x5ee0ce=dn(_0x13605d,_0x2784ff['getCompare']()):_0x5ee0ce=je;const _0x2c0cbb=_0x2784ff['toString'](),_0x260f38={...this['indexSet_']};_0x260f38[_0x2c0cbb]=_0x2784ff;const _0x4dd217={...this['indexes_']};return _0x4dd217[_0x2c0cbb]=_0x5ee0ce,new ee(_0x4dd217,_0x260f38);}['addToIndexes'](_0x314ed3,_0x4d9342){const _0x3fffd4=ln(this['indexes_'],(_0x4290db,_0x51d075)=>{const _0x40cd20=Oe(this['indexSet_'],_0x51d075);if(f(_0x40cd20,'Missing\x20index\x20implementation\x20for\x20'+_0x51d075),_0x4290db===je){if(_0x40cd20['isDefinedOn'](_0x314ed3['node'])){const _0x327843=[],_0x2c1e81=_0x4d9342['getIterator'](E['Wrap']);let _0x512260=_0x2c1e81['getNext']();for(;_0x512260;)_0x512260['name']!==_0x314ed3['name']&&_0x327843['push'](_0x512260),_0x512260=_0x2c1e81['getNext']();return _0x327843['push'](_0x314ed3),dn(_0x327843,_0x40cd20['getCompare']());}else return je;}else{const _0x571f87=_0x4d9342['get'](_0x314ed3['name']);let _0x3486a4=_0x4290db;return _0x571f87&&(_0x3486a4=_0x3486a4['remove'](new E(_0x314ed3['name'],_0x571f87))),_0x3486a4['insert'](_0x314ed3,_0x314ed3['node']);}});return new ee(_0x3fffd4,this['indexSet_']);}['removeFromIndexes'](_0x31f412,_0x21b463){const _0x5a8367=ln(this['indexes_'],_0x16234c=>{if(_0x16234c===je)return _0x16234c;{const _0x97e8a6=_0x21b463['get'](_0x31f412['name']);return _0x97e8a6?_0x16234c['remove'](new E(_0x31f412['name'],_0x97e8a6)):_0x16234c;}});return new ee(_0x5a8367,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x1c6bf3,_0x4feb1f,_0x3bede8){this['children_']=_0x1c6bf3,this['priorityNode_']=_0x4feb1f,this['indexMap_']=_0x3bede8,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x492420){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x492420,this['indexMap_']);}['getImmediateChild'](_0x457b65){if(_0x457b65==='.priority')return this['getPriority']();{const _0x17b9a6=this['children_']['get'](_0x457b65);return _0x17b9a6===null?gt:_0x17b9a6;}}['getChild'](_0x1fd850){const _0x453079=y(_0x1fd850);return _0x453079===null?this:this['getImmediateChild'](_0x453079)['getChild'](b(_0x1fd850));}['hasChild'](_0x4978ef){return this['children_']['get'](_0x4978ef)!==null;}['updateImmediateChild'](_0x317812,_0x2db9cf){if(f(_0x2db9cf,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x317812==='.priority')return this['updatePriority'](_0x2db9cf);{const _0x3be399=new E(_0x317812,_0x2db9cf);let _0x59947a,_0x5a91b1;_0x2db9cf['isEmpty']()?(_0x59947a=this['children_']['remove'](_0x317812),_0x5a91b1=this['indexMap_']['removeFromIndexes'](_0x3be399,this['children_'])):(_0x59947a=this['children_']['insert'](_0x317812,_0x2db9cf),_0x5a91b1=this['indexMap_']['addToIndexes'](_0x3be399,this['children_']));const _0x15eb07=_0x59947a['isEmpty']()?gt:this['priorityNode_'];return new g(_0x59947a,_0x15eb07,_0x5a91b1);}}['updateChild'](_0x142185,_0x2dfac0){const _0x3ffb8d=y(_0x142185);if(_0x3ffb8d===null)return _0x2dfac0;{f(y(_0x142185)!=='.priority'||we(_0x142185)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2138c7=this['getImmediateChild'](_0x3ffb8d)['updateChild'](b(_0x142185),_0x2dfac0);return this['updateImmediateChild'](_0x3ffb8d,_0x2138c7);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2723da){if(this['isEmpty']())return null;const _0x5b88da={};let _0x43ac4d=0x0,_0x33ab8d=0x0,_0x508140=!0x0;if(this['forEachChild'](R,(_0x565e73,_0xa74b86)=>{_0x5b88da[_0x565e73]=_0xa74b86['val'](_0x2723da),_0x43ac4d++,_0x508140&&g['INTEGER_REGEXP_']['test'](_0x565e73)?_0x33ab8d=Math['max'](_0x33ab8d,Number(_0x565e73)):_0x508140=!0x1;}),!_0x2723da&&_0x508140&&_0x33ab8d<0x2*_0x43ac4d){const _0x225704=[];for(const _0x4f2e59 in _0x5b88da)_0x225704[_0x4f2e59]=_0x5b88da[_0x4f2e59];return _0x225704;}else return _0x2723da&&!this['getPriority']()['isEmpty']()&&(_0x5b88da['.priority']=this['getPriority']()['val']()),_0x5b88da;}['hash'](){if(this['lazyHash_']===null){let _0x4ff224='';this['getPriority']()['isEmpty']()||(_0x4ff224+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4b83e7,_0x2653da)=>{const _0x211904=_0x2653da['hash']();_0x211904!==''&&(_0x4ff224+=':'+_0x4b83e7+':'+_0x211904);}),this['lazyHash_']=_0x4ff224===''?'':no(_0x4ff224);}return this['lazyHash_'];}['getPredecessorChildName'](_0x10ba81,_0x23d00b,_0x2a314b){const _0x5add39=this['resolveIndex_'](_0x2a314b);if(_0x5add39){const _0x1a93c1=_0x5add39['getPredecessorKey'](new E(_0x10ba81,_0x23d00b));return _0x1a93c1?_0x1a93c1['name']:null;}else return this['children_']['getPredecessorKey'](_0x10ba81);}['getFirstChildName'](_0xdead46){const _0x125d99=this['resolveIndex_'](_0xdead46);if(_0x125d99){const _0x92a654=_0x125d99['minKey']();return _0x92a654&&_0x92a654['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2540e9){const _0x10db5b=this['getFirstChildName'](_0x2540e9);return _0x10db5b?new E(_0x10db5b,this['children_']['get'](_0x10db5b)):null;}['getLastChildName'](_0x416282){const _0x2a3698=this['resolveIndex_'](_0x416282);if(_0x2a3698){const _0x51b71b=_0x2a3698['maxKey']();return _0x51b71b&&_0x51b71b['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x6c4bc2){const _0x56a729=this['getLastChildName'](_0x6c4bc2);return _0x56a729?new E(_0x56a729,this['children_']['get'](_0x56a729)):null;}['forEachChild'](_0x4ec19f,_0x1e19fe){const _0x594ca0=this['resolveIndex_'](_0x4ec19f);return _0x594ca0?_0x594ca0['inorderTraversal'](_0x259cad=>_0x1e19fe(_0x259cad['name'],_0x259cad['node'])):this['children_']['inorderTraversal'](_0x1e19fe);}['getIterator'](_0x23f4a8){return this['getIteratorFrom'](_0x23f4a8['minPost'](),_0x23f4a8);}['getIteratorFrom'](_0x1f3ec5,_0x343322){const _0xa87287=this['resolveIndex_'](_0x343322);if(_0xa87287)return _0xa87287['getIteratorFrom'](_0x1f3ec5,_0x4b04fe=>_0x4b04fe);{const _0x3f445e=this['children_']['getIteratorFrom'](_0x1f3ec5['name'],E['Wrap']);let _0x3a803a=_0x3f445e['peek']();for(;_0x3a803a!=null&&_0x343322['compare'](_0x3a803a,_0x1f3ec5)<0x0;)_0x3f445e['getNext'](),_0x3a803a=_0x3f445e['peek']();return _0x3f445e;}}['getReverseIterator'](_0x377ae4){return this['getReverseIteratorFrom'](_0x377ae4['maxPost'](),_0x377ae4);}['getReverseIteratorFrom'](_0x51cd66,_0x1359c9){const _0x1a1439=this['resolveIndex_'](_0x1359c9);if(_0x1a1439)return _0x1a1439['getReverseIteratorFrom'](_0x51cd66,_0x4b3128=>_0x4b3128);{const _0x2561cb=this['children_']['getReverseIteratorFrom'](_0x51cd66['name'],E['Wrap']);let _0x5a936a=_0x2561cb['peek']();for(;_0x5a936a!=null&&_0x1359c9['compare'](_0x5a936a,_0x51cd66)>0x0;)_0x2561cb['getNext'](),_0x5a936a=_0x2561cb['peek']();return _0x2561cb;}}['compareTo'](_0x2e759f){return this['isEmpty']()?_0x2e759f['isEmpty']()?0x0:-0x1:_0x2e759f['isLeafNode']()||_0x2e759f['isEmpty']()?0x1:_0x2e759f===Ht?-0x1:0x0;}['withIndex'](_0x5498f2){if(_0x5498f2===ye||this['indexMap_']['hasIndex'](_0x5498f2))return this;{const _0x459157=this['indexMap_']['addIndex'](_0x5498f2,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x459157);}}['isIndexed'](_0x4e8252){return _0x4e8252===ye||this['indexMap_']['hasIndex'](_0x4e8252);}['equals'](_0x472a4f){if(_0x472a4f===this)return!0x0;if(_0x472a4f['isLeafNode']())return!0x1;{const _0x5a0dc0=_0x472a4f;if(this['getPriority']()['equals'](_0x5a0dc0['getPriority']())){if(this['children_']['count']()===_0x5a0dc0['children_']['count']()){const _0x5be3ae=this['getIterator'](R),_0xf05c8d=_0x5a0dc0['getIterator'](R);let _0x29bc77=_0x5be3ae['getNext'](),_0xe609bc=_0xf05c8d['getNext']();for(;_0x29bc77&&_0xe609bc;){if(_0x29bc77['name']!==_0xe609bc['name']||!_0x29bc77['node']['equals'](_0xe609bc['node']))return!0x1;_0x29bc77=_0x5be3ae['getNext'](),_0xe609bc=_0xf05c8d['getNext']();}return _0x29bc77===null&&_0xe609bc===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x447fbd){return _0x447fbd===ye?null:this['indexMap_']['get'](_0x447fbd['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x500642){return _0x500642===this?0x0:0x1;}['equals'](_0x46921f){return _0x46921f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x396bbc){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x361ff9,_0x36fd6a=null){if(_0x361ff9===null)return g['EMPTY_NODE'];if(typeof _0x361ff9=='object'&&'.priority'in _0x361ff9&&(_0x36fd6a=_0x361ff9['.priority']),f(_0x36fd6a===null||typeof _0x36fd6a=='string'||typeof _0x36fd6a=='number'||typeof _0x36fd6a=='object'&&'.sv'in _0x36fd6a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x36fd6a),typeof _0x361ff9=='object'&&'.value'in _0x361ff9&&_0x361ff9['.value']!==null&&(_0x361ff9=_0x361ff9['.value']),typeof _0x361ff9!='object'||'.sv'in _0x361ff9){const _0x64cc9a=_0x361ff9;return new D(_0x64cc9a,N(_0x36fd6a));}if(!(_0x361ff9 instanceof Array)&&Vh){const _0x18b033=[];let _0x5cc870=!0x1;if(x(_0x361ff9,(_0x21db1d,_0x3d1170)=>{if(_0x21db1d['substring'](0x0,0x1)!=='.'){const _0xe8ad02=N(_0x3d1170);_0xe8ad02['isEmpty']()||(_0x5cc870=_0x5cc870||!_0xe8ad02['getPriority']()['isEmpty'](),_0x18b033['push'](new E(_0x21db1d,_0xe8ad02)));}}),_0x18b033['length']===0x0)return g['EMPTY_NODE'];const _0x163e90=dn(_0x18b033,Dh,_0x42983b=>_0x42983b['name'],ji);if(_0x5cc870){const _0x25dd13=dn(_0x18b033,R['getCompare']());return new g(_0x163e90,N(_0x36fd6a),new ee({'.priority':_0x25dd13},{'.priority':R}));}else return new g(_0x163e90,N(_0x36fd6a),ee['Default']);}else{let _0x165ac9=g['EMPTY_NODE'];return x(_0x361ff9,(_0x5ea44e,_0x1129ee)=>{if(Y(_0x361ff9,_0x5ea44e)&&_0x5ea44e['substring'](0x0,0x1)!=='.'){const _0x55308d=N(_0x1129ee);(_0x55308d['isLeafNode']()||!_0x55308d['isEmpty']())&&(_0x165ac9=_0x165ac9['updateImmediateChild'](_0x5ea44e,_0x55308d));}}),_0x165ac9['updatePriority'](N(_0x36fd6a));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x94d19d){super(),this['indexPath_']=_0x94d19d,f(!v(_0x94d19d)&&y(_0x94d19d)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x7c6683){return _0x7c6683['getChild'](this['indexPath_']);}['isDefinedOn'](_0x48f5b8){return!_0x48f5b8['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x285831,_0x4ce1ed){const _0x1966ae=this['extractChild'](_0x285831['node']),_0x48dba6=this['extractChild'](_0x4ce1ed['node']),_0x50a72c=_0x1966ae['compareTo'](_0x48dba6);return _0x50a72c===0x0?He(_0x285831['name'],_0x4ce1ed['name']):_0x50a72c;}['makePost'](_0x3cc1a8,_0x22b809){const _0x2f4afc=N(_0x3cc1a8),_0x4a44f8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2f4afc);return new E(_0x22b809,_0x4a44f8);}['maxPost'](){const _0x59aba1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x59aba1);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x427ee7,_0x5919ca){const _0x4915bf=_0x427ee7['node']['compareTo'](_0x5919ca['node']);return _0x4915bf===0x0?He(_0x427ee7['name'],_0x5919ca['name']):_0x4915bf;}['isDefinedOn'](_0x50b89e){return!0x0;}['indexedValueChanged'](_0x3e3a9e,_0x3fed4f){return!_0x3e3a9e['equals'](_0x3fed4f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x53b3dc,_0xf4956a){const _0x4e979c=N(_0x53b3dc);return new E(_0xf4956a,_0x4e979c);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x48611f){return{'type':'value','snapshotNode':_0x48611f};}function tt(_0x27e770,_0x5174db){return{'type':'child_added','snapshotNode':_0x5174db,'childName':_0x27e770};}function Nt(_0x87882d,_0x35175f){return{'type':'child_removed','snapshotNode':_0x35175f,'childName':_0x87882d};}function Pt(_0xd333d9,_0x178517,_0x2056fc){return{'type':'child_changed','snapshotNode':_0x178517,'childName':_0xd333d9,'oldSnap':_0x2056fc};}function $h(_0x14533b,_0x4f77c8){return{'type':'child_moved','snapshotNode':_0x4f77c8,'childName':_0x14533b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x9755e0){this['index_']=_0x9755e0;}['updateChild'](_0x295b06,_0x52c66f,_0x51d86b,_0x14da50,_0x5d1cf4,_0x362bdc){f(_0x295b06['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xe187a6=_0x295b06['getImmediateChild'](_0x52c66f);return _0xe187a6['getChild'](_0x14da50)['equals'](_0x51d86b['getChild'](_0x14da50))&&_0xe187a6['isEmpty']()===_0x51d86b['isEmpty']()||(_0x362bdc!=null&&(_0x51d86b['isEmpty']()?_0x295b06['hasChild'](_0x52c66f)?_0x362bdc['trackChildChange'](Nt(_0x52c66f,_0xe187a6)):f(_0x295b06['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xe187a6['isEmpty']()?_0x362bdc['trackChildChange'](tt(_0x52c66f,_0x51d86b)):_0x362bdc['trackChildChange'](Pt(_0x52c66f,_0x51d86b,_0xe187a6))),_0x295b06['isLeafNode']()&&_0x51d86b['isEmpty']())?_0x295b06:_0x295b06['updateImmediateChild'](_0x52c66f,_0x51d86b)['withIndex'](this['index_']);}['updateFullNode'](_0x173578,_0x3c8548,_0x12d3f1){return _0x12d3f1!=null&&(_0x173578['isLeafNode']()||_0x173578['forEachChild'](R,(_0x3db12f,_0x84f3ae)=>{_0x3c8548['hasChild'](_0x3db12f)||_0x12d3f1['trackChildChange'](Nt(_0x3db12f,_0x84f3ae));}),_0x3c8548['isLeafNode']()||_0x3c8548['forEachChild'](R,(_0x4d0baf,_0x4ec9df)=>{if(_0x173578['hasChild'](_0x4d0baf)){const _0x1775d5=_0x173578['getImmediateChild'](_0x4d0baf);_0x1775d5['equals'](_0x4ec9df)||_0x12d3f1['trackChildChange'](Pt(_0x4d0baf,_0x4ec9df,_0x1775d5));}else _0x12d3f1['trackChildChange'](tt(_0x4d0baf,_0x4ec9df));})),_0x3c8548['withIndex'](this['index_']);}['updatePriority'](_0x515b09,_0x8069e5){return _0x515b09['isEmpty']()?g['EMPTY_NODE']:_0x515b09['updatePriority'](_0x8069e5);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2e1aaf){this['indexedFilter_']=new Yi(_0x2e1aaf['getIndex']()),this['index_']=_0x2e1aaf['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2e1aaf),this['endPost_']=Ot['getEndPost_'](_0x2e1aaf),this['startIsInclusive_']=!_0x2e1aaf['startAfterSet_'],this['endIsInclusive_']=!_0x2e1aaf['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1bd815){const _0x47d11e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1bd815)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1bd815)<0x0,_0x10413f=this['endIsInclusive_']?this['index_']['compare'](_0x1bd815,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1bd815,this['getEndPost']())<0x0;return _0x47d11e&&_0x10413f;}['updateChild'](_0xa2862d,_0x4242a9,_0x2d20eb,_0x113956,_0x163d0b,_0x1c8ee5){return this['matches'](new E(_0x4242a9,_0x2d20eb))||(_0x2d20eb=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xa2862d,_0x4242a9,_0x2d20eb,_0x113956,_0x163d0b,_0x1c8ee5);}['updateFullNode'](_0x1bfe8b,_0x4663fc,_0x462d03){_0x4663fc['isLeafNode']()&&(_0x4663fc=g['EMPTY_NODE']);let _0x353b71=_0x4663fc['withIndex'](this['index_']);_0x353b71=_0x353b71['updatePriority'](g['EMPTY_NODE']);const _0x4fd134=this;return _0x4663fc['forEachChild'](R,(_0x3e71e2,_0x18588c)=>{_0x4fd134['matches'](new E(_0x3e71e2,_0x18588c))||(_0x353b71=_0x353b71['updateImmediateChild'](_0x3e71e2,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1bfe8b,_0x353b71,_0x462d03);}['updatePriority'](_0x1cdf4f,_0x492b61){return _0x1cdf4f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4edd95){if(_0x4edd95['hasStart']()){const _0x25efc8=_0x4edd95['getIndexStartName']();return _0x4edd95['getIndex']()['makePost'](_0x4edd95['getIndexStartValue'](),_0x25efc8);}else return _0x4edd95['getIndex']()['minPost']();}static['getEndPost_'](_0x24a309){if(_0x24a309['hasEnd']()){const _0x27d6b1=_0x24a309['getIndexEndName']();return _0x24a309['getIndex']()['makePost'](_0x24a309['getIndexEndValue'](),_0x27d6b1);}else return _0x24a309['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x20c611){this['withinDirectionalStart']=_0x318c27=>this['reverse_']?this['withinEndPost'](_0x318c27):this['withinStartPost'](_0x318c27),this['withinDirectionalEnd']=_0x3ea186=>this['reverse_']?this['withinStartPost'](_0x3ea186):this['withinEndPost'](_0x3ea186),this['withinStartPost']=_0xa003fb=>{const _0x56a749=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xa003fb);return this['startIsInclusive_']?_0x56a749<=0x0:_0x56a749<0x0;},this['withinEndPost']=_0xa15d85=>{const _0x13d63c=this['index_']['compare'](_0xa15d85,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x13d63c<=0x0:_0x13d63c<0x0;},this['rangedFilter_']=new Ot(_0x20c611),this['index_']=_0x20c611['getIndex'](),this['limit_']=_0x20c611['getLimit'](),this['reverse_']=!_0x20c611['isViewFromLeft'](),this['startIsInclusive_']=!_0x20c611['startAfterSet_'],this['endIsInclusive_']=!_0x20c611['endBeforeSet_'];}['updateChild'](_0x168c9d,_0x4b5113,_0x1cd77b,_0x544845,_0x5687e1,_0x14a0bf){return this['rangedFilter_']['matches'](new E(_0x4b5113,_0x1cd77b))||(_0x1cd77b=g['EMPTY_NODE']),_0x168c9d['getImmediateChild'](_0x4b5113)['equals'](_0x1cd77b)?_0x168c9d:_0x168c9d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x168c9d,_0x4b5113,_0x1cd77b,_0x544845,_0x5687e1,_0x14a0bf):this['fullLimitUpdateChild_'](_0x168c9d,_0x4b5113,_0x1cd77b,_0x5687e1,_0x14a0bf);}['updateFullNode'](_0x4a5134,_0x1e1883,_0xdf0e74){let _0x1ed6f1;if(_0x1e1883['isLeafNode']()||_0x1e1883['isEmpty']())_0x1ed6f1=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1e1883['numChildren']()&&_0x1e1883['isIndexed'](this['index_'])){_0x1ed6f1=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x415c63;this['reverse_']?_0x415c63=_0x1e1883['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x415c63=_0x1e1883['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3fe802=0x0;for(;_0x415c63['hasNext']()&&_0x3fe802<this['limit_'];){const _0x10c7f4=_0x415c63['getNext']();if(this['withinDirectionalStart'](_0x10c7f4)){if(this['withinDirectionalEnd'](_0x10c7f4))_0x1ed6f1=_0x1ed6f1['updateImmediateChild'](_0x10c7f4['name'],_0x10c7f4['node']),_0x3fe802++;else break;}else continue;}}else{_0x1ed6f1=_0x1e1883['withIndex'](this['index_']),_0x1ed6f1=_0x1ed6f1['updatePriority'](g['EMPTY_NODE']);let _0x1475ce;this['reverse_']?_0x1475ce=_0x1ed6f1['getReverseIterator'](this['index_']):_0x1475ce=_0x1ed6f1['getIterator'](this['index_']);let _0x2384e1=0x0;for(;_0x1475ce['hasNext']();){const _0x236150=_0x1475ce['getNext']();_0x2384e1<this['limit_']&&this['withinDirectionalStart'](_0x236150)&&this['withinDirectionalEnd'](_0x236150)?_0x2384e1++:_0x1ed6f1=_0x1ed6f1['updateImmediateChild'](_0x236150['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4a5134,_0x1ed6f1,_0xdf0e74);}['updatePriority'](_0x6149b5,_0x2071b8){return _0x6149b5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x441a6d,_0x47b9c6,_0x5d5540,_0x3bde43,_0x3d9240){let _0x4977bb;if(this['reverse_']){const _0xfcfc25=this['index_']['getCompare']();_0x4977bb=(_0x23aaf7,_0x5d6ceb)=>_0xfcfc25(_0x5d6ceb,_0x23aaf7);}else _0x4977bb=this['index_']['getCompare']();const _0x100341=_0x441a6d;f(_0x100341['numChildren']()===this['limit_'],'');const _0x46a330=new E(_0x47b9c6,_0x5d5540),_0x20664d=this['reverse_']?_0x100341['getFirstChild'](this['index_']):_0x100341['getLastChild'](this['index_']),_0x1bb06d=this['rangedFilter_']['matches'](_0x46a330);if(_0x100341['hasChild'](_0x47b9c6)){const _0x170dc6=_0x100341['getImmediateChild'](_0x47b9c6);let _0x521135=_0x3bde43['getChildAfterChild'](this['index_'],_0x20664d,this['reverse_']);for(;_0x521135!=null&&(_0x521135['name']===_0x47b9c6||_0x100341['hasChild'](_0x521135['name']));)_0x521135=_0x3bde43['getChildAfterChild'](this['index_'],_0x521135,this['reverse_']);const _0x31305c=_0x521135==null?0x1:_0x4977bb(_0x521135,_0x46a330);if(_0x1bb06d&&!_0x5d5540['isEmpty']()&&_0x31305c>=0x0)return _0x3d9240!=null&&_0x3d9240['trackChildChange'](Pt(_0x47b9c6,_0x5d5540,_0x170dc6)),_0x100341['updateImmediateChild'](_0x47b9c6,_0x5d5540);{_0x3d9240!=null&&_0x3d9240['trackChildChange'](Nt(_0x47b9c6,_0x170dc6));const _0x1bf116=_0x100341['updateImmediateChild'](_0x47b9c6,g['EMPTY_NODE']);return _0x521135!=null&&this['rangedFilter_']['matches'](_0x521135)?(_0x3d9240!=null&&_0x3d9240['trackChildChange'](tt(_0x521135['name'],_0x521135['node'])),_0x1bf116['updateImmediateChild'](_0x521135['name'],_0x521135['node'])):_0x1bf116;}}else return _0x5d5540['isEmpty']()?_0x441a6d:_0x1bb06d&&_0x4977bb(_0x20664d,_0x46a330)>=0x0?(_0x3d9240!=null&&(_0x3d9240['trackChildChange'](Nt(_0x20664d['name'],_0x20664d['node'])),_0x3d9240['trackChildChange'](tt(_0x47b9c6,_0x5d5540))),_0x100341['updateImmediateChild'](_0x47b9c6,_0x5d5540)['updateImmediateChild'](_0x20664d['name'],g['EMPTY_NODE'])):_0x441a6d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x6fff6b=new Qi();return _0x6fff6b['limitSet_']=this['limitSet_'],_0x6fff6b['limit_']=this['limit_'],_0x6fff6b['startSet_']=this['startSet_'],_0x6fff6b['startAfterSet_']=this['startAfterSet_'],_0x6fff6b['indexStartValue_']=this['indexStartValue_'],_0x6fff6b['startNameSet_']=this['startNameSet_'],_0x6fff6b['indexStartName_']=this['indexStartName_'],_0x6fff6b['endSet_']=this['endSet_'],_0x6fff6b['endBeforeSet_']=this['endBeforeSet_'],_0x6fff6b['indexEndValue_']=this['indexEndValue_'],_0x6fff6b['endNameSet_']=this['endNameSet_'],_0x6fff6b['indexEndName_']=this['indexEndName_'],_0x6fff6b['index_']=this['index_'],_0x6fff6b['viewFrom_']=this['viewFrom_'],_0x6fff6b;}}function qh(_0x1f856c){return _0x1f856c['loadsAllData']()?new Yi(_0x1f856c['getIndex']()):_0x1f856c['hasLimit']()?new Gh(_0x1f856c):new Ot(_0x1f856c);}function zh(_0x490f38,_0x3335a1){const _0xb475b1=_0x490f38['copy']();return _0xb475b1['limitSet_']=!0x0,_0xb475b1['limit_']=_0x3335a1,_0xb475b1['viewFrom_']='l',_0xb475b1;}function jh(_0x1818b0,_0x41e312,_0x452b0f){const _0x4a67de=_0x1818b0['copy']();return _0x4a67de['startSet_']=!0x0,_0x41e312===void 0x0&&(_0x41e312=null),_0x4a67de['indexStartValue_']=_0x41e312,_0x452b0f!=null?(_0x4a67de['startNameSet_']=!0x0,_0x4a67de['indexStartName_']=_0x452b0f):(_0x4a67de['startNameSet_']=!0x1,_0x4a67de['indexStartName_']=''),_0x4a67de;}function Kh(_0xcc627b,_0x458bd3,_0x24aff2){const _0x2206c1=_0xcc627b['copy']();return _0x2206c1['endSet_']=!0x0,_0x458bd3===void 0x0&&(_0x458bd3=null),_0x2206c1['indexEndValue_']=_0x458bd3,_0x24aff2!==void 0x0?(_0x2206c1['endNameSet_']=!0x0,_0x2206c1['indexEndName_']=_0x24aff2):(_0x2206c1['endNameSet_']=!0x1,_0x2206c1['indexEndName_']=''),_0x2206c1;}function Do(_0x515845,_0x528a48){const _0x438416=_0x515845['copy']();return _0x438416['index_']=_0x528a48,_0x438416;}function tr(_0x5cb560){const _0xc2d2f0={};if(_0x5cb560['isDefault']())return _0xc2d2f0;let _0x3d9055;if(_0x5cb560['index_']===R?_0x3d9055='$priority':_0x5cb560['index_']===Po?_0x3d9055='$value':_0x5cb560['index_']===ye?_0x3d9055='$key':(f(_0x5cb560['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x3d9055=_0x5cb560['index_']['toString']()),_0xc2d2f0['orderBy']=O(_0x3d9055),_0x5cb560['startSet_']){const _0x1f5756=_0x5cb560['startAfterSet_']?'startAfter':'startAt';_0xc2d2f0[_0x1f5756]=O(_0x5cb560['indexStartValue_']),_0x5cb560['startNameSet_']&&(_0xc2d2f0[_0x1f5756]+=','+O(_0x5cb560['indexStartName_']));}if(_0x5cb560['endSet_']){const _0x5cc756=_0x5cb560['endBeforeSet_']?'endBefore':'endAt';_0xc2d2f0[_0x5cc756]=O(_0x5cb560['indexEndValue_']),_0x5cb560['endNameSet_']&&(_0xc2d2f0[_0x5cc756]+=','+O(_0x5cb560['indexEndName_']));}return _0x5cb560['limitSet_']&&(_0x5cb560['isViewFromLeft']()?_0xc2d2f0['limitToFirst']=_0x5cb560['limit_']:_0xc2d2f0['limitToLast']=_0x5cb560['limit_']),_0xc2d2f0;}function nr(_0x3fef18){const _0x266628={};if(_0x3fef18['startSet_']&&(_0x266628['sp']=_0x3fef18['indexStartValue_'],_0x3fef18['startNameSet_']&&(_0x266628['sn']=_0x3fef18['indexStartName_']),_0x266628['sin']=!_0x3fef18['startAfterSet_']),_0x3fef18['endSet_']&&(_0x266628['ep']=_0x3fef18['indexEndValue_'],_0x3fef18['endNameSet_']&&(_0x266628['en']=_0x3fef18['indexEndName_']),_0x266628['ein']=!_0x3fef18['endBeforeSet_']),_0x3fef18['limitSet_']){_0x266628['l']=_0x3fef18['limit_'];let _0x3fe992=_0x3fef18['viewFrom_'];_0x3fe992===''&&(_0x3fef18['isViewFromLeft']()?_0x3fe992='l':_0x3fe992='r'),_0x266628['vf']=_0x3fe992;}return _0x3fef18['index_']!==R&&(_0x266628['i']=_0x3fef18['index_']['toString']()),_0x266628;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x4c057e){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xb8d898,_0x1cefc4){return _0x1cefc4!==void 0x0?'tag$'+_0x1cefc4:(f(_0xb8d898['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xb8d898['_path']['toString']());}constructor(_0x5b63f6,_0x9633cf,_0x292650,_0x2f131b){super(),this['repoInfo_']=_0x5b63f6,this['onDataUpdate_']=_0x9633cf,this['authTokenProvider_']=_0x292650,this['appCheckTokenProvider_']=_0x2f131b,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x29c641,_0x2b4cf7,_0x14bf3c,_0x32bfba){const _0x1d7172=_0x29c641['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1d7172+'\x20'+_0x29c641['_queryIdentifier']);const _0x4fe7c3=fn['getListenId_'](_0x29c641,_0x14bf3c),_0x3b24ec={};this['listens_'][_0x4fe7c3]=_0x3b24ec;const _0x13bce=tr(_0x29c641['_queryParams']);this['restRequest_'](_0x1d7172+'.json',_0x13bce,(_0xf469bd,_0x240bfd)=>{let _0xf1f50=_0x240bfd;if(_0xf469bd===0x194&&(_0xf1f50=null,_0xf469bd=null),_0xf469bd===null&&this['onDataUpdate_'](_0x1d7172,_0xf1f50,!0x1,_0x14bf3c),Oe(this['listens_'],_0x4fe7c3)===_0x3b24ec){let _0x13f36f;_0xf469bd?_0xf469bd===0x191?_0x13f36f='permission_denied':_0x13f36f='rest_error:'+_0xf469bd:_0x13f36f='ok',_0x32bfba(_0x13f36f,null);}});}['unlisten'](_0x5bac03,_0x3b4ee5){const _0x410698=fn['getListenId_'](_0x5bac03,_0x3b4ee5);delete this['listens_'][_0x410698];}['get'](_0x585968){const _0x298f2b=tr(_0x585968['_queryParams']),_0xaa195=_0x585968['_path']['toString'](),_0x27eb4d=new Ve();return this['restRequest_'](_0xaa195+'.json',_0x298f2b,(_0x463935,_0x10551f)=>{let _0x42c155=_0x10551f;_0x463935===0x194&&(_0x42c155=null,_0x463935=null),_0x463935===null?(this['onDataUpdate_'](_0xaa195,_0x42c155,!0x1,null),_0x27eb4d['resolve'](_0x42c155)):_0x27eb4d['reject'](new Error(_0x42c155));}),_0x27eb4d['promise'];}['refreshAuthToken'](_0x249341){}['restRequest_'](_0x42eef4,_0x44d9c5={},_0x1d4085){return _0x44d9c5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1f33f5,_0x5df49b])=>{_0x1f33f5&&_0x1f33f5['accessToken']&&(_0x44d9c5['auth']=_0x1f33f5['accessToken']),_0x5df49b&&_0x5df49b['token']&&(_0x44d9c5['ac']=_0x5df49b['token']);const _0x179e27=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x42eef4+'?ns='+this['repoInfo_']['namespace']+at(_0x44d9c5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x179e27);const _0x26ede2=new XMLHttpRequest();_0x26ede2['onreadystatechange']=()=>{if(_0x1d4085&&_0x26ede2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x179e27+'\x20received.\x20status:',_0x26ede2['status'],'response:',_0x26ede2['responseText']);let _0xd6da25=null;if(_0x26ede2['status']>=0xc8&&_0x26ede2['status']<0x12c){try{_0xd6da25=bt(_0x26ede2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x179e27+':\x20'+_0x26ede2['responseText']);}_0x1d4085(null,_0xd6da25);}else _0x26ede2['status']!==0x191&&_0x26ede2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x179e27+'\x20Status:\x20'+_0x26ede2['status']),_0x1d4085(_0x26ede2['status']);_0x1d4085=null;}},_0x26ede2['open']('GET',_0x179e27,!0x0),_0x26ede2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5cb53b){return this['rootNode_']['getChild'](_0x5cb53b);}['updateSnapshot'](_0x1ed546,_0x323aec){this['rootNode_']=this['rootNode_']['updateChild'](_0x1ed546,_0x323aec);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x389900,_0x24d8e5,_0x3de905){if(v(_0x24d8e5))_0x389900['value']=_0x3de905,_0x389900['children']['clear']();else{if(_0x389900['value']!==null)_0x389900['value']=_0x389900['value']['updateChild'](_0x24d8e5,_0x3de905);else{const _0x183555=y(_0x24d8e5);_0x389900['children']['has'](_0x183555)||_0x389900['children']['set'](_0x183555,pn());const _0x3d119a=_0x389900['children']['get'](_0x183555);_0x24d8e5=b(_0x24d8e5),Mo(_0x3d119a,_0x24d8e5,_0x3de905);}}}function Ei(_0x2ae74c,_0x540e08,_0x133d05){_0x2ae74c['value']!==null?_0x133d05(_0x540e08,_0x2ae74c['value']):Qh(_0x2ae74c,(_0x2b0bd1,_0x44bf61)=>{const _0x5f1cf2=new C(_0x540e08['toString']()+'/'+_0x2b0bd1);Ei(_0x44bf61,_0x5f1cf2,_0x133d05);});}function Qh(_0x445791,_0xc1dfb0){_0x445791['children']['forEach']((_0x501b64,_0x361a14)=>{_0xc1dfb0(_0x361a14,_0x501b64);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x8aa86f){this['collection_']=_0x8aa86f,this['last_']=null;}['get'](){const _0xb2adf8=this['collection_']['get'](),_0x26e8c2={..._0xb2adf8};return this['last_']&&x(this['last_'],(_0x5d3885,_0x3f6335)=>{_0x26e8c2[_0x5d3885]=_0x26e8c2[_0x5d3885]-_0x3f6335;}),this['last_']=_0xb2adf8,_0x26e8c2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x10941f,_0x1bd6ca){this['server_']=_0x1bd6ca,this['statsToReport_']={},this['statsListener_']=new Jh(_0x10941f);const _0x3936ca=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x3936ca));}['reportStats_'](){const _0x137873=this['statsListener_']['get'](),_0x3562d8={};let _0x42b243=!0x1;x(_0x137873,(_0x16db51,_0x48720c)=>{_0x48720c>0x0&&Y(this['statsToReport_'],_0x16db51)&&(_0x3562d8[_0x16db51]=_0x48720c,_0x42b243=!0x0);}),_0x42b243&&this['server_']['reportStats'](_0x3562d8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x18898b){_0x18898b[_0x18898b['OVERWRITE']=0x0]='OVERWRITE',_0x18898b[_0x18898b['MERGE']=0x1]='MERGE',_0x18898b[_0x18898b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x18898b[_0x18898b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0xf3323c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xf3323c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x51b028,_0x4ec2a0,_0x193304){this['path']=_0x51b028,this['affectedTree']=_0x4ec2a0,this['revert']=_0x193304,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5cb523){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2a1b3c=this['affectedTree']['subtree'](new C(_0x5cb523));return new _n(w(),_0x2a1b3c,this['revert']);}}else return f(y(this['path'])===_0x5cb523,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x8d9193,_0x311808){this['source']=_0x8d9193,this['path']=_0x311808,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4824f1){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x1b6fa2,_0x310413,_0x1e9690){this['source']=_0x1b6fa2,this['path']=_0x310413,this['snap']=_0x1e9690,this['type']=q['OVERWRITE'];}['operationForChild'](_0x328845){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x328845)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x2beda0,_0x2535dd,_0xc4cd9d){this['source']=_0x2beda0,this['path']=_0x2535dd,this['children']=_0xc4cd9d,this['type']=q['MERGE'];}['operationForChild'](_0x2c0a91){if(v(this['path'])){const _0x164ddb=this['children']['subtree'](new C(_0x2c0a91));return _0x164ddb['isEmpty']()?null:_0x164ddb['value']?new Fe(this['source'],w(),_0x164ddb['value']):new nt(this['source'],w(),_0x164ddb);}else return f(y(this['path'])===_0x2c0a91,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x44b2d1,_0x484626,_0x448adf){this['node_']=_0x44b2d1,this['fullyInitialized_']=_0x484626,this['filtered_']=_0x448adf;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x461dba){if(v(_0x461dba))return this['isFullyInitialized']()&&!this['filtered_'];const _0x35fd1e=y(_0x461dba);return this['isCompleteForChild'](_0x35fd1e);}['isCompleteForChild'](_0x7d279b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x7d279b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x43d41c){this['query_']=_0x43d41c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x1d4788,_0x398ae2,_0x5a7b76,_0x24e22c){const _0x16d546=[],_0x13b389=[];return _0x398ae2['forEach'](_0x2c7446=>{_0x2c7446['type']==='child_changed'&&_0x1d4788['index_']['indexedValueChanged'](_0x2c7446['oldSnap'],_0x2c7446['snapshotNode'])&&_0x13b389['push']($h(_0x2c7446['childName'],_0x2c7446['snapshotNode']));}),mt(_0x1d4788,_0x16d546,'child_removed',_0x398ae2,_0x24e22c,_0x5a7b76),mt(_0x1d4788,_0x16d546,'child_added',_0x398ae2,_0x24e22c,_0x5a7b76),mt(_0x1d4788,_0x16d546,'child_moved',_0x13b389,_0x24e22c,_0x5a7b76),mt(_0x1d4788,_0x16d546,'child_changed',_0x398ae2,_0x24e22c,_0x5a7b76),mt(_0x1d4788,_0x16d546,'value',_0x398ae2,_0x24e22c,_0x5a7b76),_0x16d546;}function mt(_0x9666cf,_0x551eb2,_0x2b50f9,_0x4a92b7,_0x3ba50a,_0x73f40c){const _0x5f5b36=_0x4a92b7['filter'](_0x181f4d=>_0x181f4d['type']===_0x2b50f9);_0x5f5b36['sort']((_0x50a619,_0x2786f6)=>su(_0x9666cf,_0x50a619,_0x2786f6)),_0x5f5b36['forEach'](_0x1fe8ad=>{const _0x19c449=iu(_0x9666cf,_0x1fe8ad,_0x73f40c);_0x3ba50a['forEach'](_0x3dd6ae=>{_0x3dd6ae['respondsTo'](_0x1fe8ad['type'])&&_0x551eb2['push'](_0x3dd6ae['createEvent'](_0x19c449,_0x9666cf['query_']));});});}function iu(_0x270c13,_0xedcf89,_0xda4f11){return _0xedcf89['type']==='value'||_0xedcf89['type']==='child_removed'||(_0xedcf89['prevName']=_0xda4f11['getPredecessorChildName'](_0xedcf89['childName'],_0xedcf89['snapshotNode'],_0x270c13['index_'])),_0xedcf89;}function su(_0x544818,_0x2abac0,_0x4e514f){if(_0x2abac0['childName']==null||_0x4e514f['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x51b10e=new E(_0x2abac0['childName'],_0x2abac0['snapshotNode']),_0x2900c3=new E(_0x4e514f['childName'],_0x4e514f['snapshotNode']);return _0x544818['index_']['compare'](_0x51b10e,_0x2900c3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x492ce3,_0x192836){return{'eventCache':_0x492ce3,'serverCache':_0x192836};}function wt(_0x4dc20b,_0x3f826a,_0x344ad3,_0x42df2a){return Dn(new Ce(_0x3f826a,_0x344ad3,_0x42df2a),_0x4dc20b['serverCache']);}function Lo(_0x1cf796,_0x24c760,_0x3e3e91,_0x314ebc){return Dn(_0x1cf796['eventCache'],new Ce(_0x24c760,_0x3e3e91,_0x314ebc));}function gn(_0x1579be){return _0x1579be['eventCache']['isFullyInitialized']()?_0x1579be['eventCache']['getNode']():null;}function Ue(_0x5a643b){return _0x5a643b['serverCache']['isFullyInitialized']()?_0x5a643b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3274a3){let _0x558f3a=new S(null);return x(_0x3274a3,(_0xe80cbc,_0x37e861)=>{_0x558f3a=_0x558f3a['set'](new C(_0xe80cbc),_0x37e861);}),_0x558f3a;}constructor(_0x24eda9,_0x40d104=ru()){this['value']=_0x24eda9,this['children']=_0x40d104;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x56f45d,_0x350a53){if(this['value']!=null&&_0x350a53(this['value']))return{'path':w(),'value':this['value']};if(v(_0x56f45d))return null;{const _0x58c1f7=y(_0x56f45d),_0x36483d=this['children']['get'](_0x58c1f7);if(_0x36483d!==null){const _0x408131=_0x36483d['findRootMostMatchingPathAndValue'](b(_0x56f45d),_0x350a53);return _0x408131!=null?{'path':A(new C(_0x58c1f7),_0x408131['path']),'value':_0x408131['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3e36e2){return this['findRootMostMatchingPathAndValue'](_0x3e36e2,()=>!0x0);}['subtree'](_0x188676){if(v(_0x188676))return this;{const _0x4f03c2=y(_0x188676),_0x2a6d2d=this['children']['get'](_0x4f03c2);return _0x2a6d2d!==null?_0x2a6d2d['subtree'](b(_0x188676)):new S(null);}}['set'](_0x2a6d1d,_0x1a7598){if(v(_0x2a6d1d))return new S(_0x1a7598,this['children']);{const _0x251d06=y(_0x2a6d1d),_0x371359=(this['children']['get'](_0x251d06)||new S(null))['set'](b(_0x2a6d1d),_0x1a7598),_0x2c654b=this['children']['insert'](_0x251d06,_0x371359);return new S(this['value'],_0x2c654b);}}['remove'](_0x2c3ba4){if(v(_0x2c3ba4))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x396f73=y(_0x2c3ba4),_0x40c7d3=this['children']['get'](_0x396f73);if(_0x40c7d3){const _0x3fe08a=_0x40c7d3['remove'](b(_0x2c3ba4));let _0x53a8f9;return _0x3fe08a['isEmpty']()?_0x53a8f9=this['children']['remove'](_0x396f73):_0x53a8f9=this['children']['insert'](_0x396f73,_0x3fe08a),this['value']===null&&_0x53a8f9['isEmpty']()?new S(null):new S(this['value'],_0x53a8f9);}else return this;}}['get'](_0x1d958d){if(v(_0x1d958d))return this['value'];{const _0x5583bf=y(_0x1d958d),_0x1efccf=this['children']['get'](_0x5583bf);return _0x1efccf?_0x1efccf['get'](b(_0x1d958d)):null;}}['setTree'](_0x4743c2,_0x34fc04){if(v(_0x4743c2))return _0x34fc04;{const _0x107806=y(_0x4743c2),_0x1e6e9a=(this['children']['get'](_0x107806)||new S(null))['setTree'](b(_0x4743c2),_0x34fc04);let _0x5031ff;return _0x1e6e9a['isEmpty']()?_0x5031ff=this['children']['remove'](_0x107806):_0x5031ff=this['children']['insert'](_0x107806,_0x1e6e9a),new S(this['value'],_0x5031ff);}}['fold'](_0x37dcf0){return this['fold_'](w(),_0x37dcf0);}['fold_'](_0x46b09d,_0x3e56b9){const _0xe32141={};return this['children']['inorderTraversal']((_0x48cf30,_0x1be1d6)=>{_0xe32141[_0x48cf30]=_0x1be1d6['fold_'](A(_0x46b09d,_0x48cf30),_0x3e56b9);}),_0x3e56b9(_0x46b09d,this['value'],_0xe32141);}['findOnPath'](_0xa7227e,_0x4e3c9f){return this['findOnPath_'](_0xa7227e,w(),_0x4e3c9f);}['findOnPath_'](_0x44679f,_0x4bea1b,_0x4d652d){const _0x16a291=this['value']?_0x4d652d(_0x4bea1b,this['value']):!0x1;if(_0x16a291)return _0x16a291;if(v(_0x44679f))return null;{const _0x56f880=y(_0x44679f),_0x51c1f3=this['children']['get'](_0x56f880);return _0x51c1f3?_0x51c1f3['findOnPath_'](b(_0x44679f),A(_0x4bea1b,_0x56f880),_0x4d652d):null;}}['foreachOnPath'](_0x155b3d,_0x105b16){return this['foreachOnPath_'](_0x155b3d,w(),_0x105b16);}['foreachOnPath_'](_0x4cd02a,_0x23bb3c,_0x23c72d){if(v(_0x4cd02a))return this;{this['value']&&_0x23c72d(_0x23bb3c,this['value']);const _0x518368=y(_0x4cd02a),_0x1d3ece=this['children']['get'](_0x518368);return _0x1d3ece?_0x1d3ece['foreachOnPath_'](b(_0x4cd02a),A(_0x23bb3c,_0x518368),_0x23c72d):new S(null);}}['foreach'](_0xe0c224){this['foreach_'](w(),_0xe0c224);}['foreach_'](_0x30a06d,_0x3282d3){this['children']['inorderTraversal']((_0x5c2225,_0x27ae6d)=>{_0x27ae6d['foreach_'](A(_0x30a06d,_0x5c2225),_0x3282d3);}),this['value']&&_0x3282d3(_0x30a06d,this['value']);}['foreachChild'](_0x5c0266){this['children']['inorderTraversal']((_0x5b68da,_0x3b5058)=>{_0x3b5058['value']&&_0x5c0266(_0x5b68da,_0x3b5058['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x239121){this['writeTree_']=_0x239121;}static['empty'](){return new j(new S(null));}}function Ct(_0x9a80e2,_0x621652,_0xa2e601){if(v(_0x621652))return new j(new S(_0xa2e601));{const _0x5e7d27=_0x9a80e2['writeTree_']['findRootMostValueAndPath'](_0x621652);if(_0x5e7d27!=null){const _0x4ba142=_0x5e7d27['path'];let _0x1db55f=_0x5e7d27['value'];const _0x5b0a42=F(_0x4ba142,_0x621652);return _0x1db55f=_0x1db55f['updateChild'](_0x5b0a42,_0xa2e601),new j(_0x9a80e2['writeTree_']['set'](_0x4ba142,_0x1db55f));}else{const _0x492254=new S(_0xa2e601),_0x5c0806=_0x9a80e2['writeTree_']['setTree'](_0x621652,_0x492254);return new j(_0x5c0806);}}}function Ii(_0x7387b7,_0x522ed0,_0x4803dc){let _0x2bc4cc=_0x7387b7;return x(_0x4803dc,(_0x348926,_0x51c433)=>{_0x2bc4cc=Ct(_0x2bc4cc,A(_0x522ed0,_0x348926),_0x51c433);}),_0x2bc4cc;}function sr(_0x526287,_0x3355d4){if(v(_0x3355d4))return j['empty']();{const _0x59d73b=_0x526287['writeTree_']['setTree'](_0x3355d4,new S(null));return new j(_0x59d73b);}}function wi(_0x23ad39,_0x44da19){return $e(_0x23ad39,_0x44da19)!=null;}function $e(_0x319f,_0x5f3a1e){const _0x8bd7bb=_0x319f['writeTree_']['findRootMostValueAndPath'](_0x5f3a1e);return _0x8bd7bb!=null?_0x319f['writeTree_']['get'](_0x8bd7bb['path'])['getChild'](F(_0x8bd7bb['path'],_0x5f3a1e)):null;}function rr(_0x4434b5){const _0x135730=[],_0x57d56e=_0x4434b5['writeTree_']['value'];return _0x57d56e!=null?_0x57d56e['isLeafNode']()||_0x57d56e['forEachChild'](R,(_0x46e881,_0x566f2d)=>{_0x135730['push'](new E(_0x46e881,_0x566f2d));}):_0x4434b5['writeTree_']['children']['inorderTraversal']((_0x5874e6,_0x2c8393)=>{_0x2c8393['value']!=null&&_0x135730['push'](new E(_0x5874e6,_0x2c8393['value']));}),_0x135730;}function ve(_0x2a942d,_0x32847c){if(v(_0x32847c))return _0x2a942d;{const _0x11f904=$e(_0x2a942d,_0x32847c);return _0x11f904!=null?new j(new S(_0x11f904)):new j(_0x2a942d['writeTree_']['subtree'](_0x32847c));}}function Ci(_0x6377fa){return _0x6377fa['writeTree_']['isEmpty']();}function it(_0x384662,_0x1464b6){return xo(w(),_0x384662['writeTree_'],_0x1464b6);}function xo(_0x3f1f79,_0xd9ce7d,_0x108663){if(_0xd9ce7d['value']!=null)return _0x108663['updateChild'](_0x3f1f79,_0xd9ce7d['value']);{let _0x2eb9f3=null;return _0xd9ce7d['children']['inorderTraversal']((_0x15d49b,_0x5e9c92)=>{_0x15d49b==='.priority'?(f(_0x5e9c92['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2eb9f3=_0x5e9c92['value']):_0x108663=xo(A(_0x3f1f79,_0x15d49b),_0x5e9c92,_0x108663);}),!_0x108663['getChild'](_0x3f1f79)['isEmpty']()&&_0x2eb9f3!==null&&(_0x108663=_0x108663['updateChild'](A(_0x3f1f79,'.priority'),_0x2eb9f3)),_0x108663;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x42ace4,_0x298406){return Bo(_0x298406,_0x42ace4);}function ou(_0x3ce7f3,_0x2f38f4,_0x3d35c3,_0x39c253,_0x4bf0ed){f(_0x39c253>_0x3ce7f3['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4bf0ed===void 0x0&&(_0x4bf0ed=!0x0),_0x3ce7f3['allWrites']['push']({'path':_0x2f38f4,'snap':_0x3d35c3,'writeId':_0x39c253,'visible':_0x4bf0ed}),_0x4bf0ed&&(_0x3ce7f3['visibleWrites']=Ct(_0x3ce7f3['visibleWrites'],_0x2f38f4,_0x3d35c3)),_0x3ce7f3['lastWriteId']=_0x39c253;}function au(_0x32039f,_0xde7829,_0xb8f12a,_0x5679ff){f(_0x5679ff>_0x32039f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x32039f['allWrites']['push']({'path':_0xde7829,'children':_0xb8f12a,'writeId':_0x5679ff,'visible':!0x0}),_0x32039f['visibleWrites']=Ii(_0x32039f['visibleWrites'],_0xde7829,_0xb8f12a),_0x32039f['lastWriteId']=_0x5679ff;}function cu(_0x44d6b7,_0x356f9a){for(let _0x205bf7=0x0;_0x205bf7<_0x44d6b7['allWrites']['length'];_0x205bf7++){const _0x4e015b=_0x44d6b7['allWrites'][_0x205bf7];if(_0x4e015b['writeId']===_0x356f9a)return _0x4e015b;}return null;}function lu(_0x3d70d6,_0x24d01a){const _0x81bd1d=_0x3d70d6['allWrites']['findIndex'](_0x5ac78b=>_0x5ac78b['writeId']===_0x24d01a);f(_0x81bd1d>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x337bef=_0x3d70d6['allWrites'][_0x81bd1d];_0x3d70d6['allWrites']['splice'](_0x81bd1d,0x1);let _0x110340=_0x337bef['visible'],_0x3b1868=!0x1,_0x216900=_0x3d70d6['allWrites']['length']-0x1;for(;_0x110340&&_0x216900>=0x0;){const _0x2a5397=_0x3d70d6['allWrites'][_0x216900];_0x2a5397['visible']&&(_0x216900>=_0x81bd1d&&hu(_0x2a5397,_0x337bef['path'])?_0x110340=!0x1:$(_0x337bef['path'],_0x2a5397['path'])&&(_0x3b1868=!0x0)),_0x216900--;}if(_0x110340){if(_0x3b1868)return uu(_0x3d70d6),!0x0;if(_0x337bef['snap'])_0x3d70d6['visibleWrites']=sr(_0x3d70d6['visibleWrites'],_0x337bef['path']);else{const _0x10473f=_0x337bef['children'];x(_0x10473f,_0x523c6b=>{_0x3d70d6['visibleWrites']=sr(_0x3d70d6['visibleWrites'],A(_0x337bef['path'],_0x523c6b));});}return!0x0;}else return!0x1;}function hu(_0x3a0920,_0x58b673){if(_0x3a0920['snap'])return $(_0x3a0920['path'],_0x58b673);for(const _0x85af95 in _0x3a0920['children'])if(_0x3a0920['children']['hasOwnProperty'](_0x85af95)&&$(A(_0x3a0920['path'],_0x85af95),_0x58b673))return!0x0;return!0x1;}function uu(_0x93ff19){_0x93ff19['visibleWrites']=Fo(_0x93ff19['allWrites'],du,w()),_0x93ff19['allWrites']['length']>0x0?_0x93ff19['lastWriteId']=_0x93ff19['allWrites'][_0x93ff19['allWrites']['length']-0x1]['writeId']:_0x93ff19['lastWriteId']=-0x1;}function du(_0x367143){return _0x367143['visible'];}function Fo(_0x24eb6b,_0x12a742,_0x1a35ea){let _0x5bf0d4=j['empty']();for(let _0x217d3c=0x0;_0x217d3c<_0x24eb6b['length'];++_0x217d3c){const _0x13b9f6=_0x24eb6b[_0x217d3c];if(_0x12a742(_0x13b9f6)){const _0x4b2bdf=_0x13b9f6['path'];let _0x1bea85;if(_0x13b9f6['snap'])$(_0x1a35ea,_0x4b2bdf)?(_0x1bea85=F(_0x1a35ea,_0x4b2bdf),_0x5bf0d4=Ct(_0x5bf0d4,_0x1bea85,_0x13b9f6['snap'])):$(_0x4b2bdf,_0x1a35ea)&&(_0x1bea85=F(_0x4b2bdf,_0x1a35ea),_0x5bf0d4=Ct(_0x5bf0d4,w(),_0x13b9f6['snap']['getChild'](_0x1bea85)));else{if(_0x13b9f6['children']){if($(_0x1a35ea,_0x4b2bdf))_0x1bea85=F(_0x1a35ea,_0x4b2bdf),_0x5bf0d4=Ii(_0x5bf0d4,_0x1bea85,_0x13b9f6['children']);else{if($(_0x4b2bdf,_0x1a35ea)){if(_0x1bea85=F(_0x4b2bdf,_0x1a35ea),v(_0x1bea85))_0x5bf0d4=Ii(_0x5bf0d4,w(),_0x13b9f6['children']);else{const _0x4522df=Oe(_0x13b9f6['children'],y(_0x1bea85));if(_0x4522df){const _0x3762e6=_0x4522df['getChild'](b(_0x1bea85));_0x5bf0d4=Ct(_0x5bf0d4,w(),_0x3762e6);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5bf0d4;}function Uo(_0x3d060e,_0x119e9e,_0x2a0dc4,_0x7bf89,_0x18d32f){if(!_0x7bf89&&!_0x18d32f){const _0x5981ff=$e(_0x3d060e['visibleWrites'],_0x119e9e);if(_0x5981ff!=null)return _0x5981ff;{const _0x4be5ba=ve(_0x3d060e['visibleWrites'],_0x119e9e);if(Ci(_0x4be5ba))return _0x2a0dc4;if(_0x2a0dc4==null&&!wi(_0x4be5ba,w()))return null;{const _0x26b6dd=_0x2a0dc4||g['EMPTY_NODE'];return it(_0x4be5ba,_0x26b6dd);}}}else{const _0xd020fc=ve(_0x3d060e['visibleWrites'],_0x119e9e);if(!_0x18d32f&&Ci(_0xd020fc))return _0x2a0dc4;if(!_0x18d32f&&_0x2a0dc4==null&&!wi(_0xd020fc,w()))return null;{const _0x4d4773=function(_0x4aebf6){return(_0x4aebf6['visible']||_0x18d32f)&&(!_0x7bf89||!~_0x7bf89['indexOf'](_0x4aebf6['writeId']))&&($(_0x4aebf6['path'],_0x119e9e)||$(_0x119e9e,_0x4aebf6['path']));},_0x2df338=Fo(_0x3d060e['allWrites'],_0x4d4773,_0x119e9e),_0x420542=_0x2a0dc4||g['EMPTY_NODE'];return it(_0x2df338,_0x420542);}}}function fu(_0x51fa21,_0x2a0921,_0xc33f1f){let _0x4eb1c8=g['EMPTY_NODE'];const _0x4c13c9=$e(_0x51fa21['visibleWrites'],_0x2a0921);if(_0x4c13c9)return _0x4c13c9['isLeafNode']()||_0x4c13c9['forEachChild'](R,(_0x1d6db3,_0x1631b0)=>{_0x4eb1c8=_0x4eb1c8['updateImmediateChild'](_0x1d6db3,_0x1631b0);}),_0x4eb1c8;if(_0xc33f1f){const _0x459577=ve(_0x51fa21['visibleWrites'],_0x2a0921);return _0xc33f1f['forEachChild'](R,(_0xaf320,_0x3a9217)=>{const _0x4bd8d9=it(ve(_0x459577,new C(_0xaf320)),_0x3a9217);_0x4eb1c8=_0x4eb1c8['updateImmediateChild'](_0xaf320,_0x4bd8d9);}),rr(_0x459577)['forEach'](_0x367a6b=>{_0x4eb1c8=_0x4eb1c8['updateImmediateChild'](_0x367a6b['name'],_0x367a6b['node']);}),_0x4eb1c8;}else{const _0x43083f=ve(_0x51fa21['visibleWrites'],_0x2a0921);return rr(_0x43083f)['forEach'](_0x3df1bf=>{_0x4eb1c8=_0x4eb1c8['updateImmediateChild'](_0x3df1bf['name'],_0x3df1bf['node']);}),_0x4eb1c8;}}function pu(_0xc5e6b8,_0x19ea70,_0x223af4,_0x4b58d6,_0x33a9ea){f(_0x4b58d6||_0x33a9ea,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3187b0=A(_0x19ea70,_0x223af4);if(wi(_0xc5e6b8['visibleWrites'],_0x3187b0))return null;{const _0x3c9da0=ve(_0xc5e6b8['visibleWrites'],_0x3187b0);return Ci(_0x3c9da0)?_0x33a9ea['getChild'](_0x223af4):it(_0x3c9da0,_0x33a9ea['getChild'](_0x223af4));}}function _u(_0x5379d4,_0xf2f7cf,_0x17159a,_0x14d179){const _0x2722ca=A(_0xf2f7cf,_0x17159a),_0x4c6b5=$e(_0x5379d4['visibleWrites'],_0x2722ca);if(_0x4c6b5!=null)return _0x4c6b5;if(_0x14d179['isCompleteForChild'](_0x17159a)){const _0x4f125c=ve(_0x5379d4['visibleWrites'],_0x2722ca);return it(_0x4f125c,_0x14d179['getNode']()['getImmediateChild'](_0x17159a));}else return null;}function gu(_0x312dd0,_0x2d279f){return $e(_0x312dd0['visibleWrites'],_0x2d279f);}function mu(_0x4c122a,_0x13f646,_0x2f96cf,_0x39df0b,_0x2467e3,_0x53ea62,_0x2374f6){let _0x20c117;const _0x43a6cf=ve(_0x4c122a['visibleWrites'],_0x13f646),_0x3704ec=$e(_0x43a6cf,w());if(_0x3704ec!=null)_0x20c117=_0x3704ec;else{if(_0x2f96cf!=null)_0x20c117=it(_0x43a6cf,_0x2f96cf);else return[];}if(_0x20c117=_0x20c117['withIndex'](_0x2374f6),!_0x20c117['isEmpty']()&&!_0x20c117['isLeafNode']()){const _0x30e21a=[],_0x3c20a9=_0x2374f6['getCompare'](),_0x509057=_0x53ea62?_0x20c117['getReverseIteratorFrom'](_0x39df0b,_0x2374f6):_0x20c117['getIteratorFrom'](_0x39df0b,_0x2374f6);let _0x442478=_0x509057['getNext']();for(;_0x442478&&_0x30e21a['length']<_0x2467e3;)_0x3c20a9(_0x442478,_0x39df0b)!==0x0&&_0x30e21a['push'](_0x442478),_0x442478=_0x509057['getNext']();return _0x30e21a;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x2fa070,_0x283a81,_0x1168f1,_0x18dd53){return Uo(_0x2fa070['writeTree'],_0x2fa070['treePath'],_0x283a81,_0x1168f1,_0x18dd53);}function es(_0x388470,_0x4f08d0){return fu(_0x388470['writeTree'],_0x388470['treePath'],_0x4f08d0);}function or(_0x254748,_0x1ebb5c,_0xd313d5,_0x10f4ff){return pu(_0x254748['writeTree'],_0x254748['treePath'],_0x1ebb5c,_0xd313d5,_0x10f4ff);}function yn(_0x5b7ac3,_0x589237){return gu(_0x5b7ac3['writeTree'],A(_0x5b7ac3['treePath'],_0x589237));}function vu(_0x38baee,_0x5f4cfb,_0x4451bb,_0x371833,_0x533dd5,_0x38c1cf){return mu(_0x38baee['writeTree'],_0x38baee['treePath'],_0x5f4cfb,_0x4451bb,_0x371833,_0x533dd5,_0x38c1cf);}function ts(_0x21f193,_0x297791,_0x5949d2){return _u(_0x21f193['writeTree'],_0x21f193['treePath'],_0x297791,_0x5949d2);}function Wo(_0x4ed3dc,_0x2dc610){return Bo(A(_0x4ed3dc['treePath'],_0x2dc610),_0x4ed3dc['writeTree']);}function Bo(_0x1dcb13,_0x17948b){return{'treePath':_0x1dcb13,'writeTree':_0x17948b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3f5aba){const _0x14e1c9=_0x3f5aba['type'],_0x5893a0=_0x3f5aba['childName'];f(_0x14e1c9==='child_added'||_0x14e1c9==='child_changed'||_0x14e1c9==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5893a0!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3c9f7=this['changeMap']['get'](_0x5893a0);if(_0x3c9f7){const _0x18ded5=_0x3c9f7['type'];if(_0x14e1c9==='child_added'&&_0x18ded5==='child_removed')this['changeMap']['set'](_0x5893a0,Pt(_0x5893a0,_0x3f5aba['snapshotNode'],_0x3c9f7['snapshotNode']));else{if(_0x14e1c9==='child_removed'&&_0x18ded5==='child_added')this['changeMap']['delete'](_0x5893a0);else{if(_0x14e1c9==='child_removed'&&_0x18ded5==='child_changed')this['changeMap']['set'](_0x5893a0,Nt(_0x5893a0,_0x3c9f7['oldSnap']));else{if(_0x14e1c9==='child_changed'&&_0x18ded5==='child_added')this['changeMap']['set'](_0x5893a0,tt(_0x5893a0,_0x3f5aba['snapshotNode']));else{if(_0x14e1c9==='child_changed'&&_0x18ded5==='child_changed')this['changeMap']['set'](_0x5893a0,Pt(_0x5893a0,_0x3f5aba['snapshotNode'],_0x3c9f7['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3f5aba+'\x20occurred\x20after\x20'+_0x3c9f7);}}}}}else this['changeMap']['set'](_0x5893a0,_0x3f5aba);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x45433e){return null;}['getChildAfterChild'](_0x2839ba,_0x311e3a,_0x291fd2){return null;}}const Vo=new Iu();class ns{constructor(_0x420835,_0x927a6e,_0x418b3c=null){this['writes_']=_0x420835,this['viewCache_']=_0x927a6e,this['optCompleteServerCache_']=_0x418b3c;}['getCompleteChild'](_0x23f81d){const _0x312b43=this['viewCache_']['eventCache'];if(_0x312b43['isCompleteForChild'](_0x23f81d))return _0x312b43['getNode']()['getImmediateChild'](_0x23f81d);{const _0x289f16=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x23f81d,_0x289f16);}}['getChildAfterChild'](_0x3b65ee,_0x34b036,_0x38c495){const _0x4cbb65=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x9a757d=vu(this['writes_'],_0x4cbb65,_0x34b036,0x1,_0x38c495,_0x3b65ee);return _0x9a757d['length']===0x0?null:_0x9a757d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x70a7fe){return{'filter':_0x70a7fe};}function Cu(_0x57c264,_0x4713bb){f(_0x4713bb['eventCache']['getNode']()['isIndexed'](_0x57c264['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4713bb['serverCache']['getNode']()['isIndexed'](_0x57c264['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x49284d,_0x493fe7,_0x89f919,_0x4624f6,_0x1dd503){const _0x3024f5=new Eu();let _0x2db67b,_0x4a793b;if(_0x89f919['type']===q['OVERWRITE']){const _0x549213=_0x89f919;_0x549213['source']['fromUser']?_0x2db67b=Ti(_0x49284d,_0x493fe7,_0x549213['path'],_0x549213['snap'],_0x4624f6,_0x1dd503,_0x3024f5):(f(_0x549213['source']['fromServer'],'Unknown\x20source.'),_0x4a793b=_0x549213['source']['tagged']||_0x493fe7['serverCache']['isFiltered']()&&!v(_0x549213['path']),_0x2db67b=vn(_0x49284d,_0x493fe7,_0x549213['path'],_0x549213['snap'],_0x4624f6,_0x1dd503,_0x4a793b,_0x3024f5));}else{if(_0x89f919['type']===q['MERGE']){const _0x1c1f5c=_0x89f919;_0x1c1f5c['source']['fromUser']?_0x2db67b=bu(_0x49284d,_0x493fe7,_0x1c1f5c['path'],_0x1c1f5c['children'],_0x4624f6,_0x1dd503,_0x3024f5):(f(_0x1c1f5c['source']['fromServer'],'Unknown\x20source.'),_0x4a793b=_0x1c1f5c['source']['tagged']||_0x493fe7['serverCache']['isFiltered'](),_0x2db67b=Si(_0x49284d,_0x493fe7,_0x1c1f5c['path'],_0x1c1f5c['children'],_0x4624f6,_0x1dd503,_0x4a793b,_0x3024f5));}else{if(_0x89f919['type']===q['ACK_USER_WRITE']){const _0x1667f7=_0x89f919;_0x1667f7['revert']?_0x2db67b=ku(_0x49284d,_0x493fe7,_0x1667f7['path'],_0x4624f6,_0x1dd503,_0x3024f5):_0x2db67b=Ru(_0x49284d,_0x493fe7,_0x1667f7['path'],_0x1667f7['affectedTree'],_0x4624f6,_0x1dd503,_0x3024f5);}else{if(_0x89f919['type']===q['LISTEN_COMPLETE'])_0x2db67b=Au(_0x49284d,_0x493fe7,_0x89f919['path'],_0x4624f6,_0x3024f5);else throw ot('Unknown\x20operation\x20type:\x20'+_0x89f919['type']);}}}const _0x248741=_0x3024f5['getChanges']();return Su(_0x493fe7,_0x2db67b,_0x248741),{'viewCache':_0x2db67b,'changes':_0x248741};}function Su(_0x342d07,_0x70b3f3,_0x4ef85b){const _0x24d8c8=_0x70b3f3['eventCache'];if(_0x24d8c8['isFullyInitialized']()){const _0x57888f=_0x24d8c8['getNode']()['isLeafNode']()||_0x24d8c8['getNode']()['isEmpty'](),_0x1af09b=gn(_0x342d07);(_0x4ef85b['length']>0x0||!_0x342d07['eventCache']['isFullyInitialized']()||_0x57888f&&!_0x24d8c8['getNode']()['equals'](_0x1af09b)||!_0x24d8c8['getNode']()['getPriority']()['equals'](_0x1af09b['getPriority']()))&&_0x4ef85b['push'](Oo(gn(_0x70b3f3)));}}function Ho(_0x51cebc,_0x416b3d,_0x36cffa,_0x6185f8,_0x4be19f,_0x2f5942){const _0x62fcb3=_0x416b3d['eventCache'];if(yn(_0x6185f8,_0x36cffa)!=null)return _0x416b3d;{let _0x35fe81,_0x5da9c6;if(v(_0x36cffa)){if(f(_0x416b3d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x416b3d['serverCache']['isFiltered']()){const _0x27a394=Ue(_0x416b3d),_0x4ee9fc=_0x27a394 instanceof g?_0x27a394:g['EMPTY_NODE'],_0x4944e4=es(_0x6185f8,_0x4ee9fc);_0x35fe81=_0x51cebc['filter']['updateFullNode'](_0x416b3d['eventCache']['getNode'](),_0x4944e4,_0x2f5942);}else{const _0x47255e=mn(_0x6185f8,Ue(_0x416b3d));_0x35fe81=_0x51cebc['filter']['updateFullNode'](_0x416b3d['eventCache']['getNode'](),_0x47255e,_0x2f5942);}}else{const _0x1a4636=y(_0x36cffa);if(_0x1a4636==='.priority'){f(we(_0x36cffa)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4ba227=_0x62fcb3['getNode']();_0x5da9c6=_0x416b3d['serverCache']['getNode']();const _0x133100=or(_0x6185f8,_0x36cffa,_0x4ba227,_0x5da9c6);_0x133100!=null?_0x35fe81=_0x51cebc['filter']['updatePriority'](_0x4ba227,_0x133100):_0x35fe81=_0x62fcb3['getNode']();}else{const _0x2e5b68=b(_0x36cffa);let _0x46d578;if(_0x62fcb3['isCompleteForChild'](_0x1a4636)){_0x5da9c6=_0x416b3d['serverCache']['getNode']();const _0x287b3d=or(_0x6185f8,_0x36cffa,_0x62fcb3['getNode'](),_0x5da9c6);_0x287b3d!=null?_0x46d578=_0x62fcb3['getNode']()['getImmediateChild'](_0x1a4636)['updateChild'](_0x2e5b68,_0x287b3d):_0x46d578=_0x62fcb3['getNode']()['getImmediateChild'](_0x1a4636);}else _0x46d578=ts(_0x6185f8,_0x1a4636,_0x416b3d['serverCache']);_0x46d578!=null?_0x35fe81=_0x51cebc['filter']['updateChild'](_0x62fcb3['getNode'](),_0x1a4636,_0x46d578,_0x2e5b68,_0x4be19f,_0x2f5942):_0x35fe81=_0x62fcb3['getNode']();}}return wt(_0x416b3d,_0x35fe81,_0x62fcb3['isFullyInitialized']()||v(_0x36cffa),_0x51cebc['filter']['filtersNodes']());}}function vn(_0x149467,_0x57a190,_0xc27344,_0x2335c4,_0x2cecc4,_0x36bbc2,_0x3552ae,_0x450bb9){const _0x1a9358=_0x57a190['serverCache'];let _0x2c32a6;const _0x2872ad=_0x3552ae?_0x149467['filter']:_0x149467['filter']['getIndexedFilter']();if(v(_0xc27344))_0x2c32a6=_0x2872ad['updateFullNode'](_0x1a9358['getNode'](),_0x2335c4,null);else{if(_0x2872ad['filtersNodes']()&&!_0x1a9358['isFiltered']()){const _0x2b6e8c=_0x1a9358['getNode']()['updateChild'](_0xc27344,_0x2335c4);_0x2c32a6=_0x2872ad['updateFullNode'](_0x1a9358['getNode'](),_0x2b6e8c,null);}else{const _0x1bfb35=y(_0xc27344);if(!_0x1a9358['isCompleteForPath'](_0xc27344)&&we(_0xc27344)>0x1)return _0x57a190;const _0x40f6ad=b(_0xc27344),_0x2f0e7f=_0x1a9358['getNode']()['getImmediateChild'](_0x1bfb35)['updateChild'](_0x40f6ad,_0x2335c4);_0x1bfb35==='.priority'?_0x2c32a6=_0x2872ad['updatePriority'](_0x1a9358['getNode'](),_0x2f0e7f):_0x2c32a6=_0x2872ad['updateChild'](_0x1a9358['getNode'](),_0x1bfb35,_0x2f0e7f,_0x40f6ad,Vo,null);}}const _0x7b5b46=Lo(_0x57a190,_0x2c32a6,_0x1a9358['isFullyInitialized']()||v(_0xc27344),_0x2872ad['filtersNodes']()),_0x31969b=new ns(_0x2cecc4,_0x7b5b46,_0x36bbc2);return Ho(_0x149467,_0x7b5b46,_0xc27344,_0x2cecc4,_0x31969b,_0x450bb9);}function Ti(_0x26b4c6,_0xe55f97,_0x5d35c8,_0xc5ee1a,_0x4b596e,_0xc1e923,_0x2f8612){const _0x3435a1=_0xe55f97['eventCache'];let _0x3818d6,_0x4f46df;const _0x566a7d=new ns(_0x4b596e,_0xe55f97,_0xc1e923);if(v(_0x5d35c8))_0x4f46df=_0x26b4c6['filter']['updateFullNode'](_0xe55f97['eventCache']['getNode'](),_0xc5ee1a,_0x2f8612),_0x3818d6=wt(_0xe55f97,_0x4f46df,!0x0,_0x26b4c6['filter']['filtersNodes']());else{const _0x185d25=y(_0x5d35c8);if(_0x185d25==='.priority')_0x4f46df=_0x26b4c6['filter']['updatePriority'](_0xe55f97['eventCache']['getNode'](),_0xc5ee1a),_0x3818d6=wt(_0xe55f97,_0x4f46df,_0x3435a1['isFullyInitialized'](),_0x3435a1['isFiltered']());else{const _0x4d5d4e=b(_0x5d35c8),_0x96f23f=_0x3435a1['getNode']()['getImmediateChild'](_0x185d25);let _0x13a75d;if(v(_0x4d5d4e))_0x13a75d=_0xc5ee1a;else{const _0x883250=_0x566a7d['getCompleteChild'](_0x185d25);_0x883250!=null?Gi(_0x4d5d4e)==='.priority'&&_0x883250['getChild'](To(_0x4d5d4e))['isEmpty']()?_0x13a75d=_0x883250:_0x13a75d=_0x883250['updateChild'](_0x4d5d4e,_0xc5ee1a):_0x13a75d=g['EMPTY_NODE'];}if(_0x96f23f['equals'](_0x13a75d))_0x3818d6=_0xe55f97;else{const _0x3cc30b=_0x26b4c6['filter']['updateChild'](_0x3435a1['getNode'](),_0x185d25,_0x13a75d,_0x4d5d4e,_0x566a7d,_0x2f8612);_0x3818d6=wt(_0xe55f97,_0x3cc30b,_0x3435a1['isFullyInitialized'](),_0x26b4c6['filter']['filtersNodes']());}}}return _0x3818d6;}function ar(_0x2c6f4a,_0x311cd1){return _0x2c6f4a['eventCache']['isCompleteForChild'](_0x311cd1);}function bu(_0x4563a6,_0x1ba53c,_0x4ab170,_0x4073d3,_0x5e7d7a,_0x303cbb,_0x4d27f4){let _0x53e511=_0x1ba53c;return _0x4073d3['foreach']((_0x571442,_0x3f74e1)=>{const _0x3fab39=A(_0x4ab170,_0x571442);ar(_0x1ba53c,y(_0x3fab39))&&(_0x53e511=Ti(_0x4563a6,_0x53e511,_0x3fab39,_0x3f74e1,_0x5e7d7a,_0x303cbb,_0x4d27f4));}),_0x4073d3['foreach']((_0x308ea2,_0x5acbd4)=>{const _0x5d1817=A(_0x4ab170,_0x308ea2);ar(_0x1ba53c,y(_0x5d1817))||(_0x53e511=Ti(_0x4563a6,_0x53e511,_0x5d1817,_0x5acbd4,_0x5e7d7a,_0x303cbb,_0x4d27f4));}),_0x53e511;}function cr(_0x3fa4e3,_0x1340ac,_0x321dac){return _0x321dac['foreach']((_0x23cccb,_0x53233b)=>{_0x1340ac=_0x1340ac['updateChild'](_0x23cccb,_0x53233b);}),_0x1340ac;}function Si(_0x4a22ce,_0x154c51,_0x30703a,_0xb08ac2,_0x5f15b6,_0x975954,_0x249a1a,_0x289053){if(_0x154c51['serverCache']['getNode']()['isEmpty']()&&!_0x154c51['serverCache']['isFullyInitialized']())return _0x154c51;let _0x2e55=_0x154c51,_0x539179;v(_0x30703a)?_0x539179=_0xb08ac2:_0x539179=new S(null)['setTree'](_0x30703a,_0xb08ac2);const _0x53a869=_0x154c51['serverCache']['getNode']();return _0x539179['children']['inorderTraversal']((_0x4ba3f5,_0x3aefbd)=>{if(_0x53a869['hasChild'](_0x4ba3f5)){const _0x10760d=_0x154c51['serverCache']['getNode']()['getImmediateChild'](_0x4ba3f5),_0x257900=cr(_0x4a22ce,_0x10760d,_0x3aefbd);_0x2e55=vn(_0x4a22ce,_0x2e55,new C(_0x4ba3f5),_0x257900,_0x5f15b6,_0x975954,_0x249a1a,_0x289053);}}),_0x539179['children']['inorderTraversal']((_0x16ac46,_0x4d2b51)=>{const _0x532939=!_0x154c51['serverCache']['isCompleteForChild'](_0x16ac46)&&_0x4d2b51['value']===null;if(!_0x53a869['hasChild'](_0x16ac46)&&!_0x532939){const _0x570f56=_0x154c51['serverCache']['getNode']()['getImmediateChild'](_0x16ac46),_0x1f8360=cr(_0x4a22ce,_0x570f56,_0x4d2b51);_0x2e55=vn(_0x4a22ce,_0x2e55,new C(_0x16ac46),_0x1f8360,_0x5f15b6,_0x975954,_0x249a1a,_0x289053);}}),_0x2e55;}function Ru(_0x47369b,_0x244dc7,_0x559eea,_0x2ffddc,_0x28097e,_0x3c2868,_0x48d79e){if(yn(_0x28097e,_0x559eea)!=null)return _0x244dc7;const _0x2f04f1=_0x244dc7['serverCache']['isFiltered'](),_0x22ef65=_0x244dc7['serverCache'];if(_0x2ffddc['value']!=null){if(v(_0x559eea)&&_0x22ef65['isFullyInitialized']()||_0x22ef65['isCompleteForPath'](_0x559eea))return vn(_0x47369b,_0x244dc7,_0x559eea,_0x22ef65['getNode']()['getChild'](_0x559eea),_0x28097e,_0x3c2868,_0x2f04f1,_0x48d79e);if(v(_0x559eea)){let _0x31a2ae=new S(null);return _0x22ef65['getNode']()['forEachChild'](ye,(_0x19484a,_0x17dba9)=>{_0x31a2ae=_0x31a2ae['set'](new C(_0x19484a),_0x17dba9);}),Si(_0x47369b,_0x244dc7,_0x559eea,_0x31a2ae,_0x28097e,_0x3c2868,_0x2f04f1,_0x48d79e);}else return _0x244dc7;}else{let _0x3600d6=new S(null);return _0x2ffddc['foreach']((_0x5a0738,_0x378911)=>{const _0x278726=A(_0x559eea,_0x5a0738);_0x22ef65['isCompleteForPath'](_0x278726)&&(_0x3600d6=_0x3600d6['set'](_0x5a0738,_0x22ef65['getNode']()['getChild'](_0x278726)));}),Si(_0x47369b,_0x244dc7,_0x559eea,_0x3600d6,_0x28097e,_0x3c2868,_0x2f04f1,_0x48d79e);}}function Au(_0x58ba7b,_0x1536c8,_0x3633b7,_0x3cf234,_0x41da2d){const _0x25b9c3=_0x1536c8['serverCache'],_0x30ddc6=Lo(_0x1536c8,_0x25b9c3['getNode'](),_0x25b9c3['isFullyInitialized']()||v(_0x3633b7),_0x25b9c3['isFiltered']());return Ho(_0x58ba7b,_0x30ddc6,_0x3633b7,_0x3cf234,Vo,_0x41da2d);}function ku(_0x31dd68,_0x1b761b,_0x5e57e2,_0xe3b7fe,_0x317e35,_0xb1e2f7){let _0x5e2225;if(yn(_0xe3b7fe,_0x5e57e2)!=null)return _0x1b761b;{const _0x2a7a85=new ns(_0xe3b7fe,_0x1b761b,_0x317e35),_0x467dd9=_0x1b761b['eventCache']['getNode']();let _0x20906e;if(v(_0x5e57e2)||y(_0x5e57e2)==='.priority'){let _0x15b61b;if(_0x1b761b['serverCache']['isFullyInitialized']())_0x15b61b=mn(_0xe3b7fe,Ue(_0x1b761b));else{const _0x4d4ae2=_0x1b761b['serverCache']['getNode']();f(_0x4d4ae2 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x15b61b=es(_0xe3b7fe,_0x4d4ae2);}_0x15b61b=_0x15b61b,_0x20906e=_0x31dd68['filter']['updateFullNode'](_0x467dd9,_0x15b61b,_0xb1e2f7);}else{const _0x4b09af=y(_0x5e57e2);let _0x2e681c=ts(_0xe3b7fe,_0x4b09af,_0x1b761b['serverCache']);_0x2e681c==null&&_0x1b761b['serverCache']['isCompleteForChild'](_0x4b09af)&&(_0x2e681c=_0x467dd9['getImmediateChild'](_0x4b09af)),_0x2e681c!=null?_0x20906e=_0x31dd68['filter']['updateChild'](_0x467dd9,_0x4b09af,_0x2e681c,b(_0x5e57e2),_0x2a7a85,_0xb1e2f7):_0x1b761b['eventCache']['getNode']()['hasChild'](_0x4b09af)?_0x20906e=_0x31dd68['filter']['updateChild'](_0x467dd9,_0x4b09af,g['EMPTY_NODE'],b(_0x5e57e2),_0x2a7a85,_0xb1e2f7):_0x20906e=_0x467dd9,_0x20906e['isEmpty']()&&_0x1b761b['serverCache']['isFullyInitialized']()&&(_0x5e2225=mn(_0xe3b7fe,Ue(_0x1b761b)),_0x5e2225['isLeafNode']()&&(_0x20906e=_0x31dd68['filter']['updateFullNode'](_0x20906e,_0x5e2225,_0xb1e2f7)));}return _0x5e2225=_0x1b761b['serverCache']['isFullyInitialized']()||yn(_0xe3b7fe,w())!=null,wt(_0x1b761b,_0x20906e,_0x5e2225,_0x31dd68['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x1e734d,_0x1a1c8e){this['query_']=_0x1e734d,this['eventRegistrations_']=[];const _0x12e74f=this['query_']['_queryParams'],_0x1131fb=new Yi(_0x12e74f['getIndex']()),_0x3059c6=qh(_0x12e74f);this['processor_']=wu(_0x3059c6);const _0x36f01d=_0x1a1c8e['serverCache'],_0x39d13f=_0x1a1c8e['eventCache'],_0x24f6a9=_0x1131fb['updateFullNode'](g['EMPTY_NODE'],_0x36f01d['getNode'](),null),_0x5b6df3=_0x3059c6['updateFullNode'](g['EMPTY_NODE'],_0x39d13f['getNode'](),null),_0xe560e0=new Ce(_0x24f6a9,_0x36f01d['isFullyInitialized'](),_0x1131fb['filtersNodes']()),_0x1c1ed0=new Ce(_0x5b6df3,_0x39d13f['isFullyInitialized'](),_0x3059c6['filtersNodes']());this['viewCache_']=Dn(_0x1c1ed0,_0xe560e0),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x37916d){return _0x37916d['viewCache_']['serverCache']['getNode']();}function Ou(_0x8e7e02){return gn(_0x8e7e02['viewCache_']);}function Du(_0x37ea58,_0x59229a){const _0x3bc3c9=Ue(_0x37ea58['viewCache_']);return _0x3bc3c9&&(_0x37ea58['query']['_queryParams']['loadsAllData']()||!v(_0x59229a)&&!_0x3bc3c9['getImmediateChild'](y(_0x59229a))['isEmpty']())?_0x3bc3c9['getChild'](_0x59229a):null;}function lr(_0x508a76){return _0x508a76['eventRegistrations_']['length']===0x0;}function Mu(_0x252aa6,_0x296ef0){_0x252aa6['eventRegistrations_']['push'](_0x296ef0);}function hr(_0x2e028e,_0x379fe7,_0x55f123){const _0x22f945=[];if(_0x55f123){f(_0x379fe7==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x24fbc8=_0x2e028e['query']['_path'];_0x2e028e['eventRegistrations_']['forEach'](_0xddb1be=>{const _0x38ba45=_0xddb1be['createCancelEvent'](_0x55f123,_0x24fbc8);_0x38ba45&&_0x22f945['push'](_0x38ba45);});}if(_0x379fe7){let _0x182c00=[];for(let _0x38a279=0x0;_0x38a279<_0x2e028e['eventRegistrations_']['length'];++_0x38a279){const _0x283520=_0x2e028e['eventRegistrations_'][_0x38a279];if(!_0x283520['matches'](_0x379fe7))_0x182c00['push'](_0x283520);else{if(_0x379fe7['hasAnyCallback']()){_0x182c00=_0x182c00['concat'](_0x2e028e['eventRegistrations_']['slice'](_0x38a279+0x1));break;}}}_0x2e028e['eventRegistrations_']=_0x182c00;}else _0x2e028e['eventRegistrations_']=[];return _0x22f945;}function ur(_0x2ffc88,_0x483615,_0x34337b,_0x845008){_0x483615['type']===q['MERGE']&&_0x483615['source']['queryId']!==null&&(f(Ue(_0x2ffc88['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2ffc88['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5ef375=_0x2ffc88['viewCache_'],_0x49b51d=Tu(_0x2ffc88['processor_'],_0x5ef375,_0x483615,_0x34337b,_0x845008);return Cu(_0x2ffc88['processor_'],_0x49b51d['viewCache']),f(_0x49b51d['viewCache']['serverCache']['isFullyInitialized']()||!_0x5ef375['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2ffc88['viewCache_']=_0x49b51d['viewCache'],$o(_0x2ffc88,_0x49b51d['changes'],_0x49b51d['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x362c87,_0x2469c0){const _0x5eac2e=_0x362c87['viewCache_']['eventCache'],_0x144b0d=[];return _0x5eac2e['getNode']()['isLeafNode']()||_0x5eac2e['getNode']()['forEachChild'](R,(_0x100063,_0x2cf8b3)=>{_0x144b0d['push'](tt(_0x100063,_0x2cf8b3));}),_0x5eac2e['isFullyInitialized']()&&_0x144b0d['push'](Oo(_0x5eac2e['getNode']())),$o(_0x362c87,_0x144b0d,_0x5eac2e['getNode'](),_0x2469c0);}function $o(_0x12ff27,_0x504407,_0x106bb1,_0x2f4421){const _0x1ff47e=_0x2f4421?[_0x2f4421]:_0x12ff27['eventRegistrations_'];return nu(_0x12ff27['eventGenerator_'],_0x504407,_0x106bb1,_0x1ff47e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x4e4f6d){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x4e4f6d;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x147ed7){return _0x147ed7['views']['size']===0x0;}function is(_0x790037,_0x932f94,_0x164c79,_0x18eb29){const _0x226730=_0x932f94['source']['queryId'];if(_0x226730!==null){const _0x2332c2=_0x790037['views']['get'](_0x226730);return f(_0x2332c2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2332c2,_0x932f94,_0x164c79,_0x18eb29);}else{let _0x2c6e14=[];for(const _0x31884d of _0x790037['views']['values']())_0x2c6e14=_0x2c6e14['concat'](ur(_0x31884d,_0x932f94,_0x164c79,_0x18eb29));return _0x2c6e14;}}function qo(_0x36b3eb,_0x5d49bc,_0x5c4847,_0x51c52f,_0x2c463e){const _0x326e0a=_0x5d49bc['_queryIdentifier'],_0x3b3ada=_0x36b3eb['views']['get'](_0x326e0a);if(!_0x3b3ada){let _0x232a68=mn(_0x5c4847,_0x2c463e?_0x51c52f:null),_0x4e70aa=!0x1;_0x232a68?_0x4e70aa=!0x0:_0x51c52f instanceof g?(_0x232a68=es(_0x5c4847,_0x51c52f),_0x4e70aa=!0x1):(_0x232a68=g['EMPTY_NODE'],_0x4e70aa=!0x1);const _0x347a34=Dn(new Ce(_0x232a68,_0x4e70aa,!0x1),new Ce(_0x51c52f,_0x2c463e,!0x1));return new Nu(_0x5d49bc,_0x347a34);}return _0x3b3ada;}function Wu(_0x3eca5a,_0x49dba1,_0x3ec03e,_0x1fc14f,_0x3eb661,_0x5265f8){const _0x57ad26=qo(_0x3eca5a,_0x49dba1,_0x1fc14f,_0x3eb661,_0x5265f8);return _0x3eca5a['views']['has'](_0x49dba1['_queryIdentifier'])||_0x3eca5a['views']['set'](_0x49dba1['_queryIdentifier'],_0x57ad26),Mu(_0x57ad26,_0x3ec03e),Lu(_0x57ad26,_0x3ec03e);}function Bu(_0x13fe8f,_0x117ec6,_0x3ab6ce,_0x428de8){const _0x1ccff6=_0x117ec6['_queryIdentifier'],_0x2d72b2=[];let _0x178dea=[];const _0x209b15=Te(_0x13fe8f);if(_0x1ccff6==='default'){for(const [_0xe5eced,_0x5e63ad]of _0x13fe8f['views']['entries']())_0x178dea=_0x178dea['concat'](hr(_0x5e63ad,_0x3ab6ce,_0x428de8)),lr(_0x5e63ad)&&(_0x13fe8f['views']['delete'](_0xe5eced),_0x5e63ad['query']['_queryParams']['loadsAllData']()||_0x2d72b2['push'](_0x5e63ad['query']));}else{const _0x542017=_0x13fe8f['views']['get'](_0x1ccff6);_0x542017&&(_0x178dea=_0x178dea['concat'](hr(_0x542017,_0x3ab6ce,_0x428de8)),lr(_0x542017)&&(_0x13fe8f['views']['delete'](_0x1ccff6),_0x542017['query']['_queryParams']['loadsAllData']()||_0x2d72b2['push'](_0x542017['query'])));}return _0x209b15&&!Te(_0x13fe8f)&&_0x2d72b2['push'](new(Fu())(_0x117ec6['_repo'],_0x117ec6['_path'])),{'removed':_0x2d72b2,'events':_0x178dea};}function zo(_0x32a569){const _0x49c258=[];for(const _0x39d89b of _0x32a569['views']['values']())_0x39d89b['query']['_queryParams']['loadsAllData']()||_0x49c258['push'](_0x39d89b);return _0x49c258;}function Ee(_0x3106da,_0x5a2e7a){let _0x8a9dee=null;for(const _0x7e4858 of _0x3106da['views']['values']())_0x8a9dee=_0x8a9dee||Du(_0x7e4858,_0x5a2e7a);return _0x8a9dee;}function jo(_0x536160,_0x4c1c1d){if(_0x4c1c1d['_queryParams']['loadsAllData']())return Ln(_0x536160);{const _0x32a660=_0x4c1c1d['_queryIdentifier'];return _0x536160['views']['get'](_0x32a660);}}function Ko(_0xcff30c,_0x554f8b){return jo(_0xcff30c,_0x554f8b)!=null;}function Te(_0x403d1d){return Ln(_0x403d1d)!=null;}function Ln(_0x5c4e51){for(const _0xd46297 of _0x5c4e51['views']['values']())if(_0xd46297['query']['_queryParams']['loadsAllData']())return _0xd46297;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xab2674){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xab2674;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x402632){this['listenProvider_']=_0x402632,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x6ec25d,_0x24576a,_0x5ed646,_0x5b7a83,_0x521968){return ou(_0x6ec25d['pendingWriteTree_'],_0x24576a,_0x5ed646,_0x5b7a83,_0x521968),_0x521968?ht(_0x6ec25d,new Fe(Ji(),_0x24576a,_0x5ed646)):[];}function Gu(_0x36a6ed,_0x4f436e,_0x59fd29,_0x10d9cb){au(_0x36a6ed['pendingWriteTree_'],_0x4f436e,_0x59fd29,_0x10d9cb);const _0x549c80=S['fromObject'](_0x59fd29);return ht(_0x36a6ed,new nt(Ji(),_0x4f436e,_0x549c80));}function pe(_0x410c6,_0x4f744a,_0xbec49e=!0x1){const _0x339f07=cu(_0x410c6['pendingWriteTree_'],_0x4f744a);if(lu(_0x410c6['pendingWriteTree_'],_0x4f744a)){let _0x2ce43e=new S(null);return _0x339f07['snap']!=null?_0x2ce43e=_0x2ce43e['set'](w(),!0x0):x(_0x339f07['children'],_0x181698=>{_0x2ce43e=_0x2ce43e['set'](new C(_0x181698),!0x0);}),ht(_0x410c6,new _n(_0x339f07['path'],_0x2ce43e,_0xbec49e));}else return[];}function $t(_0x5eae39,_0x39b3e3,_0x318605){return ht(_0x5eae39,new Fe(Xi(),_0x39b3e3,_0x318605));}function qu(_0x286fae,_0x39c654,_0x1ccab0){const _0x45c0a8=S['fromObject'](_0x1ccab0);return ht(_0x286fae,new nt(Xi(),_0x39c654,_0x45c0a8));}function zu(_0x169df6,_0x5f67ce){return ht(_0x169df6,new Dt(Xi(),_0x5f67ce));}function ju(_0x4f75cf,_0x108d43,_0x11191b){const _0xa99439=rs(_0x4f75cf,_0x11191b);if(_0xa99439){const _0x2f56fe=os(_0xa99439),_0xb35564=_0x2f56fe['path'],_0x49a5ce=_0x2f56fe['queryId'],_0x3c5a9e=F(_0xb35564,_0x108d43),_0x12ffad=new Dt(Zi(_0x49a5ce),_0x3c5a9e);return as(_0x4f75cf,_0xb35564,_0x12ffad);}else return[];}function wn(_0x4a87ec,_0x2d4b66,_0x1ad8a6,_0x5dfc9a,_0x38cb73=!0x1){const _0x5cc701=_0x2d4b66['_path'],_0x13a245=_0x4a87ec['syncPointTree_']['get'](_0x5cc701);let _0x199530=[];if(_0x13a245&&(_0x2d4b66['_queryIdentifier']==='default'||Ko(_0x13a245,_0x2d4b66))){const _0x5afa9d=Bu(_0x13a245,_0x2d4b66,_0x1ad8a6,_0x5dfc9a);Uu(_0x13a245)&&(_0x4a87ec['syncPointTree_']=_0x4a87ec['syncPointTree_']['remove'](_0x5cc701));const _0x3e06be=_0x5afa9d['removed'];if(_0x199530=_0x5afa9d['events'],!_0x38cb73){const _0x3c9cc5=_0x3e06be['findIndex'](_0x231380=>_0x231380['_queryParams']['loadsAllData']())!==-0x1,_0x56ea71=_0x4a87ec['syncPointTree_']['findOnPath'](_0x5cc701,(_0x53476c,_0xc2d4cd)=>Te(_0xc2d4cd));if(_0x3c9cc5&&!_0x56ea71){const _0x54179e=_0x4a87ec['syncPointTree_']['subtree'](_0x5cc701);if(!_0x54179e['isEmpty']()){const _0x42ed02=Qu(_0x54179e);for(let _0x77a77=0x0;_0x77a77<_0x42ed02['length'];++_0x77a77){const _0x287b69=_0x42ed02[_0x77a77],_0x5851eb=_0x287b69['query'],_0x3e227f=Xo(_0x4a87ec,_0x287b69);_0x4a87ec['listenProvider_']['startListening'](Tt(_0x5851eb),Mt(_0x4a87ec,_0x5851eb),_0x3e227f['hashFn'],_0x3e227f['onComplete']);}}}!_0x56ea71&&_0x3e06be['length']>0x0&&!_0x5dfc9a&&(_0x3c9cc5?_0x4a87ec['listenProvider_']['stopListening'](Tt(_0x2d4b66),null):_0x3e06be['forEach'](_0x262707=>{const _0x5325ac=_0x4a87ec['queryToTagMap']['get'](Fn(_0x262707));_0x4a87ec['listenProvider_']['stopListening'](Tt(_0x262707),_0x5325ac);}));}Ju(_0x4a87ec,_0x3e06be);}return _0x199530;}function Yo(_0x4b6842,_0x4725ad,_0x550c8f,_0x3b69da){const _0x1296b9=rs(_0x4b6842,_0x3b69da);if(_0x1296b9!=null){const _0x266b9d=os(_0x1296b9),_0xd67e4c=_0x266b9d['path'],_0x1db467=_0x266b9d['queryId'],_0x345905=F(_0xd67e4c,_0x4725ad),_0x10996e=new Fe(Zi(_0x1db467),_0x345905,_0x550c8f);return as(_0x4b6842,_0xd67e4c,_0x10996e);}else return[];}function Ku(_0x4afa5d,_0x338ea7,_0x302dbe,_0x122496){const _0x3ea20f=rs(_0x4afa5d,_0x122496);if(_0x3ea20f){const _0x4ac4db=os(_0x3ea20f),_0x14efeb=_0x4ac4db['path'],_0x4d5ccb=_0x4ac4db['queryId'],_0x27deb5=F(_0x14efeb,_0x338ea7),_0x4dc43e=S['fromObject'](_0x302dbe),_0x100035=new nt(Zi(_0x4d5ccb),_0x27deb5,_0x4dc43e);return as(_0x4afa5d,_0x14efeb,_0x100035);}else return[];}function bi(_0x282527,_0x19f6c6,_0x3b83f0,_0x5b7f37=!0x1){const _0x3174f3=_0x19f6c6['_path'];let _0x2e0dc5=null,_0x340e80=!0x1;_0x282527['syncPointTree_']['foreachOnPath'](_0x3174f3,(_0x83f008,_0x5b7d4d)=>{const _0x3fae2c=F(_0x83f008,_0x3174f3);_0x2e0dc5=_0x2e0dc5||Ee(_0x5b7d4d,_0x3fae2c),_0x340e80=_0x340e80||Te(_0x5b7d4d);});let _0xf705dd=_0x282527['syncPointTree_']['get'](_0x3174f3);_0xf705dd?(_0x340e80=_0x340e80||Te(_0xf705dd),_0x2e0dc5=_0x2e0dc5||Ee(_0xf705dd,w())):(_0xf705dd=new Go(),_0x282527['syncPointTree_']=_0x282527['syncPointTree_']['set'](_0x3174f3,_0xf705dd));let _0x45138b;_0x2e0dc5!=null?_0x45138b=!0x0:(_0x45138b=!0x1,_0x2e0dc5=g['EMPTY_NODE'],_0x282527['syncPointTree_']['subtree'](_0x3174f3)['foreachChild']((_0x3f890b,_0x5acea9)=>{const _0x93b2d4=Ee(_0x5acea9,w());_0x93b2d4&&(_0x2e0dc5=_0x2e0dc5['updateImmediateChild'](_0x3f890b,_0x93b2d4));}));const _0xc0dbc2=Ko(_0xf705dd,_0x19f6c6);if(!_0xc0dbc2&&!_0x19f6c6['_queryParams']['loadsAllData']()){const _0x39fc39=Fn(_0x19f6c6);f(!_0x282527['queryToTagMap']['has'](_0x39fc39),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x56e9c7=Xu();_0x282527['queryToTagMap']['set'](_0x39fc39,_0x56e9c7),_0x282527['tagToQueryMap']['set'](_0x56e9c7,_0x39fc39);}const _0x37e67f=Mn(_0x282527['pendingWriteTree_'],_0x3174f3);let _0x3ecbf3=Wu(_0xf705dd,_0x19f6c6,_0x3b83f0,_0x37e67f,_0x2e0dc5,_0x45138b);if(!_0xc0dbc2&&!_0x340e80&&!_0x5b7f37){const _0xa86c05=jo(_0xf705dd,_0x19f6c6);_0x3ecbf3=_0x3ecbf3['concat'](Zu(_0x282527,_0x19f6c6,_0xa86c05));}return _0x3ecbf3;}function xn(_0x2cd96f,_0x1d7b8b,_0x54eb01){const _0x3ea0d0=_0x2cd96f['pendingWriteTree_'],_0x516e33=_0x2cd96f['syncPointTree_']['findOnPath'](_0x1d7b8b,(_0x6f8a3e,_0x41674b)=>{const _0x2abe83=F(_0x6f8a3e,_0x1d7b8b),_0x131fb9=Ee(_0x41674b,_0x2abe83);if(_0x131fb9)return _0x131fb9;});return Uo(_0x3ea0d0,_0x1d7b8b,_0x516e33,_0x54eb01,!0x0);}function Yu(_0x41f617,_0x45153b){const _0x122e3e=_0x45153b['_path'];let _0x42fb8e=null;_0x41f617['syncPointTree_']['foreachOnPath'](_0x122e3e,(_0xce5f75,_0x3aa719)=>{const _0x53e536=F(_0xce5f75,_0x122e3e);_0x42fb8e=_0x42fb8e||Ee(_0x3aa719,_0x53e536);});let _0x4d3d1d=_0x41f617['syncPointTree_']['get'](_0x122e3e);_0x4d3d1d?_0x42fb8e=_0x42fb8e||Ee(_0x4d3d1d,w()):(_0x4d3d1d=new Go(),_0x41f617['syncPointTree_']=_0x41f617['syncPointTree_']['set'](_0x122e3e,_0x4d3d1d));const _0x522cf8=_0x42fb8e!=null,_0x2ab16d=_0x522cf8?new Ce(_0x42fb8e,!0x0,!0x1):null,_0x4e7f17=Mn(_0x41f617['pendingWriteTree_'],_0x45153b['_path']),_0x3e6150=qo(_0x4d3d1d,_0x45153b,_0x4e7f17,_0x522cf8?_0x2ab16d['getNode']():g['EMPTY_NODE'],_0x522cf8);return Ou(_0x3e6150);}function ht(_0x2ecd27,_0x1950ff){return Qo(_0x1950ff,_0x2ecd27['syncPointTree_'],null,Mn(_0x2ecd27['pendingWriteTree_'],w()));}function Qo(_0x28cf50,_0x326c67,_0x4741f7,_0x418a30){if(v(_0x28cf50['path']))return Jo(_0x28cf50,_0x326c67,_0x4741f7,_0x418a30);{const _0x2df482=_0x326c67['get'](w());_0x4741f7==null&&_0x2df482!=null&&(_0x4741f7=Ee(_0x2df482,w()));let _0x5d5ec9=[];const _0x3582e8=y(_0x28cf50['path']),_0x48c1a3=_0x28cf50['operationForChild'](_0x3582e8),_0x283de8=_0x326c67['children']['get'](_0x3582e8);if(_0x283de8&&_0x48c1a3){const _0x440491=_0x4741f7?_0x4741f7['getImmediateChild'](_0x3582e8):null,_0x2db9a1=Wo(_0x418a30,_0x3582e8);_0x5d5ec9=_0x5d5ec9['concat'](Qo(_0x48c1a3,_0x283de8,_0x440491,_0x2db9a1));}return _0x2df482&&(_0x5d5ec9=_0x5d5ec9['concat'](is(_0x2df482,_0x28cf50,_0x418a30,_0x4741f7))),_0x5d5ec9;}}function Jo(_0x44f83c,_0x379ce1,_0x4371d9,_0x5a8905){const _0x4720ea=_0x379ce1['get'](w());_0x4371d9==null&&_0x4720ea!=null&&(_0x4371d9=Ee(_0x4720ea,w()));let _0x53e154=[];return _0x379ce1['children']['inorderTraversal']((_0x445923,_0x79d8c6)=>{const _0x37151d=_0x4371d9?_0x4371d9['getImmediateChild'](_0x445923):null,_0x1cab90=Wo(_0x5a8905,_0x445923),_0x2dbfa4=_0x44f83c['operationForChild'](_0x445923);_0x2dbfa4&&(_0x53e154=_0x53e154['concat'](Jo(_0x2dbfa4,_0x79d8c6,_0x37151d,_0x1cab90)));}),_0x4720ea&&(_0x53e154=_0x53e154['concat'](is(_0x4720ea,_0x44f83c,_0x5a8905,_0x4371d9))),_0x53e154;}function Xo(_0x3fea3d,_0x5937d7){const _0xeae685=_0x5937d7['query'],_0xd7fde=Mt(_0x3fea3d,_0xeae685);return{'hashFn':()=>(Pu(_0x5937d7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x521f69=>{if(_0x521f69==='ok')return _0xd7fde?ju(_0x3fea3d,_0xeae685['_path'],_0xd7fde):zu(_0x3fea3d,_0xeae685['_path']);{const _0x1d58e5=ql(_0x521f69,_0xeae685);return wn(_0x3fea3d,_0xeae685,null,_0x1d58e5);}}};}function Mt(_0x1d7cca,_0x311f03){const _0x2286b5=Fn(_0x311f03);return _0x1d7cca['queryToTagMap']['get'](_0x2286b5);}function Fn(_0x331951){return _0x331951['_path']['toString']()+'$'+_0x331951['_queryIdentifier'];}function rs(_0x2091d4,_0x3106b4){return _0x2091d4['tagToQueryMap']['get'](_0x3106b4);}function os(_0x4959a3){const _0x3b4888=_0x4959a3['indexOf']('$');return f(_0x3b4888!==-0x1&&_0x3b4888<_0x4959a3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4959a3['substr'](_0x3b4888+0x1),'path':new C(_0x4959a3['substr'](0x0,_0x3b4888))};}function as(_0x2ca249,_0x4c45ab,_0xf4ad71){const _0x921d24=_0x2ca249['syncPointTree_']['get'](_0x4c45ab);f(_0x921d24,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x521621=Mn(_0x2ca249['pendingWriteTree_'],_0x4c45ab);return is(_0x921d24,_0xf4ad71,_0x521621,null);}function Qu(_0x245ad5){return _0x245ad5['fold']((_0x2d49c1,_0x5df578,_0xf5cb25)=>{if(_0x5df578&&Te(_0x5df578))return[Ln(_0x5df578)];{let _0xe4cfd=[];return _0x5df578&&(_0xe4cfd=zo(_0x5df578)),x(_0xf5cb25,(_0x5517c,_0x5f5bf2)=>{_0xe4cfd=_0xe4cfd['concat'](_0x5f5bf2);}),_0xe4cfd;}});}function Tt(_0x573c24){return _0x573c24['_queryParams']['loadsAllData']()&&!_0x573c24['_queryParams']['isDefault']()?new(Hu())(_0x573c24['_repo'],_0x573c24['_path']):_0x573c24;}function Ju(_0x3826e4,_0x505ef9){for(let _0x4ab5b4=0x0;_0x4ab5b4<_0x505ef9['length'];++_0x4ab5b4){const _0x3fb70c=_0x505ef9[_0x4ab5b4];if(!_0x3fb70c['_queryParams']['loadsAllData']()){const _0xe37b85=Fn(_0x3fb70c),_0x203561=_0x3826e4['queryToTagMap']['get'](_0xe37b85);_0x3826e4['queryToTagMap']['delete'](_0xe37b85),_0x3826e4['tagToQueryMap']['delete'](_0x203561);}}}function Xu(){return $u++;}function Zu(_0x8a806,_0x52eba0,_0x37e62e){const _0x3bbbb3=_0x52eba0['_path'],_0x6da667=Mt(_0x8a806,_0x52eba0),_0x538fc1=Xo(_0x8a806,_0x37e62e),_0x2d9875=_0x8a806['listenProvider_']['startListening'](Tt(_0x52eba0),_0x6da667,_0x538fc1['hashFn'],_0x538fc1['onComplete']),_0x332906=_0x8a806['syncPointTree_']['subtree'](_0x3bbbb3);if(_0x6da667)f(!Te(_0x332906['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x334757=_0x332906['fold']((_0xf7a5cb,_0x4a68d6,_0x1fb3f4)=>{if(!v(_0xf7a5cb)&&_0x4a68d6&&Te(_0x4a68d6))return[Ln(_0x4a68d6)['query']];{let _0x47e4f4=[];return _0x4a68d6&&(_0x47e4f4=_0x47e4f4['concat'](zo(_0x4a68d6)['map'](_0x51fa8e=>_0x51fa8e['query']))),x(_0x1fb3f4,(_0x590f46,_0x3aead7)=>{_0x47e4f4=_0x47e4f4['concat'](_0x3aead7);}),_0x47e4f4;}});for(let _0x1b3f50=0x0;_0x1b3f50<_0x334757['length'];++_0x1b3f50){const _0xe7ad91=_0x334757[_0x1b3f50];_0x8a806['listenProvider_']['stopListening'](Tt(_0xe7ad91),Mt(_0x8a806,_0xe7ad91));}}return _0x2d9875;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x431c8d){this['node_']=_0x431c8d;}['getImmediateChild'](_0x1525d7){const _0x2e3c32=this['node_']['getImmediateChild'](_0x1525d7);return new cs(_0x2e3c32);}['node'](){return this['node_'];}}class ls{constructor(_0x1b3c6e,_0x30462f){this['syncTree_']=_0x1b3c6e,this['path_']=_0x30462f;}['getImmediateChild'](_0x3a235e){const _0x21e22d=A(this['path_'],_0x3a235e);return new ls(this['syncTree_'],_0x21e22d);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x57c50b){return _0x57c50b=_0x57c50b||{},_0x57c50b['timestamp']=_0x57c50b['timestamp']||new Date()['getTime'](),_0x57c50b;},fr=function(_0x37d922,_0x529364,_0x534535){if(!_0x37d922||typeof _0x37d922!='object')return _0x37d922;if(f('.sv'in _0x37d922,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x37d922['.sv']=='string')return td(_0x37d922['.sv'],_0x529364,_0x534535);if(typeof _0x37d922['.sv']=='object')return nd(_0x37d922['.sv'],_0x529364);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x37d922,null,0x2));},td=function(_0x1e8c21,_0x308535,_0x2bbe9f){switch(_0x1e8c21){case'timestamp':return _0x2bbe9f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1e8c21);}},nd=function(_0x1a50f0,_0x1d6a91,_0x1b88ac){_0x1a50f0['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1a50f0,null,0x2));const _0x7da6c8=_0x1a50f0['increment'];typeof _0x7da6c8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x7da6c8);const _0x383ec2=_0x1d6a91['node']();if(f(_0x383ec2!==null&&typeof _0x383ec2<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x383ec2['isLeafNode']())return _0x7da6c8;const _0x458acc=_0x383ec2['getValue']();return typeof _0x458acc!='number'?_0x7da6c8:_0x458acc+_0x7da6c8;},Zo=function(_0x4321ff,_0x1ba5a6,_0x5bccc3,_0xd9ad29){return us(_0x1ba5a6,new ls(_0x5bccc3,_0x4321ff),_0xd9ad29);},hs=function(_0x3d071c,_0x29c5ab,_0x2ecfcd){return us(_0x3d071c,new cs(_0x29c5ab),_0x2ecfcd);};function us(_0x34cd33,_0x4a3ba5,_0x548fb3){const _0x1a59e2=_0x34cd33['getPriority']()['val'](),_0x3a2f55=fr(_0x1a59e2,_0x4a3ba5['getImmediateChild']('.priority'),_0x548fb3);let _0x50830e;if(_0x34cd33['isLeafNode']()){const _0x5b7a23=_0x34cd33,_0x41432f=fr(_0x5b7a23['getValue'](),_0x4a3ba5,_0x548fb3);return _0x41432f!==_0x5b7a23['getValue']()||_0x3a2f55!==_0x5b7a23['getPriority']()['val']()?new D(_0x41432f,N(_0x3a2f55)):_0x34cd33;}else{const _0x16b267=_0x34cd33;return _0x50830e=_0x16b267,_0x3a2f55!==_0x16b267['getPriority']()['val']()&&(_0x50830e=_0x50830e['updatePriority'](new D(_0x3a2f55))),_0x16b267['forEachChild'](R,(_0x5153af,_0x383959)=>{const _0x18b8fc=us(_0x383959,_0x4a3ba5['getImmediateChild'](_0x5153af),_0x548fb3);_0x18b8fc!==_0x383959&&(_0x50830e=_0x50830e['updateImmediateChild'](_0x5153af,_0x18b8fc));}),_0x50830e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x26d6ca='',_0x511884=null,_0x288115={'children':{},'childCount':0x0}){this['name']=_0x26d6ca,this['parent']=_0x511884,this['node']=_0x288115;}}function Un(_0x79a649,_0x13dcc4){let _0x462c82=_0x13dcc4 instanceof C?_0x13dcc4:new C(_0x13dcc4),_0x53c6dc=_0x79a649,_0x798712=y(_0x462c82);for(;_0x798712!==null;){const _0x54efea=Oe(_0x53c6dc['node']['children'],_0x798712)||{'children':{},'childCount':0x0};_0x53c6dc=new ds(_0x798712,_0x53c6dc,_0x54efea),_0x462c82=b(_0x462c82),_0x798712=y(_0x462c82);}return _0x53c6dc;}function Ge(_0x5978ad){return _0x5978ad['node']['value'];}function fs(_0x5b9198,_0x22c0c6){_0x5b9198['node']['value']=_0x22c0c6,Ri(_0x5b9198);}function ea(_0x4f4f26){return _0x4f4f26['node']['childCount']>0x0;}function id(_0x36c20f){return Ge(_0x36c20f)===void 0x0&&!ea(_0x36c20f);}function Wn(_0x503bf7,_0x1e48b5){x(_0x503bf7['node']['children'],(_0xcbfafd,_0x1dcce9)=>{_0x1e48b5(new ds(_0xcbfafd,_0x503bf7,_0x1dcce9));});}function ta(_0x31d52e,_0xe71764,_0x1ae4f8,_0x2c2cab){_0x1ae4f8&&_0xe71764(_0x31d52e),Wn(_0x31d52e,_0x400f8c=>{ta(_0x400f8c,_0xe71764,!0x0);});}function sd(_0x4701e7,_0x58c036,_0x2e2a06){let _0x2033f4=_0x4701e7['parent'];for(;_0x2033f4!==null;){if(_0x58c036(_0x2033f4))return!0x0;_0x2033f4=_0x2033f4['parent'];}return!0x1;}function Gt(_0x5e086a){return new C(_0x5e086a['parent']===null?_0x5e086a['name']:Gt(_0x5e086a['parent'])+'/'+_0x5e086a['name']);}function Ri(_0x2ea52e){_0x2ea52e['parent']!==null&&rd(_0x2ea52e['parent'],_0x2ea52e['name'],_0x2ea52e);}function rd(_0x18a528,_0x5abc59,_0xc047a6){const _0x425346=id(_0xc047a6),_0x21cacc=Y(_0x18a528['node']['children'],_0x5abc59);_0x425346&&_0x21cacc?(delete _0x18a528['node']['children'][_0x5abc59],_0x18a528['node']['childCount']--,Ri(_0x18a528)):!_0x425346&&!_0x21cacc&&(_0x18a528['node']['children'][_0x5abc59]=_0xc047a6['node'],_0x18a528['node']['childCount']++,Ri(_0x18a528));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x1bcb29){return typeof _0x1bcb29=='string'&&_0x1bcb29['length']!==0x0&&!od['test'](_0x1bcb29);},na=function(_0x4915ae){return typeof _0x4915ae=='string'&&_0x4915ae['length']!==0x0&&!ad['test'](_0x4915ae);},cd=function(_0x346ef9){return _0x346ef9&&(_0x346ef9=_0x346ef9['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x346ef9);},Cn=function(_0x111ab2){return _0x111ab2===null||typeof _0x111ab2=='string'||typeof _0x111ab2=='number'&&!Wi(_0x111ab2)||_0x111ab2&&typeof _0x111ab2=='object'&&Y(_0x111ab2,'.sv');},qt=function(_0x3c89d2,_0x1e048f,_0x4bd36c,_0x4feea2){_0x4feea2&&_0x1e048f===void 0x0||zt(Nn(_0x3c89d2,'value'),_0x1e048f,_0x4bd36c);},zt=function(_0x18ecb1,_0x42e7db,_0x116084){const _0x4dc92e=_0x116084 instanceof C?new Sh(_0x116084,_0x18ecb1):_0x116084;if(_0x42e7db===void 0x0)throw new Error(_0x18ecb1+'contains\x20undefined\x20'+Ne(_0x4dc92e));if(typeof _0x42e7db=='function')throw new Error(_0x18ecb1+'contains\x20a\x20function\x20'+Ne(_0x4dc92e)+'\x20with\x20contents\x20=\x20'+_0x42e7db['toString']());if(Wi(_0x42e7db))throw new Error(_0x18ecb1+'contains\x20'+_0x42e7db['toString']()+'\x20'+Ne(_0x4dc92e));if(typeof _0x42e7db=='string'&&_0x42e7db['length']>oi/0x3&&Pn(_0x42e7db)>oi)throw new Error(_0x18ecb1+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4dc92e)+'\x20(\x27'+_0x42e7db['substring'](0x0,0x32)+'...\x27)');if(_0x42e7db&&typeof _0x42e7db=='object'){let _0x4af825=!0x1,_0x39dc4c=!0x1;if(x(_0x42e7db,(_0x196043,_0x579322)=>{if(_0x196043==='.value')_0x4af825=!0x0;else{if(_0x196043!=='.priority'&&_0x196043!=='.sv'&&(_0x39dc4c=!0x0,!ps(_0x196043)))throw new Error(_0x18ecb1+'\x20contains\x20an\x20invalid\x20key\x20('+_0x196043+')\x20'+Ne(_0x4dc92e)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4dc92e,_0x196043),zt(_0x18ecb1,_0x579322,_0x4dc92e),Rh(_0x4dc92e);}),_0x4af825&&_0x39dc4c)throw new Error(_0x18ecb1+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4dc92e)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x512fd3,_0x26f784){let _0x2e5cdb,_0xf039cc;for(_0x2e5cdb=0x0;_0x2e5cdb<_0x26f784['length'];_0x2e5cdb++){_0xf039cc=_0x26f784[_0x2e5cdb];const _0x5c2a42=kt(_0xf039cc);for(let _0x25879b=0x0;_0x25879b<_0x5c2a42['length'];_0x25879b++)if(!(_0x5c2a42[_0x25879b]==='.priority'&&_0x25879b===_0x5c2a42['length']-0x1)){if(!ps(_0x5c2a42[_0x25879b]))throw new Error(_0x512fd3+'contains\x20an\x20invalid\x20key\x20('+_0x5c2a42[_0x25879b]+')\x20in\x20path\x20'+_0xf039cc['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x26f784['sort'](Th);let _0x1cfb40=null;for(_0x2e5cdb=0x0;_0x2e5cdb<_0x26f784['length'];_0x2e5cdb++){if(_0xf039cc=_0x26f784[_0x2e5cdb],_0x1cfb40!==null&&$(_0x1cfb40,_0xf039cc))throw new Error(_0x512fd3+'contains\x20a\x20path\x20'+_0x1cfb40['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xf039cc['toString']());_0x1cfb40=_0xf039cc;}},hd=function(_0x572910,_0x1d7224,_0x210a66,_0x42510e){const _0x325ab4=Nn(_0x572910,'values');if(!(_0x1d7224&&typeof _0x1d7224=='object')||Array['isArray'](_0x1d7224))throw new Error(_0x325ab4+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4b143f=[];x(_0x1d7224,(_0x30edd2,_0x287ecd)=>{const _0x5cca87=new C(_0x30edd2);if(zt(_0x325ab4,_0x287ecd,A(_0x210a66,_0x5cca87)),Gi(_0x5cca87)==='.priority'&&!Cn(_0x287ecd))throw new Error(_0x325ab4+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5cca87['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4b143f['push'](_0x5cca87);}),ld(_0x325ab4,_0x4b143f);},_s=function(_0x702279,_0x1b7fc8,_0x3b547,_0x1e6dff){if(!na(_0x3b547))throw new Error(Nn(_0x702279,_0x1b7fc8)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3b547+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5da7dc,_0x384ae3,_0xe69cf3,_0x446af3){_0xe69cf3&&(_0xe69cf3=_0xe69cf3['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5da7dc,_0x384ae3,_0xe69cf3);},gs=function(_0x539d94,_0x483cae){if(y(_0x483cae)==='.info')throw new Error(_0x539d94+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x383d14,_0x27b735){const _0x2e2b61=_0x27b735['path']['toString']();if(typeof _0x27b735['repoInfo']['host']!='string'||_0x27b735['repoInfo']['host']['length']===0x0||!ps(_0x27b735['repoInfo']['namespace'])&&_0x27b735['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2e2b61['length']!==0x0&&!cd(_0x2e2b61))throw new Error(Nn(_0x383d14,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x33fa50,_0x12cb6d){let _0x13d474=null;for(let _0x245c78=0x0;_0x245c78<_0x12cb6d['length'];_0x245c78++){const _0x3b5872=_0x12cb6d[_0x245c78],_0x2e286a=_0x3b5872['getPath']();_0x13d474!==null&&!qi(_0x2e286a,_0x13d474['path'])&&(_0x33fa50['eventLists_']['push'](_0x13d474),_0x13d474=null),_0x13d474===null&&(_0x13d474={'events':[],'path':_0x2e286a}),_0x13d474['events']['push'](_0x3b5872);}_0x13d474&&_0x33fa50['eventLists_']['push'](_0x13d474);}function ia(_0x1a91ab,_0x3aaf71,_0x596264){Bn(_0x1a91ab,_0x596264),sa(_0x1a91ab,_0x24f9cf=>qi(_0x24f9cf,_0x3aaf71));}function V(_0x5d229b,_0xc41062,_0xdae29f){Bn(_0x5d229b,_0xdae29f),sa(_0x5d229b,_0x230ccc=>$(_0x230ccc,_0xc41062)||$(_0xc41062,_0x230ccc));}function sa(_0x2f7fe4,_0x3b5ce6){_0x2f7fe4['recursionDepth_']++;let _0x3643d7=!0x0;for(let _0x4b7cb6=0x0;_0x4b7cb6<_0x2f7fe4['eventLists_']['length'];_0x4b7cb6++){const _0x4350e1=_0x2f7fe4['eventLists_'][_0x4b7cb6];if(_0x4350e1){const _0x2ed380=_0x4350e1['path'];_0x3b5ce6(_0x2ed380)?(pd(_0x2f7fe4['eventLists_'][_0x4b7cb6]),_0x2f7fe4['eventLists_'][_0x4b7cb6]=null):_0x3643d7=!0x1;}}_0x3643d7&&(_0x2f7fe4['eventLists_']=[]),_0x2f7fe4['recursionDepth_']--;}function pd(_0x1eacf9){for(let _0x342b48=0x0;_0x342b48<_0x1eacf9['events']['length'];_0x342b48++){const _0x44ab22=_0x1eacf9['events'][_0x342b48];if(_0x44ab22!==null){_0x1eacf9['events'][_0x342b48]=null;const _0x3234f8=_0x44ab22['getEventRunner']();Et&&L('event:\x20'+_0x44ab22['toString']()),lt(_0x3234f8);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0xed505a,_0x32d5c7,_0x5e3af0,_0x24f4ca){this['repoInfo_']=_0xed505a,this['forceRestClient_']=_0x32d5c7,this['authTokenProvider_']=_0x5e3af0,this['appCheckProvider_']=_0x24f4ca,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x51731e,_0x261ff5,_0x1a60c8){if(_0x51731e['stats_']=Hi(_0x51731e['repoInfo_']),_0x51731e['forceRestClient_']||Yl())_0x51731e['server_']=new fn(_0x51731e['repoInfo_'],(_0x5ad89a,_0x3bd22a,_0x495f85,_0x596209)=>{pr(_0x51731e,_0x5ad89a,_0x3bd22a,_0x495f85,_0x596209);},_0x51731e['authTokenProvider_'],_0x51731e['appCheckProvider_']),setTimeout(()=>_r(_0x51731e,!0x0),0x0);else{if(typeof _0x1a60c8<'u'&&_0x1a60c8!==null){if(typeof _0x1a60c8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1a60c8);}catch(_0x41498c){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x41498c);}}_0x51731e['persistentConnection_']=new ie(_0x51731e['repoInfo_'],_0x261ff5,(_0x3501fa,_0x9aa678,_0x42f233,_0x562602)=>{pr(_0x51731e,_0x3501fa,_0x9aa678,_0x42f233,_0x562602);},_0xb10ec7=>{_r(_0x51731e,_0xb10ec7);},_0x331e55=>{yd(_0x51731e,_0x331e55);},_0x51731e['authTokenProvider_'],_0x51731e['appCheckProvider_'],_0x1a60c8),_0x51731e['server_']=_0x51731e['persistentConnection_'];}_0x51731e['authTokenProvider_']['addTokenChangeListener'](_0x50a161=>{_0x51731e['server_']['refreshAuthToken'](_0x50a161);}),_0x51731e['appCheckProvider_']['addTokenChangeListener'](_0x16e5a4=>{_0x51731e['server_']['refreshAppCheckToken'](_0x16e5a4['token']);}),_0x51731e['statsReporter_']=eh(_0x51731e['repoInfo_'],()=>new eu(_0x51731e['stats_'],_0x51731e['server_'])),_0x51731e['infoData_']=new Yh(),_0x51731e['infoSyncTree_']=new dr({'startListening':(_0x58360e,_0x570d2c,_0x1da690,_0x3654ef)=>{let _0x368d23=[];const _0x12a83e=_0x51731e['infoData_']['getNode'](_0x58360e['_path']);return _0x12a83e['isEmpty']()||(_0x368d23=$t(_0x51731e['infoSyncTree_'],_0x58360e['_path'],_0x12a83e),setTimeout(()=>{_0x3654ef('ok');},0x0)),_0x368d23;},'stopListening':()=>{}}),ms(_0x51731e,'connected',!0x1),_0x51731e['serverSyncTree_']=new dr({'startListening':(_0x259bc9,_0x3cd662,_0x576a08,_0x25b962)=>(_0x51731e['server_']['listen'](_0x259bc9,_0x576a08,_0x3cd662,(_0x4fa37e,_0x167e23)=>{const _0x20067b=_0x25b962(_0x4fa37e,_0x167e23);V(_0x51731e['eventQueue_'],_0x259bc9['_path'],_0x20067b);}),[]),'stopListening':(_0x180e5c,_0x3f222e)=>{_0x51731e['server_']['unlisten'](_0x180e5c,_0x3f222e);}});}function oa(_0xb80747){const _0x3c5a44=_0xb80747['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3c5a44;}function jt(_0x390b40){return ed({'timestamp':oa(_0x390b40)});}function pr(_0x4a4896,_0x55aa39,_0x19c3ee,_0x40e8f3,_0x23ef4e){_0x4a4896['dataUpdateCount']++;const _0x2a56f7=new C(_0x55aa39);_0x19c3ee=_0x4a4896['interceptServerDataCallback_']?_0x4a4896['interceptServerDataCallback_'](_0x55aa39,_0x19c3ee):_0x19c3ee;let _0x3063e3=[];if(_0x23ef4e){if(_0x40e8f3){const _0x251e7a=ln(_0x19c3ee,_0x40dbf6=>N(_0x40dbf6));_0x3063e3=Ku(_0x4a4896['serverSyncTree_'],_0x2a56f7,_0x251e7a,_0x23ef4e);}else{const _0xe065a6=N(_0x19c3ee);_0x3063e3=Yo(_0x4a4896['serverSyncTree_'],_0x2a56f7,_0xe065a6,_0x23ef4e);}}else{if(_0x40e8f3){const _0x481bf8=ln(_0x19c3ee,_0x57b5c8=>N(_0x57b5c8));_0x3063e3=qu(_0x4a4896['serverSyncTree_'],_0x2a56f7,_0x481bf8);}else{const _0x3aec7c=N(_0x19c3ee);_0x3063e3=$t(_0x4a4896['serverSyncTree_'],_0x2a56f7,_0x3aec7c);}}let _0x3425f1=_0x2a56f7;_0x3063e3['length']>0x0&&(_0x3425f1=st(_0x4a4896,_0x2a56f7)),V(_0x4a4896['eventQueue_'],_0x3425f1,_0x3063e3);}function _r(_0x337f1f,_0xa4c66e){ms(_0x337f1f,'connected',_0xa4c66e),_0xa4c66e===!0x1&&wd(_0x337f1f);}function yd(_0x3341a6,_0x4d94c0){x(_0x4d94c0,(_0x24fab4,_0x589fed)=>{ms(_0x3341a6,_0x24fab4,_0x589fed);});}function ms(_0x351d79,_0x3c5e3f,_0x590194){const _0x536298=new C('/.info/'+_0x3c5e3f),_0x262f09=N(_0x590194);_0x351d79['infoData_']['updateSnapshot'](_0x536298,_0x262f09);const _0x808037=$t(_0x351d79['infoSyncTree_'],_0x536298,_0x262f09);V(_0x351d79['eventQueue_'],_0x536298,_0x808037);}function Vn(_0x394438){return _0x394438['nextWriteId_']++;}function vd(_0x7df881,_0xacda55,_0x51ea55){const _0x2284a1=Yu(_0x7df881['serverSyncTree_'],_0xacda55);return _0x2284a1!=null?Promise['resolve'](_0x2284a1):_0x7df881['server_']['get'](_0xacda55)['then'](_0x46f4d3=>{const _0x49962b=N(_0x46f4d3)['withIndex'](_0xacda55['_queryParams']['getIndex']());bi(_0x7df881['serverSyncTree_'],_0xacda55,_0x51ea55,!0x0);let _0x718176;if(_0xacda55['_queryParams']['loadsAllData']())_0x718176=$t(_0x7df881['serverSyncTree_'],_0xacda55['_path'],_0x49962b);else{const _0x544b77=Mt(_0x7df881['serverSyncTree_'],_0xacda55);_0x718176=Yo(_0x7df881['serverSyncTree_'],_0xacda55['_path'],_0x49962b,_0x544b77);}return V(_0x7df881['eventQueue_'],_0xacda55['_path'],_0x718176),wn(_0x7df881['serverSyncTree_'],_0xacda55,_0x51ea55,null,!0x0),_0x49962b;},_0x44d1dd=>(ut(_0x7df881,'get\x20for\x20query\x20'+O(_0xacda55)+'\x20failed:\x20'+_0x44d1dd),Promise['reject'](new Error(_0x44d1dd))));}function Ed(_0x563757,_0x1a751f,_0x37ff13,_0x4b4733,_0x3966ab){ut(_0x563757,'set',{'path':_0x1a751f['toString'](),'value':_0x37ff13,'priority':_0x4b4733});const _0x264c02=jt(_0x563757),_0x318764=N(_0x37ff13,_0x4b4733),_0x199d1e=xn(_0x563757['serverSyncTree_'],_0x1a751f),_0x5d7544=hs(_0x318764,_0x199d1e,_0x264c02),_0x350660=Vn(_0x563757),_0x507a24=ss(_0x563757['serverSyncTree_'],_0x1a751f,_0x5d7544,_0x350660,!0x0);Bn(_0x563757['eventQueue_'],_0x507a24),_0x563757['server_']['put'](_0x1a751f['toString'](),_0x318764['val'](!0x0),(_0x14d5f9,_0x4eee3d)=>{const _0x509078=_0x14d5f9==='ok';_0x509078||U('set\x20at\x20'+_0x1a751f+'\x20failed:\x20'+_0x14d5f9);const _0x3cd86f=pe(_0x563757['serverSyncTree_'],_0x350660,!_0x509078);V(_0x563757['eventQueue_'],_0x1a751f,_0x3cd86f),Ai(_0x563757,_0x3966ab,_0x14d5f9,_0x4eee3d);});const _0x3da879=vs(_0x563757,_0x1a751f);st(_0x563757,_0x3da879),V(_0x563757['eventQueue_'],_0x3da879,[]);}function Id(_0x2e05f6,_0x37d7ef,_0x3dc170,_0x5934ed){ut(_0x2e05f6,'update',{'path':_0x37d7ef['toString'](),'value':_0x3dc170});let _0x47a131=!0x0;const _0xb921d4=jt(_0x2e05f6),_0x1bd9bd={};if(x(_0x3dc170,(_0x53d3e7,_0xb98c58)=>{_0x47a131=!0x1,_0x1bd9bd[_0x53d3e7]=Zo(A(_0x37d7ef,_0x53d3e7),N(_0xb98c58),_0x2e05f6['serverSyncTree_'],_0xb921d4);}),_0x47a131)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x2e05f6,_0x5934ed,'ok',void 0x0);else{const _0x2597aa=Vn(_0x2e05f6),_0x2f0ad1=Gu(_0x2e05f6['serverSyncTree_'],_0x37d7ef,_0x1bd9bd,_0x2597aa);Bn(_0x2e05f6['eventQueue_'],_0x2f0ad1),_0x2e05f6['server_']['merge'](_0x37d7ef['toString'](),_0x3dc170,(_0x2cffd6,_0x12768e)=>{const _0xe80a7b=_0x2cffd6==='ok';_0xe80a7b||U('update\x20at\x20'+_0x37d7ef+'\x20failed:\x20'+_0x2cffd6);const _0x2c9c2a=pe(_0x2e05f6['serverSyncTree_'],_0x2597aa,!_0xe80a7b),_0xaff6b0=_0x2c9c2a['length']>0x0?st(_0x2e05f6,_0x37d7ef):_0x37d7ef;V(_0x2e05f6['eventQueue_'],_0xaff6b0,_0x2c9c2a),Ai(_0x2e05f6,_0x5934ed,_0x2cffd6,_0x12768e);}),x(_0x3dc170,_0x213a0d=>{const _0x5603ba=vs(_0x2e05f6,A(_0x37d7ef,_0x213a0d));st(_0x2e05f6,_0x5603ba);}),V(_0x2e05f6['eventQueue_'],_0x37d7ef,[]);}}function wd(_0x3eb1a0){ut(_0x3eb1a0,'onDisconnectEvents');const _0x404f53=jt(_0x3eb1a0),_0x270d2a=pn();Ei(_0x3eb1a0['onDisconnect_'],w(),(_0x90777f,_0x4c0460)=>{const _0x2eb2a7=Zo(_0x90777f,_0x4c0460,_0x3eb1a0['serverSyncTree_'],_0x404f53);Mo(_0x270d2a,_0x90777f,_0x2eb2a7);});let _0x16c8a3=[];Ei(_0x270d2a,w(),(_0x5bf0eb,_0x48bc0c)=>{_0x16c8a3=_0x16c8a3['concat']($t(_0x3eb1a0['serverSyncTree_'],_0x5bf0eb,_0x48bc0c));const _0x1970df=vs(_0x3eb1a0,_0x5bf0eb);st(_0x3eb1a0,_0x1970df);}),_0x3eb1a0['onDisconnect_']=pn(),V(_0x3eb1a0['eventQueue_'],w(),_0x16c8a3);}function Cd(_0x2c37c1,_0x10f329,_0x6b844a){let _0x4bad2f;y(_0x10f329['_path'])==='.info'?_0x4bad2f=bi(_0x2c37c1['infoSyncTree_'],_0x10f329,_0x6b844a):_0x4bad2f=bi(_0x2c37c1['serverSyncTree_'],_0x10f329,_0x6b844a),ia(_0x2c37c1['eventQueue_'],_0x10f329['_path'],_0x4bad2f);}function Td(_0x297a1f,_0x375230,_0x2d59e9){let _0x51a1d1;y(_0x375230['_path'])==='.info'?_0x51a1d1=wn(_0x297a1f['infoSyncTree_'],_0x375230,_0x2d59e9):_0x51a1d1=wn(_0x297a1f['serverSyncTree_'],_0x375230,_0x2d59e9),ia(_0x297a1f['eventQueue_'],_0x375230['_path'],_0x51a1d1);}function aa(_0x475354){_0x475354['persistentConnection_']&&_0x475354['persistentConnection_']['interrupt'](ra);}function Sd(_0x273cb7){_0x273cb7['persistentConnection_']&&_0x273cb7['persistentConnection_']['resume'](ra);}function ut(_0x4c8c74,..._0x48ea81){let _0x308d14='';_0x4c8c74['persistentConnection_']&&(_0x308d14=_0x4c8c74['persistentConnection_']['id']+':'),L(_0x308d14,..._0x48ea81);}function Ai(_0x29ff40,_0xb62903,_0x29fc9d,_0xa3ab46){_0xb62903&&lt(()=>{if(_0x29fc9d==='ok')_0xb62903(null);else{const _0x3ff95d=(_0x29fc9d||'error')['toUpperCase']();let _0x119b9c=_0x3ff95d;_0xa3ab46&&(_0x119b9c+=':\x20'+_0xa3ab46);const _0x3b9922=new Error(_0x119b9c);_0x3b9922['code']=_0x3ff95d,_0xb62903(_0x3b9922);}});}function bd(_0x56960d,_0x14c776,_0x142290,_0x5b4492,_0x263323,_0x6f5560){ut(_0x56960d,'transaction\x20on\x20'+_0x14c776);const _0x6af6c={'path':_0x14c776,'update':_0x142290,'onComplete':_0x5b4492,'status':null,'order':to(),'applyLocally':_0x6f5560,'retryCount':0x0,'unwatcher':_0x263323,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1acc9e=ys(_0x56960d,_0x14c776,void 0x0);_0x6af6c['currentInputSnapshot']=_0x1acc9e;const _0x1aeefa=_0x6af6c['update'](_0x1acc9e['val']());if(_0x1aeefa===void 0x0)_0x6af6c['unwatcher'](),_0x6af6c['currentOutputSnapshotRaw']=null,_0x6af6c['currentOutputSnapshotResolved']=null,_0x6af6c['onComplete']&&_0x6af6c['onComplete'](null,!0x1,_0x6af6c['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1aeefa,_0x6af6c['path']),_0x6af6c['status']=0x0;const _0x5f0d78=Un(_0x56960d['transactionQueueTree_'],_0x14c776),_0x510c3a=Ge(_0x5f0d78)||[];_0x510c3a['push'](_0x6af6c),fs(_0x5f0d78,_0x510c3a);let _0xe95d62;typeof _0x1aeefa=='object'&&_0x1aeefa!==null&&Y(_0x1aeefa,'.priority')?(_0xe95d62=Oe(_0x1aeefa,'.priority'),f(Cn(_0xe95d62),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xe95d62=(xn(_0x56960d['serverSyncTree_'],_0x14c776)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x351187=jt(_0x56960d),_0x2ffe7b=N(_0x1aeefa,_0xe95d62),_0x495ff8=hs(_0x2ffe7b,_0x1acc9e,_0x351187);_0x6af6c['currentOutputSnapshotRaw']=_0x2ffe7b,_0x6af6c['currentOutputSnapshotResolved']=_0x495ff8,_0x6af6c['currentWriteId']=Vn(_0x56960d);const _0xec9525=ss(_0x56960d['serverSyncTree_'],_0x14c776,_0x495ff8,_0x6af6c['currentWriteId'],_0x6af6c['applyLocally']);V(_0x56960d['eventQueue_'],_0x14c776,_0xec9525),Hn(_0x56960d,_0x56960d['transactionQueueTree_']);}}function ys(_0x28c3d2,_0x55a656,_0x2e7587){return xn(_0x28c3d2['serverSyncTree_'],_0x55a656,_0x2e7587)||g['EMPTY_NODE'];}function Hn(_0x2d5943,_0x524705=_0x2d5943['transactionQueueTree_']){if(_0x524705||$n(_0x2d5943,_0x524705),Ge(_0x524705)){const _0x511fa4=la(_0x2d5943,_0x524705);f(_0x511fa4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x511fa4['every'](_0x20ed40=>_0x20ed40['status']===0x0)&&Rd(_0x2d5943,Gt(_0x524705),_0x511fa4);}else ea(_0x524705)&&Wn(_0x524705,_0x475426=>{Hn(_0x2d5943,_0x475426);});}function Rd(_0x18b8c2,_0x31b5b5,_0x31a4be){const _0x2087f0=_0x31a4be['map'](_0x71824c=>_0x71824c['currentWriteId']),_0x7a95db=ys(_0x18b8c2,_0x31b5b5,_0x2087f0);let _0xc29c98=_0x7a95db;const _0x1ba39d=_0x7a95db['hash']();for(let _0x15da20=0x0;_0x15da20<_0x31a4be['length'];_0x15da20++){const _0x70a11d=_0x31a4be[_0x15da20];f(_0x70a11d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x70a11d['status']=0x1,_0x70a11d['retryCount']++;const _0x55154a=F(_0x31b5b5,_0x70a11d['path']);_0xc29c98=_0xc29c98['updateChild'](_0x55154a,_0x70a11d['currentOutputSnapshotRaw']);}const _0x354129=_0xc29c98['val'](!0x0),_0x514fdd=_0x31b5b5;_0x18b8c2['server_']['put'](_0x514fdd['toString'](),_0x354129,_0x13bb8c=>{ut(_0x18b8c2,'transaction\x20put\x20response',{'path':_0x514fdd['toString'](),'status':_0x13bb8c});let _0x304a78=[];if(_0x13bb8c==='ok'){const _0x336436=[];for(let _0xde32fa=0x0;_0xde32fa<_0x31a4be['length'];_0xde32fa++)_0x31a4be[_0xde32fa]['status']=0x2,_0x304a78=_0x304a78['concat'](pe(_0x18b8c2['serverSyncTree_'],_0x31a4be[_0xde32fa]['currentWriteId'])),_0x31a4be[_0xde32fa]['onComplete']&&_0x336436['push'](()=>_0x31a4be[_0xde32fa]['onComplete'](null,!0x0,_0x31a4be[_0xde32fa]['currentOutputSnapshotResolved'])),_0x31a4be[_0xde32fa]['unwatcher']();$n(_0x18b8c2,Un(_0x18b8c2['transactionQueueTree_'],_0x31b5b5)),Hn(_0x18b8c2,_0x18b8c2['transactionQueueTree_']),V(_0x18b8c2['eventQueue_'],_0x31b5b5,_0x304a78);for(let _0x3bfe29=0x0;_0x3bfe29<_0x336436['length'];_0x3bfe29++)lt(_0x336436[_0x3bfe29]);}else{if(_0x13bb8c==='datastale'){for(let _0x66433=0x0;_0x66433<_0x31a4be['length'];_0x66433++)_0x31a4be[_0x66433]['status']===0x3?_0x31a4be[_0x66433]['status']=0x4:_0x31a4be[_0x66433]['status']=0x0;}else{U('transaction\x20at\x20'+_0x514fdd['toString']()+'\x20failed:\x20'+_0x13bb8c);for(let _0x21ffb9=0x0;_0x21ffb9<_0x31a4be['length'];_0x21ffb9++)_0x31a4be[_0x21ffb9]['status']=0x4,_0x31a4be[_0x21ffb9]['abortReason']=_0x13bb8c;}st(_0x18b8c2,_0x31b5b5);}},_0x1ba39d);}function st(_0x4e8155,_0x133310){const _0x5446a6=ca(_0x4e8155,_0x133310),_0x5daaf9=Gt(_0x5446a6),_0x25e1e7=la(_0x4e8155,_0x5446a6);return Ad(_0x4e8155,_0x25e1e7,_0x5daaf9),_0x5daaf9;}function Ad(_0x558027,_0x11633d,_0x2ec9b1){if(_0x11633d['length']===0x0)return;const _0x31021a=[];let _0x524519=[];const _0x2011a5=_0x11633d['filter'](_0x2d3bf4=>_0x2d3bf4['status']===0x0)['map'](_0x3d7ac0=>_0x3d7ac0['currentWriteId']);for(let _0x4a9ef9=0x0;_0x4a9ef9<_0x11633d['length'];_0x4a9ef9++){const _0x454add=_0x11633d[_0x4a9ef9],_0x198185=F(_0x2ec9b1,_0x454add['path']);let _0x211781=!0x1,_0x5f23f9;if(f(_0x198185!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x454add['status']===0x4)_0x211781=!0x0,_0x5f23f9=_0x454add['abortReason'],_0x524519=_0x524519['concat'](pe(_0x558027['serverSyncTree_'],_0x454add['currentWriteId'],!0x0));else{if(_0x454add['status']===0x0){if(_0x454add['retryCount']>=_d)_0x211781=!0x0,_0x5f23f9='maxretry',_0x524519=_0x524519['concat'](pe(_0x558027['serverSyncTree_'],_0x454add['currentWriteId'],!0x0));else{const _0x23a0c6=ys(_0x558027,_0x454add['path'],_0x2011a5);_0x454add['currentInputSnapshot']=_0x23a0c6;const _0x3917e4=_0x11633d[_0x4a9ef9]['update'](_0x23a0c6['val']());if(_0x3917e4!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3917e4,_0x454add['path']);let _0x11db50=N(_0x3917e4);typeof _0x3917e4=='object'&&_0x3917e4!=null&&Y(_0x3917e4,'.priority')||(_0x11db50=_0x11db50['updatePriority'](_0x23a0c6['getPriority']()));const _0x2061d6=_0x454add['currentWriteId'],_0x5df70c=jt(_0x558027),_0x49e639=hs(_0x11db50,_0x23a0c6,_0x5df70c);_0x454add['currentOutputSnapshotRaw']=_0x11db50,_0x454add['currentOutputSnapshotResolved']=_0x49e639,_0x454add['currentWriteId']=Vn(_0x558027),_0x2011a5['splice'](_0x2011a5['indexOf'](_0x2061d6),0x1),_0x524519=_0x524519['concat'](ss(_0x558027['serverSyncTree_'],_0x454add['path'],_0x49e639,_0x454add['currentWriteId'],_0x454add['applyLocally'])),_0x524519=_0x524519['concat'](pe(_0x558027['serverSyncTree_'],_0x2061d6,!0x0));}else _0x211781=!0x0,_0x5f23f9='nodata',_0x524519=_0x524519['concat'](pe(_0x558027['serverSyncTree_'],_0x454add['currentWriteId'],!0x0));}}}V(_0x558027['eventQueue_'],_0x2ec9b1,_0x524519),_0x524519=[],_0x211781&&(_0x11633d[_0x4a9ef9]['status']=0x2,function(_0xdbd44f){setTimeout(_0xdbd44f,Math['floor'](0x0));}(_0x11633d[_0x4a9ef9]['unwatcher']),_0x11633d[_0x4a9ef9]['onComplete']&&(_0x5f23f9==='nodata'?_0x31021a['push'](()=>_0x11633d[_0x4a9ef9]['onComplete'](null,!0x1,_0x11633d[_0x4a9ef9]['currentInputSnapshot'])):_0x31021a['push'](()=>_0x11633d[_0x4a9ef9]['onComplete'](new Error(_0x5f23f9),!0x1,null))));}$n(_0x558027,_0x558027['transactionQueueTree_']);for(let _0x4bec14=0x0;_0x4bec14<_0x31021a['length'];_0x4bec14++)lt(_0x31021a[_0x4bec14]);Hn(_0x558027,_0x558027['transactionQueueTree_']);}function ca(_0x1f11fb,_0x203728){let _0x43c61f,_0x10065a=_0x1f11fb['transactionQueueTree_'];for(_0x43c61f=y(_0x203728);_0x43c61f!==null&&Ge(_0x10065a)===void 0x0;)_0x10065a=Un(_0x10065a,_0x43c61f),_0x203728=b(_0x203728),_0x43c61f=y(_0x203728);return _0x10065a;}function la(_0x1e6134,_0x14384c){const _0x48a47d=[];return ha(_0x1e6134,_0x14384c,_0x48a47d),_0x48a47d['sort']((_0xac0f3f,_0x3368c1)=>_0xac0f3f['order']-_0x3368c1['order']),_0x48a47d;}function ha(_0x20f060,_0xd0d4b1,_0x5d9512){const _0x2ada60=Ge(_0xd0d4b1);if(_0x2ada60){for(let _0x30eaf0=0x0;_0x30eaf0<_0x2ada60['length'];_0x30eaf0++)_0x5d9512['push'](_0x2ada60[_0x30eaf0]);}Wn(_0xd0d4b1,_0x3d1f87=>{ha(_0x20f060,_0x3d1f87,_0x5d9512);});}function $n(_0x8c361e,_0x10b96b){const _0x3081d8=Ge(_0x10b96b);if(_0x3081d8){let _0x18752f=0x0;for(let _0x1af7d0=0x0;_0x1af7d0<_0x3081d8['length'];_0x1af7d0++)_0x3081d8[_0x1af7d0]['status']!==0x2&&(_0x3081d8[_0x18752f]=_0x3081d8[_0x1af7d0],_0x18752f++);_0x3081d8['length']=_0x18752f,fs(_0x10b96b,_0x3081d8['length']>0x0?_0x3081d8:void 0x0);}Wn(_0x10b96b,_0x589a90=>{$n(_0x8c361e,_0x589a90);});}function vs(_0x5ada88,_0x3843d7){const _0x430553=Gt(ca(_0x5ada88,_0x3843d7)),_0x246a8c=Un(_0x5ada88['transactionQueueTree_'],_0x3843d7);return sd(_0x246a8c,_0x4130d3=>{ai(_0x5ada88,_0x4130d3);}),ai(_0x5ada88,_0x246a8c),ta(_0x246a8c,_0x17c7c6=>{ai(_0x5ada88,_0x17c7c6);}),_0x430553;}function ai(_0x2a55a5,_0xa71e2c){const _0x5acded=Ge(_0xa71e2c);if(_0x5acded){const _0x944e9c=[];let _0x54c75b=[],_0x252a71=-0x1;for(let _0x58e58=0x0;_0x58e58<_0x5acded['length'];_0x58e58++)_0x5acded[_0x58e58]['status']===0x3||(_0x5acded[_0x58e58]['status']===0x1?(f(_0x252a71===_0x58e58-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x252a71=_0x58e58,_0x5acded[_0x58e58]['status']=0x3,_0x5acded[_0x58e58]['abortReason']='set'):(f(_0x5acded[_0x58e58]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5acded[_0x58e58]['unwatcher'](),_0x54c75b=_0x54c75b['concat'](pe(_0x2a55a5['serverSyncTree_'],_0x5acded[_0x58e58]['currentWriteId'],!0x0)),_0x5acded[_0x58e58]['onComplete']&&_0x944e9c['push'](_0x5acded[_0x58e58]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x252a71===-0x1?fs(_0xa71e2c,void 0x0):_0x5acded['length']=_0x252a71+0x1,V(_0x2a55a5['eventQueue_'],Gt(_0xa71e2c),_0x54c75b);for(let _0x11269e=0x0;_0x11269e<_0x944e9c['length'];_0x11269e++)lt(_0x944e9c[_0x11269e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x14e9eb){let _0x2bd3c0='';const _0x2bf1e0=_0x14e9eb['split']('/');for(let _0x384a34=0x0;_0x384a34<_0x2bf1e0['length'];_0x384a34++)if(_0x2bf1e0[_0x384a34]['length']>0x0){let _0x1c55db=_0x2bf1e0[_0x384a34];try{_0x1c55db=decodeURIComponent(_0x1c55db['replace'](/\+/g,'\x20'));}catch{}_0x2bd3c0+='/'+_0x1c55db;}return _0x2bd3c0;}function Nd(_0x5c51e0){const _0x8e9acb={};_0x5c51e0['charAt'](0x0)==='?'&&(_0x5c51e0=_0x5c51e0['substring'](0x1));for(const _0x53873e of _0x5c51e0['split']('&')){if(_0x53873e['length']===0x0)continue;const _0xf8d824=_0x53873e['split']('=');_0xf8d824['length']===0x2?_0x8e9acb[decodeURIComponent(_0xf8d824[0x0])]=decodeURIComponent(_0xf8d824[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x53873e+'\x27\x20in\x20query\x20\x27'+_0x5c51e0+'\x27');}return _0x8e9acb;}const gr=function(_0x1adf2e,_0x4700b5){const _0x100167=Pd(_0x1adf2e),_0xa82170=_0x100167['namespace'];_0x100167['domain']==='firebase.com'&&oe(_0x100167['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xa82170||_0xa82170==='undefined')&&_0x100167['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x100167['secure']||Bl();const _0x3b581f=_0x100167['scheme']==='ws'||_0x100167['scheme']==='wss';return{'repoInfo':new _o(_0x100167['host'],_0x100167['secure'],_0xa82170,_0x3b581f,_0x4700b5,'',_0xa82170!==_0x100167['subdomain']),'path':new C(_0x100167['pathString'])};},Pd=function(_0x1b1c39){let _0x580c4f='',_0x18cfe6='',_0x1c823c='',_0x7b0d2d='',_0x1251f0='',_0x1f3d4f=!0x0,_0x37d576='https',_0x269a96=0x1bb;if(typeof _0x1b1c39=='string'){let _0x4b27df=_0x1b1c39['indexOf']('//');_0x4b27df>=0x0&&(_0x37d576=_0x1b1c39['substring'](0x0,_0x4b27df-0x1),_0x1b1c39=_0x1b1c39['substring'](_0x4b27df+0x2));let _0x34e9c6=_0x1b1c39['indexOf']('/');_0x34e9c6===-0x1&&(_0x34e9c6=_0x1b1c39['length']);let _0x380995=_0x1b1c39['indexOf']('?');_0x380995===-0x1&&(_0x380995=_0x1b1c39['length']),_0x580c4f=_0x1b1c39['substring'](0x0,Math['min'](_0x34e9c6,_0x380995)),_0x34e9c6<_0x380995&&(_0x7b0d2d=kd(_0x1b1c39['substring'](_0x34e9c6,_0x380995)));const _0x335a36=Nd(_0x1b1c39['substring'](Math['min'](_0x1b1c39['length'],_0x380995)));_0x4b27df=_0x580c4f['indexOf'](':'),_0x4b27df>=0x0?(_0x1f3d4f=_0x37d576==='https'||_0x37d576==='wss',_0x269a96=parseInt(_0x580c4f['substring'](_0x4b27df+0x1),0xa)):_0x4b27df=_0x580c4f['length'];const _0x11e75b=_0x580c4f['slice'](0x0,_0x4b27df);if(_0x11e75b['toLowerCase']()==='localhost')_0x18cfe6='localhost';else{if(_0x11e75b['split']('.')['length']<=0x2)_0x18cfe6=_0x11e75b;else{const _0xd386d8=_0x580c4f['indexOf']('.');_0x1c823c=_0x580c4f['substring'](0x0,_0xd386d8)['toLowerCase'](),_0x18cfe6=_0x580c4f['substring'](_0xd386d8+0x1),_0x1251f0=_0x1c823c;}}'ns'in _0x335a36&&(_0x1251f0=_0x335a36['ns']);}return{'host':_0x580c4f,'port':_0x269a96,'domain':_0x18cfe6,'subdomain':_0x1c823c,'secure':_0x1f3d4f,'scheme':_0x37d576,'pathString':_0x7b0d2d,'namespace':_0x1251f0};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x45b64f=0x0;const _0x2e4553=[];return function(_0x284c12){const _0x59c364=_0x284c12===_0x45b64f;_0x45b64f=_0x284c12;let _0x2add9e;const _0x224e17=new Array(0x8);for(_0x2add9e=0x7;_0x2add9e>=0x0;_0x2add9e--)_0x224e17[_0x2add9e]=mr['charAt'](_0x284c12%0x40),_0x284c12=Math['floor'](_0x284c12/0x40);f(_0x284c12===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x12a061=_0x224e17['join']('');if(_0x59c364){for(_0x2add9e=0xb;_0x2add9e>=0x0&&_0x2e4553[_0x2add9e]===0x3f;_0x2add9e--)_0x2e4553[_0x2add9e]=0x0;_0x2e4553[_0x2add9e]++;}else{for(_0x2add9e=0x0;_0x2add9e<0xc;_0x2add9e++)_0x2e4553[_0x2add9e]=Math['floor'](Math['random']()*0x40);}for(_0x2add9e=0x0;_0x2add9e<0xc;_0x2add9e++)_0x12a061+=mr['charAt'](_0x2e4553[_0x2add9e]);return f(_0x12a061['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x12a061;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x464f06,_0x1c2c4e,_0x4ac910,_0x534035){this['eventType']=_0x464f06,this['eventRegistration']=_0x1c2c4e,this['snapshot']=_0x4ac910,this['prevName']=_0x534035;}['getPath'](){const _0x2d0f21=this['snapshot']['ref'];return this['eventType']==='value'?_0x2d0f21['_path']:_0x2d0f21['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3d992e,_0x2563ce,_0x2b75d8){this['eventRegistration']=_0x3d992e,this['error']=_0x2563ce,this['path']=_0x2b75d8;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x932e9b,_0x52d73b){this['snapshotCallback']=_0x932e9b,this['cancelCallback']=_0x52d73b;}['onValue'](_0x1229f3,_0x2f971d){this['snapshotCallback']['call'](null,_0x1229f3,_0x2f971d);}['onCancel'](_0x498aa9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x498aa9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4fc979){return this['snapshotCallback']===_0x4fc979['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4fc979['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4fc979['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4c97a1,_0x3b9315,_0x292482,_0x5d1493){this['_repo']=_0x4c97a1,this['_path']=_0x3b9315,this['_queryParams']=_0x292482,this['_orderByCalled']=_0x5d1493;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x527471=nr(this['_queryParams']),_0x25a631=Bi(_0x527471);return _0x25a631==='{}'?'default':_0x25a631;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x59e6f3){if(_0x59e6f3=k(_0x59e6f3),!(_0x59e6f3 instanceof be))return!0x1;const _0x1dfed6=this['_repo']===_0x59e6f3['_repo'],_0x44660c=qi(this['_path'],_0x59e6f3['_path']),_0x3a90df=this['_queryIdentifier']===_0x59e6f3['_queryIdentifier'];return _0x1dfed6&&_0x44660c&&_0x3a90df;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x1ca428,_0x1857ea){if(_0x1ca428['_orderByCalled']===!0x0)throw new Error(_0x1857ea+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x59173e){let _0x180d27=null,_0x523749=null;if(_0x59173e['hasStart']()&&(_0x180d27=_0x59173e['getIndexStartValue']()),_0x59173e['hasEnd']()&&(_0x523749=_0x59173e['getIndexEndValue']()),_0x59173e['getIndex']()===ye){const _0x1c827a='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xfeb5f7='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x59173e['hasStart']()){if(_0x59173e['getIndexStartName']()!==xe)throw new Error(_0x1c827a);if(typeof _0x180d27!='string')throw new Error(_0xfeb5f7);}if(_0x59173e['hasEnd']()){if(_0x59173e['getIndexEndName']()!==Ie)throw new Error(_0x1c827a);if(typeof _0x523749!='string')throw new Error(_0xfeb5f7);}}else{if(_0x59173e['getIndex']()===R){if(_0x180d27!=null&&!Cn(_0x180d27)||_0x523749!=null&&!Cn(_0x523749))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x59173e['getIndex']()instanceof Ki||_0x59173e['getIndex']()===Po,'unknown\x20index\x20type.'),_0x180d27!=null&&typeof _0x180d27=='object'||_0x523749!=null&&typeof _0x523749=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x1e4dbd){if(_0x1e4dbd['hasStart']()&&_0x1e4dbd['hasEnd']()&&_0x1e4dbd['hasLimit']()&&!_0x1e4dbd['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0xaf55b8,_0x504dfc){super(_0xaf55b8,_0x504dfc,new Qi(),!0x1);}get['parent'](){const _0xd47d13=To(this['_path']);return _0xd47d13===null?null:new Z(this['_repo'],_0xd47d13);}get['root'](){let _0xab1cc4=this;for(;_0xab1cc4['parent']!==null;)_0xab1cc4=_0xab1cc4['parent'];return _0xab1cc4;}}class rt{constructor(_0x113e2c,_0x349579,_0x210de9){this['_node']=_0x113e2c,this['ref']=_0x349579,this['_index']=_0x210de9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5f543f){const _0x12b4d5=new C(_0x5f543f),_0x439ada=Lt(this['ref'],_0x5f543f);return new rt(this['_node']['getChild'](_0x12b4d5),_0x439ada,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x382d78){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4089bf,_0x2ea3bf)=>_0x382d78(new rt(_0x2ea3bf,Lt(this['ref'],_0x4089bf),R)));}['hasChild'](_0x28372a){const _0x205b09=new C(_0x28372a);return!this['_node']['getChild'](_0x205b09)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x6e30ee,_0x21126a){return _0x6e30ee=k(_0x6e30ee),_0x6e30ee['_checkNotDeleted']('ref'),_0x21126a!==void 0x0?Lt(_0x6e30ee['_root'],_0x21126a):_0x6e30ee['_root'];}function Lt(_0x15a948,_0x1ea7a6){return _0x15a948=k(_0x15a948),y(_0x15a948['_path'])===null?ud('child','path',_0x1ea7a6):_s('child','path',_0x1ea7a6),new Z(_0x15a948['_repo'],A(_0x15a948['_path'],_0x1ea7a6));}function d_(_0x441822,_0x4b55bb){_0x441822=k(_0x441822),gs('push',_0x441822['_path']),qt('push',_0x4b55bb,_0x441822['_path'],!0x0);const _0x54cd88=oa(_0x441822['_repo']),_0x430c39=Od(_0x54cd88),_0x7681cd=Lt(_0x441822,_0x430c39),_0x29f244=Lt(_0x441822,_0x430c39);let _0xb883a4;return _0x4b55bb!=null?_0xb883a4=Ld(_0x29f244,_0x4b55bb)['then'](()=>_0x29f244):_0xb883a4=Promise['resolve'](_0x29f244),_0x7681cd['then']=_0xb883a4['then']['bind'](_0xb883a4),_0x7681cd['catch']=_0xb883a4['then']['bind'](_0xb883a4,void 0x0),_0x7681cd;}function Ld(_0x4df15b,_0x143a7d){_0x4df15b=k(_0x4df15b),gs('set',_0x4df15b['_path']),qt('set',_0x143a7d,_0x4df15b['_path'],!0x1);const _0x4858a0=new Ve();return Ed(_0x4df15b['_repo'],_0x4df15b['_path'],_0x143a7d,null,_0x4858a0['wrapCallback'](()=>{})),_0x4858a0['promise'];}function f_(_0x597fea,_0x3e4d1a){hd('update',_0x3e4d1a,_0x597fea['_path']);const _0x313262=new Ve();return Id(_0x597fea['_repo'],_0x597fea['_path'],_0x3e4d1a,_0x313262['wrapCallback'](()=>{})),_0x313262['promise'];}function p_(_0x50e3a7){_0x50e3a7=k(_0x50e3a7);const _0x466703=new ua(()=>{}),_0x263f2e=new qn(_0x466703);return vd(_0x50e3a7['_repo'],_0x50e3a7,_0x263f2e)['then'](_0x4446c6=>new rt(_0x4446c6,new Z(_0x50e3a7['_repo'],_0x50e3a7['_path']),_0x50e3a7['_queryParams']['getIndex']()));}class qn{constructor(_0x381e6c){this['callbackContext']=_0x381e6c;}['respondsTo'](_0x876eb8){return _0x876eb8==='value';}['createEvent'](_0x33f1db,_0x5ad77b){const _0x1c95e8=_0x5ad77b['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x33f1db['snapshotNode'],new Z(_0x5ad77b['_repo'],_0x5ad77b['_path']),_0x1c95e8));}['getEventRunner'](_0x3737d7){return _0x3737d7['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3737d7['error']):()=>this['callbackContext']['onValue'](_0x3737d7['snapshot'],null);}['createCancelEvent'](_0x446268,_0x186a11){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x446268,_0x186a11):null;}['matches'](_0x789103){return _0x789103 instanceof qn?!_0x789103['callbackContext']||!this['callbackContext']?!0x0:_0x789103['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x1e38d0,_0xa7d2e4,_0x1305ee,_0x539002,_0x1b4de8){const _0x554879=new ua(_0x1305ee,void 0x0),_0x8092de=new qn(_0x554879);return Cd(_0x1e38d0['_repo'],_0x1e38d0,_0x8092de),()=>Td(_0x1e38d0['_repo'],_0x1e38d0,_0x8092de);}function Fd(_0x6f9218,_0x2e72dc,_0x2cb9c9,_0x1ee90b){return xd(_0x6f9218,'value',_0x2e72dc);}class dt{}class pa extends dt{constructor(_0xa5cb18,_0x5765c7){super(),this['_value']=_0xa5cb18,this['_key']=_0x5765c7,this['type']='endAt';}['_apply'](_0x58aa36){qt('endAt',this['_value'],_0x58aa36['_path'],!0x0);const _0x58fcf8=Kh(_0x58aa36['_queryParams'],this['_value'],this['_key']);if(fa(_0x58fcf8),Gn(_0x58fcf8),_0x58aa36['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x58aa36['_repo'],_0x58aa36['_path'],_0x58fcf8,_0x58aa36['_orderByCalled']);}}function __(_0x21fa4a,_0x5cc12d){return new pa(_0x21fa4a,_0x5cc12d);}class _a extends dt{constructor(_0x4b375f,_0x2e5f74){super(),this['_value']=_0x4b375f,this['_key']=_0x2e5f74,this['type']='startAt';}['_apply'](_0x55d5af){qt('startAt',this['_value'],_0x55d5af['_path'],!0x0);const _0x3bda=jh(_0x55d5af['_queryParams'],this['_value'],this['_key']);if(fa(_0x3bda),Gn(_0x3bda),_0x55d5af['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x55d5af['_repo'],_0x55d5af['_path'],_0x3bda,_0x55d5af['_orderByCalled']);}}function g_(_0x1cf706=null,_0x1df59f){return new _a(_0x1cf706,_0x1df59f);}class Ud extends dt{constructor(_0x2e213c){super(),this['_limit']=_0x2e213c,this['type']='limitToFirst';}['_apply'](_0x1b285c){if(_0x1b285c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1b285c['_repo'],_0x1b285c['_path'],zh(_0x1b285c['_queryParams'],this['_limit']),_0x1b285c['_orderByCalled']);}}function m_(_0x281a01){if(Math['floor'](_0x281a01)!==_0x281a01||_0x281a01<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x281a01);}class Wd extends dt{constructor(_0x3dbbbe){super(),this['_path']=_0x3dbbbe,this['type']='orderByChild';}['_apply'](_0x1255d2){da(_0x1255d2,'orderByChild');const _0x355079=new C(this['_path']);if(v(_0x355079))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x414839=new Ki(_0x355079),_0x4287c9=Do(_0x1255d2['_queryParams'],_0x414839);return Gn(_0x4287c9),new be(_0x1255d2['_repo'],_0x1255d2['_path'],_0x4287c9,!0x0);}}function y_(_0x217d31){if(_0x217d31==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x217d31==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x217d31==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x217d31),new Wd(_0x217d31);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3ca5a6){da(_0x3ca5a6,'orderByKey');const _0x160765=Do(_0x3ca5a6['_queryParams'],ye);return Gn(_0x160765),new be(_0x3ca5a6['_repo'],_0x3ca5a6['_path'],_0x160765,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x2890c2,_0x3a4d93){super(),this['_value']=_0x2890c2,this['_key']=_0x3a4d93,this['type']='equalTo';}['_apply'](_0x4940e4){if(qt('equalTo',this['_value'],_0x4940e4['_path'],!0x1),_0x4940e4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4940e4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x4940e4));}}function E_(_0x4b54ad,_0x2af390){return new Vd(_0x4b54ad,_0x2af390);}function I_(_0x34b836,..._0x2c289a){let _0x4bce84=k(_0x34b836);for(const _0x2ccd2b of _0x2c289a)_0x4bce84=_0x2ccd2b['_apply'](_0x4bce84);return _0x4bce84;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x1171a6,_0x4add92,_0x53694d,_0x4dd973){const _0x1621e0=_0x4add92['lastIndexOf'](':'),_0x4c2858=_0x4add92['substring'](0x0,_0x1621e0),_0x4b23e3=Wt(_0x4c2858);_0x1171a6['repoInfo_']=new _o(_0x4add92,_0x4b23e3,_0x1171a6['repoInfo_']['namespace'],_0x1171a6['repoInfo_']['webSocketOnly'],_0x1171a6['repoInfo_']['nodeAdmin'],_0x1171a6['repoInfo_']['persistenceKey'],_0x1171a6['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x53694d),_0x4dd973&&(_0x1171a6['authTokenProvider_']=_0x4dd973);}function qd(_0x53432f,_0xf49879,_0x30468f,_0x27ae69,_0xe062fe){let _0xd4e69e=_0x27ae69||_0x53432f['options']['databaseURL'];_0xd4e69e===void 0x0&&(_0x53432f['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x53432f['options']['projectId']),_0xd4e69e=_0x53432f['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4ebdae=gr(_0xd4e69e,_0xe062fe),_0x3fe73b=_0x4ebdae['repoInfo'],_0x4a81ef;typeof process<'u'&&Us&&(_0x4a81ef=Us[Hd]),_0x4a81ef?(_0xd4e69e='http://'+_0x4a81ef+'?ns='+_0x3fe73b['namespace'],_0x4ebdae=gr(_0xd4e69e,_0xe062fe),_0x3fe73b=_0x4ebdae['repoInfo']):_0x4ebdae['repoInfo']['secure'];const _0xf05e50=new Jl(_0x53432f['name'],_0x53432f['options'],_0xf49879);dd('Invalid\x20Firebase\x20Database\x20URL',_0x4ebdae),v(_0x4ebdae['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2852c0=jd(_0x3fe73b,_0x53432f,_0xf05e50,new Ql(_0x53432f,_0x30468f));return new Kd(_0x2852c0,_0x53432f);}function zd(_0x314f31,_0x2ac396){const _0x1dd8cb=ki[_0x2ac396];(!_0x1dd8cb||_0x1dd8cb[_0x314f31['key']]!==_0x314f31)&&oe('Database\x20'+_0x2ac396+'('+_0x314f31['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x314f31),delete _0x1dd8cb[_0x314f31['key']];}function jd(_0x423b38,_0x438634,_0x27d146,_0x5b6049){let _0x224983=ki[_0x438634['name']];_0x224983||(_0x224983={},ki[_0x438634['name']]=_0x224983);let _0x1a57ee=_0x224983[_0x423b38['toURLString']()];return _0x1a57ee&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1a57ee=new gd(_0x423b38,$d,_0x27d146,_0x5b6049),_0x224983[_0x423b38['toURLString']()]=_0x1a57ee,_0x1a57ee;}class Kd{constructor(_0xeb601,_0x182d2e){this['_repoInternal']=_0xeb601,this['app']=_0x182d2e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5ebdf4){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5ebdf4+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x3c5aa1=Qr(),_0x14a6de){const _0x53cfb5=Ui(_0x3c5aa1,'database')['getImmediate']({'identifier':_0x14a6de});if(!_0x53cfb5['_instanceStarted']){const _0x3933d2=ac('database');_0x3933d2&&Yd(_0x53cfb5,..._0x3933d2);}return _0x53cfb5;}function Yd(_0x29cb94,_0x3cfdb6,_0x437fcf,_0x51cf02={}){_0x29cb94=k(_0x29cb94),_0x29cb94['_checkNotDeleted']('useEmulator');const _0x35e2d2=_0x3cfdb6+':'+_0x437fcf,_0x2ef0f5=_0x29cb94['_repoInternal'];if(_0x29cb94['_instanceStarted']){if(_0x35e2d2===_0x29cb94['_repoInternal']['repoInfo_']['host']&&De(_0x51cf02,_0x2ef0f5['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x248a61;if(_0x2ef0f5['repoInfo_']['nodeAdmin'])_0x51cf02['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x248a61=new tn(tn['OWNER']);else{if(_0x51cf02['mockUserToken']){const _0x1ce191=typeof _0x51cf02['mockUserToken']=='string'?_0x51cf02['mockUserToken']:cc(_0x51cf02['mockUserToken'],_0x29cb94['app']['options']['projectId']);_0x248a61=new tn(_0x1ce191);}}Wt(_0x3cfdb6)&&jr(_0x3cfdb6),Gd(_0x2ef0f5,_0x35e2d2,_0x51cf02,_0x248a61);}function C_(_0x1e53c1){_0x1e53c1=k(_0x1e53c1),_0x1e53c1['_checkNotDeleted']('goOffline'),aa(_0x1e53c1['_repo']);}function T_(_0x1e6fbc){_0x1e6fbc=k(_0x1e6fbc),_0x1e6fbc['_checkNotDeleted']('goOnline'),Sd(_0x1e6fbc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x1741cf){Ll(ct),et(new Me('database',(_0x3cc7e7,{instanceIdentifier:_0x32e31f})=>{const _0x27e6e0=_0x3cc7e7['getProvider']('app')['getImmediate'](),_0x12b0d6=_0x3cc7e7['getProvider']('auth-internal'),_0x373e6f=_0x3cc7e7['getProvider']('app-check-internal');return qd(_0x27e6e0,_0x12b0d6,_0x373e6f,_0x32e31f);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x1741cf),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1d969b,_0x3629b5){this['committed']=_0x1d969b,this['snapshot']=_0x3629b5;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x30bb6a,_0x57757e,_0x2bca83){if(_0x30bb6a=k(_0x30bb6a),gs('Reference.transaction',_0x30bb6a['_path']),_0x30bb6a['key']==='.length'||_0x30bb6a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x30bb6a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x381a52=!0x0,_0x7dbba5=new Ve(),_0x1cf4b5=(_0x334964,_0x2db214,_0x17a7dd)=>{let _0x1443f8=null;_0x334964?_0x7dbba5['reject'](_0x334964):(_0x1443f8=new rt(_0x17a7dd,new Z(_0x30bb6a['_repo'],_0x30bb6a['_path']),R),_0x7dbba5['resolve'](new Xd(_0x2db214,_0x1443f8)));},_0x521d76=Fd(_0x30bb6a,()=>{});return bd(_0x30bb6a['_repo'],_0x30bb6a['_path'],_0x57757e,_0x1cf4b5,_0x521d76,_0x381a52),_0x7dbba5['promise'];}ie['prototype']['simpleListen']=function(_0xca0947,_0x4471e7){this['sendRequest']('q',{'p':_0xca0947},_0x4471e7);},ie['prototype']['echo']=function(_0x3bd9ad,_0xb85fa3){this['sendRequest']('echo',{'d':_0x3bd9ad},_0xb85fa3);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x4e11a8,..._0x145ec9){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x4e11a8,..._0x145ec9);}function nn(_0x1db711,..._0x703eda){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x1db711,..._0x703eda);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x339ca1,..._0x1db5f9){throw Es(_0x339ca1,..._0x1db5f9);}function J(_0x1ec43a,..._0x1f911d){return Es(_0x1ec43a,..._0x1f911d);}function ya(_0x2c8faa,_0x436383,_0x1dd717){const _0x5625dd={...Zd(),[_0x436383]:_0x1dd717};return new Ut('auth','Firebase',_0x5625dd)['create'](_0x436383,{'appName':_0x2c8faa['name']});}function se(_0x56d106){return ya(_0x56d106,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x42a5d8,..._0x75631){if(typeof _0x42a5d8!='string'){const _0x126038=_0x75631[0x0],_0x10ca95=[..._0x75631['slice'](0x1)];return _0x10ca95[0x0]&&(_0x10ca95[0x0]['appName']=_0x42a5d8['name']),_0x42a5d8['_errorFactory']['create'](_0x126038,..._0x10ca95);}return ma['create'](_0x42a5d8,..._0x75631);}function m(_0x220e8a,_0x385a94,..._0x1ba7fd){if(!_0x220e8a)throw Es(_0x385a94,..._0x1ba7fd);}function te(_0x41724f){const _0x8cd78e='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x41724f;throw nn(_0x8cd78e),new Error(_0x8cd78e);}function ae(_0x247d19,_0x1561e3){_0x247d19||te(_0x1561e3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x368ffe;return typeof self<'u'&&((_0x368ffe=self['location'])==null?void 0x0:_0x368ffe['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x59c237;return typeof self<'u'&&((_0x59c237=self['location'])==null?void 0x0:_0x59c237['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0xe7e94a=navigator;return _0xe7e94a['languages']&&_0xe7e94a['languages'][0x0]||_0xe7e94a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x46d50e,_0x321b8d){this['shortDelay']=_0x46d50e,this['longDelay']=_0x321b8d,ae(_0x321b8d>_0x46d50e,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1644dc,_0x32a1c4){ae(_0x1644dc['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x16d665}=_0x1644dc['emulator'];return _0x32a1c4?''+_0x16d665+(_0x32a1c4['startsWith']('/')?_0x32a1c4['slice'](0x1):_0x32a1c4):_0x16d665;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x3e9bd2,_0x1c9a84,_0x3e97f0){this['fetchImpl']=_0x3e9bd2,_0x1c9a84&&(this['headersImpl']=_0x1c9a84),_0x3e97f0&&(this['responseImpl']=_0x3e97f0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0xcc53f5,_0x569794){return _0xcc53f5['tenantId']&&!_0x569794['tenantId']?{..._0x569794,'tenantId':_0xcc53f5['tenantId']}:_0x569794;}async function Ae(_0x16b802,_0x3e8d82,_0x3cee4f,_0x4f4590,_0xbd64f1={}){return Ea(_0x16b802,_0xbd64f1,async()=>{let _0x2a2ff5={},_0x116fb1={};_0x4f4590&&(_0x3e8d82==='GET'?_0x116fb1=_0x4f4590:_0x2a2ff5={'body':JSON['stringify'](_0x4f4590)});const _0x13d872=at({..._0x116fb1,'key':_0x16b802['config']['apiKey']})['slice'](0x1),_0x5df746=await _0x16b802['_getAdditionalHeaders']();_0x5df746['Content-Type']='application/json',_0x16b802['languageCode']&&(_0x5df746['X-Firebase-Locale']=_0x16b802['languageCode']);const _0x16a50a={'method':_0x3e8d82,'headers':_0x5df746,..._0x2a2ff5};return lc()||(_0x16a50a['referrerPolicy']='strict-origin-when-cross-origin'),_0x16b802['emulatorConfig']&&Wt(_0x16b802['emulatorConfig']['host'])&&(_0x16a50a['credentials']='include'),va['fetch']()(await Ia(_0x16b802,_0x16b802['config']['apiHost'],_0x3cee4f,_0x13d872),_0x16a50a);});}async function Ea(_0x1bdc1f,_0x18e063,_0xf11449){_0x1bdc1f['_canInitEmulator']=!0x1;const _0x19f60e={...rf,..._0x18e063};try{const _0x57a35f=new lf(_0x1bdc1f),_0x5bf99c=await Promise['race']([_0xf11449(),_0x57a35f['promise']]);_0x57a35f['clearNetworkTimeout']();const _0x1c83ed=await _0x5bf99c['json']();if('needConfirmation'in _0x1c83ed)throw en(_0x1bdc1f,'account-exists-with-different-credential',_0x1c83ed);if(_0x5bf99c['ok']&&!('errorMessage'in _0x1c83ed))return _0x1c83ed;{const _0xe7b4eb=_0x5bf99c['ok']?_0x1c83ed['errorMessage']:_0x1c83ed['error']['message'],[_0xf3e105,_0x1d73a5]=_0xe7b4eb['split']('\x20:\x20');if(_0xf3e105==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1bdc1f,'credential-already-in-use',_0x1c83ed);if(_0xf3e105==='EMAIL_EXISTS')throw en(_0x1bdc1f,'email-already-in-use',_0x1c83ed);if(_0xf3e105==='USER_DISABLED')throw en(_0x1bdc1f,'user-disabled',_0x1c83ed);const _0x4306f8=_0x19f60e[_0xf3e105]||_0xf3e105['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1d73a5)throw ya(_0x1bdc1f,_0x4306f8,_0x1d73a5);K(_0x1bdc1f,_0x4306f8);}}catch(_0x2dd12d){if(_0x2dd12d instanceof Se)throw _0x2dd12d;K(_0x1bdc1f,'network-request-failed',{'message':String(_0x2dd12d)});}}async function Yt(_0x4b831f,_0x22e9c0,_0xf19104,_0x4e4ef9,_0x33c759={}){const _0x40b51f=await Ae(_0x4b831f,_0x22e9c0,_0xf19104,_0x4e4ef9,_0x33c759);return'mfaPendingCredential'in _0x40b51f&&K(_0x4b831f,'multi-factor-auth-required',{'_serverResponse':_0x40b51f}),_0x40b51f;}async function Ia(_0xa2e197,_0x39d139,_0x1cde31,_0x20bef8){const _0x17dcf9=''+_0x39d139+_0x1cde31+'?'+_0x20bef8,_0x311291=_0xa2e197,_0x4cd325=_0x311291['config']['emulator']?Is(_0xa2e197['config'],_0x17dcf9):_0xa2e197['config']['apiScheme']+'://'+_0x17dcf9;return of['includes'](_0x1cde31)&&(await _0x311291['_persistenceManagerAvailable'],_0x311291['_getPersistenceType']()==='COOKIE')?_0x311291['_getPersistence']()['_getFinalTarget'](_0x4cd325)['toString']():_0x4cd325;}function cf(_0x9fe7b7){switch(_0x9fe7b7){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x200640){this['auth']=_0x200640,this['timer']=null,this['promise']=new Promise((_0x1628ea,_0x452033)=>{this['timer']=setTimeout(()=>_0x452033(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x5e67a1,_0x1e6371,_0x4b1b4c){const _0x31860a={'appName':_0x5e67a1['name']};_0x4b1b4c['email']&&(_0x31860a['email']=_0x4b1b4c['email']),_0x4b1b4c['phoneNumber']&&(_0x31860a['phoneNumber']=_0x4b1b4c['phoneNumber']);const _0x17eb9b=J(_0x5e67a1,_0x1e6371,_0x31860a);return _0x17eb9b['customData']['_tokenResponse']=_0x4b1b4c,_0x17eb9b;}function vr(_0x1f704d){return _0x1f704d!==void 0x0&&_0x1f704d['enterprise']!==void 0x0;}class hf{constructor(_0x39c1d4){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x39c1d4['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x39c1d4['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x39c1d4['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x594659){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4fcb2b of this['recaptchaEnforcementState'])if(_0x4fcb2b['provider']&&_0x4fcb2b['provider']===_0x594659)return cf(_0x4fcb2b['enforcementState']);return null;}['isProviderEnabled'](_0x3df721){return this['getProviderEnforcementState'](_0x3df721)==='ENFORCE'||this['getProviderEnforcementState'](_0x3df721)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0xbbe32c,_0x5176b9){return Ae(_0xbbe32c,'GET','/v2/recaptchaConfig',Re(_0xbbe32c,_0x5176b9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x53edb3,_0x54a9a1){return Ae(_0x53edb3,'POST','/v1/accounts:delete',_0x54a9a1);}async function Sn(_0x33f3f2,_0x524fe5){return Ae(_0x33f3f2,'POST','/v1/accounts:lookup',_0x524fe5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x354f49){if(_0x354f49)try{const _0x28988a=new Date(Number(_0x354f49));if(!isNaN(_0x28988a['getTime']()))return _0x28988a['toUTCString']();}catch{}}async function ff(_0x116ba8,_0x153de5=!0x1){const _0x386640=k(_0x116ba8),_0x30be27=await _0x386640['getIdToken'](_0x153de5),_0x9efa0d=ws(_0x30be27);m(_0x9efa0d&&_0x9efa0d['exp']&&_0x9efa0d['auth_time']&&_0x9efa0d['iat'],_0x386640['auth'],'internal-error');const _0x1d2173=typeof _0x9efa0d['firebase']=='object'?_0x9efa0d['firebase']:void 0x0,_0x50cb0d=_0x1d2173==null?void 0x0:_0x1d2173['sign_in_provider'];return{'claims':_0x9efa0d,'token':_0x30be27,'authTime':St(ci(_0x9efa0d['auth_time'])),'issuedAtTime':St(ci(_0x9efa0d['iat'])),'expirationTime':St(ci(_0x9efa0d['exp'])),'signInProvider':_0x50cb0d||null,'signInSecondFactor':(_0x1d2173==null?void 0x0:_0x1d2173['sign_in_second_factor'])||null};}function ci(_0x46a315){return Number(_0x46a315)*0x3e8;}function ws(_0x475b0f){const [_0x18bcae,_0x39f1c2,_0x1bfba4]=_0x475b0f['split']('.');if(_0x18bcae===void 0x0||_0x39f1c2===void 0x0||_0x1bfba4===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x49e142=cn(_0x39f1c2);return _0x49e142?JSON['parse'](_0x49e142):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3cdc9a){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3cdc9a==null?void 0x0:_0x3cdc9a['toString']()),null;}}function Er(_0x27fc74){const _0x172a3e=ws(_0x27fc74);return m(_0x172a3e,'internal-error'),m(typeof _0x172a3e['exp']<'u','internal-error'),m(typeof _0x172a3e['iat']<'u','internal-error'),Number(_0x172a3e['exp'])-Number(_0x172a3e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4bd763,_0x12dda5,_0x67ae13=!0x1){if(_0x67ae13)return _0x12dda5;try{return await _0x12dda5;}catch(_0x589093){throw _0x589093 instanceof Se&&pf(_0x589093)&&_0x4bd763['auth']['currentUser']===_0x4bd763&&await _0x4bd763['auth']['signOut'](),_0x589093;}}function pf({code:_0x90e2f0}){return _0x90e2f0==='auth/user-disabled'||_0x90e2f0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x42ea7e){this['user']=_0x42ea7e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x606fd7){if(_0x606fd7){const _0x37c54a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x37c54a;}else{this['errorBackoff']=0x7530;const _0xa85d9e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xa85d9e);}}['schedule'](_0x1ad931=!0x1){if(!this['isRunning'])return;const _0x1b6d8e=this['getInterval'](_0x1ad931);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1b6d8e);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1acdc1){(_0x1acdc1==null?void 0x0:_0x1acdc1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5d44d3,_0x4438d2){this['createdAt']=_0x5d44d3,this['lastLoginAt']=_0x4438d2,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4143cf){this['createdAt']=_0x4143cf['createdAt'],this['lastLoginAt']=_0x4143cf['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x54d6a2){var _0x5dd6ab;const _0x34d9d0=_0x54d6a2['auth'],_0x33ff71=await _0x54d6a2['getIdToken'](),_0x83e5=await xt(_0x54d6a2,Sn(_0x34d9d0,{'idToken':_0x33ff71}));m(_0x83e5==null?void 0x0:_0x83e5['users']['length'],_0x34d9d0,'internal-error');const _0x59139a=_0x83e5['users'][0x0];_0x54d6a2['_notifyReloadListener'](_0x59139a);const _0x2181c5=(_0x5dd6ab=_0x59139a['providerUserInfo'])!=null&&_0x5dd6ab['length']?wa(_0x59139a['providerUserInfo']):[],_0x1065e4=mf(_0x54d6a2['providerData'],_0x2181c5),_0x2b99a1=_0x54d6a2['isAnonymous'],_0x5bf972=!(_0x54d6a2['email']&&_0x59139a['passwordHash'])&&!(_0x1065e4!=null&&_0x1065e4['length']),_0x3df4b9=_0x2b99a1?_0x5bf972:!0x1,_0x1ad983={'uid':_0x59139a['localId'],'displayName':_0x59139a['displayName']||null,'photoURL':_0x59139a['photoUrl']||null,'email':_0x59139a['email']||null,'emailVerified':_0x59139a['emailVerified']||!0x1,'phoneNumber':_0x59139a['phoneNumber']||null,'tenantId':_0x59139a['tenantId']||null,'providerData':_0x1065e4,'metadata':new Pi(_0x59139a['createdAt'],_0x59139a['lastLoginAt']),'isAnonymous':_0x3df4b9};Object['assign'](_0x54d6a2,_0x1ad983);}async function gf(_0x31fad7){const _0x45bbce=k(_0x31fad7);await bn(_0x45bbce),await _0x45bbce['auth']['_persistUserIfCurrent'](_0x45bbce),_0x45bbce['auth']['_notifyListenersIfCurrent'](_0x45bbce);}function mf(_0x30f09b,_0x976aaa){return[..._0x30f09b['filter'](_0x3ff414=>!_0x976aaa['some'](_0x1c7750=>_0x1c7750['providerId']===_0x3ff414['providerId'])),..._0x976aaa];}function wa(_0x1bc499){return _0x1bc499['map'](({providerId:_0x170632,..._0x1e2e0e})=>({'providerId':_0x170632,'uid':_0x1e2e0e['rawId']||'','displayName':_0x1e2e0e['displayName']||null,'email':_0x1e2e0e['email']||null,'phoneNumber':_0x1e2e0e['phoneNumber']||null,'photoURL':_0x1e2e0e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x1001fd,_0x29c539){const _0x53c8f8=await Ea(_0x1001fd,{},async()=>{const _0x23c06d=at({'grant_type':'refresh_token','refresh_token':_0x29c539})['slice'](0x1),{tokenApiHost:_0xe13193,apiKey:_0x464cdd}=_0x1001fd['config'],_0x4d6492=await Ia(_0x1001fd,_0xe13193,'/v1/token','key='+_0x464cdd),_0x1b3763=await _0x1001fd['_getAdditionalHeaders']();_0x1b3763['Content-Type']='application/x-www-form-urlencoded';const _0xe0307f={'method':'POST','headers':_0x1b3763,'body':_0x23c06d};return _0x1001fd['emulatorConfig']&&Wt(_0x1001fd['emulatorConfig']['host'])&&(_0xe0307f['credentials']='include'),va['fetch']()(_0x4d6492,_0xe0307f);});return{'accessToken':_0x53c8f8['access_token'],'expiresIn':_0x53c8f8['expires_in'],'refreshToken':_0x53c8f8['refresh_token']};}async function vf(_0x5a630c,_0x59258f){return Ae(_0x5a630c,'POST','/v2/accounts:revokeToken',Re(_0x5a630c,_0x59258f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x10ea1a){m(_0x10ea1a['idToken'],'internal-error'),m(typeof _0x10ea1a['idToken']<'u','internal-error'),m(typeof _0x10ea1a['refreshToken']<'u','internal-error');const _0x24945e='expiresIn'in _0x10ea1a&&typeof _0x10ea1a['expiresIn']<'u'?Number(_0x10ea1a['expiresIn']):Er(_0x10ea1a['idToken']);this['updateTokensAndExpiration'](_0x10ea1a['idToken'],_0x10ea1a['refreshToken'],_0x24945e);}['updateFromIdToken'](_0x16b593){m(_0x16b593['length']!==0x0,'internal-error');const _0x5a325e=Er(_0x16b593);this['updateTokensAndExpiration'](_0x16b593,null,_0x5a325e);}async['getToken'](_0x12ffe7,_0x21632f=!0x1){return!_0x21632f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x12ffe7,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x12ffe7,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2ce4f9,_0x230de7){const {accessToken:_0x5da094,refreshToken:_0x213550,expiresIn:_0x326326}=await yf(_0x2ce4f9,_0x230de7);this['updateTokensAndExpiration'](_0x5da094,_0x213550,Number(_0x326326));}['updateTokensAndExpiration'](_0xa13c7f,_0x3a9a7b,_0x48fcdf){this['refreshToken']=_0x3a9a7b||null,this['accessToken']=_0xa13c7f||null,this['expirationTime']=Date['now']()+_0x48fcdf*0x3e8;}static['fromJSON'](_0x16f03f,_0x428a21){const {refreshToken:_0x1aa274,accessToken:_0x4a46df,expirationTime:_0xf7ccbd}=_0x428a21,_0x5a4cb3=new Je();return _0x1aa274&&(m(typeof _0x1aa274=='string','internal-error',{'appName':_0x16f03f}),_0x5a4cb3['refreshToken']=_0x1aa274),_0x4a46df&&(m(typeof _0x4a46df=='string','internal-error',{'appName':_0x16f03f}),_0x5a4cb3['accessToken']=_0x4a46df),_0xf7ccbd&&(m(typeof _0xf7ccbd=='number','internal-error',{'appName':_0x16f03f}),_0x5a4cb3['expirationTime']=_0xf7ccbd),_0x5a4cb3;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1b33da){this['accessToken']=_0x1b33da['accessToken'],this['refreshToken']=_0x1b33da['refreshToken'],this['expirationTime']=_0x1b33da['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x53e54c,_0x16ab6c){m(typeof _0x53e54c=='string'||typeof _0x53e54c>'u','internal-error',{'appName':_0x16ab6c});}class z{constructor({uid:_0x186225,auth:_0x78fd55,stsTokenManager:_0x45cd11,..._0x3be5cd}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x186225,this['auth']=_0x78fd55,this['stsTokenManager']=_0x45cd11,this['accessToken']=_0x45cd11['accessToken'],this['displayName']=_0x3be5cd['displayName']||null,this['email']=_0x3be5cd['email']||null,this['emailVerified']=_0x3be5cd['emailVerified']||!0x1,this['phoneNumber']=_0x3be5cd['phoneNumber']||null,this['photoURL']=_0x3be5cd['photoURL']||null,this['isAnonymous']=_0x3be5cd['isAnonymous']||!0x1,this['tenantId']=_0x3be5cd['tenantId']||null,this['providerData']=_0x3be5cd['providerData']?[..._0x3be5cd['providerData']]:[],this['metadata']=new Pi(_0x3be5cd['createdAt']||void 0x0,_0x3be5cd['lastLoginAt']||void 0x0);}async['getIdToken'](_0x25eee3){const _0x3ad14a=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x25eee3));return m(_0x3ad14a,this['auth'],'internal-error'),this['accessToken']!==_0x3ad14a&&(this['accessToken']=_0x3ad14a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3ad14a;}['getIdTokenResult'](_0x37c14d){return ff(this,_0x37c14d);}['reload'](){return gf(this);}['_assign'](_0x3bc70f){this!==_0x3bc70f&&(m(this['uid']===_0x3bc70f['uid'],this['auth'],'internal-error'),this['displayName']=_0x3bc70f['displayName'],this['photoURL']=_0x3bc70f['photoURL'],this['email']=_0x3bc70f['email'],this['emailVerified']=_0x3bc70f['emailVerified'],this['phoneNumber']=_0x3bc70f['phoneNumber'],this['isAnonymous']=_0x3bc70f['isAnonymous'],this['tenantId']=_0x3bc70f['tenantId'],this['providerData']=_0x3bc70f['providerData']['map'](_0x2d63b9=>({..._0x2d63b9})),this['metadata']['_copy'](_0x3bc70f['metadata']),this['stsTokenManager']['_assign'](_0x3bc70f['stsTokenManager']));}['_clone'](_0xf4f8a1){const _0x20e0bf=new z({...this,'auth':_0xf4f8a1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x20e0bf['metadata']['_copy'](this['metadata']),_0x20e0bf;}['_onReload'](_0x2d79a2){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2d79a2,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xbb0c32){this['reloadListener']?this['reloadListener'](_0xbb0c32):this['reloadUserInfo']=_0xbb0c32;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4f8898,_0x43e3ca=!0x1){let _0x177900=!0x1;_0x4f8898['idToken']&&_0x4f8898['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4f8898),_0x177900=!0x0),_0x43e3ca&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x177900&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1f5917=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1f5917})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x181310=>({..._0x181310})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x590dce,_0x3f25f2){const _0x89f0e2=_0x3f25f2['displayName']??void 0x0,_0x5bf31b=_0x3f25f2['email']??void 0x0,_0x350ec6=_0x3f25f2['phoneNumber']??void 0x0,_0x153774=_0x3f25f2['photoURL']??void 0x0,_0x149c5a=_0x3f25f2['tenantId']??void 0x0,_0x5e451a=_0x3f25f2['_redirectEventId']??void 0x0,_0x52eb4e=_0x3f25f2['createdAt']??void 0x0,_0x205093=_0x3f25f2['lastLoginAt']??void 0x0,{uid:_0x18af64,emailVerified:_0x4ff6b7,isAnonymous:_0x4c0ccc,providerData:_0x4bc93a,stsTokenManager:_0x2faecf}=_0x3f25f2;m(_0x18af64&&_0x2faecf,_0x590dce,'internal-error');const _0xfe6eb7=Je['fromJSON'](this['name'],_0x2faecf);m(typeof _0x18af64=='string',_0x590dce,'internal-error'),ce(_0x89f0e2,_0x590dce['name']),ce(_0x5bf31b,_0x590dce['name']),m(typeof _0x4ff6b7=='boolean',_0x590dce,'internal-error'),m(typeof _0x4c0ccc=='boolean',_0x590dce,'internal-error'),ce(_0x350ec6,_0x590dce['name']),ce(_0x153774,_0x590dce['name']),ce(_0x149c5a,_0x590dce['name']),ce(_0x5e451a,_0x590dce['name']),ce(_0x52eb4e,_0x590dce['name']),ce(_0x205093,_0x590dce['name']);const _0x5c8df5=new z({'uid':_0x18af64,'auth':_0x590dce,'email':_0x5bf31b,'emailVerified':_0x4ff6b7,'displayName':_0x89f0e2,'isAnonymous':_0x4c0ccc,'photoURL':_0x153774,'phoneNumber':_0x350ec6,'tenantId':_0x149c5a,'stsTokenManager':_0xfe6eb7,'createdAt':_0x52eb4e,'lastLoginAt':_0x205093});return _0x4bc93a&&Array['isArray'](_0x4bc93a)&&(_0x5c8df5['providerData']=_0x4bc93a['map'](_0x517285=>({..._0x517285}))),_0x5e451a&&(_0x5c8df5['_redirectEventId']=_0x5e451a),_0x5c8df5;}static async['_fromIdTokenResponse'](_0x170a6a,_0x30b71b,_0x3260cc=!0x1){const _0x59b811=new Je();_0x59b811['updateFromServerResponse'](_0x30b71b);const _0x5cd400=new z({'uid':_0x30b71b['localId'],'auth':_0x170a6a,'stsTokenManager':_0x59b811,'isAnonymous':_0x3260cc});return await bn(_0x5cd400),_0x5cd400;}static async['_fromGetAccountInfoResponse'](_0x1be3fd,_0x3c5723,_0x1a6b4d){const _0x16be1c=_0x3c5723['users'][0x0];m(_0x16be1c['localId']!==void 0x0,'internal-error');const _0xa76cd2=_0x16be1c['providerUserInfo']!==void 0x0?wa(_0x16be1c['providerUserInfo']):[],_0x402273=!(_0x16be1c['email']&&_0x16be1c['passwordHash'])&&!(_0xa76cd2!=null&&_0xa76cd2['length']),_0x35a179=new Je();_0x35a179['updateFromIdToken'](_0x1a6b4d);const _0x29b4ed=new z({'uid':_0x16be1c['localId'],'auth':_0x1be3fd,'stsTokenManager':_0x35a179,'isAnonymous':_0x402273}),_0x52e822={'uid':_0x16be1c['localId'],'displayName':_0x16be1c['displayName']||null,'photoURL':_0x16be1c['photoUrl']||null,'email':_0x16be1c['email']||null,'emailVerified':_0x16be1c['emailVerified']||!0x1,'phoneNumber':_0x16be1c['phoneNumber']||null,'tenantId':_0x16be1c['tenantId']||null,'providerData':_0xa76cd2,'metadata':new Pi(_0x16be1c['createdAt'],_0x16be1c['lastLoginAt']),'isAnonymous':!(_0x16be1c['email']&&_0x16be1c['passwordHash'])&&!(_0xa76cd2!=null&&_0xa76cd2['length'])};return Object['assign'](_0x29b4ed,_0x52e822),_0x29b4ed;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x4ae7f3){ae(_0x4ae7f3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x92fe23=Ir['get'](_0x4ae7f3);return _0x92fe23?(ae(_0x92fe23 instanceof _0x4ae7f3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x92fe23):(_0x92fe23=new _0x4ae7f3(),Ir['set'](_0x4ae7f3,_0x92fe23),_0x92fe23);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x19aa98,_0x25952f){this['storage'][_0x19aa98]=_0x25952f;}async['_get'](_0x48ad39){const _0xc3bf5d=this['storage'][_0x48ad39];return _0xc3bf5d===void 0x0?null:_0xc3bf5d;}async['_remove'](_0x1308d8){delete this['storage'][_0x1308d8];}['_addListener'](_0x3d850f,_0x5b4479){}['_removeListener'](_0x5c15d6,_0x5e81af){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x1c400c,_0x518a82,_0x906df){return'firebase:'+_0x1c400c+':'+_0x518a82+':'+_0x906df;}class Xe{constructor(_0xd38dd2,_0x3b4521,_0x7589bb){this['persistence']=_0xd38dd2,this['auth']=_0x3b4521,this['userKey']=_0x7589bb;const {config:_0x1d76d3,name:_0x239e0e}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1d76d3['apiKey'],_0x239e0e),this['fullPersistenceKey']=sn('persistence',_0x1d76d3['apiKey'],_0x239e0e),this['boundEventHandler']=_0x3b4521['_onStorageEvent']['bind'](_0x3b4521),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5e8192){return this['persistence']['_set'](this['fullUserKey'],_0x5e8192['toJSON']());}async['getCurrentUser'](){const _0x2d2b72=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2d2b72)return null;if(typeof _0x2d2b72=='string'){const _0x172f09=await Sn(this['auth'],{'idToken':_0x2d2b72})['catch'](()=>{});return _0x172f09?z['_fromGetAccountInfoResponse'](this['auth'],_0x172f09,_0x2d2b72):null;}return z['_fromJSON'](this['auth'],_0x2d2b72);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3a6fee){if(this['persistence']===_0x3a6fee)return;const _0x296c31=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3a6fee,_0x296c31)return this['setCurrentUser'](_0x296c31);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x45e8ed,_0xd764a2,_0x1f003a='authUser'){if(!_0xd764a2['length'])return new Xe(ne(wr),_0x45e8ed,_0x1f003a);const _0x572bb7=(await Promise['all'](_0xd764a2['map'](async _0x491ee6=>{if(await _0x491ee6['_isAvailable']())return _0x491ee6;})))['filter'](_0x42b21=>_0x42b21);let _0x3d4a1a=_0x572bb7[0x0]||ne(wr);const _0x4203dc=sn(_0x1f003a,_0x45e8ed['config']['apiKey'],_0x45e8ed['name']);let _0x349f2a=null;for(const _0x5cb54c of _0xd764a2)try{const _0x2039b8=await _0x5cb54c['_get'](_0x4203dc);if(_0x2039b8){let _0x5f1f61;if(typeof _0x2039b8=='string'){const _0x3dfc13=await Sn(_0x45e8ed,{'idToken':_0x2039b8})['catch'](()=>{});if(!_0x3dfc13)break;_0x5f1f61=await z['_fromGetAccountInfoResponse'](_0x45e8ed,_0x3dfc13,_0x2039b8);}else _0x5f1f61=z['_fromJSON'](_0x45e8ed,_0x2039b8);_0x5cb54c!==_0x3d4a1a&&(_0x349f2a=_0x5f1f61),_0x3d4a1a=_0x5cb54c;break;}}catch{}const _0x26317f=_0x572bb7['filter'](_0x25cee1=>_0x25cee1['_shouldAllowMigration']);return!_0x3d4a1a['_shouldAllowMigration']||!_0x26317f['length']?new Xe(_0x3d4a1a,_0x45e8ed,_0x1f003a):(_0x3d4a1a=_0x26317f[0x0],_0x349f2a&&await _0x3d4a1a['_set'](_0x4203dc,_0x349f2a['toJSON']()),await Promise['all'](_0xd764a2['map'](async _0x405dd7=>{if(_0x405dd7!==_0x3d4a1a)try{await _0x405dd7['_remove'](_0x4203dc);}catch{}})),new Xe(_0x3d4a1a,_0x45e8ed,_0x1f003a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x21a902){const _0x58b549=_0x21a902['toLowerCase']();if(_0x58b549['includes']('opera/')||_0x58b549['includes']('opr/')||_0x58b549['includes']('opios/'))return'Opera';if(Ra(_0x58b549))return'IEMobile';if(_0x58b549['includes']('msie')||_0x58b549['includes']('trident/'))return'IE';if(_0x58b549['includes']('edge/'))return'Edge';if(Ta(_0x58b549))return'Firefox';if(_0x58b549['includes']('silk/'))return'Silk';if(ka(_0x58b549))return'Blackberry';if(Na(_0x58b549))return'Webos';if(Sa(_0x58b549))return'Safari';if((_0x58b549['includes']('chrome/')||ba(_0x58b549))&&!_0x58b549['includes']('edge/'))return'Chrome';if(Aa(_0x58b549))return'Android';{const _0x4c73c9=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1874cd=_0x21a902['match'](_0x4c73c9);if((_0x1874cd==null?void 0x0:_0x1874cd['length'])===0x2)return _0x1874cd[0x1];}return'Other';}function Ta(_0x3ae943=W()){return/firefox\//i['test'](_0x3ae943);}function Sa(_0x5e1939=W()){const _0x30db34=_0x5e1939['toLowerCase']();return _0x30db34['includes']('safari/')&&!_0x30db34['includes']('chrome/')&&!_0x30db34['includes']('crios/')&&!_0x30db34['includes']('android');}function ba(_0x24e51e=W()){return/crios\//i['test'](_0x24e51e);}function Ra(_0x21e8e0=W()){return/iemobile/i['test'](_0x21e8e0);}function Aa(_0x4f892b=W()){return/android/i['test'](_0x4f892b);}function ka(_0x51bae3=W()){return/blackberry/i['test'](_0x51bae3);}function Na(_0x4d2072=W()){return/webos/i['test'](_0x4d2072);}function Cs(_0x31c879=W()){return/iphone|ipad|ipod/i['test'](_0x31c879)||/macintosh/i['test'](_0x31c879)&&/mobile/i['test'](_0x31c879);}function Ef(_0x4b9bfc=W()){var _0x5d4537;return Cs(_0x4b9bfc)&&!!((_0x5d4537=window['navigator'])!=null&&_0x5d4537['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x1fdcda=W()){return Cs(_0x1fdcda)||Aa(_0x1fdcda)||Na(_0x1fdcda)||ka(_0x1fdcda)||/windows phone/i['test'](_0x1fdcda)||Ra(_0x1fdcda);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x1771f0,_0x2acbad=[]){let _0xc7de20;switch(_0x1771f0){case'Browser':_0xc7de20=Cr(W());break;case'Worker':_0xc7de20=Cr(W())+'-'+_0x1771f0;break;default:_0xc7de20=_0x1771f0;}const _0x1df385=_0x2acbad['length']?_0x2acbad['join'](','):'FirebaseCore-web';return _0xc7de20+'/JsCore/'+ct+'/'+_0x1df385;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x271cfe){this['auth']=_0x271cfe,this['queue']=[];}['pushCallback'](_0x2769ad,_0x17dd90){const _0xffca5b=_0x4e8c4d=>new Promise((_0x1bdada,_0x2c324f)=>{try{const _0xe7f08d=_0x2769ad(_0x4e8c4d);_0x1bdada(_0xe7f08d);}catch(_0x130f28){_0x2c324f(_0x130f28);}});_0xffca5b['onAbort']=_0x17dd90,this['queue']['push'](_0xffca5b);const _0x462f05=this['queue']['length']-0x1;return()=>{this['queue'][_0x462f05]=()=>Promise['resolve']();};}async['runMiddleware'](_0x6f8c76){if(this['auth']['currentUser']===_0x6f8c76)return;const _0x3e8ac3=[];try{for(const _0x169c96 of this['queue'])await _0x169c96(_0x6f8c76),_0x169c96['onAbort']&&_0x3e8ac3['push'](_0x169c96['onAbort']);}catch(_0x16bae1){_0x3e8ac3['reverse']();for(const _0x1b5002 of _0x3e8ac3)try{_0x1b5002();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x16bae1==null?void 0x0:_0x16bae1['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x16e239,_0x5ef8de={}){return Ae(_0x16e239,'GET','/v2/passwordPolicy',Re(_0x16e239,_0x5ef8de));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x543bad){var _0x6b455b;const _0x49cca3=_0x543bad['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x49cca3['minPasswordLength']??Tf,_0x49cca3['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x49cca3['maxPasswordLength']),_0x49cca3['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x49cca3['containsLowercaseCharacter']),_0x49cca3['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x49cca3['containsUppercaseCharacter']),_0x49cca3['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x49cca3['containsNumericCharacter']),_0x49cca3['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x49cca3['containsNonAlphanumericCharacter']),this['enforcementState']=_0x543bad['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x6b455b=_0x543bad['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x6b455b['join'](''))??'',this['forceUpgradeOnSignin']=_0x543bad['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x543bad['schemaVersion'];}['validatePassword'](_0x7a3555){const _0x299027={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x7a3555,_0x299027),this['validatePasswordCharacterOptions'](_0x7a3555,_0x299027),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['meetsMinPasswordLength']??!0x0),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['meetsMaxPasswordLength']??!0x0),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['containsLowercaseLetter']??!0x0),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['containsUppercaseLetter']??!0x0),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['containsNumericCharacter']??!0x0),_0x299027['isValid']&&(_0x299027['isValid']=_0x299027['containsNonAlphanumericCharacter']??!0x0),_0x299027;}['validatePasswordLengthOptions'](_0x1ef481,_0x312c49){const _0x53dade=this['customStrengthOptions']['minPasswordLength'],_0x269c31=this['customStrengthOptions']['maxPasswordLength'];_0x53dade&&(_0x312c49['meetsMinPasswordLength']=_0x1ef481['length']>=_0x53dade),_0x269c31&&(_0x312c49['meetsMaxPasswordLength']=_0x1ef481['length']<=_0x269c31);}['validatePasswordCharacterOptions'](_0x589720,_0x1b9cb8){this['updatePasswordCharacterOptionsStatuses'](_0x1b9cb8,!0x1,!0x1,!0x1,!0x1);let _0x267f8e;for(let _0x391f41=0x0;_0x391f41<_0x589720['length'];_0x391f41++)_0x267f8e=_0x589720['charAt'](_0x391f41),this['updatePasswordCharacterOptionsStatuses'](_0x1b9cb8,_0x267f8e>='a'&&_0x267f8e<='z',_0x267f8e>='A'&&_0x267f8e<='Z',_0x267f8e>='0'&&_0x267f8e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x267f8e));}['updatePasswordCharacterOptionsStatuses'](_0x476923,_0x3d3d24,_0x263551,_0x505072,_0x3b6b7b){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x476923['containsLowercaseLetter']||(_0x476923['containsLowercaseLetter']=_0x3d3d24)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x476923['containsUppercaseLetter']||(_0x476923['containsUppercaseLetter']=_0x263551)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x476923['containsNumericCharacter']||(_0x476923['containsNumericCharacter']=_0x505072)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x476923['containsNonAlphanumericCharacter']||(_0x476923['containsNonAlphanumericCharacter']=_0x3b6b7b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x20d318,_0x21ad40,_0x5f3076,_0x5dbf00){this['app']=_0x20d318,this['heartbeatServiceProvider']=_0x21ad40,this['appCheckServiceProvider']=_0x5f3076,this['config']=_0x5dbf00,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x20d318['name'],this['clientVersion']=_0x5dbf00['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2eaae1=>this['_resolvePersistenceManagerAvailable']=_0x2eaae1);}['_initializeWithPersistence'](_0x4728f3,_0x213515){return _0x213515&&(this['_popupRedirectResolver']=ne(_0x213515)),this['_initializationPromise']=this['queue'](async()=>{var _0x393b96,_0x46db1c,_0x42cf71;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4728f3),(_0x393b96=this['_resolvePersistenceManagerAvailable'])==null||_0x393b96['call'](this),!this['_deleted'])){if((_0x46db1c=this['_popupRedirectResolver'])!=null&&_0x46db1c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x213515),this['lastNotifiedUid']=((_0x42cf71=this['currentUser'])==null?void 0x0:_0x42cf71['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x59fe86=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x59fe86)){if(this['currentUser']&&_0x59fe86&&this['currentUser']['uid']===_0x59fe86['uid']){this['_currentUser']['_assign'](_0x59fe86),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x59fe86,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x12d84c){try{const _0x4f1c9a=await Sn(this,{'idToken':_0x12d84c}),_0x448a03=await z['_fromGetAccountInfoResponse'](this,_0x4f1c9a,_0x12d84c);await this['directlySetCurrentUser'](_0x448a03);}catch(_0x4a6201){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4a6201),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x78202){var _0x13ebca;if(H(this['app'])){const _0x5214fa=this['app']['settings']['authIdToken'];return _0x5214fa?new Promise(_0x24d87c=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5214fa)['then'](_0x24d87c,_0x24d87c));}):this['directlySetCurrentUser'](null);}const _0x591cd3=await this['assertedPersistence']['getCurrentUser']();let _0x1a2ba5=_0x591cd3,_0x358bba=!0x1;if(_0x78202&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x44adcd=(_0x13ebca=this['redirectUser'])==null?void 0x0:_0x13ebca['_redirectEventId'],_0x526640=_0x1a2ba5==null?void 0x0:_0x1a2ba5['_redirectEventId'],_0x295342=await this['tryRedirectSignIn'](_0x78202);(!_0x44adcd||_0x44adcd===_0x526640)&&(_0x295342!=null&&_0x295342['user'])&&(_0x1a2ba5=_0x295342['user'],_0x358bba=!0x0);}if(!_0x1a2ba5)return this['directlySetCurrentUser'](null);if(!_0x1a2ba5['_redirectEventId']){if(_0x358bba)try{await this['beforeStateQueue']['runMiddleware'](_0x1a2ba5);}catch(_0x5b57fb){_0x1a2ba5=_0x591cd3,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5b57fb));}return _0x1a2ba5?this['reloadAndSetCurrentUserOrClear'](_0x1a2ba5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1a2ba5['_redirectEventId']?this['directlySetCurrentUser'](_0x1a2ba5):this['reloadAndSetCurrentUserOrClear'](_0x1a2ba5);}async['tryRedirectSignIn'](_0xa405ce){let _0x303e6f=null;try{_0x303e6f=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xa405ce,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x303e6f;}async['reloadAndSetCurrentUserOrClear'](_0x2d09c8){try{await bn(_0x2d09c8);}catch(_0x44cd1f){if((_0x44cd1f==null?void 0x0:_0x44cd1f['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2d09c8);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x31400a){if(H(this['app']))return Promise['reject'](se(this));const _0x348dab=_0x31400a?k(_0x31400a):null;return _0x348dab&&m(_0x348dab['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x348dab&&_0x348dab['_clone'](this));}async['_updateCurrentUser'](_0x52b36a,_0x504ca6=!0x1){if(!this['_deleted'])return _0x52b36a&&m(this['tenantId']===_0x52b36a['tenantId'],this,'tenant-id-mismatch'),_0x504ca6||await this['beforeStateQueue']['runMiddleware'](_0x52b36a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x52b36a),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5477fd){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x5477fd));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x132e79){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5d586e=this['_getPasswordPolicyInternal']();return _0x5d586e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5d586e['validatePassword'](_0x132e79);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x23f6ec=await Cf(this),_0x289369=new Sf(_0x23f6ec);this['tenantId']===null?this['_projectPasswordPolicy']=_0x289369:this['_tenantPasswordPolicies'][this['tenantId']]=_0x289369;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1b02e2){this['_errorFactory']=new Ut('auth','Firebase',_0x1b02e2());}['onAuthStateChanged'](_0xd091ef,_0x2d82a1,_0x2dd330){return this['registerStateListener'](this['authStateSubscription'],_0xd091ef,_0x2d82a1,_0x2dd330);}['beforeAuthStateChanged'](_0x55fdff,_0x2d8e07){return this['beforeStateQueue']['pushCallback'](_0x55fdff,_0x2d8e07);}['onIdTokenChanged'](_0x5486fd,_0x4bac0f,_0x1eed4b){return this['registerStateListener'](this['idTokenSubscription'],_0x5486fd,_0x4bac0f,_0x1eed4b);}['authStateReady'](){return new Promise((_0x43e84b,_0x554bd5)=>{if(this['currentUser'])_0x43e84b();else{const _0x439595=this['onAuthStateChanged'](()=>{_0x439595(),_0x43e84b();},_0x554bd5);}});}async['revokeAccessToken'](_0x8fe163){if(this['currentUser']){const _0x563f9f=await this['currentUser']['getIdToken'](),_0x50c8c9={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x8fe163,'idToken':_0x563f9f};this['tenantId']!=null&&(_0x50c8c9['tenantId']=this['tenantId']),await vf(this,_0x50c8c9);}}['toJSON'](){var _0x558d1;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x558d1=this['_currentUser'])==null?void 0x0:_0x558d1['toJSON']()};}async['_setRedirectUser'](_0x3b93a7,_0x5f32ff){const _0x2803d8=await this['getOrInitRedirectPersistenceManager'](_0x5f32ff);return _0x3b93a7===null?_0x2803d8['removeCurrentUser']():_0x2803d8['setCurrentUser'](_0x3b93a7);}async['getOrInitRedirectPersistenceManager'](_0x3ae8c5){if(!this['redirectPersistenceManager']){const _0x177794=_0x3ae8c5&&ne(_0x3ae8c5)||this['_popupRedirectResolver'];m(_0x177794,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x177794['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x230964){var _0x4a140d,_0xb3fa46;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4a140d=this['_currentUser'])==null?void 0x0:_0x4a140d['_redirectEventId'])===_0x230964?this['_currentUser']:((_0xb3fa46=this['redirectUser'])==null?void 0x0:_0xb3fa46['_redirectEventId'])===_0x230964?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5334b3){if(_0x5334b3===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5334b3));}['_notifyListenersIfCurrent'](_0x4c0c1d){_0x4c0c1d===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x471496;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x45fee9=((_0x471496=this['currentUser'])==null?void 0x0:_0x471496['uid'])??null;this['lastNotifiedUid']!==_0x45fee9&&(this['lastNotifiedUid']=_0x45fee9,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3d1b5a,_0x58980b,_0x3ba39c,_0x334a7b){if(this['_deleted'])return()=>{};const _0x39f5a6=typeof _0x58980b=='function'?_0x58980b:_0x58980b['next']['bind'](_0x58980b);let _0x35a44f=!0x1;const _0xdede82=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xdede82,this,'internal-error'),_0xdede82['then'](()=>{_0x35a44f||_0x39f5a6(this['currentUser']);}),typeof _0x58980b=='function'){const _0x51d02b=_0x3d1b5a['addObserver'](_0x58980b,_0x3ba39c,_0x334a7b);return()=>{_0x35a44f=!0x0,_0x51d02b();};}else{const _0x55b3ea=_0x3d1b5a['addObserver'](_0x58980b);return()=>{_0x35a44f=!0x0,_0x55b3ea();};}}async['directlySetCurrentUser'](_0x4f9b84){this['currentUser']&&this['currentUser']!==_0x4f9b84&&this['_currentUser']['_stopProactiveRefresh'](),_0x4f9b84&&this['isProactiveRefreshEnabled']&&_0x4f9b84['_startProactiveRefresh'](),this['currentUser']=_0x4f9b84,_0x4f9b84?await this['assertedPersistence']['setCurrentUser'](_0x4f9b84):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2e44b6){return this['operations']=this['operations']['then'](_0x2e44b6,_0x2e44b6),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x50e80f){!_0x50e80f||this['frameworks']['includes'](_0x50e80f)||(this['frameworks']['push'](_0x50e80f),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2789d6;const _0x4320f0={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4320f0['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4788fc=await((_0x2789d6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2789d6['getHeartbeatsHeader']());_0x4788fc&&(_0x4320f0['X-Firebase-Client']=_0x4788fc);const _0x18dc10=await this['_getAppCheckToken']();return _0x18dc10&&(_0x4320f0['X-Firebase-AppCheck']=_0x18dc10),_0x4320f0;}async['_getAppCheckToken'](){var _0xbe3d11;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xc43552=await((_0xbe3d11=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xbe3d11['getToken']());return _0xc43552!=null&&_0xc43552['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xc43552['error']),_0xc43552==null?void 0x0:_0xc43552['token'];}}function qe(_0x2342b4){return k(_0x2342b4);}class Tr{constructor(_0x44ad47){this['auth']=_0x44ad47,this['observer']=null,this['addObserver']=Ic(_0x137b3e=>this['observer']=_0x137b3e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x187b3f){zn=_0x187b3f;}function Da(_0x4b60bc){return zn['loadJS'](_0x4b60bc);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x45deba){return'__'+_0x45deba+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x477058){_0x477058();}['execute'](_0x3e5066,_0x51e343){return Promise['resolve']('token');}['render'](_0x159249,_0x427940){return'';}}class Of{['ready'](_0x528998){_0x528998();}['execute'](_0x2da577,_0x4c3bd4){return Promise['resolve']('token');}['render'](_0x390197,_0x4c5519){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2bd8b1){this['type']=Df,this['auth']=qe(_0x2bd8b1);}async['verify'](_0x44cd08='verify',_0x5ded5d=!0x1){async function _0xbac87f(_0x32acc0){if(!_0x5ded5d){if(_0x32acc0['tenantId']==null&&_0x32acc0['_agentRecaptchaConfig']!=null)return _0x32acc0['_agentRecaptchaConfig']['siteKey'];if(_0x32acc0['tenantId']!=null&&_0x32acc0['_tenantRecaptchaConfigs'][_0x32acc0['tenantId']]!==void 0x0)return _0x32acc0['_tenantRecaptchaConfigs'][_0x32acc0['tenantId']]['siteKey'];}return new Promise(async(_0x59832a,_0x2a3767)=>{uf(_0x32acc0,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2ca302=>{if(_0x2ca302['recaptchaKey']===void 0x0)_0x2a3767(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2b4bea=new hf(_0x2ca302);return _0x32acc0['tenantId']==null?_0x32acc0['_agentRecaptchaConfig']=_0x2b4bea:_0x32acc0['_tenantRecaptchaConfigs'][_0x32acc0['tenantId']]=_0x2b4bea,_0x59832a(_0x2b4bea['siteKey']);}})['catch'](_0x8d6033=>{_0x2a3767(_0x8d6033);});});}function _0x54bc8f(_0x28d25c,_0x30431f,_0x140478){const _0x4b6b0e=window['grecaptcha'];vr(_0x4b6b0e)?_0x4b6b0e['enterprise']['ready'](()=>{_0x4b6b0e['enterprise']['execute'](_0x28d25c,{'action':_0x44cd08})['then'](_0xe5a574=>{_0x30431f(_0xe5a574);})['catch'](()=>{_0x30431f(Ma);});}):_0x140478(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x32724e,_0x59dcfd)=>{_0xbac87f(this['auth'])['then'](async _0x4edd19=>{if(!_0x5ded5d&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x54bc8f(_0x4edd19,_0x32724e,_0x59dcfd);else{if(typeof window>'u'){_0x59dcfd(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x19b8ac=Af();_0x19b8ac['length']!==0x0&&(_0x19b8ac+=_0x4edd19+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x17b7fd;(_0x17b7fd=le['scriptInjectionDeferred'])==null||_0x17b7fd['resolve']();},Da(_0x19b8ac)['then'](()=>{var _0x3977ca;return(_0x3977ca=le['scriptInjectionDeferred'])==null?void 0x0:_0x3977ca['promise'];})['then'](()=>{_0x54bc8f(_0x4edd19,_0x32724e,_0x59dcfd);})['catch'](_0x163fbe=>{_0x59dcfd(_0x163fbe);});}})['catch'](_0x7fd109=>{_0x59dcfd(_0x7fd109);});});}}le['scriptInjectionDeferred']=null;async function br(_0xf2e438,_0x182d02,_0x3daef2,_0x1c6220=!0x1,_0x1bfc71=!0x1){const _0x29d52a=new le(_0xf2e438);let _0x2d7500;if(_0x1bfc71)_0x2d7500=Ma;else try{_0x2d7500=await _0x29d52a['verify'](_0x3daef2);}catch{_0x2d7500=await _0x29d52a['verify'](_0x3daef2,!0x0);}const _0x51bf19={..._0x182d02};if(_0x3daef2==='mfaSmsEnrollment'||_0x3daef2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x51bf19){const _0x394a0f=_0x51bf19['phoneEnrollmentInfo']['phoneNumber'],_0x45a2c6=_0x51bf19['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x51bf19,{'phoneEnrollmentInfo':{'phoneNumber':_0x394a0f,'recaptchaToken':_0x45a2c6,'captchaResponse':_0x2d7500,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x51bf19){const _0x5eac35=_0x51bf19['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x51bf19,{'phoneSignInInfo':{'recaptchaToken':_0x5eac35,'captchaResponse':_0x2d7500,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x51bf19;}return _0x1c6220?Object['assign'](_0x51bf19,{'captchaResp':_0x2d7500}):Object['assign'](_0x51bf19,{'captchaResponse':_0x2d7500}),Object['assign'](_0x51bf19,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x51bf19,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x51bf19;}async function Oi(_0x9c042c,_0x3a9ff7,_0x30af00,_0x2467f2,_0x1e460b){var _0x46282e;if((_0x46282e=_0x9c042c['_getRecaptchaConfig']())!=null&&_0x46282e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x97fa06=await br(_0x9c042c,_0x3a9ff7,_0x30af00,_0x30af00==='getOobCode');return _0x2467f2(_0x9c042c,_0x97fa06);}else return _0x2467f2(_0x9c042c,_0x3a9ff7)['catch'](async _0x29aec6=>{if(_0x29aec6['code']==='auth/missing-recaptcha-token'){console['log'](_0x30af00+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2c3a9e=await br(_0x9c042c,_0x3a9ff7,_0x30af00,_0x30af00==='getOobCode');return _0x2467f2(_0x9c042c,_0x2c3a9e);}else return Promise['reject'](_0x29aec6);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x1b8907,_0x5c2244){const _0x5eb9fb=Ui(_0x1b8907,'auth');if(_0x5eb9fb['isInitialized']()){const _0x4efb1a=_0x5eb9fb['getImmediate'](),_0x566da9=_0x5eb9fb['getOptions']();if(De(_0x566da9,_0x5c2244??{}))return _0x4efb1a;K(_0x4efb1a,'already-initialized');}return _0x5eb9fb['initialize']({'options':_0x5c2244});}function Lf(_0x8e8e22,_0x58f2e9){const _0x890aa7=(_0x58f2e9==null?void 0x0:_0x58f2e9['persistence'])||[],_0x51054f=(Array['isArray'](_0x890aa7)?_0x890aa7:[_0x890aa7])['map'](ne);_0x58f2e9!=null&&_0x58f2e9['errorMap']&&_0x8e8e22['_updateErrorMap'](_0x58f2e9['errorMap']),_0x8e8e22['_initializeWithPersistence'](_0x51054f,_0x58f2e9==null?void 0x0:_0x58f2e9['popupRedirectResolver']);}function xf(_0x38c807,_0x261a6f,_0x111dd2){const _0x46f5c1=qe(_0x38c807);m(/^https?:\/\//['test'](_0x261a6f),_0x46f5c1,'invalid-emulator-scheme');const _0x588c48=!0x1,_0x5f1636=La(_0x261a6f),{host:_0x467079,port:_0x3dc029}=Ff(_0x261a6f),_0x3faffe=_0x3dc029===null?'':':'+_0x3dc029,_0x150b36={'url':_0x5f1636+'//'+_0x467079+_0x3faffe+'/'},_0x17f390=Object['freeze']({'host':_0x467079,'port':_0x3dc029,'protocol':_0x5f1636['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x588c48})});if(!_0x46f5c1['_canInitEmulator']){m(_0x46f5c1['config']['emulator']&&_0x46f5c1['emulatorConfig'],_0x46f5c1,'emulator-config-failed'),m(De(_0x150b36,_0x46f5c1['config']['emulator'])&&De(_0x17f390,_0x46f5c1['emulatorConfig']),_0x46f5c1,'emulator-config-failed');return;}_0x46f5c1['config']['emulator']=_0x150b36,_0x46f5c1['emulatorConfig']=_0x17f390,_0x46f5c1['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x467079)?jr(_0x5f1636+'//'+_0x467079+_0x3faffe):Uf();}function La(_0x5a1d79){const _0x1b1442=_0x5a1d79['indexOf'](':');return _0x1b1442<0x0?'':_0x5a1d79['substr'](0x0,_0x1b1442+0x1);}function Ff(_0x316cba){const _0x3f1cdb=La(_0x316cba),_0x2f2e01=/(\/\/)?([^?#/]+)/['exec'](_0x316cba['substr'](_0x3f1cdb['length']));if(!_0x2f2e01)return{'host':'','port':null};const _0x32a1d4=_0x2f2e01[0x2]['split']('@')['pop']()||'',_0x420979=/^(\[[^\]]+\])(:|$)/['exec'](_0x32a1d4);if(_0x420979){const _0x4b6166=_0x420979[0x1];return{'host':_0x4b6166,'port':Rr(_0x32a1d4['substr'](_0x4b6166['length']+0x1))};}else{const [_0x47693c,_0x133577]=_0x32a1d4['split'](':');return{'host':_0x47693c,'port':Rr(_0x133577)};}}function Rr(_0x4f2938){if(!_0x4f2938)return null;const _0x1e47dd=Number(_0x4f2938);return isNaN(_0x1e47dd)?null:_0x1e47dd;}function Uf(){function _0x5bc2d3(){const _0x2f78a9=document['createElement']('p'),_0x56e791=_0x2f78a9['style'];_0x2f78a9['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x56e791['position']='fixed',_0x56e791['width']='100%',_0x56e791['backgroundColor']='#ffffff',_0x56e791['border']='.1em\x20solid\x20#000000',_0x56e791['color']='#b50000',_0x56e791['bottom']='0px',_0x56e791['left']='0px',_0x56e791['margin']='0px',_0x56e791['zIndex']='10000',_0x56e791['textAlign']='center',_0x2f78a9['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2f78a9);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5bc2d3):_0x5bc2d3());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x363e01,_0x3f040d){this['providerId']=_0x363e01,this['signInMethod']=_0x3f040d;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xbe5610){return te('not\x20implemented');}['_linkToIdToken'](_0x279aac,_0x67fbec){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x422c27){return te('not\x20implemented');}}async function Wf(_0x44f5e0,_0x5a06f4){return Ae(_0x44f5e0,'POST','/v1/accounts:signUp',_0x5a06f4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x245b3c,_0x5a521b){return Yt(_0x245b3c,'POST','/v1/accounts:signInWithPassword',Re(_0x245b3c,_0x5a521b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x377dae,_0x13adfd){return Yt(_0x377dae,'POST','/v1/accounts:signInWithEmailLink',Re(_0x377dae,_0x13adfd));}async function Hf(_0x30f480,_0x18628d){return Yt(_0x30f480,'POST','/v1/accounts:signInWithEmailLink',Re(_0x30f480,_0x18628d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x22c423,_0x421cb2,_0x20d8a4,_0xe46e1f=null){super('password',_0x20d8a4),this['_email']=_0x22c423,this['_password']=_0x421cb2,this['_tenantId']=_0xe46e1f;}static['_fromEmailAndPassword'](_0x553811,_0x52fab5){return new Ft(_0x553811,_0x52fab5,'password');}static['_fromEmailAndCode'](_0x319c6a,_0x398028,_0x2109f7=null){return new Ft(_0x319c6a,_0x398028,'emailLink',_0x2109f7);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x891edb){const _0x50e1ee=typeof _0x891edb=='string'?JSON['parse'](_0x891edb):_0x891edb;if(_0x50e1ee!=null&&_0x50e1ee['email']&&(_0x50e1ee!=null&&_0x50e1ee['password'])){if(_0x50e1ee['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x50e1ee['email'],_0x50e1ee['password']);if(_0x50e1ee['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x50e1ee['email'],_0x50e1ee['password'],_0x50e1ee['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3fefdc){switch(this['signInMethod']){case'password':const _0x564b6c={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3fefdc,_0x564b6c,'signInWithPassword',Bf);case'emailLink':return Vf(_0x3fefdc,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x3fefdc,'internal-error');}}async['_linkToIdToken'](_0x1750b7,_0x2cd8c3){switch(this['signInMethod']){case'password':const _0x1f12d1={'idToken':_0x2cd8c3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1750b7,_0x1f12d1,'signUpPassword',Wf);case'emailLink':return Hf(_0x1750b7,{'idToken':_0x2cd8c3,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1750b7,'internal-error');}}['_getReauthenticationResolver'](_0x3d4f8b){return this['_getIdTokenResponse'](_0x3d4f8b);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4152cf,_0x35a5f4){return Yt(_0x4152cf,'POST','/v1/accounts:signInWithIdp',Re(_0x4152cf,_0x35a5f4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4eb5bb){const _0x15645b=new We(_0x4eb5bb['providerId'],_0x4eb5bb['signInMethod']);return _0x4eb5bb['idToken']||_0x4eb5bb['accessToken']?(_0x4eb5bb['idToken']&&(_0x15645b['idToken']=_0x4eb5bb['idToken']),_0x4eb5bb['accessToken']&&(_0x15645b['accessToken']=_0x4eb5bb['accessToken']),_0x4eb5bb['nonce']&&!_0x4eb5bb['pendingToken']&&(_0x15645b['nonce']=_0x4eb5bb['nonce']),_0x4eb5bb['pendingToken']&&(_0x15645b['pendingToken']=_0x4eb5bb['pendingToken'])):_0x4eb5bb['oauthToken']&&_0x4eb5bb['oauthTokenSecret']?(_0x15645b['accessToken']=_0x4eb5bb['oauthToken'],_0x15645b['secret']=_0x4eb5bb['oauthTokenSecret']):K('argument-error'),_0x15645b;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2c20fd){const _0x17cd88=typeof _0x2c20fd=='string'?JSON['parse'](_0x2c20fd):_0x2c20fd,{providerId:_0x5f465c,signInMethod:_0x1d3ddb,..._0x569575}=_0x17cd88;if(!_0x5f465c||!_0x1d3ddb)return null;const _0x21a575=new We(_0x5f465c,_0x1d3ddb);return _0x21a575['idToken']=_0x569575['idToken']||void 0x0,_0x21a575['accessToken']=_0x569575['accessToken']||void 0x0,_0x21a575['secret']=_0x569575['secret'],_0x21a575['nonce']=_0x569575['nonce'],_0x21a575['pendingToken']=_0x569575['pendingToken']||null,_0x21a575;}['_getIdTokenResponse'](_0x1ce6eb){const _0x3cca85=this['buildRequest']();return Ze(_0x1ce6eb,_0x3cca85);}['_linkToIdToken'](_0x2fe704,_0x192116){const _0x2b6756=this['buildRequest']();return _0x2b6756['idToken']=_0x192116,Ze(_0x2fe704,_0x2b6756);}['_getReauthenticationResolver'](_0x4e9ee9){const _0x4310a1=this['buildRequest']();return _0x4310a1['autoCreate']=!0x1,Ze(_0x4e9ee9,_0x4310a1);}['buildRequest'](){const _0x12087c={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x12087c['pendingToken']=this['pendingToken'];else{const _0x5e4fe5={};this['idToken']&&(_0x5e4fe5['id_token']=this['idToken']),this['accessToken']&&(_0x5e4fe5['access_token']=this['accessToken']),this['secret']&&(_0x5e4fe5['oauth_token_secret']=this['secret']),_0x5e4fe5['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5e4fe5['nonce']=this['nonce']),_0x12087c['postBody']=at(_0x5e4fe5);}return _0x12087c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1ca036){switch(_0x1ca036){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x45ff10){const _0x2e8652=yt(vt(_0x45ff10))['link'],_0x5c262d=_0x2e8652?yt(vt(_0x2e8652))['deep_link_id']:null,_0xc3f886=yt(vt(_0x45ff10))['deep_link_id'];return(_0xc3f886?yt(vt(_0xc3f886))['link']:null)||_0xc3f886||_0x5c262d||_0x2e8652||_0x45ff10;}class Ss{constructor(_0x1f14a0){const _0x3782c1=yt(vt(_0x1f14a0)),_0x263b80=_0x3782c1['apiKey']??null,_0x2c1be7=_0x3782c1['oobCode']??null,_0xc8b285=Gf(_0x3782c1['mode']??null);m(_0x263b80&&_0x2c1be7&&_0xc8b285,'argument-error'),this['apiKey']=_0x263b80,this['operation']=_0xc8b285,this['code']=_0x2c1be7,this['continueUrl']=_0x3782c1['continueUrl']??null,this['languageCode']=_0x3782c1['lang']??null,this['tenantId']=_0x3782c1['tenantId']??null;}static['parseLink'](_0x453d69){const _0x1f6238=qf(_0x453d69);try{return new Ss(_0x1f6238);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x3c7143,_0xc4380e){return Ft['_fromEmailAndPassword'](_0x3c7143,_0xc4380e);}static['credentialWithLink'](_0x3df219,_0x429e28){const _0x56cd90=Ss['parseLink'](_0x429e28);return m(_0x56cd90,'argument-error'),Ft['_fromEmailAndCode'](_0x3df219,_0x56cd90['code'],_0x56cd90['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x2b909c){this['providerId']=_0x2b909c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x48027d){this['defaultLanguageCode']=_0x48027d;}['setCustomParameters'](_0x35b090){return this['customParameters']=_0x35b090,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1de77a){return this['scopes']['includes'](_0x1de77a)||this['scopes']['push'](_0x1de77a),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xee990){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xee990});}static['credentialFromResult'](_0x1c3b7f){return he['credentialFromTaggedObject'](_0x1c3b7f);}static['credentialFromError'](_0x35c09a){return he['credentialFromTaggedObject'](_0x35c09a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x689b42}){if(!_0x689b42||!('oauthAccessToken'in _0x689b42)||!_0x689b42['oauthAccessToken'])return null;try{return he['credential'](_0x689b42['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2550fa,_0x565f34){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2550fa,'accessToken':_0x565f34});}static['credentialFromResult'](_0x116f33){return ue['credentialFromTaggedObject'](_0x116f33);}static['credentialFromError'](_0x179a41){return ue['credentialFromTaggedObject'](_0x179a41['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x194085}){if(!_0x194085)return null;const {oauthIdToken:_0x4db58d,oauthAccessToken:_0x3bb06d}=_0x194085;if(!_0x4db58d&&!_0x3bb06d)return null;try{return ue['credential'](_0x4db58d,_0x3bb06d);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xf3c80e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xf3c80e});}static['credentialFromResult'](_0x362452){return de['credentialFromTaggedObject'](_0x362452);}static['credentialFromError'](_0x15c595){return de['credentialFromTaggedObject'](_0x15c595['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4412e0}){if(!_0x4412e0||!('oauthAccessToken'in _0x4412e0)||!_0x4412e0['oauthAccessToken'])return null;try{return de['credential'](_0x4412e0['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x47d01a,_0x1fceea){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x47d01a,'oauthTokenSecret':_0x1fceea});}static['credentialFromResult'](_0x2ec61d){return fe['credentialFromTaggedObject'](_0x2ec61d);}static['credentialFromError'](_0x5a6bbe){return fe['credentialFromTaggedObject'](_0x5a6bbe['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x44722b}){if(!_0x44722b)return null;const {oauthAccessToken:_0x1432e5,oauthTokenSecret:_0x1929be}=_0x44722b;if(!_0x1432e5||!_0x1929be)return null;try{return fe['credential'](_0x1432e5,_0x1929be);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x279b4f,_0x4b8450){return Yt(_0x279b4f,'POST','/v1/accounts:signUp',Re(_0x279b4f,_0x4b8450));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xd6f79f){this['user']=_0xd6f79f['user'],this['providerId']=_0xd6f79f['providerId'],this['_tokenResponse']=_0xd6f79f['_tokenResponse'],this['operationType']=_0xd6f79f['operationType'];}static async['_fromIdTokenResponse'](_0x354487,_0x445cda,_0x320fdd,_0x4fd5f4=!0x1){const _0x44f20d=await z['_fromIdTokenResponse'](_0x354487,_0x320fdd,_0x4fd5f4),_0x378c37=Ar(_0x320fdd);return new Be({'user':_0x44f20d,'providerId':_0x378c37,'_tokenResponse':_0x320fdd,'operationType':_0x445cda});}static async['_forOperation'](_0x213304,_0x4f087f,_0x5721ae){await _0x213304['_updateTokensIfNecessary'](_0x5721ae,!0x0);const _0xc88ff=Ar(_0x5721ae);return new Be({'user':_0x213304,'providerId':_0xc88ff,'_tokenResponse':_0x5721ae,'operationType':_0x4f087f});}}function Ar(_0x37f79c){return _0x37f79c['providerId']?_0x37f79c['providerId']:'phoneNumber'in _0x37f79c?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xc85f45,_0x17a770,_0x352386,_0x5a3b06){super(_0x17a770['code'],_0x17a770['message']),this['operationType']=_0x352386,this['user']=_0x5a3b06,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xc85f45['name'],'tenantId':_0xc85f45['tenantId']??void 0x0,'_serverResponse':_0x17a770['customData']['_serverResponse'],'operationType':_0x352386};}static['_fromErrorAndOperation'](_0xf2bcc,_0x159203,_0x374b43,_0x1fde7e){return new Rn(_0xf2bcc,_0x159203,_0x374b43,_0x1fde7e);}}function Fa(_0x47b50c,_0x12067d,_0xbc0ec0,_0x4935c4){return(_0x12067d==='reauthenticate'?_0xbc0ec0['_getReauthenticationResolver'](_0x47b50c):_0xbc0ec0['_getIdTokenResponse'](_0x47b50c))['catch'](_0x5b9de6=>{throw _0x5b9de6['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x47b50c,_0x5b9de6,_0x12067d,_0x4935c4):_0x5b9de6;});}async function jf(_0x49bd34,_0x175f39,_0x20cc6c=!0x1){const _0x5ea594=await xt(_0x49bd34,_0x175f39['_linkToIdToken'](_0x49bd34['auth'],await _0x49bd34['getIdToken']()),_0x20cc6c);return Be['_forOperation'](_0x49bd34,'link',_0x5ea594);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xf82b16,_0x4f10f7,_0x3c9c79=!0x1){const {auth:_0x5baf7a}=_0xf82b16;if(H(_0x5baf7a['app']))return Promise['reject'](se(_0x5baf7a));const _0x440dd6='reauthenticate';try{const _0x171e51=await xt(_0xf82b16,Fa(_0x5baf7a,_0x440dd6,_0x4f10f7,_0xf82b16),_0x3c9c79);m(_0x171e51['idToken'],_0x5baf7a,'internal-error');const _0x4e18fc=ws(_0x171e51['idToken']);m(_0x4e18fc,_0x5baf7a,'internal-error');const {sub:_0x412d2e}=_0x4e18fc;return m(_0xf82b16['uid']===_0x412d2e,_0x5baf7a,'user-mismatch'),Be['_forOperation'](_0xf82b16,_0x440dd6,_0x171e51);}catch(_0x4f038b){throw(_0x4f038b==null?void 0x0:_0x4f038b['code'])==='auth/user-not-found'&&K(_0x5baf7a,'user-mismatch'),_0x4f038b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x148865,_0x27f035,_0x3e0d83=!0x1){if(H(_0x148865['app']))return Promise['reject'](se(_0x148865));const _0x32b95d='signIn',_0x13dd26=await Fa(_0x148865,_0x32b95d,_0x27f035),_0x5956a3=await Be['_fromIdTokenResponse'](_0x148865,_0x32b95d,_0x13dd26);return _0x3e0d83||await _0x148865['_updateCurrentUser'](_0x5956a3['user']),_0x5956a3;}async function Yf(_0x3484df,_0xc745d7){return Ua(qe(_0x3484df),_0xc745d7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x43cfcc){const _0x740c3e=qe(_0x43cfcc);_0x740c3e['_getPasswordPolicyInternal']()&&await _0x740c3e['_updatePasswordPolicy']();}async function R_(_0x4b678f,_0x3074bf,_0xbfe572){if(H(_0x4b678f['app']))return Promise['reject'](se(_0x4b678f));const _0x12baeb=qe(_0x4b678f),_0x3e8545=await Oi(_0x12baeb,{'returnSecureToken':!0x0,'email':_0x3074bf,'password':_0xbfe572,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x4f7d0e=>{throw _0x4f7d0e['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4b678f),_0x4f7d0e;}),_0x50e0d5=await Be['_fromIdTokenResponse'](_0x12baeb,'signIn',_0x3e8545);return await _0x12baeb['_updateCurrentUser'](_0x50e0d5['user']),_0x50e0d5;}function A_(_0xabb741,_0x1ae2f7,_0x5daefa){return H(_0xabb741['app'])?Promise['reject'](se(_0xabb741)):Yf(k(_0xabb741),ft['credential'](_0x1ae2f7,_0x5daefa))['catch'](async _0x46ef62=>{throw _0x46ef62['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xabb741),_0x46ef62;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x3fbc39,_0x131dbe){return k(_0x3fbc39)['setPersistence'](_0x131dbe);}function Qf(_0x25366b,_0x5979bc,_0x57eba1,_0xad8a79){return k(_0x25366b)['onIdTokenChanged'](_0x5979bc,_0x57eba1,_0xad8a79);}function Jf(_0x315b95,_0x302b97,_0x5ab7d7){return k(_0x315b95)['beforeAuthStateChanged'](_0x302b97,_0x5ab7d7);}function N_(_0x12751b,_0x43766c,_0x29d686,_0x147221){return k(_0x12751b)['onAuthStateChanged'](_0x43766c,_0x29d686,_0x147221);}function P_(_0x54b5e1){return k(_0x54b5e1)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xc4fa24,_0x17fa66){this['storageRetriever']=_0xc4fa24,this['type']=_0x17fa66;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xb2a05b,_0x3af548){return this['storage']['setItem'](_0xb2a05b,JSON['stringify'](_0x3af548)),Promise['resolve']();}['_get'](_0x341ccc){const _0x310404=this['storage']['getItem'](_0x341ccc);return Promise['resolve'](_0x310404?JSON['parse'](_0x310404):null);}['_remove'](_0x3fabb3){return this['storage']['removeItem'](_0x3fabb3),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4263af,_0x2d780f)=>this['onStorageEvent'](_0x4263af,_0x2d780f),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1be6a3){for(const _0x255405 of Object['keys'](this['listeners'])){const _0x3e51cb=this['storage']['getItem'](_0x255405),_0x4bfb79=this['localCache'][_0x255405];_0x3e51cb!==_0x4bfb79&&_0x1be6a3(_0x255405,_0x4bfb79,_0x3e51cb);}}['onStorageEvent'](_0x29b0b3,_0x4bf1e0=!0x1){if(!_0x29b0b3['key']){this['forAllChangedKeys']((_0x30439a,_0xe62e3f,_0xd30a5f)=>{this['notifyListeners'](_0x30439a,_0xd30a5f);});return;}const _0x40bdf6=_0x29b0b3['key'];_0x4bf1e0?this['detachListener']():this['stopPolling']();const _0x47d0da=()=>{const _0x5d7e34=this['storage']['getItem'](_0x40bdf6);!_0x4bf1e0&&this['localCache'][_0x40bdf6]===_0x5d7e34||this['notifyListeners'](_0x40bdf6,_0x5d7e34);},_0x3b1753=this['storage']['getItem'](_0x40bdf6);If()&&_0x3b1753!==_0x29b0b3['newValue']&&_0x29b0b3['newValue']!==_0x29b0b3['oldValue']?setTimeout(_0x47d0da,Zf):_0x47d0da();}['notifyListeners'](_0x5763fd,_0x21fb94){this['localCache'][_0x5763fd]=_0x21fb94;const _0x4f6560=this['listeners'][_0x5763fd];if(_0x4f6560){for(const _0x10930a of Array['from'](_0x4f6560))_0x10930a(_0x21fb94&&JSON['parse'](_0x21fb94));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1f5799,_0x98d935,_0x1afd3c)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1f5799,'oldValue':_0x98d935,'newValue':_0x1afd3c}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x39b8b8,_0x40a966){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x39b8b8]||(this['listeners'][_0x39b8b8]=new Set(),this['localCache'][_0x39b8b8]=this['storage']['getItem'](_0x39b8b8)),this['listeners'][_0x39b8b8]['add'](_0x40a966);}['_removeListener'](_0x3e0896,_0x1fbdaa){this['listeners'][_0x3e0896]&&(this['listeners'][_0x3e0896]['delete'](_0x1fbdaa),this['listeners'][_0x3e0896]['size']===0x0&&delete this['listeners'][_0x3e0896]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x44db71,_0x51a155){await super['_set'](_0x44db71,_0x51a155),this['localCache'][_0x44db71]=JSON['stringify'](_0x51a155);}async['_get'](_0x5dab4){const _0x43b605=await super['_get'](_0x5dab4);return this['localCache'][_0x5dab4]=JSON['stringify'](_0x43b605),_0x43b605;}async['_remove'](_0x44dc9e){await super['_remove'](_0x44dc9e),delete this['localCache'][_0x44dc9e];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x122e1a,_0x278a43){}['_removeListener'](_0x1c7a28,_0x44983e){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4b720d){return Promise['all'](_0x4b720d['map'](async _0x463834=>{try{return{'fulfilled':!0x0,'value':await _0x463834};}catch(_0x493531){return{'fulfilled':!0x1,'reason':_0x493531};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x46fedb){this['eventTarget']=_0x46fedb,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x39faac){const _0x528240=this['receivers']['find'](_0x291493=>_0x291493['isListeningto'](_0x39faac));if(_0x528240)return _0x528240;const _0x5a7a6f=new jn(_0x39faac);return this['receivers']['push'](_0x5a7a6f),_0x5a7a6f;}['isListeningto'](_0x47d7de){return this['eventTarget']===_0x47d7de;}async['handleEvent'](_0xc2d12){const _0x5b2d99=_0xc2d12,{eventId:_0x93b729,eventType:_0x4b8363,data:_0x380b21}=_0x5b2d99['data'],_0x5d2e97=this['handlersMap'][_0x4b8363];if(!(_0x5d2e97!=null&&_0x5d2e97['size']))return;_0x5b2d99['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x93b729,'eventType':_0x4b8363});const _0xef5c86=Array['from'](_0x5d2e97)['map'](async _0x26d5aa=>_0x26d5aa(_0x5b2d99['origin'],_0x380b21)),_0x11b0e5=await tp(_0xef5c86);_0x5b2d99['ports'][0x0]['postMessage']({'status':'done','eventId':_0x93b729,'eventType':_0x4b8363,'response':_0x11b0e5});}['_subscribe'](_0x453120,_0x357d6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x453120]||(this['handlersMap'][_0x453120]=new Set()),this['handlersMap'][_0x453120]['add'](_0x357d6);}['_unsubscribe'](_0x4e5072,_0x5bdfea){this['handlersMap'][_0x4e5072]&&_0x5bdfea&&this['handlersMap'][_0x4e5072]['delete'](_0x5bdfea),(!_0x5bdfea||this['handlersMap'][_0x4e5072]['size']===0x0)&&delete this['handlersMap'][_0x4e5072],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x1f269d='',_0xd794a0=0xa){let _0x419cdd='';for(let _0x354df3=0x0;_0x354df3<_0xd794a0;_0x354df3++)_0x419cdd+=Math['floor'](Math['random']()*0xa);return _0x1f269d+_0x419cdd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x347db8){this['target']=_0x347db8,this['handlers']=new Set();}['removeMessageHandler'](_0x34feba){_0x34feba['messageChannel']&&(_0x34feba['messageChannel']['port1']['removeEventListener']('message',_0x34feba['onMessage']),_0x34feba['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x34feba);}async['_send'](_0x57d04b,_0x2fdecb,_0x727cd6=0x32){const _0xd0cbbe=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xd0cbbe)throw new Error('connection_unavailable');let _0x4cf156,_0x3d060a;return new Promise((_0x539a2a,_0x32d40c)=>{const _0x448347=bs('',0x14);_0xd0cbbe['port1']['start']();const _0x128e86=setTimeout(()=>{_0x32d40c(new Error('unsupported_event'));},_0x727cd6);_0x3d060a={'messageChannel':_0xd0cbbe,'onMessage'(_0x1fac54){const _0xf4d045=_0x1fac54;if(_0xf4d045['data']['eventId']===_0x448347)switch(_0xf4d045['data']['status']){case'ack':clearTimeout(_0x128e86),_0x4cf156=setTimeout(()=>{_0x32d40c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4cf156),_0x539a2a(_0xf4d045['data']['response']);break;default:clearTimeout(_0x128e86),clearTimeout(_0x4cf156),_0x32d40c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3d060a),_0xd0cbbe['port1']['addEventListener']('message',_0x3d060a['onMessage']),this['target']['postMessage']({'eventType':_0x57d04b,'eventId':_0x448347,'data':_0x2fdecb},[_0xd0cbbe['port2']]);})['finally'](()=>{_0x3d060a&&this['removeMessageHandler'](_0x3d060a);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x1dfe8e){X()['location']['href']=_0x1dfe8e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x1ffe84;return((_0x1ffe84=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1ffe84['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3c9af9){this['request']=_0x3c9af9;}['toPromise'](){return new Promise((_0x2fbc99,_0x297b45)=>{this['request']['addEventListener']('success',()=>{_0x2fbc99(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x297b45(this['request']['error']);});});}}function Kn(_0x3499e7,_0x445acb){return _0x3499e7['transaction']([kn],_0x445acb?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x10434e=indexedDB['deleteDatabase'](qa);return new Jt(_0x10434e)['toPromise']();}function ja(){const _0x388ad4=indexedDB['open'](qa,ap);return new Promise((_0x50702a,_0x26850a)=>{_0x388ad4['addEventListener']('error',()=>{_0x26850a(_0x388ad4['error']);}),_0x388ad4['addEventListener']('upgradeneeded',()=>{const _0x3f9c7d=_0x388ad4['result'];try{_0x3f9c7d['createObjectStore'](kn,{'keyPath':za});}catch(_0x209e31){_0x26850a(_0x209e31);}}),_0x388ad4['addEventListener']('success',async()=>{const _0x463fe0=_0x388ad4['result'];_0x463fe0['objectStoreNames']['contains'](kn)?_0x50702a(_0x463fe0):(_0x463fe0['close'](),await cp(),_0x50702a(await ja()));});});}async function kr(_0x280801,_0x258ca3,_0x383f4b){const _0x5ee482=Kn(_0x280801,!0x0)['put']({[za]:_0x258ca3,'value':_0x383f4b});return new Jt(_0x5ee482)['toPromise']();}async function lp(_0x39d644,_0x3f8844){const _0x55a21d=Kn(_0x39d644,!0x1)['get'](_0x3f8844),_0x1e04d7=await new Jt(_0x55a21d)['toPromise']();return _0x1e04d7===void 0x0?null:_0x1e04d7['value'];}function Nr(_0x1c325a,_0x2dc592){const _0x51da12=Kn(_0x1c325a,!0x0)['delete'](_0x2dc592);return new Jt(_0x51da12)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x268bfb){let _0x54b5b3=0x0;for(;;)try{const _0x5c13ee=await this['_openDb']();return await _0x268bfb(_0x5c13ee);}catch(_0x435557){if(_0x54b5b3++>up)throw _0x435557;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1e65a5,_0x46352c)=>({'keyProcessed':(await this['_poll']())['includes'](_0x46352c['key'])})),this['receiver']['_subscribe']('ping',async(_0x297349,_0x3dac6b)=>['keyChanged']);}async['initializeSender'](){var _0x366c3c,_0x11de14;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x10cef1=await this['sender']['_send']('ping',{},0x320);_0x10cef1&&(_0x366c3c=_0x10cef1[0x0])!=null&&_0x366c3c['fulfilled']&&(_0x11de14=_0x10cef1[0x0])!=null&&_0x11de14['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4d4070){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4d4070},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x173926=>{await kr(_0x173926,An,'1'),await Nr(_0x173926,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x473d87){this['pendingWrites']++;try{await _0x473d87();}finally{this['pendingWrites']--;}}async['_set'](_0x199fc6,_0x582383){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xdf6223=>kr(_0xdf6223,_0x199fc6,_0x582383)),this['localCache'][_0x199fc6]=_0x582383,this['notifyServiceWorker'](_0x199fc6)));}async['_get'](_0x404285){const _0x2f23aa=await this['_withRetries'](_0x262f7e=>lp(_0x262f7e,_0x404285));return this['localCache'][_0x404285]=_0x2f23aa,_0x2f23aa;}async['_remove'](_0x2b24ac){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x43eed6=>Nr(_0x43eed6,_0x2b24ac)),delete this['localCache'][_0x2b24ac],this['notifyServiceWorker'](_0x2b24ac)));}async['_poll'](){const _0x3927b1=await this['_withRetries'](_0x318508=>{const _0x2accf4=Kn(_0x318508,!0x1)['getAll']();return new Jt(_0x2accf4)['toPromise']();});if(!_0x3927b1)return[];if(this['pendingWrites']!==0x0)return[];const _0x852633=[],_0x39c086=new Set();if(_0x3927b1['length']!==0x0){for(const {fbase_key:_0x1296f3,value:_0x1f2c06}of _0x3927b1)_0x39c086['add'](_0x1296f3),JSON['stringify'](this['localCache'][_0x1296f3])!==JSON['stringify'](_0x1f2c06)&&(this['notifyListeners'](_0x1296f3,_0x1f2c06),_0x852633['push'](_0x1296f3));}for(const _0x38862e of Object['keys'](this['localCache']))this['localCache'][_0x38862e]&&!_0x39c086['has'](_0x38862e)&&(this['notifyListeners'](_0x38862e,null),_0x852633['push'](_0x38862e));return _0x852633;}['notifyListeners'](_0x51765e,_0x499744){this['localCache'][_0x51765e]=_0x499744;const _0x6d87d5=this['listeners'][_0x51765e];if(_0x6d87d5){for(const _0x4b85b9 of Array['from'](_0x6d87d5))_0x4b85b9(_0x499744);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x51787e,_0x218b51){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x51787e]||(this['listeners'][_0x51787e]=new Set(),this['_get'](_0x51787e)),this['listeners'][_0x51787e]['add'](_0x218b51);}['_removeListener'](_0x313862,_0x47860a){this['listeners'][_0x313862]&&(this['listeners'][_0x313862]['delete'](_0x47860a),this['listeners'][_0x313862]['size']===0x0&&delete this['listeners'][_0x313862]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x38279e,_0x5b8bd7){return _0x5b8bd7?ne(_0x5b8bd7):(m(_0x38279e['_popupRedirectResolver'],_0x38279e,'argument-error'),_0x38279e['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2c9c03){super('custom','custom'),this['params']=_0x2c9c03;}['_getIdTokenResponse'](_0x2dde7a){return Ze(_0x2dde7a,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4ddd7a,_0x212866){return Ze(_0x4ddd7a,this['_buildIdpRequest'](_0x212866));}['_getReauthenticationResolver'](_0x593255){return Ze(_0x593255,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x361819){const _0x59c50d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x361819&&(_0x59c50d['idToken']=_0x361819),_0x59c50d;}}function pp(_0x2fd8c0){return Ua(_0x2fd8c0['auth'],new Rs(_0x2fd8c0),_0x2fd8c0['bypassAuthState']);}function _p(_0x44c637){const {auth:_0x3ebaea,user:_0x430ac2}=_0x44c637;return m(_0x430ac2,_0x3ebaea,'internal-error'),Kf(_0x430ac2,new Rs(_0x44c637),_0x44c637['bypassAuthState']);}async function gp(_0x23184a){const {auth:_0x140e7d,user:_0x5c5667}=_0x23184a;return m(_0x5c5667,_0x140e7d,'internal-error'),jf(_0x5c5667,new Rs(_0x23184a),_0x23184a['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2502bd,_0x101c0a,_0x34062f,_0x514c32,_0x3a3403=!0x1){this['auth']=_0x2502bd,this['resolver']=_0x34062f,this['user']=_0x514c32,this['bypassAuthState']=_0x3a3403,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x101c0a)?_0x101c0a:[_0x101c0a];}['execute'](){return new Promise(async(_0x46b850,_0x23e694)=>{this['pendingPromise']={'resolve':_0x46b850,'reject':_0x23e694};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x111edb){this['reject'](_0x111edb);}});}async['onAuthEvent'](_0x521fd7){const {urlResponse:_0x537b7e,sessionId:_0xcc19b0,postBody:_0x308c4c,tenantId:_0x180afb,error:_0x4fc225,type:_0x4b4243}=_0x521fd7;if(_0x4fc225){this['reject'](_0x4fc225);return;}const _0x3cead6={'auth':this['auth'],'requestUri':_0x537b7e,'sessionId':_0xcc19b0,'tenantId':_0x180afb||void 0x0,'postBody':_0x308c4c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4b4243)(_0x3cead6));}catch(_0x52b008){this['reject'](_0x52b008);}}['onError'](_0x299f8d){this['reject'](_0x299f8d);}['getIdpTask'](_0x303e1e){switch(_0x303e1e){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x479a63){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x479a63),this['unregisterAndCleanUp']();}['reject'](_0x1aaceb){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1aaceb),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1c37d4,_0x2d9d13,_0x23304e,_0x113c02,_0x1c5929){super(_0x1c37d4,_0x2d9d13,_0x113c02,_0x1c5929),this['provider']=_0x23304e,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x15078a=await this['execute']();return m(_0x15078a,this['auth'],'internal-error'),_0x15078a;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3c5e3a=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3c5e3a),this['authWindow']['associatedEvent']=_0x3c5e3a,this['resolver']['_originValidation'](this['auth'])['catch'](_0x56bdfa=>{this['reject'](_0x56bdfa);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x37bd31=>{_0x37bd31||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5512d5;return((_0x5512d5=this['authWindow'])==null?void 0x0:_0x5512d5['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3a0b6c=()=>{var _0x25e4f0,_0x32a1d9;if((_0x32a1d9=(_0x25e4f0=this['authWindow'])==null?void 0x0:_0x25e4f0['window'])!=null&&_0x32a1d9['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3a0b6c,mp['get']());};_0x3a0b6c();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x246c4a,_0x27d0ec,_0x5326fc=!0x1){super(_0x246c4a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x27d0ec,void 0x0,_0x5326fc),this['eventId']=null;}async['execute'](){let _0x19e69d=rn['get'](this['auth']['_key']());if(!_0x19e69d){try{const _0x45320d=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x19e69d=()=>Promise['resolve'](_0x45320d);}catch(_0xc07d34){_0x19e69d=()=>Promise['reject'](_0xc07d34);}rn['set'](this['auth']['_key'](),_0x19e69d);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x19e69d();}async['onAuthEvent'](_0x52654c){if(_0x52654c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x52654c);if(_0x52654c['type']==='unknown'){this['resolve'](null);return;}if(_0x52654c['eventId']){const _0x509325=await this['auth']['_redirectUserForId'](_0x52654c['eventId']);if(_0x509325)return this['user']=_0x509325,super['onAuthEvent'](_0x52654c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x416ab8,_0x481e8f){const _0xb15212=Cp(_0x481e8f),_0xf9ac6=wp(_0x416ab8);if(!await _0xf9ac6['_isAvailable']())return!0x1;const _0x15eab8=await _0xf9ac6['_get'](_0xb15212)==='true';return await _0xf9ac6['_remove'](_0xb15212),_0x15eab8;}function Ip(_0x4e3bc2,_0x38aff0){rn['set'](_0x4e3bc2['_key'](),_0x38aff0);}function wp(_0x5e8ddb){return ne(_0x5e8ddb['_redirectPersistence']);}function Cp(_0x53efc9){return sn(yp,_0x53efc9['config']['apiKey'],_0x53efc9['name']);}async function Tp(_0x9cfbdc,_0x31652b,_0x225b5d=!0x1){if(H(_0x9cfbdc['app']))return Promise['reject'](se(_0x9cfbdc));const _0xb37225=qe(_0x9cfbdc),_0x12ed83=fp(_0xb37225,_0x31652b),_0x1ad820=await new vp(_0xb37225,_0x12ed83,_0x225b5d)['execute']();return _0x1ad820&&!_0x225b5d&&(delete _0x1ad820['user']['_redirectEventId'],await _0xb37225['_persistUserIfCurrent'](_0x1ad820['user']),await _0xb37225['_setRedirectUser'](null,_0x31652b)),_0x1ad820;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x12015a){this['auth']=_0x12015a,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x142671){this['consumers']['add'](_0x142671),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x142671)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x142671),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x38f897){this['consumers']['delete'](_0x38f897);}['onEvent'](_0x33ca7f){if(this['hasEventBeenHandled'](_0x33ca7f))return!0x1;let _0x1b8675=!0x1;return this['consumers']['forEach'](_0x3a8050=>{this['isEventForConsumer'](_0x33ca7f,_0x3a8050)&&(_0x1b8675=!0x0,this['sendToConsumer'](_0x33ca7f,_0x3a8050),this['saveEventToCache'](_0x33ca7f));}),this['hasHandledPotentialRedirect']||!Rp(_0x33ca7f)||(this['hasHandledPotentialRedirect']=!0x0,_0x1b8675||(this['queuedRedirectEvent']=_0x33ca7f,_0x1b8675=!0x0)),_0x1b8675;}['sendToConsumer'](_0x7035ba,_0x18f315){var _0xc18614;if(_0x7035ba['error']&&!Qa(_0x7035ba)){const _0x17d196=((_0xc18614=_0x7035ba['error']['code'])==null?void 0x0:_0xc18614['split']('auth/')[0x1])||'internal-error';_0x18f315['onError'](J(this['auth'],_0x17d196));}else _0x18f315['onAuthEvent'](_0x7035ba);}['isEventForConsumer'](_0x2aaf90,_0x428416){const _0x461b42=_0x428416['eventId']===null||!!_0x2aaf90['eventId']&&_0x2aaf90['eventId']===_0x428416['eventId'];return _0x428416['filter']['includes'](_0x2aaf90['type'])&&_0x461b42;}['hasEventBeenHandled'](_0x607e8c){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x607e8c));}['saveEventToCache'](_0x3e51e1){this['cachedEventUids']['add'](Pr(_0x3e51e1)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x24da1c){return[_0x24da1c['type'],_0x24da1c['eventId'],_0x24da1c['sessionId'],_0x24da1c['tenantId']]['filter'](_0x5b91b2=>_0x5b91b2)['join']('-');}function Qa({type:_0x31c132,error:_0xfb7e81}){return _0x31c132==='unknown'&&(_0xfb7e81==null?void 0x0:_0xfb7e81['code'])==='auth/no-auth-event';}function Rp(_0x322cd3){switch(_0x322cd3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x322cd3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x5a5fa4,_0x34fbb1={}){return Ae(_0x5a5fa4,'GET','/v1/projects',_0x34fbb1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3714ac){if(_0x3714ac['config']['emulator'])return;const {authorizedDomains:_0x4c5246}=await Ap(_0x3714ac);for(const _0x4d41f8 of _0x4c5246)try{if(Op(_0x4d41f8))return;}catch{}K(_0x3714ac,'unauthorized-domain');}function Op(_0x1b6f04){const _0x478859=Ni(),{protocol:_0x5a8456,hostname:_0x5a61ce}=new URL(_0x478859);if(_0x1b6f04['startsWith']('chrome-extension://')){const _0x3a48a0=new URL(_0x1b6f04);return _0x3a48a0['hostname']===''&&_0x5a61ce===''?_0x5a8456==='chrome-extension:'&&_0x1b6f04['replace']('chrome-extension://','')===_0x478859['replace']('chrome-extension://',''):_0x5a8456==='chrome-extension:'&&_0x3a48a0['hostname']===_0x5a61ce;}if(!Np['test'](_0x5a8456))return!0x1;if(kp['test'](_0x1b6f04))return _0x5a61ce===_0x1b6f04;const _0x64a514=_0x1b6f04['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x64a514+'|'+_0x64a514+')$','i')['test'](_0x5a61ce);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x58e8a8=X()['___jsl'];if(_0x58e8a8!=null&&_0x58e8a8['H']){for(const _0xf9f493 of Object['keys'](_0x58e8a8['H']))if(_0x58e8a8['H'][_0xf9f493]['r']=_0x58e8a8['H'][_0xf9f493]['r']||[],_0x58e8a8['H'][_0xf9f493]['L']=_0x58e8a8['H'][_0xf9f493]['L']||[],_0x58e8a8['H'][_0xf9f493]['r']=[..._0x58e8a8['H'][_0xf9f493]['L']],_0x58e8a8['CP']){for(let _0x1f330c=0x0;_0x1f330c<_0x58e8a8['CP']['length'];_0x1f330c++)_0x58e8a8['CP'][_0x1f330c]=null;}}}function Mp(_0x1a04ae){return new Promise((_0x34a590,_0x361ccb)=>{var _0x477ce1,_0x589286,_0x537971;function _0x128c5b(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x34a590(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x361ccb(J(_0x1a04ae,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x589286=(_0x477ce1=X()['gapi'])==null?void 0x0:_0x477ce1['iframes'])!=null&&_0x589286['Iframe'])_0x34a590(gapi['iframes']['getContext']());else{if((_0x537971=X()['gapi'])!=null&&_0x537971['load'])_0x128c5b();else{const _0x1aa5fd=Nf('iframefcb');return X()[_0x1aa5fd]=()=>{gapi['load']?_0x128c5b():_0x361ccb(J(_0x1a04ae,'network-request-failed'));},Da(kf()+'?onload='+_0x1aa5fd)['catch'](_0x15b2bc=>_0x361ccb(_0x15b2bc));}}})['catch'](_0x13ced4=>{throw on=null,_0x13ced4;});}let on=null;function Lp(_0xec4b84){return on=on||Mp(_0xec4b84),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x2de3eb){const _0x17b0db=_0x2de3eb['config'];m(_0x17b0db['authDomain'],_0x2de3eb,'auth-domain-config-required');const _0x22960f=_0x17b0db['emulator']?Is(_0x17b0db,Up):'https://'+_0x2de3eb['config']['authDomain']+'/'+Fp,_0x197f16={'apiKey':_0x17b0db['apiKey'],'appName':_0x2de3eb['name'],'v':ct},_0x128673=Bp['get'](_0x2de3eb['config']['apiHost']);_0x128673&&(_0x197f16['eid']=_0x128673);const _0x2c7c16=_0x2de3eb['_getFrameworks']();return _0x2c7c16['length']&&(_0x197f16['fw']=_0x2c7c16['join'](',')),_0x22960f+'?'+at(_0x197f16)['slice'](0x1);}async function Hp(_0x1bd699){const _0xbfd770=await Lp(_0x1bd699),_0xc6bfdd=X()['gapi'];return m(_0xc6bfdd,_0x1bd699,'internal-error'),_0xbfd770['open']({'where':document['body'],'url':Vp(_0x1bd699),'messageHandlersFilter':_0xc6bfdd['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x1d08e8=>new Promise(async(_0x23f59a,_0x3c95f6)=>{await _0x1d08e8['restyle']({'setHideOnLeave':!0x1});const _0x570f82=J(_0x1bd699,'network-request-failed'),_0xea1614=X()['setTimeout'](()=>{_0x3c95f6(_0x570f82);},xp['get']());function _0x20a859(){X()['clearTimeout'](_0xea1614),_0x23f59a(_0x1d08e8);}_0x1d08e8['ping'](_0x20a859)['then'](_0x20a859,()=>{_0x3c95f6(_0x570f82);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x16e809){this['window']=_0x16e809,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x286c74,_0x4c39be,_0x1b58af,_0x215978=Gp,_0x266920=qp){const _0x13f5e5=Math['max']((window['screen']['availHeight']-_0x266920)/0x2,0x0)['toString'](),_0x4594be=Math['max']((window['screen']['availWidth']-_0x215978)/0x2,0x0)['toString']();let _0xdba439='';const _0x1c24f1={...$p,'width':_0x215978['toString'](),'height':_0x266920['toString'](),'top':_0x13f5e5,'left':_0x4594be},_0x6251d2=W()['toLowerCase']();_0x1b58af&&(_0xdba439=ba(_0x6251d2)?zp:_0x1b58af),Ta(_0x6251d2)&&(_0x4c39be=_0x4c39be||jp,_0x1c24f1['scrollbars']='yes');const _0x25a0f2=Object['entries'](_0x1c24f1)['reduce']((_0x2fd72e,[_0x300e66,_0x3999da])=>''+_0x2fd72e+_0x300e66+'='+_0x3999da+',','');if(Ef(_0x6251d2)&&_0xdba439!=='_self')return Yp(_0x4c39be||'',_0xdba439),new Dr(null);const _0x2ed3ef=window['open'](_0x4c39be||'',_0xdba439,_0x25a0f2);m(_0x2ed3ef,_0x286c74,'popup-blocked');try{_0x2ed3ef['focus']();}catch{}return new Dr(_0x2ed3ef);}function Yp(_0x2b18e0,_0x417f02){const _0x25e018=document['createElement']('a');_0x25e018['href']=_0x2b18e0,_0x25e018['target']=_0x417f02;const _0x34fd2b=document['createEvent']('MouseEvent');_0x34fd2b['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x25e018['dispatchEvent'](_0x34fd2b);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x184b0e,_0x128e94,_0x5003c4,_0xa71c65,_0xe2f90,_0x28773d){m(_0x184b0e['config']['authDomain'],_0x184b0e,'auth-domain-config-required'),m(_0x184b0e['config']['apiKey'],_0x184b0e,'invalid-api-key');const _0x3670bf={'apiKey':_0x184b0e['config']['apiKey'],'appName':_0x184b0e['name'],'authType':_0x5003c4,'redirectUrl':_0xa71c65,'v':ct,'eventId':_0xe2f90};if(_0x128e94 instanceof xa){_0x128e94['setDefaultLanguage'](_0x184b0e['languageCode']),_0x3670bf['providerId']=_0x128e94['providerId']||'',hi(_0x128e94['getCustomParameters']())||(_0x3670bf['customParameters']=JSON['stringify'](_0x128e94['getCustomParameters']()));for(const [_0x52bad2,_0x3071ee]of Object['entries']({}))_0x3670bf[_0x52bad2]=_0x3071ee;}if(_0x128e94 instanceof Qt){const _0x40df01=_0x128e94['getScopes']()['filter'](_0x503d80=>_0x503d80!=='');_0x40df01['length']>0x0&&(_0x3670bf['scopes']=_0x40df01['join'](','));}_0x184b0e['tenantId']&&(_0x3670bf['tid']=_0x184b0e['tenantId']);const _0x2dbf82=_0x3670bf;for(const _0x21af64 of Object['keys'](_0x2dbf82))_0x2dbf82[_0x21af64]===void 0x0&&delete _0x2dbf82[_0x21af64];const _0x3a28be=await _0x184b0e['_getAppCheckToken'](),_0x587d70=_0x3a28be?'#'+Xp+'='+encodeURIComponent(_0x3a28be):'';return Zp(_0x184b0e)+'?'+at(_0x2dbf82)['slice'](0x1)+_0x587d70;}function Zp({config:_0x4c8c87}){return _0x4c8c87['emulator']?Is(_0x4c8c87,Jp):'https://'+_0x4c8c87['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x3161cb,_0x48e6f4,_0xfb7bc1,_0x5069e5){var _0x1f8c3d;ae((_0x1f8c3d=this['eventManagers'][_0x3161cb['_key']()])==null?void 0x0:_0x1f8c3d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5973e2=await Mr(_0x3161cb,_0x48e6f4,_0xfb7bc1,Ni(),_0x5069e5);return Kp(_0x3161cb,_0x5973e2,bs());}async['_openRedirect'](_0xc02eed,_0x5bf67c,_0x50da03,_0x2597f5){await this['_originValidation'](_0xc02eed);const _0x14b3d5=await Mr(_0xc02eed,_0x5bf67c,_0x50da03,Ni(),_0x2597f5);return ip(_0x14b3d5),new Promise(()=>{});}['_initialize'](_0x3d3587){const _0x5693a9=_0x3d3587['_key']();if(this['eventManagers'][_0x5693a9]){const {manager:_0x59f06f,promise:_0x2fe4dc}=this['eventManagers'][_0x5693a9];return _0x59f06f?Promise['resolve'](_0x59f06f):(ae(_0x2fe4dc,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2fe4dc);}const _0x1ce985=this['initAndGetManager'](_0x3d3587);return this['eventManagers'][_0x5693a9]={'promise':_0x1ce985},_0x1ce985['catch'](()=>{delete this['eventManagers'][_0x5693a9];}),_0x1ce985;}async['initAndGetManager'](_0x152596){const _0x580e15=await Hp(_0x152596),_0x401862=new bp(_0x152596);return _0x580e15['register']('authEvent',_0x4af3c6=>(m(_0x4af3c6==null?void 0x0:_0x4af3c6['authEvent'],_0x152596,'invalid-auth-event'),{'status':_0x401862['onEvent'](_0x4af3c6['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x152596['_key']()]={'manager':_0x401862},this['iframes'][_0x152596['_key']()]=_0x580e15,_0x401862;}['_isIframeWebStorageSupported'](_0x301e83,_0x4550be){this['iframes'][_0x301e83['_key']()]['send'](li,{'type':li},_0x2609e6=>{var _0x43dee8;const _0x5a2b5e=(_0x43dee8=_0x2609e6==null?void 0x0:_0x2609e6[0x0])==null?void 0x0:_0x43dee8[li];_0x5a2b5e!==void 0x0&&_0x4550be(!!_0x5a2b5e),K(_0x301e83,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x461ff7){const _0x42a22c=_0x461ff7['_key']();return this['originValidationPromises'][_0x42a22c]||(this['originValidationPromises'][_0x42a22c]=Pp(_0x461ff7)),this['originValidationPromises'][_0x42a22c];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0xd027cb){this['auth']=_0xd027cb,this['internalListeners']=new Map();}['getUid'](){var _0x5d81a0;return this['assertAuthConfigured'](),((_0x5d81a0=this['auth']['currentUser'])==null?void 0x0:_0x5d81a0['uid'])||null;}async['getToken'](_0x5c62b8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5c62b8)}:null;}['addAuthTokenListener'](_0x31ca32){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x31ca32))return;const _0x58c504=this['auth']['onIdTokenChanged'](_0x4f94d3=>{_0x31ca32((_0x4f94d3==null?void 0x0:_0x4f94d3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x31ca32,_0x58c504),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x52871c){this['assertAuthConfigured']();const _0x20cec4=this['internalListeners']['get'](_0x52871c);_0x20cec4&&(this['internalListeners']['delete'](_0x52871c),_0x20cec4(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x4b9bc9){switch(_0x4b9bc9){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x164bb7){et(new Me('auth',(_0x125098,{options:_0x3eb471})=>{const _0x4667e8=_0x125098['getProvider']('app')['getImmediate'](),_0x160fda=_0x125098['getProvider']('heartbeat'),_0x311609=_0x125098['getProvider']('app-check-internal'),{apiKey:_0x2a88d7,authDomain:_0x373451}=_0x4667e8['options'];m(_0x2a88d7&&!_0x2a88d7['includes'](':'),'invalid-api-key',{'appName':_0x4667e8['name']});const _0x571f34={'apiKey':_0x2a88d7,'authDomain':_0x373451,'clientPlatform':_0x164bb7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x164bb7)},_0x45bb2a=new bf(_0x4667e8,_0x160fda,_0x311609,_0x571f34);return Lf(_0x45bb2a,_0x3eb471),_0x45bb2a;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x371f96,_0x5452a5,_0x5b92dc)=>{_0x371f96['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x453efa=>{const _0x2b27a1=qe(_0x453efa['getProvider']('auth')['getImmediate']());return(_0x599707=>new n_(_0x599707))(_0x2b27a1);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x164bb7)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x513c6b=>async _0x270012=>{const _0x539a0e=_0x270012&&await _0x270012['getIdTokenResult'](),_0x29ce98=_0x539a0e&&(new Date()['getTime']()-Date['parse'](_0x539a0e['issuedAtTime']))/0x3e8;if(_0x29ce98&&_0x29ce98>o_)return;const _0x1cc278=_0x539a0e==null?void 0x0:_0x539a0e['token'];Fr!==_0x1cc278&&(Fr=_0x1cc278,await fetch(_0x513c6b,{'method':_0x1cc278?'POST':'DELETE','headers':_0x1cc278?{'Authorization':'Bearer\x20'+_0x1cc278}:{}}));};function O_(_0x462702=Qr()){const _0x15c5d1=Ui(_0x462702,'auth');if(_0x15c5d1['isInitialized']())return _0x15c5d1['getImmediate']();const _0x2d00ac=Mf(_0x462702,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x3e03be=Gr('authTokenSyncURL');if(_0x3e03be&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1910f2=new URL(_0x3e03be,location['origin']);if(location['origin']===_0x1910f2['origin']){const _0x5ba7bc=a_(_0x1910f2['toString']());Jf(_0x2d00ac,_0x5ba7bc,()=>_0x5ba7bc(_0x2d00ac['currentUser'])),Qf(_0x2d00ac,_0x4612f7=>_0x5ba7bc(_0x4612f7));}}const _0x2fdbf0=Hr('auth');return _0x2fdbf0&&xf(_0x2d00ac,'http://'+_0x2fdbf0),_0x2d00ac;}function c_(){var _0x208f2f;return((_0x208f2f=document['getElementsByTagName']('head'))==null?void 0x0:_0x208f2f[0x0])??document;}Rf({'loadJS'(_0x2fe98c){return new Promise((_0x2914f5,_0x33a93b)=>{const _0x2b5b28=document['createElement']('script');_0x2b5b28['setAttribute']('src',_0x2fe98c),_0x2b5b28['onload']=_0x2914f5,_0x2b5b28['onerror']=_0x1a0946=>{const _0x599667=J('internal-error');_0x599667['customData']=_0x1a0946,_0x33a93b(_0x599667);},_0x2b5b28['type']='text/javascript',_0x2b5b28['charset']='UTF-8',c_()['appendChild'](_0x2b5b28);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};