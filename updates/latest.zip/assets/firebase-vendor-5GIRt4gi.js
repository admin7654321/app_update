const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4705dd,_0x4a5a14){if(!_0x4705dd)throw ot(_0x4a5a14);},ot=function(_0x182136){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x182136);},Wr=function(_0x1032fd){const _0x3a8462=[];let _0x3b1104=0x0;for(let _0x57d0a6=0x0;_0x57d0a6<_0x1032fd['length'];_0x57d0a6++){let _0x1c384c=_0x1032fd['charCodeAt'](_0x57d0a6);_0x1c384c<0x80?_0x3a8462[_0x3b1104++]=_0x1c384c:_0x1c384c<0x800?(_0x3a8462[_0x3b1104++]=_0x1c384c>>0x6|0xc0,_0x3a8462[_0x3b1104++]=_0x1c384c&0x3f|0x80):(_0x1c384c&0xfc00)===0xd800&&_0x57d0a6+0x1<_0x1032fd['length']&&(_0x1032fd['charCodeAt'](_0x57d0a6+0x1)&0xfc00)===0xdc00?(_0x1c384c=0x10000+((_0x1c384c&0x3ff)<<0xa)+(_0x1032fd['charCodeAt'](++_0x57d0a6)&0x3ff),_0x3a8462[_0x3b1104++]=_0x1c384c>>0x12|0xf0,_0x3a8462[_0x3b1104++]=_0x1c384c>>0xc&0x3f|0x80,_0x3a8462[_0x3b1104++]=_0x1c384c>>0x6&0x3f|0x80,_0x3a8462[_0x3b1104++]=_0x1c384c&0x3f|0x80):(_0x3a8462[_0x3b1104++]=_0x1c384c>>0xc|0xe0,_0x3a8462[_0x3b1104++]=_0x1c384c>>0x6&0x3f|0x80,_0x3a8462[_0x3b1104++]=_0x1c384c&0x3f|0x80);}return _0x3a8462;},Za=function(_0x4b8a89){const _0x462c1f=[];let _0x1dca2f=0x0,_0x40e46a=0x0;for(;_0x1dca2f<_0x4b8a89['length'];){const _0x36db57=_0x4b8a89[_0x1dca2f++];if(_0x36db57<0x80)_0x462c1f[_0x40e46a++]=String['fromCharCode'](_0x36db57);else{if(_0x36db57>0xbf&&_0x36db57<0xe0){const _0x72644f=_0x4b8a89[_0x1dca2f++];_0x462c1f[_0x40e46a++]=String['fromCharCode']((_0x36db57&0x1f)<<0x6|_0x72644f&0x3f);}else{if(_0x36db57>0xef&&_0x36db57<0x16d){const _0x5c2fff=_0x4b8a89[_0x1dca2f++],_0x387173=_0x4b8a89[_0x1dca2f++],_0x400bd4=_0x4b8a89[_0x1dca2f++],_0x2fe5fa=((_0x36db57&0x7)<<0x12|(_0x5c2fff&0x3f)<<0xc|(_0x387173&0x3f)<<0x6|_0x400bd4&0x3f)-0x10000;_0x462c1f[_0x40e46a++]=String['fromCharCode'](0xd800+(_0x2fe5fa>>0xa)),_0x462c1f[_0x40e46a++]=String['fromCharCode'](0xdc00+(_0x2fe5fa&0x3ff));}else{const _0x4a48e4=_0x4b8a89[_0x1dca2f++],_0x3f47ee=_0x4b8a89[_0x1dca2f++];_0x462c1f[_0x40e46a++]=String['fromCharCode']((_0x36db57&0xf)<<0xc|(_0x4a48e4&0x3f)<<0x6|_0x3f47ee&0x3f);}}}}return _0x462c1f['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x26d76a,_0x57f319){if(!Array['isArray'](_0x26d76a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1b1a89=_0x57f319?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4a2149=[];for(let _0x311302=0x0;_0x311302<_0x26d76a['length'];_0x311302+=0x3){const _0x34d4c8=_0x26d76a[_0x311302],_0x31ee03=_0x311302+0x1<_0x26d76a['length'],_0x3133fc=_0x31ee03?_0x26d76a[_0x311302+0x1]:0x0,_0x2e35df=_0x311302+0x2<_0x26d76a['length'],_0x6f65ef=_0x2e35df?_0x26d76a[_0x311302+0x2]:0x0,_0x5c00ee=_0x34d4c8>>0x2,_0x43209e=(_0x34d4c8&0x3)<<0x4|_0x3133fc>>0x4;let _0x5df85b=(_0x3133fc&0xf)<<0x2|_0x6f65ef>>0x6,_0x5f65c6=_0x6f65ef&0x3f;_0x2e35df||(_0x5f65c6=0x40,_0x31ee03||(_0x5df85b=0x40)),_0x4a2149['push'](_0x1b1a89[_0x5c00ee],_0x1b1a89[_0x43209e],_0x1b1a89[_0x5df85b],_0x1b1a89[_0x5f65c6]);}return _0x4a2149['join']('');},'encodeString'(_0x4852f6,_0x20cbf0){return this['HAS_NATIVE_SUPPORT']&&!_0x20cbf0?btoa(_0x4852f6):this['encodeByteArray'](Wr(_0x4852f6),_0x20cbf0);},'decodeString'(_0x384fa0,_0x338f87){return this['HAS_NATIVE_SUPPORT']&&!_0x338f87?atob(_0x384fa0):Za(this['decodeStringToByteArray'](_0x384fa0,_0x338f87));},'decodeStringToByteArray'(_0x16e1e2,_0x147367){this['init_']();const _0x20b499=_0x147367?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2fe16e=[];for(let _0x20298a=0x0;_0x20298a<_0x16e1e2['length'];){const _0x3aa76b=_0x20b499[_0x16e1e2['charAt'](_0x20298a++)],_0x305904=_0x20298a<_0x16e1e2['length']?_0x20b499[_0x16e1e2['charAt'](_0x20298a)]:0x0;++_0x20298a;const _0x2cb557=_0x20298a<_0x16e1e2['length']?_0x20b499[_0x16e1e2['charAt'](_0x20298a)]:0x40;++_0x20298a;const _0x21d2b8=_0x20298a<_0x16e1e2['length']?_0x20b499[_0x16e1e2['charAt'](_0x20298a)]:0x40;if(++_0x20298a,_0x3aa76b==null||_0x305904==null||_0x2cb557==null||_0x21d2b8==null)throw new ec();const _0x83d02=_0x3aa76b<<0x2|_0x305904>>0x4;if(_0x2fe16e['push'](_0x83d02),_0x2cb557!==0x40){const _0x443255=_0x305904<<0x4&0xf0|_0x2cb557>>0x2;if(_0x2fe16e['push'](_0x443255),_0x21d2b8!==0x40){const _0x48af7c=_0x2cb557<<0x6&0xc0|_0x21d2b8;_0x2fe16e['push'](_0x48af7c);}}}return _0x2fe16e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x453ecd=0x0;_0x453ecd<this['ENCODED_VALS']['length'];_0x453ecd++)this['byteToCharMap_'][_0x453ecd]=this['ENCODED_VALS']['charAt'](_0x453ecd),this['charToByteMap_'][this['byteToCharMap_'][_0x453ecd]]=_0x453ecd,this['byteToCharMapWebSafe_'][_0x453ecd]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x453ecd),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x453ecd]]=_0x453ecd,_0x453ecd>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x453ecd)]=_0x453ecd,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x453ecd)]=_0x453ecd);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x2f920a){const _0x359200=Wr(_0x2f920a);return Di['encodeByteArray'](_0x359200,!0x0);},an=function(_0x3e06c8){return Br(_0x3e06c8)['replace'](/\./g,'');},cn=function(_0x46b2b5){try{return Di['decodeString'](_0x46b2b5,!0x0);}catch(_0x237d38){console['error']('base64Decode\x20failed:\x20',_0x237d38);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x2e15e8){return Vr(void 0x0,_0x2e15e8);}function Vr(_0x492e6a,_0x135e38){if(!(_0x135e38 instanceof Object))return _0x135e38;switch(_0x135e38['constructor']){case Date:const _0x790b1e=_0x135e38;return new Date(_0x790b1e['getTime']());case Object:_0x492e6a===void 0x0&&(_0x492e6a={});break;case Array:_0x492e6a=[];break;default:return _0x135e38;}for(const _0x2e15b7 in _0x135e38)!_0x135e38['hasOwnProperty'](_0x2e15b7)||!nc(_0x2e15b7)||(_0x492e6a[_0x2e15b7]=Vr(_0x492e6a[_0x2e15b7],_0x135e38[_0x2e15b7]));return _0x492e6a;}function nc(_0x4fecec){return _0x4fecec!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x43dbfc=As['__FIREBASE_DEFAULTS__'];if(_0x43dbfc)return JSON['parse'](_0x43dbfc);},oc=()=>{if(typeof document>'u')return;let _0x4b726b;try{_0x4b726b=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x125afe=_0x4b726b&&cn(_0x4b726b[0x1]);return _0x125afe&&JSON['parse'](_0x125afe);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x1d69ca){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1d69ca);return;}},Hr=_0x465c0a=>{var _0x39b972,_0xbad015;return(_0xbad015=(_0x39b972=Mi())==null?void 0x0:_0x39b972['emulatorHosts'])==null?void 0x0:_0xbad015[_0x465c0a];},ac=_0x31b331=>{const _0x179afd=Hr(_0x31b331);if(!_0x179afd)return;const _0x1db0c5=_0x179afd['lastIndexOf'](':');if(_0x1db0c5<=0x0||_0x1db0c5+0x1===_0x179afd['length'])throw new Error('Invalid\x20host\x20'+_0x179afd+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x366e1a=parseInt(_0x179afd['substring'](_0x1db0c5+0x1),0xa);return _0x179afd[0x0]==='['?[_0x179afd['substring'](0x1,_0x1db0c5-0x1),_0x366e1a]:[_0x179afd['substring'](0x0,_0x1db0c5),_0x366e1a];},$r=()=>{var _0x2ba5c9;return(_0x2ba5c9=Mi())==null?void 0x0:_0x2ba5c9['config'];},Gr=_0x1b70dc=>{var _0x1bc73b;return(_0x1bc73b=Mi())==null?void 0x0:_0x1bc73b['_'+_0x1b70dc];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5096bf,_0x5a7a8f)=>{this['resolve']=_0x5096bf,this['reject']=_0x5a7a8f;});}['wrapCallback'](_0x553cc7){return(_0x250c37,_0x419c17)=>{_0x250c37?this['reject'](_0x250c37):this['resolve'](_0x419c17),typeof _0x553cc7=='function'&&(this['promise']['catch'](()=>{}),_0x553cc7['length']===0x1?_0x553cc7(_0x250c37):_0x553cc7(_0x250c37,_0x419c17));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x7d2ed9,_0x14e0fc){if(_0x7d2ed9['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3ed9e7={'alg':'none','type':'JWT'},_0x5aa7dc=_0x14e0fc||'demo-project',_0x22eb58=_0x7d2ed9['iat']||0x0,_0x70697c=_0x7d2ed9['sub']||_0x7d2ed9['user_id'];if(!_0x70697c)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3b89a7={'iss':'https://securetoken.google.com/'+_0x5aa7dc,'aud':_0x5aa7dc,'iat':_0x22eb58,'exp':_0x22eb58+0xe10,'auth_time':_0x22eb58,'sub':_0x70697c,'user_id':_0x70697c,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x7d2ed9};return[an(JSON['stringify'](_0x3ed9e7)),an(JSON['stringify'](_0x3b89a7)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x848f1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x848f1=='object'&&_0x848f1['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0xf43bd9=W();return _0xf43bd9['indexOf']('MSIE\x20')>=0x0||_0xf43bd9['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x434605,_0x1efd4e)=>{try{let _0x34cdff=!0x0;const _0x4d99f9='validate-browser-context-for-indexeddb-analytics-module',_0x2c6c4a=self['indexedDB']['open'](_0x4d99f9);_0x2c6c4a['onsuccess']=()=>{_0x2c6c4a['result']['close'](),_0x34cdff||self['indexedDB']['deleteDatabase'](_0x4d99f9),_0x434605(!0x0);},_0x2c6c4a['onupgradeneeded']=()=>{_0x34cdff=!0x1;},_0x2c6c4a['onerror']=()=>{var _0x18eb62;_0x1efd4e(((_0x18eb62=_0x2c6c4a['error'])==null?void 0x0:_0x18eb62['message'])||'');};}catch(_0x53903b){_0x1efd4e(_0x53903b);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x326217,_0x27633a,_0x4d8dd4){super(_0x27633a),this['code']=_0x326217,this['customData']=_0x4d8dd4,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x5718e6,_0x908130,_0x2804db){this['service']=_0x5718e6,this['serviceName']=_0x908130,this['errors']=_0x2804db;}['create'](_0x2b124d,..._0x51f041){const _0x4b76ac=_0x51f041[0x0]||{},_0x4abb3d=this['service']+'/'+_0x2b124d,_0x3f5492=this['errors'][_0x2b124d],_0x7b4390=_0x3f5492?gc(_0x3f5492,_0x4b76ac):'Error',_0x208ada=this['serviceName']+':\x20'+_0x7b4390+'\x20('+_0x4abb3d+').';return new Se(_0x4abb3d,_0x208ada,_0x4b76ac);}}function gc(_0x157757,_0x14ddb9){return _0x157757['replace'](mc,(_0x4e147f,_0xf9c886)=>{const _0x5def70=_0x14ddb9[_0xf9c886];return _0x5def70!=null?String(_0x5def70):'<'+_0xf9c886+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xb2d81e){return JSON['parse'](_0xb2d81e);}function O(_0x1035ab){return JSON['stringify'](_0x1035ab);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x102d70){let _0x31b819={},_0x213ba0={},_0x21ca10={},_0x17f61f='';try{const _0x3a9c49=_0x102d70['split']('.');_0x31b819=bt(cn(_0x3a9c49[0x0])||''),_0x213ba0=bt(cn(_0x3a9c49[0x1])||''),_0x17f61f=_0x3a9c49[0x2],_0x21ca10=_0x213ba0['d']||{},delete _0x213ba0['d'];}catch{}return{'header':_0x31b819,'claims':_0x213ba0,'data':_0x21ca10,'signature':_0x17f61f};},yc=function(_0x494b6e){const _0xcf4465=zr(_0x494b6e),_0x31c550=_0xcf4465['claims'];return!!_0x31c550&&typeof _0x31c550=='object'&&_0x31c550['hasOwnProperty']('iat');},vc=function(_0x49a4b2){const _0x5cf328=zr(_0x49a4b2)['claims'];return typeof _0x5cf328=='object'&&_0x5cf328['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4edc8c,_0x32da8f){return Object['prototype']['hasOwnProperty']['call'](_0x4edc8c,_0x32da8f);}function Oe(_0x5709ab,_0x128341){if(Object['prototype']['hasOwnProperty']['call'](_0x5709ab,_0x128341))return _0x5709ab[_0x128341];}function hi(_0x6deb74){for(const _0x6ba9c8 in _0x6deb74)if(Object['prototype']['hasOwnProperty']['call'](_0x6deb74,_0x6ba9c8))return!0x1;return!0x0;}function ln(_0x2e448f,_0x5a8b72,_0x5789ae){const _0x13ee14={};for(const _0x4fb342 in _0x2e448f)Object['prototype']['hasOwnProperty']['call'](_0x2e448f,_0x4fb342)&&(_0x13ee14[_0x4fb342]=_0x5a8b72['call'](_0x5789ae,_0x2e448f[_0x4fb342],_0x4fb342,_0x2e448f));return _0x13ee14;}function De(_0x1f1ae2,_0x16f0f8){if(_0x1f1ae2===_0x16f0f8)return!0x0;const _0x4ff2c1=Object['keys'](_0x1f1ae2),_0x49c092=Object['keys'](_0x16f0f8);for(const _0x19cd75 of _0x4ff2c1){if(!_0x49c092['includes'](_0x19cd75))return!0x1;const _0x56c993=_0x1f1ae2[_0x19cd75],_0x17dd7e=_0x16f0f8[_0x19cd75];if(ks(_0x56c993)&&ks(_0x17dd7e)){if(!De(_0x56c993,_0x17dd7e))return!0x1;}else{if(_0x56c993!==_0x17dd7e)return!0x1;}}for(const _0x29a550 of _0x49c092)if(!_0x4ff2c1['includes'](_0x29a550))return!0x1;return!0x0;}function ks(_0x16b4da){return _0x16b4da!==null&&typeof _0x16b4da=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x2e555b){const _0x46551f=[];for(const [_0x118e9f,_0x5b8bde]of Object['entries'](_0x2e555b))Array['isArray'](_0x5b8bde)?_0x5b8bde['forEach'](_0x4006b8=>{_0x46551f['push'](encodeURIComponent(_0x118e9f)+'='+encodeURIComponent(_0x4006b8));}):_0x46551f['push'](encodeURIComponent(_0x118e9f)+'='+encodeURIComponent(_0x5b8bde));return _0x46551f['length']?'&'+_0x46551f['join']('&'):'';}function yt(_0x3a9c27){const _0xe4ae6d={};return _0x3a9c27['replace'](/^\?/,'')['split']('&')['forEach'](_0x4b0c5b=>{if(_0x4b0c5b){const [_0x19f631,_0x474635]=_0x4b0c5b['split']('=');_0xe4ae6d[decodeURIComponent(_0x19f631)]=decodeURIComponent(_0x474635);}}),_0xe4ae6d;}function vt(_0x396d6a){const _0x1c8dd8=_0x396d6a['indexOf']('?');if(!_0x1c8dd8)return'';const _0x2995c1=_0x396d6a['indexOf']('#',_0x1c8dd8);return _0x396d6a['substring'](_0x1c8dd8,_0x2995c1>0x0?_0x2995c1:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x9d5267=0x1;_0x9d5267<this['blockSize'];++_0x9d5267)this['pad_'][_0x9d5267]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x125b32,_0x186701){_0x186701||(_0x186701=0x0);const _0x285faa=this['W_'];if(typeof _0x125b32=='string'){for(let _0x11fc44=0x0;_0x11fc44<0x10;_0x11fc44++)_0x285faa[_0x11fc44]=_0x125b32['charCodeAt'](_0x186701)<<0x18|_0x125b32['charCodeAt'](_0x186701+0x1)<<0x10|_0x125b32['charCodeAt'](_0x186701+0x2)<<0x8|_0x125b32['charCodeAt'](_0x186701+0x3),_0x186701+=0x4;}else{for(let _0x318144=0x0;_0x318144<0x10;_0x318144++)_0x285faa[_0x318144]=_0x125b32[_0x186701]<<0x18|_0x125b32[_0x186701+0x1]<<0x10|_0x125b32[_0x186701+0x2]<<0x8|_0x125b32[_0x186701+0x3],_0x186701+=0x4;}for(let _0x5d26f5=0x10;_0x5d26f5<0x50;_0x5d26f5++){const _0x718f55=_0x285faa[_0x5d26f5-0x3]^_0x285faa[_0x5d26f5-0x8]^_0x285faa[_0x5d26f5-0xe]^_0x285faa[_0x5d26f5-0x10];_0x285faa[_0x5d26f5]=(_0x718f55<<0x1|_0x718f55>>>0x1f)&0xffffffff;}let _0x11d3c6=this['chain_'][0x0],_0x156623=this['chain_'][0x1],_0x1f3f5c=this['chain_'][0x2],_0x4006a8=this['chain_'][0x3],_0x1f6f99=this['chain_'][0x4],_0x2c98e5,_0xa0fc30;for(let _0x230465=0x0;_0x230465<0x50;_0x230465++){_0x230465<0x28?_0x230465<0x14?(_0x2c98e5=_0x4006a8^_0x156623&(_0x1f3f5c^_0x4006a8),_0xa0fc30=0x5a827999):(_0x2c98e5=_0x156623^_0x1f3f5c^_0x4006a8,_0xa0fc30=0x6ed9eba1):_0x230465<0x3c?(_0x2c98e5=_0x156623&_0x1f3f5c|_0x4006a8&(_0x156623|_0x1f3f5c),_0xa0fc30=0x8f1bbcdc):(_0x2c98e5=_0x156623^_0x1f3f5c^_0x4006a8,_0xa0fc30=0xca62c1d6);const _0x40be4a=(_0x11d3c6<<0x5|_0x11d3c6>>>0x1b)+_0x2c98e5+_0x1f6f99+_0xa0fc30+_0x285faa[_0x230465]&0xffffffff;_0x1f6f99=_0x4006a8,_0x4006a8=_0x1f3f5c,_0x1f3f5c=(_0x156623<<0x1e|_0x156623>>>0x2)&0xffffffff,_0x156623=_0x11d3c6,_0x11d3c6=_0x40be4a;}this['chain_'][0x0]=this['chain_'][0x0]+_0x11d3c6&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x156623&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1f3f5c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4006a8&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1f6f99&0xffffffff;}['update'](_0x908b09,_0x19e756){if(_0x908b09==null)return;_0x19e756===void 0x0&&(_0x19e756=_0x908b09['length']);const _0x4438f4=_0x19e756-this['blockSize'];let _0x47685e=0x0;const _0x4975c7=this['buf_'];let _0x5237d9=this['inbuf_'];for(;_0x47685e<_0x19e756;){if(_0x5237d9===0x0){for(;_0x47685e<=_0x4438f4;)this['compress_'](_0x908b09,_0x47685e),_0x47685e+=this['blockSize'];}if(typeof _0x908b09=='string'){for(;_0x47685e<_0x19e756;)if(_0x4975c7[_0x5237d9]=_0x908b09['charCodeAt'](_0x47685e),++_0x5237d9,++_0x47685e,_0x5237d9===this['blockSize']){this['compress_'](_0x4975c7),_0x5237d9=0x0;break;}}else{for(;_0x47685e<_0x19e756;)if(_0x4975c7[_0x5237d9]=_0x908b09[_0x47685e],++_0x5237d9,++_0x47685e,_0x5237d9===this['blockSize']){this['compress_'](_0x4975c7),_0x5237d9=0x0;break;}}}this['inbuf_']=_0x5237d9,this['total_']+=_0x19e756;}['digest'](){const _0x49ada5=[];let _0x1f6d6a=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1328d5=this['blockSize']-0x1;_0x1328d5>=0x38;_0x1328d5--)this['buf_'][_0x1328d5]=_0x1f6d6a&0xff,_0x1f6d6a/=0x100;this['compress_'](this['buf_']);let _0x3c3323=0x0;for(let _0x2963f4=0x0;_0x2963f4<0x5;_0x2963f4++)for(let _0x3cd03e=0x18;_0x3cd03e>=0x0;_0x3cd03e-=0x8)_0x49ada5[_0x3c3323]=this['chain_'][_0x2963f4]>>_0x3cd03e&0xff,++_0x3c3323;return _0x49ada5;}}function Ic(_0x22fcaf,_0x20a20b){const _0x369b35=new wc(_0x22fcaf,_0x20a20b);return _0x369b35['subscribe']['bind'](_0x369b35);}class wc{constructor(_0x3db159,_0x28f8c0){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x28f8c0,this['task']['then'](()=>{_0x3db159(this);})['catch'](_0x30bd66=>{this['error'](_0x30bd66);});}['next'](_0x533a9f){this['forEachObserver'](_0x3f9e04=>{_0x3f9e04['next'](_0x533a9f);});}['error'](_0x54ab00){this['forEachObserver'](_0x3b4c92=>{_0x3b4c92['error'](_0x54ab00);}),this['close'](_0x54ab00);}['complete'](){this['forEachObserver'](_0x5deca1=>{_0x5deca1['complete']();}),this['close']();}['subscribe'](_0x44d9dd,_0x2a47cf,_0x2d6505){let _0x16f735;if(_0x44d9dd===void 0x0&&_0x2a47cf===void 0x0&&_0x2d6505===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x44d9dd,['next','error','complete'])?_0x16f735=_0x44d9dd:_0x16f735={'next':_0x44d9dd,'error':_0x2a47cf,'complete':_0x2d6505},_0x16f735['next']===void 0x0&&(_0x16f735['next']=Qn),_0x16f735['error']===void 0x0&&(_0x16f735['error']=Qn),_0x16f735['complete']===void 0x0&&(_0x16f735['complete']=Qn);const _0x17b876=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x16f735['error'](this['finalError']):_0x16f735['complete']();}catch{}}),this['observers']['push'](_0x16f735),_0x17b876;}['unsubscribeOne'](_0x2dd0f3){this['observers']===void 0x0||this['observers'][_0x2dd0f3]===void 0x0||(delete this['observers'][_0x2dd0f3],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2662f2){if(!this['finalized']){for(let _0x266983=0x0;_0x266983<this['observers']['length'];_0x266983++)this['sendOne'](_0x266983,_0x2662f2);}}['sendOne'](_0x7b7220,_0x4e5166){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x7b7220]!==void 0x0)try{_0x4e5166(this['observers'][_0x7b7220]);}catch(_0x15c7e4){typeof console<'u'&&console['error']&&console['error'](_0x15c7e4);}});}['close'](_0x3a8bc8){this['finalized']||(this['finalized']=!0x0,_0x3a8bc8!==void 0x0&&(this['finalError']=_0x3a8bc8),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1bedf8,_0x134353){if(typeof _0x1bedf8!='object'||_0x1bedf8===null)return!0x1;for(const _0x5d88e6 of _0x134353)if(_0x5d88e6 in _0x1bedf8&&typeof _0x1bedf8[_0x5d88e6]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x541c0a,_0x36c330){return _0x541c0a+'\x20failed:\x20'+_0x36c330+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x3488ec){const _0xfc7474=[];let _0x5d99d8=0x0;for(let _0x93722b=0x0;_0x93722b<_0x3488ec['length'];_0x93722b++){let _0x1e71f8=_0x3488ec['charCodeAt'](_0x93722b);if(_0x1e71f8>=0xd800&&_0x1e71f8<=0xdbff){const _0x4fe5f5=_0x1e71f8-0xd800;_0x93722b++,f(_0x93722b<_0x3488ec['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1b7483=_0x3488ec['charCodeAt'](_0x93722b)-0xdc00;_0x1e71f8=0x10000+(_0x4fe5f5<<0xa)+_0x1b7483;}_0x1e71f8<0x80?_0xfc7474[_0x5d99d8++]=_0x1e71f8:_0x1e71f8<0x800?(_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0x6|0xc0,_0xfc7474[_0x5d99d8++]=_0x1e71f8&0x3f|0x80):_0x1e71f8<0x10000?(_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0xc|0xe0,_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0x6&0x3f|0x80,_0xfc7474[_0x5d99d8++]=_0x1e71f8&0x3f|0x80):(_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0x12|0xf0,_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0xc&0x3f|0x80,_0xfc7474[_0x5d99d8++]=_0x1e71f8>>0x6&0x3f|0x80,_0xfc7474[_0x5d99d8++]=_0x1e71f8&0x3f|0x80);}return _0xfc7474;},Pn=function(_0x13ae03){let _0xdb3f30=0x0;for(let _0x535c68=0x0;_0x535c68<_0x13ae03['length'];_0x535c68++){const _0x2e8772=_0x13ae03['charCodeAt'](_0x535c68);_0x2e8772<0x80?_0xdb3f30++:_0x2e8772<0x800?_0xdb3f30+=0x2:_0x2e8772>=0xd800&&_0x2e8772<=0xdbff?(_0xdb3f30+=0x4,_0x535c68++):_0xdb3f30+=0x3;}return _0xdb3f30;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x32a040){return _0x32a040&&_0x32a040['_delegate']?_0x32a040['_delegate']:_0x32a040;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x4fbc6c){try{return(_0x4fbc6c['startsWith']('http://')||_0x4fbc6c['startsWith']('https://')?new URL(_0x4fbc6c)['hostname']:_0x4fbc6c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4e0125){return(await fetch(_0x4e0125,{'credentials':'include'}))['ok'];}class Me{constructor(_0xc983fa,_0x77344f,_0x366713){this['name']=_0xc983fa,this['instanceFactory']=_0x77344f,this['type']=_0x366713,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x330e29){return this['instantiationMode']=_0x330e29,this;}['setMultipleInstances'](_0x3517e7){return this['multipleInstances']=_0x3517e7,this;}['setServiceProps'](_0x4f70bb){return this['serviceProps']=_0x4f70bb,this;}['setInstanceCreatedCallback'](_0x34d924){return this['onInstanceCreated']=_0x34d924,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x5c8183,_0x4ca44e){this['name']=_0x5c8183,this['container']=_0x4ca44e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x374aa4){const _0x16364c=this['normalizeInstanceIdentifier'](_0x374aa4);if(!this['instancesDeferred']['has'](_0x16364c)){const _0x5aa229=new Ve();if(this['instancesDeferred']['set'](_0x16364c,_0x5aa229),this['isInitialized'](_0x16364c)||this['shouldAutoInitialize']())try{const _0x3d678b=this['getOrInitializeService']({'instanceIdentifier':_0x16364c});_0x3d678b&&_0x5aa229['resolve'](_0x3d678b);}catch{}}return this['instancesDeferred']['get'](_0x16364c)['promise'];}['getImmediate'](_0x306842){const _0x1c2f7f=this['normalizeInstanceIdentifier'](_0x306842==null?void 0x0:_0x306842['identifier']),_0x23543e=(_0x306842==null?void 0x0:_0x306842['optional'])??!0x1;if(this['isInitialized'](_0x1c2f7f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1c2f7f});}catch(_0x127eb6){if(_0x23543e)return null;throw _0x127eb6;}else{if(_0x23543e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x124da9){if(_0x124da9['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x124da9['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x124da9,!!this['shouldAutoInitialize']()){if(Rc(_0x124da9))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3c80f2,_0x4adbb0]of this['instancesDeferred']['entries']()){const _0x5cd3a1=this['normalizeInstanceIdentifier'](_0x3c80f2);try{const _0x26a350=this['getOrInitializeService']({'instanceIdentifier':_0x5cd3a1});_0x4adbb0['resolve'](_0x26a350);}catch{}}}}['clearInstance'](_0x3d7284=ke){this['instancesDeferred']['delete'](_0x3d7284),this['instancesOptions']['delete'](_0x3d7284),this['instances']['delete'](_0x3d7284);}async['delete'](){const _0x196ba2=Array['from'](this['instances']['values']());await Promise['all']([..._0x196ba2['filter'](_0xb53fc=>'INTERNAL'in _0xb53fc)['map'](_0x5a774d=>_0x5a774d['INTERNAL']['delete']()),..._0x196ba2['filter'](_0x719bb3=>'_delete'in _0x719bb3)['map'](_0xa4b3e1=>_0xa4b3e1['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x573ad2=ke){return this['instances']['has'](_0x573ad2);}['getOptions'](_0x11c6b9=ke){return this['instancesOptions']['get'](_0x11c6b9)||{};}['initialize'](_0x523e5c={}){const {options:_0x3dfb0a={}}=_0x523e5c,_0x3aac69=this['normalizeInstanceIdentifier'](_0x523e5c['instanceIdentifier']);if(this['isInitialized'](_0x3aac69))throw Error(this['name']+'('+_0x3aac69+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3e44e6=this['getOrInitializeService']({'instanceIdentifier':_0x3aac69,'options':_0x3dfb0a});for(const [_0x381110,_0x26220f]of this['instancesDeferred']['entries']()){const _0x4b8c6f=this['normalizeInstanceIdentifier'](_0x381110);_0x3aac69===_0x4b8c6f&&_0x26220f['resolve'](_0x3e44e6);}return _0x3e44e6;}['onInit'](_0x28ce5b,_0x2f5f1d){const _0x3a9438=this['normalizeInstanceIdentifier'](_0x2f5f1d),_0x461aa0=this['onInitCallbacks']['get'](_0x3a9438)??new Set();_0x461aa0['add'](_0x28ce5b),this['onInitCallbacks']['set'](_0x3a9438,_0x461aa0);const _0x39bbad=this['instances']['get'](_0x3a9438);return _0x39bbad&&_0x28ce5b(_0x39bbad,_0x3a9438),()=>{_0x461aa0['delete'](_0x28ce5b);};}['invokeOnInitCallbacks'](_0x441bad,_0x1a81f7){const _0x182407=this['onInitCallbacks']['get'](_0x1a81f7);if(_0x182407){for(const _0x25579c of _0x182407)try{_0x25579c(_0x441bad,_0x1a81f7);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2446cf,options:_0x2d0fa8={}}){let _0x4cd3b3=this['instances']['get'](_0x2446cf);if(!_0x4cd3b3&&this['component']&&(_0x4cd3b3=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x2446cf),'options':_0x2d0fa8}),this['instances']['set'](_0x2446cf,_0x4cd3b3),this['instancesOptions']['set'](_0x2446cf,_0x2d0fa8),this['invokeOnInitCallbacks'](_0x4cd3b3,_0x2446cf),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2446cf,_0x4cd3b3);}catch{}return _0x4cd3b3||null;}['normalizeInstanceIdentifier'](_0xdecc58=ke){return this['component']?this['component']['multipleInstances']?_0xdecc58:ke:_0xdecc58;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x1e651a){return _0x1e651a===ke?void 0x0:_0x1e651a;}function Rc(_0x47c9c8){return _0x47c9c8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2c75ac){this['name']=_0x2c75ac,this['providers']=new Map();}['addComponent'](_0x1e6222){const _0x56d680=this['getProvider'](_0x1e6222['name']);if(_0x56d680['isComponentSet']())throw new Error('Component\x20'+_0x1e6222['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x56d680['setComponent'](_0x1e6222);}['addOrOverwriteComponent'](_0x2514d3){this['getProvider'](_0x2514d3['name'])['isComponentSet']()&&this['providers']['delete'](_0x2514d3['name']),this['addComponent'](_0x2514d3);}['getProvider'](_0x33913b){if(this['providers']['has'](_0x33913b))return this['providers']['get'](_0x33913b);const _0x282f85=new Sc(_0x33913b,this);return this['providers']['set'](_0x33913b,_0x282f85),_0x282f85;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2fad6d){_0x2fad6d[_0x2fad6d['DEBUG']=0x0]='DEBUG',_0x2fad6d[_0x2fad6d['VERBOSE']=0x1]='VERBOSE',_0x2fad6d[_0x2fad6d['INFO']=0x2]='INFO',_0x2fad6d[_0x2fad6d['WARN']=0x3]='WARN',_0x2fad6d[_0x2fad6d['ERROR']=0x4]='ERROR',_0x2fad6d[_0x2fad6d['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x424698,_0x14765f,..._0x3cbaa8)=>{if(_0x14765f<_0x424698['logLevel'])return;const _0x41892c=new Date()['toISOString'](),_0x43c11a=Pc[_0x14765f];if(_0x43c11a)console[_0x43c11a]('['+_0x41892c+']\x20\x20'+_0x424698['name']+':',..._0x3cbaa8);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x14765f+')');};class xi{constructor(_0x43f76c){this['name']=_0x43f76c,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x21a37f){if(!(_0x21a37f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x21a37f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x21a37f;}['setLogLevel'](_0x360c45){this['_logLevel']=typeof _0x360c45=='string'?kc[_0x360c45]:_0x360c45;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1e6e9f){if(typeof _0x1e6e9f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1e6e9f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3bedcb){this['_userLogHandler']=_0x3bedcb;}['debug'](..._0x215e4b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x215e4b),this['_logHandler'](this,T['DEBUG'],..._0x215e4b);}['log'](..._0x58e6b5){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x58e6b5),this['_logHandler'](this,T['VERBOSE'],..._0x58e6b5);}['info'](..._0x280697){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x280697),this['_logHandler'](this,T['INFO'],..._0x280697);}['warn'](..._0xe22028){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xe22028),this['_logHandler'](this,T['WARN'],..._0xe22028);}['error'](..._0x4a11e5){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4a11e5),this['_logHandler'](this,T['ERROR'],..._0x4a11e5);}}const Dc=(_0x161a42,_0x1d0070)=>_0x1d0070['some'](_0x2dc1c5=>_0x161a42 instanceof _0x2dc1c5);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x680d93){const _0x25df12=new Promise((_0x2f3d49,_0x235234)=>{const _0x5ca036=()=>{_0x680d93['removeEventListener']('success',_0x19a451),_0x680d93['removeEventListener']('error',_0x549d6d);},_0x19a451=()=>{_0x2f3d49(_e(_0x680d93['result'])),_0x5ca036();},_0x549d6d=()=>{_0x235234(_0x680d93['error']),_0x5ca036();};_0x680d93['addEventListener']('success',_0x19a451),_0x680d93['addEventListener']('error',_0x549d6d);});return _0x25df12['then'](_0x238cc9=>{_0x238cc9 instanceof IDBCursor&&Kr['set'](_0x238cc9,_0x680d93);})['catch'](()=>{}),Fi['set'](_0x25df12,_0x680d93),_0x25df12;}function Fc(_0x281b8b){if(ui['has'](_0x281b8b))return;const _0x2db63f=new Promise((_0x1f7206,_0x138e04)=>{const _0x4c6f40=()=>{_0x281b8b['removeEventListener']('complete',_0x495f5a),_0x281b8b['removeEventListener']('error',_0x2818f2),_0x281b8b['removeEventListener']('abort',_0x2818f2);},_0x495f5a=()=>{_0x1f7206(),_0x4c6f40();},_0x2818f2=()=>{_0x138e04(_0x281b8b['error']||new DOMException('AbortError','AbortError')),_0x4c6f40();};_0x281b8b['addEventListener']('complete',_0x495f5a),_0x281b8b['addEventListener']('error',_0x2818f2),_0x281b8b['addEventListener']('abort',_0x2818f2);});ui['set'](_0x281b8b,_0x2db63f);}let di={'get'(_0x27dcaf,_0x58731c,_0x327a31){if(_0x27dcaf instanceof IDBTransaction){if(_0x58731c==='done')return ui['get'](_0x27dcaf);if(_0x58731c==='objectStoreNames')return _0x27dcaf['objectStoreNames']||Yr['get'](_0x27dcaf);if(_0x58731c==='store')return _0x327a31['objectStoreNames'][0x1]?void 0x0:_0x327a31['objectStore'](_0x327a31['objectStoreNames'][0x0]);}return _e(_0x27dcaf[_0x58731c]);},'set'(_0x59c432,_0x38cc4a,_0x3a50f9){return _0x59c432[_0x38cc4a]=_0x3a50f9,!0x0;},'has'(_0x24236f,_0x5db77d){return _0x24236f instanceof IDBTransaction&&(_0x5db77d==='done'||_0x5db77d==='store')?!0x0:_0x5db77d in _0x24236f;}};function Uc(_0x1322ed){di=_0x1322ed(di);}function Wc(_0x3eb578){return _0x3eb578===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5b9839,..._0x4d9582){const _0x53f4a7=_0x3eb578['call'](Xn(this),_0x5b9839,..._0x4d9582);return Yr['set'](_0x53f4a7,_0x5b9839['sort']?_0x5b9839['sort']():[_0x5b9839]),_e(_0x53f4a7);}:Lc()['includes'](_0x3eb578)?function(..._0x4e29f8){return _0x3eb578['apply'](Xn(this),_0x4e29f8),_e(Kr['get'](this));}:function(..._0x23e0e7){return _e(_0x3eb578['apply'](Xn(this),_0x23e0e7));};}function Bc(_0x1b2063){return typeof _0x1b2063=='function'?Wc(_0x1b2063):(_0x1b2063 instanceof IDBTransaction&&Fc(_0x1b2063),Dc(_0x1b2063,Mc())?new Proxy(_0x1b2063,di):_0x1b2063);}function _e(_0x20855d){if(_0x20855d instanceof IDBRequest)return xc(_0x20855d);if(Jn['has'](_0x20855d))return Jn['get'](_0x20855d);const _0x4d235b=Bc(_0x20855d);return _0x4d235b!==_0x20855d&&(Jn['set'](_0x20855d,_0x4d235b),Fi['set'](_0x4d235b,_0x20855d)),_0x4d235b;}const Xn=_0x1f986c=>Fi['get'](_0x1f986c);function Vc(_0x411101,_0x5b7a45,{blocked:_0x13aca7,upgrade:_0x5e545a,blocking:_0x3d4ee6,terminated:_0x2fbb66}={}){const _0x1c2915=indexedDB['open'](_0x411101,_0x5b7a45),_0x206dd3=_e(_0x1c2915);return _0x5e545a&&_0x1c2915['addEventListener']('upgradeneeded',_0x11cd66=>{_0x5e545a(_e(_0x1c2915['result']),_0x11cd66['oldVersion'],_0x11cd66['newVersion'],_e(_0x1c2915['transaction']),_0x11cd66);}),_0x13aca7&&_0x1c2915['addEventListener']('blocked',_0x42faf7=>_0x13aca7(_0x42faf7['oldVersion'],_0x42faf7['newVersion'],_0x42faf7)),_0x206dd3['then'](_0x43c5f7=>{_0x2fbb66&&_0x43c5f7['addEventListener']('close',()=>_0x2fbb66()),_0x3d4ee6&&_0x43c5f7['addEventListener']('versionchange',_0x29f49e=>_0x3d4ee6(_0x29f49e['oldVersion'],_0x29f49e['newVersion'],_0x29f49e));})['catch'](()=>{}),_0x206dd3;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x207dbe,_0x29301c){if(!(_0x207dbe instanceof IDBDatabase&&!(_0x29301c in _0x207dbe)&&typeof _0x29301c=='string'))return;if(Zn['get'](_0x29301c))return Zn['get'](_0x29301c);const _0x2b1609=_0x29301c['replace'](/FromIndex$/,''),_0x2a2432=_0x29301c!==_0x2b1609,_0x2356a1=$c['includes'](_0x2b1609);if(!(_0x2b1609 in(_0x2a2432?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2356a1||Hc['includes'](_0x2b1609)))return;const _0x3d4baf=async function(_0x237c9d,..._0x2fd28c){const _0x23b3c3=this['transaction'](_0x237c9d,_0x2356a1?'readwrite':'readonly');let _0x569eae=_0x23b3c3['store'];return _0x2a2432&&(_0x569eae=_0x569eae['index'](_0x2fd28c['shift']())),(await Promise['all']([_0x569eae[_0x2b1609](..._0x2fd28c),_0x2356a1&&_0x23b3c3['done']]))[0x0];};return Zn['set'](_0x29301c,_0x3d4baf),_0x3d4baf;}Uc(_0x1e9d0c=>({..._0x1e9d0c,'get':(_0x2d1355,_0x269204,_0x483817)=>Os(_0x2d1355,_0x269204)||_0x1e9d0c['get'](_0x2d1355,_0x269204,_0x483817),'has':(_0x1c334e,_0x2fafd3)=>!!Os(_0x1c334e,_0x2fafd3)||_0x1e9d0c['has'](_0x1c334e,_0x2fafd3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x3d007b){this['container']=_0x3d007b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x4f51b2=>{if(qc(_0x4f51b2)){const _0x1c1e36=_0x4f51b2['getImmediate']();return _0x1c1e36['library']+'/'+_0x1c1e36['version'];}else return null;})['filter'](_0x4094bd=>_0x4094bd)['join']('\x20');}}function qc(_0x391f44){const _0x253816=_0x391f44['getComponent']();return(_0x253816==null?void 0x0:_0x253816['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3f8cb3,_0x4b91b6){try{_0x3f8cb3['container']['addComponent'](_0x4b91b6);}catch(_0x2e7dd8){re['debug']('Component\x20'+_0x4b91b6['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3f8cb3['name'],_0x2e7dd8);}}function et(_0x32f51a){const _0x18604c=_0x32f51a['name'];if(gi['has'](_0x18604c))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x18604c+'.'),!0x1;gi['set'](_0x18604c,_0x32f51a);for(const _0x294884 of Le['values']())Ms(_0x294884,_0x32f51a);for(const _0x40058e of _i['values']())Ms(_0x40058e,_0x32f51a);return!0x0;}function Ui(_0x1a78fd,_0x52a4f2){const _0x350097=_0x1a78fd['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x350097&&_0x350097['triggerHeartbeat'](),_0x1a78fd['container']['getProvider'](_0x52a4f2);}function H(_0x1dd447){return _0x1dd447==null?!0x1:_0x1dd447['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x13ac16,_0x107bdc,_0x3be64c){this['_isDeleted']=!0x1,this['_options']={..._0x13ac16},this['_config']={..._0x107bdc},this['_name']=_0x107bdc['name'],this['_automaticDataCollectionEnabled']=_0x107bdc['automaticDataCollectionEnabled'],this['_container']=_0x3be64c,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3b25b1){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3b25b1;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x59a84f){this['_isDeleted']=_0x59a84f;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x56bd1f,_0x2216ae={}){let _0x14ff87=_0x56bd1f;typeof _0x2216ae!='object'&&(_0x2216ae={'name':_0x2216ae});const _0x518177={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2216ae},_0x3a04e4=_0x518177['name'];if(typeof _0x3a04e4!='string'||!_0x3a04e4)throw ge['create']('bad-app-name',{'appName':String(_0x3a04e4)});if(_0x14ff87||(_0x14ff87=$r()),!_0x14ff87)throw ge['create']('no-options');const _0x48daeb=Le['get'](_0x3a04e4);if(_0x48daeb){if(De(_0x14ff87,_0x48daeb['options'])&&De(_0x518177,_0x48daeb['config']))return _0x48daeb;throw ge['create']('duplicate-app',{'appName':_0x3a04e4});}const _0x46e0d7=new Ac(_0x3a04e4);for(const _0x21588a of gi['values']())_0x46e0d7['addComponent'](_0x21588a);const _0x455fd7=new Il(_0x14ff87,_0x518177,_0x46e0d7);return Le['set'](_0x3a04e4,_0x455fd7),_0x455fd7;}function Qr(_0x5244c9=pi){const _0x1e22ab=Le['get'](_0x5244c9);if(!_0x1e22ab&&_0x5244c9===pi&&$r())return wl();if(!_0x1e22ab)throw ge['create']('no-app',{'appName':_0x5244c9});return _0x1e22ab;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5c634d){let _0x485580=!0x1;const _0x4bd89f=_0x5c634d['name'];Le['has'](_0x4bd89f)?(_0x485580=!0x0,Le['delete'](_0x4bd89f)):_i['has'](_0x4bd89f)&&_0x5c634d['decRefCount']()<=0x0&&(_i['delete'](_0x4bd89f),_0x485580=!0x0),_0x485580&&(await Promise['all'](_0x5c634d['container']['getProviders']()['map'](_0x2b39cd=>_0x2b39cd['delete']())),_0x5c634d['isDeleted']=!0x0);}function me(_0x41f474,_0x3d7fff,_0x42bc3a){let _0x593b08=vl[_0x41f474]??_0x41f474;_0x42bc3a&&(_0x593b08+='-'+_0x42bc3a);const _0x67e02d=_0x593b08['match'](/\s|\//),_0x7bde94=_0x3d7fff['match'](/\s|\//);if(_0x67e02d||_0x7bde94){const _0x26aea8=['Unable\x20to\x20register\x20library\x20\x22'+_0x593b08+'\x22\x20with\x20version\x20\x22'+_0x3d7fff+'\x22:'];_0x67e02d&&_0x26aea8['push']('library\x20name\x20\x22'+_0x593b08+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x67e02d&&_0x7bde94&&_0x26aea8['push']('and'),_0x7bde94&&_0x26aea8['push']('version\x20name\x20\x22'+_0x3d7fff+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x26aea8['join']('\x20'));return;}et(new Me(_0x593b08+'-version',()=>({'library':_0x593b08,'version':_0x3d7fff}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2bff6e,_0x52cafb)=>{switch(_0x52cafb){case 0x0:try{_0x2bff6e['createObjectStore'](Rt);}catch(_0x5f5c39){console['warn'](_0x5f5c39);}}}})['catch'](_0x4070f4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4070f4['message']});})),ei;}async function Sl(_0x2ceafd){try{const _0x1bf78c=(await Jr())['transaction'](Rt),_0x1d89ab=await _0x1bf78c['objectStore'](Rt)['get'](Xr(_0x2ceafd));return await _0x1bf78c['done'],_0x1d89ab;}catch(_0x3e1d5f){if(_0x3e1d5f instanceof Se)re['warn'](_0x3e1d5f['message']);else{const _0x3f7a9a=ge['create']('idb-get',{'originalErrorMessage':_0x3e1d5f==null?void 0x0:_0x3e1d5f['message']});re['warn'](_0x3f7a9a['message']);}}}async function Ls(_0x32df31,_0x288281){try{const _0x787889=(await Jr())['transaction'](Rt,'readwrite');await _0x787889['objectStore'](Rt)['put'](_0x288281,Xr(_0x32df31)),await _0x787889['done'];}catch(_0x70aa93){if(_0x70aa93 instanceof Se)re['warn'](_0x70aa93['message']);else{const _0x2eb39a=ge['create']('idb-set',{'originalErrorMessage':_0x70aa93==null?void 0x0:_0x70aa93['message']});re['warn'](_0x2eb39a['message']);}}}function Xr(_0x6c0b60){return _0x6c0b60['name']+'!'+_0x6c0b60['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x130744){this['container']=_0x130744,this['_heartbeatsCache']=null;const _0x3225f8=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x3225f8),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x6e975f=>(this['_heartbeatsCache']=_0x6e975f,_0x6e975f));}async['triggerHeartbeat'](){var _0x53435e,_0x29b403;try{const _0x48c5e9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3b30b9=xs();if(((_0x53435e=this['_heartbeatsCache'])==null?void 0x0:_0x53435e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x29b403=this['_heartbeatsCache'])==null?void 0x0:_0x29b403['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3b30b9||this['_heartbeatsCache']['heartbeats']['some'](_0xa7fb70=>_0xa7fb70['date']===_0x3b30b9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3b30b9,'agent':_0x48c5e9}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x597861=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x597861,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xa4f84f){re['warn'](_0xa4f84f);}}async['getHeartbeatsHeader'](){var _0x20145d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x20145d=this['_heartbeatsCache'])==null?void 0x0:_0x20145d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3a3c26=xs(),{heartbeatsToSend:_0x3d6400,unsentEntries:_0x56c433}=kl(this['_heartbeatsCache']['heartbeats']),_0x5b617e=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3d6400}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3a3c26,_0x56c433['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x56c433,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5b617e;}catch(_0x1a2db8){return re['warn'](_0x1a2db8),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x1fdeb0,_0x16764a=bl){const _0x100433=[];let _0x36df62=_0x1fdeb0['slice']();for(const _0x15fd6b of _0x1fdeb0){const _0x2446ba=_0x100433['find'](_0x694674=>_0x694674['agent']===_0x15fd6b['agent']);if(_0x2446ba){if(_0x2446ba['dates']['push'](_0x15fd6b['date']),Fs(_0x100433)>_0x16764a){_0x2446ba['dates']['pop']();break;}}else{if(_0x100433['push']({'agent':_0x15fd6b['agent'],'dates':[_0x15fd6b['date']]}),Fs(_0x100433)>_0x16764a){_0x100433['pop']();break;}}_0x36df62=_0x36df62['slice'](0x1);}return{'heartbeatsToSend':_0x100433,'unsentEntries':_0x36df62};}class Nl{constructor(_0xf3fd7a){this['app']=_0xf3fd7a,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5a71f7=await Sl(this['app']);return _0x5a71f7!=null&&_0x5a71f7['heartbeats']?_0x5a71f7:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x93de0d){if(await this['_canUseIndexedDBPromise']){const _0x18dcdd=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x93de0d['lastSentHeartbeatDate']??_0x18dcdd['lastSentHeartbeatDate'],'heartbeats':_0x93de0d['heartbeats']});}else return;}async['add'](_0x18ce04){if(await this['_canUseIndexedDBPromise']){const _0x34249a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x18ce04['lastSentHeartbeatDate']??_0x34249a['lastSentHeartbeatDate'],'heartbeats':[..._0x34249a['heartbeats'],..._0x18ce04['heartbeats']]});}else return;}}function Fs(_0x1e2dd1){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1e2dd1}))['length'];}function Pl(_0x3f4e1d){if(_0x3f4e1d['length']===0x0)return-0x1;let _0x33b44b=0x0,_0x3b704b=_0x3f4e1d[0x0]['date'];for(let _0x3cca76=0x1;_0x3cca76<_0x3f4e1d['length'];_0x3cca76++)_0x3f4e1d[_0x3cca76]['date']<_0x3b704b&&(_0x3b704b=_0x3f4e1d[_0x3cca76]['date'],_0x33b44b=_0x3cca76);return _0x33b44b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x3f997d){et(new Me('platform-logger',_0x5ee951=>new Gc(_0x5ee951),'PRIVATE')),et(new Me('heartbeat',_0x1073bf=>new Al(_0x1073bf),'PRIVATE')),me(fi,Ds,_0x3f997d),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0xc12b4){Zr=_0xc12b4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1ec6ba){this['domStorage_']=_0x1ec6ba,this['prefix_']='firebase:';}['set'](_0xf81ad4,_0xfe9dad){_0xfe9dad==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xf81ad4)):this['domStorage_']['setItem'](this['prefixedName_'](_0xf81ad4),O(_0xfe9dad));}['get'](_0x56bf72){const _0x2f8d17=this['domStorage_']['getItem'](this['prefixedName_'](_0x56bf72));return _0x2f8d17==null?null:bt(_0x2f8d17);}['remove'](_0x12939f){this['domStorage_']['removeItem'](this['prefixedName_'](_0x12939f));}['prefixedName_'](_0x50c563){return this['prefix_']+_0x50c563;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x435ee7,_0x2a327e){_0x2a327e==null?delete this['cache_'][_0x435ee7]:this['cache_'][_0x435ee7]=_0x2a327e;}['get'](_0x268cbb){return Y(this['cache_'],_0x268cbb)?this['cache_'][_0x268cbb]:null;}['remove'](_0x81ca2b){delete this['cache_'][_0x81ca2b];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x336d65){try{if(typeof window<'u'&&typeof window[_0x336d65]<'u'){const _0x459a8b=window[_0x336d65];return _0x459a8b['setItem']('firebase:sentinel','cache'),_0x459a8b['removeItem']('firebase:sentinel'),new xl(_0x459a8b);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x4eddc4=0x1;return function(){return _0x4eddc4++;};}()),no=function(_0x54c1e2){const _0x4a9e4c=Tc(_0x54c1e2),_0x331ba3=new Ec();_0x331ba3['update'](_0x4a9e4c);const _0x1688d0=_0x331ba3['digest']();return Di['encodeByteArray'](_0x1688d0);},Bt=function(..._0x2a2c5f){let _0x31f5ce='';for(let _0x1bf16d=0x0;_0x1bf16d<_0x2a2c5f['length'];_0x1bf16d++){const _0x20e389=_0x2a2c5f[_0x1bf16d];Array['isArray'](_0x20e389)||_0x20e389&&typeof _0x20e389=='object'&&typeof _0x20e389['length']=='number'?_0x31f5ce+=Bt['apply'](null,_0x20e389):typeof _0x20e389=='object'?_0x31f5ce+=O(_0x20e389):_0x31f5ce+=_0x20e389,_0x31f5ce+='\x20';}return _0x31f5ce;};let Et=null,Vs=!0x0;const Wl=function(_0x49cdd6,_0x160808){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x2c5eda){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x58a13c=Bt['apply'](null,_0x2c5eda);Et(_0x58a13c);}},Vt=function(_0x7003dd){return function(..._0x2b0ad5){L(_0x7003dd,..._0x2b0ad5);};},mi=function(..._0x6ba41c){const _0x54ee8d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x6ba41c);Qe['error'](_0x54ee8d);},oe=function(..._0x245b5f){const _0x4a53d2='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x245b5f);throw Qe['error'](_0x4a53d2),new Error(_0x4a53d2);},U=function(..._0x294d98){const _0x14bc4e='FIREBASE\x20WARNING:\x20'+Bt(..._0x294d98);Qe['warn'](_0x14bc4e);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x3af2d2){return typeof _0x3af2d2=='number'&&(_0x3af2d2!==_0x3af2d2||_0x3af2d2===Number['POSITIVE_INFINITY']||_0x3af2d2===Number['NEGATIVE_INFINITY']);},Vl=function(_0x48aebe){if(document['readyState']==='complete')_0x48aebe();else{let _0x3fb19f=!0x1;const _0x5b8677=function(){if(!document['body']){setTimeout(_0x5b8677,Math['floor'](0xa));return;}_0x3fb19f||(_0x3fb19f=!0x0,_0x48aebe());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5b8677,!0x1),window['addEventListener']('load',_0x5b8677,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5b8677();}),window['attachEvent']('onload',_0x5b8677));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4f079d,_0x1ed2a9){if(_0x4f079d===_0x1ed2a9)return 0x0;if(_0x4f079d===xe||_0x1ed2a9===Ie)return-0x1;if(_0x1ed2a9===xe||_0x4f079d===Ie)return 0x1;{const _0x43b244=Hs(_0x4f079d),_0x11af86=Hs(_0x1ed2a9);return _0x43b244!==null?_0x11af86!==null?_0x43b244-_0x11af86===0x0?_0x4f079d['length']-_0x1ed2a9['length']:_0x43b244-_0x11af86:-0x1:_0x11af86!==null?0x1:_0x4f079d<_0x1ed2a9?-0x1:0x1;}},Hl=function(_0x11e0db,_0x160df4){return _0x11e0db===_0x160df4?0x0:_0x11e0db<_0x160df4?-0x1:0x1;},pt=function(_0x124642,_0x53f1a4){if(_0x53f1a4&&_0x124642 in _0x53f1a4)return _0x53f1a4[_0x124642];throw new Error('Missing\x20required\x20key\x20('+_0x124642+')\x20in\x20object:\x20'+O(_0x53f1a4));},Bi=function(_0x3f7993){if(typeof _0x3f7993!='object'||_0x3f7993===null)return O(_0x3f7993);const _0x2d3c73=[];for(const _0xde128 in _0x3f7993)_0x2d3c73['push'](_0xde128);_0x2d3c73['sort']();let _0x1c113a='{';for(let _0x54ed8d=0x0;_0x54ed8d<_0x2d3c73['length'];_0x54ed8d++)_0x54ed8d!==0x0&&(_0x1c113a+=','),_0x1c113a+=O(_0x2d3c73[_0x54ed8d]),_0x1c113a+=':',_0x1c113a+=Bi(_0x3f7993[_0x2d3c73[_0x54ed8d]]);return _0x1c113a+='}',_0x1c113a;},io=function(_0x21b2e7,_0x52d37a){const _0x131501=_0x21b2e7['length'];if(_0x131501<=_0x52d37a)return[_0x21b2e7];const _0x570b36=[];for(let _0x2922ef=0x0;_0x2922ef<_0x131501;_0x2922ef+=_0x52d37a)_0x2922ef+_0x52d37a>_0x131501?_0x570b36['push'](_0x21b2e7['substring'](_0x2922ef,_0x131501)):_0x570b36['push'](_0x21b2e7['substring'](_0x2922ef,_0x2922ef+_0x52d37a));return _0x570b36;};function x(_0x2b4b87,_0x39428c){for(const _0x46c616 in _0x2b4b87)_0x2b4b87['hasOwnProperty'](_0x46c616)&&_0x39428c(_0x46c616,_0x2b4b87[_0x46c616]);}const so=function(_0x9f58e0){f(!Wi(_0x9f58e0),'Invalid\x20JSON\x20number');const _0x278a4b=0xb,_0x2cb402=0x34,_0x284f9e=(0x1<<_0x278a4b-0x1)-0x1;let _0x154f30,_0x2827d3,_0x14c3bc,_0x5ceaff,_0x16525;_0x9f58e0===0x0?(_0x2827d3=0x0,_0x14c3bc=0x0,_0x154f30=0x1/_0x9f58e0===-0x1/0x0?0x1:0x0):(_0x154f30=_0x9f58e0<0x0,_0x9f58e0=Math['abs'](_0x9f58e0),_0x9f58e0>=Math['pow'](0x2,0x1-_0x284f9e)?(_0x5ceaff=Math['min'](Math['floor'](Math['log'](_0x9f58e0)/Math['LN2']),_0x284f9e),_0x2827d3=_0x5ceaff+_0x284f9e,_0x14c3bc=Math['round'](_0x9f58e0*Math['pow'](0x2,_0x2cb402-_0x5ceaff)-Math['pow'](0x2,_0x2cb402))):(_0x2827d3=0x0,_0x14c3bc=Math['round'](_0x9f58e0/Math['pow'](0x2,0x1-_0x284f9e-_0x2cb402))));const _0x4c36d8=[];for(_0x16525=_0x2cb402;_0x16525;_0x16525-=0x1)_0x4c36d8['push'](_0x14c3bc%0x2?0x1:0x0),_0x14c3bc=Math['floor'](_0x14c3bc/0x2);for(_0x16525=_0x278a4b;_0x16525;_0x16525-=0x1)_0x4c36d8['push'](_0x2827d3%0x2?0x1:0x0),_0x2827d3=Math['floor'](_0x2827d3/0x2);_0x4c36d8['push'](_0x154f30?0x1:0x0),_0x4c36d8['reverse']();const _0x37a37b=_0x4c36d8['join']('');let _0x338555='';for(_0x16525=0x0;_0x16525<0x40;_0x16525+=0x8){let _0x133309=parseInt(_0x37a37b['substr'](_0x16525,0x8),0x2)['toString'](0x10);_0x133309['length']===0x1&&(_0x133309='0'+_0x133309),_0x338555=_0x338555+_0x133309;}return _0x338555['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x409342,_0x44f6f4){let _0x532946='Unknown\x20Error';_0x409342==='too_big'?_0x532946='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x409342==='permission_denied'?_0x532946='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x409342==='unavailable'&&(_0x532946='The\x20service\x20is\x20unavailable');const _0x3d29f6=new Error(_0x409342+'\x20at\x20'+_0x44f6f4['_path']['toString']()+':\x20'+_0x532946);return _0x3d29f6['code']=_0x409342['toUpperCase'](),_0x3d29f6;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x48d6ba){if(zl['test'](_0x48d6ba)){const _0x319292=Number(_0x48d6ba);if(_0x319292>=jl&&_0x319292<=Kl)return _0x319292;}return null;},lt=function(_0x906898){try{_0x906898();}catch(_0x1fb4f2){setTimeout(()=>{const _0x145934=_0x1fb4f2['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x145934),_0x1fb4f2;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4a1052,_0x188c55){const _0xc826ef=setTimeout(_0x4a1052,_0x188c55);return typeof _0xc826ef=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xc826ef):typeof _0xc826ef=='object'&&_0xc826ef['unref']&&_0xc826ef['unref'](),_0xc826ef;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x59be7a,_0x16afc8){this['appCheckProvider']=_0x16afc8,this['appName']=_0x59be7a['name'],H(_0x59be7a)&&_0x59be7a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x59be7a['settings']['appCheckToken']),this['appCheck']=_0x16afc8==null?void 0x0:_0x16afc8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x16afc8==null||_0x16afc8['get']()['then'](_0x1bbc7f=>this['appCheck']=_0x1bbc7f);}['getToken'](_0x29daaf){if(this['serverAppAppCheckToken']){if(_0x29daaf)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x29daaf):new Promise((_0x546983,_0x1422ee)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x29daaf)['then'](_0x546983,_0x1422ee):_0x546983(null);},0x0);});}['addTokenChangeListener'](_0xaa63ee){var _0x26ae44;(_0x26ae44=this['appCheckProvider'])==null||_0x26ae44['get']()['then'](_0x8552ca=>_0x8552ca['addTokenListener'](_0xaa63ee));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0xc1a3c9,_0x4ac82a,_0xede4e4){this['appName_']=_0xc1a3c9,this['firebaseOptions_']=_0x4ac82a,this['authProvider_']=_0xede4e4,this['auth_']=null,this['auth_']=_0xede4e4['getImmediate']({'optional':!0x0}),this['auth_']||_0xede4e4['onInit'](_0xaf7eab=>this['auth_']=_0xaf7eab);}['getToken'](_0x2ddfd3){return this['auth_']?this['auth_']['getToken'](_0x2ddfd3)['catch'](_0x15754e=>_0x15754e&&_0x15754e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x15754e)):new Promise((_0x5f049e,_0x46b46b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2ddfd3)['then'](_0x5f049e,_0x46b46b):_0x5f049e(null);},0x0);});}['addTokenChangeListener'](_0x3f00c8){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3f00c8):this['authProvider_']['get']()['then'](_0xcb87c6=>_0xcb87c6['addAuthTokenListener'](_0x3f00c8));}['removeTokenChangeListener'](_0x423f9a){this['authProvider_']['get']()['then'](_0x736752=>_0x736752['removeAuthTokenListener'](_0x423f9a));}['notifyForInvalidToken'](){let _0xddf4e2='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xddf4e2+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xddf4e2+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xddf4e2+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xddf4e2);}}class tn{constructor(_0xfad944){this['accessToken']=_0xfad944;}['getToken'](_0xca0a3e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x24d906){_0x24d906(this['accessToken']);}['removeTokenChangeListener'](_0x23ba01){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0xab3b6b,_0x4e825c,_0x52d0c1,_0x35c695,_0x3b96ac=!0x1,_0x113eef='',_0xe8476e=!0x1,_0x2e56f4=!0x1,_0xd161c4=null){this['secure']=_0x4e825c,this['namespace']=_0x52d0c1,this['webSocketOnly']=_0x35c695,this['nodeAdmin']=_0x3b96ac,this['persistenceKey']=_0x113eef,this['includeNamespaceInQueryParams']=_0xe8476e,this['isUsingEmulator']=_0x2e56f4,this['emulatorOptions']=_0xd161c4,this['_host']=_0xab3b6b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0xab3b6b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5ac4a7){_0x5ac4a7!==this['internalHost']&&(this['internalHost']=_0x5ac4a7,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x534be8=this['toURLString']();return this['persistenceKey']&&(_0x534be8+='<'+this['persistenceKey']+'>'),_0x534be8;}['toURLString'](){const _0x51b0fd=this['secure']?'https://':'http://',_0x517443=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x51b0fd+this['host']+'/'+_0x517443;}}function Xl(_0x1385d0){return _0x1385d0['host']!==_0x1385d0['internalHost']||_0x1385d0['isCustomHost']()||_0x1385d0['includeNamespaceInQueryParams'];}function go(_0xa03d1d,_0x754a89,_0x1a30b4){f(typeof _0x754a89=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1a30b4=='object','typeof\x20params\x20must\x20==\x20object');let _0x1dac8e;if(_0x754a89===fo)_0x1dac8e=(_0xa03d1d['secure']?'wss://':'ws://')+_0xa03d1d['internalHost']+'/.ws?';else{if(_0x754a89===po)_0x1dac8e=(_0xa03d1d['secure']?'https://':'http://')+_0xa03d1d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x754a89);}Xl(_0xa03d1d)&&(_0x1a30b4['ns']=_0xa03d1d['namespace']);const _0x46f029=[];return x(_0x1a30b4,(_0x87395c,_0x103122)=>{_0x46f029['push'](_0x87395c+'='+_0x103122);}),_0x1dac8e+_0x46f029['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5f3b4b,_0x1a53b8=0x1){Y(this['counters_'],_0x5f3b4b)||(this['counters_'][_0x5f3b4b]=0x0),this['counters_'][_0x5f3b4b]+=_0x1a53b8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x2bbe85){const _0x1a0ff4=_0x2bbe85['toString']();return ti[_0x1a0ff4]||(ti[_0x1a0ff4]=new Zl()),ti[_0x1a0ff4];}function eh(_0x121b4d,_0x18fe0e){const _0x5be7e8=_0x121b4d['toString']();return ni[_0x5be7e8]||(ni[_0x5be7e8]=_0x18fe0e()),ni[_0x5be7e8];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4352d2){this['onMessage_']=_0x4352d2,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x285cf5,_0x1e13a0){this['closeAfterResponse']=_0x285cf5,this['onClose']=_0x1e13a0,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x392215,_0x289fbe){for(this['pendingResponses'][_0x392215]=_0x289fbe;this['pendingResponses'][this['currentResponseNum']];){const _0x393fc4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x19890b=0x0;_0x19890b<_0x393fc4['length'];++_0x19890b)_0x393fc4[_0x19890b]&&lt(()=>{this['onMessage_'](_0x393fc4[_0x19890b]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x46f714,_0x271499,_0x3aad68,_0x54b6f8,_0x4090fb,_0x2ac78d,_0xd3ad75){this['connId']=_0x46f714,this['repoInfo']=_0x271499,this['applicationId']=_0x3aad68,this['appCheckToken']=_0x54b6f8,this['authToken']=_0x4090fb,this['transportSessionId']=_0x2ac78d,this['lastSessionId']=_0xd3ad75,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x46f714),this['stats_']=Hi(_0x271499),this['urlFn']=_0x212b0f=>(this['appCheckToken']&&(_0x212b0f[yi]=this['appCheckToken']),go(_0x271499,po,_0x212b0f));}['open'](_0x4dea7c,_0xb437b9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xb437b9,this['myPacketOrderer']=new th(_0x4dea7c),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x5081a8)=>{const [_0x930d5,_0x96897b,_0x405db7,_0x95d9e3,_0x5f5444]=_0x5081a8;if(this['incrementIncomingBytes_'](_0x5081a8),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x930d5===$s)this['id']=_0x96897b,this['password']=_0x405db7;else{if(_0x930d5===nh)_0x96897b?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x96897b,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x930d5);}}},(..._0x43a686)=>{const [_0x4c30c2,_0x3f7a9b]=_0x43a686;this['incrementIncomingBytes_'](_0x43a686),this['myPacketOrderer']['handleResponse'](_0x4c30c2,_0x3f7a9b);},()=>{this['onClosed_']();},this['urlFn']);const _0x46ebbb={};_0x46ebbb[$s]='t',_0x46ebbb[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x46ebbb[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x46ebbb[ro]=Vi,this['transportSessionId']&&(_0x46ebbb[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x46ebbb[ho]=this['lastSessionId']),this['applicationId']&&(_0x46ebbb[uo]=this['applicationId']),this['appCheckToken']&&(_0x46ebbb[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x46ebbb[ao]=co);const _0x284043=this['urlFn'](_0x46ebbb);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x284043),this['scriptTagHolder']['addTag'](_0x284043,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x36f8bc){const _0x31e0ff=O(_0x36f8bc);this['bytesSent']+=_0x31e0ff['length'],this['stats_']['incrementCounter']('bytes_sent',_0x31e0ff['length']);const _0x247b62=Br(_0x31e0ff),_0xc1b70=io(_0x247b62,hh);for(let _0x3172f4=0x0;_0x3172f4<_0xc1b70['length'];_0x3172f4++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xc1b70['length'],_0xc1b70[_0x3172f4]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1fee82,_0x54d6e5){this['myDisconnFrame']=document['createElement']('iframe');const _0x5165a2={};_0x5165a2[lh]='t',_0x5165a2[mo]=_0x1fee82,_0x5165a2[yo]=_0x54d6e5,this['myDisconnFrame']['src']=this['urlFn'](_0x5165a2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x58371d){const _0x406bf8=O(_0x58371d)['length'];this['bytesReceived']+=_0x406bf8,this['stats_']['incrementCounter']('bytes_received',_0x406bf8);}}class $i{constructor(_0x4337e1,_0x14b26a,_0x3e24d2,_0x32f547){this['onDisconnect']=_0x3e24d2,this['urlFn']=_0x32f547,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x4337e1,window[sh+this['uniqueCallbackIdentifier']]=_0x14b26a,this['myIFrame']=$i['createIFrame_']();let _0x46be2f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x46be2f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3a5d2c='<html><body>'+_0x46be2f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3a5d2c),this['myIFrame']['doc']['close']();}catch(_0x460297){L('frame\x20writing\x20exception'),_0x460297['stack']&&L(_0x460297['stack']),L(_0x460297);}}}static['createIFrame_'](){const _0x57132f=document['createElement']('iframe');if(_0x57132f['style']['display']='none',document['body']){document['body']['appendChild'](_0x57132f);try{_0x57132f['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x367cc3=document['domain'];_0x57132f['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x367cc3+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x57132f['contentDocument']?_0x57132f['doc']=_0x57132f['contentDocument']:_0x57132f['contentWindow']?_0x57132f['doc']=_0x57132f['contentWindow']['document']:_0x57132f['document']&&(_0x57132f['doc']=_0x57132f['document']),_0x57132f;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x76b7cc=this['onDisconnect'];_0x76b7cc&&(this['onDisconnect']=null,_0x76b7cc());}['startLongPoll'](_0x31285a,_0x585307){for(this['myID']=_0x31285a,this['myPW']=_0x585307,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2cc0c1={};_0x2cc0c1[mo]=this['myID'],_0x2cc0c1[yo]=this['myPW'],_0x2cc0c1[vo]=this['currentSerial'];let _0x42c67e=this['urlFn'](_0x2cc0c1),_0x49bae2='',_0x166497=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x49bae2['length']<=Eo;){const _0x2b2493=this['pendingSegs']['shift']();_0x49bae2=_0x49bae2+'&'+oh+_0x166497+'='+_0x2b2493['seg']+'&'+ah+_0x166497+'='+_0x2b2493['ts']+'&'+ch+_0x166497+'='+_0x2b2493['d'],_0x166497++;}return _0x42c67e=_0x42c67e+_0x49bae2,this['addLongPollTag_'](_0x42c67e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x22579a,_0x4e2a3e,_0x2fb83d){this['pendingSegs']['push']({'seg':_0x22579a,'ts':_0x4e2a3e,'d':_0x2fb83d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2c861b,_0x5d162c){this['outstandingRequests']['add'](_0x5d162c);const _0x4920be=()=>{this['outstandingRequests']['delete'](_0x5d162c),this['newRequest_']();},_0x3a459f=setTimeout(_0x4920be,Math['floor'](uh)),_0x468bf8=()=>{clearTimeout(_0x3a459f),_0x4920be();};this['addTag'](_0x2c861b,_0x468bf8);}['addTag'](_0x467b48,_0x56b817){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5baf6e=this['myIFrame']['doc']['createElement']('script');_0x5baf6e['type']='text/javascript',_0x5baf6e['async']=!0x0,_0x5baf6e['src']=_0x467b48,_0x5baf6e['onload']=_0x5baf6e['onreadystatechange']=function(){const _0x462d64=_0x5baf6e['readyState'];(!_0x462d64||_0x462d64==='loaded'||_0x462d64==='complete')&&(_0x5baf6e['onload']=_0x5baf6e['onreadystatechange']=null,_0x5baf6e['parentNode']&&_0x5baf6e['parentNode']['removeChild'](_0x5baf6e),_0x56b817());},_0x5baf6e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x467b48),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5baf6e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x3962e0,_0x27a090,_0xde2467,_0x66d535,_0x457883,_0x46a091,_0x3371f6){this['connId']=_0x3962e0,this['applicationId']=_0xde2467,this['appCheckToken']=_0x66d535,this['authToken']=_0x457883,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x27a090),this['connURL']=G['connectionURL_'](_0x27a090,_0x46a091,_0x3371f6,_0x66d535,_0xde2467),this['nodeAdmin']=_0x27a090['nodeAdmin'];}static['connectionURL_'](_0x3898f3,_0x480fa3,_0x26e683,_0x219de8,_0x540793){const _0xd30f1c={};return _0xd30f1c[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xd30f1c[ao]=co),_0x480fa3&&(_0xd30f1c[oo]=_0x480fa3),_0x26e683&&(_0xd30f1c[ho]=_0x26e683),_0x219de8&&(_0xd30f1c[yi]=_0x219de8),_0x540793&&(_0xd30f1c[uo]=_0x540793),go(_0x3898f3,fo,_0xd30f1c);}['open'](_0x36f6ea,_0x5f3e8a){this['onDisconnect']=_0x5f3e8a,this['onMessage']=_0x36f6ea,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5cbe6f;dc(),this['mySock']=new hn(this['connURL'],[],_0x5cbe6f);}catch(_0x284fcc){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x29a2a1=_0x284fcc['message']||_0x284fcc['data'];_0x29a2a1&&this['log_'](_0x29a2a1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x17828d=>{this['handleIncomingFrame'](_0x17828d);},this['mySock']['onerror']=_0x55e3e7=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3972db=_0x55e3e7['message']||_0x55e3e7['data'];_0x3972db&&this['log_'](_0x3972db),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x149f43=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x487afd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xa4a746=navigator['userAgent']['match'](_0x487afd);_0xa4a746&&_0xa4a746['length']>0x1&&parseFloat(_0xa4a746[0x1])<4.4&&(_0x149f43=!0x0);}return!_0x149f43&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4d1c53){if(this['frames']['push'](_0x4d1c53),this['frames']['length']===this['totalFrames']){const _0x1c65b1=this['frames']['join']('');this['frames']=null;const _0x18ebc3=bt(_0x1c65b1);this['onMessage'](_0x18ebc3);}}['handleNewFrameCount_'](_0x1c3f3e){this['totalFrames']=_0x1c3f3e,this['frames']=[];}['extractFrameCount_'](_0x10299c){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x10299c['length']<=0x6){const _0x47b899=Number(_0x10299c);if(!isNaN(_0x47b899))return this['handleNewFrameCount_'](_0x47b899),null;}return this['handleNewFrameCount_'](0x1),_0x10299c;}['handleIncomingFrame'](_0x224bdc){if(this['mySock']===null)return;const _0x1b456c=_0x224bdc['data'];if(this['bytesReceived']+=_0x1b456c['length'],this['stats_']['incrementCounter']('bytes_received',_0x1b456c['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1b456c);else{const _0x236f15=this['extractFrameCount_'](_0x1b456c);_0x236f15!==null&&this['appendFrame_'](_0x236f15);}}['send'](_0x252741){this['resetKeepAlive']();const _0x8c0c70=O(_0x252741);this['bytesSent']+=_0x8c0c70['length'],this['stats_']['incrementCounter']('bytes_sent',_0x8c0c70['length']);const _0x551df6=io(_0x8c0c70,fh);_0x551df6['length']>0x1&&this['sendString_'](String(_0x551df6['length']));for(let _0x4a8f21=0x0;_0x4a8f21<_0x551df6['length'];_0x4a8f21++)this['sendString_'](_0x551df6[_0x4a8f21]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0xcde7ae){try{this['mySock']['send'](_0xcde7ae);}catch(_0x953de3){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x953de3['message']||_0x953de3['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x127260){this['initTransports_'](_0x127260);}['initTransports_'](_0x13703e){const _0x6d83f1=G&&G['isAvailable']();let _0x22f1ed=_0x6d83f1&&!G['previouslyFailed']();if(_0x13703e['webSocketOnly']&&(_0x6d83f1||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x22f1ed=!0x0),_0x22f1ed)this['transports_']=[G];else{const _0x24ce6b=this['transports_']=[];for(const _0x492ee0 of At['ALL_TRANSPORTS'])_0x492ee0&&_0x492ee0['isAvailable']()&&_0x24ce6b['push'](_0x492ee0);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x157744,_0x550a8d,_0x384476,_0x16073d,_0x22c2a0,_0x32107d,_0x377a42,_0x4576a8,_0x2fc306,_0x344fe2){this['id']=_0x157744,this['repoInfo_']=_0x550a8d,this['applicationId_']=_0x384476,this['appCheckToken_']=_0x16073d,this['authToken_']=_0x22c2a0,this['onMessage_']=_0x32107d,this['onReady_']=_0x377a42,this['onDisconnect_']=_0x4576a8,this['onKill_']=_0x2fc306,this['lastSessionId']=_0x344fe2,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x550a8d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1ae021=this['transportManager_']['initialTransport']();this['conn_']=new _0x1ae021(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1ae021['responsesRequiredToBeHealthy']||0x0;const _0x22ffc9=this['connReceiver_'](this['conn_']),_0x21d95c=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x22ffc9,_0x21d95c);},Math['floor'](0x0));const _0x4e8d93=_0x1ae021['healthyTimeout']||0x0;_0x4e8d93>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4e8d93)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5209e2){return _0x43b0d2=>{_0x5209e2===this['conn_']?this['onConnectionLost_'](_0x43b0d2):_0x5209e2===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x32c265){return _0x1c5e65=>{this['state_']!==0x2&&(_0x32c265===this['rx_']?this['onPrimaryMessageReceived_'](_0x1c5e65):_0x32c265===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1c5e65):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3004c0){const _0x32967a={'t':'d','d':_0x3004c0};this['sendData_'](_0x32967a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1bae0b){if(ii in _0x1bae0b){const _0x41c266=_0x1bae0b[ii];_0x41c266===js?this['upgradeIfSecondaryHealthy_']():_0x41c266===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x41c266===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x574fda){const _0xc5d8eb=pt('t',_0x574fda),_0xcb9ad=pt('d',_0x574fda);if(_0xc5d8eb==='c')this['onSecondaryControl_'](_0xcb9ad);else{if(_0xc5d8eb==='d')this['pendingDataMessages']['push'](_0xcb9ad);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xc5d8eb);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x20cb33){const _0x550d25=pt('t',_0x20cb33),_0x453236=pt('d',_0x20cb33);_0x550d25==='c'?this['onControl_'](_0x453236):_0x550d25==='d'&&this['onDataMessage_'](_0x453236);}['onDataMessage_'](_0x2fa63f){this['onPrimaryResponse_'](),this['onMessage_'](_0x2fa63f);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x514ce4){const _0x3ee373=pt(ii,_0x514ce4);if(Gs in _0x514ce4){const _0x4a13a4=_0x514ce4[Gs];if(_0x3ee373===Ih){const _0x547c30={..._0x4a13a4};this['repoInfo_']['isUsingEmulator']&&(_0x547c30['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x547c30);}else{if(_0x3ee373===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5f5486=0x0;_0x5f5486<this['pendingDataMessages']['length'];++_0x5f5486)this['onDataMessage_'](this['pendingDataMessages'][_0x5f5486]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3ee373===vh?this['onConnectionShutdown_'](_0x4a13a4):_0x3ee373===qs?this['onReset_'](_0x4a13a4):_0x3ee373===Eh?mi('Server\x20Error:\x20'+_0x4a13a4):_0x3ee373===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x3ee373);}}}['onHandshake_'](_0x7f18b7){const _0x10624f=_0x7f18b7['ts'],_0x290ffd=_0x7f18b7['v'],_0x118ed4=_0x7f18b7['h'];this['sessionId']=_0x7f18b7['s'],this['repoInfo_']['host']=_0x118ed4,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x10624f),Vi!==_0x290ffd&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x457086=this['transportManager_']['upgradeTransport']();_0x457086&&this['startUpgrade_'](_0x457086);}['startUpgrade_'](_0x158ef5){this['secondaryConn_']=new _0x158ef5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x158ef5['responsesRequiredToBeHealthy']||0x0;const _0x271038=this['connReceiver_'](this['secondaryConn_']),_0x43ede5=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x271038,_0x43ede5),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x418627){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x418627),this['repoInfo_']['host']=_0x418627,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x8b4383,_0x2ad38f){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x8b4383,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2ad38f,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x89cecc=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x89cecc||this['rx_']===_0x89cecc)&&this['close']();}['onConnectionLost_'](_0x416888){this['conn_']=null,!_0x416888&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x1b2910){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x1b2910),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x431ac4){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x431ac4);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x537a23,_0x27ece1,_0x1ee14a,_0x269509){}['merge'](_0x258f3d,_0x5b22a8,_0x2ef8be,_0x7ba155){}['refreshAuthToken'](_0x330c31){}['refreshAppCheckToken'](_0x5f00af){}['onDisconnectPut'](_0x63025b,_0x5c11dd,_0x2e41ae){}['onDisconnectMerge'](_0x44cf47,_0x4267ff,_0x4fa2a1){}['onDisconnectCancel'](_0x2a2b25,_0x825e43){}['reportStats'](_0x71de07){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x482cc9){this['allowedEvents_']=_0x482cc9,this['listeners_']={},f(Array['isArray'](_0x482cc9)&&_0x482cc9['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1f5d65,..._0x36fe74){if(Array['isArray'](this['listeners_'][_0x1f5d65])){const _0xd52e4a=[...this['listeners_'][_0x1f5d65]];for(let _0xa60a49=0x0;_0xa60a49<_0xd52e4a['length'];_0xa60a49++)_0xd52e4a[_0xa60a49]['callback']['apply'](_0xd52e4a[_0xa60a49]['context'],_0x36fe74);}}['on'](_0x5ddd0b,_0x4b84f7,_0x2fb7f6){this['validateEventType_'](_0x5ddd0b),this['listeners_'][_0x5ddd0b]=this['listeners_'][_0x5ddd0b]||[],this['listeners_'][_0x5ddd0b]['push']({'callback':_0x4b84f7,'context':_0x2fb7f6});const _0x4a0a0a=this['getInitialEvent'](_0x5ddd0b);_0x4a0a0a&&_0x4b84f7['apply'](_0x2fb7f6,_0x4a0a0a);}['off'](_0x17cecb,_0xbe05d,_0x3d8afc){this['validateEventType_'](_0x17cecb);const _0x175488=this['listeners_'][_0x17cecb]||[];for(let _0x2a95aa=0x0;_0x2a95aa<_0x175488['length'];_0x2a95aa++)if(_0x175488[_0x2a95aa]['callback']===_0xbe05d&&(!_0x3d8afc||_0x3d8afc===_0x175488[_0x2a95aa]['context'])){_0x175488['splice'](_0x2a95aa,0x1);return;}}['validateEventType_'](_0x30a085){f(this['allowedEvents_']['find'](_0x3da1d0=>_0x3da1d0===_0x30a085),'Unknown\x20event:\x20'+_0x30a085);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x47c03e){return f(_0x47c03e==='online','Unknown\x20event\x20type:\x20'+_0x47c03e),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x32e902,_0x397855){if(_0x397855===void 0x0){this['pieces_']=_0x32e902['split']('/');let _0x439658=0x0;for(let _0x34cb9e=0x0;_0x34cb9e<this['pieces_']['length'];_0x34cb9e++)this['pieces_'][_0x34cb9e]['length']>0x0&&(this['pieces_'][_0x439658]=this['pieces_'][_0x34cb9e],_0x439658++);this['pieces_']['length']=_0x439658,this['pieceNum_']=0x0;}else this['pieces_']=_0x32e902,this['pieceNum_']=_0x397855;}['toString'](){let _0x3cd1e3='';for(let _0x5586b3=this['pieceNum_'];_0x5586b3<this['pieces_']['length'];_0x5586b3++)this['pieces_'][_0x5586b3]!==''&&(_0x3cd1e3+='/'+this['pieces_'][_0x5586b3]);return _0x3cd1e3||'/';}}function w(){return new C('');}function y(_0x270431){return _0x270431['pieceNum_']>=_0x270431['pieces_']['length']?null:_0x270431['pieces_'][_0x270431['pieceNum_']];}function we(_0x1d8c39){return _0x1d8c39['pieces_']['length']-_0x1d8c39['pieceNum_'];}function b(_0x502147){let _0x58ac99=_0x502147['pieceNum_'];return _0x58ac99<_0x502147['pieces_']['length']&&_0x58ac99++,new C(_0x502147['pieces_'],_0x58ac99);}function Gi(_0x259cfb){return _0x259cfb['pieceNum_']<_0x259cfb['pieces_']['length']?_0x259cfb['pieces_'][_0x259cfb['pieces_']['length']-0x1]:null;}function Ch(_0x2d4e09){let _0x8cf2a1='';for(let _0x1d90d6=_0x2d4e09['pieceNum_'];_0x1d90d6<_0x2d4e09['pieces_']['length'];_0x1d90d6++)_0x2d4e09['pieces_'][_0x1d90d6]!==''&&(_0x8cf2a1+='/'+encodeURIComponent(String(_0x2d4e09['pieces_'][_0x1d90d6])));return _0x8cf2a1||'/';}function kt(_0x33e09f,_0x37ad2e=0x0){return _0x33e09f['pieces_']['slice'](_0x33e09f['pieceNum_']+_0x37ad2e);}function To(_0x3d73a6){if(_0x3d73a6['pieceNum_']>=_0x3d73a6['pieces_']['length'])return null;const _0x35b1fa=[];for(let _0x5a8167=_0x3d73a6['pieceNum_'];_0x5a8167<_0x3d73a6['pieces_']['length']-0x1;_0x5a8167++)_0x35b1fa['push'](_0x3d73a6['pieces_'][_0x5a8167]);return new C(_0x35b1fa,0x0);}function A(_0x3efd31,_0x59ba81){const _0x4d42d9=[];for(let _0xceef8=_0x3efd31['pieceNum_'];_0xceef8<_0x3efd31['pieces_']['length'];_0xceef8++)_0x4d42d9['push'](_0x3efd31['pieces_'][_0xceef8]);if(_0x59ba81 instanceof C){for(let _0x48ae5a=_0x59ba81['pieceNum_'];_0x48ae5a<_0x59ba81['pieces_']['length'];_0x48ae5a++)_0x4d42d9['push'](_0x59ba81['pieces_'][_0x48ae5a]);}else{const _0x4e88de=_0x59ba81['split']('/');for(let _0x1c383c=0x0;_0x1c383c<_0x4e88de['length'];_0x1c383c++)_0x4e88de[_0x1c383c]['length']>0x0&&_0x4d42d9['push'](_0x4e88de[_0x1c383c]);}return new C(_0x4d42d9,0x0);}function v(_0x1cdf52){return _0x1cdf52['pieceNum_']>=_0x1cdf52['pieces_']['length'];}function F(_0x315196,_0x53c758){const _0x6ab327=y(_0x315196),_0x22aef4=y(_0x53c758);if(_0x6ab327===null)return _0x53c758;if(_0x6ab327===_0x22aef4)return F(b(_0x315196),b(_0x53c758));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x53c758+')\x20is\x20not\x20within\x20outerPath\x20('+_0x315196+')');}function Th(_0x55909e,_0x8a985c){const _0x61d03=kt(_0x55909e,0x0),_0x59dcc3=kt(_0x8a985c,0x0);for(let _0xcc8326=0x0;_0xcc8326<_0x61d03['length']&&_0xcc8326<_0x59dcc3['length'];_0xcc8326++){const _0x41d261=He(_0x61d03[_0xcc8326],_0x59dcc3[_0xcc8326]);if(_0x41d261!==0x0)return _0x41d261;}return _0x61d03['length']===_0x59dcc3['length']?0x0:_0x61d03['length']<_0x59dcc3['length']?-0x1:0x1;}function qi(_0x4e2068,_0x29d031){if(we(_0x4e2068)!==we(_0x29d031))return!0x1;for(let _0x52b89a=_0x4e2068['pieceNum_'],_0x4d65aa=_0x29d031['pieceNum_'];_0x52b89a<=_0x4e2068['pieces_']['length'];_0x52b89a++,_0x4d65aa++)if(_0x4e2068['pieces_'][_0x52b89a]!==_0x29d031['pieces_'][_0x4d65aa])return!0x1;return!0x0;}function $(_0x4c7e5c,_0xfab809){let _0x45fd80=_0x4c7e5c['pieceNum_'],_0x25b7c0=_0xfab809['pieceNum_'];if(we(_0x4c7e5c)>we(_0xfab809))return!0x1;for(;_0x45fd80<_0x4c7e5c['pieces_']['length'];){if(_0x4c7e5c['pieces_'][_0x45fd80]!==_0xfab809['pieces_'][_0x25b7c0])return!0x1;++_0x45fd80,++_0x25b7c0;}return!0x0;}class Sh{constructor(_0x8c890e,_0x39e055){this['errorPrefix_']=_0x39e055,this['parts_']=kt(_0x8c890e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x50a1ad=0x0;_0x50a1ad<this['parts_']['length'];_0x50a1ad++)this['byteLength_']+=Pn(this['parts_'][_0x50a1ad]);So(this);}}function bh(_0x38e516,_0x1605f4){_0x38e516['parts_']['length']>0x0&&(_0x38e516['byteLength_']+=0x1),_0x38e516['parts_']['push'](_0x1605f4),_0x38e516['byteLength_']+=Pn(_0x1605f4),So(_0x38e516);}function Rh(_0x3fb3c2){const _0x44a202=_0x3fb3c2['parts_']['pop']();_0x3fb3c2['byteLength_']-=Pn(_0x44a202),_0x3fb3c2['parts_']['length']>0x0&&(_0x3fb3c2['byteLength_']-=0x1);}function So(_0x4ab378){if(_0x4ab378['byteLength_']>Js)throw new Error(_0x4ab378['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4ab378['byteLength_']+').');if(_0x4ab378['parts_']['length']>Qs)throw new Error(_0x4ab378['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4ab378));}function Ne(_0x4f9ce4){return _0x4f9ce4['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4f9ce4['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x11e693,_0xeadb5e;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xeadb5e='visibilitychange',_0x11e693='hidden'):typeof document['mozHidden']<'u'?(_0xeadb5e='mozvisibilitychange',_0x11e693='mozHidden'):typeof document['msHidden']<'u'?(_0xeadb5e='msvisibilitychange',_0x11e693='msHidden'):typeof document['webkitHidden']<'u'&&(_0xeadb5e='webkitvisibilitychange',_0x11e693='webkitHidden')),this['visible_']=!0x0,_0xeadb5e&&document['addEventListener'](_0xeadb5e,()=>{const _0x594e27=!document[_0x11e693];_0x594e27!==this['visible_']&&(this['visible_']=_0x594e27,this['trigger']('visible',_0x594e27));},!0x1);}['getInitialEvent'](_0x28a3bb){return f(_0x28a3bb==='visible','Unknown\x20event\x20type:\x20'+_0x28a3bb),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x241c4a,_0x416bd2,_0x22471a,_0x1d7eea,_0x4ffcc5,_0x4b7c2b,_0x43c3f0,_0x54d850){if(super(),this['repoInfo_']=_0x241c4a,this['applicationId_']=_0x416bd2,this['onDataUpdate_']=_0x22471a,this['onConnectStatus_']=_0x1d7eea,this['onServerInfoUpdate_']=_0x4ffcc5,this['authTokenProvider_']=_0x4b7c2b,this['appCheckTokenProvider_']=_0x43c3f0,this['authOverride_']=_0x54d850,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x54d850)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x241c4a['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5b9045,_0x349426,_0x2359ea){const _0x48e7d7=++this['requestNumber_'],_0x35440d={'r':_0x48e7d7,'a':_0x5b9045,'b':_0x349426};this['log_'](O(_0x35440d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x35440d),_0x2359ea&&(this['requestCBHash_'][_0x48e7d7]=_0x2359ea);}['get'](_0x1a443e){this['initConnection_']();const _0x1bf094=new Ve(),_0x424a03={'action':'g','request':{'p':_0x1a443e['_path']['toString'](),'q':_0x1a443e['_queryObject']},'onComplete':_0x59f191=>{const _0x348651=_0x59f191['d'];_0x59f191['s']==='ok'?_0x1bf094['resolve'](_0x348651):_0x1bf094['reject'](_0x348651);}};this['outstandingGets_']['push'](_0x424a03),this['outstandingGetCount_']++;const _0x2e35c6=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2e35c6),_0x1bf094['promise'];}['listen'](_0x12d8b1,_0x2e9154,_0x156fe0,_0x37f7ac){this['initConnection_']();const _0x2b180d=_0x12d8b1['_queryIdentifier'],_0x419e4a=_0x12d8b1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x419e4a+'\x20'+_0x2b180d),this['listens']['has'](_0x419e4a)||this['listens']['set'](_0x419e4a,new Map()),f(_0x12d8b1['_queryParams']['isDefault']()||!_0x12d8b1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x419e4a)['has'](_0x2b180d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x42d359={'onComplete':_0x37f7ac,'hashFn':_0x2e9154,'query':_0x12d8b1,'tag':_0x156fe0};this['listens']['get'](_0x419e4a)['set'](_0x2b180d,_0x42d359),this['connected_']&&this['sendListen_'](_0x42d359);}['sendGet_'](_0x225de3){const _0x5e5ee8=this['outstandingGets_'][_0x225de3];this['sendRequest']('g',_0x5e5ee8['request'],_0x3c677d=>{delete this['outstandingGets_'][_0x225de3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5e5ee8['onComplete']&&_0x5e5ee8['onComplete'](_0x3c677d);});}['sendListen_'](_0x5dd6af){const _0xc1a95a=_0x5dd6af['query'],_0x21e348=_0xc1a95a['_path']['toString'](),_0x423016=_0xc1a95a['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x21e348+'\x20for\x20'+_0x423016);const _0x30e5e3={'p':_0x21e348},_0x178fec='q';_0x5dd6af['tag']&&(_0x30e5e3['q']=_0xc1a95a['_queryObject'],_0x30e5e3['t']=_0x5dd6af['tag']),_0x30e5e3['h']=_0x5dd6af['hashFn'](),this['sendRequest'](_0x178fec,_0x30e5e3,_0x5069ae=>{const _0x5c1c4a=_0x5069ae['d'],_0x4d8d9c=_0x5069ae['s'];ie['warnOnListenWarnings_'](_0x5c1c4a,_0xc1a95a),(this['listens']['get'](_0x21e348)&&this['listens']['get'](_0x21e348)['get'](_0x423016))===_0x5dd6af&&(this['log_']('listen\x20response',_0x5069ae),_0x4d8d9c!=='ok'&&this['removeListen_'](_0x21e348,_0x423016),_0x5dd6af['onComplete']&&_0x5dd6af['onComplete'](_0x4d8d9c,_0x5c1c4a));});}static['warnOnListenWarnings_'](_0x23d786,_0x594bb5){if(_0x23d786&&typeof _0x23d786=='object'&&Y(_0x23d786,'w')){const _0x239e96=Oe(_0x23d786,'w');if(Array['isArray'](_0x239e96)&&~_0x239e96['indexOf']('no_index')){const _0xd48a62='\x22.indexOn\x22:\x20\x22'+_0x594bb5['_queryParams']['getIndex']()['toString']()+'\x22',_0x195201=_0x594bb5['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0xd48a62+'\x20at\x20'+_0x195201+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5285ee){this['authToken_']=_0x5285ee,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5285ee);}['reduceReconnectDelayIfAdminCredential_'](_0x56f126){(_0x56f126&&_0x56f126['length']===0x28||vc(_0x56f126))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x12277d){this['appCheckToken_']=_0x12277d,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x24b611=this['authToken_'],_0x32f6a1=yc(_0x24b611)?'auth':'gauth',_0x5b0029={'cred':_0x24b611};this['authOverride_']===null?_0x5b0029['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5b0029['authvar']=this['authOverride_']),this['sendRequest'](_0x32f6a1,_0x5b0029,_0x47be11=>{const _0x408947=_0x47be11['s'],_0x2b9de2=_0x47be11['d']||'error';this['authToken_']===_0x24b611&&(_0x408947==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x408947,_0x2b9de2));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x15b3b=>{const _0x2b5312=_0x15b3b['s'],_0x32986f=_0x15b3b['d']||'error';_0x2b5312==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2b5312,_0x32986f);});}['unlisten'](_0x48434c,_0xcfa810){const _0x35934c=_0x48434c['_path']['toString'](),_0x272012=_0x48434c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x35934c+'\x20'+_0x272012),f(_0x48434c['_queryParams']['isDefault']()||!_0x48434c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x35934c,_0x272012)&&this['connected_']&&this['sendUnlisten_'](_0x35934c,_0x272012,_0x48434c['_queryObject'],_0xcfa810);}['sendUnlisten_'](_0x515db2,_0x5696f7,_0x413752,_0xa17d3b){this['log_']('Unlisten\x20on\x20'+_0x515db2+'\x20for\x20'+_0x5696f7);const _0x15611b={'p':_0x515db2},_0x3c083e='n';_0xa17d3b&&(_0x15611b['q']=_0x413752,_0x15611b['t']=_0xa17d3b),this['sendRequest'](_0x3c083e,_0x15611b);}['onDisconnectPut'](_0x13fdd9,_0x54dd89,_0x2a2308){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x13fdd9,_0x54dd89,_0x2a2308):this['onDisconnectRequestQueue_']['push']({'pathString':_0x13fdd9,'action':'o','data':_0x54dd89,'onComplete':_0x2a2308});}['onDisconnectMerge'](_0x5b5e75,_0x581358,_0x34fc9f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5b5e75,_0x581358,_0x34fc9f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5b5e75,'action':'om','data':_0x581358,'onComplete':_0x34fc9f});}['onDisconnectCancel'](_0x31dc13,_0x515812){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x31dc13,null,_0x515812):this['onDisconnectRequestQueue_']['push']({'pathString':_0x31dc13,'action':'oc','data':null,'onComplete':_0x515812});}['sendOnDisconnect_'](_0x125e3c,_0x48b8a2,_0x586ff8,_0x38723d){const _0x5586e7={'p':_0x48b8a2,'d':_0x586ff8};this['log_']('onDisconnect\x20'+_0x125e3c,_0x5586e7),this['sendRequest'](_0x125e3c,_0x5586e7,_0x1689c8=>{_0x38723d&&setTimeout(()=>{_0x38723d(_0x1689c8['s'],_0x1689c8['d']);},Math['floor'](0x0));});}['put'](_0x1e3077,_0x599abe,_0x463397,_0x375268){this['putInternal']('p',_0x1e3077,_0x599abe,_0x463397,_0x375268);}['merge'](_0x1efd6c,_0xd81e38,_0x4706cb,_0x2f60c1){this['putInternal']('m',_0x1efd6c,_0xd81e38,_0x4706cb,_0x2f60c1);}['putInternal'](_0x2cce77,_0x1a6999,_0x1d7592,_0x212427,_0x308b22){this['initConnection_']();const _0x478f15={'p':_0x1a6999,'d':_0x1d7592};_0x308b22!==void 0x0&&(_0x478f15['h']=_0x308b22),this['outstandingPuts_']['push']({'action':_0x2cce77,'request':_0x478f15,'onComplete':_0x212427}),this['outstandingPutCount_']++;const _0x5c6f11=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5c6f11):this['log_']('Buffering\x20put:\x20'+_0x1a6999);}['sendPut_'](_0x4a943c){const _0x53389b=this['outstandingPuts_'][_0x4a943c]['action'],_0x3f6cf2=this['outstandingPuts_'][_0x4a943c]['request'],_0x1f3653=this['outstandingPuts_'][_0x4a943c]['onComplete'];this['outstandingPuts_'][_0x4a943c]['queued']=this['connected_'],this['sendRequest'](_0x53389b,_0x3f6cf2,_0xee79c4=>{this['log_'](_0x53389b+'\x20response',_0xee79c4),delete this['outstandingPuts_'][_0x4a943c],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1f3653&&_0x1f3653(_0xee79c4['s'],_0xee79c4['d']);});}['reportStats'](_0x41e7ce){if(this['connected_']){const _0x5e65f9={'c':_0x41e7ce};this['log_']('reportStats',_0x5e65f9),this['sendRequest']('s',_0x5e65f9,_0x5accf0=>{if(_0x5accf0['s']!=='ok'){const _0x24b39f=_0x5accf0['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x24b39f);}});}}['onDataMessage_'](_0x486119){if('r'in _0x486119){this['log_']('from\x20server:\x20'+O(_0x486119));const _0x2f1be0=_0x486119['r'],_0x211174=this['requestCBHash_'][_0x2f1be0];_0x211174&&(delete this['requestCBHash_'][_0x2f1be0],_0x211174(_0x486119['b']));}else{if('error'in _0x486119)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x486119['error'];'a'in _0x486119&&this['onDataPush_'](_0x486119['a'],_0x486119['b']);}}['onDataPush_'](_0x549670,_0x4bf157){this['log_']('handleServerMessage',_0x549670,_0x4bf157),_0x549670==='d'?this['onDataUpdate_'](_0x4bf157['p'],_0x4bf157['d'],!0x1,_0x4bf157['t']):_0x549670==='m'?this['onDataUpdate_'](_0x4bf157['p'],_0x4bf157['d'],!0x0,_0x4bf157['t']):_0x549670==='c'?this['onListenRevoked_'](_0x4bf157['p'],_0x4bf157['q']):_0x549670==='ac'?this['onAuthRevoked_'](_0x4bf157['s'],_0x4bf157['d']):_0x549670==='apc'?this['onAppCheckRevoked_'](_0x4bf157['s'],_0x4bf157['d']):_0x549670==='sd'?this['onSecurityDebugPacket_'](_0x4bf157):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x549670)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4edcaf,_0x55d572){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4edcaf),this['lastSessionId']=_0x55d572,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x19fa51){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x19fa51));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x487c7a){_0x487c7a&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x487c7a;}['onOnline_'](_0x4f69d0){_0x4f69d0?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x23b342=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x357ff6=Math['max'](0x0,this['reconnectDelay_']-_0x23b342);_0x357ff6=Math['random']()*_0x357ff6,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x357ff6+'ms'),this['scheduleConnect_'](_0x357ff6),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1a63f9=this['onDataMessage_']['bind'](this),_0x26d8d8=this['onReady_']['bind'](this),_0x19ca92=this['onRealtimeDisconnect_']['bind'](this),_0x1cbed7=this['id']+':'+ie['nextConnectionId_']++,_0x2d0234=this['lastSessionId'];let _0x2db893=!0x1,_0x26705d=null;const _0x227508=function(){_0x26705d?_0x26705d['close']():(_0x2db893=!0x0,_0x19ca92());},_0x21eaf9=function(_0x352e37){f(_0x26705d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x26705d['sendRequest'](_0x352e37);};this['realtime_']={'close':_0x227508,'sendRequest':_0x21eaf9};const _0x41a91d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5d51d1,_0x41f299]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x41a91d),this['appCheckTokenProvider_']['getToken'](_0x41a91d)]);_0x2db893?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5d51d1&&_0x5d51d1['accessToken'],this['appCheckToken_']=_0x41f299&&_0x41f299['token'],_0x26705d=new wh(_0x1cbed7,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1a63f9,_0x26d8d8,_0x19ca92,_0x38db7f=>{U(_0x38db7f+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x2d0234));}catch(_0x44e2c5){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x44e2c5),_0x2db893||(this['repoInfo_']['nodeAdmin']&&U(_0x44e2c5),_0x227508());}}}['interrupt'](_0x410b3b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x410b3b),this['interruptReasons_'][_0x410b3b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5a9bf6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5a9bf6),delete this['interruptReasons_'][_0x5a9bf6],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x272d0f){const _0xfb03b7=_0x272d0f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xfb03b7});}['cancelSentTransactions_'](){for(let _0x321fb6=0x0;_0x321fb6<this['outstandingPuts_']['length'];_0x321fb6++){const _0x18b981=this['outstandingPuts_'][_0x321fb6];_0x18b981&&'h'in _0x18b981['request']&&_0x18b981['queued']&&(_0x18b981['onComplete']&&_0x18b981['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x321fb6],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3cb675,_0x333c21){let _0x1165be;_0x333c21?_0x1165be=_0x333c21['map'](_0x257bb8=>Bi(_0x257bb8))['join']('$'):_0x1165be='default';const _0x240b44=this['removeListen_'](_0x3cb675,_0x1165be);_0x240b44&&_0x240b44['onComplete']&&_0x240b44['onComplete']('permission_denied');}['removeListen_'](_0xa02232,_0x2c06d5){const _0x189c30=new C(_0xa02232)['toString']();let _0x2e83ba;if(this['listens']['has'](_0x189c30)){const _0xc30710=this['listens']['get'](_0x189c30);_0x2e83ba=_0xc30710['get'](_0x2c06d5),_0xc30710['delete'](_0x2c06d5),_0xc30710['size']===0x0&&this['listens']['delete'](_0x189c30);}else _0x2e83ba=void 0x0;return _0x2e83ba;}['onAuthRevoked_'](_0xe76e8c,_0x47c075){L('Auth\x20token\x20revoked:\x20'+_0xe76e8c+'/'+_0x47c075),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xe76e8c==='invalid_token'||_0xe76e8c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x376eca,_0x306d9e){L('App\x20check\x20token\x20revoked:\x20'+_0x376eca+'/'+_0x306d9e),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x376eca==='invalid_token'||_0x376eca==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1f71e0){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1f71e0):'msg'in _0x1f71e0&&console['log']('FIREBASE:\x20'+_0x1f71e0['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x8960b8 of this['listens']['values']())for(const _0x16ba25 of _0x8960b8['values']())this['sendListen_'](_0x16ba25);for(let _0x1d1278=0x0;_0x1d1278<this['outstandingPuts_']['length'];_0x1d1278++)this['outstandingPuts_'][_0x1d1278]&&this['sendPut_'](_0x1d1278);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3d9d90=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3d9d90['action'],_0x3d9d90['pathString'],_0x3d9d90['data'],_0x3d9d90['onComplete']);}for(let _0x6da98=0x0;_0x6da98<this['outstandingGets_']['length'];_0x6da98++)this['outstandingGets_'][_0x6da98]&&this['sendGet_'](_0x6da98);}['sendConnectStats_'](){const _0x49adc4={};let _0x46546b='js';_0x49adc4['sdk.'+_0x46546b+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x49adc4['framework.cordova']=0x1:qr()&&(_0x49adc4['framework.reactnative']=0x1),this['reportStats'](_0x49adc4);}['shouldReconnect_'](){const _0x110336=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x110336;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x43ccbc,_0x5e6bdf){this['name']=_0x43ccbc,this['node']=_0x5e6bdf;}static['Wrap'](_0x2af38e,_0x512ae5){return new E(_0x2af38e,_0x512ae5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3d7b20,_0x47843a){const _0x21e0e3=new E(xe,_0x3d7b20),_0x286e8b=new E(xe,_0x47843a);return this['compare'](_0x21e0e3,_0x286e8b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2f5f80){Xt=_0x2f5f80;}['compare'](_0x4833ce,_0x36ae8c){return He(_0x4833ce['name'],_0x36ae8c['name']);}['isDefinedOn'](_0x2414ca){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x14fd3f,_0x47526d){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x25ef52,_0x1ab45c){return f(typeof _0x25ef52=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x25ef52,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x176a97,_0x4f7a53,_0x4be85b,_0x3598a2,_0x41c04e=null){this['isReverse_']=_0x3598a2,this['resultGenerator_']=_0x41c04e,this['nodeStack_']=[];let _0x980f68=0x1;for(;!_0x176a97['isEmpty']();)if(_0x176a97=_0x176a97,_0x980f68=_0x4f7a53?_0x4be85b(_0x176a97['key'],_0x4f7a53):0x1,_0x3598a2&&(_0x980f68*=-0x1),_0x980f68<0x0)this['isReverse_']?_0x176a97=_0x176a97['left']:_0x176a97=_0x176a97['right'];else{if(_0x980f68===0x0){this['nodeStack_']['push'](_0x176a97);break;}else this['nodeStack_']['push'](_0x176a97),this['isReverse_']?_0x176a97=_0x176a97['right']:_0x176a97=_0x176a97['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x54eaa5=this['nodeStack_']['pop'](),_0x1ffdfc;if(this['resultGenerator_']?_0x1ffdfc=this['resultGenerator_'](_0x54eaa5['key'],_0x54eaa5['value']):_0x1ffdfc={'key':_0x54eaa5['key'],'value':_0x54eaa5['value']},this['isReverse_']){for(_0x54eaa5=_0x54eaa5['left'];!_0x54eaa5['isEmpty']();)this['nodeStack_']['push'](_0x54eaa5),_0x54eaa5=_0x54eaa5['right'];}else{for(_0x54eaa5=_0x54eaa5['right'];!_0x54eaa5['isEmpty']();)this['nodeStack_']['push'](_0x54eaa5),_0x54eaa5=_0x54eaa5['left'];}return _0x1ffdfc;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3c5823=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3c5823['key'],_0x3c5823['value']):{'key':_0x3c5823['key'],'value':_0x3c5823['value']};}}class M{constructor(_0x5254da,_0x43eecd,_0x228c0a,_0xa88c87,_0x49726e){this['key']=_0x5254da,this['value']=_0x43eecd,this['color']=_0x228c0a??M['RED'],this['left']=_0xa88c87??B['EMPTY_NODE'],this['right']=_0x49726e??B['EMPTY_NODE'];}['copy'](_0x3add82,_0x5c0f61,_0xcc8242,_0x8bc7bd,_0x21e4af){return new M(_0x3add82??this['key'],_0x5c0f61??this['value'],_0xcc8242??this['color'],_0x8bc7bd??this['left'],_0x21e4af??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x220469){return this['left']['inorderTraversal'](_0x220469)||!!_0x220469(this['key'],this['value'])||this['right']['inorderTraversal'](_0x220469);}['reverseTraversal'](_0x54c1ad){return this['right']['reverseTraversal'](_0x54c1ad)||_0x54c1ad(this['key'],this['value'])||this['left']['reverseTraversal'](_0x54c1ad);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x134a60,_0x3ed587,_0x2828d4){let _0x32d5c2=this;const _0x94c429=_0x2828d4(_0x134a60,_0x32d5c2['key']);return _0x94c429<0x0?_0x32d5c2=_0x32d5c2['copy'](null,null,null,_0x32d5c2['left']['insert'](_0x134a60,_0x3ed587,_0x2828d4),null):_0x94c429===0x0?_0x32d5c2=_0x32d5c2['copy'](null,_0x3ed587,null,null,null):_0x32d5c2=_0x32d5c2['copy'](null,null,null,null,_0x32d5c2['right']['insert'](_0x134a60,_0x3ed587,_0x2828d4)),_0x32d5c2['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5dbdbf=this;return!_0x5dbdbf['left']['isRed_']()&&!_0x5dbdbf['left']['left']['isRed_']()&&(_0x5dbdbf=_0x5dbdbf['moveRedLeft_']()),_0x5dbdbf=_0x5dbdbf['copy'](null,null,null,_0x5dbdbf['left']['removeMin_'](),null),_0x5dbdbf['fixUp_']();}['remove'](_0x684b6a,_0x4109a3){let _0x3c450f,_0x410b31;if(_0x3c450f=this,_0x4109a3(_0x684b6a,_0x3c450f['key'])<0x0)!_0x3c450f['left']['isEmpty']()&&!_0x3c450f['left']['isRed_']()&&!_0x3c450f['left']['left']['isRed_']()&&(_0x3c450f=_0x3c450f['moveRedLeft_']()),_0x3c450f=_0x3c450f['copy'](null,null,null,_0x3c450f['left']['remove'](_0x684b6a,_0x4109a3),null);else{if(_0x3c450f['left']['isRed_']()&&(_0x3c450f=_0x3c450f['rotateRight_']()),!_0x3c450f['right']['isEmpty']()&&!_0x3c450f['right']['isRed_']()&&!_0x3c450f['right']['left']['isRed_']()&&(_0x3c450f=_0x3c450f['moveRedRight_']()),_0x4109a3(_0x684b6a,_0x3c450f['key'])===0x0){if(_0x3c450f['right']['isEmpty']())return B['EMPTY_NODE'];_0x410b31=_0x3c450f['right']['min_'](),_0x3c450f=_0x3c450f['copy'](_0x410b31['key'],_0x410b31['value'],null,null,_0x3c450f['right']['removeMin_']());}_0x3c450f=_0x3c450f['copy'](null,null,null,null,_0x3c450f['right']['remove'](_0x684b6a,_0x4109a3));}return _0x3c450f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4a4db6=this;return _0x4a4db6['right']['isRed_']()&&!_0x4a4db6['left']['isRed_']()&&(_0x4a4db6=_0x4a4db6['rotateLeft_']()),_0x4a4db6['left']['isRed_']()&&_0x4a4db6['left']['left']['isRed_']()&&(_0x4a4db6=_0x4a4db6['rotateRight_']()),_0x4a4db6['left']['isRed_']()&&_0x4a4db6['right']['isRed_']()&&(_0x4a4db6=_0x4a4db6['colorFlip_']()),_0x4a4db6;}['moveRedLeft_'](){let _0x1fb5b5=this['colorFlip_']();return _0x1fb5b5['right']['left']['isRed_']()&&(_0x1fb5b5=_0x1fb5b5['copy'](null,null,null,null,_0x1fb5b5['right']['rotateRight_']()),_0x1fb5b5=_0x1fb5b5['rotateLeft_'](),_0x1fb5b5=_0x1fb5b5['colorFlip_']()),_0x1fb5b5;}['moveRedRight_'](){let _0x3cc5bd=this['colorFlip_']();return _0x3cc5bd['left']['left']['isRed_']()&&(_0x3cc5bd=_0x3cc5bd['rotateRight_'](),_0x3cc5bd=_0x3cc5bd['colorFlip_']()),_0x3cc5bd;}['rotateLeft_'](){const _0x46a3d4=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x46a3d4,null);}['rotateRight_'](){const _0x39f79b=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x39f79b);}['colorFlip_'](){const _0x5c87b2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3a9422=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5c87b2,_0x3a9422);}['checkMaxDepth_'](){const _0x21372e=this['check_']();return Math['pow'](0x2,_0x21372e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x357dc4=this['left']['check_']();if(_0x357dc4!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x357dc4+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x21b170,_0x21b8da,_0x1ea29c,_0x1f678c,_0x1256ce){return this;}['insert'](_0x288264,_0x17bb58,_0x2e7cad){return new M(_0x288264,_0x17bb58,null);}['remove'](_0x3c0086,_0x59e495){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4ccd01){return!0x1;}['reverseTraversal'](_0x5c2501){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x262233,_0x1a3ab4=B['EMPTY_NODE']){this['comparator_']=_0x262233,this['root_']=_0x1a3ab4;}['insert'](_0xc82eb0,_0x5fb570){return new B(this['comparator_'],this['root_']['insert'](_0xc82eb0,_0x5fb570,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x54c03f){return new B(this['comparator_'],this['root_']['remove'](_0x54c03f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xa8e7f){let _0x3cc41b,_0x5aae4e=this['root_'];for(;!_0x5aae4e['isEmpty']();){if(_0x3cc41b=this['comparator_'](_0xa8e7f,_0x5aae4e['key']),_0x3cc41b===0x0)return _0x5aae4e['value'];_0x3cc41b<0x0?_0x5aae4e=_0x5aae4e['left']:_0x3cc41b>0x0&&(_0x5aae4e=_0x5aae4e['right']);}return null;}['getPredecessorKey'](_0x57c716){let _0x25351f,_0x538c80=this['root_'],_0x3a4caf=null;for(;!_0x538c80['isEmpty']();)if(_0x25351f=this['comparator_'](_0x57c716,_0x538c80['key']),_0x25351f===0x0){if(_0x538c80['left']['isEmpty']())return _0x3a4caf?_0x3a4caf['key']:null;for(_0x538c80=_0x538c80['left'];!_0x538c80['right']['isEmpty']();)_0x538c80=_0x538c80['right'];return _0x538c80['key'];}else _0x25351f<0x0?_0x538c80=_0x538c80['left']:_0x25351f>0x0&&(_0x3a4caf=_0x538c80,_0x538c80=_0x538c80['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2138fa){return this['root_']['inorderTraversal'](_0x2138fa);}['reverseTraversal'](_0x149288){return this['root_']['reverseTraversal'](_0x149288);}['getIterator'](_0x110ca7){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x110ca7);}['getIteratorFrom'](_0x40f314,_0x1643ea){return new Zt(this['root_'],_0x40f314,this['comparator_'],!0x1,_0x1643ea);}['getReverseIteratorFrom'](_0x3b5739,_0x3f913e){return new Zt(this['root_'],_0x3b5739,this['comparator_'],!0x0,_0x3f913e);}['getReverseIterator'](_0x3ef46a){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3ef46a);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x314ddd,_0x25b872){return He(_0x314ddd['name'],_0x25b872['name']);}function ji(_0x485ba1,_0xd9a17){return He(_0x485ba1,_0xd9a17);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5d84e6){vi=_0x5d84e6;}const Ro=function(_0x2f4faf){return typeof _0x2f4faf=='number'?'number:'+so(_0x2f4faf):'string:'+_0x2f4faf;},Ao=function(_0x16d301){if(_0x16d301['isLeafNode']()){const _0x5ec340=_0x16d301['val']();f(typeof _0x5ec340=='string'||typeof _0x5ec340=='number'||typeof _0x5ec340=='object'&&Y(_0x5ec340,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x16d301===vi||_0x16d301['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x16d301===vi||_0x16d301['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x153f80){er=_0x153f80;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x151558,_0x4bd294=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x151558,this['priorityNode_']=_0x4bd294,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x373f6e){return new D(this['value_'],_0x373f6e);}['getImmediateChild'](_0x50443f){return _0x50443f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3047a1){return v(_0x3047a1)?this:y(_0x3047a1)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x30a79e,_0x484930){return null;}['updateImmediateChild'](_0x586faa,_0x128466){return _0x586faa==='.priority'?this['updatePriority'](_0x128466):_0x128466['isEmpty']()&&_0x586faa!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x586faa,_0x128466)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x146258,_0x510cf9){const _0x24853d=y(_0x146258);return _0x24853d===null?_0x510cf9:_0x510cf9['isEmpty']()&&_0x24853d!=='.priority'?this:(f(_0x24853d!=='.priority'||we(_0x146258)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x24853d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x146258),_0x510cf9)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x49686b,_0x3f4ae4){return!0x1;}['val'](_0x1a7fe7){return _0x1a7fe7&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x9e8872='';this['priorityNode_']['isEmpty']()||(_0x9e8872+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x419aa9=typeof this['value_'];_0x9e8872+=_0x419aa9+':',_0x419aa9==='number'?_0x9e8872+=so(this['value_']):_0x9e8872+=this['value_'],this['lazyHash_']=no(_0x9e8872);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xf185af){return _0xf185af===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xf185af instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xf185af['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xf185af));}['compareToLeafNode_'](_0x59862a){const _0x671e94=typeof _0x59862a['value_'],_0x5ac6eb=typeof this['value_'],_0xfcefb7=D['VALUE_TYPE_ORDER']['indexOf'](_0x671e94),_0x12b21e=D['VALUE_TYPE_ORDER']['indexOf'](_0x5ac6eb);return f(_0xfcefb7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x671e94),f(_0x12b21e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5ac6eb),_0xfcefb7===_0x12b21e?_0x5ac6eb==='object'?0x0:this['value_']<_0x59862a['value_']?-0x1:this['value_']===_0x59862a['value_']?0x0:0x1:_0x12b21e-_0xfcefb7;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2740aa){if(_0x2740aa===this)return!0x0;if(_0x2740aa['isLeafNode']()){const _0x168bd3=_0x2740aa;return this['value_']===_0x168bd3['value_']&&this['priorityNode_']['equals'](_0x168bd3['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4ffdf0){ko=_0x4ffdf0;}function xh(_0x103439){No=_0x103439;}class Fh extends On{['compare'](_0x3deb63,_0x289579){const _0x44df1a=_0x3deb63['node']['getPriority'](),_0x590e9c=_0x289579['node']['getPriority'](),_0xd4d0a9=_0x44df1a['compareTo'](_0x590e9c);return _0xd4d0a9===0x0?He(_0x3deb63['name'],_0x289579['name']):_0xd4d0a9;}['isDefinedOn'](_0x1421e5){return!_0x1421e5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x492dfe,_0x38d3b7){return!_0x492dfe['getPriority']()['equals'](_0x38d3b7['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1d478a,_0x1e828d){const _0x23796e=ko(_0x1d478a);return new E(_0x1e828d,new D('[PRIORITY-POST]',_0x23796e));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x46051d){const _0x413c63=_0x5c13a8=>parseInt(Math['log'](_0x5c13a8)/Uh,0xa),_0x5245a1=_0x2cf768=>parseInt(Array(_0x2cf768+0x1)['join']('1'),0x2);this['count']=_0x413c63(_0x46051d+0x1),this['current_']=this['count']-0x1;const _0x4e2d0d=_0x5245a1(this['count']);this['bits_']=_0x46051d+0x1&_0x4e2d0d;}['nextBitIsOne'](){const _0x231310=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x231310;}}const dn=function(_0x215855,_0x50901d,_0x44b7ca,_0x16818d){_0x215855['sort'](_0x50901d);const _0x18e428=function(_0x1d04e6,_0x3174d3){const _0x11d675=_0x3174d3-_0x1d04e6;let _0x42463,_0x173326;if(_0x11d675===0x0)return null;if(_0x11d675===0x1)return _0x42463=_0x215855[_0x1d04e6],_0x173326=_0x44b7ca?_0x44b7ca(_0x42463):_0x42463,new M(_0x173326,_0x42463['node'],M['BLACK'],null,null);{const _0x5bd00e=parseInt(_0x11d675/0x2,0xa)+_0x1d04e6,_0x1b928c=_0x18e428(_0x1d04e6,_0x5bd00e),_0x2be7ee=_0x18e428(_0x5bd00e+0x1,_0x3174d3);return _0x42463=_0x215855[_0x5bd00e],_0x173326=_0x44b7ca?_0x44b7ca(_0x42463):_0x42463,new M(_0x173326,_0x42463['node'],M['BLACK'],_0x1b928c,_0x2be7ee);}},_0x2f5f1e=function(_0x28a7a6){let _0x4eca29=null,_0x4d800a=null,_0x100ff5=_0x215855['length'];const _0x42f0c3=function(_0x51e475,_0x113160){const _0x167c32=_0x100ff5-_0x51e475,_0x3eb1ec=_0x100ff5;_0x100ff5-=_0x51e475;const _0x17c4b6=_0x18e428(_0x167c32+0x1,_0x3eb1ec),_0x164bda=_0x215855[_0x167c32],_0x37d1e1=_0x44b7ca?_0x44b7ca(_0x164bda):_0x164bda;_0x1dfc25(new M(_0x37d1e1,_0x164bda['node'],_0x113160,null,_0x17c4b6));},_0x1dfc25=function(_0x3d9723){_0x4eca29?(_0x4eca29['left']=_0x3d9723,_0x4eca29=_0x3d9723):(_0x4d800a=_0x3d9723,_0x4eca29=_0x3d9723);};for(let _0x39d22c=0x0;_0x39d22c<_0x28a7a6['count'];++_0x39d22c){const _0x338521=_0x28a7a6['nextBitIsOne'](),_0x50fa27=Math['pow'](0x2,_0x28a7a6['count']-(_0x39d22c+0x1));_0x338521?_0x42f0c3(_0x50fa27,M['BLACK']):(_0x42f0c3(_0x50fa27,M['BLACK']),_0x42f0c3(_0x50fa27,M['RED']));}return _0x4d800a;},_0x1f6a7e=new Wh(_0x215855['length']),_0x17df40=_0x2f5f1e(_0x1f6a7e);return new B(_0x16818d||_0x50901d,_0x17df40);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x4cd132,_0x3e4ac4){this['indexes_']=_0x4cd132,this['indexSet_']=_0x3e4ac4;}['get'](_0x5a14b0){const _0x10a44e=Oe(this['indexes_'],_0x5a14b0);if(!_0x10a44e)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5a14b0);return _0x10a44e instanceof B?_0x10a44e:null;}['hasIndex'](_0x38a0a5){return Y(this['indexSet_'],_0x38a0a5['toString']());}['addIndex'](_0x56a1f0,_0x116389){f(_0x56a1f0!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x384ecb=[];let _0x3b3839=!0x1;const _0x119075=_0x116389['getIterator'](E['Wrap']);let _0x318dce=_0x119075['getNext']();for(;_0x318dce;)_0x3b3839=_0x3b3839||_0x56a1f0['isDefinedOn'](_0x318dce['node']),_0x384ecb['push'](_0x318dce),_0x318dce=_0x119075['getNext']();let _0x236745;_0x3b3839?_0x236745=dn(_0x384ecb,_0x56a1f0['getCompare']()):_0x236745=je;const _0x7b7c3e=_0x56a1f0['toString'](),_0x283c77={...this['indexSet_']};_0x283c77[_0x7b7c3e]=_0x56a1f0;const _0x1f8352={...this['indexes_']};return _0x1f8352[_0x7b7c3e]=_0x236745,new ee(_0x1f8352,_0x283c77);}['addToIndexes'](_0x3c0b21,_0x431dd3){const _0x588af1=ln(this['indexes_'],(_0x122053,_0x28a85f)=>{const _0x300379=Oe(this['indexSet_'],_0x28a85f);if(f(_0x300379,'Missing\x20index\x20implementation\x20for\x20'+_0x28a85f),_0x122053===je){if(_0x300379['isDefinedOn'](_0x3c0b21['node'])){const _0x5ed66d=[],_0x1a006b=_0x431dd3['getIterator'](E['Wrap']);let _0x30c688=_0x1a006b['getNext']();for(;_0x30c688;)_0x30c688['name']!==_0x3c0b21['name']&&_0x5ed66d['push'](_0x30c688),_0x30c688=_0x1a006b['getNext']();return _0x5ed66d['push'](_0x3c0b21),dn(_0x5ed66d,_0x300379['getCompare']());}else return je;}else{const _0x172759=_0x431dd3['get'](_0x3c0b21['name']);let _0x2c31ad=_0x122053;return _0x172759&&(_0x2c31ad=_0x2c31ad['remove'](new E(_0x3c0b21['name'],_0x172759))),_0x2c31ad['insert'](_0x3c0b21,_0x3c0b21['node']);}});return new ee(_0x588af1,this['indexSet_']);}['removeFromIndexes'](_0x364cf3,_0xc4ed6b){const _0x201462=ln(this['indexes_'],_0x2e5328=>{if(_0x2e5328===je)return _0x2e5328;{const _0x374156=_0xc4ed6b['get'](_0x364cf3['name']);return _0x374156?_0x2e5328['remove'](new E(_0x364cf3['name'],_0x374156)):_0x2e5328;}});return new ee(_0x201462,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3f47f5,_0x50d161,_0x7498cb){this['children_']=_0x3f47f5,this['priorityNode_']=_0x50d161,this['indexMap_']=_0x7498cb,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x174f38){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x174f38,this['indexMap_']);}['getImmediateChild'](_0x3f0fb3){if(_0x3f0fb3==='.priority')return this['getPriority']();{const _0x112904=this['children_']['get'](_0x3f0fb3);return _0x112904===null?gt:_0x112904;}}['getChild'](_0x3dbab1){const _0x495251=y(_0x3dbab1);return _0x495251===null?this:this['getImmediateChild'](_0x495251)['getChild'](b(_0x3dbab1));}['hasChild'](_0x2561ad){return this['children_']['get'](_0x2561ad)!==null;}['updateImmediateChild'](_0x3dd8df,_0x384995){if(f(_0x384995,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3dd8df==='.priority')return this['updatePriority'](_0x384995);{const _0x364d7a=new E(_0x3dd8df,_0x384995);let _0x597399,_0x1966fd;_0x384995['isEmpty']()?(_0x597399=this['children_']['remove'](_0x3dd8df),_0x1966fd=this['indexMap_']['removeFromIndexes'](_0x364d7a,this['children_'])):(_0x597399=this['children_']['insert'](_0x3dd8df,_0x384995),_0x1966fd=this['indexMap_']['addToIndexes'](_0x364d7a,this['children_']));const _0x5c4034=_0x597399['isEmpty']()?gt:this['priorityNode_'];return new g(_0x597399,_0x5c4034,_0x1966fd);}}['updateChild'](_0x1d4f67,_0x206724){const _0x356563=y(_0x1d4f67);if(_0x356563===null)return _0x206724;{f(y(_0x1d4f67)!=='.priority'||we(_0x1d4f67)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x414585=this['getImmediateChild'](_0x356563)['updateChild'](b(_0x1d4f67),_0x206724);return this['updateImmediateChild'](_0x356563,_0x414585);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3073b6){if(this['isEmpty']())return null;const _0x216362={};let _0xa730e0=0x0,_0x2addfa=0x0,_0x4d218e=!0x0;if(this['forEachChild'](R,(_0x553089,_0x312e26)=>{_0x216362[_0x553089]=_0x312e26['val'](_0x3073b6),_0xa730e0++,_0x4d218e&&g['INTEGER_REGEXP_']['test'](_0x553089)?_0x2addfa=Math['max'](_0x2addfa,Number(_0x553089)):_0x4d218e=!0x1;}),!_0x3073b6&&_0x4d218e&&_0x2addfa<0x2*_0xa730e0){const _0x5431fa=[];for(const _0x3bffce in _0x216362)_0x5431fa[_0x3bffce]=_0x216362[_0x3bffce];return _0x5431fa;}else return _0x3073b6&&!this['getPriority']()['isEmpty']()&&(_0x216362['.priority']=this['getPriority']()['val']()),_0x216362;}['hash'](){if(this['lazyHash_']===null){let _0x10e015='';this['getPriority']()['isEmpty']()||(_0x10e015+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x33f423,_0x465afa)=>{const _0x2e4e59=_0x465afa['hash']();_0x2e4e59!==''&&(_0x10e015+=':'+_0x33f423+':'+_0x2e4e59);}),this['lazyHash_']=_0x10e015===''?'':no(_0x10e015);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3e1d59,_0x25a11b,_0x1cf42d){const _0xf6be55=this['resolveIndex_'](_0x1cf42d);if(_0xf6be55){const _0x339f40=_0xf6be55['getPredecessorKey'](new E(_0x3e1d59,_0x25a11b));return _0x339f40?_0x339f40['name']:null;}else return this['children_']['getPredecessorKey'](_0x3e1d59);}['getFirstChildName'](_0x2ce3c6){const _0x1ee37b=this['resolveIndex_'](_0x2ce3c6);if(_0x1ee37b){const _0x85d0c8=_0x1ee37b['minKey']();return _0x85d0c8&&_0x85d0c8['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x412507){const _0x5f54ce=this['getFirstChildName'](_0x412507);return _0x5f54ce?new E(_0x5f54ce,this['children_']['get'](_0x5f54ce)):null;}['getLastChildName'](_0x5e7e3d){const _0x54bc48=this['resolveIndex_'](_0x5e7e3d);if(_0x54bc48){const _0x5e8db7=_0x54bc48['maxKey']();return _0x5e8db7&&_0x5e8db7['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xd6cd51){const _0x47b272=this['getLastChildName'](_0xd6cd51);return _0x47b272?new E(_0x47b272,this['children_']['get'](_0x47b272)):null;}['forEachChild'](_0x37032e,_0x471b4e){const _0x3124bf=this['resolveIndex_'](_0x37032e);return _0x3124bf?_0x3124bf['inorderTraversal'](_0x2b8f43=>_0x471b4e(_0x2b8f43['name'],_0x2b8f43['node'])):this['children_']['inorderTraversal'](_0x471b4e);}['getIterator'](_0x420cff){return this['getIteratorFrom'](_0x420cff['minPost'](),_0x420cff);}['getIteratorFrom'](_0x34e7b2,_0x3d42b6){const _0x7654e2=this['resolveIndex_'](_0x3d42b6);if(_0x7654e2)return _0x7654e2['getIteratorFrom'](_0x34e7b2,_0x3bfd39=>_0x3bfd39);{const _0x50e9fa=this['children_']['getIteratorFrom'](_0x34e7b2['name'],E['Wrap']);let _0x4812f8=_0x50e9fa['peek']();for(;_0x4812f8!=null&&_0x3d42b6['compare'](_0x4812f8,_0x34e7b2)<0x0;)_0x50e9fa['getNext'](),_0x4812f8=_0x50e9fa['peek']();return _0x50e9fa;}}['getReverseIterator'](_0xfc0c46){return this['getReverseIteratorFrom'](_0xfc0c46['maxPost'](),_0xfc0c46);}['getReverseIteratorFrom'](_0x23620a,_0x3f0bab){const _0x7c25cb=this['resolveIndex_'](_0x3f0bab);if(_0x7c25cb)return _0x7c25cb['getReverseIteratorFrom'](_0x23620a,_0x10f322=>_0x10f322);{const _0x2de2ca=this['children_']['getReverseIteratorFrom'](_0x23620a['name'],E['Wrap']);let _0x5c97cd=_0x2de2ca['peek']();for(;_0x5c97cd!=null&&_0x3f0bab['compare'](_0x5c97cd,_0x23620a)>0x0;)_0x2de2ca['getNext'](),_0x5c97cd=_0x2de2ca['peek']();return _0x2de2ca;}}['compareTo'](_0x1344f4){return this['isEmpty']()?_0x1344f4['isEmpty']()?0x0:-0x1:_0x1344f4['isLeafNode']()||_0x1344f4['isEmpty']()?0x1:_0x1344f4===Ht?-0x1:0x0;}['withIndex'](_0x3321a4){if(_0x3321a4===ye||this['indexMap_']['hasIndex'](_0x3321a4))return this;{const _0x579dca=this['indexMap_']['addIndex'](_0x3321a4,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x579dca);}}['isIndexed'](_0x237f7e){return _0x237f7e===ye||this['indexMap_']['hasIndex'](_0x237f7e);}['equals'](_0x4c8d60){if(_0x4c8d60===this)return!0x0;if(_0x4c8d60['isLeafNode']())return!0x1;{const _0xad64f0=_0x4c8d60;if(this['getPriority']()['equals'](_0xad64f0['getPriority']())){if(this['children_']['count']()===_0xad64f0['children_']['count']()){const _0x406903=this['getIterator'](R),_0x4081b8=_0xad64f0['getIterator'](R);let _0x81fb32=_0x406903['getNext'](),_0x3491d1=_0x4081b8['getNext']();for(;_0x81fb32&&_0x3491d1;){if(_0x81fb32['name']!==_0x3491d1['name']||!_0x81fb32['node']['equals'](_0x3491d1['node']))return!0x1;_0x81fb32=_0x406903['getNext'](),_0x3491d1=_0x4081b8['getNext']();}return _0x81fb32===null&&_0x3491d1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x49c06a){return _0x49c06a===ye?null:this['indexMap_']['get'](_0x49c06a['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x53ba2b){return _0x53ba2b===this?0x0:0x1;}['equals'](_0x2ed25a){return _0x2ed25a===this;}['getPriority'](){return this;}['getImmediateChild'](_0x26dede){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x2c633d,_0x37709e=null){if(_0x2c633d===null)return g['EMPTY_NODE'];if(typeof _0x2c633d=='object'&&'.priority'in _0x2c633d&&(_0x37709e=_0x2c633d['.priority']),f(_0x37709e===null||typeof _0x37709e=='string'||typeof _0x37709e=='number'||typeof _0x37709e=='object'&&'.sv'in _0x37709e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x37709e),typeof _0x2c633d=='object'&&'.value'in _0x2c633d&&_0x2c633d['.value']!==null&&(_0x2c633d=_0x2c633d['.value']),typeof _0x2c633d!='object'||'.sv'in _0x2c633d){const _0x7c69b4=_0x2c633d;return new D(_0x7c69b4,N(_0x37709e));}if(!(_0x2c633d instanceof Array)&&Vh){const _0x30d2d3=[];let _0x594055=!0x1;if(x(_0x2c633d,(_0x1b93af,_0x15e55b)=>{if(_0x1b93af['substring'](0x0,0x1)!=='.'){const _0x294020=N(_0x15e55b);_0x294020['isEmpty']()||(_0x594055=_0x594055||!_0x294020['getPriority']()['isEmpty'](),_0x30d2d3['push'](new E(_0x1b93af,_0x294020)));}}),_0x30d2d3['length']===0x0)return g['EMPTY_NODE'];const _0x2ccf6a=dn(_0x30d2d3,Dh,_0x580c53=>_0x580c53['name'],ji);if(_0x594055){const _0x438fcd=dn(_0x30d2d3,R['getCompare']());return new g(_0x2ccf6a,N(_0x37709e),new ee({'.priority':_0x438fcd},{'.priority':R}));}else return new g(_0x2ccf6a,N(_0x37709e),ee['Default']);}else{let _0xfd5212=g['EMPTY_NODE'];return x(_0x2c633d,(_0x4719fb,_0x4d02d8)=>{if(Y(_0x2c633d,_0x4719fb)&&_0x4719fb['substring'](0x0,0x1)!=='.'){const _0x22c1d4=N(_0x4d02d8);(_0x22c1d4['isLeafNode']()||!_0x22c1d4['isEmpty']())&&(_0xfd5212=_0xfd5212['updateImmediateChild'](_0x4719fb,_0x22c1d4));}}),_0xfd5212['updatePriority'](N(_0x37709e));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3b683c){super(),this['indexPath_']=_0x3b683c,f(!v(_0x3b683c)&&y(_0x3b683c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x416824){return _0x416824['getChild'](this['indexPath_']);}['isDefinedOn'](_0x338ed5){return!_0x338ed5['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4a0934,_0x203434){const _0xcc5e7e=this['extractChild'](_0x4a0934['node']),_0x588bc8=this['extractChild'](_0x203434['node']),_0x3ef6f2=_0xcc5e7e['compareTo'](_0x588bc8);return _0x3ef6f2===0x0?He(_0x4a0934['name'],_0x203434['name']):_0x3ef6f2;}['makePost'](_0x24ccc8,_0x187f7d){const _0xa567ab=N(_0x24ccc8),_0x5a16a9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xa567ab);return new E(_0x187f7d,_0x5a16a9);}['maxPost'](){const _0x8a9d41=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x8a9d41);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x2cadf9,_0x3976f2){const _0x39c529=_0x2cadf9['node']['compareTo'](_0x3976f2['node']);return _0x39c529===0x0?He(_0x2cadf9['name'],_0x3976f2['name']):_0x39c529;}['isDefinedOn'](_0x149590){return!0x0;}['indexedValueChanged'](_0x27fa01,_0x131dea){return!_0x27fa01['equals'](_0x131dea);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x140436,_0x4d6390){const _0x42a9ff=N(_0x140436);return new E(_0x4d6390,_0x42a9ff);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x231b0b){return{'type':'value','snapshotNode':_0x231b0b};}function tt(_0x31b595,_0x4f56a3){return{'type':'child_added','snapshotNode':_0x4f56a3,'childName':_0x31b595};}function Nt(_0x1e8755,_0x46e8ea){return{'type':'child_removed','snapshotNode':_0x46e8ea,'childName':_0x1e8755};}function Pt(_0x5164ed,_0x1cd128,_0x160717){return{'type':'child_changed','snapshotNode':_0x1cd128,'childName':_0x5164ed,'oldSnap':_0x160717};}function $h(_0x5d2c23,_0x177865){return{'type':'child_moved','snapshotNode':_0x177865,'childName':_0x5d2c23};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x338340){this['index_']=_0x338340;}['updateChild'](_0x14ab74,_0x4e47a3,_0x3aa6ec,_0x532fb5,_0x7eb00c,_0x41230b){f(_0x14ab74['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xb144aa=_0x14ab74['getImmediateChild'](_0x4e47a3);return _0xb144aa['getChild'](_0x532fb5)['equals'](_0x3aa6ec['getChild'](_0x532fb5))&&_0xb144aa['isEmpty']()===_0x3aa6ec['isEmpty']()||(_0x41230b!=null&&(_0x3aa6ec['isEmpty']()?_0x14ab74['hasChild'](_0x4e47a3)?_0x41230b['trackChildChange'](Nt(_0x4e47a3,_0xb144aa)):f(_0x14ab74['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xb144aa['isEmpty']()?_0x41230b['trackChildChange'](tt(_0x4e47a3,_0x3aa6ec)):_0x41230b['trackChildChange'](Pt(_0x4e47a3,_0x3aa6ec,_0xb144aa))),_0x14ab74['isLeafNode']()&&_0x3aa6ec['isEmpty']())?_0x14ab74:_0x14ab74['updateImmediateChild'](_0x4e47a3,_0x3aa6ec)['withIndex'](this['index_']);}['updateFullNode'](_0x4dfc12,_0x28e536,_0x282524){return _0x282524!=null&&(_0x4dfc12['isLeafNode']()||_0x4dfc12['forEachChild'](R,(_0x22f8d6,_0x41cb21)=>{_0x28e536['hasChild'](_0x22f8d6)||_0x282524['trackChildChange'](Nt(_0x22f8d6,_0x41cb21));}),_0x28e536['isLeafNode']()||_0x28e536['forEachChild'](R,(_0x1b85d1,_0x363f5f)=>{if(_0x4dfc12['hasChild'](_0x1b85d1)){const _0x244e90=_0x4dfc12['getImmediateChild'](_0x1b85d1);_0x244e90['equals'](_0x363f5f)||_0x282524['trackChildChange'](Pt(_0x1b85d1,_0x363f5f,_0x244e90));}else _0x282524['trackChildChange'](tt(_0x1b85d1,_0x363f5f));})),_0x28e536['withIndex'](this['index_']);}['updatePriority'](_0x3e45cb,_0x1b64a4){return _0x3e45cb['isEmpty']()?g['EMPTY_NODE']:_0x3e45cb['updatePriority'](_0x1b64a4);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x59a5cf){this['indexedFilter_']=new Yi(_0x59a5cf['getIndex']()),this['index_']=_0x59a5cf['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x59a5cf),this['endPost_']=Ot['getEndPost_'](_0x59a5cf),this['startIsInclusive_']=!_0x59a5cf['startAfterSet_'],this['endIsInclusive_']=!_0x59a5cf['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x355431){const _0xce97bd=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x355431)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x355431)<0x0,_0x380207=this['endIsInclusive_']?this['index_']['compare'](_0x355431,this['getEndPost']())<=0x0:this['index_']['compare'](_0x355431,this['getEndPost']())<0x0;return _0xce97bd&&_0x380207;}['updateChild'](_0x5d468b,_0x31e562,_0x34f12f,_0x173ae7,_0x412053,_0x153555){return this['matches'](new E(_0x31e562,_0x34f12f))||(_0x34f12f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5d468b,_0x31e562,_0x34f12f,_0x173ae7,_0x412053,_0x153555);}['updateFullNode'](_0x49ce17,_0x4f47a9,_0x4950f7){_0x4f47a9['isLeafNode']()&&(_0x4f47a9=g['EMPTY_NODE']);let _0x51b3dc=_0x4f47a9['withIndex'](this['index_']);_0x51b3dc=_0x51b3dc['updatePriority'](g['EMPTY_NODE']);const _0x3dae8e=this;return _0x4f47a9['forEachChild'](R,(_0x47b529,_0x47c27a)=>{_0x3dae8e['matches'](new E(_0x47b529,_0x47c27a))||(_0x51b3dc=_0x51b3dc['updateImmediateChild'](_0x47b529,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x49ce17,_0x51b3dc,_0x4950f7);}['updatePriority'](_0x52475b,_0x1959ac){return _0x52475b;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2965c4){if(_0x2965c4['hasStart']()){const _0x548ecf=_0x2965c4['getIndexStartName']();return _0x2965c4['getIndex']()['makePost'](_0x2965c4['getIndexStartValue'](),_0x548ecf);}else return _0x2965c4['getIndex']()['minPost']();}static['getEndPost_'](_0x55e9f2){if(_0x55e9f2['hasEnd']()){const _0x1c732f=_0x55e9f2['getIndexEndName']();return _0x55e9f2['getIndex']()['makePost'](_0x55e9f2['getIndexEndValue'](),_0x1c732f);}else return _0x55e9f2['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x3ca147){this['withinDirectionalStart']=_0x5b4f02=>this['reverse_']?this['withinEndPost'](_0x5b4f02):this['withinStartPost'](_0x5b4f02),this['withinDirectionalEnd']=_0x2f8156=>this['reverse_']?this['withinStartPost'](_0x2f8156):this['withinEndPost'](_0x2f8156),this['withinStartPost']=_0x51f47a=>{const _0x519123=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x51f47a);return this['startIsInclusive_']?_0x519123<=0x0:_0x519123<0x0;},this['withinEndPost']=_0x255ca2=>{const _0x5125f4=this['index_']['compare'](_0x255ca2,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5125f4<=0x0:_0x5125f4<0x0;},this['rangedFilter_']=new Ot(_0x3ca147),this['index_']=_0x3ca147['getIndex'](),this['limit_']=_0x3ca147['getLimit'](),this['reverse_']=!_0x3ca147['isViewFromLeft'](),this['startIsInclusive_']=!_0x3ca147['startAfterSet_'],this['endIsInclusive_']=!_0x3ca147['endBeforeSet_'];}['updateChild'](_0x1bad1c,_0x3f9458,_0x2c0883,_0x189074,_0x1cfd01,_0x19e438){return this['rangedFilter_']['matches'](new E(_0x3f9458,_0x2c0883))||(_0x2c0883=g['EMPTY_NODE']),_0x1bad1c['getImmediateChild'](_0x3f9458)['equals'](_0x2c0883)?_0x1bad1c:_0x1bad1c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1bad1c,_0x3f9458,_0x2c0883,_0x189074,_0x1cfd01,_0x19e438):this['fullLimitUpdateChild_'](_0x1bad1c,_0x3f9458,_0x2c0883,_0x1cfd01,_0x19e438);}['updateFullNode'](_0x21b2b9,_0x3de908,_0x29076a){let _0x3b3f10;if(_0x3de908['isLeafNode']()||_0x3de908['isEmpty']())_0x3b3f10=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x3de908['numChildren']()&&_0x3de908['isIndexed'](this['index_'])){_0x3b3f10=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5c6e4e;this['reverse_']?_0x5c6e4e=_0x3de908['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5c6e4e=_0x3de908['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x14f98c=0x0;for(;_0x5c6e4e['hasNext']()&&_0x14f98c<this['limit_'];){const _0x42cb97=_0x5c6e4e['getNext']();if(this['withinDirectionalStart'](_0x42cb97)){if(this['withinDirectionalEnd'](_0x42cb97))_0x3b3f10=_0x3b3f10['updateImmediateChild'](_0x42cb97['name'],_0x42cb97['node']),_0x14f98c++;else break;}else continue;}}else{_0x3b3f10=_0x3de908['withIndex'](this['index_']),_0x3b3f10=_0x3b3f10['updatePriority'](g['EMPTY_NODE']);let _0x2ada16;this['reverse_']?_0x2ada16=_0x3b3f10['getReverseIterator'](this['index_']):_0x2ada16=_0x3b3f10['getIterator'](this['index_']);let _0x271706=0x0;for(;_0x2ada16['hasNext']();){const _0x309615=_0x2ada16['getNext']();_0x271706<this['limit_']&&this['withinDirectionalStart'](_0x309615)&&this['withinDirectionalEnd'](_0x309615)?_0x271706++:_0x3b3f10=_0x3b3f10['updateImmediateChild'](_0x309615['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x21b2b9,_0x3b3f10,_0x29076a);}['updatePriority'](_0x36c105,_0xd66b96){return _0x36c105;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x595fd8,_0x3062a2,_0x2f3308,_0x3ea1e8,_0x7348f4){let _0x565d57;if(this['reverse_']){const _0xedefc7=this['index_']['getCompare']();_0x565d57=(_0x3ea8cd,_0x1d6ffa)=>_0xedefc7(_0x1d6ffa,_0x3ea8cd);}else _0x565d57=this['index_']['getCompare']();const _0x50c5ca=_0x595fd8;f(_0x50c5ca['numChildren']()===this['limit_'],'');const _0x161d88=new E(_0x3062a2,_0x2f3308),_0x58515f=this['reverse_']?_0x50c5ca['getFirstChild'](this['index_']):_0x50c5ca['getLastChild'](this['index_']),_0x575982=this['rangedFilter_']['matches'](_0x161d88);if(_0x50c5ca['hasChild'](_0x3062a2)){const _0x209ae7=_0x50c5ca['getImmediateChild'](_0x3062a2);let _0x57e2ae=_0x3ea1e8['getChildAfterChild'](this['index_'],_0x58515f,this['reverse_']);for(;_0x57e2ae!=null&&(_0x57e2ae['name']===_0x3062a2||_0x50c5ca['hasChild'](_0x57e2ae['name']));)_0x57e2ae=_0x3ea1e8['getChildAfterChild'](this['index_'],_0x57e2ae,this['reverse_']);const _0x4f726e=_0x57e2ae==null?0x1:_0x565d57(_0x57e2ae,_0x161d88);if(_0x575982&&!_0x2f3308['isEmpty']()&&_0x4f726e>=0x0)return _0x7348f4!=null&&_0x7348f4['trackChildChange'](Pt(_0x3062a2,_0x2f3308,_0x209ae7)),_0x50c5ca['updateImmediateChild'](_0x3062a2,_0x2f3308);{_0x7348f4!=null&&_0x7348f4['trackChildChange'](Nt(_0x3062a2,_0x209ae7));const _0x459008=_0x50c5ca['updateImmediateChild'](_0x3062a2,g['EMPTY_NODE']);return _0x57e2ae!=null&&this['rangedFilter_']['matches'](_0x57e2ae)?(_0x7348f4!=null&&_0x7348f4['trackChildChange'](tt(_0x57e2ae['name'],_0x57e2ae['node'])),_0x459008['updateImmediateChild'](_0x57e2ae['name'],_0x57e2ae['node'])):_0x459008;}}else return _0x2f3308['isEmpty']()?_0x595fd8:_0x575982&&_0x565d57(_0x58515f,_0x161d88)>=0x0?(_0x7348f4!=null&&(_0x7348f4['trackChildChange'](Nt(_0x58515f['name'],_0x58515f['node'])),_0x7348f4['trackChildChange'](tt(_0x3062a2,_0x2f3308))),_0x50c5ca['updateImmediateChild'](_0x3062a2,_0x2f3308)['updateImmediateChild'](_0x58515f['name'],g['EMPTY_NODE'])):_0x595fd8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5a04cb=new Qi();return _0x5a04cb['limitSet_']=this['limitSet_'],_0x5a04cb['limit_']=this['limit_'],_0x5a04cb['startSet_']=this['startSet_'],_0x5a04cb['startAfterSet_']=this['startAfterSet_'],_0x5a04cb['indexStartValue_']=this['indexStartValue_'],_0x5a04cb['startNameSet_']=this['startNameSet_'],_0x5a04cb['indexStartName_']=this['indexStartName_'],_0x5a04cb['endSet_']=this['endSet_'],_0x5a04cb['endBeforeSet_']=this['endBeforeSet_'],_0x5a04cb['indexEndValue_']=this['indexEndValue_'],_0x5a04cb['endNameSet_']=this['endNameSet_'],_0x5a04cb['indexEndName_']=this['indexEndName_'],_0x5a04cb['index_']=this['index_'],_0x5a04cb['viewFrom_']=this['viewFrom_'],_0x5a04cb;}}function qh(_0xd34f11){return _0xd34f11['loadsAllData']()?new Yi(_0xd34f11['getIndex']()):_0xd34f11['hasLimit']()?new Gh(_0xd34f11):new Ot(_0xd34f11);}function zh(_0x1ba4ed,_0xd104d){const _0x26f72f=_0x1ba4ed['copy']();return _0x26f72f['limitSet_']=!0x0,_0x26f72f['limit_']=_0xd104d,_0x26f72f['viewFrom_']='l',_0x26f72f;}function jh(_0x4af668,_0x1b3399,_0x2b8f1b){const _0x5d2fd5=_0x4af668['copy']();return _0x5d2fd5['startSet_']=!0x0,_0x1b3399===void 0x0&&(_0x1b3399=null),_0x5d2fd5['indexStartValue_']=_0x1b3399,_0x2b8f1b!=null?(_0x5d2fd5['startNameSet_']=!0x0,_0x5d2fd5['indexStartName_']=_0x2b8f1b):(_0x5d2fd5['startNameSet_']=!0x1,_0x5d2fd5['indexStartName_']=''),_0x5d2fd5;}function Kh(_0x131581,_0x4b2bf6,_0x5a4d75){const _0x570668=_0x131581['copy']();return _0x570668['endSet_']=!0x0,_0x4b2bf6===void 0x0&&(_0x4b2bf6=null),_0x570668['indexEndValue_']=_0x4b2bf6,_0x5a4d75!==void 0x0?(_0x570668['endNameSet_']=!0x0,_0x570668['indexEndName_']=_0x5a4d75):(_0x570668['endNameSet_']=!0x1,_0x570668['indexEndName_']=''),_0x570668;}function Do(_0x5a154e,_0xf29993){const _0x26d1cf=_0x5a154e['copy']();return _0x26d1cf['index_']=_0xf29993,_0x26d1cf;}function tr(_0x229a25){const _0x26d420={};if(_0x229a25['isDefault']())return _0x26d420;let _0x182d1a;if(_0x229a25['index_']===R?_0x182d1a='$priority':_0x229a25['index_']===Po?_0x182d1a='$value':_0x229a25['index_']===ye?_0x182d1a='$key':(f(_0x229a25['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x182d1a=_0x229a25['index_']['toString']()),_0x26d420['orderBy']=O(_0x182d1a),_0x229a25['startSet_']){const _0x467811=_0x229a25['startAfterSet_']?'startAfter':'startAt';_0x26d420[_0x467811]=O(_0x229a25['indexStartValue_']),_0x229a25['startNameSet_']&&(_0x26d420[_0x467811]+=','+O(_0x229a25['indexStartName_']));}if(_0x229a25['endSet_']){const _0x457ed1=_0x229a25['endBeforeSet_']?'endBefore':'endAt';_0x26d420[_0x457ed1]=O(_0x229a25['indexEndValue_']),_0x229a25['endNameSet_']&&(_0x26d420[_0x457ed1]+=','+O(_0x229a25['indexEndName_']));}return _0x229a25['limitSet_']&&(_0x229a25['isViewFromLeft']()?_0x26d420['limitToFirst']=_0x229a25['limit_']:_0x26d420['limitToLast']=_0x229a25['limit_']),_0x26d420;}function nr(_0x33a630){const _0x36a411={};if(_0x33a630['startSet_']&&(_0x36a411['sp']=_0x33a630['indexStartValue_'],_0x33a630['startNameSet_']&&(_0x36a411['sn']=_0x33a630['indexStartName_']),_0x36a411['sin']=!_0x33a630['startAfterSet_']),_0x33a630['endSet_']&&(_0x36a411['ep']=_0x33a630['indexEndValue_'],_0x33a630['endNameSet_']&&(_0x36a411['en']=_0x33a630['indexEndName_']),_0x36a411['ein']=!_0x33a630['endBeforeSet_']),_0x33a630['limitSet_']){_0x36a411['l']=_0x33a630['limit_'];let _0x2577cf=_0x33a630['viewFrom_'];_0x2577cf===''&&(_0x33a630['isViewFromLeft']()?_0x2577cf='l':_0x2577cf='r'),_0x36a411['vf']=_0x2577cf;}return _0x33a630['index_']!==R&&(_0x36a411['i']=_0x33a630['index_']['toString']()),_0x36a411;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x8f59d1){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x50a5c3,_0x2ea3ad){return _0x2ea3ad!==void 0x0?'tag$'+_0x2ea3ad:(f(_0x50a5c3['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x50a5c3['_path']['toString']());}constructor(_0x22058b,_0x252b50,_0x381900,_0x1e0a44){super(),this['repoInfo_']=_0x22058b,this['onDataUpdate_']=_0x252b50,this['authTokenProvider_']=_0x381900,this['appCheckTokenProvider_']=_0x1e0a44,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x35a753,_0x45eebb,_0x46929b,_0x5003a6){const _0x2f407b=_0x35a753['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2f407b+'\x20'+_0x35a753['_queryIdentifier']);const _0x6ce0c5=fn['getListenId_'](_0x35a753,_0x46929b),_0x1f854e={};this['listens_'][_0x6ce0c5]=_0x1f854e;const _0xb76427=tr(_0x35a753['_queryParams']);this['restRequest_'](_0x2f407b+'.json',_0xb76427,(_0x34d4c3,_0xe5dd14)=>{let _0x4ac8af=_0xe5dd14;if(_0x34d4c3===0x194&&(_0x4ac8af=null,_0x34d4c3=null),_0x34d4c3===null&&this['onDataUpdate_'](_0x2f407b,_0x4ac8af,!0x1,_0x46929b),Oe(this['listens_'],_0x6ce0c5)===_0x1f854e){let _0x390455;_0x34d4c3?_0x34d4c3===0x191?_0x390455='permission_denied':_0x390455='rest_error:'+_0x34d4c3:_0x390455='ok',_0x5003a6(_0x390455,null);}});}['unlisten'](_0x40f631,_0x319079){const _0x1e73f0=fn['getListenId_'](_0x40f631,_0x319079);delete this['listens_'][_0x1e73f0];}['get'](_0x553edc){const _0xc34252=tr(_0x553edc['_queryParams']),_0x9a1447=_0x553edc['_path']['toString'](),_0x4c6f36=new Ve();return this['restRequest_'](_0x9a1447+'.json',_0xc34252,(_0x182933,_0x5f5ddd)=>{let _0x26e72e=_0x5f5ddd;_0x182933===0x194&&(_0x26e72e=null,_0x182933=null),_0x182933===null?(this['onDataUpdate_'](_0x9a1447,_0x26e72e,!0x1,null),_0x4c6f36['resolve'](_0x26e72e)):_0x4c6f36['reject'](new Error(_0x26e72e));}),_0x4c6f36['promise'];}['refreshAuthToken'](_0x35740b){}['restRequest_'](_0x13bd74,_0x4a49bb={},_0x57ed98){return _0x4a49bb['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x37c918,_0x57edc3])=>{_0x37c918&&_0x37c918['accessToken']&&(_0x4a49bb['auth']=_0x37c918['accessToken']),_0x57edc3&&_0x57edc3['token']&&(_0x4a49bb['ac']=_0x57edc3['token']);const _0x29917c=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x13bd74+'?ns='+this['repoInfo_']['namespace']+at(_0x4a49bb);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x29917c);const _0x309d22=new XMLHttpRequest();_0x309d22['onreadystatechange']=()=>{if(_0x57ed98&&_0x309d22['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x29917c+'\x20received.\x20status:',_0x309d22['status'],'response:',_0x309d22['responseText']);let _0x5cb6b5=null;if(_0x309d22['status']>=0xc8&&_0x309d22['status']<0x12c){try{_0x5cb6b5=bt(_0x309d22['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x29917c+':\x20'+_0x309d22['responseText']);}_0x57ed98(null,_0x5cb6b5);}else _0x309d22['status']!==0x191&&_0x309d22['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x29917c+'\x20Status:\x20'+_0x309d22['status']),_0x57ed98(_0x309d22['status']);_0x57ed98=null;}},_0x309d22['open']('GET',_0x29917c,!0x0),_0x309d22['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x56c6f2){return this['rootNode_']['getChild'](_0x56c6f2);}['updateSnapshot'](_0x261a64,_0x34da5e){this['rootNode_']=this['rootNode_']['updateChild'](_0x261a64,_0x34da5e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x204fe0,_0xc16e79,_0x5711ce){if(v(_0xc16e79))_0x204fe0['value']=_0x5711ce,_0x204fe0['children']['clear']();else{if(_0x204fe0['value']!==null)_0x204fe0['value']=_0x204fe0['value']['updateChild'](_0xc16e79,_0x5711ce);else{const _0x10c3e6=y(_0xc16e79);_0x204fe0['children']['has'](_0x10c3e6)||_0x204fe0['children']['set'](_0x10c3e6,pn());const _0x395935=_0x204fe0['children']['get'](_0x10c3e6);_0xc16e79=b(_0xc16e79),Mo(_0x395935,_0xc16e79,_0x5711ce);}}}function Ei(_0x324c32,_0x1dd69b,_0x54357d){_0x324c32['value']!==null?_0x54357d(_0x1dd69b,_0x324c32['value']):Qh(_0x324c32,(_0x32ad9b,_0x1fd774)=>{const _0x325524=new C(_0x1dd69b['toString']()+'/'+_0x32ad9b);Ei(_0x1fd774,_0x325524,_0x54357d);});}function Qh(_0x25c6ed,_0x511e99){_0x25c6ed['children']['forEach']((_0xbb6214,_0x2b8ab6)=>{_0x511e99(_0x2b8ab6,_0xbb6214);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x2b9759){this['collection_']=_0x2b9759,this['last_']=null;}['get'](){const _0x2d80f5=this['collection_']['get'](),_0x1acd23={..._0x2d80f5};return this['last_']&&x(this['last_'],(_0x29efb9,_0x2baec3)=>{_0x1acd23[_0x29efb9]=_0x1acd23[_0x29efb9]-_0x2baec3;}),this['last_']=_0x2d80f5,_0x1acd23;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x291a50,_0x1f5452){this['server_']=_0x1f5452,this['statsToReport_']={},this['statsListener_']=new Jh(_0x291a50);const _0x54cd11=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x54cd11));}['reportStats_'](){const _0x5c48e=this['statsListener_']['get'](),_0x14ed4c={};let _0x2d99db=!0x1;x(_0x5c48e,(_0x590720,_0x56260d)=>{_0x56260d>0x0&&Y(this['statsToReport_'],_0x590720)&&(_0x14ed4c[_0x590720]=_0x56260d,_0x2d99db=!0x0);}),_0x2d99db&&this['server_']['reportStats'](_0x14ed4c),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x36e2a3){_0x36e2a3[_0x36e2a3['OVERWRITE']=0x0]='OVERWRITE',_0x36e2a3[_0x36e2a3['MERGE']=0x1]='MERGE',_0x36e2a3[_0x36e2a3['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x36e2a3[_0x36e2a3['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x258e18){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x258e18,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4773c1,_0x35bbaf,_0x33dc36){this['path']=_0x4773c1,this['affectedTree']=_0x35bbaf,this['revert']=_0x33dc36,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x1044ca){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x570f6c=this['affectedTree']['subtree'](new C(_0x1044ca));return new _n(w(),_0x570f6c,this['revert']);}}else return f(y(this['path'])===_0x1044ca,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x3d503a,_0x326fef){this['source']=_0x3d503a,this['path']=_0x326fef,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x277ea8){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x196d9f,_0x337af1,_0x48d5ea){this['source']=_0x196d9f,this['path']=_0x337af1,this['snap']=_0x48d5ea,this['type']=q['OVERWRITE'];}['operationForChild'](_0x440dc4){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x440dc4)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x4a2bc7,_0x31a732,_0x5b8a4a){this['source']=_0x4a2bc7,this['path']=_0x31a732,this['children']=_0x5b8a4a,this['type']=q['MERGE'];}['operationForChild'](_0x582f0c){if(v(this['path'])){const _0x5c46f5=this['children']['subtree'](new C(_0x582f0c));return _0x5c46f5['isEmpty']()?null:_0x5c46f5['value']?new Fe(this['source'],w(),_0x5c46f5['value']):new nt(this['source'],w(),_0x5c46f5);}else return f(y(this['path'])===_0x582f0c,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x703535,_0x3bab02,_0x2c98db){this['node_']=_0x703535,this['fullyInitialized_']=_0x3bab02,this['filtered_']=_0x2c98db;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2fcb3c){if(v(_0x2fcb3c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x59cb5e=y(_0x2fcb3c);return this['isCompleteForChild'](_0x59cb5e);}['isCompleteForChild'](_0x37b6da){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x37b6da);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4e741d){this['query_']=_0x4e741d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5cdca4,_0x68b675,_0x3782b2,_0x3bc26c){const _0x32172a=[],_0x3d138b=[];return _0x68b675['forEach'](_0x10dbd2=>{_0x10dbd2['type']==='child_changed'&&_0x5cdca4['index_']['indexedValueChanged'](_0x10dbd2['oldSnap'],_0x10dbd2['snapshotNode'])&&_0x3d138b['push']($h(_0x10dbd2['childName'],_0x10dbd2['snapshotNode']));}),mt(_0x5cdca4,_0x32172a,'child_removed',_0x68b675,_0x3bc26c,_0x3782b2),mt(_0x5cdca4,_0x32172a,'child_added',_0x68b675,_0x3bc26c,_0x3782b2),mt(_0x5cdca4,_0x32172a,'child_moved',_0x3d138b,_0x3bc26c,_0x3782b2),mt(_0x5cdca4,_0x32172a,'child_changed',_0x68b675,_0x3bc26c,_0x3782b2),mt(_0x5cdca4,_0x32172a,'value',_0x68b675,_0x3bc26c,_0x3782b2),_0x32172a;}function mt(_0x324bfb,_0x370555,_0x3a9473,_0x517351,_0x169a39,_0x396509){const _0xd6d9f9=_0x517351['filter'](_0x25cc55=>_0x25cc55['type']===_0x3a9473);_0xd6d9f9['sort']((_0x188261,_0x31fb42)=>su(_0x324bfb,_0x188261,_0x31fb42)),_0xd6d9f9['forEach'](_0x445daa=>{const _0x559890=iu(_0x324bfb,_0x445daa,_0x396509);_0x169a39['forEach'](_0x53d2e7=>{_0x53d2e7['respondsTo'](_0x445daa['type'])&&_0x370555['push'](_0x53d2e7['createEvent'](_0x559890,_0x324bfb['query_']));});});}function iu(_0x21e9c9,_0x1cf5c3,_0xba0b47){return _0x1cf5c3['type']==='value'||_0x1cf5c3['type']==='child_removed'||(_0x1cf5c3['prevName']=_0xba0b47['getPredecessorChildName'](_0x1cf5c3['childName'],_0x1cf5c3['snapshotNode'],_0x21e9c9['index_'])),_0x1cf5c3;}function su(_0x21a319,_0x3337ae,_0x5a97cb){if(_0x3337ae['childName']==null||_0x5a97cb['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x444704=new E(_0x3337ae['childName'],_0x3337ae['snapshotNode']),_0x38e97d=new E(_0x5a97cb['childName'],_0x5a97cb['snapshotNode']);return _0x21a319['index_']['compare'](_0x444704,_0x38e97d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x5c7951,_0x34f6db){return{'eventCache':_0x5c7951,'serverCache':_0x34f6db};}function wt(_0x10670a,_0x541978,_0x18d717,_0x524e40){return Dn(new Ce(_0x541978,_0x18d717,_0x524e40),_0x10670a['serverCache']);}function Lo(_0x21e865,_0x1830be,_0xbcf3b,_0x78d357){return Dn(_0x21e865['eventCache'],new Ce(_0x1830be,_0xbcf3b,_0x78d357));}function gn(_0xeb559b){return _0xeb559b['eventCache']['isFullyInitialized']()?_0xeb559b['eventCache']['getNode']():null;}function Ue(_0x11f295){return _0x11f295['serverCache']['isFullyInitialized']()?_0x11f295['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x4d3e61){let _0x5c0f48=new S(null);return x(_0x4d3e61,(_0x560303,_0x750afc)=>{_0x5c0f48=_0x5c0f48['set'](new C(_0x560303),_0x750afc);}),_0x5c0f48;}constructor(_0x4c954f,_0xb6811b=ru()){this['value']=_0x4c954f,this['children']=_0xb6811b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5a142e,_0x282117){if(this['value']!=null&&_0x282117(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5a142e))return null;{const _0xbcf7b0=y(_0x5a142e),_0x361fea=this['children']['get'](_0xbcf7b0);if(_0x361fea!==null){const _0x313d4b=_0x361fea['findRootMostMatchingPathAndValue'](b(_0x5a142e),_0x282117);return _0x313d4b!=null?{'path':A(new C(_0xbcf7b0),_0x313d4b['path']),'value':_0x313d4b['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x19a6d6){return this['findRootMostMatchingPathAndValue'](_0x19a6d6,()=>!0x0);}['subtree'](_0x49ac87){if(v(_0x49ac87))return this;{const _0x265615=y(_0x49ac87),_0x5c43a7=this['children']['get'](_0x265615);return _0x5c43a7!==null?_0x5c43a7['subtree'](b(_0x49ac87)):new S(null);}}['set'](_0x444e37,_0xa0f4c9){if(v(_0x444e37))return new S(_0xa0f4c9,this['children']);{const _0x5139c6=y(_0x444e37),_0xde59dd=(this['children']['get'](_0x5139c6)||new S(null))['set'](b(_0x444e37),_0xa0f4c9),_0x122cb1=this['children']['insert'](_0x5139c6,_0xde59dd);return new S(this['value'],_0x122cb1);}}['remove'](_0x2931ad){if(v(_0x2931ad))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4283f0=y(_0x2931ad),_0x3c7202=this['children']['get'](_0x4283f0);if(_0x3c7202){const _0x39624c=_0x3c7202['remove'](b(_0x2931ad));let _0xd3df5c;return _0x39624c['isEmpty']()?_0xd3df5c=this['children']['remove'](_0x4283f0):_0xd3df5c=this['children']['insert'](_0x4283f0,_0x39624c),this['value']===null&&_0xd3df5c['isEmpty']()?new S(null):new S(this['value'],_0xd3df5c);}else return this;}}['get'](_0x2dc631){if(v(_0x2dc631))return this['value'];{const _0x35b77a=y(_0x2dc631),_0x481952=this['children']['get'](_0x35b77a);return _0x481952?_0x481952['get'](b(_0x2dc631)):null;}}['setTree'](_0x1fbd8c,_0x844160){if(v(_0x1fbd8c))return _0x844160;{const _0x1bd8d1=y(_0x1fbd8c),_0x4d0927=(this['children']['get'](_0x1bd8d1)||new S(null))['setTree'](b(_0x1fbd8c),_0x844160);let _0x305d0a;return _0x4d0927['isEmpty']()?_0x305d0a=this['children']['remove'](_0x1bd8d1):_0x305d0a=this['children']['insert'](_0x1bd8d1,_0x4d0927),new S(this['value'],_0x305d0a);}}['fold'](_0x367ce8){return this['fold_'](w(),_0x367ce8);}['fold_'](_0x1dd0b1,_0x512b48){const _0x131a35={};return this['children']['inorderTraversal']((_0x36aaea,_0x25d1ef)=>{_0x131a35[_0x36aaea]=_0x25d1ef['fold_'](A(_0x1dd0b1,_0x36aaea),_0x512b48);}),_0x512b48(_0x1dd0b1,this['value'],_0x131a35);}['findOnPath'](_0x1c8cb7,_0x8253bb){return this['findOnPath_'](_0x1c8cb7,w(),_0x8253bb);}['findOnPath_'](_0x146489,_0x21c412,_0x48611f){const _0x109a16=this['value']?_0x48611f(_0x21c412,this['value']):!0x1;if(_0x109a16)return _0x109a16;if(v(_0x146489))return null;{const _0x4b1304=y(_0x146489),_0x2088b6=this['children']['get'](_0x4b1304);return _0x2088b6?_0x2088b6['findOnPath_'](b(_0x146489),A(_0x21c412,_0x4b1304),_0x48611f):null;}}['foreachOnPath'](_0x2893d1,_0x322efe){return this['foreachOnPath_'](_0x2893d1,w(),_0x322efe);}['foreachOnPath_'](_0x35a15d,_0xe42573,_0x16ffbe){if(v(_0x35a15d))return this;{this['value']&&_0x16ffbe(_0xe42573,this['value']);const _0x32d68d=y(_0x35a15d),_0x433a6b=this['children']['get'](_0x32d68d);return _0x433a6b?_0x433a6b['foreachOnPath_'](b(_0x35a15d),A(_0xe42573,_0x32d68d),_0x16ffbe):new S(null);}}['foreach'](_0x3bfc7e){this['foreach_'](w(),_0x3bfc7e);}['foreach_'](_0x4c0db9,_0x5b34fe){this['children']['inorderTraversal']((_0x1ccc76,_0x700e84)=>{_0x700e84['foreach_'](A(_0x4c0db9,_0x1ccc76),_0x5b34fe);}),this['value']&&_0x5b34fe(_0x4c0db9,this['value']);}['foreachChild'](_0x5d590e){this['children']['inorderTraversal']((_0x888173,_0x279202)=>{_0x279202['value']&&_0x5d590e(_0x888173,_0x279202['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x28cd45){this['writeTree_']=_0x28cd45;}static['empty'](){return new j(new S(null));}}function Ct(_0x11e3c2,_0x4ee014,_0x425a6a){if(v(_0x4ee014))return new j(new S(_0x425a6a));{const _0x49dc98=_0x11e3c2['writeTree_']['findRootMostValueAndPath'](_0x4ee014);if(_0x49dc98!=null){const _0x5261d8=_0x49dc98['path'];let _0x56ad10=_0x49dc98['value'];const _0x318eb1=F(_0x5261d8,_0x4ee014);return _0x56ad10=_0x56ad10['updateChild'](_0x318eb1,_0x425a6a),new j(_0x11e3c2['writeTree_']['set'](_0x5261d8,_0x56ad10));}else{const _0x2f5dfe=new S(_0x425a6a),_0x1005d1=_0x11e3c2['writeTree_']['setTree'](_0x4ee014,_0x2f5dfe);return new j(_0x1005d1);}}}function Ii(_0x5ae494,_0x1711fd,_0x5a1f07){let _0x451f2c=_0x5ae494;return x(_0x5a1f07,(_0x15461f,_0x434adc)=>{_0x451f2c=Ct(_0x451f2c,A(_0x1711fd,_0x15461f),_0x434adc);}),_0x451f2c;}function sr(_0x384635,_0x45b44e){if(v(_0x45b44e))return j['empty']();{const _0x5e4fa5=_0x384635['writeTree_']['setTree'](_0x45b44e,new S(null));return new j(_0x5e4fa5);}}function wi(_0x251058,_0x357248){return $e(_0x251058,_0x357248)!=null;}function $e(_0x246477,_0x56059f){const _0x5f5cf0=_0x246477['writeTree_']['findRootMostValueAndPath'](_0x56059f);return _0x5f5cf0!=null?_0x246477['writeTree_']['get'](_0x5f5cf0['path'])['getChild'](F(_0x5f5cf0['path'],_0x56059f)):null;}function rr(_0x480be1){const _0x444615=[],_0x415e4c=_0x480be1['writeTree_']['value'];return _0x415e4c!=null?_0x415e4c['isLeafNode']()||_0x415e4c['forEachChild'](R,(_0x29ecc6,_0x2b1c13)=>{_0x444615['push'](new E(_0x29ecc6,_0x2b1c13));}):_0x480be1['writeTree_']['children']['inorderTraversal']((_0x4cf1e3,_0x2308a7)=>{_0x2308a7['value']!=null&&_0x444615['push'](new E(_0x4cf1e3,_0x2308a7['value']));}),_0x444615;}function ve(_0x3a5fdc,_0x568d67){if(v(_0x568d67))return _0x3a5fdc;{const _0x56addf=$e(_0x3a5fdc,_0x568d67);return _0x56addf!=null?new j(new S(_0x56addf)):new j(_0x3a5fdc['writeTree_']['subtree'](_0x568d67));}}function Ci(_0x5e8b94){return _0x5e8b94['writeTree_']['isEmpty']();}function it(_0x1baa35,_0x35b7cd){return xo(w(),_0x1baa35['writeTree_'],_0x35b7cd);}function xo(_0x1377a2,_0x10e45e,_0x3eae01){if(_0x10e45e['value']!=null)return _0x3eae01['updateChild'](_0x1377a2,_0x10e45e['value']);{let _0xafb2fe=null;return _0x10e45e['children']['inorderTraversal']((_0x352cd4,_0x1c78a7)=>{_0x352cd4==='.priority'?(f(_0x1c78a7['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xafb2fe=_0x1c78a7['value']):_0x3eae01=xo(A(_0x1377a2,_0x352cd4),_0x1c78a7,_0x3eae01);}),!_0x3eae01['getChild'](_0x1377a2)['isEmpty']()&&_0xafb2fe!==null&&(_0x3eae01=_0x3eae01['updateChild'](A(_0x1377a2,'.priority'),_0xafb2fe)),_0x3eae01;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x36a97f,_0x100572){return Bo(_0x100572,_0x36a97f);}function ou(_0x4d1e40,_0x19ac48,_0x535af6,_0x565fb8,_0x1bf6b0){f(_0x565fb8>_0x4d1e40['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1bf6b0===void 0x0&&(_0x1bf6b0=!0x0),_0x4d1e40['allWrites']['push']({'path':_0x19ac48,'snap':_0x535af6,'writeId':_0x565fb8,'visible':_0x1bf6b0}),_0x1bf6b0&&(_0x4d1e40['visibleWrites']=Ct(_0x4d1e40['visibleWrites'],_0x19ac48,_0x535af6)),_0x4d1e40['lastWriteId']=_0x565fb8;}function au(_0x3d283a,_0x110c08,_0x3bfe81,_0x2e5172){f(_0x2e5172>_0x3d283a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3d283a['allWrites']['push']({'path':_0x110c08,'children':_0x3bfe81,'writeId':_0x2e5172,'visible':!0x0}),_0x3d283a['visibleWrites']=Ii(_0x3d283a['visibleWrites'],_0x110c08,_0x3bfe81),_0x3d283a['lastWriteId']=_0x2e5172;}function cu(_0x57a5b8,_0x4d563f){for(let _0x4b43a6=0x0;_0x4b43a6<_0x57a5b8['allWrites']['length'];_0x4b43a6++){const _0x32f6ac=_0x57a5b8['allWrites'][_0x4b43a6];if(_0x32f6ac['writeId']===_0x4d563f)return _0x32f6ac;}return null;}function lu(_0x9fb071,_0x3d9f48){const _0x5f1fda=_0x9fb071['allWrites']['findIndex'](_0x5d6526=>_0x5d6526['writeId']===_0x3d9f48);f(_0x5f1fda>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1b1cbf=_0x9fb071['allWrites'][_0x5f1fda];_0x9fb071['allWrites']['splice'](_0x5f1fda,0x1);let _0x16d437=_0x1b1cbf['visible'],_0x312604=!0x1,_0x4cda35=_0x9fb071['allWrites']['length']-0x1;for(;_0x16d437&&_0x4cda35>=0x0;){const _0x4134ac=_0x9fb071['allWrites'][_0x4cda35];_0x4134ac['visible']&&(_0x4cda35>=_0x5f1fda&&hu(_0x4134ac,_0x1b1cbf['path'])?_0x16d437=!0x1:$(_0x1b1cbf['path'],_0x4134ac['path'])&&(_0x312604=!0x0)),_0x4cda35--;}if(_0x16d437){if(_0x312604)return uu(_0x9fb071),!0x0;if(_0x1b1cbf['snap'])_0x9fb071['visibleWrites']=sr(_0x9fb071['visibleWrites'],_0x1b1cbf['path']);else{const _0x32f6c6=_0x1b1cbf['children'];x(_0x32f6c6,_0x5374ea=>{_0x9fb071['visibleWrites']=sr(_0x9fb071['visibleWrites'],A(_0x1b1cbf['path'],_0x5374ea));});}return!0x0;}else return!0x1;}function hu(_0x4fb5a1,_0x409529){if(_0x4fb5a1['snap'])return $(_0x4fb5a1['path'],_0x409529);for(const _0x48d01f in _0x4fb5a1['children'])if(_0x4fb5a1['children']['hasOwnProperty'](_0x48d01f)&&$(A(_0x4fb5a1['path'],_0x48d01f),_0x409529))return!0x0;return!0x1;}function uu(_0x2b01d9){_0x2b01d9['visibleWrites']=Fo(_0x2b01d9['allWrites'],du,w()),_0x2b01d9['allWrites']['length']>0x0?_0x2b01d9['lastWriteId']=_0x2b01d9['allWrites'][_0x2b01d9['allWrites']['length']-0x1]['writeId']:_0x2b01d9['lastWriteId']=-0x1;}function du(_0x1d6140){return _0x1d6140['visible'];}function Fo(_0x508c9e,_0x17d198,_0x40f80a){let _0x1ef0d3=j['empty']();for(let _0x177ca9=0x0;_0x177ca9<_0x508c9e['length'];++_0x177ca9){const _0x5b02be=_0x508c9e[_0x177ca9];if(_0x17d198(_0x5b02be)){const _0x563c6e=_0x5b02be['path'];let _0x152fbb;if(_0x5b02be['snap'])$(_0x40f80a,_0x563c6e)?(_0x152fbb=F(_0x40f80a,_0x563c6e),_0x1ef0d3=Ct(_0x1ef0d3,_0x152fbb,_0x5b02be['snap'])):$(_0x563c6e,_0x40f80a)&&(_0x152fbb=F(_0x563c6e,_0x40f80a),_0x1ef0d3=Ct(_0x1ef0d3,w(),_0x5b02be['snap']['getChild'](_0x152fbb)));else{if(_0x5b02be['children']){if($(_0x40f80a,_0x563c6e))_0x152fbb=F(_0x40f80a,_0x563c6e),_0x1ef0d3=Ii(_0x1ef0d3,_0x152fbb,_0x5b02be['children']);else{if($(_0x563c6e,_0x40f80a)){if(_0x152fbb=F(_0x563c6e,_0x40f80a),v(_0x152fbb))_0x1ef0d3=Ii(_0x1ef0d3,w(),_0x5b02be['children']);else{const _0x383a41=Oe(_0x5b02be['children'],y(_0x152fbb));if(_0x383a41){const _0x2e0c23=_0x383a41['getChild'](b(_0x152fbb));_0x1ef0d3=Ct(_0x1ef0d3,w(),_0x2e0c23);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1ef0d3;}function Uo(_0x3d45e7,_0x565b16,_0x231703,_0x3a92ca,_0x55059d){if(!_0x3a92ca&&!_0x55059d){const _0x36161e=$e(_0x3d45e7['visibleWrites'],_0x565b16);if(_0x36161e!=null)return _0x36161e;{const _0x4c61aa=ve(_0x3d45e7['visibleWrites'],_0x565b16);if(Ci(_0x4c61aa))return _0x231703;if(_0x231703==null&&!wi(_0x4c61aa,w()))return null;{const _0x64e8cf=_0x231703||g['EMPTY_NODE'];return it(_0x4c61aa,_0x64e8cf);}}}else{const _0x168fa4=ve(_0x3d45e7['visibleWrites'],_0x565b16);if(!_0x55059d&&Ci(_0x168fa4))return _0x231703;if(!_0x55059d&&_0x231703==null&&!wi(_0x168fa4,w()))return null;{const _0x5076de=function(_0x5cd3de){return(_0x5cd3de['visible']||_0x55059d)&&(!_0x3a92ca||!~_0x3a92ca['indexOf'](_0x5cd3de['writeId']))&&($(_0x5cd3de['path'],_0x565b16)||$(_0x565b16,_0x5cd3de['path']));},_0x2d4999=Fo(_0x3d45e7['allWrites'],_0x5076de,_0x565b16),_0x479167=_0x231703||g['EMPTY_NODE'];return it(_0x2d4999,_0x479167);}}}function fu(_0x2c04f5,_0x17e1f7,_0x2b6872){let _0x4db3e6=g['EMPTY_NODE'];const _0x23414d=$e(_0x2c04f5['visibleWrites'],_0x17e1f7);if(_0x23414d)return _0x23414d['isLeafNode']()||_0x23414d['forEachChild'](R,(_0x204e19,_0x2ba04f)=>{_0x4db3e6=_0x4db3e6['updateImmediateChild'](_0x204e19,_0x2ba04f);}),_0x4db3e6;if(_0x2b6872){const _0x15cce5=ve(_0x2c04f5['visibleWrites'],_0x17e1f7);return _0x2b6872['forEachChild'](R,(_0x1bc5db,_0xf4599e)=>{const _0x589ccb=it(ve(_0x15cce5,new C(_0x1bc5db)),_0xf4599e);_0x4db3e6=_0x4db3e6['updateImmediateChild'](_0x1bc5db,_0x589ccb);}),rr(_0x15cce5)['forEach'](_0x1fc22d=>{_0x4db3e6=_0x4db3e6['updateImmediateChild'](_0x1fc22d['name'],_0x1fc22d['node']);}),_0x4db3e6;}else{const _0x15f260=ve(_0x2c04f5['visibleWrites'],_0x17e1f7);return rr(_0x15f260)['forEach'](_0x1f4987=>{_0x4db3e6=_0x4db3e6['updateImmediateChild'](_0x1f4987['name'],_0x1f4987['node']);}),_0x4db3e6;}}function pu(_0x5a915a,_0x45a389,_0x135536,_0x1583e4,_0x3d686a){f(_0x1583e4||_0x3d686a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3fa4f2=A(_0x45a389,_0x135536);if(wi(_0x5a915a['visibleWrites'],_0x3fa4f2))return null;{const _0x1fde34=ve(_0x5a915a['visibleWrites'],_0x3fa4f2);return Ci(_0x1fde34)?_0x3d686a['getChild'](_0x135536):it(_0x1fde34,_0x3d686a['getChild'](_0x135536));}}function _u(_0xfd8bb8,_0x501a25,_0x5bedab,_0x5bd8da){const _0x46e350=A(_0x501a25,_0x5bedab),_0x53d0a2=$e(_0xfd8bb8['visibleWrites'],_0x46e350);if(_0x53d0a2!=null)return _0x53d0a2;if(_0x5bd8da['isCompleteForChild'](_0x5bedab)){const _0xb26cc7=ve(_0xfd8bb8['visibleWrites'],_0x46e350);return it(_0xb26cc7,_0x5bd8da['getNode']()['getImmediateChild'](_0x5bedab));}else return null;}function gu(_0x16a735,_0x34344a){return $e(_0x16a735['visibleWrites'],_0x34344a);}function mu(_0x347e9a,_0x1e4125,_0x4b85b1,_0x252b38,_0x2dab9e,_0x292ecf,_0x580a1d){let _0x6d7adb;const _0x29ce8a=ve(_0x347e9a['visibleWrites'],_0x1e4125),_0x18b2b7=$e(_0x29ce8a,w());if(_0x18b2b7!=null)_0x6d7adb=_0x18b2b7;else{if(_0x4b85b1!=null)_0x6d7adb=it(_0x29ce8a,_0x4b85b1);else return[];}if(_0x6d7adb=_0x6d7adb['withIndex'](_0x580a1d),!_0x6d7adb['isEmpty']()&&!_0x6d7adb['isLeafNode']()){const _0x3a360b=[],_0x337d76=_0x580a1d['getCompare'](),_0x287dca=_0x292ecf?_0x6d7adb['getReverseIteratorFrom'](_0x252b38,_0x580a1d):_0x6d7adb['getIteratorFrom'](_0x252b38,_0x580a1d);let _0x360309=_0x287dca['getNext']();for(;_0x360309&&_0x3a360b['length']<_0x2dab9e;)_0x337d76(_0x360309,_0x252b38)!==0x0&&_0x3a360b['push'](_0x360309),_0x360309=_0x287dca['getNext']();return _0x3a360b;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x19bda2,_0x3a618a,_0x25b009,_0x1a82a9){return Uo(_0x19bda2['writeTree'],_0x19bda2['treePath'],_0x3a618a,_0x25b009,_0x1a82a9);}function es(_0x5adb24,_0x26f29a){return fu(_0x5adb24['writeTree'],_0x5adb24['treePath'],_0x26f29a);}function or(_0x4bcdc5,_0x11f96e,_0x98a689,_0x54cc57){return pu(_0x4bcdc5['writeTree'],_0x4bcdc5['treePath'],_0x11f96e,_0x98a689,_0x54cc57);}function yn(_0x29a553,_0x2da6b6){return gu(_0x29a553['writeTree'],A(_0x29a553['treePath'],_0x2da6b6));}function vu(_0x5199e8,_0x1e8647,_0x38a904,_0x3501fd,_0x3464c2,_0x913ab0){return mu(_0x5199e8['writeTree'],_0x5199e8['treePath'],_0x1e8647,_0x38a904,_0x3501fd,_0x3464c2,_0x913ab0);}function ts(_0x3b2e4d,_0x135346,_0x13e437){return _u(_0x3b2e4d['writeTree'],_0x3b2e4d['treePath'],_0x135346,_0x13e437);}function Wo(_0x549e47,_0x5c292){return Bo(A(_0x549e47['treePath'],_0x5c292),_0x549e47['writeTree']);}function Bo(_0x29eb27,_0x36ac65){return{'treePath':_0x29eb27,'writeTree':_0x36ac65};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x216419){const _0x4ebe54=_0x216419['type'],_0x2ed62e=_0x216419['childName'];f(_0x4ebe54==='child_added'||_0x4ebe54==='child_changed'||_0x4ebe54==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2ed62e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x863511=this['changeMap']['get'](_0x2ed62e);if(_0x863511){const _0xa4a62a=_0x863511['type'];if(_0x4ebe54==='child_added'&&_0xa4a62a==='child_removed')this['changeMap']['set'](_0x2ed62e,Pt(_0x2ed62e,_0x216419['snapshotNode'],_0x863511['snapshotNode']));else{if(_0x4ebe54==='child_removed'&&_0xa4a62a==='child_added')this['changeMap']['delete'](_0x2ed62e);else{if(_0x4ebe54==='child_removed'&&_0xa4a62a==='child_changed')this['changeMap']['set'](_0x2ed62e,Nt(_0x2ed62e,_0x863511['oldSnap']));else{if(_0x4ebe54==='child_changed'&&_0xa4a62a==='child_added')this['changeMap']['set'](_0x2ed62e,tt(_0x2ed62e,_0x216419['snapshotNode']));else{if(_0x4ebe54==='child_changed'&&_0xa4a62a==='child_changed')this['changeMap']['set'](_0x2ed62e,Pt(_0x2ed62e,_0x216419['snapshotNode'],_0x863511['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x216419+'\x20occurred\x20after\x20'+_0x863511);}}}}}else this['changeMap']['set'](_0x2ed62e,_0x216419);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x2a75be){return null;}['getChildAfterChild'](_0x196efe,_0x52e5bf,_0x18c78e){return null;}}const Vo=new Iu();class ns{constructor(_0x11a8c2,_0x23ff41,_0x402e4d=null){this['writes_']=_0x11a8c2,this['viewCache_']=_0x23ff41,this['optCompleteServerCache_']=_0x402e4d;}['getCompleteChild'](_0x5aecdf){const _0x335f6c=this['viewCache_']['eventCache'];if(_0x335f6c['isCompleteForChild'](_0x5aecdf))return _0x335f6c['getNode']()['getImmediateChild'](_0x5aecdf);{const _0x41eddb=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5aecdf,_0x41eddb);}}['getChildAfterChild'](_0x4c2dd1,_0x487c00,_0x4bb855){const _0x2b570f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x253d37=vu(this['writes_'],_0x2b570f,_0x487c00,0x1,_0x4bb855,_0x4c2dd1);return _0x253d37['length']===0x0?null:_0x253d37[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x36aec0){return{'filter':_0x36aec0};}function Cu(_0x570a59,_0x1c8b0b){f(_0x1c8b0b['eventCache']['getNode']()['isIndexed'](_0x570a59['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1c8b0b['serverCache']['getNode']()['isIndexed'](_0x570a59['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x3a6af8,_0x1d5a24,_0x5618fd,_0x176bec,_0x4a4482){const _0x3fc453=new Eu();let _0x21f708,_0xca9d92;if(_0x5618fd['type']===q['OVERWRITE']){const _0x157ba7=_0x5618fd;_0x157ba7['source']['fromUser']?_0x21f708=Ti(_0x3a6af8,_0x1d5a24,_0x157ba7['path'],_0x157ba7['snap'],_0x176bec,_0x4a4482,_0x3fc453):(f(_0x157ba7['source']['fromServer'],'Unknown\x20source.'),_0xca9d92=_0x157ba7['source']['tagged']||_0x1d5a24['serverCache']['isFiltered']()&&!v(_0x157ba7['path']),_0x21f708=vn(_0x3a6af8,_0x1d5a24,_0x157ba7['path'],_0x157ba7['snap'],_0x176bec,_0x4a4482,_0xca9d92,_0x3fc453));}else{if(_0x5618fd['type']===q['MERGE']){const _0x23583b=_0x5618fd;_0x23583b['source']['fromUser']?_0x21f708=bu(_0x3a6af8,_0x1d5a24,_0x23583b['path'],_0x23583b['children'],_0x176bec,_0x4a4482,_0x3fc453):(f(_0x23583b['source']['fromServer'],'Unknown\x20source.'),_0xca9d92=_0x23583b['source']['tagged']||_0x1d5a24['serverCache']['isFiltered'](),_0x21f708=Si(_0x3a6af8,_0x1d5a24,_0x23583b['path'],_0x23583b['children'],_0x176bec,_0x4a4482,_0xca9d92,_0x3fc453));}else{if(_0x5618fd['type']===q['ACK_USER_WRITE']){const _0x238926=_0x5618fd;_0x238926['revert']?_0x21f708=ku(_0x3a6af8,_0x1d5a24,_0x238926['path'],_0x176bec,_0x4a4482,_0x3fc453):_0x21f708=Ru(_0x3a6af8,_0x1d5a24,_0x238926['path'],_0x238926['affectedTree'],_0x176bec,_0x4a4482,_0x3fc453);}else{if(_0x5618fd['type']===q['LISTEN_COMPLETE'])_0x21f708=Au(_0x3a6af8,_0x1d5a24,_0x5618fd['path'],_0x176bec,_0x3fc453);else throw ot('Unknown\x20operation\x20type:\x20'+_0x5618fd['type']);}}}const _0x1abfa7=_0x3fc453['getChanges']();return Su(_0x1d5a24,_0x21f708,_0x1abfa7),{'viewCache':_0x21f708,'changes':_0x1abfa7};}function Su(_0x70d75c,_0x239c4a,_0x574171){const _0x34c1f6=_0x239c4a['eventCache'];if(_0x34c1f6['isFullyInitialized']()){const _0x5b0fb9=_0x34c1f6['getNode']()['isLeafNode']()||_0x34c1f6['getNode']()['isEmpty'](),_0x296a78=gn(_0x70d75c);(_0x574171['length']>0x0||!_0x70d75c['eventCache']['isFullyInitialized']()||_0x5b0fb9&&!_0x34c1f6['getNode']()['equals'](_0x296a78)||!_0x34c1f6['getNode']()['getPriority']()['equals'](_0x296a78['getPriority']()))&&_0x574171['push'](Oo(gn(_0x239c4a)));}}function Ho(_0x775c70,_0x2d0e70,_0x1b2cb8,_0x2c1c9c,_0x2c363a,_0x47c012){const _0x28f10d=_0x2d0e70['eventCache'];if(yn(_0x2c1c9c,_0x1b2cb8)!=null)return _0x2d0e70;{let _0x349603,_0x4d36dd;if(v(_0x1b2cb8)){if(f(_0x2d0e70['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2d0e70['serverCache']['isFiltered']()){const _0x2670cf=Ue(_0x2d0e70),_0x4846ba=_0x2670cf instanceof g?_0x2670cf:g['EMPTY_NODE'],_0x3f9de3=es(_0x2c1c9c,_0x4846ba);_0x349603=_0x775c70['filter']['updateFullNode'](_0x2d0e70['eventCache']['getNode'](),_0x3f9de3,_0x47c012);}else{const _0x44f8c9=mn(_0x2c1c9c,Ue(_0x2d0e70));_0x349603=_0x775c70['filter']['updateFullNode'](_0x2d0e70['eventCache']['getNode'](),_0x44f8c9,_0x47c012);}}else{const _0x3169b0=y(_0x1b2cb8);if(_0x3169b0==='.priority'){f(we(_0x1b2cb8)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3964c3=_0x28f10d['getNode']();_0x4d36dd=_0x2d0e70['serverCache']['getNode']();const _0x50fd98=or(_0x2c1c9c,_0x1b2cb8,_0x3964c3,_0x4d36dd);_0x50fd98!=null?_0x349603=_0x775c70['filter']['updatePriority'](_0x3964c3,_0x50fd98):_0x349603=_0x28f10d['getNode']();}else{const _0x5412f4=b(_0x1b2cb8);let _0x23263c;if(_0x28f10d['isCompleteForChild'](_0x3169b0)){_0x4d36dd=_0x2d0e70['serverCache']['getNode']();const _0x2efedb=or(_0x2c1c9c,_0x1b2cb8,_0x28f10d['getNode'](),_0x4d36dd);_0x2efedb!=null?_0x23263c=_0x28f10d['getNode']()['getImmediateChild'](_0x3169b0)['updateChild'](_0x5412f4,_0x2efedb):_0x23263c=_0x28f10d['getNode']()['getImmediateChild'](_0x3169b0);}else _0x23263c=ts(_0x2c1c9c,_0x3169b0,_0x2d0e70['serverCache']);_0x23263c!=null?_0x349603=_0x775c70['filter']['updateChild'](_0x28f10d['getNode'](),_0x3169b0,_0x23263c,_0x5412f4,_0x2c363a,_0x47c012):_0x349603=_0x28f10d['getNode']();}}return wt(_0x2d0e70,_0x349603,_0x28f10d['isFullyInitialized']()||v(_0x1b2cb8),_0x775c70['filter']['filtersNodes']());}}function vn(_0x491ed2,_0x45cc13,_0x90c2ee,_0x59cf48,_0x15ba87,_0x2b9f50,_0x5e45ad,_0xad21dd){const _0x4a36a7=_0x45cc13['serverCache'];let _0xccc86b;const _0x4be6ad=_0x5e45ad?_0x491ed2['filter']:_0x491ed2['filter']['getIndexedFilter']();if(v(_0x90c2ee))_0xccc86b=_0x4be6ad['updateFullNode'](_0x4a36a7['getNode'](),_0x59cf48,null);else{if(_0x4be6ad['filtersNodes']()&&!_0x4a36a7['isFiltered']()){const _0x4480c4=_0x4a36a7['getNode']()['updateChild'](_0x90c2ee,_0x59cf48);_0xccc86b=_0x4be6ad['updateFullNode'](_0x4a36a7['getNode'](),_0x4480c4,null);}else{const _0x2c8fe4=y(_0x90c2ee);if(!_0x4a36a7['isCompleteForPath'](_0x90c2ee)&&we(_0x90c2ee)>0x1)return _0x45cc13;const _0x5db1c4=b(_0x90c2ee),_0x330f16=_0x4a36a7['getNode']()['getImmediateChild'](_0x2c8fe4)['updateChild'](_0x5db1c4,_0x59cf48);_0x2c8fe4==='.priority'?_0xccc86b=_0x4be6ad['updatePriority'](_0x4a36a7['getNode'](),_0x330f16):_0xccc86b=_0x4be6ad['updateChild'](_0x4a36a7['getNode'](),_0x2c8fe4,_0x330f16,_0x5db1c4,Vo,null);}}const _0x4a5101=Lo(_0x45cc13,_0xccc86b,_0x4a36a7['isFullyInitialized']()||v(_0x90c2ee),_0x4be6ad['filtersNodes']()),_0x2fccf7=new ns(_0x15ba87,_0x4a5101,_0x2b9f50);return Ho(_0x491ed2,_0x4a5101,_0x90c2ee,_0x15ba87,_0x2fccf7,_0xad21dd);}function Ti(_0x4050ed,_0x38cf15,_0x54b21b,_0x39d31d,_0x375c46,_0x2e9eb9,_0x349428){const _0x4d2792=_0x38cf15['eventCache'];let _0x1c7d4e,_0x4d15ae;const _0x1d85a8=new ns(_0x375c46,_0x38cf15,_0x2e9eb9);if(v(_0x54b21b))_0x4d15ae=_0x4050ed['filter']['updateFullNode'](_0x38cf15['eventCache']['getNode'](),_0x39d31d,_0x349428),_0x1c7d4e=wt(_0x38cf15,_0x4d15ae,!0x0,_0x4050ed['filter']['filtersNodes']());else{const _0x171891=y(_0x54b21b);if(_0x171891==='.priority')_0x4d15ae=_0x4050ed['filter']['updatePriority'](_0x38cf15['eventCache']['getNode'](),_0x39d31d),_0x1c7d4e=wt(_0x38cf15,_0x4d15ae,_0x4d2792['isFullyInitialized'](),_0x4d2792['isFiltered']());else{const _0x2f724d=b(_0x54b21b),_0x4f4f16=_0x4d2792['getNode']()['getImmediateChild'](_0x171891);let _0x5eb665;if(v(_0x2f724d))_0x5eb665=_0x39d31d;else{const _0x623e2a=_0x1d85a8['getCompleteChild'](_0x171891);_0x623e2a!=null?Gi(_0x2f724d)==='.priority'&&_0x623e2a['getChild'](To(_0x2f724d))['isEmpty']()?_0x5eb665=_0x623e2a:_0x5eb665=_0x623e2a['updateChild'](_0x2f724d,_0x39d31d):_0x5eb665=g['EMPTY_NODE'];}if(_0x4f4f16['equals'](_0x5eb665))_0x1c7d4e=_0x38cf15;else{const _0x29ebc1=_0x4050ed['filter']['updateChild'](_0x4d2792['getNode'](),_0x171891,_0x5eb665,_0x2f724d,_0x1d85a8,_0x349428);_0x1c7d4e=wt(_0x38cf15,_0x29ebc1,_0x4d2792['isFullyInitialized'](),_0x4050ed['filter']['filtersNodes']());}}}return _0x1c7d4e;}function ar(_0x440004,_0x114c1f){return _0x440004['eventCache']['isCompleteForChild'](_0x114c1f);}function bu(_0x3d3c67,_0x2c7e1c,_0x877842,_0x1f3a4c,_0x4e403e,_0x279001,_0x5c452e){let _0x127042=_0x2c7e1c;return _0x1f3a4c['foreach']((_0x2b1cd4,_0x4df337)=>{const _0x17efd5=A(_0x877842,_0x2b1cd4);ar(_0x2c7e1c,y(_0x17efd5))&&(_0x127042=Ti(_0x3d3c67,_0x127042,_0x17efd5,_0x4df337,_0x4e403e,_0x279001,_0x5c452e));}),_0x1f3a4c['foreach']((_0x532474,_0x4ef884)=>{const _0x7663dd=A(_0x877842,_0x532474);ar(_0x2c7e1c,y(_0x7663dd))||(_0x127042=Ti(_0x3d3c67,_0x127042,_0x7663dd,_0x4ef884,_0x4e403e,_0x279001,_0x5c452e));}),_0x127042;}function cr(_0x2d090f,_0x119ec2,_0x13028d){return _0x13028d['foreach']((_0x200b3c,_0x2be167)=>{_0x119ec2=_0x119ec2['updateChild'](_0x200b3c,_0x2be167);}),_0x119ec2;}function Si(_0x1352ab,_0x17c47e,_0x224684,_0x33955b,_0x2b1caa,_0x182d89,_0x4051e9,_0x244c2d){if(_0x17c47e['serverCache']['getNode']()['isEmpty']()&&!_0x17c47e['serverCache']['isFullyInitialized']())return _0x17c47e;let _0x37218e=_0x17c47e,_0x7fde35;v(_0x224684)?_0x7fde35=_0x33955b:_0x7fde35=new S(null)['setTree'](_0x224684,_0x33955b);const _0x30f10a=_0x17c47e['serverCache']['getNode']();return _0x7fde35['children']['inorderTraversal']((_0x402af5,_0x16e3a2)=>{if(_0x30f10a['hasChild'](_0x402af5)){const _0x5b00d9=_0x17c47e['serverCache']['getNode']()['getImmediateChild'](_0x402af5),_0x3e1584=cr(_0x1352ab,_0x5b00d9,_0x16e3a2);_0x37218e=vn(_0x1352ab,_0x37218e,new C(_0x402af5),_0x3e1584,_0x2b1caa,_0x182d89,_0x4051e9,_0x244c2d);}}),_0x7fde35['children']['inorderTraversal']((_0x1f5766,_0x4252e8)=>{const _0xba15f0=!_0x17c47e['serverCache']['isCompleteForChild'](_0x1f5766)&&_0x4252e8['value']===null;if(!_0x30f10a['hasChild'](_0x1f5766)&&!_0xba15f0){const _0x470fd4=_0x17c47e['serverCache']['getNode']()['getImmediateChild'](_0x1f5766),_0x3ea2dd=cr(_0x1352ab,_0x470fd4,_0x4252e8);_0x37218e=vn(_0x1352ab,_0x37218e,new C(_0x1f5766),_0x3ea2dd,_0x2b1caa,_0x182d89,_0x4051e9,_0x244c2d);}}),_0x37218e;}function Ru(_0x20c2a5,_0xf5362c,_0x4ebc67,_0x447aa7,_0x21da4a,_0x25481d,_0x5d6ea6){if(yn(_0x21da4a,_0x4ebc67)!=null)return _0xf5362c;const _0x4e32fc=_0xf5362c['serverCache']['isFiltered'](),_0x32c72e=_0xf5362c['serverCache'];if(_0x447aa7['value']!=null){if(v(_0x4ebc67)&&_0x32c72e['isFullyInitialized']()||_0x32c72e['isCompleteForPath'](_0x4ebc67))return vn(_0x20c2a5,_0xf5362c,_0x4ebc67,_0x32c72e['getNode']()['getChild'](_0x4ebc67),_0x21da4a,_0x25481d,_0x4e32fc,_0x5d6ea6);if(v(_0x4ebc67)){let _0x26277f=new S(null);return _0x32c72e['getNode']()['forEachChild'](ye,(_0x51106b,_0x24df5e)=>{_0x26277f=_0x26277f['set'](new C(_0x51106b),_0x24df5e);}),Si(_0x20c2a5,_0xf5362c,_0x4ebc67,_0x26277f,_0x21da4a,_0x25481d,_0x4e32fc,_0x5d6ea6);}else return _0xf5362c;}else{let _0x5e553a=new S(null);return _0x447aa7['foreach']((_0x532504,_0x53f3ba)=>{const _0x2ae321=A(_0x4ebc67,_0x532504);_0x32c72e['isCompleteForPath'](_0x2ae321)&&(_0x5e553a=_0x5e553a['set'](_0x532504,_0x32c72e['getNode']()['getChild'](_0x2ae321)));}),Si(_0x20c2a5,_0xf5362c,_0x4ebc67,_0x5e553a,_0x21da4a,_0x25481d,_0x4e32fc,_0x5d6ea6);}}function Au(_0x165180,_0x54d10c,_0x2cdac9,_0x1a0b19,_0x5931fe){const _0x42e6a2=_0x54d10c['serverCache'],_0xb49d9f=Lo(_0x54d10c,_0x42e6a2['getNode'](),_0x42e6a2['isFullyInitialized']()||v(_0x2cdac9),_0x42e6a2['isFiltered']());return Ho(_0x165180,_0xb49d9f,_0x2cdac9,_0x1a0b19,Vo,_0x5931fe);}function ku(_0x2e69fe,_0x4d98eb,_0x4639c2,_0x28ba4a,_0x50fd53,_0x23c126){let _0x2554ce;if(yn(_0x28ba4a,_0x4639c2)!=null)return _0x4d98eb;{const _0x5abb3d=new ns(_0x28ba4a,_0x4d98eb,_0x50fd53),_0x219b21=_0x4d98eb['eventCache']['getNode']();let _0x19b613;if(v(_0x4639c2)||y(_0x4639c2)==='.priority'){let _0x4e3810;if(_0x4d98eb['serverCache']['isFullyInitialized']())_0x4e3810=mn(_0x28ba4a,Ue(_0x4d98eb));else{const _0x218fdd=_0x4d98eb['serverCache']['getNode']();f(_0x218fdd instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4e3810=es(_0x28ba4a,_0x218fdd);}_0x4e3810=_0x4e3810,_0x19b613=_0x2e69fe['filter']['updateFullNode'](_0x219b21,_0x4e3810,_0x23c126);}else{const _0x21602b=y(_0x4639c2);let _0x5d5591=ts(_0x28ba4a,_0x21602b,_0x4d98eb['serverCache']);_0x5d5591==null&&_0x4d98eb['serverCache']['isCompleteForChild'](_0x21602b)&&(_0x5d5591=_0x219b21['getImmediateChild'](_0x21602b)),_0x5d5591!=null?_0x19b613=_0x2e69fe['filter']['updateChild'](_0x219b21,_0x21602b,_0x5d5591,b(_0x4639c2),_0x5abb3d,_0x23c126):_0x4d98eb['eventCache']['getNode']()['hasChild'](_0x21602b)?_0x19b613=_0x2e69fe['filter']['updateChild'](_0x219b21,_0x21602b,g['EMPTY_NODE'],b(_0x4639c2),_0x5abb3d,_0x23c126):_0x19b613=_0x219b21,_0x19b613['isEmpty']()&&_0x4d98eb['serverCache']['isFullyInitialized']()&&(_0x2554ce=mn(_0x28ba4a,Ue(_0x4d98eb)),_0x2554ce['isLeafNode']()&&(_0x19b613=_0x2e69fe['filter']['updateFullNode'](_0x19b613,_0x2554ce,_0x23c126)));}return _0x2554ce=_0x4d98eb['serverCache']['isFullyInitialized']()||yn(_0x28ba4a,w())!=null,wt(_0x4d98eb,_0x19b613,_0x2554ce,_0x2e69fe['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x4e4738,_0x4e7132){this['query_']=_0x4e4738,this['eventRegistrations_']=[];const _0x1687ac=this['query_']['_queryParams'],_0x3890b2=new Yi(_0x1687ac['getIndex']()),_0x4077f0=qh(_0x1687ac);this['processor_']=wu(_0x4077f0);const _0x103132=_0x4e7132['serverCache'],_0x2c4bd3=_0x4e7132['eventCache'],_0x2f2f0c=_0x3890b2['updateFullNode'](g['EMPTY_NODE'],_0x103132['getNode'](),null),_0x3fd08e=_0x4077f0['updateFullNode'](g['EMPTY_NODE'],_0x2c4bd3['getNode'](),null),_0x264546=new Ce(_0x2f2f0c,_0x103132['isFullyInitialized'](),_0x3890b2['filtersNodes']()),_0x4ba202=new Ce(_0x3fd08e,_0x2c4bd3['isFullyInitialized'](),_0x4077f0['filtersNodes']());this['viewCache_']=Dn(_0x4ba202,_0x264546),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4baf40){return _0x4baf40['viewCache_']['serverCache']['getNode']();}function Ou(_0x1c912b){return gn(_0x1c912b['viewCache_']);}function Du(_0x1d26a3,_0x5b782a){const _0x4fc954=Ue(_0x1d26a3['viewCache_']);return _0x4fc954&&(_0x1d26a3['query']['_queryParams']['loadsAllData']()||!v(_0x5b782a)&&!_0x4fc954['getImmediateChild'](y(_0x5b782a))['isEmpty']())?_0x4fc954['getChild'](_0x5b782a):null;}function lr(_0x1191f9){return _0x1191f9['eventRegistrations_']['length']===0x0;}function Mu(_0x48d828,_0x44e88c){_0x48d828['eventRegistrations_']['push'](_0x44e88c);}function hr(_0x5dc78b,_0x3eb288,_0x41b91f){const _0x45d1a5=[];if(_0x41b91f){f(_0x3eb288==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x550391=_0x5dc78b['query']['_path'];_0x5dc78b['eventRegistrations_']['forEach'](_0x585e50=>{const _0x5cef20=_0x585e50['createCancelEvent'](_0x41b91f,_0x550391);_0x5cef20&&_0x45d1a5['push'](_0x5cef20);});}if(_0x3eb288){let _0x3193f9=[];for(let _0x55d7e6=0x0;_0x55d7e6<_0x5dc78b['eventRegistrations_']['length'];++_0x55d7e6){const _0x1e4873=_0x5dc78b['eventRegistrations_'][_0x55d7e6];if(!_0x1e4873['matches'](_0x3eb288))_0x3193f9['push'](_0x1e4873);else{if(_0x3eb288['hasAnyCallback']()){_0x3193f9=_0x3193f9['concat'](_0x5dc78b['eventRegistrations_']['slice'](_0x55d7e6+0x1));break;}}}_0x5dc78b['eventRegistrations_']=_0x3193f9;}else _0x5dc78b['eventRegistrations_']=[];return _0x45d1a5;}function ur(_0x1907da,_0x1a152c,_0xff300e,_0x34e802){_0x1a152c['type']===q['MERGE']&&_0x1a152c['source']['queryId']!==null&&(f(Ue(_0x1907da['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x1907da['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x461b74=_0x1907da['viewCache_'],_0x4339ce=Tu(_0x1907da['processor_'],_0x461b74,_0x1a152c,_0xff300e,_0x34e802);return Cu(_0x1907da['processor_'],_0x4339ce['viewCache']),f(_0x4339ce['viewCache']['serverCache']['isFullyInitialized']()||!_0x461b74['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1907da['viewCache_']=_0x4339ce['viewCache'],$o(_0x1907da,_0x4339ce['changes'],_0x4339ce['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x3dc9ad,_0x4c059){const _0x767135=_0x3dc9ad['viewCache_']['eventCache'],_0x52bd5e=[];return _0x767135['getNode']()['isLeafNode']()||_0x767135['getNode']()['forEachChild'](R,(_0x49f3b5,_0x38921c)=>{_0x52bd5e['push'](tt(_0x49f3b5,_0x38921c));}),_0x767135['isFullyInitialized']()&&_0x52bd5e['push'](Oo(_0x767135['getNode']())),$o(_0x3dc9ad,_0x52bd5e,_0x767135['getNode'](),_0x4c059);}function $o(_0x4deb5b,_0x51ad62,_0x597834,_0x30004c){const _0x52716b=_0x30004c?[_0x30004c]:_0x4deb5b['eventRegistrations_'];return nu(_0x4deb5b['eventGenerator_'],_0x51ad62,_0x597834,_0x52716b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x596513){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x596513;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0xf504c8){return _0xf504c8['views']['size']===0x0;}function is(_0x12da03,_0x113422,_0x1abc8a,_0x4f5acc){const _0x4fb3ea=_0x113422['source']['queryId'];if(_0x4fb3ea!==null){const _0x16d94d=_0x12da03['views']['get'](_0x4fb3ea);return f(_0x16d94d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x16d94d,_0x113422,_0x1abc8a,_0x4f5acc);}else{let _0x186037=[];for(const _0x8f6374 of _0x12da03['views']['values']())_0x186037=_0x186037['concat'](ur(_0x8f6374,_0x113422,_0x1abc8a,_0x4f5acc));return _0x186037;}}function qo(_0x579fae,_0x15205c,_0x1d79df,_0x48c35f,_0x58132b){const _0x445c01=_0x15205c['_queryIdentifier'],_0x4b8bcd=_0x579fae['views']['get'](_0x445c01);if(!_0x4b8bcd){let _0x49ee2d=mn(_0x1d79df,_0x58132b?_0x48c35f:null),_0x3f8832=!0x1;_0x49ee2d?_0x3f8832=!0x0:_0x48c35f instanceof g?(_0x49ee2d=es(_0x1d79df,_0x48c35f),_0x3f8832=!0x1):(_0x49ee2d=g['EMPTY_NODE'],_0x3f8832=!0x1);const _0x9cd744=Dn(new Ce(_0x49ee2d,_0x3f8832,!0x1),new Ce(_0x48c35f,_0x58132b,!0x1));return new Nu(_0x15205c,_0x9cd744);}return _0x4b8bcd;}function Wu(_0x231f3c,_0x1a4a7a,_0x2af4ec,_0x4354d9,_0x1cf591,_0x1b9c0b){const _0x3c77b6=qo(_0x231f3c,_0x1a4a7a,_0x4354d9,_0x1cf591,_0x1b9c0b);return _0x231f3c['views']['has'](_0x1a4a7a['_queryIdentifier'])||_0x231f3c['views']['set'](_0x1a4a7a['_queryIdentifier'],_0x3c77b6),Mu(_0x3c77b6,_0x2af4ec),Lu(_0x3c77b6,_0x2af4ec);}function Bu(_0x58cea9,_0x2df30e,_0x57442b,_0x1231e8){const _0x4b8693=_0x2df30e['_queryIdentifier'],_0x4fdef3=[];let _0x450d1a=[];const _0x17011c=Te(_0x58cea9);if(_0x4b8693==='default'){for(const [_0x2ac573,_0x41240c]of _0x58cea9['views']['entries']())_0x450d1a=_0x450d1a['concat'](hr(_0x41240c,_0x57442b,_0x1231e8)),lr(_0x41240c)&&(_0x58cea9['views']['delete'](_0x2ac573),_0x41240c['query']['_queryParams']['loadsAllData']()||_0x4fdef3['push'](_0x41240c['query']));}else{const _0x1950b7=_0x58cea9['views']['get'](_0x4b8693);_0x1950b7&&(_0x450d1a=_0x450d1a['concat'](hr(_0x1950b7,_0x57442b,_0x1231e8)),lr(_0x1950b7)&&(_0x58cea9['views']['delete'](_0x4b8693),_0x1950b7['query']['_queryParams']['loadsAllData']()||_0x4fdef3['push'](_0x1950b7['query'])));}return _0x17011c&&!Te(_0x58cea9)&&_0x4fdef3['push'](new(Fu())(_0x2df30e['_repo'],_0x2df30e['_path'])),{'removed':_0x4fdef3,'events':_0x450d1a};}function zo(_0x463504){const _0x202bf7=[];for(const _0x5b35e0 of _0x463504['views']['values']())_0x5b35e0['query']['_queryParams']['loadsAllData']()||_0x202bf7['push'](_0x5b35e0);return _0x202bf7;}function Ee(_0xd3cb01,_0x585fc2){let _0x2298e6=null;for(const _0x523dfe of _0xd3cb01['views']['values']())_0x2298e6=_0x2298e6||Du(_0x523dfe,_0x585fc2);return _0x2298e6;}function jo(_0x2a13e5,_0x58bd16){if(_0x58bd16['_queryParams']['loadsAllData']())return Ln(_0x2a13e5);{const _0x4c6eff=_0x58bd16['_queryIdentifier'];return _0x2a13e5['views']['get'](_0x4c6eff);}}function Ko(_0x67933d,_0x483675){return jo(_0x67933d,_0x483675)!=null;}function Te(_0x32be57){return Ln(_0x32be57)!=null;}function Ln(_0x3d4579){for(const _0x264d85 of _0x3d4579['views']['values']())if(_0x264d85['query']['_queryParams']['loadsAllData']())return _0x264d85;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x19f4ba){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x19f4ba;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x56d36d){this['listenProvider_']=_0x56d36d,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x7ae180,_0x335777,_0x251ee4,_0x597ca9,_0x55ad67){return ou(_0x7ae180['pendingWriteTree_'],_0x335777,_0x251ee4,_0x597ca9,_0x55ad67),_0x55ad67?ht(_0x7ae180,new Fe(Ji(),_0x335777,_0x251ee4)):[];}function Gu(_0x4b7e83,_0x12644f,_0x147928,_0x32447b){au(_0x4b7e83['pendingWriteTree_'],_0x12644f,_0x147928,_0x32447b);const _0x166ec4=S['fromObject'](_0x147928);return ht(_0x4b7e83,new nt(Ji(),_0x12644f,_0x166ec4));}function pe(_0x1ffbc3,_0x111b6a,_0x144e43=!0x1){const _0x3efb2b=cu(_0x1ffbc3['pendingWriteTree_'],_0x111b6a);if(lu(_0x1ffbc3['pendingWriteTree_'],_0x111b6a)){let _0x3b773d=new S(null);return _0x3efb2b['snap']!=null?_0x3b773d=_0x3b773d['set'](w(),!0x0):x(_0x3efb2b['children'],_0x9106f9=>{_0x3b773d=_0x3b773d['set'](new C(_0x9106f9),!0x0);}),ht(_0x1ffbc3,new _n(_0x3efb2b['path'],_0x3b773d,_0x144e43));}else return[];}function $t(_0x57ae67,_0x2775c3,_0x518973){return ht(_0x57ae67,new Fe(Xi(),_0x2775c3,_0x518973));}function qu(_0x3c8430,_0x988edb,_0x1b714a){const _0xa56c7c=S['fromObject'](_0x1b714a);return ht(_0x3c8430,new nt(Xi(),_0x988edb,_0xa56c7c));}function zu(_0xef8b97,_0x2bd721){return ht(_0xef8b97,new Dt(Xi(),_0x2bd721));}function ju(_0x57484d,_0x26209f,_0x1c7af4){const _0x46e67d=rs(_0x57484d,_0x1c7af4);if(_0x46e67d){const _0x51bb30=os(_0x46e67d),_0x524762=_0x51bb30['path'],_0x6773f1=_0x51bb30['queryId'],_0x2a977b=F(_0x524762,_0x26209f),_0x3e8159=new Dt(Zi(_0x6773f1),_0x2a977b);return as(_0x57484d,_0x524762,_0x3e8159);}else return[];}function wn(_0x237246,_0x219a7e,_0x22ef9a,_0x162102,_0x583c8e=!0x1){const _0x3c26de=_0x219a7e['_path'],_0x281ddb=_0x237246['syncPointTree_']['get'](_0x3c26de);let _0x1e4214=[];if(_0x281ddb&&(_0x219a7e['_queryIdentifier']==='default'||Ko(_0x281ddb,_0x219a7e))){const _0x2e3457=Bu(_0x281ddb,_0x219a7e,_0x22ef9a,_0x162102);Uu(_0x281ddb)&&(_0x237246['syncPointTree_']=_0x237246['syncPointTree_']['remove'](_0x3c26de));const _0xa118df=_0x2e3457['removed'];if(_0x1e4214=_0x2e3457['events'],!_0x583c8e){const _0x52e4ba=_0xa118df['findIndex'](_0xdc9326=>_0xdc9326['_queryParams']['loadsAllData']())!==-0x1,_0x4f3e9d=_0x237246['syncPointTree_']['findOnPath'](_0x3c26de,(_0x2e9dea,_0x222cc9)=>Te(_0x222cc9));if(_0x52e4ba&&!_0x4f3e9d){const _0x15de62=_0x237246['syncPointTree_']['subtree'](_0x3c26de);if(!_0x15de62['isEmpty']()){const _0x1d94c8=Qu(_0x15de62);for(let _0x297431=0x0;_0x297431<_0x1d94c8['length'];++_0x297431){const _0x2ef1e6=_0x1d94c8[_0x297431],_0x5bb036=_0x2ef1e6['query'],_0x228d39=Xo(_0x237246,_0x2ef1e6);_0x237246['listenProvider_']['startListening'](Tt(_0x5bb036),Mt(_0x237246,_0x5bb036),_0x228d39['hashFn'],_0x228d39['onComplete']);}}}!_0x4f3e9d&&_0xa118df['length']>0x0&&!_0x162102&&(_0x52e4ba?_0x237246['listenProvider_']['stopListening'](Tt(_0x219a7e),null):_0xa118df['forEach'](_0x26c813=>{const _0x45ecba=_0x237246['queryToTagMap']['get'](Fn(_0x26c813));_0x237246['listenProvider_']['stopListening'](Tt(_0x26c813),_0x45ecba);}));}Ju(_0x237246,_0xa118df);}return _0x1e4214;}function Yo(_0x26ed0a,_0x1d0d3e,_0x34cb8e,_0x1622e0){const _0xb4234e=rs(_0x26ed0a,_0x1622e0);if(_0xb4234e!=null){const _0x570c98=os(_0xb4234e),_0x221516=_0x570c98['path'],_0x1edd1a=_0x570c98['queryId'],_0x359412=F(_0x221516,_0x1d0d3e),_0x322d5b=new Fe(Zi(_0x1edd1a),_0x359412,_0x34cb8e);return as(_0x26ed0a,_0x221516,_0x322d5b);}else return[];}function Ku(_0x1197d4,_0x51d55d,_0x4955ff,_0x4c7bf0){const _0x29ffc5=rs(_0x1197d4,_0x4c7bf0);if(_0x29ffc5){const _0xde6d88=os(_0x29ffc5),_0x4a3dcb=_0xde6d88['path'],_0xef40f6=_0xde6d88['queryId'],_0x6ee5e8=F(_0x4a3dcb,_0x51d55d),_0x546fa3=S['fromObject'](_0x4955ff),_0x37e488=new nt(Zi(_0xef40f6),_0x6ee5e8,_0x546fa3);return as(_0x1197d4,_0x4a3dcb,_0x37e488);}else return[];}function bi(_0x44e386,_0x3fa3ad,_0x512e84,_0x30439d=!0x1){const _0x4ec5fb=_0x3fa3ad['_path'];let _0x4c35a2=null,_0x254dd7=!0x1;_0x44e386['syncPointTree_']['foreachOnPath'](_0x4ec5fb,(_0x455621,_0xdbb6e0)=>{const _0x40779e=F(_0x455621,_0x4ec5fb);_0x4c35a2=_0x4c35a2||Ee(_0xdbb6e0,_0x40779e),_0x254dd7=_0x254dd7||Te(_0xdbb6e0);});let _0x14379b=_0x44e386['syncPointTree_']['get'](_0x4ec5fb);_0x14379b?(_0x254dd7=_0x254dd7||Te(_0x14379b),_0x4c35a2=_0x4c35a2||Ee(_0x14379b,w())):(_0x14379b=new Go(),_0x44e386['syncPointTree_']=_0x44e386['syncPointTree_']['set'](_0x4ec5fb,_0x14379b));let _0x251057;_0x4c35a2!=null?_0x251057=!0x0:(_0x251057=!0x1,_0x4c35a2=g['EMPTY_NODE'],_0x44e386['syncPointTree_']['subtree'](_0x4ec5fb)['foreachChild']((_0x34046d,_0x55b460)=>{const _0x528845=Ee(_0x55b460,w());_0x528845&&(_0x4c35a2=_0x4c35a2['updateImmediateChild'](_0x34046d,_0x528845));}));const _0x3465ca=Ko(_0x14379b,_0x3fa3ad);if(!_0x3465ca&&!_0x3fa3ad['_queryParams']['loadsAllData']()){const _0x5168b1=Fn(_0x3fa3ad);f(!_0x44e386['queryToTagMap']['has'](_0x5168b1),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xd81bd2=Xu();_0x44e386['queryToTagMap']['set'](_0x5168b1,_0xd81bd2),_0x44e386['tagToQueryMap']['set'](_0xd81bd2,_0x5168b1);}const _0x12cb43=Mn(_0x44e386['pendingWriteTree_'],_0x4ec5fb);let _0x19a65f=Wu(_0x14379b,_0x3fa3ad,_0x512e84,_0x12cb43,_0x4c35a2,_0x251057);if(!_0x3465ca&&!_0x254dd7&&!_0x30439d){const _0x34c559=jo(_0x14379b,_0x3fa3ad);_0x19a65f=_0x19a65f['concat'](Zu(_0x44e386,_0x3fa3ad,_0x34c559));}return _0x19a65f;}function xn(_0x46740e,_0x288fef,_0x53248b){const _0xa0d43d=_0x46740e['pendingWriteTree_'],_0x59a2a2=_0x46740e['syncPointTree_']['findOnPath'](_0x288fef,(_0x29efb2,_0x2ea6a1)=>{const _0x12c6f7=F(_0x29efb2,_0x288fef),_0x2b2b37=Ee(_0x2ea6a1,_0x12c6f7);if(_0x2b2b37)return _0x2b2b37;});return Uo(_0xa0d43d,_0x288fef,_0x59a2a2,_0x53248b,!0x0);}function Yu(_0x38b825,_0x39f0c2){const _0xeb935e=_0x39f0c2['_path'];let _0x124acd=null;_0x38b825['syncPointTree_']['foreachOnPath'](_0xeb935e,(_0x1052bc,_0x40d984)=>{const _0x14eba1=F(_0x1052bc,_0xeb935e);_0x124acd=_0x124acd||Ee(_0x40d984,_0x14eba1);});let _0x486d18=_0x38b825['syncPointTree_']['get'](_0xeb935e);_0x486d18?_0x124acd=_0x124acd||Ee(_0x486d18,w()):(_0x486d18=new Go(),_0x38b825['syncPointTree_']=_0x38b825['syncPointTree_']['set'](_0xeb935e,_0x486d18));const _0x21547c=_0x124acd!=null,_0x1f04fb=_0x21547c?new Ce(_0x124acd,!0x0,!0x1):null,_0x71c946=Mn(_0x38b825['pendingWriteTree_'],_0x39f0c2['_path']),_0x2bddbd=qo(_0x486d18,_0x39f0c2,_0x71c946,_0x21547c?_0x1f04fb['getNode']():g['EMPTY_NODE'],_0x21547c);return Ou(_0x2bddbd);}function ht(_0x46d905,_0x45aa61){return Qo(_0x45aa61,_0x46d905['syncPointTree_'],null,Mn(_0x46d905['pendingWriteTree_'],w()));}function Qo(_0x40140,_0x22fd71,_0x211279,_0x36860f){if(v(_0x40140['path']))return Jo(_0x40140,_0x22fd71,_0x211279,_0x36860f);{const _0x50bffb=_0x22fd71['get'](w());_0x211279==null&&_0x50bffb!=null&&(_0x211279=Ee(_0x50bffb,w()));let _0x1aaabf=[];const _0x341585=y(_0x40140['path']),_0x7600fa=_0x40140['operationForChild'](_0x341585),_0x149d71=_0x22fd71['children']['get'](_0x341585);if(_0x149d71&&_0x7600fa){const _0x39aa2d=_0x211279?_0x211279['getImmediateChild'](_0x341585):null,_0x110e41=Wo(_0x36860f,_0x341585);_0x1aaabf=_0x1aaabf['concat'](Qo(_0x7600fa,_0x149d71,_0x39aa2d,_0x110e41));}return _0x50bffb&&(_0x1aaabf=_0x1aaabf['concat'](is(_0x50bffb,_0x40140,_0x36860f,_0x211279))),_0x1aaabf;}}function Jo(_0x216d9f,_0x193e9b,_0x231dca,_0x50c4a5){const _0x3b83f3=_0x193e9b['get'](w());_0x231dca==null&&_0x3b83f3!=null&&(_0x231dca=Ee(_0x3b83f3,w()));let _0x55014a=[];return _0x193e9b['children']['inorderTraversal']((_0xb47c9b,_0x4bac26)=>{const _0x48f3f3=_0x231dca?_0x231dca['getImmediateChild'](_0xb47c9b):null,_0x2a92e4=Wo(_0x50c4a5,_0xb47c9b),_0x1498f7=_0x216d9f['operationForChild'](_0xb47c9b);_0x1498f7&&(_0x55014a=_0x55014a['concat'](Jo(_0x1498f7,_0x4bac26,_0x48f3f3,_0x2a92e4)));}),_0x3b83f3&&(_0x55014a=_0x55014a['concat'](is(_0x3b83f3,_0x216d9f,_0x50c4a5,_0x231dca))),_0x55014a;}function Xo(_0x5d3025,_0x11ee15){const _0xf1ea7c=_0x11ee15['query'],_0x4f11a7=Mt(_0x5d3025,_0xf1ea7c);return{'hashFn':()=>(Pu(_0x11ee15)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x493eda=>{if(_0x493eda==='ok')return _0x4f11a7?ju(_0x5d3025,_0xf1ea7c['_path'],_0x4f11a7):zu(_0x5d3025,_0xf1ea7c['_path']);{const _0x4b511b=ql(_0x493eda,_0xf1ea7c);return wn(_0x5d3025,_0xf1ea7c,null,_0x4b511b);}}};}function Mt(_0x42d643,_0x427ceb){const _0x346547=Fn(_0x427ceb);return _0x42d643['queryToTagMap']['get'](_0x346547);}function Fn(_0x4c7fde){return _0x4c7fde['_path']['toString']()+'$'+_0x4c7fde['_queryIdentifier'];}function rs(_0x1018e0,_0x3d2cfb){return _0x1018e0['tagToQueryMap']['get'](_0x3d2cfb);}function os(_0x58ad34){const _0x4d5a7c=_0x58ad34['indexOf']('$');return f(_0x4d5a7c!==-0x1&&_0x4d5a7c<_0x58ad34['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x58ad34['substr'](_0x4d5a7c+0x1),'path':new C(_0x58ad34['substr'](0x0,_0x4d5a7c))};}function as(_0xa1d25d,_0xb3740a,_0x2339e5){const _0x4294ce=_0xa1d25d['syncPointTree_']['get'](_0xb3740a);f(_0x4294ce,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3a33d8=Mn(_0xa1d25d['pendingWriteTree_'],_0xb3740a);return is(_0x4294ce,_0x2339e5,_0x3a33d8,null);}function Qu(_0xf25da0){return _0xf25da0['fold']((_0x75ab74,_0x334382,_0x1d0320)=>{if(_0x334382&&Te(_0x334382))return[Ln(_0x334382)];{let _0x3d3b99=[];return _0x334382&&(_0x3d3b99=zo(_0x334382)),x(_0x1d0320,(_0x207ebc,_0x40bea1)=>{_0x3d3b99=_0x3d3b99['concat'](_0x40bea1);}),_0x3d3b99;}});}function Tt(_0x51cb17){return _0x51cb17['_queryParams']['loadsAllData']()&&!_0x51cb17['_queryParams']['isDefault']()?new(Hu())(_0x51cb17['_repo'],_0x51cb17['_path']):_0x51cb17;}function Ju(_0x4524e6,_0x1e82f6){for(let _0x3f9faa=0x0;_0x3f9faa<_0x1e82f6['length'];++_0x3f9faa){const _0x360850=_0x1e82f6[_0x3f9faa];if(!_0x360850['_queryParams']['loadsAllData']()){const _0x195a72=Fn(_0x360850),_0x16a666=_0x4524e6['queryToTagMap']['get'](_0x195a72);_0x4524e6['queryToTagMap']['delete'](_0x195a72),_0x4524e6['tagToQueryMap']['delete'](_0x16a666);}}}function Xu(){return $u++;}function Zu(_0x19dafb,_0x2eec5e,_0x493e52){const _0x197c5d=_0x2eec5e['_path'],_0xf47c77=Mt(_0x19dafb,_0x2eec5e),_0xc5e928=Xo(_0x19dafb,_0x493e52),_0x20c5ba=_0x19dafb['listenProvider_']['startListening'](Tt(_0x2eec5e),_0xf47c77,_0xc5e928['hashFn'],_0xc5e928['onComplete']),_0x4c84b9=_0x19dafb['syncPointTree_']['subtree'](_0x197c5d);if(_0xf47c77)f(!Te(_0x4c84b9['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2cd9c5=_0x4c84b9['fold']((_0x817382,_0x28c2de,_0x5f3155)=>{if(!v(_0x817382)&&_0x28c2de&&Te(_0x28c2de))return[Ln(_0x28c2de)['query']];{let _0x3231b7=[];return _0x28c2de&&(_0x3231b7=_0x3231b7['concat'](zo(_0x28c2de)['map'](_0x11275f=>_0x11275f['query']))),x(_0x5f3155,(_0x674866,_0x8e4e01)=>{_0x3231b7=_0x3231b7['concat'](_0x8e4e01);}),_0x3231b7;}});for(let _0x26910c=0x0;_0x26910c<_0x2cd9c5['length'];++_0x26910c){const _0x48cf45=_0x2cd9c5[_0x26910c];_0x19dafb['listenProvider_']['stopListening'](Tt(_0x48cf45),Mt(_0x19dafb,_0x48cf45));}}return _0x20c5ba;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x251715){this['node_']=_0x251715;}['getImmediateChild'](_0x1db6a1){const _0x318286=this['node_']['getImmediateChild'](_0x1db6a1);return new cs(_0x318286);}['node'](){return this['node_'];}}class ls{constructor(_0x1b6902,_0xa947d5){this['syncTree_']=_0x1b6902,this['path_']=_0xa947d5;}['getImmediateChild'](_0x2a2169){const _0x55f024=A(this['path_'],_0x2a2169);return new ls(this['syncTree_'],_0x55f024);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x26a91a){return _0x26a91a=_0x26a91a||{},_0x26a91a['timestamp']=_0x26a91a['timestamp']||new Date()['getTime'](),_0x26a91a;},fr=function(_0x430e5c,_0x2014ed,_0x8e2c5f){if(!_0x430e5c||typeof _0x430e5c!='object')return _0x430e5c;if(f('.sv'in _0x430e5c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x430e5c['.sv']=='string')return td(_0x430e5c['.sv'],_0x2014ed,_0x8e2c5f);if(typeof _0x430e5c['.sv']=='object')return nd(_0x430e5c['.sv'],_0x2014ed);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x430e5c,null,0x2));},td=function(_0x375602,_0x41a455,_0x34d78d){switch(_0x375602){case'timestamp':return _0x34d78d['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x375602);}},nd=function(_0x22a105,_0x5914a3,_0x5bc25e){_0x22a105['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x22a105,null,0x2));const _0x4ca361=_0x22a105['increment'];typeof _0x4ca361!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4ca361);const _0x43ff99=_0x5914a3['node']();if(f(_0x43ff99!==null&&typeof _0x43ff99<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x43ff99['isLeafNode']())return _0x4ca361;const _0x443a68=_0x43ff99['getValue']();return typeof _0x443a68!='number'?_0x4ca361:_0x443a68+_0x4ca361;},Zo=function(_0x8ff0e8,_0xd8ce11,_0x30cb32,_0x476186){return us(_0xd8ce11,new ls(_0x30cb32,_0x8ff0e8),_0x476186);},hs=function(_0x3151e2,_0x1f7222,_0x520019){return us(_0x3151e2,new cs(_0x1f7222),_0x520019);};function us(_0x4e7a4f,_0x34fb9a,_0x163948){const _0x1a6168=_0x4e7a4f['getPriority']()['val'](),_0x43e7ee=fr(_0x1a6168,_0x34fb9a['getImmediateChild']('.priority'),_0x163948);let _0x41678a;if(_0x4e7a4f['isLeafNode']()){const _0x424ae3=_0x4e7a4f,_0x2069fc=fr(_0x424ae3['getValue'](),_0x34fb9a,_0x163948);return _0x2069fc!==_0x424ae3['getValue']()||_0x43e7ee!==_0x424ae3['getPriority']()['val']()?new D(_0x2069fc,N(_0x43e7ee)):_0x4e7a4f;}else{const _0x4ce620=_0x4e7a4f;return _0x41678a=_0x4ce620,_0x43e7ee!==_0x4ce620['getPriority']()['val']()&&(_0x41678a=_0x41678a['updatePriority'](new D(_0x43e7ee))),_0x4ce620['forEachChild'](R,(_0x4b4131,_0x4707db)=>{const _0x726bd=us(_0x4707db,_0x34fb9a['getImmediateChild'](_0x4b4131),_0x163948);_0x726bd!==_0x4707db&&(_0x41678a=_0x41678a['updateImmediateChild'](_0x4b4131,_0x726bd));}),_0x41678a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x11fdc6='',_0xeab86b=null,_0x4d3d19={'children':{},'childCount':0x0}){this['name']=_0x11fdc6,this['parent']=_0xeab86b,this['node']=_0x4d3d19;}}function Un(_0x4d7418,_0x195fba){let _0x28b68d=_0x195fba instanceof C?_0x195fba:new C(_0x195fba),_0x268c59=_0x4d7418,_0x1aeec1=y(_0x28b68d);for(;_0x1aeec1!==null;){const _0x13e543=Oe(_0x268c59['node']['children'],_0x1aeec1)||{'children':{},'childCount':0x0};_0x268c59=new ds(_0x1aeec1,_0x268c59,_0x13e543),_0x28b68d=b(_0x28b68d),_0x1aeec1=y(_0x28b68d);}return _0x268c59;}function Ge(_0x5426ba){return _0x5426ba['node']['value'];}function fs(_0x91bd8d,_0x104aa6){_0x91bd8d['node']['value']=_0x104aa6,Ri(_0x91bd8d);}function ea(_0x324e07){return _0x324e07['node']['childCount']>0x0;}function id(_0x394690){return Ge(_0x394690)===void 0x0&&!ea(_0x394690);}function Wn(_0x188d8c,_0x236417){x(_0x188d8c['node']['children'],(_0x2529ac,_0x431b7b)=>{_0x236417(new ds(_0x2529ac,_0x188d8c,_0x431b7b));});}function ta(_0x178d8d,_0x5a5db6,_0x1eea35,_0x8fde2c){_0x1eea35&&_0x5a5db6(_0x178d8d),Wn(_0x178d8d,_0x3f11f3=>{ta(_0x3f11f3,_0x5a5db6,!0x0);});}function sd(_0x331411,_0x527819,_0x57e08a){let _0x9e0400=_0x331411['parent'];for(;_0x9e0400!==null;){if(_0x527819(_0x9e0400))return!0x0;_0x9e0400=_0x9e0400['parent'];}return!0x1;}function Gt(_0x5a9f13){return new C(_0x5a9f13['parent']===null?_0x5a9f13['name']:Gt(_0x5a9f13['parent'])+'/'+_0x5a9f13['name']);}function Ri(_0xae94c6){_0xae94c6['parent']!==null&&rd(_0xae94c6['parent'],_0xae94c6['name'],_0xae94c6);}function rd(_0x2b38fb,_0x3a9bed,_0xb90f26){const _0x32a6a8=id(_0xb90f26),_0x14c7b6=Y(_0x2b38fb['node']['children'],_0x3a9bed);_0x32a6a8&&_0x14c7b6?(delete _0x2b38fb['node']['children'][_0x3a9bed],_0x2b38fb['node']['childCount']--,Ri(_0x2b38fb)):!_0x32a6a8&&!_0x14c7b6&&(_0x2b38fb['node']['children'][_0x3a9bed]=_0xb90f26['node'],_0x2b38fb['node']['childCount']++,Ri(_0x2b38fb));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x38493e){return typeof _0x38493e=='string'&&_0x38493e['length']!==0x0&&!od['test'](_0x38493e);},na=function(_0x2c560c){return typeof _0x2c560c=='string'&&_0x2c560c['length']!==0x0&&!ad['test'](_0x2c560c);},cd=function(_0x6eb935){return _0x6eb935&&(_0x6eb935=_0x6eb935['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x6eb935);},Cn=function(_0x5d0ffb){return _0x5d0ffb===null||typeof _0x5d0ffb=='string'||typeof _0x5d0ffb=='number'&&!Wi(_0x5d0ffb)||_0x5d0ffb&&typeof _0x5d0ffb=='object'&&Y(_0x5d0ffb,'.sv');},qt=function(_0x3f5235,_0x4fa0fa,_0x2be3e7,_0x21d375){_0x21d375&&_0x4fa0fa===void 0x0||zt(Nn(_0x3f5235,'value'),_0x4fa0fa,_0x2be3e7);},zt=function(_0x219827,_0x263245,_0x6e8081){const _0xc5eb5a=_0x6e8081 instanceof C?new Sh(_0x6e8081,_0x219827):_0x6e8081;if(_0x263245===void 0x0)throw new Error(_0x219827+'contains\x20undefined\x20'+Ne(_0xc5eb5a));if(typeof _0x263245=='function')throw new Error(_0x219827+'contains\x20a\x20function\x20'+Ne(_0xc5eb5a)+'\x20with\x20contents\x20=\x20'+_0x263245['toString']());if(Wi(_0x263245))throw new Error(_0x219827+'contains\x20'+_0x263245['toString']()+'\x20'+Ne(_0xc5eb5a));if(typeof _0x263245=='string'&&_0x263245['length']>oi/0x3&&Pn(_0x263245)>oi)throw new Error(_0x219827+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0xc5eb5a)+'\x20(\x27'+_0x263245['substring'](0x0,0x32)+'...\x27)');if(_0x263245&&typeof _0x263245=='object'){let _0x11f3d5=!0x1,_0x59d2d9=!0x1;if(x(_0x263245,(_0x378e2a,_0xb364a1)=>{if(_0x378e2a==='.value')_0x11f3d5=!0x0;else{if(_0x378e2a!=='.priority'&&_0x378e2a!=='.sv'&&(_0x59d2d9=!0x0,!ps(_0x378e2a)))throw new Error(_0x219827+'\x20contains\x20an\x20invalid\x20key\x20('+_0x378e2a+')\x20'+Ne(_0xc5eb5a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0xc5eb5a,_0x378e2a),zt(_0x219827,_0xb364a1,_0xc5eb5a),Rh(_0xc5eb5a);}),_0x11f3d5&&_0x59d2d9)throw new Error(_0x219827+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0xc5eb5a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x426d07,_0x52b27d){let _0x1d8fc9,_0x3cd8c8;for(_0x1d8fc9=0x0;_0x1d8fc9<_0x52b27d['length'];_0x1d8fc9++){_0x3cd8c8=_0x52b27d[_0x1d8fc9];const _0x42be96=kt(_0x3cd8c8);for(let _0x16a9e3=0x0;_0x16a9e3<_0x42be96['length'];_0x16a9e3++)if(!(_0x42be96[_0x16a9e3]==='.priority'&&_0x16a9e3===_0x42be96['length']-0x1)){if(!ps(_0x42be96[_0x16a9e3]))throw new Error(_0x426d07+'contains\x20an\x20invalid\x20key\x20('+_0x42be96[_0x16a9e3]+')\x20in\x20path\x20'+_0x3cd8c8['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x52b27d['sort'](Th);let _0x51b4d0=null;for(_0x1d8fc9=0x0;_0x1d8fc9<_0x52b27d['length'];_0x1d8fc9++){if(_0x3cd8c8=_0x52b27d[_0x1d8fc9],_0x51b4d0!==null&&$(_0x51b4d0,_0x3cd8c8))throw new Error(_0x426d07+'contains\x20a\x20path\x20'+_0x51b4d0['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3cd8c8['toString']());_0x51b4d0=_0x3cd8c8;}},hd=function(_0x46511c,_0x1d4af0,_0xd62ed8,_0x18d9e4){const _0x5417d7=Nn(_0x46511c,'values');if(!(_0x1d4af0&&typeof _0x1d4af0=='object')||Array['isArray'](_0x1d4af0))throw new Error(_0x5417d7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4eab7a=[];x(_0x1d4af0,(_0xb7fa99,_0x212da3)=>{const _0x10eaab=new C(_0xb7fa99);if(zt(_0x5417d7,_0x212da3,A(_0xd62ed8,_0x10eaab)),Gi(_0x10eaab)==='.priority'&&!Cn(_0x212da3))throw new Error(_0x5417d7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x10eaab['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4eab7a['push'](_0x10eaab);}),ld(_0x5417d7,_0x4eab7a);},_s=function(_0x1ecb7a,_0x1caeef,_0x77536c,_0xd6f07c){if(!na(_0x77536c))throw new Error(Nn(_0x1ecb7a,_0x1caeef)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x77536c+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x38b8c4,_0x2d1f64,_0x56b112,_0x25b7a5){_0x56b112&&(_0x56b112=_0x56b112['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x38b8c4,_0x2d1f64,_0x56b112);},gs=function(_0x274565,_0x1750fe){if(y(_0x1750fe)==='.info')throw new Error(_0x274565+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x25f290,_0x4ffa20){const _0x426c34=_0x4ffa20['path']['toString']();if(typeof _0x4ffa20['repoInfo']['host']!='string'||_0x4ffa20['repoInfo']['host']['length']===0x0||!ps(_0x4ffa20['repoInfo']['namespace'])&&_0x4ffa20['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x426c34['length']!==0x0&&!cd(_0x426c34))throw new Error(Nn(_0x25f290,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x351e1a,_0x3f9861){let _0xc5ec29=null;for(let _0x16850c=0x0;_0x16850c<_0x3f9861['length'];_0x16850c++){const _0x307113=_0x3f9861[_0x16850c],_0x4d484b=_0x307113['getPath']();_0xc5ec29!==null&&!qi(_0x4d484b,_0xc5ec29['path'])&&(_0x351e1a['eventLists_']['push'](_0xc5ec29),_0xc5ec29=null),_0xc5ec29===null&&(_0xc5ec29={'events':[],'path':_0x4d484b}),_0xc5ec29['events']['push'](_0x307113);}_0xc5ec29&&_0x351e1a['eventLists_']['push'](_0xc5ec29);}function ia(_0x5c53b1,_0x478334,_0x1fe805){Bn(_0x5c53b1,_0x1fe805),sa(_0x5c53b1,_0x24d5c9=>qi(_0x24d5c9,_0x478334));}function V(_0x113d5a,_0x5eb782,_0x2e9692){Bn(_0x113d5a,_0x2e9692),sa(_0x113d5a,_0xf48dda=>$(_0xf48dda,_0x5eb782)||$(_0x5eb782,_0xf48dda));}function sa(_0x5c1b9d,_0x1369c4){_0x5c1b9d['recursionDepth_']++;let _0x4d05d1=!0x0;for(let _0x55e554=0x0;_0x55e554<_0x5c1b9d['eventLists_']['length'];_0x55e554++){const _0xf6b97=_0x5c1b9d['eventLists_'][_0x55e554];if(_0xf6b97){const _0x194005=_0xf6b97['path'];_0x1369c4(_0x194005)?(pd(_0x5c1b9d['eventLists_'][_0x55e554]),_0x5c1b9d['eventLists_'][_0x55e554]=null):_0x4d05d1=!0x1;}}_0x4d05d1&&(_0x5c1b9d['eventLists_']=[]),_0x5c1b9d['recursionDepth_']--;}function pd(_0x24f7e6){for(let _0x92694d=0x0;_0x92694d<_0x24f7e6['events']['length'];_0x92694d++){const _0x3ad762=_0x24f7e6['events'][_0x92694d];if(_0x3ad762!==null){_0x24f7e6['events'][_0x92694d]=null;const _0x57e822=_0x3ad762['getEventRunner']();Et&&L('event:\x20'+_0x3ad762['toString']()),lt(_0x57e822);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x436390,_0x244b7a,_0x3c35a3,_0x2a81b8){this['repoInfo_']=_0x436390,this['forceRestClient_']=_0x244b7a,this['authTokenProvider_']=_0x3c35a3,this['appCheckProvider_']=_0x2a81b8,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x460009,_0x47c197,_0x358e77){if(_0x460009['stats_']=Hi(_0x460009['repoInfo_']),_0x460009['forceRestClient_']||Yl())_0x460009['server_']=new fn(_0x460009['repoInfo_'],(_0x74b4cb,_0x2f491d,_0x4e9220,_0x50a951)=>{pr(_0x460009,_0x74b4cb,_0x2f491d,_0x4e9220,_0x50a951);},_0x460009['authTokenProvider_'],_0x460009['appCheckProvider_']),setTimeout(()=>_r(_0x460009,!0x0),0x0);else{if(typeof _0x358e77<'u'&&_0x358e77!==null){if(typeof _0x358e77!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x358e77);}catch(_0xec9e3f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0xec9e3f);}}_0x460009['persistentConnection_']=new ie(_0x460009['repoInfo_'],_0x47c197,(_0x270de6,_0x2a8829,_0x4c9f11,_0x1a4830)=>{pr(_0x460009,_0x270de6,_0x2a8829,_0x4c9f11,_0x1a4830);},_0x501349=>{_r(_0x460009,_0x501349);},_0x3dd15e=>{yd(_0x460009,_0x3dd15e);},_0x460009['authTokenProvider_'],_0x460009['appCheckProvider_'],_0x358e77),_0x460009['server_']=_0x460009['persistentConnection_'];}_0x460009['authTokenProvider_']['addTokenChangeListener'](_0x409bac=>{_0x460009['server_']['refreshAuthToken'](_0x409bac);}),_0x460009['appCheckProvider_']['addTokenChangeListener'](_0x543136=>{_0x460009['server_']['refreshAppCheckToken'](_0x543136['token']);}),_0x460009['statsReporter_']=eh(_0x460009['repoInfo_'],()=>new eu(_0x460009['stats_'],_0x460009['server_'])),_0x460009['infoData_']=new Yh(),_0x460009['infoSyncTree_']=new dr({'startListening':(_0x33771a,_0x4e4a7f,_0x5f042a,_0x468e30)=>{let _0x152b5a=[];const _0x208f6a=_0x460009['infoData_']['getNode'](_0x33771a['_path']);return _0x208f6a['isEmpty']()||(_0x152b5a=$t(_0x460009['infoSyncTree_'],_0x33771a['_path'],_0x208f6a),setTimeout(()=>{_0x468e30('ok');},0x0)),_0x152b5a;},'stopListening':()=>{}}),ms(_0x460009,'connected',!0x1),_0x460009['serverSyncTree_']=new dr({'startListening':(_0x2872ff,_0x156071,_0x3dd8ab,_0x20a3b0)=>(_0x460009['server_']['listen'](_0x2872ff,_0x3dd8ab,_0x156071,(_0x41e2a0,_0x32b263)=>{const _0x44ca4c=_0x20a3b0(_0x41e2a0,_0x32b263);V(_0x460009['eventQueue_'],_0x2872ff['_path'],_0x44ca4c);}),[]),'stopListening':(_0x58a2f7,_0x919cae)=>{_0x460009['server_']['unlisten'](_0x58a2f7,_0x919cae);}});}function oa(_0x137c48){const _0xb8dd93=_0x137c48['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xb8dd93;}function jt(_0x3153d9){return ed({'timestamp':oa(_0x3153d9)});}function pr(_0x55be54,_0x71faae,_0x2b105f,_0xc95c94,_0x4c01d4){_0x55be54['dataUpdateCount']++;const _0x5d26ea=new C(_0x71faae);_0x2b105f=_0x55be54['interceptServerDataCallback_']?_0x55be54['interceptServerDataCallback_'](_0x71faae,_0x2b105f):_0x2b105f;let _0x4103a0=[];if(_0x4c01d4){if(_0xc95c94){const _0x14f090=ln(_0x2b105f,_0x5eec74=>N(_0x5eec74));_0x4103a0=Ku(_0x55be54['serverSyncTree_'],_0x5d26ea,_0x14f090,_0x4c01d4);}else{const _0x8accd8=N(_0x2b105f);_0x4103a0=Yo(_0x55be54['serverSyncTree_'],_0x5d26ea,_0x8accd8,_0x4c01d4);}}else{if(_0xc95c94){const _0x35cb62=ln(_0x2b105f,_0x5647f0=>N(_0x5647f0));_0x4103a0=qu(_0x55be54['serverSyncTree_'],_0x5d26ea,_0x35cb62);}else{const _0x29025e=N(_0x2b105f);_0x4103a0=$t(_0x55be54['serverSyncTree_'],_0x5d26ea,_0x29025e);}}let _0x4e8bb3=_0x5d26ea;_0x4103a0['length']>0x0&&(_0x4e8bb3=st(_0x55be54,_0x5d26ea)),V(_0x55be54['eventQueue_'],_0x4e8bb3,_0x4103a0);}function _r(_0x1c5787,_0x27ded8){ms(_0x1c5787,'connected',_0x27ded8),_0x27ded8===!0x1&&wd(_0x1c5787);}function yd(_0x440550,_0x564014){x(_0x564014,(_0x105ddc,_0xc37817)=>{ms(_0x440550,_0x105ddc,_0xc37817);});}function ms(_0x50f223,_0x1e3454,_0x2141a9){const _0x4a753e=new C('/.info/'+_0x1e3454),_0x5721ec=N(_0x2141a9);_0x50f223['infoData_']['updateSnapshot'](_0x4a753e,_0x5721ec);const _0x45001b=$t(_0x50f223['infoSyncTree_'],_0x4a753e,_0x5721ec);V(_0x50f223['eventQueue_'],_0x4a753e,_0x45001b);}function Vn(_0x2322cf){return _0x2322cf['nextWriteId_']++;}function vd(_0x1c556d,_0x19d956,_0x2dd4fe){const _0x39ba43=Yu(_0x1c556d['serverSyncTree_'],_0x19d956);return _0x39ba43!=null?Promise['resolve'](_0x39ba43):_0x1c556d['server_']['get'](_0x19d956)['then'](_0xe201d8=>{const _0x36610f=N(_0xe201d8)['withIndex'](_0x19d956['_queryParams']['getIndex']());bi(_0x1c556d['serverSyncTree_'],_0x19d956,_0x2dd4fe,!0x0);let _0x293ed8;if(_0x19d956['_queryParams']['loadsAllData']())_0x293ed8=$t(_0x1c556d['serverSyncTree_'],_0x19d956['_path'],_0x36610f);else{const _0x327649=Mt(_0x1c556d['serverSyncTree_'],_0x19d956);_0x293ed8=Yo(_0x1c556d['serverSyncTree_'],_0x19d956['_path'],_0x36610f,_0x327649);}return V(_0x1c556d['eventQueue_'],_0x19d956['_path'],_0x293ed8),wn(_0x1c556d['serverSyncTree_'],_0x19d956,_0x2dd4fe,null,!0x0),_0x36610f;},_0x56a262=>(ut(_0x1c556d,'get\x20for\x20query\x20'+O(_0x19d956)+'\x20failed:\x20'+_0x56a262),Promise['reject'](new Error(_0x56a262))));}function Ed(_0x2d7ff8,_0xfa4f8f,_0x463afe,_0x469f40,_0x8c12d){ut(_0x2d7ff8,'set',{'path':_0xfa4f8f['toString'](),'value':_0x463afe,'priority':_0x469f40});const _0x189513=jt(_0x2d7ff8),_0x5e7a19=N(_0x463afe,_0x469f40),_0x20c123=xn(_0x2d7ff8['serverSyncTree_'],_0xfa4f8f),_0xf27116=hs(_0x5e7a19,_0x20c123,_0x189513),_0x2ad75d=Vn(_0x2d7ff8),_0x15a414=ss(_0x2d7ff8['serverSyncTree_'],_0xfa4f8f,_0xf27116,_0x2ad75d,!0x0);Bn(_0x2d7ff8['eventQueue_'],_0x15a414),_0x2d7ff8['server_']['put'](_0xfa4f8f['toString'](),_0x5e7a19['val'](!0x0),(_0x57ad58,_0x2a4b95)=>{const _0x3dd20b=_0x57ad58==='ok';_0x3dd20b||U('set\x20at\x20'+_0xfa4f8f+'\x20failed:\x20'+_0x57ad58);const _0x3cb841=pe(_0x2d7ff8['serverSyncTree_'],_0x2ad75d,!_0x3dd20b);V(_0x2d7ff8['eventQueue_'],_0xfa4f8f,_0x3cb841),Ai(_0x2d7ff8,_0x8c12d,_0x57ad58,_0x2a4b95);});const _0x4d0e3d=vs(_0x2d7ff8,_0xfa4f8f);st(_0x2d7ff8,_0x4d0e3d),V(_0x2d7ff8['eventQueue_'],_0x4d0e3d,[]);}function Id(_0x258953,_0x17ca6a,_0x246a58,_0x394741){ut(_0x258953,'update',{'path':_0x17ca6a['toString'](),'value':_0x246a58});let _0x10e212=!0x0;const _0x2f0b10=jt(_0x258953),_0x1f0328={};if(x(_0x246a58,(_0x3915c6,_0x402166)=>{_0x10e212=!0x1,_0x1f0328[_0x3915c6]=Zo(A(_0x17ca6a,_0x3915c6),N(_0x402166),_0x258953['serverSyncTree_'],_0x2f0b10);}),_0x10e212)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x258953,_0x394741,'ok',void 0x0);else{const _0x1c0f33=Vn(_0x258953),_0x233b8c=Gu(_0x258953['serverSyncTree_'],_0x17ca6a,_0x1f0328,_0x1c0f33);Bn(_0x258953['eventQueue_'],_0x233b8c),_0x258953['server_']['merge'](_0x17ca6a['toString'](),_0x246a58,(_0x3da301,_0x2ddc5d)=>{const _0x277fcf=_0x3da301==='ok';_0x277fcf||U('update\x20at\x20'+_0x17ca6a+'\x20failed:\x20'+_0x3da301);const _0x5ee1af=pe(_0x258953['serverSyncTree_'],_0x1c0f33,!_0x277fcf),_0x3a13a4=_0x5ee1af['length']>0x0?st(_0x258953,_0x17ca6a):_0x17ca6a;V(_0x258953['eventQueue_'],_0x3a13a4,_0x5ee1af),Ai(_0x258953,_0x394741,_0x3da301,_0x2ddc5d);}),x(_0x246a58,_0x2af9e2=>{const _0x5dfd76=vs(_0x258953,A(_0x17ca6a,_0x2af9e2));st(_0x258953,_0x5dfd76);}),V(_0x258953['eventQueue_'],_0x17ca6a,[]);}}function wd(_0x328b87){ut(_0x328b87,'onDisconnectEvents');const _0x477007=jt(_0x328b87),_0x41c05d=pn();Ei(_0x328b87['onDisconnect_'],w(),(_0x159e09,_0x3aec96)=>{const _0x2956e0=Zo(_0x159e09,_0x3aec96,_0x328b87['serverSyncTree_'],_0x477007);Mo(_0x41c05d,_0x159e09,_0x2956e0);});let _0x23dcba=[];Ei(_0x41c05d,w(),(_0x43ceab,_0x2480ab)=>{_0x23dcba=_0x23dcba['concat']($t(_0x328b87['serverSyncTree_'],_0x43ceab,_0x2480ab));const _0x9b74=vs(_0x328b87,_0x43ceab);st(_0x328b87,_0x9b74);}),_0x328b87['onDisconnect_']=pn(),V(_0x328b87['eventQueue_'],w(),_0x23dcba);}function Cd(_0x349ba5,_0x2b37bb,_0x39b7a8){let _0x246aa3;y(_0x2b37bb['_path'])==='.info'?_0x246aa3=bi(_0x349ba5['infoSyncTree_'],_0x2b37bb,_0x39b7a8):_0x246aa3=bi(_0x349ba5['serverSyncTree_'],_0x2b37bb,_0x39b7a8),ia(_0x349ba5['eventQueue_'],_0x2b37bb['_path'],_0x246aa3);}function Td(_0x351772,_0x2c4afb,_0x4b2021){let _0x13345e;y(_0x2c4afb['_path'])==='.info'?_0x13345e=wn(_0x351772['infoSyncTree_'],_0x2c4afb,_0x4b2021):_0x13345e=wn(_0x351772['serverSyncTree_'],_0x2c4afb,_0x4b2021),ia(_0x351772['eventQueue_'],_0x2c4afb['_path'],_0x13345e);}function aa(_0x1e03a5){_0x1e03a5['persistentConnection_']&&_0x1e03a5['persistentConnection_']['interrupt'](ra);}function Sd(_0x4ef128){_0x4ef128['persistentConnection_']&&_0x4ef128['persistentConnection_']['resume'](ra);}function ut(_0x12e083,..._0x6e889c){let _0x293209='';_0x12e083['persistentConnection_']&&(_0x293209=_0x12e083['persistentConnection_']['id']+':'),L(_0x293209,..._0x6e889c);}function Ai(_0x1cefc8,_0x138b19,_0x18e2bf,_0xb043e4){_0x138b19&&lt(()=>{if(_0x18e2bf==='ok')_0x138b19(null);else{const _0x39e72f=(_0x18e2bf||'error')['toUpperCase']();let _0x5df27a=_0x39e72f;_0xb043e4&&(_0x5df27a+=':\x20'+_0xb043e4);const _0x426050=new Error(_0x5df27a);_0x426050['code']=_0x39e72f,_0x138b19(_0x426050);}});}function bd(_0x3bfcfb,_0x4f7a1b,_0x5b69bf,_0x16eb7a,_0x4e6d55,_0x273907){ut(_0x3bfcfb,'transaction\x20on\x20'+_0x4f7a1b);const _0x154f4d={'path':_0x4f7a1b,'update':_0x5b69bf,'onComplete':_0x16eb7a,'status':null,'order':to(),'applyLocally':_0x273907,'retryCount':0x0,'unwatcher':_0x4e6d55,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x463080=ys(_0x3bfcfb,_0x4f7a1b,void 0x0);_0x154f4d['currentInputSnapshot']=_0x463080;const _0x3aa00e=_0x154f4d['update'](_0x463080['val']());if(_0x3aa00e===void 0x0)_0x154f4d['unwatcher'](),_0x154f4d['currentOutputSnapshotRaw']=null,_0x154f4d['currentOutputSnapshotResolved']=null,_0x154f4d['onComplete']&&_0x154f4d['onComplete'](null,!0x1,_0x154f4d['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3aa00e,_0x154f4d['path']),_0x154f4d['status']=0x0;const _0x249a9f=Un(_0x3bfcfb['transactionQueueTree_'],_0x4f7a1b),_0x5c24fd=Ge(_0x249a9f)||[];_0x5c24fd['push'](_0x154f4d),fs(_0x249a9f,_0x5c24fd);let _0x22f037;typeof _0x3aa00e=='object'&&_0x3aa00e!==null&&Y(_0x3aa00e,'.priority')?(_0x22f037=Oe(_0x3aa00e,'.priority'),f(Cn(_0x22f037),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x22f037=(xn(_0x3bfcfb['serverSyncTree_'],_0x4f7a1b)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x39b732=jt(_0x3bfcfb),_0x4284d7=N(_0x3aa00e,_0x22f037),_0x4f1e88=hs(_0x4284d7,_0x463080,_0x39b732);_0x154f4d['currentOutputSnapshotRaw']=_0x4284d7,_0x154f4d['currentOutputSnapshotResolved']=_0x4f1e88,_0x154f4d['currentWriteId']=Vn(_0x3bfcfb);const _0x1e7305=ss(_0x3bfcfb['serverSyncTree_'],_0x4f7a1b,_0x4f1e88,_0x154f4d['currentWriteId'],_0x154f4d['applyLocally']);V(_0x3bfcfb['eventQueue_'],_0x4f7a1b,_0x1e7305),Hn(_0x3bfcfb,_0x3bfcfb['transactionQueueTree_']);}}function ys(_0x54a403,_0x374d7d,_0x227bf2){return xn(_0x54a403['serverSyncTree_'],_0x374d7d,_0x227bf2)||g['EMPTY_NODE'];}function Hn(_0x194d98,_0x11ed05=_0x194d98['transactionQueueTree_']){if(_0x11ed05||$n(_0x194d98,_0x11ed05),Ge(_0x11ed05)){const _0x14263b=la(_0x194d98,_0x11ed05);f(_0x14263b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x14263b['every'](_0x445e34=>_0x445e34['status']===0x0)&&Rd(_0x194d98,Gt(_0x11ed05),_0x14263b);}else ea(_0x11ed05)&&Wn(_0x11ed05,_0x457b1e=>{Hn(_0x194d98,_0x457b1e);});}function Rd(_0x32576a,_0x14f5b1,_0x1ca537){const _0x3a06f3=_0x1ca537['map'](_0x5ecbee=>_0x5ecbee['currentWriteId']),_0x25b491=ys(_0x32576a,_0x14f5b1,_0x3a06f3);let _0x491ece=_0x25b491;const _0x1b4349=_0x25b491['hash']();for(let _0x18d375=0x0;_0x18d375<_0x1ca537['length'];_0x18d375++){const _0x10c26e=_0x1ca537[_0x18d375];f(_0x10c26e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x10c26e['status']=0x1,_0x10c26e['retryCount']++;const _0x54e080=F(_0x14f5b1,_0x10c26e['path']);_0x491ece=_0x491ece['updateChild'](_0x54e080,_0x10c26e['currentOutputSnapshotRaw']);}const _0x184c1a=_0x491ece['val'](!0x0),_0x3f9346=_0x14f5b1;_0x32576a['server_']['put'](_0x3f9346['toString'](),_0x184c1a,_0x28fd43=>{ut(_0x32576a,'transaction\x20put\x20response',{'path':_0x3f9346['toString'](),'status':_0x28fd43});let _0x5abe8f=[];if(_0x28fd43==='ok'){const _0x5ae15e=[];for(let _0x2a9bac=0x0;_0x2a9bac<_0x1ca537['length'];_0x2a9bac++)_0x1ca537[_0x2a9bac]['status']=0x2,_0x5abe8f=_0x5abe8f['concat'](pe(_0x32576a['serverSyncTree_'],_0x1ca537[_0x2a9bac]['currentWriteId'])),_0x1ca537[_0x2a9bac]['onComplete']&&_0x5ae15e['push'](()=>_0x1ca537[_0x2a9bac]['onComplete'](null,!0x0,_0x1ca537[_0x2a9bac]['currentOutputSnapshotResolved'])),_0x1ca537[_0x2a9bac]['unwatcher']();$n(_0x32576a,Un(_0x32576a['transactionQueueTree_'],_0x14f5b1)),Hn(_0x32576a,_0x32576a['transactionQueueTree_']),V(_0x32576a['eventQueue_'],_0x14f5b1,_0x5abe8f);for(let _0x4f5dfe=0x0;_0x4f5dfe<_0x5ae15e['length'];_0x4f5dfe++)lt(_0x5ae15e[_0x4f5dfe]);}else{if(_0x28fd43==='datastale'){for(let _0x54069b=0x0;_0x54069b<_0x1ca537['length'];_0x54069b++)_0x1ca537[_0x54069b]['status']===0x3?_0x1ca537[_0x54069b]['status']=0x4:_0x1ca537[_0x54069b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3f9346['toString']()+'\x20failed:\x20'+_0x28fd43);for(let _0x13d36b=0x0;_0x13d36b<_0x1ca537['length'];_0x13d36b++)_0x1ca537[_0x13d36b]['status']=0x4,_0x1ca537[_0x13d36b]['abortReason']=_0x28fd43;}st(_0x32576a,_0x14f5b1);}},_0x1b4349);}function st(_0x34fa83,_0x5ae984){const _0x1e7539=ca(_0x34fa83,_0x5ae984),_0xd49e1=Gt(_0x1e7539),_0x9524df=la(_0x34fa83,_0x1e7539);return Ad(_0x34fa83,_0x9524df,_0xd49e1),_0xd49e1;}function Ad(_0x44f92a,_0x145fbb,_0x4e0f24){if(_0x145fbb['length']===0x0)return;const _0x5befff=[];let _0x4e0bdb=[];const _0x22d3ad=_0x145fbb['filter'](_0x481f9d=>_0x481f9d['status']===0x0)['map'](_0x15c93c=>_0x15c93c['currentWriteId']);for(let _0x48c7b1=0x0;_0x48c7b1<_0x145fbb['length'];_0x48c7b1++){const _0x249ed0=_0x145fbb[_0x48c7b1],_0x25581b=F(_0x4e0f24,_0x249ed0['path']);let _0x562c9c=!0x1,_0x20d896;if(f(_0x25581b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x249ed0['status']===0x4)_0x562c9c=!0x0,_0x20d896=_0x249ed0['abortReason'],_0x4e0bdb=_0x4e0bdb['concat'](pe(_0x44f92a['serverSyncTree_'],_0x249ed0['currentWriteId'],!0x0));else{if(_0x249ed0['status']===0x0){if(_0x249ed0['retryCount']>=_d)_0x562c9c=!0x0,_0x20d896='maxretry',_0x4e0bdb=_0x4e0bdb['concat'](pe(_0x44f92a['serverSyncTree_'],_0x249ed0['currentWriteId'],!0x0));else{const _0x2ccaea=ys(_0x44f92a,_0x249ed0['path'],_0x22d3ad);_0x249ed0['currentInputSnapshot']=_0x2ccaea;const _0x14794c=_0x145fbb[_0x48c7b1]['update'](_0x2ccaea['val']());if(_0x14794c!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x14794c,_0x249ed0['path']);let _0xaf3750=N(_0x14794c);typeof _0x14794c=='object'&&_0x14794c!=null&&Y(_0x14794c,'.priority')||(_0xaf3750=_0xaf3750['updatePriority'](_0x2ccaea['getPriority']()));const _0x29411d=_0x249ed0['currentWriteId'],_0x3ee56d=jt(_0x44f92a),_0x33efac=hs(_0xaf3750,_0x2ccaea,_0x3ee56d);_0x249ed0['currentOutputSnapshotRaw']=_0xaf3750,_0x249ed0['currentOutputSnapshotResolved']=_0x33efac,_0x249ed0['currentWriteId']=Vn(_0x44f92a),_0x22d3ad['splice'](_0x22d3ad['indexOf'](_0x29411d),0x1),_0x4e0bdb=_0x4e0bdb['concat'](ss(_0x44f92a['serverSyncTree_'],_0x249ed0['path'],_0x33efac,_0x249ed0['currentWriteId'],_0x249ed0['applyLocally'])),_0x4e0bdb=_0x4e0bdb['concat'](pe(_0x44f92a['serverSyncTree_'],_0x29411d,!0x0));}else _0x562c9c=!0x0,_0x20d896='nodata',_0x4e0bdb=_0x4e0bdb['concat'](pe(_0x44f92a['serverSyncTree_'],_0x249ed0['currentWriteId'],!0x0));}}}V(_0x44f92a['eventQueue_'],_0x4e0f24,_0x4e0bdb),_0x4e0bdb=[],_0x562c9c&&(_0x145fbb[_0x48c7b1]['status']=0x2,function(_0x4c23df){setTimeout(_0x4c23df,Math['floor'](0x0));}(_0x145fbb[_0x48c7b1]['unwatcher']),_0x145fbb[_0x48c7b1]['onComplete']&&(_0x20d896==='nodata'?_0x5befff['push'](()=>_0x145fbb[_0x48c7b1]['onComplete'](null,!0x1,_0x145fbb[_0x48c7b1]['currentInputSnapshot'])):_0x5befff['push'](()=>_0x145fbb[_0x48c7b1]['onComplete'](new Error(_0x20d896),!0x1,null))));}$n(_0x44f92a,_0x44f92a['transactionQueueTree_']);for(let _0x292c6a=0x0;_0x292c6a<_0x5befff['length'];_0x292c6a++)lt(_0x5befff[_0x292c6a]);Hn(_0x44f92a,_0x44f92a['transactionQueueTree_']);}function ca(_0x4168ed,_0x429b2d){let _0x5250ff,_0x106138=_0x4168ed['transactionQueueTree_'];for(_0x5250ff=y(_0x429b2d);_0x5250ff!==null&&Ge(_0x106138)===void 0x0;)_0x106138=Un(_0x106138,_0x5250ff),_0x429b2d=b(_0x429b2d),_0x5250ff=y(_0x429b2d);return _0x106138;}function la(_0x401c0d,_0x495597){const _0x2eda87=[];return ha(_0x401c0d,_0x495597,_0x2eda87),_0x2eda87['sort']((_0x377cc4,_0x47cc16)=>_0x377cc4['order']-_0x47cc16['order']),_0x2eda87;}function ha(_0x14e967,_0x1cce2d,_0x11673e){const _0x581351=Ge(_0x1cce2d);if(_0x581351){for(let _0x1c0c3a=0x0;_0x1c0c3a<_0x581351['length'];_0x1c0c3a++)_0x11673e['push'](_0x581351[_0x1c0c3a]);}Wn(_0x1cce2d,_0x5c5369=>{ha(_0x14e967,_0x5c5369,_0x11673e);});}function $n(_0x471775,_0x52c764){const _0x293422=Ge(_0x52c764);if(_0x293422){let _0xc4f5a1=0x0;for(let _0x9e69d6=0x0;_0x9e69d6<_0x293422['length'];_0x9e69d6++)_0x293422[_0x9e69d6]['status']!==0x2&&(_0x293422[_0xc4f5a1]=_0x293422[_0x9e69d6],_0xc4f5a1++);_0x293422['length']=_0xc4f5a1,fs(_0x52c764,_0x293422['length']>0x0?_0x293422:void 0x0);}Wn(_0x52c764,_0x46390f=>{$n(_0x471775,_0x46390f);});}function vs(_0x56d507,_0x2183d1){const _0x2fcd43=Gt(ca(_0x56d507,_0x2183d1)),_0x56ffd9=Un(_0x56d507['transactionQueueTree_'],_0x2183d1);return sd(_0x56ffd9,_0x5a0d02=>{ai(_0x56d507,_0x5a0d02);}),ai(_0x56d507,_0x56ffd9),ta(_0x56ffd9,_0x287467=>{ai(_0x56d507,_0x287467);}),_0x2fcd43;}function ai(_0x5f5274,_0x4081b0){const _0x4b0c8c=Ge(_0x4081b0);if(_0x4b0c8c){const _0x4a3910=[];let _0x2cad9f=[],_0x5371bd=-0x1;for(let _0x4bcb75=0x0;_0x4bcb75<_0x4b0c8c['length'];_0x4bcb75++)_0x4b0c8c[_0x4bcb75]['status']===0x3||(_0x4b0c8c[_0x4bcb75]['status']===0x1?(f(_0x5371bd===_0x4bcb75-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5371bd=_0x4bcb75,_0x4b0c8c[_0x4bcb75]['status']=0x3,_0x4b0c8c[_0x4bcb75]['abortReason']='set'):(f(_0x4b0c8c[_0x4bcb75]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4b0c8c[_0x4bcb75]['unwatcher'](),_0x2cad9f=_0x2cad9f['concat'](pe(_0x5f5274['serverSyncTree_'],_0x4b0c8c[_0x4bcb75]['currentWriteId'],!0x0)),_0x4b0c8c[_0x4bcb75]['onComplete']&&_0x4a3910['push'](_0x4b0c8c[_0x4bcb75]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5371bd===-0x1?fs(_0x4081b0,void 0x0):_0x4b0c8c['length']=_0x5371bd+0x1,V(_0x5f5274['eventQueue_'],Gt(_0x4081b0),_0x2cad9f);for(let _0xcad90d=0x0;_0xcad90d<_0x4a3910['length'];_0xcad90d++)lt(_0x4a3910[_0xcad90d]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x1ad625){let _0x1a2929='';const _0xcf3ba9=_0x1ad625['split']('/');for(let _0x2d6154=0x0;_0x2d6154<_0xcf3ba9['length'];_0x2d6154++)if(_0xcf3ba9[_0x2d6154]['length']>0x0){let _0x5c1b69=_0xcf3ba9[_0x2d6154];try{_0x5c1b69=decodeURIComponent(_0x5c1b69['replace'](/\+/g,'\x20'));}catch{}_0x1a2929+='/'+_0x5c1b69;}return _0x1a2929;}function Nd(_0x5e00f2){const _0x1eab6f={};_0x5e00f2['charAt'](0x0)==='?'&&(_0x5e00f2=_0x5e00f2['substring'](0x1));for(const _0x22cd96 of _0x5e00f2['split']('&')){if(_0x22cd96['length']===0x0)continue;const _0x42ab4c=_0x22cd96['split']('=');_0x42ab4c['length']===0x2?_0x1eab6f[decodeURIComponent(_0x42ab4c[0x0])]=decodeURIComponent(_0x42ab4c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x22cd96+'\x27\x20in\x20query\x20\x27'+_0x5e00f2+'\x27');}return _0x1eab6f;}const gr=function(_0x56bc6e,_0x143d1a){const _0x3f79b0=Pd(_0x56bc6e),_0x2eb1d6=_0x3f79b0['namespace'];_0x3f79b0['domain']==='firebase.com'&&oe(_0x3f79b0['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2eb1d6||_0x2eb1d6==='undefined')&&_0x3f79b0['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3f79b0['secure']||Bl();const _0x4cd397=_0x3f79b0['scheme']==='ws'||_0x3f79b0['scheme']==='wss';return{'repoInfo':new _o(_0x3f79b0['host'],_0x3f79b0['secure'],_0x2eb1d6,_0x4cd397,_0x143d1a,'',_0x2eb1d6!==_0x3f79b0['subdomain']),'path':new C(_0x3f79b0['pathString'])};},Pd=function(_0x33ba03){let _0x355c82='',_0x404cf4='',_0x5997fe='',_0x2702df='',_0x4c8214='',_0x741c7=!0x0,_0x3c1eec='https',_0x1bdb6f=0x1bb;if(typeof _0x33ba03=='string'){let _0x1041ef=_0x33ba03['indexOf']('//');_0x1041ef>=0x0&&(_0x3c1eec=_0x33ba03['substring'](0x0,_0x1041ef-0x1),_0x33ba03=_0x33ba03['substring'](_0x1041ef+0x2));let _0x5d7df9=_0x33ba03['indexOf']('/');_0x5d7df9===-0x1&&(_0x5d7df9=_0x33ba03['length']);let _0x18c90d=_0x33ba03['indexOf']('?');_0x18c90d===-0x1&&(_0x18c90d=_0x33ba03['length']),_0x355c82=_0x33ba03['substring'](0x0,Math['min'](_0x5d7df9,_0x18c90d)),_0x5d7df9<_0x18c90d&&(_0x2702df=kd(_0x33ba03['substring'](_0x5d7df9,_0x18c90d)));const _0x1e90ec=Nd(_0x33ba03['substring'](Math['min'](_0x33ba03['length'],_0x18c90d)));_0x1041ef=_0x355c82['indexOf'](':'),_0x1041ef>=0x0?(_0x741c7=_0x3c1eec==='https'||_0x3c1eec==='wss',_0x1bdb6f=parseInt(_0x355c82['substring'](_0x1041ef+0x1),0xa)):_0x1041ef=_0x355c82['length'];const _0x44c591=_0x355c82['slice'](0x0,_0x1041ef);if(_0x44c591['toLowerCase']()==='localhost')_0x404cf4='localhost';else{if(_0x44c591['split']('.')['length']<=0x2)_0x404cf4=_0x44c591;else{const _0x3c5186=_0x355c82['indexOf']('.');_0x5997fe=_0x355c82['substring'](0x0,_0x3c5186)['toLowerCase'](),_0x404cf4=_0x355c82['substring'](_0x3c5186+0x1),_0x4c8214=_0x5997fe;}}'ns'in _0x1e90ec&&(_0x4c8214=_0x1e90ec['ns']);}return{'host':_0x355c82,'port':_0x1bdb6f,'domain':_0x404cf4,'subdomain':_0x5997fe,'secure':_0x741c7,'scheme':_0x3c1eec,'pathString':_0x2702df,'namespace':_0x4c8214};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x9a309b=0x0;const _0x36f36b=[];return function(_0x5c0d43){const _0x5d8872=_0x5c0d43===_0x9a309b;_0x9a309b=_0x5c0d43;let _0x52ddc0;const _0x211e7e=new Array(0x8);for(_0x52ddc0=0x7;_0x52ddc0>=0x0;_0x52ddc0--)_0x211e7e[_0x52ddc0]=mr['charAt'](_0x5c0d43%0x40),_0x5c0d43=Math['floor'](_0x5c0d43/0x40);f(_0x5c0d43===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x502eed=_0x211e7e['join']('');if(_0x5d8872){for(_0x52ddc0=0xb;_0x52ddc0>=0x0&&_0x36f36b[_0x52ddc0]===0x3f;_0x52ddc0--)_0x36f36b[_0x52ddc0]=0x0;_0x36f36b[_0x52ddc0]++;}else{for(_0x52ddc0=0x0;_0x52ddc0<0xc;_0x52ddc0++)_0x36f36b[_0x52ddc0]=Math['floor'](Math['random']()*0x40);}for(_0x52ddc0=0x0;_0x52ddc0<0xc;_0x52ddc0++)_0x502eed+=mr['charAt'](_0x36f36b[_0x52ddc0]);return f(_0x502eed['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x502eed;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x3b45f4,_0x409c9f,_0x5d9878,_0x27436d){this['eventType']=_0x3b45f4,this['eventRegistration']=_0x409c9f,this['snapshot']=_0x5d9878,this['prevName']=_0x27436d;}['getPath'](){const _0x306507=this['snapshot']['ref'];return this['eventType']==='value'?_0x306507['_path']:_0x306507['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x5b1896,_0x549076,_0x3bd592){this['eventRegistration']=_0x5b1896,this['error']=_0x549076,this['path']=_0x3bd592;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x17f7ed,_0x5779e6){this['snapshotCallback']=_0x17f7ed,this['cancelCallback']=_0x5779e6;}['onValue'](_0x39597f,_0x3330f2){this['snapshotCallback']['call'](null,_0x39597f,_0x3330f2);}['onCancel'](_0x2989ab){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2989ab);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1af861){return this['snapshotCallback']===_0x1af861['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1af861['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1af861['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xadcd75,_0x41510d,_0xf88367,_0x5de05f){this['_repo']=_0xadcd75,this['_path']=_0x41510d,this['_queryParams']=_0xf88367,this['_orderByCalled']=_0x5de05f;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5a6849=nr(this['_queryParams']),_0x210e63=Bi(_0x5a6849);return _0x210e63==='{}'?'default':_0x210e63;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4f1f37){if(_0x4f1f37=k(_0x4f1f37),!(_0x4f1f37 instanceof be))return!0x1;const _0x472e53=this['_repo']===_0x4f1f37['_repo'],_0x24a223=qi(this['_path'],_0x4f1f37['_path']),_0xdde5de=this['_queryIdentifier']===_0x4f1f37['_queryIdentifier'];return _0x472e53&&_0x24a223&&_0xdde5de;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x3e9e7e,_0x535039){if(_0x3e9e7e['_orderByCalled']===!0x0)throw new Error(_0x535039+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x1f3672){let _0x4a38ca=null,_0x2be059=null;if(_0x1f3672['hasStart']()&&(_0x4a38ca=_0x1f3672['getIndexStartValue']()),_0x1f3672['hasEnd']()&&(_0x2be059=_0x1f3672['getIndexEndValue']()),_0x1f3672['getIndex']()===ye){const _0x1d80a1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x10441e='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1f3672['hasStart']()){if(_0x1f3672['getIndexStartName']()!==xe)throw new Error(_0x1d80a1);if(typeof _0x4a38ca!='string')throw new Error(_0x10441e);}if(_0x1f3672['hasEnd']()){if(_0x1f3672['getIndexEndName']()!==Ie)throw new Error(_0x1d80a1);if(typeof _0x2be059!='string')throw new Error(_0x10441e);}}else{if(_0x1f3672['getIndex']()===R){if(_0x4a38ca!=null&&!Cn(_0x4a38ca)||_0x2be059!=null&&!Cn(_0x2be059))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1f3672['getIndex']()instanceof Ki||_0x1f3672['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4a38ca!=null&&typeof _0x4a38ca=='object'||_0x2be059!=null&&typeof _0x2be059=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x3434b3){if(_0x3434b3['hasStart']()&&_0x3434b3['hasEnd']()&&_0x3434b3['hasLimit']()&&!_0x3434b3['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x5e1a30,_0x516986){super(_0x5e1a30,_0x516986,new Qi(),!0x1);}get['parent'](){const _0x575015=To(this['_path']);return _0x575015===null?null:new Z(this['_repo'],_0x575015);}get['root'](){let _0x1673a5=this;for(;_0x1673a5['parent']!==null;)_0x1673a5=_0x1673a5['parent'];return _0x1673a5;}}class rt{constructor(_0x48e418,_0xdff8e4,_0x26d5c3){this['_node']=_0x48e418,this['ref']=_0xdff8e4,this['_index']=_0x26d5c3;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x14d351){const _0x30debf=new C(_0x14d351),_0x41e2fb=Lt(this['ref'],_0x14d351);return new rt(this['_node']['getChild'](_0x30debf),_0x41e2fb,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xfaaedb){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x7fedcb,_0x41ede6)=>_0xfaaedb(new rt(_0x41ede6,Lt(this['ref'],_0x7fedcb),R)));}['hasChild'](_0x323340){const _0x2f25bf=new C(_0x323340);return!this['_node']['getChild'](_0x2f25bf)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x316b7b,_0x43e61c){return _0x316b7b=k(_0x316b7b),_0x316b7b['_checkNotDeleted']('ref'),_0x43e61c!==void 0x0?Lt(_0x316b7b['_root'],_0x43e61c):_0x316b7b['_root'];}function Lt(_0x25baaa,_0x47e4ac){return _0x25baaa=k(_0x25baaa),y(_0x25baaa['_path'])===null?ud('child','path',_0x47e4ac):_s('child','path',_0x47e4ac),new Z(_0x25baaa['_repo'],A(_0x25baaa['_path'],_0x47e4ac));}function d_(_0xcbfccc,_0x2b2e07){_0xcbfccc=k(_0xcbfccc),gs('push',_0xcbfccc['_path']),qt('push',_0x2b2e07,_0xcbfccc['_path'],!0x0);const _0x1cd0a2=oa(_0xcbfccc['_repo']),_0x1a3981=Od(_0x1cd0a2),_0x3f8fec=Lt(_0xcbfccc,_0x1a3981),_0x47e6a5=Lt(_0xcbfccc,_0x1a3981);let _0xf7b4eb;return _0x2b2e07!=null?_0xf7b4eb=Ld(_0x47e6a5,_0x2b2e07)['then'](()=>_0x47e6a5):_0xf7b4eb=Promise['resolve'](_0x47e6a5),_0x3f8fec['then']=_0xf7b4eb['then']['bind'](_0xf7b4eb),_0x3f8fec['catch']=_0xf7b4eb['then']['bind'](_0xf7b4eb,void 0x0),_0x3f8fec;}function Ld(_0x27acf2,_0x5a8ccd){_0x27acf2=k(_0x27acf2),gs('set',_0x27acf2['_path']),qt('set',_0x5a8ccd,_0x27acf2['_path'],!0x1);const _0xfa3a6d=new Ve();return Ed(_0x27acf2['_repo'],_0x27acf2['_path'],_0x5a8ccd,null,_0xfa3a6d['wrapCallback'](()=>{})),_0xfa3a6d['promise'];}function f_(_0x223543,_0x35a78e){hd('update',_0x35a78e,_0x223543['_path']);const _0xcc7ccb=new Ve();return Id(_0x223543['_repo'],_0x223543['_path'],_0x35a78e,_0xcc7ccb['wrapCallback'](()=>{})),_0xcc7ccb['promise'];}function p_(_0x5b03b0){_0x5b03b0=k(_0x5b03b0);const _0x9b1388=new ua(()=>{}),_0x7156d4=new qn(_0x9b1388);return vd(_0x5b03b0['_repo'],_0x5b03b0,_0x7156d4)['then'](_0x583eba=>new rt(_0x583eba,new Z(_0x5b03b0['_repo'],_0x5b03b0['_path']),_0x5b03b0['_queryParams']['getIndex']()));}class qn{constructor(_0x5b9aaa){this['callbackContext']=_0x5b9aaa;}['respondsTo'](_0x583292){return _0x583292==='value';}['createEvent'](_0x5b0e53,_0x409ee5){const _0x49e661=_0x409ee5['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x5b0e53['snapshotNode'],new Z(_0x409ee5['_repo'],_0x409ee5['_path']),_0x49e661));}['getEventRunner'](_0x271822){return _0x271822['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x271822['error']):()=>this['callbackContext']['onValue'](_0x271822['snapshot'],null);}['createCancelEvent'](_0xf95caa,_0x3ba4d6){return this['callbackContext']['hasCancelCallback']?new Md(this,_0xf95caa,_0x3ba4d6):null;}['matches'](_0x5e47e1){return _0x5e47e1 instanceof qn?!_0x5e47e1['callbackContext']||!this['callbackContext']?!0x0:_0x5e47e1['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x254cf9,_0x3ef627,_0x2d66bd,_0x1c4479,_0x19eb0f){const _0x5b9514=new ua(_0x2d66bd,void 0x0),_0x5700d8=new qn(_0x5b9514);return Cd(_0x254cf9['_repo'],_0x254cf9,_0x5700d8),()=>Td(_0x254cf9['_repo'],_0x254cf9,_0x5700d8);}function Fd(_0xc9107a,_0x46b832,_0x132392,_0x8df22f){return xd(_0xc9107a,'value',_0x46b832);}class dt{}class pa extends dt{constructor(_0x329a74,_0x2e7211){super(),this['_value']=_0x329a74,this['_key']=_0x2e7211,this['type']='endAt';}['_apply'](_0x1cfefc){qt('endAt',this['_value'],_0x1cfefc['_path'],!0x0);const _0x2cc66c=Kh(_0x1cfefc['_queryParams'],this['_value'],this['_key']);if(fa(_0x2cc66c),Gn(_0x2cc66c),_0x1cfefc['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x1cfefc['_repo'],_0x1cfefc['_path'],_0x2cc66c,_0x1cfefc['_orderByCalled']);}}function __(_0x501bf3,_0xb1492b){return new pa(_0x501bf3,_0xb1492b);}class _a extends dt{constructor(_0x50f8aa,_0x226eac){super(),this['_value']=_0x50f8aa,this['_key']=_0x226eac,this['type']='startAt';}['_apply'](_0x946002){qt('startAt',this['_value'],_0x946002['_path'],!0x0);const _0x2e0ff=jh(_0x946002['_queryParams'],this['_value'],this['_key']);if(fa(_0x2e0ff),Gn(_0x2e0ff),_0x946002['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x946002['_repo'],_0x946002['_path'],_0x2e0ff,_0x946002['_orderByCalled']);}}function g_(_0x101ac7=null,_0x532a6f){return new _a(_0x101ac7,_0x532a6f);}class Ud extends dt{constructor(_0x1cd266){super(),this['_limit']=_0x1cd266,this['type']='limitToFirst';}['_apply'](_0x481be2){if(_0x481be2['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x481be2['_repo'],_0x481be2['_path'],zh(_0x481be2['_queryParams'],this['_limit']),_0x481be2['_orderByCalled']);}}function m_(_0x102eae){if(Math['floor'](_0x102eae)!==_0x102eae||_0x102eae<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x102eae);}class Wd extends dt{constructor(_0x4782f2){super(),this['_path']=_0x4782f2,this['type']='orderByChild';}['_apply'](_0x262cd5){da(_0x262cd5,'orderByChild');const _0x458181=new C(this['_path']);if(v(_0x458181))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x276e65=new Ki(_0x458181),_0x5837fe=Do(_0x262cd5['_queryParams'],_0x276e65);return Gn(_0x5837fe),new be(_0x262cd5['_repo'],_0x262cd5['_path'],_0x5837fe,!0x0);}}function y_(_0x36cb7d){if(_0x36cb7d==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x36cb7d==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x36cb7d==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x36cb7d),new Wd(_0x36cb7d);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x6ad728){da(_0x6ad728,'orderByKey');const _0x3bdc01=Do(_0x6ad728['_queryParams'],ye);return Gn(_0x3bdc01),new be(_0x6ad728['_repo'],_0x6ad728['_path'],_0x3bdc01,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x360c9e,_0x40c445){super(),this['_value']=_0x360c9e,this['_key']=_0x40c445,this['type']='equalTo';}['_apply'](_0x2f2f31){if(qt('equalTo',this['_value'],_0x2f2f31['_path'],!0x1),_0x2f2f31['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2f2f31['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2f2f31));}}function E_(_0x4a9549,_0x1c1110){return new Vd(_0x4a9549,_0x1c1110);}function I_(_0x3a4db5,..._0xade931){let _0x5d39ac=k(_0x3a4db5);for(const _0x230414 of _0xade931)_0x5d39ac=_0x230414['_apply'](_0x5d39ac);return _0x5d39ac;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x47ac8f,_0x18b4ad,_0x52ef58,_0x128b44){const _0x5a0667=_0x18b4ad['lastIndexOf'](':'),_0x4d3627=_0x18b4ad['substring'](0x0,_0x5a0667),_0x11836e=Wt(_0x4d3627);_0x47ac8f['repoInfo_']=new _o(_0x18b4ad,_0x11836e,_0x47ac8f['repoInfo_']['namespace'],_0x47ac8f['repoInfo_']['webSocketOnly'],_0x47ac8f['repoInfo_']['nodeAdmin'],_0x47ac8f['repoInfo_']['persistenceKey'],_0x47ac8f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x52ef58),_0x128b44&&(_0x47ac8f['authTokenProvider_']=_0x128b44);}function qd(_0x39fc7a,_0x44cad5,_0x2bf980,_0x258426,_0x4dc1e5){let _0x2ea178=_0x258426||_0x39fc7a['options']['databaseURL'];_0x2ea178===void 0x0&&(_0x39fc7a['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x39fc7a['options']['projectId']),_0x2ea178=_0x39fc7a['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3a173c=gr(_0x2ea178,_0x4dc1e5),_0x2f11cc=_0x3a173c['repoInfo'],_0x3c4d15;typeof process<'u'&&Us&&(_0x3c4d15=Us[Hd]),_0x3c4d15?(_0x2ea178='http://'+_0x3c4d15+'?ns='+_0x2f11cc['namespace'],_0x3a173c=gr(_0x2ea178,_0x4dc1e5),_0x2f11cc=_0x3a173c['repoInfo']):_0x3a173c['repoInfo']['secure'];const _0x14987a=new Jl(_0x39fc7a['name'],_0x39fc7a['options'],_0x44cad5);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3a173c),v(_0x3a173c['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x424c65=jd(_0x2f11cc,_0x39fc7a,_0x14987a,new Ql(_0x39fc7a,_0x2bf980));return new Kd(_0x424c65,_0x39fc7a);}function zd(_0x1aa58f,_0xf16fd5){const _0x4c26b3=ki[_0xf16fd5];(!_0x4c26b3||_0x4c26b3[_0x1aa58f['key']]!==_0x1aa58f)&&oe('Database\x20'+_0xf16fd5+'('+_0x1aa58f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x1aa58f),delete _0x4c26b3[_0x1aa58f['key']];}function jd(_0x21cc4b,_0x174aeb,_0x4f7091,_0x353298){let _0x496c2c=ki[_0x174aeb['name']];_0x496c2c||(_0x496c2c={},ki[_0x174aeb['name']]=_0x496c2c);let _0x212a1d=_0x496c2c[_0x21cc4b['toURLString']()];return _0x212a1d&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x212a1d=new gd(_0x21cc4b,$d,_0x4f7091,_0x353298),_0x496c2c[_0x21cc4b['toURLString']()]=_0x212a1d,_0x212a1d;}class Kd{constructor(_0x4f1020,_0x3a1c5a){this['_repoInternal']=_0x4f1020,this['app']=_0x3a1c5a,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x19fa54){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x19fa54+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x317417=Qr(),_0x484329){const _0x2f27c7=Ui(_0x317417,'database')['getImmediate']({'identifier':_0x484329});if(!_0x2f27c7['_instanceStarted']){const _0x71f343=ac('database');_0x71f343&&Yd(_0x2f27c7,..._0x71f343);}return _0x2f27c7;}function Yd(_0x29d505,_0x1a6cd1,_0x4775be,_0x493046={}){_0x29d505=k(_0x29d505),_0x29d505['_checkNotDeleted']('useEmulator');const _0x787218=_0x1a6cd1+':'+_0x4775be,_0x40a965=_0x29d505['_repoInternal'];if(_0x29d505['_instanceStarted']){if(_0x787218===_0x29d505['_repoInternal']['repoInfo_']['host']&&De(_0x493046,_0x40a965['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x36e619;if(_0x40a965['repoInfo_']['nodeAdmin'])_0x493046['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x36e619=new tn(tn['OWNER']);else{if(_0x493046['mockUserToken']){const _0x2d9a7c=typeof _0x493046['mockUserToken']=='string'?_0x493046['mockUserToken']:cc(_0x493046['mockUserToken'],_0x29d505['app']['options']['projectId']);_0x36e619=new tn(_0x2d9a7c);}}Wt(_0x1a6cd1)&&jr(_0x1a6cd1),Gd(_0x40a965,_0x787218,_0x493046,_0x36e619);}function C_(_0x599ee8){_0x599ee8=k(_0x599ee8),_0x599ee8['_checkNotDeleted']('goOffline'),aa(_0x599ee8['_repo']);}function T_(_0x4ce7d8){_0x4ce7d8=k(_0x4ce7d8),_0x4ce7d8['_checkNotDeleted']('goOnline'),Sd(_0x4ce7d8['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x124c79){Ll(ct),et(new Me('database',(_0xbaec26,{instanceIdentifier:_0x54c7fd})=>{const _0x482f9b=_0xbaec26['getProvider']('app')['getImmediate'](),_0x43ec48=_0xbaec26['getProvider']('auth-internal'),_0x40f323=_0xbaec26['getProvider']('app-check-internal');return qd(_0x482f9b,_0x43ec48,_0x40f323,_0x54c7fd);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x124c79),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xe603d3,_0x1a7f53){this['committed']=_0xe603d3,this['snapshot']=_0x1a7f53;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x95700c,_0x4aa81a,_0x604554){if(_0x95700c=k(_0x95700c),gs('Reference.transaction',_0x95700c['_path']),_0x95700c['key']==='.length'||_0x95700c['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x95700c['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1eb3da=!0x0,_0x31b6de=new Ve(),_0x554f2d=(_0x160b7f,_0x43bf05,_0x5c5e46)=>{let _0x55dd7a=null;_0x160b7f?_0x31b6de['reject'](_0x160b7f):(_0x55dd7a=new rt(_0x5c5e46,new Z(_0x95700c['_repo'],_0x95700c['_path']),R),_0x31b6de['resolve'](new Xd(_0x43bf05,_0x55dd7a)));},_0x9d5d9b=Fd(_0x95700c,()=>{});return bd(_0x95700c['_repo'],_0x95700c['_path'],_0x4aa81a,_0x554f2d,_0x9d5d9b,_0x1eb3da),_0x31b6de['promise'];}ie['prototype']['simpleListen']=function(_0x498bef,_0x4e9b00){this['sendRequest']('q',{'p':_0x498bef},_0x4e9b00);},ie['prototype']['echo']=function(_0x5b55da,_0x5e5708){this['sendRequest']('echo',{'d':_0x5b55da},_0x5e5708);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x11ae58,..._0x1ac28c){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x11ae58,..._0x1ac28c);}function nn(_0x2fe995,..._0x16ed16){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2fe995,..._0x16ed16);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x1709d5,..._0x43760e){throw Es(_0x1709d5,..._0x43760e);}function J(_0x507392,..._0x5dec1e){return Es(_0x507392,..._0x5dec1e);}function ya(_0x332a73,_0xec675e,_0x98d988){const _0x371da7={...Zd(),[_0xec675e]:_0x98d988};return new Ut('auth','Firebase',_0x371da7)['create'](_0xec675e,{'appName':_0x332a73['name']});}function se(_0x523d4e){return ya(_0x523d4e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x3a075f,..._0x44b450){if(typeof _0x3a075f!='string'){const _0x2e8c23=_0x44b450[0x0],_0xc0e849=[..._0x44b450['slice'](0x1)];return _0xc0e849[0x0]&&(_0xc0e849[0x0]['appName']=_0x3a075f['name']),_0x3a075f['_errorFactory']['create'](_0x2e8c23,..._0xc0e849);}return ma['create'](_0x3a075f,..._0x44b450);}function m(_0x431ec0,_0x489b0a,..._0x2df78c){if(!_0x431ec0)throw Es(_0x489b0a,..._0x2df78c);}function te(_0x1bb8df){const _0x498a27='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1bb8df;throw nn(_0x498a27),new Error(_0x498a27);}function ae(_0x26e132,_0x59222f){_0x26e132||te(_0x59222f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0xd5feb6;return typeof self<'u'&&((_0xd5feb6=self['location'])==null?void 0x0:_0xd5feb6['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5d2a6d;return typeof self<'u'&&((_0x5d2a6d=self['location'])==null?void 0x0:_0x5d2a6d['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x5a54fd=navigator;return _0x5a54fd['languages']&&_0x5a54fd['languages'][0x0]||_0x5a54fd['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3d36d9,_0x4408eb){this['shortDelay']=_0x3d36d9,this['longDelay']=_0x4408eb,ae(_0x4408eb>_0x3d36d9,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x494962,_0x357ca3){ae(_0x494962['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x498bed}=_0x494962['emulator'];return _0x357ca3?''+_0x498bed+(_0x357ca3['startsWith']('/')?_0x357ca3['slice'](0x1):_0x357ca3):_0x498bed;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x3ad9df,_0x32bb5c,_0x850c66){this['fetchImpl']=_0x3ad9df,_0x32bb5c&&(this['headersImpl']=_0x32bb5c),_0x850c66&&(this['responseImpl']=_0x850c66);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x132e72,_0x3cd133){return _0x132e72['tenantId']&&!_0x3cd133['tenantId']?{..._0x3cd133,'tenantId':_0x132e72['tenantId']}:_0x3cd133;}async function Ae(_0x453552,_0x2f0731,_0x4b68f4,_0x147df7,_0x1ccee5={}){return Ea(_0x453552,_0x1ccee5,async()=>{let _0x384617={},_0x403a1b={};_0x147df7&&(_0x2f0731==='GET'?_0x403a1b=_0x147df7:_0x384617={'body':JSON['stringify'](_0x147df7)});const _0x331980=at({..._0x403a1b,'key':_0x453552['config']['apiKey']})['slice'](0x1),_0x1d239d=await _0x453552['_getAdditionalHeaders']();_0x1d239d['Content-Type']='application/json',_0x453552['languageCode']&&(_0x1d239d['X-Firebase-Locale']=_0x453552['languageCode']);const _0x3a5df6={'method':_0x2f0731,'headers':_0x1d239d,..._0x384617};return lc()||(_0x3a5df6['referrerPolicy']='strict-origin-when-cross-origin'),_0x453552['emulatorConfig']&&Wt(_0x453552['emulatorConfig']['host'])&&(_0x3a5df6['credentials']='include'),va['fetch']()(await Ia(_0x453552,_0x453552['config']['apiHost'],_0x4b68f4,_0x331980),_0x3a5df6);});}async function Ea(_0x293219,_0x39391d,_0x19263b){_0x293219['_canInitEmulator']=!0x1;const _0x1fedc9={...rf,..._0x39391d};try{const _0x57c20c=new lf(_0x293219),_0x6a2f72=await Promise['race']([_0x19263b(),_0x57c20c['promise']]);_0x57c20c['clearNetworkTimeout']();const _0x34f91c=await _0x6a2f72['json']();if('needConfirmation'in _0x34f91c)throw en(_0x293219,'account-exists-with-different-credential',_0x34f91c);if(_0x6a2f72['ok']&&!('errorMessage'in _0x34f91c))return _0x34f91c;{const _0xf4f419=_0x6a2f72['ok']?_0x34f91c['errorMessage']:_0x34f91c['error']['message'],[_0xda888b,_0x9ef942]=_0xf4f419['split']('\x20:\x20');if(_0xda888b==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x293219,'credential-already-in-use',_0x34f91c);if(_0xda888b==='EMAIL_EXISTS')throw en(_0x293219,'email-already-in-use',_0x34f91c);if(_0xda888b==='USER_DISABLED')throw en(_0x293219,'user-disabled',_0x34f91c);const _0x59ea0d=_0x1fedc9[_0xda888b]||_0xda888b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x9ef942)throw ya(_0x293219,_0x59ea0d,_0x9ef942);K(_0x293219,_0x59ea0d);}}catch(_0x2ab909){if(_0x2ab909 instanceof Se)throw _0x2ab909;K(_0x293219,'network-request-failed',{'message':String(_0x2ab909)});}}async function Yt(_0x2ce417,_0x46039c,_0x262cd3,_0x27591c,_0x5be89d={}){const _0x50dfa4=await Ae(_0x2ce417,_0x46039c,_0x262cd3,_0x27591c,_0x5be89d);return'mfaPendingCredential'in _0x50dfa4&&K(_0x2ce417,'multi-factor-auth-required',{'_serverResponse':_0x50dfa4}),_0x50dfa4;}async function Ia(_0x558c10,_0x59143c,_0x3e7c38,_0x4b4a87){const _0x11f9c7=''+_0x59143c+_0x3e7c38+'?'+_0x4b4a87,_0x2b8c1c=_0x558c10,_0x3c5685=_0x2b8c1c['config']['emulator']?Is(_0x558c10['config'],_0x11f9c7):_0x558c10['config']['apiScheme']+'://'+_0x11f9c7;return of['includes'](_0x3e7c38)&&(await _0x2b8c1c['_persistenceManagerAvailable'],_0x2b8c1c['_getPersistenceType']()==='COOKIE')?_0x2b8c1c['_getPersistence']()['_getFinalTarget'](_0x3c5685)['toString']():_0x3c5685;}function cf(_0x43c99b){switch(_0x43c99b){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x29d467){this['auth']=_0x29d467,this['timer']=null,this['promise']=new Promise((_0x31d520,_0x2e4824)=>{this['timer']=setTimeout(()=>_0x2e4824(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x5879cc,_0x56189c,_0x534670){const _0x22623e={'appName':_0x5879cc['name']};_0x534670['email']&&(_0x22623e['email']=_0x534670['email']),_0x534670['phoneNumber']&&(_0x22623e['phoneNumber']=_0x534670['phoneNumber']);const _0x264cd1=J(_0x5879cc,_0x56189c,_0x22623e);return _0x264cd1['customData']['_tokenResponse']=_0x534670,_0x264cd1;}function vr(_0x84ca9e){return _0x84ca9e!==void 0x0&&_0x84ca9e['enterprise']!==void 0x0;}class hf{constructor(_0x2df96b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2df96b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2df96b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2df96b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x41168c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1aa3bc of this['recaptchaEnforcementState'])if(_0x1aa3bc['provider']&&_0x1aa3bc['provider']===_0x41168c)return cf(_0x1aa3bc['enforcementState']);return null;}['isProviderEnabled'](_0x424b13){return this['getProviderEnforcementState'](_0x424b13)==='ENFORCE'||this['getProviderEnforcementState'](_0x424b13)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0xa08853,_0x59ca0a){return Ae(_0xa08853,'GET','/v2/recaptchaConfig',Re(_0xa08853,_0x59ca0a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x92e936,_0x316a30){return Ae(_0x92e936,'POST','/v1/accounts:delete',_0x316a30);}async function Sn(_0x839f72,_0x564441){return Ae(_0x839f72,'POST','/v1/accounts:lookup',_0x564441);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x448cc2){if(_0x448cc2)try{const _0x5d79d1=new Date(Number(_0x448cc2));if(!isNaN(_0x5d79d1['getTime']()))return _0x5d79d1['toUTCString']();}catch{}}async function ff(_0x543974,_0x202d03=!0x1){const _0x72876d=k(_0x543974),_0x2a9749=await _0x72876d['getIdToken'](_0x202d03),_0x261a02=ws(_0x2a9749);m(_0x261a02&&_0x261a02['exp']&&_0x261a02['auth_time']&&_0x261a02['iat'],_0x72876d['auth'],'internal-error');const _0x152e1e=typeof _0x261a02['firebase']=='object'?_0x261a02['firebase']:void 0x0,_0x135ed1=_0x152e1e==null?void 0x0:_0x152e1e['sign_in_provider'];return{'claims':_0x261a02,'token':_0x2a9749,'authTime':St(ci(_0x261a02['auth_time'])),'issuedAtTime':St(ci(_0x261a02['iat'])),'expirationTime':St(ci(_0x261a02['exp'])),'signInProvider':_0x135ed1||null,'signInSecondFactor':(_0x152e1e==null?void 0x0:_0x152e1e['sign_in_second_factor'])||null};}function ci(_0x17c304){return Number(_0x17c304)*0x3e8;}function ws(_0x26df02){const [_0x4c8807,_0x5ef5cc,_0x2111fd]=_0x26df02['split']('.');if(_0x4c8807===void 0x0||_0x5ef5cc===void 0x0||_0x2111fd===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x58720a=cn(_0x5ef5cc);return _0x58720a?JSON['parse'](_0x58720a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5ec2bd){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5ec2bd==null?void 0x0:_0x5ec2bd['toString']()),null;}}function Er(_0x14687d){const _0x39343a=ws(_0x14687d);return m(_0x39343a,'internal-error'),m(typeof _0x39343a['exp']<'u','internal-error'),m(typeof _0x39343a['iat']<'u','internal-error'),Number(_0x39343a['exp'])-Number(_0x39343a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x21fb0e,_0x3bf817,_0x56f547=!0x1){if(_0x56f547)return _0x3bf817;try{return await _0x3bf817;}catch(_0x1733ab){throw _0x1733ab instanceof Se&&pf(_0x1733ab)&&_0x21fb0e['auth']['currentUser']===_0x21fb0e&&await _0x21fb0e['auth']['signOut'](),_0x1733ab;}}function pf({code:_0x3ef0ea}){return _0x3ef0ea==='auth/user-disabled'||_0x3ef0ea==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x262102){this['user']=_0x262102,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1592e1){if(_0x1592e1){const _0x3420c7=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3420c7;}else{this['errorBackoff']=0x7530;const _0x37a655=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x37a655);}}['schedule'](_0x5b0f52=!0x1){if(!this['isRunning'])return;const _0x110c0b=this['getInterval'](_0x5b0f52);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x110c0b);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x47874d){(_0x47874d==null?void 0x0:_0x47874d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x41fdf0,_0x2d811b){this['createdAt']=_0x41fdf0,this['lastLoginAt']=_0x2d811b,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x5d35d0){this['createdAt']=_0x5d35d0['createdAt'],this['lastLoginAt']=_0x5d35d0['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x3fc3a9){var _0x3f4635;const _0x29fb03=_0x3fc3a9['auth'],_0x3dd97d=await _0x3fc3a9['getIdToken'](),_0x18396b=await xt(_0x3fc3a9,Sn(_0x29fb03,{'idToken':_0x3dd97d}));m(_0x18396b==null?void 0x0:_0x18396b['users']['length'],_0x29fb03,'internal-error');const _0x35d5ba=_0x18396b['users'][0x0];_0x3fc3a9['_notifyReloadListener'](_0x35d5ba);const _0x464658=(_0x3f4635=_0x35d5ba['providerUserInfo'])!=null&&_0x3f4635['length']?wa(_0x35d5ba['providerUserInfo']):[],_0xdd2de6=mf(_0x3fc3a9['providerData'],_0x464658),_0x3b490b=_0x3fc3a9['isAnonymous'],_0x2760ed=!(_0x3fc3a9['email']&&_0x35d5ba['passwordHash'])&&!(_0xdd2de6!=null&&_0xdd2de6['length']),_0xc21f65=_0x3b490b?_0x2760ed:!0x1,_0x4a321e={'uid':_0x35d5ba['localId'],'displayName':_0x35d5ba['displayName']||null,'photoURL':_0x35d5ba['photoUrl']||null,'email':_0x35d5ba['email']||null,'emailVerified':_0x35d5ba['emailVerified']||!0x1,'phoneNumber':_0x35d5ba['phoneNumber']||null,'tenantId':_0x35d5ba['tenantId']||null,'providerData':_0xdd2de6,'metadata':new Pi(_0x35d5ba['createdAt'],_0x35d5ba['lastLoginAt']),'isAnonymous':_0xc21f65};Object['assign'](_0x3fc3a9,_0x4a321e);}async function gf(_0x3f4a8a){const _0x4cf096=k(_0x3f4a8a);await bn(_0x4cf096),await _0x4cf096['auth']['_persistUserIfCurrent'](_0x4cf096),_0x4cf096['auth']['_notifyListenersIfCurrent'](_0x4cf096);}function mf(_0x8267dd,_0x5ec2ad){return[..._0x8267dd['filter'](_0x13a774=>!_0x5ec2ad['some'](_0x573152=>_0x573152['providerId']===_0x13a774['providerId'])),..._0x5ec2ad];}function wa(_0x4f0b68){return _0x4f0b68['map'](({providerId:_0x254b78,..._0x517608})=>({'providerId':_0x254b78,'uid':_0x517608['rawId']||'','displayName':_0x517608['displayName']||null,'email':_0x517608['email']||null,'phoneNumber':_0x517608['phoneNumber']||null,'photoURL':_0x517608['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x4b4176,_0x4b9c6f){const _0x455d7d=await Ea(_0x4b4176,{},async()=>{const _0x340c99=at({'grant_type':'refresh_token','refresh_token':_0x4b9c6f})['slice'](0x1),{tokenApiHost:_0x21f202,apiKey:_0x5db476}=_0x4b4176['config'],_0x489140=await Ia(_0x4b4176,_0x21f202,'/v1/token','key='+_0x5db476),_0x4f6cf0=await _0x4b4176['_getAdditionalHeaders']();_0x4f6cf0['Content-Type']='application/x-www-form-urlencoded';const _0x18cbbb={'method':'POST','headers':_0x4f6cf0,'body':_0x340c99};return _0x4b4176['emulatorConfig']&&Wt(_0x4b4176['emulatorConfig']['host'])&&(_0x18cbbb['credentials']='include'),va['fetch']()(_0x489140,_0x18cbbb);});return{'accessToken':_0x455d7d['access_token'],'expiresIn':_0x455d7d['expires_in'],'refreshToken':_0x455d7d['refresh_token']};}async function vf(_0xfb6bee,_0x486abe){return Ae(_0xfb6bee,'POST','/v2/accounts:revokeToken',Re(_0xfb6bee,_0x486abe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4af4ff){m(_0x4af4ff['idToken'],'internal-error'),m(typeof _0x4af4ff['idToken']<'u','internal-error'),m(typeof _0x4af4ff['refreshToken']<'u','internal-error');const _0x29dc09='expiresIn'in _0x4af4ff&&typeof _0x4af4ff['expiresIn']<'u'?Number(_0x4af4ff['expiresIn']):Er(_0x4af4ff['idToken']);this['updateTokensAndExpiration'](_0x4af4ff['idToken'],_0x4af4ff['refreshToken'],_0x29dc09);}['updateFromIdToken'](_0x57e5a2){m(_0x57e5a2['length']!==0x0,'internal-error');const _0x582f57=Er(_0x57e5a2);this['updateTokensAndExpiration'](_0x57e5a2,null,_0x582f57);}async['getToken'](_0xb1e6ba,_0x14cb6c=!0x1){return!_0x14cb6c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xb1e6ba,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xb1e6ba,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x571624,_0x3c6231){const {accessToken:_0x429c03,refreshToken:_0x1d63c5,expiresIn:_0x8ad029}=await yf(_0x571624,_0x3c6231);this['updateTokensAndExpiration'](_0x429c03,_0x1d63c5,Number(_0x8ad029));}['updateTokensAndExpiration'](_0x2707dd,_0xe55bbe,_0x37194c){this['refreshToken']=_0xe55bbe||null,this['accessToken']=_0x2707dd||null,this['expirationTime']=Date['now']()+_0x37194c*0x3e8;}static['fromJSON'](_0x4a6f5d,_0x219b54){const {refreshToken:_0x465ed7,accessToken:_0x5c69d8,expirationTime:_0x1114b8}=_0x219b54,_0x3417eb=new Je();return _0x465ed7&&(m(typeof _0x465ed7=='string','internal-error',{'appName':_0x4a6f5d}),_0x3417eb['refreshToken']=_0x465ed7),_0x5c69d8&&(m(typeof _0x5c69d8=='string','internal-error',{'appName':_0x4a6f5d}),_0x3417eb['accessToken']=_0x5c69d8),_0x1114b8&&(m(typeof _0x1114b8=='number','internal-error',{'appName':_0x4a6f5d}),_0x3417eb['expirationTime']=_0x1114b8),_0x3417eb;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x487b16){this['accessToken']=_0x487b16['accessToken'],this['refreshToken']=_0x487b16['refreshToken'],this['expirationTime']=_0x487b16['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5d57c0,_0x311876){m(typeof _0x5d57c0=='string'||typeof _0x5d57c0>'u','internal-error',{'appName':_0x311876});}class z{constructor({uid:_0x51b143,auth:_0x432727,stsTokenManager:_0x1c4be8,..._0x58ad5c}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x51b143,this['auth']=_0x432727,this['stsTokenManager']=_0x1c4be8,this['accessToken']=_0x1c4be8['accessToken'],this['displayName']=_0x58ad5c['displayName']||null,this['email']=_0x58ad5c['email']||null,this['emailVerified']=_0x58ad5c['emailVerified']||!0x1,this['phoneNumber']=_0x58ad5c['phoneNumber']||null,this['photoURL']=_0x58ad5c['photoURL']||null,this['isAnonymous']=_0x58ad5c['isAnonymous']||!0x1,this['tenantId']=_0x58ad5c['tenantId']||null,this['providerData']=_0x58ad5c['providerData']?[..._0x58ad5c['providerData']]:[],this['metadata']=new Pi(_0x58ad5c['createdAt']||void 0x0,_0x58ad5c['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2651f9){const _0x360a69=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2651f9));return m(_0x360a69,this['auth'],'internal-error'),this['accessToken']!==_0x360a69&&(this['accessToken']=_0x360a69,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x360a69;}['getIdTokenResult'](_0xc60b08){return ff(this,_0xc60b08);}['reload'](){return gf(this);}['_assign'](_0x4880b7){this!==_0x4880b7&&(m(this['uid']===_0x4880b7['uid'],this['auth'],'internal-error'),this['displayName']=_0x4880b7['displayName'],this['photoURL']=_0x4880b7['photoURL'],this['email']=_0x4880b7['email'],this['emailVerified']=_0x4880b7['emailVerified'],this['phoneNumber']=_0x4880b7['phoneNumber'],this['isAnonymous']=_0x4880b7['isAnonymous'],this['tenantId']=_0x4880b7['tenantId'],this['providerData']=_0x4880b7['providerData']['map'](_0x1f31e8=>({..._0x1f31e8})),this['metadata']['_copy'](_0x4880b7['metadata']),this['stsTokenManager']['_assign'](_0x4880b7['stsTokenManager']));}['_clone'](_0x2aba03){const _0x561ceb=new z({...this,'auth':_0x2aba03,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x561ceb['metadata']['_copy'](this['metadata']),_0x561ceb;}['_onReload'](_0x400aa7){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x400aa7,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4fbd7e){this['reloadListener']?this['reloadListener'](_0x4fbd7e):this['reloadUserInfo']=_0x4fbd7e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3df900,_0x129df4=!0x1){let _0xe98625=!0x1;_0x3df900['idToken']&&_0x3df900['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3df900),_0xe98625=!0x0),_0x129df4&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0xe98625&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2a2ebb=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2a2ebb})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x12995f=>({..._0x12995f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4df073,_0x3059c3){const _0x58dd8f=_0x3059c3['displayName']??void 0x0,_0x44c90d=_0x3059c3['email']??void 0x0,_0x71600=_0x3059c3['phoneNumber']??void 0x0,_0x3fa2db=_0x3059c3['photoURL']??void 0x0,_0x17a4f5=_0x3059c3['tenantId']??void 0x0,_0x1211c3=_0x3059c3['_redirectEventId']??void 0x0,_0x5dcdde=_0x3059c3['createdAt']??void 0x0,_0xe3397d=_0x3059c3['lastLoginAt']??void 0x0,{uid:_0x3fe2e1,emailVerified:_0x4f2da8,isAnonymous:_0x32a1f7,providerData:_0x60330,stsTokenManager:_0x2d04f1}=_0x3059c3;m(_0x3fe2e1&&_0x2d04f1,_0x4df073,'internal-error');const _0x197a49=Je['fromJSON'](this['name'],_0x2d04f1);m(typeof _0x3fe2e1=='string',_0x4df073,'internal-error'),ce(_0x58dd8f,_0x4df073['name']),ce(_0x44c90d,_0x4df073['name']),m(typeof _0x4f2da8=='boolean',_0x4df073,'internal-error'),m(typeof _0x32a1f7=='boolean',_0x4df073,'internal-error'),ce(_0x71600,_0x4df073['name']),ce(_0x3fa2db,_0x4df073['name']),ce(_0x17a4f5,_0x4df073['name']),ce(_0x1211c3,_0x4df073['name']),ce(_0x5dcdde,_0x4df073['name']),ce(_0xe3397d,_0x4df073['name']);const _0x16f4bf=new z({'uid':_0x3fe2e1,'auth':_0x4df073,'email':_0x44c90d,'emailVerified':_0x4f2da8,'displayName':_0x58dd8f,'isAnonymous':_0x32a1f7,'photoURL':_0x3fa2db,'phoneNumber':_0x71600,'tenantId':_0x17a4f5,'stsTokenManager':_0x197a49,'createdAt':_0x5dcdde,'lastLoginAt':_0xe3397d});return _0x60330&&Array['isArray'](_0x60330)&&(_0x16f4bf['providerData']=_0x60330['map'](_0x37e4ba=>({..._0x37e4ba}))),_0x1211c3&&(_0x16f4bf['_redirectEventId']=_0x1211c3),_0x16f4bf;}static async['_fromIdTokenResponse'](_0x5ce684,_0x2d2741,_0x546277=!0x1){const _0x1cc5e1=new Je();_0x1cc5e1['updateFromServerResponse'](_0x2d2741);const _0x130c54=new z({'uid':_0x2d2741['localId'],'auth':_0x5ce684,'stsTokenManager':_0x1cc5e1,'isAnonymous':_0x546277});return await bn(_0x130c54),_0x130c54;}static async['_fromGetAccountInfoResponse'](_0x174010,_0x418ccd,_0x39bfa1){const _0xe66138=_0x418ccd['users'][0x0];m(_0xe66138['localId']!==void 0x0,'internal-error');const _0x460bec=_0xe66138['providerUserInfo']!==void 0x0?wa(_0xe66138['providerUserInfo']):[],_0x4dbb25=!(_0xe66138['email']&&_0xe66138['passwordHash'])&&!(_0x460bec!=null&&_0x460bec['length']),_0x1e470b=new Je();_0x1e470b['updateFromIdToken'](_0x39bfa1);const _0x96a653=new z({'uid':_0xe66138['localId'],'auth':_0x174010,'stsTokenManager':_0x1e470b,'isAnonymous':_0x4dbb25}),_0x422578={'uid':_0xe66138['localId'],'displayName':_0xe66138['displayName']||null,'photoURL':_0xe66138['photoUrl']||null,'email':_0xe66138['email']||null,'emailVerified':_0xe66138['emailVerified']||!0x1,'phoneNumber':_0xe66138['phoneNumber']||null,'tenantId':_0xe66138['tenantId']||null,'providerData':_0x460bec,'metadata':new Pi(_0xe66138['createdAt'],_0xe66138['lastLoginAt']),'isAnonymous':!(_0xe66138['email']&&_0xe66138['passwordHash'])&&!(_0x460bec!=null&&_0x460bec['length'])};return Object['assign'](_0x96a653,_0x422578),_0x96a653;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x53b41b){ae(_0x53b41b instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3a519f=Ir['get'](_0x53b41b);return _0x3a519f?(ae(_0x3a519f instanceof _0x53b41b,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3a519f):(_0x3a519f=new _0x53b41b(),Ir['set'](_0x53b41b,_0x3a519f),_0x3a519f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xbd54b5,_0x3e50d2){this['storage'][_0xbd54b5]=_0x3e50d2;}async['_get'](_0x49af96){const _0x56e676=this['storage'][_0x49af96];return _0x56e676===void 0x0?null:_0x56e676;}async['_remove'](_0x183cfe){delete this['storage'][_0x183cfe];}['_addListener'](_0x28051f,_0x3ad7fd){}['_removeListener'](_0xb45f07,_0x5082d1){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x51bcd0,_0x22b899,_0x389f61){return'firebase:'+_0x51bcd0+':'+_0x22b899+':'+_0x389f61;}class Xe{constructor(_0x1cd740,_0x5e1944,_0x22a6e3){this['persistence']=_0x1cd740,this['auth']=_0x5e1944,this['userKey']=_0x22a6e3;const {config:_0x3a2d44,name:_0x55c4b7}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3a2d44['apiKey'],_0x55c4b7),this['fullPersistenceKey']=sn('persistence',_0x3a2d44['apiKey'],_0x55c4b7),this['boundEventHandler']=_0x5e1944['_onStorageEvent']['bind'](_0x5e1944),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x54d028){return this['persistence']['_set'](this['fullUserKey'],_0x54d028['toJSON']());}async['getCurrentUser'](){const _0x3bba51=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3bba51)return null;if(typeof _0x3bba51=='string'){const _0x38a296=await Sn(this['auth'],{'idToken':_0x3bba51})['catch'](()=>{});return _0x38a296?z['_fromGetAccountInfoResponse'](this['auth'],_0x38a296,_0x3bba51):null;}return z['_fromJSON'](this['auth'],_0x3bba51);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x500a96){if(this['persistence']===_0x500a96)return;const _0x5cc9e8=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x500a96,_0x5cc9e8)return this['setCurrentUser'](_0x5cc9e8);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x31f263,_0x55687e,_0x11fd3b='authUser'){if(!_0x55687e['length'])return new Xe(ne(wr),_0x31f263,_0x11fd3b);const _0x584303=(await Promise['all'](_0x55687e['map'](async _0x4a43b8=>{if(await _0x4a43b8['_isAvailable']())return _0x4a43b8;})))['filter'](_0x1fe1eb=>_0x1fe1eb);let _0x3834e3=_0x584303[0x0]||ne(wr);const _0x5acd27=sn(_0x11fd3b,_0x31f263['config']['apiKey'],_0x31f263['name']);let _0x5a6c11=null;for(const _0x2ac3c6 of _0x55687e)try{const _0xce01fb=await _0x2ac3c6['_get'](_0x5acd27);if(_0xce01fb){let _0x5df943;if(typeof _0xce01fb=='string'){const _0x1d7c11=await Sn(_0x31f263,{'idToken':_0xce01fb})['catch'](()=>{});if(!_0x1d7c11)break;_0x5df943=await z['_fromGetAccountInfoResponse'](_0x31f263,_0x1d7c11,_0xce01fb);}else _0x5df943=z['_fromJSON'](_0x31f263,_0xce01fb);_0x2ac3c6!==_0x3834e3&&(_0x5a6c11=_0x5df943),_0x3834e3=_0x2ac3c6;break;}}catch{}const _0x16bee0=_0x584303['filter'](_0x4a1a96=>_0x4a1a96['_shouldAllowMigration']);return!_0x3834e3['_shouldAllowMigration']||!_0x16bee0['length']?new Xe(_0x3834e3,_0x31f263,_0x11fd3b):(_0x3834e3=_0x16bee0[0x0],_0x5a6c11&&await _0x3834e3['_set'](_0x5acd27,_0x5a6c11['toJSON']()),await Promise['all'](_0x55687e['map'](async _0x56ff82=>{if(_0x56ff82!==_0x3834e3)try{await _0x56ff82['_remove'](_0x5acd27);}catch{}})),new Xe(_0x3834e3,_0x31f263,_0x11fd3b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x1f6c34){const _0x28722f=_0x1f6c34['toLowerCase']();if(_0x28722f['includes']('opera/')||_0x28722f['includes']('opr/')||_0x28722f['includes']('opios/'))return'Opera';if(Ra(_0x28722f))return'IEMobile';if(_0x28722f['includes']('msie')||_0x28722f['includes']('trident/'))return'IE';if(_0x28722f['includes']('edge/'))return'Edge';if(Ta(_0x28722f))return'Firefox';if(_0x28722f['includes']('silk/'))return'Silk';if(ka(_0x28722f))return'Blackberry';if(Na(_0x28722f))return'Webos';if(Sa(_0x28722f))return'Safari';if((_0x28722f['includes']('chrome/')||ba(_0x28722f))&&!_0x28722f['includes']('edge/'))return'Chrome';if(Aa(_0x28722f))return'Android';{const _0x92d35d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xa2ef37=_0x1f6c34['match'](_0x92d35d);if((_0xa2ef37==null?void 0x0:_0xa2ef37['length'])===0x2)return _0xa2ef37[0x1];}return'Other';}function Ta(_0x3f61f4=W()){return/firefox\//i['test'](_0x3f61f4);}function Sa(_0x2e324f=W()){const _0x4f4d3e=_0x2e324f['toLowerCase']();return _0x4f4d3e['includes']('safari/')&&!_0x4f4d3e['includes']('chrome/')&&!_0x4f4d3e['includes']('crios/')&&!_0x4f4d3e['includes']('android');}function ba(_0x2b1bb5=W()){return/crios\//i['test'](_0x2b1bb5);}function Ra(_0x146c15=W()){return/iemobile/i['test'](_0x146c15);}function Aa(_0x365007=W()){return/android/i['test'](_0x365007);}function ka(_0x534207=W()){return/blackberry/i['test'](_0x534207);}function Na(_0x1b4fe5=W()){return/webos/i['test'](_0x1b4fe5);}function Cs(_0x38bac7=W()){return/iphone|ipad|ipod/i['test'](_0x38bac7)||/macintosh/i['test'](_0x38bac7)&&/mobile/i['test'](_0x38bac7);}function Ef(_0x3069d6=W()){var _0x3534b8;return Cs(_0x3069d6)&&!!((_0x3534b8=window['navigator'])!=null&&_0x3534b8['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4411ed=W()){return Cs(_0x4411ed)||Aa(_0x4411ed)||Na(_0x4411ed)||ka(_0x4411ed)||/windows phone/i['test'](_0x4411ed)||Ra(_0x4411ed);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x1be37d,_0x2d967e=[]){let _0x516e4b;switch(_0x1be37d){case'Browser':_0x516e4b=Cr(W());break;case'Worker':_0x516e4b=Cr(W())+'-'+_0x1be37d;break;default:_0x516e4b=_0x1be37d;}const _0x41278f=_0x2d967e['length']?_0x2d967e['join'](','):'FirebaseCore-web';return _0x516e4b+'/JsCore/'+ct+'/'+_0x41278f;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x477dc2){this['auth']=_0x477dc2,this['queue']=[];}['pushCallback'](_0x10b89a,_0x22736a){const _0x34f59b=_0x3e4fab=>new Promise((_0xb4baae,_0x3bcdd5)=>{try{const _0x2bc601=_0x10b89a(_0x3e4fab);_0xb4baae(_0x2bc601);}catch(_0x132063){_0x3bcdd5(_0x132063);}});_0x34f59b['onAbort']=_0x22736a,this['queue']['push'](_0x34f59b);const _0xd3001=this['queue']['length']-0x1;return()=>{this['queue'][_0xd3001]=()=>Promise['resolve']();};}async['runMiddleware'](_0x20a269){if(this['auth']['currentUser']===_0x20a269)return;const _0x20d000=[];try{for(const _0x2fecbf of this['queue'])await _0x2fecbf(_0x20a269),_0x2fecbf['onAbort']&&_0x20d000['push'](_0x2fecbf['onAbort']);}catch(_0x3440f4){_0x20d000['reverse']();for(const _0x4a244f of _0x20d000)try{_0x4a244f();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3440f4==null?void 0x0:_0x3440f4['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x30c147,_0x511de0={}){return Ae(_0x30c147,'GET','/v2/passwordPolicy',Re(_0x30c147,_0x511de0));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x32b7a3){var _0x18f4bc;const _0x3e820e=_0x32b7a3['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3e820e['minPasswordLength']??Tf,_0x3e820e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3e820e['maxPasswordLength']),_0x3e820e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3e820e['containsLowercaseCharacter']),_0x3e820e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3e820e['containsUppercaseCharacter']),_0x3e820e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3e820e['containsNumericCharacter']),_0x3e820e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3e820e['containsNonAlphanumericCharacter']),this['enforcementState']=_0x32b7a3['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x18f4bc=_0x32b7a3['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x18f4bc['join'](''))??'',this['forceUpgradeOnSignin']=_0x32b7a3['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x32b7a3['schemaVersion'];}['validatePassword'](_0x13c2e9){const _0x2067c1={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x13c2e9,_0x2067c1),this['validatePasswordCharacterOptions'](_0x13c2e9,_0x2067c1),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['meetsMinPasswordLength']??!0x0),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['meetsMaxPasswordLength']??!0x0),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['containsLowercaseLetter']??!0x0),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['containsUppercaseLetter']??!0x0),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['containsNumericCharacter']??!0x0),_0x2067c1['isValid']&&(_0x2067c1['isValid']=_0x2067c1['containsNonAlphanumericCharacter']??!0x0),_0x2067c1;}['validatePasswordLengthOptions'](_0x557a27,_0x33cb7b){const _0xf44fac=this['customStrengthOptions']['minPasswordLength'],_0x1564eb=this['customStrengthOptions']['maxPasswordLength'];_0xf44fac&&(_0x33cb7b['meetsMinPasswordLength']=_0x557a27['length']>=_0xf44fac),_0x1564eb&&(_0x33cb7b['meetsMaxPasswordLength']=_0x557a27['length']<=_0x1564eb);}['validatePasswordCharacterOptions'](_0x702368,_0x35d1a5){this['updatePasswordCharacterOptionsStatuses'](_0x35d1a5,!0x1,!0x1,!0x1,!0x1);let _0x1b10b4;for(let _0x4e2672=0x0;_0x4e2672<_0x702368['length'];_0x4e2672++)_0x1b10b4=_0x702368['charAt'](_0x4e2672),this['updatePasswordCharacterOptionsStatuses'](_0x35d1a5,_0x1b10b4>='a'&&_0x1b10b4<='z',_0x1b10b4>='A'&&_0x1b10b4<='Z',_0x1b10b4>='0'&&_0x1b10b4<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1b10b4));}['updatePasswordCharacterOptionsStatuses'](_0x2005cc,_0x19efed,_0x5c6423,_0x130151,_0x24a3ec){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2005cc['containsLowercaseLetter']||(_0x2005cc['containsLowercaseLetter']=_0x19efed)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2005cc['containsUppercaseLetter']||(_0x2005cc['containsUppercaseLetter']=_0x5c6423)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2005cc['containsNumericCharacter']||(_0x2005cc['containsNumericCharacter']=_0x130151)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2005cc['containsNonAlphanumericCharacter']||(_0x2005cc['containsNonAlphanumericCharacter']=_0x24a3ec));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x5aa239,_0x4c6a9f,_0x1d61b4,_0x2a6454){this['app']=_0x5aa239,this['heartbeatServiceProvider']=_0x4c6a9f,this['appCheckServiceProvider']=_0x1d61b4,this['config']=_0x2a6454,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5aa239['name'],this['clientVersion']=_0x2a6454['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5a79d1=>this['_resolvePersistenceManagerAvailable']=_0x5a79d1);}['_initializeWithPersistence'](_0x68b791,_0x1df8bf){return _0x1df8bf&&(this['_popupRedirectResolver']=ne(_0x1df8bf)),this['_initializationPromise']=this['queue'](async()=>{var _0x1aaece,_0x169f73,_0x5b9505;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x68b791),(_0x1aaece=this['_resolvePersistenceManagerAvailable'])==null||_0x1aaece['call'](this),!this['_deleted'])){if((_0x169f73=this['_popupRedirectResolver'])!=null&&_0x169f73['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1df8bf),this['lastNotifiedUid']=((_0x5b9505=this['currentUser'])==null?void 0x0:_0x5b9505['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4291cf=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4291cf)){if(this['currentUser']&&_0x4291cf&&this['currentUser']['uid']===_0x4291cf['uid']){this['_currentUser']['_assign'](_0x4291cf),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4291cf,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4d6c09){try{const _0x2ab513=await Sn(this,{'idToken':_0x4d6c09}),_0x11ce7b=await z['_fromGetAccountInfoResponse'](this,_0x2ab513,_0x4d6c09);await this['directlySetCurrentUser'](_0x11ce7b);}catch(_0x24e13c){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x24e13c),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3d9adc){var _0x12ce56;if(H(this['app'])){const _0x3935c4=this['app']['settings']['authIdToken'];return _0x3935c4?new Promise(_0x10b39d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3935c4)['then'](_0x10b39d,_0x10b39d));}):this['directlySetCurrentUser'](null);}const _0x1d69e5=await this['assertedPersistence']['getCurrentUser']();let _0x4553be=_0x1d69e5,_0xd8ed18=!0x1;if(_0x3d9adc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5734a1=(_0x12ce56=this['redirectUser'])==null?void 0x0:_0x12ce56['_redirectEventId'],_0xa3d424=_0x4553be==null?void 0x0:_0x4553be['_redirectEventId'],_0x53c674=await this['tryRedirectSignIn'](_0x3d9adc);(!_0x5734a1||_0x5734a1===_0xa3d424)&&(_0x53c674!=null&&_0x53c674['user'])&&(_0x4553be=_0x53c674['user'],_0xd8ed18=!0x0);}if(!_0x4553be)return this['directlySetCurrentUser'](null);if(!_0x4553be['_redirectEventId']){if(_0xd8ed18)try{await this['beforeStateQueue']['runMiddleware'](_0x4553be);}catch(_0x11097b){_0x4553be=_0x1d69e5,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x11097b));}return _0x4553be?this['reloadAndSetCurrentUserOrClear'](_0x4553be):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4553be['_redirectEventId']?this['directlySetCurrentUser'](_0x4553be):this['reloadAndSetCurrentUserOrClear'](_0x4553be);}async['tryRedirectSignIn'](_0x2e1a59){let _0x19cd0e=null;try{_0x19cd0e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2e1a59,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x19cd0e;}async['reloadAndSetCurrentUserOrClear'](_0x28a27d){try{await bn(_0x28a27d);}catch(_0x3b293b){if((_0x3b293b==null?void 0x0:_0x3b293b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x28a27d);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3d1294){if(H(this['app']))return Promise['reject'](se(this));const _0x16cbe3=_0x3d1294?k(_0x3d1294):null;return _0x16cbe3&&m(_0x16cbe3['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x16cbe3&&_0x16cbe3['_clone'](this));}async['_updateCurrentUser'](_0x27ceae,_0xa6b8fe=!0x1){if(!this['_deleted'])return _0x27ceae&&m(this['tenantId']===_0x27ceae['tenantId'],this,'tenant-id-mismatch'),_0xa6b8fe||await this['beforeStateQueue']['runMiddleware'](_0x27ceae),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x27ceae),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x27f989){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x27f989));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x542429){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5726c1=this['_getPasswordPolicyInternal']();return _0x5726c1['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5726c1['validatePassword'](_0x542429);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x343a1d=await Cf(this),_0xa0cd63=new Sf(_0x343a1d);this['tenantId']===null?this['_projectPasswordPolicy']=_0xa0cd63:this['_tenantPasswordPolicies'][this['tenantId']]=_0xa0cd63;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x569684){this['_errorFactory']=new Ut('auth','Firebase',_0x569684());}['onAuthStateChanged'](_0xa9219,_0x430e13,_0x40e90b){return this['registerStateListener'](this['authStateSubscription'],_0xa9219,_0x430e13,_0x40e90b);}['beforeAuthStateChanged'](_0x18fa33,_0x1cb77c){return this['beforeStateQueue']['pushCallback'](_0x18fa33,_0x1cb77c);}['onIdTokenChanged'](_0x58d0f0,_0xbdd772,_0x32b056){return this['registerStateListener'](this['idTokenSubscription'],_0x58d0f0,_0xbdd772,_0x32b056);}['authStateReady'](){return new Promise((_0x4eee45,_0x5da019)=>{if(this['currentUser'])_0x4eee45();else{const _0xf3e800=this['onAuthStateChanged'](()=>{_0xf3e800(),_0x4eee45();},_0x5da019);}});}async['revokeAccessToken'](_0x592d1a){if(this['currentUser']){const _0x504e31=await this['currentUser']['getIdToken'](),_0x47539f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x592d1a,'idToken':_0x504e31};this['tenantId']!=null&&(_0x47539f['tenantId']=this['tenantId']),await vf(this,_0x47539f);}}['toJSON'](){var _0x2b541c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2b541c=this['_currentUser'])==null?void 0x0:_0x2b541c['toJSON']()};}async['_setRedirectUser'](_0x3a584c,_0x353969){const _0x31eac8=await this['getOrInitRedirectPersistenceManager'](_0x353969);return _0x3a584c===null?_0x31eac8['removeCurrentUser']():_0x31eac8['setCurrentUser'](_0x3a584c);}async['getOrInitRedirectPersistenceManager'](_0x5d9d46){if(!this['redirectPersistenceManager']){const _0x5137d6=_0x5d9d46&&ne(_0x5d9d46)||this['_popupRedirectResolver'];m(_0x5137d6,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x5137d6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1eef8b){var _0xd55b72,_0x2b0ecd;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xd55b72=this['_currentUser'])==null?void 0x0:_0xd55b72['_redirectEventId'])===_0x1eef8b?this['_currentUser']:((_0x2b0ecd=this['redirectUser'])==null?void 0x0:_0x2b0ecd['_redirectEventId'])===_0x1eef8b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x119efd){if(_0x119efd===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x119efd));}['_notifyListenersIfCurrent'](_0x3f4d5c){_0x3f4d5c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x330bee;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xfbfeda=((_0x330bee=this['currentUser'])==null?void 0x0:_0x330bee['uid'])??null;this['lastNotifiedUid']!==_0xfbfeda&&(this['lastNotifiedUid']=_0xfbfeda,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1bc93b,_0x2bf202,_0x452622,_0x3c465b){if(this['_deleted'])return()=>{};const _0x544c7=typeof _0x2bf202=='function'?_0x2bf202:_0x2bf202['next']['bind'](_0x2bf202);let _0x5bbf9a=!0x1;const _0x19094a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x19094a,this,'internal-error'),_0x19094a['then'](()=>{_0x5bbf9a||_0x544c7(this['currentUser']);}),typeof _0x2bf202=='function'){const _0x50cbf6=_0x1bc93b['addObserver'](_0x2bf202,_0x452622,_0x3c465b);return()=>{_0x5bbf9a=!0x0,_0x50cbf6();};}else{const _0x11e6f6=_0x1bc93b['addObserver'](_0x2bf202);return()=>{_0x5bbf9a=!0x0,_0x11e6f6();};}}async['directlySetCurrentUser'](_0x17d4fa){this['currentUser']&&this['currentUser']!==_0x17d4fa&&this['_currentUser']['_stopProactiveRefresh'](),_0x17d4fa&&this['isProactiveRefreshEnabled']&&_0x17d4fa['_startProactiveRefresh'](),this['currentUser']=_0x17d4fa,_0x17d4fa?await this['assertedPersistence']['setCurrentUser'](_0x17d4fa):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x41324f){return this['operations']=this['operations']['then'](_0x41324f,_0x41324f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2a75aa){!_0x2a75aa||this['frameworks']['includes'](_0x2a75aa)||(this['frameworks']['push'](_0x2a75aa),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5bcd54;const _0x3b79be={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3b79be['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4de60a=await((_0x5bcd54=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5bcd54['getHeartbeatsHeader']());_0x4de60a&&(_0x3b79be['X-Firebase-Client']=_0x4de60a);const _0x3f3118=await this['_getAppCheckToken']();return _0x3f3118&&(_0x3b79be['X-Firebase-AppCheck']=_0x3f3118),_0x3b79be;}async['_getAppCheckToken'](){var _0x33d2a3;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5129e3=await((_0x33d2a3=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x33d2a3['getToken']());return _0x5129e3!=null&&_0x5129e3['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5129e3['error']),_0x5129e3==null?void 0x0:_0x5129e3['token'];}}function qe(_0x11bbeb){return k(_0x11bbeb);}class Tr{constructor(_0x5ee909){this['auth']=_0x5ee909,this['observer']=null,this['addObserver']=Ic(_0x2f022e=>this['observer']=_0x2f022e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x230d41){zn=_0x230d41;}function Da(_0x4e8072){return zn['loadJS'](_0x4e8072);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x10899f){return'__'+_0x10899f+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x19a110){_0x19a110();}['execute'](_0x598ec1,_0x5163d1){return Promise['resolve']('token');}['render'](_0x31db4e,_0xd75698){return'';}}class Of{['ready'](_0x3473e6){_0x3473e6();}['execute'](_0x482bf6,_0x1c7f43){return Promise['resolve']('token');}['render'](_0x459c6b,_0x50c2ba){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3f1187){this['type']=Df,this['auth']=qe(_0x3f1187);}async['verify'](_0x185db4='verify',_0x1cc69c=!0x1){async function _0x19d4ac(_0x31bc6f){if(!_0x1cc69c){if(_0x31bc6f['tenantId']==null&&_0x31bc6f['_agentRecaptchaConfig']!=null)return _0x31bc6f['_agentRecaptchaConfig']['siteKey'];if(_0x31bc6f['tenantId']!=null&&_0x31bc6f['_tenantRecaptchaConfigs'][_0x31bc6f['tenantId']]!==void 0x0)return _0x31bc6f['_tenantRecaptchaConfigs'][_0x31bc6f['tenantId']]['siteKey'];}return new Promise(async(_0x1b4743,_0x2944c2)=>{uf(_0x31bc6f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x348b09=>{if(_0x348b09['recaptchaKey']===void 0x0)_0x2944c2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x26ca3b=new hf(_0x348b09);return _0x31bc6f['tenantId']==null?_0x31bc6f['_agentRecaptchaConfig']=_0x26ca3b:_0x31bc6f['_tenantRecaptchaConfigs'][_0x31bc6f['tenantId']]=_0x26ca3b,_0x1b4743(_0x26ca3b['siteKey']);}})['catch'](_0x3c4b70=>{_0x2944c2(_0x3c4b70);});});}function _0x494890(_0x132d9e,_0x23bf1c,_0x329f82){const _0x1e3e81=window['grecaptcha'];vr(_0x1e3e81)?_0x1e3e81['enterprise']['ready'](()=>{_0x1e3e81['enterprise']['execute'](_0x132d9e,{'action':_0x185db4})['then'](_0x2f6dcd=>{_0x23bf1c(_0x2f6dcd);})['catch'](()=>{_0x23bf1c(Ma);});}):_0x329f82(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x480623,_0x359216)=>{_0x19d4ac(this['auth'])['then'](async _0x9802d6=>{if(!_0x1cc69c&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x494890(_0x9802d6,_0x480623,_0x359216);else{if(typeof window>'u'){_0x359216(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x13edb7=Af();_0x13edb7['length']!==0x0&&(_0x13edb7+=_0x9802d6+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x6817f3;(_0x6817f3=le['scriptInjectionDeferred'])==null||_0x6817f3['resolve']();},Da(_0x13edb7)['then'](()=>{var _0x25b43f;return(_0x25b43f=le['scriptInjectionDeferred'])==null?void 0x0:_0x25b43f['promise'];})['then'](()=>{_0x494890(_0x9802d6,_0x480623,_0x359216);})['catch'](_0x1c1436=>{_0x359216(_0x1c1436);});}})['catch'](_0x1a744f=>{_0x359216(_0x1a744f);});});}}le['scriptInjectionDeferred']=null;async function br(_0x38caac,_0x2f9b41,_0x4aaca0,_0x524d9b=!0x1,_0x53c9b1=!0x1){const _0x1277d2=new le(_0x38caac);let _0xd600f;if(_0x53c9b1)_0xd600f=Ma;else try{_0xd600f=await _0x1277d2['verify'](_0x4aaca0);}catch{_0xd600f=await _0x1277d2['verify'](_0x4aaca0,!0x0);}const _0x36f978={..._0x2f9b41};if(_0x4aaca0==='mfaSmsEnrollment'||_0x4aaca0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x36f978){const _0x2e0d4c=_0x36f978['phoneEnrollmentInfo']['phoneNumber'],_0x4b6ee4=_0x36f978['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x36f978,{'phoneEnrollmentInfo':{'phoneNumber':_0x2e0d4c,'recaptchaToken':_0x4b6ee4,'captchaResponse':_0xd600f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x36f978){const _0x30de6c=_0x36f978['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x36f978,{'phoneSignInInfo':{'recaptchaToken':_0x30de6c,'captchaResponse':_0xd600f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x36f978;}return _0x524d9b?Object['assign'](_0x36f978,{'captchaResp':_0xd600f}):Object['assign'](_0x36f978,{'captchaResponse':_0xd600f}),Object['assign'](_0x36f978,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x36f978,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x36f978;}async function Oi(_0x3b8edc,_0x462baa,_0x54e87e,_0x135cc2,_0x1e111e){var _0x24b491;if((_0x24b491=_0x3b8edc['_getRecaptchaConfig']())!=null&&_0x24b491['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x208e5f=await br(_0x3b8edc,_0x462baa,_0x54e87e,_0x54e87e==='getOobCode');return _0x135cc2(_0x3b8edc,_0x208e5f);}else return _0x135cc2(_0x3b8edc,_0x462baa)['catch'](async _0x143033=>{if(_0x143033['code']==='auth/missing-recaptcha-token'){console['log'](_0x54e87e+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x361119=await br(_0x3b8edc,_0x462baa,_0x54e87e,_0x54e87e==='getOobCode');return _0x135cc2(_0x3b8edc,_0x361119);}else return Promise['reject'](_0x143033);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5654e9,_0x1bded0){const _0x4961cc=Ui(_0x5654e9,'auth');if(_0x4961cc['isInitialized']()){const _0x506854=_0x4961cc['getImmediate'](),_0x320100=_0x4961cc['getOptions']();if(De(_0x320100,_0x1bded0??{}))return _0x506854;K(_0x506854,'already-initialized');}return _0x4961cc['initialize']({'options':_0x1bded0});}function Lf(_0x45c095,_0x590b43){const _0x56d606=(_0x590b43==null?void 0x0:_0x590b43['persistence'])||[],_0x43e595=(Array['isArray'](_0x56d606)?_0x56d606:[_0x56d606])['map'](ne);_0x590b43!=null&&_0x590b43['errorMap']&&_0x45c095['_updateErrorMap'](_0x590b43['errorMap']),_0x45c095['_initializeWithPersistence'](_0x43e595,_0x590b43==null?void 0x0:_0x590b43['popupRedirectResolver']);}function xf(_0x57b6d6,_0x22b68c,_0x4af566){const _0x34e1da=qe(_0x57b6d6);m(/^https?:\/\//['test'](_0x22b68c),_0x34e1da,'invalid-emulator-scheme');const _0xc0a9ec=!0x1,_0xcc339=La(_0x22b68c),{host:_0x3de5de,port:_0xd1702f}=Ff(_0x22b68c),_0x609a37=_0xd1702f===null?'':':'+_0xd1702f,_0x278827={'url':_0xcc339+'//'+_0x3de5de+_0x609a37+'/'},_0x4f5c35=Object['freeze']({'host':_0x3de5de,'port':_0xd1702f,'protocol':_0xcc339['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0xc0a9ec})});if(!_0x34e1da['_canInitEmulator']){m(_0x34e1da['config']['emulator']&&_0x34e1da['emulatorConfig'],_0x34e1da,'emulator-config-failed'),m(De(_0x278827,_0x34e1da['config']['emulator'])&&De(_0x4f5c35,_0x34e1da['emulatorConfig']),_0x34e1da,'emulator-config-failed');return;}_0x34e1da['config']['emulator']=_0x278827,_0x34e1da['emulatorConfig']=_0x4f5c35,_0x34e1da['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3de5de)?jr(_0xcc339+'//'+_0x3de5de+_0x609a37):Uf();}function La(_0x58ad08){const _0x27f66e=_0x58ad08['indexOf'](':');return _0x27f66e<0x0?'':_0x58ad08['substr'](0x0,_0x27f66e+0x1);}function Ff(_0x59da9f){const _0x233f20=La(_0x59da9f),_0x47043c=/(\/\/)?([^?#/]+)/['exec'](_0x59da9f['substr'](_0x233f20['length']));if(!_0x47043c)return{'host':'','port':null};const _0x353469=_0x47043c[0x2]['split']('@')['pop']()||'',_0x3f1145=/^(\[[^\]]+\])(:|$)/['exec'](_0x353469);if(_0x3f1145){const _0x3020d3=_0x3f1145[0x1];return{'host':_0x3020d3,'port':Rr(_0x353469['substr'](_0x3020d3['length']+0x1))};}else{const [_0x3443c4,_0x299a85]=_0x353469['split'](':');return{'host':_0x3443c4,'port':Rr(_0x299a85)};}}function Rr(_0x52c709){if(!_0x52c709)return null;const _0x353a08=Number(_0x52c709);return isNaN(_0x353a08)?null:_0x353a08;}function Uf(){function _0x2b46cb(){const _0x50dc8c=document['createElement']('p'),_0x20006f=_0x50dc8c['style'];_0x50dc8c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x20006f['position']='fixed',_0x20006f['width']='100%',_0x20006f['backgroundColor']='#ffffff',_0x20006f['border']='.1em\x20solid\x20#000000',_0x20006f['color']='#b50000',_0x20006f['bottom']='0px',_0x20006f['left']='0px',_0x20006f['margin']='0px',_0x20006f['zIndex']='10000',_0x20006f['textAlign']='center',_0x50dc8c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x50dc8c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2b46cb):_0x2b46cb());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x36ea4f,_0x281ef8){this['providerId']=_0x36ea4f,this['signInMethod']=_0x281ef8;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x52d717){return te('not\x20implemented');}['_linkToIdToken'](_0xf6699f,_0x112b9f){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xfa017a){return te('not\x20implemented');}}async function Wf(_0x19fea7,_0x457801){return Ae(_0x19fea7,'POST','/v1/accounts:signUp',_0x457801);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x10711d,_0x101d14){return Yt(_0x10711d,'POST','/v1/accounts:signInWithPassword',Re(_0x10711d,_0x101d14));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x702f79,_0xc8b810){return Yt(_0x702f79,'POST','/v1/accounts:signInWithEmailLink',Re(_0x702f79,_0xc8b810));}async function Hf(_0x251587,_0x5ef6d0){return Yt(_0x251587,'POST','/v1/accounts:signInWithEmailLink',Re(_0x251587,_0x5ef6d0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x13969d,_0x4151db,_0x5a6263,_0x1f93ac=null){super('password',_0x5a6263),this['_email']=_0x13969d,this['_password']=_0x4151db,this['_tenantId']=_0x1f93ac;}static['_fromEmailAndPassword'](_0x2be29a,_0x39923b){return new Ft(_0x2be29a,_0x39923b,'password');}static['_fromEmailAndCode'](_0x51e03e,_0x90c992,_0x379937=null){return new Ft(_0x51e03e,_0x90c992,'emailLink',_0x379937);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xf6ed0b){const _0x121569=typeof _0xf6ed0b=='string'?JSON['parse'](_0xf6ed0b):_0xf6ed0b;if(_0x121569!=null&&_0x121569['email']&&(_0x121569!=null&&_0x121569['password'])){if(_0x121569['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x121569['email'],_0x121569['password']);if(_0x121569['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x121569['email'],_0x121569['password'],_0x121569['tenantId']);}return null;}async['_getIdTokenResponse'](_0x565a0b){switch(this['signInMethod']){case'password':const _0x413799={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x565a0b,_0x413799,'signInWithPassword',Bf);case'emailLink':return Vf(_0x565a0b,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x565a0b,'internal-error');}}async['_linkToIdToken'](_0x129851,_0x3527a7){switch(this['signInMethod']){case'password':const _0x5b0685={'idToken':_0x3527a7,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x129851,_0x5b0685,'signUpPassword',Wf);case'emailLink':return Hf(_0x129851,{'idToken':_0x3527a7,'email':this['_email'],'oobCode':this['_password']});default:K(_0x129851,'internal-error');}}['_getReauthenticationResolver'](_0xcf1c9f){return this['_getIdTokenResponse'](_0xcf1c9f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3dd30e,_0x135ce8){return Yt(_0x3dd30e,'POST','/v1/accounts:signInWithIdp',Re(_0x3dd30e,_0x135ce8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3d3efe){const _0x46595d=new We(_0x3d3efe['providerId'],_0x3d3efe['signInMethod']);return _0x3d3efe['idToken']||_0x3d3efe['accessToken']?(_0x3d3efe['idToken']&&(_0x46595d['idToken']=_0x3d3efe['idToken']),_0x3d3efe['accessToken']&&(_0x46595d['accessToken']=_0x3d3efe['accessToken']),_0x3d3efe['nonce']&&!_0x3d3efe['pendingToken']&&(_0x46595d['nonce']=_0x3d3efe['nonce']),_0x3d3efe['pendingToken']&&(_0x46595d['pendingToken']=_0x3d3efe['pendingToken'])):_0x3d3efe['oauthToken']&&_0x3d3efe['oauthTokenSecret']?(_0x46595d['accessToken']=_0x3d3efe['oauthToken'],_0x46595d['secret']=_0x3d3efe['oauthTokenSecret']):K('argument-error'),_0x46595d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5c81b7){const _0xb1ba73=typeof _0x5c81b7=='string'?JSON['parse'](_0x5c81b7):_0x5c81b7,{providerId:_0x36fe70,signInMethod:_0x59f7f9,..._0x5a8351}=_0xb1ba73;if(!_0x36fe70||!_0x59f7f9)return null;const _0x40ce60=new We(_0x36fe70,_0x59f7f9);return _0x40ce60['idToken']=_0x5a8351['idToken']||void 0x0,_0x40ce60['accessToken']=_0x5a8351['accessToken']||void 0x0,_0x40ce60['secret']=_0x5a8351['secret'],_0x40ce60['nonce']=_0x5a8351['nonce'],_0x40ce60['pendingToken']=_0x5a8351['pendingToken']||null,_0x40ce60;}['_getIdTokenResponse'](_0xf2022e){const _0x12450a=this['buildRequest']();return Ze(_0xf2022e,_0x12450a);}['_linkToIdToken'](_0x505626,_0x638b59){const _0x47128b=this['buildRequest']();return _0x47128b['idToken']=_0x638b59,Ze(_0x505626,_0x47128b);}['_getReauthenticationResolver'](_0x217ad2){const _0x57e24d=this['buildRequest']();return _0x57e24d['autoCreate']=!0x1,Ze(_0x217ad2,_0x57e24d);}['buildRequest'](){const _0x394f92={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x394f92['pendingToken']=this['pendingToken'];else{const _0x51a7ae={};this['idToken']&&(_0x51a7ae['id_token']=this['idToken']),this['accessToken']&&(_0x51a7ae['access_token']=this['accessToken']),this['secret']&&(_0x51a7ae['oauth_token_secret']=this['secret']),_0x51a7ae['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x51a7ae['nonce']=this['nonce']),_0x394f92['postBody']=at(_0x51a7ae);}return _0x394f92;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x42680c){switch(_0x42680c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x314fe1){const _0x7ad3ef=yt(vt(_0x314fe1))['link'],_0x265a9d=_0x7ad3ef?yt(vt(_0x7ad3ef))['deep_link_id']:null,_0x3d21ef=yt(vt(_0x314fe1))['deep_link_id'];return(_0x3d21ef?yt(vt(_0x3d21ef))['link']:null)||_0x3d21ef||_0x265a9d||_0x7ad3ef||_0x314fe1;}class Ss{constructor(_0x4b939a){const _0x1e1514=yt(vt(_0x4b939a)),_0x1c88db=_0x1e1514['apiKey']??null,_0x34b0e2=_0x1e1514['oobCode']??null,_0x51008d=Gf(_0x1e1514['mode']??null);m(_0x1c88db&&_0x34b0e2&&_0x51008d,'argument-error'),this['apiKey']=_0x1c88db,this['operation']=_0x51008d,this['code']=_0x34b0e2,this['continueUrl']=_0x1e1514['continueUrl']??null,this['languageCode']=_0x1e1514['lang']??null,this['tenantId']=_0x1e1514['tenantId']??null;}static['parseLink'](_0x8e131b){const _0x5aed90=qf(_0x8e131b);try{return new Ss(_0x5aed90);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4e486a,_0x5e21ab){return Ft['_fromEmailAndPassword'](_0x4e486a,_0x5e21ab);}static['credentialWithLink'](_0xff2943,_0x4fc28f){const _0x227092=Ss['parseLink'](_0x4fc28f);return m(_0x227092,'argument-error'),Ft['_fromEmailAndCode'](_0xff2943,_0x227092['code'],_0x227092['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5a5143){this['providerId']=_0x5a5143,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4b5488){this['defaultLanguageCode']=_0x4b5488;}['setCustomParameters'](_0x288cd0){return this['customParameters']=_0x288cd0,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x21ee86){return this['scopes']['includes'](_0x21ee86)||this['scopes']['push'](_0x21ee86),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3af908){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3af908});}static['credentialFromResult'](_0x36e04e){return he['credentialFromTaggedObject'](_0x36e04e);}static['credentialFromError'](_0x39b611){return he['credentialFromTaggedObject'](_0x39b611['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3f77a5}){if(!_0x3f77a5||!('oauthAccessToken'in _0x3f77a5)||!_0x3f77a5['oauthAccessToken'])return null;try{return he['credential'](_0x3f77a5['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2babf3,_0x235f44){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2babf3,'accessToken':_0x235f44});}static['credentialFromResult'](_0x1e9a25){return ue['credentialFromTaggedObject'](_0x1e9a25);}static['credentialFromError'](_0x3c8ff7){return ue['credentialFromTaggedObject'](_0x3c8ff7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x192102}){if(!_0x192102)return null;const {oauthIdToken:_0x29246,oauthAccessToken:_0x66872d}=_0x192102;if(!_0x29246&&!_0x66872d)return null;try{return ue['credential'](_0x29246,_0x66872d);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xd71b1){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xd71b1});}static['credentialFromResult'](_0x1cda6f){return de['credentialFromTaggedObject'](_0x1cda6f);}static['credentialFromError'](_0x59a66d){return de['credentialFromTaggedObject'](_0x59a66d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4a7522}){if(!_0x4a7522||!('oauthAccessToken'in _0x4a7522)||!_0x4a7522['oauthAccessToken'])return null;try{return de['credential'](_0x4a7522['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x19c1ce,_0x4ac741){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x19c1ce,'oauthTokenSecret':_0x4ac741});}static['credentialFromResult'](_0x2f814c){return fe['credentialFromTaggedObject'](_0x2f814c);}static['credentialFromError'](_0x4d21c8){return fe['credentialFromTaggedObject'](_0x4d21c8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x734bc5}){if(!_0x734bc5)return null;const {oauthAccessToken:_0x3c7b55,oauthTokenSecret:_0x1c36c6}=_0x734bc5;if(!_0x3c7b55||!_0x1c36c6)return null;try{return fe['credential'](_0x3c7b55,_0x1c36c6);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x29314d,_0x8b661c){return Yt(_0x29314d,'POST','/v1/accounts:signUp',Re(_0x29314d,_0x8b661c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x1439da){this['user']=_0x1439da['user'],this['providerId']=_0x1439da['providerId'],this['_tokenResponse']=_0x1439da['_tokenResponse'],this['operationType']=_0x1439da['operationType'];}static async['_fromIdTokenResponse'](_0x4a6374,_0xc73651,_0x4b1d96,_0x310ee9=!0x1){const _0x214fbf=await z['_fromIdTokenResponse'](_0x4a6374,_0x4b1d96,_0x310ee9),_0x22339b=Ar(_0x4b1d96);return new Be({'user':_0x214fbf,'providerId':_0x22339b,'_tokenResponse':_0x4b1d96,'operationType':_0xc73651});}static async['_forOperation'](_0x1ff4aa,_0x2e64c5,_0x1ef5ab){await _0x1ff4aa['_updateTokensIfNecessary'](_0x1ef5ab,!0x0);const _0x11014a=Ar(_0x1ef5ab);return new Be({'user':_0x1ff4aa,'providerId':_0x11014a,'_tokenResponse':_0x1ef5ab,'operationType':_0x2e64c5});}}function Ar(_0x3dc230){return _0x3dc230['providerId']?_0x3dc230['providerId']:'phoneNumber'in _0x3dc230?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x2fc81e,_0x4df78d,_0x3710e7,_0x2fc349){super(_0x4df78d['code'],_0x4df78d['message']),this['operationType']=_0x3710e7,this['user']=_0x2fc349,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x2fc81e['name'],'tenantId':_0x2fc81e['tenantId']??void 0x0,'_serverResponse':_0x4df78d['customData']['_serverResponse'],'operationType':_0x3710e7};}static['_fromErrorAndOperation'](_0x5b87a9,_0x48641b,_0x5dbeac,_0x7a54de){return new Rn(_0x5b87a9,_0x48641b,_0x5dbeac,_0x7a54de);}}function Fa(_0x303cc3,_0x102dda,_0x6b2a99,_0x349959){return(_0x102dda==='reauthenticate'?_0x6b2a99['_getReauthenticationResolver'](_0x303cc3):_0x6b2a99['_getIdTokenResponse'](_0x303cc3))['catch'](_0x3f40a8=>{throw _0x3f40a8['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x303cc3,_0x3f40a8,_0x102dda,_0x349959):_0x3f40a8;});}async function jf(_0x2b4665,_0x26fc0e,_0xf0eb29=!0x1){const _0x508cfc=await xt(_0x2b4665,_0x26fc0e['_linkToIdToken'](_0x2b4665['auth'],await _0x2b4665['getIdToken']()),_0xf0eb29);return Be['_forOperation'](_0x2b4665,'link',_0x508cfc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4cd85b,_0x3f0f3a,_0x24480f=!0x1){const {auth:_0x3c254a}=_0x4cd85b;if(H(_0x3c254a['app']))return Promise['reject'](se(_0x3c254a));const _0x44cafe='reauthenticate';try{const _0x503cb8=await xt(_0x4cd85b,Fa(_0x3c254a,_0x44cafe,_0x3f0f3a,_0x4cd85b),_0x24480f);m(_0x503cb8['idToken'],_0x3c254a,'internal-error');const _0x360568=ws(_0x503cb8['idToken']);m(_0x360568,_0x3c254a,'internal-error');const {sub:_0x505ca2}=_0x360568;return m(_0x4cd85b['uid']===_0x505ca2,_0x3c254a,'user-mismatch'),Be['_forOperation'](_0x4cd85b,_0x44cafe,_0x503cb8);}catch(_0x53a456){throw(_0x53a456==null?void 0x0:_0x53a456['code'])==='auth/user-not-found'&&K(_0x3c254a,'user-mismatch'),_0x53a456;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x5254ac,_0x4271db,_0x328e64=!0x1){if(H(_0x5254ac['app']))return Promise['reject'](se(_0x5254ac));const _0xe6024a='signIn',_0x23762f=await Fa(_0x5254ac,_0xe6024a,_0x4271db),_0x22d06c=await Be['_fromIdTokenResponse'](_0x5254ac,_0xe6024a,_0x23762f);return _0x328e64||await _0x5254ac['_updateCurrentUser'](_0x22d06c['user']),_0x22d06c;}async function Yf(_0x27e87d,_0x3993a8){return Ua(qe(_0x27e87d),_0x3993a8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3ba6df){const _0x2e0809=qe(_0x3ba6df);_0x2e0809['_getPasswordPolicyInternal']()&&await _0x2e0809['_updatePasswordPolicy']();}async function R_(_0x5c35e0,_0x194c64,_0x31699e){if(H(_0x5c35e0['app']))return Promise['reject'](se(_0x5c35e0));const _0x3e0437=qe(_0x5c35e0),_0x526ca9=await Oi(_0x3e0437,{'returnSecureToken':!0x0,'email':_0x194c64,'password':_0x31699e,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x35e62b=>{throw _0x35e62b['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5c35e0),_0x35e62b;}),_0x10fccd=await Be['_fromIdTokenResponse'](_0x3e0437,'signIn',_0x526ca9);return await _0x3e0437['_updateCurrentUser'](_0x10fccd['user']),_0x10fccd;}function A_(_0x138177,_0x23219b,_0x50e80b){return H(_0x138177['app'])?Promise['reject'](se(_0x138177)):Yf(k(_0x138177),ft['credential'](_0x23219b,_0x50e80b))['catch'](async _0x1c5dca=>{throw _0x1c5dca['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x138177),_0x1c5dca;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x22aab9,_0x1cd515){return k(_0x22aab9)['setPersistence'](_0x1cd515);}function Qf(_0x351005,_0x525f83,_0x331f47,_0x55c7b8){return k(_0x351005)['onIdTokenChanged'](_0x525f83,_0x331f47,_0x55c7b8);}function Jf(_0x4c3c9d,_0x1f3c95,_0x1e072f){return k(_0x4c3c9d)['beforeAuthStateChanged'](_0x1f3c95,_0x1e072f);}function N_(_0x38700f,_0x2b89c8,_0xa13ea,_0x429bce){return k(_0x38700f)['onAuthStateChanged'](_0x2b89c8,_0xa13ea,_0x429bce);}function P_(_0x438980){return k(_0x438980)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xabfee6,_0x4f2d99){this['storageRetriever']=_0xabfee6,this['type']=_0x4f2d99;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1ae348,_0x4f6330){return this['storage']['setItem'](_0x1ae348,JSON['stringify'](_0x4f6330)),Promise['resolve']();}['_get'](_0x431dcc){const _0xba3952=this['storage']['getItem'](_0x431dcc);return Promise['resolve'](_0xba3952?JSON['parse'](_0xba3952):null);}['_remove'](_0x224a34){return this['storage']['removeItem'](_0x224a34),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4e27a7,_0x2da429)=>this['onStorageEvent'](_0x4e27a7,_0x2da429),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4e2a38){for(const _0x41c21d of Object['keys'](this['listeners'])){const _0xa4ffff=this['storage']['getItem'](_0x41c21d),_0x1caf5c=this['localCache'][_0x41c21d];_0xa4ffff!==_0x1caf5c&&_0x4e2a38(_0x41c21d,_0x1caf5c,_0xa4ffff);}}['onStorageEvent'](_0x575bc4,_0x1d8d3a=!0x1){if(!_0x575bc4['key']){this['forAllChangedKeys']((_0x1e21da,_0x563ad3,_0x27d4c5)=>{this['notifyListeners'](_0x1e21da,_0x27d4c5);});return;}const _0x3b228f=_0x575bc4['key'];_0x1d8d3a?this['detachListener']():this['stopPolling']();const _0x58aacb=()=>{const _0x351bfe=this['storage']['getItem'](_0x3b228f);!_0x1d8d3a&&this['localCache'][_0x3b228f]===_0x351bfe||this['notifyListeners'](_0x3b228f,_0x351bfe);},_0x382be6=this['storage']['getItem'](_0x3b228f);If()&&_0x382be6!==_0x575bc4['newValue']&&_0x575bc4['newValue']!==_0x575bc4['oldValue']?setTimeout(_0x58aacb,Zf):_0x58aacb();}['notifyListeners'](_0x5bec1f,_0x1bfef0){this['localCache'][_0x5bec1f]=_0x1bfef0;const _0x276c7c=this['listeners'][_0x5bec1f];if(_0x276c7c){for(const _0xedd618 of Array['from'](_0x276c7c))_0xedd618(_0x1bfef0&&JSON['parse'](_0x1bfef0));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xa237ce,_0x4e060f,_0x3178c6)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xa237ce,'oldValue':_0x4e060f,'newValue':_0x3178c6}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x288672,_0x37c71c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x288672]||(this['listeners'][_0x288672]=new Set(),this['localCache'][_0x288672]=this['storage']['getItem'](_0x288672)),this['listeners'][_0x288672]['add'](_0x37c71c);}['_removeListener'](_0x3ba607,_0x5c6e52){this['listeners'][_0x3ba607]&&(this['listeners'][_0x3ba607]['delete'](_0x5c6e52),this['listeners'][_0x3ba607]['size']===0x0&&delete this['listeners'][_0x3ba607]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2609e1,_0x37a6b0){await super['_set'](_0x2609e1,_0x37a6b0),this['localCache'][_0x2609e1]=JSON['stringify'](_0x37a6b0);}async['_get'](_0x37e276){const _0x285838=await super['_get'](_0x37e276);return this['localCache'][_0x37e276]=JSON['stringify'](_0x285838),_0x285838;}async['_remove'](_0xbff2fd){await super['_remove'](_0xbff2fd),delete this['localCache'][_0xbff2fd];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x392f28,_0x47aae2){}['_removeListener'](_0x317899,_0x1e8525){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x5c96cd){return Promise['all'](_0x5c96cd['map'](async _0x35ef59=>{try{return{'fulfilled':!0x0,'value':await _0x35ef59};}catch(_0x5d9ba0){return{'fulfilled':!0x1,'reason':_0x5d9ba0};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x38e469){this['eventTarget']=_0x38e469,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x102015){const _0x5c2534=this['receivers']['find'](_0x2910ab=>_0x2910ab['isListeningto'](_0x102015));if(_0x5c2534)return _0x5c2534;const _0x2bbb65=new jn(_0x102015);return this['receivers']['push'](_0x2bbb65),_0x2bbb65;}['isListeningto'](_0x2d8820){return this['eventTarget']===_0x2d8820;}async['handleEvent'](_0x37d157){const _0x53ae33=_0x37d157,{eventId:_0x33d5bd,eventType:_0x288b1c,data:_0x50ab43}=_0x53ae33['data'],_0x1ad907=this['handlersMap'][_0x288b1c];if(!(_0x1ad907!=null&&_0x1ad907['size']))return;_0x53ae33['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x33d5bd,'eventType':_0x288b1c});const _0x2b9297=Array['from'](_0x1ad907)['map'](async _0x5b7f73=>_0x5b7f73(_0x53ae33['origin'],_0x50ab43)),_0x21c07f=await tp(_0x2b9297);_0x53ae33['ports'][0x0]['postMessage']({'status':'done','eventId':_0x33d5bd,'eventType':_0x288b1c,'response':_0x21c07f});}['_subscribe'](_0x374426,_0x5c2b26){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x374426]||(this['handlersMap'][_0x374426]=new Set()),this['handlersMap'][_0x374426]['add'](_0x5c2b26);}['_unsubscribe'](_0x5e786a,_0x53c3e8){this['handlersMap'][_0x5e786a]&&_0x53c3e8&&this['handlersMap'][_0x5e786a]['delete'](_0x53c3e8),(!_0x53c3e8||this['handlersMap'][_0x5e786a]['size']===0x0)&&delete this['handlersMap'][_0x5e786a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x325040='',_0x26bc0f=0xa){let _0x13eaa0='';for(let _0x492a09=0x0;_0x492a09<_0x26bc0f;_0x492a09++)_0x13eaa0+=Math['floor'](Math['random']()*0xa);return _0x325040+_0x13eaa0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x35b59b){this['target']=_0x35b59b,this['handlers']=new Set();}['removeMessageHandler'](_0x1be14b){_0x1be14b['messageChannel']&&(_0x1be14b['messageChannel']['port1']['removeEventListener']('message',_0x1be14b['onMessage']),_0x1be14b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1be14b);}async['_send'](_0x2b959a,_0x3f3fd3,_0x3d2d2b=0x32){const _0x4da514=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4da514)throw new Error('connection_unavailable');let _0x5bbfac,_0x825697;return new Promise((_0x138c44,_0x1fd178)=>{const _0x4c6e6d=bs('',0x14);_0x4da514['port1']['start']();const _0x3c12fa=setTimeout(()=>{_0x1fd178(new Error('unsupported_event'));},_0x3d2d2b);_0x825697={'messageChannel':_0x4da514,'onMessage'(_0x17e1ad){const _0x3bfb2b=_0x17e1ad;if(_0x3bfb2b['data']['eventId']===_0x4c6e6d)switch(_0x3bfb2b['data']['status']){case'ack':clearTimeout(_0x3c12fa),_0x5bbfac=setTimeout(()=>{_0x1fd178(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5bbfac),_0x138c44(_0x3bfb2b['data']['response']);break;default:clearTimeout(_0x3c12fa),clearTimeout(_0x5bbfac),_0x1fd178(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x825697),_0x4da514['port1']['addEventListener']('message',_0x825697['onMessage']),this['target']['postMessage']({'eventType':_0x2b959a,'eventId':_0x4c6e6d,'data':_0x3f3fd3},[_0x4da514['port2']]);})['finally'](()=>{_0x825697&&this['removeMessageHandler'](_0x825697);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x34c0fa){X()['location']['href']=_0x34c0fa;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x44c4fe;return((_0x44c4fe=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x44c4fe['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x1b698e){this['request']=_0x1b698e;}['toPromise'](){return new Promise((_0x47a597,_0x1647ad)=>{this['request']['addEventListener']('success',()=>{_0x47a597(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1647ad(this['request']['error']);});});}}function Kn(_0x4fe1bc,_0x35e7a3){return _0x4fe1bc['transaction']([kn],_0x35e7a3?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x2dc672=indexedDB['deleteDatabase'](qa);return new Jt(_0x2dc672)['toPromise']();}function ja(){const _0x14e960=indexedDB['open'](qa,ap);return new Promise((_0x4ed100,_0x1890be)=>{_0x14e960['addEventListener']('error',()=>{_0x1890be(_0x14e960['error']);}),_0x14e960['addEventListener']('upgradeneeded',()=>{const _0x3dad00=_0x14e960['result'];try{_0x3dad00['createObjectStore'](kn,{'keyPath':za});}catch(_0x51f209){_0x1890be(_0x51f209);}}),_0x14e960['addEventListener']('success',async()=>{const _0x3cc1f2=_0x14e960['result'];_0x3cc1f2['objectStoreNames']['contains'](kn)?_0x4ed100(_0x3cc1f2):(_0x3cc1f2['close'](),await cp(),_0x4ed100(await ja()));});});}async function kr(_0x2c5b0f,_0x4242da,_0x51691f){const _0xef0df5=Kn(_0x2c5b0f,!0x0)['put']({[za]:_0x4242da,'value':_0x51691f});return new Jt(_0xef0df5)['toPromise']();}async function lp(_0x1d1917,_0x5037c3){const _0x2e217a=Kn(_0x1d1917,!0x1)['get'](_0x5037c3),_0x2ee878=await new Jt(_0x2e217a)['toPromise']();return _0x2ee878===void 0x0?null:_0x2ee878['value'];}function Nr(_0x333116,_0x4063be){const _0x2e7fa9=Kn(_0x333116,!0x0)['delete'](_0x4063be);return new Jt(_0x2e7fa9)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x559d29){let _0x2bc1a8=0x0;for(;;)try{const _0x57cba1=await this['_openDb']();return await _0x559d29(_0x57cba1);}catch(_0x37cc18){if(_0x2bc1a8++>up)throw _0x37cc18;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x433628,_0x4b7b8f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4b7b8f['key'])})),this['receiver']['_subscribe']('ping',async(_0x43f53f,_0x1b27a8)=>['keyChanged']);}async['initializeSender'](){var _0x2e5aae,_0x2cfd9c;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x59a0b1=await this['sender']['_send']('ping',{},0x320);_0x59a0b1&&(_0x2e5aae=_0x59a0b1[0x0])!=null&&_0x2e5aae['fulfilled']&&(_0x2cfd9c=_0x59a0b1[0x0])!=null&&_0x2cfd9c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x43e481){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x43e481},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3acb10=>{await kr(_0x3acb10,An,'1'),await Nr(_0x3acb10,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x104412){this['pendingWrites']++;try{await _0x104412();}finally{this['pendingWrites']--;}}async['_set'](_0x73edb,_0x4821f7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4d35b5=>kr(_0x4d35b5,_0x73edb,_0x4821f7)),this['localCache'][_0x73edb]=_0x4821f7,this['notifyServiceWorker'](_0x73edb)));}async['_get'](_0x2f3ed7){const _0x5217db=await this['_withRetries'](_0x1e508a=>lp(_0x1e508a,_0x2f3ed7));return this['localCache'][_0x2f3ed7]=_0x5217db,_0x5217db;}async['_remove'](_0x2b96e5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3ee1ab=>Nr(_0x3ee1ab,_0x2b96e5)),delete this['localCache'][_0x2b96e5],this['notifyServiceWorker'](_0x2b96e5)));}async['_poll'](){const _0x3c81f=await this['_withRetries'](_0x50f373=>{const _0x1b9d42=Kn(_0x50f373,!0x1)['getAll']();return new Jt(_0x1b9d42)['toPromise']();});if(!_0x3c81f)return[];if(this['pendingWrites']!==0x0)return[];const _0x540ec2=[],_0x419407=new Set();if(_0x3c81f['length']!==0x0){for(const {fbase_key:_0x661626,value:_0x496c7c}of _0x3c81f)_0x419407['add'](_0x661626),JSON['stringify'](this['localCache'][_0x661626])!==JSON['stringify'](_0x496c7c)&&(this['notifyListeners'](_0x661626,_0x496c7c),_0x540ec2['push'](_0x661626));}for(const _0x44f83e of Object['keys'](this['localCache']))this['localCache'][_0x44f83e]&&!_0x419407['has'](_0x44f83e)&&(this['notifyListeners'](_0x44f83e,null),_0x540ec2['push'](_0x44f83e));return _0x540ec2;}['notifyListeners'](_0x14149d,_0x646360){this['localCache'][_0x14149d]=_0x646360;const _0x499aae=this['listeners'][_0x14149d];if(_0x499aae){for(const _0x563c0f of Array['from'](_0x499aae))_0x563c0f(_0x646360);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4c8112,_0x2536e3){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4c8112]||(this['listeners'][_0x4c8112]=new Set(),this['_get'](_0x4c8112)),this['listeners'][_0x4c8112]['add'](_0x2536e3);}['_removeListener'](_0x5f5652,_0x586e59){this['listeners'][_0x5f5652]&&(this['listeners'][_0x5f5652]['delete'](_0x586e59),this['listeners'][_0x5f5652]['size']===0x0&&delete this['listeners'][_0x5f5652]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51f64a,_0x197f38){return _0x197f38?ne(_0x197f38):(m(_0x51f64a['_popupRedirectResolver'],_0x51f64a,'argument-error'),_0x51f64a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2c726e){super('custom','custom'),this['params']=_0x2c726e;}['_getIdTokenResponse'](_0x5e3243){return Ze(_0x5e3243,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4fcff3,_0x199305){return Ze(_0x4fcff3,this['_buildIdpRequest'](_0x199305));}['_getReauthenticationResolver'](_0x20a27d){return Ze(_0x20a27d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x25157c){const _0x20f4d8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x25157c&&(_0x20f4d8['idToken']=_0x25157c),_0x20f4d8;}}function pp(_0x6783c2){return Ua(_0x6783c2['auth'],new Rs(_0x6783c2),_0x6783c2['bypassAuthState']);}function _p(_0x50b1b3){const {auth:_0x324427,user:_0x127ae9}=_0x50b1b3;return m(_0x127ae9,_0x324427,'internal-error'),Kf(_0x127ae9,new Rs(_0x50b1b3),_0x50b1b3['bypassAuthState']);}async function gp(_0x4e2f42){const {auth:_0x1657b3,user:_0x5cc117}=_0x4e2f42;return m(_0x5cc117,_0x1657b3,'internal-error'),jf(_0x5cc117,new Rs(_0x4e2f42),_0x4e2f42['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x150fd2,_0x57e2f7,_0x540c8e,_0x2a8427,_0x4cd64b=!0x1){this['auth']=_0x150fd2,this['resolver']=_0x540c8e,this['user']=_0x2a8427,this['bypassAuthState']=_0x4cd64b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x57e2f7)?_0x57e2f7:[_0x57e2f7];}['execute'](){return new Promise(async(_0x4192d8,_0x14c7fb)=>{this['pendingPromise']={'resolve':_0x4192d8,'reject':_0x14c7fb};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x455f5f){this['reject'](_0x455f5f);}});}async['onAuthEvent'](_0x568dba){const {urlResponse:_0x862b3f,sessionId:_0x1624cf,postBody:_0x5aeef6,tenantId:_0x34f8c1,error:_0x20d7f1,type:_0x1a64b4}=_0x568dba;if(_0x20d7f1){this['reject'](_0x20d7f1);return;}const _0x12ee8c={'auth':this['auth'],'requestUri':_0x862b3f,'sessionId':_0x1624cf,'tenantId':_0x34f8c1||void 0x0,'postBody':_0x5aeef6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1a64b4)(_0x12ee8c));}catch(_0xbecd5d){this['reject'](_0xbecd5d);}}['onError'](_0x31d5c8){this['reject'](_0x31d5c8);}['getIdpTask'](_0x5be689){switch(_0x5be689){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x352d79){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x352d79),this['unregisterAndCleanUp']();}['reject'](_0x524c45){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x524c45),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x493cca,_0x5243d2,_0xc9896,_0x559c3e,_0x5df7a8){super(_0x493cca,_0x5243d2,_0x559c3e,_0x5df7a8),this['provider']=_0xc9896,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x1dac1c=await this['execute']();return m(_0x1dac1c,this['auth'],'internal-error'),_0x1dac1c;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1c3c31=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1c3c31),this['authWindow']['associatedEvent']=_0x1c3c31,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1c3f67=>{this['reject'](_0x1c3f67);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x489fe4=>{_0x489fe4||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x587961;return((_0x587961=this['authWindow'])==null?void 0x0:_0x587961['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3f2de0=()=>{var _0x3ba9cc,_0x557cee;if((_0x557cee=(_0x3ba9cc=this['authWindow'])==null?void 0x0:_0x3ba9cc['window'])!=null&&_0x557cee['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3f2de0,mp['get']());};_0x3f2de0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x50e9f8,_0x35e2ee,_0x230b96=!0x1){super(_0x50e9f8,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x35e2ee,void 0x0,_0x230b96),this['eventId']=null;}async['execute'](){let _0x3f35f3=rn['get'](this['auth']['_key']());if(!_0x3f35f3){try{const _0x128ee3=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3f35f3=()=>Promise['resolve'](_0x128ee3);}catch(_0x2d8441){_0x3f35f3=()=>Promise['reject'](_0x2d8441);}rn['set'](this['auth']['_key'](),_0x3f35f3);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3f35f3();}async['onAuthEvent'](_0xd41065){if(_0xd41065['type']==='signInViaRedirect')return super['onAuthEvent'](_0xd41065);if(_0xd41065['type']==='unknown'){this['resolve'](null);return;}if(_0xd41065['eventId']){const _0x583445=await this['auth']['_redirectUserForId'](_0xd41065['eventId']);if(_0x583445)return this['user']=_0x583445,super['onAuthEvent'](_0xd41065);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x1cc9aa,_0x435568){const _0x3ce2bb=Cp(_0x435568),_0x3e40e0=wp(_0x1cc9aa);if(!await _0x3e40e0['_isAvailable']())return!0x1;const _0x45464d=await _0x3e40e0['_get'](_0x3ce2bb)==='true';return await _0x3e40e0['_remove'](_0x3ce2bb),_0x45464d;}function Ip(_0x2eeaca,_0x12293c){rn['set'](_0x2eeaca['_key'](),_0x12293c);}function wp(_0x5edefd){return ne(_0x5edefd['_redirectPersistence']);}function Cp(_0x458bcf){return sn(yp,_0x458bcf['config']['apiKey'],_0x458bcf['name']);}async function Tp(_0x5771c1,_0x24d524,_0x307593=!0x1){if(H(_0x5771c1['app']))return Promise['reject'](se(_0x5771c1));const _0x56af0f=qe(_0x5771c1),_0x23c46d=fp(_0x56af0f,_0x24d524),_0x45bec9=await new vp(_0x56af0f,_0x23c46d,_0x307593)['execute']();return _0x45bec9&&!_0x307593&&(delete _0x45bec9['user']['_redirectEventId'],await _0x56af0f['_persistUserIfCurrent'](_0x45bec9['user']),await _0x56af0f['_setRedirectUser'](null,_0x24d524)),_0x45bec9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x79a167){this['auth']=_0x79a167,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xe44e6c){this['consumers']['add'](_0xe44e6c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xe44e6c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xe44e6c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x246776){this['consumers']['delete'](_0x246776);}['onEvent'](_0x4684ff){if(this['hasEventBeenHandled'](_0x4684ff))return!0x1;let _0x5e75fb=!0x1;return this['consumers']['forEach'](_0x1da462=>{this['isEventForConsumer'](_0x4684ff,_0x1da462)&&(_0x5e75fb=!0x0,this['sendToConsumer'](_0x4684ff,_0x1da462),this['saveEventToCache'](_0x4684ff));}),this['hasHandledPotentialRedirect']||!Rp(_0x4684ff)||(this['hasHandledPotentialRedirect']=!0x0,_0x5e75fb||(this['queuedRedirectEvent']=_0x4684ff,_0x5e75fb=!0x0)),_0x5e75fb;}['sendToConsumer'](_0x1c51d0,_0x18f3e1){var _0x1f0e9a;if(_0x1c51d0['error']&&!Qa(_0x1c51d0)){const _0x14b401=((_0x1f0e9a=_0x1c51d0['error']['code'])==null?void 0x0:_0x1f0e9a['split']('auth/')[0x1])||'internal-error';_0x18f3e1['onError'](J(this['auth'],_0x14b401));}else _0x18f3e1['onAuthEvent'](_0x1c51d0);}['isEventForConsumer'](_0x2a5efc,_0x217d9a){const _0x30a6e5=_0x217d9a['eventId']===null||!!_0x2a5efc['eventId']&&_0x2a5efc['eventId']===_0x217d9a['eventId'];return _0x217d9a['filter']['includes'](_0x2a5efc['type'])&&_0x30a6e5;}['hasEventBeenHandled'](_0x216974){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x216974));}['saveEventToCache'](_0xf0db71){this['cachedEventUids']['add'](Pr(_0xf0db71)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x296db9){return[_0x296db9['type'],_0x296db9['eventId'],_0x296db9['sessionId'],_0x296db9['tenantId']]['filter'](_0x593824=>_0x593824)['join']('-');}function Qa({type:_0x2fd572,error:_0x5244ac}){return _0x2fd572==='unknown'&&(_0x5244ac==null?void 0x0:_0x5244ac['code'])==='auth/no-auth-event';}function Rp(_0x4d91d6){switch(_0x4d91d6['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4d91d6);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x5b8be9,_0x1cd3d1={}){return Ae(_0x5b8be9,'GET','/v1/projects',_0x1cd3d1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x20e1a3){if(_0x20e1a3['config']['emulator'])return;const {authorizedDomains:_0x50eb7d}=await Ap(_0x20e1a3);for(const _0xa684fc of _0x50eb7d)try{if(Op(_0xa684fc))return;}catch{}K(_0x20e1a3,'unauthorized-domain');}function Op(_0x18a2b3){const _0x48b47b=Ni(),{protocol:_0x2e71d2,hostname:_0x39f2a4}=new URL(_0x48b47b);if(_0x18a2b3['startsWith']('chrome-extension://')){const _0x4fa717=new URL(_0x18a2b3);return _0x4fa717['hostname']===''&&_0x39f2a4===''?_0x2e71d2==='chrome-extension:'&&_0x18a2b3['replace']('chrome-extension://','')===_0x48b47b['replace']('chrome-extension://',''):_0x2e71d2==='chrome-extension:'&&_0x4fa717['hostname']===_0x39f2a4;}if(!Np['test'](_0x2e71d2))return!0x1;if(kp['test'](_0x18a2b3))return _0x39f2a4===_0x18a2b3;const _0x25dc24=_0x18a2b3['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x25dc24+'|'+_0x25dc24+')$','i')['test'](_0x39f2a4);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x29974f=X()['___jsl'];if(_0x29974f!=null&&_0x29974f['H']){for(const _0x9a3bb1 of Object['keys'](_0x29974f['H']))if(_0x29974f['H'][_0x9a3bb1]['r']=_0x29974f['H'][_0x9a3bb1]['r']||[],_0x29974f['H'][_0x9a3bb1]['L']=_0x29974f['H'][_0x9a3bb1]['L']||[],_0x29974f['H'][_0x9a3bb1]['r']=[..._0x29974f['H'][_0x9a3bb1]['L']],_0x29974f['CP']){for(let _0x81cce9=0x0;_0x81cce9<_0x29974f['CP']['length'];_0x81cce9++)_0x29974f['CP'][_0x81cce9]=null;}}}function Mp(_0x1f1e00){return new Promise((_0x1e0cf0,_0x457a46)=>{var _0x12041b,_0x127b2b,_0x478c9e;function _0x40cf0c(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1e0cf0(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x457a46(J(_0x1f1e00,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x127b2b=(_0x12041b=X()['gapi'])==null?void 0x0:_0x12041b['iframes'])!=null&&_0x127b2b['Iframe'])_0x1e0cf0(gapi['iframes']['getContext']());else{if((_0x478c9e=X()['gapi'])!=null&&_0x478c9e['load'])_0x40cf0c();else{const _0x26fb55=Nf('iframefcb');return X()[_0x26fb55]=()=>{gapi['load']?_0x40cf0c():_0x457a46(J(_0x1f1e00,'network-request-failed'));},Da(kf()+'?onload='+_0x26fb55)['catch'](_0x2b9375=>_0x457a46(_0x2b9375));}}})['catch'](_0x4ac1c8=>{throw on=null,_0x4ac1c8;});}let on=null;function Lp(_0x21fc0d){return on=on||Mp(_0x21fc0d),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x1f80a1){const _0x17a41d=_0x1f80a1['config'];m(_0x17a41d['authDomain'],_0x1f80a1,'auth-domain-config-required');const _0x2d3a39=_0x17a41d['emulator']?Is(_0x17a41d,Up):'https://'+_0x1f80a1['config']['authDomain']+'/'+Fp,_0x55294e={'apiKey':_0x17a41d['apiKey'],'appName':_0x1f80a1['name'],'v':ct},_0xae60de=Bp['get'](_0x1f80a1['config']['apiHost']);_0xae60de&&(_0x55294e['eid']=_0xae60de);const _0x15deea=_0x1f80a1['_getFrameworks']();return _0x15deea['length']&&(_0x55294e['fw']=_0x15deea['join'](',')),_0x2d3a39+'?'+at(_0x55294e)['slice'](0x1);}async function Hp(_0x2b4e44){const _0x45df02=await Lp(_0x2b4e44),_0x2e656d=X()['gapi'];return m(_0x2e656d,_0x2b4e44,'internal-error'),_0x45df02['open']({'where':document['body'],'url':Vp(_0x2b4e44),'messageHandlersFilter':_0x2e656d['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x54f42a=>new Promise(async(_0x3e3fc9,_0x2d10cb)=>{await _0x54f42a['restyle']({'setHideOnLeave':!0x1});const _0x3cc307=J(_0x2b4e44,'network-request-failed'),_0x4f98b8=X()['setTimeout'](()=>{_0x2d10cb(_0x3cc307);},xp['get']());function _0x16e74d(){X()['clearTimeout'](_0x4f98b8),_0x3e3fc9(_0x54f42a);}_0x54f42a['ping'](_0x16e74d)['then'](_0x16e74d,()=>{_0x2d10cb(_0x3cc307);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x4c4d73){this['window']=_0x4c4d73,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x4d4a38,_0x30cb3e,_0x51482c,_0x56b8ec=Gp,_0x3a47cd=qp){const _0x28ca8b=Math['max']((window['screen']['availHeight']-_0x3a47cd)/0x2,0x0)['toString'](),_0x140a6f=Math['max']((window['screen']['availWidth']-_0x56b8ec)/0x2,0x0)['toString']();let _0x55cedd='';const _0x9d1609={...$p,'width':_0x56b8ec['toString'](),'height':_0x3a47cd['toString'](),'top':_0x28ca8b,'left':_0x140a6f},_0x5dbd3a=W()['toLowerCase']();_0x51482c&&(_0x55cedd=ba(_0x5dbd3a)?zp:_0x51482c),Ta(_0x5dbd3a)&&(_0x30cb3e=_0x30cb3e||jp,_0x9d1609['scrollbars']='yes');const _0x57c457=Object['entries'](_0x9d1609)['reduce']((_0x253fca,[_0x14d82c,_0x36cf3f])=>''+_0x253fca+_0x14d82c+'='+_0x36cf3f+',','');if(Ef(_0x5dbd3a)&&_0x55cedd!=='_self')return Yp(_0x30cb3e||'',_0x55cedd),new Dr(null);const _0x550a43=window['open'](_0x30cb3e||'',_0x55cedd,_0x57c457);m(_0x550a43,_0x4d4a38,'popup-blocked');try{_0x550a43['focus']();}catch{}return new Dr(_0x550a43);}function Yp(_0x4051ed,_0x3145f2){const _0x598aeb=document['createElement']('a');_0x598aeb['href']=_0x4051ed,_0x598aeb['target']=_0x3145f2;const _0x4d3d3a=document['createEvent']('MouseEvent');_0x4d3d3a['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x598aeb['dispatchEvent'](_0x4d3d3a);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x399a95,_0x37146b,_0xccb5d6,_0x12801c,_0x40b817,_0x12903d){m(_0x399a95['config']['authDomain'],_0x399a95,'auth-domain-config-required'),m(_0x399a95['config']['apiKey'],_0x399a95,'invalid-api-key');const _0x4e8088={'apiKey':_0x399a95['config']['apiKey'],'appName':_0x399a95['name'],'authType':_0xccb5d6,'redirectUrl':_0x12801c,'v':ct,'eventId':_0x40b817};if(_0x37146b instanceof xa){_0x37146b['setDefaultLanguage'](_0x399a95['languageCode']),_0x4e8088['providerId']=_0x37146b['providerId']||'',hi(_0x37146b['getCustomParameters']())||(_0x4e8088['customParameters']=JSON['stringify'](_0x37146b['getCustomParameters']()));for(const [_0x455c36,_0x22c69e]of Object['entries']({}))_0x4e8088[_0x455c36]=_0x22c69e;}if(_0x37146b instanceof Qt){const _0x587d2a=_0x37146b['getScopes']()['filter'](_0x2ae929=>_0x2ae929!=='');_0x587d2a['length']>0x0&&(_0x4e8088['scopes']=_0x587d2a['join'](','));}_0x399a95['tenantId']&&(_0x4e8088['tid']=_0x399a95['tenantId']);const _0x3ee242=_0x4e8088;for(const _0x41f9b3 of Object['keys'](_0x3ee242))_0x3ee242[_0x41f9b3]===void 0x0&&delete _0x3ee242[_0x41f9b3];const _0x4d4011=await _0x399a95['_getAppCheckToken'](),_0x58c05a=_0x4d4011?'#'+Xp+'='+encodeURIComponent(_0x4d4011):'';return Zp(_0x399a95)+'?'+at(_0x3ee242)['slice'](0x1)+_0x58c05a;}function Zp({config:_0x660196}){return _0x660196['emulator']?Is(_0x660196,Jp):'https://'+_0x660196['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x9a2ea2,_0x195a9f,_0x54eaf9,_0x4194ef){var _0x5a7edd;ae((_0x5a7edd=this['eventManagers'][_0x9a2ea2['_key']()])==null?void 0x0:_0x5a7edd['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x35829d=await Mr(_0x9a2ea2,_0x195a9f,_0x54eaf9,Ni(),_0x4194ef);return Kp(_0x9a2ea2,_0x35829d,bs());}async['_openRedirect'](_0x1db92e,_0x4b4a65,_0x5a0ed2,_0x2033f4){await this['_originValidation'](_0x1db92e);const _0x19c2b1=await Mr(_0x1db92e,_0x4b4a65,_0x5a0ed2,Ni(),_0x2033f4);return ip(_0x19c2b1),new Promise(()=>{});}['_initialize'](_0x57e901){const _0x2df9a3=_0x57e901['_key']();if(this['eventManagers'][_0x2df9a3]){const {manager:_0x354ad5,promise:_0x357724}=this['eventManagers'][_0x2df9a3];return _0x354ad5?Promise['resolve'](_0x354ad5):(ae(_0x357724,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x357724);}const _0x1e1938=this['initAndGetManager'](_0x57e901);return this['eventManagers'][_0x2df9a3]={'promise':_0x1e1938},_0x1e1938['catch'](()=>{delete this['eventManagers'][_0x2df9a3];}),_0x1e1938;}async['initAndGetManager'](_0x5b7bef){const _0x3d1a24=await Hp(_0x5b7bef),_0x1c4b20=new bp(_0x5b7bef);return _0x3d1a24['register']('authEvent',_0x22e328=>(m(_0x22e328==null?void 0x0:_0x22e328['authEvent'],_0x5b7bef,'invalid-auth-event'),{'status':_0x1c4b20['onEvent'](_0x22e328['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5b7bef['_key']()]={'manager':_0x1c4b20},this['iframes'][_0x5b7bef['_key']()]=_0x3d1a24,_0x1c4b20;}['_isIframeWebStorageSupported'](_0x5b648b,_0x2db803){this['iframes'][_0x5b648b['_key']()]['send'](li,{'type':li},_0x1ebf5c=>{var _0x1f0ece;const _0x33427d=(_0x1f0ece=_0x1ebf5c==null?void 0x0:_0x1ebf5c[0x0])==null?void 0x0:_0x1f0ece[li];_0x33427d!==void 0x0&&_0x2db803(!!_0x33427d),K(_0x5b648b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x37652b){const _0x3837bf=_0x37652b['_key']();return this['originValidationPromises'][_0x3837bf]||(this['originValidationPromises'][_0x3837bf]=Pp(_0x37652b)),this['originValidationPromises'][_0x3837bf];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x4ae35a){this['auth']=_0x4ae35a,this['internalListeners']=new Map();}['getUid'](){var _0xdc110a;return this['assertAuthConfigured'](),((_0xdc110a=this['auth']['currentUser'])==null?void 0x0:_0xdc110a['uid'])||null;}async['getToken'](_0x3a93f1){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3a93f1)}:null;}['addAuthTokenListener'](_0x21bd3d){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x21bd3d))return;const _0x654a39=this['auth']['onIdTokenChanged'](_0x48a455=>{_0x21bd3d((_0x48a455==null?void 0x0:_0x48a455['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x21bd3d,_0x654a39),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x177b6d){this['assertAuthConfigured']();const _0x586e1d=this['internalListeners']['get'](_0x177b6d);_0x586e1d&&(this['internalListeners']['delete'](_0x177b6d),_0x586e1d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x59ff34){switch(_0x59ff34){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x2a5dc5){et(new Me('auth',(_0x8cf641,{options:_0x67c05a})=>{const _0x3ae872=_0x8cf641['getProvider']('app')['getImmediate'](),_0x4270d7=_0x8cf641['getProvider']('heartbeat'),_0x1e7602=_0x8cf641['getProvider']('app-check-internal'),{apiKey:_0x40b830,authDomain:_0x10dcf5}=_0x3ae872['options'];m(_0x40b830&&!_0x40b830['includes'](':'),'invalid-api-key',{'appName':_0x3ae872['name']});const _0x476507={'apiKey':_0x40b830,'authDomain':_0x10dcf5,'clientPlatform':_0x2a5dc5,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x2a5dc5)},_0x18849f=new bf(_0x3ae872,_0x4270d7,_0x1e7602,_0x476507);return Lf(_0x18849f,_0x67c05a),_0x18849f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x159160,_0x437ca1,_0x566430)=>{_0x159160['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3914fe=>{const _0x53bc5d=qe(_0x3914fe['getProvider']('auth')['getImmediate']());return(_0xdebee4=>new n_(_0xdebee4))(_0x53bc5d);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x2a5dc5)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x28258e=>async _0x52aae5=>{const _0xf01bce=_0x52aae5&&await _0x52aae5['getIdTokenResult'](),_0x51a359=_0xf01bce&&(new Date()['getTime']()-Date['parse'](_0xf01bce['issuedAtTime']))/0x3e8;if(_0x51a359&&_0x51a359>o_)return;const _0x140798=_0xf01bce==null?void 0x0:_0xf01bce['token'];Fr!==_0x140798&&(Fr=_0x140798,await fetch(_0x28258e,{'method':_0x140798?'POST':'DELETE','headers':_0x140798?{'Authorization':'Bearer\x20'+_0x140798}:{}}));};function O_(_0x4e3b56=Qr()){const _0xc5334d=Ui(_0x4e3b56,'auth');if(_0xc5334d['isInitialized']())return _0xc5334d['getImmediate']();const _0x17d169=Mf(_0x4e3b56,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x35dd31=Gr('authTokenSyncURL');if(_0x35dd31&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5463b4=new URL(_0x35dd31,location['origin']);if(location['origin']===_0x5463b4['origin']){const _0x4bdab0=a_(_0x5463b4['toString']());Jf(_0x17d169,_0x4bdab0,()=>_0x4bdab0(_0x17d169['currentUser'])),Qf(_0x17d169,_0x836b7b=>_0x4bdab0(_0x836b7b));}}const _0x1d813f=Hr('auth');return _0x1d813f&&xf(_0x17d169,'http://'+_0x1d813f),_0x17d169;}function c_(){var _0x2edf16;return((_0x2edf16=document['getElementsByTagName']('head'))==null?void 0x0:_0x2edf16[0x0])??document;}Rf({'loadJS'(_0x9239dd){return new Promise((_0x4649c0,_0x274a8a)=>{const _0x3df38c=document['createElement']('script');_0x3df38c['setAttribute']('src',_0x9239dd),_0x3df38c['onload']=_0x4649c0,_0x3df38c['onerror']=_0x207e1d=>{const _0x158ccc=J('internal-error');_0x158ccc['customData']=_0x207e1d,_0x274a8a(_0x158ccc);},_0x3df38c['type']='text/javascript',_0x3df38c['charset']='UTF-8',c_()['appendChild'](_0x3df38c);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};