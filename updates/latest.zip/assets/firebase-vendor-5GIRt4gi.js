const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3f1b9c,_0x378e5a){if(!_0x3f1b9c)throw ot(_0x378e5a);},ot=function(_0xeb4ca7){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xeb4ca7);},Wr=function(_0x1f58e4){const _0x238f2f=[];let _0x4a8362=0x0;for(let _0x49cfca=0x0;_0x49cfca<_0x1f58e4['length'];_0x49cfca++){let _0x3b026a=_0x1f58e4['charCodeAt'](_0x49cfca);_0x3b026a<0x80?_0x238f2f[_0x4a8362++]=_0x3b026a:_0x3b026a<0x800?(_0x238f2f[_0x4a8362++]=_0x3b026a>>0x6|0xc0,_0x238f2f[_0x4a8362++]=_0x3b026a&0x3f|0x80):(_0x3b026a&0xfc00)===0xd800&&_0x49cfca+0x1<_0x1f58e4['length']&&(_0x1f58e4['charCodeAt'](_0x49cfca+0x1)&0xfc00)===0xdc00?(_0x3b026a=0x10000+((_0x3b026a&0x3ff)<<0xa)+(_0x1f58e4['charCodeAt'](++_0x49cfca)&0x3ff),_0x238f2f[_0x4a8362++]=_0x3b026a>>0x12|0xf0,_0x238f2f[_0x4a8362++]=_0x3b026a>>0xc&0x3f|0x80,_0x238f2f[_0x4a8362++]=_0x3b026a>>0x6&0x3f|0x80,_0x238f2f[_0x4a8362++]=_0x3b026a&0x3f|0x80):(_0x238f2f[_0x4a8362++]=_0x3b026a>>0xc|0xe0,_0x238f2f[_0x4a8362++]=_0x3b026a>>0x6&0x3f|0x80,_0x238f2f[_0x4a8362++]=_0x3b026a&0x3f|0x80);}return _0x238f2f;},Za=function(_0xf957be){const _0x1f4849=[];let _0xa50379=0x0,_0x121959=0x0;for(;_0xa50379<_0xf957be['length'];){const _0x20eca3=_0xf957be[_0xa50379++];if(_0x20eca3<0x80)_0x1f4849[_0x121959++]=String['fromCharCode'](_0x20eca3);else{if(_0x20eca3>0xbf&&_0x20eca3<0xe0){const _0x45a4d7=_0xf957be[_0xa50379++];_0x1f4849[_0x121959++]=String['fromCharCode']((_0x20eca3&0x1f)<<0x6|_0x45a4d7&0x3f);}else{if(_0x20eca3>0xef&&_0x20eca3<0x16d){const _0x38bdbd=_0xf957be[_0xa50379++],_0xbe60e1=_0xf957be[_0xa50379++],_0x4f1e7b=_0xf957be[_0xa50379++],_0x36e1c1=((_0x20eca3&0x7)<<0x12|(_0x38bdbd&0x3f)<<0xc|(_0xbe60e1&0x3f)<<0x6|_0x4f1e7b&0x3f)-0x10000;_0x1f4849[_0x121959++]=String['fromCharCode'](0xd800+(_0x36e1c1>>0xa)),_0x1f4849[_0x121959++]=String['fromCharCode'](0xdc00+(_0x36e1c1&0x3ff));}else{const _0x490de3=_0xf957be[_0xa50379++],_0x28c3f6=_0xf957be[_0xa50379++];_0x1f4849[_0x121959++]=String['fromCharCode']((_0x20eca3&0xf)<<0xc|(_0x490de3&0x3f)<<0x6|_0x28c3f6&0x3f);}}}}return _0x1f4849['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x44daec,_0x1b1cbb){if(!Array['isArray'](_0x44daec))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x155544=_0x1b1cbb?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4fd6e2=[];for(let _0x1e5b1d=0x0;_0x1e5b1d<_0x44daec['length'];_0x1e5b1d+=0x3){const _0x55029f=_0x44daec[_0x1e5b1d],_0x4e54a0=_0x1e5b1d+0x1<_0x44daec['length'],_0x3f80a2=_0x4e54a0?_0x44daec[_0x1e5b1d+0x1]:0x0,_0x49bcb8=_0x1e5b1d+0x2<_0x44daec['length'],_0x3da3a4=_0x49bcb8?_0x44daec[_0x1e5b1d+0x2]:0x0,_0x4d51e1=_0x55029f>>0x2,_0x23e86d=(_0x55029f&0x3)<<0x4|_0x3f80a2>>0x4;let _0x56367a=(_0x3f80a2&0xf)<<0x2|_0x3da3a4>>0x6,_0x3c7d02=_0x3da3a4&0x3f;_0x49bcb8||(_0x3c7d02=0x40,_0x4e54a0||(_0x56367a=0x40)),_0x4fd6e2['push'](_0x155544[_0x4d51e1],_0x155544[_0x23e86d],_0x155544[_0x56367a],_0x155544[_0x3c7d02]);}return _0x4fd6e2['join']('');},'encodeString'(_0xad844f,_0x324e67){return this['HAS_NATIVE_SUPPORT']&&!_0x324e67?btoa(_0xad844f):this['encodeByteArray'](Wr(_0xad844f),_0x324e67);},'decodeString'(_0x52df09,_0x4a2f03){return this['HAS_NATIVE_SUPPORT']&&!_0x4a2f03?atob(_0x52df09):Za(this['decodeStringToByteArray'](_0x52df09,_0x4a2f03));},'decodeStringToByteArray'(_0x70fae7,_0x27071f){this['init_']();const _0x4cc78e=_0x27071f?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x342809=[];for(let _0x263329=0x0;_0x263329<_0x70fae7['length'];){const _0x259b26=_0x4cc78e[_0x70fae7['charAt'](_0x263329++)],_0x4a5fac=_0x263329<_0x70fae7['length']?_0x4cc78e[_0x70fae7['charAt'](_0x263329)]:0x0;++_0x263329;const _0x6425f9=_0x263329<_0x70fae7['length']?_0x4cc78e[_0x70fae7['charAt'](_0x263329)]:0x40;++_0x263329;const _0x45280f=_0x263329<_0x70fae7['length']?_0x4cc78e[_0x70fae7['charAt'](_0x263329)]:0x40;if(++_0x263329,_0x259b26==null||_0x4a5fac==null||_0x6425f9==null||_0x45280f==null)throw new ec();const _0x561c3e=_0x259b26<<0x2|_0x4a5fac>>0x4;if(_0x342809['push'](_0x561c3e),_0x6425f9!==0x40){const _0x517d8c=_0x4a5fac<<0x4&0xf0|_0x6425f9>>0x2;if(_0x342809['push'](_0x517d8c),_0x45280f!==0x40){const _0x1626a8=_0x6425f9<<0x6&0xc0|_0x45280f;_0x342809['push'](_0x1626a8);}}}return _0x342809;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x23a2ed=0x0;_0x23a2ed<this['ENCODED_VALS']['length'];_0x23a2ed++)this['byteToCharMap_'][_0x23a2ed]=this['ENCODED_VALS']['charAt'](_0x23a2ed),this['charToByteMap_'][this['byteToCharMap_'][_0x23a2ed]]=_0x23a2ed,this['byteToCharMapWebSafe_'][_0x23a2ed]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x23a2ed),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x23a2ed]]=_0x23a2ed,_0x23a2ed>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x23a2ed)]=_0x23a2ed,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x23a2ed)]=_0x23a2ed);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x7cfa15){const _0x23d9d6=Wr(_0x7cfa15);return Di['encodeByteArray'](_0x23d9d6,!0x0);},an=function(_0x56bda8){return Br(_0x56bda8)['replace'](/\./g,'');},cn=function(_0x32fd45){try{return Di['decodeString'](_0x32fd45,!0x0);}catch(_0x44f7e2){console['error']('base64Decode\x20failed:\x20',_0x44f7e2);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x320411){return Vr(void 0x0,_0x320411);}function Vr(_0x323e92,_0x48a7ba){if(!(_0x48a7ba instanceof Object))return _0x48a7ba;switch(_0x48a7ba['constructor']){case Date:const _0x493763=_0x48a7ba;return new Date(_0x493763['getTime']());case Object:_0x323e92===void 0x0&&(_0x323e92={});break;case Array:_0x323e92=[];break;default:return _0x48a7ba;}for(const _0x30c8cb in _0x48a7ba)!_0x48a7ba['hasOwnProperty'](_0x30c8cb)||!nc(_0x30c8cb)||(_0x323e92[_0x30c8cb]=Vr(_0x323e92[_0x30c8cb],_0x48a7ba[_0x30c8cb]));return _0x323e92;}function nc(_0x146217){return _0x146217!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x3f19b4=As['__FIREBASE_DEFAULTS__'];if(_0x3f19b4)return JSON['parse'](_0x3f19b4);},oc=()=>{if(typeof document>'u')return;let _0x1a954e;try{_0x1a954e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4abbe8=_0x1a954e&&cn(_0x1a954e[0x1]);return _0x4abbe8&&JSON['parse'](_0x4abbe8);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x447655){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x447655);return;}},Hr=_0x5c38b8=>{var _0x1b0423,_0x452642;return(_0x452642=(_0x1b0423=Mi())==null?void 0x0:_0x1b0423['emulatorHosts'])==null?void 0x0:_0x452642[_0x5c38b8];},ac=_0x22f3ef=>{const _0x419d93=Hr(_0x22f3ef);if(!_0x419d93)return;const _0xda53e0=_0x419d93['lastIndexOf'](':');if(_0xda53e0<=0x0||_0xda53e0+0x1===_0x419d93['length'])throw new Error('Invalid\x20host\x20'+_0x419d93+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x471cd3=parseInt(_0x419d93['substring'](_0xda53e0+0x1),0xa);return _0x419d93[0x0]==='['?[_0x419d93['substring'](0x1,_0xda53e0-0x1),_0x471cd3]:[_0x419d93['substring'](0x0,_0xda53e0),_0x471cd3];},$r=()=>{var _0x35acc2;return(_0x35acc2=Mi())==null?void 0x0:_0x35acc2['config'];},Gr=_0x53c62e=>{var _0x44815f;return(_0x44815f=Mi())==null?void 0x0:_0x44815f['_'+_0x53c62e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xf79471,_0x9d9baf)=>{this['resolve']=_0xf79471,this['reject']=_0x9d9baf;});}['wrapCallback'](_0x296610){return(_0x1a2882,_0x68f510)=>{_0x1a2882?this['reject'](_0x1a2882):this['resolve'](_0x68f510),typeof _0x296610=='function'&&(this['promise']['catch'](()=>{}),_0x296610['length']===0x1?_0x296610(_0x1a2882):_0x296610(_0x1a2882,_0x68f510));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x5eadeb,_0x48a853){if(_0x5eadeb['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5940b0={'alg':'none','type':'JWT'},_0x591dd2=_0x48a853||'demo-project',_0xc10c2=_0x5eadeb['iat']||0x0,_0x4ebc97=_0x5eadeb['sub']||_0x5eadeb['user_id'];if(!_0x4ebc97)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x53e79e={'iss':'https://securetoken.google.com/'+_0x591dd2,'aud':_0x591dd2,'iat':_0xc10c2,'exp':_0xc10c2+0xe10,'auth_time':_0xc10c2,'sub':_0x4ebc97,'user_id':_0x4ebc97,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5eadeb};return[an(JSON['stringify'](_0x5940b0)),an(JSON['stringify'](_0x53e79e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x33394e=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x33394e=='object'&&_0x33394e['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x437f57=W();return _0x437f57['indexOf']('MSIE\x20')>=0x0||_0x437f57['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x5a643e,_0x57433e)=>{try{let _0x4e2321=!0x0;const _0x417765='validate-browser-context-for-indexeddb-analytics-module',_0x43cbb0=self['indexedDB']['open'](_0x417765);_0x43cbb0['onsuccess']=()=>{_0x43cbb0['result']['close'](),_0x4e2321||self['indexedDB']['deleteDatabase'](_0x417765),_0x5a643e(!0x0);},_0x43cbb0['onupgradeneeded']=()=>{_0x4e2321=!0x1;},_0x43cbb0['onerror']=()=>{var _0x44c85f;_0x57433e(((_0x44c85f=_0x43cbb0['error'])==null?void 0x0:_0x44c85f['message'])||'');};}catch(_0x1b0367){_0x57433e(_0x1b0367);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x596ab5,_0x29661e,_0x562363){super(_0x29661e),this['code']=_0x596ab5,this['customData']=_0x562363,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x937f0,_0x3fde2b,_0x40d7a8){this['service']=_0x937f0,this['serviceName']=_0x3fde2b,this['errors']=_0x40d7a8;}['create'](_0x5a6352,..._0xb5a7b1){const _0x2daba0=_0xb5a7b1[0x0]||{},_0x2e6b89=this['service']+'/'+_0x5a6352,_0x4cc5cb=this['errors'][_0x5a6352],_0x5f09e1=_0x4cc5cb?gc(_0x4cc5cb,_0x2daba0):'Error',_0x405149=this['serviceName']+':\x20'+_0x5f09e1+'\x20('+_0x2e6b89+').';return new Se(_0x2e6b89,_0x405149,_0x2daba0);}}function gc(_0x1d7f7b,_0x38b96f){return _0x1d7f7b['replace'](mc,(_0x4724a1,_0x26c039)=>{const _0x3d5c7d=_0x38b96f[_0x26c039];return _0x3d5c7d!=null?String(_0x3d5c7d):'<'+_0x26c039+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4d93bb){return JSON['parse'](_0x4d93bb);}function O(_0x1e3960){return JSON['stringify'](_0x1e3960);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x22b53d){let _0x3edacb={},_0x4d3a50={},_0x35dacb={},_0x573ef1='';try{const _0x5be0b0=_0x22b53d['split']('.');_0x3edacb=bt(cn(_0x5be0b0[0x0])||''),_0x4d3a50=bt(cn(_0x5be0b0[0x1])||''),_0x573ef1=_0x5be0b0[0x2],_0x35dacb=_0x4d3a50['d']||{},delete _0x4d3a50['d'];}catch{}return{'header':_0x3edacb,'claims':_0x4d3a50,'data':_0x35dacb,'signature':_0x573ef1};},yc=function(_0xdbe4d6){const _0x15a3ba=zr(_0xdbe4d6),_0x575aae=_0x15a3ba['claims'];return!!_0x575aae&&typeof _0x575aae=='object'&&_0x575aae['hasOwnProperty']('iat');},vc=function(_0x231dd6){const _0x290f3f=zr(_0x231dd6)['claims'];return typeof _0x290f3f=='object'&&_0x290f3f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1d6eb7,_0x5c15f2){return Object['prototype']['hasOwnProperty']['call'](_0x1d6eb7,_0x5c15f2);}function Oe(_0x410894,_0x265e50){if(Object['prototype']['hasOwnProperty']['call'](_0x410894,_0x265e50))return _0x410894[_0x265e50];}function hi(_0x539fe1){for(const _0x39f9aa in _0x539fe1)if(Object['prototype']['hasOwnProperty']['call'](_0x539fe1,_0x39f9aa))return!0x1;return!0x0;}function ln(_0x5d9547,_0x45776c,_0xc5d48b){const _0x25f3dc={};for(const _0x35e4eb in _0x5d9547)Object['prototype']['hasOwnProperty']['call'](_0x5d9547,_0x35e4eb)&&(_0x25f3dc[_0x35e4eb]=_0x45776c['call'](_0xc5d48b,_0x5d9547[_0x35e4eb],_0x35e4eb,_0x5d9547));return _0x25f3dc;}function De(_0x40a0cc,_0x163b7e){if(_0x40a0cc===_0x163b7e)return!0x0;const _0x5872ba=Object['keys'](_0x40a0cc),_0x157542=Object['keys'](_0x163b7e);for(const _0x351945 of _0x5872ba){if(!_0x157542['includes'](_0x351945))return!0x1;const _0x5003bf=_0x40a0cc[_0x351945],_0x47da4e=_0x163b7e[_0x351945];if(ks(_0x5003bf)&&ks(_0x47da4e)){if(!De(_0x5003bf,_0x47da4e))return!0x1;}else{if(_0x5003bf!==_0x47da4e)return!0x1;}}for(const _0x1b7e32 of _0x157542)if(!_0x5872ba['includes'](_0x1b7e32))return!0x1;return!0x0;}function ks(_0x536f0c){return _0x536f0c!==null&&typeof _0x536f0c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4bdc68){const _0x9da191=[];for(const [_0x5f41c0,_0x4e8e14]of Object['entries'](_0x4bdc68))Array['isArray'](_0x4e8e14)?_0x4e8e14['forEach'](_0x29b921=>{_0x9da191['push'](encodeURIComponent(_0x5f41c0)+'='+encodeURIComponent(_0x29b921));}):_0x9da191['push'](encodeURIComponent(_0x5f41c0)+'='+encodeURIComponent(_0x4e8e14));return _0x9da191['length']?'&'+_0x9da191['join']('&'):'';}function yt(_0x32fec8){const _0x5d3ca1={};return _0x32fec8['replace'](/^\?/,'')['split']('&')['forEach'](_0x2ace95=>{if(_0x2ace95){const [_0x53d500,_0x1f67cf]=_0x2ace95['split']('=');_0x5d3ca1[decodeURIComponent(_0x53d500)]=decodeURIComponent(_0x1f67cf);}}),_0x5d3ca1;}function vt(_0x3ffbad){const _0x5f1328=_0x3ffbad['indexOf']('?');if(!_0x5f1328)return'';const _0x53bb77=_0x3ffbad['indexOf']('#',_0x5f1328);return _0x3ffbad['substring'](_0x5f1328,_0x53bb77>0x0?_0x53bb77:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x306747=0x1;_0x306747<this['blockSize'];++_0x306747)this['pad_'][_0x306747]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1476cd,_0xadcbc7){_0xadcbc7||(_0xadcbc7=0x0);const _0x47a440=this['W_'];if(typeof _0x1476cd=='string'){for(let _0x253caa=0x0;_0x253caa<0x10;_0x253caa++)_0x47a440[_0x253caa]=_0x1476cd['charCodeAt'](_0xadcbc7)<<0x18|_0x1476cd['charCodeAt'](_0xadcbc7+0x1)<<0x10|_0x1476cd['charCodeAt'](_0xadcbc7+0x2)<<0x8|_0x1476cd['charCodeAt'](_0xadcbc7+0x3),_0xadcbc7+=0x4;}else{for(let _0x537c45=0x0;_0x537c45<0x10;_0x537c45++)_0x47a440[_0x537c45]=_0x1476cd[_0xadcbc7]<<0x18|_0x1476cd[_0xadcbc7+0x1]<<0x10|_0x1476cd[_0xadcbc7+0x2]<<0x8|_0x1476cd[_0xadcbc7+0x3],_0xadcbc7+=0x4;}for(let _0x51820e=0x10;_0x51820e<0x50;_0x51820e++){const _0x2bff9d=_0x47a440[_0x51820e-0x3]^_0x47a440[_0x51820e-0x8]^_0x47a440[_0x51820e-0xe]^_0x47a440[_0x51820e-0x10];_0x47a440[_0x51820e]=(_0x2bff9d<<0x1|_0x2bff9d>>>0x1f)&0xffffffff;}let _0x1baf88=this['chain_'][0x0],_0x14dfc7=this['chain_'][0x1],_0x351794=this['chain_'][0x2],_0x5dd91b=this['chain_'][0x3],_0x1becb7=this['chain_'][0x4],_0x22ed94,_0x4baaff;for(let _0x56bd41=0x0;_0x56bd41<0x50;_0x56bd41++){_0x56bd41<0x28?_0x56bd41<0x14?(_0x22ed94=_0x5dd91b^_0x14dfc7&(_0x351794^_0x5dd91b),_0x4baaff=0x5a827999):(_0x22ed94=_0x14dfc7^_0x351794^_0x5dd91b,_0x4baaff=0x6ed9eba1):_0x56bd41<0x3c?(_0x22ed94=_0x14dfc7&_0x351794|_0x5dd91b&(_0x14dfc7|_0x351794),_0x4baaff=0x8f1bbcdc):(_0x22ed94=_0x14dfc7^_0x351794^_0x5dd91b,_0x4baaff=0xca62c1d6);const _0x204d94=(_0x1baf88<<0x5|_0x1baf88>>>0x1b)+_0x22ed94+_0x1becb7+_0x4baaff+_0x47a440[_0x56bd41]&0xffffffff;_0x1becb7=_0x5dd91b,_0x5dd91b=_0x351794,_0x351794=(_0x14dfc7<<0x1e|_0x14dfc7>>>0x2)&0xffffffff,_0x14dfc7=_0x1baf88,_0x1baf88=_0x204d94;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1baf88&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x14dfc7&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x351794&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5dd91b&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1becb7&0xffffffff;}['update'](_0x27dca7,_0x5e53a4){if(_0x27dca7==null)return;_0x5e53a4===void 0x0&&(_0x5e53a4=_0x27dca7['length']);const _0x2d6270=_0x5e53a4-this['blockSize'];let _0x5215f8=0x0;const _0x304c1f=this['buf_'];let _0x268434=this['inbuf_'];for(;_0x5215f8<_0x5e53a4;){if(_0x268434===0x0){for(;_0x5215f8<=_0x2d6270;)this['compress_'](_0x27dca7,_0x5215f8),_0x5215f8+=this['blockSize'];}if(typeof _0x27dca7=='string'){for(;_0x5215f8<_0x5e53a4;)if(_0x304c1f[_0x268434]=_0x27dca7['charCodeAt'](_0x5215f8),++_0x268434,++_0x5215f8,_0x268434===this['blockSize']){this['compress_'](_0x304c1f),_0x268434=0x0;break;}}else{for(;_0x5215f8<_0x5e53a4;)if(_0x304c1f[_0x268434]=_0x27dca7[_0x5215f8],++_0x268434,++_0x5215f8,_0x268434===this['blockSize']){this['compress_'](_0x304c1f),_0x268434=0x0;break;}}}this['inbuf_']=_0x268434,this['total_']+=_0x5e53a4;}['digest'](){const _0x2b9b84=[];let _0x4fe6eb=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x22a83a=this['blockSize']-0x1;_0x22a83a>=0x38;_0x22a83a--)this['buf_'][_0x22a83a]=_0x4fe6eb&0xff,_0x4fe6eb/=0x100;this['compress_'](this['buf_']);let _0x342278=0x0;for(let _0x2aee91=0x0;_0x2aee91<0x5;_0x2aee91++)for(let _0x35996d=0x18;_0x35996d>=0x0;_0x35996d-=0x8)_0x2b9b84[_0x342278]=this['chain_'][_0x2aee91]>>_0x35996d&0xff,++_0x342278;return _0x2b9b84;}}function Ic(_0x1cf3f1,_0x4dd4d4){const _0x1beaf6=new wc(_0x1cf3f1,_0x4dd4d4);return _0x1beaf6['subscribe']['bind'](_0x1beaf6);}class wc{constructor(_0x3aee65,_0x2e494c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2e494c,this['task']['then'](()=>{_0x3aee65(this);})['catch'](_0x1e7519=>{this['error'](_0x1e7519);});}['next'](_0x4d1c4a){this['forEachObserver'](_0x5a230c=>{_0x5a230c['next'](_0x4d1c4a);});}['error'](_0x2cdea9){this['forEachObserver'](_0x47dec5=>{_0x47dec5['error'](_0x2cdea9);}),this['close'](_0x2cdea9);}['complete'](){this['forEachObserver'](_0x5f2548=>{_0x5f2548['complete']();}),this['close']();}['subscribe'](_0x456346,_0x36bec4,_0x90710d){let _0x464224;if(_0x456346===void 0x0&&_0x36bec4===void 0x0&&_0x90710d===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x456346,['next','error','complete'])?_0x464224=_0x456346:_0x464224={'next':_0x456346,'error':_0x36bec4,'complete':_0x90710d},_0x464224['next']===void 0x0&&(_0x464224['next']=Qn),_0x464224['error']===void 0x0&&(_0x464224['error']=Qn),_0x464224['complete']===void 0x0&&(_0x464224['complete']=Qn);const _0x4c983e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x464224['error'](this['finalError']):_0x464224['complete']();}catch{}}),this['observers']['push'](_0x464224),_0x4c983e;}['unsubscribeOne'](_0x1e46ac){this['observers']===void 0x0||this['observers'][_0x1e46ac]===void 0x0||(delete this['observers'][_0x1e46ac],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x32fa8a){if(!this['finalized']){for(let _0x292d22=0x0;_0x292d22<this['observers']['length'];_0x292d22++)this['sendOne'](_0x292d22,_0x32fa8a);}}['sendOne'](_0x256cb5,_0x4d6990){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x256cb5]!==void 0x0)try{_0x4d6990(this['observers'][_0x256cb5]);}catch(_0x14d84a){typeof console<'u'&&console['error']&&console['error'](_0x14d84a);}});}['close'](_0x338a87){this['finalized']||(this['finalized']=!0x0,_0x338a87!==void 0x0&&(this['finalError']=_0x338a87),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x29cff7,_0x37187c){if(typeof _0x29cff7!='object'||_0x29cff7===null)return!0x1;for(const _0x612a34 of _0x37187c)if(_0x612a34 in _0x29cff7&&typeof _0x29cff7[_0x612a34]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x1294b0,_0x48dd7a){return _0x1294b0+'\x20failed:\x20'+_0x48dd7a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x48a9a3){const _0x1eb848=[];let _0x3b7ec5=0x0;for(let _0x1e6ba3=0x0;_0x1e6ba3<_0x48a9a3['length'];_0x1e6ba3++){let _0x4a1a75=_0x48a9a3['charCodeAt'](_0x1e6ba3);if(_0x4a1a75>=0xd800&&_0x4a1a75<=0xdbff){const _0x2f3dbe=_0x4a1a75-0xd800;_0x1e6ba3++,f(_0x1e6ba3<_0x48a9a3['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5ef896=_0x48a9a3['charCodeAt'](_0x1e6ba3)-0xdc00;_0x4a1a75=0x10000+(_0x2f3dbe<<0xa)+_0x5ef896;}_0x4a1a75<0x80?_0x1eb848[_0x3b7ec5++]=_0x4a1a75:_0x4a1a75<0x800?(_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0x6|0xc0,_0x1eb848[_0x3b7ec5++]=_0x4a1a75&0x3f|0x80):_0x4a1a75<0x10000?(_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0xc|0xe0,_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0x6&0x3f|0x80,_0x1eb848[_0x3b7ec5++]=_0x4a1a75&0x3f|0x80):(_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0x12|0xf0,_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0xc&0x3f|0x80,_0x1eb848[_0x3b7ec5++]=_0x4a1a75>>0x6&0x3f|0x80,_0x1eb848[_0x3b7ec5++]=_0x4a1a75&0x3f|0x80);}return _0x1eb848;},Pn=function(_0x59a113){let _0x3f12=0x0;for(let _0x271d16=0x0;_0x271d16<_0x59a113['length'];_0x271d16++){const _0x1f2d6f=_0x59a113['charCodeAt'](_0x271d16);_0x1f2d6f<0x80?_0x3f12++:_0x1f2d6f<0x800?_0x3f12+=0x2:_0x1f2d6f>=0xd800&&_0x1f2d6f<=0xdbff?(_0x3f12+=0x4,_0x271d16++):_0x3f12+=0x3;}return _0x3f12;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x22fe07){return _0x22fe07&&_0x22fe07['_delegate']?_0x22fe07['_delegate']:_0x22fe07;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x4b6be5){try{return(_0x4b6be5['startsWith']('http://')||_0x4b6be5['startsWith']('https://')?new URL(_0x4b6be5)['hostname']:_0x4b6be5)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x32c880){return(await fetch(_0x32c880,{'credentials':'include'}))['ok'];}class Me{constructor(_0x120317,_0x22eff6,_0x58e5f9){this['name']=_0x120317,this['instanceFactory']=_0x22eff6,this['type']=_0x58e5f9,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0xf9bb7b){return this['instantiationMode']=_0xf9bb7b,this;}['setMultipleInstances'](_0x51c523){return this['multipleInstances']=_0x51c523,this;}['setServiceProps'](_0x4af085){return this['serviceProps']=_0x4af085,this;}['setInstanceCreatedCallback'](_0x45976e){return this['onInstanceCreated']=_0x45976e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x1b8726,_0x15ca6e){this['name']=_0x1b8726,this['container']=_0x15ca6e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4fa7dc){const _0x327fc1=this['normalizeInstanceIdentifier'](_0x4fa7dc);if(!this['instancesDeferred']['has'](_0x327fc1)){const _0xa6a70b=new Ve();if(this['instancesDeferred']['set'](_0x327fc1,_0xa6a70b),this['isInitialized'](_0x327fc1)||this['shouldAutoInitialize']())try{const _0x502954=this['getOrInitializeService']({'instanceIdentifier':_0x327fc1});_0x502954&&_0xa6a70b['resolve'](_0x502954);}catch{}}return this['instancesDeferred']['get'](_0x327fc1)['promise'];}['getImmediate'](_0x19226b){const _0x590f00=this['normalizeInstanceIdentifier'](_0x19226b==null?void 0x0:_0x19226b['identifier']),_0x4e083c=(_0x19226b==null?void 0x0:_0x19226b['optional'])??!0x1;if(this['isInitialized'](_0x590f00)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x590f00});}catch(_0x52339c){if(_0x4e083c)return null;throw _0x52339c;}else{if(_0x4e083c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x328053){if(_0x328053['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x328053['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x328053,!!this['shouldAutoInitialize']()){if(Rc(_0x328053))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x2672ac,_0x4a3478]of this['instancesDeferred']['entries']()){const _0x5c9591=this['normalizeInstanceIdentifier'](_0x2672ac);try{const _0x313006=this['getOrInitializeService']({'instanceIdentifier':_0x5c9591});_0x4a3478['resolve'](_0x313006);}catch{}}}}['clearInstance'](_0x207d2d=ke){this['instancesDeferred']['delete'](_0x207d2d),this['instancesOptions']['delete'](_0x207d2d),this['instances']['delete'](_0x207d2d);}async['delete'](){const _0x4e6598=Array['from'](this['instances']['values']());await Promise['all']([..._0x4e6598['filter'](_0x54fb2b=>'INTERNAL'in _0x54fb2b)['map'](_0x2eaf90=>_0x2eaf90['INTERNAL']['delete']()),..._0x4e6598['filter'](_0x34bd2b=>'_delete'in _0x34bd2b)['map'](_0x5901a4=>_0x5901a4['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x22153a=ke){return this['instances']['has'](_0x22153a);}['getOptions'](_0x224ab8=ke){return this['instancesOptions']['get'](_0x224ab8)||{};}['initialize'](_0x389e22={}){const {options:_0x3c8f6a={}}=_0x389e22,_0x2c3144=this['normalizeInstanceIdentifier'](_0x389e22['instanceIdentifier']);if(this['isInitialized'](_0x2c3144))throw Error(this['name']+'('+_0x2c3144+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x15b409=this['getOrInitializeService']({'instanceIdentifier':_0x2c3144,'options':_0x3c8f6a});for(const [_0x127642,_0x4c14bb]of this['instancesDeferred']['entries']()){const _0x2e9daa=this['normalizeInstanceIdentifier'](_0x127642);_0x2c3144===_0x2e9daa&&_0x4c14bb['resolve'](_0x15b409);}return _0x15b409;}['onInit'](_0x5a1316,_0x162a2e){const _0xc217b2=this['normalizeInstanceIdentifier'](_0x162a2e),_0x288c6b=this['onInitCallbacks']['get'](_0xc217b2)??new Set();_0x288c6b['add'](_0x5a1316),this['onInitCallbacks']['set'](_0xc217b2,_0x288c6b);const _0x12c8df=this['instances']['get'](_0xc217b2);return _0x12c8df&&_0x5a1316(_0x12c8df,_0xc217b2),()=>{_0x288c6b['delete'](_0x5a1316);};}['invokeOnInitCallbacks'](_0x342161,_0x1f9f5f){const _0xed87ca=this['onInitCallbacks']['get'](_0x1f9f5f);if(_0xed87ca){for(const _0x9e8453 of _0xed87ca)try{_0x9e8453(_0x342161,_0x1f9f5f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x35e22a,options:_0x203407={}}){let _0x160120=this['instances']['get'](_0x35e22a);if(!_0x160120&&this['component']&&(_0x160120=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x35e22a),'options':_0x203407}),this['instances']['set'](_0x35e22a,_0x160120),this['instancesOptions']['set'](_0x35e22a,_0x203407),this['invokeOnInitCallbacks'](_0x160120,_0x35e22a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x35e22a,_0x160120);}catch{}return _0x160120||null;}['normalizeInstanceIdentifier'](_0x3568c1=ke){return this['component']?this['component']['multipleInstances']?_0x3568c1:ke:_0x3568c1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x514925){return _0x514925===ke?void 0x0:_0x514925;}function Rc(_0x14c54b){return _0x14c54b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xf3c549){this['name']=_0xf3c549,this['providers']=new Map();}['addComponent'](_0x448f3d){const _0xee32d1=this['getProvider'](_0x448f3d['name']);if(_0xee32d1['isComponentSet']())throw new Error('Component\x20'+_0x448f3d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xee32d1['setComponent'](_0x448f3d);}['addOrOverwriteComponent'](_0x4c0aa0){this['getProvider'](_0x4c0aa0['name'])['isComponentSet']()&&this['providers']['delete'](_0x4c0aa0['name']),this['addComponent'](_0x4c0aa0);}['getProvider'](_0x336f40){if(this['providers']['has'](_0x336f40))return this['providers']['get'](_0x336f40);const _0x46f6df=new Sc(_0x336f40,this);return this['providers']['set'](_0x336f40,_0x46f6df),_0x46f6df;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4cac85){_0x4cac85[_0x4cac85['DEBUG']=0x0]='DEBUG',_0x4cac85[_0x4cac85['VERBOSE']=0x1]='VERBOSE',_0x4cac85[_0x4cac85['INFO']=0x2]='INFO',_0x4cac85[_0x4cac85['WARN']=0x3]='WARN',_0x4cac85[_0x4cac85['ERROR']=0x4]='ERROR',_0x4cac85[_0x4cac85['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x54e26b,_0x52cc77,..._0x4b26d1)=>{if(_0x52cc77<_0x54e26b['logLevel'])return;const _0x35fc94=new Date()['toISOString'](),_0x309424=Pc[_0x52cc77];if(_0x309424)console[_0x309424]('['+_0x35fc94+']\x20\x20'+_0x54e26b['name']+':',..._0x4b26d1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x52cc77+')');};class xi{constructor(_0x224891){this['name']=_0x224891,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xc87030){if(!(_0xc87030 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xc87030+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xc87030;}['setLogLevel'](_0x5881c9){this['_logLevel']=typeof _0x5881c9=='string'?kc[_0x5881c9]:_0x5881c9;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4e67c5){if(typeof _0x4e67c5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4e67c5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x55677d){this['_userLogHandler']=_0x55677d;}['debug'](..._0x3f38ee){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3f38ee),this['_logHandler'](this,T['DEBUG'],..._0x3f38ee);}['log'](..._0x1b7c93){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1b7c93),this['_logHandler'](this,T['VERBOSE'],..._0x1b7c93);}['info'](..._0x30be4e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x30be4e),this['_logHandler'](this,T['INFO'],..._0x30be4e);}['warn'](..._0x7dcfb6){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x7dcfb6),this['_logHandler'](this,T['WARN'],..._0x7dcfb6);}['error'](..._0x463ba5){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x463ba5),this['_logHandler'](this,T['ERROR'],..._0x463ba5);}}const Dc=(_0x467c6f,_0x55e4e2)=>_0x55e4e2['some'](_0x13e3b2=>_0x467c6f instanceof _0x13e3b2);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x167dad){const _0x5b5c20=new Promise((_0x368b6e,_0x386baf)=>{const _0x969976=()=>{_0x167dad['removeEventListener']('success',_0x4a08a8),_0x167dad['removeEventListener']('error',_0x5e38ce);},_0x4a08a8=()=>{_0x368b6e(_e(_0x167dad['result'])),_0x969976();},_0x5e38ce=()=>{_0x386baf(_0x167dad['error']),_0x969976();};_0x167dad['addEventListener']('success',_0x4a08a8),_0x167dad['addEventListener']('error',_0x5e38ce);});return _0x5b5c20['then'](_0x1f5796=>{_0x1f5796 instanceof IDBCursor&&Kr['set'](_0x1f5796,_0x167dad);})['catch'](()=>{}),Fi['set'](_0x5b5c20,_0x167dad),_0x5b5c20;}function Fc(_0x299036){if(ui['has'](_0x299036))return;const _0x474845=new Promise((_0x1d78ef,_0xa994ef)=>{const _0x3de705=()=>{_0x299036['removeEventListener']('complete',_0x464fdd),_0x299036['removeEventListener']('error',_0x59ceca),_0x299036['removeEventListener']('abort',_0x59ceca);},_0x464fdd=()=>{_0x1d78ef(),_0x3de705();},_0x59ceca=()=>{_0xa994ef(_0x299036['error']||new DOMException('AbortError','AbortError')),_0x3de705();};_0x299036['addEventListener']('complete',_0x464fdd),_0x299036['addEventListener']('error',_0x59ceca),_0x299036['addEventListener']('abort',_0x59ceca);});ui['set'](_0x299036,_0x474845);}let di={'get'(_0x3f18c5,_0x18a37d,_0x13659f){if(_0x3f18c5 instanceof IDBTransaction){if(_0x18a37d==='done')return ui['get'](_0x3f18c5);if(_0x18a37d==='objectStoreNames')return _0x3f18c5['objectStoreNames']||Yr['get'](_0x3f18c5);if(_0x18a37d==='store')return _0x13659f['objectStoreNames'][0x1]?void 0x0:_0x13659f['objectStore'](_0x13659f['objectStoreNames'][0x0]);}return _e(_0x3f18c5[_0x18a37d]);},'set'(_0x5a5e6e,_0x2f4d49,_0x53c55d){return _0x5a5e6e[_0x2f4d49]=_0x53c55d,!0x0;},'has'(_0x429320,_0x449b23){return _0x429320 instanceof IDBTransaction&&(_0x449b23==='done'||_0x449b23==='store')?!0x0:_0x449b23 in _0x429320;}};function Uc(_0x49ef52){di=_0x49ef52(di);}function Wc(_0x276f9d){return _0x276f9d===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x29f11a,..._0x3aaef2){const _0x34ba5c=_0x276f9d['call'](Xn(this),_0x29f11a,..._0x3aaef2);return Yr['set'](_0x34ba5c,_0x29f11a['sort']?_0x29f11a['sort']():[_0x29f11a]),_e(_0x34ba5c);}:Lc()['includes'](_0x276f9d)?function(..._0x3f9c99){return _0x276f9d['apply'](Xn(this),_0x3f9c99),_e(Kr['get'](this));}:function(..._0x2a4674){return _e(_0x276f9d['apply'](Xn(this),_0x2a4674));};}function Bc(_0x38f54c){return typeof _0x38f54c=='function'?Wc(_0x38f54c):(_0x38f54c instanceof IDBTransaction&&Fc(_0x38f54c),Dc(_0x38f54c,Mc())?new Proxy(_0x38f54c,di):_0x38f54c);}function _e(_0x5315a5){if(_0x5315a5 instanceof IDBRequest)return xc(_0x5315a5);if(Jn['has'](_0x5315a5))return Jn['get'](_0x5315a5);const _0x592317=Bc(_0x5315a5);return _0x592317!==_0x5315a5&&(Jn['set'](_0x5315a5,_0x592317),Fi['set'](_0x592317,_0x5315a5)),_0x592317;}const Xn=_0x4359ce=>Fi['get'](_0x4359ce);function Vc(_0x44adea,_0x33db70,{blocked:_0x513843,upgrade:_0xeb2f79,blocking:_0x27852f,terminated:_0x37e1c5}={}){const _0x5d6257=indexedDB['open'](_0x44adea,_0x33db70),_0x28288c=_e(_0x5d6257);return _0xeb2f79&&_0x5d6257['addEventListener']('upgradeneeded',_0x7e02cd=>{_0xeb2f79(_e(_0x5d6257['result']),_0x7e02cd['oldVersion'],_0x7e02cd['newVersion'],_e(_0x5d6257['transaction']),_0x7e02cd);}),_0x513843&&_0x5d6257['addEventListener']('blocked',_0x2be738=>_0x513843(_0x2be738['oldVersion'],_0x2be738['newVersion'],_0x2be738)),_0x28288c['then'](_0x3156e8=>{_0x37e1c5&&_0x3156e8['addEventListener']('close',()=>_0x37e1c5()),_0x27852f&&_0x3156e8['addEventListener']('versionchange',_0x9e7356=>_0x27852f(_0x9e7356['oldVersion'],_0x9e7356['newVersion'],_0x9e7356));})['catch'](()=>{}),_0x28288c;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x132691,_0xf78cf4){if(!(_0x132691 instanceof IDBDatabase&&!(_0xf78cf4 in _0x132691)&&typeof _0xf78cf4=='string'))return;if(Zn['get'](_0xf78cf4))return Zn['get'](_0xf78cf4);const _0xe5ffb2=_0xf78cf4['replace'](/FromIndex$/,''),_0x5db4bd=_0xf78cf4!==_0xe5ffb2,_0x468a78=$c['includes'](_0xe5ffb2);if(!(_0xe5ffb2 in(_0x5db4bd?IDBIndex:IDBObjectStore)['prototype'])||!(_0x468a78||Hc['includes'](_0xe5ffb2)))return;const _0x1e0855=async function(_0x291fa3,..._0x1020a0){const _0x387e5a=this['transaction'](_0x291fa3,_0x468a78?'readwrite':'readonly');let _0x44c432=_0x387e5a['store'];return _0x5db4bd&&(_0x44c432=_0x44c432['index'](_0x1020a0['shift']())),(await Promise['all']([_0x44c432[_0xe5ffb2](..._0x1020a0),_0x468a78&&_0x387e5a['done']]))[0x0];};return Zn['set'](_0xf78cf4,_0x1e0855),_0x1e0855;}Uc(_0x2ff345=>({..._0x2ff345,'get':(_0x216325,_0x404495,_0x1dc1e0)=>Os(_0x216325,_0x404495)||_0x2ff345['get'](_0x216325,_0x404495,_0x1dc1e0),'has':(_0x510c51,_0x3c390f)=>!!Os(_0x510c51,_0x3c390f)||_0x2ff345['has'](_0x510c51,_0x3c390f)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x48454c){this['container']=_0x48454c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x57cfea=>{if(qc(_0x57cfea)){const _0x221be1=_0x57cfea['getImmediate']();return _0x221be1['library']+'/'+_0x221be1['version'];}else return null;})['filter'](_0x5f0d91=>_0x5f0d91)['join']('\x20');}}function qc(_0x27b9e9){const _0x56e5de=_0x27b9e9['getComponent']();return(_0x56e5de==null?void 0x0:_0x56e5de['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x25fa5b,_0x540314){try{_0x25fa5b['container']['addComponent'](_0x540314);}catch(_0x3ce729){re['debug']('Component\x20'+_0x540314['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x25fa5b['name'],_0x3ce729);}}function et(_0x146a7b){const _0x29f368=_0x146a7b['name'];if(gi['has'](_0x29f368))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x29f368+'.'),!0x1;gi['set'](_0x29f368,_0x146a7b);for(const _0x6b4fda of Le['values']())Ms(_0x6b4fda,_0x146a7b);for(const _0x5b6b40 of _i['values']())Ms(_0x5b6b40,_0x146a7b);return!0x0;}function Ui(_0xfb2992,_0x5bc20a){const _0x259829=_0xfb2992['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x259829&&_0x259829['triggerHeartbeat'](),_0xfb2992['container']['getProvider'](_0x5bc20a);}function H(_0x40bcac){return _0x40bcac==null?!0x1:_0x40bcac['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x215b2e,_0x512466,_0x29a8ee){this['_isDeleted']=!0x1,this['_options']={..._0x215b2e},this['_config']={..._0x512466},this['_name']=_0x512466['name'],this['_automaticDataCollectionEnabled']=_0x512466['automaticDataCollectionEnabled'],this['_container']=_0x29a8ee,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x7ff35c){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x7ff35c;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x273e3e){this['_isDeleted']=_0x273e3e;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5e8c07,_0x2e6175={}){let _0x430820=_0x5e8c07;typeof _0x2e6175!='object'&&(_0x2e6175={'name':_0x2e6175});const _0x30177e={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2e6175},_0x54691e=_0x30177e['name'];if(typeof _0x54691e!='string'||!_0x54691e)throw ge['create']('bad-app-name',{'appName':String(_0x54691e)});if(_0x430820||(_0x430820=$r()),!_0x430820)throw ge['create']('no-options');const _0x427ec4=Le['get'](_0x54691e);if(_0x427ec4){if(De(_0x430820,_0x427ec4['options'])&&De(_0x30177e,_0x427ec4['config']))return _0x427ec4;throw ge['create']('duplicate-app',{'appName':_0x54691e});}const _0x400608=new Ac(_0x54691e);for(const _0x235bbc of gi['values']())_0x400608['addComponent'](_0x235bbc);const _0x48e38f=new Il(_0x430820,_0x30177e,_0x400608);return Le['set'](_0x54691e,_0x48e38f),_0x48e38f;}function Qr(_0x245db4=pi){const _0x500e35=Le['get'](_0x245db4);if(!_0x500e35&&_0x245db4===pi&&$r())return wl();if(!_0x500e35)throw ge['create']('no-app',{'appName':_0x245db4});return _0x500e35;}function l_(){return Array['from'](Le['values']());}async function h_(_0x20d99a){let _0x139bf1=!0x1;const _0x73d760=_0x20d99a['name'];Le['has'](_0x73d760)?(_0x139bf1=!0x0,Le['delete'](_0x73d760)):_i['has'](_0x73d760)&&_0x20d99a['decRefCount']()<=0x0&&(_i['delete'](_0x73d760),_0x139bf1=!0x0),_0x139bf1&&(await Promise['all'](_0x20d99a['container']['getProviders']()['map'](_0x329e1a=>_0x329e1a['delete']())),_0x20d99a['isDeleted']=!0x0);}function me(_0x480b44,_0xb52dca,_0x219e27){let _0x246a7c=vl[_0x480b44]??_0x480b44;_0x219e27&&(_0x246a7c+='-'+_0x219e27);const _0x192d96=_0x246a7c['match'](/\s|\//),_0x11c8b8=_0xb52dca['match'](/\s|\//);if(_0x192d96||_0x11c8b8){const _0x292e4b=['Unable\x20to\x20register\x20library\x20\x22'+_0x246a7c+'\x22\x20with\x20version\x20\x22'+_0xb52dca+'\x22:'];_0x192d96&&_0x292e4b['push']('library\x20name\x20\x22'+_0x246a7c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x192d96&&_0x11c8b8&&_0x292e4b['push']('and'),_0x11c8b8&&_0x292e4b['push']('version\x20name\x20\x22'+_0xb52dca+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x292e4b['join']('\x20'));return;}et(new Me(_0x246a7c+'-version',()=>({'library':_0x246a7c,'version':_0xb52dca}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4ba889,_0x1ed61c)=>{switch(_0x1ed61c){case 0x0:try{_0x4ba889['createObjectStore'](Rt);}catch(_0x30ddf0){console['warn'](_0x30ddf0);}}}})['catch'](_0x528dbb=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x528dbb['message']});})),ei;}async function Sl(_0x2343e2){try{const _0x2a38f7=(await Jr())['transaction'](Rt),_0x420f11=await _0x2a38f7['objectStore'](Rt)['get'](Xr(_0x2343e2));return await _0x2a38f7['done'],_0x420f11;}catch(_0x161883){if(_0x161883 instanceof Se)re['warn'](_0x161883['message']);else{const _0x2e52dc=ge['create']('idb-get',{'originalErrorMessage':_0x161883==null?void 0x0:_0x161883['message']});re['warn'](_0x2e52dc['message']);}}}async function Ls(_0x2dfdc2,_0x1ee373){try{const _0x5d8387=(await Jr())['transaction'](Rt,'readwrite');await _0x5d8387['objectStore'](Rt)['put'](_0x1ee373,Xr(_0x2dfdc2)),await _0x5d8387['done'];}catch(_0x34fbe9){if(_0x34fbe9 instanceof Se)re['warn'](_0x34fbe9['message']);else{const _0x471770=ge['create']('idb-set',{'originalErrorMessage':_0x34fbe9==null?void 0x0:_0x34fbe9['message']});re['warn'](_0x471770['message']);}}}function Xr(_0x5143f1){return _0x5143f1['name']+'!'+_0x5143f1['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x533579){this['container']=_0x533579,this['_heartbeatsCache']=null;const _0x542e60=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x542e60),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x37a4e6=>(this['_heartbeatsCache']=_0x37a4e6,_0x37a4e6));}async['triggerHeartbeat'](){var _0x2e2a29,_0x330612;try{const _0x3745af=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x13fd66=xs();if(((_0x2e2a29=this['_heartbeatsCache'])==null?void 0x0:_0x2e2a29['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x330612=this['_heartbeatsCache'])==null?void 0x0:_0x330612['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x13fd66||this['_heartbeatsCache']['heartbeats']['some'](_0x318a3a=>_0x318a3a['date']===_0x13fd66))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x13fd66,'agent':_0x3745af}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x196a52=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x196a52,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x24ba22){re['warn'](_0x24ba22);}}async['getHeartbeatsHeader'](){var _0x10ede7;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x10ede7=this['_heartbeatsCache'])==null?void 0x0:_0x10ede7['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5236e0=xs(),{heartbeatsToSend:_0x46040d,unsentEntries:_0x3aa2d0}=kl(this['_heartbeatsCache']['heartbeats']),_0x4bb24e=an(JSON['stringify']({'version':0x2,'heartbeats':_0x46040d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5236e0,_0x3aa2d0['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3aa2d0,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4bb24e;}catch(_0x490d18){return re['warn'](_0x490d18),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x453eb8,_0x3ad084=bl){const _0x226ca5=[];let _0x2ec0ee=_0x453eb8['slice']();for(const _0x80ffa1 of _0x453eb8){const _0x1a5e7f=_0x226ca5['find'](_0x5d046c=>_0x5d046c['agent']===_0x80ffa1['agent']);if(_0x1a5e7f){if(_0x1a5e7f['dates']['push'](_0x80ffa1['date']),Fs(_0x226ca5)>_0x3ad084){_0x1a5e7f['dates']['pop']();break;}}else{if(_0x226ca5['push']({'agent':_0x80ffa1['agent'],'dates':[_0x80ffa1['date']]}),Fs(_0x226ca5)>_0x3ad084){_0x226ca5['pop']();break;}}_0x2ec0ee=_0x2ec0ee['slice'](0x1);}return{'heartbeatsToSend':_0x226ca5,'unsentEntries':_0x2ec0ee};}class Nl{constructor(_0x57df31){this['app']=_0x57df31,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xee63fb=await Sl(this['app']);return _0xee63fb!=null&&_0xee63fb['heartbeats']?_0xee63fb:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x39b589){if(await this['_canUseIndexedDBPromise']){const _0x178437=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x39b589['lastSentHeartbeatDate']??_0x178437['lastSentHeartbeatDate'],'heartbeats':_0x39b589['heartbeats']});}else return;}async['add'](_0x5ee834){if(await this['_canUseIndexedDBPromise']){const _0x3889ef=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5ee834['lastSentHeartbeatDate']??_0x3889ef['lastSentHeartbeatDate'],'heartbeats':[..._0x3889ef['heartbeats'],..._0x5ee834['heartbeats']]});}else return;}}function Fs(_0x196f57){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x196f57}))['length'];}function Pl(_0x3f9ddf){if(_0x3f9ddf['length']===0x0)return-0x1;let _0x341380=0x0,_0x3d0459=_0x3f9ddf[0x0]['date'];for(let _0x54aac5=0x1;_0x54aac5<_0x3f9ddf['length'];_0x54aac5++)_0x3f9ddf[_0x54aac5]['date']<_0x3d0459&&(_0x3d0459=_0x3f9ddf[_0x54aac5]['date'],_0x341380=_0x54aac5);return _0x341380;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4ec0b6){et(new Me('platform-logger',_0xec1ed1=>new Gc(_0xec1ed1),'PRIVATE')),et(new Me('heartbeat',_0x440df0=>new Al(_0x440df0),'PRIVATE')),me(fi,Ds,_0x4ec0b6),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x3f8e45){Zr=_0x3f8e45;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1ff73b){this['domStorage_']=_0x1ff73b,this['prefix_']='firebase:';}['set'](_0x4e3fda,_0x3d261c){_0x3d261c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4e3fda)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4e3fda),O(_0x3d261c));}['get'](_0x114545){const _0x49840a=this['domStorage_']['getItem'](this['prefixedName_'](_0x114545));return _0x49840a==null?null:bt(_0x49840a);}['remove'](_0x22d885){this['domStorage_']['removeItem'](this['prefixedName_'](_0x22d885));}['prefixedName_'](_0x182440){return this['prefix_']+_0x182440;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2bab50,_0x50564f){_0x50564f==null?delete this['cache_'][_0x2bab50]:this['cache_'][_0x2bab50]=_0x50564f;}['get'](_0x114da1){return Y(this['cache_'],_0x114da1)?this['cache_'][_0x114da1]:null;}['remove'](_0x11f8ca){delete this['cache_'][_0x11f8ca];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x26d773){try{if(typeof window<'u'&&typeof window[_0x26d773]<'u'){const _0x383990=window[_0x26d773];return _0x383990['setItem']('firebase:sentinel','cache'),_0x383990['removeItem']('firebase:sentinel'),new xl(_0x383990);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x2cf457=0x1;return function(){return _0x2cf457++;};}()),no=function(_0x323b3c){const _0x378494=Tc(_0x323b3c),_0x560c14=new Ec();_0x560c14['update'](_0x378494);const _0x23bb38=_0x560c14['digest']();return Di['encodeByteArray'](_0x23bb38);},Bt=function(..._0x35af09){let _0x3c7d61='';for(let _0x395f3e=0x0;_0x395f3e<_0x35af09['length'];_0x395f3e++){const _0x210271=_0x35af09[_0x395f3e];Array['isArray'](_0x210271)||_0x210271&&typeof _0x210271=='object'&&typeof _0x210271['length']=='number'?_0x3c7d61+=Bt['apply'](null,_0x210271):typeof _0x210271=='object'?_0x3c7d61+=O(_0x210271):_0x3c7d61+=_0x210271,_0x3c7d61+='\x20';}return _0x3c7d61;};let Et=null,Vs=!0x0;const Wl=function(_0x4f70f4,_0x583a7){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x51f1b6){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x5eb1d4=Bt['apply'](null,_0x51f1b6);Et(_0x5eb1d4);}},Vt=function(_0xab7ff1){return function(..._0x2c87a3){L(_0xab7ff1,..._0x2c87a3);};},mi=function(..._0x3074da){const _0x175994='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x3074da);Qe['error'](_0x175994);},oe=function(..._0x40da9d){const _0x4813d3='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x40da9d);throw Qe['error'](_0x4813d3),new Error(_0x4813d3);},U=function(..._0x4cf7fa){const _0x35becb='FIREBASE\x20WARNING:\x20'+Bt(..._0x4cf7fa);Qe['warn'](_0x35becb);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x3b55fb){return typeof _0x3b55fb=='number'&&(_0x3b55fb!==_0x3b55fb||_0x3b55fb===Number['POSITIVE_INFINITY']||_0x3b55fb===Number['NEGATIVE_INFINITY']);},Vl=function(_0xb01881){if(document['readyState']==='complete')_0xb01881();else{let _0xba06b4=!0x1;const _0x1cb090=function(){if(!document['body']){setTimeout(_0x1cb090,Math['floor'](0xa));return;}_0xba06b4||(_0xba06b4=!0x0,_0xb01881());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1cb090,!0x1),window['addEventListener']('load',_0x1cb090,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1cb090();}),window['attachEvent']('onload',_0x1cb090));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x32eadd,_0x1e1ff8){if(_0x32eadd===_0x1e1ff8)return 0x0;if(_0x32eadd===xe||_0x1e1ff8===Ie)return-0x1;if(_0x1e1ff8===xe||_0x32eadd===Ie)return 0x1;{const _0x44a89f=Hs(_0x32eadd),_0x4a60cd=Hs(_0x1e1ff8);return _0x44a89f!==null?_0x4a60cd!==null?_0x44a89f-_0x4a60cd===0x0?_0x32eadd['length']-_0x1e1ff8['length']:_0x44a89f-_0x4a60cd:-0x1:_0x4a60cd!==null?0x1:_0x32eadd<_0x1e1ff8?-0x1:0x1;}},Hl=function(_0x5789fa,_0x266ee7){return _0x5789fa===_0x266ee7?0x0:_0x5789fa<_0x266ee7?-0x1:0x1;},pt=function(_0x13a438,_0x55445f){if(_0x55445f&&_0x13a438 in _0x55445f)return _0x55445f[_0x13a438];throw new Error('Missing\x20required\x20key\x20('+_0x13a438+')\x20in\x20object:\x20'+O(_0x55445f));},Bi=function(_0x251fe5){if(typeof _0x251fe5!='object'||_0x251fe5===null)return O(_0x251fe5);const _0x58d847=[];for(const _0x5c6a92 in _0x251fe5)_0x58d847['push'](_0x5c6a92);_0x58d847['sort']();let _0x305782='{';for(let _0x484604=0x0;_0x484604<_0x58d847['length'];_0x484604++)_0x484604!==0x0&&(_0x305782+=','),_0x305782+=O(_0x58d847[_0x484604]),_0x305782+=':',_0x305782+=Bi(_0x251fe5[_0x58d847[_0x484604]]);return _0x305782+='}',_0x305782;},io=function(_0x1f8e3f,_0x1ff387){const _0x40339a=_0x1f8e3f['length'];if(_0x40339a<=_0x1ff387)return[_0x1f8e3f];const _0xa8561d=[];for(let _0xf136d9=0x0;_0xf136d9<_0x40339a;_0xf136d9+=_0x1ff387)_0xf136d9+_0x1ff387>_0x40339a?_0xa8561d['push'](_0x1f8e3f['substring'](_0xf136d9,_0x40339a)):_0xa8561d['push'](_0x1f8e3f['substring'](_0xf136d9,_0xf136d9+_0x1ff387));return _0xa8561d;};function x(_0x11e7a1,_0x115145){for(const _0x55bf45 in _0x11e7a1)_0x11e7a1['hasOwnProperty'](_0x55bf45)&&_0x115145(_0x55bf45,_0x11e7a1[_0x55bf45]);}const so=function(_0x3afa7c){f(!Wi(_0x3afa7c),'Invalid\x20JSON\x20number');const _0x107c00=0xb,_0x2e421b=0x34,_0x48e188=(0x1<<_0x107c00-0x1)-0x1;let _0x4818a3,_0x1df7b7,_0x5bfb8d,_0x536932,_0x817d0e;_0x3afa7c===0x0?(_0x1df7b7=0x0,_0x5bfb8d=0x0,_0x4818a3=0x1/_0x3afa7c===-0x1/0x0?0x1:0x0):(_0x4818a3=_0x3afa7c<0x0,_0x3afa7c=Math['abs'](_0x3afa7c),_0x3afa7c>=Math['pow'](0x2,0x1-_0x48e188)?(_0x536932=Math['min'](Math['floor'](Math['log'](_0x3afa7c)/Math['LN2']),_0x48e188),_0x1df7b7=_0x536932+_0x48e188,_0x5bfb8d=Math['round'](_0x3afa7c*Math['pow'](0x2,_0x2e421b-_0x536932)-Math['pow'](0x2,_0x2e421b))):(_0x1df7b7=0x0,_0x5bfb8d=Math['round'](_0x3afa7c/Math['pow'](0x2,0x1-_0x48e188-_0x2e421b))));const _0x1f9f52=[];for(_0x817d0e=_0x2e421b;_0x817d0e;_0x817d0e-=0x1)_0x1f9f52['push'](_0x5bfb8d%0x2?0x1:0x0),_0x5bfb8d=Math['floor'](_0x5bfb8d/0x2);for(_0x817d0e=_0x107c00;_0x817d0e;_0x817d0e-=0x1)_0x1f9f52['push'](_0x1df7b7%0x2?0x1:0x0),_0x1df7b7=Math['floor'](_0x1df7b7/0x2);_0x1f9f52['push'](_0x4818a3?0x1:0x0),_0x1f9f52['reverse']();const _0x691667=_0x1f9f52['join']('');let _0x1f5abf='';for(_0x817d0e=0x0;_0x817d0e<0x40;_0x817d0e+=0x8){let _0x522487=parseInt(_0x691667['substr'](_0x817d0e,0x8),0x2)['toString'](0x10);_0x522487['length']===0x1&&(_0x522487='0'+_0x522487),_0x1f5abf=_0x1f5abf+_0x522487;}return _0x1f5abf['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2e68e2,_0x82a0ee){let _0x5a8a78='Unknown\x20Error';_0x2e68e2==='too_big'?_0x5a8a78='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2e68e2==='permission_denied'?_0x5a8a78='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2e68e2==='unavailable'&&(_0x5a8a78='The\x20service\x20is\x20unavailable');const _0x265128=new Error(_0x2e68e2+'\x20at\x20'+_0x82a0ee['_path']['toString']()+':\x20'+_0x5a8a78);return _0x265128['code']=_0x2e68e2['toUpperCase'](),_0x265128;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0xed655d){if(zl['test'](_0xed655d)){const _0x4406b3=Number(_0xed655d);if(_0x4406b3>=jl&&_0x4406b3<=Kl)return _0x4406b3;}return null;},lt=function(_0xe4805){try{_0xe4805();}catch(_0x2d5b76){setTimeout(()=>{const _0x1d9b92=_0x2d5b76['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1d9b92),_0x2d5b76;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4227d8,_0x23d5c5){const _0x1cbc86=setTimeout(_0x4227d8,_0x23d5c5);return typeof _0x1cbc86=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1cbc86):typeof _0x1cbc86=='object'&&_0x1cbc86['unref']&&_0x1cbc86['unref'](),_0x1cbc86;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x196db9,_0x4abbc8){this['appCheckProvider']=_0x4abbc8,this['appName']=_0x196db9['name'],H(_0x196db9)&&_0x196db9['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x196db9['settings']['appCheckToken']),this['appCheck']=_0x4abbc8==null?void 0x0:_0x4abbc8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4abbc8==null||_0x4abbc8['get']()['then'](_0x168cb5=>this['appCheck']=_0x168cb5);}['getToken'](_0x88c505){if(this['serverAppAppCheckToken']){if(_0x88c505)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x88c505):new Promise((_0x4390f,_0x518f3c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x88c505)['then'](_0x4390f,_0x518f3c):_0x4390f(null);},0x0);});}['addTokenChangeListener'](_0x51fd3e){var _0x3dd00f;(_0x3dd00f=this['appCheckProvider'])==null||_0x3dd00f['get']()['then'](_0x3d4cfc=>_0x3d4cfc['addTokenListener'](_0x51fd3e));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x253ea7,_0x539c08,_0x33f968){this['appName_']=_0x253ea7,this['firebaseOptions_']=_0x539c08,this['authProvider_']=_0x33f968,this['auth_']=null,this['auth_']=_0x33f968['getImmediate']({'optional':!0x0}),this['auth_']||_0x33f968['onInit'](_0x3d2a8c=>this['auth_']=_0x3d2a8c);}['getToken'](_0x3d62f7){return this['auth_']?this['auth_']['getToken'](_0x3d62f7)['catch'](_0x4e0b30=>_0x4e0b30&&_0x4e0b30['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4e0b30)):new Promise((_0x2bb23a,_0x323906)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3d62f7)['then'](_0x2bb23a,_0x323906):_0x2bb23a(null);},0x0);});}['addTokenChangeListener'](_0x365d1c){this['auth_']?this['auth_']['addAuthTokenListener'](_0x365d1c):this['authProvider_']['get']()['then'](_0x46d830=>_0x46d830['addAuthTokenListener'](_0x365d1c));}['removeTokenChangeListener'](_0x43968d){this['authProvider_']['get']()['then'](_0x356e21=>_0x356e21['removeAuthTokenListener'](_0x43968d));}['notifyForInvalidToken'](){let _0x45c87b='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x45c87b+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x45c87b+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x45c87b+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x45c87b);}}class tn{constructor(_0x56985e){this['accessToken']=_0x56985e;}['getToken'](_0x1ccad2){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x330130){_0x330130(this['accessToken']);}['removeTokenChangeListener'](_0x2dc03a){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x3c5d0d,_0x2f0bd4,_0x307496,_0x2482dc,_0x32d244=!0x1,_0x557f18='',_0x1f8302=!0x1,_0x2da8be=!0x1,_0x224b0c=null){this['secure']=_0x2f0bd4,this['namespace']=_0x307496,this['webSocketOnly']=_0x2482dc,this['nodeAdmin']=_0x32d244,this['persistenceKey']=_0x557f18,this['includeNamespaceInQueryParams']=_0x1f8302,this['isUsingEmulator']=_0x2da8be,this['emulatorOptions']=_0x224b0c,this['_host']=_0x3c5d0d['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x3c5d0d)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x37c47d){_0x37c47d!==this['internalHost']&&(this['internalHost']=_0x37c47d,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x593269=this['toURLString']();return this['persistenceKey']&&(_0x593269+='<'+this['persistenceKey']+'>'),_0x593269;}['toURLString'](){const _0x3f93fd=this['secure']?'https://':'http://',_0x4ea577=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3f93fd+this['host']+'/'+_0x4ea577;}}function Xl(_0x529ad2){return _0x529ad2['host']!==_0x529ad2['internalHost']||_0x529ad2['isCustomHost']()||_0x529ad2['includeNamespaceInQueryParams'];}function go(_0x1b3259,_0x449cb3,_0x34c017){f(typeof _0x449cb3=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x34c017=='object','typeof\x20params\x20must\x20==\x20object');let _0x2bf2ed;if(_0x449cb3===fo)_0x2bf2ed=(_0x1b3259['secure']?'wss://':'ws://')+_0x1b3259['internalHost']+'/.ws?';else{if(_0x449cb3===po)_0x2bf2ed=(_0x1b3259['secure']?'https://':'http://')+_0x1b3259['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x449cb3);}Xl(_0x1b3259)&&(_0x34c017['ns']=_0x1b3259['namespace']);const _0x9e95f0=[];return x(_0x34c017,(_0x37228e,_0x1fe043)=>{_0x9e95f0['push'](_0x37228e+'='+_0x1fe043);}),_0x2bf2ed+_0x9e95f0['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0xd976d2,_0x11099c=0x1){Y(this['counters_'],_0xd976d2)||(this['counters_'][_0xd976d2]=0x0),this['counters_'][_0xd976d2]+=_0x11099c;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x3bf8e5){const _0x5e179e=_0x3bf8e5['toString']();return ti[_0x5e179e]||(ti[_0x5e179e]=new Zl()),ti[_0x5e179e];}function eh(_0x4ac0ee,_0x5b38eb){const _0x13ed00=_0x4ac0ee['toString']();return ni[_0x13ed00]||(ni[_0x13ed00]=_0x5b38eb()),ni[_0x13ed00];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x505892){this['onMessage_']=_0x505892,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xe0bb1,_0x4dc82e){this['closeAfterResponse']=_0xe0bb1,this['onClose']=_0x4dc82e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1ca67c,_0x1f6b3b){for(this['pendingResponses'][_0x1ca67c]=_0x1f6b3b;this['pendingResponses'][this['currentResponseNum']];){const _0x194888=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x442b25=0x0;_0x442b25<_0x194888['length'];++_0x442b25)_0x194888[_0x442b25]&&lt(()=>{this['onMessage_'](_0x194888[_0x442b25]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2bbba0,_0x3b5cf5,_0x572979,_0x200460,_0x4678f9,_0x89f559,_0x51184f){this['connId']=_0x2bbba0,this['repoInfo']=_0x3b5cf5,this['applicationId']=_0x572979,this['appCheckToken']=_0x200460,this['authToken']=_0x4678f9,this['transportSessionId']=_0x89f559,this['lastSessionId']=_0x51184f,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2bbba0),this['stats_']=Hi(_0x3b5cf5),this['urlFn']=_0x7935ef=>(this['appCheckToken']&&(_0x7935ef[yi]=this['appCheckToken']),go(_0x3b5cf5,po,_0x7935ef));}['open'](_0xfb557f,_0x109d28){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x109d28,this['myPacketOrderer']=new th(_0xfb557f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x17b957)=>{const [_0x3f15e9,_0xbaa1b9,_0x9f580f,_0x1d6941,_0x1d0808]=_0x17b957;if(this['incrementIncomingBytes_'](_0x17b957),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3f15e9===$s)this['id']=_0xbaa1b9,this['password']=_0x9f580f;else{if(_0x3f15e9===nh)_0xbaa1b9?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xbaa1b9,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3f15e9);}}},(..._0x49dc3e)=>{const [_0x1b393f,_0x2e493f]=_0x49dc3e;this['incrementIncomingBytes_'](_0x49dc3e),this['myPacketOrderer']['handleResponse'](_0x1b393f,_0x2e493f);},()=>{this['onClosed_']();},this['urlFn']);const _0x48eabf={};_0x48eabf[$s]='t',_0x48eabf[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x48eabf[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x48eabf[ro]=Vi,this['transportSessionId']&&(_0x48eabf[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x48eabf[ho]=this['lastSessionId']),this['applicationId']&&(_0x48eabf[uo]=this['applicationId']),this['appCheckToken']&&(_0x48eabf[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x48eabf[ao]=co);const _0x2458cd=this['urlFn'](_0x48eabf);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2458cd),this['scriptTagHolder']['addTag'](_0x2458cd,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4c7f76){const _0x21d8e3=O(_0x4c7f76);this['bytesSent']+=_0x21d8e3['length'],this['stats_']['incrementCounter']('bytes_sent',_0x21d8e3['length']);const _0x380378=Br(_0x21d8e3),_0x3b3ebf=io(_0x380378,hh);for(let _0x5000ea=0x0;_0x5000ea<_0x3b3ebf['length'];_0x5000ea++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b3ebf['length'],_0x3b3ebf[_0x5000ea]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x17d58d,_0x5d2cec){this['myDisconnFrame']=document['createElement']('iframe');const _0xddf8b3={};_0xddf8b3[lh]='t',_0xddf8b3[mo]=_0x17d58d,_0xddf8b3[yo]=_0x5d2cec,this['myDisconnFrame']['src']=this['urlFn'](_0xddf8b3),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x50aea7){const _0x587db0=O(_0x50aea7)['length'];this['bytesReceived']+=_0x587db0,this['stats_']['incrementCounter']('bytes_received',_0x587db0);}}class $i{constructor(_0x51f15c,_0x3ffc5c,_0xea0a7d,_0x303398){this['onDisconnect']=_0xea0a7d,this['urlFn']=_0x303398,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x51f15c,window[sh+this['uniqueCallbackIdentifier']]=_0x3ffc5c,this['myIFrame']=$i['createIFrame_']();let _0x463ced='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x463ced='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5a6f4d='<html><body>'+_0x463ced+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5a6f4d),this['myIFrame']['doc']['close']();}catch(_0x4fa011){L('frame\x20writing\x20exception'),_0x4fa011['stack']&&L(_0x4fa011['stack']),L(_0x4fa011);}}}static['createIFrame_'](){const _0x4ed993=document['createElement']('iframe');if(_0x4ed993['style']['display']='none',document['body']){document['body']['appendChild'](_0x4ed993);try{_0x4ed993['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xde6d98=document['domain'];_0x4ed993['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xde6d98+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4ed993['contentDocument']?_0x4ed993['doc']=_0x4ed993['contentDocument']:_0x4ed993['contentWindow']?_0x4ed993['doc']=_0x4ed993['contentWindow']['document']:_0x4ed993['document']&&(_0x4ed993['doc']=_0x4ed993['document']),_0x4ed993;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x486fe7=this['onDisconnect'];_0x486fe7&&(this['onDisconnect']=null,_0x486fe7());}['startLongPoll'](_0x49a996,_0x121f85){for(this['myID']=_0x49a996,this['myPW']=_0x121f85,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x36419b={};_0x36419b[mo]=this['myID'],_0x36419b[yo]=this['myPW'],_0x36419b[vo]=this['currentSerial'];let _0x38d56c=this['urlFn'](_0x36419b),_0x584b05='',_0x28f3bd=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x584b05['length']<=Eo;){const _0x726687=this['pendingSegs']['shift']();_0x584b05=_0x584b05+'&'+oh+_0x28f3bd+'='+_0x726687['seg']+'&'+ah+_0x28f3bd+'='+_0x726687['ts']+'&'+ch+_0x28f3bd+'='+_0x726687['d'],_0x28f3bd++;}return _0x38d56c=_0x38d56c+_0x584b05,this['addLongPollTag_'](_0x38d56c,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1022e0,_0x432af1,_0x197b1e){this['pendingSegs']['push']({'seg':_0x1022e0,'ts':_0x432af1,'d':_0x197b1e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xb2b845,_0x3620d0){this['outstandingRequests']['add'](_0x3620d0);const _0x42617d=()=>{this['outstandingRequests']['delete'](_0x3620d0),this['newRequest_']();},_0x257ce3=setTimeout(_0x42617d,Math['floor'](uh)),_0x17b161=()=>{clearTimeout(_0x257ce3),_0x42617d();};this['addTag'](_0xb2b845,_0x17b161);}['addTag'](_0x215e10,_0x4bdc35){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1972f9=this['myIFrame']['doc']['createElement']('script');_0x1972f9['type']='text/javascript',_0x1972f9['async']=!0x0,_0x1972f9['src']=_0x215e10,_0x1972f9['onload']=_0x1972f9['onreadystatechange']=function(){const _0x361438=_0x1972f9['readyState'];(!_0x361438||_0x361438==='loaded'||_0x361438==='complete')&&(_0x1972f9['onload']=_0x1972f9['onreadystatechange']=null,_0x1972f9['parentNode']&&_0x1972f9['parentNode']['removeChild'](_0x1972f9),_0x4bdc35());},_0x1972f9['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x215e10),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1972f9);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x32d2b6,_0x43f06d,_0x220eea,_0x5760d0,_0x83dd87,_0x252985,_0x3e0386){this['connId']=_0x32d2b6,this['applicationId']=_0x220eea,this['appCheckToken']=_0x5760d0,this['authToken']=_0x83dd87,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x43f06d),this['connURL']=G['connectionURL_'](_0x43f06d,_0x252985,_0x3e0386,_0x5760d0,_0x220eea),this['nodeAdmin']=_0x43f06d['nodeAdmin'];}static['connectionURL_'](_0x719faa,_0x36848d,_0x248e7b,_0x4dd7ce,_0x1dcc93){const _0x346903={};return _0x346903[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x346903[ao]=co),_0x36848d&&(_0x346903[oo]=_0x36848d),_0x248e7b&&(_0x346903[ho]=_0x248e7b),_0x4dd7ce&&(_0x346903[yi]=_0x4dd7ce),_0x1dcc93&&(_0x346903[uo]=_0x1dcc93),go(_0x719faa,fo,_0x346903);}['open'](_0x17cc49,_0x2ba108){this['onDisconnect']=_0x2ba108,this['onMessage']=_0x17cc49,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x6fe260;dc(),this['mySock']=new hn(this['connURL'],[],_0x6fe260);}catch(_0x2b64fb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x436b15=_0x2b64fb['message']||_0x2b64fb['data'];_0x436b15&&this['log_'](_0x436b15),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4ef08e=>{this['handleIncomingFrame'](_0x4ef08e);},this['mySock']['onerror']=_0x43a08a=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5be69c=_0x43a08a['message']||_0x43a08a['data'];_0x5be69c&&this['log_'](_0x5be69c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x474bae=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5a2847=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2b69e7=navigator['userAgent']['match'](_0x5a2847);_0x2b69e7&&_0x2b69e7['length']>0x1&&parseFloat(_0x2b69e7[0x1])<4.4&&(_0x474bae=!0x0);}return!_0x474bae&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2d594f){if(this['frames']['push'](_0x2d594f),this['frames']['length']===this['totalFrames']){const _0x1d556b=this['frames']['join']('');this['frames']=null;const _0x347332=bt(_0x1d556b);this['onMessage'](_0x347332);}}['handleNewFrameCount_'](_0x4b1598){this['totalFrames']=_0x4b1598,this['frames']=[];}['extractFrameCount_'](_0x35cd6e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x35cd6e['length']<=0x6){const _0x1aae99=Number(_0x35cd6e);if(!isNaN(_0x1aae99))return this['handleNewFrameCount_'](_0x1aae99),null;}return this['handleNewFrameCount_'](0x1),_0x35cd6e;}['handleIncomingFrame'](_0x38f0b2){if(this['mySock']===null)return;const _0x3a3882=_0x38f0b2['data'];if(this['bytesReceived']+=_0x3a3882['length'],this['stats_']['incrementCounter']('bytes_received',_0x3a3882['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3a3882);else{const _0x1e76a9=this['extractFrameCount_'](_0x3a3882);_0x1e76a9!==null&&this['appendFrame_'](_0x1e76a9);}}['send'](_0x504f90){this['resetKeepAlive']();const _0x3747d1=O(_0x504f90);this['bytesSent']+=_0x3747d1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3747d1['length']);const _0x31e473=io(_0x3747d1,fh);_0x31e473['length']>0x1&&this['sendString_'](String(_0x31e473['length']));for(let _0x43a299=0x0;_0x43a299<_0x31e473['length'];_0x43a299++)this['sendString_'](_0x31e473[_0x43a299]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x30c6e7){try{this['mySock']['send'](_0x30c6e7);}catch(_0x521b33){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x521b33['message']||_0x521b33['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3826a){this['initTransports_'](_0x3826a);}['initTransports_'](_0x1b4285){const _0x305a01=G&&G['isAvailable']();let _0x29de90=_0x305a01&&!G['previouslyFailed']();if(_0x1b4285['webSocketOnly']&&(_0x305a01||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x29de90=!0x0),_0x29de90)this['transports_']=[G];else{const _0x2f6bd5=this['transports_']=[];for(const _0x29d53c of At['ALL_TRANSPORTS'])_0x29d53c&&_0x29d53c['isAvailable']()&&_0x2f6bd5['push'](_0x29d53c);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x18ecf5,_0x5d50e3,_0x5f03ba,_0x338fc7,_0x86e157,_0x419f77,_0x25951a,_0x1eb94d,_0x1ce90c,_0x4f76c2){this['id']=_0x18ecf5,this['repoInfo_']=_0x5d50e3,this['applicationId_']=_0x5f03ba,this['appCheckToken_']=_0x338fc7,this['authToken_']=_0x86e157,this['onMessage_']=_0x419f77,this['onReady_']=_0x25951a,this['onDisconnect_']=_0x1eb94d,this['onKill_']=_0x1ce90c,this['lastSessionId']=_0x4f76c2,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x5d50e3),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x500680=this['transportManager_']['initialTransport']();this['conn_']=new _0x500680(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x500680['responsesRequiredToBeHealthy']||0x0;const _0x214400=this['connReceiver_'](this['conn_']),_0x184595=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x214400,_0x184595);},Math['floor'](0x0));const _0x224781=_0x500680['healthyTimeout']||0x0;_0x224781>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x224781)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x59f48c){return _0x200ffb=>{_0x59f48c===this['conn_']?this['onConnectionLost_'](_0x200ffb):_0x59f48c===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x30403b){return _0x29ba07=>{this['state_']!==0x2&&(_0x30403b===this['rx_']?this['onPrimaryMessageReceived_'](_0x29ba07):_0x30403b===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x29ba07):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1028fc){const _0xd938e4={'t':'d','d':_0x1028fc};this['sendData_'](_0xd938e4);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4ee634){if(ii in _0x4ee634){const _0x3e4590=_0x4ee634[ii];_0x3e4590===js?this['upgradeIfSecondaryHealthy_']():_0x3e4590===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3e4590===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3edde2){const _0x106335=pt('t',_0x3edde2),_0x2923b8=pt('d',_0x3edde2);if(_0x106335==='c')this['onSecondaryControl_'](_0x2923b8);else{if(_0x106335==='d')this['pendingDataMessages']['push'](_0x2923b8);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x106335);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5150b6){const _0x168791=pt('t',_0x5150b6),_0x540da8=pt('d',_0x5150b6);_0x168791==='c'?this['onControl_'](_0x540da8):_0x168791==='d'&&this['onDataMessage_'](_0x540da8);}['onDataMessage_'](_0x22ab64){this['onPrimaryResponse_'](),this['onMessage_'](_0x22ab64);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x12054d){const _0x331ffb=pt(ii,_0x12054d);if(Gs in _0x12054d){const _0x11d329=_0x12054d[Gs];if(_0x331ffb===Ih){const _0x58b0a4={..._0x11d329};this['repoInfo_']['isUsingEmulator']&&(_0x58b0a4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x58b0a4);}else{if(_0x331ffb===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x407ae1=0x0;_0x407ae1<this['pendingDataMessages']['length'];++_0x407ae1)this['onDataMessage_'](this['pendingDataMessages'][_0x407ae1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x331ffb===vh?this['onConnectionShutdown_'](_0x11d329):_0x331ffb===qs?this['onReset_'](_0x11d329):_0x331ffb===Eh?mi('Server\x20Error:\x20'+_0x11d329):_0x331ffb===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x331ffb);}}}['onHandshake_'](_0x348894){const _0x39d743=_0x348894['ts'],_0x219522=_0x348894['v'],_0x5af8c3=_0x348894['h'];this['sessionId']=_0x348894['s'],this['repoInfo_']['host']=_0x5af8c3,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x39d743),Vi!==_0x219522&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x508eed=this['transportManager_']['upgradeTransport']();_0x508eed&&this['startUpgrade_'](_0x508eed);}['startUpgrade_'](_0x153194){this['secondaryConn_']=new _0x153194(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x153194['responsesRequiredToBeHealthy']||0x0;const _0x2752c8=this['connReceiver_'](this['secondaryConn_']),_0x5d6451=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2752c8,_0x5d6451),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x9b7a59){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x9b7a59),this['repoInfo_']['host']=_0x9b7a59,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x13cba5,_0x2fbf01){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x13cba5,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2fbf01,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x37705c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x37705c||this['rx_']===_0x37705c)&&this['close']();}['onConnectionLost_'](_0x31d4de){this['conn_']=null,!_0x31d4de&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2713ee){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2713ee),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x880b8b){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x880b8b);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x3f7bdb,_0x2ec5b3,_0x46086f,_0x9e4e4f){}['merge'](_0x2a402f,_0x37dbcb,_0x1d5c1c,_0xe8d533){}['refreshAuthToken'](_0x40d9cb){}['refreshAppCheckToken'](_0x27524d){}['onDisconnectPut'](_0x540f7b,_0x1427b1,_0x33b443){}['onDisconnectMerge'](_0x52d8df,_0x5d6c49,_0x3be715){}['onDisconnectCancel'](_0x5e636a,_0x4a0298){}['reportStats'](_0x35beba){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2282fa){this['allowedEvents_']=_0x2282fa,this['listeners_']={},f(Array['isArray'](_0x2282fa)&&_0x2282fa['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x31cab8,..._0x43389e){if(Array['isArray'](this['listeners_'][_0x31cab8])){const _0x427b71=[...this['listeners_'][_0x31cab8]];for(let _0xaa1da5=0x0;_0xaa1da5<_0x427b71['length'];_0xaa1da5++)_0x427b71[_0xaa1da5]['callback']['apply'](_0x427b71[_0xaa1da5]['context'],_0x43389e);}}['on'](_0x242171,_0x1c44d3,_0x1c13e7){this['validateEventType_'](_0x242171),this['listeners_'][_0x242171]=this['listeners_'][_0x242171]||[],this['listeners_'][_0x242171]['push']({'callback':_0x1c44d3,'context':_0x1c13e7});const _0x3003a1=this['getInitialEvent'](_0x242171);_0x3003a1&&_0x1c44d3['apply'](_0x1c13e7,_0x3003a1);}['off'](_0x29daf1,_0x4ccf40,_0x4caa0f){this['validateEventType_'](_0x29daf1);const _0x351ead=this['listeners_'][_0x29daf1]||[];for(let _0x5fd4bb=0x0;_0x5fd4bb<_0x351ead['length'];_0x5fd4bb++)if(_0x351ead[_0x5fd4bb]['callback']===_0x4ccf40&&(!_0x4caa0f||_0x4caa0f===_0x351ead[_0x5fd4bb]['context'])){_0x351ead['splice'](_0x5fd4bb,0x1);return;}}['validateEventType_'](_0x4aea0f){f(this['allowedEvents_']['find'](_0x58c764=>_0x58c764===_0x4aea0f),'Unknown\x20event:\x20'+_0x4aea0f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x291f13){return f(_0x291f13==='online','Unknown\x20event\x20type:\x20'+_0x291f13),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0xfb3ece,_0x4f0b04){if(_0x4f0b04===void 0x0){this['pieces_']=_0xfb3ece['split']('/');let _0x20863c=0x0;for(let _0x782ab4=0x0;_0x782ab4<this['pieces_']['length'];_0x782ab4++)this['pieces_'][_0x782ab4]['length']>0x0&&(this['pieces_'][_0x20863c]=this['pieces_'][_0x782ab4],_0x20863c++);this['pieces_']['length']=_0x20863c,this['pieceNum_']=0x0;}else this['pieces_']=_0xfb3ece,this['pieceNum_']=_0x4f0b04;}['toString'](){let _0x41a745='';for(let _0x4296ae=this['pieceNum_'];_0x4296ae<this['pieces_']['length'];_0x4296ae++)this['pieces_'][_0x4296ae]!==''&&(_0x41a745+='/'+this['pieces_'][_0x4296ae]);return _0x41a745||'/';}}function w(){return new C('');}function y(_0x300de6){return _0x300de6['pieceNum_']>=_0x300de6['pieces_']['length']?null:_0x300de6['pieces_'][_0x300de6['pieceNum_']];}function we(_0x14714f){return _0x14714f['pieces_']['length']-_0x14714f['pieceNum_'];}function b(_0x43c8c7){let _0x4e5d60=_0x43c8c7['pieceNum_'];return _0x4e5d60<_0x43c8c7['pieces_']['length']&&_0x4e5d60++,new C(_0x43c8c7['pieces_'],_0x4e5d60);}function Gi(_0x25cc15){return _0x25cc15['pieceNum_']<_0x25cc15['pieces_']['length']?_0x25cc15['pieces_'][_0x25cc15['pieces_']['length']-0x1]:null;}function Ch(_0xc5bbc8){let _0x170670='';for(let _0x3dd96e=_0xc5bbc8['pieceNum_'];_0x3dd96e<_0xc5bbc8['pieces_']['length'];_0x3dd96e++)_0xc5bbc8['pieces_'][_0x3dd96e]!==''&&(_0x170670+='/'+encodeURIComponent(String(_0xc5bbc8['pieces_'][_0x3dd96e])));return _0x170670||'/';}function kt(_0x12aa9a,_0x58d6d0=0x0){return _0x12aa9a['pieces_']['slice'](_0x12aa9a['pieceNum_']+_0x58d6d0);}function To(_0x280afb){if(_0x280afb['pieceNum_']>=_0x280afb['pieces_']['length'])return null;const _0x466bd3=[];for(let _0x244d01=_0x280afb['pieceNum_'];_0x244d01<_0x280afb['pieces_']['length']-0x1;_0x244d01++)_0x466bd3['push'](_0x280afb['pieces_'][_0x244d01]);return new C(_0x466bd3,0x0);}function A(_0x362bed,_0x512077){const _0x46a11f=[];for(let _0x4ec204=_0x362bed['pieceNum_'];_0x4ec204<_0x362bed['pieces_']['length'];_0x4ec204++)_0x46a11f['push'](_0x362bed['pieces_'][_0x4ec204]);if(_0x512077 instanceof C){for(let _0x11cf23=_0x512077['pieceNum_'];_0x11cf23<_0x512077['pieces_']['length'];_0x11cf23++)_0x46a11f['push'](_0x512077['pieces_'][_0x11cf23]);}else{const _0x30471c=_0x512077['split']('/');for(let _0x523d19=0x0;_0x523d19<_0x30471c['length'];_0x523d19++)_0x30471c[_0x523d19]['length']>0x0&&_0x46a11f['push'](_0x30471c[_0x523d19]);}return new C(_0x46a11f,0x0);}function v(_0x144f57){return _0x144f57['pieceNum_']>=_0x144f57['pieces_']['length'];}function F(_0x410e64,_0x1ced06){const _0x35f5f4=y(_0x410e64),_0x258720=y(_0x1ced06);if(_0x35f5f4===null)return _0x1ced06;if(_0x35f5f4===_0x258720)return F(b(_0x410e64),b(_0x1ced06));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1ced06+')\x20is\x20not\x20within\x20outerPath\x20('+_0x410e64+')');}function Th(_0x144991,_0x89abdc){const _0x6e02bf=kt(_0x144991,0x0),_0x437ebe=kt(_0x89abdc,0x0);for(let _0x22f5a9=0x0;_0x22f5a9<_0x6e02bf['length']&&_0x22f5a9<_0x437ebe['length'];_0x22f5a9++){const _0x45214a=He(_0x6e02bf[_0x22f5a9],_0x437ebe[_0x22f5a9]);if(_0x45214a!==0x0)return _0x45214a;}return _0x6e02bf['length']===_0x437ebe['length']?0x0:_0x6e02bf['length']<_0x437ebe['length']?-0x1:0x1;}function qi(_0x195ada,_0x1650b6){if(we(_0x195ada)!==we(_0x1650b6))return!0x1;for(let _0x345457=_0x195ada['pieceNum_'],_0x7480ed=_0x1650b6['pieceNum_'];_0x345457<=_0x195ada['pieces_']['length'];_0x345457++,_0x7480ed++)if(_0x195ada['pieces_'][_0x345457]!==_0x1650b6['pieces_'][_0x7480ed])return!0x1;return!0x0;}function $(_0x5749c5,_0xebfcae){let _0x59aea3=_0x5749c5['pieceNum_'],_0x1f9c5d=_0xebfcae['pieceNum_'];if(we(_0x5749c5)>we(_0xebfcae))return!0x1;for(;_0x59aea3<_0x5749c5['pieces_']['length'];){if(_0x5749c5['pieces_'][_0x59aea3]!==_0xebfcae['pieces_'][_0x1f9c5d])return!0x1;++_0x59aea3,++_0x1f9c5d;}return!0x0;}class Sh{constructor(_0x5b9d5c,_0x49fb2d){this['errorPrefix_']=_0x49fb2d,this['parts_']=kt(_0x5b9d5c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3429e0=0x0;_0x3429e0<this['parts_']['length'];_0x3429e0++)this['byteLength_']+=Pn(this['parts_'][_0x3429e0]);So(this);}}function bh(_0x380120,_0x20f44d){_0x380120['parts_']['length']>0x0&&(_0x380120['byteLength_']+=0x1),_0x380120['parts_']['push'](_0x20f44d),_0x380120['byteLength_']+=Pn(_0x20f44d),So(_0x380120);}function Rh(_0x24179f){const _0x293c47=_0x24179f['parts_']['pop']();_0x24179f['byteLength_']-=Pn(_0x293c47),_0x24179f['parts_']['length']>0x0&&(_0x24179f['byteLength_']-=0x1);}function So(_0x447149){if(_0x447149['byteLength_']>Js)throw new Error(_0x447149['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x447149['byteLength_']+').');if(_0x447149['parts_']['length']>Qs)throw new Error(_0x447149['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x447149));}function Ne(_0xdc564a){return _0xdc564a['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xdc564a['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x47e7a0,_0x5be349;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5be349='visibilitychange',_0x47e7a0='hidden'):typeof document['mozHidden']<'u'?(_0x5be349='mozvisibilitychange',_0x47e7a0='mozHidden'):typeof document['msHidden']<'u'?(_0x5be349='msvisibilitychange',_0x47e7a0='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5be349='webkitvisibilitychange',_0x47e7a0='webkitHidden')),this['visible_']=!0x0,_0x5be349&&document['addEventListener'](_0x5be349,()=>{const _0x12729b=!document[_0x47e7a0];_0x12729b!==this['visible_']&&(this['visible_']=_0x12729b,this['trigger']('visible',_0x12729b));},!0x1);}['getInitialEvent'](_0x40f114){return f(_0x40f114==='visible','Unknown\x20event\x20type:\x20'+_0x40f114),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x175bbc,_0x49c712,_0x5550b4,_0x381870,_0x12189d,_0x43ce2d,_0x5e594c,_0x1c46e3){if(super(),this['repoInfo_']=_0x175bbc,this['applicationId_']=_0x49c712,this['onDataUpdate_']=_0x5550b4,this['onConnectStatus_']=_0x381870,this['onServerInfoUpdate_']=_0x12189d,this['authTokenProvider_']=_0x43ce2d,this['appCheckTokenProvider_']=_0x5e594c,this['authOverride_']=_0x1c46e3,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1c46e3)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x175bbc['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x53ba56,_0x3d5182,_0x3959c8){const _0x174c02=++this['requestNumber_'],_0x3b04a3={'r':_0x174c02,'a':_0x53ba56,'b':_0x3d5182};this['log_'](O(_0x3b04a3)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3b04a3),_0x3959c8&&(this['requestCBHash_'][_0x174c02]=_0x3959c8);}['get'](_0x3a9b6e){this['initConnection_']();const _0x497cde=new Ve(),_0x2659c8={'action':'g','request':{'p':_0x3a9b6e['_path']['toString'](),'q':_0x3a9b6e['_queryObject']},'onComplete':_0x1de938=>{const _0x339b4b=_0x1de938['d'];_0x1de938['s']==='ok'?_0x497cde['resolve'](_0x339b4b):_0x497cde['reject'](_0x339b4b);}};this['outstandingGets_']['push'](_0x2659c8),this['outstandingGetCount_']++;const _0x3d10cc=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3d10cc),_0x497cde['promise'];}['listen'](_0x22b352,_0x32b223,_0x4f4055,_0x337948){this['initConnection_']();const _0xc06e7e=_0x22b352['_queryIdentifier'],_0x1108c1=_0x22b352['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1108c1+'\x20'+_0xc06e7e),this['listens']['has'](_0x1108c1)||this['listens']['set'](_0x1108c1,new Map()),f(_0x22b352['_queryParams']['isDefault']()||!_0x22b352['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1108c1)['has'](_0xc06e7e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4c246b={'onComplete':_0x337948,'hashFn':_0x32b223,'query':_0x22b352,'tag':_0x4f4055};this['listens']['get'](_0x1108c1)['set'](_0xc06e7e,_0x4c246b),this['connected_']&&this['sendListen_'](_0x4c246b);}['sendGet_'](_0x26df41){const _0x284473=this['outstandingGets_'][_0x26df41];this['sendRequest']('g',_0x284473['request'],_0x4513e5=>{delete this['outstandingGets_'][_0x26df41],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x284473['onComplete']&&_0x284473['onComplete'](_0x4513e5);});}['sendListen_'](_0x15e318){const _0x58a4e0=_0x15e318['query'],_0x39e69e=_0x58a4e0['_path']['toString'](),_0x285be1=_0x58a4e0['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x39e69e+'\x20for\x20'+_0x285be1);const _0xfe5a9d={'p':_0x39e69e},_0x2bb357='q';_0x15e318['tag']&&(_0xfe5a9d['q']=_0x58a4e0['_queryObject'],_0xfe5a9d['t']=_0x15e318['tag']),_0xfe5a9d['h']=_0x15e318['hashFn'](),this['sendRequest'](_0x2bb357,_0xfe5a9d,_0x29242a=>{const _0x23dae6=_0x29242a['d'],_0x968e21=_0x29242a['s'];ie['warnOnListenWarnings_'](_0x23dae6,_0x58a4e0),(this['listens']['get'](_0x39e69e)&&this['listens']['get'](_0x39e69e)['get'](_0x285be1))===_0x15e318&&(this['log_']('listen\x20response',_0x29242a),_0x968e21!=='ok'&&this['removeListen_'](_0x39e69e,_0x285be1),_0x15e318['onComplete']&&_0x15e318['onComplete'](_0x968e21,_0x23dae6));});}static['warnOnListenWarnings_'](_0x17d938,_0x33b9b9){if(_0x17d938&&typeof _0x17d938=='object'&&Y(_0x17d938,'w')){const _0x4e847c=Oe(_0x17d938,'w');if(Array['isArray'](_0x4e847c)&&~_0x4e847c['indexOf']('no_index')){const _0x2868e9='\x22.indexOn\x22:\x20\x22'+_0x33b9b9['_queryParams']['getIndex']()['toString']()+'\x22',_0x4f671a=_0x33b9b9['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2868e9+'\x20at\x20'+_0x4f671a+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x29b111){this['authToken_']=_0x29b111,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x29b111);}['reduceReconnectDelayIfAdminCredential_'](_0x166d14){(_0x166d14&&_0x166d14['length']===0x28||vc(_0x166d14))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x41c79b){this['appCheckToken_']=_0x41c79b,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x52bf1f=this['authToken_'],_0x26e885=yc(_0x52bf1f)?'auth':'gauth',_0x5745ad={'cred':_0x52bf1f};this['authOverride_']===null?_0x5745ad['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5745ad['authvar']=this['authOverride_']),this['sendRequest'](_0x26e885,_0x5745ad,_0x13f69b=>{const _0xa68de4=_0x13f69b['s'],_0x2b102b=_0x13f69b['d']||'error';this['authToken_']===_0x52bf1f&&(_0xa68de4==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0xa68de4,_0x2b102b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x22756c=>{const _0x50378f=_0x22756c['s'],_0x891b9b=_0x22756c['d']||'error';_0x50378f==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x50378f,_0x891b9b);});}['unlisten'](_0x3a1faf,_0x1f2790){const _0xc6776b=_0x3a1faf['_path']['toString'](),_0x45b526=_0x3a1faf['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xc6776b+'\x20'+_0x45b526),f(_0x3a1faf['_queryParams']['isDefault']()||!_0x3a1faf['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xc6776b,_0x45b526)&&this['connected_']&&this['sendUnlisten_'](_0xc6776b,_0x45b526,_0x3a1faf['_queryObject'],_0x1f2790);}['sendUnlisten_'](_0x572177,_0xe89697,_0x192bfc,_0x5ae073){this['log_']('Unlisten\x20on\x20'+_0x572177+'\x20for\x20'+_0xe89697);const _0x433619={'p':_0x572177},_0x25bafd='n';_0x5ae073&&(_0x433619['q']=_0x192bfc,_0x433619['t']=_0x5ae073),this['sendRequest'](_0x25bafd,_0x433619);}['onDisconnectPut'](_0x46055c,_0x2cc808,_0x3c1b2c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x46055c,_0x2cc808,_0x3c1b2c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x46055c,'action':'o','data':_0x2cc808,'onComplete':_0x3c1b2c});}['onDisconnectMerge'](_0x5b2d8b,_0xd68a8c,_0x35b068){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5b2d8b,_0xd68a8c,_0x35b068):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5b2d8b,'action':'om','data':_0xd68a8c,'onComplete':_0x35b068});}['onDisconnectCancel'](_0x494c2f,_0x214eba){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x494c2f,null,_0x214eba):this['onDisconnectRequestQueue_']['push']({'pathString':_0x494c2f,'action':'oc','data':null,'onComplete':_0x214eba});}['sendOnDisconnect_'](_0xf18e32,_0xdde9d,_0x282b78,_0x5a31db){const _0x4bc1a2={'p':_0xdde9d,'d':_0x282b78};this['log_']('onDisconnect\x20'+_0xf18e32,_0x4bc1a2),this['sendRequest'](_0xf18e32,_0x4bc1a2,_0xb11393=>{_0x5a31db&&setTimeout(()=>{_0x5a31db(_0xb11393['s'],_0xb11393['d']);},Math['floor'](0x0));});}['put'](_0x13611b,_0x4e4e7a,_0x2e8fc2,_0x43f2a9){this['putInternal']('p',_0x13611b,_0x4e4e7a,_0x2e8fc2,_0x43f2a9);}['merge'](_0x5b0979,_0x1395c7,_0x35b15a,_0x8cdc73){this['putInternal']('m',_0x5b0979,_0x1395c7,_0x35b15a,_0x8cdc73);}['putInternal'](_0x17f08c,_0x2dadf0,_0x5b69de,_0x2274f0,_0x491ce0){this['initConnection_']();const _0x28cff7={'p':_0x2dadf0,'d':_0x5b69de};_0x491ce0!==void 0x0&&(_0x28cff7['h']=_0x491ce0),this['outstandingPuts_']['push']({'action':_0x17f08c,'request':_0x28cff7,'onComplete':_0x2274f0}),this['outstandingPutCount_']++;const _0x260546=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x260546):this['log_']('Buffering\x20put:\x20'+_0x2dadf0);}['sendPut_'](_0x1d3cdf){const _0x5b9270=this['outstandingPuts_'][_0x1d3cdf]['action'],_0x2fba63=this['outstandingPuts_'][_0x1d3cdf]['request'],_0x511b71=this['outstandingPuts_'][_0x1d3cdf]['onComplete'];this['outstandingPuts_'][_0x1d3cdf]['queued']=this['connected_'],this['sendRequest'](_0x5b9270,_0x2fba63,_0x511624=>{this['log_'](_0x5b9270+'\x20response',_0x511624),delete this['outstandingPuts_'][_0x1d3cdf],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x511b71&&_0x511b71(_0x511624['s'],_0x511624['d']);});}['reportStats'](_0x35f57c){if(this['connected_']){const _0x379d6d={'c':_0x35f57c};this['log_']('reportStats',_0x379d6d),this['sendRequest']('s',_0x379d6d,_0x447859=>{if(_0x447859['s']!=='ok'){const _0x461591=_0x447859['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x461591);}});}}['onDataMessage_'](_0x40342a){if('r'in _0x40342a){this['log_']('from\x20server:\x20'+O(_0x40342a));const _0x35f9fc=_0x40342a['r'],_0x320cec=this['requestCBHash_'][_0x35f9fc];_0x320cec&&(delete this['requestCBHash_'][_0x35f9fc],_0x320cec(_0x40342a['b']));}else{if('error'in _0x40342a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x40342a['error'];'a'in _0x40342a&&this['onDataPush_'](_0x40342a['a'],_0x40342a['b']);}}['onDataPush_'](_0x2892c6,_0x3d79bd){this['log_']('handleServerMessage',_0x2892c6,_0x3d79bd),_0x2892c6==='d'?this['onDataUpdate_'](_0x3d79bd['p'],_0x3d79bd['d'],!0x1,_0x3d79bd['t']):_0x2892c6==='m'?this['onDataUpdate_'](_0x3d79bd['p'],_0x3d79bd['d'],!0x0,_0x3d79bd['t']):_0x2892c6==='c'?this['onListenRevoked_'](_0x3d79bd['p'],_0x3d79bd['q']):_0x2892c6==='ac'?this['onAuthRevoked_'](_0x3d79bd['s'],_0x3d79bd['d']):_0x2892c6==='apc'?this['onAppCheckRevoked_'](_0x3d79bd['s'],_0x3d79bd['d']):_0x2892c6==='sd'?this['onSecurityDebugPacket_'](_0x3d79bd):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2892c6)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x385cea,_0xf61691){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x385cea),this['lastSessionId']=_0xf61691,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5ecfdb){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5ecfdb));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1b468d){_0x1b468d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1b468d;}['onOnline_'](_0x2d7a09){_0x2d7a09?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3dd981=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x292a51=Math['max'](0x0,this['reconnectDelay_']-_0x3dd981);_0x292a51=Math['random']()*_0x292a51,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x292a51+'ms'),this['scheduleConnect_'](_0x292a51),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x42b4f4=this['onDataMessage_']['bind'](this),_0x30ef12=this['onReady_']['bind'](this),_0x3354cd=this['onRealtimeDisconnect_']['bind'](this),_0x3c180f=this['id']+':'+ie['nextConnectionId_']++,_0x1833c2=this['lastSessionId'];let _0x4e1d26=!0x1,_0x2013c0=null;const _0x44cc2b=function(){_0x2013c0?_0x2013c0['close']():(_0x4e1d26=!0x0,_0x3354cd());},_0x2dc1dd=function(_0x5d6cbb){f(_0x2013c0,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2013c0['sendRequest'](_0x5d6cbb);};this['realtime_']={'close':_0x44cc2b,'sendRequest':_0x2dc1dd};const _0x2e1a97=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x8344de,_0x4dc4ff]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2e1a97),this['appCheckTokenProvider_']['getToken'](_0x2e1a97)]);_0x4e1d26?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x8344de&&_0x8344de['accessToken'],this['appCheckToken_']=_0x4dc4ff&&_0x4dc4ff['token'],_0x2013c0=new wh(_0x3c180f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x42b4f4,_0x30ef12,_0x3354cd,_0xf40263=>{U(_0xf40263+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x1833c2));}catch(_0x19eecf){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x19eecf),_0x4e1d26||(this['repoInfo_']['nodeAdmin']&&U(_0x19eecf),_0x44cc2b());}}}['interrupt'](_0x33df21){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x33df21),this['interruptReasons_'][_0x33df21]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x35ff2b){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x35ff2b),delete this['interruptReasons_'][_0x35ff2b],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x28a563){const _0x1dd671=_0x28a563-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1dd671});}['cancelSentTransactions_'](){for(let _0x4a8126=0x0;_0x4a8126<this['outstandingPuts_']['length'];_0x4a8126++){const _0x27c0d0=this['outstandingPuts_'][_0x4a8126];_0x27c0d0&&'h'in _0x27c0d0['request']&&_0x27c0d0['queued']&&(_0x27c0d0['onComplete']&&_0x27c0d0['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4a8126],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x15449f,_0x250659){let _0x4f28fe;_0x250659?_0x4f28fe=_0x250659['map'](_0x4bb4b1=>Bi(_0x4bb4b1))['join']('$'):_0x4f28fe='default';const _0x3223e6=this['removeListen_'](_0x15449f,_0x4f28fe);_0x3223e6&&_0x3223e6['onComplete']&&_0x3223e6['onComplete']('permission_denied');}['removeListen_'](_0x1f22fd,_0x22fb2d){const _0x5853d2=new C(_0x1f22fd)['toString']();let _0x57dca7;if(this['listens']['has'](_0x5853d2)){const _0x589b07=this['listens']['get'](_0x5853d2);_0x57dca7=_0x589b07['get'](_0x22fb2d),_0x589b07['delete'](_0x22fb2d),_0x589b07['size']===0x0&&this['listens']['delete'](_0x5853d2);}else _0x57dca7=void 0x0;return _0x57dca7;}['onAuthRevoked_'](_0x3345ba,_0x3875e2){L('Auth\x20token\x20revoked:\x20'+_0x3345ba+'/'+_0x3875e2),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3345ba==='invalid_token'||_0x3345ba==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1e7721,_0x5be2d8){L('App\x20check\x20token\x20revoked:\x20'+_0x1e7721+'/'+_0x5be2d8),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1e7721==='invalid_token'||_0x1e7721==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1bc3b2){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1bc3b2):'msg'in _0x1bc3b2&&console['log']('FIREBASE:\x20'+_0x1bc3b2['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x46438c of this['listens']['values']())for(const _0x2c1860 of _0x46438c['values']())this['sendListen_'](_0x2c1860);for(let _0x2a9ddd=0x0;_0x2a9ddd<this['outstandingPuts_']['length'];_0x2a9ddd++)this['outstandingPuts_'][_0x2a9ddd]&&this['sendPut_'](_0x2a9ddd);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3a92f1=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3a92f1['action'],_0x3a92f1['pathString'],_0x3a92f1['data'],_0x3a92f1['onComplete']);}for(let _0x369f3c=0x0;_0x369f3c<this['outstandingGets_']['length'];_0x369f3c++)this['outstandingGets_'][_0x369f3c]&&this['sendGet_'](_0x369f3c);}['sendConnectStats_'](){const _0x134647={};let _0x540e44='js';_0x134647['sdk.'+_0x540e44+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x134647['framework.cordova']=0x1:qr()&&(_0x134647['framework.reactnative']=0x1),this['reportStats'](_0x134647);}['shouldReconnect_'](){const _0x5b0c9d=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x5b0c9d;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x252ff2,_0x11da62){this['name']=_0x252ff2,this['node']=_0x11da62;}static['Wrap'](_0x3e8bd4,_0x50c67c){return new E(_0x3e8bd4,_0x50c67c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x395cc7,_0x229b05){const _0x1f608a=new E(xe,_0x395cc7),_0x56429d=new E(xe,_0x229b05);return this['compare'](_0x1f608a,_0x56429d)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2ca132){Xt=_0x2ca132;}['compare'](_0x4f8f7b,_0x4ed66a){return He(_0x4f8f7b['name'],_0x4ed66a['name']);}['isDefinedOn'](_0x31a884){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4e69dd,_0x19fecc){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x1cf75c,_0x31637c){return f(typeof _0x1cf75c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1cf75c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x47b334,_0x499f11,_0x59c828,_0x4d73c0,_0xe8f217=null){this['isReverse_']=_0x4d73c0,this['resultGenerator_']=_0xe8f217,this['nodeStack_']=[];let _0xde2246=0x1;for(;!_0x47b334['isEmpty']();)if(_0x47b334=_0x47b334,_0xde2246=_0x499f11?_0x59c828(_0x47b334['key'],_0x499f11):0x1,_0x4d73c0&&(_0xde2246*=-0x1),_0xde2246<0x0)this['isReverse_']?_0x47b334=_0x47b334['left']:_0x47b334=_0x47b334['right'];else{if(_0xde2246===0x0){this['nodeStack_']['push'](_0x47b334);break;}else this['nodeStack_']['push'](_0x47b334),this['isReverse_']?_0x47b334=_0x47b334['right']:_0x47b334=_0x47b334['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x49cbbb=this['nodeStack_']['pop'](),_0x1d0be6;if(this['resultGenerator_']?_0x1d0be6=this['resultGenerator_'](_0x49cbbb['key'],_0x49cbbb['value']):_0x1d0be6={'key':_0x49cbbb['key'],'value':_0x49cbbb['value']},this['isReverse_']){for(_0x49cbbb=_0x49cbbb['left'];!_0x49cbbb['isEmpty']();)this['nodeStack_']['push'](_0x49cbbb),_0x49cbbb=_0x49cbbb['right'];}else{for(_0x49cbbb=_0x49cbbb['right'];!_0x49cbbb['isEmpty']();)this['nodeStack_']['push'](_0x49cbbb),_0x49cbbb=_0x49cbbb['left'];}return _0x1d0be6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4863d6=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4863d6['key'],_0x4863d6['value']):{'key':_0x4863d6['key'],'value':_0x4863d6['value']};}}class M{constructor(_0x70409f,_0x519cdd,_0x1f722f,_0x102214,_0x317e5c){this['key']=_0x70409f,this['value']=_0x519cdd,this['color']=_0x1f722f??M['RED'],this['left']=_0x102214??B['EMPTY_NODE'],this['right']=_0x317e5c??B['EMPTY_NODE'];}['copy'](_0x388e31,_0x5839ab,_0x373177,_0x5d7a0f,_0x1356cc){return new M(_0x388e31??this['key'],_0x5839ab??this['value'],_0x373177??this['color'],_0x5d7a0f??this['left'],_0x1356cc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x511a7d){return this['left']['inorderTraversal'](_0x511a7d)||!!_0x511a7d(this['key'],this['value'])||this['right']['inorderTraversal'](_0x511a7d);}['reverseTraversal'](_0x42e6df){return this['right']['reverseTraversal'](_0x42e6df)||_0x42e6df(this['key'],this['value'])||this['left']['reverseTraversal'](_0x42e6df);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x8b818a,_0x50ae38,_0x2e7cf4){let _0x2d13a2=this;const _0x1daa74=_0x2e7cf4(_0x8b818a,_0x2d13a2['key']);return _0x1daa74<0x0?_0x2d13a2=_0x2d13a2['copy'](null,null,null,_0x2d13a2['left']['insert'](_0x8b818a,_0x50ae38,_0x2e7cf4),null):_0x1daa74===0x0?_0x2d13a2=_0x2d13a2['copy'](null,_0x50ae38,null,null,null):_0x2d13a2=_0x2d13a2['copy'](null,null,null,null,_0x2d13a2['right']['insert'](_0x8b818a,_0x50ae38,_0x2e7cf4)),_0x2d13a2['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0xb3c604=this;return!_0xb3c604['left']['isRed_']()&&!_0xb3c604['left']['left']['isRed_']()&&(_0xb3c604=_0xb3c604['moveRedLeft_']()),_0xb3c604=_0xb3c604['copy'](null,null,null,_0xb3c604['left']['removeMin_'](),null),_0xb3c604['fixUp_']();}['remove'](_0x222695,_0x33b3ae){let _0x4bc181,_0x3d070e;if(_0x4bc181=this,_0x33b3ae(_0x222695,_0x4bc181['key'])<0x0)!_0x4bc181['left']['isEmpty']()&&!_0x4bc181['left']['isRed_']()&&!_0x4bc181['left']['left']['isRed_']()&&(_0x4bc181=_0x4bc181['moveRedLeft_']()),_0x4bc181=_0x4bc181['copy'](null,null,null,_0x4bc181['left']['remove'](_0x222695,_0x33b3ae),null);else{if(_0x4bc181['left']['isRed_']()&&(_0x4bc181=_0x4bc181['rotateRight_']()),!_0x4bc181['right']['isEmpty']()&&!_0x4bc181['right']['isRed_']()&&!_0x4bc181['right']['left']['isRed_']()&&(_0x4bc181=_0x4bc181['moveRedRight_']()),_0x33b3ae(_0x222695,_0x4bc181['key'])===0x0){if(_0x4bc181['right']['isEmpty']())return B['EMPTY_NODE'];_0x3d070e=_0x4bc181['right']['min_'](),_0x4bc181=_0x4bc181['copy'](_0x3d070e['key'],_0x3d070e['value'],null,null,_0x4bc181['right']['removeMin_']());}_0x4bc181=_0x4bc181['copy'](null,null,null,null,_0x4bc181['right']['remove'](_0x222695,_0x33b3ae));}return _0x4bc181['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x27474d=this;return _0x27474d['right']['isRed_']()&&!_0x27474d['left']['isRed_']()&&(_0x27474d=_0x27474d['rotateLeft_']()),_0x27474d['left']['isRed_']()&&_0x27474d['left']['left']['isRed_']()&&(_0x27474d=_0x27474d['rotateRight_']()),_0x27474d['left']['isRed_']()&&_0x27474d['right']['isRed_']()&&(_0x27474d=_0x27474d['colorFlip_']()),_0x27474d;}['moveRedLeft_'](){let _0x4d1af5=this['colorFlip_']();return _0x4d1af5['right']['left']['isRed_']()&&(_0x4d1af5=_0x4d1af5['copy'](null,null,null,null,_0x4d1af5['right']['rotateRight_']()),_0x4d1af5=_0x4d1af5['rotateLeft_'](),_0x4d1af5=_0x4d1af5['colorFlip_']()),_0x4d1af5;}['moveRedRight_'](){let _0x572754=this['colorFlip_']();return _0x572754['left']['left']['isRed_']()&&(_0x572754=_0x572754['rotateRight_'](),_0x572754=_0x572754['colorFlip_']()),_0x572754;}['rotateLeft_'](){const _0x54e0ac=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x54e0ac,null);}['rotateRight_'](){const _0x5b2fc6=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5b2fc6);}['colorFlip_'](){const _0x13f505=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4b7f40=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x13f505,_0x4b7f40);}['checkMaxDepth_'](){const _0xa4d9b4=this['check_']();return Math['pow'](0x2,_0xa4d9b4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xec10e4=this['left']['check_']();if(_0xec10e4!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xec10e4+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x59a226,_0xe74a67,_0x3a44f5,_0x2c3119,_0x11c470){return this;}['insert'](_0x6799d1,_0x675fda,_0x29a0e0){return new M(_0x6799d1,_0x675fda,null);}['remove'](_0x4b76b5,_0x133d4f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x42ec4d){return!0x1;}['reverseTraversal'](_0x300b35){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x51c7ea,_0x28c09b=B['EMPTY_NODE']){this['comparator_']=_0x51c7ea,this['root_']=_0x28c09b;}['insert'](_0x4428f7,_0x5d07c5){return new B(this['comparator_'],this['root_']['insert'](_0x4428f7,_0x5d07c5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1e3c24){return new B(this['comparator_'],this['root_']['remove'](_0x1e3c24,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2f4f64){let _0x11d5b3,_0x1f8072=this['root_'];for(;!_0x1f8072['isEmpty']();){if(_0x11d5b3=this['comparator_'](_0x2f4f64,_0x1f8072['key']),_0x11d5b3===0x0)return _0x1f8072['value'];_0x11d5b3<0x0?_0x1f8072=_0x1f8072['left']:_0x11d5b3>0x0&&(_0x1f8072=_0x1f8072['right']);}return null;}['getPredecessorKey'](_0x57db23){let _0x1b7c84,_0x5672f4=this['root_'],_0x3f108d=null;for(;!_0x5672f4['isEmpty']();)if(_0x1b7c84=this['comparator_'](_0x57db23,_0x5672f4['key']),_0x1b7c84===0x0){if(_0x5672f4['left']['isEmpty']())return _0x3f108d?_0x3f108d['key']:null;for(_0x5672f4=_0x5672f4['left'];!_0x5672f4['right']['isEmpty']();)_0x5672f4=_0x5672f4['right'];return _0x5672f4['key'];}else _0x1b7c84<0x0?_0x5672f4=_0x5672f4['left']:_0x1b7c84>0x0&&(_0x3f108d=_0x5672f4,_0x5672f4=_0x5672f4['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2cfec7){return this['root_']['inorderTraversal'](_0x2cfec7);}['reverseTraversal'](_0x443b1c){return this['root_']['reverseTraversal'](_0x443b1c);}['getIterator'](_0xc0b2cb){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0xc0b2cb);}['getIteratorFrom'](_0x5591ef,_0xd6d742){return new Zt(this['root_'],_0x5591ef,this['comparator_'],!0x1,_0xd6d742);}['getReverseIteratorFrom'](_0x168d25,_0x3c5ab3){return new Zt(this['root_'],_0x168d25,this['comparator_'],!0x0,_0x3c5ab3);}['getReverseIterator'](_0x55d828){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x55d828);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x39ca54,_0x53ee58){return He(_0x39ca54['name'],_0x53ee58['name']);}function ji(_0x53caa3,_0x3bbad7){return He(_0x53caa3,_0x3bbad7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x632a67){vi=_0x632a67;}const Ro=function(_0x320d3e){return typeof _0x320d3e=='number'?'number:'+so(_0x320d3e):'string:'+_0x320d3e;},Ao=function(_0x2644b6){if(_0x2644b6['isLeafNode']()){const _0x36fdcd=_0x2644b6['val']();f(typeof _0x36fdcd=='string'||typeof _0x36fdcd=='number'||typeof _0x36fdcd=='object'&&Y(_0x36fdcd,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2644b6===vi||_0x2644b6['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2644b6===vi||_0x2644b6['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5a4ecb){er=_0x5a4ecb;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4e1e7c,_0x43f783=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4e1e7c,this['priorityNode_']=_0x43f783,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x39b3dd){return new D(this['value_'],_0x39b3dd);}['getImmediateChild'](_0x228adf){return _0x228adf==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x13718f){return v(_0x13718f)?this:y(_0x13718f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x22f757,_0x3c386d){return null;}['updateImmediateChild'](_0x46cf5a,_0x521397){return _0x46cf5a==='.priority'?this['updatePriority'](_0x521397):_0x521397['isEmpty']()&&_0x46cf5a!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x46cf5a,_0x521397)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3fa23b,_0x2e3fe5){const _0x117524=y(_0x3fa23b);return _0x117524===null?_0x2e3fe5:_0x2e3fe5['isEmpty']()&&_0x117524!=='.priority'?this:(f(_0x117524!=='.priority'||we(_0x3fa23b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x117524,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3fa23b),_0x2e3fe5)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2ce81d,_0x4bf529){return!0x1;}['val'](_0x5f4254){return _0x5f4254&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x491c8f='';this['priorityNode_']['isEmpty']()||(_0x491c8f+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x59d9d5=typeof this['value_'];_0x491c8f+=_0x59d9d5+':',_0x59d9d5==='number'?_0x491c8f+=so(this['value_']):_0x491c8f+=this['value_'],this['lazyHash_']=no(_0x491c8f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1622b9){return _0x1622b9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1622b9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1622b9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1622b9));}['compareToLeafNode_'](_0x46d1fc){const _0x35c182=typeof _0x46d1fc['value_'],_0x147571=typeof this['value_'],_0x123ad7=D['VALUE_TYPE_ORDER']['indexOf'](_0x35c182),_0x266f65=D['VALUE_TYPE_ORDER']['indexOf'](_0x147571);return f(_0x123ad7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x35c182),f(_0x266f65>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x147571),_0x123ad7===_0x266f65?_0x147571==='object'?0x0:this['value_']<_0x46d1fc['value_']?-0x1:this['value_']===_0x46d1fc['value_']?0x0:0x1:_0x266f65-_0x123ad7;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x7bc51){if(_0x7bc51===this)return!0x0;if(_0x7bc51['isLeafNode']()){const _0x2e9f74=_0x7bc51;return this['value_']===_0x2e9f74['value_']&&this['priorityNode_']['equals'](_0x2e9f74['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4b59bc){ko=_0x4b59bc;}function xh(_0x5ac668){No=_0x5ac668;}class Fh extends On{['compare'](_0x485827,_0x1e63eb){const _0x5dcf54=_0x485827['node']['getPriority'](),_0x2edf3d=_0x1e63eb['node']['getPriority'](),_0x5a102f=_0x5dcf54['compareTo'](_0x2edf3d);return _0x5a102f===0x0?He(_0x485827['name'],_0x1e63eb['name']):_0x5a102f;}['isDefinedOn'](_0x383d28){return!_0x383d28['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5746ae,_0x3b5cad){return!_0x5746ae['getPriority']()['equals'](_0x3b5cad['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xa6d1f7,_0x60d9da){const _0x3dae61=ko(_0xa6d1f7);return new E(_0x60d9da,new D('[PRIORITY-POST]',_0x3dae61));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x50e581){const _0x5c8b55=_0x151f2c=>parseInt(Math['log'](_0x151f2c)/Uh,0xa),_0x41f380=_0x3f66f0=>parseInt(Array(_0x3f66f0+0x1)['join']('1'),0x2);this['count']=_0x5c8b55(_0x50e581+0x1),this['current_']=this['count']-0x1;const _0xdabe2b=_0x41f380(this['count']);this['bits_']=_0x50e581+0x1&_0xdabe2b;}['nextBitIsOne'](){const _0x2baa86=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2baa86;}}const dn=function(_0x2fac64,_0x120998,_0x26f2b7,_0x4cf9a9){_0x2fac64['sort'](_0x120998);const _0x342f5f=function(_0xeed185,_0x563713){const _0x1b6b24=_0x563713-_0xeed185;let _0x251997,_0xffff17;if(_0x1b6b24===0x0)return null;if(_0x1b6b24===0x1)return _0x251997=_0x2fac64[_0xeed185],_0xffff17=_0x26f2b7?_0x26f2b7(_0x251997):_0x251997,new M(_0xffff17,_0x251997['node'],M['BLACK'],null,null);{const _0x3b6bf4=parseInt(_0x1b6b24/0x2,0xa)+_0xeed185,_0xf8cd4=_0x342f5f(_0xeed185,_0x3b6bf4),_0x1a10eb=_0x342f5f(_0x3b6bf4+0x1,_0x563713);return _0x251997=_0x2fac64[_0x3b6bf4],_0xffff17=_0x26f2b7?_0x26f2b7(_0x251997):_0x251997,new M(_0xffff17,_0x251997['node'],M['BLACK'],_0xf8cd4,_0x1a10eb);}},_0x3b3818=function(_0x43336b){let _0x40bd24=null,_0x3d44ca=null,_0xd9dd11=_0x2fac64['length'];const _0x34c4d9=function(_0xbd025,_0xc14934){const _0x3ae61e=_0xd9dd11-_0xbd025,_0x137a23=_0xd9dd11;_0xd9dd11-=_0xbd025;const _0x2b3811=_0x342f5f(_0x3ae61e+0x1,_0x137a23),_0x4cdf9c=_0x2fac64[_0x3ae61e],_0x5b0bcb=_0x26f2b7?_0x26f2b7(_0x4cdf9c):_0x4cdf9c;_0x1745db(new M(_0x5b0bcb,_0x4cdf9c['node'],_0xc14934,null,_0x2b3811));},_0x1745db=function(_0x3de402){_0x40bd24?(_0x40bd24['left']=_0x3de402,_0x40bd24=_0x3de402):(_0x3d44ca=_0x3de402,_0x40bd24=_0x3de402);};for(let _0x29bca6=0x0;_0x29bca6<_0x43336b['count'];++_0x29bca6){const _0x5eb9a9=_0x43336b['nextBitIsOne'](),_0x25793a=Math['pow'](0x2,_0x43336b['count']-(_0x29bca6+0x1));_0x5eb9a9?_0x34c4d9(_0x25793a,M['BLACK']):(_0x34c4d9(_0x25793a,M['BLACK']),_0x34c4d9(_0x25793a,M['RED']));}return _0x3d44ca;},_0x2d9da0=new Wh(_0x2fac64['length']),_0x2a314c=_0x3b3818(_0x2d9da0);return new B(_0x4cf9a9||_0x120998,_0x2a314c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x59495a,_0x24a990){this['indexes_']=_0x59495a,this['indexSet_']=_0x24a990;}['get'](_0x100084){const _0xaa5ca3=Oe(this['indexes_'],_0x100084);if(!_0xaa5ca3)throw new Error('No\x20index\x20defined\x20for\x20'+_0x100084);return _0xaa5ca3 instanceof B?_0xaa5ca3:null;}['hasIndex'](_0x2ea6ed){return Y(this['indexSet_'],_0x2ea6ed['toString']());}['addIndex'](_0x3a7fc9,_0x2645d3){f(_0x3a7fc9!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1cf61d=[];let _0xe8f384=!0x1;const _0x46b008=_0x2645d3['getIterator'](E['Wrap']);let _0x2cb9e6=_0x46b008['getNext']();for(;_0x2cb9e6;)_0xe8f384=_0xe8f384||_0x3a7fc9['isDefinedOn'](_0x2cb9e6['node']),_0x1cf61d['push'](_0x2cb9e6),_0x2cb9e6=_0x46b008['getNext']();let _0x3409ea;_0xe8f384?_0x3409ea=dn(_0x1cf61d,_0x3a7fc9['getCompare']()):_0x3409ea=je;const _0x2f24a4=_0x3a7fc9['toString'](),_0x9ccf7c={...this['indexSet_']};_0x9ccf7c[_0x2f24a4]=_0x3a7fc9;const _0x1f063c={...this['indexes_']};return _0x1f063c[_0x2f24a4]=_0x3409ea,new ee(_0x1f063c,_0x9ccf7c);}['addToIndexes'](_0x186bf1,_0xc7787b){const _0x453d48=ln(this['indexes_'],(_0x5b234f,_0x36a954)=>{const _0x414540=Oe(this['indexSet_'],_0x36a954);if(f(_0x414540,'Missing\x20index\x20implementation\x20for\x20'+_0x36a954),_0x5b234f===je){if(_0x414540['isDefinedOn'](_0x186bf1['node'])){const _0x50370b=[],_0x1db9f8=_0xc7787b['getIterator'](E['Wrap']);let _0x359853=_0x1db9f8['getNext']();for(;_0x359853;)_0x359853['name']!==_0x186bf1['name']&&_0x50370b['push'](_0x359853),_0x359853=_0x1db9f8['getNext']();return _0x50370b['push'](_0x186bf1),dn(_0x50370b,_0x414540['getCompare']());}else return je;}else{const _0x55e623=_0xc7787b['get'](_0x186bf1['name']);let _0x252775=_0x5b234f;return _0x55e623&&(_0x252775=_0x252775['remove'](new E(_0x186bf1['name'],_0x55e623))),_0x252775['insert'](_0x186bf1,_0x186bf1['node']);}});return new ee(_0x453d48,this['indexSet_']);}['removeFromIndexes'](_0x4e649e,_0x53fd77){const _0x485e45=ln(this['indexes_'],_0x40a66b=>{if(_0x40a66b===je)return _0x40a66b;{const _0x5885dd=_0x53fd77['get'](_0x4e649e['name']);return _0x5885dd?_0x40a66b['remove'](new E(_0x4e649e['name'],_0x5885dd)):_0x40a66b;}});return new ee(_0x485e45,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3aac5d,_0x246bb9,_0x5d5e0d){this['children_']=_0x3aac5d,this['priorityNode_']=_0x246bb9,this['indexMap_']=_0x5d5e0d,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x516194){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x516194,this['indexMap_']);}['getImmediateChild'](_0xc360cc){if(_0xc360cc==='.priority')return this['getPriority']();{const _0x46e607=this['children_']['get'](_0xc360cc);return _0x46e607===null?gt:_0x46e607;}}['getChild'](_0x5b773c){const _0x37e4b1=y(_0x5b773c);return _0x37e4b1===null?this:this['getImmediateChild'](_0x37e4b1)['getChild'](b(_0x5b773c));}['hasChild'](_0x1e598b){return this['children_']['get'](_0x1e598b)!==null;}['updateImmediateChild'](_0x1902f8,_0x1cc5d5){if(f(_0x1cc5d5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1902f8==='.priority')return this['updatePriority'](_0x1cc5d5);{const _0x598c20=new E(_0x1902f8,_0x1cc5d5);let _0x40b739,_0x5425c8;_0x1cc5d5['isEmpty']()?(_0x40b739=this['children_']['remove'](_0x1902f8),_0x5425c8=this['indexMap_']['removeFromIndexes'](_0x598c20,this['children_'])):(_0x40b739=this['children_']['insert'](_0x1902f8,_0x1cc5d5),_0x5425c8=this['indexMap_']['addToIndexes'](_0x598c20,this['children_']));const _0x2fe4c4=_0x40b739['isEmpty']()?gt:this['priorityNode_'];return new g(_0x40b739,_0x2fe4c4,_0x5425c8);}}['updateChild'](_0x325a2e,_0x13acf9){const _0x4eff73=y(_0x325a2e);if(_0x4eff73===null)return _0x13acf9;{f(y(_0x325a2e)!=='.priority'||we(_0x325a2e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xd64d69=this['getImmediateChild'](_0x4eff73)['updateChild'](b(_0x325a2e),_0x13acf9);return this['updateImmediateChild'](_0x4eff73,_0xd64d69);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x28ea29){if(this['isEmpty']())return null;const _0xf0dbf4={};let _0x1b793e=0x0,_0x35c05d=0x0,_0x316767=!0x0;if(this['forEachChild'](R,(_0xdc2ee6,_0x4a75e7)=>{_0xf0dbf4[_0xdc2ee6]=_0x4a75e7['val'](_0x28ea29),_0x1b793e++,_0x316767&&g['INTEGER_REGEXP_']['test'](_0xdc2ee6)?_0x35c05d=Math['max'](_0x35c05d,Number(_0xdc2ee6)):_0x316767=!0x1;}),!_0x28ea29&&_0x316767&&_0x35c05d<0x2*_0x1b793e){const _0x4cd1cf=[];for(const _0xf08fe3 in _0xf0dbf4)_0x4cd1cf[_0xf08fe3]=_0xf0dbf4[_0xf08fe3];return _0x4cd1cf;}else return _0x28ea29&&!this['getPriority']()['isEmpty']()&&(_0xf0dbf4['.priority']=this['getPriority']()['val']()),_0xf0dbf4;}['hash'](){if(this['lazyHash_']===null){let _0x1a33aa='';this['getPriority']()['isEmpty']()||(_0x1a33aa+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x7d04c8,_0x46651e)=>{const _0x45549e=_0x46651e['hash']();_0x45549e!==''&&(_0x1a33aa+=':'+_0x7d04c8+':'+_0x45549e);}),this['lazyHash_']=_0x1a33aa===''?'':no(_0x1a33aa);}return this['lazyHash_'];}['getPredecessorChildName'](_0x182df4,_0x2a3c1a,_0x940f24){const _0x5278ca=this['resolveIndex_'](_0x940f24);if(_0x5278ca){const _0x4f0080=_0x5278ca['getPredecessorKey'](new E(_0x182df4,_0x2a3c1a));return _0x4f0080?_0x4f0080['name']:null;}else return this['children_']['getPredecessorKey'](_0x182df4);}['getFirstChildName'](_0x218acf){const _0x3647b3=this['resolveIndex_'](_0x218acf);if(_0x3647b3){const _0x4ae5f7=_0x3647b3['minKey']();return _0x4ae5f7&&_0x4ae5f7['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5c41d4){const _0x13bcae=this['getFirstChildName'](_0x5c41d4);return _0x13bcae?new E(_0x13bcae,this['children_']['get'](_0x13bcae)):null;}['getLastChildName'](_0x174e9b){const _0x2600bc=this['resolveIndex_'](_0x174e9b);if(_0x2600bc){const _0x3bd8fc=_0x2600bc['maxKey']();return _0x3bd8fc&&_0x3bd8fc['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2966f1){const _0x59be4a=this['getLastChildName'](_0x2966f1);return _0x59be4a?new E(_0x59be4a,this['children_']['get'](_0x59be4a)):null;}['forEachChild'](_0x1c0bca,_0x34959f){const _0x138e10=this['resolveIndex_'](_0x1c0bca);return _0x138e10?_0x138e10['inorderTraversal'](_0x4dd082=>_0x34959f(_0x4dd082['name'],_0x4dd082['node'])):this['children_']['inorderTraversal'](_0x34959f);}['getIterator'](_0x43a118){return this['getIteratorFrom'](_0x43a118['minPost'](),_0x43a118);}['getIteratorFrom'](_0x5bd34f,_0x5a0bee){const _0x54c831=this['resolveIndex_'](_0x5a0bee);if(_0x54c831)return _0x54c831['getIteratorFrom'](_0x5bd34f,_0x2cdd17=>_0x2cdd17);{const _0x3e499c=this['children_']['getIteratorFrom'](_0x5bd34f['name'],E['Wrap']);let _0x26af53=_0x3e499c['peek']();for(;_0x26af53!=null&&_0x5a0bee['compare'](_0x26af53,_0x5bd34f)<0x0;)_0x3e499c['getNext'](),_0x26af53=_0x3e499c['peek']();return _0x3e499c;}}['getReverseIterator'](_0x44b37f){return this['getReverseIteratorFrom'](_0x44b37f['maxPost'](),_0x44b37f);}['getReverseIteratorFrom'](_0x5ade1e,_0x4f576e){const _0x5bc804=this['resolveIndex_'](_0x4f576e);if(_0x5bc804)return _0x5bc804['getReverseIteratorFrom'](_0x5ade1e,_0x293eac=>_0x293eac);{const _0x333de=this['children_']['getReverseIteratorFrom'](_0x5ade1e['name'],E['Wrap']);let _0x450a7f=_0x333de['peek']();for(;_0x450a7f!=null&&_0x4f576e['compare'](_0x450a7f,_0x5ade1e)>0x0;)_0x333de['getNext'](),_0x450a7f=_0x333de['peek']();return _0x333de;}}['compareTo'](_0xbc470c){return this['isEmpty']()?_0xbc470c['isEmpty']()?0x0:-0x1:_0xbc470c['isLeafNode']()||_0xbc470c['isEmpty']()?0x1:_0xbc470c===Ht?-0x1:0x0;}['withIndex'](_0x234f85){if(_0x234f85===ye||this['indexMap_']['hasIndex'](_0x234f85))return this;{const _0x9cf841=this['indexMap_']['addIndex'](_0x234f85,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x9cf841);}}['isIndexed'](_0x570315){return _0x570315===ye||this['indexMap_']['hasIndex'](_0x570315);}['equals'](_0x1024b4){if(_0x1024b4===this)return!0x0;if(_0x1024b4['isLeafNode']())return!0x1;{const _0x50a210=_0x1024b4;if(this['getPriority']()['equals'](_0x50a210['getPriority']())){if(this['children_']['count']()===_0x50a210['children_']['count']()){const _0xe5351e=this['getIterator'](R),_0x2f2120=_0x50a210['getIterator'](R);let _0x1cf503=_0xe5351e['getNext'](),_0x34754e=_0x2f2120['getNext']();for(;_0x1cf503&&_0x34754e;){if(_0x1cf503['name']!==_0x34754e['name']||!_0x1cf503['node']['equals'](_0x34754e['node']))return!0x1;_0x1cf503=_0xe5351e['getNext'](),_0x34754e=_0x2f2120['getNext']();}return _0x1cf503===null&&_0x34754e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x100f20){return _0x100f20===ye?null:this['indexMap_']['get'](_0x100f20['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x3f5b61){return _0x3f5b61===this?0x0:0x1;}['equals'](_0x174bd9){return _0x174bd9===this;}['getPriority'](){return this;}['getImmediateChild'](_0xeac12e){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x33aa27,_0x56105d=null){if(_0x33aa27===null)return g['EMPTY_NODE'];if(typeof _0x33aa27=='object'&&'.priority'in _0x33aa27&&(_0x56105d=_0x33aa27['.priority']),f(_0x56105d===null||typeof _0x56105d=='string'||typeof _0x56105d=='number'||typeof _0x56105d=='object'&&'.sv'in _0x56105d,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x56105d),typeof _0x33aa27=='object'&&'.value'in _0x33aa27&&_0x33aa27['.value']!==null&&(_0x33aa27=_0x33aa27['.value']),typeof _0x33aa27!='object'||'.sv'in _0x33aa27){const _0x371098=_0x33aa27;return new D(_0x371098,N(_0x56105d));}if(!(_0x33aa27 instanceof Array)&&Vh){const _0x30dec8=[];let _0x208803=!0x1;if(x(_0x33aa27,(_0x18277e,_0x14a7f4)=>{if(_0x18277e['substring'](0x0,0x1)!=='.'){const _0x163fe6=N(_0x14a7f4);_0x163fe6['isEmpty']()||(_0x208803=_0x208803||!_0x163fe6['getPriority']()['isEmpty'](),_0x30dec8['push'](new E(_0x18277e,_0x163fe6)));}}),_0x30dec8['length']===0x0)return g['EMPTY_NODE'];const _0x5e3b07=dn(_0x30dec8,Dh,_0x5a9183=>_0x5a9183['name'],ji);if(_0x208803){const _0x202dfb=dn(_0x30dec8,R['getCompare']());return new g(_0x5e3b07,N(_0x56105d),new ee({'.priority':_0x202dfb},{'.priority':R}));}else return new g(_0x5e3b07,N(_0x56105d),ee['Default']);}else{let _0x4b296a=g['EMPTY_NODE'];return x(_0x33aa27,(_0x5abddb,_0x19d2ee)=>{if(Y(_0x33aa27,_0x5abddb)&&_0x5abddb['substring'](0x0,0x1)!=='.'){const _0x392e1b=N(_0x19d2ee);(_0x392e1b['isLeafNode']()||!_0x392e1b['isEmpty']())&&(_0x4b296a=_0x4b296a['updateImmediateChild'](_0x5abddb,_0x392e1b));}}),_0x4b296a['updatePriority'](N(_0x56105d));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x257bad){super(),this['indexPath_']=_0x257bad,f(!v(_0x257bad)&&y(_0x257bad)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2be0da){return _0x2be0da['getChild'](this['indexPath_']);}['isDefinedOn'](_0x261012){return!_0x261012['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4275b0,_0x2410f4){const _0x22f829=this['extractChild'](_0x4275b0['node']),_0x3eaf6f=this['extractChild'](_0x2410f4['node']),_0x46a2b0=_0x22f829['compareTo'](_0x3eaf6f);return _0x46a2b0===0x0?He(_0x4275b0['name'],_0x2410f4['name']):_0x46a2b0;}['makePost'](_0x5d43d8,_0x14f73f){const _0x313c09=N(_0x5d43d8),_0x476df7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x313c09);return new E(_0x14f73f,_0x476df7);}['maxPost'](){const _0x3ebe90=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x3ebe90);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x4a7af8,_0x595e05){const _0x31bac0=_0x4a7af8['node']['compareTo'](_0x595e05['node']);return _0x31bac0===0x0?He(_0x4a7af8['name'],_0x595e05['name']):_0x31bac0;}['isDefinedOn'](_0x5ee40f){return!0x0;}['indexedValueChanged'](_0x19e689,_0x1b2dc4){return!_0x19e689['equals'](_0x1b2dc4);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4b4f04,_0x329b10){const _0x130d00=N(_0x4b4f04);return new E(_0x329b10,_0x130d00);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5ef2a2){return{'type':'value','snapshotNode':_0x5ef2a2};}function tt(_0xf3adce,_0x39fb49){return{'type':'child_added','snapshotNode':_0x39fb49,'childName':_0xf3adce};}function Nt(_0x18d259,_0x25193a){return{'type':'child_removed','snapshotNode':_0x25193a,'childName':_0x18d259};}function Pt(_0x5af864,_0xe7691,_0xd7e3ff){return{'type':'child_changed','snapshotNode':_0xe7691,'childName':_0x5af864,'oldSnap':_0xd7e3ff};}function $h(_0x52f31f,_0x388b61){return{'type':'child_moved','snapshotNode':_0x388b61,'childName':_0x52f31f};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x238be1){this['index_']=_0x238be1;}['updateChild'](_0x3939e2,_0x35ec9e,_0xfc4990,_0x5ace51,_0x171a6c,_0x3b377c){f(_0x3939e2['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4a3ecf=_0x3939e2['getImmediateChild'](_0x35ec9e);return _0x4a3ecf['getChild'](_0x5ace51)['equals'](_0xfc4990['getChild'](_0x5ace51))&&_0x4a3ecf['isEmpty']()===_0xfc4990['isEmpty']()||(_0x3b377c!=null&&(_0xfc4990['isEmpty']()?_0x3939e2['hasChild'](_0x35ec9e)?_0x3b377c['trackChildChange'](Nt(_0x35ec9e,_0x4a3ecf)):f(_0x3939e2['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4a3ecf['isEmpty']()?_0x3b377c['trackChildChange'](tt(_0x35ec9e,_0xfc4990)):_0x3b377c['trackChildChange'](Pt(_0x35ec9e,_0xfc4990,_0x4a3ecf))),_0x3939e2['isLeafNode']()&&_0xfc4990['isEmpty']())?_0x3939e2:_0x3939e2['updateImmediateChild'](_0x35ec9e,_0xfc4990)['withIndex'](this['index_']);}['updateFullNode'](_0x4a4842,_0x1df89d,_0x3554fe){return _0x3554fe!=null&&(_0x4a4842['isLeafNode']()||_0x4a4842['forEachChild'](R,(_0x41bf10,_0xaaac89)=>{_0x1df89d['hasChild'](_0x41bf10)||_0x3554fe['trackChildChange'](Nt(_0x41bf10,_0xaaac89));}),_0x1df89d['isLeafNode']()||_0x1df89d['forEachChild'](R,(_0x876a36,_0x29a891)=>{if(_0x4a4842['hasChild'](_0x876a36)){const _0x2af990=_0x4a4842['getImmediateChild'](_0x876a36);_0x2af990['equals'](_0x29a891)||_0x3554fe['trackChildChange'](Pt(_0x876a36,_0x29a891,_0x2af990));}else _0x3554fe['trackChildChange'](tt(_0x876a36,_0x29a891));})),_0x1df89d['withIndex'](this['index_']);}['updatePriority'](_0x176ab3,_0x270d66){return _0x176ab3['isEmpty']()?g['EMPTY_NODE']:_0x176ab3['updatePriority'](_0x270d66);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x207f19){this['indexedFilter_']=new Yi(_0x207f19['getIndex']()),this['index_']=_0x207f19['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x207f19),this['endPost_']=Ot['getEndPost_'](_0x207f19),this['startIsInclusive_']=!_0x207f19['startAfterSet_'],this['endIsInclusive_']=!_0x207f19['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3b5bc4){const _0x45ef51=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3b5bc4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3b5bc4)<0x0,_0x1728a2=this['endIsInclusive_']?this['index_']['compare'](_0x3b5bc4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3b5bc4,this['getEndPost']())<0x0;return _0x45ef51&&_0x1728a2;}['updateChild'](_0x2604f6,_0x4685e6,_0x51b093,_0x5818eb,_0x3e1175,_0x4cbd02){return this['matches'](new E(_0x4685e6,_0x51b093))||(_0x51b093=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2604f6,_0x4685e6,_0x51b093,_0x5818eb,_0x3e1175,_0x4cbd02);}['updateFullNode'](_0x4e4da2,_0x4ceb2e,_0x34d617){_0x4ceb2e['isLeafNode']()&&(_0x4ceb2e=g['EMPTY_NODE']);let _0x1ff25a=_0x4ceb2e['withIndex'](this['index_']);_0x1ff25a=_0x1ff25a['updatePriority'](g['EMPTY_NODE']);const _0x509b87=this;return _0x4ceb2e['forEachChild'](R,(_0x25f923,_0x505e73)=>{_0x509b87['matches'](new E(_0x25f923,_0x505e73))||(_0x1ff25a=_0x1ff25a['updateImmediateChild'](_0x25f923,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4e4da2,_0x1ff25a,_0x34d617);}['updatePriority'](_0x7b803,_0x3267ae){return _0x7b803;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x171931){if(_0x171931['hasStart']()){const _0x1c8a06=_0x171931['getIndexStartName']();return _0x171931['getIndex']()['makePost'](_0x171931['getIndexStartValue'](),_0x1c8a06);}else return _0x171931['getIndex']()['minPost']();}static['getEndPost_'](_0x404548){if(_0x404548['hasEnd']()){const _0x4ba6b9=_0x404548['getIndexEndName']();return _0x404548['getIndex']()['makePost'](_0x404548['getIndexEndValue'](),_0x4ba6b9);}else return _0x404548['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x4a72e5){this['withinDirectionalStart']=_0x359907=>this['reverse_']?this['withinEndPost'](_0x359907):this['withinStartPost'](_0x359907),this['withinDirectionalEnd']=_0x1c564d=>this['reverse_']?this['withinStartPost'](_0x1c564d):this['withinEndPost'](_0x1c564d),this['withinStartPost']=_0x406fb3=>{const _0x23f9b4=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x406fb3);return this['startIsInclusive_']?_0x23f9b4<=0x0:_0x23f9b4<0x0;},this['withinEndPost']=_0x23aca6=>{const _0x52cad7=this['index_']['compare'](_0x23aca6,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x52cad7<=0x0:_0x52cad7<0x0;},this['rangedFilter_']=new Ot(_0x4a72e5),this['index_']=_0x4a72e5['getIndex'](),this['limit_']=_0x4a72e5['getLimit'](),this['reverse_']=!_0x4a72e5['isViewFromLeft'](),this['startIsInclusive_']=!_0x4a72e5['startAfterSet_'],this['endIsInclusive_']=!_0x4a72e5['endBeforeSet_'];}['updateChild'](_0x5082b4,_0x1f9a6b,_0xbb221a,_0x1a48e8,_0x358f17,_0x26923e){return this['rangedFilter_']['matches'](new E(_0x1f9a6b,_0xbb221a))||(_0xbb221a=g['EMPTY_NODE']),_0x5082b4['getImmediateChild'](_0x1f9a6b)['equals'](_0xbb221a)?_0x5082b4:_0x5082b4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5082b4,_0x1f9a6b,_0xbb221a,_0x1a48e8,_0x358f17,_0x26923e):this['fullLimitUpdateChild_'](_0x5082b4,_0x1f9a6b,_0xbb221a,_0x358f17,_0x26923e);}['updateFullNode'](_0x307a8c,_0x44eca1,_0x5cdd45){let _0x5dd310;if(_0x44eca1['isLeafNode']()||_0x44eca1['isEmpty']())_0x5dd310=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x44eca1['numChildren']()&&_0x44eca1['isIndexed'](this['index_'])){_0x5dd310=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x32669b;this['reverse_']?_0x32669b=_0x44eca1['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x32669b=_0x44eca1['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x8173cc=0x0;for(;_0x32669b['hasNext']()&&_0x8173cc<this['limit_'];){const _0x22f0db=_0x32669b['getNext']();if(this['withinDirectionalStart'](_0x22f0db)){if(this['withinDirectionalEnd'](_0x22f0db))_0x5dd310=_0x5dd310['updateImmediateChild'](_0x22f0db['name'],_0x22f0db['node']),_0x8173cc++;else break;}else continue;}}else{_0x5dd310=_0x44eca1['withIndex'](this['index_']),_0x5dd310=_0x5dd310['updatePriority'](g['EMPTY_NODE']);let _0x3b2846;this['reverse_']?_0x3b2846=_0x5dd310['getReverseIterator'](this['index_']):_0x3b2846=_0x5dd310['getIterator'](this['index_']);let _0x2e7877=0x0;for(;_0x3b2846['hasNext']();){const _0x299369=_0x3b2846['getNext']();_0x2e7877<this['limit_']&&this['withinDirectionalStart'](_0x299369)&&this['withinDirectionalEnd'](_0x299369)?_0x2e7877++:_0x5dd310=_0x5dd310['updateImmediateChild'](_0x299369['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x307a8c,_0x5dd310,_0x5cdd45);}['updatePriority'](_0x410ac3,_0x873264){return _0x410ac3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5c673d,_0x583f3d,_0x4fb681,_0x37771b,_0x23ee6){let _0x2a4393;if(this['reverse_']){const _0x22af07=this['index_']['getCompare']();_0x2a4393=(_0x3f7aaf,_0x52316b)=>_0x22af07(_0x52316b,_0x3f7aaf);}else _0x2a4393=this['index_']['getCompare']();const _0x1753dc=_0x5c673d;f(_0x1753dc['numChildren']()===this['limit_'],'');const _0x35802e=new E(_0x583f3d,_0x4fb681),_0x262458=this['reverse_']?_0x1753dc['getFirstChild'](this['index_']):_0x1753dc['getLastChild'](this['index_']),_0x40488e=this['rangedFilter_']['matches'](_0x35802e);if(_0x1753dc['hasChild'](_0x583f3d)){const _0x2ba29b=_0x1753dc['getImmediateChild'](_0x583f3d);let _0x5bad65=_0x37771b['getChildAfterChild'](this['index_'],_0x262458,this['reverse_']);for(;_0x5bad65!=null&&(_0x5bad65['name']===_0x583f3d||_0x1753dc['hasChild'](_0x5bad65['name']));)_0x5bad65=_0x37771b['getChildAfterChild'](this['index_'],_0x5bad65,this['reverse_']);const _0x5a3524=_0x5bad65==null?0x1:_0x2a4393(_0x5bad65,_0x35802e);if(_0x40488e&&!_0x4fb681['isEmpty']()&&_0x5a3524>=0x0)return _0x23ee6!=null&&_0x23ee6['trackChildChange'](Pt(_0x583f3d,_0x4fb681,_0x2ba29b)),_0x1753dc['updateImmediateChild'](_0x583f3d,_0x4fb681);{_0x23ee6!=null&&_0x23ee6['trackChildChange'](Nt(_0x583f3d,_0x2ba29b));const _0x12987b=_0x1753dc['updateImmediateChild'](_0x583f3d,g['EMPTY_NODE']);return _0x5bad65!=null&&this['rangedFilter_']['matches'](_0x5bad65)?(_0x23ee6!=null&&_0x23ee6['trackChildChange'](tt(_0x5bad65['name'],_0x5bad65['node'])),_0x12987b['updateImmediateChild'](_0x5bad65['name'],_0x5bad65['node'])):_0x12987b;}}else return _0x4fb681['isEmpty']()?_0x5c673d:_0x40488e&&_0x2a4393(_0x262458,_0x35802e)>=0x0?(_0x23ee6!=null&&(_0x23ee6['trackChildChange'](Nt(_0x262458['name'],_0x262458['node'])),_0x23ee6['trackChildChange'](tt(_0x583f3d,_0x4fb681))),_0x1753dc['updateImmediateChild'](_0x583f3d,_0x4fb681)['updateImmediateChild'](_0x262458['name'],g['EMPTY_NODE'])):_0x5c673d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xd7c15e=new Qi();return _0xd7c15e['limitSet_']=this['limitSet_'],_0xd7c15e['limit_']=this['limit_'],_0xd7c15e['startSet_']=this['startSet_'],_0xd7c15e['startAfterSet_']=this['startAfterSet_'],_0xd7c15e['indexStartValue_']=this['indexStartValue_'],_0xd7c15e['startNameSet_']=this['startNameSet_'],_0xd7c15e['indexStartName_']=this['indexStartName_'],_0xd7c15e['endSet_']=this['endSet_'],_0xd7c15e['endBeforeSet_']=this['endBeforeSet_'],_0xd7c15e['indexEndValue_']=this['indexEndValue_'],_0xd7c15e['endNameSet_']=this['endNameSet_'],_0xd7c15e['indexEndName_']=this['indexEndName_'],_0xd7c15e['index_']=this['index_'],_0xd7c15e['viewFrom_']=this['viewFrom_'],_0xd7c15e;}}function qh(_0xee8585){return _0xee8585['loadsAllData']()?new Yi(_0xee8585['getIndex']()):_0xee8585['hasLimit']()?new Gh(_0xee8585):new Ot(_0xee8585);}function zh(_0x204185,_0x4b9025){const _0x343ea1=_0x204185['copy']();return _0x343ea1['limitSet_']=!0x0,_0x343ea1['limit_']=_0x4b9025,_0x343ea1['viewFrom_']='l',_0x343ea1;}function jh(_0x91277a,_0x6b23cc,_0x26a03a){const _0x29d76e=_0x91277a['copy']();return _0x29d76e['startSet_']=!0x0,_0x6b23cc===void 0x0&&(_0x6b23cc=null),_0x29d76e['indexStartValue_']=_0x6b23cc,_0x26a03a!=null?(_0x29d76e['startNameSet_']=!0x0,_0x29d76e['indexStartName_']=_0x26a03a):(_0x29d76e['startNameSet_']=!0x1,_0x29d76e['indexStartName_']=''),_0x29d76e;}function Kh(_0x1230c3,_0x48cb64,_0x21be73){const _0x19d561=_0x1230c3['copy']();return _0x19d561['endSet_']=!0x0,_0x48cb64===void 0x0&&(_0x48cb64=null),_0x19d561['indexEndValue_']=_0x48cb64,_0x21be73!==void 0x0?(_0x19d561['endNameSet_']=!0x0,_0x19d561['indexEndName_']=_0x21be73):(_0x19d561['endNameSet_']=!0x1,_0x19d561['indexEndName_']=''),_0x19d561;}function Do(_0x1b59d2,_0x1a4f47){const _0x2c6153=_0x1b59d2['copy']();return _0x2c6153['index_']=_0x1a4f47,_0x2c6153;}function tr(_0x57a1a6){const _0x2fc5b2={};if(_0x57a1a6['isDefault']())return _0x2fc5b2;let _0x5b07b5;if(_0x57a1a6['index_']===R?_0x5b07b5='$priority':_0x57a1a6['index_']===Po?_0x5b07b5='$value':_0x57a1a6['index_']===ye?_0x5b07b5='$key':(f(_0x57a1a6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5b07b5=_0x57a1a6['index_']['toString']()),_0x2fc5b2['orderBy']=O(_0x5b07b5),_0x57a1a6['startSet_']){const _0x5eb189=_0x57a1a6['startAfterSet_']?'startAfter':'startAt';_0x2fc5b2[_0x5eb189]=O(_0x57a1a6['indexStartValue_']),_0x57a1a6['startNameSet_']&&(_0x2fc5b2[_0x5eb189]+=','+O(_0x57a1a6['indexStartName_']));}if(_0x57a1a6['endSet_']){const _0x55dc9b=_0x57a1a6['endBeforeSet_']?'endBefore':'endAt';_0x2fc5b2[_0x55dc9b]=O(_0x57a1a6['indexEndValue_']),_0x57a1a6['endNameSet_']&&(_0x2fc5b2[_0x55dc9b]+=','+O(_0x57a1a6['indexEndName_']));}return _0x57a1a6['limitSet_']&&(_0x57a1a6['isViewFromLeft']()?_0x2fc5b2['limitToFirst']=_0x57a1a6['limit_']:_0x2fc5b2['limitToLast']=_0x57a1a6['limit_']),_0x2fc5b2;}function nr(_0x471e35){const _0x49c5a8={};if(_0x471e35['startSet_']&&(_0x49c5a8['sp']=_0x471e35['indexStartValue_'],_0x471e35['startNameSet_']&&(_0x49c5a8['sn']=_0x471e35['indexStartName_']),_0x49c5a8['sin']=!_0x471e35['startAfterSet_']),_0x471e35['endSet_']&&(_0x49c5a8['ep']=_0x471e35['indexEndValue_'],_0x471e35['endNameSet_']&&(_0x49c5a8['en']=_0x471e35['indexEndName_']),_0x49c5a8['ein']=!_0x471e35['endBeforeSet_']),_0x471e35['limitSet_']){_0x49c5a8['l']=_0x471e35['limit_'];let _0x4e1c43=_0x471e35['viewFrom_'];_0x4e1c43===''&&(_0x471e35['isViewFromLeft']()?_0x4e1c43='l':_0x4e1c43='r'),_0x49c5a8['vf']=_0x4e1c43;}return _0x471e35['index_']!==R&&(_0x49c5a8['i']=_0x471e35['index_']['toString']()),_0x49c5a8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x4ea185){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x189dc2,_0x54d0ab){return _0x54d0ab!==void 0x0?'tag$'+_0x54d0ab:(f(_0x189dc2['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x189dc2['_path']['toString']());}constructor(_0x373754,_0x53eb55,_0xabfaaf,_0x2ed88f){super(),this['repoInfo_']=_0x373754,this['onDataUpdate_']=_0x53eb55,this['authTokenProvider_']=_0xabfaaf,this['appCheckTokenProvider_']=_0x2ed88f,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2213cb,_0xa58def,_0x5f1264,_0x34e192){const _0x1e2500=_0x2213cb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1e2500+'\x20'+_0x2213cb['_queryIdentifier']);const _0x296f8a=fn['getListenId_'](_0x2213cb,_0x5f1264),_0x1bcd2b={};this['listens_'][_0x296f8a]=_0x1bcd2b;const _0xb0e506=tr(_0x2213cb['_queryParams']);this['restRequest_'](_0x1e2500+'.json',_0xb0e506,(_0x259571,_0x30ef37)=>{let _0x1c975f=_0x30ef37;if(_0x259571===0x194&&(_0x1c975f=null,_0x259571=null),_0x259571===null&&this['onDataUpdate_'](_0x1e2500,_0x1c975f,!0x1,_0x5f1264),Oe(this['listens_'],_0x296f8a)===_0x1bcd2b){let _0x54fc70;_0x259571?_0x259571===0x191?_0x54fc70='permission_denied':_0x54fc70='rest_error:'+_0x259571:_0x54fc70='ok',_0x34e192(_0x54fc70,null);}});}['unlisten'](_0x2ee9c3,_0x2f184c){const _0x5e6ed2=fn['getListenId_'](_0x2ee9c3,_0x2f184c);delete this['listens_'][_0x5e6ed2];}['get'](_0x3ed636){const _0x11f0c1=tr(_0x3ed636['_queryParams']),_0x59361a=_0x3ed636['_path']['toString'](),_0x472338=new Ve();return this['restRequest_'](_0x59361a+'.json',_0x11f0c1,(_0x4ad38b,_0x3777d6)=>{let _0x1fd0e9=_0x3777d6;_0x4ad38b===0x194&&(_0x1fd0e9=null,_0x4ad38b=null),_0x4ad38b===null?(this['onDataUpdate_'](_0x59361a,_0x1fd0e9,!0x1,null),_0x472338['resolve'](_0x1fd0e9)):_0x472338['reject'](new Error(_0x1fd0e9));}),_0x472338['promise'];}['refreshAuthToken'](_0x5ae8a3){}['restRequest_'](_0x20298b,_0x4d595c={},_0x2676ae){return _0x4d595c['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3c5b33,_0x1aee7f])=>{_0x3c5b33&&_0x3c5b33['accessToken']&&(_0x4d595c['auth']=_0x3c5b33['accessToken']),_0x1aee7f&&_0x1aee7f['token']&&(_0x4d595c['ac']=_0x1aee7f['token']);const _0x1641a7=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x20298b+'?ns='+this['repoInfo_']['namespace']+at(_0x4d595c);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1641a7);const _0xb53c3a=new XMLHttpRequest();_0xb53c3a['onreadystatechange']=()=>{if(_0x2676ae&&_0xb53c3a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1641a7+'\x20received.\x20status:',_0xb53c3a['status'],'response:',_0xb53c3a['responseText']);let _0x5bc91a=null;if(_0xb53c3a['status']>=0xc8&&_0xb53c3a['status']<0x12c){try{_0x5bc91a=bt(_0xb53c3a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1641a7+':\x20'+_0xb53c3a['responseText']);}_0x2676ae(null,_0x5bc91a);}else _0xb53c3a['status']!==0x191&&_0xb53c3a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1641a7+'\x20Status:\x20'+_0xb53c3a['status']),_0x2676ae(_0xb53c3a['status']);_0x2676ae=null;}},_0xb53c3a['open']('GET',_0x1641a7,!0x0),_0xb53c3a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ac1e3){return this['rootNode_']['getChild'](_0x3ac1e3);}['updateSnapshot'](_0x4e6c2a,_0x4cc76b){this['rootNode_']=this['rootNode_']['updateChild'](_0x4e6c2a,_0x4cc76b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x25ae66,_0x356730,_0x20e0f7){if(v(_0x356730))_0x25ae66['value']=_0x20e0f7,_0x25ae66['children']['clear']();else{if(_0x25ae66['value']!==null)_0x25ae66['value']=_0x25ae66['value']['updateChild'](_0x356730,_0x20e0f7);else{const _0x4275ea=y(_0x356730);_0x25ae66['children']['has'](_0x4275ea)||_0x25ae66['children']['set'](_0x4275ea,pn());const _0x4a555f=_0x25ae66['children']['get'](_0x4275ea);_0x356730=b(_0x356730),Mo(_0x4a555f,_0x356730,_0x20e0f7);}}}function Ei(_0x151b37,_0x312690,_0x3d0a53){_0x151b37['value']!==null?_0x3d0a53(_0x312690,_0x151b37['value']):Qh(_0x151b37,(_0x1dd04a,_0x27d49e)=>{const _0x2b7f7a=new C(_0x312690['toString']()+'/'+_0x1dd04a);Ei(_0x27d49e,_0x2b7f7a,_0x3d0a53);});}function Qh(_0x39ad08,_0x2ef213){_0x39ad08['children']['forEach']((_0x265b02,_0x3e0eae)=>{_0x2ef213(_0x3e0eae,_0x265b02);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x17252c){this['collection_']=_0x17252c,this['last_']=null;}['get'](){const _0x47e064=this['collection_']['get'](),_0x1823d0={..._0x47e064};return this['last_']&&x(this['last_'],(_0x198989,_0xc57df8)=>{_0x1823d0[_0x198989]=_0x1823d0[_0x198989]-_0xc57df8;}),this['last_']=_0x47e064,_0x1823d0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x464155,_0x308661){this['server_']=_0x308661,this['statsToReport_']={},this['statsListener_']=new Jh(_0x464155);const _0xc8efbc=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0xc8efbc));}['reportStats_'](){const _0x2a0433=this['statsListener_']['get'](),_0x4b68c7={};let _0xd49c45=!0x1;x(_0x2a0433,(_0x544903,_0x163846)=>{_0x163846>0x0&&Y(this['statsToReport_'],_0x544903)&&(_0x4b68c7[_0x544903]=_0x163846,_0xd49c45=!0x0);}),_0xd49c45&&this['server_']['reportStats'](_0x4b68c7),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x25fc48){_0x25fc48[_0x25fc48['OVERWRITE']=0x0]='OVERWRITE',_0x25fc48[_0x25fc48['MERGE']=0x1]='MERGE',_0x25fc48[_0x25fc48['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x25fc48[_0x25fc48['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x62a6a1){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x62a6a1,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x1e6f1a,_0x93ecde,_0x132761){this['path']=_0x1e6f1a,this['affectedTree']=_0x93ecde,this['revert']=_0x132761,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x305f31){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2a813c=this['affectedTree']['subtree'](new C(_0x305f31));return new _n(w(),_0x2a813c,this['revert']);}}else return f(y(this['path'])===_0x305f31,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x2c4dab,_0x45ff3f){this['source']=_0x2c4dab,this['path']=_0x45ff3f,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3173e9){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x43579b,_0x3d4e90,_0x2a541){this['source']=_0x43579b,this['path']=_0x3d4e90,this['snap']=_0x2a541,this['type']=q['OVERWRITE'];}['operationForChild'](_0x25588d){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x25588d)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x1a64d7,_0x2017ec,_0x4c6557){this['source']=_0x1a64d7,this['path']=_0x2017ec,this['children']=_0x4c6557,this['type']=q['MERGE'];}['operationForChild'](_0x5684bd){if(v(this['path'])){const _0x56452a=this['children']['subtree'](new C(_0x5684bd));return _0x56452a['isEmpty']()?null:_0x56452a['value']?new Fe(this['source'],w(),_0x56452a['value']):new nt(this['source'],w(),_0x56452a);}else return f(y(this['path'])===_0x5684bd,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x7d3c64,_0x1ed6b8,_0x22dee8){this['node_']=_0x7d3c64,this['fullyInitialized_']=_0x1ed6b8,this['filtered_']=_0x22dee8;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xcdf67){if(v(_0xcdf67))return this['isFullyInitialized']()&&!this['filtered_'];const _0x555081=y(_0xcdf67);return this['isCompleteForChild'](_0x555081);}['isCompleteForChild'](_0x1b3f2c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1b3f2c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4e241b){this['query_']=_0x4e241b,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4b47ea,_0xf6e97f,_0x5ea360,_0x54196c){const _0x6393f2=[],_0x49e628=[];return _0xf6e97f['forEach'](_0x4ab174=>{_0x4ab174['type']==='child_changed'&&_0x4b47ea['index_']['indexedValueChanged'](_0x4ab174['oldSnap'],_0x4ab174['snapshotNode'])&&_0x49e628['push']($h(_0x4ab174['childName'],_0x4ab174['snapshotNode']));}),mt(_0x4b47ea,_0x6393f2,'child_removed',_0xf6e97f,_0x54196c,_0x5ea360),mt(_0x4b47ea,_0x6393f2,'child_added',_0xf6e97f,_0x54196c,_0x5ea360),mt(_0x4b47ea,_0x6393f2,'child_moved',_0x49e628,_0x54196c,_0x5ea360),mt(_0x4b47ea,_0x6393f2,'child_changed',_0xf6e97f,_0x54196c,_0x5ea360),mt(_0x4b47ea,_0x6393f2,'value',_0xf6e97f,_0x54196c,_0x5ea360),_0x6393f2;}function mt(_0x2774bf,_0x429b99,_0x9635f5,_0x13827b,_0x3a46a9,_0x462dfa){const _0x270d78=_0x13827b['filter'](_0x997db5=>_0x997db5['type']===_0x9635f5);_0x270d78['sort']((_0xca431f,_0x5beb7b)=>su(_0x2774bf,_0xca431f,_0x5beb7b)),_0x270d78['forEach'](_0x53c05a=>{const _0x58ccf1=iu(_0x2774bf,_0x53c05a,_0x462dfa);_0x3a46a9['forEach'](_0x3cc7b6=>{_0x3cc7b6['respondsTo'](_0x53c05a['type'])&&_0x429b99['push'](_0x3cc7b6['createEvent'](_0x58ccf1,_0x2774bf['query_']));});});}function iu(_0x50aca8,_0x3b9a84,_0x15f521){return _0x3b9a84['type']==='value'||_0x3b9a84['type']==='child_removed'||(_0x3b9a84['prevName']=_0x15f521['getPredecessorChildName'](_0x3b9a84['childName'],_0x3b9a84['snapshotNode'],_0x50aca8['index_'])),_0x3b9a84;}function su(_0x380c9e,_0x59d5b3,_0x2bab60){if(_0x59d5b3['childName']==null||_0x2bab60['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3f8e8d=new E(_0x59d5b3['childName'],_0x59d5b3['snapshotNode']),_0x260a17=new E(_0x2bab60['childName'],_0x2bab60['snapshotNode']);return _0x380c9e['index_']['compare'](_0x3f8e8d,_0x260a17);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xd31070,_0x25eef8){return{'eventCache':_0xd31070,'serverCache':_0x25eef8};}function wt(_0x2c1e38,_0x4e3cde,_0x508f8a,_0x205428){return Dn(new Ce(_0x4e3cde,_0x508f8a,_0x205428),_0x2c1e38['serverCache']);}function Lo(_0x20beb1,_0x5f559c,_0x25e146,_0x14098f){return Dn(_0x20beb1['eventCache'],new Ce(_0x5f559c,_0x25e146,_0x14098f));}function gn(_0x5e1f48){return _0x5e1f48['eventCache']['isFullyInitialized']()?_0x5e1f48['eventCache']['getNode']():null;}function Ue(_0x117df8){return _0x117df8['serverCache']['isFullyInitialized']()?_0x117df8['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x412032){let _0xb6625d=new S(null);return x(_0x412032,(_0x309818,_0x48d951)=>{_0xb6625d=_0xb6625d['set'](new C(_0x309818),_0x48d951);}),_0xb6625d;}constructor(_0x599b44,_0x20258c=ru()){this['value']=_0x599b44,this['children']=_0x20258c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x57ce8e,_0x1b611e){if(this['value']!=null&&_0x1b611e(this['value']))return{'path':w(),'value':this['value']};if(v(_0x57ce8e))return null;{const _0x51f8b0=y(_0x57ce8e),_0x5881fb=this['children']['get'](_0x51f8b0);if(_0x5881fb!==null){const _0xb80d15=_0x5881fb['findRootMostMatchingPathAndValue'](b(_0x57ce8e),_0x1b611e);return _0xb80d15!=null?{'path':A(new C(_0x51f8b0),_0xb80d15['path']),'value':_0xb80d15['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x260b33){return this['findRootMostMatchingPathAndValue'](_0x260b33,()=>!0x0);}['subtree'](_0x57a24b){if(v(_0x57a24b))return this;{const _0x4f5296=y(_0x57a24b),_0xadd972=this['children']['get'](_0x4f5296);return _0xadd972!==null?_0xadd972['subtree'](b(_0x57a24b)):new S(null);}}['set'](_0x300bdc,_0x271056){if(v(_0x300bdc))return new S(_0x271056,this['children']);{const _0x377a41=y(_0x300bdc),_0x29f966=(this['children']['get'](_0x377a41)||new S(null))['set'](b(_0x300bdc),_0x271056),_0x303712=this['children']['insert'](_0x377a41,_0x29f966);return new S(this['value'],_0x303712);}}['remove'](_0x1d64a2){if(v(_0x1d64a2))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x517d74=y(_0x1d64a2),_0x526212=this['children']['get'](_0x517d74);if(_0x526212){const _0x1a1693=_0x526212['remove'](b(_0x1d64a2));let _0x186f16;return _0x1a1693['isEmpty']()?_0x186f16=this['children']['remove'](_0x517d74):_0x186f16=this['children']['insert'](_0x517d74,_0x1a1693),this['value']===null&&_0x186f16['isEmpty']()?new S(null):new S(this['value'],_0x186f16);}else return this;}}['get'](_0x504b66){if(v(_0x504b66))return this['value'];{const _0x21f851=y(_0x504b66),_0x15ad9f=this['children']['get'](_0x21f851);return _0x15ad9f?_0x15ad9f['get'](b(_0x504b66)):null;}}['setTree'](_0x5d63b0,_0x4d8e83){if(v(_0x5d63b0))return _0x4d8e83;{const _0x104124=y(_0x5d63b0),_0x235c08=(this['children']['get'](_0x104124)||new S(null))['setTree'](b(_0x5d63b0),_0x4d8e83);let _0x1c3bab;return _0x235c08['isEmpty']()?_0x1c3bab=this['children']['remove'](_0x104124):_0x1c3bab=this['children']['insert'](_0x104124,_0x235c08),new S(this['value'],_0x1c3bab);}}['fold'](_0x166e9d){return this['fold_'](w(),_0x166e9d);}['fold_'](_0x4f0571,_0x52ab89){const _0x5b2213={};return this['children']['inorderTraversal']((_0x14a0d9,_0x1986a9)=>{_0x5b2213[_0x14a0d9]=_0x1986a9['fold_'](A(_0x4f0571,_0x14a0d9),_0x52ab89);}),_0x52ab89(_0x4f0571,this['value'],_0x5b2213);}['findOnPath'](_0x523711,_0xf01c39){return this['findOnPath_'](_0x523711,w(),_0xf01c39);}['findOnPath_'](_0x5b48b4,_0x3539ab,_0x42a8da){const _0x3e20af=this['value']?_0x42a8da(_0x3539ab,this['value']):!0x1;if(_0x3e20af)return _0x3e20af;if(v(_0x5b48b4))return null;{const _0xe2572=y(_0x5b48b4),_0x4df078=this['children']['get'](_0xe2572);return _0x4df078?_0x4df078['findOnPath_'](b(_0x5b48b4),A(_0x3539ab,_0xe2572),_0x42a8da):null;}}['foreachOnPath'](_0x474317,_0x4372c2){return this['foreachOnPath_'](_0x474317,w(),_0x4372c2);}['foreachOnPath_'](_0x17a183,_0x19555e,_0x313fc7){if(v(_0x17a183))return this;{this['value']&&_0x313fc7(_0x19555e,this['value']);const _0x21f774=y(_0x17a183),_0x22fde0=this['children']['get'](_0x21f774);return _0x22fde0?_0x22fde0['foreachOnPath_'](b(_0x17a183),A(_0x19555e,_0x21f774),_0x313fc7):new S(null);}}['foreach'](_0x5a6f42){this['foreach_'](w(),_0x5a6f42);}['foreach_'](_0x57692b,_0xaa96b2){this['children']['inorderTraversal']((_0x5a0f4e,_0x265147)=>{_0x265147['foreach_'](A(_0x57692b,_0x5a0f4e),_0xaa96b2);}),this['value']&&_0xaa96b2(_0x57692b,this['value']);}['foreachChild'](_0x56beb0){this['children']['inorderTraversal']((_0x433dcf,_0x251ce4)=>{_0x251ce4['value']&&_0x56beb0(_0x433dcf,_0x251ce4['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x32c045){this['writeTree_']=_0x32c045;}static['empty'](){return new j(new S(null));}}function Ct(_0x5ef9db,_0x24c3e0,_0x36ec67){if(v(_0x24c3e0))return new j(new S(_0x36ec67));{const _0x28b01b=_0x5ef9db['writeTree_']['findRootMostValueAndPath'](_0x24c3e0);if(_0x28b01b!=null){const _0x3d6802=_0x28b01b['path'];let _0x3faca3=_0x28b01b['value'];const _0x4cbbef=F(_0x3d6802,_0x24c3e0);return _0x3faca3=_0x3faca3['updateChild'](_0x4cbbef,_0x36ec67),new j(_0x5ef9db['writeTree_']['set'](_0x3d6802,_0x3faca3));}else{const _0x46c501=new S(_0x36ec67),_0x1191d2=_0x5ef9db['writeTree_']['setTree'](_0x24c3e0,_0x46c501);return new j(_0x1191d2);}}}function Ii(_0x1cd86f,_0x1a154f,_0x4da226){let _0x353f82=_0x1cd86f;return x(_0x4da226,(_0x5a03a3,_0x26c03f)=>{_0x353f82=Ct(_0x353f82,A(_0x1a154f,_0x5a03a3),_0x26c03f);}),_0x353f82;}function sr(_0x2a2cac,_0x2b3396){if(v(_0x2b3396))return j['empty']();{const _0x3c4320=_0x2a2cac['writeTree_']['setTree'](_0x2b3396,new S(null));return new j(_0x3c4320);}}function wi(_0x80677c,_0x1bb8c0){return $e(_0x80677c,_0x1bb8c0)!=null;}function $e(_0xa35d9c,_0x47caa8){const _0x3c993d=_0xa35d9c['writeTree_']['findRootMostValueAndPath'](_0x47caa8);return _0x3c993d!=null?_0xa35d9c['writeTree_']['get'](_0x3c993d['path'])['getChild'](F(_0x3c993d['path'],_0x47caa8)):null;}function rr(_0x4ca104){const _0x41f3c8=[],_0x34031d=_0x4ca104['writeTree_']['value'];return _0x34031d!=null?_0x34031d['isLeafNode']()||_0x34031d['forEachChild'](R,(_0x58bf27,_0x121684)=>{_0x41f3c8['push'](new E(_0x58bf27,_0x121684));}):_0x4ca104['writeTree_']['children']['inorderTraversal']((_0x2d7c03,_0x2dd3ff)=>{_0x2dd3ff['value']!=null&&_0x41f3c8['push'](new E(_0x2d7c03,_0x2dd3ff['value']));}),_0x41f3c8;}function ve(_0x3c143d,_0x5a45d5){if(v(_0x5a45d5))return _0x3c143d;{const _0x3ef7fb=$e(_0x3c143d,_0x5a45d5);return _0x3ef7fb!=null?new j(new S(_0x3ef7fb)):new j(_0x3c143d['writeTree_']['subtree'](_0x5a45d5));}}function Ci(_0x2e620d){return _0x2e620d['writeTree_']['isEmpty']();}function it(_0x2bc01a,_0x69117d){return xo(w(),_0x2bc01a['writeTree_'],_0x69117d);}function xo(_0x3d105a,_0x388d47,_0xe6ce0c){if(_0x388d47['value']!=null)return _0xe6ce0c['updateChild'](_0x3d105a,_0x388d47['value']);{let _0x583a37=null;return _0x388d47['children']['inorderTraversal']((_0x173233,_0x2451dc)=>{_0x173233==='.priority'?(f(_0x2451dc['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x583a37=_0x2451dc['value']):_0xe6ce0c=xo(A(_0x3d105a,_0x173233),_0x2451dc,_0xe6ce0c);}),!_0xe6ce0c['getChild'](_0x3d105a)['isEmpty']()&&_0x583a37!==null&&(_0xe6ce0c=_0xe6ce0c['updateChild'](A(_0x3d105a,'.priority'),_0x583a37)),_0xe6ce0c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1131ee,_0x288a7a){return Bo(_0x288a7a,_0x1131ee);}function ou(_0x2daba9,_0x1c3f03,_0x5dc444,_0xb41beb,_0x447bab){f(_0xb41beb>_0x2daba9['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x447bab===void 0x0&&(_0x447bab=!0x0),_0x2daba9['allWrites']['push']({'path':_0x1c3f03,'snap':_0x5dc444,'writeId':_0xb41beb,'visible':_0x447bab}),_0x447bab&&(_0x2daba9['visibleWrites']=Ct(_0x2daba9['visibleWrites'],_0x1c3f03,_0x5dc444)),_0x2daba9['lastWriteId']=_0xb41beb;}function au(_0x507917,_0x12170e,_0x3ff954,_0x28d59d){f(_0x28d59d>_0x507917['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x507917['allWrites']['push']({'path':_0x12170e,'children':_0x3ff954,'writeId':_0x28d59d,'visible':!0x0}),_0x507917['visibleWrites']=Ii(_0x507917['visibleWrites'],_0x12170e,_0x3ff954),_0x507917['lastWriteId']=_0x28d59d;}function cu(_0x3059a9,_0xcab129){for(let _0x151ff3=0x0;_0x151ff3<_0x3059a9['allWrites']['length'];_0x151ff3++){const _0x38990f=_0x3059a9['allWrites'][_0x151ff3];if(_0x38990f['writeId']===_0xcab129)return _0x38990f;}return null;}function lu(_0x5978bb,_0x5390cb){const _0x1b6eb4=_0x5978bb['allWrites']['findIndex'](_0x478a98=>_0x478a98['writeId']===_0x5390cb);f(_0x1b6eb4>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4dca59=_0x5978bb['allWrites'][_0x1b6eb4];_0x5978bb['allWrites']['splice'](_0x1b6eb4,0x1);let _0x15b641=_0x4dca59['visible'],_0x53e793=!0x1,_0x2c632d=_0x5978bb['allWrites']['length']-0x1;for(;_0x15b641&&_0x2c632d>=0x0;){const _0x51c64e=_0x5978bb['allWrites'][_0x2c632d];_0x51c64e['visible']&&(_0x2c632d>=_0x1b6eb4&&hu(_0x51c64e,_0x4dca59['path'])?_0x15b641=!0x1:$(_0x4dca59['path'],_0x51c64e['path'])&&(_0x53e793=!0x0)),_0x2c632d--;}if(_0x15b641){if(_0x53e793)return uu(_0x5978bb),!0x0;if(_0x4dca59['snap'])_0x5978bb['visibleWrites']=sr(_0x5978bb['visibleWrites'],_0x4dca59['path']);else{const _0x18a870=_0x4dca59['children'];x(_0x18a870,_0x4b41d1=>{_0x5978bb['visibleWrites']=sr(_0x5978bb['visibleWrites'],A(_0x4dca59['path'],_0x4b41d1));});}return!0x0;}else return!0x1;}function hu(_0x3c0d10,_0x37bdc0){if(_0x3c0d10['snap'])return $(_0x3c0d10['path'],_0x37bdc0);for(const _0x42f593 in _0x3c0d10['children'])if(_0x3c0d10['children']['hasOwnProperty'](_0x42f593)&&$(A(_0x3c0d10['path'],_0x42f593),_0x37bdc0))return!0x0;return!0x1;}function uu(_0x29c0dc){_0x29c0dc['visibleWrites']=Fo(_0x29c0dc['allWrites'],du,w()),_0x29c0dc['allWrites']['length']>0x0?_0x29c0dc['lastWriteId']=_0x29c0dc['allWrites'][_0x29c0dc['allWrites']['length']-0x1]['writeId']:_0x29c0dc['lastWriteId']=-0x1;}function du(_0x3e0dfe){return _0x3e0dfe['visible'];}function Fo(_0x5c5670,_0x1a9186,_0x24bd29){let _0x194e7b=j['empty']();for(let _0x429f9b=0x0;_0x429f9b<_0x5c5670['length'];++_0x429f9b){const _0x151f60=_0x5c5670[_0x429f9b];if(_0x1a9186(_0x151f60)){const _0x1d7219=_0x151f60['path'];let _0xbce32e;if(_0x151f60['snap'])$(_0x24bd29,_0x1d7219)?(_0xbce32e=F(_0x24bd29,_0x1d7219),_0x194e7b=Ct(_0x194e7b,_0xbce32e,_0x151f60['snap'])):$(_0x1d7219,_0x24bd29)&&(_0xbce32e=F(_0x1d7219,_0x24bd29),_0x194e7b=Ct(_0x194e7b,w(),_0x151f60['snap']['getChild'](_0xbce32e)));else{if(_0x151f60['children']){if($(_0x24bd29,_0x1d7219))_0xbce32e=F(_0x24bd29,_0x1d7219),_0x194e7b=Ii(_0x194e7b,_0xbce32e,_0x151f60['children']);else{if($(_0x1d7219,_0x24bd29)){if(_0xbce32e=F(_0x1d7219,_0x24bd29),v(_0xbce32e))_0x194e7b=Ii(_0x194e7b,w(),_0x151f60['children']);else{const _0x55b616=Oe(_0x151f60['children'],y(_0xbce32e));if(_0x55b616){const _0x26bafd=_0x55b616['getChild'](b(_0xbce32e));_0x194e7b=Ct(_0x194e7b,w(),_0x26bafd);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x194e7b;}function Uo(_0x34afd9,_0x4e343a,_0x2adb94,_0x27fab1,_0x4f1d28){if(!_0x27fab1&&!_0x4f1d28){const _0x3afeea=$e(_0x34afd9['visibleWrites'],_0x4e343a);if(_0x3afeea!=null)return _0x3afeea;{const _0x3e3396=ve(_0x34afd9['visibleWrites'],_0x4e343a);if(Ci(_0x3e3396))return _0x2adb94;if(_0x2adb94==null&&!wi(_0x3e3396,w()))return null;{const _0xda6bf6=_0x2adb94||g['EMPTY_NODE'];return it(_0x3e3396,_0xda6bf6);}}}else{const _0x68c62a=ve(_0x34afd9['visibleWrites'],_0x4e343a);if(!_0x4f1d28&&Ci(_0x68c62a))return _0x2adb94;if(!_0x4f1d28&&_0x2adb94==null&&!wi(_0x68c62a,w()))return null;{const _0x51593e=function(_0x17eaf7){return(_0x17eaf7['visible']||_0x4f1d28)&&(!_0x27fab1||!~_0x27fab1['indexOf'](_0x17eaf7['writeId']))&&($(_0x17eaf7['path'],_0x4e343a)||$(_0x4e343a,_0x17eaf7['path']));},_0x471740=Fo(_0x34afd9['allWrites'],_0x51593e,_0x4e343a),_0x41520d=_0x2adb94||g['EMPTY_NODE'];return it(_0x471740,_0x41520d);}}}function fu(_0x419253,_0x5e761e,_0x53fb2b){let _0x212e70=g['EMPTY_NODE'];const _0x611c07=$e(_0x419253['visibleWrites'],_0x5e761e);if(_0x611c07)return _0x611c07['isLeafNode']()||_0x611c07['forEachChild'](R,(_0x4f825e,_0x49af7f)=>{_0x212e70=_0x212e70['updateImmediateChild'](_0x4f825e,_0x49af7f);}),_0x212e70;if(_0x53fb2b){const _0x278c1b=ve(_0x419253['visibleWrites'],_0x5e761e);return _0x53fb2b['forEachChild'](R,(_0x2967c8,_0x3bdb7c)=>{const _0x5ebb4c=it(ve(_0x278c1b,new C(_0x2967c8)),_0x3bdb7c);_0x212e70=_0x212e70['updateImmediateChild'](_0x2967c8,_0x5ebb4c);}),rr(_0x278c1b)['forEach'](_0x2b26f0=>{_0x212e70=_0x212e70['updateImmediateChild'](_0x2b26f0['name'],_0x2b26f0['node']);}),_0x212e70;}else{const _0x103a43=ve(_0x419253['visibleWrites'],_0x5e761e);return rr(_0x103a43)['forEach'](_0x21c001=>{_0x212e70=_0x212e70['updateImmediateChild'](_0x21c001['name'],_0x21c001['node']);}),_0x212e70;}}function pu(_0x4d4a34,_0x3f4d09,_0x5495d8,_0x2ddc33,_0x18173c){f(_0x2ddc33||_0x18173c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x531f3a=A(_0x3f4d09,_0x5495d8);if(wi(_0x4d4a34['visibleWrites'],_0x531f3a))return null;{const _0x37fefc=ve(_0x4d4a34['visibleWrites'],_0x531f3a);return Ci(_0x37fefc)?_0x18173c['getChild'](_0x5495d8):it(_0x37fefc,_0x18173c['getChild'](_0x5495d8));}}function _u(_0x1af918,_0x42c48f,_0x3d898c,_0x384f83){const _0x30f36f=A(_0x42c48f,_0x3d898c),_0x302184=$e(_0x1af918['visibleWrites'],_0x30f36f);if(_0x302184!=null)return _0x302184;if(_0x384f83['isCompleteForChild'](_0x3d898c)){const _0x49249b=ve(_0x1af918['visibleWrites'],_0x30f36f);return it(_0x49249b,_0x384f83['getNode']()['getImmediateChild'](_0x3d898c));}else return null;}function gu(_0x3c996d,_0x476a83){return $e(_0x3c996d['visibleWrites'],_0x476a83);}function mu(_0x49c114,_0x435059,_0x5cf88a,_0x26f9ab,_0x3ada1f,_0x2bdf9b,_0x1cb85b){let _0x33329f;const _0x4b97eb=ve(_0x49c114['visibleWrites'],_0x435059),_0x145d0f=$e(_0x4b97eb,w());if(_0x145d0f!=null)_0x33329f=_0x145d0f;else{if(_0x5cf88a!=null)_0x33329f=it(_0x4b97eb,_0x5cf88a);else return[];}if(_0x33329f=_0x33329f['withIndex'](_0x1cb85b),!_0x33329f['isEmpty']()&&!_0x33329f['isLeafNode']()){const _0x335c0a=[],_0x8cfd7c=_0x1cb85b['getCompare'](),_0xa3c95e=_0x2bdf9b?_0x33329f['getReverseIteratorFrom'](_0x26f9ab,_0x1cb85b):_0x33329f['getIteratorFrom'](_0x26f9ab,_0x1cb85b);let _0x2cb7ec=_0xa3c95e['getNext']();for(;_0x2cb7ec&&_0x335c0a['length']<_0x3ada1f;)_0x8cfd7c(_0x2cb7ec,_0x26f9ab)!==0x0&&_0x335c0a['push'](_0x2cb7ec),_0x2cb7ec=_0xa3c95e['getNext']();return _0x335c0a;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1ef05b,_0x540021,_0x330f64,_0x2b83b1){return Uo(_0x1ef05b['writeTree'],_0x1ef05b['treePath'],_0x540021,_0x330f64,_0x2b83b1);}function es(_0x2b4ed6,_0x5d3977){return fu(_0x2b4ed6['writeTree'],_0x2b4ed6['treePath'],_0x5d3977);}function or(_0x300ed5,_0x2abf84,_0x52b62f,_0x27f532){return pu(_0x300ed5['writeTree'],_0x300ed5['treePath'],_0x2abf84,_0x52b62f,_0x27f532);}function yn(_0x2fb66a,_0x42e374){return gu(_0x2fb66a['writeTree'],A(_0x2fb66a['treePath'],_0x42e374));}function vu(_0x555904,_0x4d16ff,_0x25e6dd,_0x45475a,_0x3f4ac9,_0x3cb2ff){return mu(_0x555904['writeTree'],_0x555904['treePath'],_0x4d16ff,_0x25e6dd,_0x45475a,_0x3f4ac9,_0x3cb2ff);}function ts(_0x410b59,_0x556a54,_0x5de02c){return _u(_0x410b59['writeTree'],_0x410b59['treePath'],_0x556a54,_0x5de02c);}function Wo(_0x2164b4,_0x104264){return Bo(A(_0x2164b4['treePath'],_0x104264),_0x2164b4['writeTree']);}function Bo(_0x1f983f,_0x1dc887){return{'treePath':_0x1f983f,'writeTree':_0x1dc887};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x51e53e){const _0x5e68b4=_0x51e53e['type'],_0x2f3ed8=_0x51e53e['childName'];f(_0x5e68b4==='child_added'||_0x5e68b4==='child_changed'||_0x5e68b4==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2f3ed8!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2d449e=this['changeMap']['get'](_0x2f3ed8);if(_0x2d449e){const _0x1d6307=_0x2d449e['type'];if(_0x5e68b4==='child_added'&&_0x1d6307==='child_removed')this['changeMap']['set'](_0x2f3ed8,Pt(_0x2f3ed8,_0x51e53e['snapshotNode'],_0x2d449e['snapshotNode']));else{if(_0x5e68b4==='child_removed'&&_0x1d6307==='child_added')this['changeMap']['delete'](_0x2f3ed8);else{if(_0x5e68b4==='child_removed'&&_0x1d6307==='child_changed')this['changeMap']['set'](_0x2f3ed8,Nt(_0x2f3ed8,_0x2d449e['oldSnap']));else{if(_0x5e68b4==='child_changed'&&_0x1d6307==='child_added')this['changeMap']['set'](_0x2f3ed8,tt(_0x2f3ed8,_0x51e53e['snapshotNode']));else{if(_0x5e68b4==='child_changed'&&_0x1d6307==='child_changed')this['changeMap']['set'](_0x2f3ed8,Pt(_0x2f3ed8,_0x51e53e['snapshotNode'],_0x2d449e['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x51e53e+'\x20occurred\x20after\x20'+_0x2d449e);}}}}}else this['changeMap']['set'](_0x2f3ed8,_0x51e53e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x349027){return null;}['getChildAfterChild'](_0x46192e,_0x3c9889,_0x2196ae){return null;}}const Vo=new Iu();class ns{constructor(_0x28fbf4,_0x96c2b2,_0x5a6520=null){this['writes_']=_0x28fbf4,this['viewCache_']=_0x96c2b2,this['optCompleteServerCache_']=_0x5a6520;}['getCompleteChild'](_0x3973c0){const _0x75d433=this['viewCache_']['eventCache'];if(_0x75d433['isCompleteForChild'](_0x3973c0))return _0x75d433['getNode']()['getImmediateChild'](_0x3973c0);{const _0x1f4334=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x3973c0,_0x1f4334);}}['getChildAfterChild'](_0x367a73,_0x96c7ce,_0xe2684){const _0x531380=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x7d40e5=vu(this['writes_'],_0x531380,_0x96c7ce,0x1,_0xe2684,_0x367a73);return _0x7d40e5['length']===0x0?null:_0x7d40e5[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x581a03){return{'filter':_0x581a03};}function Cu(_0x17a993,_0x1cffd8){f(_0x1cffd8['eventCache']['getNode']()['isIndexed'](_0x17a993['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1cffd8['serverCache']['getNode']()['isIndexed'](_0x17a993['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x509761,_0x5bd18b,_0x508c92,_0x556af3,_0x5259da){const _0x1efffd=new Eu();let _0x411b84,_0xae6fe2;if(_0x508c92['type']===q['OVERWRITE']){const _0x22518a=_0x508c92;_0x22518a['source']['fromUser']?_0x411b84=Ti(_0x509761,_0x5bd18b,_0x22518a['path'],_0x22518a['snap'],_0x556af3,_0x5259da,_0x1efffd):(f(_0x22518a['source']['fromServer'],'Unknown\x20source.'),_0xae6fe2=_0x22518a['source']['tagged']||_0x5bd18b['serverCache']['isFiltered']()&&!v(_0x22518a['path']),_0x411b84=vn(_0x509761,_0x5bd18b,_0x22518a['path'],_0x22518a['snap'],_0x556af3,_0x5259da,_0xae6fe2,_0x1efffd));}else{if(_0x508c92['type']===q['MERGE']){const _0x25af35=_0x508c92;_0x25af35['source']['fromUser']?_0x411b84=bu(_0x509761,_0x5bd18b,_0x25af35['path'],_0x25af35['children'],_0x556af3,_0x5259da,_0x1efffd):(f(_0x25af35['source']['fromServer'],'Unknown\x20source.'),_0xae6fe2=_0x25af35['source']['tagged']||_0x5bd18b['serverCache']['isFiltered'](),_0x411b84=Si(_0x509761,_0x5bd18b,_0x25af35['path'],_0x25af35['children'],_0x556af3,_0x5259da,_0xae6fe2,_0x1efffd));}else{if(_0x508c92['type']===q['ACK_USER_WRITE']){const _0x1b53e2=_0x508c92;_0x1b53e2['revert']?_0x411b84=ku(_0x509761,_0x5bd18b,_0x1b53e2['path'],_0x556af3,_0x5259da,_0x1efffd):_0x411b84=Ru(_0x509761,_0x5bd18b,_0x1b53e2['path'],_0x1b53e2['affectedTree'],_0x556af3,_0x5259da,_0x1efffd);}else{if(_0x508c92['type']===q['LISTEN_COMPLETE'])_0x411b84=Au(_0x509761,_0x5bd18b,_0x508c92['path'],_0x556af3,_0x1efffd);else throw ot('Unknown\x20operation\x20type:\x20'+_0x508c92['type']);}}}const _0x18e39f=_0x1efffd['getChanges']();return Su(_0x5bd18b,_0x411b84,_0x18e39f),{'viewCache':_0x411b84,'changes':_0x18e39f};}function Su(_0x9deb45,_0x3581b4,_0x566037){const _0x27be61=_0x3581b4['eventCache'];if(_0x27be61['isFullyInitialized']()){const _0x4fad64=_0x27be61['getNode']()['isLeafNode']()||_0x27be61['getNode']()['isEmpty'](),_0x20acf9=gn(_0x9deb45);(_0x566037['length']>0x0||!_0x9deb45['eventCache']['isFullyInitialized']()||_0x4fad64&&!_0x27be61['getNode']()['equals'](_0x20acf9)||!_0x27be61['getNode']()['getPriority']()['equals'](_0x20acf9['getPriority']()))&&_0x566037['push'](Oo(gn(_0x3581b4)));}}function Ho(_0x2c3ba0,_0x2b688f,_0x54bc0d,_0x306e9c,_0xe47a4d,_0xe278d1){const _0x9e932e=_0x2b688f['eventCache'];if(yn(_0x306e9c,_0x54bc0d)!=null)return _0x2b688f;{let _0x32e907,_0x4704fd;if(v(_0x54bc0d)){if(f(_0x2b688f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2b688f['serverCache']['isFiltered']()){const _0xc418bd=Ue(_0x2b688f),_0x4e71c4=_0xc418bd instanceof g?_0xc418bd:g['EMPTY_NODE'],_0x788800=es(_0x306e9c,_0x4e71c4);_0x32e907=_0x2c3ba0['filter']['updateFullNode'](_0x2b688f['eventCache']['getNode'](),_0x788800,_0xe278d1);}else{const _0x55787f=mn(_0x306e9c,Ue(_0x2b688f));_0x32e907=_0x2c3ba0['filter']['updateFullNode'](_0x2b688f['eventCache']['getNode'](),_0x55787f,_0xe278d1);}}else{const _0x1a63bc=y(_0x54bc0d);if(_0x1a63bc==='.priority'){f(we(_0x54bc0d)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2b681b=_0x9e932e['getNode']();_0x4704fd=_0x2b688f['serverCache']['getNode']();const _0xc59d0=or(_0x306e9c,_0x54bc0d,_0x2b681b,_0x4704fd);_0xc59d0!=null?_0x32e907=_0x2c3ba0['filter']['updatePriority'](_0x2b681b,_0xc59d0):_0x32e907=_0x9e932e['getNode']();}else{const _0x1d5805=b(_0x54bc0d);let _0x15a9a2;if(_0x9e932e['isCompleteForChild'](_0x1a63bc)){_0x4704fd=_0x2b688f['serverCache']['getNode']();const _0x5467a7=or(_0x306e9c,_0x54bc0d,_0x9e932e['getNode'](),_0x4704fd);_0x5467a7!=null?_0x15a9a2=_0x9e932e['getNode']()['getImmediateChild'](_0x1a63bc)['updateChild'](_0x1d5805,_0x5467a7):_0x15a9a2=_0x9e932e['getNode']()['getImmediateChild'](_0x1a63bc);}else _0x15a9a2=ts(_0x306e9c,_0x1a63bc,_0x2b688f['serverCache']);_0x15a9a2!=null?_0x32e907=_0x2c3ba0['filter']['updateChild'](_0x9e932e['getNode'](),_0x1a63bc,_0x15a9a2,_0x1d5805,_0xe47a4d,_0xe278d1):_0x32e907=_0x9e932e['getNode']();}}return wt(_0x2b688f,_0x32e907,_0x9e932e['isFullyInitialized']()||v(_0x54bc0d),_0x2c3ba0['filter']['filtersNodes']());}}function vn(_0x5f36bc,_0x2b1ac2,_0x300c5c,_0x4b9221,_0x2fb23b,_0x31b7b8,_0x5104e1,_0x57317f){const _0x2d1764=_0x2b1ac2['serverCache'];let _0x1550eb;const _0x108d21=_0x5104e1?_0x5f36bc['filter']:_0x5f36bc['filter']['getIndexedFilter']();if(v(_0x300c5c))_0x1550eb=_0x108d21['updateFullNode'](_0x2d1764['getNode'](),_0x4b9221,null);else{if(_0x108d21['filtersNodes']()&&!_0x2d1764['isFiltered']()){const _0x42be53=_0x2d1764['getNode']()['updateChild'](_0x300c5c,_0x4b9221);_0x1550eb=_0x108d21['updateFullNode'](_0x2d1764['getNode'](),_0x42be53,null);}else{const _0x20f3ee=y(_0x300c5c);if(!_0x2d1764['isCompleteForPath'](_0x300c5c)&&we(_0x300c5c)>0x1)return _0x2b1ac2;const _0x4fa5cd=b(_0x300c5c),_0x4038d1=_0x2d1764['getNode']()['getImmediateChild'](_0x20f3ee)['updateChild'](_0x4fa5cd,_0x4b9221);_0x20f3ee==='.priority'?_0x1550eb=_0x108d21['updatePriority'](_0x2d1764['getNode'](),_0x4038d1):_0x1550eb=_0x108d21['updateChild'](_0x2d1764['getNode'](),_0x20f3ee,_0x4038d1,_0x4fa5cd,Vo,null);}}const _0x5983d1=Lo(_0x2b1ac2,_0x1550eb,_0x2d1764['isFullyInitialized']()||v(_0x300c5c),_0x108d21['filtersNodes']()),_0x72df74=new ns(_0x2fb23b,_0x5983d1,_0x31b7b8);return Ho(_0x5f36bc,_0x5983d1,_0x300c5c,_0x2fb23b,_0x72df74,_0x57317f);}function Ti(_0x4006df,_0x305005,_0x5cc166,_0x4bcfdd,_0x26b139,_0x1b6107,_0x339ce3){const _0xa5e4bf=_0x305005['eventCache'];let _0x4d5685,_0xa06ba7;const _0x30bfdc=new ns(_0x26b139,_0x305005,_0x1b6107);if(v(_0x5cc166))_0xa06ba7=_0x4006df['filter']['updateFullNode'](_0x305005['eventCache']['getNode'](),_0x4bcfdd,_0x339ce3),_0x4d5685=wt(_0x305005,_0xa06ba7,!0x0,_0x4006df['filter']['filtersNodes']());else{const _0x4112d8=y(_0x5cc166);if(_0x4112d8==='.priority')_0xa06ba7=_0x4006df['filter']['updatePriority'](_0x305005['eventCache']['getNode'](),_0x4bcfdd),_0x4d5685=wt(_0x305005,_0xa06ba7,_0xa5e4bf['isFullyInitialized'](),_0xa5e4bf['isFiltered']());else{const _0x3681e5=b(_0x5cc166),_0x1ea55b=_0xa5e4bf['getNode']()['getImmediateChild'](_0x4112d8);let _0x31471f;if(v(_0x3681e5))_0x31471f=_0x4bcfdd;else{const _0x1b2a80=_0x30bfdc['getCompleteChild'](_0x4112d8);_0x1b2a80!=null?Gi(_0x3681e5)==='.priority'&&_0x1b2a80['getChild'](To(_0x3681e5))['isEmpty']()?_0x31471f=_0x1b2a80:_0x31471f=_0x1b2a80['updateChild'](_0x3681e5,_0x4bcfdd):_0x31471f=g['EMPTY_NODE'];}if(_0x1ea55b['equals'](_0x31471f))_0x4d5685=_0x305005;else{const _0x34a84a=_0x4006df['filter']['updateChild'](_0xa5e4bf['getNode'](),_0x4112d8,_0x31471f,_0x3681e5,_0x30bfdc,_0x339ce3);_0x4d5685=wt(_0x305005,_0x34a84a,_0xa5e4bf['isFullyInitialized'](),_0x4006df['filter']['filtersNodes']());}}}return _0x4d5685;}function ar(_0x383ef1,_0x372468){return _0x383ef1['eventCache']['isCompleteForChild'](_0x372468);}function bu(_0x441973,_0x1ba03a,_0x414a51,_0x436982,_0x38f62f,_0x3d7b03,_0x150de5){let _0x8f714c=_0x1ba03a;return _0x436982['foreach']((_0x5733a0,_0x32f4c8)=>{const _0xc7dd0c=A(_0x414a51,_0x5733a0);ar(_0x1ba03a,y(_0xc7dd0c))&&(_0x8f714c=Ti(_0x441973,_0x8f714c,_0xc7dd0c,_0x32f4c8,_0x38f62f,_0x3d7b03,_0x150de5));}),_0x436982['foreach']((_0x45f645,_0x1e0e4b)=>{const _0x2faae6=A(_0x414a51,_0x45f645);ar(_0x1ba03a,y(_0x2faae6))||(_0x8f714c=Ti(_0x441973,_0x8f714c,_0x2faae6,_0x1e0e4b,_0x38f62f,_0x3d7b03,_0x150de5));}),_0x8f714c;}function cr(_0x3697b1,_0x4be8c2,_0x455f8c){return _0x455f8c['foreach']((_0x35979e,_0x2feac4)=>{_0x4be8c2=_0x4be8c2['updateChild'](_0x35979e,_0x2feac4);}),_0x4be8c2;}function Si(_0x5de07d,_0x20c5f8,_0x50f4b6,_0x3ce403,_0xc0f97a,_0x15260c,_0x3f43e8,_0x2f0b5a){if(_0x20c5f8['serverCache']['getNode']()['isEmpty']()&&!_0x20c5f8['serverCache']['isFullyInitialized']())return _0x20c5f8;let _0x25106e=_0x20c5f8,_0x48a83c;v(_0x50f4b6)?_0x48a83c=_0x3ce403:_0x48a83c=new S(null)['setTree'](_0x50f4b6,_0x3ce403);const _0x18b964=_0x20c5f8['serverCache']['getNode']();return _0x48a83c['children']['inorderTraversal']((_0x5bfb90,_0x18422e)=>{if(_0x18b964['hasChild'](_0x5bfb90)){const _0x15e2ff=_0x20c5f8['serverCache']['getNode']()['getImmediateChild'](_0x5bfb90),_0x203f5f=cr(_0x5de07d,_0x15e2ff,_0x18422e);_0x25106e=vn(_0x5de07d,_0x25106e,new C(_0x5bfb90),_0x203f5f,_0xc0f97a,_0x15260c,_0x3f43e8,_0x2f0b5a);}}),_0x48a83c['children']['inorderTraversal']((_0x58cd57,_0x1add90)=>{const _0x59f9e2=!_0x20c5f8['serverCache']['isCompleteForChild'](_0x58cd57)&&_0x1add90['value']===null;if(!_0x18b964['hasChild'](_0x58cd57)&&!_0x59f9e2){const _0x2e5a61=_0x20c5f8['serverCache']['getNode']()['getImmediateChild'](_0x58cd57),_0x21b54a=cr(_0x5de07d,_0x2e5a61,_0x1add90);_0x25106e=vn(_0x5de07d,_0x25106e,new C(_0x58cd57),_0x21b54a,_0xc0f97a,_0x15260c,_0x3f43e8,_0x2f0b5a);}}),_0x25106e;}function Ru(_0x13c2f2,_0xe39985,_0x14420b,_0x406704,_0x21eeb1,_0x402374,_0x5e8459){if(yn(_0x21eeb1,_0x14420b)!=null)return _0xe39985;const _0xfbc0c4=_0xe39985['serverCache']['isFiltered'](),_0x6cfc3d=_0xe39985['serverCache'];if(_0x406704['value']!=null){if(v(_0x14420b)&&_0x6cfc3d['isFullyInitialized']()||_0x6cfc3d['isCompleteForPath'](_0x14420b))return vn(_0x13c2f2,_0xe39985,_0x14420b,_0x6cfc3d['getNode']()['getChild'](_0x14420b),_0x21eeb1,_0x402374,_0xfbc0c4,_0x5e8459);if(v(_0x14420b)){let _0x170d63=new S(null);return _0x6cfc3d['getNode']()['forEachChild'](ye,(_0x546a9d,_0x398665)=>{_0x170d63=_0x170d63['set'](new C(_0x546a9d),_0x398665);}),Si(_0x13c2f2,_0xe39985,_0x14420b,_0x170d63,_0x21eeb1,_0x402374,_0xfbc0c4,_0x5e8459);}else return _0xe39985;}else{let _0x4e5b7a=new S(null);return _0x406704['foreach']((_0x413709,_0x2363e6)=>{const _0x5d1fbd=A(_0x14420b,_0x413709);_0x6cfc3d['isCompleteForPath'](_0x5d1fbd)&&(_0x4e5b7a=_0x4e5b7a['set'](_0x413709,_0x6cfc3d['getNode']()['getChild'](_0x5d1fbd)));}),Si(_0x13c2f2,_0xe39985,_0x14420b,_0x4e5b7a,_0x21eeb1,_0x402374,_0xfbc0c4,_0x5e8459);}}function Au(_0x3f915e,_0x534940,_0x4d74c2,_0x206951,_0x2a939d){const _0x477a12=_0x534940['serverCache'],_0x5332f6=Lo(_0x534940,_0x477a12['getNode'](),_0x477a12['isFullyInitialized']()||v(_0x4d74c2),_0x477a12['isFiltered']());return Ho(_0x3f915e,_0x5332f6,_0x4d74c2,_0x206951,Vo,_0x2a939d);}function ku(_0x3b1d7e,_0x35a96d,_0x291a5b,_0x5c1a94,_0x1283e9,_0x1d3de7){let _0x166195;if(yn(_0x5c1a94,_0x291a5b)!=null)return _0x35a96d;{const _0x2db917=new ns(_0x5c1a94,_0x35a96d,_0x1283e9),_0xcec436=_0x35a96d['eventCache']['getNode']();let _0x5a27cf;if(v(_0x291a5b)||y(_0x291a5b)==='.priority'){let _0x1938ab;if(_0x35a96d['serverCache']['isFullyInitialized']())_0x1938ab=mn(_0x5c1a94,Ue(_0x35a96d));else{const _0x1fba93=_0x35a96d['serverCache']['getNode']();f(_0x1fba93 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1938ab=es(_0x5c1a94,_0x1fba93);}_0x1938ab=_0x1938ab,_0x5a27cf=_0x3b1d7e['filter']['updateFullNode'](_0xcec436,_0x1938ab,_0x1d3de7);}else{const _0x3e214b=y(_0x291a5b);let _0x5d3865=ts(_0x5c1a94,_0x3e214b,_0x35a96d['serverCache']);_0x5d3865==null&&_0x35a96d['serverCache']['isCompleteForChild'](_0x3e214b)&&(_0x5d3865=_0xcec436['getImmediateChild'](_0x3e214b)),_0x5d3865!=null?_0x5a27cf=_0x3b1d7e['filter']['updateChild'](_0xcec436,_0x3e214b,_0x5d3865,b(_0x291a5b),_0x2db917,_0x1d3de7):_0x35a96d['eventCache']['getNode']()['hasChild'](_0x3e214b)?_0x5a27cf=_0x3b1d7e['filter']['updateChild'](_0xcec436,_0x3e214b,g['EMPTY_NODE'],b(_0x291a5b),_0x2db917,_0x1d3de7):_0x5a27cf=_0xcec436,_0x5a27cf['isEmpty']()&&_0x35a96d['serverCache']['isFullyInitialized']()&&(_0x166195=mn(_0x5c1a94,Ue(_0x35a96d)),_0x166195['isLeafNode']()&&(_0x5a27cf=_0x3b1d7e['filter']['updateFullNode'](_0x5a27cf,_0x166195,_0x1d3de7)));}return _0x166195=_0x35a96d['serverCache']['isFullyInitialized']()||yn(_0x5c1a94,w())!=null,wt(_0x35a96d,_0x5a27cf,_0x166195,_0x3b1d7e['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x53bb76,_0x941739){this['query_']=_0x53bb76,this['eventRegistrations_']=[];const _0x5162ea=this['query_']['_queryParams'],_0x294478=new Yi(_0x5162ea['getIndex']()),_0x370250=qh(_0x5162ea);this['processor_']=wu(_0x370250);const _0xc517b=_0x941739['serverCache'],_0x40d85c=_0x941739['eventCache'],_0x5845cf=_0x294478['updateFullNode'](g['EMPTY_NODE'],_0xc517b['getNode'](),null),_0x2acf36=_0x370250['updateFullNode'](g['EMPTY_NODE'],_0x40d85c['getNode'](),null),_0x5a2d25=new Ce(_0x5845cf,_0xc517b['isFullyInitialized'](),_0x294478['filtersNodes']()),_0x5ab0da=new Ce(_0x2acf36,_0x40d85c['isFullyInitialized'](),_0x370250['filtersNodes']());this['viewCache_']=Dn(_0x5ab0da,_0x5a2d25),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4b5d68){return _0x4b5d68['viewCache_']['serverCache']['getNode']();}function Ou(_0x39392f){return gn(_0x39392f['viewCache_']);}function Du(_0x11bb31,_0x561e4f){const _0x5d91cb=Ue(_0x11bb31['viewCache_']);return _0x5d91cb&&(_0x11bb31['query']['_queryParams']['loadsAllData']()||!v(_0x561e4f)&&!_0x5d91cb['getImmediateChild'](y(_0x561e4f))['isEmpty']())?_0x5d91cb['getChild'](_0x561e4f):null;}function lr(_0x2f51ab){return _0x2f51ab['eventRegistrations_']['length']===0x0;}function Mu(_0x5759a4,_0xc44203){_0x5759a4['eventRegistrations_']['push'](_0xc44203);}function hr(_0x571a91,_0x15428c,_0x44308a){const _0x33a4ea=[];if(_0x44308a){f(_0x15428c==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x508465=_0x571a91['query']['_path'];_0x571a91['eventRegistrations_']['forEach'](_0x153572=>{const _0x4f1d50=_0x153572['createCancelEvent'](_0x44308a,_0x508465);_0x4f1d50&&_0x33a4ea['push'](_0x4f1d50);});}if(_0x15428c){let _0x3ca334=[];for(let _0x3410ce=0x0;_0x3410ce<_0x571a91['eventRegistrations_']['length'];++_0x3410ce){const _0x43f066=_0x571a91['eventRegistrations_'][_0x3410ce];if(!_0x43f066['matches'](_0x15428c))_0x3ca334['push'](_0x43f066);else{if(_0x15428c['hasAnyCallback']()){_0x3ca334=_0x3ca334['concat'](_0x571a91['eventRegistrations_']['slice'](_0x3410ce+0x1));break;}}}_0x571a91['eventRegistrations_']=_0x3ca334;}else _0x571a91['eventRegistrations_']=[];return _0x33a4ea;}function ur(_0x5ed11b,_0x33f4b7,_0x36b6f1,_0x31f0d0){_0x33f4b7['type']===q['MERGE']&&_0x33f4b7['source']['queryId']!==null&&(f(Ue(_0x5ed11b['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x5ed11b['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x155b87=_0x5ed11b['viewCache_'],_0x204961=Tu(_0x5ed11b['processor_'],_0x155b87,_0x33f4b7,_0x36b6f1,_0x31f0d0);return Cu(_0x5ed11b['processor_'],_0x204961['viewCache']),f(_0x204961['viewCache']['serverCache']['isFullyInitialized']()||!_0x155b87['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5ed11b['viewCache_']=_0x204961['viewCache'],$o(_0x5ed11b,_0x204961['changes'],_0x204961['viewCache']['eventCache']['getNode'](),null);}function Lu(_0xf9575d,_0x3b6ff5){const _0x580edd=_0xf9575d['viewCache_']['eventCache'],_0x3bcf3f=[];return _0x580edd['getNode']()['isLeafNode']()||_0x580edd['getNode']()['forEachChild'](R,(_0x5b3ad1,_0x5d3cfd)=>{_0x3bcf3f['push'](tt(_0x5b3ad1,_0x5d3cfd));}),_0x580edd['isFullyInitialized']()&&_0x3bcf3f['push'](Oo(_0x580edd['getNode']())),$o(_0xf9575d,_0x3bcf3f,_0x580edd['getNode'](),_0x3b6ff5);}function $o(_0xb41ef2,_0x4df9d9,_0x52e770,_0x198948){const _0x369755=_0x198948?[_0x198948]:_0xb41ef2['eventRegistrations_'];return nu(_0xb41ef2['eventGenerator_'],_0x4df9d9,_0x52e770,_0x369755);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xcde618){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xcde618;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x53923a){return _0x53923a['views']['size']===0x0;}function is(_0x44c594,_0x4563a3,_0x1001cf,_0x53d47b){const _0x2e41a5=_0x4563a3['source']['queryId'];if(_0x2e41a5!==null){const _0x3aa008=_0x44c594['views']['get'](_0x2e41a5);return f(_0x3aa008!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x3aa008,_0x4563a3,_0x1001cf,_0x53d47b);}else{let _0x35562b=[];for(const _0x5201d5 of _0x44c594['views']['values']())_0x35562b=_0x35562b['concat'](ur(_0x5201d5,_0x4563a3,_0x1001cf,_0x53d47b));return _0x35562b;}}function qo(_0x4929ac,_0x1f64c6,_0x3b2e8b,_0xe88a93,_0x1b15b0){const _0xf53083=_0x1f64c6['_queryIdentifier'],_0x3f2d3d=_0x4929ac['views']['get'](_0xf53083);if(!_0x3f2d3d){let _0x2f6bfd=mn(_0x3b2e8b,_0x1b15b0?_0xe88a93:null),_0x37e5fe=!0x1;_0x2f6bfd?_0x37e5fe=!0x0:_0xe88a93 instanceof g?(_0x2f6bfd=es(_0x3b2e8b,_0xe88a93),_0x37e5fe=!0x1):(_0x2f6bfd=g['EMPTY_NODE'],_0x37e5fe=!0x1);const _0x537726=Dn(new Ce(_0x2f6bfd,_0x37e5fe,!0x1),new Ce(_0xe88a93,_0x1b15b0,!0x1));return new Nu(_0x1f64c6,_0x537726);}return _0x3f2d3d;}function Wu(_0x499160,_0x578f18,_0x3a31f3,_0x5a56e9,_0x3d5073,_0x26739d){const _0x33aa6d=qo(_0x499160,_0x578f18,_0x5a56e9,_0x3d5073,_0x26739d);return _0x499160['views']['has'](_0x578f18['_queryIdentifier'])||_0x499160['views']['set'](_0x578f18['_queryIdentifier'],_0x33aa6d),Mu(_0x33aa6d,_0x3a31f3),Lu(_0x33aa6d,_0x3a31f3);}function Bu(_0x48d28d,_0xaf715e,_0x102921,_0x2883da){const _0x4755dd=_0xaf715e['_queryIdentifier'],_0x44a313=[];let _0x46a275=[];const _0x572e30=Te(_0x48d28d);if(_0x4755dd==='default'){for(const [_0x16b94f,_0xe3f70d]of _0x48d28d['views']['entries']())_0x46a275=_0x46a275['concat'](hr(_0xe3f70d,_0x102921,_0x2883da)),lr(_0xe3f70d)&&(_0x48d28d['views']['delete'](_0x16b94f),_0xe3f70d['query']['_queryParams']['loadsAllData']()||_0x44a313['push'](_0xe3f70d['query']));}else{const _0x716d71=_0x48d28d['views']['get'](_0x4755dd);_0x716d71&&(_0x46a275=_0x46a275['concat'](hr(_0x716d71,_0x102921,_0x2883da)),lr(_0x716d71)&&(_0x48d28d['views']['delete'](_0x4755dd),_0x716d71['query']['_queryParams']['loadsAllData']()||_0x44a313['push'](_0x716d71['query'])));}return _0x572e30&&!Te(_0x48d28d)&&_0x44a313['push'](new(Fu())(_0xaf715e['_repo'],_0xaf715e['_path'])),{'removed':_0x44a313,'events':_0x46a275};}function zo(_0x51db94){const _0x98ce34=[];for(const _0x45ecda of _0x51db94['views']['values']())_0x45ecda['query']['_queryParams']['loadsAllData']()||_0x98ce34['push'](_0x45ecda);return _0x98ce34;}function Ee(_0x374011,_0xf0038){let _0x2dfde5=null;for(const _0x563794 of _0x374011['views']['values']())_0x2dfde5=_0x2dfde5||Du(_0x563794,_0xf0038);return _0x2dfde5;}function jo(_0x34c4a0,_0x612cba){if(_0x612cba['_queryParams']['loadsAllData']())return Ln(_0x34c4a0);{const _0x311df8=_0x612cba['_queryIdentifier'];return _0x34c4a0['views']['get'](_0x311df8);}}function Ko(_0x4c9457,_0x70db66){return jo(_0x4c9457,_0x70db66)!=null;}function Te(_0x43320f){return Ln(_0x43320f)!=null;}function Ln(_0x5260ea){for(const _0x511816 of _0x5260ea['views']['values']())if(_0x511816['query']['_queryParams']['loadsAllData']())return _0x511816;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x3e4051){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3e4051;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x281799){this['listenProvider_']=_0x281799,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x1886a9,_0x39f8ab,_0x3663bb,_0x47b5ae,_0x1599ce){return ou(_0x1886a9['pendingWriteTree_'],_0x39f8ab,_0x3663bb,_0x47b5ae,_0x1599ce),_0x1599ce?ht(_0x1886a9,new Fe(Ji(),_0x39f8ab,_0x3663bb)):[];}function Gu(_0x37bbfb,_0x58b885,_0xdc7904,_0x195d61){au(_0x37bbfb['pendingWriteTree_'],_0x58b885,_0xdc7904,_0x195d61);const _0x33beb8=S['fromObject'](_0xdc7904);return ht(_0x37bbfb,new nt(Ji(),_0x58b885,_0x33beb8));}function pe(_0x30a694,_0x50d48c,_0x3c878c=!0x1){const _0x207dc1=cu(_0x30a694['pendingWriteTree_'],_0x50d48c);if(lu(_0x30a694['pendingWriteTree_'],_0x50d48c)){let _0xda7ed0=new S(null);return _0x207dc1['snap']!=null?_0xda7ed0=_0xda7ed0['set'](w(),!0x0):x(_0x207dc1['children'],_0x304cca=>{_0xda7ed0=_0xda7ed0['set'](new C(_0x304cca),!0x0);}),ht(_0x30a694,new _n(_0x207dc1['path'],_0xda7ed0,_0x3c878c));}else return[];}function $t(_0x869e1,_0x3324d7,_0x2a90e9){return ht(_0x869e1,new Fe(Xi(),_0x3324d7,_0x2a90e9));}function qu(_0x2dd2ef,_0x2e0036,_0x10e94c){const _0x44000f=S['fromObject'](_0x10e94c);return ht(_0x2dd2ef,new nt(Xi(),_0x2e0036,_0x44000f));}function zu(_0x26cfe8,_0x2aa5bb){return ht(_0x26cfe8,new Dt(Xi(),_0x2aa5bb));}function ju(_0x498356,_0x214f11,_0x42403d){const _0xcad9e6=rs(_0x498356,_0x42403d);if(_0xcad9e6){const _0xe132b7=os(_0xcad9e6),_0x525f30=_0xe132b7['path'],_0x540b1f=_0xe132b7['queryId'],_0x595334=F(_0x525f30,_0x214f11),_0x7cb8c0=new Dt(Zi(_0x540b1f),_0x595334);return as(_0x498356,_0x525f30,_0x7cb8c0);}else return[];}function wn(_0x44de6d,_0x442e79,_0x2b8de0,_0x282650,_0x28d0ac=!0x1){const _0x45dc49=_0x442e79['_path'],_0x1c9a3f=_0x44de6d['syncPointTree_']['get'](_0x45dc49);let _0x3f8343=[];if(_0x1c9a3f&&(_0x442e79['_queryIdentifier']==='default'||Ko(_0x1c9a3f,_0x442e79))){const _0xe4bd58=Bu(_0x1c9a3f,_0x442e79,_0x2b8de0,_0x282650);Uu(_0x1c9a3f)&&(_0x44de6d['syncPointTree_']=_0x44de6d['syncPointTree_']['remove'](_0x45dc49));const _0x56a778=_0xe4bd58['removed'];if(_0x3f8343=_0xe4bd58['events'],!_0x28d0ac){const _0x426753=_0x56a778['findIndex'](_0x501ed8=>_0x501ed8['_queryParams']['loadsAllData']())!==-0x1,_0x270db6=_0x44de6d['syncPointTree_']['findOnPath'](_0x45dc49,(_0xa2ad9b,_0x2049ac)=>Te(_0x2049ac));if(_0x426753&&!_0x270db6){const _0x518683=_0x44de6d['syncPointTree_']['subtree'](_0x45dc49);if(!_0x518683['isEmpty']()){const _0x37067e=Qu(_0x518683);for(let _0x5e11c1=0x0;_0x5e11c1<_0x37067e['length'];++_0x5e11c1){const _0x609d39=_0x37067e[_0x5e11c1],_0x8907eb=_0x609d39['query'],_0x42c26a=Xo(_0x44de6d,_0x609d39);_0x44de6d['listenProvider_']['startListening'](Tt(_0x8907eb),Mt(_0x44de6d,_0x8907eb),_0x42c26a['hashFn'],_0x42c26a['onComplete']);}}}!_0x270db6&&_0x56a778['length']>0x0&&!_0x282650&&(_0x426753?_0x44de6d['listenProvider_']['stopListening'](Tt(_0x442e79),null):_0x56a778['forEach'](_0x4fff3f=>{const _0x214ff9=_0x44de6d['queryToTagMap']['get'](Fn(_0x4fff3f));_0x44de6d['listenProvider_']['stopListening'](Tt(_0x4fff3f),_0x214ff9);}));}Ju(_0x44de6d,_0x56a778);}return _0x3f8343;}function Yo(_0x3ba5ed,_0x3e3572,_0x2b931d,_0x407afe){const _0x20f5a6=rs(_0x3ba5ed,_0x407afe);if(_0x20f5a6!=null){const _0x1f685d=os(_0x20f5a6),_0x5e5ae9=_0x1f685d['path'],_0x5a80f7=_0x1f685d['queryId'],_0x29c0ae=F(_0x5e5ae9,_0x3e3572),_0x46cfef=new Fe(Zi(_0x5a80f7),_0x29c0ae,_0x2b931d);return as(_0x3ba5ed,_0x5e5ae9,_0x46cfef);}else return[];}function Ku(_0x3c5cdb,_0x48f267,_0x38d18,_0x434e7c){const _0xd6ddb3=rs(_0x3c5cdb,_0x434e7c);if(_0xd6ddb3){const _0x1050ef=os(_0xd6ddb3),_0x5c432d=_0x1050ef['path'],_0x4551ce=_0x1050ef['queryId'],_0x50781c=F(_0x5c432d,_0x48f267),_0x3c64fd=S['fromObject'](_0x38d18),_0x3c2bd5=new nt(Zi(_0x4551ce),_0x50781c,_0x3c64fd);return as(_0x3c5cdb,_0x5c432d,_0x3c2bd5);}else return[];}function bi(_0x234f1b,_0x326c1b,_0x29d953,_0x2a91af=!0x1){const _0xacd6c=_0x326c1b['_path'];let _0x86e47d=null,_0x1e7f16=!0x1;_0x234f1b['syncPointTree_']['foreachOnPath'](_0xacd6c,(_0x473c5a,_0x4cea34)=>{const _0x5c5b0d=F(_0x473c5a,_0xacd6c);_0x86e47d=_0x86e47d||Ee(_0x4cea34,_0x5c5b0d),_0x1e7f16=_0x1e7f16||Te(_0x4cea34);});let _0x28ad29=_0x234f1b['syncPointTree_']['get'](_0xacd6c);_0x28ad29?(_0x1e7f16=_0x1e7f16||Te(_0x28ad29),_0x86e47d=_0x86e47d||Ee(_0x28ad29,w())):(_0x28ad29=new Go(),_0x234f1b['syncPointTree_']=_0x234f1b['syncPointTree_']['set'](_0xacd6c,_0x28ad29));let _0x4889af;_0x86e47d!=null?_0x4889af=!0x0:(_0x4889af=!0x1,_0x86e47d=g['EMPTY_NODE'],_0x234f1b['syncPointTree_']['subtree'](_0xacd6c)['foreachChild']((_0x2156a5,_0x5a7f7a)=>{const _0x183193=Ee(_0x5a7f7a,w());_0x183193&&(_0x86e47d=_0x86e47d['updateImmediateChild'](_0x2156a5,_0x183193));}));const _0x2302e9=Ko(_0x28ad29,_0x326c1b);if(!_0x2302e9&&!_0x326c1b['_queryParams']['loadsAllData']()){const _0x6ec752=Fn(_0x326c1b);f(!_0x234f1b['queryToTagMap']['has'](_0x6ec752),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3ba539=Xu();_0x234f1b['queryToTagMap']['set'](_0x6ec752,_0x3ba539),_0x234f1b['tagToQueryMap']['set'](_0x3ba539,_0x6ec752);}const _0x51107e=Mn(_0x234f1b['pendingWriteTree_'],_0xacd6c);let _0x37f694=Wu(_0x28ad29,_0x326c1b,_0x29d953,_0x51107e,_0x86e47d,_0x4889af);if(!_0x2302e9&&!_0x1e7f16&&!_0x2a91af){const _0x535275=jo(_0x28ad29,_0x326c1b);_0x37f694=_0x37f694['concat'](Zu(_0x234f1b,_0x326c1b,_0x535275));}return _0x37f694;}function xn(_0x268b54,_0x560aa9,_0xcac557){const _0x6d922a=_0x268b54['pendingWriteTree_'],_0x49878d=_0x268b54['syncPointTree_']['findOnPath'](_0x560aa9,(_0x599877,_0x19631a)=>{const _0x3a1487=F(_0x599877,_0x560aa9),_0x5f4b97=Ee(_0x19631a,_0x3a1487);if(_0x5f4b97)return _0x5f4b97;});return Uo(_0x6d922a,_0x560aa9,_0x49878d,_0xcac557,!0x0);}function Yu(_0x44f76c,_0xed1182){const _0x234981=_0xed1182['_path'];let _0x133f42=null;_0x44f76c['syncPointTree_']['foreachOnPath'](_0x234981,(_0x564c4b,_0x4afd19)=>{const _0xf73543=F(_0x564c4b,_0x234981);_0x133f42=_0x133f42||Ee(_0x4afd19,_0xf73543);});let _0x24c858=_0x44f76c['syncPointTree_']['get'](_0x234981);_0x24c858?_0x133f42=_0x133f42||Ee(_0x24c858,w()):(_0x24c858=new Go(),_0x44f76c['syncPointTree_']=_0x44f76c['syncPointTree_']['set'](_0x234981,_0x24c858));const _0x529473=_0x133f42!=null,_0x10aea6=_0x529473?new Ce(_0x133f42,!0x0,!0x1):null,_0x2147f4=Mn(_0x44f76c['pendingWriteTree_'],_0xed1182['_path']),_0xf69f21=qo(_0x24c858,_0xed1182,_0x2147f4,_0x529473?_0x10aea6['getNode']():g['EMPTY_NODE'],_0x529473);return Ou(_0xf69f21);}function ht(_0x4097dd,_0x21a16b){return Qo(_0x21a16b,_0x4097dd['syncPointTree_'],null,Mn(_0x4097dd['pendingWriteTree_'],w()));}function Qo(_0x483164,_0x471576,_0x7137f,_0x572e0b){if(v(_0x483164['path']))return Jo(_0x483164,_0x471576,_0x7137f,_0x572e0b);{const _0x39b588=_0x471576['get'](w());_0x7137f==null&&_0x39b588!=null&&(_0x7137f=Ee(_0x39b588,w()));let _0x1d9053=[];const _0x4e91cd=y(_0x483164['path']),_0x1a9279=_0x483164['operationForChild'](_0x4e91cd),_0x33bdf9=_0x471576['children']['get'](_0x4e91cd);if(_0x33bdf9&&_0x1a9279){const _0x3db07c=_0x7137f?_0x7137f['getImmediateChild'](_0x4e91cd):null,_0x5a03ec=Wo(_0x572e0b,_0x4e91cd);_0x1d9053=_0x1d9053['concat'](Qo(_0x1a9279,_0x33bdf9,_0x3db07c,_0x5a03ec));}return _0x39b588&&(_0x1d9053=_0x1d9053['concat'](is(_0x39b588,_0x483164,_0x572e0b,_0x7137f))),_0x1d9053;}}function Jo(_0x2c5f3b,_0x10ac9c,_0x11fb46,_0x5ae120){const _0x3360c2=_0x10ac9c['get'](w());_0x11fb46==null&&_0x3360c2!=null&&(_0x11fb46=Ee(_0x3360c2,w()));let _0x4e772f=[];return _0x10ac9c['children']['inorderTraversal']((_0x18dc7c,_0x57a73f)=>{const _0x55191c=_0x11fb46?_0x11fb46['getImmediateChild'](_0x18dc7c):null,_0x49a5f1=Wo(_0x5ae120,_0x18dc7c),_0x18be57=_0x2c5f3b['operationForChild'](_0x18dc7c);_0x18be57&&(_0x4e772f=_0x4e772f['concat'](Jo(_0x18be57,_0x57a73f,_0x55191c,_0x49a5f1)));}),_0x3360c2&&(_0x4e772f=_0x4e772f['concat'](is(_0x3360c2,_0x2c5f3b,_0x5ae120,_0x11fb46))),_0x4e772f;}function Xo(_0x1ca686,_0x2fcb60){const _0x440bf6=_0x2fcb60['query'],_0x40db57=Mt(_0x1ca686,_0x440bf6);return{'hashFn':()=>(Pu(_0x2fcb60)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x44a9b0=>{if(_0x44a9b0==='ok')return _0x40db57?ju(_0x1ca686,_0x440bf6['_path'],_0x40db57):zu(_0x1ca686,_0x440bf6['_path']);{const _0x2b51ea=ql(_0x44a9b0,_0x440bf6);return wn(_0x1ca686,_0x440bf6,null,_0x2b51ea);}}};}function Mt(_0x2df021,_0x5b4b11){const _0x5a330c=Fn(_0x5b4b11);return _0x2df021['queryToTagMap']['get'](_0x5a330c);}function Fn(_0x10da7d){return _0x10da7d['_path']['toString']()+'$'+_0x10da7d['_queryIdentifier'];}function rs(_0x12aea9,_0x558fdf){return _0x12aea9['tagToQueryMap']['get'](_0x558fdf);}function os(_0x1a2960){const _0x3edaed=_0x1a2960['indexOf']('$');return f(_0x3edaed!==-0x1&&_0x3edaed<_0x1a2960['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1a2960['substr'](_0x3edaed+0x1),'path':new C(_0x1a2960['substr'](0x0,_0x3edaed))};}function as(_0x19cca6,_0x4abaae,_0x1fd975){const _0x582055=_0x19cca6['syncPointTree_']['get'](_0x4abaae);f(_0x582055,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x52c2d5=Mn(_0x19cca6['pendingWriteTree_'],_0x4abaae);return is(_0x582055,_0x1fd975,_0x52c2d5,null);}function Qu(_0x19f1e5){return _0x19f1e5['fold']((_0x1247f4,_0x553693,_0x542bd7)=>{if(_0x553693&&Te(_0x553693))return[Ln(_0x553693)];{let _0x1e5fbb=[];return _0x553693&&(_0x1e5fbb=zo(_0x553693)),x(_0x542bd7,(_0x3ff9d6,_0x15bcbd)=>{_0x1e5fbb=_0x1e5fbb['concat'](_0x15bcbd);}),_0x1e5fbb;}});}function Tt(_0xd3e6e2){return _0xd3e6e2['_queryParams']['loadsAllData']()&&!_0xd3e6e2['_queryParams']['isDefault']()?new(Hu())(_0xd3e6e2['_repo'],_0xd3e6e2['_path']):_0xd3e6e2;}function Ju(_0x129944,_0x27647b){for(let _0x49ae2b=0x0;_0x49ae2b<_0x27647b['length'];++_0x49ae2b){const _0x1636cf=_0x27647b[_0x49ae2b];if(!_0x1636cf['_queryParams']['loadsAllData']()){const _0x14f3bb=Fn(_0x1636cf),_0x26fa84=_0x129944['queryToTagMap']['get'](_0x14f3bb);_0x129944['queryToTagMap']['delete'](_0x14f3bb),_0x129944['tagToQueryMap']['delete'](_0x26fa84);}}}function Xu(){return $u++;}function Zu(_0x121fa3,_0x479b80,_0x14fc3d){const _0x267ecc=_0x479b80['_path'],_0x10cdda=Mt(_0x121fa3,_0x479b80),_0x1ba044=Xo(_0x121fa3,_0x14fc3d),_0x38d0f4=_0x121fa3['listenProvider_']['startListening'](Tt(_0x479b80),_0x10cdda,_0x1ba044['hashFn'],_0x1ba044['onComplete']),_0xb1a8a6=_0x121fa3['syncPointTree_']['subtree'](_0x267ecc);if(_0x10cdda)f(!Te(_0xb1a8a6['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x1e8ff4=_0xb1a8a6['fold']((_0x18a7d5,_0x4c56ae,_0x1ecc91)=>{if(!v(_0x18a7d5)&&_0x4c56ae&&Te(_0x4c56ae))return[Ln(_0x4c56ae)['query']];{let _0xd06ca6=[];return _0x4c56ae&&(_0xd06ca6=_0xd06ca6['concat'](zo(_0x4c56ae)['map'](_0x12d07d=>_0x12d07d['query']))),x(_0x1ecc91,(_0x5375b4,_0x190098)=>{_0xd06ca6=_0xd06ca6['concat'](_0x190098);}),_0xd06ca6;}});for(let _0x230077=0x0;_0x230077<_0x1e8ff4['length'];++_0x230077){const _0x30f8b6=_0x1e8ff4[_0x230077];_0x121fa3['listenProvider_']['stopListening'](Tt(_0x30f8b6),Mt(_0x121fa3,_0x30f8b6));}}return _0x38d0f4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x206c78){this['node_']=_0x206c78;}['getImmediateChild'](_0x2d0933){const _0x1f6ce5=this['node_']['getImmediateChild'](_0x2d0933);return new cs(_0x1f6ce5);}['node'](){return this['node_'];}}class ls{constructor(_0x516797,_0x43c560){this['syncTree_']=_0x516797,this['path_']=_0x43c560;}['getImmediateChild'](_0x1fd964){const _0x27582e=A(this['path_'],_0x1fd964);return new ls(this['syncTree_'],_0x27582e);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x108c47){return _0x108c47=_0x108c47||{},_0x108c47['timestamp']=_0x108c47['timestamp']||new Date()['getTime'](),_0x108c47;},fr=function(_0x26ec96,_0xf708c0,_0x5e85cb){if(!_0x26ec96||typeof _0x26ec96!='object')return _0x26ec96;if(f('.sv'in _0x26ec96,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x26ec96['.sv']=='string')return td(_0x26ec96['.sv'],_0xf708c0,_0x5e85cb);if(typeof _0x26ec96['.sv']=='object')return nd(_0x26ec96['.sv'],_0xf708c0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x26ec96,null,0x2));},td=function(_0x7b773,_0x7394fb,_0x3e26d0){switch(_0x7b773){case'timestamp':return _0x3e26d0['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x7b773);}},nd=function(_0x23a13f,_0x4c7fa8,_0x34fe6c){_0x23a13f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x23a13f,null,0x2));const _0x3c2f41=_0x23a13f['increment'];typeof _0x3c2f41!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3c2f41);const _0x55b006=_0x4c7fa8['node']();if(f(_0x55b006!==null&&typeof _0x55b006<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x55b006['isLeafNode']())return _0x3c2f41;const _0x239446=_0x55b006['getValue']();return typeof _0x239446!='number'?_0x3c2f41:_0x239446+_0x3c2f41;},Zo=function(_0x530213,_0x32dea,_0x1e2d77,_0x113820){return us(_0x32dea,new ls(_0x1e2d77,_0x530213),_0x113820);},hs=function(_0x4d40fc,_0x29e684,_0x1b9ac7){return us(_0x4d40fc,new cs(_0x29e684),_0x1b9ac7);};function us(_0x172cf1,_0x40a52e,_0x15c66d){const _0x2746a7=_0x172cf1['getPriority']()['val'](),_0x49fdc2=fr(_0x2746a7,_0x40a52e['getImmediateChild']('.priority'),_0x15c66d);let _0x23058f;if(_0x172cf1['isLeafNode']()){const _0x4369a3=_0x172cf1,_0x5e72f6=fr(_0x4369a3['getValue'](),_0x40a52e,_0x15c66d);return _0x5e72f6!==_0x4369a3['getValue']()||_0x49fdc2!==_0x4369a3['getPriority']()['val']()?new D(_0x5e72f6,N(_0x49fdc2)):_0x172cf1;}else{const _0x2b0222=_0x172cf1;return _0x23058f=_0x2b0222,_0x49fdc2!==_0x2b0222['getPriority']()['val']()&&(_0x23058f=_0x23058f['updatePriority'](new D(_0x49fdc2))),_0x2b0222['forEachChild'](R,(_0x44c0c,_0x4538c8)=>{const _0x1c9b84=us(_0x4538c8,_0x40a52e['getImmediateChild'](_0x44c0c),_0x15c66d);_0x1c9b84!==_0x4538c8&&(_0x23058f=_0x23058f['updateImmediateChild'](_0x44c0c,_0x1c9b84));}),_0x23058f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x162361='',_0x56ce75=null,_0x545bab={'children':{},'childCount':0x0}){this['name']=_0x162361,this['parent']=_0x56ce75,this['node']=_0x545bab;}}function Un(_0x48679f,_0x35766d){let _0x271758=_0x35766d instanceof C?_0x35766d:new C(_0x35766d),_0x6ec0a0=_0x48679f,_0x5392e8=y(_0x271758);for(;_0x5392e8!==null;){const _0x756d3a=Oe(_0x6ec0a0['node']['children'],_0x5392e8)||{'children':{},'childCount':0x0};_0x6ec0a0=new ds(_0x5392e8,_0x6ec0a0,_0x756d3a),_0x271758=b(_0x271758),_0x5392e8=y(_0x271758);}return _0x6ec0a0;}function Ge(_0x3877c4){return _0x3877c4['node']['value'];}function fs(_0x1259ea,_0x585847){_0x1259ea['node']['value']=_0x585847,Ri(_0x1259ea);}function ea(_0x57ec6a){return _0x57ec6a['node']['childCount']>0x0;}function id(_0x31c4bd){return Ge(_0x31c4bd)===void 0x0&&!ea(_0x31c4bd);}function Wn(_0x30d537,_0x343153){x(_0x30d537['node']['children'],(_0x5b633e,_0x2cf9da)=>{_0x343153(new ds(_0x5b633e,_0x30d537,_0x2cf9da));});}function ta(_0x52cd0d,_0x5ea70c,_0x1de64a,_0x3c7903){_0x1de64a&&_0x5ea70c(_0x52cd0d),Wn(_0x52cd0d,_0x498441=>{ta(_0x498441,_0x5ea70c,!0x0);});}function sd(_0x5957c1,_0x4d3952,_0x34e47e){let _0x1cf9ab=_0x5957c1['parent'];for(;_0x1cf9ab!==null;){if(_0x4d3952(_0x1cf9ab))return!0x0;_0x1cf9ab=_0x1cf9ab['parent'];}return!0x1;}function Gt(_0x1f3670){return new C(_0x1f3670['parent']===null?_0x1f3670['name']:Gt(_0x1f3670['parent'])+'/'+_0x1f3670['name']);}function Ri(_0x5ee4b7){_0x5ee4b7['parent']!==null&&rd(_0x5ee4b7['parent'],_0x5ee4b7['name'],_0x5ee4b7);}function rd(_0x4e9c6e,_0x5d75ba,_0xb502c0){const _0x3ce2fb=id(_0xb502c0),_0x194074=Y(_0x4e9c6e['node']['children'],_0x5d75ba);_0x3ce2fb&&_0x194074?(delete _0x4e9c6e['node']['children'][_0x5d75ba],_0x4e9c6e['node']['childCount']--,Ri(_0x4e9c6e)):!_0x3ce2fb&&!_0x194074&&(_0x4e9c6e['node']['children'][_0x5d75ba]=_0xb502c0['node'],_0x4e9c6e['node']['childCount']++,Ri(_0x4e9c6e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x49cb57){return typeof _0x49cb57=='string'&&_0x49cb57['length']!==0x0&&!od['test'](_0x49cb57);},na=function(_0x398001){return typeof _0x398001=='string'&&_0x398001['length']!==0x0&&!ad['test'](_0x398001);},cd=function(_0x1ddde7){return _0x1ddde7&&(_0x1ddde7=_0x1ddde7['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1ddde7);},Cn=function(_0x5aa6a7){return _0x5aa6a7===null||typeof _0x5aa6a7=='string'||typeof _0x5aa6a7=='number'&&!Wi(_0x5aa6a7)||_0x5aa6a7&&typeof _0x5aa6a7=='object'&&Y(_0x5aa6a7,'.sv');},qt=function(_0x53496f,_0x44b12f,_0x495517,_0x535549){_0x535549&&_0x44b12f===void 0x0||zt(Nn(_0x53496f,'value'),_0x44b12f,_0x495517);},zt=function(_0x57dcb2,_0x401480,_0x5b26c4){const _0x306699=_0x5b26c4 instanceof C?new Sh(_0x5b26c4,_0x57dcb2):_0x5b26c4;if(_0x401480===void 0x0)throw new Error(_0x57dcb2+'contains\x20undefined\x20'+Ne(_0x306699));if(typeof _0x401480=='function')throw new Error(_0x57dcb2+'contains\x20a\x20function\x20'+Ne(_0x306699)+'\x20with\x20contents\x20=\x20'+_0x401480['toString']());if(Wi(_0x401480))throw new Error(_0x57dcb2+'contains\x20'+_0x401480['toString']()+'\x20'+Ne(_0x306699));if(typeof _0x401480=='string'&&_0x401480['length']>oi/0x3&&Pn(_0x401480)>oi)throw new Error(_0x57dcb2+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x306699)+'\x20(\x27'+_0x401480['substring'](0x0,0x32)+'...\x27)');if(_0x401480&&typeof _0x401480=='object'){let _0x7f0c7c=!0x1,_0x1b5766=!0x1;if(x(_0x401480,(_0x4a0716,_0x2c28fb)=>{if(_0x4a0716==='.value')_0x7f0c7c=!0x0;else{if(_0x4a0716!=='.priority'&&_0x4a0716!=='.sv'&&(_0x1b5766=!0x0,!ps(_0x4a0716)))throw new Error(_0x57dcb2+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4a0716+')\x20'+Ne(_0x306699)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x306699,_0x4a0716),zt(_0x57dcb2,_0x2c28fb,_0x306699),Rh(_0x306699);}),_0x7f0c7c&&_0x1b5766)throw new Error(_0x57dcb2+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x306699)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x5b24a7,_0x2910e2){let _0xca1c02,_0x4f1e3;for(_0xca1c02=0x0;_0xca1c02<_0x2910e2['length'];_0xca1c02++){_0x4f1e3=_0x2910e2[_0xca1c02];const _0x115560=kt(_0x4f1e3);for(let _0xdf5573=0x0;_0xdf5573<_0x115560['length'];_0xdf5573++)if(!(_0x115560[_0xdf5573]==='.priority'&&_0xdf5573===_0x115560['length']-0x1)){if(!ps(_0x115560[_0xdf5573]))throw new Error(_0x5b24a7+'contains\x20an\x20invalid\x20key\x20('+_0x115560[_0xdf5573]+')\x20in\x20path\x20'+_0x4f1e3['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2910e2['sort'](Th);let _0x52bb1c=null;for(_0xca1c02=0x0;_0xca1c02<_0x2910e2['length'];_0xca1c02++){if(_0x4f1e3=_0x2910e2[_0xca1c02],_0x52bb1c!==null&&$(_0x52bb1c,_0x4f1e3))throw new Error(_0x5b24a7+'contains\x20a\x20path\x20'+_0x52bb1c['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4f1e3['toString']());_0x52bb1c=_0x4f1e3;}},hd=function(_0x3dff29,_0x290375,_0x3689b9,_0x19a942){const _0x59d17d=Nn(_0x3dff29,'values');if(!(_0x290375&&typeof _0x290375=='object')||Array['isArray'](_0x290375))throw new Error(_0x59d17d+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x55e459=[];x(_0x290375,(_0x529a02,_0x3cb110)=>{const _0x2d9fee=new C(_0x529a02);if(zt(_0x59d17d,_0x3cb110,A(_0x3689b9,_0x2d9fee)),Gi(_0x2d9fee)==='.priority'&&!Cn(_0x3cb110))throw new Error(_0x59d17d+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2d9fee['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x55e459['push'](_0x2d9fee);}),ld(_0x59d17d,_0x55e459);},_s=function(_0x18b9ad,_0x3e8ab8,_0x53ecc0,_0x262adf){if(!na(_0x53ecc0))throw new Error(Nn(_0x18b9ad,_0x3e8ab8)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x53ecc0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x34f7ca,_0x7bdfb9,_0xe352a5,_0x8ff0cc){_0xe352a5&&(_0xe352a5=_0xe352a5['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x34f7ca,_0x7bdfb9,_0xe352a5);},gs=function(_0xcb95e1,_0x4cc2c1){if(y(_0x4cc2c1)==='.info')throw new Error(_0xcb95e1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x52b711,_0x4a45d4){const _0x321555=_0x4a45d4['path']['toString']();if(typeof _0x4a45d4['repoInfo']['host']!='string'||_0x4a45d4['repoInfo']['host']['length']===0x0||!ps(_0x4a45d4['repoInfo']['namespace'])&&_0x4a45d4['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x321555['length']!==0x0&&!cd(_0x321555))throw new Error(Nn(_0x52b711,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x170504,_0x3bb038){let _0x1b9dbd=null;for(let _0x5d64b5=0x0;_0x5d64b5<_0x3bb038['length'];_0x5d64b5++){const _0x8db4ee=_0x3bb038[_0x5d64b5],_0x539e05=_0x8db4ee['getPath']();_0x1b9dbd!==null&&!qi(_0x539e05,_0x1b9dbd['path'])&&(_0x170504['eventLists_']['push'](_0x1b9dbd),_0x1b9dbd=null),_0x1b9dbd===null&&(_0x1b9dbd={'events':[],'path':_0x539e05}),_0x1b9dbd['events']['push'](_0x8db4ee);}_0x1b9dbd&&_0x170504['eventLists_']['push'](_0x1b9dbd);}function ia(_0x3053a0,_0x4c1b4a,_0x5d1d1a){Bn(_0x3053a0,_0x5d1d1a),sa(_0x3053a0,_0x51c91c=>qi(_0x51c91c,_0x4c1b4a));}function V(_0x2e2470,_0x322c76,_0x14d901){Bn(_0x2e2470,_0x14d901),sa(_0x2e2470,_0x38b1d9=>$(_0x38b1d9,_0x322c76)||$(_0x322c76,_0x38b1d9));}function sa(_0x21bc11,_0x23428b){_0x21bc11['recursionDepth_']++;let _0x17787b=!0x0;for(let _0x2f7a16=0x0;_0x2f7a16<_0x21bc11['eventLists_']['length'];_0x2f7a16++){const _0x9024e6=_0x21bc11['eventLists_'][_0x2f7a16];if(_0x9024e6){const _0x15a5df=_0x9024e6['path'];_0x23428b(_0x15a5df)?(pd(_0x21bc11['eventLists_'][_0x2f7a16]),_0x21bc11['eventLists_'][_0x2f7a16]=null):_0x17787b=!0x1;}}_0x17787b&&(_0x21bc11['eventLists_']=[]),_0x21bc11['recursionDepth_']--;}function pd(_0x5bb46b){for(let _0x307dbb=0x0;_0x307dbb<_0x5bb46b['events']['length'];_0x307dbb++){const _0x10ba8a=_0x5bb46b['events'][_0x307dbb];if(_0x10ba8a!==null){_0x5bb46b['events'][_0x307dbb]=null;const _0x3084f4=_0x10ba8a['getEventRunner']();Et&&L('event:\x20'+_0x10ba8a['toString']()),lt(_0x3084f4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x17a93b,_0x499b42,_0x2e6204,_0xca0fb4){this['repoInfo_']=_0x17a93b,this['forceRestClient_']=_0x499b42,this['authTokenProvider_']=_0x2e6204,this['appCheckProvider_']=_0xca0fb4,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x1c6a71,_0x3011b5,_0x329db4){if(_0x1c6a71['stats_']=Hi(_0x1c6a71['repoInfo_']),_0x1c6a71['forceRestClient_']||Yl())_0x1c6a71['server_']=new fn(_0x1c6a71['repoInfo_'],(_0x298dea,_0x5b24f5,_0x1e8198,_0x4c7a98)=>{pr(_0x1c6a71,_0x298dea,_0x5b24f5,_0x1e8198,_0x4c7a98);},_0x1c6a71['authTokenProvider_'],_0x1c6a71['appCheckProvider_']),setTimeout(()=>_r(_0x1c6a71,!0x0),0x0);else{if(typeof _0x329db4<'u'&&_0x329db4!==null){if(typeof _0x329db4!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x329db4);}catch(_0x5d6069){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5d6069);}}_0x1c6a71['persistentConnection_']=new ie(_0x1c6a71['repoInfo_'],_0x3011b5,(_0x189aa3,_0x3b0d90,_0xd24bce,_0x20759b)=>{pr(_0x1c6a71,_0x189aa3,_0x3b0d90,_0xd24bce,_0x20759b);},_0x508ecb=>{_r(_0x1c6a71,_0x508ecb);},_0x560e10=>{yd(_0x1c6a71,_0x560e10);},_0x1c6a71['authTokenProvider_'],_0x1c6a71['appCheckProvider_'],_0x329db4),_0x1c6a71['server_']=_0x1c6a71['persistentConnection_'];}_0x1c6a71['authTokenProvider_']['addTokenChangeListener'](_0x4bc664=>{_0x1c6a71['server_']['refreshAuthToken'](_0x4bc664);}),_0x1c6a71['appCheckProvider_']['addTokenChangeListener'](_0x46ee8f=>{_0x1c6a71['server_']['refreshAppCheckToken'](_0x46ee8f['token']);}),_0x1c6a71['statsReporter_']=eh(_0x1c6a71['repoInfo_'],()=>new eu(_0x1c6a71['stats_'],_0x1c6a71['server_'])),_0x1c6a71['infoData_']=new Yh(),_0x1c6a71['infoSyncTree_']=new dr({'startListening':(_0x1637ec,_0x121da7,_0x524739,_0x5495bb)=>{let _0x1218b1=[];const _0x170eeb=_0x1c6a71['infoData_']['getNode'](_0x1637ec['_path']);return _0x170eeb['isEmpty']()||(_0x1218b1=$t(_0x1c6a71['infoSyncTree_'],_0x1637ec['_path'],_0x170eeb),setTimeout(()=>{_0x5495bb('ok');},0x0)),_0x1218b1;},'stopListening':()=>{}}),ms(_0x1c6a71,'connected',!0x1),_0x1c6a71['serverSyncTree_']=new dr({'startListening':(_0x7e8623,_0x1d0e3c,_0x227d82,_0x146796)=>(_0x1c6a71['server_']['listen'](_0x7e8623,_0x227d82,_0x1d0e3c,(_0x145b80,_0x1eacf8)=>{const _0x1f5296=_0x146796(_0x145b80,_0x1eacf8);V(_0x1c6a71['eventQueue_'],_0x7e8623['_path'],_0x1f5296);}),[]),'stopListening':(_0x389292,_0xba87c4)=>{_0x1c6a71['server_']['unlisten'](_0x389292,_0xba87c4);}});}function oa(_0x428c63){const _0x44d0cc=_0x428c63['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x44d0cc;}function jt(_0x525f11){return ed({'timestamp':oa(_0x525f11)});}function pr(_0x17c388,_0x313c2a,_0x246a43,_0x56d85d,_0x136f84){_0x17c388['dataUpdateCount']++;const _0x4caa0c=new C(_0x313c2a);_0x246a43=_0x17c388['interceptServerDataCallback_']?_0x17c388['interceptServerDataCallback_'](_0x313c2a,_0x246a43):_0x246a43;let _0x34c33e=[];if(_0x136f84){if(_0x56d85d){const _0x1af0d2=ln(_0x246a43,_0x55b8dd=>N(_0x55b8dd));_0x34c33e=Ku(_0x17c388['serverSyncTree_'],_0x4caa0c,_0x1af0d2,_0x136f84);}else{const _0x2e44d3=N(_0x246a43);_0x34c33e=Yo(_0x17c388['serverSyncTree_'],_0x4caa0c,_0x2e44d3,_0x136f84);}}else{if(_0x56d85d){const _0x237454=ln(_0x246a43,_0x1739d6=>N(_0x1739d6));_0x34c33e=qu(_0x17c388['serverSyncTree_'],_0x4caa0c,_0x237454);}else{const _0x4168ae=N(_0x246a43);_0x34c33e=$t(_0x17c388['serverSyncTree_'],_0x4caa0c,_0x4168ae);}}let _0x9432b9=_0x4caa0c;_0x34c33e['length']>0x0&&(_0x9432b9=st(_0x17c388,_0x4caa0c)),V(_0x17c388['eventQueue_'],_0x9432b9,_0x34c33e);}function _r(_0x1d460d,_0x6db450){ms(_0x1d460d,'connected',_0x6db450),_0x6db450===!0x1&&wd(_0x1d460d);}function yd(_0x58b4ad,_0xb907e7){x(_0xb907e7,(_0x384734,_0xba157b)=>{ms(_0x58b4ad,_0x384734,_0xba157b);});}function ms(_0x3687c0,_0x3f18c4,_0x230ad6){const _0x2e8408=new C('/.info/'+_0x3f18c4),_0x3020d8=N(_0x230ad6);_0x3687c0['infoData_']['updateSnapshot'](_0x2e8408,_0x3020d8);const _0x53c389=$t(_0x3687c0['infoSyncTree_'],_0x2e8408,_0x3020d8);V(_0x3687c0['eventQueue_'],_0x2e8408,_0x53c389);}function Vn(_0xd5a727){return _0xd5a727['nextWriteId_']++;}function vd(_0x54900f,_0x57049c,_0x2ebbaa){const _0x828383=Yu(_0x54900f['serverSyncTree_'],_0x57049c);return _0x828383!=null?Promise['resolve'](_0x828383):_0x54900f['server_']['get'](_0x57049c)['then'](_0x231a2e=>{const _0x391e5a=N(_0x231a2e)['withIndex'](_0x57049c['_queryParams']['getIndex']());bi(_0x54900f['serverSyncTree_'],_0x57049c,_0x2ebbaa,!0x0);let _0x37cb6b;if(_0x57049c['_queryParams']['loadsAllData']())_0x37cb6b=$t(_0x54900f['serverSyncTree_'],_0x57049c['_path'],_0x391e5a);else{const _0x4c080e=Mt(_0x54900f['serverSyncTree_'],_0x57049c);_0x37cb6b=Yo(_0x54900f['serverSyncTree_'],_0x57049c['_path'],_0x391e5a,_0x4c080e);}return V(_0x54900f['eventQueue_'],_0x57049c['_path'],_0x37cb6b),wn(_0x54900f['serverSyncTree_'],_0x57049c,_0x2ebbaa,null,!0x0),_0x391e5a;},_0x1a36f7=>(ut(_0x54900f,'get\x20for\x20query\x20'+O(_0x57049c)+'\x20failed:\x20'+_0x1a36f7),Promise['reject'](new Error(_0x1a36f7))));}function Ed(_0x58bea9,_0x2a0154,_0x4dbf4e,_0xf5e374,_0x5ad11b){ut(_0x58bea9,'set',{'path':_0x2a0154['toString'](),'value':_0x4dbf4e,'priority':_0xf5e374});const _0x238ce2=jt(_0x58bea9),_0x2c18f9=N(_0x4dbf4e,_0xf5e374),_0x4ce7d6=xn(_0x58bea9['serverSyncTree_'],_0x2a0154),_0x38e47a=hs(_0x2c18f9,_0x4ce7d6,_0x238ce2),_0x3f81bd=Vn(_0x58bea9),_0x2f0135=ss(_0x58bea9['serverSyncTree_'],_0x2a0154,_0x38e47a,_0x3f81bd,!0x0);Bn(_0x58bea9['eventQueue_'],_0x2f0135),_0x58bea9['server_']['put'](_0x2a0154['toString'](),_0x2c18f9['val'](!0x0),(_0x300622,_0x5d6d9e)=>{const _0x3a680a=_0x300622==='ok';_0x3a680a||U('set\x20at\x20'+_0x2a0154+'\x20failed:\x20'+_0x300622);const _0x5d083c=pe(_0x58bea9['serverSyncTree_'],_0x3f81bd,!_0x3a680a);V(_0x58bea9['eventQueue_'],_0x2a0154,_0x5d083c),Ai(_0x58bea9,_0x5ad11b,_0x300622,_0x5d6d9e);});const _0x4e8931=vs(_0x58bea9,_0x2a0154);st(_0x58bea9,_0x4e8931),V(_0x58bea9['eventQueue_'],_0x4e8931,[]);}function Id(_0x406841,_0x295d1a,_0xfa054b,_0x2782fa){ut(_0x406841,'update',{'path':_0x295d1a['toString'](),'value':_0xfa054b});let _0x245361=!0x0;const _0x458712=jt(_0x406841),_0x489a6a={};if(x(_0xfa054b,(_0x29d968,_0x39f7d5)=>{_0x245361=!0x1,_0x489a6a[_0x29d968]=Zo(A(_0x295d1a,_0x29d968),N(_0x39f7d5),_0x406841['serverSyncTree_'],_0x458712);}),_0x245361)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x406841,_0x2782fa,'ok',void 0x0);else{const _0x2d3013=Vn(_0x406841),_0x591361=Gu(_0x406841['serverSyncTree_'],_0x295d1a,_0x489a6a,_0x2d3013);Bn(_0x406841['eventQueue_'],_0x591361),_0x406841['server_']['merge'](_0x295d1a['toString'](),_0xfa054b,(_0x32c7db,_0x3fc4b3)=>{const _0x5a501c=_0x32c7db==='ok';_0x5a501c||U('update\x20at\x20'+_0x295d1a+'\x20failed:\x20'+_0x32c7db);const _0x3e8117=pe(_0x406841['serverSyncTree_'],_0x2d3013,!_0x5a501c),_0x13cc55=_0x3e8117['length']>0x0?st(_0x406841,_0x295d1a):_0x295d1a;V(_0x406841['eventQueue_'],_0x13cc55,_0x3e8117),Ai(_0x406841,_0x2782fa,_0x32c7db,_0x3fc4b3);}),x(_0xfa054b,_0x136684=>{const _0x413fef=vs(_0x406841,A(_0x295d1a,_0x136684));st(_0x406841,_0x413fef);}),V(_0x406841['eventQueue_'],_0x295d1a,[]);}}function wd(_0x3900fe){ut(_0x3900fe,'onDisconnectEvents');const _0x24b7a7=jt(_0x3900fe),_0x34a1bb=pn();Ei(_0x3900fe['onDisconnect_'],w(),(_0x2a55c0,_0x55a1d8)=>{const _0x593dac=Zo(_0x2a55c0,_0x55a1d8,_0x3900fe['serverSyncTree_'],_0x24b7a7);Mo(_0x34a1bb,_0x2a55c0,_0x593dac);});let _0x29cfe6=[];Ei(_0x34a1bb,w(),(_0x5bc371,_0x23770d)=>{_0x29cfe6=_0x29cfe6['concat']($t(_0x3900fe['serverSyncTree_'],_0x5bc371,_0x23770d));const _0x4c11c8=vs(_0x3900fe,_0x5bc371);st(_0x3900fe,_0x4c11c8);}),_0x3900fe['onDisconnect_']=pn(),V(_0x3900fe['eventQueue_'],w(),_0x29cfe6);}function Cd(_0x185067,_0x17ae19,_0x523b15){let _0x4b0fd1;y(_0x17ae19['_path'])==='.info'?_0x4b0fd1=bi(_0x185067['infoSyncTree_'],_0x17ae19,_0x523b15):_0x4b0fd1=bi(_0x185067['serverSyncTree_'],_0x17ae19,_0x523b15),ia(_0x185067['eventQueue_'],_0x17ae19['_path'],_0x4b0fd1);}function Td(_0x47b487,_0x9b73b8,_0x536852){let _0x572279;y(_0x9b73b8['_path'])==='.info'?_0x572279=wn(_0x47b487['infoSyncTree_'],_0x9b73b8,_0x536852):_0x572279=wn(_0x47b487['serverSyncTree_'],_0x9b73b8,_0x536852),ia(_0x47b487['eventQueue_'],_0x9b73b8['_path'],_0x572279);}function aa(_0x4c2bbb){_0x4c2bbb['persistentConnection_']&&_0x4c2bbb['persistentConnection_']['interrupt'](ra);}function Sd(_0x1740e6){_0x1740e6['persistentConnection_']&&_0x1740e6['persistentConnection_']['resume'](ra);}function ut(_0x22c1b5,..._0x5b38c1){let _0xd364b5='';_0x22c1b5['persistentConnection_']&&(_0xd364b5=_0x22c1b5['persistentConnection_']['id']+':'),L(_0xd364b5,..._0x5b38c1);}function Ai(_0x3802dd,_0x44b739,_0x35c07e,_0x580237){_0x44b739&&lt(()=>{if(_0x35c07e==='ok')_0x44b739(null);else{const _0x3b9899=(_0x35c07e||'error')['toUpperCase']();let _0x30766f=_0x3b9899;_0x580237&&(_0x30766f+=':\x20'+_0x580237);const _0x2b28b9=new Error(_0x30766f);_0x2b28b9['code']=_0x3b9899,_0x44b739(_0x2b28b9);}});}function bd(_0x3f4c88,_0x286753,_0x3153f8,_0x5bb08e,_0x240e92,_0x4f360b){ut(_0x3f4c88,'transaction\x20on\x20'+_0x286753);const _0x2cffa0={'path':_0x286753,'update':_0x3153f8,'onComplete':_0x5bb08e,'status':null,'order':to(),'applyLocally':_0x4f360b,'retryCount':0x0,'unwatcher':_0x240e92,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x548d2a=ys(_0x3f4c88,_0x286753,void 0x0);_0x2cffa0['currentInputSnapshot']=_0x548d2a;const _0x4abf75=_0x2cffa0['update'](_0x548d2a['val']());if(_0x4abf75===void 0x0)_0x2cffa0['unwatcher'](),_0x2cffa0['currentOutputSnapshotRaw']=null,_0x2cffa0['currentOutputSnapshotResolved']=null,_0x2cffa0['onComplete']&&_0x2cffa0['onComplete'](null,!0x1,_0x2cffa0['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x4abf75,_0x2cffa0['path']),_0x2cffa0['status']=0x0;const _0x9e719b=Un(_0x3f4c88['transactionQueueTree_'],_0x286753),_0x46ceac=Ge(_0x9e719b)||[];_0x46ceac['push'](_0x2cffa0),fs(_0x9e719b,_0x46ceac);let _0x108d23;typeof _0x4abf75=='object'&&_0x4abf75!==null&&Y(_0x4abf75,'.priority')?(_0x108d23=Oe(_0x4abf75,'.priority'),f(Cn(_0x108d23),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x108d23=(xn(_0x3f4c88['serverSyncTree_'],_0x286753)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x97ae29=jt(_0x3f4c88),_0x1a3024=N(_0x4abf75,_0x108d23),_0x55ebeb=hs(_0x1a3024,_0x548d2a,_0x97ae29);_0x2cffa0['currentOutputSnapshotRaw']=_0x1a3024,_0x2cffa0['currentOutputSnapshotResolved']=_0x55ebeb,_0x2cffa0['currentWriteId']=Vn(_0x3f4c88);const _0x206be0=ss(_0x3f4c88['serverSyncTree_'],_0x286753,_0x55ebeb,_0x2cffa0['currentWriteId'],_0x2cffa0['applyLocally']);V(_0x3f4c88['eventQueue_'],_0x286753,_0x206be0),Hn(_0x3f4c88,_0x3f4c88['transactionQueueTree_']);}}function ys(_0x2dcac0,_0x3cc95a,_0x17cac0){return xn(_0x2dcac0['serverSyncTree_'],_0x3cc95a,_0x17cac0)||g['EMPTY_NODE'];}function Hn(_0x5df71e,_0x58d25f=_0x5df71e['transactionQueueTree_']){if(_0x58d25f||$n(_0x5df71e,_0x58d25f),Ge(_0x58d25f)){const _0x3f9e6a=la(_0x5df71e,_0x58d25f);f(_0x3f9e6a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3f9e6a['every'](_0x41b29d=>_0x41b29d['status']===0x0)&&Rd(_0x5df71e,Gt(_0x58d25f),_0x3f9e6a);}else ea(_0x58d25f)&&Wn(_0x58d25f,_0x749f33=>{Hn(_0x5df71e,_0x749f33);});}function Rd(_0x450be6,_0x24acff,_0x7f865f){const _0x204c94=_0x7f865f['map'](_0x270f15=>_0x270f15['currentWriteId']),_0x4d1077=ys(_0x450be6,_0x24acff,_0x204c94);let _0x24bc0d=_0x4d1077;const _0x38b95e=_0x4d1077['hash']();for(let _0x355698=0x0;_0x355698<_0x7f865f['length'];_0x355698++){const _0x58296e=_0x7f865f[_0x355698];f(_0x58296e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x58296e['status']=0x1,_0x58296e['retryCount']++;const _0x1261fc=F(_0x24acff,_0x58296e['path']);_0x24bc0d=_0x24bc0d['updateChild'](_0x1261fc,_0x58296e['currentOutputSnapshotRaw']);}const _0x45d092=_0x24bc0d['val'](!0x0),_0x56763d=_0x24acff;_0x450be6['server_']['put'](_0x56763d['toString'](),_0x45d092,_0x96f633=>{ut(_0x450be6,'transaction\x20put\x20response',{'path':_0x56763d['toString'](),'status':_0x96f633});let _0x4f2879=[];if(_0x96f633==='ok'){const _0x5d069b=[];for(let _0x59a9ba=0x0;_0x59a9ba<_0x7f865f['length'];_0x59a9ba++)_0x7f865f[_0x59a9ba]['status']=0x2,_0x4f2879=_0x4f2879['concat'](pe(_0x450be6['serverSyncTree_'],_0x7f865f[_0x59a9ba]['currentWriteId'])),_0x7f865f[_0x59a9ba]['onComplete']&&_0x5d069b['push'](()=>_0x7f865f[_0x59a9ba]['onComplete'](null,!0x0,_0x7f865f[_0x59a9ba]['currentOutputSnapshotResolved'])),_0x7f865f[_0x59a9ba]['unwatcher']();$n(_0x450be6,Un(_0x450be6['transactionQueueTree_'],_0x24acff)),Hn(_0x450be6,_0x450be6['transactionQueueTree_']),V(_0x450be6['eventQueue_'],_0x24acff,_0x4f2879);for(let _0x999bc2=0x0;_0x999bc2<_0x5d069b['length'];_0x999bc2++)lt(_0x5d069b[_0x999bc2]);}else{if(_0x96f633==='datastale'){for(let _0x33f644=0x0;_0x33f644<_0x7f865f['length'];_0x33f644++)_0x7f865f[_0x33f644]['status']===0x3?_0x7f865f[_0x33f644]['status']=0x4:_0x7f865f[_0x33f644]['status']=0x0;}else{U('transaction\x20at\x20'+_0x56763d['toString']()+'\x20failed:\x20'+_0x96f633);for(let _0x313e80=0x0;_0x313e80<_0x7f865f['length'];_0x313e80++)_0x7f865f[_0x313e80]['status']=0x4,_0x7f865f[_0x313e80]['abortReason']=_0x96f633;}st(_0x450be6,_0x24acff);}},_0x38b95e);}function st(_0x5bee71,_0x3dc6c5){const _0x456d99=ca(_0x5bee71,_0x3dc6c5),_0x21ff82=Gt(_0x456d99),_0x355e67=la(_0x5bee71,_0x456d99);return Ad(_0x5bee71,_0x355e67,_0x21ff82),_0x21ff82;}function Ad(_0xc6344a,_0x47e7a4,_0x1e5316){if(_0x47e7a4['length']===0x0)return;const _0x2f7b2e=[];let _0x4111af=[];const _0x674341=_0x47e7a4['filter'](_0x2b919c=>_0x2b919c['status']===0x0)['map'](_0x456adb=>_0x456adb['currentWriteId']);for(let _0x4f5443=0x0;_0x4f5443<_0x47e7a4['length'];_0x4f5443++){const _0x509f13=_0x47e7a4[_0x4f5443],_0x11312c=F(_0x1e5316,_0x509f13['path']);let _0x8bc75e=!0x1,_0x4c9e8a;if(f(_0x11312c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x509f13['status']===0x4)_0x8bc75e=!0x0,_0x4c9e8a=_0x509f13['abortReason'],_0x4111af=_0x4111af['concat'](pe(_0xc6344a['serverSyncTree_'],_0x509f13['currentWriteId'],!0x0));else{if(_0x509f13['status']===0x0){if(_0x509f13['retryCount']>=_d)_0x8bc75e=!0x0,_0x4c9e8a='maxretry',_0x4111af=_0x4111af['concat'](pe(_0xc6344a['serverSyncTree_'],_0x509f13['currentWriteId'],!0x0));else{const _0x239986=ys(_0xc6344a,_0x509f13['path'],_0x674341);_0x509f13['currentInputSnapshot']=_0x239986;const _0x33d880=_0x47e7a4[_0x4f5443]['update'](_0x239986['val']());if(_0x33d880!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x33d880,_0x509f13['path']);let _0x1964ad=N(_0x33d880);typeof _0x33d880=='object'&&_0x33d880!=null&&Y(_0x33d880,'.priority')||(_0x1964ad=_0x1964ad['updatePriority'](_0x239986['getPriority']()));const _0x390752=_0x509f13['currentWriteId'],_0x210f32=jt(_0xc6344a),_0x33f957=hs(_0x1964ad,_0x239986,_0x210f32);_0x509f13['currentOutputSnapshotRaw']=_0x1964ad,_0x509f13['currentOutputSnapshotResolved']=_0x33f957,_0x509f13['currentWriteId']=Vn(_0xc6344a),_0x674341['splice'](_0x674341['indexOf'](_0x390752),0x1),_0x4111af=_0x4111af['concat'](ss(_0xc6344a['serverSyncTree_'],_0x509f13['path'],_0x33f957,_0x509f13['currentWriteId'],_0x509f13['applyLocally'])),_0x4111af=_0x4111af['concat'](pe(_0xc6344a['serverSyncTree_'],_0x390752,!0x0));}else _0x8bc75e=!0x0,_0x4c9e8a='nodata',_0x4111af=_0x4111af['concat'](pe(_0xc6344a['serverSyncTree_'],_0x509f13['currentWriteId'],!0x0));}}}V(_0xc6344a['eventQueue_'],_0x1e5316,_0x4111af),_0x4111af=[],_0x8bc75e&&(_0x47e7a4[_0x4f5443]['status']=0x2,function(_0x4d9448){setTimeout(_0x4d9448,Math['floor'](0x0));}(_0x47e7a4[_0x4f5443]['unwatcher']),_0x47e7a4[_0x4f5443]['onComplete']&&(_0x4c9e8a==='nodata'?_0x2f7b2e['push'](()=>_0x47e7a4[_0x4f5443]['onComplete'](null,!0x1,_0x47e7a4[_0x4f5443]['currentInputSnapshot'])):_0x2f7b2e['push'](()=>_0x47e7a4[_0x4f5443]['onComplete'](new Error(_0x4c9e8a),!0x1,null))));}$n(_0xc6344a,_0xc6344a['transactionQueueTree_']);for(let _0x22dd55=0x0;_0x22dd55<_0x2f7b2e['length'];_0x22dd55++)lt(_0x2f7b2e[_0x22dd55]);Hn(_0xc6344a,_0xc6344a['transactionQueueTree_']);}function ca(_0x3d160a,_0x5cd6f5){let _0x8ff5a7,_0x59fb78=_0x3d160a['transactionQueueTree_'];for(_0x8ff5a7=y(_0x5cd6f5);_0x8ff5a7!==null&&Ge(_0x59fb78)===void 0x0;)_0x59fb78=Un(_0x59fb78,_0x8ff5a7),_0x5cd6f5=b(_0x5cd6f5),_0x8ff5a7=y(_0x5cd6f5);return _0x59fb78;}function la(_0xcc7c04,_0x406e6c){const _0x5b965c=[];return ha(_0xcc7c04,_0x406e6c,_0x5b965c),_0x5b965c['sort']((_0x2a43ae,_0x5ab1d5)=>_0x2a43ae['order']-_0x5ab1d5['order']),_0x5b965c;}function ha(_0x4024a8,_0x472c64,_0x11e06b){const _0x58effb=Ge(_0x472c64);if(_0x58effb){for(let _0x351f20=0x0;_0x351f20<_0x58effb['length'];_0x351f20++)_0x11e06b['push'](_0x58effb[_0x351f20]);}Wn(_0x472c64,_0x48d134=>{ha(_0x4024a8,_0x48d134,_0x11e06b);});}function $n(_0x53592d,_0x37f410){const _0x2c1e73=Ge(_0x37f410);if(_0x2c1e73){let _0x547c4a=0x0;for(let _0x2bf77a=0x0;_0x2bf77a<_0x2c1e73['length'];_0x2bf77a++)_0x2c1e73[_0x2bf77a]['status']!==0x2&&(_0x2c1e73[_0x547c4a]=_0x2c1e73[_0x2bf77a],_0x547c4a++);_0x2c1e73['length']=_0x547c4a,fs(_0x37f410,_0x2c1e73['length']>0x0?_0x2c1e73:void 0x0);}Wn(_0x37f410,_0x33d998=>{$n(_0x53592d,_0x33d998);});}function vs(_0x5ebb55,_0x4042f1){const _0x1b899a=Gt(ca(_0x5ebb55,_0x4042f1)),_0xd345c=Un(_0x5ebb55['transactionQueueTree_'],_0x4042f1);return sd(_0xd345c,_0xaa06d6=>{ai(_0x5ebb55,_0xaa06d6);}),ai(_0x5ebb55,_0xd345c),ta(_0xd345c,_0x2207c8=>{ai(_0x5ebb55,_0x2207c8);}),_0x1b899a;}function ai(_0x306c67,_0xf2ca1b){const _0x53afdf=Ge(_0xf2ca1b);if(_0x53afdf){const _0x31dc0c=[];let _0x2938ab=[],_0x5b94d9=-0x1;for(let _0x1e09cc=0x0;_0x1e09cc<_0x53afdf['length'];_0x1e09cc++)_0x53afdf[_0x1e09cc]['status']===0x3||(_0x53afdf[_0x1e09cc]['status']===0x1?(f(_0x5b94d9===_0x1e09cc-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5b94d9=_0x1e09cc,_0x53afdf[_0x1e09cc]['status']=0x3,_0x53afdf[_0x1e09cc]['abortReason']='set'):(f(_0x53afdf[_0x1e09cc]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x53afdf[_0x1e09cc]['unwatcher'](),_0x2938ab=_0x2938ab['concat'](pe(_0x306c67['serverSyncTree_'],_0x53afdf[_0x1e09cc]['currentWriteId'],!0x0)),_0x53afdf[_0x1e09cc]['onComplete']&&_0x31dc0c['push'](_0x53afdf[_0x1e09cc]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5b94d9===-0x1?fs(_0xf2ca1b,void 0x0):_0x53afdf['length']=_0x5b94d9+0x1,V(_0x306c67['eventQueue_'],Gt(_0xf2ca1b),_0x2938ab);for(let _0x618568=0x0;_0x618568<_0x31dc0c['length'];_0x618568++)lt(_0x31dc0c[_0x618568]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x456a06){let _0x1a1afc='';const _0x19e5ba=_0x456a06['split']('/');for(let _0x4ebb66=0x0;_0x4ebb66<_0x19e5ba['length'];_0x4ebb66++)if(_0x19e5ba[_0x4ebb66]['length']>0x0){let _0x5cc9f2=_0x19e5ba[_0x4ebb66];try{_0x5cc9f2=decodeURIComponent(_0x5cc9f2['replace'](/\+/g,'\x20'));}catch{}_0x1a1afc+='/'+_0x5cc9f2;}return _0x1a1afc;}function Nd(_0x382125){const _0x124bea={};_0x382125['charAt'](0x0)==='?'&&(_0x382125=_0x382125['substring'](0x1));for(const _0x5f06e4 of _0x382125['split']('&')){if(_0x5f06e4['length']===0x0)continue;const _0x4c352b=_0x5f06e4['split']('=');_0x4c352b['length']===0x2?_0x124bea[decodeURIComponent(_0x4c352b[0x0])]=decodeURIComponent(_0x4c352b[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5f06e4+'\x27\x20in\x20query\x20\x27'+_0x382125+'\x27');}return _0x124bea;}const gr=function(_0x253c76,_0x375286){const _0x278387=Pd(_0x253c76),_0x400ab3=_0x278387['namespace'];_0x278387['domain']==='firebase.com'&&oe(_0x278387['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x400ab3||_0x400ab3==='undefined')&&_0x278387['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x278387['secure']||Bl();const _0x23a7c6=_0x278387['scheme']==='ws'||_0x278387['scheme']==='wss';return{'repoInfo':new _o(_0x278387['host'],_0x278387['secure'],_0x400ab3,_0x23a7c6,_0x375286,'',_0x400ab3!==_0x278387['subdomain']),'path':new C(_0x278387['pathString'])};},Pd=function(_0x3950e9){let _0xa4cc7a='',_0x41b0ce='',_0xb5d92e='',_0x48e9a3='',_0x2aba58='',_0x2fed64=!0x0,_0x521e55='https',_0x149044=0x1bb;if(typeof _0x3950e9=='string'){let _0x36d36a=_0x3950e9['indexOf']('//');_0x36d36a>=0x0&&(_0x521e55=_0x3950e9['substring'](0x0,_0x36d36a-0x1),_0x3950e9=_0x3950e9['substring'](_0x36d36a+0x2));let _0xffb51=_0x3950e9['indexOf']('/');_0xffb51===-0x1&&(_0xffb51=_0x3950e9['length']);let _0x4ad88a=_0x3950e9['indexOf']('?');_0x4ad88a===-0x1&&(_0x4ad88a=_0x3950e9['length']),_0xa4cc7a=_0x3950e9['substring'](0x0,Math['min'](_0xffb51,_0x4ad88a)),_0xffb51<_0x4ad88a&&(_0x48e9a3=kd(_0x3950e9['substring'](_0xffb51,_0x4ad88a)));const _0x1f8642=Nd(_0x3950e9['substring'](Math['min'](_0x3950e9['length'],_0x4ad88a)));_0x36d36a=_0xa4cc7a['indexOf'](':'),_0x36d36a>=0x0?(_0x2fed64=_0x521e55==='https'||_0x521e55==='wss',_0x149044=parseInt(_0xa4cc7a['substring'](_0x36d36a+0x1),0xa)):_0x36d36a=_0xa4cc7a['length'];const _0x17fbc8=_0xa4cc7a['slice'](0x0,_0x36d36a);if(_0x17fbc8['toLowerCase']()==='localhost')_0x41b0ce='localhost';else{if(_0x17fbc8['split']('.')['length']<=0x2)_0x41b0ce=_0x17fbc8;else{const _0x476a2d=_0xa4cc7a['indexOf']('.');_0xb5d92e=_0xa4cc7a['substring'](0x0,_0x476a2d)['toLowerCase'](),_0x41b0ce=_0xa4cc7a['substring'](_0x476a2d+0x1),_0x2aba58=_0xb5d92e;}}'ns'in _0x1f8642&&(_0x2aba58=_0x1f8642['ns']);}return{'host':_0xa4cc7a,'port':_0x149044,'domain':_0x41b0ce,'subdomain':_0xb5d92e,'secure':_0x2fed64,'scheme':_0x521e55,'pathString':_0x48e9a3,'namespace':_0x2aba58};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x387687=0x0;const _0x463bfb=[];return function(_0x3148f8){const _0x104c7d=_0x3148f8===_0x387687;_0x387687=_0x3148f8;let _0x50a2b6;const _0x5c5ca1=new Array(0x8);for(_0x50a2b6=0x7;_0x50a2b6>=0x0;_0x50a2b6--)_0x5c5ca1[_0x50a2b6]=mr['charAt'](_0x3148f8%0x40),_0x3148f8=Math['floor'](_0x3148f8/0x40);f(_0x3148f8===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x17645e=_0x5c5ca1['join']('');if(_0x104c7d){for(_0x50a2b6=0xb;_0x50a2b6>=0x0&&_0x463bfb[_0x50a2b6]===0x3f;_0x50a2b6--)_0x463bfb[_0x50a2b6]=0x0;_0x463bfb[_0x50a2b6]++;}else{for(_0x50a2b6=0x0;_0x50a2b6<0xc;_0x50a2b6++)_0x463bfb[_0x50a2b6]=Math['floor'](Math['random']()*0x40);}for(_0x50a2b6=0x0;_0x50a2b6<0xc;_0x50a2b6++)_0x17645e+=mr['charAt'](_0x463bfb[_0x50a2b6]);return f(_0x17645e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x17645e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2c0c07,_0x28deb3,_0x4a9469,_0x1efa99){this['eventType']=_0x2c0c07,this['eventRegistration']=_0x28deb3,this['snapshot']=_0x4a9469,this['prevName']=_0x1efa99;}['getPath'](){const _0x5c729f=this['snapshot']['ref'];return this['eventType']==='value'?_0x5c729f['_path']:_0x5c729f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x5efc1e,_0x4f37df,_0x5c2b41){this['eventRegistration']=_0x5efc1e,this['error']=_0x4f37df,this['path']=_0x5c2b41;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x1ce9eb,_0x30181d){this['snapshotCallback']=_0x1ce9eb,this['cancelCallback']=_0x30181d;}['onValue'](_0x39deb6,_0xb5cfa1){this['snapshotCallback']['call'](null,_0x39deb6,_0xb5cfa1);}['onCancel'](_0x4047b4){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4047b4);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x42a9f8){return this['snapshotCallback']===_0x42a9f8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x42a9f8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x42a9f8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x380e0b,_0x14e68,_0x21dcca,_0x35736d){this['_repo']=_0x380e0b,this['_path']=_0x14e68,this['_queryParams']=_0x21dcca,this['_orderByCalled']=_0x35736d;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1b867d=nr(this['_queryParams']),_0x5de0bb=Bi(_0x1b867d);return _0x5de0bb==='{}'?'default':_0x5de0bb;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x409bd0){if(_0x409bd0=k(_0x409bd0),!(_0x409bd0 instanceof be))return!0x1;const _0x44102d=this['_repo']===_0x409bd0['_repo'],_0x504672=qi(this['_path'],_0x409bd0['_path']),_0x2ccdf2=this['_queryIdentifier']===_0x409bd0['_queryIdentifier'];return _0x44102d&&_0x504672&&_0x2ccdf2;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x29fbd4,_0x100ab5){if(_0x29fbd4['_orderByCalled']===!0x0)throw new Error(_0x100ab5+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x4efa20){let _0x35051d=null,_0x248a86=null;if(_0x4efa20['hasStart']()&&(_0x35051d=_0x4efa20['getIndexStartValue']()),_0x4efa20['hasEnd']()&&(_0x248a86=_0x4efa20['getIndexEndValue']()),_0x4efa20['getIndex']()===ye){const _0x2505e1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x34e74a='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4efa20['hasStart']()){if(_0x4efa20['getIndexStartName']()!==xe)throw new Error(_0x2505e1);if(typeof _0x35051d!='string')throw new Error(_0x34e74a);}if(_0x4efa20['hasEnd']()){if(_0x4efa20['getIndexEndName']()!==Ie)throw new Error(_0x2505e1);if(typeof _0x248a86!='string')throw new Error(_0x34e74a);}}else{if(_0x4efa20['getIndex']()===R){if(_0x35051d!=null&&!Cn(_0x35051d)||_0x248a86!=null&&!Cn(_0x248a86))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4efa20['getIndex']()instanceof Ki||_0x4efa20['getIndex']()===Po,'unknown\x20index\x20type.'),_0x35051d!=null&&typeof _0x35051d=='object'||_0x248a86!=null&&typeof _0x248a86=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x18404f){if(_0x18404f['hasStart']()&&_0x18404f['hasEnd']()&&_0x18404f['hasLimit']()&&!_0x18404f['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x3901c9,_0x4e1c4d){super(_0x3901c9,_0x4e1c4d,new Qi(),!0x1);}get['parent'](){const _0x90e4ef=To(this['_path']);return _0x90e4ef===null?null:new Z(this['_repo'],_0x90e4ef);}get['root'](){let _0x519db0=this;for(;_0x519db0['parent']!==null;)_0x519db0=_0x519db0['parent'];return _0x519db0;}}class rt{constructor(_0x7c5cea,_0x23c6ce,_0x30a3e1){this['_node']=_0x7c5cea,this['ref']=_0x23c6ce,this['_index']=_0x30a3e1;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x594fe3){const _0x31ce22=new C(_0x594fe3),_0x1c165d=Lt(this['ref'],_0x594fe3);return new rt(this['_node']['getChild'](_0x31ce22),_0x1c165d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x44454d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x867abf,_0x21c757)=>_0x44454d(new rt(_0x21c757,Lt(this['ref'],_0x867abf),R)));}['hasChild'](_0x54fdd6){const _0x1ae2e3=new C(_0x54fdd6);return!this['_node']['getChild'](_0x1ae2e3)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1554dd,_0x44dff2){return _0x1554dd=k(_0x1554dd),_0x1554dd['_checkNotDeleted']('ref'),_0x44dff2!==void 0x0?Lt(_0x1554dd['_root'],_0x44dff2):_0x1554dd['_root'];}function Lt(_0x485d4f,_0x427f76){return _0x485d4f=k(_0x485d4f),y(_0x485d4f['_path'])===null?ud('child','path',_0x427f76):_s('child','path',_0x427f76),new Z(_0x485d4f['_repo'],A(_0x485d4f['_path'],_0x427f76));}function d_(_0x4d3c64,_0x44cef0){_0x4d3c64=k(_0x4d3c64),gs('push',_0x4d3c64['_path']),qt('push',_0x44cef0,_0x4d3c64['_path'],!0x0);const _0x3f1619=oa(_0x4d3c64['_repo']),_0x5cf5fc=Od(_0x3f1619),_0x2ace6c=Lt(_0x4d3c64,_0x5cf5fc),_0x1d5612=Lt(_0x4d3c64,_0x5cf5fc);let _0x5162e0;return _0x44cef0!=null?_0x5162e0=Ld(_0x1d5612,_0x44cef0)['then'](()=>_0x1d5612):_0x5162e0=Promise['resolve'](_0x1d5612),_0x2ace6c['then']=_0x5162e0['then']['bind'](_0x5162e0),_0x2ace6c['catch']=_0x5162e0['then']['bind'](_0x5162e0,void 0x0),_0x2ace6c;}function Ld(_0x4a1ac4,_0x55eb0c){_0x4a1ac4=k(_0x4a1ac4),gs('set',_0x4a1ac4['_path']),qt('set',_0x55eb0c,_0x4a1ac4['_path'],!0x1);const _0x305eed=new Ve();return Ed(_0x4a1ac4['_repo'],_0x4a1ac4['_path'],_0x55eb0c,null,_0x305eed['wrapCallback'](()=>{})),_0x305eed['promise'];}function f_(_0x4e0054,_0x166e28){hd('update',_0x166e28,_0x4e0054['_path']);const _0x14f2f7=new Ve();return Id(_0x4e0054['_repo'],_0x4e0054['_path'],_0x166e28,_0x14f2f7['wrapCallback'](()=>{})),_0x14f2f7['promise'];}function p_(_0x15dadf){_0x15dadf=k(_0x15dadf);const _0xaaa123=new ua(()=>{}),_0x360d69=new qn(_0xaaa123);return vd(_0x15dadf['_repo'],_0x15dadf,_0x360d69)['then'](_0x11beb6=>new rt(_0x11beb6,new Z(_0x15dadf['_repo'],_0x15dadf['_path']),_0x15dadf['_queryParams']['getIndex']()));}class qn{constructor(_0x21c115){this['callbackContext']=_0x21c115;}['respondsTo'](_0x4e605c){return _0x4e605c==='value';}['createEvent'](_0x29530d,_0x5a7d4b){const _0x545cc8=_0x5a7d4b['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x29530d['snapshotNode'],new Z(_0x5a7d4b['_repo'],_0x5a7d4b['_path']),_0x545cc8));}['getEventRunner'](_0x426c97){return _0x426c97['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x426c97['error']):()=>this['callbackContext']['onValue'](_0x426c97['snapshot'],null);}['createCancelEvent'](_0x1d7aec,_0x168214){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x1d7aec,_0x168214):null;}['matches'](_0x638463){return _0x638463 instanceof qn?!_0x638463['callbackContext']||!this['callbackContext']?!0x0:_0x638463['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x293a58,_0x20845c,_0x557256,_0x4c3134,_0xc13dec){const _0x25ce8f=new ua(_0x557256,void 0x0),_0x2bba1c=new qn(_0x25ce8f);return Cd(_0x293a58['_repo'],_0x293a58,_0x2bba1c),()=>Td(_0x293a58['_repo'],_0x293a58,_0x2bba1c);}function Fd(_0x468459,_0x254a64,_0x19abad,_0x59f780){return xd(_0x468459,'value',_0x254a64);}class dt{}class pa extends dt{constructor(_0x3abec8,_0x121816){super(),this['_value']=_0x3abec8,this['_key']=_0x121816,this['type']='endAt';}['_apply'](_0x415c18){qt('endAt',this['_value'],_0x415c18['_path'],!0x0);const _0x253332=Kh(_0x415c18['_queryParams'],this['_value'],this['_key']);if(fa(_0x253332),Gn(_0x253332),_0x415c18['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x415c18['_repo'],_0x415c18['_path'],_0x253332,_0x415c18['_orderByCalled']);}}function __(_0x4d8a54,_0x3d0a5d){return new pa(_0x4d8a54,_0x3d0a5d);}class _a extends dt{constructor(_0x234519,_0x1a76a3){super(),this['_value']=_0x234519,this['_key']=_0x1a76a3,this['type']='startAt';}['_apply'](_0x384faa){qt('startAt',this['_value'],_0x384faa['_path'],!0x0);const _0x54b3c4=jh(_0x384faa['_queryParams'],this['_value'],this['_key']);if(fa(_0x54b3c4),Gn(_0x54b3c4),_0x384faa['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x384faa['_repo'],_0x384faa['_path'],_0x54b3c4,_0x384faa['_orderByCalled']);}}function g_(_0x23fc90=null,_0x5a8433){return new _a(_0x23fc90,_0x5a8433);}class Ud extends dt{constructor(_0x34f9d8){super(),this['_limit']=_0x34f9d8,this['type']='limitToFirst';}['_apply'](_0x4af149){if(_0x4af149['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x4af149['_repo'],_0x4af149['_path'],zh(_0x4af149['_queryParams'],this['_limit']),_0x4af149['_orderByCalled']);}}function m_(_0x1366ad){if(Math['floor'](_0x1366ad)!==_0x1366ad||_0x1366ad<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x1366ad);}class Wd extends dt{constructor(_0x216149){super(),this['_path']=_0x216149,this['type']='orderByChild';}['_apply'](_0x5511c9){da(_0x5511c9,'orderByChild');const _0x4c3b3c=new C(this['_path']);if(v(_0x4c3b3c))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x204c73=new Ki(_0x4c3b3c),_0x1c0ddc=Do(_0x5511c9['_queryParams'],_0x204c73);return Gn(_0x1c0ddc),new be(_0x5511c9['_repo'],_0x5511c9['_path'],_0x1c0ddc,!0x0);}}function y_(_0x3d44fd){if(_0x3d44fd==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3d44fd==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3d44fd==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x3d44fd),new Wd(_0x3d44fd);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x466ed9){da(_0x466ed9,'orderByKey');const _0x2596ad=Do(_0x466ed9['_queryParams'],ye);return Gn(_0x2596ad),new be(_0x466ed9['_repo'],_0x466ed9['_path'],_0x2596ad,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x42006f,_0x28c42f){super(),this['_value']=_0x42006f,this['_key']=_0x28c42f,this['type']='equalTo';}['_apply'](_0x3988c8){if(qt('equalTo',this['_value'],_0x3988c8['_path'],!0x1),_0x3988c8['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3988c8['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3988c8));}}function E_(_0x423668,_0x5371a7){return new Vd(_0x423668,_0x5371a7);}function I_(_0x584c91,..._0x366411){let _0x1542e2=k(_0x584c91);for(const _0xde5475 of _0x366411)_0x1542e2=_0xde5475['_apply'](_0x1542e2);return _0x1542e2;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x432308,_0x5941fe,_0x41b852,_0x55b9e2){const _0x4f419e=_0x5941fe['lastIndexOf'](':'),_0x46f74b=_0x5941fe['substring'](0x0,_0x4f419e),_0x3848df=Wt(_0x46f74b);_0x432308['repoInfo_']=new _o(_0x5941fe,_0x3848df,_0x432308['repoInfo_']['namespace'],_0x432308['repoInfo_']['webSocketOnly'],_0x432308['repoInfo_']['nodeAdmin'],_0x432308['repoInfo_']['persistenceKey'],_0x432308['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x41b852),_0x55b9e2&&(_0x432308['authTokenProvider_']=_0x55b9e2);}function qd(_0x3ba10d,_0xe14d4e,_0x500852,_0x5a9cc0,_0x3fa7ae){let _0x3b4e1d=_0x5a9cc0||_0x3ba10d['options']['databaseURL'];_0x3b4e1d===void 0x0&&(_0x3ba10d['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3ba10d['options']['projectId']),_0x3b4e1d=_0x3ba10d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x50719b=gr(_0x3b4e1d,_0x3fa7ae),_0x174a06=_0x50719b['repoInfo'],_0x42cdd2;typeof process<'u'&&Us&&(_0x42cdd2=Us[Hd]),_0x42cdd2?(_0x3b4e1d='http://'+_0x42cdd2+'?ns='+_0x174a06['namespace'],_0x50719b=gr(_0x3b4e1d,_0x3fa7ae),_0x174a06=_0x50719b['repoInfo']):_0x50719b['repoInfo']['secure'];const _0x38e684=new Jl(_0x3ba10d['name'],_0x3ba10d['options'],_0xe14d4e);dd('Invalid\x20Firebase\x20Database\x20URL',_0x50719b),v(_0x50719b['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x980146=jd(_0x174a06,_0x3ba10d,_0x38e684,new Ql(_0x3ba10d,_0x500852));return new Kd(_0x980146,_0x3ba10d);}function zd(_0x32b5e5,_0x180005){const _0x3d3870=ki[_0x180005];(!_0x3d3870||_0x3d3870[_0x32b5e5['key']]!==_0x32b5e5)&&oe('Database\x20'+_0x180005+'('+_0x32b5e5['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x32b5e5),delete _0x3d3870[_0x32b5e5['key']];}function jd(_0x2e626f,_0x31ad41,_0x59fd26,_0x3f9cfd){let _0x18f006=ki[_0x31ad41['name']];_0x18f006||(_0x18f006={},ki[_0x31ad41['name']]=_0x18f006);let _0x571432=_0x18f006[_0x2e626f['toURLString']()];return _0x571432&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x571432=new gd(_0x2e626f,$d,_0x59fd26,_0x3f9cfd),_0x18f006[_0x2e626f['toURLString']()]=_0x571432,_0x571432;}class Kd{constructor(_0x138aa6,_0x218d05){this['_repoInternal']=_0x138aa6,this['app']=_0x218d05,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x33bd0b){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x33bd0b+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1e176a=Qr(),_0x221a29){const _0x3b3810=Ui(_0x1e176a,'database')['getImmediate']({'identifier':_0x221a29});if(!_0x3b3810['_instanceStarted']){const _0x2fb4af=ac('database');_0x2fb4af&&Yd(_0x3b3810,..._0x2fb4af);}return _0x3b3810;}function Yd(_0x5e6e0e,_0x4c41dd,_0x1ca008,_0x295fbc={}){_0x5e6e0e=k(_0x5e6e0e),_0x5e6e0e['_checkNotDeleted']('useEmulator');const _0x1d5d2e=_0x4c41dd+':'+_0x1ca008,_0x1d59c2=_0x5e6e0e['_repoInternal'];if(_0x5e6e0e['_instanceStarted']){if(_0x1d5d2e===_0x5e6e0e['_repoInternal']['repoInfo_']['host']&&De(_0x295fbc,_0x1d59c2['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x37f52a;if(_0x1d59c2['repoInfo_']['nodeAdmin'])_0x295fbc['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x37f52a=new tn(tn['OWNER']);else{if(_0x295fbc['mockUserToken']){const _0x54f521=typeof _0x295fbc['mockUserToken']=='string'?_0x295fbc['mockUserToken']:cc(_0x295fbc['mockUserToken'],_0x5e6e0e['app']['options']['projectId']);_0x37f52a=new tn(_0x54f521);}}Wt(_0x4c41dd)&&jr(_0x4c41dd),Gd(_0x1d59c2,_0x1d5d2e,_0x295fbc,_0x37f52a);}function C_(_0x4eb136){_0x4eb136=k(_0x4eb136),_0x4eb136['_checkNotDeleted']('goOffline'),aa(_0x4eb136['_repo']);}function T_(_0x2c9b1d){_0x2c9b1d=k(_0x2c9b1d),_0x2c9b1d['_checkNotDeleted']('goOnline'),Sd(_0x2c9b1d['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x3d2dec){Ll(ct),et(new Me('database',(_0x2ad122,{instanceIdentifier:_0x3f2c27})=>{const _0x16b55b=_0x2ad122['getProvider']('app')['getImmediate'](),_0xb3821c=_0x2ad122['getProvider']('auth-internal'),_0xa05574=_0x2ad122['getProvider']('app-check-internal');return qd(_0x16b55b,_0xb3821c,_0xa05574,_0x3f2c27);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x3d2dec),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x4455a4,_0x30ca5e){this['committed']=_0x4455a4,this['snapshot']=_0x30ca5e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x53e060,_0x4490cb,_0x40e9f3){if(_0x53e060=k(_0x53e060),gs('Reference.transaction',_0x53e060['_path']),_0x53e060['key']==='.length'||_0x53e060['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x53e060['key']+'\x20is\x20a\x20read-only\x20object.';const _0x39819e=!0x0,_0x5b88ff=new Ve(),_0x2ae05d=(_0x45775f,_0x5cbac1,_0x50e838)=>{let _0x984a2d=null;_0x45775f?_0x5b88ff['reject'](_0x45775f):(_0x984a2d=new rt(_0x50e838,new Z(_0x53e060['_repo'],_0x53e060['_path']),R),_0x5b88ff['resolve'](new Xd(_0x5cbac1,_0x984a2d)));},_0x2e7e63=Fd(_0x53e060,()=>{});return bd(_0x53e060['_repo'],_0x53e060['_path'],_0x4490cb,_0x2ae05d,_0x2e7e63,_0x39819e),_0x5b88ff['promise'];}ie['prototype']['simpleListen']=function(_0x1d3e5b,_0x5572c3){this['sendRequest']('q',{'p':_0x1d3e5b},_0x5572c3);},ie['prototype']['echo']=function(_0x5466a0,_0x35fd93){this['sendRequest']('echo',{'d':_0x5466a0},_0x35fd93);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x561322,..._0x273403){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x561322,..._0x273403);}function nn(_0xc1245f,..._0x23ac00){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0xc1245f,..._0x23ac00);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x4e8a63,..._0x5590ea){throw Es(_0x4e8a63,..._0x5590ea);}function J(_0x2e7ac7,..._0x1e9fe2){return Es(_0x2e7ac7,..._0x1e9fe2);}function ya(_0x2f2e91,_0x24b8dc,_0x288f1f){const _0x3e49a0={...Zd(),[_0x24b8dc]:_0x288f1f};return new Ut('auth','Firebase',_0x3e49a0)['create'](_0x24b8dc,{'appName':_0x2f2e91['name']});}function se(_0x4b9335){return ya(_0x4b9335,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x2fc7ce,..._0x24ac03){if(typeof _0x2fc7ce!='string'){const _0x415e36=_0x24ac03[0x0],_0x45e469=[..._0x24ac03['slice'](0x1)];return _0x45e469[0x0]&&(_0x45e469[0x0]['appName']=_0x2fc7ce['name']),_0x2fc7ce['_errorFactory']['create'](_0x415e36,..._0x45e469);}return ma['create'](_0x2fc7ce,..._0x24ac03);}function m(_0x44411a,_0x2dd1a0,..._0xd79f4b){if(!_0x44411a)throw Es(_0x2dd1a0,..._0xd79f4b);}function te(_0x4ad1e6){const _0x9712d9='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4ad1e6;throw nn(_0x9712d9),new Error(_0x9712d9);}function ae(_0x43ab3f,_0x24ab75){_0x43ab3f||te(_0x24ab75);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x118c63;return typeof self<'u'&&((_0x118c63=self['location'])==null?void 0x0:_0x118c63['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5e43ff;return typeof self<'u'&&((_0x5e43ff=self['location'])==null?void 0x0:_0x5e43ff['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x4e513d=navigator;return _0x4e513d['languages']&&_0x4e513d['languages'][0x0]||_0x4e513d['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x21d3ba,_0x3029f1){this['shortDelay']=_0x21d3ba,this['longDelay']=_0x3029f1,ae(_0x3029f1>_0x21d3ba,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x2c3c32,_0x39c94a){ae(_0x2c3c32['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x47f8f0}=_0x2c3c32['emulator'];return _0x39c94a?''+_0x47f8f0+(_0x39c94a['startsWith']('/')?_0x39c94a['slice'](0x1):_0x39c94a):_0x47f8f0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0xbccd3e,_0x401dde,_0x479f4a){this['fetchImpl']=_0xbccd3e,_0x401dde&&(this['headersImpl']=_0x401dde),_0x479f4a&&(this['responseImpl']=_0x479f4a);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x355ddd,_0xa9411c){return _0x355ddd['tenantId']&&!_0xa9411c['tenantId']?{..._0xa9411c,'tenantId':_0x355ddd['tenantId']}:_0xa9411c;}async function Ae(_0x267f1f,_0x391a16,_0x1cbbc0,_0x55b4e8,_0x183910={}){return Ea(_0x267f1f,_0x183910,async()=>{let _0x4a61f9={},_0x567e22={};_0x55b4e8&&(_0x391a16==='GET'?_0x567e22=_0x55b4e8:_0x4a61f9={'body':JSON['stringify'](_0x55b4e8)});const _0x124b24=at({..._0x567e22,'key':_0x267f1f['config']['apiKey']})['slice'](0x1),_0x275940=await _0x267f1f['_getAdditionalHeaders']();_0x275940['Content-Type']='application/json',_0x267f1f['languageCode']&&(_0x275940['X-Firebase-Locale']=_0x267f1f['languageCode']);const _0x15bbf7={'method':_0x391a16,'headers':_0x275940,..._0x4a61f9};return lc()||(_0x15bbf7['referrerPolicy']='strict-origin-when-cross-origin'),_0x267f1f['emulatorConfig']&&Wt(_0x267f1f['emulatorConfig']['host'])&&(_0x15bbf7['credentials']='include'),va['fetch']()(await Ia(_0x267f1f,_0x267f1f['config']['apiHost'],_0x1cbbc0,_0x124b24),_0x15bbf7);});}async function Ea(_0xa42ec5,_0x5cf399,_0x122479){_0xa42ec5['_canInitEmulator']=!0x1;const _0x7d9e77={...rf,..._0x5cf399};try{const _0x35638f=new lf(_0xa42ec5),_0x574357=await Promise['race']([_0x122479(),_0x35638f['promise']]);_0x35638f['clearNetworkTimeout']();const _0x592af3=await _0x574357['json']();if('needConfirmation'in _0x592af3)throw en(_0xa42ec5,'account-exists-with-different-credential',_0x592af3);if(_0x574357['ok']&&!('errorMessage'in _0x592af3))return _0x592af3;{const _0x305113=_0x574357['ok']?_0x592af3['errorMessage']:_0x592af3['error']['message'],[_0x271b98,_0x310535]=_0x305113['split']('\x20:\x20');if(_0x271b98==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0xa42ec5,'credential-already-in-use',_0x592af3);if(_0x271b98==='EMAIL_EXISTS')throw en(_0xa42ec5,'email-already-in-use',_0x592af3);if(_0x271b98==='USER_DISABLED')throw en(_0xa42ec5,'user-disabled',_0x592af3);const _0x2eecdb=_0x7d9e77[_0x271b98]||_0x271b98['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x310535)throw ya(_0xa42ec5,_0x2eecdb,_0x310535);K(_0xa42ec5,_0x2eecdb);}}catch(_0x50ad57){if(_0x50ad57 instanceof Se)throw _0x50ad57;K(_0xa42ec5,'network-request-failed',{'message':String(_0x50ad57)});}}async function Yt(_0x14f6cb,_0x1278b6,_0x191aa8,_0x5cc064,_0x45def3={}){const _0x3726ca=await Ae(_0x14f6cb,_0x1278b6,_0x191aa8,_0x5cc064,_0x45def3);return'mfaPendingCredential'in _0x3726ca&&K(_0x14f6cb,'multi-factor-auth-required',{'_serverResponse':_0x3726ca}),_0x3726ca;}async function Ia(_0x126e28,_0x26b5dc,_0x4ceb7d,_0x6aabda){const _0x101ac8=''+_0x26b5dc+_0x4ceb7d+'?'+_0x6aabda,_0x4b40b6=_0x126e28,_0x103c5d=_0x4b40b6['config']['emulator']?Is(_0x126e28['config'],_0x101ac8):_0x126e28['config']['apiScheme']+'://'+_0x101ac8;return of['includes'](_0x4ceb7d)&&(await _0x4b40b6['_persistenceManagerAvailable'],_0x4b40b6['_getPersistenceType']()==='COOKIE')?_0x4b40b6['_getPersistence']()['_getFinalTarget'](_0x103c5d)['toString']():_0x103c5d;}function cf(_0x11804e){switch(_0x11804e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x377ac1){this['auth']=_0x377ac1,this['timer']=null,this['promise']=new Promise((_0x4bb536,_0x333775)=>{this['timer']=setTimeout(()=>_0x333775(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1c53dc,_0x3d6e2b,_0x54f6cd){const _0x148d16={'appName':_0x1c53dc['name']};_0x54f6cd['email']&&(_0x148d16['email']=_0x54f6cd['email']),_0x54f6cd['phoneNumber']&&(_0x148d16['phoneNumber']=_0x54f6cd['phoneNumber']);const _0x5e5b07=J(_0x1c53dc,_0x3d6e2b,_0x148d16);return _0x5e5b07['customData']['_tokenResponse']=_0x54f6cd,_0x5e5b07;}function vr(_0x2124f4){return _0x2124f4!==void 0x0&&_0x2124f4['enterprise']!==void 0x0;}class hf{constructor(_0x168814){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x168814['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x168814['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x168814['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1bed4c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xdd3bbe of this['recaptchaEnforcementState'])if(_0xdd3bbe['provider']&&_0xdd3bbe['provider']===_0x1bed4c)return cf(_0xdd3bbe['enforcementState']);return null;}['isProviderEnabled'](_0x454b2e){return this['getProviderEnforcementState'](_0x454b2e)==='ENFORCE'||this['getProviderEnforcementState'](_0x454b2e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x561bf1,_0x4f1fef){return Ae(_0x561bf1,'GET','/v2/recaptchaConfig',Re(_0x561bf1,_0x4f1fef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4a20f8,_0x32fa69){return Ae(_0x4a20f8,'POST','/v1/accounts:delete',_0x32fa69);}async function Sn(_0x542242,_0x14d73a){return Ae(_0x542242,'POST','/v1/accounts:lookup',_0x14d73a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x467cff){if(_0x467cff)try{const _0x3e3043=new Date(Number(_0x467cff));if(!isNaN(_0x3e3043['getTime']()))return _0x3e3043['toUTCString']();}catch{}}async function ff(_0x4a79d3,_0x13d65b=!0x1){const _0x4215fc=k(_0x4a79d3),_0x41f6a1=await _0x4215fc['getIdToken'](_0x13d65b),_0x2353d8=ws(_0x41f6a1);m(_0x2353d8&&_0x2353d8['exp']&&_0x2353d8['auth_time']&&_0x2353d8['iat'],_0x4215fc['auth'],'internal-error');const _0x1acd07=typeof _0x2353d8['firebase']=='object'?_0x2353d8['firebase']:void 0x0,_0x8ec387=_0x1acd07==null?void 0x0:_0x1acd07['sign_in_provider'];return{'claims':_0x2353d8,'token':_0x41f6a1,'authTime':St(ci(_0x2353d8['auth_time'])),'issuedAtTime':St(ci(_0x2353d8['iat'])),'expirationTime':St(ci(_0x2353d8['exp'])),'signInProvider':_0x8ec387||null,'signInSecondFactor':(_0x1acd07==null?void 0x0:_0x1acd07['sign_in_second_factor'])||null};}function ci(_0x4883fb){return Number(_0x4883fb)*0x3e8;}function ws(_0x20445d){const [_0x6c8f1c,_0x21b50d,_0x295306]=_0x20445d['split']('.');if(_0x6c8f1c===void 0x0||_0x21b50d===void 0x0||_0x295306===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x34b81a=cn(_0x21b50d);return _0x34b81a?JSON['parse'](_0x34b81a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x129b37){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x129b37==null?void 0x0:_0x129b37['toString']()),null;}}function Er(_0x59f5b2){const _0x3b2bf8=ws(_0x59f5b2);return m(_0x3b2bf8,'internal-error'),m(typeof _0x3b2bf8['exp']<'u','internal-error'),m(typeof _0x3b2bf8['iat']<'u','internal-error'),Number(_0x3b2bf8['exp'])-Number(_0x3b2bf8['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x5fbc93,_0x7ab3e,_0x6af424=!0x1){if(_0x6af424)return _0x7ab3e;try{return await _0x7ab3e;}catch(_0x2fe197){throw _0x2fe197 instanceof Se&&pf(_0x2fe197)&&_0x5fbc93['auth']['currentUser']===_0x5fbc93&&await _0x5fbc93['auth']['signOut'](),_0x2fe197;}}function pf({code:_0xccb2ed}){return _0xccb2ed==='auth/user-disabled'||_0xccb2ed==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x53e2b4){this['user']=_0x53e2b4,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2f38ac){if(_0x2f38ac){const _0x4ffa89=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4ffa89;}else{this['errorBackoff']=0x7530;const _0x59a02b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x59a02b);}}['schedule'](_0x3e763f=!0x1){if(!this['isRunning'])return;const _0x109182=this['getInterval'](_0x3e763f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x109182);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1c1571){(_0x1c1571==null?void 0x0:_0x1c1571['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x2a5e61,_0x4bbfe6){this['createdAt']=_0x2a5e61,this['lastLoginAt']=_0x4bbfe6,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0xa8128){this['createdAt']=_0xa8128['createdAt'],this['lastLoginAt']=_0xa8128['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x388796){var _0x5465a0;const _0x28b423=_0x388796['auth'],_0x53a0d9=await _0x388796['getIdToken'](),_0x42fe47=await xt(_0x388796,Sn(_0x28b423,{'idToken':_0x53a0d9}));m(_0x42fe47==null?void 0x0:_0x42fe47['users']['length'],_0x28b423,'internal-error');const _0x445130=_0x42fe47['users'][0x0];_0x388796['_notifyReloadListener'](_0x445130);const _0x225c30=(_0x5465a0=_0x445130['providerUserInfo'])!=null&&_0x5465a0['length']?wa(_0x445130['providerUserInfo']):[],_0x1be4fb=mf(_0x388796['providerData'],_0x225c30),_0x269561=_0x388796['isAnonymous'],_0x2a30c2=!(_0x388796['email']&&_0x445130['passwordHash'])&&!(_0x1be4fb!=null&&_0x1be4fb['length']),_0x24968a=_0x269561?_0x2a30c2:!0x1,_0x55ccc7={'uid':_0x445130['localId'],'displayName':_0x445130['displayName']||null,'photoURL':_0x445130['photoUrl']||null,'email':_0x445130['email']||null,'emailVerified':_0x445130['emailVerified']||!0x1,'phoneNumber':_0x445130['phoneNumber']||null,'tenantId':_0x445130['tenantId']||null,'providerData':_0x1be4fb,'metadata':new Pi(_0x445130['createdAt'],_0x445130['lastLoginAt']),'isAnonymous':_0x24968a};Object['assign'](_0x388796,_0x55ccc7);}async function gf(_0x4e8140){const _0x413000=k(_0x4e8140);await bn(_0x413000),await _0x413000['auth']['_persistUserIfCurrent'](_0x413000),_0x413000['auth']['_notifyListenersIfCurrent'](_0x413000);}function mf(_0x6775de,_0x5f287b){return[..._0x6775de['filter'](_0x55f3fd=>!_0x5f287b['some'](_0x3be8f9=>_0x3be8f9['providerId']===_0x55f3fd['providerId'])),..._0x5f287b];}function wa(_0x105061){return _0x105061['map'](({providerId:_0xbedb91,..._0x90aa37})=>({'providerId':_0xbedb91,'uid':_0x90aa37['rawId']||'','displayName':_0x90aa37['displayName']||null,'email':_0x90aa37['email']||null,'phoneNumber':_0x90aa37['phoneNumber']||null,'photoURL':_0x90aa37['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x2a97fa,_0x3f2c40){const _0x3fc5d7=await Ea(_0x2a97fa,{},async()=>{const _0x26455c=at({'grant_type':'refresh_token','refresh_token':_0x3f2c40})['slice'](0x1),{tokenApiHost:_0x5daf52,apiKey:_0x5f2526}=_0x2a97fa['config'],_0x233396=await Ia(_0x2a97fa,_0x5daf52,'/v1/token','key='+_0x5f2526),_0x1cfb15=await _0x2a97fa['_getAdditionalHeaders']();_0x1cfb15['Content-Type']='application/x-www-form-urlencoded';const _0x2447a0={'method':'POST','headers':_0x1cfb15,'body':_0x26455c};return _0x2a97fa['emulatorConfig']&&Wt(_0x2a97fa['emulatorConfig']['host'])&&(_0x2447a0['credentials']='include'),va['fetch']()(_0x233396,_0x2447a0);});return{'accessToken':_0x3fc5d7['access_token'],'expiresIn':_0x3fc5d7['expires_in'],'refreshToken':_0x3fc5d7['refresh_token']};}async function vf(_0x33374e,_0x2c6b3f){return Ae(_0x33374e,'POST','/v2/accounts:revokeToken',Re(_0x33374e,_0x2c6b3f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x19a178){m(_0x19a178['idToken'],'internal-error'),m(typeof _0x19a178['idToken']<'u','internal-error'),m(typeof _0x19a178['refreshToken']<'u','internal-error');const _0x3f1e3e='expiresIn'in _0x19a178&&typeof _0x19a178['expiresIn']<'u'?Number(_0x19a178['expiresIn']):Er(_0x19a178['idToken']);this['updateTokensAndExpiration'](_0x19a178['idToken'],_0x19a178['refreshToken'],_0x3f1e3e);}['updateFromIdToken'](_0x54ceb1){m(_0x54ceb1['length']!==0x0,'internal-error');const _0x792662=Er(_0x54ceb1);this['updateTokensAndExpiration'](_0x54ceb1,null,_0x792662);}async['getToken'](_0x4222f1,_0x3d6458=!0x1){return!_0x3d6458&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4222f1,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4222f1,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5d8a01,_0x3f5711){const {accessToken:_0x476b31,refreshToken:_0x21a569,expiresIn:_0x93934b}=await yf(_0x5d8a01,_0x3f5711);this['updateTokensAndExpiration'](_0x476b31,_0x21a569,Number(_0x93934b));}['updateTokensAndExpiration'](_0x46ad55,_0x3af1b4,_0x9aee78){this['refreshToken']=_0x3af1b4||null,this['accessToken']=_0x46ad55||null,this['expirationTime']=Date['now']()+_0x9aee78*0x3e8;}static['fromJSON'](_0x1a1d24,_0x3e4b5c){const {refreshToken:_0x1fbc03,accessToken:_0x4b4d77,expirationTime:_0x4eea24}=_0x3e4b5c,_0xd0ac26=new Je();return _0x1fbc03&&(m(typeof _0x1fbc03=='string','internal-error',{'appName':_0x1a1d24}),_0xd0ac26['refreshToken']=_0x1fbc03),_0x4b4d77&&(m(typeof _0x4b4d77=='string','internal-error',{'appName':_0x1a1d24}),_0xd0ac26['accessToken']=_0x4b4d77),_0x4eea24&&(m(typeof _0x4eea24=='number','internal-error',{'appName':_0x1a1d24}),_0xd0ac26['expirationTime']=_0x4eea24),_0xd0ac26;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x24026b){this['accessToken']=_0x24026b['accessToken'],this['refreshToken']=_0x24026b['refreshToken'],this['expirationTime']=_0x24026b['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x55ee05,_0x466710){m(typeof _0x55ee05=='string'||typeof _0x55ee05>'u','internal-error',{'appName':_0x466710});}class z{constructor({uid:_0x1f4ec6,auth:_0x160334,stsTokenManager:_0x1ac331,..._0x273b83}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1f4ec6,this['auth']=_0x160334,this['stsTokenManager']=_0x1ac331,this['accessToken']=_0x1ac331['accessToken'],this['displayName']=_0x273b83['displayName']||null,this['email']=_0x273b83['email']||null,this['emailVerified']=_0x273b83['emailVerified']||!0x1,this['phoneNumber']=_0x273b83['phoneNumber']||null,this['photoURL']=_0x273b83['photoURL']||null,this['isAnonymous']=_0x273b83['isAnonymous']||!0x1,this['tenantId']=_0x273b83['tenantId']||null,this['providerData']=_0x273b83['providerData']?[..._0x273b83['providerData']]:[],this['metadata']=new Pi(_0x273b83['createdAt']||void 0x0,_0x273b83['lastLoginAt']||void 0x0);}async['getIdToken'](_0x44cd55){const _0x2a91ff=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x44cd55));return m(_0x2a91ff,this['auth'],'internal-error'),this['accessToken']!==_0x2a91ff&&(this['accessToken']=_0x2a91ff,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2a91ff;}['getIdTokenResult'](_0xeec633){return ff(this,_0xeec633);}['reload'](){return gf(this);}['_assign'](_0x71c72b){this!==_0x71c72b&&(m(this['uid']===_0x71c72b['uid'],this['auth'],'internal-error'),this['displayName']=_0x71c72b['displayName'],this['photoURL']=_0x71c72b['photoURL'],this['email']=_0x71c72b['email'],this['emailVerified']=_0x71c72b['emailVerified'],this['phoneNumber']=_0x71c72b['phoneNumber'],this['isAnonymous']=_0x71c72b['isAnonymous'],this['tenantId']=_0x71c72b['tenantId'],this['providerData']=_0x71c72b['providerData']['map'](_0x4a50e7=>({..._0x4a50e7})),this['metadata']['_copy'](_0x71c72b['metadata']),this['stsTokenManager']['_assign'](_0x71c72b['stsTokenManager']));}['_clone'](_0x2fa2eb){const _0x4b97e1=new z({...this,'auth':_0x2fa2eb,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4b97e1['metadata']['_copy'](this['metadata']),_0x4b97e1;}['_onReload'](_0x2acc28){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2acc28,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1c462f){this['reloadListener']?this['reloadListener'](_0x1c462f):this['reloadUserInfo']=_0x1c462f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x144467,_0xae569=!0x1){let _0x1ec8e3=!0x1;_0x144467['idToken']&&_0x144467['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x144467),_0x1ec8e3=!0x0),_0xae569&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1ec8e3&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0xea5995=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0xea5995})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2279b9=>({..._0x2279b9})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x43b5a8,_0x4dd507){const _0x5cb57b=_0x4dd507['displayName']??void 0x0,_0x217fca=_0x4dd507['email']??void 0x0,_0x2e5149=_0x4dd507['phoneNumber']??void 0x0,_0x4ab4d1=_0x4dd507['photoURL']??void 0x0,_0x47c013=_0x4dd507['tenantId']??void 0x0,_0x376a5d=_0x4dd507['_redirectEventId']??void 0x0,_0x450901=_0x4dd507['createdAt']??void 0x0,_0x8e841e=_0x4dd507['lastLoginAt']??void 0x0,{uid:_0x4bef00,emailVerified:_0x61ae0,isAnonymous:_0x221c2d,providerData:_0x445e8e,stsTokenManager:_0xa1f604}=_0x4dd507;m(_0x4bef00&&_0xa1f604,_0x43b5a8,'internal-error');const _0x1c5885=Je['fromJSON'](this['name'],_0xa1f604);m(typeof _0x4bef00=='string',_0x43b5a8,'internal-error'),ce(_0x5cb57b,_0x43b5a8['name']),ce(_0x217fca,_0x43b5a8['name']),m(typeof _0x61ae0=='boolean',_0x43b5a8,'internal-error'),m(typeof _0x221c2d=='boolean',_0x43b5a8,'internal-error'),ce(_0x2e5149,_0x43b5a8['name']),ce(_0x4ab4d1,_0x43b5a8['name']),ce(_0x47c013,_0x43b5a8['name']),ce(_0x376a5d,_0x43b5a8['name']),ce(_0x450901,_0x43b5a8['name']),ce(_0x8e841e,_0x43b5a8['name']);const _0x2682ed=new z({'uid':_0x4bef00,'auth':_0x43b5a8,'email':_0x217fca,'emailVerified':_0x61ae0,'displayName':_0x5cb57b,'isAnonymous':_0x221c2d,'photoURL':_0x4ab4d1,'phoneNumber':_0x2e5149,'tenantId':_0x47c013,'stsTokenManager':_0x1c5885,'createdAt':_0x450901,'lastLoginAt':_0x8e841e});return _0x445e8e&&Array['isArray'](_0x445e8e)&&(_0x2682ed['providerData']=_0x445e8e['map'](_0x24619d=>({..._0x24619d}))),_0x376a5d&&(_0x2682ed['_redirectEventId']=_0x376a5d),_0x2682ed;}static async['_fromIdTokenResponse'](_0x32efe6,_0x5e4ad3,_0x480b13=!0x1){const _0x42c09b=new Je();_0x42c09b['updateFromServerResponse'](_0x5e4ad3);const _0x1fee32=new z({'uid':_0x5e4ad3['localId'],'auth':_0x32efe6,'stsTokenManager':_0x42c09b,'isAnonymous':_0x480b13});return await bn(_0x1fee32),_0x1fee32;}static async['_fromGetAccountInfoResponse'](_0x3c2fe8,_0xe750c,_0x9f4e36){const _0x44df6f=_0xe750c['users'][0x0];m(_0x44df6f['localId']!==void 0x0,'internal-error');const _0x1d5a0e=_0x44df6f['providerUserInfo']!==void 0x0?wa(_0x44df6f['providerUserInfo']):[],_0xdfde8a=!(_0x44df6f['email']&&_0x44df6f['passwordHash'])&&!(_0x1d5a0e!=null&&_0x1d5a0e['length']),_0x3993b8=new Je();_0x3993b8['updateFromIdToken'](_0x9f4e36);const _0x2840da=new z({'uid':_0x44df6f['localId'],'auth':_0x3c2fe8,'stsTokenManager':_0x3993b8,'isAnonymous':_0xdfde8a}),_0x5ccdcb={'uid':_0x44df6f['localId'],'displayName':_0x44df6f['displayName']||null,'photoURL':_0x44df6f['photoUrl']||null,'email':_0x44df6f['email']||null,'emailVerified':_0x44df6f['emailVerified']||!0x1,'phoneNumber':_0x44df6f['phoneNumber']||null,'tenantId':_0x44df6f['tenantId']||null,'providerData':_0x1d5a0e,'metadata':new Pi(_0x44df6f['createdAt'],_0x44df6f['lastLoginAt']),'isAnonymous':!(_0x44df6f['email']&&_0x44df6f['passwordHash'])&&!(_0x1d5a0e!=null&&_0x1d5a0e['length'])};return Object['assign'](_0x2840da,_0x5ccdcb),_0x2840da;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x23fc6c){ae(_0x23fc6c instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3ef17f=Ir['get'](_0x23fc6c);return _0x3ef17f?(ae(_0x3ef17f instanceof _0x23fc6c,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3ef17f):(_0x3ef17f=new _0x23fc6c(),Ir['set'](_0x23fc6c,_0x3ef17f),_0x3ef17f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3f1036,_0x387889){this['storage'][_0x3f1036]=_0x387889;}async['_get'](_0x551690){const _0x281ffe=this['storage'][_0x551690];return _0x281ffe===void 0x0?null:_0x281ffe;}async['_remove'](_0x312761){delete this['storage'][_0x312761];}['_addListener'](_0x6cc0df,_0x16cb25){}['_removeListener'](_0x5b16fb,_0x4d5343){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3bdee0,_0x40fd70,_0xe82981){return'firebase:'+_0x3bdee0+':'+_0x40fd70+':'+_0xe82981;}class Xe{constructor(_0x261b50,_0x5c7659,_0x1785e4){this['persistence']=_0x261b50,this['auth']=_0x5c7659,this['userKey']=_0x1785e4;const {config:_0x1420de,name:_0x312527}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1420de['apiKey'],_0x312527),this['fullPersistenceKey']=sn('persistence',_0x1420de['apiKey'],_0x312527),this['boundEventHandler']=_0x5c7659['_onStorageEvent']['bind'](_0x5c7659),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x46c439){return this['persistence']['_set'](this['fullUserKey'],_0x46c439['toJSON']());}async['getCurrentUser'](){const _0x2799f5=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2799f5)return null;if(typeof _0x2799f5=='string'){const _0x39039c=await Sn(this['auth'],{'idToken':_0x2799f5})['catch'](()=>{});return _0x39039c?z['_fromGetAccountInfoResponse'](this['auth'],_0x39039c,_0x2799f5):null;}return z['_fromJSON'](this['auth'],_0x2799f5);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x155331){if(this['persistence']===_0x155331)return;const _0x10266a=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x155331,_0x10266a)return this['setCurrentUser'](_0x10266a);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2c3254,_0x3ea776,_0x40c7f8='authUser'){if(!_0x3ea776['length'])return new Xe(ne(wr),_0x2c3254,_0x40c7f8);const _0x1c646a=(await Promise['all'](_0x3ea776['map'](async _0x586df1=>{if(await _0x586df1['_isAvailable']())return _0x586df1;})))['filter'](_0x3fa521=>_0x3fa521);let _0x5aaace=_0x1c646a[0x0]||ne(wr);const _0x8ad834=sn(_0x40c7f8,_0x2c3254['config']['apiKey'],_0x2c3254['name']);let _0x37b161=null;for(const _0x929262 of _0x3ea776)try{const _0x333815=await _0x929262['_get'](_0x8ad834);if(_0x333815){let _0x551101;if(typeof _0x333815=='string'){const _0x418ab9=await Sn(_0x2c3254,{'idToken':_0x333815})['catch'](()=>{});if(!_0x418ab9)break;_0x551101=await z['_fromGetAccountInfoResponse'](_0x2c3254,_0x418ab9,_0x333815);}else _0x551101=z['_fromJSON'](_0x2c3254,_0x333815);_0x929262!==_0x5aaace&&(_0x37b161=_0x551101),_0x5aaace=_0x929262;break;}}catch{}const _0x868038=_0x1c646a['filter'](_0x50738f=>_0x50738f['_shouldAllowMigration']);return!_0x5aaace['_shouldAllowMigration']||!_0x868038['length']?new Xe(_0x5aaace,_0x2c3254,_0x40c7f8):(_0x5aaace=_0x868038[0x0],_0x37b161&&await _0x5aaace['_set'](_0x8ad834,_0x37b161['toJSON']()),await Promise['all'](_0x3ea776['map'](async _0xbd468d=>{if(_0xbd468d!==_0x5aaace)try{await _0xbd468d['_remove'](_0x8ad834);}catch{}})),new Xe(_0x5aaace,_0x2c3254,_0x40c7f8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x13d246){const _0x193ab=_0x13d246['toLowerCase']();if(_0x193ab['includes']('opera/')||_0x193ab['includes']('opr/')||_0x193ab['includes']('opios/'))return'Opera';if(Ra(_0x193ab))return'IEMobile';if(_0x193ab['includes']('msie')||_0x193ab['includes']('trident/'))return'IE';if(_0x193ab['includes']('edge/'))return'Edge';if(Ta(_0x193ab))return'Firefox';if(_0x193ab['includes']('silk/'))return'Silk';if(ka(_0x193ab))return'Blackberry';if(Na(_0x193ab))return'Webos';if(Sa(_0x193ab))return'Safari';if((_0x193ab['includes']('chrome/')||ba(_0x193ab))&&!_0x193ab['includes']('edge/'))return'Chrome';if(Aa(_0x193ab))return'Android';{const _0x240399=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xaae994=_0x13d246['match'](_0x240399);if((_0xaae994==null?void 0x0:_0xaae994['length'])===0x2)return _0xaae994[0x1];}return'Other';}function Ta(_0xab7aeb=W()){return/firefox\//i['test'](_0xab7aeb);}function Sa(_0x1a869b=W()){const _0x9905c2=_0x1a869b['toLowerCase']();return _0x9905c2['includes']('safari/')&&!_0x9905c2['includes']('chrome/')&&!_0x9905c2['includes']('crios/')&&!_0x9905c2['includes']('android');}function ba(_0x49690e=W()){return/crios\//i['test'](_0x49690e);}function Ra(_0x376cab=W()){return/iemobile/i['test'](_0x376cab);}function Aa(_0x11ccf5=W()){return/android/i['test'](_0x11ccf5);}function ka(_0x4cfb1f=W()){return/blackberry/i['test'](_0x4cfb1f);}function Na(_0x39b2fe=W()){return/webos/i['test'](_0x39b2fe);}function Cs(_0x3fcce1=W()){return/iphone|ipad|ipod/i['test'](_0x3fcce1)||/macintosh/i['test'](_0x3fcce1)&&/mobile/i['test'](_0x3fcce1);}function Ef(_0x2e5d03=W()){var _0x544753;return Cs(_0x2e5d03)&&!!((_0x544753=window['navigator'])!=null&&_0x544753['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x568834=W()){return Cs(_0x568834)||Aa(_0x568834)||Na(_0x568834)||ka(_0x568834)||/windows phone/i['test'](_0x568834)||Ra(_0x568834);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x250531,_0x38e400=[]){let _0x4f818e;switch(_0x250531){case'Browser':_0x4f818e=Cr(W());break;case'Worker':_0x4f818e=Cr(W())+'-'+_0x250531;break;default:_0x4f818e=_0x250531;}const _0x3363ff=_0x38e400['length']?_0x38e400['join'](','):'FirebaseCore-web';return _0x4f818e+'/JsCore/'+ct+'/'+_0x3363ff;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2cf253){this['auth']=_0x2cf253,this['queue']=[];}['pushCallback'](_0x3af10c,_0x4e4be4){const _0x3fecb2=_0x314772=>new Promise((_0x235afd,_0x5e9063)=>{try{const _0x42aac1=_0x3af10c(_0x314772);_0x235afd(_0x42aac1);}catch(_0xb6eaf1){_0x5e9063(_0xb6eaf1);}});_0x3fecb2['onAbort']=_0x4e4be4,this['queue']['push'](_0x3fecb2);const _0x15121b=this['queue']['length']-0x1;return()=>{this['queue'][_0x15121b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x11c423){if(this['auth']['currentUser']===_0x11c423)return;const _0x3c7b60=[];try{for(const _0x1092b3 of this['queue'])await _0x1092b3(_0x11c423),_0x1092b3['onAbort']&&_0x3c7b60['push'](_0x1092b3['onAbort']);}catch(_0x22ecd8){_0x3c7b60['reverse']();for(const _0x3aa27b of _0x3c7b60)try{_0x3aa27b();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x22ecd8==null?void 0x0:_0x22ecd8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x2f5d4e,_0x39f27e={}){return Ae(_0x2f5d4e,'GET','/v2/passwordPolicy',Re(_0x2f5d4e,_0x39f27e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x5d3b25){var _0x1750cb;const _0x254f9b=_0x5d3b25['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x254f9b['minPasswordLength']??Tf,_0x254f9b['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x254f9b['maxPasswordLength']),_0x254f9b['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x254f9b['containsLowercaseCharacter']),_0x254f9b['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x254f9b['containsUppercaseCharacter']),_0x254f9b['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x254f9b['containsNumericCharacter']),_0x254f9b['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x254f9b['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5d3b25['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1750cb=_0x5d3b25['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1750cb['join'](''))??'',this['forceUpgradeOnSignin']=_0x5d3b25['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5d3b25['schemaVersion'];}['validatePassword'](_0x39f700){const _0x5f275={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x39f700,_0x5f275),this['validatePasswordCharacterOptions'](_0x39f700,_0x5f275),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['meetsMinPasswordLength']??!0x0),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['meetsMaxPasswordLength']??!0x0),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['containsLowercaseLetter']??!0x0),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['containsUppercaseLetter']??!0x0),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['containsNumericCharacter']??!0x0),_0x5f275['isValid']&&(_0x5f275['isValid']=_0x5f275['containsNonAlphanumericCharacter']??!0x0),_0x5f275;}['validatePasswordLengthOptions'](_0x1a8bdf,_0x15960e){const _0x21553f=this['customStrengthOptions']['minPasswordLength'],_0x52c203=this['customStrengthOptions']['maxPasswordLength'];_0x21553f&&(_0x15960e['meetsMinPasswordLength']=_0x1a8bdf['length']>=_0x21553f),_0x52c203&&(_0x15960e['meetsMaxPasswordLength']=_0x1a8bdf['length']<=_0x52c203);}['validatePasswordCharacterOptions'](_0x42438c,_0x3ebc51){this['updatePasswordCharacterOptionsStatuses'](_0x3ebc51,!0x1,!0x1,!0x1,!0x1);let _0x25cb18;for(let _0x57bf8e=0x0;_0x57bf8e<_0x42438c['length'];_0x57bf8e++)_0x25cb18=_0x42438c['charAt'](_0x57bf8e),this['updatePasswordCharacterOptionsStatuses'](_0x3ebc51,_0x25cb18>='a'&&_0x25cb18<='z',_0x25cb18>='A'&&_0x25cb18<='Z',_0x25cb18>='0'&&_0x25cb18<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x25cb18));}['updatePasswordCharacterOptionsStatuses'](_0x1af212,_0x283a7c,_0x2728a9,_0x55a70a,_0x4d2c23){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1af212['containsLowercaseLetter']||(_0x1af212['containsLowercaseLetter']=_0x283a7c)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1af212['containsUppercaseLetter']||(_0x1af212['containsUppercaseLetter']=_0x2728a9)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1af212['containsNumericCharacter']||(_0x1af212['containsNumericCharacter']=_0x55a70a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1af212['containsNonAlphanumericCharacter']||(_0x1af212['containsNonAlphanumericCharacter']=_0x4d2c23));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3854f0,_0x16504d,_0x2d87f7,_0x5bf1d2){this['app']=_0x3854f0,this['heartbeatServiceProvider']=_0x16504d,this['appCheckServiceProvider']=_0x2d87f7,this['config']=_0x5bf1d2,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3854f0['name'],this['clientVersion']=_0x5bf1d2['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x36feac=>this['_resolvePersistenceManagerAvailable']=_0x36feac);}['_initializeWithPersistence'](_0x249127,_0x5079b9){return _0x5079b9&&(this['_popupRedirectResolver']=ne(_0x5079b9)),this['_initializationPromise']=this['queue'](async()=>{var _0x3b5900,_0x42d25a,_0x12f831;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x249127),(_0x3b5900=this['_resolvePersistenceManagerAvailable'])==null||_0x3b5900['call'](this),!this['_deleted'])){if((_0x42d25a=this['_popupRedirectResolver'])!=null&&_0x42d25a['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5079b9),this['lastNotifiedUid']=((_0x12f831=this['currentUser'])==null?void 0x0:_0x12f831['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x479d0a=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x479d0a)){if(this['currentUser']&&_0x479d0a&&this['currentUser']['uid']===_0x479d0a['uid']){this['_currentUser']['_assign'](_0x479d0a),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x479d0a,!0x0);}}async['initializeCurrentUserFromIdToken'](_0xab3332){try{const _0x57ff85=await Sn(this,{'idToken':_0xab3332}),_0x4271ba=await z['_fromGetAccountInfoResponse'](this,_0x57ff85,_0xab3332);await this['directlySetCurrentUser'](_0x4271ba);}catch(_0x16cb15){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x16cb15),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3a6b74){var _0x7e5ed5;if(H(this['app'])){const _0x37dd33=this['app']['settings']['authIdToken'];return _0x37dd33?new Promise(_0x250deb=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x37dd33)['then'](_0x250deb,_0x250deb));}):this['directlySetCurrentUser'](null);}const _0x175d2c=await this['assertedPersistence']['getCurrentUser']();let _0x176786=_0x175d2c,_0x575e32=!0x1;if(_0x3a6b74&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xb64210=(_0x7e5ed5=this['redirectUser'])==null?void 0x0:_0x7e5ed5['_redirectEventId'],_0x366845=_0x176786==null?void 0x0:_0x176786['_redirectEventId'],_0x4f6126=await this['tryRedirectSignIn'](_0x3a6b74);(!_0xb64210||_0xb64210===_0x366845)&&(_0x4f6126!=null&&_0x4f6126['user'])&&(_0x176786=_0x4f6126['user'],_0x575e32=!0x0);}if(!_0x176786)return this['directlySetCurrentUser'](null);if(!_0x176786['_redirectEventId']){if(_0x575e32)try{await this['beforeStateQueue']['runMiddleware'](_0x176786);}catch(_0xee7b99){_0x176786=_0x175d2c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xee7b99));}return _0x176786?this['reloadAndSetCurrentUserOrClear'](_0x176786):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x176786['_redirectEventId']?this['directlySetCurrentUser'](_0x176786):this['reloadAndSetCurrentUserOrClear'](_0x176786);}async['tryRedirectSignIn'](_0x4cd8e6){let _0x91f657=null;try{_0x91f657=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4cd8e6,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x91f657;}async['reloadAndSetCurrentUserOrClear'](_0x5243f5){try{await bn(_0x5243f5);}catch(_0x1f6f14){if((_0x1f6f14==null?void 0x0:_0x1f6f14['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5243f5);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x218446){if(H(this['app']))return Promise['reject'](se(this));const _0x5ee9c4=_0x218446?k(_0x218446):null;return _0x5ee9c4&&m(_0x5ee9c4['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5ee9c4&&_0x5ee9c4['_clone'](this));}async['_updateCurrentUser'](_0x3d9dde,_0x5ad744=!0x1){if(!this['_deleted'])return _0x3d9dde&&m(this['tenantId']===_0x3d9dde['tenantId'],this,'tenant-id-mismatch'),_0x5ad744||await this['beforeStateQueue']['runMiddleware'](_0x3d9dde),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3d9dde),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x377cbd){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x377cbd));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x365cc2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4d391d=this['_getPasswordPolicyInternal']();return _0x4d391d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4d391d['validatePassword'](_0x365cc2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5a3bc9=await Cf(this),_0x2f4988=new Sf(_0x5a3bc9);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2f4988:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2f4988;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x37ae52){this['_errorFactory']=new Ut('auth','Firebase',_0x37ae52());}['onAuthStateChanged'](_0x444515,_0x486e6a,_0x388086){return this['registerStateListener'](this['authStateSubscription'],_0x444515,_0x486e6a,_0x388086);}['beforeAuthStateChanged'](_0x866ccd,_0x17cfe3){return this['beforeStateQueue']['pushCallback'](_0x866ccd,_0x17cfe3);}['onIdTokenChanged'](_0x183dd9,_0x58ba3f,_0x2b2fd9){return this['registerStateListener'](this['idTokenSubscription'],_0x183dd9,_0x58ba3f,_0x2b2fd9);}['authStateReady'](){return new Promise((_0x58f55f,_0x172d3a)=>{if(this['currentUser'])_0x58f55f();else{const _0x177e55=this['onAuthStateChanged'](()=>{_0x177e55(),_0x58f55f();},_0x172d3a);}});}async['revokeAccessToken'](_0x391ba4){if(this['currentUser']){const _0x152e1d=await this['currentUser']['getIdToken'](),_0x55edda={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x391ba4,'idToken':_0x152e1d};this['tenantId']!=null&&(_0x55edda['tenantId']=this['tenantId']),await vf(this,_0x55edda);}}['toJSON'](){var _0x37333c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x37333c=this['_currentUser'])==null?void 0x0:_0x37333c['toJSON']()};}async['_setRedirectUser'](_0x55c3aa,_0xababd5){const _0x1b9fc8=await this['getOrInitRedirectPersistenceManager'](_0xababd5);return _0x55c3aa===null?_0x1b9fc8['removeCurrentUser']():_0x1b9fc8['setCurrentUser'](_0x55c3aa);}async['getOrInitRedirectPersistenceManager'](_0x2527a8){if(!this['redirectPersistenceManager']){const _0x2d48a7=_0x2527a8&&ne(_0x2527a8)||this['_popupRedirectResolver'];m(_0x2d48a7,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x2d48a7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x18e0e5){var _0x5651d7,_0x332dac;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5651d7=this['_currentUser'])==null?void 0x0:_0x5651d7['_redirectEventId'])===_0x18e0e5?this['_currentUser']:((_0x332dac=this['redirectUser'])==null?void 0x0:_0x332dac['_redirectEventId'])===_0x18e0e5?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1e3476){if(_0x1e3476===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1e3476));}['_notifyListenersIfCurrent'](_0x598a4b){_0x598a4b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2a369c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x448487=((_0x2a369c=this['currentUser'])==null?void 0x0:_0x2a369c['uid'])??null;this['lastNotifiedUid']!==_0x448487&&(this['lastNotifiedUid']=_0x448487,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3fee84,_0x7bb315,_0x58a50c,_0x173a3){if(this['_deleted'])return()=>{};const _0x37aebc=typeof _0x7bb315=='function'?_0x7bb315:_0x7bb315['next']['bind'](_0x7bb315);let _0x3c9939=!0x1;const _0x232f12=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x232f12,this,'internal-error'),_0x232f12['then'](()=>{_0x3c9939||_0x37aebc(this['currentUser']);}),typeof _0x7bb315=='function'){const _0x2c1e9b=_0x3fee84['addObserver'](_0x7bb315,_0x58a50c,_0x173a3);return()=>{_0x3c9939=!0x0,_0x2c1e9b();};}else{const _0x1a5ccd=_0x3fee84['addObserver'](_0x7bb315);return()=>{_0x3c9939=!0x0,_0x1a5ccd();};}}async['directlySetCurrentUser'](_0x17b8a7){this['currentUser']&&this['currentUser']!==_0x17b8a7&&this['_currentUser']['_stopProactiveRefresh'](),_0x17b8a7&&this['isProactiveRefreshEnabled']&&_0x17b8a7['_startProactiveRefresh'](),this['currentUser']=_0x17b8a7,_0x17b8a7?await this['assertedPersistence']['setCurrentUser'](_0x17b8a7):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x54d3c0){return this['operations']=this['operations']['then'](_0x54d3c0,_0x54d3c0),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4aadd2){!_0x4aadd2||this['frameworks']['includes'](_0x4aadd2)||(this['frameworks']['push'](_0x4aadd2),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x36b6d6;const _0x58fcc4={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x58fcc4['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1f4384=await((_0x36b6d6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x36b6d6['getHeartbeatsHeader']());_0x1f4384&&(_0x58fcc4['X-Firebase-Client']=_0x1f4384);const _0x563e05=await this['_getAppCheckToken']();return _0x563e05&&(_0x58fcc4['X-Firebase-AppCheck']=_0x563e05),_0x58fcc4;}async['_getAppCheckToken'](){var _0x260596;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x109f01=await((_0x260596=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x260596['getToken']());return _0x109f01!=null&&_0x109f01['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x109f01['error']),_0x109f01==null?void 0x0:_0x109f01['token'];}}function qe(_0x3c08ca){return k(_0x3c08ca);}class Tr{constructor(_0x2d98da){this['auth']=_0x2d98da,this['observer']=null,this['addObserver']=Ic(_0x18e631=>this['observer']=_0x18e631);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2c1f63){zn=_0x2c1f63;}function Da(_0xf4ad23){return zn['loadJS'](_0xf4ad23);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x473805){return'__'+_0x473805+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xff402d){_0xff402d();}['execute'](_0x1584a3,_0x52b0e8){return Promise['resolve']('token');}['render'](_0x5630b9,_0x1cb5c2){return'';}}class Of{['ready'](_0xb54084){_0xb54084();}['execute'](_0xe9bc1e,_0x18aefa){return Promise['resolve']('token');}['render'](_0x378c71,_0x50a086){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2cc4bb){this['type']=Df,this['auth']=qe(_0x2cc4bb);}async['verify'](_0x819027='verify',_0x2a474e=!0x1){async function _0x284ae9(_0x433c25){if(!_0x2a474e){if(_0x433c25['tenantId']==null&&_0x433c25['_agentRecaptchaConfig']!=null)return _0x433c25['_agentRecaptchaConfig']['siteKey'];if(_0x433c25['tenantId']!=null&&_0x433c25['_tenantRecaptchaConfigs'][_0x433c25['tenantId']]!==void 0x0)return _0x433c25['_tenantRecaptchaConfigs'][_0x433c25['tenantId']]['siteKey'];}return new Promise(async(_0x2df316,_0x103d3d)=>{uf(_0x433c25,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x55b824=>{if(_0x55b824['recaptchaKey']===void 0x0)_0x103d3d(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x55e00d=new hf(_0x55b824);return _0x433c25['tenantId']==null?_0x433c25['_agentRecaptchaConfig']=_0x55e00d:_0x433c25['_tenantRecaptchaConfigs'][_0x433c25['tenantId']]=_0x55e00d,_0x2df316(_0x55e00d['siteKey']);}})['catch'](_0x43bd7b=>{_0x103d3d(_0x43bd7b);});});}function _0x1e18c4(_0x5b0399,_0x3954a8,_0x33e917){const _0xab6f3c=window['grecaptcha'];vr(_0xab6f3c)?_0xab6f3c['enterprise']['ready'](()=>{_0xab6f3c['enterprise']['execute'](_0x5b0399,{'action':_0x819027})['then'](_0x661b37=>{_0x3954a8(_0x661b37);})['catch'](()=>{_0x3954a8(Ma);});}):_0x33e917(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1049cb,_0x686397)=>{_0x284ae9(this['auth'])['then'](async _0x4d421a=>{if(!_0x2a474e&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x1e18c4(_0x4d421a,_0x1049cb,_0x686397);else{if(typeof window>'u'){_0x686397(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5a0ab1=Af();_0x5a0ab1['length']!==0x0&&(_0x5a0ab1+=_0x4d421a+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x2ad5d1;(_0x2ad5d1=le['scriptInjectionDeferred'])==null||_0x2ad5d1['resolve']();},Da(_0x5a0ab1)['then'](()=>{var _0x5ca08a;return(_0x5ca08a=le['scriptInjectionDeferred'])==null?void 0x0:_0x5ca08a['promise'];})['then'](()=>{_0x1e18c4(_0x4d421a,_0x1049cb,_0x686397);})['catch'](_0x49c1db=>{_0x686397(_0x49c1db);});}})['catch'](_0x28d7c9=>{_0x686397(_0x28d7c9);});});}}le['scriptInjectionDeferred']=null;async function br(_0xb81100,_0x2029c0,_0x59e255,_0x40b116=!0x1,_0x568a05=!0x1){const _0x4fbd02=new le(_0xb81100);let _0xd21219;if(_0x568a05)_0xd21219=Ma;else try{_0xd21219=await _0x4fbd02['verify'](_0x59e255);}catch{_0xd21219=await _0x4fbd02['verify'](_0x59e255,!0x0);}const _0x3588bf={..._0x2029c0};if(_0x59e255==='mfaSmsEnrollment'||_0x59e255==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3588bf){const _0x5c23ed=_0x3588bf['phoneEnrollmentInfo']['phoneNumber'],_0x4cf670=_0x3588bf['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3588bf,{'phoneEnrollmentInfo':{'phoneNumber':_0x5c23ed,'recaptchaToken':_0x4cf670,'captchaResponse':_0xd21219,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3588bf){const _0x1335a8=_0x3588bf['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3588bf,{'phoneSignInInfo':{'recaptchaToken':_0x1335a8,'captchaResponse':_0xd21219,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3588bf;}return _0x40b116?Object['assign'](_0x3588bf,{'captchaResp':_0xd21219}):Object['assign'](_0x3588bf,{'captchaResponse':_0xd21219}),Object['assign'](_0x3588bf,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3588bf,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3588bf;}async function Oi(_0xd84866,_0x806b00,_0x589ed0,_0x1a13bf,_0x566312){var _0xf2568a;if((_0xf2568a=_0xd84866['_getRecaptchaConfig']())!=null&&_0xf2568a['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4d2aba=await br(_0xd84866,_0x806b00,_0x589ed0,_0x589ed0==='getOobCode');return _0x1a13bf(_0xd84866,_0x4d2aba);}else return _0x1a13bf(_0xd84866,_0x806b00)['catch'](async _0xe0aa4b=>{if(_0xe0aa4b['code']==='auth/missing-recaptcha-token'){console['log'](_0x589ed0+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3c8496=await br(_0xd84866,_0x806b00,_0x589ed0,_0x589ed0==='getOobCode');return _0x1a13bf(_0xd84866,_0x3c8496);}else return Promise['reject'](_0xe0aa4b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x23d9ca,_0x435981){const _0x28e2e8=Ui(_0x23d9ca,'auth');if(_0x28e2e8['isInitialized']()){const _0x4d3f97=_0x28e2e8['getImmediate'](),_0x2804b4=_0x28e2e8['getOptions']();if(De(_0x2804b4,_0x435981??{}))return _0x4d3f97;K(_0x4d3f97,'already-initialized');}return _0x28e2e8['initialize']({'options':_0x435981});}function Lf(_0x288cc0,_0x521a83){const _0x108b7e=(_0x521a83==null?void 0x0:_0x521a83['persistence'])||[],_0x169974=(Array['isArray'](_0x108b7e)?_0x108b7e:[_0x108b7e])['map'](ne);_0x521a83!=null&&_0x521a83['errorMap']&&_0x288cc0['_updateErrorMap'](_0x521a83['errorMap']),_0x288cc0['_initializeWithPersistence'](_0x169974,_0x521a83==null?void 0x0:_0x521a83['popupRedirectResolver']);}function xf(_0x9f0a71,_0x4e1881,_0x2eedef){const _0x5136f6=qe(_0x9f0a71);m(/^https?:\/\//['test'](_0x4e1881),_0x5136f6,'invalid-emulator-scheme');const _0x18379f=!0x1,_0x1d87da=La(_0x4e1881),{host:_0x4baa18,port:_0x525b5d}=Ff(_0x4e1881),_0x187c44=_0x525b5d===null?'':':'+_0x525b5d,_0x21bf61={'url':_0x1d87da+'//'+_0x4baa18+_0x187c44+'/'},_0x6cf65e=Object['freeze']({'host':_0x4baa18,'port':_0x525b5d,'protocol':_0x1d87da['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x18379f})});if(!_0x5136f6['_canInitEmulator']){m(_0x5136f6['config']['emulator']&&_0x5136f6['emulatorConfig'],_0x5136f6,'emulator-config-failed'),m(De(_0x21bf61,_0x5136f6['config']['emulator'])&&De(_0x6cf65e,_0x5136f6['emulatorConfig']),_0x5136f6,'emulator-config-failed');return;}_0x5136f6['config']['emulator']=_0x21bf61,_0x5136f6['emulatorConfig']=_0x6cf65e,_0x5136f6['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x4baa18)?jr(_0x1d87da+'//'+_0x4baa18+_0x187c44):Uf();}function La(_0x1019c8){const _0xd433a8=_0x1019c8['indexOf'](':');return _0xd433a8<0x0?'':_0x1019c8['substr'](0x0,_0xd433a8+0x1);}function Ff(_0x2e6807){const _0x268a72=La(_0x2e6807),_0x452c38=/(\/\/)?([^?#/]+)/['exec'](_0x2e6807['substr'](_0x268a72['length']));if(!_0x452c38)return{'host':'','port':null};const _0x5d98b1=_0x452c38[0x2]['split']('@')['pop']()||'',_0x50aad3=/^(\[[^\]]+\])(:|$)/['exec'](_0x5d98b1);if(_0x50aad3){const _0x5f5582=_0x50aad3[0x1];return{'host':_0x5f5582,'port':Rr(_0x5d98b1['substr'](_0x5f5582['length']+0x1))};}else{const [_0x370802,_0x47ea9d]=_0x5d98b1['split'](':');return{'host':_0x370802,'port':Rr(_0x47ea9d)};}}function Rr(_0x469fd2){if(!_0x469fd2)return null;const _0x11e96f=Number(_0x469fd2);return isNaN(_0x11e96f)?null:_0x11e96f;}function Uf(){function _0x188677(){const _0x2afabc=document['createElement']('p'),_0x54290f=_0x2afabc['style'];_0x2afabc['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x54290f['position']='fixed',_0x54290f['width']='100%',_0x54290f['backgroundColor']='#ffffff',_0x54290f['border']='.1em\x20solid\x20#000000',_0x54290f['color']='#b50000',_0x54290f['bottom']='0px',_0x54290f['left']='0px',_0x54290f['margin']='0px',_0x54290f['zIndex']='10000',_0x54290f['textAlign']='center',_0x2afabc['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2afabc);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x188677):_0x188677());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x3cdd07,_0x18b9f1){this['providerId']=_0x3cdd07,this['signInMethod']=_0x18b9f1;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xb1a04c){return te('not\x20implemented');}['_linkToIdToken'](_0x374f7a,_0x1d1127){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x5c00f4){return te('not\x20implemented');}}async function Wf(_0x27a93d,_0x21c3f1){return Ae(_0x27a93d,'POST','/v1/accounts:signUp',_0x21c3f1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x5efae7,_0x2b2f8c){return Yt(_0x5efae7,'POST','/v1/accounts:signInWithPassword',Re(_0x5efae7,_0x2b2f8c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4028a0,_0x264f1f){return Yt(_0x4028a0,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4028a0,_0x264f1f));}async function Hf(_0x46d72c,_0x14c4f3){return Yt(_0x46d72c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x46d72c,_0x14c4f3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x3d7139,_0x53c65a,_0x14bea8,_0x4144f0=null){super('password',_0x14bea8),this['_email']=_0x3d7139,this['_password']=_0x53c65a,this['_tenantId']=_0x4144f0;}static['_fromEmailAndPassword'](_0xd782c,_0x1280a4){return new Ft(_0xd782c,_0x1280a4,'password');}static['_fromEmailAndCode'](_0x4e44b5,_0x84dbe5,_0x15c5ab=null){return new Ft(_0x4e44b5,_0x84dbe5,'emailLink',_0x15c5ab);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x255050){const _0x16dc37=typeof _0x255050=='string'?JSON['parse'](_0x255050):_0x255050;if(_0x16dc37!=null&&_0x16dc37['email']&&(_0x16dc37!=null&&_0x16dc37['password'])){if(_0x16dc37['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x16dc37['email'],_0x16dc37['password']);if(_0x16dc37['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x16dc37['email'],_0x16dc37['password'],_0x16dc37['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2b10bf){switch(this['signInMethod']){case'password':const _0x3eb4a2={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2b10bf,_0x3eb4a2,'signInWithPassword',Bf);case'emailLink':return Vf(_0x2b10bf,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x2b10bf,'internal-error');}}async['_linkToIdToken'](_0x21e2be,_0x5908d0){switch(this['signInMethod']){case'password':const _0xf13632={'idToken':_0x5908d0,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x21e2be,_0xf13632,'signUpPassword',Wf);case'emailLink':return Hf(_0x21e2be,{'idToken':_0x5908d0,'email':this['_email'],'oobCode':this['_password']});default:K(_0x21e2be,'internal-error');}}['_getReauthenticationResolver'](_0x40f1a3){return this['_getIdTokenResponse'](_0x40f1a3);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x27227d,_0x3974ca){return Yt(_0x27227d,'POST','/v1/accounts:signInWithIdp',Re(_0x27227d,_0x3974ca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4bc55e){const _0x251f16=new We(_0x4bc55e['providerId'],_0x4bc55e['signInMethod']);return _0x4bc55e['idToken']||_0x4bc55e['accessToken']?(_0x4bc55e['idToken']&&(_0x251f16['idToken']=_0x4bc55e['idToken']),_0x4bc55e['accessToken']&&(_0x251f16['accessToken']=_0x4bc55e['accessToken']),_0x4bc55e['nonce']&&!_0x4bc55e['pendingToken']&&(_0x251f16['nonce']=_0x4bc55e['nonce']),_0x4bc55e['pendingToken']&&(_0x251f16['pendingToken']=_0x4bc55e['pendingToken'])):_0x4bc55e['oauthToken']&&_0x4bc55e['oauthTokenSecret']?(_0x251f16['accessToken']=_0x4bc55e['oauthToken'],_0x251f16['secret']=_0x4bc55e['oauthTokenSecret']):K('argument-error'),_0x251f16;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xa9b046){const _0x389d44=typeof _0xa9b046=='string'?JSON['parse'](_0xa9b046):_0xa9b046,{providerId:_0x64494a,signInMethod:_0x54fa48,..._0x2ba02a}=_0x389d44;if(!_0x64494a||!_0x54fa48)return null;const _0x58eea8=new We(_0x64494a,_0x54fa48);return _0x58eea8['idToken']=_0x2ba02a['idToken']||void 0x0,_0x58eea8['accessToken']=_0x2ba02a['accessToken']||void 0x0,_0x58eea8['secret']=_0x2ba02a['secret'],_0x58eea8['nonce']=_0x2ba02a['nonce'],_0x58eea8['pendingToken']=_0x2ba02a['pendingToken']||null,_0x58eea8;}['_getIdTokenResponse'](_0x445fcf){const _0x15d8cb=this['buildRequest']();return Ze(_0x445fcf,_0x15d8cb);}['_linkToIdToken'](_0x1f10ed,_0x368092){const _0x449939=this['buildRequest']();return _0x449939['idToken']=_0x368092,Ze(_0x1f10ed,_0x449939);}['_getReauthenticationResolver'](_0x584d55){const _0x47f3a3=this['buildRequest']();return _0x47f3a3['autoCreate']=!0x1,Ze(_0x584d55,_0x47f3a3);}['buildRequest'](){const _0x1c2ea0={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1c2ea0['pendingToken']=this['pendingToken'];else{const _0x2c1f40={};this['idToken']&&(_0x2c1f40['id_token']=this['idToken']),this['accessToken']&&(_0x2c1f40['access_token']=this['accessToken']),this['secret']&&(_0x2c1f40['oauth_token_secret']=this['secret']),_0x2c1f40['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2c1f40['nonce']=this['nonce']),_0x1c2ea0['postBody']=at(_0x2c1f40);}return _0x1c2ea0;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x194b00){switch(_0x194b00){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x4261a7){const _0x552ae5=yt(vt(_0x4261a7))['link'],_0x573844=_0x552ae5?yt(vt(_0x552ae5))['deep_link_id']:null,_0x52f6ff=yt(vt(_0x4261a7))['deep_link_id'];return(_0x52f6ff?yt(vt(_0x52f6ff))['link']:null)||_0x52f6ff||_0x573844||_0x552ae5||_0x4261a7;}class Ss{constructor(_0x19eec8){const _0x4c2949=yt(vt(_0x19eec8)),_0x146960=_0x4c2949['apiKey']??null,_0x53ee05=_0x4c2949['oobCode']??null,_0x42ee5e=Gf(_0x4c2949['mode']??null);m(_0x146960&&_0x53ee05&&_0x42ee5e,'argument-error'),this['apiKey']=_0x146960,this['operation']=_0x42ee5e,this['code']=_0x53ee05,this['continueUrl']=_0x4c2949['continueUrl']??null,this['languageCode']=_0x4c2949['lang']??null,this['tenantId']=_0x4c2949['tenantId']??null;}static['parseLink'](_0x137451){const _0x5598f5=qf(_0x137451);try{return new Ss(_0x5598f5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x1df11e,_0xea0ec0){return Ft['_fromEmailAndPassword'](_0x1df11e,_0xea0ec0);}static['credentialWithLink'](_0x4cacd7,_0x404c5f){const _0x427445=Ss['parseLink'](_0x404c5f);return m(_0x427445,'argument-error'),Ft['_fromEmailAndCode'](_0x4cacd7,_0x427445['code'],_0x427445['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x174aa5){this['providerId']=_0x174aa5,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xbce456){this['defaultLanguageCode']=_0xbce456;}['setCustomParameters'](_0x26775e){return this['customParameters']=_0x26775e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xe9367e){return this['scopes']['includes'](_0xe9367e)||this['scopes']['push'](_0xe9367e),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x383ec8){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x383ec8});}static['credentialFromResult'](_0x20cb6c){return he['credentialFromTaggedObject'](_0x20cb6c);}static['credentialFromError'](_0x3de852){return he['credentialFromTaggedObject'](_0x3de852['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3640dc}){if(!_0x3640dc||!('oauthAccessToken'in _0x3640dc)||!_0x3640dc['oauthAccessToken'])return null;try{return he['credential'](_0x3640dc['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x44c3e8,_0x1f2918){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x44c3e8,'accessToken':_0x1f2918});}static['credentialFromResult'](_0x274034){return ue['credentialFromTaggedObject'](_0x274034);}static['credentialFromError'](_0x2211c5){return ue['credentialFromTaggedObject'](_0x2211c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3d7cfe}){if(!_0x3d7cfe)return null;const {oauthIdToken:_0x42b488,oauthAccessToken:_0x1bd4c4}=_0x3d7cfe;if(!_0x42b488&&!_0x1bd4c4)return null;try{return ue['credential'](_0x42b488,_0x1bd4c4);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x25bd8e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x25bd8e});}static['credentialFromResult'](_0x4c1350){return de['credentialFromTaggedObject'](_0x4c1350);}static['credentialFromError'](_0x415ba7){return de['credentialFromTaggedObject'](_0x415ba7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x111649}){if(!_0x111649||!('oauthAccessToken'in _0x111649)||!_0x111649['oauthAccessToken'])return null;try{return de['credential'](_0x111649['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2391d5,_0x1462b6){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2391d5,'oauthTokenSecret':_0x1462b6});}static['credentialFromResult'](_0xcc5ac9){return fe['credentialFromTaggedObject'](_0xcc5ac9);}static['credentialFromError'](_0x50cbeb){return fe['credentialFromTaggedObject'](_0x50cbeb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x432bab}){if(!_0x432bab)return null;const {oauthAccessToken:_0x144310,oauthTokenSecret:_0x2baffd}=_0x432bab;if(!_0x144310||!_0x2baffd)return null;try{return fe['credential'](_0x144310,_0x2baffd);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x56b1ce,_0x324a2a){return Yt(_0x56b1ce,'POST','/v1/accounts:signUp',Re(_0x56b1ce,_0x324a2a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x11a8b8){this['user']=_0x11a8b8['user'],this['providerId']=_0x11a8b8['providerId'],this['_tokenResponse']=_0x11a8b8['_tokenResponse'],this['operationType']=_0x11a8b8['operationType'];}static async['_fromIdTokenResponse'](_0x36dc91,_0x106bfd,_0x439a9b,_0x5bd539=!0x1){const _0xc59786=await z['_fromIdTokenResponse'](_0x36dc91,_0x439a9b,_0x5bd539),_0x3a2f41=Ar(_0x439a9b);return new Be({'user':_0xc59786,'providerId':_0x3a2f41,'_tokenResponse':_0x439a9b,'operationType':_0x106bfd});}static async['_forOperation'](_0x3c9ae8,_0x33b056,_0x150946){await _0x3c9ae8['_updateTokensIfNecessary'](_0x150946,!0x0);const _0x14167b=Ar(_0x150946);return new Be({'user':_0x3c9ae8,'providerId':_0x14167b,'_tokenResponse':_0x150946,'operationType':_0x33b056});}}function Ar(_0x510849){return _0x510849['providerId']?_0x510849['providerId']:'phoneNumber'in _0x510849?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x368b92,_0x418778,_0x1d1db0,_0x3401ab){super(_0x418778['code'],_0x418778['message']),this['operationType']=_0x1d1db0,this['user']=_0x3401ab,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x368b92['name'],'tenantId':_0x368b92['tenantId']??void 0x0,'_serverResponse':_0x418778['customData']['_serverResponse'],'operationType':_0x1d1db0};}static['_fromErrorAndOperation'](_0x5b67ef,_0x4558d8,_0x137b5e,_0x3ca919){return new Rn(_0x5b67ef,_0x4558d8,_0x137b5e,_0x3ca919);}}function Fa(_0x215e8a,_0x8020e1,_0x17120e,_0x2d2d60){return(_0x8020e1==='reauthenticate'?_0x17120e['_getReauthenticationResolver'](_0x215e8a):_0x17120e['_getIdTokenResponse'](_0x215e8a))['catch'](_0x1b0c27=>{throw _0x1b0c27['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x215e8a,_0x1b0c27,_0x8020e1,_0x2d2d60):_0x1b0c27;});}async function jf(_0xf9b94e,_0x41bd2f,_0x1a6d8a=!0x1){const _0x8470ba=await xt(_0xf9b94e,_0x41bd2f['_linkToIdToken'](_0xf9b94e['auth'],await _0xf9b94e['getIdToken']()),_0x1a6d8a);return Be['_forOperation'](_0xf9b94e,'link',_0x8470ba);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x40fa54,_0x35d4e7,_0x3d5ebb=!0x1){const {auth:_0x1da3e4}=_0x40fa54;if(H(_0x1da3e4['app']))return Promise['reject'](se(_0x1da3e4));const _0x475d58='reauthenticate';try{const _0x3314a7=await xt(_0x40fa54,Fa(_0x1da3e4,_0x475d58,_0x35d4e7,_0x40fa54),_0x3d5ebb);m(_0x3314a7['idToken'],_0x1da3e4,'internal-error');const _0x2e192f=ws(_0x3314a7['idToken']);m(_0x2e192f,_0x1da3e4,'internal-error');const {sub:_0x132d5b}=_0x2e192f;return m(_0x40fa54['uid']===_0x132d5b,_0x1da3e4,'user-mismatch'),Be['_forOperation'](_0x40fa54,_0x475d58,_0x3314a7);}catch(_0x411c31){throw(_0x411c31==null?void 0x0:_0x411c31['code'])==='auth/user-not-found'&&K(_0x1da3e4,'user-mismatch'),_0x411c31;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x1c7440,_0xa4bff6,_0x2005d2=!0x1){if(H(_0x1c7440['app']))return Promise['reject'](se(_0x1c7440));const _0x3a1e1d='signIn',_0x14a1dd=await Fa(_0x1c7440,_0x3a1e1d,_0xa4bff6),_0x573d56=await Be['_fromIdTokenResponse'](_0x1c7440,_0x3a1e1d,_0x14a1dd);return _0x2005d2||await _0x1c7440['_updateCurrentUser'](_0x573d56['user']),_0x573d56;}async function Yf(_0xf2c502,_0x3f13ab){return Ua(qe(_0xf2c502),_0x3f13ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x332e35){const _0x406c16=qe(_0x332e35);_0x406c16['_getPasswordPolicyInternal']()&&await _0x406c16['_updatePasswordPolicy']();}async function R_(_0x3162c0,_0x4f91a4,_0x191a77){if(H(_0x3162c0['app']))return Promise['reject'](se(_0x3162c0));const _0x46e058=qe(_0x3162c0),_0x5293f9=await Oi(_0x46e058,{'returnSecureToken':!0x0,'email':_0x4f91a4,'password':_0x191a77,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x4dfc6b=>{throw _0x4dfc6b['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3162c0),_0x4dfc6b;}),_0x25e0aa=await Be['_fromIdTokenResponse'](_0x46e058,'signIn',_0x5293f9);return await _0x46e058['_updateCurrentUser'](_0x25e0aa['user']),_0x25e0aa;}function A_(_0x3edda1,_0x534966,_0xe29ec3){return H(_0x3edda1['app'])?Promise['reject'](se(_0x3edda1)):Yf(k(_0x3edda1),ft['credential'](_0x534966,_0xe29ec3))['catch'](async _0xc9f46e=>{throw _0xc9f46e['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3edda1),_0xc9f46e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x115558,_0x303590){return k(_0x115558)['setPersistence'](_0x303590);}function Qf(_0x4ee79b,_0x342bf0,_0x166803,_0x3bf40d){return k(_0x4ee79b)['onIdTokenChanged'](_0x342bf0,_0x166803,_0x3bf40d);}function Jf(_0x59fec6,_0x3e8f9f,_0xb82c5e){return k(_0x59fec6)['beforeAuthStateChanged'](_0x3e8f9f,_0xb82c5e);}function N_(_0x4f353c,_0x5eecfe,_0x550aa9,_0x4b4f83){return k(_0x4f353c)['onAuthStateChanged'](_0x5eecfe,_0x550aa9,_0x4b4f83);}function P_(_0x4626b1){return k(_0x4626b1)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x18e2e0,_0x1c2c96){this['storageRetriever']=_0x18e2e0,this['type']=_0x1c2c96;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x6fbbe,_0x54f729){return this['storage']['setItem'](_0x6fbbe,JSON['stringify'](_0x54f729)),Promise['resolve']();}['_get'](_0x1e80d4){const _0x4225e0=this['storage']['getItem'](_0x1e80d4);return Promise['resolve'](_0x4225e0?JSON['parse'](_0x4225e0):null);}['_remove'](_0x44f798){return this['storage']['removeItem'](_0x44f798),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3191c9,_0x4d115b)=>this['onStorageEvent'](_0x3191c9,_0x4d115b),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x24b062){for(const _0x385360 of Object['keys'](this['listeners'])){const _0x366cfa=this['storage']['getItem'](_0x385360),_0x2003cb=this['localCache'][_0x385360];_0x366cfa!==_0x2003cb&&_0x24b062(_0x385360,_0x2003cb,_0x366cfa);}}['onStorageEvent'](_0x50bd75,_0x2feea1=!0x1){if(!_0x50bd75['key']){this['forAllChangedKeys']((_0x243a35,_0x1577d5,_0x38c953)=>{this['notifyListeners'](_0x243a35,_0x38c953);});return;}const _0x59c6ec=_0x50bd75['key'];_0x2feea1?this['detachListener']():this['stopPolling']();const _0x2d2a9e=()=>{const _0x1a43c7=this['storage']['getItem'](_0x59c6ec);!_0x2feea1&&this['localCache'][_0x59c6ec]===_0x1a43c7||this['notifyListeners'](_0x59c6ec,_0x1a43c7);},_0x5ce5e4=this['storage']['getItem'](_0x59c6ec);If()&&_0x5ce5e4!==_0x50bd75['newValue']&&_0x50bd75['newValue']!==_0x50bd75['oldValue']?setTimeout(_0x2d2a9e,Zf):_0x2d2a9e();}['notifyListeners'](_0x176500,_0x519dfb){this['localCache'][_0x176500]=_0x519dfb;const _0x33d910=this['listeners'][_0x176500];if(_0x33d910){for(const _0x4727a4 of Array['from'](_0x33d910))_0x4727a4(_0x519dfb&&JSON['parse'](_0x519dfb));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4bf7f5,_0x562afb,_0x587724)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4bf7f5,'oldValue':_0x562afb,'newValue':_0x587724}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x46804d,_0x1b233c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x46804d]||(this['listeners'][_0x46804d]=new Set(),this['localCache'][_0x46804d]=this['storage']['getItem'](_0x46804d)),this['listeners'][_0x46804d]['add'](_0x1b233c);}['_removeListener'](_0x2a264d,_0x12b760){this['listeners'][_0x2a264d]&&(this['listeners'][_0x2a264d]['delete'](_0x12b760),this['listeners'][_0x2a264d]['size']===0x0&&delete this['listeners'][_0x2a264d]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1aad91,_0x2f297f){await super['_set'](_0x1aad91,_0x2f297f),this['localCache'][_0x1aad91]=JSON['stringify'](_0x2f297f);}async['_get'](_0x493d48){const _0xf123fa=await super['_get'](_0x493d48);return this['localCache'][_0x493d48]=JSON['stringify'](_0xf123fa),_0xf123fa;}async['_remove'](_0x20bb79){await super['_remove'](_0x20bb79),delete this['localCache'][_0x20bb79];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4b037a,_0x4aec09){}['_removeListener'](_0x4f15d7,_0x3fe5cb){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x235e50){return Promise['all'](_0x235e50['map'](async _0x3ece43=>{try{return{'fulfilled':!0x0,'value':await _0x3ece43};}catch(_0x20d5ca){return{'fulfilled':!0x1,'reason':_0x20d5ca};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x5c3c80){this['eventTarget']=_0x5c3c80,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x8f146d){const _0xb11c66=this['receivers']['find'](_0x3114a1=>_0x3114a1['isListeningto'](_0x8f146d));if(_0xb11c66)return _0xb11c66;const _0x1bdc03=new jn(_0x8f146d);return this['receivers']['push'](_0x1bdc03),_0x1bdc03;}['isListeningto'](_0x31ed7d){return this['eventTarget']===_0x31ed7d;}async['handleEvent'](_0x18463d){const _0x2f1e00=_0x18463d,{eventId:_0xc9bfee,eventType:_0x592757,data:_0x1289b0}=_0x2f1e00['data'],_0x31d5aa=this['handlersMap'][_0x592757];if(!(_0x31d5aa!=null&&_0x31d5aa['size']))return;_0x2f1e00['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xc9bfee,'eventType':_0x592757});const _0x327841=Array['from'](_0x31d5aa)['map'](async _0xdaed2d=>_0xdaed2d(_0x2f1e00['origin'],_0x1289b0)),_0x492858=await tp(_0x327841);_0x2f1e00['ports'][0x0]['postMessage']({'status':'done','eventId':_0xc9bfee,'eventType':_0x592757,'response':_0x492858});}['_subscribe'](_0x288f5d,_0x2ca6e6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x288f5d]||(this['handlersMap'][_0x288f5d]=new Set()),this['handlersMap'][_0x288f5d]['add'](_0x2ca6e6);}['_unsubscribe'](_0x5e4a00,_0x5ae25a){this['handlersMap'][_0x5e4a00]&&_0x5ae25a&&this['handlersMap'][_0x5e4a00]['delete'](_0x5ae25a),(!_0x5ae25a||this['handlersMap'][_0x5e4a00]['size']===0x0)&&delete this['handlersMap'][_0x5e4a00],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x257b24='',_0x4921ff=0xa){let _0xc0f2ca='';for(let _0x3bf03f=0x0;_0x3bf03f<_0x4921ff;_0x3bf03f++)_0xc0f2ca+=Math['floor'](Math['random']()*0xa);return _0x257b24+_0xc0f2ca;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x57ebcd){this['target']=_0x57ebcd,this['handlers']=new Set();}['removeMessageHandler'](_0x4a7004){_0x4a7004['messageChannel']&&(_0x4a7004['messageChannel']['port1']['removeEventListener']('message',_0x4a7004['onMessage']),_0x4a7004['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4a7004);}async['_send'](_0x5d3bbb,_0x7f1e98,_0x27e252=0x32){const _0xc52b1d=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xc52b1d)throw new Error('connection_unavailable');let _0x261961,_0x57ea32;return new Promise((_0xd57554,_0x2e3c76)=>{const _0x3aa99e=bs('',0x14);_0xc52b1d['port1']['start']();const _0x136a95=setTimeout(()=>{_0x2e3c76(new Error('unsupported_event'));},_0x27e252);_0x57ea32={'messageChannel':_0xc52b1d,'onMessage'(_0x17c2e1){const _0x5895f1=_0x17c2e1;if(_0x5895f1['data']['eventId']===_0x3aa99e)switch(_0x5895f1['data']['status']){case'ack':clearTimeout(_0x136a95),_0x261961=setTimeout(()=>{_0x2e3c76(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x261961),_0xd57554(_0x5895f1['data']['response']);break;default:clearTimeout(_0x136a95),clearTimeout(_0x261961),_0x2e3c76(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x57ea32),_0xc52b1d['port1']['addEventListener']('message',_0x57ea32['onMessage']),this['target']['postMessage']({'eventType':_0x5d3bbb,'eventId':_0x3aa99e,'data':_0x7f1e98},[_0xc52b1d['port2']]);})['finally'](()=>{_0x57ea32&&this['removeMessageHandler'](_0x57ea32);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x52c970){X()['location']['href']=_0x52c970;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x41aa74;return((_0x41aa74=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x41aa74['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x46e7e1){this['request']=_0x46e7e1;}['toPromise'](){return new Promise((_0x456039,_0x179592)=>{this['request']['addEventListener']('success',()=>{_0x456039(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x179592(this['request']['error']);});});}}function Kn(_0x35c11b,_0x1f643d){return _0x35c11b['transaction']([kn],_0x1f643d?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x48e1ef=indexedDB['deleteDatabase'](qa);return new Jt(_0x48e1ef)['toPromise']();}function ja(){const _0x1bf1a2=indexedDB['open'](qa,ap);return new Promise((_0x462957,_0x2538e3)=>{_0x1bf1a2['addEventListener']('error',()=>{_0x2538e3(_0x1bf1a2['error']);}),_0x1bf1a2['addEventListener']('upgradeneeded',()=>{const _0x378256=_0x1bf1a2['result'];try{_0x378256['createObjectStore'](kn,{'keyPath':za});}catch(_0x506dd5){_0x2538e3(_0x506dd5);}}),_0x1bf1a2['addEventListener']('success',async()=>{const _0x1ca1b2=_0x1bf1a2['result'];_0x1ca1b2['objectStoreNames']['contains'](kn)?_0x462957(_0x1ca1b2):(_0x1ca1b2['close'](),await cp(),_0x462957(await ja()));});});}async function kr(_0x50e6df,_0x1c0eb0,_0x1dde88){const _0x349ab4=Kn(_0x50e6df,!0x0)['put']({[za]:_0x1c0eb0,'value':_0x1dde88});return new Jt(_0x349ab4)['toPromise']();}async function lp(_0x40695f,_0x2b86b8){const _0x137f17=Kn(_0x40695f,!0x1)['get'](_0x2b86b8),_0x24b86d=await new Jt(_0x137f17)['toPromise']();return _0x24b86d===void 0x0?null:_0x24b86d['value'];}function Nr(_0x21209a,_0xb9dba5){const _0x912305=Kn(_0x21209a,!0x0)['delete'](_0xb9dba5);return new Jt(_0x912305)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x253504){let _0x4f6599=0x0;for(;;)try{const _0x287e6a=await this['_openDb']();return await _0x253504(_0x287e6a);}catch(_0x1540f2){if(_0x4f6599++>up)throw _0x1540f2;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1f071c,_0x3bbad4)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3bbad4['key'])})),this['receiver']['_subscribe']('ping',async(_0x453071,_0x3b9d6d)=>['keyChanged']);}async['initializeSender'](){var _0x2dd159,_0x4322ee;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x3ebf56=await this['sender']['_send']('ping',{},0x320);_0x3ebf56&&(_0x2dd159=_0x3ebf56[0x0])!=null&&_0x2dd159['fulfilled']&&(_0x4322ee=_0x3ebf56[0x0])!=null&&_0x4322ee['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2e6152){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2e6152},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4f937f=>{await kr(_0x4f937f,An,'1'),await Nr(_0x4f937f,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x43d1ce){this['pendingWrites']++;try{await _0x43d1ce();}finally{this['pendingWrites']--;}}async['_set'](_0x2dc05b,_0x123a69){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x154fa2=>kr(_0x154fa2,_0x2dc05b,_0x123a69)),this['localCache'][_0x2dc05b]=_0x123a69,this['notifyServiceWorker'](_0x2dc05b)));}async['_get'](_0x486735){const _0x44de2c=await this['_withRetries'](_0x443230=>lp(_0x443230,_0x486735));return this['localCache'][_0x486735]=_0x44de2c,_0x44de2c;}async['_remove'](_0xe5cf1a){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4b98ea=>Nr(_0x4b98ea,_0xe5cf1a)),delete this['localCache'][_0xe5cf1a],this['notifyServiceWorker'](_0xe5cf1a)));}async['_poll'](){const _0x1bdc37=await this['_withRetries'](_0x2b5ecf=>{const _0x22e968=Kn(_0x2b5ecf,!0x1)['getAll']();return new Jt(_0x22e968)['toPromise']();});if(!_0x1bdc37)return[];if(this['pendingWrites']!==0x0)return[];const _0x3d3309=[],_0x2e328b=new Set();if(_0x1bdc37['length']!==0x0){for(const {fbase_key:_0x1943bb,value:_0xf2dcfa}of _0x1bdc37)_0x2e328b['add'](_0x1943bb),JSON['stringify'](this['localCache'][_0x1943bb])!==JSON['stringify'](_0xf2dcfa)&&(this['notifyListeners'](_0x1943bb,_0xf2dcfa),_0x3d3309['push'](_0x1943bb));}for(const _0x40357a of Object['keys'](this['localCache']))this['localCache'][_0x40357a]&&!_0x2e328b['has'](_0x40357a)&&(this['notifyListeners'](_0x40357a,null),_0x3d3309['push'](_0x40357a));return _0x3d3309;}['notifyListeners'](_0x4b42ed,_0x14231b){this['localCache'][_0x4b42ed]=_0x14231b;const _0x44c978=this['listeners'][_0x4b42ed];if(_0x44c978){for(const _0x4c2030 of Array['from'](_0x44c978))_0x4c2030(_0x14231b);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x532259,_0x326705){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x532259]||(this['listeners'][_0x532259]=new Set(),this['_get'](_0x532259)),this['listeners'][_0x532259]['add'](_0x326705);}['_removeListener'](_0x2e330b,_0xe4dfa9){this['listeners'][_0x2e330b]&&(this['listeners'][_0x2e330b]['delete'](_0xe4dfa9),this['listeners'][_0x2e330b]['size']===0x0&&delete this['listeners'][_0x2e330b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x2d3abd,_0x7cf720){return _0x7cf720?ne(_0x7cf720):(m(_0x2d3abd['_popupRedirectResolver'],_0x2d3abd,'argument-error'),_0x2d3abd['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4caa07){super('custom','custom'),this['params']=_0x4caa07;}['_getIdTokenResponse'](_0x18b1fc){return Ze(_0x18b1fc,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4a6177,_0x2e641f){return Ze(_0x4a6177,this['_buildIdpRequest'](_0x2e641f));}['_getReauthenticationResolver'](_0x5b8deb){return Ze(_0x5b8deb,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x130b29){const _0x2548d4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x130b29&&(_0x2548d4['idToken']=_0x130b29),_0x2548d4;}}function pp(_0x25d2f0){return Ua(_0x25d2f0['auth'],new Rs(_0x25d2f0),_0x25d2f0['bypassAuthState']);}function _p(_0x5dec3c){const {auth:_0x1317e6,user:_0x102897}=_0x5dec3c;return m(_0x102897,_0x1317e6,'internal-error'),Kf(_0x102897,new Rs(_0x5dec3c),_0x5dec3c['bypassAuthState']);}async function gp(_0x266573){const {auth:_0x5da47d,user:_0x4dff5d}=_0x266573;return m(_0x4dff5d,_0x5da47d,'internal-error'),jf(_0x4dff5d,new Rs(_0x266573),_0x266573['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5ab066,_0x43d893,_0x1a3062,_0x2545c4,_0x1e5fde=!0x1){this['auth']=_0x5ab066,this['resolver']=_0x1a3062,this['user']=_0x2545c4,this['bypassAuthState']=_0x1e5fde,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x43d893)?_0x43d893:[_0x43d893];}['execute'](){return new Promise(async(_0x2d7c8a,_0x2bbc78)=>{this['pendingPromise']={'resolve':_0x2d7c8a,'reject':_0x2bbc78};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xbe677c){this['reject'](_0xbe677c);}});}async['onAuthEvent'](_0x337f32){const {urlResponse:_0x3239d4,sessionId:_0x5bcfd7,postBody:_0x1b0220,tenantId:_0x596e8d,error:_0x3b0f4b,type:_0x1a8d5}=_0x337f32;if(_0x3b0f4b){this['reject'](_0x3b0f4b);return;}const _0x369c1d={'auth':this['auth'],'requestUri':_0x3239d4,'sessionId':_0x5bcfd7,'tenantId':_0x596e8d||void 0x0,'postBody':_0x1b0220||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1a8d5)(_0x369c1d));}catch(_0x19a49a){this['reject'](_0x19a49a);}}['onError'](_0x2e1788){this['reject'](_0x2e1788);}['getIdpTask'](_0x4aed86){switch(_0x4aed86){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x1a71a8){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1a71a8),this['unregisterAndCleanUp']();}['reject'](_0x35bfa1){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x35bfa1),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0xbfeaf,_0xd92580,_0x4fd8ab,_0x522ab4,_0x3a3689){super(_0xbfeaf,_0xd92580,_0x522ab4,_0x3a3689),this['provider']=_0x4fd8ab,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x5b3145=await this['execute']();return m(_0x5b3145,this['auth'],'internal-error'),_0x5b3145;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4e275d=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4e275d),this['authWindow']['associatedEvent']=_0x4e275d,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2b8771=>{this['reject'](_0x2b8771);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x11dac9=>{_0x11dac9||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x22ea37;return((_0x22ea37=this['authWindow'])==null?void 0x0:_0x22ea37['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2eabfd=()=>{var _0x2f1f5b,_0x56e1ad;if((_0x56e1ad=(_0x2f1f5b=this['authWindow'])==null?void 0x0:_0x2f1f5b['window'])!=null&&_0x56e1ad['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2eabfd,mp['get']());};_0x2eabfd();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x39ba52,_0x285f94,_0x29f646=!0x1){super(_0x39ba52,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x285f94,void 0x0,_0x29f646),this['eventId']=null;}async['execute'](){let _0x520d98=rn['get'](this['auth']['_key']());if(!_0x520d98){try{const _0x40a81d=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x520d98=()=>Promise['resolve'](_0x40a81d);}catch(_0x24d9e6){_0x520d98=()=>Promise['reject'](_0x24d9e6);}rn['set'](this['auth']['_key'](),_0x520d98);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x520d98();}async['onAuthEvent'](_0x169d93){if(_0x169d93['type']==='signInViaRedirect')return super['onAuthEvent'](_0x169d93);if(_0x169d93['type']==='unknown'){this['resolve'](null);return;}if(_0x169d93['eventId']){const _0x41a865=await this['auth']['_redirectUserForId'](_0x169d93['eventId']);if(_0x41a865)return this['user']=_0x41a865,super['onAuthEvent'](_0x169d93);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x5c7a0d,_0x2672a0){const _0x440943=Cp(_0x2672a0),_0x584659=wp(_0x5c7a0d);if(!await _0x584659['_isAvailable']())return!0x1;const _0x4c7b99=await _0x584659['_get'](_0x440943)==='true';return await _0x584659['_remove'](_0x440943),_0x4c7b99;}function Ip(_0x2b5f83,_0x2b7fd3){rn['set'](_0x2b5f83['_key'](),_0x2b7fd3);}function wp(_0x3ea9d4){return ne(_0x3ea9d4['_redirectPersistence']);}function Cp(_0x3cf4d0){return sn(yp,_0x3cf4d0['config']['apiKey'],_0x3cf4d0['name']);}async function Tp(_0x284611,_0x15e5b6,_0x130ec5=!0x1){if(H(_0x284611['app']))return Promise['reject'](se(_0x284611));const _0x530dfc=qe(_0x284611),_0x19b7eb=fp(_0x530dfc,_0x15e5b6),_0x5e786f=await new vp(_0x530dfc,_0x19b7eb,_0x130ec5)['execute']();return _0x5e786f&&!_0x130ec5&&(delete _0x5e786f['user']['_redirectEventId'],await _0x530dfc['_persistUserIfCurrent'](_0x5e786f['user']),await _0x530dfc['_setRedirectUser'](null,_0x15e5b6)),_0x5e786f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x44f26c){this['auth']=_0x44f26c,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x895dc5){this['consumers']['add'](_0x895dc5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x895dc5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x895dc5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x20cca4){this['consumers']['delete'](_0x20cca4);}['onEvent'](_0x17ffde){if(this['hasEventBeenHandled'](_0x17ffde))return!0x1;let _0x23e3a5=!0x1;return this['consumers']['forEach'](_0x4666bd=>{this['isEventForConsumer'](_0x17ffde,_0x4666bd)&&(_0x23e3a5=!0x0,this['sendToConsumer'](_0x17ffde,_0x4666bd),this['saveEventToCache'](_0x17ffde));}),this['hasHandledPotentialRedirect']||!Rp(_0x17ffde)||(this['hasHandledPotentialRedirect']=!0x0,_0x23e3a5||(this['queuedRedirectEvent']=_0x17ffde,_0x23e3a5=!0x0)),_0x23e3a5;}['sendToConsumer'](_0x3dea9c,_0x49055c){var _0x1ab731;if(_0x3dea9c['error']&&!Qa(_0x3dea9c)){const _0x498e2b=((_0x1ab731=_0x3dea9c['error']['code'])==null?void 0x0:_0x1ab731['split']('auth/')[0x1])||'internal-error';_0x49055c['onError'](J(this['auth'],_0x498e2b));}else _0x49055c['onAuthEvent'](_0x3dea9c);}['isEventForConsumer'](_0x14aca6,_0x348333){const _0x450217=_0x348333['eventId']===null||!!_0x14aca6['eventId']&&_0x14aca6['eventId']===_0x348333['eventId'];return _0x348333['filter']['includes'](_0x14aca6['type'])&&_0x450217;}['hasEventBeenHandled'](_0x2db203){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2db203));}['saveEventToCache'](_0x17c278){this['cachedEventUids']['add'](Pr(_0x17c278)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2d9c41){return[_0x2d9c41['type'],_0x2d9c41['eventId'],_0x2d9c41['sessionId'],_0x2d9c41['tenantId']]['filter'](_0x5b0f1e=>_0x5b0f1e)['join']('-');}function Qa({type:_0x10f8a5,error:_0x4fa036}){return _0x10f8a5==='unknown'&&(_0x4fa036==null?void 0x0:_0x4fa036['code'])==='auth/no-auth-event';}function Rp(_0x413f98){switch(_0x413f98['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x413f98);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x201245,_0x571988={}){return Ae(_0x201245,'GET','/v1/projects',_0x571988);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3e7b8d){if(_0x3e7b8d['config']['emulator'])return;const {authorizedDomains:_0x40961e}=await Ap(_0x3e7b8d);for(const _0x4c2b69 of _0x40961e)try{if(Op(_0x4c2b69))return;}catch{}K(_0x3e7b8d,'unauthorized-domain');}function Op(_0x54a43c){const _0x584897=Ni(),{protocol:_0x22a13b,hostname:_0x4e3183}=new URL(_0x584897);if(_0x54a43c['startsWith']('chrome-extension://')){const _0x419dae=new URL(_0x54a43c);return _0x419dae['hostname']===''&&_0x4e3183===''?_0x22a13b==='chrome-extension:'&&_0x54a43c['replace']('chrome-extension://','')===_0x584897['replace']('chrome-extension://',''):_0x22a13b==='chrome-extension:'&&_0x419dae['hostname']===_0x4e3183;}if(!Np['test'](_0x22a13b))return!0x1;if(kp['test'](_0x54a43c))return _0x4e3183===_0x54a43c;const _0x2aaa5d=_0x54a43c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2aaa5d+'|'+_0x2aaa5d+')$','i')['test'](_0x4e3183);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x5f501d=X()['___jsl'];if(_0x5f501d!=null&&_0x5f501d['H']){for(const _0x228a52 of Object['keys'](_0x5f501d['H']))if(_0x5f501d['H'][_0x228a52]['r']=_0x5f501d['H'][_0x228a52]['r']||[],_0x5f501d['H'][_0x228a52]['L']=_0x5f501d['H'][_0x228a52]['L']||[],_0x5f501d['H'][_0x228a52]['r']=[..._0x5f501d['H'][_0x228a52]['L']],_0x5f501d['CP']){for(let _0x1f507e=0x0;_0x1f507e<_0x5f501d['CP']['length'];_0x1f507e++)_0x5f501d['CP'][_0x1f507e]=null;}}}function Mp(_0x1fbd15){return new Promise((_0x85d2e3,_0x55cc2f)=>{var _0x2ba82b,_0x56697c,_0x57c805;function _0x303e38(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x85d2e3(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x55cc2f(J(_0x1fbd15,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x56697c=(_0x2ba82b=X()['gapi'])==null?void 0x0:_0x2ba82b['iframes'])!=null&&_0x56697c['Iframe'])_0x85d2e3(gapi['iframes']['getContext']());else{if((_0x57c805=X()['gapi'])!=null&&_0x57c805['load'])_0x303e38();else{const _0x1f3d77=Nf('iframefcb');return X()[_0x1f3d77]=()=>{gapi['load']?_0x303e38():_0x55cc2f(J(_0x1fbd15,'network-request-failed'));},Da(kf()+'?onload='+_0x1f3d77)['catch'](_0x576f04=>_0x55cc2f(_0x576f04));}}})['catch'](_0x2e5a3f=>{throw on=null,_0x2e5a3f;});}let on=null;function Lp(_0x58fde9){return on=on||Mp(_0x58fde9),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x1a3b19){const _0x4131c9=_0x1a3b19['config'];m(_0x4131c9['authDomain'],_0x1a3b19,'auth-domain-config-required');const _0x241a03=_0x4131c9['emulator']?Is(_0x4131c9,Up):'https://'+_0x1a3b19['config']['authDomain']+'/'+Fp,_0x575d76={'apiKey':_0x4131c9['apiKey'],'appName':_0x1a3b19['name'],'v':ct},_0x4aae87=Bp['get'](_0x1a3b19['config']['apiHost']);_0x4aae87&&(_0x575d76['eid']=_0x4aae87);const _0xa56241=_0x1a3b19['_getFrameworks']();return _0xa56241['length']&&(_0x575d76['fw']=_0xa56241['join'](',')),_0x241a03+'?'+at(_0x575d76)['slice'](0x1);}async function Hp(_0x53a901){const _0x2d32ad=await Lp(_0x53a901),_0x480b99=X()['gapi'];return m(_0x480b99,_0x53a901,'internal-error'),_0x2d32ad['open']({'where':document['body'],'url':Vp(_0x53a901),'messageHandlersFilter':_0x480b99['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0xeab8af=>new Promise(async(_0x3baab3,_0x499072)=>{await _0xeab8af['restyle']({'setHideOnLeave':!0x1});const _0x42740f=J(_0x53a901,'network-request-failed'),_0x2b6f21=X()['setTimeout'](()=>{_0x499072(_0x42740f);},xp['get']());function _0x4a65e8(){X()['clearTimeout'](_0x2b6f21),_0x3baab3(_0xeab8af);}_0xeab8af['ping'](_0x4a65e8)['then'](_0x4a65e8,()=>{_0x499072(_0x42740f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x19172e){this['window']=_0x19172e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x51cfc6,_0x4eb3cd,_0x10783a,_0x1efc66=Gp,_0x9c8303=qp){const _0x51a5c4=Math['max']((window['screen']['availHeight']-_0x9c8303)/0x2,0x0)['toString'](),_0xa8e60d=Math['max']((window['screen']['availWidth']-_0x1efc66)/0x2,0x0)['toString']();let _0x303acb='';const _0x53f3e0={...$p,'width':_0x1efc66['toString'](),'height':_0x9c8303['toString'](),'top':_0x51a5c4,'left':_0xa8e60d},_0xa9c842=W()['toLowerCase']();_0x10783a&&(_0x303acb=ba(_0xa9c842)?zp:_0x10783a),Ta(_0xa9c842)&&(_0x4eb3cd=_0x4eb3cd||jp,_0x53f3e0['scrollbars']='yes');const _0x2bf01e=Object['entries'](_0x53f3e0)['reduce']((_0x4f189f,[_0x98ba84,_0x1925e1])=>''+_0x4f189f+_0x98ba84+'='+_0x1925e1+',','');if(Ef(_0xa9c842)&&_0x303acb!=='_self')return Yp(_0x4eb3cd||'',_0x303acb),new Dr(null);const _0x3d94f9=window['open'](_0x4eb3cd||'',_0x303acb,_0x2bf01e);m(_0x3d94f9,_0x51cfc6,'popup-blocked');try{_0x3d94f9['focus']();}catch{}return new Dr(_0x3d94f9);}function Yp(_0x30b87c,_0x33c387){const _0x268ff0=document['createElement']('a');_0x268ff0['href']=_0x30b87c,_0x268ff0['target']=_0x33c387;const _0x1df7dc=document['createEvent']('MouseEvent');_0x1df7dc['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x268ff0['dispatchEvent'](_0x1df7dc);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x12b9d0,_0x1a62b6,_0x15c244,_0xcec213,_0x55d855,_0x1f0b4c){m(_0x12b9d0['config']['authDomain'],_0x12b9d0,'auth-domain-config-required'),m(_0x12b9d0['config']['apiKey'],_0x12b9d0,'invalid-api-key');const _0x13a2bf={'apiKey':_0x12b9d0['config']['apiKey'],'appName':_0x12b9d0['name'],'authType':_0x15c244,'redirectUrl':_0xcec213,'v':ct,'eventId':_0x55d855};if(_0x1a62b6 instanceof xa){_0x1a62b6['setDefaultLanguage'](_0x12b9d0['languageCode']),_0x13a2bf['providerId']=_0x1a62b6['providerId']||'',hi(_0x1a62b6['getCustomParameters']())||(_0x13a2bf['customParameters']=JSON['stringify'](_0x1a62b6['getCustomParameters']()));for(const [_0x417dcb,_0x43d0e3]of Object['entries']({}))_0x13a2bf[_0x417dcb]=_0x43d0e3;}if(_0x1a62b6 instanceof Qt){const _0x1f36b9=_0x1a62b6['getScopes']()['filter'](_0x488492=>_0x488492!=='');_0x1f36b9['length']>0x0&&(_0x13a2bf['scopes']=_0x1f36b9['join'](','));}_0x12b9d0['tenantId']&&(_0x13a2bf['tid']=_0x12b9d0['tenantId']);const _0x1f8850=_0x13a2bf;for(const _0x2626e9 of Object['keys'](_0x1f8850))_0x1f8850[_0x2626e9]===void 0x0&&delete _0x1f8850[_0x2626e9];const _0x268c29=await _0x12b9d0['_getAppCheckToken'](),_0x23ec7d=_0x268c29?'#'+Xp+'='+encodeURIComponent(_0x268c29):'';return Zp(_0x12b9d0)+'?'+at(_0x1f8850)['slice'](0x1)+_0x23ec7d;}function Zp({config:_0x2b4768}){return _0x2b4768['emulator']?Is(_0x2b4768,Jp):'https://'+_0x2b4768['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x1972cd,_0x9e3960,_0x2d8726,_0x29370f){var _0x3f02db;ae((_0x3f02db=this['eventManagers'][_0x1972cd['_key']()])==null?void 0x0:_0x3f02db['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5a5701=await Mr(_0x1972cd,_0x9e3960,_0x2d8726,Ni(),_0x29370f);return Kp(_0x1972cd,_0x5a5701,bs());}async['_openRedirect'](_0x48c73c,_0x524a39,_0x138c6d,_0x4015eb){await this['_originValidation'](_0x48c73c);const _0x10b52c=await Mr(_0x48c73c,_0x524a39,_0x138c6d,Ni(),_0x4015eb);return ip(_0x10b52c),new Promise(()=>{});}['_initialize'](_0x3bff98){const _0x837384=_0x3bff98['_key']();if(this['eventManagers'][_0x837384]){const {manager:_0x203e3f,promise:_0x3bcfc4}=this['eventManagers'][_0x837384];return _0x203e3f?Promise['resolve'](_0x203e3f):(ae(_0x3bcfc4,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3bcfc4);}const _0x16c218=this['initAndGetManager'](_0x3bff98);return this['eventManagers'][_0x837384]={'promise':_0x16c218},_0x16c218['catch'](()=>{delete this['eventManagers'][_0x837384];}),_0x16c218;}async['initAndGetManager'](_0x489ad2){const _0x31f97a=await Hp(_0x489ad2),_0x4117de=new bp(_0x489ad2);return _0x31f97a['register']('authEvent',_0x1ad43d=>(m(_0x1ad43d==null?void 0x0:_0x1ad43d['authEvent'],_0x489ad2,'invalid-auth-event'),{'status':_0x4117de['onEvent'](_0x1ad43d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x489ad2['_key']()]={'manager':_0x4117de},this['iframes'][_0x489ad2['_key']()]=_0x31f97a,_0x4117de;}['_isIframeWebStorageSupported'](_0x4046c9,_0x45dcf4){this['iframes'][_0x4046c9['_key']()]['send'](li,{'type':li},_0x2468db=>{var _0x4ae14a;const _0x1789a5=(_0x4ae14a=_0x2468db==null?void 0x0:_0x2468db[0x0])==null?void 0x0:_0x4ae14a[li];_0x1789a5!==void 0x0&&_0x45dcf4(!!_0x1789a5),K(_0x4046c9,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4d20ba){const _0x1e2795=_0x4d20ba['_key']();return this['originValidationPromises'][_0x1e2795]||(this['originValidationPromises'][_0x1e2795]=Pp(_0x4d20ba)),this['originValidationPromises'][_0x1e2795];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x18966b){this['auth']=_0x18966b,this['internalListeners']=new Map();}['getUid'](){var _0x42b654;return this['assertAuthConfigured'](),((_0x42b654=this['auth']['currentUser'])==null?void 0x0:_0x42b654['uid'])||null;}async['getToken'](_0x71e920){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x71e920)}:null;}['addAuthTokenListener'](_0x4eb363){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4eb363))return;const _0x261137=this['auth']['onIdTokenChanged'](_0x4ba34d=>{_0x4eb363((_0x4ba34d==null?void 0x0:_0x4ba34d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4eb363,_0x261137),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5ebf67){this['assertAuthConfigured']();const _0x35c8d3=this['internalListeners']['get'](_0x5ebf67);_0x35c8d3&&(this['internalListeners']['delete'](_0x5ebf67),_0x35c8d3(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x39af78){switch(_0x39af78){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x1fd3a5){et(new Me('auth',(_0x445d13,{options:_0x12d73c})=>{const _0x605e53=_0x445d13['getProvider']('app')['getImmediate'](),_0x3892f6=_0x445d13['getProvider']('heartbeat'),_0x5e3336=_0x445d13['getProvider']('app-check-internal'),{apiKey:_0x4f0c82,authDomain:_0x1674e9}=_0x605e53['options'];m(_0x4f0c82&&!_0x4f0c82['includes'](':'),'invalid-api-key',{'appName':_0x605e53['name']});const _0x5940eb={'apiKey':_0x4f0c82,'authDomain':_0x1674e9,'clientPlatform':_0x1fd3a5,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x1fd3a5)},_0x2546b7=new bf(_0x605e53,_0x3892f6,_0x5e3336,_0x5940eb);return Lf(_0x2546b7,_0x12d73c),_0x2546b7;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x293262,_0x273b9b,_0x3a547e)=>{_0x293262['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x269e09=>{const _0x427454=qe(_0x269e09['getProvider']('auth')['getImmediate']());return(_0x2f515b=>new n_(_0x2f515b))(_0x427454);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x1fd3a5)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2bb3b6=>async _0x3c0c19=>{const _0x4712da=_0x3c0c19&&await _0x3c0c19['getIdTokenResult'](),_0x37ab3a=_0x4712da&&(new Date()['getTime']()-Date['parse'](_0x4712da['issuedAtTime']))/0x3e8;if(_0x37ab3a&&_0x37ab3a>o_)return;const _0x2477c9=_0x4712da==null?void 0x0:_0x4712da['token'];Fr!==_0x2477c9&&(Fr=_0x2477c9,await fetch(_0x2bb3b6,{'method':_0x2477c9?'POST':'DELETE','headers':_0x2477c9?{'Authorization':'Bearer\x20'+_0x2477c9}:{}}));};function O_(_0x24a6c2=Qr()){const _0x563347=Ui(_0x24a6c2,'auth');if(_0x563347['isInitialized']())return _0x563347['getImmediate']();const _0x1cb460=Mf(_0x24a6c2,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x17f3d3=Gr('authTokenSyncURL');if(_0x17f3d3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2a7c76=new URL(_0x17f3d3,location['origin']);if(location['origin']===_0x2a7c76['origin']){const _0xf835ee=a_(_0x2a7c76['toString']());Jf(_0x1cb460,_0xf835ee,()=>_0xf835ee(_0x1cb460['currentUser'])),Qf(_0x1cb460,_0x302923=>_0xf835ee(_0x302923));}}const _0xa0935e=Hr('auth');return _0xa0935e&&xf(_0x1cb460,'http://'+_0xa0935e),_0x1cb460;}function c_(){var _0x1c5612;return((_0x1c5612=document['getElementsByTagName']('head'))==null?void 0x0:_0x1c5612[0x0])??document;}Rf({'loadJS'(_0x504e5e){return new Promise((_0x23275e,_0x2985e5)=>{const _0x2e210f=document['createElement']('script');_0x2e210f['setAttribute']('src',_0x504e5e),_0x2e210f['onload']=_0x23275e,_0x2e210f['onerror']=_0x1cd3e1=>{const _0x42dc09=J('internal-error');_0x42dc09['customData']=_0x1cd3e1,_0x2985e5(_0x42dc09);},_0x2e210f['type']='text/javascript',_0x2e210f['charset']='UTF-8',c_()['appendChild'](_0x2e210f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};