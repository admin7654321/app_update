const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1f9dc4,_0x3b080d){if(!_0x1f9dc4)throw ot(_0x3b080d);},ot=function(_0xd2b5cd){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xd2b5cd);},Wr=function(_0x558bc1){const _0x56ae52=[];let _0x2c7fe1=0x0;for(let _0x456564=0x0;_0x456564<_0x558bc1['length'];_0x456564++){let _0x48cc24=_0x558bc1['charCodeAt'](_0x456564);_0x48cc24<0x80?_0x56ae52[_0x2c7fe1++]=_0x48cc24:_0x48cc24<0x800?(_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0x6|0xc0,_0x56ae52[_0x2c7fe1++]=_0x48cc24&0x3f|0x80):(_0x48cc24&0xfc00)===0xd800&&_0x456564+0x1<_0x558bc1['length']&&(_0x558bc1['charCodeAt'](_0x456564+0x1)&0xfc00)===0xdc00?(_0x48cc24=0x10000+((_0x48cc24&0x3ff)<<0xa)+(_0x558bc1['charCodeAt'](++_0x456564)&0x3ff),_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0x12|0xf0,_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0xc&0x3f|0x80,_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0x6&0x3f|0x80,_0x56ae52[_0x2c7fe1++]=_0x48cc24&0x3f|0x80):(_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0xc|0xe0,_0x56ae52[_0x2c7fe1++]=_0x48cc24>>0x6&0x3f|0x80,_0x56ae52[_0x2c7fe1++]=_0x48cc24&0x3f|0x80);}return _0x56ae52;},Za=function(_0x3ba594){const _0x397ef1=[];let _0x14c1ad=0x0,_0x253ec1=0x0;for(;_0x14c1ad<_0x3ba594['length'];){const _0x57da8b=_0x3ba594[_0x14c1ad++];if(_0x57da8b<0x80)_0x397ef1[_0x253ec1++]=String['fromCharCode'](_0x57da8b);else{if(_0x57da8b>0xbf&&_0x57da8b<0xe0){const _0x41ee1d=_0x3ba594[_0x14c1ad++];_0x397ef1[_0x253ec1++]=String['fromCharCode']((_0x57da8b&0x1f)<<0x6|_0x41ee1d&0x3f);}else{if(_0x57da8b>0xef&&_0x57da8b<0x16d){const _0x5c0ac0=_0x3ba594[_0x14c1ad++],_0x18e538=_0x3ba594[_0x14c1ad++],_0x4dd563=_0x3ba594[_0x14c1ad++],_0x11d27e=((_0x57da8b&0x7)<<0x12|(_0x5c0ac0&0x3f)<<0xc|(_0x18e538&0x3f)<<0x6|_0x4dd563&0x3f)-0x10000;_0x397ef1[_0x253ec1++]=String['fromCharCode'](0xd800+(_0x11d27e>>0xa)),_0x397ef1[_0x253ec1++]=String['fromCharCode'](0xdc00+(_0x11d27e&0x3ff));}else{const _0x435b0d=_0x3ba594[_0x14c1ad++],_0x210e64=_0x3ba594[_0x14c1ad++];_0x397ef1[_0x253ec1++]=String['fromCharCode']((_0x57da8b&0xf)<<0xc|(_0x435b0d&0x3f)<<0x6|_0x210e64&0x3f);}}}}return _0x397ef1['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xba8cf6,_0xb72eda){if(!Array['isArray'](_0xba8cf6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x277af3=_0xb72eda?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xc57426=[];for(let _0x5045f3=0x0;_0x5045f3<_0xba8cf6['length'];_0x5045f3+=0x3){const _0x1a40f4=_0xba8cf6[_0x5045f3],_0x3a30cd=_0x5045f3+0x1<_0xba8cf6['length'],_0x3b6c93=_0x3a30cd?_0xba8cf6[_0x5045f3+0x1]:0x0,_0x2f447e=_0x5045f3+0x2<_0xba8cf6['length'],_0x28baa9=_0x2f447e?_0xba8cf6[_0x5045f3+0x2]:0x0,_0x1522a8=_0x1a40f4>>0x2,_0x4ac943=(_0x1a40f4&0x3)<<0x4|_0x3b6c93>>0x4;let _0x277a8b=(_0x3b6c93&0xf)<<0x2|_0x28baa9>>0x6,_0x2e50dc=_0x28baa9&0x3f;_0x2f447e||(_0x2e50dc=0x40,_0x3a30cd||(_0x277a8b=0x40)),_0xc57426['push'](_0x277af3[_0x1522a8],_0x277af3[_0x4ac943],_0x277af3[_0x277a8b],_0x277af3[_0x2e50dc]);}return _0xc57426['join']('');},'encodeString'(_0x4f18df,_0x1c5f7e){return this['HAS_NATIVE_SUPPORT']&&!_0x1c5f7e?btoa(_0x4f18df):this['encodeByteArray'](Wr(_0x4f18df),_0x1c5f7e);},'decodeString'(_0x3039a7,_0x3ba1b4){return this['HAS_NATIVE_SUPPORT']&&!_0x3ba1b4?atob(_0x3039a7):Za(this['decodeStringToByteArray'](_0x3039a7,_0x3ba1b4));},'decodeStringToByteArray'(_0x2be7d7,_0x2e2030){this['init_']();const _0xb56a19=_0x2e2030?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1cddd8=[];for(let _0x38eec8=0x0;_0x38eec8<_0x2be7d7['length'];){const _0x2fcf9f=_0xb56a19[_0x2be7d7['charAt'](_0x38eec8++)],_0x19a835=_0x38eec8<_0x2be7d7['length']?_0xb56a19[_0x2be7d7['charAt'](_0x38eec8)]:0x0;++_0x38eec8;const _0x375ca5=_0x38eec8<_0x2be7d7['length']?_0xb56a19[_0x2be7d7['charAt'](_0x38eec8)]:0x40;++_0x38eec8;const _0x54fbba=_0x38eec8<_0x2be7d7['length']?_0xb56a19[_0x2be7d7['charAt'](_0x38eec8)]:0x40;if(++_0x38eec8,_0x2fcf9f==null||_0x19a835==null||_0x375ca5==null||_0x54fbba==null)throw new ec();const _0x3c3f1c=_0x2fcf9f<<0x2|_0x19a835>>0x4;if(_0x1cddd8['push'](_0x3c3f1c),_0x375ca5!==0x40){const _0x40b79d=_0x19a835<<0x4&0xf0|_0x375ca5>>0x2;if(_0x1cddd8['push'](_0x40b79d),_0x54fbba!==0x40){const _0x3c7b12=_0x375ca5<<0x6&0xc0|_0x54fbba;_0x1cddd8['push'](_0x3c7b12);}}}return _0x1cddd8;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3936aa=0x0;_0x3936aa<this['ENCODED_VALS']['length'];_0x3936aa++)this['byteToCharMap_'][_0x3936aa]=this['ENCODED_VALS']['charAt'](_0x3936aa),this['charToByteMap_'][this['byteToCharMap_'][_0x3936aa]]=_0x3936aa,this['byteToCharMapWebSafe_'][_0x3936aa]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3936aa),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3936aa]]=_0x3936aa,_0x3936aa>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3936aa)]=_0x3936aa,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3936aa)]=_0x3936aa);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x93fc24){const _0x1e4718=Wr(_0x93fc24);return Di['encodeByteArray'](_0x1e4718,!0x0);},an=function(_0x1e7a6f){return Br(_0x1e7a6f)['replace'](/\./g,'');},cn=function(_0x5f2076){try{return Di['decodeString'](_0x5f2076,!0x0);}catch(_0x1e384b){console['error']('base64Decode\x20failed:\x20',_0x1e384b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3f0bfd){return Vr(void 0x0,_0x3f0bfd);}function Vr(_0x1a2535,_0x2fb2a1){if(!(_0x2fb2a1 instanceof Object))return _0x2fb2a1;switch(_0x2fb2a1['constructor']){case Date:const _0x4a931b=_0x2fb2a1;return new Date(_0x4a931b['getTime']());case Object:_0x1a2535===void 0x0&&(_0x1a2535={});break;case Array:_0x1a2535=[];break;default:return _0x2fb2a1;}for(const _0x4150c4 in _0x2fb2a1)!_0x2fb2a1['hasOwnProperty'](_0x4150c4)||!nc(_0x4150c4)||(_0x1a2535[_0x4150c4]=Vr(_0x1a2535[_0x4150c4],_0x2fb2a1[_0x4150c4]));return _0x1a2535;}function nc(_0x360a12){return _0x360a12!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2b2918=As['__FIREBASE_DEFAULTS__'];if(_0x2b2918)return JSON['parse'](_0x2b2918);},oc=()=>{if(typeof document>'u')return;let _0xbbbb06;try{_0xbbbb06=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x37b2d1=_0xbbbb06&&cn(_0xbbbb06[0x1]);return _0x37b2d1&&JSON['parse'](_0x37b2d1);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4cb29d){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4cb29d);return;}},Hr=_0x1a6872=>{var _0x1ccc99,_0x40508e;return(_0x40508e=(_0x1ccc99=Mi())==null?void 0x0:_0x1ccc99['emulatorHosts'])==null?void 0x0:_0x40508e[_0x1a6872];},ac=_0x54d5e9=>{const _0x796fad=Hr(_0x54d5e9);if(!_0x796fad)return;const _0x22ecfa=_0x796fad['lastIndexOf'](':');if(_0x22ecfa<=0x0||_0x22ecfa+0x1===_0x796fad['length'])throw new Error('Invalid\x20host\x20'+_0x796fad+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x15dedb=parseInt(_0x796fad['substring'](_0x22ecfa+0x1),0xa);return _0x796fad[0x0]==='['?[_0x796fad['substring'](0x1,_0x22ecfa-0x1),_0x15dedb]:[_0x796fad['substring'](0x0,_0x22ecfa),_0x15dedb];},$r=()=>{var _0x5b3ff3;return(_0x5b3ff3=Mi())==null?void 0x0:_0x5b3ff3['config'];},Gr=_0x1cd503=>{var _0x1cf18d;return(_0x1cf18d=Mi())==null?void 0x0:_0x1cf18d['_'+_0x1cd503];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4b934f,_0x380abc)=>{this['resolve']=_0x4b934f,this['reject']=_0x380abc;});}['wrapCallback'](_0x2753fa){return(_0x1b3f45,_0x5927c7)=>{_0x1b3f45?this['reject'](_0x1b3f45):this['resolve'](_0x5927c7),typeof _0x2753fa=='function'&&(this['promise']['catch'](()=>{}),_0x2753fa['length']===0x1?_0x2753fa(_0x1b3f45):_0x2753fa(_0x1b3f45,_0x5927c7));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x41bcc5,_0xeb2a01){if(_0x41bcc5['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5e0f71={'alg':'none','type':'JWT'},_0x293f01=_0xeb2a01||'demo-project',_0x57461a=_0x41bcc5['iat']||0x0,_0x300902=_0x41bcc5['sub']||_0x41bcc5['user_id'];if(!_0x300902)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5a0c97={'iss':'https://securetoken.google.com/'+_0x293f01,'aud':_0x293f01,'iat':_0x57461a,'exp':_0x57461a+0xe10,'auth_time':_0x57461a,'sub':_0x300902,'user_id':_0x300902,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x41bcc5};return[an(JSON['stringify'](_0x5e0f71)),an(JSON['stringify'](_0x5a0c97)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4a2dea=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4a2dea=='object'&&_0x4a2dea['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x355357=W();return _0x355357['indexOf']('MSIE\x20')>=0x0||_0x355357['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x30b886,_0xe1564a)=>{try{let _0x5817e5=!0x0;const _0x35d0a8='validate-browser-context-for-indexeddb-analytics-module',_0x1c181d=self['indexedDB']['open'](_0x35d0a8);_0x1c181d['onsuccess']=()=>{_0x1c181d['result']['close'](),_0x5817e5||self['indexedDB']['deleteDatabase'](_0x35d0a8),_0x30b886(!0x0);},_0x1c181d['onupgradeneeded']=()=>{_0x5817e5=!0x1;},_0x1c181d['onerror']=()=>{var _0x31e11b;_0xe1564a(((_0x31e11b=_0x1c181d['error'])==null?void 0x0:_0x31e11b['message'])||'');};}catch(_0x29c1c8){_0xe1564a(_0x29c1c8);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x149416,_0x2260af,_0x4560f0){super(_0x2260af),this['code']=_0x149416,this['customData']=_0x4560f0,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x394d3e,_0x48d66c,_0x436387){this['service']=_0x394d3e,this['serviceName']=_0x48d66c,this['errors']=_0x436387;}['create'](_0x2a3353,..._0x2f8129){const _0x8fbf99=_0x2f8129[0x0]||{},_0x4f4cf1=this['service']+'/'+_0x2a3353,_0x31e58b=this['errors'][_0x2a3353],_0x384a3f=_0x31e58b?gc(_0x31e58b,_0x8fbf99):'Error',_0x57ed42=this['serviceName']+':\x20'+_0x384a3f+'\x20('+_0x4f4cf1+').';return new Se(_0x4f4cf1,_0x57ed42,_0x8fbf99);}}function gc(_0x41f9b6,_0x24eb6a){return _0x41f9b6['replace'](mc,(_0x311831,_0x516075)=>{const _0x272ffb=_0x24eb6a[_0x516075];return _0x272ffb!=null?String(_0x272ffb):'<'+_0x516075+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4dc3ad){return JSON['parse'](_0x4dc3ad);}function O(_0x1924b1){return JSON['stringify'](_0x1924b1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x85aeae){let _0x34a4b5={},_0x25e526={},_0x53bb9c={},_0x24e412='';try{const _0x2ca923=_0x85aeae['split']('.');_0x34a4b5=bt(cn(_0x2ca923[0x0])||''),_0x25e526=bt(cn(_0x2ca923[0x1])||''),_0x24e412=_0x2ca923[0x2],_0x53bb9c=_0x25e526['d']||{},delete _0x25e526['d'];}catch{}return{'header':_0x34a4b5,'claims':_0x25e526,'data':_0x53bb9c,'signature':_0x24e412};},yc=function(_0x43252e){const _0x51bd63=zr(_0x43252e),_0x5d7eea=_0x51bd63['claims'];return!!_0x5d7eea&&typeof _0x5d7eea=='object'&&_0x5d7eea['hasOwnProperty']('iat');},vc=function(_0x4c5c77){const _0x539401=zr(_0x4c5c77)['claims'];return typeof _0x539401=='object'&&_0x539401['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x26d56f,_0x3b0ebc){return Object['prototype']['hasOwnProperty']['call'](_0x26d56f,_0x3b0ebc);}function Oe(_0x3c0991,_0xa9e1c0){if(Object['prototype']['hasOwnProperty']['call'](_0x3c0991,_0xa9e1c0))return _0x3c0991[_0xa9e1c0];}function hi(_0x58aabf){for(const _0xe911a6 in _0x58aabf)if(Object['prototype']['hasOwnProperty']['call'](_0x58aabf,_0xe911a6))return!0x1;return!0x0;}function ln(_0x480bd0,_0x8118b1,_0xcc4e50){const _0x255f9e={};for(const _0x487955 in _0x480bd0)Object['prototype']['hasOwnProperty']['call'](_0x480bd0,_0x487955)&&(_0x255f9e[_0x487955]=_0x8118b1['call'](_0xcc4e50,_0x480bd0[_0x487955],_0x487955,_0x480bd0));return _0x255f9e;}function De(_0xf77e85,_0x45915a){if(_0xf77e85===_0x45915a)return!0x0;const _0x196f49=Object['keys'](_0xf77e85),_0x3d2de3=Object['keys'](_0x45915a);for(const _0x13acbf of _0x196f49){if(!_0x3d2de3['includes'](_0x13acbf))return!0x1;const _0xf34757=_0xf77e85[_0x13acbf],_0x2cfa8d=_0x45915a[_0x13acbf];if(ks(_0xf34757)&&ks(_0x2cfa8d)){if(!De(_0xf34757,_0x2cfa8d))return!0x1;}else{if(_0xf34757!==_0x2cfa8d)return!0x1;}}for(const _0xc69fc3 of _0x3d2de3)if(!_0x196f49['includes'](_0xc69fc3))return!0x1;return!0x0;}function ks(_0x51a841){return _0x51a841!==null&&typeof _0x51a841=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3d81ac){const _0x242431=[];for(const [_0xcd95dd,_0x5df113]of Object['entries'](_0x3d81ac))Array['isArray'](_0x5df113)?_0x5df113['forEach'](_0x50555c=>{_0x242431['push'](encodeURIComponent(_0xcd95dd)+'='+encodeURIComponent(_0x50555c));}):_0x242431['push'](encodeURIComponent(_0xcd95dd)+'='+encodeURIComponent(_0x5df113));return _0x242431['length']?'&'+_0x242431['join']('&'):'';}function yt(_0x218e5b){const _0x436144={};return _0x218e5b['replace'](/^\?/,'')['split']('&')['forEach'](_0x5eae01=>{if(_0x5eae01){const [_0x2aa91b,_0x58b0ec]=_0x5eae01['split']('=');_0x436144[decodeURIComponent(_0x2aa91b)]=decodeURIComponent(_0x58b0ec);}}),_0x436144;}function vt(_0xa20b60){const _0xa290c9=_0xa20b60['indexOf']('?');if(!_0xa290c9)return'';const _0x37722c=_0xa20b60['indexOf']('#',_0xa290c9);return _0xa20b60['substring'](_0xa290c9,_0x37722c>0x0?_0x37722c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5e83c1=0x1;_0x5e83c1<this['blockSize'];++_0x5e83c1)this['pad_'][_0x5e83c1]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2779ee,_0x51fbe4){_0x51fbe4||(_0x51fbe4=0x0);const _0x137768=this['W_'];if(typeof _0x2779ee=='string'){for(let _0x835be3=0x0;_0x835be3<0x10;_0x835be3++)_0x137768[_0x835be3]=_0x2779ee['charCodeAt'](_0x51fbe4)<<0x18|_0x2779ee['charCodeAt'](_0x51fbe4+0x1)<<0x10|_0x2779ee['charCodeAt'](_0x51fbe4+0x2)<<0x8|_0x2779ee['charCodeAt'](_0x51fbe4+0x3),_0x51fbe4+=0x4;}else{for(let _0x2f1242=0x0;_0x2f1242<0x10;_0x2f1242++)_0x137768[_0x2f1242]=_0x2779ee[_0x51fbe4]<<0x18|_0x2779ee[_0x51fbe4+0x1]<<0x10|_0x2779ee[_0x51fbe4+0x2]<<0x8|_0x2779ee[_0x51fbe4+0x3],_0x51fbe4+=0x4;}for(let _0x51f1b8=0x10;_0x51f1b8<0x50;_0x51f1b8++){const _0x42688a=_0x137768[_0x51f1b8-0x3]^_0x137768[_0x51f1b8-0x8]^_0x137768[_0x51f1b8-0xe]^_0x137768[_0x51f1b8-0x10];_0x137768[_0x51f1b8]=(_0x42688a<<0x1|_0x42688a>>>0x1f)&0xffffffff;}let _0x13d6d4=this['chain_'][0x0],_0xae4e3c=this['chain_'][0x1],_0x52d69e=this['chain_'][0x2],_0x480ff4=this['chain_'][0x3],_0x4192fb=this['chain_'][0x4],_0x46df50,_0x268fbd;for(let _0x5c9ad5=0x0;_0x5c9ad5<0x50;_0x5c9ad5++){_0x5c9ad5<0x28?_0x5c9ad5<0x14?(_0x46df50=_0x480ff4^_0xae4e3c&(_0x52d69e^_0x480ff4),_0x268fbd=0x5a827999):(_0x46df50=_0xae4e3c^_0x52d69e^_0x480ff4,_0x268fbd=0x6ed9eba1):_0x5c9ad5<0x3c?(_0x46df50=_0xae4e3c&_0x52d69e|_0x480ff4&(_0xae4e3c|_0x52d69e),_0x268fbd=0x8f1bbcdc):(_0x46df50=_0xae4e3c^_0x52d69e^_0x480ff4,_0x268fbd=0xca62c1d6);const _0xfd0275=(_0x13d6d4<<0x5|_0x13d6d4>>>0x1b)+_0x46df50+_0x4192fb+_0x268fbd+_0x137768[_0x5c9ad5]&0xffffffff;_0x4192fb=_0x480ff4,_0x480ff4=_0x52d69e,_0x52d69e=(_0xae4e3c<<0x1e|_0xae4e3c>>>0x2)&0xffffffff,_0xae4e3c=_0x13d6d4,_0x13d6d4=_0xfd0275;}this['chain_'][0x0]=this['chain_'][0x0]+_0x13d6d4&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xae4e3c&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52d69e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x480ff4&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4192fb&0xffffffff;}['update'](_0x117289,_0x130506){if(_0x117289==null)return;_0x130506===void 0x0&&(_0x130506=_0x117289['length']);const _0x67bfb3=_0x130506-this['blockSize'];let _0x413f8d=0x0;const _0x58f912=this['buf_'];let _0x34e7dc=this['inbuf_'];for(;_0x413f8d<_0x130506;){if(_0x34e7dc===0x0){for(;_0x413f8d<=_0x67bfb3;)this['compress_'](_0x117289,_0x413f8d),_0x413f8d+=this['blockSize'];}if(typeof _0x117289=='string'){for(;_0x413f8d<_0x130506;)if(_0x58f912[_0x34e7dc]=_0x117289['charCodeAt'](_0x413f8d),++_0x34e7dc,++_0x413f8d,_0x34e7dc===this['blockSize']){this['compress_'](_0x58f912),_0x34e7dc=0x0;break;}}else{for(;_0x413f8d<_0x130506;)if(_0x58f912[_0x34e7dc]=_0x117289[_0x413f8d],++_0x34e7dc,++_0x413f8d,_0x34e7dc===this['blockSize']){this['compress_'](_0x58f912),_0x34e7dc=0x0;break;}}}this['inbuf_']=_0x34e7dc,this['total_']+=_0x130506;}['digest'](){const _0x5f588b=[];let _0x2b3cfd=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x32a6bb=this['blockSize']-0x1;_0x32a6bb>=0x38;_0x32a6bb--)this['buf_'][_0x32a6bb]=_0x2b3cfd&0xff,_0x2b3cfd/=0x100;this['compress_'](this['buf_']);let _0x4d989c=0x0;for(let _0xfff02e=0x0;_0xfff02e<0x5;_0xfff02e++)for(let _0x466652=0x18;_0x466652>=0x0;_0x466652-=0x8)_0x5f588b[_0x4d989c]=this['chain_'][_0xfff02e]>>_0x466652&0xff,++_0x4d989c;return _0x5f588b;}}function Ic(_0x110985,_0x13efa8){const _0x306fb2=new wc(_0x110985,_0x13efa8);return _0x306fb2['subscribe']['bind'](_0x306fb2);}class wc{constructor(_0x273226,_0x444f12){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x444f12,this['task']['then'](()=>{_0x273226(this);})['catch'](_0x51750a=>{this['error'](_0x51750a);});}['next'](_0x403dba){this['forEachObserver'](_0x84ab36=>{_0x84ab36['next'](_0x403dba);});}['error'](_0x1af4d4){this['forEachObserver'](_0x46561f=>{_0x46561f['error'](_0x1af4d4);}),this['close'](_0x1af4d4);}['complete'](){this['forEachObserver'](_0x203ca0=>{_0x203ca0['complete']();}),this['close']();}['subscribe'](_0x40296a,_0x4c8bba,_0x470a76){let _0x46446f;if(_0x40296a===void 0x0&&_0x4c8bba===void 0x0&&_0x470a76===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x40296a,['next','error','complete'])?_0x46446f=_0x40296a:_0x46446f={'next':_0x40296a,'error':_0x4c8bba,'complete':_0x470a76},_0x46446f['next']===void 0x0&&(_0x46446f['next']=Qn),_0x46446f['error']===void 0x0&&(_0x46446f['error']=Qn),_0x46446f['complete']===void 0x0&&(_0x46446f['complete']=Qn);const _0x1a955f=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x46446f['error'](this['finalError']):_0x46446f['complete']();}catch{}}),this['observers']['push'](_0x46446f),_0x1a955f;}['unsubscribeOne'](_0x2b067b){this['observers']===void 0x0||this['observers'][_0x2b067b]===void 0x0||(delete this['observers'][_0x2b067b],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3d8527){if(!this['finalized']){for(let _0x178270=0x0;_0x178270<this['observers']['length'];_0x178270++)this['sendOne'](_0x178270,_0x3d8527);}}['sendOne'](_0xa2c224,_0x43f876){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xa2c224]!==void 0x0)try{_0x43f876(this['observers'][_0xa2c224]);}catch(_0x32eee2){typeof console<'u'&&console['error']&&console['error'](_0x32eee2);}});}['close'](_0x224f2f){this['finalized']||(this['finalized']=!0x0,_0x224f2f!==void 0x0&&(this['finalError']=_0x224f2f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x32c395,_0x5db2e7){if(typeof _0x32c395!='object'||_0x32c395===null)return!0x1;for(const _0x202eae of _0x5db2e7)if(_0x202eae in _0x32c395&&typeof _0x32c395[_0x202eae]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x56f3fe,_0x10752c){return _0x56f3fe+'\x20failed:\x20'+_0x10752c+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x241872){const _0x527d40=[];let _0x2cc8c3=0x0;for(let _0x3d4c61=0x0;_0x3d4c61<_0x241872['length'];_0x3d4c61++){let _0x2c3b36=_0x241872['charCodeAt'](_0x3d4c61);if(_0x2c3b36>=0xd800&&_0x2c3b36<=0xdbff){const _0x5d393e=_0x2c3b36-0xd800;_0x3d4c61++,f(_0x3d4c61<_0x241872['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x44756d=_0x241872['charCodeAt'](_0x3d4c61)-0xdc00;_0x2c3b36=0x10000+(_0x5d393e<<0xa)+_0x44756d;}_0x2c3b36<0x80?_0x527d40[_0x2cc8c3++]=_0x2c3b36:_0x2c3b36<0x800?(_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0x6|0xc0,_0x527d40[_0x2cc8c3++]=_0x2c3b36&0x3f|0x80):_0x2c3b36<0x10000?(_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0xc|0xe0,_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0x6&0x3f|0x80,_0x527d40[_0x2cc8c3++]=_0x2c3b36&0x3f|0x80):(_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0x12|0xf0,_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0xc&0x3f|0x80,_0x527d40[_0x2cc8c3++]=_0x2c3b36>>0x6&0x3f|0x80,_0x527d40[_0x2cc8c3++]=_0x2c3b36&0x3f|0x80);}return _0x527d40;},Pn=function(_0x1c0afc){let _0x466b13=0x0;for(let _0xd228e6=0x0;_0xd228e6<_0x1c0afc['length'];_0xd228e6++){const _0x23e13a=_0x1c0afc['charCodeAt'](_0xd228e6);_0x23e13a<0x80?_0x466b13++:_0x23e13a<0x800?_0x466b13+=0x2:_0x23e13a>=0xd800&&_0x23e13a<=0xdbff?(_0x466b13+=0x4,_0xd228e6++):_0x466b13+=0x3;}return _0x466b13;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x3be362){return _0x3be362&&_0x3be362['_delegate']?_0x3be362['_delegate']:_0x3be362;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x349df7){try{return(_0x349df7['startsWith']('http://')||_0x349df7['startsWith']('https://')?new URL(_0x349df7)['hostname']:_0x349df7)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3f577c){return(await fetch(_0x3f577c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x483588,_0x3dd424,_0x2b376b){this['name']=_0x483588,this['instanceFactory']=_0x3dd424,this['type']=_0x2b376b,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x25b97b){return this['instantiationMode']=_0x25b97b,this;}['setMultipleInstances'](_0x48223c){return this['multipleInstances']=_0x48223c,this;}['setServiceProps'](_0x4ad378){return this['serviceProps']=_0x4ad378,this;}['setInstanceCreatedCallback'](_0x1b40cc){return this['onInstanceCreated']=_0x1b40cc,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x5f3957,_0x3fde07){this['name']=_0x5f3957,this['container']=_0x3fde07,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5828e4){const _0x29db30=this['normalizeInstanceIdentifier'](_0x5828e4);if(!this['instancesDeferred']['has'](_0x29db30)){const _0x3de922=new Ve();if(this['instancesDeferred']['set'](_0x29db30,_0x3de922),this['isInitialized'](_0x29db30)||this['shouldAutoInitialize']())try{const _0x965e70=this['getOrInitializeService']({'instanceIdentifier':_0x29db30});_0x965e70&&_0x3de922['resolve'](_0x965e70);}catch{}}return this['instancesDeferred']['get'](_0x29db30)['promise'];}['getImmediate'](_0x4e23b9){const _0x14000d=this['normalizeInstanceIdentifier'](_0x4e23b9==null?void 0x0:_0x4e23b9['identifier']),_0x3c03dc=(_0x4e23b9==null?void 0x0:_0x4e23b9['optional'])??!0x1;if(this['isInitialized'](_0x14000d)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x14000d});}catch(_0x5ca5b9){if(_0x3c03dc)return null;throw _0x5ca5b9;}else{if(_0x3c03dc)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3bf499){if(_0x3bf499['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3bf499['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3bf499,!!this['shouldAutoInitialize']()){if(Rc(_0x3bf499))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x4f7625,_0x118b29]of this['instancesDeferred']['entries']()){const _0x53d88f=this['normalizeInstanceIdentifier'](_0x4f7625);try{const _0x2b51a9=this['getOrInitializeService']({'instanceIdentifier':_0x53d88f});_0x118b29['resolve'](_0x2b51a9);}catch{}}}}['clearInstance'](_0x18bb42=ke){this['instancesDeferred']['delete'](_0x18bb42),this['instancesOptions']['delete'](_0x18bb42),this['instances']['delete'](_0x18bb42);}async['delete'](){const _0x4c11c5=Array['from'](this['instances']['values']());await Promise['all']([..._0x4c11c5['filter'](_0x2beec6=>'INTERNAL'in _0x2beec6)['map'](_0x77409=>_0x77409['INTERNAL']['delete']()),..._0x4c11c5['filter'](_0x59d482=>'_delete'in _0x59d482)['map'](_0x1b2f6c=>_0x1b2f6c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4348e5=ke){return this['instances']['has'](_0x4348e5);}['getOptions'](_0x5dc9a5=ke){return this['instancesOptions']['get'](_0x5dc9a5)||{};}['initialize'](_0x1bbefd={}){const {options:_0x1cf6fb={}}=_0x1bbefd,_0x16c00c=this['normalizeInstanceIdentifier'](_0x1bbefd['instanceIdentifier']);if(this['isInitialized'](_0x16c00c))throw Error(this['name']+'('+_0x16c00c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x987523=this['getOrInitializeService']({'instanceIdentifier':_0x16c00c,'options':_0x1cf6fb});for(const [_0x19eb22,_0x4cb479]of this['instancesDeferred']['entries']()){const _0x5a0d92=this['normalizeInstanceIdentifier'](_0x19eb22);_0x16c00c===_0x5a0d92&&_0x4cb479['resolve'](_0x987523);}return _0x987523;}['onInit'](_0x16cedb,_0x5021aa){const _0x570ce8=this['normalizeInstanceIdentifier'](_0x5021aa),_0x48f124=this['onInitCallbacks']['get'](_0x570ce8)??new Set();_0x48f124['add'](_0x16cedb),this['onInitCallbacks']['set'](_0x570ce8,_0x48f124);const _0x442fab=this['instances']['get'](_0x570ce8);return _0x442fab&&_0x16cedb(_0x442fab,_0x570ce8),()=>{_0x48f124['delete'](_0x16cedb);};}['invokeOnInitCallbacks'](_0x158a47,_0x3e39d0){const _0x245df3=this['onInitCallbacks']['get'](_0x3e39d0);if(_0x245df3){for(const _0x4885cb of _0x245df3)try{_0x4885cb(_0x158a47,_0x3e39d0);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5e0ca2,options:_0x40dc3f={}}){let _0x434d51=this['instances']['get'](_0x5e0ca2);if(!_0x434d51&&this['component']&&(_0x434d51=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5e0ca2),'options':_0x40dc3f}),this['instances']['set'](_0x5e0ca2,_0x434d51),this['instancesOptions']['set'](_0x5e0ca2,_0x40dc3f),this['invokeOnInitCallbacks'](_0x434d51,_0x5e0ca2),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5e0ca2,_0x434d51);}catch{}return _0x434d51||null;}['normalizeInstanceIdentifier'](_0x571d34=ke){return this['component']?this['component']['multipleInstances']?_0x571d34:ke:_0x571d34;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x112005){return _0x112005===ke?void 0x0:_0x112005;}function Rc(_0x4522b1){return _0x4522b1['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2815b4){this['name']=_0x2815b4,this['providers']=new Map();}['addComponent'](_0x182d8d){const _0x47602b=this['getProvider'](_0x182d8d['name']);if(_0x47602b['isComponentSet']())throw new Error('Component\x20'+_0x182d8d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x47602b['setComponent'](_0x182d8d);}['addOrOverwriteComponent'](_0x47e6a5){this['getProvider'](_0x47e6a5['name'])['isComponentSet']()&&this['providers']['delete'](_0x47e6a5['name']),this['addComponent'](_0x47e6a5);}['getProvider'](_0x152b77){if(this['providers']['has'](_0x152b77))return this['providers']['get'](_0x152b77);const _0x52a01d=new Sc(_0x152b77,this);return this['providers']['set'](_0x152b77,_0x52a01d),_0x52a01d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x358253){_0x358253[_0x358253['DEBUG']=0x0]='DEBUG',_0x358253[_0x358253['VERBOSE']=0x1]='VERBOSE',_0x358253[_0x358253['INFO']=0x2]='INFO',_0x358253[_0x358253['WARN']=0x3]='WARN',_0x358253[_0x358253['ERROR']=0x4]='ERROR',_0x358253[_0x358253['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x16cf73,_0x10000b,..._0x325bc0)=>{if(_0x10000b<_0x16cf73['logLevel'])return;const _0x3b5414=new Date()['toISOString'](),_0x8b0582=Pc[_0x10000b];if(_0x8b0582)console[_0x8b0582]('['+_0x3b5414+']\x20\x20'+_0x16cf73['name']+':',..._0x325bc0);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x10000b+')');};class xi{constructor(_0x410f27){this['name']=_0x410f27,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x41d672){if(!(_0x41d672 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x41d672+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x41d672;}['setLogLevel'](_0x333411){this['_logLevel']=typeof _0x333411=='string'?kc[_0x333411]:_0x333411;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x302ca5){if(typeof _0x302ca5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x302ca5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4f4835){this['_userLogHandler']=_0x4f4835;}['debug'](..._0x2e39a3){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2e39a3),this['_logHandler'](this,T['DEBUG'],..._0x2e39a3);}['log'](..._0x18449a){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x18449a),this['_logHandler'](this,T['VERBOSE'],..._0x18449a);}['info'](..._0x57045c){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x57045c),this['_logHandler'](this,T['INFO'],..._0x57045c);}['warn'](..._0x2d3090){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2d3090),this['_logHandler'](this,T['WARN'],..._0x2d3090);}['error'](..._0x491b3b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x491b3b),this['_logHandler'](this,T['ERROR'],..._0x491b3b);}}const Dc=(_0x2de9a8,_0x554705)=>_0x554705['some'](_0x4bf001=>_0x2de9a8 instanceof _0x4bf001);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x4d257e){const _0x3518e2=new Promise((_0x26f50b,_0x3d7fe1)=>{const _0x1af047=()=>{_0x4d257e['removeEventListener']('success',_0x1c2d05),_0x4d257e['removeEventListener']('error',_0x232295);},_0x1c2d05=()=>{_0x26f50b(_e(_0x4d257e['result'])),_0x1af047();},_0x232295=()=>{_0x3d7fe1(_0x4d257e['error']),_0x1af047();};_0x4d257e['addEventListener']('success',_0x1c2d05),_0x4d257e['addEventListener']('error',_0x232295);});return _0x3518e2['then'](_0x570462=>{_0x570462 instanceof IDBCursor&&Kr['set'](_0x570462,_0x4d257e);})['catch'](()=>{}),Fi['set'](_0x3518e2,_0x4d257e),_0x3518e2;}function Fc(_0xcc06e2){if(ui['has'](_0xcc06e2))return;const _0x1d0500=new Promise((_0x439bd9,_0x2cf03b)=>{const _0x4c7ebb=()=>{_0xcc06e2['removeEventListener']('complete',_0x3b7374),_0xcc06e2['removeEventListener']('error',_0x154f8e),_0xcc06e2['removeEventListener']('abort',_0x154f8e);},_0x3b7374=()=>{_0x439bd9(),_0x4c7ebb();},_0x154f8e=()=>{_0x2cf03b(_0xcc06e2['error']||new DOMException('AbortError','AbortError')),_0x4c7ebb();};_0xcc06e2['addEventListener']('complete',_0x3b7374),_0xcc06e2['addEventListener']('error',_0x154f8e),_0xcc06e2['addEventListener']('abort',_0x154f8e);});ui['set'](_0xcc06e2,_0x1d0500);}let di={'get'(_0x1c3a31,_0x53ec66,_0x492a17){if(_0x1c3a31 instanceof IDBTransaction){if(_0x53ec66==='done')return ui['get'](_0x1c3a31);if(_0x53ec66==='objectStoreNames')return _0x1c3a31['objectStoreNames']||Yr['get'](_0x1c3a31);if(_0x53ec66==='store')return _0x492a17['objectStoreNames'][0x1]?void 0x0:_0x492a17['objectStore'](_0x492a17['objectStoreNames'][0x0]);}return _e(_0x1c3a31[_0x53ec66]);},'set'(_0x41ebad,_0x36d975,_0x27eabb){return _0x41ebad[_0x36d975]=_0x27eabb,!0x0;},'has'(_0x498e4b,_0x512855){return _0x498e4b instanceof IDBTransaction&&(_0x512855==='done'||_0x512855==='store')?!0x0:_0x512855 in _0x498e4b;}};function Uc(_0x3538fc){di=_0x3538fc(di);}function Wc(_0x325f6b){return _0x325f6b===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2681df,..._0x33dbe3){const _0x532185=_0x325f6b['call'](Xn(this),_0x2681df,..._0x33dbe3);return Yr['set'](_0x532185,_0x2681df['sort']?_0x2681df['sort']():[_0x2681df]),_e(_0x532185);}:Lc()['includes'](_0x325f6b)?function(..._0xb81a46){return _0x325f6b['apply'](Xn(this),_0xb81a46),_e(Kr['get'](this));}:function(..._0x596223){return _e(_0x325f6b['apply'](Xn(this),_0x596223));};}function Bc(_0xb95d88){return typeof _0xb95d88=='function'?Wc(_0xb95d88):(_0xb95d88 instanceof IDBTransaction&&Fc(_0xb95d88),Dc(_0xb95d88,Mc())?new Proxy(_0xb95d88,di):_0xb95d88);}function _e(_0x56e209){if(_0x56e209 instanceof IDBRequest)return xc(_0x56e209);if(Jn['has'](_0x56e209))return Jn['get'](_0x56e209);const _0x1427ad=Bc(_0x56e209);return _0x1427ad!==_0x56e209&&(Jn['set'](_0x56e209,_0x1427ad),Fi['set'](_0x1427ad,_0x56e209)),_0x1427ad;}const Xn=_0x2bf817=>Fi['get'](_0x2bf817);function Vc(_0x1696d7,_0x5c2011,{blocked:_0x49e8f6,upgrade:_0x303d1b,blocking:_0x422f82,terminated:_0x34c5d9}={}){const _0x4cef40=indexedDB['open'](_0x1696d7,_0x5c2011),_0x3c246d=_e(_0x4cef40);return _0x303d1b&&_0x4cef40['addEventListener']('upgradeneeded',_0x13209b=>{_0x303d1b(_e(_0x4cef40['result']),_0x13209b['oldVersion'],_0x13209b['newVersion'],_e(_0x4cef40['transaction']),_0x13209b);}),_0x49e8f6&&_0x4cef40['addEventListener']('blocked',_0x3e571b=>_0x49e8f6(_0x3e571b['oldVersion'],_0x3e571b['newVersion'],_0x3e571b)),_0x3c246d['then'](_0x542d81=>{_0x34c5d9&&_0x542d81['addEventListener']('close',()=>_0x34c5d9()),_0x422f82&&_0x542d81['addEventListener']('versionchange',_0x2affb9=>_0x422f82(_0x2affb9['oldVersion'],_0x2affb9['newVersion'],_0x2affb9));})['catch'](()=>{}),_0x3c246d;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x29d0e2,_0x34d169){if(!(_0x29d0e2 instanceof IDBDatabase&&!(_0x34d169 in _0x29d0e2)&&typeof _0x34d169=='string'))return;if(Zn['get'](_0x34d169))return Zn['get'](_0x34d169);const _0x794cc6=_0x34d169['replace'](/FromIndex$/,''),_0x4f7ce5=_0x34d169!==_0x794cc6,_0x144162=$c['includes'](_0x794cc6);if(!(_0x794cc6 in(_0x4f7ce5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x144162||Hc['includes'](_0x794cc6)))return;const _0x1415dd=async function(_0x4d781b,..._0x587b8b){const _0x17fc6e=this['transaction'](_0x4d781b,_0x144162?'readwrite':'readonly');let _0x2e93f1=_0x17fc6e['store'];return _0x4f7ce5&&(_0x2e93f1=_0x2e93f1['index'](_0x587b8b['shift']())),(await Promise['all']([_0x2e93f1[_0x794cc6](..._0x587b8b),_0x144162&&_0x17fc6e['done']]))[0x0];};return Zn['set'](_0x34d169,_0x1415dd),_0x1415dd;}Uc(_0x2bfae1=>({..._0x2bfae1,'get':(_0x34c45e,_0x4d2675,_0x144229)=>Os(_0x34c45e,_0x4d2675)||_0x2bfae1['get'](_0x34c45e,_0x4d2675,_0x144229),'has':(_0x2e012f,_0x30aa9d)=>!!Os(_0x2e012f,_0x30aa9d)||_0x2bfae1['has'](_0x2e012f,_0x30aa9d)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x203d37){this['container']=_0x203d37;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1567dc=>{if(qc(_0x1567dc)){const _0x567bbc=_0x1567dc['getImmediate']();return _0x567bbc['library']+'/'+_0x567bbc['version'];}else return null;})['filter'](_0x44360d=>_0x44360d)['join']('\x20');}}function qc(_0x265470){const _0x10dc9d=_0x265470['getComponent']();return(_0x10dc9d==null?void 0x0:_0x10dc9d['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4461d8,_0x1facdc){try{_0x4461d8['container']['addComponent'](_0x1facdc);}catch(_0x1629ec){re['debug']('Component\x20'+_0x1facdc['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4461d8['name'],_0x1629ec);}}function et(_0x494e50){const _0x9faacd=_0x494e50['name'];if(gi['has'](_0x9faacd))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x9faacd+'.'),!0x1;gi['set'](_0x9faacd,_0x494e50);for(const _0x19a1b9 of Le['values']())Ms(_0x19a1b9,_0x494e50);for(const _0x56800b of _i['values']())Ms(_0x56800b,_0x494e50);return!0x0;}function Ui(_0x3d9076,_0x976c46){const _0x10a6aa=_0x3d9076['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x10a6aa&&_0x10a6aa['triggerHeartbeat'](),_0x3d9076['container']['getProvider'](_0x976c46);}function H(_0x572e3c){return _0x572e3c==null?!0x1:_0x572e3c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0xd75ddb,_0x45b844,_0x42d0d3){this['_isDeleted']=!0x1,this['_options']={..._0xd75ddb},this['_config']={..._0x45b844},this['_name']=_0x45b844['name'],this['_automaticDataCollectionEnabled']=_0x45b844['automaticDataCollectionEnabled'],this['_container']=_0x42d0d3,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4a34e6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4a34e6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x216c26){this['_isDeleted']=_0x216c26;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x33f338,_0xc79c9e={}){let _0x5438ab=_0x33f338;typeof _0xc79c9e!='object'&&(_0xc79c9e={'name':_0xc79c9e});const _0x3c0c36={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0xc79c9e},_0x385b4f=_0x3c0c36['name'];if(typeof _0x385b4f!='string'||!_0x385b4f)throw ge['create']('bad-app-name',{'appName':String(_0x385b4f)});if(_0x5438ab||(_0x5438ab=$r()),!_0x5438ab)throw ge['create']('no-options');const _0x38d2c3=Le['get'](_0x385b4f);if(_0x38d2c3){if(De(_0x5438ab,_0x38d2c3['options'])&&De(_0x3c0c36,_0x38d2c3['config']))return _0x38d2c3;throw ge['create']('duplicate-app',{'appName':_0x385b4f});}const _0x3d78a1=new Ac(_0x385b4f);for(const _0x494162 of gi['values']())_0x3d78a1['addComponent'](_0x494162);const _0x81d67b=new Il(_0x5438ab,_0x3c0c36,_0x3d78a1);return Le['set'](_0x385b4f,_0x81d67b),_0x81d67b;}function Qr(_0x138c21=pi){const _0xf77159=Le['get'](_0x138c21);if(!_0xf77159&&_0x138c21===pi&&$r())return wl();if(!_0xf77159)throw ge['create']('no-app',{'appName':_0x138c21});return _0xf77159;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5b6265){let _0x1fb82b=!0x1;const _0x559466=_0x5b6265['name'];Le['has'](_0x559466)?(_0x1fb82b=!0x0,Le['delete'](_0x559466)):_i['has'](_0x559466)&&_0x5b6265['decRefCount']()<=0x0&&(_i['delete'](_0x559466),_0x1fb82b=!0x0),_0x1fb82b&&(await Promise['all'](_0x5b6265['container']['getProviders']()['map'](_0x19558f=>_0x19558f['delete']())),_0x5b6265['isDeleted']=!0x0);}function me(_0x50bb9c,_0x545cb5,_0x5d71bd){let _0x57486c=vl[_0x50bb9c]??_0x50bb9c;_0x5d71bd&&(_0x57486c+='-'+_0x5d71bd);const _0x35a5a8=_0x57486c['match'](/\s|\//),_0x20d95f=_0x545cb5['match'](/\s|\//);if(_0x35a5a8||_0x20d95f){const _0x1a237b=['Unable\x20to\x20register\x20library\x20\x22'+_0x57486c+'\x22\x20with\x20version\x20\x22'+_0x545cb5+'\x22:'];_0x35a5a8&&_0x1a237b['push']('library\x20name\x20\x22'+_0x57486c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x35a5a8&&_0x20d95f&&_0x1a237b['push']('and'),_0x20d95f&&_0x1a237b['push']('version\x20name\x20\x22'+_0x545cb5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x1a237b['join']('\x20'));return;}et(new Me(_0x57486c+'-version',()=>({'library':_0x57486c,'version':_0x545cb5}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x60e41b,_0x5dfd47)=>{switch(_0x5dfd47){case 0x0:try{_0x60e41b['createObjectStore'](Rt);}catch(_0x135a6a){console['warn'](_0x135a6a);}}}})['catch'](_0xd2b68c=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xd2b68c['message']});})),ei;}async function Sl(_0x46fed1){try{const _0xc1f1b0=(await Jr())['transaction'](Rt),_0x4f5095=await _0xc1f1b0['objectStore'](Rt)['get'](Xr(_0x46fed1));return await _0xc1f1b0['done'],_0x4f5095;}catch(_0x7b3d93){if(_0x7b3d93 instanceof Se)re['warn'](_0x7b3d93['message']);else{const _0x52b450=ge['create']('idb-get',{'originalErrorMessage':_0x7b3d93==null?void 0x0:_0x7b3d93['message']});re['warn'](_0x52b450['message']);}}}async function Ls(_0x349662,_0x1c482b){try{const _0x357f5e=(await Jr())['transaction'](Rt,'readwrite');await _0x357f5e['objectStore'](Rt)['put'](_0x1c482b,Xr(_0x349662)),await _0x357f5e['done'];}catch(_0x1dc227){if(_0x1dc227 instanceof Se)re['warn'](_0x1dc227['message']);else{const _0x1cb2bf=ge['create']('idb-set',{'originalErrorMessage':_0x1dc227==null?void 0x0:_0x1dc227['message']});re['warn'](_0x1cb2bf['message']);}}}function Xr(_0x12adce){return _0x12adce['name']+'!'+_0x12adce['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x946d9a){this['container']=_0x946d9a,this['_heartbeatsCache']=null;const _0x2456f9=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2456f9),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x896af=>(this['_heartbeatsCache']=_0x896af,_0x896af));}async['triggerHeartbeat'](){var _0x1d1ad5,_0x1305fc;try{const _0x12c849=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1e2bb8=xs();if(((_0x1d1ad5=this['_heartbeatsCache'])==null?void 0x0:_0x1d1ad5['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1305fc=this['_heartbeatsCache'])==null?void 0x0:_0x1305fc['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1e2bb8||this['_heartbeatsCache']['heartbeats']['some'](_0xd7b15e=>_0xd7b15e['date']===_0x1e2bb8))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1e2bb8,'agent':_0x12c849}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1ca7df=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1ca7df,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1e62f8){re['warn'](_0x1e62f8);}}async['getHeartbeatsHeader'](){var _0x4ee205;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4ee205=this['_heartbeatsCache'])==null?void 0x0:_0x4ee205['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x71e930=xs(),{heartbeatsToSend:_0x3d9959,unsentEntries:_0xc48da4}=kl(this['_heartbeatsCache']['heartbeats']),_0x36a4ff=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3d9959}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x71e930,_0xc48da4['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xc48da4,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x36a4ff;}catch(_0x2dcc7c){return re['warn'](_0x2dcc7c),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x220d8e,_0x531c60=bl){const _0x46018a=[];let _0x402247=_0x220d8e['slice']();for(const _0xb98b3f of _0x220d8e){const _0x2e63d2=_0x46018a['find'](_0x44d8b1=>_0x44d8b1['agent']===_0xb98b3f['agent']);if(_0x2e63d2){if(_0x2e63d2['dates']['push'](_0xb98b3f['date']),Fs(_0x46018a)>_0x531c60){_0x2e63d2['dates']['pop']();break;}}else{if(_0x46018a['push']({'agent':_0xb98b3f['agent'],'dates':[_0xb98b3f['date']]}),Fs(_0x46018a)>_0x531c60){_0x46018a['pop']();break;}}_0x402247=_0x402247['slice'](0x1);}return{'heartbeatsToSend':_0x46018a,'unsentEntries':_0x402247};}class Nl{constructor(_0x74160f){this['app']=_0x74160f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2b9df4=await Sl(this['app']);return _0x2b9df4!=null&&_0x2b9df4['heartbeats']?_0x2b9df4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x317ee0){if(await this['_canUseIndexedDBPromise']){const _0x7d6e82=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x317ee0['lastSentHeartbeatDate']??_0x7d6e82['lastSentHeartbeatDate'],'heartbeats':_0x317ee0['heartbeats']});}else return;}async['add'](_0x2bb775){if(await this['_canUseIndexedDBPromise']){const _0x1b0533=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2bb775['lastSentHeartbeatDate']??_0x1b0533['lastSentHeartbeatDate'],'heartbeats':[..._0x1b0533['heartbeats'],..._0x2bb775['heartbeats']]});}else return;}}function Fs(_0x52ea8f){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x52ea8f}))['length'];}function Pl(_0x2658a6){if(_0x2658a6['length']===0x0)return-0x1;let _0x126864=0x0,_0x22846f=_0x2658a6[0x0]['date'];for(let _0x5c5def=0x1;_0x5c5def<_0x2658a6['length'];_0x5c5def++)_0x2658a6[_0x5c5def]['date']<_0x22846f&&(_0x22846f=_0x2658a6[_0x5c5def]['date'],_0x126864=_0x5c5def);return _0x126864;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x23fbac){et(new Me('platform-logger',_0x44c632=>new Gc(_0x44c632),'PRIVATE')),et(new Me('heartbeat',_0x3e5933=>new Al(_0x3e5933),'PRIVATE')),me(fi,Ds,_0x23fbac),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x1c9e27){Zr=_0x1c9e27;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x40f877){this['domStorage_']=_0x40f877,this['prefix_']='firebase:';}['set'](_0x579fde,_0x698ff3){_0x698ff3==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x579fde)):this['domStorage_']['setItem'](this['prefixedName_'](_0x579fde),O(_0x698ff3));}['get'](_0x5f2480){const _0x5ad8fa=this['domStorage_']['getItem'](this['prefixedName_'](_0x5f2480));return _0x5ad8fa==null?null:bt(_0x5ad8fa);}['remove'](_0x42f084){this['domStorage_']['removeItem'](this['prefixedName_'](_0x42f084));}['prefixedName_'](_0x5de659){return this['prefix_']+_0x5de659;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2ed415,_0xd72789){_0xd72789==null?delete this['cache_'][_0x2ed415]:this['cache_'][_0x2ed415]=_0xd72789;}['get'](_0x2eeacb){return Y(this['cache_'],_0x2eeacb)?this['cache_'][_0x2eeacb]:null;}['remove'](_0x57411a){delete this['cache_'][_0x57411a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x57da0f){try{if(typeof window<'u'&&typeof window[_0x57da0f]<'u'){const _0xa45896=window[_0x57da0f];return _0xa45896['setItem']('firebase:sentinel','cache'),_0xa45896['removeItem']('firebase:sentinel'),new xl(_0xa45896);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x2204ec=0x1;return function(){return _0x2204ec++;};}()),no=function(_0x203a6c){const _0x5eb21e=Tc(_0x203a6c),_0x3822bc=new Ec();_0x3822bc['update'](_0x5eb21e);const _0x8b4d78=_0x3822bc['digest']();return Di['encodeByteArray'](_0x8b4d78);},Bt=function(..._0x4a1dd4){let _0x4a9f69='';for(let _0x4a1ed2=0x0;_0x4a1ed2<_0x4a1dd4['length'];_0x4a1ed2++){const _0x122144=_0x4a1dd4[_0x4a1ed2];Array['isArray'](_0x122144)||_0x122144&&typeof _0x122144=='object'&&typeof _0x122144['length']=='number'?_0x4a9f69+=Bt['apply'](null,_0x122144):typeof _0x122144=='object'?_0x4a9f69+=O(_0x122144):_0x4a9f69+=_0x122144,_0x4a9f69+='\x20';}return _0x4a9f69;};let Et=null,Vs=!0x0;const Wl=function(_0x4f3083,_0x2b2a7e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5377a1){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x124d98=Bt['apply'](null,_0x5377a1);Et(_0x124d98);}},Vt=function(_0x169b4c){return function(..._0x2e2c35){L(_0x169b4c,..._0x2e2c35);};},mi=function(..._0x4fea8b){const _0xf58700='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x4fea8b);Qe['error'](_0xf58700);},oe=function(..._0x57047d){const _0x5b85f9='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x57047d);throw Qe['error'](_0x5b85f9),new Error(_0x5b85f9);},U=function(..._0x1248cb){const _0x5763f8='FIREBASE\x20WARNING:\x20'+Bt(..._0x1248cb);Qe['warn'](_0x5763f8);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x4c23b6){return typeof _0x4c23b6=='number'&&(_0x4c23b6!==_0x4c23b6||_0x4c23b6===Number['POSITIVE_INFINITY']||_0x4c23b6===Number['NEGATIVE_INFINITY']);},Vl=function(_0x75f320){if(document['readyState']==='complete')_0x75f320();else{let _0x129326=!0x1;const _0x1dfeac=function(){if(!document['body']){setTimeout(_0x1dfeac,Math['floor'](0xa));return;}_0x129326||(_0x129326=!0x0,_0x75f320());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1dfeac,!0x1),window['addEventListener']('load',_0x1dfeac,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1dfeac();}),window['attachEvent']('onload',_0x1dfeac));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x7f6880,_0x2c0ad6){if(_0x7f6880===_0x2c0ad6)return 0x0;if(_0x7f6880===xe||_0x2c0ad6===Ie)return-0x1;if(_0x2c0ad6===xe||_0x7f6880===Ie)return 0x1;{const _0x2ea9e0=Hs(_0x7f6880),_0x18f8ee=Hs(_0x2c0ad6);return _0x2ea9e0!==null?_0x18f8ee!==null?_0x2ea9e0-_0x18f8ee===0x0?_0x7f6880['length']-_0x2c0ad6['length']:_0x2ea9e0-_0x18f8ee:-0x1:_0x18f8ee!==null?0x1:_0x7f6880<_0x2c0ad6?-0x1:0x1;}},Hl=function(_0x278e49,_0x22366d){return _0x278e49===_0x22366d?0x0:_0x278e49<_0x22366d?-0x1:0x1;},pt=function(_0xd033c9,_0x4c5084){if(_0x4c5084&&_0xd033c9 in _0x4c5084)return _0x4c5084[_0xd033c9];throw new Error('Missing\x20required\x20key\x20('+_0xd033c9+')\x20in\x20object:\x20'+O(_0x4c5084));},Bi=function(_0x4d04b4){if(typeof _0x4d04b4!='object'||_0x4d04b4===null)return O(_0x4d04b4);const _0x5494f4=[];for(const _0x681cac in _0x4d04b4)_0x5494f4['push'](_0x681cac);_0x5494f4['sort']();let _0x220002='{';for(let _0x25de2c=0x0;_0x25de2c<_0x5494f4['length'];_0x25de2c++)_0x25de2c!==0x0&&(_0x220002+=','),_0x220002+=O(_0x5494f4[_0x25de2c]),_0x220002+=':',_0x220002+=Bi(_0x4d04b4[_0x5494f4[_0x25de2c]]);return _0x220002+='}',_0x220002;},io=function(_0x50a796,_0x5d6b74){const _0x390809=_0x50a796['length'];if(_0x390809<=_0x5d6b74)return[_0x50a796];const _0x56fba3=[];for(let _0x55cedd=0x0;_0x55cedd<_0x390809;_0x55cedd+=_0x5d6b74)_0x55cedd+_0x5d6b74>_0x390809?_0x56fba3['push'](_0x50a796['substring'](_0x55cedd,_0x390809)):_0x56fba3['push'](_0x50a796['substring'](_0x55cedd,_0x55cedd+_0x5d6b74));return _0x56fba3;};function x(_0x47a25b,_0x361afc){for(const _0x14e1c9 in _0x47a25b)_0x47a25b['hasOwnProperty'](_0x14e1c9)&&_0x361afc(_0x14e1c9,_0x47a25b[_0x14e1c9]);}const so=function(_0x433f20){f(!Wi(_0x433f20),'Invalid\x20JSON\x20number');const _0x49bcb4=0xb,_0x1d715d=0x34,_0x3ce08d=(0x1<<_0x49bcb4-0x1)-0x1;let _0x307cfc,_0x3e465c,_0x15b15b,_0x4258a6,_0xf8ecee;_0x433f20===0x0?(_0x3e465c=0x0,_0x15b15b=0x0,_0x307cfc=0x1/_0x433f20===-0x1/0x0?0x1:0x0):(_0x307cfc=_0x433f20<0x0,_0x433f20=Math['abs'](_0x433f20),_0x433f20>=Math['pow'](0x2,0x1-_0x3ce08d)?(_0x4258a6=Math['min'](Math['floor'](Math['log'](_0x433f20)/Math['LN2']),_0x3ce08d),_0x3e465c=_0x4258a6+_0x3ce08d,_0x15b15b=Math['round'](_0x433f20*Math['pow'](0x2,_0x1d715d-_0x4258a6)-Math['pow'](0x2,_0x1d715d))):(_0x3e465c=0x0,_0x15b15b=Math['round'](_0x433f20/Math['pow'](0x2,0x1-_0x3ce08d-_0x1d715d))));const _0x2f05b8=[];for(_0xf8ecee=_0x1d715d;_0xf8ecee;_0xf8ecee-=0x1)_0x2f05b8['push'](_0x15b15b%0x2?0x1:0x0),_0x15b15b=Math['floor'](_0x15b15b/0x2);for(_0xf8ecee=_0x49bcb4;_0xf8ecee;_0xf8ecee-=0x1)_0x2f05b8['push'](_0x3e465c%0x2?0x1:0x0),_0x3e465c=Math['floor'](_0x3e465c/0x2);_0x2f05b8['push'](_0x307cfc?0x1:0x0),_0x2f05b8['reverse']();const _0x4ec80d=_0x2f05b8['join']('');let _0x1107d0='';for(_0xf8ecee=0x0;_0xf8ecee<0x40;_0xf8ecee+=0x8){let _0x415bdd=parseInt(_0x4ec80d['substr'](_0xf8ecee,0x8),0x2)['toString'](0x10);_0x415bdd['length']===0x1&&(_0x415bdd='0'+_0x415bdd),_0x1107d0=_0x1107d0+_0x415bdd;}return _0x1107d0['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x153198,_0x4319fc){let _0x4ed98f='Unknown\x20Error';_0x153198==='too_big'?_0x4ed98f='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x153198==='permission_denied'?_0x4ed98f='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x153198==='unavailable'&&(_0x4ed98f='The\x20service\x20is\x20unavailable');const _0x395bc7=new Error(_0x153198+'\x20at\x20'+_0x4319fc['_path']['toString']()+':\x20'+_0x4ed98f);return _0x395bc7['code']=_0x153198['toUpperCase'](),_0x395bc7;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x49d0be){if(zl['test'](_0x49d0be)){const _0x39816c=Number(_0x49d0be);if(_0x39816c>=jl&&_0x39816c<=Kl)return _0x39816c;}return null;},lt=function(_0x41f3d2){try{_0x41f3d2();}catch(_0x492b45){setTimeout(()=>{const _0x339071=_0x492b45['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x339071),_0x492b45;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x573934,_0x9b53c3){const _0x3b36de=setTimeout(_0x573934,_0x9b53c3);return typeof _0x3b36de=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3b36de):typeof _0x3b36de=='object'&&_0x3b36de['unref']&&_0x3b36de['unref'](),_0x3b36de;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x31df8a,_0x2921a9){this['appCheckProvider']=_0x2921a9,this['appName']=_0x31df8a['name'],H(_0x31df8a)&&_0x31df8a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x31df8a['settings']['appCheckToken']),this['appCheck']=_0x2921a9==null?void 0x0:_0x2921a9['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2921a9==null||_0x2921a9['get']()['then'](_0x5ad58b=>this['appCheck']=_0x5ad58b);}['getToken'](_0x527f7b){if(this['serverAppAppCheckToken']){if(_0x527f7b)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x527f7b):new Promise((_0x45d8d6,_0x4a61ce)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x527f7b)['then'](_0x45d8d6,_0x4a61ce):_0x45d8d6(null);},0x0);});}['addTokenChangeListener'](_0x4a7623){var _0x2691e4;(_0x2691e4=this['appCheckProvider'])==null||_0x2691e4['get']()['then'](_0x137d79=>_0x137d79['addTokenListener'](_0x4a7623));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x13cfff,_0x40c5ab,_0x16c530){this['appName_']=_0x13cfff,this['firebaseOptions_']=_0x40c5ab,this['authProvider_']=_0x16c530,this['auth_']=null,this['auth_']=_0x16c530['getImmediate']({'optional':!0x0}),this['auth_']||_0x16c530['onInit'](_0xb0fac7=>this['auth_']=_0xb0fac7);}['getToken'](_0x47f862){return this['auth_']?this['auth_']['getToken'](_0x47f862)['catch'](_0x5c4901=>_0x5c4901&&_0x5c4901['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5c4901)):new Promise((_0x4a84f1,_0x4a6e44)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x47f862)['then'](_0x4a84f1,_0x4a6e44):_0x4a84f1(null);},0x0);});}['addTokenChangeListener'](_0x5e50dc){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5e50dc):this['authProvider_']['get']()['then'](_0x355069=>_0x355069['addAuthTokenListener'](_0x5e50dc));}['removeTokenChangeListener'](_0x9e5513){this['authProvider_']['get']()['then'](_0x155a7f=>_0x155a7f['removeAuthTokenListener'](_0x9e5513));}['notifyForInvalidToken'](){let _0x1cd735='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1cd735+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1cd735+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1cd735+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1cd735);}}class tn{constructor(_0x54a8f1){this['accessToken']=_0x54a8f1;}['getToken'](_0x4df6d9){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x267c8e){_0x267c8e(this['accessToken']);}['removeTokenChangeListener'](_0x5a3185){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x5536aa,_0x85ecf7,_0x22ede3,_0x374690,_0x4c7ba5=!0x1,_0x38f0b7='',_0x1fbcc2=!0x1,_0x5eb5ff=!0x1,_0x563ef3=null){this['secure']=_0x85ecf7,this['namespace']=_0x22ede3,this['webSocketOnly']=_0x374690,this['nodeAdmin']=_0x4c7ba5,this['persistenceKey']=_0x38f0b7,this['includeNamespaceInQueryParams']=_0x1fbcc2,this['isUsingEmulator']=_0x5eb5ff,this['emulatorOptions']=_0x563ef3,this['_host']=_0x5536aa['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x5536aa)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5b8b3c){_0x5b8b3c!==this['internalHost']&&(this['internalHost']=_0x5b8b3c,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5248c3=this['toURLString']();return this['persistenceKey']&&(_0x5248c3+='<'+this['persistenceKey']+'>'),_0x5248c3;}['toURLString'](){const _0x2b6be1=this['secure']?'https://':'http://',_0x10acb8=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2b6be1+this['host']+'/'+_0x10acb8;}}function Xl(_0x5d20de){return _0x5d20de['host']!==_0x5d20de['internalHost']||_0x5d20de['isCustomHost']()||_0x5d20de['includeNamespaceInQueryParams'];}function go(_0x10dc07,_0x1f3b09,_0xc94f38){f(typeof _0x1f3b09=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xc94f38=='object','typeof\x20params\x20must\x20==\x20object');let _0x219514;if(_0x1f3b09===fo)_0x219514=(_0x10dc07['secure']?'wss://':'ws://')+_0x10dc07['internalHost']+'/.ws?';else{if(_0x1f3b09===po)_0x219514=(_0x10dc07['secure']?'https://':'http://')+_0x10dc07['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1f3b09);}Xl(_0x10dc07)&&(_0xc94f38['ns']=_0x10dc07['namespace']);const _0x37c1bc=[];return x(_0xc94f38,(_0x54dcfc,_0x46bd9c)=>{_0x37c1bc['push'](_0x54dcfc+'='+_0x46bd9c);}),_0x219514+_0x37c1bc['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x2b2247,_0x3f2ee1=0x1){Y(this['counters_'],_0x2b2247)||(this['counters_'][_0x2b2247]=0x0),this['counters_'][_0x2b2247]+=_0x3f2ee1;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x31db92){const _0x314713=_0x31db92['toString']();return ti[_0x314713]||(ti[_0x314713]=new Zl()),ti[_0x314713];}function eh(_0x4f3fce,_0x3e139b){const _0x1d4589=_0x4f3fce['toString']();return ni[_0x1d4589]||(ni[_0x1d4589]=_0x3e139b()),ni[_0x1d4589];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x352bee){this['onMessage_']=_0x352bee,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x365b81,_0x93d8a4){this['closeAfterResponse']=_0x365b81,this['onClose']=_0x93d8a4,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xd7686b,_0x593ec7){for(this['pendingResponses'][_0xd7686b]=_0x593ec7;this['pendingResponses'][this['currentResponseNum']];){const _0x5eeb82=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x45c9ee=0x0;_0x45c9ee<_0x5eeb82['length'];++_0x45c9ee)_0x5eeb82[_0x45c9ee]&&lt(()=>{this['onMessage_'](_0x5eeb82[_0x45c9ee]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x4a5c83,_0x213863,_0x3f42c1,_0x296dbc,_0x29e5b4,_0x29e78a,_0x1c63bc){this['connId']=_0x4a5c83,this['repoInfo']=_0x213863,this['applicationId']=_0x3f42c1,this['appCheckToken']=_0x296dbc,this['authToken']=_0x29e5b4,this['transportSessionId']=_0x29e78a,this['lastSessionId']=_0x1c63bc,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x4a5c83),this['stats_']=Hi(_0x213863),this['urlFn']=_0x137025=>(this['appCheckToken']&&(_0x137025[yi]=this['appCheckToken']),go(_0x213863,po,_0x137025));}['open'](_0x4ba7c2,_0x4e2c57){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4e2c57,this['myPacketOrderer']=new th(_0x4ba7c2),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x472050)=>{const [_0x4c12f0,_0x4e17b5,_0x472269,_0x10dd88,_0x1d1f7e]=_0x472050;if(this['incrementIncomingBytes_'](_0x472050),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4c12f0===$s)this['id']=_0x4e17b5,this['password']=_0x472269;else{if(_0x4c12f0===nh)_0x4e17b5?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4e17b5,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4c12f0);}}},(..._0x4c45b9)=>{const [_0x5b4904,_0x5af5b2]=_0x4c45b9;this['incrementIncomingBytes_'](_0x4c45b9),this['myPacketOrderer']['handleResponse'](_0x5b4904,_0x5af5b2);},()=>{this['onClosed_']();},this['urlFn']);const _0x2d777b={};_0x2d777b[$s]='t',_0x2d777b[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2d777b[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2d777b[ro]=Vi,this['transportSessionId']&&(_0x2d777b[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x2d777b[ho]=this['lastSessionId']),this['applicationId']&&(_0x2d777b[uo]=this['applicationId']),this['appCheckToken']&&(_0x2d777b[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2d777b[ao]=co);const _0x1b2724=this['urlFn'](_0x2d777b);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1b2724),this['scriptTagHolder']['addTag'](_0x1b2724,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x31d112){const _0x5a48a2=O(_0x31d112);this['bytesSent']+=_0x5a48a2['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5a48a2['length']);const _0x475425=Br(_0x5a48a2),_0x22166d=io(_0x475425,hh);for(let _0xacbd78=0x0;_0xacbd78<_0x22166d['length'];_0xacbd78++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x22166d['length'],_0x22166d[_0xacbd78]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xb8f003,_0x1e2fb5){this['myDisconnFrame']=document['createElement']('iframe');const _0xec3852={};_0xec3852[lh]='t',_0xec3852[mo]=_0xb8f003,_0xec3852[yo]=_0x1e2fb5,this['myDisconnFrame']['src']=this['urlFn'](_0xec3852),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x162296){const _0x46d61b=O(_0x162296)['length'];this['bytesReceived']+=_0x46d61b,this['stats_']['incrementCounter']('bytes_received',_0x46d61b);}}class $i{constructor(_0x403a7d,_0x424908,_0x4bd18f,_0x533025){this['onDisconnect']=_0x4bd18f,this['urlFn']=_0x533025,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x403a7d,window[sh+this['uniqueCallbackIdentifier']]=_0x424908,this['myIFrame']=$i['createIFrame_']();let _0x22ded7='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x22ded7='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1ff71a='<html><body>'+_0x22ded7+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1ff71a),this['myIFrame']['doc']['close']();}catch(_0x44cc56){L('frame\x20writing\x20exception'),_0x44cc56['stack']&&L(_0x44cc56['stack']),L(_0x44cc56);}}}static['createIFrame_'](){const _0x494315=document['createElement']('iframe');if(_0x494315['style']['display']='none',document['body']){document['body']['appendChild'](_0x494315);try{_0x494315['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x57971e=document['domain'];_0x494315['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x57971e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x494315['contentDocument']?_0x494315['doc']=_0x494315['contentDocument']:_0x494315['contentWindow']?_0x494315['doc']=_0x494315['contentWindow']['document']:_0x494315['document']&&(_0x494315['doc']=_0x494315['document']),_0x494315;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x355a50=this['onDisconnect'];_0x355a50&&(this['onDisconnect']=null,_0x355a50());}['startLongPoll'](_0x17199c,_0x443875){for(this['myID']=_0x17199c,this['myPW']=_0x443875,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x20c647={};_0x20c647[mo]=this['myID'],_0x20c647[yo]=this['myPW'],_0x20c647[vo]=this['currentSerial'];let _0x105a8b=this['urlFn'](_0x20c647),_0x51f226='',_0x4e73e9=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x51f226['length']<=Eo;){const _0xcbea34=this['pendingSegs']['shift']();_0x51f226=_0x51f226+'&'+oh+_0x4e73e9+'='+_0xcbea34['seg']+'&'+ah+_0x4e73e9+'='+_0xcbea34['ts']+'&'+ch+_0x4e73e9+'='+_0xcbea34['d'],_0x4e73e9++;}return _0x105a8b=_0x105a8b+_0x51f226,this['addLongPollTag_'](_0x105a8b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x371fea,_0x3756d9,_0x2cb02d){this['pendingSegs']['push']({'seg':_0x371fea,'ts':_0x3756d9,'d':_0x2cb02d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x6760a8,_0x1608c1){this['outstandingRequests']['add'](_0x1608c1);const _0xdaf491=()=>{this['outstandingRequests']['delete'](_0x1608c1),this['newRequest_']();},_0x11ecd6=setTimeout(_0xdaf491,Math['floor'](uh)),_0x10bf55=()=>{clearTimeout(_0x11ecd6),_0xdaf491();};this['addTag'](_0x6760a8,_0x10bf55);}['addTag'](_0x314351,_0x39a113){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xe6def6=this['myIFrame']['doc']['createElement']('script');_0xe6def6['type']='text/javascript',_0xe6def6['async']=!0x0,_0xe6def6['src']=_0x314351,_0xe6def6['onload']=_0xe6def6['onreadystatechange']=function(){const _0xe10ba1=_0xe6def6['readyState'];(!_0xe10ba1||_0xe10ba1==='loaded'||_0xe10ba1==='complete')&&(_0xe6def6['onload']=_0xe6def6['onreadystatechange']=null,_0xe6def6['parentNode']&&_0xe6def6['parentNode']['removeChild'](_0xe6def6),_0x39a113());},_0xe6def6['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x314351),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xe6def6);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x44c677,_0x35be02,_0x32e314,_0x5d6caa,_0x47b792,_0x15a266,_0x1153dd){this['connId']=_0x44c677,this['applicationId']=_0x32e314,this['appCheckToken']=_0x5d6caa,this['authToken']=_0x47b792,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x35be02),this['connURL']=G['connectionURL_'](_0x35be02,_0x15a266,_0x1153dd,_0x5d6caa,_0x32e314),this['nodeAdmin']=_0x35be02['nodeAdmin'];}static['connectionURL_'](_0x5ac9c3,_0x4bd52f,_0xd9e62b,_0xa7c04f,_0x1c8764){const _0x59d013={};return _0x59d013[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x59d013[ao]=co),_0x4bd52f&&(_0x59d013[oo]=_0x4bd52f),_0xd9e62b&&(_0x59d013[ho]=_0xd9e62b),_0xa7c04f&&(_0x59d013[yi]=_0xa7c04f),_0x1c8764&&(_0x59d013[uo]=_0x1c8764),go(_0x5ac9c3,fo,_0x59d013);}['open'](_0x32f830,_0xa68ebd){this['onDisconnect']=_0xa68ebd,this['onMessage']=_0x32f830,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0xf38f60;dc(),this['mySock']=new hn(this['connURL'],[],_0xf38f60);}catch(_0xa0c094){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x83e3df=_0xa0c094['message']||_0xa0c094['data'];_0x83e3df&&this['log_'](_0x83e3df),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x32ef45=>{this['handleIncomingFrame'](_0x32ef45);},this['mySock']['onerror']=_0x181b50=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2d93a7=_0x181b50['message']||_0x181b50['data'];_0x2d93a7&&this['log_'](_0x2d93a7),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x505406=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x479b4b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5f4450=navigator['userAgent']['match'](_0x479b4b);_0x5f4450&&_0x5f4450['length']>0x1&&parseFloat(_0x5f4450[0x1])<4.4&&(_0x505406=!0x0);}return!_0x505406&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x352121){if(this['frames']['push'](_0x352121),this['frames']['length']===this['totalFrames']){const _0x4c0ac0=this['frames']['join']('');this['frames']=null;const _0x5d1c6b=bt(_0x4c0ac0);this['onMessage'](_0x5d1c6b);}}['handleNewFrameCount_'](_0x1ae5b2){this['totalFrames']=_0x1ae5b2,this['frames']=[];}['extractFrameCount_'](_0x375432){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x375432['length']<=0x6){const _0x2ff541=Number(_0x375432);if(!isNaN(_0x2ff541))return this['handleNewFrameCount_'](_0x2ff541),null;}return this['handleNewFrameCount_'](0x1),_0x375432;}['handleIncomingFrame'](_0x1c52df){if(this['mySock']===null)return;const _0x1ae1a0=_0x1c52df['data'];if(this['bytesReceived']+=_0x1ae1a0['length'],this['stats_']['incrementCounter']('bytes_received',_0x1ae1a0['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1ae1a0);else{const _0x9afdb=this['extractFrameCount_'](_0x1ae1a0);_0x9afdb!==null&&this['appendFrame_'](_0x9afdb);}}['send'](_0x107c82){this['resetKeepAlive']();const _0x37cbec=O(_0x107c82);this['bytesSent']+=_0x37cbec['length'],this['stats_']['incrementCounter']('bytes_sent',_0x37cbec['length']);const _0x5a7ee2=io(_0x37cbec,fh);_0x5a7ee2['length']>0x1&&this['sendString_'](String(_0x5a7ee2['length']));for(let _0xffba6e=0x0;_0xffba6e<_0x5a7ee2['length'];_0xffba6e++)this['sendString_'](_0x5a7ee2[_0xffba6e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x128c7a){try{this['mySock']['send'](_0x128c7a);}catch(_0x47bbdc){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x47bbdc['message']||_0x47bbdc['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2d69a2){this['initTransports_'](_0x2d69a2);}['initTransports_'](_0x4311f7){const _0x4b7226=G&&G['isAvailable']();let _0xbe22c9=_0x4b7226&&!G['previouslyFailed']();if(_0x4311f7['webSocketOnly']&&(_0x4b7226||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xbe22c9=!0x0),_0xbe22c9)this['transports_']=[G];else{const _0x55bf71=this['transports_']=[];for(const _0x97972a of At['ALL_TRANSPORTS'])_0x97972a&&_0x97972a['isAvailable']()&&_0x55bf71['push'](_0x97972a);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x176a33,_0x26e91c,_0x2b0c94,_0x74ea3c,_0x23d82f,_0x52e909,_0x39a94c,_0x1e0466,_0x2316ec,_0x1a12ad){this['id']=_0x176a33,this['repoInfo_']=_0x26e91c,this['applicationId_']=_0x2b0c94,this['appCheckToken_']=_0x74ea3c,this['authToken_']=_0x23d82f,this['onMessage_']=_0x52e909,this['onReady_']=_0x39a94c,this['onDisconnect_']=_0x1e0466,this['onKill_']=_0x2316ec,this['lastSessionId']=_0x1a12ad,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x26e91c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5e835b=this['transportManager_']['initialTransport']();this['conn_']=new _0x5e835b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5e835b['responsesRequiredToBeHealthy']||0x0;const _0x157cd5=this['connReceiver_'](this['conn_']),_0x5cd9d5=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x157cd5,_0x5cd9d5);},Math['floor'](0x0));const _0x5ae1fc=_0x5e835b['healthyTimeout']||0x0;_0x5ae1fc>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5ae1fc)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2cb252){return _0x4f6e74=>{_0x2cb252===this['conn_']?this['onConnectionLost_'](_0x4f6e74):_0x2cb252===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1de705){return _0x25b1d5=>{this['state_']!==0x2&&(_0x1de705===this['rx_']?this['onPrimaryMessageReceived_'](_0x25b1d5):_0x1de705===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x25b1d5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x47d657){const _0x284c9c={'t':'d','d':_0x47d657};this['sendData_'](_0x284c9c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xe62b28){if(ii in _0xe62b28){const _0x3c7a81=_0xe62b28[ii];_0x3c7a81===js?this['upgradeIfSecondaryHealthy_']():_0x3c7a81===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3c7a81===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x35e9c0){const _0x14ce81=pt('t',_0x35e9c0),_0x3bc8cb=pt('d',_0x35e9c0);if(_0x14ce81==='c')this['onSecondaryControl_'](_0x3bc8cb);else{if(_0x14ce81==='d')this['pendingDataMessages']['push'](_0x3bc8cb);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x14ce81);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x25d189){const _0x222bd8=pt('t',_0x25d189),_0x591be2=pt('d',_0x25d189);_0x222bd8==='c'?this['onControl_'](_0x591be2):_0x222bd8==='d'&&this['onDataMessage_'](_0x591be2);}['onDataMessage_'](_0xe072a3){this['onPrimaryResponse_'](),this['onMessage_'](_0xe072a3);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5653d3){const _0x18e6bf=pt(ii,_0x5653d3);if(Gs in _0x5653d3){const _0x150a22=_0x5653d3[Gs];if(_0x18e6bf===Ih){const _0x3bd7cc={..._0x150a22};this['repoInfo_']['isUsingEmulator']&&(_0x3bd7cc['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3bd7cc);}else{if(_0x18e6bf===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x35e62a=0x0;_0x35e62a<this['pendingDataMessages']['length'];++_0x35e62a)this['onDataMessage_'](this['pendingDataMessages'][_0x35e62a]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x18e6bf===vh?this['onConnectionShutdown_'](_0x150a22):_0x18e6bf===qs?this['onReset_'](_0x150a22):_0x18e6bf===Eh?mi('Server\x20Error:\x20'+_0x150a22):_0x18e6bf===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x18e6bf);}}}['onHandshake_'](_0x38de70){const _0x14f096=_0x38de70['ts'],_0x2ea6ff=_0x38de70['v'],_0x259e65=_0x38de70['h'];this['sessionId']=_0x38de70['s'],this['repoInfo_']['host']=_0x259e65,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x14f096),Vi!==_0x2ea6ff&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2c4e3b=this['transportManager_']['upgradeTransport']();_0x2c4e3b&&this['startUpgrade_'](_0x2c4e3b);}['startUpgrade_'](_0x3d7a4d){this['secondaryConn_']=new _0x3d7a4d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3d7a4d['responsesRequiredToBeHealthy']||0x0;const _0x42caba=this['connReceiver_'](this['secondaryConn_']),_0x4616d7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x42caba,_0x4616d7),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x5c5833){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5c5833),this['repoInfo_']['host']=_0x5c5833,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3b2d00,_0x5581d6){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3b2d00,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5581d6,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x36079c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x36079c||this['rx_']===_0x36079c)&&this['close']();}['onConnectionLost_'](_0x5e06f4){this['conn_']=null,!_0x5e06f4&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x19243a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x19243a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2dced9){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2dced9);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x3734ea,_0x3fe8c8,_0x488fb5,_0x2507e5){}['merge'](_0x57938f,_0x70d925,_0xd37305,_0x28a885){}['refreshAuthToken'](_0x2ebcc0){}['refreshAppCheckToken'](_0x4ea374){}['onDisconnectPut'](_0x788966,_0x42c2d8,_0x38e228){}['onDisconnectMerge'](_0x11c33a,_0x19e32e,_0x9d87a){}['onDisconnectCancel'](_0x56d55c,_0x214f4f){}['reportStats'](_0x5eebe8){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x443d6f){this['allowedEvents_']=_0x443d6f,this['listeners_']={},f(Array['isArray'](_0x443d6f)&&_0x443d6f['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x10dd8c,..._0x2e576b){if(Array['isArray'](this['listeners_'][_0x10dd8c])){const _0x434e9a=[...this['listeners_'][_0x10dd8c]];for(let _0x639e9e=0x0;_0x639e9e<_0x434e9a['length'];_0x639e9e++)_0x434e9a[_0x639e9e]['callback']['apply'](_0x434e9a[_0x639e9e]['context'],_0x2e576b);}}['on'](_0xcdaec2,_0xc8b882,_0x1ecce0){this['validateEventType_'](_0xcdaec2),this['listeners_'][_0xcdaec2]=this['listeners_'][_0xcdaec2]||[],this['listeners_'][_0xcdaec2]['push']({'callback':_0xc8b882,'context':_0x1ecce0});const _0x4bc593=this['getInitialEvent'](_0xcdaec2);_0x4bc593&&_0xc8b882['apply'](_0x1ecce0,_0x4bc593);}['off'](_0x2e0c67,_0x1a77d9,_0x22e274){this['validateEventType_'](_0x2e0c67);const _0x36390e=this['listeners_'][_0x2e0c67]||[];for(let _0x51daa4=0x0;_0x51daa4<_0x36390e['length'];_0x51daa4++)if(_0x36390e[_0x51daa4]['callback']===_0x1a77d9&&(!_0x22e274||_0x22e274===_0x36390e[_0x51daa4]['context'])){_0x36390e['splice'](_0x51daa4,0x1);return;}}['validateEventType_'](_0x237b14){f(this['allowedEvents_']['find'](_0x2cfe4a=>_0x2cfe4a===_0x237b14),'Unknown\x20event:\x20'+_0x237b14);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2cbaf0){return f(_0x2cbaf0==='online','Unknown\x20event\x20type:\x20'+_0x2cbaf0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x5bf7ee,_0x54dd72){if(_0x54dd72===void 0x0){this['pieces_']=_0x5bf7ee['split']('/');let _0x3171dd=0x0;for(let _0x39d888=0x0;_0x39d888<this['pieces_']['length'];_0x39d888++)this['pieces_'][_0x39d888]['length']>0x0&&(this['pieces_'][_0x3171dd]=this['pieces_'][_0x39d888],_0x3171dd++);this['pieces_']['length']=_0x3171dd,this['pieceNum_']=0x0;}else this['pieces_']=_0x5bf7ee,this['pieceNum_']=_0x54dd72;}['toString'](){let _0x46ea89='';for(let _0x5a0352=this['pieceNum_'];_0x5a0352<this['pieces_']['length'];_0x5a0352++)this['pieces_'][_0x5a0352]!==''&&(_0x46ea89+='/'+this['pieces_'][_0x5a0352]);return _0x46ea89||'/';}}function w(){return new C('');}function y(_0x16841e){return _0x16841e['pieceNum_']>=_0x16841e['pieces_']['length']?null:_0x16841e['pieces_'][_0x16841e['pieceNum_']];}function we(_0x1e6dbb){return _0x1e6dbb['pieces_']['length']-_0x1e6dbb['pieceNum_'];}function b(_0x16f35b){let _0x4bf52b=_0x16f35b['pieceNum_'];return _0x4bf52b<_0x16f35b['pieces_']['length']&&_0x4bf52b++,new C(_0x16f35b['pieces_'],_0x4bf52b);}function Gi(_0x3317d0){return _0x3317d0['pieceNum_']<_0x3317d0['pieces_']['length']?_0x3317d0['pieces_'][_0x3317d0['pieces_']['length']-0x1]:null;}function Ch(_0x233b04){let _0x32bf51='';for(let _0x119da4=_0x233b04['pieceNum_'];_0x119da4<_0x233b04['pieces_']['length'];_0x119da4++)_0x233b04['pieces_'][_0x119da4]!==''&&(_0x32bf51+='/'+encodeURIComponent(String(_0x233b04['pieces_'][_0x119da4])));return _0x32bf51||'/';}function kt(_0x1a7af9,_0x1605f9=0x0){return _0x1a7af9['pieces_']['slice'](_0x1a7af9['pieceNum_']+_0x1605f9);}function To(_0x3fe792){if(_0x3fe792['pieceNum_']>=_0x3fe792['pieces_']['length'])return null;const _0x4aa251=[];for(let _0x3c4a85=_0x3fe792['pieceNum_'];_0x3c4a85<_0x3fe792['pieces_']['length']-0x1;_0x3c4a85++)_0x4aa251['push'](_0x3fe792['pieces_'][_0x3c4a85]);return new C(_0x4aa251,0x0);}function A(_0x3002b7,_0x489a13){const _0x336d68=[];for(let _0x3c2b48=_0x3002b7['pieceNum_'];_0x3c2b48<_0x3002b7['pieces_']['length'];_0x3c2b48++)_0x336d68['push'](_0x3002b7['pieces_'][_0x3c2b48]);if(_0x489a13 instanceof C){for(let _0x437a10=_0x489a13['pieceNum_'];_0x437a10<_0x489a13['pieces_']['length'];_0x437a10++)_0x336d68['push'](_0x489a13['pieces_'][_0x437a10]);}else{const _0x5987d5=_0x489a13['split']('/');for(let _0x3e0f91=0x0;_0x3e0f91<_0x5987d5['length'];_0x3e0f91++)_0x5987d5[_0x3e0f91]['length']>0x0&&_0x336d68['push'](_0x5987d5[_0x3e0f91]);}return new C(_0x336d68,0x0);}function v(_0x57afe5){return _0x57afe5['pieceNum_']>=_0x57afe5['pieces_']['length'];}function F(_0x542180,_0xe4da6e){const _0x18500b=y(_0x542180),_0x4964fe=y(_0xe4da6e);if(_0x18500b===null)return _0xe4da6e;if(_0x18500b===_0x4964fe)return F(b(_0x542180),b(_0xe4da6e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xe4da6e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x542180+')');}function Th(_0x5132f3,_0x566394){const _0x2ff837=kt(_0x5132f3,0x0),_0x460722=kt(_0x566394,0x0);for(let _0x47bd55=0x0;_0x47bd55<_0x2ff837['length']&&_0x47bd55<_0x460722['length'];_0x47bd55++){const _0x467086=He(_0x2ff837[_0x47bd55],_0x460722[_0x47bd55]);if(_0x467086!==0x0)return _0x467086;}return _0x2ff837['length']===_0x460722['length']?0x0:_0x2ff837['length']<_0x460722['length']?-0x1:0x1;}function qi(_0x42bf0e,_0x4b938a){if(we(_0x42bf0e)!==we(_0x4b938a))return!0x1;for(let _0x2b3acc=_0x42bf0e['pieceNum_'],_0x1b9938=_0x4b938a['pieceNum_'];_0x2b3acc<=_0x42bf0e['pieces_']['length'];_0x2b3acc++,_0x1b9938++)if(_0x42bf0e['pieces_'][_0x2b3acc]!==_0x4b938a['pieces_'][_0x1b9938])return!0x1;return!0x0;}function $(_0x25be49,_0x19e3a){let _0x150a8e=_0x25be49['pieceNum_'],_0x1b3bab=_0x19e3a['pieceNum_'];if(we(_0x25be49)>we(_0x19e3a))return!0x1;for(;_0x150a8e<_0x25be49['pieces_']['length'];){if(_0x25be49['pieces_'][_0x150a8e]!==_0x19e3a['pieces_'][_0x1b3bab])return!0x1;++_0x150a8e,++_0x1b3bab;}return!0x0;}class Sh{constructor(_0x47d5e6,_0x2c718b){this['errorPrefix_']=_0x2c718b,this['parts_']=kt(_0x47d5e6,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1bac1d=0x0;_0x1bac1d<this['parts_']['length'];_0x1bac1d++)this['byteLength_']+=Pn(this['parts_'][_0x1bac1d]);So(this);}}function bh(_0x2001d7,_0x8393f3){_0x2001d7['parts_']['length']>0x0&&(_0x2001d7['byteLength_']+=0x1),_0x2001d7['parts_']['push'](_0x8393f3),_0x2001d7['byteLength_']+=Pn(_0x8393f3),So(_0x2001d7);}function Rh(_0x4f63af){const _0x396223=_0x4f63af['parts_']['pop']();_0x4f63af['byteLength_']-=Pn(_0x396223),_0x4f63af['parts_']['length']>0x0&&(_0x4f63af['byteLength_']-=0x1);}function So(_0x4bdc19){if(_0x4bdc19['byteLength_']>Js)throw new Error(_0x4bdc19['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4bdc19['byteLength_']+').');if(_0x4bdc19['parts_']['length']>Qs)throw new Error(_0x4bdc19['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4bdc19));}function Ne(_0x5de4e8){return _0x5de4e8['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5de4e8['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x507a3f,_0x17e05d;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x17e05d='visibilitychange',_0x507a3f='hidden'):typeof document['mozHidden']<'u'?(_0x17e05d='mozvisibilitychange',_0x507a3f='mozHidden'):typeof document['msHidden']<'u'?(_0x17e05d='msvisibilitychange',_0x507a3f='msHidden'):typeof document['webkitHidden']<'u'&&(_0x17e05d='webkitvisibilitychange',_0x507a3f='webkitHidden')),this['visible_']=!0x0,_0x17e05d&&document['addEventListener'](_0x17e05d,()=>{const _0x413ea4=!document[_0x507a3f];_0x413ea4!==this['visible_']&&(this['visible_']=_0x413ea4,this['trigger']('visible',_0x413ea4));},!0x1);}['getInitialEvent'](_0x42d5ab){return f(_0x42d5ab==='visible','Unknown\x20event\x20type:\x20'+_0x42d5ab),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x2346ea,_0x5769f3,_0x5a24d6,_0x8326eb,_0x421b23,_0x37b077,_0x5760c4,_0x4004ef){if(super(),this['repoInfo_']=_0x2346ea,this['applicationId_']=_0x5769f3,this['onDataUpdate_']=_0x5a24d6,this['onConnectStatus_']=_0x8326eb,this['onServerInfoUpdate_']=_0x421b23,this['authTokenProvider_']=_0x37b077,this['appCheckTokenProvider_']=_0x5760c4,this['authOverride_']=_0x4004ef,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4004ef)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2346ea['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x411c0d,_0x3cc2d6,_0x3fbde9){const _0x3256e3=++this['requestNumber_'],_0x45bdde={'r':_0x3256e3,'a':_0x411c0d,'b':_0x3cc2d6};this['log_'](O(_0x45bdde)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x45bdde),_0x3fbde9&&(this['requestCBHash_'][_0x3256e3]=_0x3fbde9);}['get'](_0x360e43){this['initConnection_']();const _0x6f6d27=new Ve(),_0x1d57f6={'action':'g','request':{'p':_0x360e43['_path']['toString'](),'q':_0x360e43['_queryObject']},'onComplete':_0x29ef26=>{const _0x180dd1=_0x29ef26['d'];_0x29ef26['s']==='ok'?_0x6f6d27['resolve'](_0x180dd1):_0x6f6d27['reject'](_0x180dd1);}};this['outstandingGets_']['push'](_0x1d57f6),this['outstandingGetCount_']++;const _0x34b305=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x34b305),_0x6f6d27['promise'];}['listen'](_0x1905d0,_0x3a03f6,_0xfbbea5,_0x4a6c2b){this['initConnection_']();const _0x335e1d=_0x1905d0['_queryIdentifier'],_0x17254=_0x1905d0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x17254+'\x20'+_0x335e1d),this['listens']['has'](_0x17254)||this['listens']['set'](_0x17254,new Map()),f(_0x1905d0['_queryParams']['isDefault']()||!_0x1905d0['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x17254)['has'](_0x335e1d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x195fb8={'onComplete':_0x4a6c2b,'hashFn':_0x3a03f6,'query':_0x1905d0,'tag':_0xfbbea5};this['listens']['get'](_0x17254)['set'](_0x335e1d,_0x195fb8),this['connected_']&&this['sendListen_'](_0x195fb8);}['sendGet_'](_0x4e1de7){const _0x1821d7=this['outstandingGets_'][_0x4e1de7];this['sendRequest']('g',_0x1821d7['request'],_0x18b309=>{delete this['outstandingGets_'][_0x4e1de7],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1821d7['onComplete']&&_0x1821d7['onComplete'](_0x18b309);});}['sendListen_'](_0x22d307){const _0x39c0e3=_0x22d307['query'],_0x23f69d=_0x39c0e3['_path']['toString'](),_0x22a332=_0x39c0e3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x23f69d+'\x20for\x20'+_0x22a332);const _0x1aab10={'p':_0x23f69d},_0x55b5a2='q';_0x22d307['tag']&&(_0x1aab10['q']=_0x39c0e3['_queryObject'],_0x1aab10['t']=_0x22d307['tag']),_0x1aab10['h']=_0x22d307['hashFn'](),this['sendRequest'](_0x55b5a2,_0x1aab10,_0x21e38d=>{const _0x5ede7c=_0x21e38d['d'],_0x40336d=_0x21e38d['s'];ie['warnOnListenWarnings_'](_0x5ede7c,_0x39c0e3),(this['listens']['get'](_0x23f69d)&&this['listens']['get'](_0x23f69d)['get'](_0x22a332))===_0x22d307&&(this['log_']('listen\x20response',_0x21e38d),_0x40336d!=='ok'&&this['removeListen_'](_0x23f69d,_0x22a332),_0x22d307['onComplete']&&_0x22d307['onComplete'](_0x40336d,_0x5ede7c));});}static['warnOnListenWarnings_'](_0x23a6e1,_0x4c1e50){if(_0x23a6e1&&typeof _0x23a6e1=='object'&&Y(_0x23a6e1,'w')){const _0x3299eb=Oe(_0x23a6e1,'w');if(Array['isArray'](_0x3299eb)&&~_0x3299eb['indexOf']('no_index')){const _0x5ae697='\x22.indexOn\x22:\x20\x22'+_0x4c1e50['_queryParams']['getIndex']()['toString']()+'\x22',_0x3da400=_0x4c1e50['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5ae697+'\x20at\x20'+_0x3da400+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4b230c){this['authToken_']=_0x4b230c,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4b230c);}['reduceReconnectDelayIfAdminCredential_'](_0x70008d){(_0x70008d&&_0x70008d['length']===0x28||vc(_0x70008d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1c3be2){this['appCheckToken_']=_0x1c3be2,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xfdd63e=this['authToken_'],_0x393002=yc(_0xfdd63e)?'auth':'gauth',_0x3e217b={'cred':_0xfdd63e};this['authOverride_']===null?_0x3e217b['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3e217b['authvar']=this['authOverride_']),this['sendRequest'](_0x393002,_0x3e217b,_0x2e9dff=>{const _0x13da99=_0x2e9dff['s'],_0xd20b08=_0x2e9dff['d']||'error';this['authToken_']===_0xfdd63e&&(_0x13da99==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x13da99,_0xd20b08));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5ccaa6=>{const _0x36ee9f=_0x5ccaa6['s'],_0x3c1703=_0x5ccaa6['d']||'error';_0x36ee9f==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x36ee9f,_0x3c1703);});}['unlisten'](_0x5ba3e3,_0x2974f3){const _0x40f785=_0x5ba3e3['_path']['toString'](),_0x462753=_0x5ba3e3['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x40f785+'\x20'+_0x462753),f(_0x5ba3e3['_queryParams']['isDefault']()||!_0x5ba3e3['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x40f785,_0x462753)&&this['connected_']&&this['sendUnlisten_'](_0x40f785,_0x462753,_0x5ba3e3['_queryObject'],_0x2974f3);}['sendUnlisten_'](_0x1ead96,_0x59b785,_0x366d1b,_0x49d7b8){this['log_']('Unlisten\x20on\x20'+_0x1ead96+'\x20for\x20'+_0x59b785);const _0x5a3440={'p':_0x1ead96},_0x3467fc='n';_0x49d7b8&&(_0x5a3440['q']=_0x366d1b,_0x5a3440['t']=_0x49d7b8),this['sendRequest'](_0x3467fc,_0x5a3440);}['onDisconnectPut'](_0x5e5885,_0x5ae333,_0x1c139e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5e5885,_0x5ae333,_0x1c139e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5e5885,'action':'o','data':_0x5ae333,'onComplete':_0x1c139e});}['onDisconnectMerge'](_0x2e46a2,_0x2a8d36,_0x1dca7f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2e46a2,_0x2a8d36,_0x1dca7f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2e46a2,'action':'om','data':_0x2a8d36,'onComplete':_0x1dca7f});}['onDisconnectCancel'](_0x589501,_0x1462c2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x589501,null,_0x1462c2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x589501,'action':'oc','data':null,'onComplete':_0x1462c2});}['sendOnDisconnect_'](_0x26ccc6,_0x413609,_0x3c064d,_0x1efb7f){const _0x11a6b8={'p':_0x413609,'d':_0x3c064d};this['log_']('onDisconnect\x20'+_0x26ccc6,_0x11a6b8),this['sendRequest'](_0x26ccc6,_0x11a6b8,_0x2fc662=>{_0x1efb7f&&setTimeout(()=>{_0x1efb7f(_0x2fc662['s'],_0x2fc662['d']);},Math['floor'](0x0));});}['put'](_0x457e85,_0x30f279,_0x146319,_0x17e1a2){this['putInternal']('p',_0x457e85,_0x30f279,_0x146319,_0x17e1a2);}['merge'](_0x3c5a0c,_0x3616bb,_0x3278d4,_0x5d766a){this['putInternal']('m',_0x3c5a0c,_0x3616bb,_0x3278d4,_0x5d766a);}['putInternal'](_0x1b04be,_0x15041c,_0x3e3603,_0x2fd3cf,_0x128811){this['initConnection_']();const _0x4f0f9d={'p':_0x15041c,'d':_0x3e3603};_0x128811!==void 0x0&&(_0x4f0f9d['h']=_0x128811),this['outstandingPuts_']['push']({'action':_0x1b04be,'request':_0x4f0f9d,'onComplete':_0x2fd3cf}),this['outstandingPutCount_']++;const _0x55536c=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x55536c):this['log_']('Buffering\x20put:\x20'+_0x15041c);}['sendPut_'](_0x201319){const _0x56b369=this['outstandingPuts_'][_0x201319]['action'],_0xff40af=this['outstandingPuts_'][_0x201319]['request'],_0xfd781a=this['outstandingPuts_'][_0x201319]['onComplete'];this['outstandingPuts_'][_0x201319]['queued']=this['connected_'],this['sendRequest'](_0x56b369,_0xff40af,_0x257ecb=>{this['log_'](_0x56b369+'\x20response',_0x257ecb),delete this['outstandingPuts_'][_0x201319],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xfd781a&&_0xfd781a(_0x257ecb['s'],_0x257ecb['d']);});}['reportStats'](_0x285202){if(this['connected_']){const _0x155fa8={'c':_0x285202};this['log_']('reportStats',_0x155fa8),this['sendRequest']('s',_0x155fa8,_0xccd90f=>{if(_0xccd90f['s']!=='ok'){const _0x48dc03=_0xccd90f['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x48dc03);}});}}['onDataMessage_'](_0x2c9d6e){if('r'in _0x2c9d6e){this['log_']('from\x20server:\x20'+O(_0x2c9d6e));const _0x82c979=_0x2c9d6e['r'],_0x521b2b=this['requestCBHash_'][_0x82c979];_0x521b2b&&(delete this['requestCBHash_'][_0x82c979],_0x521b2b(_0x2c9d6e['b']));}else{if('error'in _0x2c9d6e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2c9d6e['error'];'a'in _0x2c9d6e&&this['onDataPush_'](_0x2c9d6e['a'],_0x2c9d6e['b']);}}['onDataPush_'](_0x2d4a10,_0x53ebc4){this['log_']('handleServerMessage',_0x2d4a10,_0x53ebc4),_0x2d4a10==='d'?this['onDataUpdate_'](_0x53ebc4['p'],_0x53ebc4['d'],!0x1,_0x53ebc4['t']):_0x2d4a10==='m'?this['onDataUpdate_'](_0x53ebc4['p'],_0x53ebc4['d'],!0x0,_0x53ebc4['t']):_0x2d4a10==='c'?this['onListenRevoked_'](_0x53ebc4['p'],_0x53ebc4['q']):_0x2d4a10==='ac'?this['onAuthRevoked_'](_0x53ebc4['s'],_0x53ebc4['d']):_0x2d4a10==='apc'?this['onAppCheckRevoked_'](_0x53ebc4['s'],_0x53ebc4['d']):_0x2d4a10==='sd'?this['onSecurityDebugPacket_'](_0x53ebc4):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2d4a10)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1935a8,_0x478fa7){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1935a8),this['lastSessionId']=_0x478fa7,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3673d2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3673d2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x10a487){_0x10a487&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x10a487;}['onOnline_'](_0x3d9448){_0x3d9448?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xd45ce0=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2d8b6e=Math['max'](0x0,this['reconnectDelay_']-_0xd45ce0);_0x2d8b6e=Math['random']()*_0x2d8b6e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2d8b6e+'ms'),this['scheduleConnect_'](_0x2d8b6e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5da3ee=this['onDataMessage_']['bind'](this),_0x519cff=this['onReady_']['bind'](this),_0x52ed1d=this['onRealtimeDisconnect_']['bind'](this),_0x391a96=this['id']+':'+ie['nextConnectionId_']++,_0x4e802f=this['lastSessionId'];let _0x46615d=!0x1,_0x36c719=null;const _0x2b6fd1=function(){_0x36c719?_0x36c719['close']():(_0x46615d=!0x0,_0x52ed1d());},_0x33b02f=function(_0x23d7bb){f(_0x36c719,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x36c719['sendRequest'](_0x23d7bb);};this['realtime_']={'close':_0x2b6fd1,'sendRequest':_0x33b02f};const _0x5615d9=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x42cda3,_0x3bc358]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5615d9),this['appCheckTokenProvider_']['getToken'](_0x5615d9)]);_0x46615d?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x42cda3&&_0x42cda3['accessToken'],this['appCheckToken_']=_0x3bc358&&_0x3bc358['token'],_0x36c719=new wh(_0x391a96,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5da3ee,_0x519cff,_0x52ed1d,_0x5a14e6=>{U(_0x5a14e6+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x4e802f));}catch(_0x2d2db0){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2d2db0),_0x46615d||(this['repoInfo_']['nodeAdmin']&&U(_0x2d2db0),_0x2b6fd1());}}}['interrupt'](_0x541e63){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x541e63),this['interruptReasons_'][_0x541e63]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4f183c){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4f183c),delete this['interruptReasons_'][_0x4f183c],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3a13ce){const _0x420ebb=_0x3a13ce-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x420ebb});}['cancelSentTransactions_'](){for(let _0x1dfe5c=0x0;_0x1dfe5c<this['outstandingPuts_']['length'];_0x1dfe5c++){const _0x23b2d9=this['outstandingPuts_'][_0x1dfe5c];_0x23b2d9&&'h'in _0x23b2d9['request']&&_0x23b2d9['queued']&&(_0x23b2d9['onComplete']&&_0x23b2d9['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1dfe5c],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x53d9bd,_0x5a44cc){let _0x16f77b;_0x5a44cc?_0x16f77b=_0x5a44cc['map'](_0x55aded=>Bi(_0x55aded))['join']('$'):_0x16f77b='default';const _0x1bb491=this['removeListen_'](_0x53d9bd,_0x16f77b);_0x1bb491&&_0x1bb491['onComplete']&&_0x1bb491['onComplete']('permission_denied');}['removeListen_'](_0x5e8d59,_0x543f8c){const _0x11592d=new C(_0x5e8d59)['toString']();let _0x5f2633;if(this['listens']['has'](_0x11592d)){const _0xaf6bb8=this['listens']['get'](_0x11592d);_0x5f2633=_0xaf6bb8['get'](_0x543f8c),_0xaf6bb8['delete'](_0x543f8c),_0xaf6bb8['size']===0x0&&this['listens']['delete'](_0x11592d);}else _0x5f2633=void 0x0;return _0x5f2633;}['onAuthRevoked_'](_0x4022f5,_0x276c49){L('Auth\x20token\x20revoked:\x20'+_0x4022f5+'/'+_0x276c49),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4022f5==='invalid_token'||_0x4022f5==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x442dc2,_0xaf71b0){L('App\x20check\x20token\x20revoked:\x20'+_0x442dc2+'/'+_0xaf71b0),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x442dc2==='invalid_token'||_0x442dc2==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x49c157){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x49c157):'msg'in _0x49c157&&console['log']('FIREBASE:\x20'+_0x49c157['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x292719 of this['listens']['values']())for(const _0x1cfcf1 of _0x292719['values']())this['sendListen_'](_0x1cfcf1);for(let _0x27ca7b=0x0;_0x27ca7b<this['outstandingPuts_']['length'];_0x27ca7b++)this['outstandingPuts_'][_0x27ca7b]&&this['sendPut_'](_0x27ca7b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x456c3d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x456c3d['action'],_0x456c3d['pathString'],_0x456c3d['data'],_0x456c3d['onComplete']);}for(let _0x2f2a77=0x0;_0x2f2a77<this['outstandingGets_']['length'];_0x2f2a77++)this['outstandingGets_'][_0x2f2a77]&&this['sendGet_'](_0x2f2a77);}['sendConnectStats_'](){const _0x4c3127={};let _0x4596eb='js';_0x4c3127['sdk.'+_0x4596eb+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x4c3127['framework.cordova']=0x1:qr()&&(_0x4c3127['framework.reactnative']=0x1),this['reportStats'](_0x4c3127);}['shouldReconnect_'](){const _0x598849=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x598849;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x324b9,_0x55b1d7){this['name']=_0x324b9,this['node']=_0x55b1d7;}static['Wrap'](_0x2fd5bb,_0x41f7f6){return new E(_0x2fd5bb,_0x41f7f6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5c2de3,_0x5cbf29){const _0x118aae=new E(xe,_0x5c2de3),_0x4fe56d=new E(xe,_0x5cbf29);return this['compare'](_0x118aae,_0x4fe56d)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x3add71){Xt=_0x3add71;}['compare'](_0x515912,_0x1489a3){return He(_0x515912['name'],_0x1489a3['name']);}['isDefinedOn'](_0x1c5617){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x299a2b,_0x47ac54){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3535f4,_0x10d368){return f(typeof _0x3535f4=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3535f4,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x47f833,_0x3bb47a,_0x5cd1eb,_0x2f8ec3,_0x2f28b3=null){this['isReverse_']=_0x2f8ec3,this['resultGenerator_']=_0x2f28b3,this['nodeStack_']=[];let _0x33909f=0x1;for(;!_0x47f833['isEmpty']();)if(_0x47f833=_0x47f833,_0x33909f=_0x3bb47a?_0x5cd1eb(_0x47f833['key'],_0x3bb47a):0x1,_0x2f8ec3&&(_0x33909f*=-0x1),_0x33909f<0x0)this['isReverse_']?_0x47f833=_0x47f833['left']:_0x47f833=_0x47f833['right'];else{if(_0x33909f===0x0){this['nodeStack_']['push'](_0x47f833);break;}else this['nodeStack_']['push'](_0x47f833),this['isReverse_']?_0x47f833=_0x47f833['right']:_0x47f833=_0x47f833['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x48e453=this['nodeStack_']['pop'](),_0x103b8c;if(this['resultGenerator_']?_0x103b8c=this['resultGenerator_'](_0x48e453['key'],_0x48e453['value']):_0x103b8c={'key':_0x48e453['key'],'value':_0x48e453['value']},this['isReverse_']){for(_0x48e453=_0x48e453['left'];!_0x48e453['isEmpty']();)this['nodeStack_']['push'](_0x48e453),_0x48e453=_0x48e453['right'];}else{for(_0x48e453=_0x48e453['right'];!_0x48e453['isEmpty']();)this['nodeStack_']['push'](_0x48e453),_0x48e453=_0x48e453['left'];}return _0x103b8c;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xb0338a=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xb0338a['key'],_0xb0338a['value']):{'key':_0xb0338a['key'],'value':_0xb0338a['value']};}}class M{constructor(_0x2202c5,_0x45423a,_0x2c8a3e,_0x54182f,_0x40c40b){this['key']=_0x2202c5,this['value']=_0x45423a,this['color']=_0x2c8a3e??M['RED'],this['left']=_0x54182f??B['EMPTY_NODE'],this['right']=_0x40c40b??B['EMPTY_NODE'];}['copy'](_0x2076d5,_0x17d962,_0xd231e5,_0x36c329,_0x461860){return new M(_0x2076d5??this['key'],_0x17d962??this['value'],_0xd231e5??this['color'],_0x36c329??this['left'],_0x461860??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x265baa){return this['left']['inorderTraversal'](_0x265baa)||!!_0x265baa(this['key'],this['value'])||this['right']['inorderTraversal'](_0x265baa);}['reverseTraversal'](_0x51e956){return this['right']['reverseTraversal'](_0x51e956)||_0x51e956(this['key'],this['value'])||this['left']['reverseTraversal'](_0x51e956);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xc125d8,_0x1b0a68,_0x3748de){let _0x48efb0=this;const _0x10d9a9=_0x3748de(_0xc125d8,_0x48efb0['key']);return _0x10d9a9<0x0?_0x48efb0=_0x48efb0['copy'](null,null,null,_0x48efb0['left']['insert'](_0xc125d8,_0x1b0a68,_0x3748de),null):_0x10d9a9===0x0?_0x48efb0=_0x48efb0['copy'](null,_0x1b0a68,null,null,null):_0x48efb0=_0x48efb0['copy'](null,null,null,null,_0x48efb0['right']['insert'](_0xc125d8,_0x1b0a68,_0x3748de)),_0x48efb0['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2cbb9b=this;return!_0x2cbb9b['left']['isRed_']()&&!_0x2cbb9b['left']['left']['isRed_']()&&(_0x2cbb9b=_0x2cbb9b['moveRedLeft_']()),_0x2cbb9b=_0x2cbb9b['copy'](null,null,null,_0x2cbb9b['left']['removeMin_'](),null),_0x2cbb9b['fixUp_']();}['remove'](_0x2bf0d8,_0x392e03){let _0x3aae00,_0x40d8fc;if(_0x3aae00=this,_0x392e03(_0x2bf0d8,_0x3aae00['key'])<0x0)!_0x3aae00['left']['isEmpty']()&&!_0x3aae00['left']['isRed_']()&&!_0x3aae00['left']['left']['isRed_']()&&(_0x3aae00=_0x3aae00['moveRedLeft_']()),_0x3aae00=_0x3aae00['copy'](null,null,null,_0x3aae00['left']['remove'](_0x2bf0d8,_0x392e03),null);else{if(_0x3aae00['left']['isRed_']()&&(_0x3aae00=_0x3aae00['rotateRight_']()),!_0x3aae00['right']['isEmpty']()&&!_0x3aae00['right']['isRed_']()&&!_0x3aae00['right']['left']['isRed_']()&&(_0x3aae00=_0x3aae00['moveRedRight_']()),_0x392e03(_0x2bf0d8,_0x3aae00['key'])===0x0){if(_0x3aae00['right']['isEmpty']())return B['EMPTY_NODE'];_0x40d8fc=_0x3aae00['right']['min_'](),_0x3aae00=_0x3aae00['copy'](_0x40d8fc['key'],_0x40d8fc['value'],null,null,_0x3aae00['right']['removeMin_']());}_0x3aae00=_0x3aae00['copy'](null,null,null,null,_0x3aae00['right']['remove'](_0x2bf0d8,_0x392e03));}return _0x3aae00['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x421485=this;return _0x421485['right']['isRed_']()&&!_0x421485['left']['isRed_']()&&(_0x421485=_0x421485['rotateLeft_']()),_0x421485['left']['isRed_']()&&_0x421485['left']['left']['isRed_']()&&(_0x421485=_0x421485['rotateRight_']()),_0x421485['left']['isRed_']()&&_0x421485['right']['isRed_']()&&(_0x421485=_0x421485['colorFlip_']()),_0x421485;}['moveRedLeft_'](){let _0x551d35=this['colorFlip_']();return _0x551d35['right']['left']['isRed_']()&&(_0x551d35=_0x551d35['copy'](null,null,null,null,_0x551d35['right']['rotateRight_']()),_0x551d35=_0x551d35['rotateLeft_'](),_0x551d35=_0x551d35['colorFlip_']()),_0x551d35;}['moveRedRight_'](){let _0xb3cb20=this['colorFlip_']();return _0xb3cb20['left']['left']['isRed_']()&&(_0xb3cb20=_0xb3cb20['rotateRight_'](),_0xb3cb20=_0xb3cb20['colorFlip_']()),_0xb3cb20;}['rotateLeft_'](){const _0x1f8500=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1f8500,null);}['rotateRight_'](){const _0x77c6a4=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x77c6a4);}['colorFlip_'](){const _0x5f2f59=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1201bb=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5f2f59,_0x1201bb);}['checkMaxDepth_'](){const _0x56e2c4=this['check_']();return Math['pow'](0x2,_0x56e2c4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2bc7a4=this['left']['check_']();if(_0x2bc7a4!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2bc7a4+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x4d07ea,_0x925bb9,_0x997010,_0x183477,_0x16a15d){return this;}['insert'](_0x24ef0b,_0x1a66f9,_0x3ec7c){return new M(_0x24ef0b,_0x1a66f9,null);}['remove'](_0x3503f6,_0x5c0022){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1bcd48){return!0x1;}['reverseTraversal'](_0x3fdaa4){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5a37c6,_0x2a8d55=B['EMPTY_NODE']){this['comparator_']=_0x5a37c6,this['root_']=_0x2a8d55;}['insert'](_0x53f5df,_0x130780){return new B(this['comparator_'],this['root_']['insert'](_0x53f5df,_0x130780,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x11cb6b){return new B(this['comparator_'],this['root_']['remove'](_0x11cb6b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x17b3ec){let _0x30f1fa,_0x354d2b=this['root_'];for(;!_0x354d2b['isEmpty']();){if(_0x30f1fa=this['comparator_'](_0x17b3ec,_0x354d2b['key']),_0x30f1fa===0x0)return _0x354d2b['value'];_0x30f1fa<0x0?_0x354d2b=_0x354d2b['left']:_0x30f1fa>0x0&&(_0x354d2b=_0x354d2b['right']);}return null;}['getPredecessorKey'](_0x4c70cb){let _0x26889b,_0x39ad41=this['root_'],_0x3dbe95=null;for(;!_0x39ad41['isEmpty']();)if(_0x26889b=this['comparator_'](_0x4c70cb,_0x39ad41['key']),_0x26889b===0x0){if(_0x39ad41['left']['isEmpty']())return _0x3dbe95?_0x3dbe95['key']:null;for(_0x39ad41=_0x39ad41['left'];!_0x39ad41['right']['isEmpty']();)_0x39ad41=_0x39ad41['right'];return _0x39ad41['key'];}else _0x26889b<0x0?_0x39ad41=_0x39ad41['left']:_0x26889b>0x0&&(_0x3dbe95=_0x39ad41,_0x39ad41=_0x39ad41['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x32ecec){return this['root_']['inorderTraversal'](_0x32ecec);}['reverseTraversal'](_0x24ca61){return this['root_']['reverseTraversal'](_0x24ca61);}['getIterator'](_0x51be7b){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x51be7b);}['getIteratorFrom'](_0x3cfee0,_0x531c89){return new Zt(this['root_'],_0x3cfee0,this['comparator_'],!0x1,_0x531c89);}['getReverseIteratorFrom'](_0x20f705,_0x37d4bf){return new Zt(this['root_'],_0x20f705,this['comparator_'],!0x0,_0x37d4bf);}['getReverseIterator'](_0x266d04){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x266d04);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x15ef26,_0x285b2c){return He(_0x15ef26['name'],_0x285b2c['name']);}function ji(_0x1cf69c,_0x59c351){return He(_0x1cf69c,_0x59c351);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x2fdcad){vi=_0x2fdcad;}const Ro=function(_0x58d92a){return typeof _0x58d92a=='number'?'number:'+so(_0x58d92a):'string:'+_0x58d92a;},Ao=function(_0x5968d3){if(_0x5968d3['isLeafNode']()){const _0x4b387c=_0x5968d3['val']();f(typeof _0x4b387c=='string'||typeof _0x4b387c=='number'||typeof _0x4b387c=='object'&&Y(_0x4b387c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5968d3===vi||_0x5968d3['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5968d3===vi||_0x5968d3['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x557d28){er=_0x557d28;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2be4af,_0x18e096=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2be4af,this['priorityNode_']=_0x18e096,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x957b7e){return new D(this['value_'],_0x957b7e);}['getImmediateChild'](_0x386826){return _0x386826==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4f7ea7){return v(_0x4f7ea7)?this:y(_0x4f7ea7)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x165686,_0x47bfba){return null;}['updateImmediateChild'](_0x1acbd2,_0x31a479){return _0x1acbd2==='.priority'?this['updatePriority'](_0x31a479):_0x31a479['isEmpty']()&&_0x1acbd2!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1acbd2,_0x31a479)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xc78592,_0x3a204d){const _0x52e23e=y(_0xc78592);return _0x52e23e===null?_0x3a204d:_0x3a204d['isEmpty']()&&_0x52e23e!=='.priority'?this:(f(_0x52e23e!=='.priority'||we(_0xc78592)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x52e23e,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0xc78592),_0x3a204d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x45ec88,_0x2df6f0){return!0x1;}['val'](_0x4ed5c5){return _0x4ed5c5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x56bc5e='';this['priorityNode_']['isEmpty']()||(_0x56bc5e+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x181176=typeof this['value_'];_0x56bc5e+=_0x181176+':',_0x181176==='number'?_0x56bc5e+=so(this['value_']):_0x56bc5e+=this['value_'],this['lazyHash_']=no(_0x56bc5e);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4ac270){return _0x4ac270===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4ac270 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4ac270['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4ac270));}['compareToLeafNode_'](_0xaf4f94){const _0x4a41ee=typeof _0xaf4f94['value_'],_0x41c8df=typeof this['value_'],_0x205db3=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a41ee),_0x3ba8dc=D['VALUE_TYPE_ORDER']['indexOf'](_0x41c8df);return f(_0x205db3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a41ee),f(_0x3ba8dc>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x41c8df),_0x205db3===_0x3ba8dc?_0x41c8df==='object'?0x0:this['value_']<_0xaf4f94['value_']?-0x1:this['value_']===_0xaf4f94['value_']?0x0:0x1:_0x3ba8dc-_0x205db3;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x18c6f1){if(_0x18c6f1===this)return!0x0;if(_0x18c6f1['isLeafNode']()){const _0x9e87d9=_0x18c6f1;return this['value_']===_0x9e87d9['value_']&&this['priorityNode_']['equals'](_0x9e87d9['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3dfd9b){ko=_0x3dfd9b;}function xh(_0x3f8321){No=_0x3f8321;}class Fh extends On{['compare'](_0x43edff,_0x2a2bba){const _0x303820=_0x43edff['node']['getPriority'](),_0x3b5940=_0x2a2bba['node']['getPriority'](),_0x46dbd4=_0x303820['compareTo'](_0x3b5940);return _0x46dbd4===0x0?He(_0x43edff['name'],_0x2a2bba['name']):_0x46dbd4;}['isDefinedOn'](_0x481674){return!_0x481674['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4164ad,_0x23e95d){return!_0x4164ad['getPriority']()['equals'](_0x23e95d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x4d898f,_0x236b1a){const _0x262cbd=ko(_0x4d898f);return new E(_0x236b1a,new D('[PRIORITY-POST]',_0x262cbd));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x5ca06a){const _0x28b5fa=_0x1806fe=>parseInt(Math['log'](_0x1806fe)/Uh,0xa),_0x1689e4=_0x2ff522=>parseInt(Array(_0x2ff522+0x1)['join']('1'),0x2);this['count']=_0x28b5fa(_0x5ca06a+0x1),this['current_']=this['count']-0x1;const _0x51c133=_0x1689e4(this['count']);this['bits_']=_0x5ca06a+0x1&_0x51c133;}['nextBitIsOne'](){const _0x360dfe=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x360dfe;}}const dn=function(_0x1d0f2d,_0x4d620e,_0x322677,_0x2cf528){_0x1d0f2d['sort'](_0x4d620e);const _0x25853d=function(_0x343c73,_0x2543b6){const _0x2ec821=_0x2543b6-_0x343c73;let _0x2dfda3,_0x3a2ca7;if(_0x2ec821===0x0)return null;if(_0x2ec821===0x1)return _0x2dfda3=_0x1d0f2d[_0x343c73],_0x3a2ca7=_0x322677?_0x322677(_0x2dfda3):_0x2dfda3,new M(_0x3a2ca7,_0x2dfda3['node'],M['BLACK'],null,null);{const _0x1e94dc=parseInt(_0x2ec821/0x2,0xa)+_0x343c73,_0x412aac=_0x25853d(_0x343c73,_0x1e94dc),_0x1db36f=_0x25853d(_0x1e94dc+0x1,_0x2543b6);return _0x2dfda3=_0x1d0f2d[_0x1e94dc],_0x3a2ca7=_0x322677?_0x322677(_0x2dfda3):_0x2dfda3,new M(_0x3a2ca7,_0x2dfda3['node'],M['BLACK'],_0x412aac,_0x1db36f);}},_0x2b88d9=function(_0x204def){let _0x1f4c7c=null,_0x1042b7=null,_0x1662a0=_0x1d0f2d['length'];const _0x210b66=function(_0x31fa32,_0x3e5dc3){const _0x23e84c=_0x1662a0-_0x31fa32,_0x37f0f6=_0x1662a0;_0x1662a0-=_0x31fa32;const _0x5dfe3a=_0x25853d(_0x23e84c+0x1,_0x37f0f6),_0x31b318=_0x1d0f2d[_0x23e84c],_0x340326=_0x322677?_0x322677(_0x31b318):_0x31b318;_0x5df845(new M(_0x340326,_0x31b318['node'],_0x3e5dc3,null,_0x5dfe3a));},_0x5df845=function(_0x3e3af3){_0x1f4c7c?(_0x1f4c7c['left']=_0x3e3af3,_0x1f4c7c=_0x3e3af3):(_0x1042b7=_0x3e3af3,_0x1f4c7c=_0x3e3af3);};for(let _0x3873dc=0x0;_0x3873dc<_0x204def['count'];++_0x3873dc){const _0xd48c3e=_0x204def['nextBitIsOne'](),_0x3f5c0a=Math['pow'](0x2,_0x204def['count']-(_0x3873dc+0x1));_0xd48c3e?_0x210b66(_0x3f5c0a,M['BLACK']):(_0x210b66(_0x3f5c0a,M['BLACK']),_0x210b66(_0x3f5c0a,M['RED']));}return _0x1042b7;},_0x649dc3=new Wh(_0x1d0f2d['length']),_0x3a1240=_0x2b88d9(_0x649dc3);return new B(_0x2cf528||_0x4d620e,_0x3a1240);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2d60cd,_0x35d08e){this['indexes_']=_0x2d60cd,this['indexSet_']=_0x35d08e;}['get'](_0x1399d9){const _0x3a9b98=Oe(this['indexes_'],_0x1399d9);if(!_0x3a9b98)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1399d9);return _0x3a9b98 instanceof B?_0x3a9b98:null;}['hasIndex'](_0x1ff288){return Y(this['indexSet_'],_0x1ff288['toString']());}['addIndex'](_0x5b46ed,_0x23453b){f(_0x5b46ed!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x5e8409=[];let _0x1c8b17=!0x1;const _0x502f83=_0x23453b['getIterator'](E['Wrap']);let _0x318705=_0x502f83['getNext']();for(;_0x318705;)_0x1c8b17=_0x1c8b17||_0x5b46ed['isDefinedOn'](_0x318705['node']),_0x5e8409['push'](_0x318705),_0x318705=_0x502f83['getNext']();let _0x4a0ff6;_0x1c8b17?_0x4a0ff6=dn(_0x5e8409,_0x5b46ed['getCompare']()):_0x4a0ff6=je;const _0x5a27af=_0x5b46ed['toString'](),_0x4fe4df={...this['indexSet_']};_0x4fe4df[_0x5a27af]=_0x5b46ed;const _0x49bd18={...this['indexes_']};return _0x49bd18[_0x5a27af]=_0x4a0ff6,new ee(_0x49bd18,_0x4fe4df);}['addToIndexes'](_0x2094f4,_0x177e43){const _0x12c52d=ln(this['indexes_'],(_0x574184,_0x57b224)=>{const _0x486038=Oe(this['indexSet_'],_0x57b224);if(f(_0x486038,'Missing\x20index\x20implementation\x20for\x20'+_0x57b224),_0x574184===je){if(_0x486038['isDefinedOn'](_0x2094f4['node'])){const _0x270cc6=[],_0xceb2cc=_0x177e43['getIterator'](E['Wrap']);let _0x503059=_0xceb2cc['getNext']();for(;_0x503059;)_0x503059['name']!==_0x2094f4['name']&&_0x270cc6['push'](_0x503059),_0x503059=_0xceb2cc['getNext']();return _0x270cc6['push'](_0x2094f4),dn(_0x270cc6,_0x486038['getCompare']());}else return je;}else{const _0x5341f3=_0x177e43['get'](_0x2094f4['name']);let _0x4251e6=_0x574184;return _0x5341f3&&(_0x4251e6=_0x4251e6['remove'](new E(_0x2094f4['name'],_0x5341f3))),_0x4251e6['insert'](_0x2094f4,_0x2094f4['node']);}});return new ee(_0x12c52d,this['indexSet_']);}['removeFromIndexes'](_0x50fb09,_0x17a508){const _0x294534=ln(this['indexes_'],_0x358919=>{if(_0x358919===je)return _0x358919;{const _0x417b40=_0x17a508['get'](_0x50fb09['name']);return _0x417b40?_0x358919['remove'](new E(_0x50fb09['name'],_0x417b40)):_0x358919;}});return new ee(_0x294534,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x5cdcdd,_0x3f15f7,_0x393f2a){this['children_']=_0x5cdcdd,this['priorityNode_']=_0x3f15f7,this['indexMap_']=_0x393f2a,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1f30dd){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1f30dd,this['indexMap_']);}['getImmediateChild'](_0x25639b){if(_0x25639b==='.priority')return this['getPriority']();{const _0x161e5f=this['children_']['get'](_0x25639b);return _0x161e5f===null?gt:_0x161e5f;}}['getChild'](_0x4ba656){const _0x4b784d=y(_0x4ba656);return _0x4b784d===null?this:this['getImmediateChild'](_0x4b784d)['getChild'](b(_0x4ba656));}['hasChild'](_0x4a34f1){return this['children_']['get'](_0x4a34f1)!==null;}['updateImmediateChild'](_0x147318,_0x1669fd){if(f(_0x1669fd,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x147318==='.priority')return this['updatePriority'](_0x1669fd);{const _0x488a85=new E(_0x147318,_0x1669fd);let _0x3d6f1c,_0x2579ef;_0x1669fd['isEmpty']()?(_0x3d6f1c=this['children_']['remove'](_0x147318),_0x2579ef=this['indexMap_']['removeFromIndexes'](_0x488a85,this['children_'])):(_0x3d6f1c=this['children_']['insert'](_0x147318,_0x1669fd),_0x2579ef=this['indexMap_']['addToIndexes'](_0x488a85,this['children_']));const _0x2b3d4b=_0x3d6f1c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x3d6f1c,_0x2b3d4b,_0x2579ef);}}['updateChild'](_0x5c8f72,_0x5b8ee1){const _0xa49580=y(_0x5c8f72);if(_0xa49580===null)return _0x5b8ee1;{f(y(_0x5c8f72)!=='.priority'||we(_0x5c8f72)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x3f25d4=this['getImmediateChild'](_0xa49580)['updateChild'](b(_0x5c8f72),_0x5b8ee1);return this['updateImmediateChild'](_0xa49580,_0x3f25d4);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x44fc50){if(this['isEmpty']())return null;const _0x1ed5ab={};let _0x29ac45=0x0,_0x3eb52f=0x0,_0x162617=!0x0;if(this['forEachChild'](R,(_0x2ca5d7,_0x271bde)=>{_0x1ed5ab[_0x2ca5d7]=_0x271bde['val'](_0x44fc50),_0x29ac45++,_0x162617&&g['INTEGER_REGEXP_']['test'](_0x2ca5d7)?_0x3eb52f=Math['max'](_0x3eb52f,Number(_0x2ca5d7)):_0x162617=!0x1;}),!_0x44fc50&&_0x162617&&_0x3eb52f<0x2*_0x29ac45){const _0x477218=[];for(const _0x244c75 in _0x1ed5ab)_0x477218[_0x244c75]=_0x1ed5ab[_0x244c75];return _0x477218;}else return _0x44fc50&&!this['getPriority']()['isEmpty']()&&(_0x1ed5ab['.priority']=this['getPriority']()['val']()),_0x1ed5ab;}['hash'](){if(this['lazyHash_']===null){let _0x372a81='';this['getPriority']()['isEmpty']()||(_0x372a81+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x234268,_0x1fe9fc)=>{const _0x27ba4b=_0x1fe9fc['hash']();_0x27ba4b!==''&&(_0x372a81+=':'+_0x234268+':'+_0x27ba4b);}),this['lazyHash_']=_0x372a81===''?'':no(_0x372a81);}return this['lazyHash_'];}['getPredecessorChildName'](_0x14efe5,_0x26abc1,_0x5ed6a8){const _0x5000df=this['resolveIndex_'](_0x5ed6a8);if(_0x5000df){const _0x17b50a=_0x5000df['getPredecessorKey'](new E(_0x14efe5,_0x26abc1));return _0x17b50a?_0x17b50a['name']:null;}else return this['children_']['getPredecessorKey'](_0x14efe5);}['getFirstChildName'](_0x8c5a99){const _0x451397=this['resolveIndex_'](_0x8c5a99);if(_0x451397){const _0x50592d=_0x451397['minKey']();return _0x50592d&&_0x50592d['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x49da9c){const _0x59c704=this['getFirstChildName'](_0x49da9c);return _0x59c704?new E(_0x59c704,this['children_']['get'](_0x59c704)):null;}['getLastChildName'](_0x10c2ba){const _0x115a67=this['resolveIndex_'](_0x10c2ba);if(_0x115a67){const _0x1a66a6=_0x115a67['maxKey']();return _0x1a66a6&&_0x1a66a6['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x292475){const _0x1b3c6e=this['getLastChildName'](_0x292475);return _0x1b3c6e?new E(_0x1b3c6e,this['children_']['get'](_0x1b3c6e)):null;}['forEachChild'](_0x5d7aa1,_0x3ec641){const _0x4dd339=this['resolveIndex_'](_0x5d7aa1);return _0x4dd339?_0x4dd339['inorderTraversal'](_0x1c1105=>_0x3ec641(_0x1c1105['name'],_0x1c1105['node'])):this['children_']['inorderTraversal'](_0x3ec641);}['getIterator'](_0x3c243a){return this['getIteratorFrom'](_0x3c243a['minPost'](),_0x3c243a);}['getIteratorFrom'](_0x432b9e,_0x224d0b){const _0x429ec8=this['resolveIndex_'](_0x224d0b);if(_0x429ec8)return _0x429ec8['getIteratorFrom'](_0x432b9e,_0x576969=>_0x576969);{const _0x33fdfb=this['children_']['getIteratorFrom'](_0x432b9e['name'],E['Wrap']);let _0x2e52d9=_0x33fdfb['peek']();for(;_0x2e52d9!=null&&_0x224d0b['compare'](_0x2e52d9,_0x432b9e)<0x0;)_0x33fdfb['getNext'](),_0x2e52d9=_0x33fdfb['peek']();return _0x33fdfb;}}['getReverseIterator'](_0x227170){return this['getReverseIteratorFrom'](_0x227170['maxPost'](),_0x227170);}['getReverseIteratorFrom'](_0x3c7828,_0x1403dd){const _0x3672d8=this['resolveIndex_'](_0x1403dd);if(_0x3672d8)return _0x3672d8['getReverseIteratorFrom'](_0x3c7828,_0x2ad147=>_0x2ad147);{const _0x3e3b60=this['children_']['getReverseIteratorFrom'](_0x3c7828['name'],E['Wrap']);let _0x587552=_0x3e3b60['peek']();for(;_0x587552!=null&&_0x1403dd['compare'](_0x587552,_0x3c7828)>0x0;)_0x3e3b60['getNext'](),_0x587552=_0x3e3b60['peek']();return _0x3e3b60;}}['compareTo'](_0x22b1d2){return this['isEmpty']()?_0x22b1d2['isEmpty']()?0x0:-0x1:_0x22b1d2['isLeafNode']()||_0x22b1d2['isEmpty']()?0x1:_0x22b1d2===Ht?-0x1:0x0;}['withIndex'](_0x3e179a){if(_0x3e179a===ye||this['indexMap_']['hasIndex'](_0x3e179a))return this;{const _0x540a44=this['indexMap_']['addIndex'](_0x3e179a,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x540a44);}}['isIndexed'](_0x39a9f0){return _0x39a9f0===ye||this['indexMap_']['hasIndex'](_0x39a9f0);}['equals'](_0x3ea62f){if(_0x3ea62f===this)return!0x0;if(_0x3ea62f['isLeafNode']())return!0x1;{const _0x5a442e=_0x3ea62f;if(this['getPriority']()['equals'](_0x5a442e['getPriority']())){if(this['children_']['count']()===_0x5a442e['children_']['count']()){const _0x214ca1=this['getIterator'](R),_0xc64bc=_0x5a442e['getIterator'](R);let _0x51b182=_0x214ca1['getNext'](),_0x1a4cde=_0xc64bc['getNext']();for(;_0x51b182&&_0x1a4cde;){if(_0x51b182['name']!==_0x1a4cde['name']||!_0x51b182['node']['equals'](_0x1a4cde['node']))return!0x1;_0x51b182=_0x214ca1['getNext'](),_0x1a4cde=_0xc64bc['getNext']();}return _0x51b182===null&&_0x1a4cde===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x516473){return _0x516473===ye?null:this['indexMap_']['get'](_0x516473['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x4010b9){return _0x4010b9===this?0x0:0x1;}['equals'](_0x38aa85){return _0x38aa85===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4976d7){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x3d346d,_0x18896a=null){if(_0x3d346d===null)return g['EMPTY_NODE'];if(typeof _0x3d346d=='object'&&'.priority'in _0x3d346d&&(_0x18896a=_0x3d346d['.priority']),f(_0x18896a===null||typeof _0x18896a=='string'||typeof _0x18896a=='number'||typeof _0x18896a=='object'&&'.sv'in _0x18896a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x18896a),typeof _0x3d346d=='object'&&'.value'in _0x3d346d&&_0x3d346d['.value']!==null&&(_0x3d346d=_0x3d346d['.value']),typeof _0x3d346d!='object'||'.sv'in _0x3d346d){const _0x3e9519=_0x3d346d;return new D(_0x3e9519,N(_0x18896a));}if(!(_0x3d346d instanceof Array)&&Vh){const _0xfbb6ea=[];let _0x5182ec=!0x1;if(x(_0x3d346d,(_0x49d64d,_0x17334b)=>{if(_0x49d64d['substring'](0x0,0x1)!=='.'){const _0x3b875e=N(_0x17334b);_0x3b875e['isEmpty']()||(_0x5182ec=_0x5182ec||!_0x3b875e['getPriority']()['isEmpty'](),_0xfbb6ea['push'](new E(_0x49d64d,_0x3b875e)));}}),_0xfbb6ea['length']===0x0)return g['EMPTY_NODE'];const _0x140e69=dn(_0xfbb6ea,Dh,_0x3d00ab=>_0x3d00ab['name'],ji);if(_0x5182ec){const _0x4395bd=dn(_0xfbb6ea,R['getCompare']());return new g(_0x140e69,N(_0x18896a),new ee({'.priority':_0x4395bd},{'.priority':R}));}else return new g(_0x140e69,N(_0x18896a),ee['Default']);}else{let _0x5a1a8c=g['EMPTY_NODE'];return x(_0x3d346d,(_0x9be5b9,_0x1936fa)=>{if(Y(_0x3d346d,_0x9be5b9)&&_0x9be5b9['substring'](0x0,0x1)!=='.'){const _0x5b9ba3=N(_0x1936fa);(_0x5b9ba3['isLeafNode']()||!_0x5b9ba3['isEmpty']())&&(_0x5a1a8c=_0x5a1a8c['updateImmediateChild'](_0x9be5b9,_0x5b9ba3));}}),_0x5a1a8c['updatePriority'](N(_0x18896a));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x74cfd7){super(),this['indexPath_']=_0x74cfd7,f(!v(_0x74cfd7)&&y(_0x74cfd7)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x336db4){return _0x336db4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4218d3){return!_0x4218d3['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4dce44,_0x4a5f04){const _0x9f3b4e=this['extractChild'](_0x4dce44['node']),_0x5cb425=this['extractChild'](_0x4a5f04['node']),_0x11a1d9=_0x9f3b4e['compareTo'](_0x5cb425);return _0x11a1d9===0x0?He(_0x4dce44['name'],_0x4a5f04['name']):_0x11a1d9;}['makePost'](_0x5024f6,_0x15c515){const _0xea1492=N(_0x5024f6),_0x3ee180=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xea1492);return new E(_0x15c515,_0x3ee180);}['maxPost'](){const _0x29d770=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x29d770);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x410521,_0x4a239b){const _0x3fa6b6=_0x410521['node']['compareTo'](_0x4a239b['node']);return _0x3fa6b6===0x0?He(_0x410521['name'],_0x4a239b['name']):_0x3fa6b6;}['isDefinedOn'](_0x4aa5b0){return!0x0;}['indexedValueChanged'](_0x5e7f8f,_0x30a1f6){return!_0x5e7f8f['equals'](_0x30a1f6);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1ded4a,_0x3817fa){const _0x277650=N(_0x1ded4a);return new E(_0x3817fa,_0x277650);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x350552){return{'type':'value','snapshotNode':_0x350552};}function tt(_0x14a0d0,_0x1e2f17){return{'type':'child_added','snapshotNode':_0x1e2f17,'childName':_0x14a0d0};}function Nt(_0x1b9b99,_0x4bcc03){return{'type':'child_removed','snapshotNode':_0x4bcc03,'childName':_0x1b9b99};}function Pt(_0x413ac9,_0x234bf2,_0xc22e3c){return{'type':'child_changed','snapshotNode':_0x234bf2,'childName':_0x413ac9,'oldSnap':_0xc22e3c};}function $h(_0x21dc2e,_0x58a144){return{'type':'child_moved','snapshotNode':_0x58a144,'childName':_0x21dc2e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0xe73d6c){this['index_']=_0xe73d6c;}['updateChild'](_0x419c35,_0x5f41a8,_0x912a92,_0x33d7aa,_0x4f07cf,_0x3c733b){f(_0x419c35['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x241d02=_0x419c35['getImmediateChild'](_0x5f41a8);return _0x241d02['getChild'](_0x33d7aa)['equals'](_0x912a92['getChild'](_0x33d7aa))&&_0x241d02['isEmpty']()===_0x912a92['isEmpty']()||(_0x3c733b!=null&&(_0x912a92['isEmpty']()?_0x419c35['hasChild'](_0x5f41a8)?_0x3c733b['trackChildChange'](Nt(_0x5f41a8,_0x241d02)):f(_0x419c35['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x241d02['isEmpty']()?_0x3c733b['trackChildChange'](tt(_0x5f41a8,_0x912a92)):_0x3c733b['trackChildChange'](Pt(_0x5f41a8,_0x912a92,_0x241d02))),_0x419c35['isLeafNode']()&&_0x912a92['isEmpty']())?_0x419c35:_0x419c35['updateImmediateChild'](_0x5f41a8,_0x912a92)['withIndex'](this['index_']);}['updateFullNode'](_0x3a6c5c,_0x561fa3,_0x5922d2){return _0x5922d2!=null&&(_0x3a6c5c['isLeafNode']()||_0x3a6c5c['forEachChild'](R,(_0x5c9185,_0x1b53a7)=>{_0x561fa3['hasChild'](_0x5c9185)||_0x5922d2['trackChildChange'](Nt(_0x5c9185,_0x1b53a7));}),_0x561fa3['isLeafNode']()||_0x561fa3['forEachChild'](R,(_0x23da73,_0x5c1372)=>{if(_0x3a6c5c['hasChild'](_0x23da73)){const _0x316602=_0x3a6c5c['getImmediateChild'](_0x23da73);_0x316602['equals'](_0x5c1372)||_0x5922d2['trackChildChange'](Pt(_0x23da73,_0x5c1372,_0x316602));}else _0x5922d2['trackChildChange'](tt(_0x23da73,_0x5c1372));})),_0x561fa3['withIndex'](this['index_']);}['updatePriority'](_0x2d2cb4,_0x2204bc){return _0x2d2cb4['isEmpty']()?g['EMPTY_NODE']:_0x2d2cb4['updatePriority'](_0x2204bc);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x47f019){this['indexedFilter_']=new Yi(_0x47f019['getIndex']()),this['index_']=_0x47f019['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x47f019),this['endPost_']=Ot['getEndPost_'](_0x47f019),this['startIsInclusive_']=!_0x47f019['startAfterSet_'],this['endIsInclusive_']=!_0x47f019['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2e0100){const _0x4893fd=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2e0100)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2e0100)<0x0,_0x5eb719=this['endIsInclusive_']?this['index_']['compare'](_0x2e0100,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2e0100,this['getEndPost']())<0x0;return _0x4893fd&&_0x5eb719;}['updateChild'](_0x4d5c22,_0x1d443d,_0x4f7bab,_0x4eb1ec,_0x191656,_0x44b75e){return this['matches'](new E(_0x1d443d,_0x4f7bab))||(_0x4f7bab=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4d5c22,_0x1d443d,_0x4f7bab,_0x4eb1ec,_0x191656,_0x44b75e);}['updateFullNode'](_0x156e9,_0x424e5b,_0x5d013d){_0x424e5b['isLeafNode']()&&(_0x424e5b=g['EMPTY_NODE']);let _0x96773b=_0x424e5b['withIndex'](this['index_']);_0x96773b=_0x96773b['updatePriority'](g['EMPTY_NODE']);const _0x34ba5a=this;return _0x424e5b['forEachChild'](R,(_0x4c6141,_0x613fb6)=>{_0x34ba5a['matches'](new E(_0x4c6141,_0x613fb6))||(_0x96773b=_0x96773b['updateImmediateChild'](_0x4c6141,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x156e9,_0x96773b,_0x5d013d);}['updatePriority'](_0x3bba1a,_0x1034d7){return _0x3bba1a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x335d86){if(_0x335d86['hasStart']()){const _0x2628bd=_0x335d86['getIndexStartName']();return _0x335d86['getIndex']()['makePost'](_0x335d86['getIndexStartValue'](),_0x2628bd);}else return _0x335d86['getIndex']()['minPost']();}static['getEndPost_'](_0x16f0b8){if(_0x16f0b8['hasEnd']()){const _0x532101=_0x16f0b8['getIndexEndName']();return _0x16f0b8['getIndex']()['makePost'](_0x16f0b8['getIndexEndValue'](),_0x532101);}else return _0x16f0b8['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x5a1835){this['withinDirectionalStart']=_0x4797e4=>this['reverse_']?this['withinEndPost'](_0x4797e4):this['withinStartPost'](_0x4797e4),this['withinDirectionalEnd']=_0x3905a4=>this['reverse_']?this['withinStartPost'](_0x3905a4):this['withinEndPost'](_0x3905a4),this['withinStartPost']=_0x5ed8df=>{const _0x360449=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5ed8df);return this['startIsInclusive_']?_0x360449<=0x0:_0x360449<0x0;},this['withinEndPost']=_0x26be2e=>{const _0x52241f=this['index_']['compare'](_0x26be2e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x52241f<=0x0:_0x52241f<0x0;},this['rangedFilter_']=new Ot(_0x5a1835),this['index_']=_0x5a1835['getIndex'](),this['limit_']=_0x5a1835['getLimit'](),this['reverse_']=!_0x5a1835['isViewFromLeft'](),this['startIsInclusive_']=!_0x5a1835['startAfterSet_'],this['endIsInclusive_']=!_0x5a1835['endBeforeSet_'];}['updateChild'](_0x5a066b,_0x4832ce,_0x49369c,_0x348328,_0x4ffb24,_0x90e40f){return this['rangedFilter_']['matches'](new E(_0x4832ce,_0x49369c))||(_0x49369c=g['EMPTY_NODE']),_0x5a066b['getImmediateChild'](_0x4832ce)['equals'](_0x49369c)?_0x5a066b:_0x5a066b['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5a066b,_0x4832ce,_0x49369c,_0x348328,_0x4ffb24,_0x90e40f):this['fullLimitUpdateChild_'](_0x5a066b,_0x4832ce,_0x49369c,_0x4ffb24,_0x90e40f);}['updateFullNode'](_0x47cea0,_0xfb13a9,_0x5738ad){let _0x2dfb8d;if(_0xfb13a9['isLeafNode']()||_0xfb13a9['isEmpty']())_0x2dfb8d=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xfb13a9['numChildren']()&&_0xfb13a9['isIndexed'](this['index_'])){_0x2dfb8d=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5621c4;this['reverse_']?_0x5621c4=_0xfb13a9['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5621c4=_0xfb13a9['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2a032e=0x0;for(;_0x5621c4['hasNext']()&&_0x2a032e<this['limit_'];){const _0x4f6056=_0x5621c4['getNext']();if(this['withinDirectionalStart'](_0x4f6056)){if(this['withinDirectionalEnd'](_0x4f6056))_0x2dfb8d=_0x2dfb8d['updateImmediateChild'](_0x4f6056['name'],_0x4f6056['node']),_0x2a032e++;else break;}else continue;}}else{_0x2dfb8d=_0xfb13a9['withIndex'](this['index_']),_0x2dfb8d=_0x2dfb8d['updatePriority'](g['EMPTY_NODE']);let _0x2a7e7b;this['reverse_']?_0x2a7e7b=_0x2dfb8d['getReverseIterator'](this['index_']):_0x2a7e7b=_0x2dfb8d['getIterator'](this['index_']);let _0x440224=0x0;for(;_0x2a7e7b['hasNext']();){const _0x5ec428=_0x2a7e7b['getNext']();_0x440224<this['limit_']&&this['withinDirectionalStart'](_0x5ec428)&&this['withinDirectionalEnd'](_0x5ec428)?_0x440224++:_0x2dfb8d=_0x2dfb8d['updateImmediateChild'](_0x5ec428['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x47cea0,_0x2dfb8d,_0x5738ad);}['updatePriority'](_0x2dc6e4,_0x1b25d6){return _0x2dc6e4;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x43543a,_0x5a8c5f,_0x5b0ffb,_0x104c78,_0x186c73){let _0x12139d;if(this['reverse_']){const _0x1e030f=this['index_']['getCompare']();_0x12139d=(_0x284653,_0x5344e4)=>_0x1e030f(_0x5344e4,_0x284653);}else _0x12139d=this['index_']['getCompare']();const _0x4c7380=_0x43543a;f(_0x4c7380['numChildren']()===this['limit_'],'');const _0xebf720=new E(_0x5a8c5f,_0x5b0ffb),_0x168e15=this['reverse_']?_0x4c7380['getFirstChild'](this['index_']):_0x4c7380['getLastChild'](this['index_']),_0x40d46d=this['rangedFilter_']['matches'](_0xebf720);if(_0x4c7380['hasChild'](_0x5a8c5f)){const _0x1d1be3=_0x4c7380['getImmediateChild'](_0x5a8c5f);let _0x26c687=_0x104c78['getChildAfterChild'](this['index_'],_0x168e15,this['reverse_']);for(;_0x26c687!=null&&(_0x26c687['name']===_0x5a8c5f||_0x4c7380['hasChild'](_0x26c687['name']));)_0x26c687=_0x104c78['getChildAfterChild'](this['index_'],_0x26c687,this['reverse_']);const _0x572134=_0x26c687==null?0x1:_0x12139d(_0x26c687,_0xebf720);if(_0x40d46d&&!_0x5b0ffb['isEmpty']()&&_0x572134>=0x0)return _0x186c73!=null&&_0x186c73['trackChildChange'](Pt(_0x5a8c5f,_0x5b0ffb,_0x1d1be3)),_0x4c7380['updateImmediateChild'](_0x5a8c5f,_0x5b0ffb);{_0x186c73!=null&&_0x186c73['trackChildChange'](Nt(_0x5a8c5f,_0x1d1be3));const _0x4005ff=_0x4c7380['updateImmediateChild'](_0x5a8c5f,g['EMPTY_NODE']);return _0x26c687!=null&&this['rangedFilter_']['matches'](_0x26c687)?(_0x186c73!=null&&_0x186c73['trackChildChange'](tt(_0x26c687['name'],_0x26c687['node'])),_0x4005ff['updateImmediateChild'](_0x26c687['name'],_0x26c687['node'])):_0x4005ff;}}else return _0x5b0ffb['isEmpty']()?_0x43543a:_0x40d46d&&_0x12139d(_0x168e15,_0xebf720)>=0x0?(_0x186c73!=null&&(_0x186c73['trackChildChange'](Nt(_0x168e15['name'],_0x168e15['node'])),_0x186c73['trackChildChange'](tt(_0x5a8c5f,_0x5b0ffb))),_0x4c7380['updateImmediateChild'](_0x5a8c5f,_0x5b0ffb)['updateImmediateChild'](_0x168e15['name'],g['EMPTY_NODE'])):_0x43543a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x18ec90=new Qi();return _0x18ec90['limitSet_']=this['limitSet_'],_0x18ec90['limit_']=this['limit_'],_0x18ec90['startSet_']=this['startSet_'],_0x18ec90['startAfterSet_']=this['startAfterSet_'],_0x18ec90['indexStartValue_']=this['indexStartValue_'],_0x18ec90['startNameSet_']=this['startNameSet_'],_0x18ec90['indexStartName_']=this['indexStartName_'],_0x18ec90['endSet_']=this['endSet_'],_0x18ec90['endBeforeSet_']=this['endBeforeSet_'],_0x18ec90['indexEndValue_']=this['indexEndValue_'],_0x18ec90['endNameSet_']=this['endNameSet_'],_0x18ec90['indexEndName_']=this['indexEndName_'],_0x18ec90['index_']=this['index_'],_0x18ec90['viewFrom_']=this['viewFrom_'],_0x18ec90;}}function qh(_0x16a778){return _0x16a778['loadsAllData']()?new Yi(_0x16a778['getIndex']()):_0x16a778['hasLimit']()?new Gh(_0x16a778):new Ot(_0x16a778);}function zh(_0x23eb48,_0xd10c4f){const _0x5d28a2=_0x23eb48['copy']();return _0x5d28a2['limitSet_']=!0x0,_0x5d28a2['limit_']=_0xd10c4f,_0x5d28a2['viewFrom_']='l',_0x5d28a2;}function jh(_0x51db91,_0x320c30,_0x2c6f6f){const _0x461314=_0x51db91['copy']();return _0x461314['startSet_']=!0x0,_0x320c30===void 0x0&&(_0x320c30=null),_0x461314['indexStartValue_']=_0x320c30,_0x2c6f6f!=null?(_0x461314['startNameSet_']=!0x0,_0x461314['indexStartName_']=_0x2c6f6f):(_0x461314['startNameSet_']=!0x1,_0x461314['indexStartName_']=''),_0x461314;}function Kh(_0x2b439e,_0x272359,_0x212c80){const _0x422ba3=_0x2b439e['copy']();return _0x422ba3['endSet_']=!0x0,_0x272359===void 0x0&&(_0x272359=null),_0x422ba3['indexEndValue_']=_0x272359,_0x212c80!==void 0x0?(_0x422ba3['endNameSet_']=!0x0,_0x422ba3['indexEndName_']=_0x212c80):(_0x422ba3['endNameSet_']=!0x1,_0x422ba3['indexEndName_']=''),_0x422ba3;}function Do(_0x1d93a8,_0x1a9c0d){const _0x5b2e21=_0x1d93a8['copy']();return _0x5b2e21['index_']=_0x1a9c0d,_0x5b2e21;}function tr(_0x15e7af){const _0x259f26={};if(_0x15e7af['isDefault']())return _0x259f26;let _0x49a3cf;if(_0x15e7af['index_']===R?_0x49a3cf='$priority':_0x15e7af['index_']===Po?_0x49a3cf='$value':_0x15e7af['index_']===ye?_0x49a3cf='$key':(f(_0x15e7af['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x49a3cf=_0x15e7af['index_']['toString']()),_0x259f26['orderBy']=O(_0x49a3cf),_0x15e7af['startSet_']){const _0x38bb4b=_0x15e7af['startAfterSet_']?'startAfter':'startAt';_0x259f26[_0x38bb4b]=O(_0x15e7af['indexStartValue_']),_0x15e7af['startNameSet_']&&(_0x259f26[_0x38bb4b]+=','+O(_0x15e7af['indexStartName_']));}if(_0x15e7af['endSet_']){const _0x26fb63=_0x15e7af['endBeforeSet_']?'endBefore':'endAt';_0x259f26[_0x26fb63]=O(_0x15e7af['indexEndValue_']),_0x15e7af['endNameSet_']&&(_0x259f26[_0x26fb63]+=','+O(_0x15e7af['indexEndName_']));}return _0x15e7af['limitSet_']&&(_0x15e7af['isViewFromLeft']()?_0x259f26['limitToFirst']=_0x15e7af['limit_']:_0x259f26['limitToLast']=_0x15e7af['limit_']),_0x259f26;}function nr(_0x5d7cb1){const _0xfd6a98={};if(_0x5d7cb1['startSet_']&&(_0xfd6a98['sp']=_0x5d7cb1['indexStartValue_'],_0x5d7cb1['startNameSet_']&&(_0xfd6a98['sn']=_0x5d7cb1['indexStartName_']),_0xfd6a98['sin']=!_0x5d7cb1['startAfterSet_']),_0x5d7cb1['endSet_']&&(_0xfd6a98['ep']=_0x5d7cb1['indexEndValue_'],_0x5d7cb1['endNameSet_']&&(_0xfd6a98['en']=_0x5d7cb1['indexEndName_']),_0xfd6a98['ein']=!_0x5d7cb1['endBeforeSet_']),_0x5d7cb1['limitSet_']){_0xfd6a98['l']=_0x5d7cb1['limit_'];let _0x41e2ad=_0x5d7cb1['viewFrom_'];_0x41e2ad===''&&(_0x5d7cb1['isViewFromLeft']()?_0x41e2ad='l':_0x41e2ad='r'),_0xfd6a98['vf']=_0x41e2ad;}return _0x5d7cb1['index_']!==R&&(_0xfd6a98['i']=_0x5d7cb1['index_']['toString']()),_0xfd6a98;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2197a7){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x17999c,_0x101ee4){return _0x101ee4!==void 0x0?'tag$'+_0x101ee4:(f(_0x17999c['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x17999c['_path']['toString']());}constructor(_0xfa60c6,_0x364a66,_0x1ccabc,_0x5d171b){super(),this['repoInfo_']=_0xfa60c6,this['onDataUpdate_']=_0x364a66,this['authTokenProvider_']=_0x1ccabc,this['appCheckTokenProvider_']=_0x5d171b,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x9f1075,_0xf97bb1,_0x460585,_0x472a7e){const _0x168dbb=_0x9f1075['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x168dbb+'\x20'+_0x9f1075['_queryIdentifier']);const _0xbcc94f=fn['getListenId_'](_0x9f1075,_0x460585),_0x54f2d6={};this['listens_'][_0xbcc94f]=_0x54f2d6;const _0x564d53=tr(_0x9f1075['_queryParams']);this['restRequest_'](_0x168dbb+'.json',_0x564d53,(_0xa50cae,_0xf4c166)=>{let _0x585305=_0xf4c166;if(_0xa50cae===0x194&&(_0x585305=null,_0xa50cae=null),_0xa50cae===null&&this['onDataUpdate_'](_0x168dbb,_0x585305,!0x1,_0x460585),Oe(this['listens_'],_0xbcc94f)===_0x54f2d6){let _0x50689b;_0xa50cae?_0xa50cae===0x191?_0x50689b='permission_denied':_0x50689b='rest_error:'+_0xa50cae:_0x50689b='ok',_0x472a7e(_0x50689b,null);}});}['unlisten'](_0x2f5519,_0x25323b){const _0x53304a=fn['getListenId_'](_0x2f5519,_0x25323b);delete this['listens_'][_0x53304a];}['get'](_0x481abc){const _0x4e7536=tr(_0x481abc['_queryParams']),_0x32366e=_0x481abc['_path']['toString'](),_0x1b7f47=new Ve();return this['restRequest_'](_0x32366e+'.json',_0x4e7536,(_0x4ddfc6,_0x363657)=>{let _0x1ebd98=_0x363657;_0x4ddfc6===0x194&&(_0x1ebd98=null,_0x4ddfc6=null),_0x4ddfc6===null?(this['onDataUpdate_'](_0x32366e,_0x1ebd98,!0x1,null),_0x1b7f47['resolve'](_0x1ebd98)):_0x1b7f47['reject'](new Error(_0x1ebd98));}),_0x1b7f47['promise'];}['refreshAuthToken'](_0x4ef4f9){}['restRequest_'](_0xd3517f,_0x577f88={},_0x1dccdc){return _0x577f88['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3a0e1d,_0x2f4253])=>{_0x3a0e1d&&_0x3a0e1d['accessToken']&&(_0x577f88['auth']=_0x3a0e1d['accessToken']),_0x2f4253&&_0x2f4253['token']&&(_0x577f88['ac']=_0x2f4253['token']);const _0x2ef6a2=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xd3517f+'?ns='+this['repoInfo_']['namespace']+at(_0x577f88);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2ef6a2);const _0x5711db=new XMLHttpRequest();_0x5711db['onreadystatechange']=()=>{if(_0x1dccdc&&_0x5711db['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2ef6a2+'\x20received.\x20status:',_0x5711db['status'],'response:',_0x5711db['responseText']);let _0x5b91e6=null;if(_0x5711db['status']>=0xc8&&_0x5711db['status']<0x12c){try{_0x5b91e6=bt(_0x5711db['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2ef6a2+':\x20'+_0x5711db['responseText']);}_0x1dccdc(null,_0x5b91e6);}else _0x5711db['status']!==0x191&&_0x5711db['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2ef6a2+'\x20Status:\x20'+_0x5711db['status']),_0x1dccdc(_0x5711db['status']);_0x1dccdc=null;}},_0x5711db['open']('GET',_0x2ef6a2,!0x0),_0x5711db['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4ca6e){return this['rootNode_']['getChild'](_0x4ca6e);}['updateSnapshot'](_0xf21b3a,_0x484478){this['rootNode_']=this['rootNode_']['updateChild'](_0xf21b3a,_0x484478);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x1e2ccb,_0x12216d,_0x1ba255){if(v(_0x12216d))_0x1e2ccb['value']=_0x1ba255,_0x1e2ccb['children']['clear']();else{if(_0x1e2ccb['value']!==null)_0x1e2ccb['value']=_0x1e2ccb['value']['updateChild'](_0x12216d,_0x1ba255);else{const _0x544270=y(_0x12216d);_0x1e2ccb['children']['has'](_0x544270)||_0x1e2ccb['children']['set'](_0x544270,pn());const _0x4dd6c0=_0x1e2ccb['children']['get'](_0x544270);_0x12216d=b(_0x12216d),Mo(_0x4dd6c0,_0x12216d,_0x1ba255);}}}function Ei(_0x46d268,_0x3274e8,_0xcad28d){_0x46d268['value']!==null?_0xcad28d(_0x3274e8,_0x46d268['value']):Qh(_0x46d268,(_0x18a215,_0xa2e528)=>{const _0x1aa89b=new C(_0x3274e8['toString']()+'/'+_0x18a215);Ei(_0xa2e528,_0x1aa89b,_0xcad28d);});}function Qh(_0x470083,_0x3340f7){_0x470083['children']['forEach']((_0x59a998,_0x246ae3)=>{_0x3340f7(_0x246ae3,_0x59a998);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x35558e){this['collection_']=_0x35558e,this['last_']=null;}['get'](){const _0x1a2e61=this['collection_']['get'](),_0x2ff7f4={..._0x1a2e61};return this['last_']&&x(this['last_'],(_0x586b24,_0x5b5c21)=>{_0x2ff7f4[_0x586b24]=_0x2ff7f4[_0x586b24]-_0x5b5c21;}),this['last_']=_0x1a2e61,_0x2ff7f4;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x59c54e,_0x52fea2){this['server_']=_0x52fea2,this['statsToReport_']={},this['statsListener_']=new Jh(_0x59c54e);const _0x4f81ef=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x4f81ef));}['reportStats_'](){const _0x107b4d=this['statsListener_']['get'](),_0x1acd67={};let _0x239c78=!0x1;x(_0x107b4d,(_0x1137cf,_0x3c7f26)=>{_0x3c7f26>0x0&&Y(this['statsToReport_'],_0x1137cf)&&(_0x1acd67[_0x1137cf]=_0x3c7f26,_0x239c78=!0x0);}),_0x239c78&&this['server_']['reportStats'](_0x1acd67),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x2abd4b){_0x2abd4b[_0x2abd4b['OVERWRITE']=0x0]='OVERWRITE',_0x2abd4b[_0x2abd4b['MERGE']=0x1]='MERGE',_0x2abd4b[_0x2abd4b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2abd4b[_0x2abd4b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x1d986b){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1d986b,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x45b586,_0x26963e,_0x1a1194){this['path']=_0x45b586,this['affectedTree']=_0x26963e,this['revert']=_0x1a1194,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5503c4){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3d2016=this['affectedTree']['subtree'](new C(_0x5503c4));return new _n(w(),_0x3d2016,this['revert']);}}else return f(y(this['path'])===_0x5503c4,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5dc449,_0x2f6b9e){this['source']=_0x5dc449,this['path']=_0x2f6b9e,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x2b4f04){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x320899,_0x15fd69,_0x276410){this['source']=_0x320899,this['path']=_0x15fd69,this['snap']=_0x276410,this['type']=q['OVERWRITE'];}['operationForChild'](_0x522535){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x522535)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x2b7add,_0x26abd1,_0x193744){this['source']=_0x2b7add,this['path']=_0x26abd1,this['children']=_0x193744,this['type']=q['MERGE'];}['operationForChild'](_0x4089ff){if(v(this['path'])){const _0x2d2701=this['children']['subtree'](new C(_0x4089ff));return _0x2d2701['isEmpty']()?null:_0x2d2701['value']?new Fe(this['source'],w(),_0x2d2701['value']):new nt(this['source'],w(),_0x2d2701);}else return f(y(this['path'])===_0x4089ff,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x41984a,_0x1e9467,_0xe2c0b7){this['node_']=_0x41984a,this['fullyInitialized_']=_0x1e9467,this['filtered_']=_0xe2c0b7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x482882){if(v(_0x482882))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5854f4=y(_0x482882);return this['isCompleteForChild'](_0x5854f4);}['isCompleteForChild'](_0x43236c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x43236c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x1011f7){this['query_']=_0x1011f7,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x101a87,_0x1aac44,_0xa96176,_0x37a6e6){const _0x2b7a66=[],_0x4fc78d=[];return _0x1aac44['forEach'](_0x23e6fa=>{_0x23e6fa['type']==='child_changed'&&_0x101a87['index_']['indexedValueChanged'](_0x23e6fa['oldSnap'],_0x23e6fa['snapshotNode'])&&_0x4fc78d['push']($h(_0x23e6fa['childName'],_0x23e6fa['snapshotNode']));}),mt(_0x101a87,_0x2b7a66,'child_removed',_0x1aac44,_0x37a6e6,_0xa96176),mt(_0x101a87,_0x2b7a66,'child_added',_0x1aac44,_0x37a6e6,_0xa96176),mt(_0x101a87,_0x2b7a66,'child_moved',_0x4fc78d,_0x37a6e6,_0xa96176),mt(_0x101a87,_0x2b7a66,'child_changed',_0x1aac44,_0x37a6e6,_0xa96176),mt(_0x101a87,_0x2b7a66,'value',_0x1aac44,_0x37a6e6,_0xa96176),_0x2b7a66;}function mt(_0x1a98b5,_0x32dbe7,_0x34513f,_0x27e88f,_0x296564,_0x578c3f){const _0x28b08e=_0x27e88f['filter'](_0x282e33=>_0x282e33['type']===_0x34513f);_0x28b08e['sort']((_0x5972d6,_0x417dcf)=>su(_0x1a98b5,_0x5972d6,_0x417dcf)),_0x28b08e['forEach'](_0x471d53=>{const _0x19c7ee=iu(_0x1a98b5,_0x471d53,_0x578c3f);_0x296564['forEach'](_0x1bed42=>{_0x1bed42['respondsTo'](_0x471d53['type'])&&_0x32dbe7['push'](_0x1bed42['createEvent'](_0x19c7ee,_0x1a98b5['query_']));});});}function iu(_0x290786,_0x1c6208,_0x696795){return _0x1c6208['type']==='value'||_0x1c6208['type']==='child_removed'||(_0x1c6208['prevName']=_0x696795['getPredecessorChildName'](_0x1c6208['childName'],_0x1c6208['snapshotNode'],_0x290786['index_'])),_0x1c6208;}function su(_0x19542e,_0x37b4b2,_0x2b93a4){if(_0x37b4b2['childName']==null||_0x2b93a4['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x385d25=new E(_0x37b4b2['childName'],_0x37b4b2['snapshotNode']),_0x68f3ee=new E(_0x2b93a4['childName'],_0x2b93a4['snapshotNode']);return _0x19542e['index_']['compare'](_0x385d25,_0x68f3ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x544a57,_0xd83751){return{'eventCache':_0x544a57,'serverCache':_0xd83751};}function wt(_0x10377f,_0x20db6d,_0x355b78,_0x23b774){return Dn(new Ce(_0x20db6d,_0x355b78,_0x23b774),_0x10377f['serverCache']);}function Lo(_0x1c15a3,_0x5027dd,_0x1feb5e,_0x2922e1){return Dn(_0x1c15a3['eventCache'],new Ce(_0x5027dd,_0x1feb5e,_0x2922e1));}function gn(_0x3b0494){return _0x3b0494['eventCache']['isFullyInitialized']()?_0x3b0494['eventCache']['getNode']():null;}function Ue(_0x403d11){return _0x403d11['serverCache']['isFullyInitialized']()?_0x403d11['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x254985){let _0x120b1b=new S(null);return x(_0x254985,(_0x50d3bf,_0x2b4c35)=>{_0x120b1b=_0x120b1b['set'](new C(_0x50d3bf),_0x2b4c35);}),_0x120b1b;}constructor(_0x2e50ef,_0x57d531=ru()){this['value']=_0x2e50ef,this['children']=_0x57d531;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x47cca7,_0x30a5fa){if(this['value']!=null&&_0x30a5fa(this['value']))return{'path':w(),'value':this['value']};if(v(_0x47cca7))return null;{const _0x18477c=y(_0x47cca7),_0x35a719=this['children']['get'](_0x18477c);if(_0x35a719!==null){const _0x3d4390=_0x35a719['findRootMostMatchingPathAndValue'](b(_0x47cca7),_0x30a5fa);return _0x3d4390!=null?{'path':A(new C(_0x18477c),_0x3d4390['path']),'value':_0x3d4390['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x40a804){return this['findRootMostMatchingPathAndValue'](_0x40a804,()=>!0x0);}['subtree'](_0x56f753){if(v(_0x56f753))return this;{const _0x55fe91=y(_0x56f753),_0x286c0f=this['children']['get'](_0x55fe91);return _0x286c0f!==null?_0x286c0f['subtree'](b(_0x56f753)):new S(null);}}['set'](_0x13e217,_0x2de43b){if(v(_0x13e217))return new S(_0x2de43b,this['children']);{const _0x371231=y(_0x13e217),_0x57f4a4=(this['children']['get'](_0x371231)||new S(null))['set'](b(_0x13e217),_0x2de43b),_0x145aca=this['children']['insert'](_0x371231,_0x57f4a4);return new S(this['value'],_0x145aca);}}['remove'](_0x440274){if(v(_0x440274))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3ef4f0=y(_0x440274),_0x3718b0=this['children']['get'](_0x3ef4f0);if(_0x3718b0){const _0x33131b=_0x3718b0['remove'](b(_0x440274));let _0x4374ad;return _0x33131b['isEmpty']()?_0x4374ad=this['children']['remove'](_0x3ef4f0):_0x4374ad=this['children']['insert'](_0x3ef4f0,_0x33131b),this['value']===null&&_0x4374ad['isEmpty']()?new S(null):new S(this['value'],_0x4374ad);}else return this;}}['get'](_0x3e94f8){if(v(_0x3e94f8))return this['value'];{const _0x502881=y(_0x3e94f8),_0x1f0854=this['children']['get'](_0x502881);return _0x1f0854?_0x1f0854['get'](b(_0x3e94f8)):null;}}['setTree'](_0x19718f,_0xabab){if(v(_0x19718f))return _0xabab;{const _0x195942=y(_0x19718f),_0xcf03ca=(this['children']['get'](_0x195942)||new S(null))['setTree'](b(_0x19718f),_0xabab);let _0x428153;return _0xcf03ca['isEmpty']()?_0x428153=this['children']['remove'](_0x195942):_0x428153=this['children']['insert'](_0x195942,_0xcf03ca),new S(this['value'],_0x428153);}}['fold'](_0x58d976){return this['fold_'](w(),_0x58d976);}['fold_'](_0x441c79,_0x1b84b1){const _0x32703f={};return this['children']['inorderTraversal']((_0x4900bb,_0x458456)=>{_0x32703f[_0x4900bb]=_0x458456['fold_'](A(_0x441c79,_0x4900bb),_0x1b84b1);}),_0x1b84b1(_0x441c79,this['value'],_0x32703f);}['findOnPath'](_0x195928,_0x41cfe3){return this['findOnPath_'](_0x195928,w(),_0x41cfe3);}['findOnPath_'](_0x15aa8d,_0x2856e8,_0x55f8e3){const _0x302023=this['value']?_0x55f8e3(_0x2856e8,this['value']):!0x1;if(_0x302023)return _0x302023;if(v(_0x15aa8d))return null;{const _0x5101ea=y(_0x15aa8d),_0x3c5198=this['children']['get'](_0x5101ea);return _0x3c5198?_0x3c5198['findOnPath_'](b(_0x15aa8d),A(_0x2856e8,_0x5101ea),_0x55f8e3):null;}}['foreachOnPath'](_0x28f0be,_0x3dcb19){return this['foreachOnPath_'](_0x28f0be,w(),_0x3dcb19);}['foreachOnPath_'](_0x916575,_0x3f8c71,_0xd6bb11){if(v(_0x916575))return this;{this['value']&&_0xd6bb11(_0x3f8c71,this['value']);const _0xf1e6f8=y(_0x916575),_0x225dfd=this['children']['get'](_0xf1e6f8);return _0x225dfd?_0x225dfd['foreachOnPath_'](b(_0x916575),A(_0x3f8c71,_0xf1e6f8),_0xd6bb11):new S(null);}}['foreach'](_0x41cba9){this['foreach_'](w(),_0x41cba9);}['foreach_'](_0x309695,_0x3dc51a){this['children']['inorderTraversal']((_0x5f5393,_0x50dcaa)=>{_0x50dcaa['foreach_'](A(_0x309695,_0x5f5393),_0x3dc51a);}),this['value']&&_0x3dc51a(_0x309695,this['value']);}['foreachChild'](_0x277632){this['children']['inorderTraversal']((_0x142f32,_0xc8ea3b)=>{_0xc8ea3b['value']&&_0x277632(_0x142f32,_0xc8ea3b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2b4a85){this['writeTree_']=_0x2b4a85;}static['empty'](){return new j(new S(null));}}function Ct(_0x5d5a65,_0x37f5d1,_0x2a9510){if(v(_0x37f5d1))return new j(new S(_0x2a9510));{const _0x44696e=_0x5d5a65['writeTree_']['findRootMostValueAndPath'](_0x37f5d1);if(_0x44696e!=null){const _0x3dfe14=_0x44696e['path'];let _0x2a10ea=_0x44696e['value'];const _0x4bc695=F(_0x3dfe14,_0x37f5d1);return _0x2a10ea=_0x2a10ea['updateChild'](_0x4bc695,_0x2a9510),new j(_0x5d5a65['writeTree_']['set'](_0x3dfe14,_0x2a10ea));}else{const _0x13a166=new S(_0x2a9510),_0x140b48=_0x5d5a65['writeTree_']['setTree'](_0x37f5d1,_0x13a166);return new j(_0x140b48);}}}function Ii(_0x2401d2,_0x9a397f,_0x3b3ffe){let _0x586971=_0x2401d2;return x(_0x3b3ffe,(_0x20aed0,_0x285b1e)=>{_0x586971=Ct(_0x586971,A(_0x9a397f,_0x20aed0),_0x285b1e);}),_0x586971;}function sr(_0x14ff71,_0x5b769a){if(v(_0x5b769a))return j['empty']();{const _0xd4a10a=_0x14ff71['writeTree_']['setTree'](_0x5b769a,new S(null));return new j(_0xd4a10a);}}function wi(_0x54d211,_0x23b6c6){return $e(_0x54d211,_0x23b6c6)!=null;}function $e(_0x2cc038,_0x191bf7){const _0x378946=_0x2cc038['writeTree_']['findRootMostValueAndPath'](_0x191bf7);return _0x378946!=null?_0x2cc038['writeTree_']['get'](_0x378946['path'])['getChild'](F(_0x378946['path'],_0x191bf7)):null;}function rr(_0x1d861d){const _0x2e7a74=[],_0x2c3cbc=_0x1d861d['writeTree_']['value'];return _0x2c3cbc!=null?_0x2c3cbc['isLeafNode']()||_0x2c3cbc['forEachChild'](R,(_0x45a7ce,_0x54b152)=>{_0x2e7a74['push'](new E(_0x45a7ce,_0x54b152));}):_0x1d861d['writeTree_']['children']['inorderTraversal']((_0x4a7b1b,_0x44d277)=>{_0x44d277['value']!=null&&_0x2e7a74['push'](new E(_0x4a7b1b,_0x44d277['value']));}),_0x2e7a74;}function ve(_0x4028c1,_0x454944){if(v(_0x454944))return _0x4028c1;{const _0x3463c9=$e(_0x4028c1,_0x454944);return _0x3463c9!=null?new j(new S(_0x3463c9)):new j(_0x4028c1['writeTree_']['subtree'](_0x454944));}}function Ci(_0x3c60e2){return _0x3c60e2['writeTree_']['isEmpty']();}function it(_0x3749b7,_0x271a77){return xo(w(),_0x3749b7['writeTree_'],_0x271a77);}function xo(_0x4978f8,_0x23fad4,_0x58f573){if(_0x23fad4['value']!=null)return _0x58f573['updateChild'](_0x4978f8,_0x23fad4['value']);{let _0x508b86=null;return _0x23fad4['children']['inorderTraversal']((_0x1fcba6,_0x55ef7d)=>{_0x1fcba6==='.priority'?(f(_0x55ef7d['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x508b86=_0x55ef7d['value']):_0x58f573=xo(A(_0x4978f8,_0x1fcba6),_0x55ef7d,_0x58f573);}),!_0x58f573['getChild'](_0x4978f8)['isEmpty']()&&_0x508b86!==null&&(_0x58f573=_0x58f573['updateChild'](A(_0x4978f8,'.priority'),_0x508b86)),_0x58f573;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0xe85907,_0x24466f){return Bo(_0x24466f,_0xe85907);}function ou(_0x15ef29,_0x17d544,_0x54410a,_0x291741,_0xd1dd05){f(_0x291741>_0x15ef29['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xd1dd05===void 0x0&&(_0xd1dd05=!0x0),_0x15ef29['allWrites']['push']({'path':_0x17d544,'snap':_0x54410a,'writeId':_0x291741,'visible':_0xd1dd05}),_0xd1dd05&&(_0x15ef29['visibleWrites']=Ct(_0x15ef29['visibleWrites'],_0x17d544,_0x54410a)),_0x15ef29['lastWriteId']=_0x291741;}function au(_0x3c4411,_0x4485ce,_0x484e95,_0x4966aa){f(_0x4966aa>_0x3c4411['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3c4411['allWrites']['push']({'path':_0x4485ce,'children':_0x484e95,'writeId':_0x4966aa,'visible':!0x0}),_0x3c4411['visibleWrites']=Ii(_0x3c4411['visibleWrites'],_0x4485ce,_0x484e95),_0x3c4411['lastWriteId']=_0x4966aa;}function cu(_0x3c0115,_0x5e79d0){for(let _0x5cb64e=0x0;_0x5cb64e<_0x3c0115['allWrites']['length'];_0x5cb64e++){const _0x59bceb=_0x3c0115['allWrites'][_0x5cb64e];if(_0x59bceb['writeId']===_0x5e79d0)return _0x59bceb;}return null;}function lu(_0x1a3765,_0x8a8050){const _0x17ead0=_0x1a3765['allWrites']['findIndex'](_0xdce180=>_0xdce180['writeId']===_0x8a8050);f(_0x17ead0>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1ca528=_0x1a3765['allWrites'][_0x17ead0];_0x1a3765['allWrites']['splice'](_0x17ead0,0x1);let _0x5c5a7a=_0x1ca528['visible'],_0x39e832=!0x1,_0x125102=_0x1a3765['allWrites']['length']-0x1;for(;_0x5c5a7a&&_0x125102>=0x0;){const _0x420af5=_0x1a3765['allWrites'][_0x125102];_0x420af5['visible']&&(_0x125102>=_0x17ead0&&hu(_0x420af5,_0x1ca528['path'])?_0x5c5a7a=!0x1:$(_0x1ca528['path'],_0x420af5['path'])&&(_0x39e832=!0x0)),_0x125102--;}if(_0x5c5a7a){if(_0x39e832)return uu(_0x1a3765),!0x0;if(_0x1ca528['snap'])_0x1a3765['visibleWrites']=sr(_0x1a3765['visibleWrites'],_0x1ca528['path']);else{const _0x193f56=_0x1ca528['children'];x(_0x193f56,_0x510d77=>{_0x1a3765['visibleWrites']=sr(_0x1a3765['visibleWrites'],A(_0x1ca528['path'],_0x510d77));});}return!0x0;}else return!0x1;}function hu(_0x540ee4,_0x1bcc70){if(_0x540ee4['snap'])return $(_0x540ee4['path'],_0x1bcc70);for(const _0x32a651 in _0x540ee4['children'])if(_0x540ee4['children']['hasOwnProperty'](_0x32a651)&&$(A(_0x540ee4['path'],_0x32a651),_0x1bcc70))return!0x0;return!0x1;}function uu(_0x124aa7){_0x124aa7['visibleWrites']=Fo(_0x124aa7['allWrites'],du,w()),_0x124aa7['allWrites']['length']>0x0?_0x124aa7['lastWriteId']=_0x124aa7['allWrites'][_0x124aa7['allWrites']['length']-0x1]['writeId']:_0x124aa7['lastWriteId']=-0x1;}function du(_0x767f77){return _0x767f77['visible'];}function Fo(_0x6058aa,_0x3fb095,_0x2a273){let _0x5d771d=j['empty']();for(let _0x5804aa=0x0;_0x5804aa<_0x6058aa['length'];++_0x5804aa){const _0x35b65a=_0x6058aa[_0x5804aa];if(_0x3fb095(_0x35b65a)){const _0x19d76b=_0x35b65a['path'];let _0x498dee;if(_0x35b65a['snap'])$(_0x2a273,_0x19d76b)?(_0x498dee=F(_0x2a273,_0x19d76b),_0x5d771d=Ct(_0x5d771d,_0x498dee,_0x35b65a['snap'])):$(_0x19d76b,_0x2a273)&&(_0x498dee=F(_0x19d76b,_0x2a273),_0x5d771d=Ct(_0x5d771d,w(),_0x35b65a['snap']['getChild'](_0x498dee)));else{if(_0x35b65a['children']){if($(_0x2a273,_0x19d76b))_0x498dee=F(_0x2a273,_0x19d76b),_0x5d771d=Ii(_0x5d771d,_0x498dee,_0x35b65a['children']);else{if($(_0x19d76b,_0x2a273)){if(_0x498dee=F(_0x19d76b,_0x2a273),v(_0x498dee))_0x5d771d=Ii(_0x5d771d,w(),_0x35b65a['children']);else{const _0x4fb4d8=Oe(_0x35b65a['children'],y(_0x498dee));if(_0x4fb4d8){const _0x16cabf=_0x4fb4d8['getChild'](b(_0x498dee));_0x5d771d=Ct(_0x5d771d,w(),_0x16cabf);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5d771d;}function Uo(_0x371a76,_0x451c30,_0x318e93,_0x52c510,_0x56196b){if(!_0x52c510&&!_0x56196b){const _0x54c80b=$e(_0x371a76['visibleWrites'],_0x451c30);if(_0x54c80b!=null)return _0x54c80b;{const _0x472875=ve(_0x371a76['visibleWrites'],_0x451c30);if(Ci(_0x472875))return _0x318e93;if(_0x318e93==null&&!wi(_0x472875,w()))return null;{const _0x3fec17=_0x318e93||g['EMPTY_NODE'];return it(_0x472875,_0x3fec17);}}}else{const _0x3dd699=ve(_0x371a76['visibleWrites'],_0x451c30);if(!_0x56196b&&Ci(_0x3dd699))return _0x318e93;if(!_0x56196b&&_0x318e93==null&&!wi(_0x3dd699,w()))return null;{const _0x201780=function(_0x20d4da){return(_0x20d4da['visible']||_0x56196b)&&(!_0x52c510||!~_0x52c510['indexOf'](_0x20d4da['writeId']))&&($(_0x20d4da['path'],_0x451c30)||$(_0x451c30,_0x20d4da['path']));},_0x28e66f=Fo(_0x371a76['allWrites'],_0x201780,_0x451c30),_0x2af13c=_0x318e93||g['EMPTY_NODE'];return it(_0x28e66f,_0x2af13c);}}}function fu(_0x12b329,_0x2e091c,_0x165b02){let _0xb4762f=g['EMPTY_NODE'];const _0x1b5e49=$e(_0x12b329['visibleWrites'],_0x2e091c);if(_0x1b5e49)return _0x1b5e49['isLeafNode']()||_0x1b5e49['forEachChild'](R,(_0x544e3c,_0x56ed4d)=>{_0xb4762f=_0xb4762f['updateImmediateChild'](_0x544e3c,_0x56ed4d);}),_0xb4762f;if(_0x165b02){const _0x2f0ec0=ve(_0x12b329['visibleWrites'],_0x2e091c);return _0x165b02['forEachChild'](R,(_0xc158b4,_0x30eb13)=>{const _0x27b2cc=it(ve(_0x2f0ec0,new C(_0xc158b4)),_0x30eb13);_0xb4762f=_0xb4762f['updateImmediateChild'](_0xc158b4,_0x27b2cc);}),rr(_0x2f0ec0)['forEach'](_0x12d3b2=>{_0xb4762f=_0xb4762f['updateImmediateChild'](_0x12d3b2['name'],_0x12d3b2['node']);}),_0xb4762f;}else{const _0x252a5b=ve(_0x12b329['visibleWrites'],_0x2e091c);return rr(_0x252a5b)['forEach'](_0x11970b=>{_0xb4762f=_0xb4762f['updateImmediateChild'](_0x11970b['name'],_0x11970b['node']);}),_0xb4762f;}}function pu(_0x1c2e41,_0xe99ff8,_0x287999,_0x2943a2,_0xc7ae22){f(_0x2943a2||_0xc7ae22,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x23efbd=A(_0xe99ff8,_0x287999);if(wi(_0x1c2e41['visibleWrites'],_0x23efbd))return null;{const _0x2cb679=ve(_0x1c2e41['visibleWrites'],_0x23efbd);return Ci(_0x2cb679)?_0xc7ae22['getChild'](_0x287999):it(_0x2cb679,_0xc7ae22['getChild'](_0x287999));}}function _u(_0x31064b,_0x409c1f,_0x16eb57,_0x234e32){const _0x375af8=A(_0x409c1f,_0x16eb57),_0x124124=$e(_0x31064b['visibleWrites'],_0x375af8);if(_0x124124!=null)return _0x124124;if(_0x234e32['isCompleteForChild'](_0x16eb57)){const _0x54214c=ve(_0x31064b['visibleWrites'],_0x375af8);return it(_0x54214c,_0x234e32['getNode']()['getImmediateChild'](_0x16eb57));}else return null;}function gu(_0x4f7626,_0x933416){return $e(_0x4f7626['visibleWrites'],_0x933416);}function mu(_0x3e5751,_0x4204e1,_0xcee1ee,_0x420850,_0x557541,_0x2e8c66,_0x57feb4){let _0x34cbbc;const _0x37f9b8=ve(_0x3e5751['visibleWrites'],_0x4204e1),_0x5d0729=$e(_0x37f9b8,w());if(_0x5d0729!=null)_0x34cbbc=_0x5d0729;else{if(_0xcee1ee!=null)_0x34cbbc=it(_0x37f9b8,_0xcee1ee);else return[];}if(_0x34cbbc=_0x34cbbc['withIndex'](_0x57feb4),!_0x34cbbc['isEmpty']()&&!_0x34cbbc['isLeafNode']()){const _0x243689=[],_0x53e432=_0x57feb4['getCompare'](),_0x16b70c=_0x2e8c66?_0x34cbbc['getReverseIteratorFrom'](_0x420850,_0x57feb4):_0x34cbbc['getIteratorFrom'](_0x420850,_0x57feb4);let _0x1acaef=_0x16b70c['getNext']();for(;_0x1acaef&&_0x243689['length']<_0x557541;)_0x53e432(_0x1acaef,_0x420850)!==0x0&&_0x243689['push'](_0x1acaef),_0x1acaef=_0x16b70c['getNext']();return _0x243689;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x17124e,_0x3e543d,_0x20bcab,_0x290b8e){return Uo(_0x17124e['writeTree'],_0x17124e['treePath'],_0x3e543d,_0x20bcab,_0x290b8e);}function es(_0x1b862f,_0x3d77b3){return fu(_0x1b862f['writeTree'],_0x1b862f['treePath'],_0x3d77b3);}function or(_0x14ea01,_0x237586,_0x40a988,_0x45f3e9){return pu(_0x14ea01['writeTree'],_0x14ea01['treePath'],_0x237586,_0x40a988,_0x45f3e9);}function yn(_0x3238da,_0x566ed0){return gu(_0x3238da['writeTree'],A(_0x3238da['treePath'],_0x566ed0));}function vu(_0x358fdf,_0x345a90,_0x405938,_0x1f25e1,_0x27acad,_0x1dce33){return mu(_0x358fdf['writeTree'],_0x358fdf['treePath'],_0x345a90,_0x405938,_0x1f25e1,_0x27acad,_0x1dce33);}function ts(_0x1d68ff,_0x10ea29,_0x3f73d4){return _u(_0x1d68ff['writeTree'],_0x1d68ff['treePath'],_0x10ea29,_0x3f73d4);}function Wo(_0x13a510,_0x5d697c){return Bo(A(_0x13a510['treePath'],_0x5d697c),_0x13a510['writeTree']);}function Bo(_0x41b379,_0x5bf4d0){return{'treePath':_0x41b379,'writeTree':_0x5bf4d0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x50fe02){const _0x11b24f=_0x50fe02['type'],_0x91ecf=_0x50fe02['childName'];f(_0x11b24f==='child_added'||_0x11b24f==='child_changed'||_0x11b24f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x91ecf!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x524f62=this['changeMap']['get'](_0x91ecf);if(_0x524f62){const _0x447def=_0x524f62['type'];if(_0x11b24f==='child_added'&&_0x447def==='child_removed')this['changeMap']['set'](_0x91ecf,Pt(_0x91ecf,_0x50fe02['snapshotNode'],_0x524f62['snapshotNode']));else{if(_0x11b24f==='child_removed'&&_0x447def==='child_added')this['changeMap']['delete'](_0x91ecf);else{if(_0x11b24f==='child_removed'&&_0x447def==='child_changed')this['changeMap']['set'](_0x91ecf,Nt(_0x91ecf,_0x524f62['oldSnap']));else{if(_0x11b24f==='child_changed'&&_0x447def==='child_added')this['changeMap']['set'](_0x91ecf,tt(_0x91ecf,_0x50fe02['snapshotNode']));else{if(_0x11b24f==='child_changed'&&_0x447def==='child_changed')this['changeMap']['set'](_0x91ecf,Pt(_0x91ecf,_0x50fe02['snapshotNode'],_0x524f62['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x50fe02+'\x20occurred\x20after\x20'+_0x524f62);}}}}}else this['changeMap']['set'](_0x91ecf,_0x50fe02);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x2f1be7){return null;}['getChildAfterChild'](_0x3fae28,_0x3bc6b5,_0x2cb1d1){return null;}}const Vo=new Iu();class ns{constructor(_0x166eaf,_0x4695dd,_0x221a3f=null){this['writes_']=_0x166eaf,this['viewCache_']=_0x4695dd,this['optCompleteServerCache_']=_0x221a3f;}['getCompleteChild'](_0x5ebbc4){const _0x25136c=this['viewCache_']['eventCache'];if(_0x25136c['isCompleteForChild'](_0x5ebbc4))return _0x25136c['getNode']()['getImmediateChild'](_0x5ebbc4);{const _0x55765c=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5ebbc4,_0x55765c);}}['getChildAfterChild'](_0x2ec3bd,_0x56c7ab,_0x2a46be){const _0x2f75ab=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x2174af=vu(this['writes_'],_0x2f75ab,_0x56c7ab,0x1,_0x2a46be,_0x2ec3bd);return _0x2174af['length']===0x0?null:_0x2174af[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3a49d4){return{'filter':_0x3a49d4};}function Cu(_0x424aef,_0x21370b){f(_0x21370b['eventCache']['getNode']()['isIndexed'](_0x424aef['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x21370b['serverCache']['getNode']()['isIndexed'](_0x424aef['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5c6dde,_0x4878a1,_0x71cbff,_0x400eaf,_0xb79cc6){const _0x5bab47=new Eu();let _0x5233ce,_0x11ace0;if(_0x71cbff['type']===q['OVERWRITE']){const _0x5c3814=_0x71cbff;_0x5c3814['source']['fromUser']?_0x5233ce=Ti(_0x5c6dde,_0x4878a1,_0x5c3814['path'],_0x5c3814['snap'],_0x400eaf,_0xb79cc6,_0x5bab47):(f(_0x5c3814['source']['fromServer'],'Unknown\x20source.'),_0x11ace0=_0x5c3814['source']['tagged']||_0x4878a1['serverCache']['isFiltered']()&&!v(_0x5c3814['path']),_0x5233ce=vn(_0x5c6dde,_0x4878a1,_0x5c3814['path'],_0x5c3814['snap'],_0x400eaf,_0xb79cc6,_0x11ace0,_0x5bab47));}else{if(_0x71cbff['type']===q['MERGE']){const _0x512c08=_0x71cbff;_0x512c08['source']['fromUser']?_0x5233ce=bu(_0x5c6dde,_0x4878a1,_0x512c08['path'],_0x512c08['children'],_0x400eaf,_0xb79cc6,_0x5bab47):(f(_0x512c08['source']['fromServer'],'Unknown\x20source.'),_0x11ace0=_0x512c08['source']['tagged']||_0x4878a1['serverCache']['isFiltered'](),_0x5233ce=Si(_0x5c6dde,_0x4878a1,_0x512c08['path'],_0x512c08['children'],_0x400eaf,_0xb79cc6,_0x11ace0,_0x5bab47));}else{if(_0x71cbff['type']===q['ACK_USER_WRITE']){const _0x115997=_0x71cbff;_0x115997['revert']?_0x5233ce=ku(_0x5c6dde,_0x4878a1,_0x115997['path'],_0x400eaf,_0xb79cc6,_0x5bab47):_0x5233ce=Ru(_0x5c6dde,_0x4878a1,_0x115997['path'],_0x115997['affectedTree'],_0x400eaf,_0xb79cc6,_0x5bab47);}else{if(_0x71cbff['type']===q['LISTEN_COMPLETE'])_0x5233ce=Au(_0x5c6dde,_0x4878a1,_0x71cbff['path'],_0x400eaf,_0x5bab47);else throw ot('Unknown\x20operation\x20type:\x20'+_0x71cbff['type']);}}}const _0x221301=_0x5bab47['getChanges']();return Su(_0x4878a1,_0x5233ce,_0x221301),{'viewCache':_0x5233ce,'changes':_0x221301};}function Su(_0x18a0dd,_0x4d653d,_0xd3640c){const _0x481d85=_0x4d653d['eventCache'];if(_0x481d85['isFullyInitialized']()){const _0x1d17ef=_0x481d85['getNode']()['isLeafNode']()||_0x481d85['getNode']()['isEmpty'](),_0x42be8b=gn(_0x18a0dd);(_0xd3640c['length']>0x0||!_0x18a0dd['eventCache']['isFullyInitialized']()||_0x1d17ef&&!_0x481d85['getNode']()['equals'](_0x42be8b)||!_0x481d85['getNode']()['getPriority']()['equals'](_0x42be8b['getPriority']()))&&_0xd3640c['push'](Oo(gn(_0x4d653d)));}}function Ho(_0x3294f0,_0x26fb17,_0x120915,_0x57e6aa,_0x4de0d9,_0x99564c){const _0x212d8b=_0x26fb17['eventCache'];if(yn(_0x57e6aa,_0x120915)!=null)return _0x26fb17;{let _0x2ae4b8,_0x49556b;if(v(_0x120915)){if(f(_0x26fb17['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x26fb17['serverCache']['isFiltered']()){const _0x3dd7b8=Ue(_0x26fb17),_0x408239=_0x3dd7b8 instanceof g?_0x3dd7b8:g['EMPTY_NODE'],_0x470b42=es(_0x57e6aa,_0x408239);_0x2ae4b8=_0x3294f0['filter']['updateFullNode'](_0x26fb17['eventCache']['getNode'](),_0x470b42,_0x99564c);}else{const _0x14eb50=mn(_0x57e6aa,Ue(_0x26fb17));_0x2ae4b8=_0x3294f0['filter']['updateFullNode'](_0x26fb17['eventCache']['getNode'](),_0x14eb50,_0x99564c);}}else{const _0x404109=y(_0x120915);if(_0x404109==='.priority'){f(we(_0x120915)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4d2932=_0x212d8b['getNode']();_0x49556b=_0x26fb17['serverCache']['getNode']();const _0x2d2cec=or(_0x57e6aa,_0x120915,_0x4d2932,_0x49556b);_0x2d2cec!=null?_0x2ae4b8=_0x3294f0['filter']['updatePriority'](_0x4d2932,_0x2d2cec):_0x2ae4b8=_0x212d8b['getNode']();}else{const _0x2e151c=b(_0x120915);let _0x350e5d;if(_0x212d8b['isCompleteForChild'](_0x404109)){_0x49556b=_0x26fb17['serverCache']['getNode']();const _0x3f8ea8=or(_0x57e6aa,_0x120915,_0x212d8b['getNode'](),_0x49556b);_0x3f8ea8!=null?_0x350e5d=_0x212d8b['getNode']()['getImmediateChild'](_0x404109)['updateChild'](_0x2e151c,_0x3f8ea8):_0x350e5d=_0x212d8b['getNode']()['getImmediateChild'](_0x404109);}else _0x350e5d=ts(_0x57e6aa,_0x404109,_0x26fb17['serverCache']);_0x350e5d!=null?_0x2ae4b8=_0x3294f0['filter']['updateChild'](_0x212d8b['getNode'](),_0x404109,_0x350e5d,_0x2e151c,_0x4de0d9,_0x99564c):_0x2ae4b8=_0x212d8b['getNode']();}}return wt(_0x26fb17,_0x2ae4b8,_0x212d8b['isFullyInitialized']()||v(_0x120915),_0x3294f0['filter']['filtersNodes']());}}function vn(_0x420435,_0x538bc4,_0x1f9d1d,_0x3db9c6,_0x419386,_0x129013,_0xb3f7e8,_0x3623b9){const _0x6af74e=_0x538bc4['serverCache'];let _0x2739cc;const _0x2dd153=_0xb3f7e8?_0x420435['filter']:_0x420435['filter']['getIndexedFilter']();if(v(_0x1f9d1d))_0x2739cc=_0x2dd153['updateFullNode'](_0x6af74e['getNode'](),_0x3db9c6,null);else{if(_0x2dd153['filtersNodes']()&&!_0x6af74e['isFiltered']()){const _0x5146fe=_0x6af74e['getNode']()['updateChild'](_0x1f9d1d,_0x3db9c6);_0x2739cc=_0x2dd153['updateFullNode'](_0x6af74e['getNode'](),_0x5146fe,null);}else{const _0x3d98b0=y(_0x1f9d1d);if(!_0x6af74e['isCompleteForPath'](_0x1f9d1d)&&we(_0x1f9d1d)>0x1)return _0x538bc4;const _0x5530a3=b(_0x1f9d1d),_0x2df3b1=_0x6af74e['getNode']()['getImmediateChild'](_0x3d98b0)['updateChild'](_0x5530a3,_0x3db9c6);_0x3d98b0==='.priority'?_0x2739cc=_0x2dd153['updatePriority'](_0x6af74e['getNode'](),_0x2df3b1):_0x2739cc=_0x2dd153['updateChild'](_0x6af74e['getNode'](),_0x3d98b0,_0x2df3b1,_0x5530a3,Vo,null);}}const _0x5db08d=Lo(_0x538bc4,_0x2739cc,_0x6af74e['isFullyInitialized']()||v(_0x1f9d1d),_0x2dd153['filtersNodes']()),_0x3b5b6a=new ns(_0x419386,_0x5db08d,_0x129013);return Ho(_0x420435,_0x5db08d,_0x1f9d1d,_0x419386,_0x3b5b6a,_0x3623b9);}function Ti(_0x515da2,_0x9ddd29,_0x36a29f,_0x1d20e8,_0x56aafc,_0x4aad91,_0x542366){const _0x393ad1=_0x9ddd29['eventCache'];let _0x1ee97f,_0x267fd4;const _0x898156=new ns(_0x56aafc,_0x9ddd29,_0x4aad91);if(v(_0x36a29f))_0x267fd4=_0x515da2['filter']['updateFullNode'](_0x9ddd29['eventCache']['getNode'](),_0x1d20e8,_0x542366),_0x1ee97f=wt(_0x9ddd29,_0x267fd4,!0x0,_0x515da2['filter']['filtersNodes']());else{const _0x550b41=y(_0x36a29f);if(_0x550b41==='.priority')_0x267fd4=_0x515da2['filter']['updatePriority'](_0x9ddd29['eventCache']['getNode'](),_0x1d20e8),_0x1ee97f=wt(_0x9ddd29,_0x267fd4,_0x393ad1['isFullyInitialized'](),_0x393ad1['isFiltered']());else{const _0x1669a3=b(_0x36a29f),_0x5f4135=_0x393ad1['getNode']()['getImmediateChild'](_0x550b41);let _0x23023f;if(v(_0x1669a3))_0x23023f=_0x1d20e8;else{const _0x55b669=_0x898156['getCompleteChild'](_0x550b41);_0x55b669!=null?Gi(_0x1669a3)==='.priority'&&_0x55b669['getChild'](To(_0x1669a3))['isEmpty']()?_0x23023f=_0x55b669:_0x23023f=_0x55b669['updateChild'](_0x1669a3,_0x1d20e8):_0x23023f=g['EMPTY_NODE'];}if(_0x5f4135['equals'](_0x23023f))_0x1ee97f=_0x9ddd29;else{const _0x1862a4=_0x515da2['filter']['updateChild'](_0x393ad1['getNode'](),_0x550b41,_0x23023f,_0x1669a3,_0x898156,_0x542366);_0x1ee97f=wt(_0x9ddd29,_0x1862a4,_0x393ad1['isFullyInitialized'](),_0x515da2['filter']['filtersNodes']());}}}return _0x1ee97f;}function ar(_0x3cfade,_0x199370){return _0x3cfade['eventCache']['isCompleteForChild'](_0x199370);}function bu(_0x1a847f,_0x922411,_0x3c711a,_0x26d3f0,_0x8409f1,_0x109a4c,_0x25ec5e){let _0x550bf5=_0x922411;return _0x26d3f0['foreach']((_0x30ec5c,_0x410205)=>{const _0x5a1205=A(_0x3c711a,_0x30ec5c);ar(_0x922411,y(_0x5a1205))&&(_0x550bf5=Ti(_0x1a847f,_0x550bf5,_0x5a1205,_0x410205,_0x8409f1,_0x109a4c,_0x25ec5e));}),_0x26d3f0['foreach']((_0x1e1277,_0x269362)=>{const _0x5ee961=A(_0x3c711a,_0x1e1277);ar(_0x922411,y(_0x5ee961))||(_0x550bf5=Ti(_0x1a847f,_0x550bf5,_0x5ee961,_0x269362,_0x8409f1,_0x109a4c,_0x25ec5e));}),_0x550bf5;}function cr(_0x51bd12,_0x41a548,_0x2f424d){return _0x2f424d['foreach']((_0x358857,_0x40d5b9)=>{_0x41a548=_0x41a548['updateChild'](_0x358857,_0x40d5b9);}),_0x41a548;}function Si(_0x433310,_0x2dc790,_0x4a80f0,_0x517a1b,_0x44478e,_0x56cca6,_0x206dd0,_0x5d9531){if(_0x2dc790['serverCache']['getNode']()['isEmpty']()&&!_0x2dc790['serverCache']['isFullyInitialized']())return _0x2dc790;let _0x563c2b=_0x2dc790,_0x407116;v(_0x4a80f0)?_0x407116=_0x517a1b:_0x407116=new S(null)['setTree'](_0x4a80f0,_0x517a1b);const _0x18b3d9=_0x2dc790['serverCache']['getNode']();return _0x407116['children']['inorderTraversal']((_0x246c60,_0x36edb8)=>{if(_0x18b3d9['hasChild'](_0x246c60)){const _0x190b2b=_0x2dc790['serverCache']['getNode']()['getImmediateChild'](_0x246c60),_0x177976=cr(_0x433310,_0x190b2b,_0x36edb8);_0x563c2b=vn(_0x433310,_0x563c2b,new C(_0x246c60),_0x177976,_0x44478e,_0x56cca6,_0x206dd0,_0x5d9531);}}),_0x407116['children']['inorderTraversal']((_0x54988a,_0x1bc9fa)=>{const _0x25b103=!_0x2dc790['serverCache']['isCompleteForChild'](_0x54988a)&&_0x1bc9fa['value']===null;if(!_0x18b3d9['hasChild'](_0x54988a)&&!_0x25b103){const _0x5cd482=_0x2dc790['serverCache']['getNode']()['getImmediateChild'](_0x54988a),_0x56a628=cr(_0x433310,_0x5cd482,_0x1bc9fa);_0x563c2b=vn(_0x433310,_0x563c2b,new C(_0x54988a),_0x56a628,_0x44478e,_0x56cca6,_0x206dd0,_0x5d9531);}}),_0x563c2b;}function Ru(_0x355ab9,_0x5a89ec,_0x45154b,_0x468b01,_0x21db8c,_0x5459b4,_0x268efa){if(yn(_0x21db8c,_0x45154b)!=null)return _0x5a89ec;const _0x1c7909=_0x5a89ec['serverCache']['isFiltered'](),_0x4ba5b6=_0x5a89ec['serverCache'];if(_0x468b01['value']!=null){if(v(_0x45154b)&&_0x4ba5b6['isFullyInitialized']()||_0x4ba5b6['isCompleteForPath'](_0x45154b))return vn(_0x355ab9,_0x5a89ec,_0x45154b,_0x4ba5b6['getNode']()['getChild'](_0x45154b),_0x21db8c,_0x5459b4,_0x1c7909,_0x268efa);if(v(_0x45154b)){let _0x1d9c1f=new S(null);return _0x4ba5b6['getNode']()['forEachChild'](ye,(_0x170bf3,_0x3bb7df)=>{_0x1d9c1f=_0x1d9c1f['set'](new C(_0x170bf3),_0x3bb7df);}),Si(_0x355ab9,_0x5a89ec,_0x45154b,_0x1d9c1f,_0x21db8c,_0x5459b4,_0x1c7909,_0x268efa);}else return _0x5a89ec;}else{let _0x170f00=new S(null);return _0x468b01['foreach']((_0x138ac3,_0x1dc954)=>{const _0x50b01e=A(_0x45154b,_0x138ac3);_0x4ba5b6['isCompleteForPath'](_0x50b01e)&&(_0x170f00=_0x170f00['set'](_0x138ac3,_0x4ba5b6['getNode']()['getChild'](_0x50b01e)));}),Si(_0x355ab9,_0x5a89ec,_0x45154b,_0x170f00,_0x21db8c,_0x5459b4,_0x1c7909,_0x268efa);}}function Au(_0x2556fa,_0x43a137,_0x54cf59,_0x4d65d1,_0x9ae864){const _0x1426f2=_0x43a137['serverCache'],_0x3d8908=Lo(_0x43a137,_0x1426f2['getNode'](),_0x1426f2['isFullyInitialized']()||v(_0x54cf59),_0x1426f2['isFiltered']());return Ho(_0x2556fa,_0x3d8908,_0x54cf59,_0x4d65d1,Vo,_0x9ae864);}function ku(_0x380acf,_0x111178,_0x59f6b6,_0x2608de,_0x47752c,_0x2f380a){let _0x2fdb31;if(yn(_0x2608de,_0x59f6b6)!=null)return _0x111178;{const _0x3f68bc=new ns(_0x2608de,_0x111178,_0x47752c),_0x323474=_0x111178['eventCache']['getNode']();let _0x5b1295;if(v(_0x59f6b6)||y(_0x59f6b6)==='.priority'){let _0x4ae241;if(_0x111178['serverCache']['isFullyInitialized']())_0x4ae241=mn(_0x2608de,Ue(_0x111178));else{const _0x5705ca=_0x111178['serverCache']['getNode']();f(_0x5705ca instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4ae241=es(_0x2608de,_0x5705ca);}_0x4ae241=_0x4ae241,_0x5b1295=_0x380acf['filter']['updateFullNode'](_0x323474,_0x4ae241,_0x2f380a);}else{const _0xec0ba4=y(_0x59f6b6);let _0x1abfe9=ts(_0x2608de,_0xec0ba4,_0x111178['serverCache']);_0x1abfe9==null&&_0x111178['serverCache']['isCompleteForChild'](_0xec0ba4)&&(_0x1abfe9=_0x323474['getImmediateChild'](_0xec0ba4)),_0x1abfe9!=null?_0x5b1295=_0x380acf['filter']['updateChild'](_0x323474,_0xec0ba4,_0x1abfe9,b(_0x59f6b6),_0x3f68bc,_0x2f380a):_0x111178['eventCache']['getNode']()['hasChild'](_0xec0ba4)?_0x5b1295=_0x380acf['filter']['updateChild'](_0x323474,_0xec0ba4,g['EMPTY_NODE'],b(_0x59f6b6),_0x3f68bc,_0x2f380a):_0x5b1295=_0x323474,_0x5b1295['isEmpty']()&&_0x111178['serverCache']['isFullyInitialized']()&&(_0x2fdb31=mn(_0x2608de,Ue(_0x111178)),_0x2fdb31['isLeafNode']()&&(_0x5b1295=_0x380acf['filter']['updateFullNode'](_0x5b1295,_0x2fdb31,_0x2f380a)));}return _0x2fdb31=_0x111178['serverCache']['isFullyInitialized']()||yn(_0x2608de,w())!=null,wt(_0x111178,_0x5b1295,_0x2fdb31,_0x380acf['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3df2f0,_0x157475){this['query_']=_0x3df2f0,this['eventRegistrations_']=[];const _0x35d581=this['query_']['_queryParams'],_0x57d13e=new Yi(_0x35d581['getIndex']()),_0x5e03ed=qh(_0x35d581);this['processor_']=wu(_0x5e03ed);const _0x4ec8c5=_0x157475['serverCache'],_0x5d3a6e=_0x157475['eventCache'],_0x16a75c=_0x57d13e['updateFullNode'](g['EMPTY_NODE'],_0x4ec8c5['getNode'](),null),_0x4a68a8=_0x5e03ed['updateFullNode'](g['EMPTY_NODE'],_0x5d3a6e['getNode'](),null),_0x4d8820=new Ce(_0x16a75c,_0x4ec8c5['isFullyInitialized'](),_0x57d13e['filtersNodes']()),_0x34d98f=new Ce(_0x4a68a8,_0x5d3a6e['isFullyInitialized'](),_0x5e03ed['filtersNodes']());this['viewCache_']=Dn(_0x34d98f,_0x4d8820),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4edf16){return _0x4edf16['viewCache_']['serverCache']['getNode']();}function Ou(_0x40c54a){return gn(_0x40c54a['viewCache_']);}function Du(_0x12b365,_0x39a765){const _0x4d654a=Ue(_0x12b365['viewCache_']);return _0x4d654a&&(_0x12b365['query']['_queryParams']['loadsAllData']()||!v(_0x39a765)&&!_0x4d654a['getImmediateChild'](y(_0x39a765))['isEmpty']())?_0x4d654a['getChild'](_0x39a765):null;}function lr(_0x5a96b8){return _0x5a96b8['eventRegistrations_']['length']===0x0;}function Mu(_0x18791e,_0x4e6d79){_0x18791e['eventRegistrations_']['push'](_0x4e6d79);}function hr(_0x5f4e0e,_0x107bde,_0x3c5114){const _0x1c8b08=[];if(_0x3c5114){f(_0x107bde==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x18553d=_0x5f4e0e['query']['_path'];_0x5f4e0e['eventRegistrations_']['forEach'](_0x76b69b=>{const _0x3aec43=_0x76b69b['createCancelEvent'](_0x3c5114,_0x18553d);_0x3aec43&&_0x1c8b08['push'](_0x3aec43);});}if(_0x107bde){let _0x268594=[];for(let _0x56967c=0x0;_0x56967c<_0x5f4e0e['eventRegistrations_']['length'];++_0x56967c){const _0x46415a=_0x5f4e0e['eventRegistrations_'][_0x56967c];if(!_0x46415a['matches'](_0x107bde))_0x268594['push'](_0x46415a);else{if(_0x107bde['hasAnyCallback']()){_0x268594=_0x268594['concat'](_0x5f4e0e['eventRegistrations_']['slice'](_0x56967c+0x1));break;}}}_0x5f4e0e['eventRegistrations_']=_0x268594;}else _0x5f4e0e['eventRegistrations_']=[];return _0x1c8b08;}function ur(_0x4e21d1,_0x45bfda,_0x4ad7a5,_0x3b0f6d){_0x45bfda['type']===q['MERGE']&&_0x45bfda['source']['queryId']!==null&&(f(Ue(_0x4e21d1['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x4e21d1['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x239c5e=_0x4e21d1['viewCache_'],_0x12f933=Tu(_0x4e21d1['processor_'],_0x239c5e,_0x45bfda,_0x4ad7a5,_0x3b0f6d);return Cu(_0x4e21d1['processor_'],_0x12f933['viewCache']),f(_0x12f933['viewCache']['serverCache']['isFullyInitialized']()||!_0x239c5e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4e21d1['viewCache_']=_0x12f933['viewCache'],$o(_0x4e21d1,_0x12f933['changes'],_0x12f933['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x27cefb,_0x1e48ee){const _0x1332a1=_0x27cefb['viewCache_']['eventCache'],_0x15dbd8=[];return _0x1332a1['getNode']()['isLeafNode']()||_0x1332a1['getNode']()['forEachChild'](R,(_0x34238f,_0x25f2f3)=>{_0x15dbd8['push'](tt(_0x34238f,_0x25f2f3));}),_0x1332a1['isFullyInitialized']()&&_0x15dbd8['push'](Oo(_0x1332a1['getNode']())),$o(_0x27cefb,_0x15dbd8,_0x1332a1['getNode'](),_0x1e48ee);}function $o(_0x52f9b2,_0x1ae848,_0x51009c,_0x196594){const _0x5322e8=_0x196594?[_0x196594]:_0x52f9b2['eventRegistrations_'];return nu(_0x52f9b2['eventGenerator_'],_0x1ae848,_0x51009c,_0x5322e8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x44bf8e){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x44bf8e;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x35240a){return _0x35240a['views']['size']===0x0;}function is(_0x15ee31,_0x23e8d1,_0x255dec,_0xce571a){const _0x2c3cda=_0x23e8d1['source']['queryId'];if(_0x2c3cda!==null){const _0x588bfa=_0x15ee31['views']['get'](_0x2c3cda);return f(_0x588bfa!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x588bfa,_0x23e8d1,_0x255dec,_0xce571a);}else{let _0x3e4f77=[];for(const _0x11b532 of _0x15ee31['views']['values']())_0x3e4f77=_0x3e4f77['concat'](ur(_0x11b532,_0x23e8d1,_0x255dec,_0xce571a));return _0x3e4f77;}}function qo(_0x19c83b,_0x5dc29e,_0x1fe138,_0x2b4542,_0x5194d2){const _0x40c2d5=_0x5dc29e['_queryIdentifier'],_0x3c0a82=_0x19c83b['views']['get'](_0x40c2d5);if(!_0x3c0a82){let _0x78be4=mn(_0x1fe138,_0x5194d2?_0x2b4542:null),_0x430914=!0x1;_0x78be4?_0x430914=!0x0:_0x2b4542 instanceof g?(_0x78be4=es(_0x1fe138,_0x2b4542),_0x430914=!0x1):(_0x78be4=g['EMPTY_NODE'],_0x430914=!0x1);const _0x572e07=Dn(new Ce(_0x78be4,_0x430914,!0x1),new Ce(_0x2b4542,_0x5194d2,!0x1));return new Nu(_0x5dc29e,_0x572e07);}return _0x3c0a82;}function Wu(_0x1a8190,_0x40a312,_0x3ebcfb,_0x15111a,_0x3edf1b,_0x290302){const _0x591b89=qo(_0x1a8190,_0x40a312,_0x15111a,_0x3edf1b,_0x290302);return _0x1a8190['views']['has'](_0x40a312['_queryIdentifier'])||_0x1a8190['views']['set'](_0x40a312['_queryIdentifier'],_0x591b89),Mu(_0x591b89,_0x3ebcfb),Lu(_0x591b89,_0x3ebcfb);}function Bu(_0x5ec307,_0x10636c,_0x19f335,_0x1a4951){const _0x45f658=_0x10636c['_queryIdentifier'],_0x2b245a=[];let _0x4d7bfc=[];const _0x3f42a5=Te(_0x5ec307);if(_0x45f658==='default'){for(const [_0x544f7a,_0x2f6cee]of _0x5ec307['views']['entries']())_0x4d7bfc=_0x4d7bfc['concat'](hr(_0x2f6cee,_0x19f335,_0x1a4951)),lr(_0x2f6cee)&&(_0x5ec307['views']['delete'](_0x544f7a),_0x2f6cee['query']['_queryParams']['loadsAllData']()||_0x2b245a['push'](_0x2f6cee['query']));}else{const _0x1ed783=_0x5ec307['views']['get'](_0x45f658);_0x1ed783&&(_0x4d7bfc=_0x4d7bfc['concat'](hr(_0x1ed783,_0x19f335,_0x1a4951)),lr(_0x1ed783)&&(_0x5ec307['views']['delete'](_0x45f658),_0x1ed783['query']['_queryParams']['loadsAllData']()||_0x2b245a['push'](_0x1ed783['query'])));}return _0x3f42a5&&!Te(_0x5ec307)&&_0x2b245a['push'](new(Fu())(_0x10636c['_repo'],_0x10636c['_path'])),{'removed':_0x2b245a,'events':_0x4d7bfc};}function zo(_0x59414b){const _0x1dfad4=[];for(const _0x10feac of _0x59414b['views']['values']())_0x10feac['query']['_queryParams']['loadsAllData']()||_0x1dfad4['push'](_0x10feac);return _0x1dfad4;}function Ee(_0x3bbf2d,_0x113dbd){let _0x2fda82=null;for(const _0x133fc1 of _0x3bbf2d['views']['values']())_0x2fda82=_0x2fda82||Du(_0x133fc1,_0x113dbd);return _0x2fda82;}function jo(_0xf8e354,_0x3af6fa){if(_0x3af6fa['_queryParams']['loadsAllData']())return Ln(_0xf8e354);{const _0x152db0=_0x3af6fa['_queryIdentifier'];return _0xf8e354['views']['get'](_0x152db0);}}function Ko(_0x5768a6,_0x51a50a){return jo(_0x5768a6,_0x51a50a)!=null;}function Te(_0x5185e0){return Ln(_0x5185e0)!=null;}function Ln(_0x3e5382){for(const _0x4c8507 of _0x3e5382['views']['values']())if(_0x4c8507['query']['_queryParams']['loadsAllData']())return _0x4c8507;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x2236f1){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x2236f1;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x233280){this['listenProvider_']=_0x233280,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x25f89e,_0x1cef6c,_0x3b921f,_0x3f6809,_0x6daecc){return ou(_0x25f89e['pendingWriteTree_'],_0x1cef6c,_0x3b921f,_0x3f6809,_0x6daecc),_0x6daecc?ht(_0x25f89e,new Fe(Ji(),_0x1cef6c,_0x3b921f)):[];}function Gu(_0x5905f1,_0x194008,_0x40dcd1,_0x293e39){au(_0x5905f1['pendingWriteTree_'],_0x194008,_0x40dcd1,_0x293e39);const _0x1fb926=S['fromObject'](_0x40dcd1);return ht(_0x5905f1,new nt(Ji(),_0x194008,_0x1fb926));}function pe(_0x11736b,_0x453ded,_0x4ae2ed=!0x1){const _0x1f4bcb=cu(_0x11736b['pendingWriteTree_'],_0x453ded);if(lu(_0x11736b['pendingWriteTree_'],_0x453ded)){let _0x27ae8e=new S(null);return _0x1f4bcb['snap']!=null?_0x27ae8e=_0x27ae8e['set'](w(),!0x0):x(_0x1f4bcb['children'],_0x3661b8=>{_0x27ae8e=_0x27ae8e['set'](new C(_0x3661b8),!0x0);}),ht(_0x11736b,new _n(_0x1f4bcb['path'],_0x27ae8e,_0x4ae2ed));}else return[];}function $t(_0x53d7c4,_0x1f778e,_0x30d677){return ht(_0x53d7c4,new Fe(Xi(),_0x1f778e,_0x30d677));}function qu(_0x1f249a,_0x3efae2,_0x38d0ef){const _0x348f59=S['fromObject'](_0x38d0ef);return ht(_0x1f249a,new nt(Xi(),_0x3efae2,_0x348f59));}function zu(_0x486bce,_0xf63de9){return ht(_0x486bce,new Dt(Xi(),_0xf63de9));}function ju(_0xa32881,_0x3e3990,_0x540016){const _0x302d11=rs(_0xa32881,_0x540016);if(_0x302d11){const _0x3118bf=os(_0x302d11),_0x4f44aa=_0x3118bf['path'],_0x450e47=_0x3118bf['queryId'],_0x8139c9=F(_0x4f44aa,_0x3e3990),_0x15364f=new Dt(Zi(_0x450e47),_0x8139c9);return as(_0xa32881,_0x4f44aa,_0x15364f);}else return[];}function wn(_0x4b48ef,_0x1c3903,_0x3d7560,_0x4d25e3,_0x1c8f34=!0x1){const _0x614b=_0x1c3903['_path'],_0x1a4cbb=_0x4b48ef['syncPointTree_']['get'](_0x614b);let _0x341656=[];if(_0x1a4cbb&&(_0x1c3903['_queryIdentifier']==='default'||Ko(_0x1a4cbb,_0x1c3903))){const _0x1749f5=Bu(_0x1a4cbb,_0x1c3903,_0x3d7560,_0x4d25e3);Uu(_0x1a4cbb)&&(_0x4b48ef['syncPointTree_']=_0x4b48ef['syncPointTree_']['remove'](_0x614b));const _0x1a5e66=_0x1749f5['removed'];if(_0x341656=_0x1749f5['events'],!_0x1c8f34){const _0x58b3df=_0x1a5e66['findIndex'](_0x1532f3=>_0x1532f3['_queryParams']['loadsAllData']())!==-0x1,_0x4de88c=_0x4b48ef['syncPointTree_']['findOnPath'](_0x614b,(_0xe52448,_0x252952)=>Te(_0x252952));if(_0x58b3df&&!_0x4de88c){const _0x294aab=_0x4b48ef['syncPointTree_']['subtree'](_0x614b);if(!_0x294aab['isEmpty']()){const _0x362f06=Qu(_0x294aab);for(let _0x40871d=0x0;_0x40871d<_0x362f06['length'];++_0x40871d){const _0x403c2d=_0x362f06[_0x40871d],_0x2c0644=_0x403c2d['query'],_0x11c816=Xo(_0x4b48ef,_0x403c2d);_0x4b48ef['listenProvider_']['startListening'](Tt(_0x2c0644),Mt(_0x4b48ef,_0x2c0644),_0x11c816['hashFn'],_0x11c816['onComplete']);}}}!_0x4de88c&&_0x1a5e66['length']>0x0&&!_0x4d25e3&&(_0x58b3df?_0x4b48ef['listenProvider_']['stopListening'](Tt(_0x1c3903),null):_0x1a5e66['forEach'](_0x364ed7=>{const _0x2da4a3=_0x4b48ef['queryToTagMap']['get'](Fn(_0x364ed7));_0x4b48ef['listenProvider_']['stopListening'](Tt(_0x364ed7),_0x2da4a3);}));}Ju(_0x4b48ef,_0x1a5e66);}return _0x341656;}function Yo(_0x3d88bc,_0x4cb9de,_0x1c274c,_0x4c5795){const _0x463e13=rs(_0x3d88bc,_0x4c5795);if(_0x463e13!=null){const _0x495a80=os(_0x463e13),_0x1f2cd9=_0x495a80['path'],_0x54af7f=_0x495a80['queryId'],_0xfee1a5=F(_0x1f2cd9,_0x4cb9de),_0x3e9873=new Fe(Zi(_0x54af7f),_0xfee1a5,_0x1c274c);return as(_0x3d88bc,_0x1f2cd9,_0x3e9873);}else return[];}function Ku(_0x3c76a1,_0x2bd810,_0x2de5ce,_0x209611){const _0xc69874=rs(_0x3c76a1,_0x209611);if(_0xc69874){const _0x3a4261=os(_0xc69874),_0x51f826=_0x3a4261['path'],_0x4e8b81=_0x3a4261['queryId'],_0xcb3df5=F(_0x51f826,_0x2bd810),_0x57470d=S['fromObject'](_0x2de5ce),_0x1a8973=new nt(Zi(_0x4e8b81),_0xcb3df5,_0x57470d);return as(_0x3c76a1,_0x51f826,_0x1a8973);}else return[];}function bi(_0x462ba2,_0x571e50,_0x4eae47,_0x246335=!0x1){const _0x50d617=_0x571e50['_path'];let _0x283d58=null,_0x4a2e8c=!0x1;_0x462ba2['syncPointTree_']['foreachOnPath'](_0x50d617,(_0x73ab84,_0x565cac)=>{const _0x4ebb72=F(_0x73ab84,_0x50d617);_0x283d58=_0x283d58||Ee(_0x565cac,_0x4ebb72),_0x4a2e8c=_0x4a2e8c||Te(_0x565cac);});let _0x144d4d=_0x462ba2['syncPointTree_']['get'](_0x50d617);_0x144d4d?(_0x4a2e8c=_0x4a2e8c||Te(_0x144d4d),_0x283d58=_0x283d58||Ee(_0x144d4d,w())):(_0x144d4d=new Go(),_0x462ba2['syncPointTree_']=_0x462ba2['syncPointTree_']['set'](_0x50d617,_0x144d4d));let _0x97f679;_0x283d58!=null?_0x97f679=!0x0:(_0x97f679=!0x1,_0x283d58=g['EMPTY_NODE'],_0x462ba2['syncPointTree_']['subtree'](_0x50d617)['foreachChild']((_0x33d330,_0x4e3287)=>{const _0x39dd54=Ee(_0x4e3287,w());_0x39dd54&&(_0x283d58=_0x283d58['updateImmediateChild'](_0x33d330,_0x39dd54));}));const _0x461c39=Ko(_0x144d4d,_0x571e50);if(!_0x461c39&&!_0x571e50['_queryParams']['loadsAllData']()){const _0x54a4ab=Fn(_0x571e50);f(!_0x462ba2['queryToTagMap']['has'](_0x54a4ab),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x11ef2b=Xu();_0x462ba2['queryToTagMap']['set'](_0x54a4ab,_0x11ef2b),_0x462ba2['tagToQueryMap']['set'](_0x11ef2b,_0x54a4ab);}const _0x1756a1=Mn(_0x462ba2['pendingWriteTree_'],_0x50d617);let _0x229fda=Wu(_0x144d4d,_0x571e50,_0x4eae47,_0x1756a1,_0x283d58,_0x97f679);if(!_0x461c39&&!_0x4a2e8c&&!_0x246335){const _0x25fade=jo(_0x144d4d,_0x571e50);_0x229fda=_0x229fda['concat'](Zu(_0x462ba2,_0x571e50,_0x25fade));}return _0x229fda;}function xn(_0x158d19,_0x5412fc,_0x37db83){const _0x38ebc7=_0x158d19['pendingWriteTree_'],_0x4b1aad=_0x158d19['syncPointTree_']['findOnPath'](_0x5412fc,(_0x44c95c,_0x4be3f1)=>{const _0x11ddff=F(_0x44c95c,_0x5412fc),_0x44dcab=Ee(_0x4be3f1,_0x11ddff);if(_0x44dcab)return _0x44dcab;});return Uo(_0x38ebc7,_0x5412fc,_0x4b1aad,_0x37db83,!0x0);}function Yu(_0x4ebf5e,_0x4063cf){const _0x28ab5e=_0x4063cf['_path'];let _0x330f1c=null;_0x4ebf5e['syncPointTree_']['foreachOnPath'](_0x28ab5e,(_0xa0ca56,_0x1ef5d6)=>{const _0x37af32=F(_0xa0ca56,_0x28ab5e);_0x330f1c=_0x330f1c||Ee(_0x1ef5d6,_0x37af32);});let _0x2a0b2b=_0x4ebf5e['syncPointTree_']['get'](_0x28ab5e);_0x2a0b2b?_0x330f1c=_0x330f1c||Ee(_0x2a0b2b,w()):(_0x2a0b2b=new Go(),_0x4ebf5e['syncPointTree_']=_0x4ebf5e['syncPointTree_']['set'](_0x28ab5e,_0x2a0b2b));const _0x39c5f7=_0x330f1c!=null,_0x52b28c=_0x39c5f7?new Ce(_0x330f1c,!0x0,!0x1):null,_0x2eee93=Mn(_0x4ebf5e['pendingWriteTree_'],_0x4063cf['_path']),_0x2e2547=qo(_0x2a0b2b,_0x4063cf,_0x2eee93,_0x39c5f7?_0x52b28c['getNode']():g['EMPTY_NODE'],_0x39c5f7);return Ou(_0x2e2547);}function ht(_0x208653,_0x1c67e2){return Qo(_0x1c67e2,_0x208653['syncPointTree_'],null,Mn(_0x208653['pendingWriteTree_'],w()));}function Qo(_0x4413e1,_0x27a32f,_0x5e00e6,_0x3ef9df){if(v(_0x4413e1['path']))return Jo(_0x4413e1,_0x27a32f,_0x5e00e6,_0x3ef9df);{const _0x18cd21=_0x27a32f['get'](w());_0x5e00e6==null&&_0x18cd21!=null&&(_0x5e00e6=Ee(_0x18cd21,w()));let _0x7f3993=[];const _0x5db3dd=y(_0x4413e1['path']),_0x27bde1=_0x4413e1['operationForChild'](_0x5db3dd),_0x105f32=_0x27a32f['children']['get'](_0x5db3dd);if(_0x105f32&&_0x27bde1){const _0x371ec0=_0x5e00e6?_0x5e00e6['getImmediateChild'](_0x5db3dd):null,_0x3a9474=Wo(_0x3ef9df,_0x5db3dd);_0x7f3993=_0x7f3993['concat'](Qo(_0x27bde1,_0x105f32,_0x371ec0,_0x3a9474));}return _0x18cd21&&(_0x7f3993=_0x7f3993['concat'](is(_0x18cd21,_0x4413e1,_0x3ef9df,_0x5e00e6))),_0x7f3993;}}function Jo(_0x2b05da,_0x38b6d5,_0x5cf362,_0x42a6c4){const _0x5505b2=_0x38b6d5['get'](w());_0x5cf362==null&&_0x5505b2!=null&&(_0x5cf362=Ee(_0x5505b2,w()));let _0x1560ec=[];return _0x38b6d5['children']['inorderTraversal']((_0x193f0d,_0x1a7d45)=>{const _0x4f80a9=_0x5cf362?_0x5cf362['getImmediateChild'](_0x193f0d):null,_0x5f1c26=Wo(_0x42a6c4,_0x193f0d),_0x30d507=_0x2b05da['operationForChild'](_0x193f0d);_0x30d507&&(_0x1560ec=_0x1560ec['concat'](Jo(_0x30d507,_0x1a7d45,_0x4f80a9,_0x5f1c26)));}),_0x5505b2&&(_0x1560ec=_0x1560ec['concat'](is(_0x5505b2,_0x2b05da,_0x42a6c4,_0x5cf362))),_0x1560ec;}function Xo(_0x3c39a8,_0x2c29ef){const _0x45f9ea=_0x2c29ef['query'],_0x28f7b8=Mt(_0x3c39a8,_0x45f9ea);return{'hashFn':()=>(Pu(_0x2c29ef)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2646e0=>{if(_0x2646e0==='ok')return _0x28f7b8?ju(_0x3c39a8,_0x45f9ea['_path'],_0x28f7b8):zu(_0x3c39a8,_0x45f9ea['_path']);{const _0x3d8c66=ql(_0x2646e0,_0x45f9ea);return wn(_0x3c39a8,_0x45f9ea,null,_0x3d8c66);}}};}function Mt(_0xc8dfc1,_0x34cc1e){const _0x26f9d4=Fn(_0x34cc1e);return _0xc8dfc1['queryToTagMap']['get'](_0x26f9d4);}function Fn(_0x3a8841){return _0x3a8841['_path']['toString']()+'$'+_0x3a8841['_queryIdentifier'];}function rs(_0x4a2d39,_0x5b65ac){return _0x4a2d39['tagToQueryMap']['get'](_0x5b65ac);}function os(_0x44b714){const _0xff52e4=_0x44b714['indexOf']('$');return f(_0xff52e4!==-0x1&&_0xff52e4<_0x44b714['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x44b714['substr'](_0xff52e4+0x1),'path':new C(_0x44b714['substr'](0x0,_0xff52e4))};}function as(_0xf9a367,_0x3d9244,_0xc301db){const _0x21df68=_0xf9a367['syncPointTree_']['get'](_0x3d9244);f(_0x21df68,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4ba8d0=Mn(_0xf9a367['pendingWriteTree_'],_0x3d9244);return is(_0x21df68,_0xc301db,_0x4ba8d0,null);}function Qu(_0x381666){return _0x381666['fold']((_0x1a39a3,_0x16963f,_0x17fe47)=>{if(_0x16963f&&Te(_0x16963f))return[Ln(_0x16963f)];{let _0x46ea95=[];return _0x16963f&&(_0x46ea95=zo(_0x16963f)),x(_0x17fe47,(_0x51bad7,_0x286037)=>{_0x46ea95=_0x46ea95['concat'](_0x286037);}),_0x46ea95;}});}function Tt(_0xd5a93b){return _0xd5a93b['_queryParams']['loadsAllData']()&&!_0xd5a93b['_queryParams']['isDefault']()?new(Hu())(_0xd5a93b['_repo'],_0xd5a93b['_path']):_0xd5a93b;}function Ju(_0x5647e7,_0x4edd40){for(let _0x280929=0x0;_0x280929<_0x4edd40['length'];++_0x280929){const _0x4cf54c=_0x4edd40[_0x280929];if(!_0x4cf54c['_queryParams']['loadsAllData']()){const _0x483cac=Fn(_0x4cf54c),_0x4dfafb=_0x5647e7['queryToTagMap']['get'](_0x483cac);_0x5647e7['queryToTagMap']['delete'](_0x483cac),_0x5647e7['tagToQueryMap']['delete'](_0x4dfafb);}}}function Xu(){return $u++;}function Zu(_0x10592b,_0x4019d6,_0x405d59){const _0x4cc31d=_0x4019d6['_path'],_0x597604=Mt(_0x10592b,_0x4019d6),_0x8fc097=Xo(_0x10592b,_0x405d59),_0x1eadfd=_0x10592b['listenProvider_']['startListening'](Tt(_0x4019d6),_0x597604,_0x8fc097['hashFn'],_0x8fc097['onComplete']),_0x4f0154=_0x10592b['syncPointTree_']['subtree'](_0x4cc31d);if(_0x597604)f(!Te(_0x4f0154['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x161886=_0x4f0154['fold']((_0x33998b,_0x361b5a,_0x1a52e4)=>{if(!v(_0x33998b)&&_0x361b5a&&Te(_0x361b5a))return[Ln(_0x361b5a)['query']];{let _0x379169=[];return _0x361b5a&&(_0x379169=_0x379169['concat'](zo(_0x361b5a)['map'](_0x345b3f=>_0x345b3f['query']))),x(_0x1a52e4,(_0x384cd7,_0x12f1e1)=>{_0x379169=_0x379169['concat'](_0x12f1e1);}),_0x379169;}});for(let _0x575445=0x0;_0x575445<_0x161886['length'];++_0x575445){const _0x5bab33=_0x161886[_0x575445];_0x10592b['listenProvider_']['stopListening'](Tt(_0x5bab33),Mt(_0x10592b,_0x5bab33));}}return _0x1eadfd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x1b90e1){this['node_']=_0x1b90e1;}['getImmediateChild'](_0x3ba683){const _0x544fd8=this['node_']['getImmediateChild'](_0x3ba683);return new cs(_0x544fd8);}['node'](){return this['node_'];}}class ls{constructor(_0x27b563,_0x5e4111){this['syncTree_']=_0x27b563,this['path_']=_0x5e4111;}['getImmediateChild'](_0x34e49d){const _0x597711=A(this['path_'],_0x34e49d);return new ls(this['syncTree_'],_0x597711);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x50d76c){return _0x50d76c=_0x50d76c||{},_0x50d76c['timestamp']=_0x50d76c['timestamp']||new Date()['getTime'](),_0x50d76c;},fr=function(_0x1b3dde,_0x4d6e1e,_0x400167){if(!_0x1b3dde||typeof _0x1b3dde!='object')return _0x1b3dde;if(f('.sv'in _0x1b3dde,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1b3dde['.sv']=='string')return td(_0x1b3dde['.sv'],_0x4d6e1e,_0x400167);if(typeof _0x1b3dde['.sv']=='object')return nd(_0x1b3dde['.sv'],_0x4d6e1e);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1b3dde,null,0x2));},td=function(_0x4b34c8,_0x2e0cf5,_0x5d9477){switch(_0x4b34c8){case'timestamp':return _0x5d9477['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4b34c8);}},nd=function(_0xded17e,_0x52c5a1,_0x212dbf){_0xded17e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xded17e,null,0x2));const _0x551f78=_0xded17e['increment'];typeof _0x551f78!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x551f78);const _0x4715d6=_0x52c5a1['node']();if(f(_0x4715d6!==null&&typeof _0x4715d6<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4715d6['isLeafNode']())return _0x551f78;const _0xf53eef=_0x4715d6['getValue']();return typeof _0xf53eef!='number'?_0x551f78:_0xf53eef+_0x551f78;},Zo=function(_0x2e05ad,_0x5c65ac,_0xb8ed58,_0xab376e){return us(_0x5c65ac,new ls(_0xb8ed58,_0x2e05ad),_0xab376e);},hs=function(_0x252a85,_0x16ebd9,_0x3df38d){return us(_0x252a85,new cs(_0x16ebd9),_0x3df38d);};function us(_0x29a93b,_0x448ed0,_0x40807a){const _0x542c72=_0x29a93b['getPriority']()['val'](),_0x3ec178=fr(_0x542c72,_0x448ed0['getImmediateChild']('.priority'),_0x40807a);let _0x29062e;if(_0x29a93b['isLeafNode']()){const _0x2a3e95=_0x29a93b,_0x5a1de4=fr(_0x2a3e95['getValue'](),_0x448ed0,_0x40807a);return _0x5a1de4!==_0x2a3e95['getValue']()||_0x3ec178!==_0x2a3e95['getPriority']()['val']()?new D(_0x5a1de4,N(_0x3ec178)):_0x29a93b;}else{const _0x4ea682=_0x29a93b;return _0x29062e=_0x4ea682,_0x3ec178!==_0x4ea682['getPriority']()['val']()&&(_0x29062e=_0x29062e['updatePriority'](new D(_0x3ec178))),_0x4ea682['forEachChild'](R,(_0x234064,_0x1f71fc)=>{const _0x42c0ed=us(_0x1f71fc,_0x448ed0['getImmediateChild'](_0x234064),_0x40807a);_0x42c0ed!==_0x1f71fc&&(_0x29062e=_0x29062e['updateImmediateChild'](_0x234064,_0x42c0ed));}),_0x29062e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4e1f5e='',_0x547233=null,_0x480a2f={'children':{},'childCount':0x0}){this['name']=_0x4e1f5e,this['parent']=_0x547233,this['node']=_0x480a2f;}}function Un(_0x1d5a85,_0x2b89b2){let _0x365ca3=_0x2b89b2 instanceof C?_0x2b89b2:new C(_0x2b89b2),_0x157c11=_0x1d5a85,_0x33f5de=y(_0x365ca3);for(;_0x33f5de!==null;){const _0x17a270=Oe(_0x157c11['node']['children'],_0x33f5de)||{'children':{},'childCount':0x0};_0x157c11=new ds(_0x33f5de,_0x157c11,_0x17a270),_0x365ca3=b(_0x365ca3),_0x33f5de=y(_0x365ca3);}return _0x157c11;}function Ge(_0x2ea652){return _0x2ea652['node']['value'];}function fs(_0x4f7a2b,_0x106cd0){_0x4f7a2b['node']['value']=_0x106cd0,Ri(_0x4f7a2b);}function ea(_0x47d056){return _0x47d056['node']['childCount']>0x0;}function id(_0x5c5668){return Ge(_0x5c5668)===void 0x0&&!ea(_0x5c5668);}function Wn(_0x3eb4cd,_0x2dd0d8){x(_0x3eb4cd['node']['children'],(_0x4d0cdf,_0x2ed506)=>{_0x2dd0d8(new ds(_0x4d0cdf,_0x3eb4cd,_0x2ed506));});}function ta(_0x5ec435,_0x5185e4,_0xe99d73,_0x207cb5){_0xe99d73&&_0x5185e4(_0x5ec435),Wn(_0x5ec435,_0xd64bee=>{ta(_0xd64bee,_0x5185e4,!0x0);});}function sd(_0xddbc01,_0x14f1ad,_0x1b289a){let _0x53e474=_0xddbc01['parent'];for(;_0x53e474!==null;){if(_0x14f1ad(_0x53e474))return!0x0;_0x53e474=_0x53e474['parent'];}return!0x1;}function Gt(_0x201ef9){return new C(_0x201ef9['parent']===null?_0x201ef9['name']:Gt(_0x201ef9['parent'])+'/'+_0x201ef9['name']);}function Ri(_0x8d0642){_0x8d0642['parent']!==null&&rd(_0x8d0642['parent'],_0x8d0642['name'],_0x8d0642);}function rd(_0x26fa15,_0x490860,_0x8c760b){const _0x1cc488=id(_0x8c760b),_0x4a3dc2=Y(_0x26fa15['node']['children'],_0x490860);_0x1cc488&&_0x4a3dc2?(delete _0x26fa15['node']['children'][_0x490860],_0x26fa15['node']['childCount']--,Ri(_0x26fa15)):!_0x1cc488&&!_0x4a3dc2&&(_0x26fa15['node']['children'][_0x490860]=_0x8c760b['node'],_0x26fa15['node']['childCount']++,Ri(_0x26fa15));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x46814c){return typeof _0x46814c=='string'&&_0x46814c['length']!==0x0&&!od['test'](_0x46814c);},na=function(_0x68ad67){return typeof _0x68ad67=='string'&&_0x68ad67['length']!==0x0&&!ad['test'](_0x68ad67);},cd=function(_0x2038e0){return _0x2038e0&&(_0x2038e0=_0x2038e0['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x2038e0);},Cn=function(_0x420c86){return _0x420c86===null||typeof _0x420c86=='string'||typeof _0x420c86=='number'&&!Wi(_0x420c86)||_0x420c86&&typeof _0x420c86=='object'&&Y(_0x420c86,'.sv');},qt=function(_0x2ecb72,_0x5d11b4,_0x10af46,_0x5b18cb){_0x5b18cb&&_0x5d11b4===void 0x0||zt(Nn(_0x2ecb72,'value'),_0x5d11b4,_0x10af46);},zt=function(_0x30e8ff,_0x55b6b2,_0x1a8675){const _0x1dc581=_0x1a8675 instanceof C?new Sh(_0x1a8675,_0x30e8ff):_0x1a8675;if(_0x55b6b2===void 0x0)throw new Error(_0x30e8ff+'contains\x20undefined\x20'+Ne(_0x1dc581));if(typeof _0x55b6b2=='function')throw new Error(_0x30e8ff+'contains\x20a\x20function\x20'+Ne(_0x1dc581)+'\x20with\x20contents\x20=\x20'+_0x55b6b2['toString']());if(Wi(_0x55b6b2))throw new Error(_0x30e8ff+'contains\x20'+_0x55b6b2['toString']()+'\x20'+Ne(_0x1dc581));if(typeof _0x55b6b2=='string'&&_0x55b6b2['length']>oi/0x3&&Pn(_0x55b6b2)>oi)throw new Error(_0x30e8ff+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1dc581)+'\x20(\x27'+_0x55b6b2['substring'](0x0,0x32)+'...\x27)');if(_0x55b6b2&&typeof _0x55b6b2=='object'){let _0x3f19bb=!0x1,_0x5edb37=!0x1;if(x(_0x55b6b2,(_0x34227c,_0x69c3e7)=>{if(_0x34227c==='.value')_0x3f19bb=!0x0;else{if(_0x34227c!=='.priority'&&_0x34227c!=='.sv'&&(_0x5edb37=!0x0,!ps(_0x34227c)))throw new Error(_0x30e8ff+'\x20contains\x20an\x20invalid\x20key\x20('+_0x34227c+')\x20'+Ne(_0x1dc581)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1dc581,_0x34227c),zt(_0x30e8ff,_0x69c3e7,_0x1dc581),Rh(_0x1dc581);}),_0x3f19bb&&_0x5edb37)throw new Error(_0x30e8ff+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1dc581)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x3ad7cf,_0x579812){let _0x9d066f,_0x2110d9;for(_0x9d066f=0x0;_0x9d066f<_0x579812['length'];_0x9d066f++){_0x2110d9=_0x579812[_0x9d066f];const _0xd1b9a5=kt(_0x2110d9);for(let _0x821645=0x0;_0x821645<_0xd1b9a5['length'];_0x821645++)if(!(_0xd1b9a5[_0x821645]==='.priority'&&_0x821645===_0xd1b9a5['length']-0x1)){if(!ps(_0xd1b9a5[_0x821645]))throw new Error(_0x3ad7cf+'contains\x20an\x20invalid\x20key\x20('+_0xd1b9a5[_0x821645]+')\x20in\x20path\x20'+_0x2110d9['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x579812['sort'](Th);let _0x397d33=null;for(_0x9d066f=0x0;_0x9d066f<_0x579812['length'];_0x9d066f++){if(_0x2110d9=_0x579812[_0x9d066f],_0x397d33!==null&&$(_0x397d33,_0x2110d9))throw new Error(_0x3ad7cf+'contains\x20a\x20path\x20'+_0x397d33['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2110d9['toString']());_0x397d33=_0x2110d9;}},hd=function(_0x60bd2f,_0x21b02b,_0x2d8ec4,_0x52e53a){const _0x475ec5=Nn(_0x60bd2f,'values');if(!(_0x21b02b&&typeof _0x21b02b=='object')||Array['isArray'](_0x21b02b))throw new Error(_0x475ec5+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x26f0a4=[];x(_0x21b02b,(_0x1f4728,_0x5c0c04)=>{const _0x2ca583=new C(_0x1f4728);if(zt(_0x475ec5,_0x5c0c04,A(_0x2d8ec4,_0x2ca583)),Gi(_0x2ca583)==='.priority'&&!Cn(_0x5c0c04))throw new Error(_0x475ec5+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2ca583['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x26f0a4['push'](_0x2ca583);}),ld(_0x475ec5,_0x26f0a4);},_s=function(_0x5b305f,_0xaf4897,_0x4b733f,_0x36bcf5){if(!na(_0x4b733f))throw new Error(Nn(_0x5b305f,_0xaf4897)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4b733f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x35ea1c,_0x4ec856,_0x151c6b,_0x1df8b6){_0x151c6b&&(_0x151c6b=_0x151c6b['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x35ea1c,_0x4ec856,_0x151c6b);},gs=function(_0x404fe3,_0x4c2ec8){if(y(_0x4c2ec8)==='.info')throw new Error(_0x404fe3+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x50f830,_0x5b0490){const _0x3cd33f=_0x5b0490['path']['toString']();if(typeof _0x5b0490['repoInfo']['host']!='string'||_0x5b0490['repoInfo']['host']['length']===0x0||!ps(_0x5b0490['repoInfo']['namespace'])&&_0x5b0490['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3cd33f['length']!==0x0&&!cd(_0x3cd33f))throw new Error(Nn(_0x50f830,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0xa82928,_0x12ab53){let _0x2e0ebd=null;for(let _0x4a8571=0x0;_0x4a8571<_0x12ab53['length'];_0x4a8571++){const _0x34d23e=_0x12ab53[_0x4a8571],_0x40ae82=_0x34d23e['getPath']();_0x2e0ebd!==null&&!qi(_0x40ae82,_0x2e0ebd['path'])&&(_0xa82928['eventLists_']['push'](_0x2e0ebd),_0x2e0ebd=null),_0x2e0ebd===null&&(_0x2e0ebd={'events':[],'path':_0x40ae82}),_0x2e0ebd['events']['push'](_0x34d23e);}_0x2e0ebd&&_0xa82928['eventLists_']['push'](_0x2e0ebd);}function ia(_0x38fa6e,_0x140968,_0x415466){Bn(_0x38fa6e,_0x415466),sa(_0x38fa6e,_0x340380=>qi(_0x340380,_0x140968));}function V(_0x59a77b,_0x507c17,_0x3e6584){Bn(_0x59a77b,_0x3e6584),sa(_0x59a77b,_0x27d80b=>$(_0x27d80b,_0x507c17)||$(_0x507c17,_0x27d80b));}function sa(_0x461771,_0x181dd7){_0x461771['recursionDepth_']++;let _0x4cb854=!0x0;for(let _0x3aced5=0x0;_0x3aced5<_0x461771['eventLists_']['length'];_0x3aced5++){const _0x3e85e4=_0x461771['eventLists_'][_0x3aced5];if(_0x3e85e4){const _0x570efa=_0x3e85e4['path'];_0x181dd7(_0x570efa)?(pd(_0x461771['eventLists_'][_0x3aced5]),_0x461771['eventLists_'][_0x3aced5]=null):_0x4cb854=!0x1;}}_0x4cb854&&(_0x461771['eventLists_']=[]),_0x461771['recursionDepth_']--;}function pd(_0x34b4e4){for(let _0x409cdf=0x0;_0x409cdf<_0x34b4e4['events']['length'];_0x409cdf++){const _0x23a1a5=_0x34b4e4['events'][_0x409cdf];if(_0x23a1a5!==null){_0x34b4e4['events'][_0x409cdf]=null;const _0x14927b=_0x23a1a5['getEventRunner']();Et&&L('event:\x20'+_0x23a1a5['toString']()),lt(_0x14927b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x20638b,_0x34cab3,_0x3b1dda,_0x118747){this['repoInfo_']=_0x20638b,this['forceRestClient_']=_0x34cab3,this['authTokenProvider_']=_0x3b1dda,this['appCheckProvider_']=_0x118747,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x20e382,_0x2eaa95,_0x26d8d0){if(_0x20e382['stats_']=Hi(_0x20e382['repoInfo_']),_0x20e382['forceRestClient_']||Yl())_0x20e382['server_']=new fn(_0x20e382['repoInfo_'],(_0x331d3a,_0x15745b,_0x1fab21,_0x489d4a)=>{pr(_0x20e382,_0x331d3a,_0x15745b,_0x1fab21,_0x489d4a);},_0x20e382['authTokenProvider_'],_0x20e382['appCheckProvider_']),setTimeout(()=>_r(_0x20e382,!0x0),0x0);else{if(typeof _0x26d8d0<'u'&&_0x26d8d0!==null){if(typeof _0x26d8d0!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x26d8d0);}catch(_0x3e3cb6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3e3cb6);}}_0x20e382['persistentConnection_']=new ie(_0x20e382['repoInfo_'],_0x2eaa95,(_0x5862d9,_0x16d987,_0x528e20,_0x2fe247)=>{pr(_0x20e382,_0x5862d9,_0x16d987,_0x528e20,_0x2fe247);},_0x66c78d=>{_r(_0x20e382,_0x66c78d);},_0x31f04c=>{yd(_0x20e382,_0x31f04c);},_0x20e382['authTokenProvider_'],_0x20e382['appCheckProvider_'],_0x26d8d0),_0x20e382['server_']=_0x20e382['persistentConnection_'];}_0x20e382['authTokenProvider_']['addTokenChangeListener'](_0x4fc363=>{_0x20e382['server_']['refreshAuthToken'](_0x4fc363);}),_0x20e382['appCheckProvider_']['addTokenChangeListener'](_0x117294=>{_0x20e382['server_']['refreshAppCheckToken'](_0x117294['token']);}),_0x20e382['statsReporter_']=eh(_0x20e382['repoInfo_'],()=>new eu(_0x20e382['stats_'],_0x20e382['server_'])),_0x20e382['infoData_']=new Yh(),_0x20e382['infoSyncTree_']=new dr({'startListening':(_0x51b646,_0x1dd48c,_0x3b3d16,_0x4d1c7a)=>{let _0x2b0699=[];const _0x598f0f=_0x20e382['infoData_']['getNode'](_0x51b646['_path']);return _0x598f0f['isEmpty']()||(_0x2b0699=$t(_0x20e382['infoSyncTree_'],_0x51b646['_path'],_0x598f0f),setTimeout(()=>{_0x4d1c7a('ok');},0x0)),_0x2b0699;},'stopListening':()=>{}}),ms(_0x20e382,'connected',!0x1),_0x20e382['serverSyncTree_']=new dr({'startListening':(_0x1592c1,_0x4c42a7,_0x3d53e5,_0x212577)=>(_0x20e382['server_']['listen'](_0x1592c1,_0x3d53e5,_0x4c42a7,(_0x5e9e16,_0x3df17b)=>{const _0x727737=_0x212577(_0x5e9e16,_0x3df17b);V(_0x20e382['eventQueue_'],_0x1592c1['_path'],_0x727737);}),[]),'stopListening':(_0x424933,_0x147b7c)=>{_0x20e382['server_']['unlisten'](_0x424933,_0x147b7c);}});}function oa(_0x5370de){const _0x463e23=_0x5370de['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x463e23;}function jt(_0xd27b3){return ed({'timestamp':oa(_0xd27b3)});}function pr(_0x4d7aff,_0xcce89b,_0x3f9d21,_0x394f7c,_0x130c08){_0x4d7aff['dataUpdateCount']++;const _0x1a4d60=new C(_0xcce89b);_0x3f9d21=_0x4d7aff['interceptServerDataCallback_']?_0x4d7aff['interceptServerDataCallback_'](_0xcce89b,_0x3f9d21):_0x3f9d21;let _0x1561a3=[];if(_0x130c08){if(_0x394f7c){const _0x2912fe=ln(_0x3f9d21,_0x5ae45e=>N(_0x5ae45e));_0x1561a3=Ku(_0x4d7aff['serverSyncTree_'],_0x1a4d60,_0x2912fe,_0x130c08);}else{const _0x30024a=N(_0x3f9d21);_0x1561a3=Yo(_0x4d7aff['serverSyncTree_'],_0x1a4d60,_0x30024a,_0x130c08);}}else{if(_0x394f7c){const _0x55baa1=ln(_0x3f9d21,_0xae8e54=>N(_0xae8e54));_0x1561a3=qu(_0x4d7aff['serverSyncTree_'],_0x1a4d60,_0x55baa1);}else{const _0x1addde=N(_0x3f9d21);_0x1561a3=$t(_0x4d7aff['serverSyncTree_'],_0x1a4d60,_0x1addde);}}let _0x2fac2a=_0x1a4d60;_0x1561a3['length']>0x0&&(_0x2fac2a=st(_0x4d7aff,_0x1a4d60)),V(_0x4d7aff['eventQueue_'],_0x2fac2a,_0x1561a3);}function _r(_0x96a5a1,_0x436cf8){ms(_0x96a5a1,'connected',_0x436cf8),_0x436cf8===!0x1&&wd(_0x96a5a1);}function yd(_0x1a3cd7,_0x1fcd84){x(_0x1fcd84,(_0x36374a,_0xe5e773)=>{ms(_0x1a3cd7,_0x36374a,_0xe5e773);});}function ms(_0x1d0833,_0x350617,_0x5d13ea){const _0x4e63a2=new C('/.info/'+_0x350617),_0x5b81ad=N(_0x5d13ea);_0x1d0833['infoData_']['updateSnapshot'](_0x4e63a2,_0x5b81ad);const _0x3d49e0=$t(_0x1d0833['infoSyncTree_'],_0x4e63a2,_0x5b81ad);V(_0x1d0833['eventQueue_'],_0x4e63a2,_0x3d49e0);}function Vn(_0x261f35){return _0x261f35['nextWriteId_']++;}function vd(_0x1fee4b,_0x24bc44,_0x37cd5a){const _0xc60cb1=Yu(_0x1fee4b['serverSyncTree_'],_0x24bc44);return _0xc60cb1!=null?Promise['resolve'](_0xc60cb1):_0x1fee4b['server_']['get'](_0x24bc44)['then'](_0x53bfd8=>{const _0x15511e=N(_0x53bfd8)['withIndex'](_0x24bc44['_queryParams']['getIndex']());bi(_0x1fee4b['serverSyncTree_'],_0x24bc44,_0x37cd5a,!0x0);let _0x384eb9;if(_0x24bc44['_queryParams']['loadsAllData']())_0x384eb9=$t(_0x1fee4b['serverSyncTree_'],_0x24bc44['_path'],_0x15511e);else{const _0x519164=Mt(_0x1fee4b['serverSyncTree_'],_0x24bc44);_0x384eb9=Yo(_0x1fee4b['serverSyncTree_'],_0x24bc44['_path'],_0x15511e,_0x519164);}return V(_0x1fee4b['eventQueue_'],_0x24bc44['_path'],_0x384eb9),wn(_0x1fee4b['serverSyncTree_'],_0x24bc44,_0x37cd5a,null,!0x0),_0x15511e;},_0x430f45=>(ut(_0x1fee4b,'get\x20for\x20query\x20'+O(_0x24bc44)+'\x20failed:\x20'+_0x430f45),Promise['reject'](new Error(_0x430f45))));}function Ed(_0x2da6bd,_0x7fb5b5,_0x23f439,_0x156ace,_0x512079){ut(_0x2da6bd,'set',{'path':_0x7fb5b5['toString'](),'value':_0x23f439,'priority':_0x156ace});const _0x36a7ed=jt(_0x2da6bd),_0x59c27b=N(_0x23f439,_0x156ace),_0x43b982=xn(_0x2da6bd['serverSyncTree_'],_0x7fb5b5),_0x5b393f=hs(_0x59c27b,_0x43b982,_0x36a7ed),_0x447827=Vn(_0x2da6bd),_0x4ae4d4=ss(_0x2da6bd['serverSyncTree_'],_0x7fb5b5,_0x5b393f,_0x447827,!0x0);Bn(_0x2da6bd['eventQueue_'],_0x4ae4d4),_0x2da6bd['server_']['put'](_0x7fb5b5['toString'](),_0x59c27b['val'](!0x0),(_0x19f07e,_0x256172)=>{const _0x1f5126=_0x19f07e==='ok';_0x1f5126||U('set\x20at\x20'+_0x7fb5b5+'\x20failed:\x20'+_0x19f07e);const _0x454770=pe(_0x2da6bd['serverSyncTree_'],_0x447827,!_0x1f5126);V(_0x2da6bd['eventQueue_'],_0x7fb5b5,_0x454770),Ai(_0x2da6bd,_0x512079,_0x19f07e,_0x256172);});const _0x5c82ce=vs(_0x2da6bd,_0x7fb5b5);st(_0x2da6bd,_0x5c82ce),V(_0x2da6bd['eventQueue_'],_0x5c82ce,[]);}function Id(_0x59ed40,_0xe4b93f,_0x46c87a,_0x35575c){ut(_0x59ed40,'update',{'path':_0xe4b93f['toString'](),'value':_0x46c87a});let _0x494663=!0x0;const _0x4af092=jt(_0x59ed40),_0x399f34={};if(x(_0x46c87a,(_0x16a98f,_0x24fa9c)=>{_0x494663=!0x1,_0x399f34[_0x16a98f]=Zo(A(_0xe4b93f,_0x16a98f),N(_0x24fa9c),_0x59ed40['serverSyncTree_'],_0x4af092);}),_0x494663)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x59ed40,_0x35575c,'ok',void 0x0);else{const _0x262c19=Vn(_0x59ed40),_0x20822a=Gu(_0x59ed40['serverSyncTree_'],_0xe4b93f,_0x399f34,_0x262c19);Bn(_0x59ed40['eventQueue_'],_0x20822a),_0x59ed40['server_']['merge'](_0xe4b93f['toString'](),_0x46c87a,(_0x162560,_0x320a5d)=>{const _0x1dfd4e=_0x162560==='ok';_0x1dfd4e||U('update\x20at\x20'+_0xe4b93f+'\x20failed:\x20'+_0x162560);const _0x57e85f=pe(_0x59ed40['serverSyncTree_'],_0x262c19,!_0x1dfd4e),_0x15c238=_0x57e85f['length']>0x0?st(_0x59ed40,_0xe4b93f):_0xe4b93f;V(_0x59ed40['eventQueue_'],_0x15c238,_0x57e85f),Ai(_0x59ed40,_0x35575c,_0x162560,_0x320a5d);}),x(_0x46c87a,_0x3b5638=>{const _0x81990d=vs(_0x59ed40,A(_0xe4b93f,_0x3b5638));st(_0x59ed40,_0x81990d);}),V(_0x59ed40['eventQueue_'],_0xe4b93f,[]);}}function wd(_0x4ac006){ut(_0x4ac006,'onDisconnectEvents');const _0x4f585d=jt(_0x4ac006),_0x26eaec=pn();Ei(_0x4ac006['onDisconnect_'],w(),(_0x552df8,_0x43cdbb)=>{const _0x417e6b=Zo(_0x552df8,_0x43cdbb,_0x4ac006['serverSyncTree_'],_0x4f585d);Mo(_0x26eaec,_0x552df8,_0x417e6b);});let _0x18eaad=[];Ei(_0x26eaec,w(),(_0x13ce8d,_0x2cd1c9)=>{_0x18eaad=_0x18eaad['concat']($t(_0x4ac006['serverSyncTree_'],_0x13ce8d,_0x2cd1c9));const _0x5b517a=vs(_0x4ac006,_0x13ce8d);st(_0x4ac006,_0x5b517a);}),_0x4ac006['onDisconnect_']=pn(),V(_0x4ac006['eventQueue_'],w(),_0x18eaad);}function Cd(_0xd71ede,_0x25dc70,_0x19e609){let _0x2f399e;y(_0x25dc70['_path'])==='.info'?_0x2f399e=bi(_0xd71ede['infoSyncTree_'],_0x25dc70,_0x19e609):_0x2f399e=bi(_0xd71ede['serverSyncTree_'],_0x25dc70,_0x19e609),ia(_0xd71ede['eventQueue_'],_0x25dc70['_path'],_0x2f399e);}function Td(_0x1e68c5,_0x31a94c,_0x5484ac){let _0x34fd39;y(_0x31a94c['_path'])==='.info'?_0x34fd39=wn(_0x1e68c5['infoSyncTree_'],_0x31a94c,_0x5484ac):_0x34fd39=wn(_0x1e68c5['serverSyncTree_'],_0x31a94c,_0x5484ac),ia(_0x1e68c5['eventQueue_'],_0x31a94c['_path'],_0x34fd39);}function aa(_0x1f1bdb){_0x1f1bdb['persistentConnection_']&&_0x1f1bdb['persistentConnection_']['interrupt'](ra);}function Sd(_0x14f166){_0x14f166['persistentConnection_']&&_0x14f166['persistentConnection_']['resume'](ra);}function ut(_0x2b9742,..._0x209e04){let _0xfb171b='';_0x2b9742['persistentConnection_']&&(_0xfb171b=_0x2b9742['persistentConnection_']['id']+':'),L(_0xfb171b,..._0x209e04);}function Ai(_0x25accf,_0x2b0f8c,_0x5a9a6f,_0x502068){_0x2b0f8c&&lt(()=>{if(_0x5a9a6f==='ok')_0x2b0f8c(null);else{const _0x1e8a9d=(_0x5a9a6f||'error')['toUpperCase']();let _0x113a34=_0x1e8a9d;_0x502068&&(_0x113a34+=':\x20'+_0x502068);const _0x4419f1=new Error(_0x113a34);_0x4419f1['code']=_0x1e8a9d,_0x2b0f8c(_0x4419f1);}});}function bd(_0x2b7e9b,_0x2c07ef,_0x130832,_0x176093,_0x3574fe,_0x19f83a){ut(_0x2b7e9b,'transaction\x20on\x20'+_0x2c07ef);const _0x548a32={'path':_0x2c07ef,'update':_0x130832,'onComplete':_0x176093,'status':null,'order':to(),'applyLocally':_0x19f83a,'retryCount':0x0,'unwatcher':_0x3574fe,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3bc6c1=ys(_0x2b7e9b,_0x2c07ef,void 0x0);_0x548a32['currentInputSnapshot']=_0x3bc6c1;const _0x34508b=_0x548a32['update'](_0x3bc6c1['val']());if(_0x34508b===void 0x0)_0x548a32['unwatcher'](),_0x548a32['currentOutputSnapshotRaw']=null,_0x548a32['currentOutputSnapshotResolved']=null,_0x548a32['onComplete']&&_0x548a32['onComplete'](null,!0x1,_0x548a32['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x34508b,_0x548a32['path']),_0x548a32['status']=0x0;const _0x299a8f=Un(_0x2b7e9b['transactionQueueTree_'],_0x2c07ef),_0x2431e9=Ge(_0x299a8f)||[];_0x2431e9['push'](_0x548a32),fs(_0x299a8f,_0x2431e9);let _0x154256;typeof _0x34508b=='object'&&_0x34508b!==null&&Y(_0x34508b,'.priority')?(_0x154256=Oe(_0x34508b,'.priority'),f(Cn(_0x154256),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x154256=(xn(_0x2b7e9b['serverSyncTree_'],_0x2c07ef)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3993ef=jt(_0x2b7e9b),_0x1e355c=N(_0x34508b,_0x154256),_0x1a3be0=hs(_0x1e355c,_0x3bc6c1,_0x3993ef);_0x548a32['currentOutputSnapshotRaw']=_0x1e355c,_0x548a32['currentOutputSnapshotResolved']=_0x1a3be0,_0x548a32['currentWriteId']=Vn(_0x2b7e9b);const _0x5a0b4d=ss(_0x2b7e9b['serverSyncTree_'],_0x2c07ef,_0x1a3be0,_0x548a32['currentWriteId'],_0x548a32['applyLocally']);V(_0x2b7e9b['eventQueue_'],_0x2c07ef,_0x5a0b4d),Hn(_0x2b7e9b,_0x2b7e9b['transactionQueueTree_']);}}function ys(_0x154972,_0x4b28aa,_0xbb1cc6){return xn(_0x154972['serverSyncTree_'],_0x4b28aa,_0xbb1cc6)||g['EMPTY_NODE'];}function Hn(_0x20635a,_0x9d7365=_0x20635a['transactionQueueTree_']){if(_0x9d7365||$n(_0x20635a,_0x9d7365),Ge(_0x9d7365)){const _0x39a3fa=la(_0x20635a,_0x9d7365);f(_0x39a3fa['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x39a3fa['every'](_0x564dae=>_0x564dae['status']===0x0)&&Rd(_0x20635a,Gt(_0x9d7365),_0x39a3fa);}else ea(_0x9d7365)&&Wn(_0x9d7365,_0x1488dc=>{Hn(_0x20635a,_0x1488dc);});}function Rd(_0x9c8c3e,_0x4823c6,_0xee21a3){const _0x5b2eca=_0xee21a3['map'](_0x39a445=>_0x39a445['currentWriteId']),_0x11f014=ys(_0x9c8c3e,_0x4823c6,_0x5b2eca);let _0x4c3c74=_0x11f014;const _0x4b7e56=_0x11f014['hash']();for(let _0x1fb33f=0x0;_0x1fb33f<_0xee21a3['length'];_0x1fb33f++){const _0x297b2a=_0xee21a3[_0x1fb33f];f(_0x297b2a['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x297b2a['status']=0x1,_0x297b2a['retryCount']++;const _0x16d97d=F(_0x4823c6,_0x297b2a['path']);_0x4c3c74=_0x4c3c74['updateChild'](_0x16d97d,_0x297b2a['currentOutputSnapshotRaw']);}const _0x3cd1aa=_0x4c3c74['val'](!0x0),_0x1d176d=_0x4823c6;_0x9c8c3e['server_']['put'](_0x1d176d['toString'](),_0x3cd1aa,_0x4fdc7d=>{ut(_0x9c8c3e,'transaction\x20put\x20response',{'path':_0x1d176d['toString'](),'status':_0x4fdc7d});let _0x5a4001=[];if(_0x4fdc7d==='ok'){const _0x2b8c05=[];for(let _0x35d45f=0x0;_0x35d45f<_0xee21a3['length'];_0x35d45f++)_0xee21a3[_0x35d45f]['status']=0x2,_0x5a4001=_0x5a4001['concat'](pe(_0x9c8c3e['serverSyncTree_'],_0xee21a3[_0x35d45f]['currentWriteId'])),_0xee21a3[_0x35d45f]['onComplete']&&_0x2b8c05['push'](()=>_0xee21a3[_0x35d45f]['onComplete'](null,!0x0,_0xee21a3[_0x35d45f]['currentOutputSnapshotResolved'])),_0xee21a3[_0x35d45f]['unwatcher']();$n(_0x9c8c3e,Un(_0x9c8c3e['transactionQueueTree_'],_0x4823c6)),Hn(_0x9c8c3e,_0x9c8c3e['transactionQueueTree_']),V(_0x9c8c3e['eventQueue_'],_0x4823c6,_0x5a4001);for(let _0x588bce=0x0;_0x588bce<_0x2b8c05['length'];_0x588bce++)lt(_0x2b8c05[_0x588bce]);}else{if(_0x4fdc7d==='datastale'){for(let _0x29f21b=0x0;_0x29f21b<_0xee21a3['length'];_0x29f21b++)_0xee21a3[_0x29f21b]['status']===0x3?_0xee21a3[_0x29f21b]['status']=0x4:_0xee21a3[_0x29f21b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1d176d['toString']()+'\x20failed:\x20'+_0x4fdc7d);for(let _0xdfa4ac=0x0;_0xdfa4ac<_0xee21a3['length'];_0xdfa4ac++)_0xee21a3[_0xdfa4ac]['status']=0x4,_0xee21a3[_0xdfa4ac]['abortReason']=_0x4fdc7d;}st(_0x9c8c3e,_0x4823c6);}},_0x4b7e56);}function st(_0x572a74,_0x1cb64b){const _0x221214=ca(_0x572a74,_0x1cb64b),_0x1d4d43=Gt(_0x221214),_0x5a2a4b=la(_0x572a74,_0x221214);return Ad(_0x572a74,_0x5a2a4b,_0x1d4d43),_0x1d4d43;}function Ad(_0x345e82,_0x364fbf,_0x4f4f04){if(_0x364fbf['length']===0x0)return;const _0x1bd3be=[];let _0x48f70d=[];const _0x4927b3=_0x364fbf['filter'](_0x1dbe0f=>_0x1dbe0f['status']===0x0)['map'](_0x32c6de=>_0x32c6de['currentWriteId']);for(let _0x2ec338=0x0;_0x2ec338<_0x364fbf['length'];_0x2ec338++){const _0x33b165=_0x364fbf[_0x2ec338],_0x529d3f=F(_0x4f4f04,_0x33b165['path']);let _0x636186=!0x1,_0x42520e;if(f(_0x529d3f!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x33b165['status']===0x4)_0x636186=!0x0,_0x42520e=_0x33b165['abortReason'],_0x48f70d=_0x48f70d['concat'](pe(_0x345e82['serverSyncTree_'],_0x33b165['currentWriteId'],!0x0));else{if(_0x33b165['status']===0x0){if(_0x33b165['retryCount']>=_d)_0x636186=!0x0,_0x42520e='maxretry',_0x48f70d=_0x48f70d['concat'](pe(_0x345e82['serverSyncTree_'],_0x33b165['currentWriteId'],!0x0));else{const _0x5baddc=ys(_0x345e82,_0x33b165['path'],_0x4927b3);_0x33b165['currentInputSnapshot']=_0x5baddc;const _0x227258=_0x364fbf[_0x2ec338]['update'](_0x5baddc['val']());if(_0x227258!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x227258,_0x33b165['path']);let _0x395a0d=N(_0x227258);typeof _0x227258=='object'&&_0x227258!=null&&Y(_0x227258,'.priority')||(_0x395a0d=_0x395a0d['updatePriority'](_0x5baddc['getPriority']()));const _0x6c57e4=_0x33b165['currentWriteId'],_0x3d5391=jt(_0x345e82),_0xa24f7a=hs(_0x395a0d,_0x5baddc,_0x3d5391);_0x33b165['currentOutputSnapshotRaw']=_0x395a0d,_0x33b165['currentOutputSnapshotResolved']=_0xa24f7a,_0x33b165['currentWriteId']=Vn(_0x345e82),_0x4927b3['splice'](_0x4927b3['indexOf'](_0x6c57e4),0x1),_0x48f70d=_0x48f70d['concat'](ss(_0x345e82['serverSyncTree_'],_0x33b165['path'],_0xa24f7a,_0x33b165['currentWriteId'],_0x33b165['applyLocally'])),_0x48f70d=_0x48f70d['concat'](pe(_0x345e82['serverSyncTree_'],_0x6c57e4,!0x0));}else _0x636186=!0x0,_0x42520e='nodata',_0x48f70d=_0x48f70d['concat'](pe(_0x345e82['serverSyncTree_'],_0x33b165['currentWriteId'],!0x0));}}}V(_0x345e82['eventQueue_'],_0x4f4f04,_0x48f70d),_0x48f70d=[],_0x636186&&(_0x364fbf[_0x2ec338]['status']=0x2,function(_0x106834){setTimeout(_0x106834,Math['floor'](0x0));}(_0x364fbf[_0x2ec338]['unwatcher']),_0x364fbf[_0x2ec338]['onComplete']&&(_0x42520e==='nodata'?_0x1bd3be['push'](()=>_0x364fbf[_0x2ec338]['onComplete'](null,!0x1,_0x364fbf[_0x2ec338]['currentInputSnapshot'])):_0x1bd3be['push'](()=>_0x364fbf[_0x2ec338]['onComplete'](new Error(_0x42520e),!0x1,null))));}$n(_0x345e82,_0x345e82['transactionQueueTree_']);for(let _0x2976f8=0x0;_0x2976f8<_0x1bd3be['length'];_0x2976f8++)lt(_0x1bd3be[_0x2976f8]);Hn(_0x345e82,_0x345e82['transactionQueueTree_']);}function ca(_0x262f1a,_0x111c5e){let _0x3d1583,_0x53eb39=_0x262f1a['transactionQueueTree_'];for(_0x3d1583=y(_0x111c5e);_0x3d1583!==null&&Ge(_0x53eb39)===void 0x0;)_0x53eb39=Un(_0x53eb39,_0x3d1583),_0x111c5e=b(_0x111c5e),_0x3d1583=y(_0x111c5e);return _0x53eb39;}function la(_0x5aecb5,_0x5835cc){const _0x38ab82=[];return ha(_0x5aecb5,_0x5835cc,_0x38ab82),_0x38ab82['sort']((_0x2a85f2,_0x4334c1)=>_0x2a85f2['order']-_0x4334c1['order']),_0x38ab82;}function ha(_0x3182a4,_0x1e0e6b,_0x40a877){const _0x382a32=Ge(_0x1e0e6b);if(_0x382a32){for(let _0x2bb006=0x0;_0x2bb006<_0x382a32['length'];_0x2bb006++)_0x40a877['push'](_0x382a32[_0x2bb006]);}Wn(_0x1e0e6b,_0x127aeb=>{ha(_0x3182a4,_0x127aeb,_0x40a877);});}function $n(_0xb6136b,_0x55cffc){const _0x573dc3=Ge(_0x55cffc);if(_0x573dc3){let _0x29a1f1=0x0;for(let _0x2c11fe=0x0;_0x2c11fe<_0x573dc3['length'];_0x2c11fe++)_0x573dc3[_0x2c11fe]['status']!==0x2&&(_0x573dc3[_0x29a1f1]=_0x573dc3[_0x2c11fe],_0x29a1f1++);_0x573dc3['length']=_0x29a1f1,fs(_0x55cffc,_0x573dc3['length']>0x0?_0x573dc3:void 0x0);}Wn(_0x55cffc,_0x571ec5=>{$n(_0xb6136b,_0x571ec5);});}function vs(_0x1b06e8,_0x4a03fc){const _0xc80de3=Gt(ca(_0x1b06e8,_0x4a03fc)),_0x34429d=Un(_0x1b06e8['transactionQueueTree_'],_0x4a03fc);return sd(_0x34429d,_0x484d6e=>{ai(_0x1b06e8,_0x484d6e);}),ai(_0x1b06e8,_0x34429d),ta(_0x34429d,_0x2bf1ee=>{ai(_0x1b06e8,_0x2bf1ee);}),_0xc80de3;}function ai(_0x2085f0,_0x1016aa){const _0x5d4af0=Ge(_0x1016aa);if(_0x5d4af0){const _0x2c9297=[];let _0x56c7dc=[],_0x364345=-0x1;for(let _0x26dd10=0x0;_0x26dd10<_0x5d4af0['length'];_0x26dd10++)_0x5d4af0[_0x26dd10]['status']===0x3||(_0x5d4af0[_0x26dd10]['status']===0x1?(f(_0x364345===_0x26dd10-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x364345=_0x26dd10,_0x5d4af0[_0x26dd10]['status']=0x3,_0x5d4af0[_0x26dd10]['abortReason']='set'):(f(_0x5d4af0[_0x26dd10]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5d4af0[_0x26dd10]['unwatcher'](),_0x56c7dc=_0x56c7dc['concat'](pe(_0x2085f0['serverSyncTree_'],_0x5d4af0[_0x26dd10]['currentWriteId'],!0x0)),_0x5d4af0[_0x26dd10]['onComplete']&&_0x2c9297['push'](_0x5d4af0[_0x26dd10]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x364345===-0x1?fs(_0x1016aa,void 0x0):_0x5d4af0['length']=_0x364345+0x1,V(_0x2085f0['eventQueue_'],Gt(_0x1016aa),_0x56c7dc);for(let _0x40a834=0x0;_0x40a834<_0x2c9297['length'];_0x40a834++)lt(_0x2c9297[_0x40a834]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x533935){let _0x34f41a='';const _0x4ad84f=_0x533935['split']('/');for(let _0x5d711b=0x0;_0x5d711b<_0x4ad84f['length'];_0x5d711b++)if(_0x4ad84f[_0x5d711b]['length']>0x0){let _0x241be7=_0x4ad84f[_0x5d711b];try{_0x241be7=decodeURIComponent(_0x241be7['replace'](/\+/g,'\x20'));}catch{}_0x34f41a+='/'+_0x241be7;}return _0x34f41a;}function Nd(_0x7cb5e5){const _0x5df20b={};_0x7cb5e5['charAt'](0x0)==='?'&&(_0x7cb5e5=_0x7cb5e5['substring'](0x1));for(const _0x288f8a of _0x7cb5e5['split']('&')){if(_0x288f8a['length']===0x0)continue;const _0x5e5180=_0x288f8a['split']('=');_0x5e5180['length']===0x2?_0x5df20b[decodeURIComponent(_0x5e5180[0x0])]=decodeURIComponent(_0x5e5180[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x288f8a+'\x27\x20in\x20query\x20\x27'+_0x7cb5e5+'\x27');}return _0x5df20b;}const gr=function(_0x134a3f,_0x5a91b5){const _0x1516de=Pd(_0x134a3f),_0x25dfde=_0x1516de['namespace'];_0x1516de['domain']==='firebase.com'&&oe(_0x1516de['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x25dfde||_0x25dfde==='undefined')&&_0x1516de['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1516de['secure']||Bl();const _0x30c919=_0x1516de['scheme']==='ws'||_0x1516de['scheme']==='wss';return{'repoInfo':new _o(_0x1516de['host'],_0x1516de['secure'],_0x25dfde,_0x30c919,_0x5a91b5,'',_0x25dfde!==_0x1516de['subdomain']),'path':new C(_0x1516de['pathString'])};},Pd=function(_0x5a1bc1){let _0x225859='',_0x573f12='',_0x1636f9='',_0x63132e='',_0x1c5a98='',_0x1fc64=!0x0,_0x346482='https',_0x6876ee=0x1bb;if(typeof _0x5a1bc1=='string'){let _0x54dc88=_0x5a1bc1['indexOf']('//');_0x54dc88>=0x0&&(_0x346482=_0x5a1bc1['substring'](0x0,_0x54dc88-0x1),_0x5a1bc1=_0x5a1bc1['substring'](_0x54dc88+0x2));let _0x27f447=_0x5a1bc1['indexOf']('/');_0x27f447===-0x1&&(_0x27f447=_0x5a1bc1['length']);let _0x495ca7=_0x5a1bc1['indexOf']('?');_0x495ca7===-0x1&&(_0x495ca7=_0x5a1bc1['length']),_0x225859=_0x5a1bc1['substring'](0x0,Math['min'](_0x27f447,_0x495ca7)),_0x27f447<_0x495ca7&&(_0x63132e=kd(_0x5a1bc1['substring'](_0x27f447,_0x495ca7)));const _0x47047c=Nd(_0x5a1bc1['substring'](Math['min'](_0x5a1bc1['length'],_0x495ca7)));_0x54dc88=_0x225859['indexOf'](':'),_0x54dc88>=0x0?(_0x1fc64=_0x346482==='https'||_0x346482==='wss',_0x6876ee=parseInt(_0x225859['substring'](_0x54dc88+0x1),0xa)):_0x54dc88=_0x225859['length'];const _0x561426=_0x225859['slice'](0x0,_0x54dc88);if(_0x561426['toLowerCase']()==='localhost')_0x573f12='localhost';else{if(_0x561426['split']('.')['length']<=0x2)_0x573f12=_0x561426;else{const _0x161ff8=_0x225859['indexOf']('.');_0x1636f9=_0x225859['substring'](0x0,_0x161ff8)['toLowerCase'](),_0x573f12=_0x225859['substring'](_0x161ff8+0x1),_0x1c5a98=_0x1636f9;}}'ns'in _0x47047c&&(_0x1c5a98=_0x47047c['ns']);}return{'host':_0x225859,'port':_0x6876ee,'domain':_0x573f12,'subdomain':_0x1636f9,'secure':_0x1fc64,'scheme':_0x346482,'pathString':_0x63132e,'namespace':_0x1c5a98};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x507ee1=0x0;const _0x5a4cf5=[];return function(_0x38b21c){const _0x46c22e=_0x38b21c===_0x507ee1;_0x507ee1=_0x38b21c;let _0x2d0092;const _0x515070=new Array(0x8);for(_0x2d0092=0x7;_0x2d0092>=0x0;_0x2d0092--)_0x515070[_0x2d0092]=mr['charAt'](_0x38b21c%0x40),_0x38b21c=Math['floor'](_0x38b21c/0x40);f(_0x38b21c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x308edb=_0x515070['join']('');if(_0x46c22e){for(_0x2d0092=0xb;_0x2d0092>=0x0&&_0x5a4cf5[_0x2d0092]===0x3f;_0x2d0092--)_0x5a4cf5[_0x2d0092]=0x0;_0x5a4cf5[_0x2d0092]++;}else{for(_0x2d0092=0x0;_0x2d0092<0xc;_0x2d0092++)_0x5a4cf5[_0x2d0092]=Math['floor'](Math['random']()*0x40);}for(_0x2d0092=0x0;_0x2d0092<0xc;_0x2d0092++)_0x308edb+=mr['charAt'](_0x5a4cf5[_0x2d0092]);return f(_0x308edb['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x308edb;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x1e4273,_0x1efa1a,_0x12fdd5,_0xd6a5ed){this['eventType']=_0x1e4273,this['eventRegistration']=_0x1efa1a,this['snapshot']=_0x12fdd5,this['prevName']=_0xd6a5ed;}['getPath'](){const _0x55e53f=this['snapshot']['ref'];return this['eventType']==='value'?_0x55e53f['_path']:_0x55e53f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x13e2ec,_0x4897f1,_0x2d6b9e){this['eventRegistration']=_0x13e2ec,this['error']=_0x4897f1,this['path']=_0x2d6b9e;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x23e979,_0x4fdade){this['snapshotCallback']=_0x23e979,this['cancelCallback']=_0x4fdade;}['onValue'](_0x5bf0e0,_0x232a44){this['snapshotCallback']['call'](null,_0x5bf0e0,_0x232a44);}['onCancel'](_0x49ba4f){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x49ba4f);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1f1028){return this['snapshotCallback']===_0x1f1028['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1f1028['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1f1028['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x591e8b,_0x4ddc58,_0x2ab3e4,_0x1ac7e6){this['_repo']=_0x591e8b,this['_path']=_0x4ddc58,this['_queryParams']=_0x2ab3e4,this['_orderByCalled']=_0x1ac7e6;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x514763=nr(this['_queryParams']),_0x353aae=Bi(_0x514763);return _0x353aae==='{}'?'default':_0x353aae;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x377b6b){if(_0x377b6b=k(_0x377b6b),!(_0x377b6b instanceof be))return!0x1;const _0x4a74d9=this['_repo']===_0x377b6b['_repo'],_0x4388a4=qi(this['_path'],_0x377b6b['_path']),_0x249d5=this['_queryIdentifier']===_0x377b6b['_queryIdentifier'];return _0x4a74d9&&_0x4388a4&&_0x249d5;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x5cc223,_0x337d17){if(_0x5cc223['_orderByCalled']===!0x0)throw new Error(_0x337d17+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x46cf5d){let _0x27daaf=null,_0x3e0943=null;if(_0x46cf5d['hasStart']()&&(_0x27daaf=_0x46cf5d['getIndexStartValue']()),_0x46cf5d['hasEnd']()&&(_0x3e0943=_0x46cf5d['getIndexEndValue']()),_0x46cf5d['getIndex']()===ye){const _0x2195c2='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3a83c1='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x46cf5d['hasStart']()){if(_0x46cf5d['getIndexStartName']()!==xe)throw new Error(_0x2195c2);if(typeof _0x27daaf!='string')throw new Error(_0x3a83c1);}if(_0x46cf5d['hasEnd']()){if(_0x46cf5d['getIndexEndName']()!==Ie)throw new Error(_0x2195c2);if(typeof _0x3e0943!='string')throw new Error(_0x3a83c1);}}else{if(_0x46cf5d['getIndex']()===R){if(_0x27daaf!=null&&!Cn(_0x27daaf)||_0x3e0943!=null&&!Cn(_0x3e0943))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x46cf5d['getIndex']()instanceof Ki||_0x46cf5d['getIndex']()===Po,'unknown\x20index\x20type.'),_0x27daaf!=null&&typeof _0x27daaf=='object'||_0x3e0943!=null&&typeof _0x3e0943=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x1ddca6){if(_0x1ddca6['hasStart']()&&_0x1ddca6['hasEnd']()&&_0x1ddca6['hasLimit']()&&!_0x1ddca6['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x29b30f,_0x30e247){super(_0x29b30f,_0x30e247,new Qi(),!0x1);}get['parent'](){const _0x447ead=To(this['_path']);return _0x447ead===null?null:new Z(this['_repo'],_0x447ead);}get['root'](){let _0x4dea14=this;for(;_0x4dea14['parent']!==null;)_0x4dea14=_0x4dea14['parent'];return _0x4dea14;}}class rt{constructor(_0x4a90b4,_0x180702,_0x3c04c9){this['_node']=_0x4a90b4,this['ref']=_0x180702,this['_index']=_0x3c04c9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5a8b74){const _0x710241=new C(_0x5a8b74),_0x24ff5c=Lt(this['ref'],_0x5a8b74);return new rt(this['_node']['getChild'](_0x710241),_0x24ff5c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x8b3c7a){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x19610d,_0x1c38e3)=>_0x8b3c7a(new rt(_0x1c38e3,Lt(this['ref'],_0x19610d),R)));}['hasChild'](_0x45c830){const _0x3a1f77=new C(_0x45c830);return!this['_node']['getChild'](_0x3a1f77)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x4f90f0,_0x5c9d4f){return _0x4f90f0=k(_0x4f90f0),_0x4f90f0['_checkNotDeleted']('ref'),_0x5c9d4f!==void 0x0?Lt(_0x4f90f0['_root'],_0x5c9d4f):_0x4f90f0['_root'];}function Lt(_0x97d41e,_0x3c1c42){return _0x97d41e=k(_0x97d41e),y(_0x97d41e['_path'])===null?ud('child','path',_0x3c1c42):_s('child','path',_0x3c1c42),new Z(_0x97d41e['_repo'],A(_0x97d41e['_path'],_0x3c1c42));}function d_(_0x5919e2,_0x32c270){_0x5919e2=k(_0x5919e2),gs('push',_0x5919e2['_path']),qt('push',_0x32c270,_0x5919e2['_path'],!0x0);const _0x495b8c=oa(_0x5919e2['_repo']),_0x3d3345=Od(_0x495b8c),_0x49e9f5=Lt(_0x5919e2,_0x3d3345),_0x78e1d4=Lt(_0x5919e2,_0x3d3345);let _0x581888;return _0x32c270!=null?_0x581888=Ld(_0x78e1d4,_0x32c270)['then'](()=>_0x78e1d4):_0x581888=Promise['resolve'](_0x78e1d4),_0x49e9f5['then']=_0x581888['then']['bind'](_0x581888),_0x49e9f5['catch']=_0x581888['then']['bind'](_0x581888,void 0x0),_0x49e9f5;}function Ld(_0x3b32fa,_0x203637){_0x3b32fa=k(_0x3b32fa),gs('set',_0x3b32fa['_path']),qt('set',_0x203637,_0x3b32fa['_path'],!0x1);const _0x191e3b=new Ve();return Ed(_0x3b32fa['_repo'],_0x3b32fa['_path'],_0x203637,null,_0x191e3b['wrapCallback'](()=>{})),_0x191e3b['promise'];}function f_(_0x296530,_0x1a48c2){hd('update',_0x1a48c2,_0x296530['_path']);const _0x4b0d70=new Ve();return Id(_0x296530['_repo'],_0x296530['_path'],_0x1a48c2,_0x4b0d70['wrapCallback'](()=>{})),_0x4b0d70['promise'];}function p_(_0x4edf2c){_0x4edf2c=k(_0x4edf2c);const _0x380d91=new ua(()=>{}),_0xfef237=new qn(_0x380d91);return vd(_0x4edf2c['_repo'],_0x4edf2c,_0xfef237)['then'](_0x4da471=>new rt(_0x4da471,new Z(_0x4edf2c['_repo'],_0x4edf2c['_path']),_0x4edf2c['_queryParams']['getIndex']()));}class qn{constructor(_0x48799a){this['callbackContext']=_0x48799a;}['respondsTo'](_0x5d49fa){return _0x5d49fa==='value';}['createEvent'](_0x589dc8,_0x31f671){const _0x4d6a05=_0x31f671['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x589dc8['snapshotNode'],new Z(_0x31f671['_repo'],_0x31f671['_path']),_0x4d6a05));}['getEventRunner'](_0x3a10cb){return _0x3a10cb['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3a10cb['error']):()=>this['callbackContext']['onValue'](_0x3a10cb['snapshot'],null);}['createCancelEvent'](_0xeb10d1,_0x3d6dd7){return this['callbackContext']['hasCancelCallback']?new Md(this,_0xeb10d1,_0x3d6dd7):null;}['matches'](_0x2203b2){return _0x2203b2 instanceof qn?!_0x2203b2['callbackContext']||!this['callbackContext']?!0x0:_0x2203b2['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3275ee,_0x27cd9f,_0x3fd2fd,_0x299582,_0x2151f1){const _0xc8d752=new ua(_0x3fd2fd,void 0x0),_0x24295a=new qn(_0xc8d752);return Cd(_0x3275ee['_repo'],_0x3275ee,_0x24295a),()=>Td(_0x3275ee['_repo'],_0x3275ee,_0x24295a);}function Fd(_0x229005,_0x42f374,_0xfe8da5,_0x127b67){return xd(_0x229005,'value',_0x42f374);}class dt{}class pa extends dt{constructor(_0x859afb,_0x445bbe){super(),this['_value']=_0x859afb,this['_key']=_0x445bbe,this['type']='endAt';}['_apply'](_0x1f2fd2){qt('endAt',this['_value'],_0x1f2fd2['_path'],!0x0);const _0x586db9=Kh(_0x1f2fd2['_queryParams'],this['_value'],this['_key']);if(fa(_0x586db9),Gn(_0x586db9),_0x1f2fd2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x1f2fd2['_repo'],_0x1f2fd2['_path'],_0x586db9,_0x1f2fd2['_orderByCalled']);}}function __(_0x2fec59,_0x108840){return new pa(_0x2fec59,_0x108840);}class _a extends dt{constructor(_0x2ed73d,_0x1d37fd){super(),this['_value']=_0x2ed73d,this['_key']=_0x1d37fd,this['type']='startAt';}['_apply'](_0x5e8eee){qt('startAt',this['_value'],_0x5e8eee['_path'],!0x0);const _0x27d34b=jh(_0x5e8eee['_queryParams'],this['_value'],this['_key']);if(fa(_0x27d34b),Gn(_0x27d34b),_0x5e8eee['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5e8eee['_repo'],_0x5e8eee['_path'],_0x27d34b,_0x5e8eee['_orderByCalled']);}}function g_(_0xdbbb32=null,_0x456e72){return new _a(_0xdbbb32,_0x456e72);}class Ud extends dt{constructor(_0x1d3738){super(),this['_limit']=_0x1d3738,this['type']='limitToFirst';}['_apply'](_0x41a55c){if(_0x41a55c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x41a55c['_repo'],_0x41a55c['_path'],zh(_0x41a55c['_queryParams'],this['_limit']),_0x41a55c['_orderByCalled']);}}function m_(_0x14c03c){if(Math['floor'](_0x14c03c)!==_0x14c03c||_0x14c03c<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x14c03c);}class Wd extends dt{constructor(_0xbdad50){super(),this['_path']=_0xbdad50,this['type']='orderByChild';}['_apply'](_0x567e29){da(_0x567e29,'orderByChild');const _0x382893=new C(this['_path']);if(v(_0x382893))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x33ecb9=new Ki(_0x382893),_0x77b407=Do(_0x567e29['_queryParams'],_0x33ecb9);return Gn(_0x77b407),new be(_0x567e29['_repo'],_0x567e29['_path'],_0x77b407,!0x0);}}function y_(_0x19d778){if(_0x19d778==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x19d778==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x19d778==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x19d778),new Wd(_0x19d778);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3c3cdd){da(_0x3c3cdd,'orderByKey');const _0x185efb=Do(_0x3c3cdd['_queryParams'],ye);return Gn(_0x185efb),new be(_0x3c3cdd['_repo'],_0x3c3cdd['_path'],_0x185efb,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x5cfd2c,_0x4fa78f){super(),this['_value']=_0x5cfd2c,this['_key']=_0x4fa78f,this['type']='equalTo';}['_apply'](_0x1329ac){if(qt('equalTo',this['_value'],_0x1329ac['_path'],!0x1),_0x1329ac['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1329ac['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x1329ac));}}function E_(_0x475c42,_0x313840){return new Vd(_0x475c42,_0x313840);}function I_(_0x45b1d8,..._0x2e18a7){let _0x550d19=k(_0x45b1d8);for(const _0x591cf2 of _0x2e18a7)_0x550d19=_0x591cf2['_apply'](_0x550d19);return _0x550d19;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0xcd9bd4,_0x151221,_0x2f4e77,_0x5c21fa){const _0x18c08b=_0x151221['lastIndexOf'](':'),_0x40d107=_0x151221['substring'](0x0,_0x18c08b),_0x30a068=Wt(_0x40d107);_0xcd9bd4['repoInfo_']=new _o(_0x151221,_0x30a068,_0xcd9bd4['repoInfo_']['namespace'],_0xcd9bd4['repoInfo_']['webSocketOnly'],_0xcd9bd4['repoInfo_']['nodeAdmin'],_0xcd9bd4['repoInfo_']['persistenceKey'],_0xcd9bd4['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2f4e77),_0x5c21fa&&(_0xcd9bd4['authTokenProvider_']=_0x5c21fa);}function qd(_0x3b978d,_0x222cc1,_0x2fe3c7,_0x238f91,_0x175a1d){let _0x45f91f=_0x238f91||_0x3b978d['options']['databaseURL'];_0x45f91f===void 0x0&&(_0x3b978d['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3b978d['options']['projectId']),_0x45f91f=_0x3b978d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2bcf9b=gr(_0x45f91f,_0x175a1d),_0x47a42a=_0x2bcf9b['repoInfo'],_0x5511cd;typeof process<'u'&&Us&&(_0x5511cd=Us[Hd]),_0x5511cd?(_0x45f91f='http://'+_0x5511cd+'?ns='+_0x47a42a['namespace'],_0x2bcf9b=gr(_0x45f91f,_0x175a1d),_0x47a42a=_0x2bcf9b['repoInfo']):_0x2bcf9b['repoInfo']['secure'];const _0x34d0f0=new Jl(_0x3b978d['name'],_0x3b978d['options'],_0x222cc1);dd('Invalid\x20Firebase\x20Database\x20URL',_0x2bcf9b),v(_0x2bcf9b['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5ca0e5=jd(_0x47a42a,_0x3b978d,_0x34d0f0,new Ql(_0x3b978d,_0x2fe3c7));return new Kd(_0x5ca0e5,_0x3b978d);}function zd(_0x59a5b4,_0x1b61ce){const _0x2b1550=ki[_0x1b61ce];(!_0x2b1550||_0x2b1550[_0x59a5b4['key']]!==_0x59a5b4)&&oe('Database\x20'+_0x1b61ce+'('+_0x59a5b4['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x59a5b4),delete _0x2b1550[_0x59a5b4['key']];}function jd(_0x5ba524,_0x456d5f,_0x7229f0,_0x2ccb76){let _0x13e3b4=ki[_0x456d5f['name']];_0x13e3b4||(_0x13e3b4={},ki[_0x456d5f['name']]=_0x13e3b4);let _0x3c33a6=_0x13e3b4[_0x5ba524['toURLString']()];return _0x3c33a6&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3c33a6=new gd(_0x5ba524,$d,_0x7229f0,_0x2ccb76),_0x13e3b4[_0x5ba524['toURLString']()]=_0x3c33a6,_0x3c33a6;}class Kd{constructor(_0x557038,_0x4bc780){this['_repoInternal']=_0x557038,this['app']=_0x4bc780,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0xed1d72){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0xed1d72+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x5619ec=Qr(),_0x5793b7){const _0x3720d1=Ui(_0x5619ec,'database')['getImmediate']({'identifier':_0x5793b7});if(!_0x3720d1['_instanceStarted']){const _0x991f45=ac('database');_0x991f45&&Yd(_0x3720d1,..._0x991f45);}return _0x3720d1;}function Yd(_0x120f99,_0x200929,_0xcb1c5b,_0x2370ce={}){_0x120f99=k(_0x120f99),_0x120f99['_checkNotDeleted']('useEmulator');const _0x4e87cc=_0x200929+':'+_0xcb1c5b,_0xa10228=_0x120f99['_repoInternal'];if(_0x120f99['_instanceStarted']){if(_0x4e87cc===_0x120f99['_repoInternal']['repoInfo_']['host']&&De(_0x2370ce,_0xa10228['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x42342a;if(_0xa10228['repoInfo_']['nodeAdmin'])_0x2370ce['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x42342a=new tn(tn['OWNER']);else{if(_0x2370ce['mockUserToken']){const _0x17baf8=typeof _0x2370ce['mockUserToken']=='string'?_0x2370ce['mockUserToken']:cc(_0x2370ce['mockUserToken'],_0x120f99['app']['options']['projectId']);_0x42342a=new tn(_0x17baf8);}}Wt(_0x200929)&&jr(_0x200929),Gd(_0xa10228,_0x4e87cc,_0x2370ce,_0x42342a);}function C_(_0x123801){_0x123801=k(_0x123801),_0x123801['_checkNotDeleted']('goOffline'),aa(_0x123801['_repo']);}function T_(_0x293fba){_0x293fba=k(_0x293fba),_0x293fba['_checkNotDeleted']('goOnline'),Sd(_0x293fba['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x5908c7){Ll(ct),et(new Me('database',(_0x30236e,{instanceIdentifier:_0x5f3aca})=>{const _0x10bdda=_0x30236e['getProvider']('app')['getImmediate'](),_0x58ccd7=_0x30236e['getProvider']('auth-internal'),_0x5c4ce1=_0x30236e['getProvider']('app-check-internal');return qd(_0x10bdda,_0x58ccd7,_0x5c4ce1,_0x5f3aca);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x5908c7),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x5d76ec,_0xcb5513){this['committed']=_0x5d76ec,this['snapshot']=_0xcb5513;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x5e6a9f,_0x15111e,_0x52ab68){if(_0x5e6a9f=k(_0x5e6a9f),gs('Reference.transaction',_0x5e6a9f['_path']),_0x5e6a9f['key']==='.length'||_0x5e6a9f['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5e6a9f['key']+'\x20is\x20a\x20read-only\x20object.';const _0x17e296=!0x0,_0x5b1e08=new Ve(),_0x5f50f5=(_0x2295ee,_0x331f18,_0xa49ec4)=>{let _0x4e2c9d=null;_0x2295ee?_0x5b1e08['reject'](_0x2295ee):(_0x4e2c9d=new rt(_0xa49ec4,new Z(_0x5e6a9f['_repo'],_0x5e6a9f['_path']),R),_0x5b1e08['resolve'](new Xd(_0x331f18,_0x4e2c9d)));},_0x378283=Fd(_0x5e6a9f,()=>{});return bd(_0x5e6a9f['_repo'],_0x5e6a9f['_path'],_0x15111e,_0x5f50f5,_0x378283,_0x17e296),_0x5b1e08['promise'];}ie['prototype']['simpleListen']=function(_0x5718df,_0xc02976){this['sendRequest']('q',{'p':_0x5718df},_0xc02976);},ie['prototype']['echo']=function(_0x4ce2b1,_0x111acc){this['sendRequest']('echo',{'d':_0x4ce2b1},_0x111acc);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x54c91a,..._0xb2708){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x54c91a,..._0xb2708);}function nn(_0x565564,..._0x272edf){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x565564,..._0x272edf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x21f94f,..._0x3268cc){throw Es(_0x21f94f,..._0x3268cc);}function J(_0x5d6c63,..._0x25d19a){return Es(_0x5d6c63,..._0x25d19a);}function ya(_0x8e4b11,_0x59a095,_0x2b0b1f){const _0x4642e2={...Zd(),[_0x59a095]:_0x2b0b1f};return new Ut('auth','Firebase',_0x4642e2)['create'](_0x59a095,{'appName':_0x8e4b11['name']});}function se(_0x46db06){return ya(_0x46db06,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0xb87af4,..._0x180c19){if(typeof _0xb87af4!='string'){const _0x45906e=_0x180c19[0x0],_0x249578=[..._0x180c19['slice'](0x1)];return _0x249578[0x0]&&(_0x249578[0x0]['appName']=_0xb87af4['name']),_0xb87af4['_errorFactory']['create'](_0x45906e,..._0x249578);}return ma['create'](_0xb87af4,..._0x180c19);}function m(_0x2b1ea2,_0x5bd6f8,..._0x4c0f55){if(!_0x2b1ea2)throw Es(_0x5bd6f8,..._0x4c0f55);}function te(_0x3c08d6){const _0x46023c='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3c08d6;throw nn(_0x46023c),new Error(_0x46023c);}function ae(_0xa93812,_0x3b1c04){_0xa93812||te(_0x3b1c04);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x54749e;return typeof self<'u'&&((_0x54749e=self['location'])==null?void 0x0:_0x54749e['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x19c2fa;return typeof self<'u'&&((_0x19c2fa=self['location'])==null?void 0x0:_0x19c2fa['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x532683=navigator;return _0x532683['languages']&&_0x532683['languages'][0x0]||_0x532683['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xde1219,_0x4a9178){this['shortDelay']=_0xde1219,this['longDelay']=_0x4a9178,ae(_0x4a9178>_0xde1219,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x3c6f51,_0x4137bc){ae(_0x3c6f51['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x43ff92}=_0x3c6f51['emulator'];return _0x4137bc?''+_0x43ff92+(_0x4137bc['startsWith']('/')?_0x4137bc['slice'](0x1):_0x4137bc):_0x43ff92;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1c95af,_0x3cc745,_0xf05dec){this['fetchImpl']=_0x1c95af,_0x3cc745&&(this['headersImpl']=_0x3cc745),_0xf05dec&&(this['responseImpl']=_0xf05dec);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x555c13,_0x5349a0){return _0x555c13['tenantId']&&!_0x5349a0['tenantId']?{..._0x5349a0,'tenantId':_0x555c13['tenantId']}:_0x5349a0;}async function Ae(_0x35557f,_0x4f1f2b,_0x5141d0,_0x1a0a62,_0x21c849={}){return Ea(_0x35557f,_0x21c849,async()=>{let _0x5044d7={},_0x2e493f={};_0x1a0a62&&(_0x4f1f2b==='GET'?_0x2e493f=_0x1a0a62:_0x5044d7={'body':JSON['stringify'](_0x1a0a62)});const _0x3d6da2=at({..._0x2e493f,'key':_0x35557f['config']['apiKey']})['slice'](0x1),_0x27657a=await _0x35557f['_getAdditionalHeaders']();_0x27657a['Content-Type']='application/json',_0x35557f['languageCode']&&(_0x27657a['X-Firebase-Locale']=_0x35557f['languageCode']);const _0x373fd3={'method':_0x4f1f2b,'headers':_0x27657a,..._0x5044d7};return lc()||(_0x373fd3['referrerPolicy']='strict-origin-when-cross-origin'),_0x35557f['emulatorConfig']&&Wt(_0x35557f['emulatorConfig']['host'])&&(_0x373fd3['credentials']='include'),va['fetch']()(await Ia(_0x35557f,_0x35557f['config']['apiHost'],_0x5141d0,_0x3d6da2),_0x373fd3);});}async function Ea(_0x3ffc3a,_0x26aed2,_0xb6eb33){_0x3ffc3a['_canInitEmulator']=!0x1;const _0x2f84aa={...rf,..._0x26aed2};try{const _0x46d461=new lf(_0x3ffc3a),_0x635f08=await Promise['race']([_0xb6eb33(),_0x46d461['promise']]);_0x46d461['clearNetworkTimeout']();const _0x5aac51=await _0x635f08['json']();if('needConfirmation'in _0x5aac51)throw en(_0x3ffc3a,'account-exists-with-different-credential',_0x5aac51);if(_0x635f08['ok']&&!('errorMessage'in _0x5aac51))return _0x5aac51;{const _0x361340=_0x635f08['ok']?_0x5aac51['errorMessage']:_0x5aac51['error']['message'],[_0x59ae19,_0x199b34]=_0x361340['split']('\x20:\x20');if(_0x59ae19==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x3ffc3a,'credential-already-in-use',_0x5aac51);if(_0x59ae19==='EMAIL_EXISTS')throw en(_0x3ffc3a,'email-already-in-use',_0x5aac51);if(_0x59ae19==='USER_DISABLED')throw en(_0x3ffc3a,'user-disabled',_0x5aac51);const _0x155101=_0x2f84aa[_0x59ae19]||_0x59ae19['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x199b34)throw ya(_0x3ffc3a,_0x155101,_0x199b34);K(_0x3ffc3a,_0x155101);}}catch(_0x2cf44a){if(_0x2cf44a instanceof Se)throw _0x2cf44a;K(_0x3ffc3a,'network-request-failed',{'message':String(_0x2cf44a)});}}async function Yt(_0x2c48df,_0x26a7af,_0x58ba3c,_0x3853de,_0xfe15b9={}){const _0xc41036=await Ae(_0x2c48df,_0x26a7af,_0x58ba3c,_0x3853de,_0xfe15b9);return'mfaPendingCredential'in _0xc41036&&K(_0x2c48df,'multi-factor-auth-required',{'_serverResponse':_0xc41036}),_0xc41036;}async function Ia(_0xde650d,_0x56d7eb,_0x52aa78,_0x134a71){const _0x66e9f2=''+_0x56d7eb+_0x52aa78+'?'+_0x134a71,_0x434d5c=_0xde650d,_0x1061d3=_0x434d5c['config']['emulator']?Is(_0xde650d['config'],_0x66e9f2):_0xde650d['config']['apiScheme']+'://'+_0x66e9f2;return of['includes'](_0x52aa78)&&(await _0x434d5c['_persistenceManagerAvailable'],_0x434d5c['_getPersistenceType']()==='COOKIE')?_0x434d5c['_getPersistence']()['_getFinalTarget'](_0x1061d3)['toString']():_0x1061d3;}function cf(_0x2b1dff){switch(_0x2b1dff){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x18eb70){this['auth']=_0x18eb70,this['timer']=null,this['promise']=new Promise((_0x556e0b,_0x2f3b64)=>{this['timer']=setTimeout(()=>_0x2f3b64(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x213acc,_0x49f741,_0x1f4e0a){const _0x2ffcf9={'appName':_0x213acc['name']};_0x1f4e0a['email']&&(_0x2ffcf9['email']=_0x1f4e0a['email']),_0x1f4e0a['phoneNumber']&&(_0x2ffcf9['phoneNumber']=_0x1f4e0a['phoneNumber']);const _0x510c41=J(_0x213acc,_0x49f741,_0x2ffcf9);return _0x510c41['customData']['_tokenResponse']=_0x1f4e0a,_0x510c41;}function vr(_0x3b6717){return _0x3b6717!==void 0x0&&_0x3b6717['enterprise']!==void 0x0;}class hf{constructor(_0x41cf0b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x41cf0b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x41cf0b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x41cf0b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1eae0b){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x586ef7 of this['recaptchaEnforcementState'])if(_0x586ef7['provider']&&_0x586ef7['provider']===_0x1eae0b)return cf(_0x586ef7['enforcementState']);return null;}['isProviderEnabled'](_0x15f6e3){return this['getProviderEnforcementState'](_0x15f6e3)==='ENFORCE'||this['getProviderEnforcementState'](_0x15f6e3)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x1016b2,_0x1bf982){return Ae(_0x1016b2,'GET','/v2/recaptchaConfig',Re(_0x1016b2,_0x1bf982));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0xd8a228,_0x1fa3ff){return Ae(_0xd8a228,'POST','/v1/accounts:delete',_0x1fa3ff);}async function Sn(_0x5a1899,_0x3c9245){return Ae(_0x5a1899,'POST','/v1/accounts:lookup',_0x3c9245);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x502c02){if(_0x502c02)try{const _0x4973a6=new Date(Number(_0x502c02));if(!isNaN(_0x4973a6['getTime']()))return _0x4973a6['toUTCString']();}catch{}}async function ff(_0x2f7eda,_0x4a8de5=!0x1){const _0x188d1f=k(_0x2f7eda),_0x5a6bfb=await _0x188d1f['getIdToken'](_0x4a8de5),_0x51c58f=ws(_0x5a6bfb);m(_0x51c58f&&_0x51c58f['exp']&&_0x51c58f['auth_time']&&_0x51c58f['iat'],_0x188d1f['auth'],'internal-error');const _0x43e81f=typeof _0x51c58f['firebase']=='object'?_0x51c58f['firebase']:void 0x0,_0xa6fce6=_0x43e81f==null?void 0x0:_0x43e81f['sign_in_provider'];return{'claims':_0x51c58f,'token':_0x5a6bfb,'authTime':St(ci(_0x51c58f['auth_time'])),'issuedAtTime':St(ci(_0x51c58f['iat'])),'expirationTime':St(ci(_0x51c58f['exp'])),'signInProvider':_0xa6fce6||null,'signInSecondFactor':(_0x43e81f==null?void 0x0:_0x43e81f['sign_in_second_factor'])||null};}function ci(_0x240abd){return Number(_0x240abd)*0x3e8;}function ws(_0x42558e){const [_0x226041,_0x98fe1d,_0x6f2ed6]=_0x42558e['split']('.');if(_0x226041===void 0x0||_0x98fe1d===void 0x0||_0x6f2ed6===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x15a8e0=cn(_0x98fe1d);return _0x15a8e0?JSON['parse'](_0x15a8e0):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xf66892){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xf66892==null?void 0x0:_0xf66892['toString']()),null;}}function Er(_0x2472b0){const _0x30ae58=ws(_0x2472b0);return m(_0x30ae58,'internal-error'),m(typeof _0x30ae58['exp']<'u','internal-error'),m(typeof _0x30ae58['iat']<'u','internal-error'),Number(_0x30ae58['exp'])-Number(_0x30ae58['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4489bf,_0x306b4a,_0x216398=!0x1){if(_0x216398)return _0x306b4a;try{return await _0x306b4a;}catch(_0x42d28c){throw _0x42d28c instanceof Se&&pf(_0x42d28c)&&_0x4489bf['auth']['currentUser']===_0x4489bf&&await _0x4489bf['auth']['signOut'](),_0x42d28c;}}function pf({code:_0x4776a0}){return _0x4776a0==='auth/user-disabled'||_0x4776a0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x332b0a){this['user']=_0x332b0a,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x344b1a){if(_0x344b1a){const _0x2c7512=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2c7512;}else{this['errorBackoff']=0x7530;const _0x5baef2=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5baef2);}}['schedule'](_0x53df12=!0x1){if(!this['isRunning'])return;const _0x1c7e03=this['getInterval'](_0x53df12);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1c7e03);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x37e427){(_0x37e427==null?void 0x0:_0x37e427['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x23e34e,_0x2cc9c2){this['createdAt']=_0x23e34e,this['lastLoginAt']=_0x2cc9c2,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x1e7350){this['createdAt']=_0x1e7350['createdAt'],this['lastLoginAt']=_0x1e7350['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0xa96a93){var _0x13a785;const _0x3deb30=_0xa96a93['auth'],_0x519f94=await _0xa96a93['getIdToken'](),_0x5ebf57=await xt(_0xa96a93,Sn(_0x3deb30,{'idToken':_0x519f94}));m(_0x5ebf57==null?void 0x0:_0x5ebf57['users']['length'],_0x3deb30,'internal-error');const _0x4d49c4=_0x5ebf57['users'][0x0];_0xa96a93['_notifyReloadListener'](_0x4d49c4);const _0x18694f=(_0x13a785=_0x4d49c4['providerUserInfo'])!=null&&_0x13a785['length']?wa(_0x4d49c4['providerUserInfo']):[],_0x71e2f1=mf(_0xa96a93['providerData'],_0x18694f),_0x4470e6=_0xa96a93['isAnonymous'],_0x4e2906=!(_0xa96a93['email']&&_0x4d49c4['passwordHash'])&&!(_0x71e2f1!=null&&_0x71e2f1['length']),_0x451852=_0x4470e6?_0x4e2906:!0x1,_0x36edf6={'uid':_0x4d49c4['localId'],'displayName':_0x4d49c4['displayName']||null,'photoURL':_0x4d49c4['photoUrl']||null,'email':_0x4d49c4['email']||null,'emailVerified':_0x4d49c4['emailVerified']||!0x1,'phoneNumber':_0x4d49c4['phoneNumber']||null,'tenantId':_0x4d49c4['tenantId']||null,'providerData':_0x71e2f1,'metadata':new Pi(_0x4d49c4['createdAt'],_0x4d49c4['lastLoginAt']),'isAnonymous':_0x451852};Object['assign'](_0xa96a93,_0x36edf6);}async function gf(_0x28d6f8){const _0x1be9ad=k(_0x28d6f8);await bn(_0x1be9ad),await _0x1be9ad['auth']['_persistUserIfCurrent'](_0x1be9ad),_0x1be9ad['auth']['_notifyListenersIfCurrent'](_0x1be9ad);}function mf(_0x25a0ca,_0x436cd5){return[..._0x25a0ca['filter'](_0x2ecb09=>!_0x436cd5['some'](_0x7b8c31=>_0x7b8c31['providerId']===_0x2ecb09['providerId'])),..._0x436cd5];}function wa(_0x1b7014){return _0x1b7014['map'](({providerId:_0x51a0d8,..._0x374e9e})=>({'providerId':_0x51a0d8,'uid':_0x374e9e['rawId']||'','displayName':_0x374e9e['displayName']||null,'email':_0x374e9e['email']||null,'phoneNumber':_0x374e9e['phoneNumber']||null,'photoURL':_0x374e9e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x58527c,_0x1caeb6){const _0x48f3d0=await Ea(_0x58527c,{},async()=>{const _0x3aa323=at({'grant_type':'refresh_token','refresh_token':_0x1caeb6})['slice'](0x1),{tokenApiHost:_0x23862d,apiKey:_0x567a46}=_0x58527c['config'],_0x294c6c=await Ia(_0x58527c,_0x23862d,'/v1/token','key='+_0x567a46),_0x56bc24=await _0x58527c['_getAdditionalHeaders']();_0x56bc24['Content-Type']='application/x-www-form-urlencoded';const _0x431f2b={'method':'POST','headers':_0x56bc24,'body':_0x3aa323};return _0x58527c['emulatorConfig']&&Wt(_0x58527c['emulatorConfig']['host'])&&(_0x431f2b['credentials']='include'),va['fetch']()(_0x294c6c,_0x431f2b);});return{'accessToken':_0x48f3d0['access_token'],'expiresIn':_0x48f3d0['expires_in'],'refreshToken':_0x48f3d0['refresh_token']};}async function vf(_0x1b1201,_0x2a4330){return Ae(_0x1b1201,'POST','/v2/accounts:revokeToken',Re(_0x1b1201,_0x2a4330));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x113646){m(_0x113646['idToken'],'internal-error'),m(typeof _0x113646['idToken']<'u','internal-error'),m(typeof _0x113646['refreshToken']<'u','internal-error');const _0x35fb08='expiresIn'in _0x113646&&typeof _0x113646['expiresIn']<'u'?Number(_0x113646['expiresIn']):Er(_0x113646['idToken']);this['updateTokensAndExpiration'](_0x113646['idToken'],_0x113646['refreshToken'],_0x35fb08);}['updateFromIdToken'](_0x215be8){m(_0x215be8['length']!==0x0,'internal-error');const _0x5504ce=Er(_0x215be8);this['updateTokensAndExpiration'](_0x215be8,null,_0x5504ce);}async['getToken'](_0x2fde2c,_0x469558=!0x1){return!_0x469558&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2fde2c,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2fde2c,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x43f97b,_0x3ffce0){const {accessToken:_0x2c0340,refreshToken:_0x3646e1,expiresIn:_0x1400dd}=await yf(_0x43f97b,_0x3ffce0);this['updateTokensAndExpiration'](_0x2c0340,_0x3646e1,Number(_0x1400dd));}['updateTokensAndExpiration'](_0x406498,_0x364e5e,_0x44173e){this['refreshToken']=_0x364e5e||null,this['accessToken']=_0x406498||null,this['expirationTime']=Date['now']()+_0x44173e*0x3e8;}static['fromJSON'](_0x352be2,_0x2f2965){const {refreshToken:_0x2abeb9,accessToken:_0xe44c8,expirationTime:_0x33b957}=_0x2f2965,_0x2a16f1=new Je();return _0x2abeb9&&(m(typeof _0x2abeb9=='string','internal-error',{'appName':_0x352be2}),_0x2a16f1['refreshToken']=_0x2abeb9),_0xe44c8&&(m(typeof _0xe44c8=='string','internal-error',{'appName':_0x352be2}),_0x2a16f1['accessToken']=_0xe44c8),_0x33b957&&(m(typeof _0x33b957=='number','internal-error',{'appName':_0x352be2}),_0x2a16f1['expirationTime']=_0x33b957),_0x2a16f1;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3380ca){this['accessToken']=_0x3380ca['accessToken'],this['refreshToken']=_0x3380ca['refreshToken'],this['expirationTime']=_0x3380ca['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x204858,_0x2741b1){m(typeof _0x204858=='string'||typeof _0x204858>'u','internal-error',{'appName':_0x2741b1});}class z{constructor({uid:_0x48b6ac,auth:_0x1e3be3,stsTokenManager:_0xa6face,..._0x186be8}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x48b6ac,this['auth']=_0x1e3be3,this['stsTokenManager']=_0xa6face,this['accessToken']=_0xa6face['accessToken'],this['displayName']=_0x186be8['displayName']||null,this['email']=_0x186be8['email']||null,this['emailVerified']=_0x186be8['emailVerified']||!0x1,this['phoneNumber']=_0x186be8['phoneNumber']||null,this['photoURL']=_0x186be8['photoURL']||null,this['isAnonymous']=_0x186be8['isAnonymous']||!0x1,this['tenantId']=_0x186be8['tenantId']||null,this['providerData']=_0x186be8['providerData']?[..._0x186be8['providerData']]:[],this['metadata']=new Pi(_0x186be8['createdAt']||void 0x0,_0x186be8['lastLoginAt']||void 0x0);}async['getIdToken'](_0xc15c40){const _0x5221a5=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0xc15c40));return m(_0x5221a5,this['auth'],'internal-error'),this['accessToken']!==_0x5221a5&&(this['accessToken']=_0x5221a5,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5221a5;}['getIdTokenResult'](_0x5f1db9){return ff(this,_0x5f1db9);}['reload'](){return gf(this);}['_assign'](_0x25f1b1){this!==_0x25f1b1&&(m(this['uid']===_0x25f1b1['uid'],this['auth'],'internal-error'),this['displayName']=_0x25f1b1['displayName'],this['photoURL']=_0x25f1b1['photoURL'],this['email']=_0x25f1b1['email'],this['emailVerified']=_0x25f1b1['emailVerified'],this['phoneNumber']=_0x25f1b1['phoneNumber'],this['isAnonymous']=_0x25f1b1['isAnonymous'],this['tenantId']=_0x25f1b1['tenantId'],this['providerData']=_0x25f1b1['providerData']['map'](_0xdb7c3=>({..._0xdb7c3})),this['metadata']['_copy'](_0x25f1b1['metadata']),this['stsTokenManager']['_assign'](_0x25f1b1['stsTokenManager']));}['_clone'](_0x1b811d){const _0x3975f3=new z({...this,'auth':_0x1b811d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3975f3['metadata']['_copy'](this['metadata']),_0x3975f3;}['_onReload'](_0x5c573a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5c573a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4a9ca3){this['reloadListener']?this['reloadListener'](_0x4a9ca3):this['reloadUserInfo']=_0x4a9ca3;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4f1d13,_0x50fbd2=!0x1){let _0x1b7dda=!0x1;_0x4f1d13['idToken']&&_0x4f1d13['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4f1d13),_0x1b7dda=!0x0),_0x50fbd2&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1b7dda&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x19f756=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x19f756})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x44f948=>({..._0x44f948})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0xfdfc71,_0x3d5688){const _0x457739=_0x3d5688['displayName']??void 0x0,_0xac4865=_0x3d5688['email']??void 0x0,_0x5a48ba=_0x3d5688['phoneNumber']??void 0x0,_0x59eede=_0x3d5688['photoURL']??void 0x0,_0x26bf80=_0x3d5688['tenantId']??void 0x0,_0x15bb7c=_0x3d5688['_redirectEventId']??void 0x0,_0x4a31c8=_0x3d5688['createdAt']??void 0x0,_0xed3765=_0x3d5688['lastLoginAt']??void 0x0,{uid:_0x4576a1,emailVerified:_0x2040c9,isAnonymous:_0x5660d6,providerData:_0x31bc99,stsTokenManager:_0x12ba3a}=_0x3d5688;m(_0x4576a1&&_0x12ba3a,_0xfdfc71,'internal-error');const _0xecf5e3=Je['fromJSON'](this['name'],_0x12ba3a);m(typeof _0x4576a1=='string',_0xfdfc71,'internal-error'),ce(_0x457739,_0xfdfc71['name']),ce(_0xac4865,_0xfdfc71['name']),m(typeof _0x2040c9=='boolean',_0xfdfc71,'internal-error'),m(typeof _0x5660d6=='boolean',_0xfdfc71,'internal-error'),ce(_0x5a48ba,_0xfdfc71['name']),ce(_0x59eede,_0xfdfc71['name']),ce(_0x26bf80,_0xfdfc71['name']),ce(_0x15bb7c,_0xfdfc71['name']),ce(_0x4a31c8,_0xfdfc71['name']),ce(_0xed3765,_0xfdfc71['name']);const _0x4f4f06=new z({'uid':_0x4576a1,'auth':_0xfdfc71,'email':_0xac4865,'emailVerified':_0x2040c9,'displayName':_0x457739,'isAnonymous':_0x5660d6,'photoURL':_0x59eede,'phoneNumber':_0x5a48ba,'tenantId':_0x26bf80,'stsTokenManager':_0xecf5e3,'createdAt':_0x4a31c8,'lastLoginAt':_0xed3765});return _0x31bc99&&Array['isArray'](_0x31bc99)&&(_0x4f4f06['providerData']=_0x31bc99['map'](_0x5aab9c=>({..._0x5aab9c}))),_0x15bb7c&&(_0x4f4f06['_redirectEventId']=_0x15bb7c),_0x4f4f06;}static async['_fromIdTokenResponse'](_0x1137ac,_0xc32acd,_0x7d147e=!0x1){const _0x5daec0=new Je();_0x5daec0['updateFromServerResponse'](_0xc32acd);const _0x384508=new z({'uid':_0xc32acd['localId'],'auth':_0x1137ac,'stsTokenManager':_0x5daec0,'isAnonymous':_0x7d147e});return await bn(_0x384508),_0x384508;}static async['_fromGetAccountInfoResponse'](_0x5ae8a0,_0x3cc818,_0x441296){const _0x574c3a=_0x3cc818['users'][0x0];m(_0x574c3a['localId']!==void 0x0,'internal-error');const _0x144e40=_0x574c3a['providerUserInfo']!==void 0x0?wa(_0x574c3a['providerUserInfo']):[],_0x280f24=!(_0x574c3a['email']&&_0x574c3a['passwordHash'])&&!(_0x144e40!=null&&_0x144e40['length']),_0x16ed06=new Je();_0x16ed06['updateFromIdToken'](_0x441296);const _0x471885=new z({'uid':_0x574c3a['localId'],'auth':_0x5ae8a0,'stsTokenManager':_0x16ed06,'isAnonymous':_0x280f24}),_0x3cb31e={'uid':_0x574c3a['localId'],'displayName':_0x574c3a['displayName']||null,'photoURL':_0x574c3a['photoUrl']||null,'email':_0x574c3a['email']||null,'emailVerified':_0x574c3a['emailVerified']||!0x1,'phoneNumber':_0x574c3a['phoneNumber']||null,'tenantId':_0x574c3a['tenantId']||null,'providerData':_0x144e40,'metadata':new Pi(_0x574c3a['createdAt'],_0x574c3a['lastLoginAt']),'isAnonymous':!(_0x574c3a['email']&&_0x574c3a['passwordHash'])&&!(_0x144e40!=null&&_0x144e40['length'])};return Object['assign'](_0x471885,_0x3cb31e),_0x471885;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x5d5993){ae(_0x5d5993 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x88168f=Ir['get'](_0x5d5993);return _0x88168f?(ae(_0x88168f instanceof _0x5d5993,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x88168f):(_0x88168f=new _0x5d5993(),Ir['set'](_0x5d5993,_0x88168f),_0x88168f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x51c634,_0x48f078){this['storage'][_0x51c634]=_0x48f078;}async['_get'](_0x5ea27f){const _0x50dc28=this['storage'][_0x5ea27f];return _0x50dc28===void 0x0?null:_0x50dc28;}async['_remove'](_0x410ae9){delete this['storage'][_0x410ae9];}['_addListener'](_0x4697f8,_0x4b5fc1){}['_removeListener'](_0x5e2777,_0x50931b){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x26f807,_0x574ce4,_0x1a3a5a){return'firebase:'+_0x26f807+':'+_0x574ce4+':'+_0x1a3a5a;}class Xe{constructor(_0x1cc68a,_0x3c1077,_0x1c4096){this['persistence']=_0x1cc68a,this['auth']=_0x3c1077,this['userKey']=_0x1c4096;const {config:_0x4fe928,name:_0x4930bb}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x4fe928['apiKey'],_0x4930bb),this['fullPersistenceKey']=sn('persistence',_0x4fe928['apiKey'],_0x4930bb),this['boundEventHandler']=_0x3c1077['_onStorageEvent']['bind'](_0x3c1077),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x254d81){return this['persistence']['_set'](this['fullUserKey'],_0x254d81['toJSON']());}async['getCurrentUser'](){const _0x1267eb=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1267eb)return null;if(typeof _0x1267eb=='string'){const _0x28632a=await Sn(this['auth'],{'idToken':_0x1267eb})['catch'](()=>{});return _0x28632a?z['_fromGetAccountInfoResponse'](this['auth'],_0x28632a,_0x1267eb):null;}return z['_fromJSON'](this['auth'],_0x1267eb);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x25277e){if(this['persistence']===_0x25277e)return;const _0x1600bf=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x25277e,_0x1600bf)return this['setCurrentUser'](_0x1600bf);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x18ccca,_0x9d56f7,_0x4d0660='authUser'){if(!_0x9d56f7['length'])return new Xe(ne(wr),_0x18ccca,_0x4d0660);const _0x10fa8a=(await Promise['all'](_0x9d56f7['map'](async _0x5bef9d=>{if(await _0x5bef9d['_isAvailable']())return _0x5bef9d;})))['filter'](_0xd68f86=>_0xd68f86);let _0x586a77=_0x10fa8a[0x0]||ne(wr);const _0x69d6fb=sn(_0x4d0660,_0x18ccca['config']['apiKey'],_0x18ccca['name']);let _0x128a75=null;for(const _0x51aace of _0x9d56f7)try{const _0x38d11a=await _0x51aace['_get'](_0x69d6fb);if(_0x38d11a){let _0x3017d2;if(typeof _0x38d11a=='string'){const _0x497926=await Sn(_0x18ccca,{'idToken':_0x38d11a})['catch'](()=>{});if(!_0x497926)break;_0x3017d2=await z['_fromGetAccountInfoResponse'](_0x18ccca,_0x497926,_0x38d11a);}else _0x3017d2=z['_fromJSON'](_0x18ccca,_0x38d11a);_0x51aace!==_0x586a77&&(_0x128a75=_0x3017d2),_0x586a77=_0x51aace;break;}}catch{}const _0x26c7fd=_0x10fa8a['filter'](_0x30626e=>_0x30626e['_shouldAllowMigration']);return!_0x586a77['_shouldAllowMigration']||!_0x26c7fd['length']?new Xe(_0x586a77,_0x18ccca,_0x4d0660):(_0x586a77=_0x26c7fd[0x0],_0x128a75&&await _0x586a77['_set'](_0x69d6fb,_0x128a75['toJSON']()),await Promise['all'](_0x9d56f7['map'](async _0x3100a2=>{if(_0x3100a2!==_0x586a77)try{await _0x3100a2['_remove'](_0x69d6fb);}catch{}})),new Xe(_0x586a77,_0x18ccca,_0x4d0660));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3acb0b){const _0x33295b=_0x3acb0b['toLowerCase']();if(_0x33295b['includes']('opera/')||_0x33295b['includes']('opr/')||_0x33295b['includes']('opios/'))return'Opera';if(Ra(_0x33295b))return'IEMobile';if(_0x33295b['includes']('msie')||_0x33295b['includes']('trident/'))return'IE';if(_0x33295b['includes']('edge/'))return'Edge';if(Ta(_0x33295b))return'Firefox';if(_0x33295b['includes']('silk/'))return'Silk';if(ka(_0x33295b))return'Blackberry';if(Na(_0x33295b))return'Webos';if(Sa(_0x33295b))return'Safari';if((_0x33295b['includes']('chrome/')||ba(_0x33295b))&&!_0x33295b['includes']('edge/'))return'Chrome';if(Aa(_0x33295b))return'Android';{const _0x4f459d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4f6c58=_0x3acb0b['match'](_0x4f459d);if((_0x4f6c58==null?void 0x0:_0x4f6c58['length'])===0x2)return _0x4f6c58[0x1];}return'Other';}function Ta(_0x31a403=W()){return/firefox\//i['test'](_0x31a403);}function Sa(_0x597059=W()){const _0x458da9=_0x597059['toLowerCase']();return _0x458da9['includes']('safari/')&&!_0x458da9['includes']('chrome/')&&!_0x458da9['includes']('crios/')&&!_0x458da9['includes']('android');}function ba(_0x2b08c0=W()){return/crios\//i['test'](_0x2b08c0);}function Ra(_0x18b104=W()){return/iemobile/i['test'](_0x18b104);}function Aa(_0x5b4478=W()){return/android/i['test'](_0x5b4478);}function ka(_0x4a7c5c=W()){return/blackberry/i['test'](_0x4a7c5c);}function Na(_0x2fc7da=W()){return/webos/i['test'](_0x2fc7da);}function Cs(_0x2b4a96=W()){return/iphone|ipad|ipod/i['test'](_0x2b4a96)||/macintosh/i['test'](_0x2b4a96)&&/mobile/i['test'](_0x2b4a96);}function Ef(_0x3b638e=W()){var _0x455d76;return Cs(_0x3b638e)&&!!((_0x455d76=window['navigator'])!=null&&_0x455d76['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x15a8de=W()){return Cs(_0x15a8de)||Aa(_0x15a8de)||Na(_0x15a8de)||ka(_0x15a8de)||/windows phone/i['test'](_0x15a8de)||Ra(_0x15a8de);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x261ffe,_0x57ab23=[]){let _0x8cc013;switch(_0x261ffe){case'Browser':_0x8cc013=Cr(W());break;case'Worker':_0x8cc013=Cr(W())+'-'+_0x261ffe;break;default:_0x8cc013=_0x261ffe;}const _0xbb3bbd=_0x57ab23['length']?_0x57ab23['join'](','):'FirebaseCore-web';return _0x8cc013+'/JsCore/'+ct+'/'+_0xbb3bbd;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3297cd){this['auth']=_0x3297cd,this['queue']=[];}['pushCallback'](_0x596dce,_0x2dee3a){const _0x497b1f=_0x33eb1a=>new Promise((_0x2dc8b1,_0x17f318)=>{try{const _0x628604=_0x596dce(_0x33eb1a);_0x2dc8b1(_0x628604);}catch(_0x1be0a1){_0x17f318(_0x1be0a1);}});_0x497b1f['onAbort']=_0x2dee3a,this['queue']['push'](_0x497b1f);const _0x1a1d1b=this['queue']['length']-0x1;return()=>{this['queue'][_0x1a1d1b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x7cb841){if(this['auth']['currentUser']===_0x7cb841)return;const _0x2e29ae=[];try{for(const _0x476bfe of this['queue'])await _0x476bfe(_0x7cb841),_0x476bfe['onAbort']&&_0x2e29ae['push'](_0x476bfe['onAbort']);}catch(_0x5c4b33){_0x2e29ae['reverse']();for(const _0x5bb47b of _0x2e29ae)try{_0x5bb47b();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5c4b33==null?void 0x0:_0x5c4b33['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4eb14f,_0x14c6d2={}){return Ae(_0x4eb14f,'GET','/v2/passwordPolicy',Re(_0x4eb14f,_0x14c6d2));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x8904a2){var _0x1532be;const _0x25bffe=_0x8904a2['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x25bffe['minPasswordLength']??Tf,_0x25bffe['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x25bffe['maxPasswordLength']),_0x25bffe['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x25bffe['containsLowercaseCharacter']),_0x25bffe['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x25bffe['containsUppercaseCharacter']),_0x25bffe['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x25bffe['containsNumericCharacter']),_0x25bffe['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x25bffe['containsNonAlphanumericCharacter']),this['enforcementState']=_0x8904a2['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1532be=_0x8904a2['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1532be['join'](''))??'',this['forceUpgradeOnSignin']=_0x8904a2['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x8904a2['schemaVersion'];}['validatePassword'](_0x5dacd9){const _0x2fb71f={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5dacd9,_0x2fb71f),this['validatePasswordCharacterOptions'](_0x5dacd9,_0x2fb71f),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['meetsMinPasswordLength']??!0x0),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['meetsMaxPasswordLength']??!0x0),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['containsLowercaseLetter']??!0x0),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['containsUppercaseLetter']??!0x0),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['containsNumericCharacter']??!0x0),_0x2fb71f['isValid']&&(_0x2fb71f['isValid']=_0x2fb71f['containsNonAlphanumericCharacter']??!0x0),_0x2fb71f;}['validatePasswordLengthOptions'](_0x106c56,_0x4c7988){const _0x5f03f6=this['customStrengthOptions']['minPasswordLength'],_0x59cf83=this['customStrengthOptions']['maxPasswordLength'];_0x5f03f6&&(_0x4c7988['meetsMinPasswordLength']=_0x106c56['length']>=_0x5f03f6),_0x59cf83&&(_0x4c7988['meetsMaxPasswordLength']=_0x106c56['length']<=_0x59cf83);}['validatePasswordCharacterOptions'](_0x4dfd6a,_0x401d94){this['updatePasswordCharacterOptionsStatuses'](_0x401d94,!0x1,!0x1,!0x1,!0x1);let _0x3637d4;for(let _0xcc94b9=0x0;_0xcc94b9<_0x4dfd6a['length'];_0xcc94b9++)_0x3637d4=_0x4dfd6a['charAt'](_0xcc94b9),this['updatePasswordCharacterOptionsStatuses'](_0x401d94,_0x3637d4>='a'&&_0x3637d4<='z',_0x3637d4>='A'&&_0x3637d4<='Z',_0x3637d4>='0'&&_0x3637d4<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3637d4));}['updatePasswordCharacterOptionsStatuses'](_0x3c8409,_0x476899,_0x1b68df,_0x23fb04,_0x484543){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x3c8409['containsLowercaseLetter']||(_0x3c8409['containsLowercaseLetter']=_0x476899)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x3c8409['containsUppercaseLetter']||(_0x3c8409['containsUppercaseLetter']=_0x1b68df)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x3c8409['containsNumericCharacter']||(_0x3c8409['containsNumericCharacter']=_0x23fb04)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x3c8409['containsNonAlphanumericCharacter']||(_0x3c8409['containsNonAlphanumericCharacter']=_0x484543));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x23443f,_0x40d726,_0x48ab3a,_0x501135){this['app']=_0x23443f,this['heartbeatServiceProvider']=_0x40d726,this['appCheckServiceProvider']=_0x48ab3a,this['config']=_0x501135,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x23443f['name'],this['clientVersion']=_0x501135['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5e8c36=>this['_resolvePersistenceManagerAvailable']=_0x5e8c36);}['_initializeWithPersistence'](_0x830c0d,_0x33bb1a){return _0x33bb1a&&(this['_popupRedirectResolver']=ne(_0x33bb1a)),this['_initializationPromise']=this['queue'](async()=>{var _0x4c6a54,_0x2cd802,_0x22bd8b;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x830c0d),(_0x4c6a54=this['_resolvePersistenceManagerAvailable'])==null||_0x4c6a54['call'](this),!this['_deleted'])){if((_0x2cd802=this['_popupRedirectResolver'])!=null&&_0x2cd802['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x33bb1a),this['lastNotifiedUid']=((_0x22bd8b=this['currentUser'])==null?void 0x0:_0x22bd8b['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2e7cce=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2e7cce)){if(this['currentUser']&&_0x2e7cce&&this['currentUser']['uid']===_0x2e7cce['uid']){this['_currentUser']['_assign'](_0x2e7cce),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2e7cce,!0x0);}}async['initializeCurrentUserFromIdToken'](_0xd99a85){try{const _0x42d609=await Sn(this,{'idToken':_0xd99a85}),_0x56c6d4=await z['_fromGetAccountInfoResponse'](this,_0x42d609,_0xd99a85);await this['directlySetCurrentUser'](_0x56c6d4);}catch(_0x47de20){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x47de20),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5c806b){var _0x18c958;if(H(this['app'])){const _0x71d347=this['app']['settings']['authIdToken'];return _0x71d347?new Promise(_0x29f3f1=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x71d347)['then'](_0x29f3f1,_0x29f3f1));}):this['directlySetCurrentUser'](null);}const _0x4931a9=await this['assertedPersistence']['getCurrentUser']();let _0x59ef4e=_0x4931a9,_0x2fe74f=!0x1;if(_0x5c806b&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x8db522=(_0x18c958=this['redirectUser'])==null?void 0x0:_0x18c958['_redirectEventId'],_0x13136c=_0x59ef4e==null?void 0x0:_0x59ef4e['_redirectEventId'],_0x3ab5cc=await this['tryRedirectSignIn'](_0x5c806b);(!_0x8db522||_0x8db522===_0x13136c)&&(_0x3ab5cc!=null&&_0x3ab5cc['user'])&&(_0x59ef4e=_0x3ab5cc['user'],_0x2fe74f=!0x0);}if(!_0x59ef4e)return this['directlySetCurrentUser'](null);if(!_0x59ef4e['_redirectEventId']){if(_0x2fe74f)try{await this['beforeStateQueue']['runMiddleware'](_0x59ef4e);}catch(_0x2d11e4){_0x59ef4e=_0x4931a9,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2d11e4));}return _0x59ef4e?this['reloadAndSetCurrentUserOrClear'](_0x59ef4e):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x59ef4e['_redirectEventId']?this['directlySetCurrentUser'](_0x59ef4e):this['reloadAndSetCurrentUserOrClear'](_0x59ef4e);}async['tryRedirectSignIn'](_0x108a3b){let _0x435dd3=null;try{_0x435dd3=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x108a3b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x435dd3;}async['reloadAndSetCurrentUserOrClear'](_0x2f12bf){try{await bn(_0x2f12bf);}catch(_0x58db10){if((_0x58db10==null?void 0x0:_0x58db10['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2f12bf);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x36c172){if(H(this['app']))return Promise['reject'](se(this));const _0x5da9ff=_0x36c172?k(_0x36c172):null;return _0x5da9ff&&m(_0x5da9ff['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5da9ff&&_0x5da9ff['_clone'](this));}async['_updateCurrentUser'](_0x2636e6,_0x53a05b=!0x1){if(!this['_deleted'])return _0x2636e6&&m(this['tenantId']===_0x2636e6['tenantId'],this,'tenant-id-mismatch'),_0x53a05b||await this['beforeStateQueue']['runMiddleware'](_0x2636e6),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2636e6),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4f2ff3){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x4f2ff3));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x178ffe){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x25f21d=this['_getPasswordPolicyInternal']();return _0x25f21d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x25f21d['validatePassword'](_0x178ffe);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x21d7af=await Cf(this),_0x5182a4=new Sf(_0x21d7af);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5182a4:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5182a4;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2b9f01){this['_errorFactory']=new Ut('auth','Firebase',_0x2b9f01());}['onAuthStateChanged'](_0x4f25a7,_0x5b226c,_0x475b5f){return this['registerStateListener'](this['authStateSubscription'],_0x4f25a7,_0x5b226c,_0x475b5f);}['beforeAuthStateChanged'](_0x26fa35,_0x28db9e){return this['beforeStateQueue']['pushCallback'](_0x26fa35,_0x28db9e);}['onIdTokenChanged'](_0x4125bc,_0x1044fc,_0x700112){return this['registerStateListener'](this['idTokenSubscription'],_0x4125bc,_0x1044fc,_0x700112);}['authStateReady'](){return new Promise((_0x4b87e7,_0x3f3a48)=>{if(this['currentUser'])_0x4b87e7();else{const _0x4bf6e9=this['onAuthStateChanged'](()=>{_0x4bf6e9(),_0x4b87e7();},_0x3f3a48);}});}async['revokeAccessToken'](_0x239eea){if(this['currentUser']){const _0x4615b1=await this['currentUser']['getIdToken'](),_0x3345a3={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x239eea,'idToken':_0x4615b1};this['tenantId']!=null&&(_0x3345a3['tenantId']=this['tenantId']),await vf(this,_0x3345a3);}}['toJSON'](){var _0x3b2e93;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3b2e93=this['_currentUser'])==null?void 0x0:_0x3b2e93['toJSON']()};}async['_setRedirectUser'](_0x4d6680,_0x235d87){const _0x45d96c=await this['getOrInitRedirectPersistenceManager'](_0x235d87);return _0x4d6680===null?_0x45d96c['removeCurrentUser']():_0x45d96c['setCurrentUser'](_0x4d6680);}async['getOrInitRedirectPersistenceManager'](_0x4f4ddc){if(!this['redirectPersistenceManager']){const _0x35a899=_0x4f4ddc&&ne(_0x4f4ddc)||this['_popupRedirectResolver'];m(_0x35a899,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x35a899['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1877ff){var _0x57d06d,_0x111e75;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x57d06d=this['_currentUser'])==null?void 0x0:_0x57d06d['_redirectEventId'])===_0x1877ff?this['_currentUser']:((_0x111e75=this['redirectUser'])==null?void 0x0:_0x111e75['_redirectEventId'])===_0x1877ff?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3ba828){if(_0x3ba828===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3ba828));}['_notifyListenersIfCurrent'](_0x2057f2){_0x2057f2===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2e1aa6;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4d437b=((_0x2e1aa6=this['currentUser'])==null?void 0x0:_0x2e1aa6['uid'])??null;this['lastNotifiedUid']!==_0x4d437b&&(this['lastNotifiedUid']=_0x4d437b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3407ef,_0xbf550e,_0x47d594,_0x11ae53){if(this['_deleted'])return()=>{};const _0x22414e=typeof _0xbf550e=='function'?_0xbf550e:_0xbf550e['next']['bind'](_0xbf550e);let _0x34d244=!0x1;const _0x35402d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x35402d,this,'internal-error'),_0x35402d['then'](()=>{_0x34d244||_0x22414e(this['currentUser']);}),typeof _0xbf550e=='function'){const _0x2b89bb=_0x3407ef['addObserver'](_0xbf550e,_0x47d594,_0x11ae53);return()=>{_0x34d244=!0x0,_0x2b89bb();};}else{const _0x51428a=_0x3407ef['addObserver'](_0xbf550e);return()=>{_0x34d244=!0x0,_0x51428a();};}}async['directlySetCurrentUser'](_0x56e720){this['currentUser']&&this['currentUser']!==_0x56e720&&this['_currentUser']['_stopProactiveRefresh'](),_0x56e720&&this['isProactiveRefreshEnabled']&&_0x56e720['_startProactiveRefresh'](),this['currentUser']=_0x56e720,_0x56e720?await this['assertedPersistence']['setCurrentUser'](_0x56e720):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xf1132b){return this['operations']=this['operations']['then'](_0xf1132b,_0xf1132b),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4997d2){!_0x4997d2||this['frameworks']['includes'](_0x4997d2)||(this['frameworks']['push'](_0x4997d2),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5a4b53;const _0x16dd44={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x16dd44['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x53c26e=await((_0x5a4b53=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a4b53['getHeartbeatsHeader']());_0x53c26e&&(_0x16dd44['X-Firebase-Client']=_0x53c26e);const _0xe9c22e=await this['_getAppCheckToken']();return _0xe9c22e&&(_0x16dd44['X-Firebase-AppCheck']=_0xe9c22e),_0x16dd44;}async['_getAppCheckToken'](){var _0x1fea3f;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x427dbd=await((_0x1fea3f=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1fea3f['getToken']());return _0x427dbd!=null&&_0x427dbd['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x427dbd['error']),_0x427dbd==null?void 0x0:_0x427dbd['token'];}}function qe(_0x584047){return k(_0x584047);}class Tr{constructor(_0x4c1c44){this['auth']=_0x4c1c44,this['observer']=null,this['addObserver']=Ic(_0x1c1e79=>this['observer']=_0x1c1e79);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2ecc21){zn=_0x2ecc21;}function Da(_0x164d6e){return zn['loadJS'](_0x164d6e);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x394bbf){return'__'+_0x394bbf+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x190007){_0x190007();}['execute'](_0x2c3cc6,_0x1ed8ad){return Promise['resolve']('token');}['render'](_0xf4331f,_0x17760e){return'';}}class Of{['ready'](_0x44585a){_0x44585a();}['execute'](_0xfbb522,_0x396c9c){return Promise['resolve']('token');}['render'](_0x10afc7,_0x56c829){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4c6398){this['type']=Df,this['auth']=qe(_0x4c6398);}async['verify'](_0x2fff2d='verify',_0x552d43=!0x1){async function _0x1f7c8e(_0x4fe0d7){if(!_0x552d43){if(_0x4fe0d7['tenantId']==null&&_0x4fe0d7['_agentRecaptchaConfig']!=null)return _0x4fe0d7['_agentRecaptchaConfig']['siteKey'];if(_0x4fe0d7['tenantId']!=null&&_0x4fe0d7['_tenantRecaptchaConfigs'][_0x4fe0d7['tenantId']]!==void 0x0)return _0x4fe0d7['_tenantRecaptchaConfigs'][_0x4fe0d7['tenantId']]['siteKey'];}return new Promise(async(_0x269e52,_0x46bb50)=>{uf(_0x4fe0d7,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4a9d0c=>{if(_0x4a9d0c['recaptchaKey']===void 0x0)_0x46bb50(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x424fec=new hf(_0x4a9d0c);return _0x4fe0d7['tenantId']==null?_0x4fe0d7['_agentRecaptchaConfig']=_0x424fec:_0x4fe0d7['_tenantRecaptchaConfigs'][_0x4fe0d7['tenantId']]=_0x424fec,_0x269e52(_0x424fec['siteKey']);}})['catch'](_0x290173=>{_0x46bb50(_0x290173);});});}function _0x1cd993(_0x1ba0fa,_0x274ef9,_0x1836d4){const _0x347211=window['grecaptcha'];vr(_0x347211)?_0x347211['enterprise']['ready'](()=>{_0x347211['enterprise']['execute'](_0x1ba0fa,{'action':_0x2fff2d})['then'](_0x45df36=>{_0x274ef9(_0x45df36);})['catch'](()=>{_0x274ef9(Ma);});}):_0x1836d4(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1660f2,_0x4c37ac)=>{_0x1f7c8e(this['auth'])['then'](async _0x4c13cf=>{if(!_0x552d43&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x1cd993(_0x4c13cf,_0x1660f2,_0x4c37ac);else{if(typeof window>'u'){_0x4c37ac(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1706dc=Af();_0x1706dc['length']!==0x0&&(_0x1706dc+=_0x4c13cf+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x71eaef;(_0x71eaef=le['scriptInjectionDeferred'])==null||_0x71eaef['resolve']();},Da(_0x1706dc)['then'](()=>{var _0x52d1db;return(_0x52d1db=le['scriptInjectionDeferred'])==null?void 0x0:_0x52d1db['promise'];})['then'](()=>{_0x1cd993(_0x4c13cf,_0x1660f2,_0x4c37ac);})['catch'](_0x5cc3b8=>{_0x4c37ac(_0x5cc3b8);});}})['catch'](_0x314bee=>{_0x4c37ac(_0x314bee);});});}}le['scriptInjectionDeferred']=null;async function br(_0x387d80,_0x26a195,_0x2a4872,_0x204ae9=!0x1,_0x22c9fb=!0x1){const _0x63acfb=new le(_0x387d80);let _0x59c344;if(_0x22c9fb)_0x59c344=Ma;else try{_0x59c344=await _0x63acfb['verify'](_0x2a4872);}catch{_0x59c344=await _0x63acfb['verify'](_0x2a4872,!0x0);}const _0x4f4576={..._0x26a195};if(_0x2a4872==='mfaSmsEnrollment'||_0x2a4872==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4f4576){const _0x3668db=_0x4f4576['phoneEnrollmentInfo']['phoneNumber'],_0x45ded2=_0x4f4576['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4f4576,{'phoneEnrollmentInfo':{'phoneNumber':_0x3668db,'recaptchaToken':_0x45ded2,'captchaResponse':_0x59c344,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4f4576){const _0x3db185=_0x4f4576['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4f4576,{'phoneSignInInfo':{'recaptchaToken':_0x3db185,'captchaResponse':_0x59c344,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4f4576;}return _0x204ae9?Object['assign'](_0x4f4576,{'captchaResp':_0x59c344}):Object['assign'](_0x4f4576,{'captchaResponse':_0x59c344}),Object['assign'](_0x4f4576,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4f4576,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4f4576;}async function Oi(_0x28cc26,_0x37f41c,_0x53a4e1,_0x1ec2d9,_0x4c6869){var _0x35a8b7;if((_0x35a8b7=_0x28cc26['_getRecaptchaConfig']())!=null&&_0x35a8b7['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xc0702f=await br(_0x28cc26,_0x37f41c,_0x53a4e1,_0x53a4e1==='getOobCode');return _0x1ec2d9(_0x28cc26,_0xc0702f);}else return _0x1ec2d9(_0x28cc26,_0x37f41c)['catch'](async _0x51e504=>{if(_0x51e504['code']==='auth/missing-recaptcha-token'){console['log'](_0x53a4e1+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x590e71=await br(_0x28cc26,_0x37f41c,_0x53a4e1,_0x53a4e1==='getOobCode');return _0x1ec2d9(_0x28cc26,_0x590e71);}else return Promise['reject'](_0x51e504);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5d2cce,_0x2d25ed){const _0x25d175=Ui(_0x5d2cce,'auth');if(_0x25d175['isInitialized']()){const _0x1f9327=_0x25d175['getImmediate'](),_0x289787=_0x25d175['getOptions']();if(De(_0x289787,_0x2d25ed??{}))return _0x1f9327;K(_0x1f9327,'already-initialized');}return _0x25d175['initialize']({'options':_0x2d25ed});}function Lf(_0x17fb18,_0x2cc4b9){const _0x284d07=(_0x2cc4b9==null?void 0x0:_0x2cc4b9['persistence'])||[],_0x10fb5b=(Array['isArray'](_0x284d07)?_0x284d07:[_0x284d07])['map'](ne);_0x2cc4b9!=null&&_0x2cc4b9['errorMap']&&_0x17fb18['_updateErrorMap'](_0x2cc4b9['errorMap']),_0x17fb18['_initializeWithPersistence'](_0x10fb5b,_0x2cc4b9==null?void 0x0:_0x2cc4b9['popupRedirectResolver']);}function xf(_0x1836f7,_0x3dada4,_0x20ccbc){const _0x1ea067=qe(_0x1836f7);m(/^https?:\/\//['test'](_0x3dada4),_0x1ea067,'invalid-emulator-scheme');const _0x509323=!0x1,_0x432277=La(_0x3dada4),{host:_0x47e0a1,port:_0x3c2015}=Ff(_0x3dada4),_0x1cce31=_0x3c2015===null?'':':'+_0x3c2015,_0x54ef4c={'url':_0x432277+'//'+_0x47e0a1+_0x1cce31+'/'},_0x5acb22=Object['freeze']({'host':_0x47e0a1,'port':_0x3c2015,'protocol':_0x432277['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x509323})});if(!_0x1ea067['_canInitEmulator']){m(_0x1ea067['config']['emulator']&&_0x1ea067['emulatorConfig'],_0x1ea067,'emulator-config-failed'),m(De(_0x54ef4c,_0x1ea067['config']['emulator'])&&De(_0x5acb22,_0x1ea067['emulatorConfig']),_0x1ea067,'emulator-config-failed');return;}_0x1ea067['config']['emulator']=_0x54ef4c,_0x1ea067['emulatorConfig']=_0x5acb22,_0x1ea067['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x47e0a1)?jr(_0x432277+'//'+_0x47e0a1+_0x1cce31):Uf();}function La(_0x430e20){const _0x124365=_0x430e20['indexOf'](':');return _0x124365<0x0?'':_0x430e20['substr'](0x0,_0x124365+0x1);}function Ff(_0x150e96){const _0x55f770=La(_0x150e96),_0x24c74c=/(\/\/)?([^?#/]+)/['exec'](_0x150e96['substr'](_0x55f770['length']));if(!_0x24c74c)return{'host':'','port':null};const _0x45e003=_0x24c74c[0x2]['split']('@')['pop']()||'',_0x544e74=/^(\[[^\]]+\])(:|$)/['exec'](_0x45e003);if(_0x544e74){const _0x8aa73f=_0x544e74[0x1];return{'host':_0x8aa73f,'port':Rr(_0x45e003['substr'](_0x8aa73f['length']+0x1))};}else{const [_0x595b85,_0x40bd21]=_0x45e003['split'](':');return{'host':_0x595b85,'port':Rr(_0x40bd21)};}}function Rr(_0x403090){if(!_0x403090)return null;const _0x3b61ef=Number(_0x403090);return isNaN(_0x3b61ef)?null:_0x3b61ef;}function Uf(){function _0x3af944(){const _0x250684=document['createElement']('p'),_0x39449e=_0x250684['style'];_0x250684['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x39449e['position']='fixed',_0x39449e['width']='100%',_0x39449e['backgroundColor']='#ffffff',_0x39449e['border']='.1em\x20solid\x20#000000',_0x39449e['color']='#b50000',_0x39449e['bottom']='0px',_0x39449e['left']='0px',_0x39449e['margin']='0px',_0x39449e['zIndex']='10000',_0x39449e['textAlign']='center',_0x250684['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x250684);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3af944):_0x3af944());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x3b7d4d,_0x466678){this['providerId']=_0x3b7d4d,this['signInMethod']=_0x466678;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x532cda){return te('not\x20implemented');}['_linkToIdToken'](_0x52e910,_0x211bef){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1df887){return te('not\x20implemented');}}async function Wf(_0x56448c,_0x363791){return Ae(_0x56448c,'POST','/v1/accounts:signUp',_0x363791);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2fa61f,_0x54ae10){return Yt(_0x2fa61f,'POST','/v1/accounts:signInWithPassword',Re(_0x2fa61f,_0x54ae10));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x2b95ef,_0x3275fe){return Yt(_0x2b95ef,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2b95ef,_0x3275fe));}async function Hf(_0x494233,_0x12d24a){return Yt(_0x494233,'POST','/v1/accounts:signInWithEmailLink',Re(_0x494233,_0x12d24a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x2e4e62,_0x20f78c,_0x5f2e0f,_0x37e896=null){super('password',_0x5f2e0f),this['_email']=_0x2e4e62,this['_password']=_0x20f78c,this['_tenantId']=_0x37e896;}static['_fromEmailAndPassword'](_0x4edeaf,_0x16fd9){return new Ft(_0x4edeaf,_0x16fd9,'password');}static['_fromEmailAndCode'](_0x125c41,_0x124380,_0x1c2ec9=null){return new Ft(_0x125c41,_0x124380,'emailLink',_0x1c2ec9);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x372fbd){const _0x3b6ec0=typeof _0x372fbd=='string'?JSON['parse'](_0x372fbd):_0x372fbd;if(_0x3b6ec0!=null&&_0x3b6ec0['email']&&(_0x3b6ec0!=null&&_0x3b6ec0['password'])){if(_0x3b6ec0['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3b6ec0['email'],_0x3b6ec0['password']);if(_0x3b6ec0['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3b6ec0['email'],_0x3b6ec0['password'],_0x3b6ec0['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3f5a3c){switch(this['signInMethod']){case'password':const _0x252a3b={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3f5a3c,_0x252a3b,'signInWithPassword',Bf);case'emailLink':return Vf(_0x3f5a3c,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x3f5a3c,'internal-error');}}async['_linkToIdToken'](_0x1ac9a6,_0x4bce92){switch(this['signInMethod']){case'password':const _0x4f391a={'idToken':_0x4bce92,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1ac9a6,_0x4f391a,'signUpPassword',Wf);case'emailLink':return Hf(_0x1ac9a6,{'idToken':_0x4bce92,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1ac9a6,'internal-error');}}['_getReauthenticationResolver'](_0x37fb64){return this['_getIdTokenResponse'](_0x37fb64);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x6f5268,_0x35bcd0){return Yt(_0x6f5268,'POST','/v1/accounts:signInWithIdp',Re(_0x6f5268,_0x35bcd0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0xd5d78c){const _0xfe1264=new We(_0xd5d78c['providerId'],_0xd5d78c['signInMethod']);return _0xd5d78c['idToken']||_0xd5d78c['accessToken']?(_0xd5d78c['idToken']&&(_0xfe1264['idToken']=_0xd5d78c['idToken']),_0xd5d78c['accessToken']&&(_0xfe1264['accessToken']=_0xd5d78c['accessToken']),_0xd5d78c['nonce']&&!_0xd5d78c['pendingToken']&&(_0xfe1264['nonce']=_0xd5d78c['nonce']),_0xd5d78c['pendingToken']&&(_0xfe1264['pendingToken']=_0xd5d78c['pendingToken'])):_0xd5d78c['oauthToken']&&_0xd5d78c['oauthTokenSecret']?(_0xfe1264['accessToken']=_0xd5d78c['oauthToken'],_0xfe1264['secret']=_0xd5d78c['oauthTokenSecret']):K('argument-error'),_0xfe1264;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1ecd80){const _0x37c53b=typeof _0x1ecd80=='string'?JSON['parse'](_0x1ecd80):_0x1ecd80,{providerId:_0x50a3c0,signInMethod:_0x40b423,..._0x4afded}=_0x37c53b;if(!_0x50a3c0||!_0x40b423)return null;const _0x383f08=new We(_0x50a3c0,_0x40b423);return _0x383f08['idToken']=_0x4afded['idToken']||void 0x0,_0x383f08['accessToken']=_0x4afded['accessToken']||void 0x0,_0x383f08['secret']=_0x4afded['secret'],_0x383f08['nonce']=_0x4afded['nonce'],_0x383f08['pendingToken']=_0x4afded['pendingToken']||null,_0x383f08;}['_getIdTokenResponse'](_0x631801){const _0x6a988c=this['buildRequest']();return Ze(_0x631801,_0x6a988c);}['_linkToIdToken'](_0x4e8665,_0x5d5dcb){const _0x5bab2d=this['buildRequest']();return _0x5bab2d['idToken']=_0x5d5dcb,Ze(_0x4e8665,_0x5bab2d);}['_getReauthenticationResolver'](_0x190c8f){const _0x3afdb9=this['buildRequest']();return _0x3afdb9['autoCreate']=!0x1,Ze(_0x190c8f,_0x3afdb9);}['buildRequest'](){const _0x41c796={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x41c796['pendingToken']=this['pendingToken'];else{const _0x157868={};this['idToken']&&(_0x157868['id_token']=this['idToken']),this['accessToken']&&(_0x157868['access_token']=this['accessToken']),this['secret']&&(_0x157868['oauth_token_secret']=this['secret']),_0x157868['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x157868['nonce']=this['nonce']),_0x41c796['postBody']=at(_0x157868);}return _0x41c796;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0xabe350){switch(_0xabe350){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x39be56){const _0x5c54a9=yt(vt(_0x39be56))['link'],_0x1f44fe=_0x5c54a9?yt(vt(_0x5c54a9))['deep_link_id']:null,_0xa7d3b9=yt(vt(_0x39be56))['deep_link_id'];return(_0xa7d3b9?yt(vt(_0xa7d3b9))['link']:null)||_0xa7d3b9||_0x1f44fe||_0x5c54a9||_0x39be56;}class Ss{constructor(_0x14b12b){const _0x4e0cc8=yt(vt(_0x14b12b)),_0x3142a0=_0x4e0cc8['apiKey']??null,_0x27013f=_0x4e0cc8['oobCode']??null,_0x2eda11=Gf(_0x4e0cc8['mode']??null);m(_0x3142a0&&_0x27013f&&_0x2eda11,'argument-error'),this['apiKey']=_0x3142a0,this['operation']=_0x2eda11,this['code']=_0x27013f,this['continueUrl']=_0x4e0cc8['continueUrl']??null,this['languageCode']=_0x4e0cc8['lang']??null,this['tenantId']=_0x4e0cc8['tenantId']??null;}static['parseLink'](_0x3cea49){const _0x245cee=qf(_0x3cea49);try{return new Ss(_0x245cee);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x33a694,_0x21dfba){return Ft['_fromEmailAndPassword'](_0x33a694,_0x21dfba);}static['credentialWithLink'](_0x4e343b,_0x49064a){const _0x100d0e=Ss['parseLink'](_0x49064a);return m(_0x100d0e,'argument-error'),Ft['_fromEmailAndCode'](_0x4e343b,_0x100d0e['code'],_0x100d0e['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x30ea4e){this['providerId']=_0x30ea4e,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x16e6f1){this['defaultLanguageCode']=_0x16e6f1;}['setCustomParameters'](_0x41086c){return this['customParameters']=_0x41086c,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3c0c5c){return this['scopes']['includes'](_0x3c0c5c)||this['scopes']['push'](_0x3c0c5c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x48fc2d){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x48fc2d});}static['credentialFromResult'](_0x9a3bb5){return he['credentialFromTaggedObject'](_0x9a3bb5);}static['credentialFromError'](_0x516419){return he['credentialFromTaggedObject'](_0x516419['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x82ba63}){if(!_0x82ba63||!('oauthAccessToken'in _0x82ba63)||!_0x82ba63['oauthAccessToken'])return null;try{return he['credential'](_0x82ba63['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3a4710,_0x3c5bbc){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3a4710,'accessToken':_0x3c5bbc});}static['credentialFromResult'](_0x564c95){return ue['credentialFromTaggedObject'](_0x564c95);}static['credentialFromError'](_0x3b0ab9){return ue['credentialFromTaggedObject'](_0x3b0ab9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x909197}){if(!_0x909197)return null;const {oauthIdToken:_0x4a3a55,oauthAccessToken:_0x1f9f5e}=_0x909197;if(!_0x4a3a55&&!_0x1f9f5e)return null;try{return ue['credential'](_0x4a3a55,_0x1f9f5e);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x181ef1){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x181ef1});}static['credentialFromResult'](_0x1ad549){return de['credentialFromTaggedObject'](_0x1ad549);}static['credentialFromError'](_0x211d8f){return de['credentialFromTaggedObject'](_0x211d8f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1088c9}){if(!_0x1088c9||!('oauthAccessToken'in _0x1088c9)||!_0x1088c9['oauthAccessToken'])return null;try{return de['credential'](_0x1088c9['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x387b9d,_0x26e54f){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x387b9d,'oauthTokenSecret':_0x26e54f});}static['credentialFromResult'](_0x2fef0c){return fe['credentialFromTaggedObject'](_0x2fef0c);}static['credentialFromError'](_0x3c6d67){return fe['credentialFromTaggedObject'](_0x3c6d67['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b7342}){if(!_0x1b7342)return null;const {oauthAccessToken:_0x484587,oauthTokenSecret:_0x353441}=_0x1b7342;if(!_0x484587||!_0x353441)return null;try{return fe['credential'](_0x484587,_0x353441);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4a4cc3,_0x4782a4){return Yt(_0x4a4cc3,'POST','/v1/accounts:signUp',Re(_0x4a4cc3,_0x4782a4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x30e325){this['user']=_0x30e325['user'],this['providerId']=_0x30e325['providerId'],this['_tokenResponse']=_0x30e325['_tokenResponse'],this['operationType']=_0x30e325['operationType'];}static async['_fromIdTokenResponse'](_0x465cb4,_0x1f6685,_0x428c22,_0x57a22c=!0x1){const _0x48d341=await z['_fromIdTokenResponse'](_0x465cb4,_0x428c22,_0x57a22c),_0x4c2a95=Ar(_0x428c22);return new Be({'user':_0x48d341,'providerId':_0x4c2a95,'_tokenResponse':_0x428c22,'operationType':_0x1f6685});}static async['_forOperation'](_0x5029b2,_0x16749c,_0x5535e2){await _0x5029b2['_updateTokensIfNecessary'](_0x5535e2,!0x0);const _0x2d8529=Ar(_0x5535e2);return new Be({'user':_0x5029b2,'providerId':_0x2d8529,'_tokenResponse':_0x5535e2,'operationType':_0x16749c});}}function Ar(_0xa75632){return _0xa75632['providerId']?_0xa75632['providerId']:'phoneNumber'in _0xa75632?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x3f101f,_0x1448bc,_0x5eedd8,_0x29cd10){super(_0x1448bc['code'],_0x1448bc['message']),this['operationType']=_0x5eedd8,this['user']=_0x29cd10,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x3f101f['name'],'tenantId':_0x3f101f['tenantId']??void 0x0,'_serverResponse':_0x1448bc['customData']['_serverResponse'],'operationType':_0x5eedd8};}static['_fromErrorAndOperation'](_0x59d088,_0x3247ca,_0xa72cdb,_0x13cdee){return new Rn(_0x59d088,_0x3247ca,_0xa72cdb,_0x13cdee);}}function Fa(_0xe046eb,_0x1669ef,_0x4b6627,_0xc1ec4f){return(_0x1669ef==='reauthenticate'?_0x4b6627['_getReauthenticationResolver'](_0xe046eb):_0x4b6627['_getIdTokenResponse'](_0xe046eb))['catch'](_0x4fb6dc=>{throw _0x4fb6dc['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0xe046eb,_0x4fb6dc,_0x1669ef,_0xc1ec4f):_0x4fb6dc;});}async function jf(_0x2093e0,_0x1e5552,_0x51f56e=!0x1){const _0x3bc092=await xt(_0x2093e0,_0x1e5552['_linkToIdToken'](_0x2093e0['auth'],await _0x2093e0['getIdToken']()),_0x51f56e);return Be['_forOperation'](_0x2093e0,'link',_0x3bc092);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x31779d,_0x710df3,_0x349224=!0x1){const {auth:_0x54413c}=_0x31779d;if(H(_0x54413c['app']))return Promise['reject'](se(_0x54413c));const _0x19286d='reauthenticate';try{const _0x15fbf9=await xt(_0x31779d,Fa(_0x54413c,_0x19286d,_0x710df3,_0x31779d),_0x349224);m(_0x15fbf9['idToken'],_0x54413c,'internal-error');const _0x201dd9=ws(_0x15fbf9['idToken']);m(_0x201dd9,_0x54413c,'internal-error');const {sub:_0x15fde1}=_0x201dd9;return m(_0x31779d['uid']===_0x15fde1,_0x54413c,'user-mismatch'),Be['_forOperation'](_0x31779d,_0x19286d,_0x15fbf9);}catch(_0x242c97){throw(_0x242c97==null?void 0x0:_0x242c97['code'])==='auth/user-not-found'&&K(_0x54413c,'user-mismatch'),_0x242c97;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0xb8afb3,_0x3c627f,_0x3e9df3=!0x1){if(H(_0xb8afb3['app']))return Promise['reject'](se(_0xb8afb3));const _0x50d144='signIn',_0x4ce7ca=await Fa(_0xb8afb3,_0x50d144,_0x3c627f),_0x1452b9=await Be['_fromIdTokenResponse'](_0xb8afb3,_0x50d144,_0x4ce7ca);return _0x3e9df3||await _0xb8afb3['_updateCurrentUser'](_0x1452b9['user']),_0x1452b9;}async function Yf(_0x41cb26,_0x147aef){return Ua(qe(_0x41cb26),_0x147aef);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x34a172){const _0x18acd1=qe(_0x34a172);_0x18acd1['_getPasswordPolicyInternal']()&&await _0x18acd1['_updatePasswordPolicy']();}async function R_(_0x200e11,_0x226fca,_0x55637b){if(H(_0x200e11['app']))return Promise['reject'](se(_0x200e11));const _0x3a54ba=qe(_0x200e11),_0x57b11b=await Oi(_0x3a54ba,{'returnSecureToken':!0x0,'email':_0x226fca,'password':_0x55637b,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x35b2dd=>{throw _0x35b2dd['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x200e11),_0x35b2dd;}),_0x2133d8=await Be['_fromIdTokenResponse'](_0x3a54ba,'signIn',_0x57b11b);return await _0x3a54ba['_updateCurrentUser'](_0x2133d8['user']),_0x2133d8;}function A_(_0x4dade4,_0x96a34c,_0x143d9d){return H(_0x4dade4['app'])?Promise['reject'](se(_0x4dade4)):Yf(k(_0x4dade4),ft['credential'](_0x96a34c,_0x143d9d))['catch'](async _0x410b70=>{throw _0x410b70['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4dade4),_0x410b70;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5d9b49,_0x5dd16f){return k(_0x5d9b49)['setPersistence'](_0x5dd16f);}function Qf(_0xf828d3,_0x442a8a,_0x322f53,_0x1507a3){return k(_0xf828d3)['onIdTokenChanged'](_0x442a8a,_0x322f53,_0x1507a3);}function Jf(_0x57730e,_0x47bfa4,_0x2d9205){return k(_0x57730e)['beforeAuthStateChanged'](_0x47bfa4,_0x2d9205);}function N_(_0x354039,_0x1c4f80,_0x2e89a0,_0x26e17b){return k(_0x354039)['onAuthStateChanged'](_0x1c4f80,_0x2e89a0,_0x26e17b);}function P_(_0x5b1698){return k(_0x5b1698)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xd61718,_0x1eb61f){this['storageRetriever']=_0xd61718,this['type']=_0x1eb61f;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5c40ae,_0x5b3807){return this['storage']['setItem'](_0x5c40ae,JSON['stringify'](_0x5b3807)),Promise['resolve']();}['_get'](_0xc9d25b){const _0x1d7e37=this['storage']['getItem'](_0xc9d25b);return Promise['resolve'](_0x1d7e37?JSON['parse'](_0x1d7e37):null);}['_remove'](_0x4d2281){return this['storage']['removeItem'](_0x4d2281),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xc9caa4,_0xf07960)=>this['onStorageEvent'](_0xc9caa4,_0xf07960),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xae7b0){for(const _0x6d711a of Object['keys'](this['listeners'])){const _0x279f4e=this['storage']['getItem'](_0x6d711a),_0x4ef7f1=this['localCache'][_0x6d711a];_0x279f4e!==_0x4ef7f1&&_0xae7b0(_0x6d711a,_0x4ef7f1,_0x279f4e);}}['onStorageEvent'](_0x3a1717,_0x4cde9d=!0x1){if(!_0x3a1717['key']){this['forAllChangedKeys']((_0x3791d6,_0x1f204a,_0x5b3990)=>{this['notifyListeners'](_0x3791d6,_0x5b3990);});return;}const _0x447983=_0x3a1717['key'];_0x4cde9d?this['detachListener']():this['stopPolling']();const _0x5bf708=()=>{const _0x178281=this['storage']['getItem'](_0x447983);!_0x4cde9d&&this['localCache'][_0x447983]===_0x178281||this['notifyListeners'](_0x447983,_0x178281);},_0x1ad55d=this['storage']['getItem'](_0x447983);If()&&_0x1ad55d!==_0x3a1717['newValue']&&_0x3a1717['newValue']!==_0x3a1717['oldValue']?setTimeout(_0x5bf708,Zf):_0x5bf708();}['notifyListeners'](_0x4d5fc9,_0x3096bf){this['localCache'][_0x4d5fc9]=_0x3096bf;const _0x292259=this['listeners'][_0x4d5fc9];if(_0x292259){for(const _0x44e80c of Array['from'](_0x292259))_0x44e80c(_0x3096bf&&JSON['parse'](_0x3096bf));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x17d989,_0x380e6c,_0x251bea)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x17d989,'oldValue':_0x380e6c,'newValue':_0x251bea}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x45932d,_0x596977){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x45932d]||(this['listeners'][_0x45932d]=new Set(),this['localCache'][_0x45932d]=this['storage']['getItem'](_0x45932d)),this['listeners'][_0x45932d]['add'](_0x596977);}['_removeListener'](_0x282b4d,_0x1266a2){this['listeners'][_0x282b4d]&&(this['listeners'][_0x282b4d]['delete'](_0x1266a2),this['listeners'][_0x282b4d]['size']===0x0&&delete this['listeners'][_0x282b4d]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x26b62d,_0x1be05d){await super['_set'](_0x26b62d,_0x1be05d),this['localCache'][_0x26b62d]=JSON['stringify'](_0x1be05d);}async['_get'](_0xf470fb){const _0x370fbc=await super['_get'](_0xf470fb);return this['localCache'][_0xf470fb]=JSON['stringify'](_0x370fbc),_0x370fbc;}async['_remove'](_0x1f1b79){await super['_remove'](_0x1f1b79),delete this['localCache'][_0x1f1b79];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x513654,_0x3be4a6){}['_removeListener'](_0x5ca461,_0xd95053){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x48a46d){return Promise['all'](_0x48a46d['map'](async _0x1d57fd=>{try{return{'fulfilled':!0x0,'value':await _0x1d57fd};}catch(_0x4c75f1){return{'fulfilled':!0x1,'reason':_0x4c75f1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x502ee3){this['eventTarget']=_0x502ee3,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x523270){const _0x459dfb=this['receivers']['find'](_0x2dee2e=>_0x2dee2e['isListeningto'](_0x523270));if(_0x459dfb)return _0x459dfb;const _0x32d46e=new jn(_0x523270);return this['receivers']['push'](_0x32d46e),_0x32d46e;}['isListeningto'](_0x2c48dd){return this['eventTarget']===_0x2c48dd;}async['handleEvent'](_0x1f70aa){const _0x2a96d3=_0x1f70aa,{eventId:_0x494566,eventType:_0x3beb7e,data:_0x4bf434}=_0x2a96d3['data'],_0x82414e=this['handlersMap'][_0x3beb7e];if(!(_0x82414e!=null&&_0x82414e['size']))return;_0x2a96d3['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x494566,'eventType':_0x3beb7e});const _0x4a6f7a=Array['from'](_0x82414e)['map'](async _0x1917eb=>_0x1917eb(_0x2a96d3['origin'],_0x4bf434)),_0x1ec113=await tp(_0x4a6f7a);_0x2a96d3['ports'][0x0]['postMessage']({'status':'done','eventId':_0x494566,'eventType':_0x3beb7e,'response':_0x1ec113});}['_subscribe'](_0x7d4cc4,_0x2dc80d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x7d4cc4]||(this['handlersMap'][_0x7d4cc4]=new Set()),this['handlersMap'][_0x7d4cc4]['add'](_0x2dc80d);}['_unsubscribe'](_0x1b979a,_0xf98b91){this['handlersMap'][_0x1b979a]&&_0xf98b91&&this['handlersMap'][_0x1b979a]['delete'](_0xf98b91),(!_0xf98b91||this['handlersMap'][_0x1b979a]['size']===0x0)&&delete this['handlersMap'][_0x1b979a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4d9315='',_0x3eb1d3=0xa){let _0x3f4b32='';for(let _0x199226=0x0;_0x199226<_0x3eb1d3;_0x199226++)_0x3f4b32+=Math['floor'](Math['random']()*0xa);return _0x4d9315+_0x3f4b32;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x1a4e3f){this['target']=_0x1a4e3f,this['handlers']=new Set();}['removeMessageHandler'](_0x138601){_0x138601['messageChannel']&&(_0x138601['messageChannel']['port1']['removeEventListener']('message',_0x138601['onMessage']),_0x138601['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x138601);}async['_send'](_0x4f8e19,_0x3f5bdc,_0x1b6101=0x32){const _0x46da15=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x46da15)throw new Error('connection_unavailable');let _0x5893a5,_0x3b0dac;return new Promise((_0x51bafc,_0x2b92d4)=>{const _0x656b95=bs('',0x14);_0x46da15['port1']['start']();const _0x401e2e=setTimeout(()=>{_0x2b92d4(new Error('unsupported_event'));},_0x1b6101);_0x3b0dac={'messageChannel':_0x46da15,'onMessage'(_0x451906){const _0x26cff9=_0x451906;if(_0x26cff9['data']['eventId']===_0x656b95)switch(_0x26cff9['data']['status']){case'ack':clearTimeout(_0x401e2e),_0x5893a5=setTimeout(()=>{_0x2b92d4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5893a5),_0x51bafc(_0x26cff9['data']['response']);break;default:clearTimeout(_0x401e2e),clearTimeout(_0x5893a5),_0x2b92d4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3b0dac),_0x46da15['port1']['addEventListener']('message',_0x3b0dac['onMessage']),this['target']['postMessage']({'eventType':_0x4f8e19,'eventId':_0x656b95,'data':_0x3f5bdc},[_0x46da15['port2']]);})['finally'](()=>{_0x3b0dac&&this['removeMessageHandler'](_0x3b0dac);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x5d35c2){X()['location']['href']=_0x5d35c2;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x45e3cf;return((_0x45e3cf=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x45e3cf['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x223aaa){this['request']=_0x223aaa;}['toPromise'](){return new Promise((_0x3b1b9f,_0x5b1b4d)=>{this['request']['addEventListener']('success',()=>{_0x3b1b9f(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x5b1b4d(this['request']['error']);});});}}function Kn(_0x3d8ab4,_0x4bcc1a){return _0x3d8ab4['transaction']([kn],_0x4bcc1a?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5bf5eb=indexedDB['deleteDatabase'](qa);return new Jt(_0x5bf5eb)['toPromise']();}function ja(){const _0x143caf=indexedDB['open'](qa,ap);return new Promise((_0x15f165,_0x408bad)=>{_0x143caf['addEventListener']('error',()=>{_0x408bad(_0x143caf['error']);}),_0x143caf['addEventListener']('upgradeneeded',()=>{const _0x181c02=_0x143caf['result'];try{_0x181c02['createObjectStore'](kn,{'keyPath':za});}catch(_0x5502fc){_0x408bad(_0x5502fc);}}),_0x143caf['addEventListener']('success',async()=>{const _0x103f7f=_0x143caf['result'];_0x103f7f['objectStoreNames']['contains'](kn)?_0x15f165(_0x103f7f):(_0x103f7f['close'](),await cp(),_0x15f165(await ja()));});});}async function kr(_0x31b67e,_0x3d9112,_0xe83376){const _0x57b920=Kn(_0x31b67e,!0x0)['put']({[za]:_0x3d9112,'value':_0xe83376});return new Jt(_0x57b920)['toPromise']();}async function lp(_0x21b787,_0x47b588){const _0x246312=Kn(_0x21b787,!0x1)['get'](_0x47b588),_0x450742=await new Jt(_0x246312)['toPromise']();return _0x450742===void 0x0?null:_0x450742['value'];}function Nr(_0x58619f,_0x3fcbbe){const _0xa61b31=Kn(_0x58619f,!0x0)['delete'](_0x3fcbbe);return new Jt(_0xa61b31)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x831416){let _0xa07f1e=0x0;for(;;)try{const _0x5488a2=await this['_openDb']();return await _0x831416(_0x5488a2);}catch(_0x260426){if(_0xa07f1e++>up)throw _0x260426;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x22b71e,_0x38eb2c)=>({'keyProcessed':(await this['_poll']())['includes'](_0x38eb2c['key'])})),this['receiver']['_subscribe']('ping',async(_0x3e2aa7,_0x1a52bb)=>['keyChanged']);}async['initializeSender'](){var _0x37a1de,_0x4dcbff;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4c5fe3=await this['sender']['_send']('ping',{},0x320);_0x4c5fe3&&(_0x37a1de=_0x4c5fe3[0x0])!=null&&_0x37a1de['fulfilled']&&(_0x4dcbff=_0x4c5fe3[0x0])!=null&&_0x4dcbff['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x9fcd9d){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x9fcd9d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3bf384=>{await kr(_0x3bf384,An,'1'),await Nr(_0x3bf384,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x578b66){this['pendingWrites']++;try{await _0x578b66();}finally{this['pendingWrites']--;}}async['_set'](_0x172c81,_0x269bea){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x705c08=>kr(_0x705c08,_0x172c81,_0x269bea)),this['localCache'][_0x172c81]=_0x269bea,this['notifyServiceWorker'](_0x172c81)));}async['_get'](_0x558d8d){const _0x4e3957=await this['_withRetries'](_0x2b987a=>lp(_0x2b987a,_0x558d8d));return this['localCache'][_0x558d8d]=_0x4e3957,_0x4e3957;}async['_remove'](_0xfcfb11){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x137c3b=>Nr(_0x137c3b,_0xfcfb11)),delete this['localCache'][_0xfcfb11],this['notifyServiceWorker'](_0xfcfb11)));}async['_poll'](){const _0x3ba983=await this['_withRetries'](_0x23f7e2=>{const _0x2996a6=Kn(_0x23f7e2,!0x1)['getAll']();return new Jt(_0x2996a6)['toPromise']();});if(!_0x3ba983)return[];if(this['pendingWrites']!==0x0)return[];const _0x56a350=[],_0x235f4e=new Set();if(_0x3ba983['length']!==0x0){for(const {fbase_key:_0x108216,value:_0x120a0f}of _0x3ba983)_0x235f4e['add'](_0x108216),JSON['stringify'](this['localCache'][_0x108216])!==JSON['stringify'](_0x120a0f)&&(this['notifyListeners'](_0x108216,_0x120a0f),_0x56a350['push'](_0x108216));}for(const _0x3cb4fd of Object['keys'](this['localCache']))this['localCache'][_0x3cb4fd]&&!_0x235f4e['has'](_0x3cb4fd)&&(this['notifyListeners'](_0x3cb4fd,null),_0x56a350['push'](_0x3cb4fd));return _0x56a350;}['notifyListeners'](_0x256795,_0x39af68){this['localCache'][_0x256795]=_0x39af68;const _0x1e64c9=this['listeners'][_0x256795];if(_0x1e64c9){for(const _0x237c88 of Array['from'](_0x1e64c9))_0x237c88(_0x39af68);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x53acc9,_0x287939){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x53acc9]||(this['listeners'][_0x53acc9]=new Set(),this['_get'](_0x53acc9)),this['listeners'][_0x53acc9]['add'](_0x287939);}['_removeListener'](_0xb9f543,_0xe57668){this['listeners'][_0xb9f543]&&(this['listeners'][_0xb9f543]['delete'](_0xe57668),this['listeners'][_0xb9f543]['size']===0x0&&delete this['listeners'][_0xb9f543]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x11564a,_0x1a9b05){return _0x1a9b05?ne(_0x1a9b05):(m(_0x11564a['_popupRedirectResolver'],_0x11564a,'argument-error'),_0x11564a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x29084a){super('custom','custom'),this['params']=_0x29084a;}['_getIdTokenResponse'](_0x5022a5){return Ze(_0x5022a5,this['_buildIdpRequest']());}['_linkToIdToken'](_0x160777,_0x5ee00c){return Ze(_0x160777,this['_buildIdpRequest'](_0x5ee00c));}['_getReauthenticationResolver'](_0x542ceb){return Ze(_0x542ceb,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4f8f45){const _0xc634a2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4f8f45&&(_0xc634a2['idToken']=_0x4f8f45),_0xc634a2;}}function pp(_0xa6545d){return Ua(_0xa6545d['auth'],new Rs(_0xa6545d),_0xa6545d['bypassAuthState']);}function _p(_0x266f76){const {auth:_0x5c0748,user:_0x1db445}=_0x266f76;return m(_0x1db445,_0x5c0748,'internal-error'),Kf(_0x1db445,new Rs(_0x266f76),_0x266f76['bypassAuthState']);}async function gp(_0x14ab83){const {auth:_0x4d6450,user:_0xa7529c}=_0x14ab83;return m(_0xa7529c,_0x4d6450,'internal-error'),jf(_0xa7529c,new Rs(_0x14ab83),_0x14ab83['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2a74f4,_0x34ebcd,_0x30a385,_0x40eb2d,_0x1c065e=!0x1){this['auth']=_0x2a74f4,this['resolver']=_0x30a385,this['user']=_0x40eb2d,this['bypassAuthState']=_0x1c065e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x34ebcd)?_0x34ebcd:[_0x34ebcd];}['execute'](){return new Promise(async(_0x280bda,_0x5f2852)=>{this['pendingPromise']={'resolve':_0x280bda,'reject':_0x5f2852};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3debcc){this['reject'](_0x3debcc);}});}async['onAuthEvent'](_0x4ca84a){const {urlResponse:_0x2a16a2,sessionId:_0x119c94,postBody:_0x33b2cf,tenantId:_0x16e607,error:_0x36a6d2,type:_0x430246}=_0x4ca84a;if(_0x36a6d2){this['reject'](_0x36a6d2);return;}const _0x123429={'auth':this['auth'],'requestUri':_0x2a16a2,'sessionId':_0x119c94,'tenantId':_0x16e607||void 0x0,'postBody':_0x33b2cf||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x430246)(_0x123429));}catch(_0x4f8ea8){this['reject'](_0x4f8ea8);}}['onError'](_0xe06253){this['reject'](_0xe06253);}['getIdpTask'](_0x2effb2){switch(_0x2effb2){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0xc494e3){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xc494e3),this['unregisterAndCleanUp']();}['reject'](_0x46fe46){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x46fe46),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x26a2c5,_0x153013,_0x1e14aa,_0x1553dd,_0x203d79){super(_0x26a2c5,_0x153013,_0x1553dd,_0x203d79),this['provider']=_0x1e14aa,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x271002=await this['execute']();return m(_0x271002,this['auth'],'internal-error'),_0x271002;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2b5e9f=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2b5e9f),this['authWindow']['associatedEvent']=_0x2b5e9f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x469245=>{this['reject'](_0x469245);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x21b156=>{_0x21b156||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x147d0d;return((_0x147d0d=this['authWindow'])==null?void 0x0:_0x147d0d['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x17bcb0=()=>{var _0x3c2fd5,_0x31b872;if((_0x31b872=(_0x3c2fd5=this['authWindow'])==null?void 0x0:_0x3c2fd5['window'])!=null&&_0x31b872['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x17bcb0,mp['get']());};_0x17bcb0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x248600,_0x56f259,_0x201a13=!0x1){super(_0x248600,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x56f259,void 0x0,_0x201a13),this['eventId']=null;}async['execute'](){let _0x34aa61=rn['get'](this['auth']['_key']());if(!_0x34aa61){try{const _0x14ade3=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x34aa61=()=>Promise['resolve'](_0x14ade3);}catch(_0xf4d3f){_0x34aa61=()=>Promise['reject'](_0xf4d3f);}rn['set'](this['auth']['_key'](),_0x34aa61);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x34aa61();}async['onAuthEvent'](_0xdf1704){if(_0xdf1704['type']==='signInViaRedirect')return super['onAuthEvent'](_0xdf1704);if(_0xdf1704['type']==='unknown'){this['resolve'](null);return;}if(_0xdf1704['eventId']){const _0x3082e1=await this['auth']['_redirectUserForId'](_0xdf1704['eventId']);if(_0x3082e1)return this['user']=_0x3082e1,super['onAuthEvent'](_0xdf1704);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x5057e8,_0x2a40c4){const _0x2bf929=Cp(_0x2a40c4),_0x15968f=wp(_0x5057e8);if(!await _0x15968f['_isAvailable']())return!0x1;const _0x19ed39=await _0x15968f['_get'](_0x2bf929)==='true';return await _0x15968f['_remove'](_0x2bf929),_0x19ed39;}function Ip(_0x548c9b,_0x264efb){rn['set'](_0x548c9b['_key'](),_0x264efb);}function wp(_0x14871d){return ne(_0x14871d['_redirectPersistence']);}function Cp(_0x5a94){return sn(yp,_0x5a94['config']['apiKey'],_0x5a94['name']);}async function Tp(_0x597171,_0x43f428,_0x15ccad=!0x1){if(H(_0x597171['app']))return Promise['reject'](se(_0x597171));const _0x4ff1c7=qe(_0x597171),_0x2d6a41=fp(_0x4ff1c7,_0x43f428),_0x1ecbb6=await new vp(_0x4ff1c7,_0x2d6a41,_0x15ccad)['execute']();return _0x1ecbb6&&!_0x15ccad&&(delete _0x1ecbb6['user']['_redirectEventId'],await _0x4ff1c7['_persistUserIfCurrent'](_0x1ecbb6['user']),await _0x4ff1c7['_setRedirectUser'](null,_0x43f428)),_0x1ecbb6;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x109a46){this['auth']=_0x109a46,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xcb1998){this['consumers']['add'](_0xcb1998),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xcb1998)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xcb1998),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x21f209){this['consumers']['delete'](_0x21f209);}['onEvent'](_0x4e4148){if(this['hasEventBeenHandled'](_0x4e4148))return!0x1;let _0x54c1a3=!0x1;return this['consumers']['forEach'](_0x1bc9d6=>{this['isEventForConsumer'](_0x4e4148,_0x1bc9d6)&&(_0x54c1a3=!0x0,this['sendToConsumer'](_0x4e4148,_0x1bc9d6),this['saveEventToCache'](_0x4e4148));}),this['hasHandledPotentialRedirect']||!Rp(_0x4e4148)||(this['hasHandledPotentialRedirect']=!0x0,_0x54c1a3||(this['queuedRedirectEvent']=_0x4e4148,_0x54c1a3=!0x0)),_0x54c1a3;}['sendToConsumer'](_0x44cbc9,_0x3383e8){var _0x3011eb;if(_0x44cbc9['error']&&!Qa(_0x44cbc9)){const _0x351bf5=((_0x3011eb=_0x44cbc9['error']['code'])==null?void 0x0:_0x3011eb['split']('auth/')[0x1])||'internal-error';_0x3383e8['onError'](J(this['auth'],_0x351bf5));}else _0x3383e8['onAuthEvent'](_0x44cbc9);}['isEventForConsumer'](_0x31dec1,_0x5679d8){const _0x2533e1=_0x5679d8['eventId']===null||!!_0x31dec1['eventId']&&_0x31dec1['eventId']===_0x5679d8['eventId'];return _0x5679d8['filter']['includes'](_0x31dec1['type'])&&_0x2533e1;}['hasEventBeenHandled'](_0x3bfb82){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x3bfb82));}['saveEventToCache'](_0x480ce5){this['cachedEventUids']['add'](Pr(_0x480ce5)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x5a9afd){return[_0x5a9afd['type'],_0x5a9afd['eventId'],_0x5a9afd['sessionId'],_0x5a9afd['tenantId']]['filter'](_0x10735c=>_0x10735c)['join']('-');}function Qa({type:_0x4ffe64,error:_0x340618}){return _0x4ffe64==='unknown'&&(_0x340618==null?void 0x0:_0x340618['code'])==='auth/no-auth-event';}function Rp(_0x42f061){switch(_0x42f061['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x42f061);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x1c6caf,_0x59c3fe={}){return Ae(_0x1c6caf,'GET','/v1/projects',_0x59c3fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x27032e){if(_0x27032e['config']['emulator'])return;const {authorizedDomains:_0x195ebb}=await Ap(_0x27032e);for(const _0x4426d4 of _0x195ebb)try{if(Op(_0x4426d4))return;}catch{}K(_0x27032e,'unauthorized-domain');}function Op(_0x18efdc){const _0x1a60b6=Ni(),{protocol:_0x4b464f,hostname:_0x4f4b2c}=new URL(_0x1a60b6);if(_0x18efdc['startsWith']('chrome-extension://')){const _0x72b83b=new URL(_0x18efdc);return _0x72b83b['hostname']===''&&_0x4f4b2c===''?_0x4b464f==='chrome-extension:'&&_0x18efdc['replace']('chrome-extension://','')===_0x1a60b6['replace']('chrome-extension://',''):_0x4b464f==='chrome-extension:'&&_0x72b83b['hostname']===_0x4f4b2c;}if(!Np['test'](_0x4b464f))return!0x1;if(kp['test'](_0x18efdc))return _0x4f4b2c===_0x18efdc;const _0x3ca8a7=_0x18efdc['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3ca8a7+'|'+_0x3ca8a7+')$','i')['test'](_0x4f4b2c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x56e037=X()['___jsl'];if(_0x56e037!=null&&_0x56e037['H']){for(const _0x399e60 of Object['keys'](_0x56e037['H']))if(_0x56e037['H'][_0x399e60]['r']=_0x56e037['H'][_0x399e60]['r']||[],_0x56e037['H'][_0x399e60]['L']=_0x56e037['H'][_0x399e60]['L']||[],_0x56e037['H'][_0x399e60]['r']=[..._0x56e037['H'][_0x399e60]['L']],_0x56e037['CP']){for(let _0x405ee7=0x0;_0x405ee7<_0x56e037['CP']['length'];_0x405ee7++)_0x56e037['CP'][_0x405ee7]=null;}}}function Mp(_0x1b534c){return new Promise((_0x81ee62,_0x38ab96)=>{var _0x4ddb7f,_0x5e46d6,_0x51cb25;function _0x403be3(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x81ee62(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x38ab96(J(_0x1b534c,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5e46d6=(_0x4ddb7f=X()['gapi'])==null?void 0x0:_0x4ddb7f['iframes'])!=null&&_0x5e46d6['Iframe'])_0x81ee62(gapi['iframes']['getContext']());else{if((_0x51cb25=X()['gapi'])!=null&&_0x51cb25['load'])_0x403be3();else{const _0x29156a=Nf('iframefcb');return X()[_0x29156a]=()=>{gapi['load']?_0x403be3():_0x38ab96(J(_0x1b534c,'network-request-failed'));},Da(kf()+'?onload='+_0x29156a)['catch'](_0x4b84ff=>_0x38ab96(_0x4b84ff));}}})['catch'](_0x29db25=>{throw on=null,_0x29db25;});}let on=null;function Lp(_0x11dbe5){return on=on||Mp(_0x11dbe5),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x392238){const _0x3d8cc8=_0x392238['config'];m(_0x3d8cc8['authDomain'],_0x392238,'auth-domain-config-required');const _0x10178c=_0x3d8cc8['emulator']?Is(_0x3d8cc8,Up):'https://'+_0x392238['config']['authDomain']+'/'+Fp,_0x3d5f5f={'apiKey':_0x3d8cc8['apiKey'],'appName':_0x392238['name'],'v':ct},_0x591acf=Bp['get'](_0x392238['config']['apiHost']);_0x591acf&&(_0x3d5f5f['eid']=_0x591acf);const _0x28dea5=_0x392238['_getFrameworks']();return _0x28dea5['length']&&(_0x3d5f5f['fw']=_0x28dea5['join'](',')),_0x10178c+'?'+at(_0x3d5f5f)['slice'](0x1);}async function Hp(_0x3deab6){const _0x2278ec=await Lp(_0x3deab6),_0x3d4d1b=X()['gapi'];return m(_0x3d4d1b,_0x3deab6,'internal-error'),_0x2278ec['open']({'where':document['body'],'url':Vp(_0x3deab6),'messageHandlersFilter':_0x3d4d1b['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x2e66b9=>new Promise(async(_0xa6654f,_0x81f385)=>{await _0x2e66b9['restyle']({'setHideOnLeave':!0x1});const _0x510be8=J(_0x3deab6,'network-request-failed'),_0x3599bf=X()['setTimeout'](()=>{_0x81f385(_0x510be8);},xp['get']());function _0x2c4d9f(){X()['clearTimeout'](_0x3599bf),_0xa6654f(_0x2e66b9);}_0x2e66b9['ping'](_0x2c4d9f)['then'](_0x2c4d9f,()=>{_0x81f385(_0x510be8);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x4ef549){this['window']=_0x4ef549,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x1e3d8f,_0x104240,_0x50a49c,_0x78c0eb=Gp,_0x3d2900=qp){const _0x18840b=Math['max']((window['screen']['availHeight']-_0x3d2900)/0x2,0x0)['toString'](),_0x22ed2c=Math['max']((window['screen']['availWidth']-_0x78c0eb)/0x2,0x0)['toString']();let _0x1686cd='';const _0x1f0b87={...$p,'width':_0x78c0eb['toString'](),'height':_0x3d2900['toString'](),'top':_0x18840b,'left':_0x22ed2c},_0x2fbe5a=W()['toLowerCase']();_0x50a49c&&(_0x1686cd=ba(_0x2fbe5a)?zp:_0x50a49c),Ta(_0x2fbe5a)&&(_0x104240=_0x104240||jp,_0x1f0b87['scrollbars']='yes');const _0x4f37c1=Object['entries'](_0x1f0b87)['reduce']((_0xf72d65,[_0x26732d,_0x158b39])=>''+_0xf72d65+_0x26732d+'='+_0x158b39+',','');if(Ef(_0x2fbe5a)&&_0x1686cd!=='_self')return Yp(_0x104240||'',_0x1686cd),new Dr(null);const _0x2fefe0=window['open'](_0x104240||'',_0x1686cd,_0x4f37c1);m(_0x2fefe0,_0x1e3d8f,'popup-blocked');try{_0x2fefe0['focus']();}catch{}return new Dr(_0x2fefe0);}function Yp(_0x861466,_0x3af1ab){const _0x47e519=document['createElement']('a');_0x47e519['href']=_0x861466,_0x47e519['target']=_0x3af1ab;const _0x3112ef=document['createEvent']('MouseEvent');_0x3112ef['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x47e519['dispatchEvent'](_0x3112ef);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x5c593c,_0xa2f2e9,_0x5e161d,_0x76061c,_0x279b3e,_0x26385a){m(_0x5c593c['config']['authDomain'],_0x5c593c,'auth-domain-config-required'),m(_0x5c593c['config']['apiKey'],_0x5c593c,'invalid-api-key');const _0x192db3={'apiKey':_0x5c593c['config']['apiKey'],'appName':_0x5c593c['name'],'authType':_0x5e161d,'redirectUrl':_0x76061c,'v':ct,'eventId':_0x279b3e};if(_0xa2f2e9 instanceof xa){_0xa2f2e9['setDefaultLanguage'](_0x5c593c['languageCode']),_0x192db3['providerId']=_0xa2f2e9['providerId']||'',hi(_0xa2f2e9['getCustomParameters']())||(_0x192db3['customParameters']=JSON['stringify'](_0xa2f2e9['getCustomParameters']()));for(const [_0x4e466f,_0x5efc67]of Object['entries']({}))_0x192db3[_0x4e466f]=_0x5efc67;}if(_0xa2f2e9 instanceof Qt){const _0x1813c9=_0xa2f2e9['getScopes']()['filter'](_0xe8b2db=>_0xe8b2db!=='');_0x1813c9['length']>0x0&&(_0x192db3['scopes']=_0x1813c9['join'](','));}_0x5c593c['tenantId']&&(_0x192db3['tid']=_0x5c593c['tenantId']);const _0x1a6387=_0x192db3;for(const _0x476557 of Object['keys'](_0x1a6387))_0x1a6387[_0x476557]===void 0x0&&delete _0x1a6387[_0x476557];const _0x43ca80=await _0x5c593c['_getAppCheckToken'](),_0x9a703e=_0x43ca80?'#'+Xp+'='+encodeURIComponent(_0x43ca80):'';return Zp(_0x5c593c)+'?'+at(_0x1a6387)['slice'](0x1)+_0x9a703e;}function Zp({config:_0x4dfc2f}){return _0x4dfc2f['emulator']?Is(_0x4dfc2f,Jp):'https://'+_0x4dfc2f['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x4afa09,_0x329285,_0x53aefa,_0x57fca0){var _0x304cf5;ae((_0x304cf5=this['eventManagers'][_0x4afa09['_key']()])==null?void 0x0:_0x304cf5['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2b9a71=await Mr(_0x4afa09,_0x329285,_0x53aefa,Ni(),_0x57fca0);return Kp(_0x4afa09,_0x2b9a71,bs());}async['_openRedirect'](_0x1b365d,_0x445693,_0x5b76be,_0x5d90a4){await this['_originValidation'](_0x1b365d);const _0x4c9ffd=await Mr(_0x1b365d,_0x445693,_0x5b76be,Ni(),_0x5d90a4);return ip(_0x4c9ffd),new Promise(()=>{});}['_initialize'](_0x2d7688){const _0x28a3f4=_0x2d7688['_key']();if(this['eventManagers'][_0x28a3f4]){const {manager:_0x13c449,promise:_0xcfd0ae}=this['eventManagers'][_0x28a3f4];return _0x13c449?Promise['resolve'](_0x13c449):(ae(_0xcfd0ae,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xcfd0ae);}const _0x1a41d1=this['initAndGetManager'](_0x2d7688);return this['eventManagers'][_0x28a3f4]={'promise':_0x1a41d1},_0x1a41d1['catch'](()=>{delete this['eventManagers'][_0x28a3f4];}),_0x1a41d1;}async['initAndGetManager'](_0x13440f){const _0x324564=await Hp(_0x13440f),_0x2e55d8=new bp(_0x13440f);return _0x324564['register']('authEvent',_0x326261=>(m(_0x326261==null?void 0x0:_0x326261['authEvent'],_0x13440f,'invalid-auth-event'),{'status':_0x2e55d8['onEvent'](_0x326261['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x13440f['_key']()]={'manager':_0x2e55d8},this['iframes'][_0x13440f['_key']()]=_0x324564,_0x2e55d8;}['_isIframeWebStorageSupported'](_0x5aab0,_0xecf17f){this['iframes'][_0x5aab0['_key']()]['send'](li,{'type':li},_0x2c04fd=>{var _0x1693f3;const _0x306f28=(_0x1693f3=_0x2c04fd==null?void 0x0:_0x2c04fd[0x0])==null?void 0x0:_0x1693f3[li];_0x306f28!==void 0x0&&_0xecf17f(!!_0x306f28),K(_0x5aab0,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5eb5fc){const _0x1d1496=_0x5eb5fc['_key']();return this['originValidationPromises'][_0x1d1496]||(this['originValidationPromises'][_0x1d1496]=Pp(_0x5eb5fc)),this['originValidationPromises'][_0x1d1496];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x49b1f2){this['auth']=_0x49b1f2,this['internalListeners']=new Map();}['getUid'](){var _0x3a062c;return this['assertAuthConfigured'](),((_0x3a062c=this['auth']['currentUser'])==null?void 0x0:_0x3a062c['uid'])||null;}async['getToken'](_0x1a173b){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1a173b)}:null;}['addAuthTokenListener'](_0x5920ae){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5920ae))return;const _0x2daa83=this['auth']['onIdTokenChanged'](_0x8900cc=>{_0x5920ae((_0x8900cc==null?void 0x0:_0x8900cc['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5920ae,_0x2daa83),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xe1de4e){this['assertAuthConfigured']();const _0x2aa985=this['internalListeners']['get'](_0xe1de4e);_0x2aa985&&(this['internalListeners']['delete'](_0xe1de4e),_0x2aa985(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x408573){switch(_0x408573){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x49390f){et(new Me('auth',(_0x3915d9,{options:_0x54d8ee})=>{const _0x225430=_0x3915d9['getProvider']('app')['getImmediate'](),_0x502caa=_0x3915d9['getProvider']('heartbeat'),_0x3a415f=_0x3915d9['getProvider']('app-check-internal'),{apiKey:_0x445dda,authDomain:_0x31a43a}=_0x225430['options'];m(_0x445dda&&!_0x445dda['includes'](':'),'invalid-api-key',{'appName':_0x225430['name']});const _0x48c3af={'apiKey':_0x445dda,'authDomain':_0x31a43a,'clientPlatform':_0x49390f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x49390f)},_0x51bc59=new bf(_0x225430,_0x502caa,_0x3a415f,_0x48c3af);return Lf(_0x51bc59,_0x54d8ee),_0x51bc59;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x19a4f6,_0x111641,_0x1cc186)=>{_0x19a4f6['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x2b6ad9=>{const _0x4f61f0=qe(_0x2b6ad9['getProvider']('auth')['getImmediate']());return(_0x1ecd84=>new n_(_0x1ecd84))(_0x4f61f0);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x49390f)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x5a7330=>async _0xd7de05=>{const _0xce3a84=_0xd7de05&&await _0xd7de05['getIdTokenResult'](),_0xc6cf5f=_0xce3a84&&(new Date()['getTime']()-Date['parse'](_0xce3a84['issuedAtTime']))/0x3e8;if(_0xc6cf5f&&_0xc6cf5f>o_)return;const _0x45388a=_0xce3a84==null?void 0x0:_0xce3a84['token'];Fr!==_0x45388a&&(Fr=_0x45388a,await fetch(_0x5a7330,{'method':_0x45388a?'POST':'DELETE','headers':_0x45388a?{'Authorization':'Bearer\x20'+_0x45388a}:{}}));};function O_(_0x382b7f=Qr()){const _0x526fb4=Ui(_0x382b7f,'auth');if(_0x526fb4['isInitialized']())return _0x526fb4['getImmediate']();const _0x2714d1=Mf(_0x382b7f,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x3a822e=Gr('authTokenSyncURL');if(_0x3a822e&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x423e70=new URL(_0x3a822e,location['origin']);if(location['origin']===_0x423e70['origin']){const _0x91ce7e=a_(_0x423e70['toString']());Jf(_0x2714d1,_0x91ce7e,()=>_0x91ce7e(_0x2714d1['currentUser'])),Qf(_0x2714d1,_0x1af238=>_0x91ce7e(_0x1af238));}}const _0x25e7ff=Hr('auth');return _0x25e7ff&&xf(_0x2714d1,'http://'+_0x25e7ff),_0x2714d1;}function c_(){var _0x4eeb25;return((_0x4eeb25=document['getElementsByTagName']('head'))==null?void 0x0:_0x4eeb25[0x0])??document;}Rf({'loadJS'(_0x2fbb58){return new Promise((_0x5a1a71,_0x6d423b)=>{const _0x2415c9=document['createElement']('script');_0x2415c9['setAttribute']('src',_0x2fbb58),_0x2415c9['onload']=_0x5a1a71,_0x2415c9['onerror']=_0x5707d4=>{const _0x534a7f=J('internal-error');_0x534a7f['customData']=_0x5707d4,_0x6d423b(_0x534a7f);},_0x2415c9['type']='text/javascript',_0x2415c9['charset']='UTF-8',c_()['appendChild'](_0x2415c9);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};