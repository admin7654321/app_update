const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3a01ec,_0x522509){if(!_0x3a01ec)throw ot(_0x522509);},ot=function(_0x31cc9b){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x31cc9b);},Wr=function(_0x3d8d90){const _0x17edba=[];let _0x23922f=0x0;for(let _0x249a5=0x0;_0x249a5<_0x3d8d90['length'];_0x249a5++){let _0x1d5ac4=_0x3d8d90['charCodeAt'](_0x249a5);_0x1d5ac4<0x80?_0x17edba[_0x23922f++]=_0x1d5ac4:_0x1d5ac4<0x800?(_0x17edba[_0x23922f++]=_0x1d5ac4>>0x6|0xc0,_0x17edba[_0x23922f++]=_0x1d5ac4&0x3f|0x80):(_0x1d5ac4&0xfc00)===0xd800&&_0x249a5+0x1<_0x3d8d90['length']&&(_0x3d8d90['charCodeAt'](_0x249a5+0x1)&0xfc00)===0xdc00?(_0x1d5ac4=0x10000+((_0x1d5ac4&0x3ff)<<0xa)+(_0x3d8d90['charCodeAt'](++_0x249a5)&0x3ff),_0x17edba[_0x23922f++]=_0x1d5ac4>>0x12|0xf0,_0x17edba[_0x23922f++]=_0x1d5ac4>>0xc&0x3f|0x80,_0x17edba[_0x23922f++]=_0x1d5ac4>>0x6&0x3f|0x80,_0x17edba[_0x23922f++]=_0x1d5ac4&0x3f|0x80):(_0x17edba[_0x23922f++]=_0x1d5ac4>>0xc|0xe0,_0x17edba[_0x23922f++]=_0x1d5ac4>>0x6&0x3f|0x80,_0x17edba[_0x23922f++]=_0x1d5ac4&0x3f|0x80);}return _0x17edba;},Za=function(_0x4a838a){const _0x2e2dd0=[];let _0x37ffcb=0x0,_0x1c39f2=0x0;for(;_0x37ffcb<_0x4a838a['length'];){const _0x4c227c=_0x4a838a[_0x37ffcb++];if(_0x4c227c<0x80)_0x2e2dd0[_0x1c39f2++]=String['fromCharCode'](_0x4c227c);else{if(_0x4c227c>0xbf&&_0x4c227c<0xe0){const _0x1ad985=_0x4a838a[_0x37ffcb++];_0x2e2dd0[_0x1c39f2++]=String['fromCharCode']((_0x4c227c&0x1f)<<0x6|_0x1ad985&0x3f);}else{if(_0x4c227c>0xef&&_0x4c227c<0x16d){const _0x4278c6=_0x4a838a[_0x37ffcb++],_0x3ed35e=_0x4a838a[_0x37ffcb++],_0x5a606d=_0x4a838a[_0x37ffcb++],_0x4fde54=((_0x4c227c&0x7)<<0x12|(_0x4278c6&0x3f)<<0xc|(_0x3ed35e&0x3f)<<0x6|_0x5a606d&0x3f)-0x10000;_0x2e2dd0[_0x1c39f2++]=String['fromCharCode'](0xd800+(_0x4fde54>>0xa)),_0x2e2dd0[_0x1c39f2++]=String['fromCharCode'](0xdc00+(_0x4fde54&0x3ff));}else{const _0x235e2c=_0x4a838a[_0x37ffcb++],_0x362362=_0x4a838a[_0x37ffcb++];_0x2e2dd0[_0x1c39f2++]=String['fromCharCode']((_0x4c227c&0xf)<<0xc|(_0x235e2c&0x3f)<<0x6|_0x362362&0x3f);}}}}return _0x2e2dd0['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x18258a,_0x2c3939){if(!Array['isArray'](_0x18258a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x61c6f=_0x2c3939?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x37cfc8=[];for(let _0x5d8b45=0x0;_0x5d8b45<_0x18258a['length'];_0x5d8b45+=0x3){const _0xe26caf=_0x18258a[_0x5d8b45],_0x451d1a=_0x5d8b45+0x1<_0x18258a['length'],_0x143938=_0x451d1a?_0x18258a[_0x5d8b45+0x1]:0x0,_0xc9386c=_0x5d8b45+0x2<_0x18258a['length'],_0xa44cb0=_0xc9386c?_0x18258a[_0x5d8b45+0x2]:0x0,_0x20b5f9=_0xe26caf>>0x2,_0x4939d4=(_0xe26caf&0x3)<<0x4|_0x143938>>0x4;let _0x4fc4e2=(_0x143938&0xf)<<0x2|_0xa44cb0>>0x6,_0x177709=_0xa44cb0&0x3f;_0xc9386c||(_0x177709=0x40,_0x451d1a||(_0x4fc4e2=0x40)),_0x37cfc8['push'](_0x61c6f[_0x20b5f9],_0x61c6f[_0x4939d4],_0x61c6f[_0x4fc4e2],_0x61c6f[_0x177709]);}return _0x37cfc8['join']('');},'encodeString'(_0x2a4c78,_0x388f2a){return this['HAS_NATIVE_SUPPORT']&&!_0x388f2a?btoa(_0x2a4c78):this['encodeByteArray'](Wr(_0x2a4c78),_0x388f2a);},'decodeString'(_0x112b4d,_0x267712){return this['HAS_NATIVE_SUPPORT']&&!_0x267712?atob(_0x112b4d):Za(this['decodeStringToByteArray'](_0x112b4d,_0x267712));},'decodeStringToByteArray'(_0x377891,_0x1bd179){this['init_']();const _0x163794=_0x1bd179?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x6f54a5=[];for(let _0xa9a226=0x0;_0xa9a226<_0x377891['length'];){const _0x2688eb=_0x163794[_0x377891['charAt'](_0xa9a226++)],_0x5434c1=_0xa9a226<_0x377891['length']?_0x163794[_0x377891['charAt'](_0xa9a226)]:0x0;++_0xa9a226;const _0x549704=_0xa9a226<_0x377891['length']?_0x163794[_0x377891['charAt'](_0xa9a226)]:0x40;++_0xa9a226;const _0x2eb939=_0xa9a226<_0x377891['length']?_0x163794[_0x377891['charAt'](_0xa9a226)]:0x40;if(++_0xa9a226,_0x2688eb==null||_0x5434c1==null||_0x549704==null||_0x2eb939==null)throw new ec();const _0x279110=_0x2688eb<<0x2|_0x5434c1>>0x4;if(_0x6f54a5['push'](_0x279110),_0x549704!==0x40){const _0x16df36=_0x5434c1<<0x4&0xf0|_0x549704>>0x2;if(_0x6f54a5['push'](_0x16df36),_0x2eb939!==0x40){const _0x5900aa=_0x549704<<0x6&0xc0|_0x2eb939;_0x6f54a5['push'](_0x5900aa);}}}return _0x6f54a5;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4155b4=0x0;_0x4155b4<this['ENCODED_VALS']['length'];_0x4155b4++)this['byteToCharMap_'][_0x4155b4]=this['ENCODED_VALS']['charAt'](_0x4155b4),this['charToByteMap_'][this['byteToCharMap_'][_0x4155b4]]=_0x4155b4,this['byteToCharMapWebSafe_'][_0x4155b4]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4155b4),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4155b4]]=_0x4155b4,_0x4155b4>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4155b4)]=_0x4155b4,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4155b4)]=_0x4155b4);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x160b22){const _0x316364=Wr(_0x160b22);return Di['encodeByteArray'](_0x316364,!0x0);},an=function(_0x5876b0){return Br(_0x5876b0)['replace'](/\./g,'');},cn=function(_0x4e4932){try{return Di['decodeString'](_0x4e4932,!0x0);}catch(_0x1f9c91){console['error']('base64Decode\x20failed:\x20',_0x1f9c91);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x5331f7){return Vr(void 0x0,_0x5331f7);}function Vr(_0x175bcb,_0xed6f2d){if(!(_0xed6f2d instanceof Object))return _0xed6f2d;switch(_0xed6f2d['constructor']){case Date:const _0x5ac503=_0xed6f2d;return new Date(_0x5ac503['getTime']());case Object:_0x175bcb===void 0x0&&(_0x175bcb={});break;case Array:_0x175bcb=[];break;default:return _0xed6f2d;}for(const _0x3d613f in _0xed6f2d)!_0xed6f2d['hasOwnProperty'](_0x3d613f)||!nc(_0x3d613f)||(_0x175bcb[_0x3d613f]=Vr(_0x175bcb[_0x3d613f],_0xed6f2d[_0x3d613f]));return _0x175bcb;}function nc(_0x4d3931){return _0x4d3931!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x399457=As['__FIREBASE_DEFAULTS__'];if(_0x399457)return JSON['parse'](_0x399457);},oc=()=>{if(typeof document>'u')return;let _0x34fffb;try{_0x34fffb=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1bd8b5=_0x34fffb&&cn(_0x34fffb[0x1]);return _0x1bd8b5&&JSON['parse'](_0x1bd8b5);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x442529){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x442529);return;}},Hr=_0xd2fc67=>{var _0x54cbd7,_0x17528c;return(_0x17528c=(_0x54cbd7=Mi())==null?void 0x0:_0x54cbd7['emulatorHosts'])==null?void 0x0:_0x17528c[_0xd2fc67];},ac=_0x4c3439=>{const _0x3bccff=Hr(_0x4c3439);if(!_0x3bccff)return;const _0xffc593=_0x3bccff['lastIndexOf'](':');if(_0xffc593<=0x0||_0xffc593+0x1===_0x3bccff['length'])throw new Error('Invalid\x20host\x20'+_0x3bccff+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0xd6dd31=parseInt(_0x3bccff['substring'](_0xffc593+0x1),0xa);return _0x3bccff[0x0]==='['?[_0x3bccff['substring'](0x1,_0xffc593-0x1),_0xd6dd31]:[_0x3bccff['substring'](0x0,_0xffc593),_0xd6dd31];},$r=()=>{var _0x1b04eb;return(_0x1b04eb=Mi())==null?void 0x0:_0x1b04eb['config'];},Gr=_0xfddf83=>{var _0x1afe06;return(_0x1afe06=Mi())==null?void 0x0:_0x1afe06['_'+_0xfddf83];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1165ce,_0x7e7a68)=>{this['resolve']=_0x1165ce,this['reject']=_0x7e7a68;});}['wrapCallback'](_0x801ac1){return(_0x529109,_0x339ca8)=>{_0x529109?this['reject'](_0x529109):this['resolve'](_0x339ca8),typeof _0x801ac1=='function'&&(this['promise']['catch'](()=>{}),_0x801ac1['length']===0x1?_0x801ac1(_0x529109):_0x801ac1(_0x529109,_0x339ca8));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x38a639,_0x2a167c){if(_0x38a639['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x52a100={'alg':'none','type':'JWT'},_0x2acbd1=_0x2a167c||'demo-project',_0x53f489=_0x38a639['iat']||0x0,_0xdc8284=_0x38a639['sub']||_0x38a639['user_id'];if(!_0xdc8284)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x20094e={'iss':'https://securetoken.google.com/'+_0x2acbd1,'aud':_0x2acbd1,'iat':_0x53f489,'exp':_0x53f489+0xe10,'auth_time':_0x53f489,'sub':_0xdc8284,'user_id':_0xdc8284,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x38a639};return[an(JSON['stringify'](_0x52a100)),an(JSON['stringify'](_0x20094e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x3517ad=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3517ad=='object'&&_0x3517ad['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x32b5ee=W();return _0x32b5ee['indexOf']('MSIE\x20')>=0x0||_0x32b5ee['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x1b8fce,_0x1d5f78)=>{try{let _0x2f0f59=!0x0;const _0x70c9a3='validate-browser-context-for-indexeddb-analytics-module',_0x6e15d9=self['indexedDB']['open'](_0x70c9a3);_0x6e15d9['onsuccess']=()=>{_0x6e15d9['result']['close'](),_0x2f0f59||self['indexedDB']['deleteDatabase'](_0x70c9a3),_0x1b8fce(!0x0);},_0x6e15d9['onupgradeneeded']=()=>{_0x2f0f59=!0x1;},_0x6e15d9['onerror']=()=>{var _0x50d57f;_0x1d5f78(((_0x50d57f=_0x6e15d9['error'])==null?void 0x0:_0x50d57f['message'])||'');};}catch(_0x59b5bb){_0x1d5f78(_0x59b5bb);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x59a6ea,_0x5d1b64,_0x29d379){super(_0x5d1b64),this['code']=_0x59a6ea,this['customData']=_0x29d379,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x53e210,_0x3bf2d4,_0x31c817){this['service']=_0x53e210,this['serviceName']=_0x3bf2d4,this['errors']=_0x31c817;}['create'](_0x8caecc,..._0x87fc0b){const _0x3bd852=_0x87fc0b[0x0]||{},_0x2fe6c8=this['service']+'/'+_0x8caecc,_0x36bf0b=this['errors'][_0x8caecc],_0x4b2bc4=_0x36bf0b?gc(_0x36bf0b,_0x3bd852):'Error',_0x58caca=this['serviceName']+':\x20'+_0x4b2bc4+'\x20('+_0x2fe6c8+').';return new Se(_0x2fe6c8,_0x58caca,_0x3bd852);}}function gc(_0x3f5543,_0xddc9d6){return _0x3f5543['replace'](mc,(_0x478142,_0x3a4faf)=>{const _0x43e916=_0xddc9d6[_0x3a4faf];return _0x43e916!=null?String(_0x43e916):'<'+_0x3a4faf+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x823047){return JSON['parse'](_0x823047);}function O(_0x113392){return JSON['stringify'](_0x113392);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x1a91ed){let _0x33ea0b={},_0x2b5b3a={},_0x5eeb55={},_0x206636='';try{const _0x5f0d92=_0x1a91ed['split']('.');_0x33ea0b=bt(cn(_0x5f0d92[0x0])||''),_0x2b5b3a=bt(cn(_0x5f0d92[0x1])||''),_0x206636=_0x5f0d92[0x2],_0x5eeb55=_0x2b5b3a['d']||{},delete _0x2b5b3a['d'];}catch{}return{'header':_0x33ea0b,'claims':_0x2b5b3a,'data':_0x5eeb55,'signature':_0x206636};},yc=function(_0x1dcd79){const _0x34c77c=zr(_0x1dcd79),_0x47034c=_0x34c77c['claims'];return!!_0x47034c&&typeof _0x47034c=='object'&&_0x47034c['hasOwnProperty']('iat');},vc=function(_0x2f40a0){const _0x1f91fc=zr(_0x2f40a0)['claims'];return typeof _0x1f91fc=='object'&&_0x1f91fc['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x277214,_0x4fd67e){return Object['prototype']['hasOwnProperty']['call'](_0x277214,_0x4fd67e);}function Oe(_0x124639,_0x5cf363){if(Object['prototype']['hasOwnProperty']['call'](_0x124639,_0x5cf363))return _0x124639[_0x5cf363];}function hi(_0x52c190){for(const _0x385cdf in _0x52c190)if(Object['prototype']['hasOwnProperty']['call'](_0x52c190,_0x385cdf))return!0x1;return!0x0;}function ln(_0x5606b1,_0x158207,_0x3c8d90){const _0x28c38e={};for(const _0x53f00a in _0x5606b1)Object['prototype']['hasOwnProperty']['call'](_0x5606b1,_0x53f00a)&&(_0x28c38e[_0x53f00a]=_0x158207['call'](_0x3c8d90,_0x5606b1[_0x53f00a],_0x53f00a,_0x5606b1));return _0x28c38e;}function De(_0x1fa0ca,_0x44ff4c){if(_0x1fa0ca===_0x44ff4c)return!0x0;const _0xa85a3b=Object['keys'](_0x1fa0ca),_0x3fd986=Object['keys'](_0x44ff4c);for(const _0x24abc1 of _0xa85a3b){if(!_0x3fd986['includes'](_0x24abc1))return!0x1;const _0x26ca7c=_0x1fa0ca[_0x24abc1],_0x40483a=_0x44ff4c[_0x24abc1];if(ks(_0x26ca7c)&&ks(_0x40483a)){if(!De(_0x26ca7c,_0x40483a))return!0x1;}else{if(_0x26ca7c!==_0x40483a)return!0x1;}}for(const _0xea8f0b of _0x3fd986)if(!_0xa85a3b['includes'](_0xea8f0b))return!0x1;return!0x0;}function ks(_0x209d14){return _0x209d14!==null&&typeof _0x209d14=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x233f68){const _0x2149c3=[];for(const [_0x45aafb,_0xaa49c7]of Object['entries'](_0x233f68))Array['isArray'](_0xaa49c7)?_0xaa49c7['forEach'](_0x1f9428=>{_0x2149c3['push'](encodeURIComponent(_0x45aafb)+'='+encodeURIComponent(_0x1f9428));}):_0x2149c3['push'](encodeURIComponent(_0x45aafb)+'='+encodeURIComponent(_0xaa49c7));return _0x2149c3['length']?'&'+_0x2149c3['join']('&'):'';}function yt(_0x1e6ebd){const _0x4c8a81={};return _0x1e6ebd['replace'](/^\?/,'')['split']('&')['forEach'](_0x860a11=>{if(_0x860a11){const [_0xa56b3c,_0x34f8d8]=_0x860a11['split']('=');_0x4c8a81[decodeURIComponent(_0xa56b3c)]=decodeURIComponent(_0x34f8d8);}}),_0x4c8a81;}function vt(_0x43437e){const _0x9fe9a9=_0x43437e['indexOf']('?');if(!_0x9fe9a9)return'';const _0x26d281=_0x43437e['indexOf']('#',_0x9fe9a9);return _0x43437e['substring'](_0x9fe9a9,_0x26d281>0x0?_0x26d281:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x33c7c8=0x1;_0x33c7c8<this['blockSize'];++_0x33c7c8)this['pad_'][_0x33c7c8]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4299fe,_0x77b7c6){_0x77b7c6||(_0x77b7c6=0x0);const _0x53e978=this['W_'];if(typeof _0x4299fe=='string'){for(let _0x5bcb05=0x0;_0x5bcb05<0x10;_0x5bcb05++)_0x53e978[_0x5bcb05]=_0x4299fe['charCodeAt'](_0x77b7c6)<<0x18|_0x4299fe['charCodeAt'](_0x77b7c6+0x1)<<0x10|_0x4299fe['charCodeAt'](_0x77b7c6+0x2)<<0x8|_0x4299fe['charCodeAt'](_0x77b7c6+0x3),_0x77b7c6+=0x4;}else{for(let _0x5eb68b=0x0;_0x5eb68b<0x10;_0x5eb68b++)_0x53e978[_0x5eb68b]=_0x4299fe[_0x77b7c6]<<0x18|_0x4299fe[_0x77b7c6+0x1]<<0x10|_0x4299fe[_0x77b7c6+0x2]<<0x8|_0x4299fe[_0x77b7c6+0x3],_0x77b7c6+=0x4;}for(let _0x2b24f8=0x10;_0x2b24f8<0x50;_0x2b24f8++){const _0x4b2873=_0x53e978[_0x2b24f8-0x3]^_0x53e978[_0x2b24f8-0x8]^_0x53e978[_0x2b24f8-0xe]^_0x53e978[_0x2b24f8-0x10];_0x53e978[_0x2b24f8]=(_0x4b2873<<0x1|_0x4b2873>>>0x1f)&0xffffffff;}let _0x2f0017=this['chain_'][0x0],_0x55d1f9=this['chain_'][0x1],_0x42ea67=this['chain_'][0x2],_0x302ef8=this['chain_'][0x3],_0x40af66=this['chain_'][0x4],_0x3b89e8,_0x3f4267;for(let _0x3ea0dd=0x0;_0x3ea0dd<0x50;_0x3ea0dd++){_0x3ea0dd<0x28?_0x3ea0dd<0x14?(_0x3b89e8=_0x302ef8^_0x55d1f9&(_0x42ea67^_0x302ef8),_0x3f4267=0x5a827999):(_0x3b89e8=_0x55d1f9^_0x42ea67^_0x302ef8,_0x3f4267=0x6ed9eba1):_0x3ea0dd<0x3c?(_0x3b89e8=_0x55d1f9&_0x42ea67|_0x302ef8&(_0x55d1f9|_0x42ea67),_0x3f4267=0x8f1bbcdc):(_0x3b89e8=_0x55d1f9^_0x42ea67^_0x302ef8,_0x3f4267=0xca62c1d6);const _0x2b02d0=(_0x2f0017<<0x5|_0x2f0017>>>0x1b)+_0x3b89e8+_0x40af66+_0x3f4267+_0x53e978[_0x3ea0dd]&0xffffffff;_0x40af66=_0x302ef8,_0x302ef8=_0x42ea67,_0x42ea67=(_0x55d1f9<<0x1e|_0x55d1f9>>>0x2)&0xffffffff,_0x55d1f9=_0x2f0017,_0x2f0017=_0x2b02d0;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2f0017&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x55d1f9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x42ea67&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x302ef8&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x40af66&0xffffffff;}['update'](_0x2b7689,_0x865de5){if(_0x2b7689==null)return;_0x865de5===void 0x0&&(_0x865de5=_0x2b7689['length']);const _0x27fe00=_0x865de5-this['blockSize'];let _0x5b6eba=0x0;const _0x2103f5=this['buf_'];let _0x382fd7=this['inbuf_'];for(;_0x5b6eba<_0x865de5;){if(_0x382fd7===0x0){for(;_0x5b6eba<=_0x27fe00;)this['compress_'](_0x2b7689,_0x5b6eba),_0x5b6eba+=this['blockSize'];}if(typeof _0x2b7689=='string'){for(;_0x5b6eba<_0x865de5;)if(_0x2103f5[_0x382fd7]=_0x2b7689['charCodeAt'](_0x5b6eba),++_0x382fd7,++_0x5b6eba,_0x382fd7===this['blockSize']){this['compress_'](_0x2103f5),_0x382fd7=0x0;break;}}else{for(;_0x5b6eba<_0x865de5;)if(_0x2103f5[_0x382fd7]=_0x2b7689[_0x5b6eba],++_0x382fd7,++_0x5b6eba,_0x382fd7===this['blockSize']){this['compress_'](_0x2103f5),_0x382fd7=0x0;break;}}}this['inbuf_']=_0x382fd7,this['total_']+=_0x865de5;}['digest'](){const _0x3205e7=[];let _0x176983=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4d200d=this['blockSize']-0x1;_0x4d200d>=0x38;_0x4d200d--)this['buf_'][_0x4d200d]=_0x176983&0xff,_0x176983/=0x100;this['compress_'](this['buf_']);let _0x1fef60=0x0;for(let _0x2cf5ac=0x0;_0x2cf5ac<0x5;_0x2cf5ac++)for(let _0x1dafb0=0x18;_0x1dafb0>=0x0;_0x1dafb0-=0x8)_0x3205e7[_0x1fef60]=this['chain_'][_0x2cf5ac]>>_0x1dafb0&0xff,++_0x1fef60;return _0x3205e7;}}function Ic(_0x8b7ce5,_0x51a0ce){const _0x5f5bca=new wc(_0x8b7ce5,_0x51a0ce);return _0x5f5bca['subscribe']['bind'](_0x5f5bca);}class wc{constructor(_0x23103e,_0x542595){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x542595,this['task']['then'](()=>{_0x23103e(this);})['catch'](_0x284849=>{this['error'](_0x284849);});}['next'](_0x503cf5){this['forEachObserver'](_0x1dda5d=>{_0x1dda5d['next'](_0x503cf5);});}['error'](_0x863fd3){this['forEachObserver'](_0x462a1b=>{_0x462a1b['error'](_0x863fd3);}),this['close'](_0x863fd3);}['complete'](){this['forEachObserver'](_0x4e86aa=>{_0x4e86aa['complete']();}),this['close']();}['subscribe'](_0x396da5,_0x152679,_0x4df51c){let _0x384373;if(_0x396da5===void 0x0&&_0x152679===void 0x0&&_0x4df51c===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x396da5,['next','error','complete'])?_0x384373=_0x396da5:_0x384373={'next':_0x396da5,'error':_0x152679,'complete':_0x4df51c},_0x384373['next']===void 0x0&&(_0x384373['next']=Qn),_0x384373['error']===void 0x0&&(_0x384373['error']=Qn),_0x384373['complete']===void 0x0&&(_0x384373['complete']=Qn);const _0x2fde5a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x384373['error'](this['finalError']):_0x384373['complete']();}catch{}}),this['observers']['push'](_0x384373),_0x2fde5a;}['unsubscribeOne'](_0x5ef593){this['observers']===void 0x0||this['observers'][_0x5ef593]===void 0x0||(delete this['observers'][_0x5ef593],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2ab798){if(!this['finalized']){for(let _0x1bfd87=0x0;_0x1bfd87<this['observers']['length'];_0x1bfd87++)this['sendOne'](_0x1bfd87,_0x2ab798);}}['sendOne'](_0x33813a,_0x341398){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x33813a]!==void 0x0)try{_0x341398(this['observers'][_0x33813a]);}catch(_0x184a3a){typeof console<'u'&&console['error']&&console['error'](_0x184a3a);}});}['close'](_0x4bee77){this['finalized']||(this['finalized']=!0x0,_0x4bee77!==void 0x0&&(this['finalError']=_0x4bee77),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x10be97,_0x29e950){if(typeof _0x10be97!='object'||_0x10be97===null)return!0x1;for(const _0x4b17f5 of _0x29e950)if(_0x4b17f5 in _0x10be97&&typeof _0x10be97[_0x4b17f5]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x4f7475,_0x591b60){return _0x4f7475+'\x20failed:\x20'+_0x591b60+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x5394f1){const _0x40b260=[];let _0x5cb1dc=0x0;for(let _0x4c4013=0x0;_0x4c4013<_0x5394f1['length'];_0x4c4013++){let _0x43edc3=_0x5394f1['charCodeAt'](_0x4c4013);if(_0x43edc3>=0xd800&&_0x43edc3<=0xdbff){const _0x171b2d=_0x43edc3-0xd800;_0x4c4013++,f(_0x4c4013<_0x5394f1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x7f7cc2=_0x5394f1['charCodeAt'](_0x4c4013)-0xdc00;_0x43edc3=0x10000+(_0x171b2d<<0xa)+_0x7f7cc2;}_0x43edc3<0x80?_0x40b260[_0x5cb1dc++]=_0x43edc3:_0x43edc3<0x800?(_0x40b260[_0x5cb1dc++]=_0x43edc3>>0x6|0xc0,_0x40b260[_0x5cb1dc++]=_0x43edc3&0x3f|0x80):_0x43edc3<0x10000?(_0x40b260[_0x5cb1dc++]=_0x43edc3>>0xc|0xe0,_0x40b260[_0x5cb1dc++]=_0x43edc3>>0x6&0x3f|0x80,_0x40b260[_0x5cb1dc++]=_0x43edc3&0x3f|0x80):(_0x40b260[_0x5cb1dc++]=_0x43edc3>>0x12|0xf0,_0x40b260[_0x5cb1dc++]=_0x43edc3>>0xc&0x3f|0x80,_0x40b260[_0x5cb1dc++]=_0x43edc3>>0x6&0x3f|0x80,_0x40b260[_0x5cb1dc++]=_0x43edc3&0x3f|0x80);}return _0x40b260;},Pn=function(_0x563f2c){let _0xb4a6a0=0x0;for(let _0x379527=0x0;_0x379527<_0x563f2c['length'];_0x379527++){const _0x2a7725=_0x563f2c['charCodeAt'](_0x379527);_0x2a7725<0x80?_0xb4a6a0++:_0x2a7725<0x800?_0xb4a6a0+=0x2:_0x2a7725>=0xd800&&_0x2a7725<=0xdbff?(_0xb4a6a0+=0x4,_0x379527++):_0xb4a6a0+=0x3;}return _0xb4a6a0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x1ec50b){return _0x1ec50b&&_0x1ec50b['_delegate']?_0x1ec50b['_delegate']:_0x1ec50b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x40c06b){try{return(_0x40c06b['startsWith']('http://')||_0x40c06b['startsWith']('https://')?new URL(_0x40c06b)['hostname']:_0x40c06b)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x571cd3){return(await fetch(_0x571cd3,{'credentials':'include'}))['ok'];}class Me{constructor(_0x480a32,_0x301d9f,_0x4b77a2){this['name']=_0x480a32,this['instanceFactory']=_0x301d9f,this['type']=_0x4b77a2,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4e6641){return this['instantiationMode']=_0x4e6641,this;}['setMultipleInstances'](_0x2304b9){return this['multipleInstances']=_0x2304b9,this;}['setServiceProps'](_0x30098a){return this['serviceProps']=_0x30098a,this;}['setInstanceCreatedCallback'](_0x32e642){return this['onInstanceCreated']=_0x32e642,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xc5d34d,_0x247039){this['name']=_0xc5d34d,this['container']=_0x247039,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4c1803){const _0x5bd40a=this['normalizeInstanceIdentifier'](_0x4c1803);if(!this['instancesDeferred']['has'](_0x5bd40a)){const _0x15f0c5=new Ve();if(this['instancesDeferred']['set'](_0x5bd40a,_0x15f0c5),this['isInitialized'](_0x5bd40a)||this['shouldAutoInitialize']())try{const _0x5ad8d6=this['getOrInitializeService']({'instanceIdentifier':_0x5bd40a});_0x5ad8d6&&_0x15f0c5['resolve'](_0x5ad8d6);}catch{}}return this['instancesDeferred']['get'](_0x5bd40a)['promise'];}['getImmediate'](_0x318882){const _0x48a8fb=this['normalizeInstanceIdentifier'](_0x318882==null?void 0x0:_0x318882['identifier']),_0x2bb335=(_0x318882==null?void 0x0:_0x318882['optional'])??!0x1;if(this['isInitialized'](_0x48a8fb)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x48a8fb});}catch(_0x162ed7){if(_0x2bb335)return null;throw _0x162ed7;}else{if(_0x2bb335)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xa68bc1){if(_0xa68bc1['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xa68bc1['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xa68bc1,!!this['shouldAutoInitialize']()){if(Rc(_0xa68bc1))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1820d9,_0x31ffcb]of this['instancesDeferred']['entries']()){const _0x2b424b=this['normalizeInstanceIdentifier'](_0x1820d9);try{const _0x135605=this['getOrInitializeService']({'instanceIdentifier':_0x2b424b});_0x31ffcb['resolve'](_0x135605);}catch{}}}}['clearInstance'](_0x511625=ke){this['instancesDeferred']['delete'](_0x511625),this['instancesOptions']['delete'](_0x511625),this['instances']['delete'](_0x511625);}async['delete'](){const _0x278947=Array['from'](this['instances']['values']());await Promise['all']([..._0x278947['filter'](_0x229163=>'INTERNAL'in _0x229163)['map'](_0xc5943f=>_0xc5943f['INTERNAL']['delete']()),..._0x278947['filter'](_0x537e58=>'_delete'in _0x537e58)['map'](_0x3c6fb5=>_0x3c6fb5['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x363f28=ke){return this['instances']['has'](_0x363f28);}['getOptions'](_0x39608d=ke){return this['instancesOptions']['get'](_0x39608d)||{};}['initialize'](_0x3edf40={}){const {options:_0x2eb621={}}=_0x3edf40,_0x1aa006=this['normalizeInstanceIdentifier'](_0x3edf40['instanceIdentifier']);if(this['isInitialized'](_0x1aa006))throw Error(this['name']+'('+_0x1aa006+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x13428b=this['getOrInitializeService']({'instanceIdentifier':_0x1aa006,'options':_0x2eb621});for(const [_0x7d0102,_0xa3b20c]of this['instancesDeferred']['entries']()){const _0x37cac4=this['normalizeInstanceIdentifier'](_0x7d0102);_0x1aa006===_0x37cac4&&_0xa3b20c['resolve'](_0x13428b);}return _0x13428b;}['onInit'](_0x31f068,_0x4c9c04){const _0x3ed7e2=this['normalizeInstanceIdentifier'](_0x4c9c04),_0x28f218=this['onInitCallbacks']['get'](_0x3ed7e2)??new Set();_0x28f218['add'](_0x31f068),this['onInitCallbacks']['set'](_0x3ed7e2,_0x28f218);const _0x289a9f=this['instances']['get'](_0x3ed7e2);return _0x289a9f&&_0x31f068(_0x289a9f,_0x3ed7e2),()=>{_0x28f218['delete'](_0x31f068);};}['invokeOnInitCallbacks'](_0x42075f,_0x2974bd){const _0x526e9f=this['onInitCallbacks']['get'](_0x2974bd);if(_0x526e9f){for(const _0x2bf6a6 of _0x526e9f)try{_0x2bf6a6(_0x42075f,_0x2974bd);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1e8096,options:_0x12ae34={}}){let _0x2fb8ab=this['instances']['get'](_0x1e8096);if(!_0x2fb8ab&&this['component']&&(_0x2fb8ab=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x1e8096),'options':_0x12ae34}),this['instances']['set'](_0x1e8096,_0x2fb8ab),this['instancesOptions']['set'](_0x1e8096,_0x12ae34),this['invokeOnInitCallbacks'](_0x2fb8ab,_0x1e8096),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1e8096,_0x2fb8ab);}catch{}return _0x2fb8ab||null;}['normalizeInstanceIdentifier'](_0x4e2d42=ke){return this['component']?this['component']['multipleInstances']?_0x4e2d42:ke:_0x4e2d42;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x58975c){return _0x58975c===ke?void 0x0:_0x58975c;}function Rc(_0x322458){return _0x322458['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1efc8c){this['name']=_0x1efc8c,this['providers']=new Map();}['addComponent'](_0x363383){const _0x2c14d9=this['getProvider'](_0x363383['name']);if(_0x2c14d9['isComponentSet']())throw new Error('Component\x20'+_0x363383['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2c14d9['setComponent'](_0x363383);}['addOrOverwriteComponent'](_0x41d5ae){this['getProvider'](_0x41d5ae['name'])['isComponentSet']()&&this['providers']['delete'](_0x41d5ae['name']),this['addComponent'](_0x41d5ae);}['getProvider'](_0x44b5ce){if(this['providers']['has'](_0x44b5ce))return this['providers']['get'](_0x44b5ce);const _0x2d6b8a=new Sc(_0x44b5ce,this);return this['providers']['set'](_0x44b5ce,_0x2d6b8a),_0x2d6b8a;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3d9b4d){_0x3d9b4d[_0x3d9b4d['DEBUG']=0x0]='DEBUG',_0x3d9b4d[_0x3d9b4d['VERBOSE']=0x1]='VERBOSE',_0x3d9b4d[_0x3d9b4d['INFO']=0x2]='INFO',_0x3d9b4d[_0x3d9b4d['WARN']=0x3]='WARN',_0x3d9b4d[_0x3d9b4d['ERROR']=0x4]='ERROR',_0x3d9b4d[_0x3d9b4d['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x4e9bee,_0x26be91,..._0xe0085a)=>{if(_0x26be91<_0x4e9bee['logLevel'])return;const _0x24001a=new Date()['toISOString'](),_0x84dab3=Pc[_0x26be91];if(_0x84dab3)console[_0x84dab3]('['+_0x24001a+']\x20\x20'+_0x4e9bee['name']+':',..._0xe0085a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x26be91+')');};class xi{constructor(_0x442c55){this['name']=_0x442c55,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x20316c){if(!(_0x20316c in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x20316c+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x20316c;}['setLogLevel'](_0xb52aea){this['_logLevel']=typeof _0xb52aea=='string'?kc[_0xb52aea]:_0xb52aea;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x466303){if(typeof _0x466303!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x466303;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x38fbf7){this['_userLogHandler']=_0x38fbf7;}['debug'](..._0x375308){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x375308),this['_logHandler'](this,T['DEBUG'],..._0x375308);}['log'](..._0x262aaf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x262aaf),this['_logHandler'](this,T['VERBOSE'],..._0x262aaf);}['info'](..._0x3b02ca){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3b02ca),this['_logHandler'](this,T['INFO'],..._0x3b02ca);}['warn'](..._0x193195){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x193195),this['_logHandler'](this,T['WARN'],..._0x193195);}['error'](..._0x489cb5){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x489cb5),this['_logHandler'](this,T['ERROR'],..._0x489cb5);}}const Dc=(_0x511168,_0x3f2d0e)=>_0x3f2d0e['some'](_0x343803=>_0x511168 instanceof _0x343803);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x848e51){const _0x46872e=new Promise((_0x5eb8a5,_0x133bcf)=>{const _0x423740=()=>{_0x848e51['removeEventListener']('success',_0x1d6eb3),_0x848e51['removeEventListener']('error',_0x224b90);},_0x1d6eb3=()=>{_0x5eb8a5(_e(_0x848e51['result'])),_0x423740();},_0x224b90=()=>{_0x133bcf(_0x848e51['error']),_0x423740();};_0x848e51['addEventListener']('success',_0x1d6eb3),_0x848e51['addEventListener']('error',_0x224b90);});return _0x46872e['then'](_0x5a52f4=>{_0x5a52f4 instanceof IDBCursor&&Kr['set'](_0x5a52f4,_0x848e51);})['catch'](()=>{}),Fi['set'](_0x46872e,_0x848e51),_0x46872e;}function Fc(_0x1fed00){if(ui['has'](_0x1fed00))return;const _0x59c33e=new Promise((_0xe665e4,_0x3f2f15)=>{const _0x3fb556=()=>{_0x1fed00['removeEventListener']('complete',_0x58bcd8),_0x1fed00['removeEventListener']('error',_0x19196a),_0x1fed00['removeEventListener']('abort',_0x19196a);},_0x58bcd8=()=>{_0xe665e4(),_0x3fb556();},_0x19196a=()=>{_0x3f2f15(_0x1fed00['error']||new DOMException('AbortError','AbortError')),_0x3fb556();};_0x1fed00['addEventListener']('complete',_0x58bcd8),_0x1fed00['addEventListener']('error',_0x19196a),_0x1fed00['addEventListener']('abort',_0x19196a);});ui['set'](_0x1fed00,_0x59c33e);}let di={'get'(_0x42401b,_0x2d5727,_0x523965){if(_0x42401b instanceof IDBTransaction){if(_0x2d5727==='done')return ui['get'](_0x42401b);if(_0x2d5727==='objectStoreNames')return _0x42401b['objectStoreNames']||Yr['get'](_0x42401b);if(_0x2d5727==='store')return _0x523965['objectStoreNames'][0x1]?void 0x0:_0x523965['objectStore'](_0x523965['objectStoreNames'][0x0]);}return _e(_0x42401b[_0x2d5727]);},'set'(_0x37f83f,_0x4b220,_0x3da531){return _0x37f83f[_0x4b220]=_0x3da531,!0x0;},'has'(_0x198af9,_0x32754b){return _0x198af9 instanceof IDBTransaction&&(_0x32754b==='done'||_0x32754b==='store')?!0x0:_0x32754b in _0x198af9;}};function Uc(_0x2aae41){di=_0x2aae41(di);}function Wc(_0x452d22){return _0x452d22===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x455a8c,..._0x51d1d3){const _0x7c6595=_0x452d22['call'](Xn(this),_0x455a8c,..._0x51d1d3);return Yr['set'](_0x7c6595,_0x455a8c['sort']?_0x455a8c['sort']():[_0x455a8c]),_e(_0x7c6595);}:Lc()['includes'](_0x452d22)?function(..._0x1d027c){return _0x452d22['apply'](Xn(this),_0x1d027c),_e(Kr['get'](this));}:function(..._0x38e7d5){return _e(_0x452d22['apply'](Xn(this),_0x38e7d5));};}function Bc(_0x110180){return typeof _0x110180=='function'?Wc(_0x110180):(_0x110180 instanceof IDBTransaction&&Fc(_0x110180),Dc(_0x110180,Mc())?new Proxy(_0x110180,di):_0x110180);}function _e(_0x20e05a){if(_0x20e05a instanceof IDBRequest)return xc(_0x20e05a);if(Jn['has'](_0x20e05a))return Jn['get'](_0x20e05a);const _0x210efc=Bc(_0x20e05a);return _0x210efc!==_0x20e05a&&(Jn['set'](_0x20e05a,_0x210efc),Fi['set'](_0x210efc,_0x20e05a)),_0x210efc;}const Xn=_0x59e0fd=>Fi['get'](_0x59e0fd);function Vc(_0x4b896c,_0x3923bd,{blocked:_0x56599f,upgrade:_0x12851f,blocking:_0x5c89c0,terminated:_0x304ff6}={}){const _0x5bee00=indexedDB['open'](_0x4b896c,_0x3923bd),_0x572287=_e(_0x5bee00);return _0x12851f&&_0x5bee00['addEventListener']('upgradeneeded',_0x46ba4f=>{_0x12851f(_e(_0x5bee00['result']),_0x46ba4f['oldVersion'],_0x46ba4f['newVersion'],_e(_0x5bee00['transaction']),_0x46ba4f);}),_0x56599f&&_0x5bee00['addEventListener']('blocked',_0x1df173=>_0x56599f(_0x1df173['oldVersion'],_0x1df173['newVersion'],_0x1df173)),_0x572287['then'](_0x1eaf97=>{_0x304ff6&&_0x1eaf97['addEventListener']('close',()=>_0x304ff6()),_0x5c89c0&&_0x1eaf97['addEventListener']('versionchange',_0x195740=>_0x5c89c0(_0x195740['oldVersion'],_0x195740['newVersion'],_0x195740));})['catch'](()=>{}),_0x572287;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x43faf9,_0x5b3099){if(!(_0x43faf9 instanceof IDBDatabase&&!(_0x5b3099 in _0x43faf9)&&typeof _0x5b3099=='string'))return;if(Zn['get'](_0x5b3099))return Zn['get'](_0x5b3099);const _0x1cbe8d=_0x5b3099['replace'](/FromIndex$/,''),_0xdf1340=_0x5b3099!==_0x1cbe8d,_0x35ab4c=$c['includes'](_0x1cbe8d);if(!(_0x1cbe8d in(_0xdf1340?IDBIndex:IDBObjectStore)['prototype'])||!(_0x35ab4c||Hc['includes'](_0x1cbe8d)))return;const _0x33cdca=async function(_0x306b2e,..._0x4013fd){const _0x3b35d6=this['transaction'](_0x306b2e,_0x35ab4c?'readwrite':'readonly');let _0x5c2495=_0x3b35d6['store'];return _0xdf1340&&(_0x5c2495=_0x5c2495['index'](_0x4013fd['shift']())),(await Promise['all']([_0x5c2495[_0x1cbe8d](..._0x4013fd),_0x35ab4c&&_0x3b35d6['done']]))[0x0];};return Zn['set'](_0x5b3099,_0x33cdca),_0x33cdca;}Uc(_0x3f77bb=>({..._0x3f77bb,'get':(_0x374f89,_0x16a2ec,_0x44f6af)=>Os(_0x374f89,_0x16a2ec)||_0x3f77bb['get'](_0x374f89,_0x16a2ec,_0x44f6af),'has':(_0x4786a4,_0x4f84bf)=>!!Os(_0x4786a4,_0x4f84bf)||_0x3f77bb['has'](_0x4786a4,_0x4f84bf)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x3cad6d){this['container']=_0x3cad6d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x362181=>{if(qc(_0x362181)){const _0x313c19=_0x362181['getImmediate']();return _0x313c19['library']+'/'+_0x313c19['version'];}else return null;})['filter'](_0x580ef2=>_0x580ef2)['join']('\x20');}}function qc(_0x56be9c){const _0x2b7d55=_0x56be9c['getComponent']();return(_0x2b7d55==null?void 0x0:_0x2b7d55['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x238c90,_0x18a95a){try{_0x238c90['container']['addComponent'](_0x18a95a);}catch(_0x6ed191){re['debug']('Component\x20'+_0x18a95a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x238c90['name'],_0x6ed191);}}function et(_0x48c358){const _0x4716bd=_0x48c358['name'];if(gi['has'](_0x4716bd))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4716bd+'.'),!0x1;gi['set'](_0x4716bd,_0x48c358);for(const _0x1f6ad2 of Le['values']())Ms(_0x1f6ad2,_0x48c358);for(const _0x3362cd of _i['values']())Ms(_0x3362cd,_0x48c358);return!0x0;}function Ui(_0x5bc2f1,_0x37d37d){const _0x290463=_0x5bc2f1['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x290463&&_0x290463['triggerHeartbeat'](),_0x5bc2f1['container']['getProvider'](_0x37d37d);}function H(_0x3e210d){return _0x3e210d==null?!0x1:_0x3e210d['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4d8186,_0xd33cd3,_0x462310){this['_isDeleted']=!0x1,this['_options']={..._0x4d8186},this['_config']={..._0xd33cd3},this['_name']=_0xd33cd3['name'],this['_automaticDataCollectionEnabled']=_0xd33cd3['automaticDataCollectionEnabled'],this['_container']=_0x462310,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x431c9f){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x431c9f;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x22cede){this['_isDeleted']=_0x22cede;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x42c1c9,_0x2b9505={}){let _0x42d5e5=_0x42c1c9;typeof _0x2b9505!='object'&&(_0x2b9505={'name':_0x2b9505});const _0x4ffddb={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2b9505},_0x4380ae=_0x4ffddb['name'];if(typeof _0x4380ae!='string'||!_0x4380ae)throw ge['create']('bad-app-name',{'appName':String(_0x4380ae)});if(_0x42d5e5||(_0x42d5e5=$r()),!_0x42d5e5)throw ge['create']('no-options');const _0x17e3f9=Le['get'](_0x4380ae);if(_0x17e3f9){if(De(_0x42d5e5,_0x17e3f9['options'])&&De(_0x4ffddb,_0x17e3f9['config']))return _0x17e3f9;throw ge['create']('duplicate-app',{'appName':_0x4380ae});}const _0x31c33a=new Ac(_0x4380ae);for(const _0x3a69d3 of gi['values']())_0x31c33a['addComponent'](_0x3a69d3);const _0x46f62d=new Il(_0x42d5e5,_0x4ffddb,_0x31c33a);return Le['set'](_0x4380ae,_0x46f62d),_0x46f62d;}function Qr(_0x40484a=pi){const _0x3b1357=Le['get'](_0x40484a);if(!_0x3b1357&&_0x40484a===pi&&$r())return wl();if(!_0x3b1357)throw ge['create']('no-app',{'appName':_0x40484a});return _0x3b1357;}function l_(){return Array['from'](Le['values']());}async function h_(_0x402070){let _0x1b8205=!0x1;const _0x3317d4=_0x402070['name'];Le['has'](_0x3317d4)?(_0x1b8205=!0x0,Le['delete'](_0x3317d4)):_i['has'](_0x3317d4)&&_0x402070['decRefCount']()<=0x0&&(_i['delete'](_0x3317d4),_0x1b8205=!0x0),_0x1b8205&&(await Promise['all'](_0x402070['container']['getProviders']()['map'](_0x71bbdf=>_0x71bbdf['delete']())),_0x402070['isDeleted']=!0x0);}function me(_0x227408,_0x2c9698,_0x2a72c0){let _0x56a0a8=vl[_0x227408]??_0x227408;_0x2a72c0&&(_0x56a0a8+='-'+_0x2a72c0);const _0x59004a=_0x56a0a8['match'](/\s|\//),_0x38713d=_0x2c9698['match'](/\s|\//);if(_0x59004a||_0x38713d){const _0x5f0011=['Unable\x20to\x20register\x20library\x20\x22'+_0x56a0a8+'\x22\x20with\x20version\x20\x22'+_0x2c9698+'\x22:'];_0x59004a&&_0x5f0011['push']('library\x20name\x20\x22'+_0x56a0a8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x59004a&&_0x38713d&&_0x5f0011['push']('and'),_0x38713d&&_0x5f0011['push']('version\x20name\x20\x22'+_0x2c9698+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5f0011['join']('\x20'));return;}et(new Me(_0x56a0a8+'-version',()=>({'library':_0x56a0a8,'version':_0x2c9698}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3369a2,_0x34d59d)=>{switch(_0x34d59d){case 0x0:try{_0x3369a2['createObjectStore'](Rt);}catch(_0x137050){console['warn'](_0x137050);}}}})['catch'](_0x1141e4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1141e4['message']});})),ei;}async function Sl(_0x2d56a0){try{const _0x410e4d=(await Jr())['transaction'](Rt),_0x130dca=await _0x410e4d['objectStore'](Rt)['get'](Xr(_0x2d56a0));return await _0x410e4d['done'],_0x130dca;}catch(_0x1f2044){if(_0x1f2044 instanceof Se)re['warn'](_0x1f2044['message']);else{const _0x1d43ca=ge['create']('idb-get',{'originalErrorMessage':_0x1f2044==null?void 0x0:_0x1f2044['message']});re['warn'](_0x1d43ca['message']);}}}async function Ls(_0x3cccbb,_0x2ab448){try{const _0x34fff0=(await Jr())['transaction'](Rt,'readwrite');await _0x34fff0['objectStore'](Rt)['put'](_0x2ab448,Xr(_0x3cccbb)),await _0x34fff0['done'];}catch(_0xb92e2a){if(_0xb92e2a instanceof Se)re['warn'](_0xb92e2a['message']);else{const _0x1afd8e=ge['create']('idb-set',{'originalErrorMessage':_0xb92e2a==null?void 0x0:_0xb92e2a['message']});re['warn'](_0x1afd8e['message']);}}}function Xr(_0xf0fd38){return _0xf0fd38['name']+'!'+_0xf0fd38['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x30d77b){this['container']=_0x30d77b,this['_heartbeatsCache']=null;const _0x20df9a=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x20df9a),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x680165=>(this['_heartbeatsCache']=_0x680165,_0x680165));}async['triggerHeartbeat'](){var _0x2ad42d,_0x4d0f0a;try{const _0x270af7=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x236f6a=xs();if(((_0x2ad42d=this['_heartbeatsCache'])==null?void 0x0:_0x2ad42d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4d0f0a=this['_heartbeatsCache'])==null?void 0x0:_0x4d0f0a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x236f6a||this['_heartbeatsCache']['heartbeats']['some'](_0x3215a2=>_0x3215a2['date']===_0x236f6a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x236f6a,'agent':_0x270af7}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x400404=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x400404,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x674cb4){re['warn'](_0x674cb4);}}async['getHeartbeatsHeader'](){var _0x490a2a;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x490a2a=this['_heartbeatsCache'])==null?void 0x0:_0x490a2a['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3619e1=xs(),{heartbeatsToSend:_0x1abdb7,unsentEntries:_0x3eca5b}=kl(this['_heartbeatsCache']['heartbeats']),_0x4ce341=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1abdb7}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3619e1,_0x3eca5b['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3eca5b,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4ce341;}catch(_0x419de1){return re['warn'](_0x419de1),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x1dcc73,_0x3f48ba=bl){const _0x19d380=[];let _0x5e97e4=_0x1dcc73['slice']();for(const _0xadd20c of _0x1dcc73){const _0x345ad5=_0x19d380['find'](_0x1dca15=>_0x1dca15['agent']===_0xadd20c['agent']);if(_0x345ad5){if(_0x345ad5['dates']['push'](_0xadd20c['date']),Fs(_0x19d380)>_0x3f48ba){_0x345ad5['dates']['pop']();break;}}else{if(_0x19d380['push']({'agent':_0xadd20c['agent'],'dates':[_0xadd20c['date']]}),Fs(_0x19d380)>_0x3f48ba){_0x19d380['pop']();break;}}_0x5e97e4=_0x5e97e4['slice'](0x1);}return{'heartbeatsToSend':_0x19d380,'unsentEntries':_0x5e97e4};}class Nl{constructor(_0x130ba3){this['app']=_0x130ba3,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1a85ac=await Sl(this['app']);return _0x1a85ac!=null&&_0x1a85ac['heartbeats']?_0x1a85ac:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2efd81){if(await this['_canUseIndexedDBPromise']){const _0x75c813=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2efd81['lastSentHeartbeatDate']??_0x75c813['lastSentHeartbeatDate'],'heartbeats':_0x2efd81['heartbeats']});}else return;}async['add'](_0x48f5fd){if(await this['_canUseIndexedDBPromise']){const _0x3c4325=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x48f5fd['lastSentHeartbeatDate']??_0x3c4325['lastSentHeartbeatDate'],'heartbeats':[..._0x3c4325['heartbeats'],..._0x48f5fd['heartbeats']]});}else return;}}function Fs(_0x222146){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x222146}))['length'];}function Pl(_0x450df7){if(_0x450df7['length']===0x0)return-0x1;let _0x53e6b6=0x0,_0x35fac6=_0x450df7[0x0]['date'];for(let _0x1c0a8a=0x1;_0x1c0a8a<_0x450df7['length'];_0x1c0a8a++)_0x450df7[_0x1c0a8a]['date']<_0x35fac6&&(_0x35fac6=_0x450df7[_0x1c0a8a]['date'],_0x53e6b6=_0x1c0a8a);return _0x53e6b6;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x13faf4){et(new Me('platform-logger',_0x5efba7=>new Gc(_0x5efba7),'PRIVATE')),et(new Me('heartbeat',_0x213b5c=>new Al(_0x213b5c),'PRIVATE')),me(fi,Ds,_0x13faf4),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x3486d1){Zr=_0x3486d1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x4dc84a){this['domStorage_']=_0x4dc84a,this['prefix_']='firebase:';}['set'](_0x5d8faf,_0x5b9aca){_0x5b9aca==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5d8faf)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5d8faf),O(_0x5b9aca));}['get'](_0x2d1864){const _0x13353f=this['domStorage_']['getItem'](this['prefixedName_'](_0x2d1864));return _0x13353f==null?null:bt(_0x13353f);}['remove'](_0x2f2859){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2f2859));}['prefixedName_'](_0x1d939e){return this['prefix_']+_0x1d939e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x29544,_0x500789){_0x500789==null?delete this['cache_'][_0x29544]:this['cache_'][_0x29544]=_0x500789;}['get'](_0x1e8d07){return Y(this['cache_'],_0x1e8d07)?this['cache_'][_0x1e8d07]:null;}['remove'](_0x698247){delete this['cache_'][_0x698247];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x35d088){try{if(typeof window<'u'&&typeof window[_0x35d088]<'u'){const _0x46e9aa=window[_0x35d088];return _0x46e9aa['setItem']('firebase:sentinel','cache'),_0x46e9aa['removeItem']('firebase:sentinel'),new xl(_0x46e9aa);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x45f8ac=0x1;return function(){return _0x45f8ac++;};}()),no=function(_0x816e2d){const _0x2e1bd1=Tc(_0x816e2d),_0x1450b6=new Ec();_0x1450b6['update'](_0x2e1bd1);const _0x3edbf1=_0x1450b6['digest']();return Di['encodeByteArray'](_0x3edbf1);},Bt=function(..._0x173a0f){let _0x4fc2bb='';for(let _0x1e5db5=0x0;_0x1e5db5<_0x173a0f['length'];_0x1e5db5++){const _0x1b25c9=_0x173a0f[_0x1e5db5];Array['isArray'](_0x1b25c9)||_0x1b25c9&&typeof _0x1b25c9=='object'&&typeof _0x1b25c9['length']=='number'?_0x4fc2bb+=Bt['apply'](null,_0x1b25c9):typeof _0x1b25c9=='object'?_0x4fc2bb+=O(_0x1b25c9):_0x4fc2bb+=_0x1b25c9,_0x4fc2bb+='\x20';}return _0x4fc2bb;};let Et=null,Vs=!0x0;const Wl=function(_0x192e30,_0x1aa1ae){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1bed66){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x57f8ad=Bt['apply'](null,_0x1bed66);Et(_0x57f8ad);}},Vt=function(_0x50841b){return function(..._0x112883){L(_0x50841b,..._0x112883);};},mi=function(..._0x456fda){const _0x1760d3='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x456fda);Qe['error'](_0x1760d3);},oe=function(..._0x429c9e){const _0x506c4d='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x429c9e);throw Qe['error'](_0x506c4d),new Error(_0x506c4d);},U=function(..._0x35fe9f){const _0xc438ad='FIREBASE\x20WARNING:\x20'+Bt(..._0x35fe9f);Qe['warn'](_0xc438ad);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x41cd68){return typeof _0x41cd68=='number'&&(_0x41cd68!==_0x41cd68||_0x41cd68===Number['POSITIVE_INFINITY']||_0x41cd68===Number['NEGATIVE_INFINITY']);},Vl=function(_0x33359c){if(document['readyState']==='complete')_0x33359c();else{let _0x396882=!0x1;const _0x2d2967=function(){if(!document['body']){setTimeout(_0x2d2967,Math['floor'](0xa));return;}_0x396882||(_0x396882=!0x0,_0x33359c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2d2967,!0x1),window['addEventListener']('load',_0x2d2967,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2d2967();}),window['attachEvent']('onload',_0x2d2967));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x26b076,_0x3030e8){if(_0x26b076===_0x3030e8)return 0x0;if(_0x26b076===xe||_0x3030e8===Ie)return-0x1;if(_0x3030e8===xe||_0x26b076===Ie)return 0x1;{const _0xe5a89=Hs(_0x26b076),_0xb8334c=Hs(_0x3030e8);return _0xe5a89!==null?_0xb8334c!==null?_0xe5a89-_0xb8334c===0x0?_0x26b076['length']-_0x3030e8['length']:_0xe5a89-_0xb8334c:-0x1:_0xb8334c!==null?0x1:_0x26b076<_0x3030e8?-0x1:0x1;}},Hl=function(_0x52ca1a,_0x3413fa){return _0x52ca1a===_0x3413fa?0x0:_0x52ca1a<_0x3413fa?-0x1:0x1;},pt=function(_0x1b7ab1,_0x39f55c){if(_0x39f55c&&_0x1b7ab1 in _0x39f55c)return _0x39f55c[_0x1b7ab1];throw new Error('Missing\x20required\x20key\x20('+_0x1b7ab1+')\x20in\x20object:\x20'+O(_0x39f55c));},Bi=function(_0x21e249){if(typeof _0x21e249!='object'||_0x21e249===null)return O(_0x21e249);const _0xbec53c=[];for(const _0x49ae34 in _0x21e249)_0xbec53c['push'](_0x49ae34);_0xbec53c['sort']();let _0x1a7763='{';for(let _0x3476e2=0x0;_0x3476e2<_0xbec53c['length'];_0x3476e2++)_0x3476e2!==0x0&&(_0x1a7763+=','),_0x1a7763+=O(_0xbec53c[_0x3476e2]),_0x1a7763+=':',_0x1a7763+=Bi(_0x21e249[_0xbec53c[_0x3476e2]]);return _0x1a7763+='}',_0x1a7763;},io=function(_0x593c1c,_0x4b47db){const _0x2ebe7e=_0x593c1c['length'];if(_0x2ebe7e<=_0x4b47db)return[_0x593c1c];const _0x6aac40=[];for(let _0xb7d3db=0x0;_0xb7d3db<_0x2ebe7e;_0xb7d3db+=_0x4b47db)_0xb7d3db+_0x4b47db>_0x2ebe7e?_0x6aac40['push'](_0x593c1c['substring'](_0xb7d3db,_0x2ebe7e)):_0x6aac40['push'](_0x593c1c['substring'](_0xb7d3db,_0xb7d3db+_0x4b47db));return _0x6aac40;};function x(_0x1b455,_0xdc9a46){for(const _0x81e2b6 in _0x1b455)_0x1b455['hasOwnProperty'](_0x81e2b6)&&_0xdc9a46(_0x81e2b6,_0x1b455[_0x81e2b6]);}const so=function(_0x508ea4){f(!Wi(_0x508ea4),'Invalid\x20JSON\x20number');const _0x26cc98=0xb,_0x38c5c5=0x34,_0x3bb4fa=(0x1<<_0x26cc98-0x1)-0x1;let _0x1abd45,_0x906510,_0x2fb9dd,_0x47b2ba,_0x5f4454;_0x508ea4===0x0?(_0x906510=0x0,_0x2fb9dd=0x0,_0x1abd45=0x1/_0x508ea4===-0x1/0x0?0x1:0x0):(_0x1abd45=_0x508ea4<0x0,_0x508ea4=Math['abs'](_0x508ea4),_0x508ea4>=Math['pow'](0x2,0x1-_0x3bb4fa)?(_0x47b2ba=Math['min'](Math['floor'](Math['log'](_0x508ea4)/Math['LN2']),_0x3bb4fa),_0x906510=_0x47b2ba+_0x3bb4fa,_0x2fb9dd=Math['round'](_0x508ea4*Math['pow'](0x2,_0x38c5c5-_0x47b2ba)-Math['pow'](0x2,_0x38c5c5))):(_0x906510=0x0,_0x2fb9dd=Math['round'](_0x508ea4/Math['pow'](0x2,0x1-_0x3bb4fa-_0x38c5c5))));const _0x480b4a=[];for(_0x5f4454=_0x38c5c5;_0x5f4454;_0x5f4454-=0x1)_0x480b4a['push'](_0x2fb9dd%0x2?0x1:0x0),_0x2fb9dd=Math['floor'](_0x2fb9dd/0x2);for(_0x5f4454=_0x26cc98;_0x5f4454;_0x5f4454-=0x1)_0x480b4a['push'](_0x906510%0x2?0x1:0x0),_0x906510=Math['floor'](_0x906510/0x2);_0x480b4a['push'](_0x1abd45?0x1:0x0),_0x480b4a['reverse']();const _0x9206d2=_0x480b4a['join']('');let _0x254cad='';for(_0x5f4454=0x0;_0x5f4454<0x40;_0x5f4454+=0x8){let _0x3f27e4=parseInt(_0x9206d2['substr'](_0x5f4454,0x8),0x2)['toString'](0x10);_0x3f27e4['length']===0x1&&(_0x3f27e4='0'+_0x3f27e4),_0x254cad=_0x254cad+_0x3f27e4;}return _0x254cad['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2120f2,_0x223e00){let _0x40acd2='Unknown\x20Error';_0x2120f2==='too_big'?_0x40acd2='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2120f2==='permission_denied'?_0x40acd2='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2120f2==='unavailable'&&(_0x40acd2='The\x20service\x20is\x20unavailable');const _0x11fbb7=new Error(_0x2120f2+'\x20at\x20'+_0x223e00['_path']['toString']()+':\x20'+_0x40acd2);return _0x11fbb7['code']=_0x2120f2['toUpperCase'](),_0x11fbb7;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x4ff09c){if(zl['test'](_0x4ff09c)){const _0x276895=Number(_0x4ff09c);if(_0x276895>=jl&&_0x276895<=Kl)return _0x276895;}return null;},lt=function(_0x4de82e){try{_0x4de82e();}catch(_0x51e732){setTimeout(()=>{const _0x548114=_0x51e732['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x548114),_0x51e732;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x40dfe2,_0x4d31a3){const _0x82f538=setTimeout(_0x40dfe2,_0x4d31a3);return typeof _0x82f538=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x82f538):typeof _0x82f538=='object'&&_0x82f538['unref']&&_0x82f538['unref'](),_0x82f538;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x3ee806,_0x4670f4){this['appCheckProvider']=_0x4670f4,this['appName']=_0x3ee806['name'],H(_0x3ee806)&&_0x3ee806['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3ee806['settings']['appCheckToken']),this['appCheck']=_0x4670f4==null?void 0x0:_0x4670f4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4670f4==null||_0x4670f4['get']()['then'](_0x355793=>this['appCheck']=_0x355793);}['getToken'](_0x19b5b4){if(this['serverAppAppCheckToken']){if(_0x19b5b4)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x19b5b4):new Promise((_0x1323d4,_0x1dfcd6)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x19b5b4)['then'](_0x1323d4,_0x1dfcd6):_0x1323d4(null);},0x0);});}['addTokenChangeListener'](_0x5d7b9e){var _0x585454;(_0x585454=this['appCheckProvider'])==null||_0x585454['get']()['then'](_0xc457cb=>_0xc457cb['addTokenListener'](_0x5d7b9e));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x9d6653,_0x4a8e6a,_0x54bde7){this['appName_']=_0x9d6653,this['firebaseOptions_']=_0x4a8e6a,this['authProvider_']=_0x54bde7,this['auth_']=null,this['auth_']=_0x54bde7['getImmediate']({'optional':!0x0}),this['auth_']||_0x54bde7['onInit'](_0x3d575a=>this['auth_']=_0x3d575a);}['getToken'](_0x1af0c2){return this['auth_']?this['auth_']['getToken'](_0x1af0c2)['catch'](_0x1fe688=>_0x1fe688&&_0x1fe688['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1fe688)):new Promise((_0x472758,_0x5ac8bf)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1af0c2)['then'](_0x472758,_0x5ac8bf):_0x472758(null);},0x0);});}['addTokenChangeListener'](_0x1233ce){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1233ce):this['authProvider_']['get']()['then'](_0x3e00ec=>_0x3e00ec['addAuthTokenListener'](_0x1233ce));}['removeTokenChangeListener'](_0x3101a8){this['authProvider_']['get']()['then'](_0x496ad4=>_0x496ad4['removeAuthTokenListener'](_0x3101a8));}['notifyForInvalidToken'](){let _0x531403='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x531403+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x531403+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x531403+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x531403);}}class tn{constructor(_0x278268){this['accessToken']=_0x278268;}['getToken'](_0x4b0a1c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x33f654){_0x33f654(this['accessToken']);}['removeTokenChangeListener'](_0xc65d1e){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x5862b5,_0x28a379,_0x250fe8,_0x24bd1f,_0x1932e0=!0x1,_0x22e73f='',_0xb0ea0=!0x1,_0xc8dcd=!0x1,_0x42ad60=null){this['secure']=_0x28a379,this['namespace']=_0x250fe8,this['webSocketOnly']=_0x24bd1f,this['nodeAdmin']=_0x1932e0,this['persistenceKey']=_0x22e73f,this['includeNamespaceInQueryParams']=_0xb0ea0,this['isUsingEmulator']=_0xc8dcd,this['emulatorOptions']=_0x42ad60,this['_host']=_0x5862b5['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x5862b5)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4c2887){_0x4c2887!==this['internalHost']&&(this['internalHost']=_0x4c2887,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xd1049b=this['toURLString']();return this['persistenceKey']&&(_0xd1049b+='<'+this['persistenceKey']+'>'),_0xd1049b;}['toURLString'](){const _0xaf6cd5=this['secure']?'https://':'http://',_0x24ded5=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xaf6cd5+this['host']+'/'+_0x24ded5;}}function Xl(_0xbc80f4){return _0xbc80f4['host']!==_0xbc80f4['internalHost']||_0xbc80f4['isCustomHost']()||_0xbc80f4['includeNamespaceInQueryParams'];}function go(_0x1e7421,_0x444b24,_0x4ee9a1){f(typeof _0x444b24=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4ee9a1=='object','typeof\x20params\x20must\x20==\x20object');let _0x6dd8a3;if(_0x444b24===fo)_0x6dd8a3=(_0x1e7421['secure']?'wss://':'ws://')+_0x1e7421['internalHost']+'/.ws?';else{if(_0x444b24===po)_0x6dd8a3=(_0x1e7421['secure']?'https://':'http://')+_0x1e7421['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x444b24);}Xl(_0x1e7421)&&(_0x4ee9a1['ns']=_0x1e7421['namespace']);const _0x14b594=[];return x(_0x4ee9a1,(_0x456dec,_0x431b6f)=>{_0x14b594['push'](_0x456dec+'='+_0x431b6f);}),_0x6dd8a3+_0x14b594['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x581f8e,_0x54fe27=0x1){Y(this['counters_'],_0x581f8e)||(this['counters_'][_0x581f8e]=0x0),this['counters_'][_0x581f8e]+=_0x54fe27;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x4cfa0f){const _0xba3e45=_0x4cfa0f['toString']();return ti[_0xba3e45]||(ti[_0xba3e45]=new Zl()),ti[_0xba3e45];}function eh(_0x24006a,_0x322b29){const _0x315c14=_0x24006a['toString']();return ni[_0x315c14]||(ni[_0x315c14]=_0x322b29()),ni[_0x315c14];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2c8543){this['onMessage_']=_0x2c8543,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3a8a3f,_0x117eb2){this['closeAfterResponse']=_0x3a8a3f,this['onClose']=_0x117eb2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x86f7ed,_0x28a7fc){for(this['pendingResponses'][_0x86f7ed]=_0x28a7fc;this['pendingResponses'][this['currentResponseNum']];){const _0x31431c=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4266c9=0x0;_0x4266c9<_0x31431c['length'];++_0x4266c9)_0x31431c[_0x4266c9]&&lt(()=>{this['onMessage_'](_0x31431c[_0x4266c9]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x44188b,_0x5c2bb4,_0x45eafa,_0x230491,_0x5a9a88,_0x8f7b85,_0x206fba){this['connId']=_0x44188b,this['repoInfo']=_0x5c2bb4,this['applicationId']=_0x45eafa,this['appCheckToken']=_0x230491,this['authToken']=_0x5a9a88,this['transportSessionId']=_0x8f7b85,this['lastSessionId']=_0x206fba,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x44188b),this['stats_']=Hi(_0x5c2bb4),this['urlFn']=_0x52e84c=>(this['appCheckToken']&&(_0x52e84c[yi]=this['appCheckToken']),go(_0x5c2bb4,po,_0x52e84c));}['open'](_0x3a3500,_0x47a96f){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x47a96f,this['myPacketOrderer']=new th(_0x3a3500),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x5dfc6a)=>{const [_0x3c56f6,_0x352668,_0x76eef,_0x430937,_0x462ccc]=_0x5dfc6a;if(this['incrementIncomingBytes_'](_0x5dfc6a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3c56f6===$s)this['id']=_0x352668,this['password']=_0x76eef;else{if(_0x3c56f6===nh)_0x352668?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x352668,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3c56f6);}}},(..._0xa8dfd8)=>{const [_0x2c5487,_0x3f47f0]=_0xa8dfd8;this['incrementIncomingBytes_'](_0xa8dfd8),this['myPacketOrderer']['handleResponse'](_0x2c5487,_0x3f47f0);},()=>{this['onClosed_']();},this['urlFn']);const _0x5820af={};_0x5820af[$s]='t',_0x5820af[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5820af[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5820af[ro]=Vi,this['transportSessionId']&&(_0x5820af[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x5820af[ho]=this['lastSessionId']),this['applicationId']&&(_0x5820af[uo]=this['applicationId']),this['appCheckToken']&&(_0x5820af[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5820af[ao]=co);const _0x5277c4=this['urlFn'](_0x5820af);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5277c4),this['scriptTagHolder']['addTag'](_0x5277c4,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x34740e){const _0xcfb2c6=O(_0x34740e);this['bytesSent']+=_0xcfb2c6['length'],this['stats_']['incrementCounter']('bytes_sent',_0xcfb2c6['length']);const _0x416109=Br(_0xcfb2c6),_0x3f15c8=io(_0x416109,hh);for(let _0x5ce28b=0x0;_0x5ce28b<_0x3f15c8['length'];_0x5ce28b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3f15c8['length'],_0x3f15c8[_0x5ce28b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4584b,_0x42bbaa){this['myDisconnFrame']=document['createElement']('iframe');const _0x59fbfe={};_0x59fbfe[lh]='t',_0x59fbfe[mo]=_0x4584b,_0x59fbfe[yo]=_0x42bbaa,this['myDisconnFrame']['src']=this['urlFn'](_0x59fbfe),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3ab72f){const _0x51a8dd=O(_0x3ab72f)['length'];this['bytesReceived']+=_0x51a8dd,this['stats_']['incrementCounter']('bytes_received',_0x51a8dd);}}class $i{constructor(_0x5da4ce,_0x5ca889,_0x34da47,_0x450fec){this['onDisconnect']=_0x34da47,this['urlFn']=_0x450fec,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x5da4ce,window[sh+this['uniqueCallbackIdentifier']]=_0x5ca889,this['myIFrame']=$i['createIFrame_']();let _0x560ff3='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x560ff3='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5ab771='<html><body>'+_0x560ff3+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5ab771),this['myIFrame']['doc']['close']();}catch(_0x562534){L('frame\x20writing\x20exception'),_0x562534['stack']&&L(_0x562534['stack']),L(_0x562534);}}}static['createIFrame_'](){const _0x4f422e=document['createElement']('iframe');if(_0x4f422e['style']['display']='none',document['body']){document['body']['appendChild'](_0x4f422e);try{_0x4f422e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5f25f8=document['domain'];_0x4f422e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5f25f8+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4f422e['contentDocument']?_0x4f422e['doc']=_0x4f422e['contentDocument']:_0x4f422e['contentWindow']?_0x4f422e['doc']=_0x4f422e['contentWindow']['document']:_0x4f422e['document']&&(_0x4f422e['doc']=_0x4f422e['document']),_0x4f422e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x903d7a=this['onDisconnect'];_0x903d7a&&(this['onDisconnect']=null,_0x903d7a());}['startLongPoll'](_0x2b4f95,_0x50a6c3){for(this['myID']=_0x2b4f95,this['myPW']=_0x50a6c3,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3150e7={};_0x3150e7[mo]=this['myID'],_0x3150e7[yo]=this['myPW'],_0x3150e7[vo]=this['currentSerial'];let _0x37e46d=this['urlFn'](_0x3150e7),_0xcb8042='',_0x37784b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0xcb8042['length']<=Eo;){const _0x2d1a51=this['pendingSegs']['shift']();_0xcb8042=_0xcb8042+'&'+oh+_0x37784b+'='+_0x2d1a51['seg']+'&'+ah+_0x37784b+'='+_0x2d1a51['ts']+'&'+ch+_0x37784b+'='+_0x2d1a51['d'],_0x37784b++;}return _0x37e46d=_0x37e46d+_0xcb8042,this['addLongPollTag_'](_0x37e46d,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x261b3d,_0x3dbe91,_0x50f8fa){this['pendingSegs']['push']({'seg':_0x261b3d,'ts':_0x3dbe91,'d':_0x50f8fa}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x53baea,_0x83d2a6){this['outstandingRequests']['add'](_0x83d2a6);const _0x5c0655=()=>{this['outstandingRequests']['delete'](_0x83d2a6),this['newRequest_']();},_0x4f9db9=setTimeout(_0x5c0655,Math['floor'](uh)),_0x4b419f=()=>{clearTimeout(_0x4f9db9),_0x5c0655();};this['addTag'](_0x53baea,_0x4b419f);}['addTag'](_0x313bad,_0x430ac1){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x342ef3=this['myIFrame']['doc']['createElement']('script');_0x342ef3['type']='text/javascript',_0x342ef3['async']=!0x0,_0x342ef3['src']=_0x313bad,_0x342ef3['onload']=_0x342ef3['onreadystatechange']=function(){const _0x401356=_0x342ef3['readyState'];(!_0x401356||_0x401356==='loaded'||_0x401356==='complete')&&(_0x342ef3['onload']=_0x342ef3['onreadystatechange']=null,_0x342ef3['parentNode']&&_0x342ef3['parentNode']['removeChild'](_0x342ef3),_0x430ac1());},_0x342ef3['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x313bad),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x342ef3);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x41be1d,_0x49d474,_0x374b9a,_0x35e3ef,_0x3c3617,_0x940801,_0x114f13){this['connId']=_0x41be1d,this['applicationId']=_0x374b9a,this['appCheckToken']=_0x35e3ef,this['authToken']=_0x3c3617,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x49d474),this['connURL']=G['connectionURL_'](_0x49d474,_0x940801,_0x114f13,_0x35e3ef,_0x374b9a),this['nodeAdmin']=_0x49d474['nodeAdmin'];}static['connectionURL_'](_0x5c013b,_0x3787e1,_0x4e0e98,_0x3daa1a,_0xf8edc4){const _0x414d3c={};return _0x414d3c[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x414d3c[ao]=co),_0x3787e1&&(_0x414d3c[oo]=_0x3787e1),_0x4e0e98&&(_0x414d3c[ho]=_0x4e0e98),_0x3daa1a&&(_0x414d3c[yi]=_0x3daa1a),_0xf8edc4&&(_0x414d3c[uo]=_0xf8edc4),go(_0x5c013b,fo,_0x414d3c);}['open'](_0x3d7b17,_0x1f53ac){this['onDisconnect']=_0x1f53ac,this['onMessage']=_0x3d7b17,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x517594;dc(),this['mySock']=new hn(this['connURL'],[],_0x517594);}catch(_0x3d8f2c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3ee3f5=_0x3d8f2c['message']||_0x3d8f2c['data'];_0x3ee3f5&&this['log_'](_0x3ee3f5),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x35f8ab=>{this['handleIncomingFrame'](_0x35f8ab);},this['mySock']['onerror']=_0x24fb69=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5c751a=_0x24fb69['message']||_0x24fb69['data'];_0x5c751a&&this['log_'](_0x5c751a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4bf766=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x38a7f6=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5124db=navigator['userAgent']['match'](_0x38a7f6);_0x5124db&&_0x5124db['length']>0x1&&parseFloat(_0x5124db[0x1])<4.4&&(_0x4bf766=!0x0);}return!_0x4bf766&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x729db5){if(this['frames']['push'](_0x729db5),this['frames']['length']===this['totalFrames']){const _0x5798d4=this['frames']['join']('');this['frames']=null;const _0x649f22=bt(_0x5798d4);this['onMessage'](_0x649f22);}}['handleNewFrameCount_'](_0x24a7f5){this['totalFrames']=_0x24a7f5,this['frames']=[];}['extractFrameCount_'](_0x3dbc51){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3dbc51['length']<=0x6){const _0x593b7c=Number(_0x3dbc51);if(!isNaN(_0x593b7c))return this['handleNewFrameCount_'](_0x593b7c),null;}return this['handleNewFrameCount_'](0x1),_0x3dbc51;}['handleIncomingFrame'](_0x2032b3){if(this['mySock']===null)return;const _0x2c5b6f=_0x2032b3['data'];if(this['bytesReceived']+=_0x2c5b6f['length'],this['stats_']['incrementCounter']('bytes_received',_0x2c5b6f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2c5b6f);else{const _0x11ab07=this['extractFrameCount_'](_0x2c5b6f);_0x11ab07!==null&&this['appendFrame_'](_0x11ab07);}}['send'](_0x50a8d5){this['resetKeepAlive']();const _0x71c852=O(_0x50a8d5);this['bytesSent']+=_0x71c852['length'],this['stats_']['incrementCounter']('bytes_sent',_0x71c852['length']);const _0x49bec6=io(_0x71c852,fh);_0x49bec6['length']>0x1&&this['sendString_'](String(_0x49bec6['length']));for(let _0x19981f=0x0;_0x19981f<_0x49bec6['length'];_0x19981f++)this['sendString_'](_0x49bec6[_0x19981f]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x48c169){try{this['mySock']['send'](_0x48c169);}catch(_0x3f7f9a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3f7f9a['message']||_0x3f7f9a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x45dc83){this['initTransports_'](_0x45dc83);}['initTransports_'](_0x820a16){const _0x2906af=G&&G['isAvailable']();let _0x39b7e0=_0x2906af&&!G['previouslyFailed']();if(_0x820a16['webSocketOnly']&&(_0x2906af||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x39b7e0=!0x0),_0x39b7e0)this['transports_']=[G];else{const _0x4daea1=this['transports_']=[];for(const _0x4a3f6a of At['ALL_TRANSPORTS'])_0x4a3f6a&&_0x4a3f6a['isAvailable']()&&_0x4daea1['push'](_0x4a3f6a);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x41d631,_0x64715c,_0x4c6335,_0x340ce7,_0x2032d0,_0x2827b4,_0x26800b,_0x417a5f,_0x513543,_0x1bbd41){this['id']=_0x41d631,this['repoInfo_']=_0x64715c,this['applicationId_']=_0x4c6335,this['appCheckToken_']=_0x340ce7,this['authToken_']=_0x2032d0,this['onMessage_']=_0x2827b4,this['onReady_']=_0x26800b,this['onDisconnect_']=_0x417a5f,this['onKill_']=_0x513543,this['lastSessionId']=_0x1bbd41,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x64715c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x15bcbf=this['transportManager_']['initialTransport']();this['conn_']=new _0x15bcbf(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x15bcbf['responsesRequiredToBeHealthy']||0x0;const _0x3f6741=this['connReceiver_'](this['conn_']),_0x337b0e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3f6741,_0x337b0e);},Math['floor'](0x0));const _0x17624e=_0x15bcbf['healthyTimeout']||0x0;_0x17624e>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x17624e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1b58c3){return _0x156b14=>{_0x1b58c3===this['conn_']?this['onConnectionLost_'](_0x156b14):_0x1b58c3===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x187fa6){return _0x20beb1=>{this['state_']!==0x2&&(_0x187fa6===this['rx_']?this['onPrimaryMessageReceived_'](_0x20beb1):_0x187fa6===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x20beb1):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x15f870){const _0xaca31f={'t':'d','d':_0x15f870};this['sendData_'](_0xaca31f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2f4721){if(ii in _0x2f4721){const _0x5e575b=_0x2f4721[ii];_0x5e575b===js?this['upgradeIfSecondaryHealthy_']():_0x5e575b===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5e575b===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x37d12b){const _0x122f03=pt('t',_0x37d12b),_0x46e02b=pt('d',_0x37d12b);if(_0x122f03==='c')this['onSecondaryControl_'](_0x46e02b);else{if(_0x122f03==='d')this['pendingDataMessages']['push'](_0x46e02b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x122f03);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x51bcda){const _0x2d81de=pt('t',_0x51bcda),_0x43e1b7=pt('d',_0x51bcda);_0x2d81de==='c'?this['onControl_'](_0x43e1b7):_0x2d81de==='d'&&this['onDataMessage_'](_0x43e1b7);}['onDataMessage_'](_0xda734b){this['onPrimaryResponse_'](),this['onMessage_'](_0xda734b);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5f3def){const _0x19f5b0=pt(ii,_0x5f3def);if(Gs in _0x5f3def){const _0x31566d=_0x5f3def[Gs];if(_0x19f5b0===Ih){const _0x322d3e={..._0x31566d};this['repoInfo_']['isUsingEmulator']&&(_0x322d3e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x322d3e);}else{if(_0x19f5b0===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1af9b2=0x0;_0x1af9b2<this['pendingDataMessages']['length'];++_0x1af9b2)this['onDataMessage_'](this['pendingDataMessages'][_0x1af9b2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x19f5b0===vh?this['onConnectionShutdown_'](_0x31566d):_0x19f5b0===qs?this['onReset_'](_0x31566d):_0x19f5b0===Eh?mi('Server\x20Error:\x20'+_0x31566d):_0x19f5b0===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x19f5b0);}}}['onHandshake_'](_0x5c4ac7){const _0x550e08=_0x5c4ac7['ts'],_0x17391e=_0x5c4ac7['v'],_0x1b562d=_0x5c4ac7['h'];this['sessionId']=_0x5c4ac7['s'],this['repoInfo_']['host']=_0x1b562d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x550e08),Vi!==_0x17391e&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1f635a=this['transportManager_']['upgradeTransport']();_0x1f635a&&this['startUpgrade_'](_0x1f635a);}['startUpgrade_'](_0x2df420){this['secondaryConn_']=new _0x2df420(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2df420['responsesRequiredToBeHealthy']||0x0;const _0x4f7151=this['connReceiver_'](this['secondaryConn_']),_0xe7e12a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4f7151,_0xe7e12a),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2b235c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2b235c),this['repoInfo_']['host']=_0x2b235c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3708ab,_0x382251){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3708ab,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x382251,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x36d84c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x36d84c||this['rx_']===_0x36d84c)&&this['close']();}['onConnectionLost_'](_0x2426ae){this['conn_']=null,!_0x2426ae&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x8cf704){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x8cf704),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x517fde){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x517fde);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0xcace14,_0x36ff36,_0x31a50d,_0x33cee4){}['merge'](_0x4800a4,_0x159484,_0xd38bbb,_0x56a574){}['refreshAuthToken'](_0x375dd5){}['refreshAppCheckToken'](_0x81993e){}['onDisconnectPut'](_0x48d466,_0x502628,_0x11993e){}['onDisconnectMerge'](_0x149bfb,_0x5e00d3,_0x1dc0b8){}['onDisconnectCancel'](_0x5a15d2,_0xe8ab73){}['reportStats'](_0x339074){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x26b05a){this['allowedEvents_']=_0x26b05a,this['listeners_']={},f(Array['isArray'](_0x26b05a)&&_0x26b05a['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3f7047,..._0x320917){if(Array['isArray'](this['listeners_'][_0x3f7047])){const _0x2c2282=[...this['listeners_'][_0x3f7047]];for(let _0x266a0e=0x0;_0x266a0e<_0x2c2282['length'];_0x266a0e++)_0x2c2282[_0x266a0e]['callback']['apply'](_0x2c2282[_0x266a0e]['context'],_0x320917);}}['on'](_0x35b0ef,_0x7b8020,_0x4bef10){this['validateEventType_'](_0x35b0ef),this['listeners_'][_0x35b0ef]=this['listeners_'][_0x35b0ef]||[],this['listeners_'][_0x35b0ef]['push']({'callback':_0x7b8020,'context':_0x4bef10});const _0x21d24f=this['getInitialEvent'](_0x35b0ef);_0x21d24f&&_0x7b8020['apply'](_0x4bef10,_0x21d24f);}['off'](_0xb0584c,_0xcdc8fc,_0x88bd4d){this['validateEventType_'](_0xb0584c);const _0x38c288=this['listeners_'][_0xb0584c]||[];for(let _0x4e77c9=0x0;_0x4e77c9<_0x38c288['length'];_0x4e77c9++)if(_0x38c288[_0x4e77c9]['callback']===_0xcdc8fc&&(!_0x88bd4d||_0x88bd4d===_0x38c288[_0x4e77c9]['context'])){_0x38c288['splice'](_0x4e77c9,0x1);return;}}['validateEventType_'](_0x232ac5){f(this['allowedEvents_']['find'](_0x35a647=>_0x35a647===_0x232ac5),'Unknown\x20event:\x20'+_0x232ac5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x43156f){return f(_0x43156f==='online','Unknown\x20event\x20type:\x20'+_0x43156f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x32f63a,_0x3189ef){if(_0x3189ef===void 0x0){this['pieces_']=_0x32f63a['split']('/');let _0x3e2a33=0x0;for(let _0x492969=0x0;_0x492969<this['pieces_']['length'];_0x492969++)this['pieces_'][_0x492969]['length']>0x0&&(this['pieces_'][_0x3e2a33]=this['pieces_'][_0x492969],_0x3e2a33++);this['pieces_']['length']=_0x3e2a33,this['pieceNum_']=0x0;}else this['pieces_']=_0x32f63a,this['pieceNum_']=_0x3189ef;}['toString'](){let _0x16e12f='';for(let _0x350c99=this['pieceNum_'];_0x350c99<this['pieces_']['length'];_0x350c99++)this['pieces_'][_0x350c99]!==''&&(_0x16e12f+='/'+this['pieces_'][_0x350c99]);return _0x16e12f||'/';}}function w(){return new C('');}function y(_0x25f003){return _0x25f003['pieceNum_']>=_0x25f003['pieces_']['length']?null:_0x25f003['pieces_'][_0x25f003['pieceNum_']];}function we(_0x53ac1d){return _0x53ac1d['pieces_']['length']-_0x53ac1d['pieceNum_'];}function b(_0x3f2275){let _0x14e6cc=_0x3f2275['pieceNum_'];return _0x14e6cc<_0x3f2275['pieces_']['length']&&_0x14e6cc++,new C(_0x3f2275['pieces_'],_0x14e6cc);}function Gi(_0x4b032a){return _0x4b032a['pieceNum_']<_0x4b032a['pieces_']['length']?_0x4b032a['pieces_'][_0x4b032a['pieces_']['length']-0x1]:null;}function Ch(_0x3d6213){let _0x2ec666='';for(let _0x5f50b5=_0x3d6213['pieceNum_'];_0x5f50b5<_0x3d6213['pieces_']['length'];_0x5f50b5++)_0x3d6213['pieces_'][_0x5f50b5]!==''&&(_0x2ec666+='/'+encodeURIComponent(String(_0x3d6213['pieces_'][_0x5f50b5])));return _0x2ec666||'/';}function kt(_0x513959,_0x5f2a0a=0x0){return _0x513959['pieces_']['slice'](_0x513959['pieceNum_']+_0x5f2a0a);}function To(_0x8d0e33){if(_0x8d0e33['pieceNum_']>=_0x8d0e33['pieces_']['length'])return null;const _0x5aa188=[];for(let _0x4315cb=_0x8d0e33['pieceNum_'];_0x4315cb<_0x8d0e33['pieces_']['length']-0x1;_0x4315cb++)_0x5aa188['push'](_0x8d0e33['pieces_'][_0x4315cb]);return new C(_0x5aa188,0x0);}function A(_0x151052,_0x38af2b){const _0x13a2ef=[];for(let _0x297e4e=_0x151052['pieceNum_'];_0x297e4e<_0x151052['pieces_']['length'];_0x297e4e++)_0x13a2ef['push'](_0x151052['pieces_'][_0x297e4e]);if(_0x38af2b instanceof C){for(let _0x20efa6=_0x38af2b['pieceNum_'];_0x20efa6<_0x38af2b['pieces_']['length'];_0x20efa6++)_0x13a2ef['push'](_0x38af2b['pieces_'][_0x20efa6]);}else{const _0x303b0e=_0x38af2b['split']('/');for(let _0x2fded3=0x0;_0x2fded3<_0x303b0e['length'];_0x2fded3++)_0x303b0e[_0x2fded3]['length']>0x0&&_0x13a2ef['push'](_0x303b0e[_0x2fded3]);}return new C(_0x13a2ef,0x0);}function v(_0x507ca0){return _0x507ca0['pieceNum_']>=_0x507ca0['pieces_']['length'];}function F(_0x442acd,_0x421b9e){const _0x53d91d=y(_0x442acd),_0x136217=y(_0x421b9e);if(_0x53d91d===null)return _0x421b9e;if(_0x53d91d===_0x136217)return F(b(_0x442acd),b(_0x421b9e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x421b9e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x442acd+')');}function Th(_0x181771,_0x50d435){const _0x4c1a2b=kt(_0x181771,0x0),_0x328065=kt(_0x50d435,0x0);for(let _0x2bbe50=0x0;_0x2bbe50<_0x4c1a2b['length']&&_0x2bbe50<_0x328065['length'];_0x2bbe50++){const _0xd28659=He(_0x4c1a2b[_0x2bbe50],_0x328065[_0x2bbe50]);if(_0xd28659!==0x0)return _0xd28659;}return _0x4c1a2b['length']===_0x328065['length']?0x0:_0x4c1a2b['length']<_0x328065['length']?-0x1:0x1;}function qi(_0x1d626b,_0x2132a3){if(we(_0x1d626b)!==we(_0x2132a3))return!0x1;for(let _0x198f1d=_0x1d626b['pieceNum_'],_0x101870=_0x2132a3['pieceNum_'];_0x198f1d<=_0x1d626b['pieces_']['length'];_0x198f1d++,_0x101870++)if(_0x1d626b['pieces_'][_0x198f1d]!==_0x2132a3['pieces_'][_0x101870])return!0x1;return!0x0;}function $(_0x5e3540,_0x471167){let _0x2c1b88=_0x5e3540['pieceNum_'],_0x5dee7d=_0x471167['pieceNum_'];if(we(_0x5e3540)>we(_0x471167))return!0x1;for(;_0x2c1b88<_0x5e3540['pieces_']['length'];){if(_0x5e3540['pieces_'][_0x2c1b88]!==_0x471167['pieces_'][_0x5dee7d])return!0x1;++_0x2c1b88,++_0x5dee7d;}return!0x0;}class Sh{constructor(_0xea2a9e,_0x3ea0f0){this['errorPrefix_']=_0x3ea0f0,this['parts_']=kt(_0xea2a9e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x51eac7=0x0;_0x51eac7<this['parts_']['length'];_0x51eac7++)this['byteLength_']+=Pn(this['parts_'][_0x51eac7]);So(this);}}function bh(_0x520f89,_0x1704c6){_0x520f89['parts_']['length']>0x0&&(_0x520f89['byteLength_']+=0x1),_0x520f89['parts_']['push'](_0x1704c6),_0x520f89['byteLength_']+=Pn(_0x1704c6),So(_0x520f89);}function Rh(_0xb6f1d1){const _0x21ca6d=_0xb6f1d1['parts_']['pop']();_0xb6f1d1['byteLength_']-=Pn(_0x21ca6d),_0xb6f1d1['parts_']['length']>0x0&&(_0xb6f1d1['byteLength_']-=0x1);}function So(_0xf7bdb0){if(_0xf7bdb0['byteLength_']>Js)throw new Error(_0xf7bdb0['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0xf7bdb0['byteLength_']+').');if(_0xf7bdb0['parts_']['length']>Qs)throw new Error(_0xf7bdb0['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0xf7bdb0));}function Ne(_0x2db922){return _0x2db922['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2db922['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x4764d0,_0x51d59c;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x51d59c='visibilitychange',_0x4764d0='hidden'):typeof document['mozHidden']<'u'?(_0x51d59c='mozvisibilitychange',_0x4764d0='mozHidden'):typeof document['msHidden']<'u'?(_0x51d59c='msvisibilitychange',_0x4764d0='msHidden'):typeof document['webkitHidden']<'u'&&(_0x51d59c='webkitvisibilitychange',_0x4764d0='webkitHidden')),this['visible_']=!0x0,_0x51d59c&&document['addEventListener'](_0x51d59c,()=>{const _0x39e126=!document[_0x4764d0];_0x39e126!==this['visible_']&&(this['visible_']=_0x39e126,this['trigger']('visible',_0x39e126));},!0x1);}['getInitialEvent'](_0x5469f){return f(_0x5469f==='visible','Unknown\x20event\x20type:\x20'+_0x5469f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x2e65e9,_0x14af6e,_0x2efc3f,_0x2951cb,_0x173027,_0x241b57,_0x367cc2,_0x4fb8c1){if(super(),this['repoInfo_']=_0x2e65e9,this['applicationId_']=_0x14af6e,this['onDataUpdate_']=_0x2efc3f,this['onConnectStatus_']=_0x2951cb,this['onServerInfoUpdate_']=_0x173027,this['authTokenProvider_']=_0x241b57,this['appCheckTokenProvider_']=_0x367cc2,this['authOverride_']=_0x4fb8c1,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4fb8c1)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2e65e9['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x550fc0,_0x5b4847,_0x33aafc){const _0x2aabb9=++this['requestNumber_'],_0x20dd5a={'r':_0x2aabb9,'a':_0x550fc0,'b':_0x5b4847};this['log_'](O(_0x20dd5a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x20dd5a),_0x33aafc&&(this['requestCBHash_'][_0x2aabb9]=_0x33aafc);}['get'](_0x30eff0){this['initConnection_']();const _0x293cb8=new Ve(),_0x5b0902={'action':'g','request':{'p':_0x30eff0['_path']['toString'](),'q':_0x30eff0['_queryObject']},'onComplete':_0x310d57=>{const _0x1fd3f7=_0x310d57['d'];_0x310d57['s']==='ok'?_0x293cb8['resolve'](_0x1fd3f7):_0x293cb8['reject'](_0x1fd3f7);}};this['outstandingGets_']['push'](_0x5b0902),this['outstandingGetCount_']++;const _0x216159=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x216159),_0x293cb8['promise'];}['listen'](_0x2f5a85,_0x17bb76,_0x58e02a,_0x1f7045){this['initConnection_']();const _0xa6c258=_0x2f5a85['_queryIdentifier'],_0x3b68f5=_0x2f5a85['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3b68f5+'\x20'+_0xa6c258),this['listens']['has'](_0x3b68f5)||this['listens']['set'](_0x3b68f5,new Map()),f(_0x2f5a85['_queryParams']['isDefault']()||!_0x2f5a85['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3b68f5)['has'](_0xa6c258),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x3dbb32={'onComplete':_0x1f7045,'hashFn':_0x17bb76,'query':_0x2f5a85,'tag':_0x58e02a};this['listens']['get'](_0x3b68f5)['set'](_0xa6c258,_0x3dbb32),this['connected_']&&this['sendListen_'](_0x3dbb32);}['sendGet_'](_0xec0d4d){const _0x82f46c=this['outstandingGets_'][_0xec0d4d];this['sendRequest']('g',_0x82f46c['request'],_0xad9f1e=>{delete this['outstandingGets_'][_0xec0d4d],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x82f46c['onComplete']&&_0x82f46c['onComplete'](_0xad9f1e);});}['sendListen_'](_0x4f659e){const _0xf7b49=_0x4f659e['query'],_0x168cb0=_0xf7b49['_path']['toString'](),_0x32df73=_0xf7b49['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x168cb0+'\x20for\x20'+_0x32df73);const _0x2f056d={'p':_0x168cb0},_0x459d9a='q';_0x4f659e['tag']&&(_0x2f056d['q']=_0xf7b49['_queryObject'],_0x2f056d['t']=_0x4f659e['tag']),_0x2f056d['h']=_0x4f659e['hashFn'](),this['sendRequest'](_0x459d9a,_0x2f056d,_0x1abc52=>{const _0x3fff0d=_0x1abc52['d'],_0xe6143e=_0x1abc52['s'];ie['warnOnListenWarnings_'](_0x3fff0d,_0xf7b49),(this['listens']['get'](_0x168cb0)&&this['listens']['get'](_0x168cb0)['get'](_0x32df73))===_0x4f659e&&(this['log_']('listen\x20response',_0x1abc52),_0xe6143e!=='ok'&&this['removeListen_'](_0x168cb0,_0x32df73),_0x4f659e['onComplete']&&_0x4f659e['onComplete'](_0xe6143e,_0x3fff0d));});}static['warnOnListenWarnings_'](_0x246810,_0x53ab95){if(_0x246810&&typeof _0x246810=='object'&&Y(_0x246810,'w')){const _0x517450=Oe(_0x246810,'w');if(Array['isArray'](_0x517450)&&~_0x517450['indexOf']('no_index')){const _0x60ce30='\x22.indexOn\x22:\x20\x22'+_0x53ab95['_queryParams']['getIndex']()['toString']()+'\x22',_0x2b1ae0=_0x53ab95['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x60ce30+'\x20at\x20'+_0x2b1ae0+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4f7750){this['authToken_']=_0x4f7750,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4f7750);}['reduceReconnectDelayIfAdminCredential_'](_0x2129c4){(_0x2129c4&&_0x2129c4['length']===0x28||vc(_0x2129c4))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x2aedad){this['appCheckToken_']=_0x2aedad,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x240ced=this['authToken_'],_0x3a9ad0=yc(_0x240ced)?'auth':'gauth',_0x1ab7ad={'cred':_0x240ced};this['authOverride_']===null?_0x1ab7ad['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1ab7ad['authvar']=this['authOverride_']),this['sendRequest'](_0x3a9ad0,_0x1ab7ad,_0x202ee6=>{const _0x20d45e=_0x202ee6['s'],_0x1e0892=_0x202ee6['d']||'error';this['authToken_']===_0x240ced&&(_0x20d45e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x20d45e,_0x1e0892));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x9bb42b=>{const _0x39908a=_0x9bb42b['s'],_0x40c625=_0x9bb42b['d']||'error';_0x39908a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x39908a,_0x40c625);});}['unlisten'](_0x12332b,_0x41ee08){const _0x1e3d76=_0x12332b['_path']['toString'](),_0x4a2ace=_0x12332b['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1e3d76+'\x20'+_0x4a2ace),f(_0x12332b['_queryParams']['isDefault']()||!_0x12332b['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1e3d76,_0x4a2ace)&&this['connected_']&&this['sendUnlisten_'](_0x1e3d76,_0x4a2ace,_0x12332b['_queryObject'],_0x41ee08);}['sendUnlisten_'](_0x283619,_0x39ef72,_0x16910b,_0x39af2b){this['log_']('Unlisten\x20on\x20'+_0x283619+'\x20for\x20'+_0x39ef72);const _0xd43835={'p':_0x283619},_0x38c5f0='n';_0x39af2b&&(_0xd43835['q']=_0x16910b,_0xd43835['t']=_0x39af2b),this['sendRequest'](_0x38c5f0,_0xd43835);}['onDisconnectPut'](_0x5a832a,_0x29ac5b,_0x57ef08){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5a832a,_0x29ac5b,_0x57ef08):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5a832a,'action':'o','data':_0x29ac5b,'onComplete':_0x57ef08});}['onDisconnectMerge'](_0x2044eb,_0x3b5d0c,_0x2c6c1b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2044eb,_0x3b5d0c,_0x2c6c1b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2044eb,'action':'om','data':_0x3b5d0c,'onComplete':_0x2c6c1b});}['onDisconnectCancel'](_0x368ade,_0x240200){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x368ade,null,_0x240200):this['onDisconnectRequestQueue_']['push']({'pathString':_0x368ade,'action':'oc','data':null,'onComplete':_0x240200});}['sendOnDisconnect_'](_0x22c59c,_0x4a19d1,_0x8cba68,_0x20e78b){const _0x2f1bc1={'p':_0x4a19d1,'d':_0x8cba68};this['log_']('onDisconnect\x20'+_0x22c59c,_0x2f1bc1),this['sendRequest'](_0x22c59c,_0x2f1bc1,_0x456a2a=>{_0x20e78b&&setTimeout(()=>{_0x20e78b(_0x456a2a['s'],_0x456a2a['d']);},Math['floor'](0x0));});}['put'](_0xac393b,_0x1f4f9f,_0x2bcf74,_0x4dba99){this['putInternal']('p',_0xac393b,_0x1f4f9f,_0x2bcf74,_0x4dba99);}['merge'](_0x1ff5fd,_0x5ba4b1,_0x40c1e4,_0x4574d7){this['putInternal']('m',_0x1ff5fd,_0x5ba4b1,_0x40c1e4,_0x4574d7);}['putInternal'](_0x221466,_0x26981e,_0x2087cc,_0x2fd836,_0xda543c){this['initConnection_']();const _0x958c20={'p':_0x26981e,'d':_0x2087cc};_0xda543c!==void 0x0&&(_0x958c20['h']=_0xda543c),this['outstandingPuts_']['push']({'action':_0x221466,'request':_0x958c20,'onComplete':_0x2fd836}),this['outstandingPutCount_']++;const _0x3fd7bf=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3fd7bf):this['log_']('Buffering\x20put:\x20'+_0x26981e);}['sendPut_'](_0x60f22){const _0x2605f4=this['outstandingPuts_'][_0x60f22]['action'],_0x446802=this['outstandingPuts_'][_0x60f22]['request'],_0x448a20=this['outstandingPuts_'][_0x60f22]['onComplete'];this['outstandingPuts_'][_0x60f22]['queued']=this['connected_'],this['sendRequest'](_0x2605f4,_0x446802,_0x383e2e=>{this['log_'](_0x2605f4+'\x20response',_0x383e2e),delete this['outstandingPuts_'][_0x60f22],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x448a20&&_0x448a20(_0x383e2e['s'],_0x383e2e['d']);});}['reportStats'](_0x3e1a7b){if(this['connected_']){const _0x1021cf={'c':_0x3e1a7b};this['log_']('reportStats',_0x1021cf),this['sendRequest']('s',_0x1021cf,_0x5b8b45=>{if(_0x5b8b45['s']!=='ok'){const _0x32027e=_0x5b8b45['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x32027e);}});}}['onDataMessage_'](_0x50640c){if('r'in _0x50640c){this['log_']('from\x20server:\x20'+O(_0x50640c));const _0x5c2a81=_0x50640c['r'],_0x3c9d72=this['requestCBHash_'][_0x5c2a81];_0x3c9d72&&(delete this['requestCBHash_'][_0x5c2a81],_0x3c9d72(_0x50640c['b']));}else{if('error'in _0x50640c)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x50640c['error'];'a'in _0x50640c&&this['onDataPush_'](_0x50640c['a'],_0x50640c['b']);}}['onDataPush_'](_0x399c94,_0x445d16){this['log_']('handleServerMessage',_0x399c94,_0x445d16),_0x399c94==='d'?this['onDataUpdate_'](_0x445d16['p'],_0x445d16['d'],!0x1,_0x445d16['t']):_0x399c94==='m'?this['onDataUpdate_'](_0x445d16['p'],_0x445d16['d'],!0x0,_0x445d16['t']):_0x399c94==='c'?this['onListenRevoked_'](_0x445d16['p'],_0x445d16['q']):_0x399c94==='ac'?this['onAuthRevoked_'](_0x445d16['s'],_0x445d16['d']):_0x399c94==='apc'?this['onAppCheckRevoked_'](_0x445d16['s'],_0x445d16['d']):_0x399c94==='sd'?this['onSecurityDebugPacket_'](_0x445d16):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x399c94)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x33360a,_0x1f3331){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x33360a),this['lastSessionId']=_0x1f3331,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4ef453){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4ef453));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x3fb2f0){_0x3fb2f0&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x3fb2f0;}['onOnline_'](_0x465067){_0x465067?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x6a8884=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x571fbf=Math['max'](0x0,this['reconnectDelay_']-_0x6a8884);_0x571fbf=Math['random']()*_0x571fbf,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x571fbf+'ms'),this['scheduleConnect_'](_0x571fbf),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5c93f2=this['onDataMessage_']['bind'](this),_0x323b58=this['onReady_']['bind'](this),_0x39ed33=this['onRealtimeDisconnect_']['bind'](this),_0x3ac822=this['id']+':'+ie['nextConnectionId_']++,_0x450c2c=this['lastSessionId'];let _0x10d431=!0x1,_0x21d6de=null;const _0x559d90=function(){_0x21d6de?_0x21d6de['close']():(_0x10d431=!0x0,_0x39ed33());},_0x53eb40=function(_0xca5460){f(_0x21d6de,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x21d6de['sendRequest'](_0xca5460);};this['realtime_']={'close':_0x559d90,'sendRequest':_0x53eb40};const _0x3726a0=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1da758,_0x1fee8d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3726a0),this['appCheckTokenProvider_']['getToken'](_0x3726a0)]);_0x10d431?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1da758&&_0x1da758['accessToken'],this['appCheckToken_']=_0x1fee8d&&_0x1fee8d['token'],_0x21d6de=new wh(_0x3ac822,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5c93f2,_0x323b58,_0x39ed33,_0x4af597=>{U(_0x4af597+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x450c2c));}catch(_0x456df8){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x456df8),_0x10d431||(this['repoInfo_']['nodeAdmin']&&U(_0x456df8),_0x559d90());}}}['interrupt'](_0x56de86){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x56de86),this['interruptReasons_'][_0x56de86]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x32cf15){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x32cf15),delete this['interruptReasons_'][_0x32cf15],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2768b2){const _0x1a18da=_0x2768b2-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1a18da});}['cancelSentTransactions_'](){for(let _0x1ddad8=0x0;_0x1ddad8<this['outstandingPuts_']['length'];_0x1ddad8++){const _0x3ef25a=this['outstandingPuts_'][_0x1ddad8];_0x3ef25a&&'h'in _0x3ef25a['request']&&_0x3ef25a['queued']&&(_0x3ef25a['onComplete']&&_0x3ef25a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1ddad8],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x420c09,_0x2cd3eb){let _0x4af3d7;_0x2cd3eb?_0x4af3d7=_0x2cd3eb['map'](_0x123bbc=>Bi(_0x123bbc))['join']('$'):_0x4af3d7='default';const _0x4adea8=this['removeListen_'](_0x420c09,_0x4af3d7);_0x4adea8&&_0x4adea8['onComplete']&&_0x4adea8['onComplete']('permission_denied');}['removeListen_'](_0x23da10,_0x20fd3e){const _0x167dfc=new C(_0x23da10)['toString']();let _0x3488df;if(this['listens']['has'](_0x167dfc)){const _0x5d344f=this['listens']['get'](_0x167dfc);_0x3488df=_0x5d344f['get'](_0x20fd3e),_0x5d344f['delete'](_0x20fd3e),_0x5d344f['size']===0x0&&this['listens']['delete'](_0x167dfc);}else _0x3488df=void 0x0;return _0x3488df;}['onAuthRevoked_'](_0x2bc50f,_0xc76121){L('Auth\x20token\x20revoked:\x20'+_0x2bc50f+'/'+_0xc76121),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2bc50f==='invalid_token'||_0x2bc50f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x100630,_0xafabe7){L('App\x20check\x20token\x20revoked:\x20'+_0x100630+'/'+_0xafabe7),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x100630==='invalid_token'||_0x100630==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x23ef39){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x23ef39):'msg'in _0x23ef39&&console['log']('FIREBASE:\x20'+_0x23ef39['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1a3286 of this['listens']['values']())for(const _0x81955f of _0x1a3286['values']())this['sendListen_'](_0x81955f);for(let _0x5526fd=0x0;_0x5526fd<this['outstandingPuts_']['length'];_0x5526fd++)this['outstandingPuts_'][_0x5526fd]&&this['sendPut_'](_0x5526fd);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3091d6=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3091d6['action'],_0x3091d6['pathString'],_0x3091d6['data'],_0x3091d6['onComplete']);}for(let _0x18ddd2=0x0;_0x18ddd2<this['outstandingGets_']['length'];_0x18ddd2++)this['outstandingGets_'][_0x18ddd2]&&this['sendGet_'](_0x18ddd2);}['sendConnectStats_'](){const _0x235e76={};let _0x106960='js';_0x235e76['sdk.'+_0x106960+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x235e76['framework.cordova']=0x1:qr()&&(_0x235e76['framework.reactnative']=0x1),this['reportStats'](_0x235e76);}['shouldReconnect_'](){const _0x1c07d5=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x1c07d5;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1e3c8c,_0x1c21ad){this['name']=_0x1e3c8c,this['node']=_0x1c21ad;}static['Wrap'](_0x599bd8,_0x5f06d4){return new E(_0x599bd8,_0x5f06d4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x168d93,_0x5bae40){const _0x319dcb=new E(xe,_0x168d93),_0x92cdfb=new E(xe,_0x5bae40);return this['compare'](_0x319dcb,_0x92cdfb)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x5cf42a){Xt=_0x5cf42a;}['compare'](_0x634a0a,_0x18136f){return He(_0x634a0a['name'],_0x18136f['name']);}['isDefinedOn'](_0x20074f){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4a1c07,_0x355b68){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x181f4d,_0x32102d){return f(typeof _0x181f4d=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x181f4d,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0xf8e9a9,_0x37eb16,_0x1f2797,_0x3a2378,_0x51f437=null){this['isReverse_']=_0x3a2378,this['resultGenerator_']=_0x51f437,this['nodeStack_']=[];let _0x8603f7=0x1;for(;!_0xf8e9a9['isEmpty']();)if(_0xf8e9a9=_0xf8e9a9,_0x8603f7=_0x37eb16?_0x1f2797(_0xf8e9a9['key'],_0x37eb16):0x1,_0x3a2378&&(_0x8603f7*=-0x1),_0x8603f7<0x0)this['isReverse_']?_0xf8e9a9=_0xf8e9a9['left']:_0xf8e9a9=_0xf8e9a9['right'];else{if(_0x8603f7===0x0){this['nodeStack_']['push'](_0xf8e9a9);break;}else this['nodeStack_']['push'](_0xf8e9a9),this['isReverse_']?_0xf8e9a9=_0xf8e9a9['right']:_0xf8e9a9=_0xf8e9a9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1a3e27=this['nodeStack_']['pop'](),_0x23b595;if(this['resultGenerator_']?_0x23b595=this['resultGenerator_'](_0x1a3e27['key'],_0x1a3e27['value']):_0x23b595={'key':_0x1a3e27['key'],'value':_0x1a3e27['value']},this['isReverse_']){for(_0x1a3e27=_0x1a3e27['left'];!_0x1a3e27['isEmpty']();)this['nodeStack_']['push'](_0x1a3e27),_0x1a3e27=_0x1a3e27['right'];}else{for(_0x1a3e27=_0x1a3e27['right'];!_0x1a3e27['isEmpty']();)this['nodeStack_']['push'](_0x1a3e27),_0x1a3e27=_0x1a3e27['left'];}return _0x23b595;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4a04b7=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4a04b7['key'],_0x4a04b7['value']):{'key':_0x4a04b7['key'],'value':_0x4a04b7['value']};}}class M{constructor(_0x41e638,_0x32ffdf,_0x2d02e3,_0x419d5f,_0x57729e){this['key']=_0x41e638,this['value']=_0x32ffdf,this['color']=_0x2d02e3??M['RED'],this['left']=_0x419d5f??B['EMPTY_NODE'],this['right']=_0x57729e??B['EMPTY_NODE'];}['copy'](_0x2e753f,_0x157824,_0x11b282,_0x2768fb,_0xc9150c){return new M(_0x2e753f??this['key'],_0x157824??this['value'],_0x11b282??this['color'],_0x2768fb??this['left'],_0xc9150c??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3a53a5){return this['left']['inorderTraversal'](_0x3a53a5)||!!_0x3a53a5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3a53a5);}['reverseTraversal'](_0x3df786){return this['right']['reverseTraversal'](_0x3df786)||_0x3df786(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3df786);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x18eac1,_0x57a4f6,_0x1e074d){let _0x1c80e0=this;const _0x3e20d0=_0x1e074d(_0x18eac1,_0x1c80e0['key']);return _0x3e20d0<0x0?_0x1c80e0=_0x1c80e0['copy'](null,null,null,_0x1c80e0['left']['insert'](_0x18eac1,_0x57a4f6,_0x1e074d),null):_0x3e20d0===0x0?_0x1c80e0=_0x1c80e0['copy'](null,_0x57a4f6,null,null,null):_0x1c80e0=_0x1c80e0['copy'](null,null,null,null,_0x1c80e0['right']['insert'](_0x18eac1,_0x57a4f6,_0x1e074d)),_0x1c80e0['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x7e12ca=this;return!_0x7e12ca['left']['isRed_']()&&!_0x7e12ca['left']['left']['isRed_']()&&(_0x7e12ca=_0x7e12ca['moveRedLeft_']()),_0x7e12ca=_0x7e12ca['copy'](null,null,null,_0x7e12ca['left']['removeMin_'](),null),_0x7e12ca['fixUp_']();}['remove'](_0x25696f,_0x2a8234){let _0x4293a0,_0x2403a9;if(_0x4293a0=this,_0x2a8234(_0x25696f,_0x4293a0['key'])<0x0)!_0x4293a0['left']['isEmpty']()&&!_0x4293a0['left']['isRed_']()&&!_0x4293a0['left']['left']['isRed_']()&&(_0x4293a0=_0x4293a0['moveRedLeft_']()),_0x4293a0=_0x4293a0['copy'](null,null,null,_0x4293a0['left']['remove'](_0x25696f,_0x2a8234),null);else{if(_0x4293a0['left']['isRed_']()&&(_0x4293a0=_0x4293a0['rotateRight_']()),!_0x4293a0['right']['isEmpty']()&&!_0x4293a0['right']['isRed_']()&&!_0x4293a0['right']['left']['isRed_']()&&(_0x4293a0=_0x4293a0['moveRedRight_']()),_0x2a8234(_0x25696f,_0x4293a0['key'])===0x0){if(_0x4293a0['right']['isEmpty']())return B['EMPTY_NODE'];_0x2403a9=_0x4293a0['right']['min_'](),_0x4293a0=_0x4293a0['copy'](_0x2403a9['key'],_0x2403a9['value'],null,null,_0x4293a0['right']['removeMin_']());}_0x4293a0=_0x4293a0['copy'](null,null,null,null,_0x4293a0['right']['remove'](_0x25696f,_0x2a8234));}return _0x4293a0['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x15e167=this;return _0x15e167['right']['isRed_']()&&!_0x15e167['left']['isRed_']()&&(_0x15e167=_0x15e167['rotateLeft_']()),_0x15e167['left']['isRed_']()&&_0x15e167['left']['left']['isRed_']()&&(_0x15e167=_0x15e167['rotateRight_']()),_0x15e167['left']['isRed_']()&&_0x15e167['right']['isRed_']()&&(_0x15e167=_0x15e167['colorFlip_']()),_0x15e167;}['moveRedLeft_'](){let _0x33cd66=this['colorFlip_']();return _0x33cd66['right']['left']['isRed_']()&&(_0x33cd66=_0x33cd66['copy'](null,null,null,null,_0x33cd66['right']['rotateRight_']()),_0x33cd66=_0x33cd66['rotateLeft_'](),_0x33cd66=_0x33cd66['colorFlip_']()),_0x33cd66;}['moveRedRight_'](){let _0x4277bd=this['colorFlip_']();return _0x4277bd['left']['left']['isRed_']()&&(_0x4277bd=_0x4277bd['rotateRight_'](),_0x4277bd=_0x4277bd['colorFlip_']()),_0x4277bd;}['rotateLeft_'](){const _0x4cf1ca=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4cf1ca,null);}['rotateRight_'](){const _0x32e1e0=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x32e1e0);}['colorFlip_'](){const _0xff74f6=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3a1361=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xff74f6,_0x3a1361);}['checkMaxDepth_'](){const _0xc53701=this['check_']();return Math['pow'](0x2,_0xc53701)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x56bc30=this['left']['check_']();if(_0x56bc30!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x56bc30+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x4d8dfc,_0x537634,_0x342a48,_0x578a47,_0x502efb){return this;}['insert'](_0xee66d2,_0x18eb65,_0x39c2af){return new M(_0xee66d2,_0x18eb65,null);}['remove'](_0x82da52,_0xf92c25){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xe6eb26){return!0x1;}['reverseTraversal'](_0x1019c3){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x181932,_0x4b3f51=B['EMPTY_NODE']){this['comparator_']=_0x181932,this['root_']=_0x4b3f51;}['insert'](_0x231033,_0x534783){return new B(this['comparator_'],this['root_']['insert'](_0x231033,_0x534783,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3e59c4){return new B(this['comparator_'],this['root_']['remove'](_0x3e59c4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xfb0553){let _0x14db9a,_0x2b1c19=this['root_'];for(;!_0x2b1c19['isEmpty']();){if(_0x14db9a=this['comparator_'](_0xfb0553,_0x2b1c19['key']),_0x14db9a===0x0)return _0x2b1c19['value'];_0x14db9a<0x0?_0x2b1c19=_0x2b1c19['left']:_0x14db9a>0x0&&(_0x2b1c19=_0x2b1c19['right']);}return null;}['getPredecessorKey'](_0xca51dc){let _0x3a1bd8,_0x329ab3=this['root_'],_0x268565=null;for(;!_0x329ab3['isEmpty']();)if(_0x3a1bd8=this['comparator_'](_0xca51dc,_0x329ab3['key']),_0x3a1bd8===0x0){if(_0x329ab3['left']['isEmpty']())return _0x268565?_0x268565['key']:null;for(_0x329ab3=_0x329ab3['left'];!_0x329ab3['right']['isEmpty']();)_0x329ab3=_0x329ab3['right'];return _0x329ab3['key'];}else _0x3a1bd8<0x0?_0x329ab3=_0x329ab3['left']:_0x3a1bd8>0x0&&(_0x268565=_0x329ab3,_0x329ab3=_0x329ab3['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x486d05){return this['root_']['inorderTraversal'](_0x486d05);}['reverseTraversal'](_0x5df17e){return this['root_']['reverseTraversal'](_0x5df17e);}['getIterator'](_0x111894){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x111894);}['getIteratorFrom'](_0x38cabe,_0x5d26f4){return new Zt(this['root_'],_0x38cabe,this['comparator_'],!0x1,_0x5d26f4);}['getReverseIteratorFrom'](_0x5b6597,_0x457494){return new Zt(this['root_'],_0x5b6597,this['comparator_'],!0x0,_0x457494);}['getReverseIterator'](_0xe942d4){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0xe942d4);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x23c365,_0xfdeb9b){return He(_0x23c365['name'],_0xfdeb9b['name']);}function ji(_0x542391,_0x1cfef5){return He(_0x542391,_0x1cfef5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x10b00b){vi=_0x10b00b;}const Ro=function(_0x437dfc){return typeof _0x437dfc=='number'?'number:'+so(_0x437dfc):'string:'+_0x437dfc;},Ao=function(_0x1fa959){if(_0x1fa959['isLeafNode']()){const _0x2e1caf=_0x1fa959['val']();f(typeof _0x2e1caf=='string'||typeof _0x2e1caf=='number'||typeof _0x2e1caf=='object'&&Y(_0x2e1caf,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1fa959===vi||_0x1fa959['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1fa959===vi||_0x1fa959['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x41382d){er=_0x41382d;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x261b99,_0x5c8060=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x261b99,this['priorityNode_']=_0x5c8060,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4eafbe){return new D(this['value_'],_0x4eafbe);}['getImmediateChild'](_0x456cb3){return _0x456cb3==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x405a8f){return v(_0x405a8f)?this:y(_0x405a8f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1cedfd,_0x2db832){return null;}['updateImmediateChild'](_0x42a3eb,_0x1897ee){return _0x42a3eb==='.priority'?this['updatePriority'](_0x1897ee):_0x1897ee['isEmpty']()&&_0x42a3eb!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x42a3eb,_0x1897ee)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x393a99,_0x31dca5){const _0x1b4a69=y(_0x393a99);return _0x1b4a69===null?_0x31dca5:_0x31dca5['isEmpty']()&&_0x1b4a69!=='.priority'?this:(f(_0x1b4a69!=='.priority'||we(_0x393a99)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1b4a69,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x393a99),_0x31dca5)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2639d0,_0x345421){return!0x1;}['val'](_0x14d805){return _0x14d805&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x48e5b9='';this['priorityNode_']['isEmpty']()||(_0x48e5b9+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x435854=typeof this['value_'];_0x48e5b9+=_0x435854+':',_0x435854==='number'?_0x48e5b9+=so(this['value_']):_0x48e5b9+=this['value_'],this['lazyHash_']=no(_0x48e5b9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1de013){return _0x1de013===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1de013 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1de013['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1de013));}['compareToLeafNode_'](_0x21087c){const _0x3639a0=typeof _0x21087c['value_'],_0x5727c9=typeof this['value_'],_0x31bcab=D['VALUE_TYPE_ORDER']['indexOf'](_0x3639a0),_0x2f7f56=D['VALUE_TYPE_ORDER']['indexOf'](_0x5727c9);return f(_0x31bcab>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3639a0),f(_0x2f7f56>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5727c9),_0x31bcab===_0x2f7f56?_0x5727c9==='object'?0x0:this['value_']<_0x21087c['value_']?-0x1:this['value_']===_0x21087c['value_']?0x0:0x1:_0x2f7f56-_0x31bcab;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3865bd){if(_0x3865bd===this)return!0x0;if(_0x3865bd['isLeafNode']()){const _0x5d5078=_0x3865bd;return this['value_']===_0x5d5078['value_']&&this['priorityNode_']['equals'](_0x5d5078['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x21b794){ko=_0x21b794;}function xh(_0x37fab7){No=_0x37fab7;}class Fh extends On{['compare'](_0xd16164,_0x544018){const _0xf4591b=_0xd16164['node']['getPriority'](),_0x4944e9=_0x544018['node']['getPriority'](),_0x2d7221=_0xf4591b['compareTo'](_0x4944e9);return _0x2d7221===0x0?He(_0xd16164['name'],_0x544018['name']):_0x2d7221;}['isDefinedOn'](_0x14b065){return!_0x14b065['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x45b0f2,_0x56ebcb){return!_0x45b0f2['getPriority']()['equals'](_0x56ebcb['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2f4757,_0x3ce655){const _0x394da6=ko(_0x2f4757);return new E(_0x3ce655,new D('[PRIORITY-POST]',_0x394da6));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0xf36768){const _0x3c5615=_0x6d6aee=>parseInt(Math['log'](_0x6d6aee)/Uh,0xa),_0x192ca6=_0x195b5f=>parseInt(Array(_0x195b5f+0x1)['join']('1'),0x2);this['count']=_0x3c5615(_0xf36768+0x1),this['current_']=this['count']-0x1;const _0x5d66cc=_0x192ca6(this['count']);this['bits_']=_0xf36768+0x1&_0x5d66cc;}['nextBitIsOne'](){const _0x469fa6=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x469fa6;}}const dn=function(_0x45ed79,_0x587bb0,_0x32db19,_0x233d7a){_0x45ed79['sort'](_0x587bb0);const _0x360021=function(_0xc31ec7,_0x353abe){const _0xf28d56=_0x353abe-_0xc31ec7;let _0x46b230,_0x38deac;if(_0xf28d56===0x0)return null;if(_0xf28d56===0x1)return _0x46b230=_0x45ed79[_0xc31ec7],_0x38deac=_0x32db19?_0x32db19(_0x46b230):_0x46b230,new M(_0x38deac,_0x46b230['node'],M['BLACK'],null,null);{const _0x54dae3=parseInt(_0xf28d56/0x2,0xa)+_0xc31ec7,_0x4c6ca1=_0x360021(_0xc31ec7,_0x54dae3),_0x30a9a6=_0x360021(_0x54dae3+0x1,_0x353abe);return _0x46b230=_0x45ed79[_0x54dae3],_0x38deac=_0x32db19?_0x32db19(_0x46b230):_0x46b230,new M(_0x38deac,_0x46b230['node'],M['BLACK'],_0x4c6ca1,_0x30a9a6);}},_0x303328=function(_0x566a86){let _0x517b17=null,_0x2d274d=null,_0x25b561=_0x45ed79['length'];const _0x1f33b2=function(_0x4af1dd,_0x425daa){const _0x591212=_0x25b561-_0x4af1dd,_0xfa4cde=_0x25b561;_0x25b561-=_0x4af1dd;const _0x57c2fc=_0x360021(_0x591212+0x1,_0xfa4cde),_0x6d7324=_0x45ed79[_0x591212],_0x3a6522=_0x32db19?_0x32db19(_0x6d7324):_0x6d7324;_0x5d5334(new M(_0x3a6522,_0x6d7324['node'],_0x425daa,null,_0x57c2fc));},_0x5d5334=function(_0x559b6f){_0x517b17?(_0x517b17['left']=_0x559b6f,_0x517b17=_0x559b6f):(_0x2d274d=_0x559b6f,_0x517b17=_0x559b6f);};for(let _0x57ba08=0x0;_0x57ba08<_0x566a86['count'];++_0x57ba08){const _0xcdc45b=_0x566a86['nextBitIsOne'](),_0x33016b=Math['pow'](0x2,_0x566a86['count']-(_0x57ba08+0x1));_0xcdc45b?_0x1f33b2(_0x33016b,M['BLACK']):(_0x1f33b2(_0x33016b,M['BLACK']),_0x1f33b2(_0x33016b,M['RED']));}return _0x2d274d;},_0x2c27cc=new Wh(_0x45ed79['length']),_0x1e73c5=_0x303328(_0x2c27cc);return new B(_0x233d7a||_0x587bb0,_0x1e73c5);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x27c82e,_0x460020){this['indexes_']=_0x27c82e,this['indexSet_']=_0x460020;}['get'](_0x3afb2c){const _0x4660d9=Oe(this['indexes_'],_0x3afb2c);if(!_0x4660d9)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3afb2c);return _0x4660d9 instanceof B?_0x4660d9:null;}['hasIndex'](_0x4dc5a){return Y(this['indexSet_'],_0x4dc5a['toString']());}['addIndex'](_0x4890a1,_0x1d282f){f(_0x4890a1!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1669c0=[];let _0x1a190b=!0x1;const _0x5e6456=_0x1d282f['getIterator'](E['Wrap']);let _0x39da14=_0x5e6456['getNext']();for(;_0x39da14;)_0x1a190b=_0x1a190b||_0x4890a1['isDefinedOn'](_0x39da14['node']),_0x1669c0['push'](_0x39da14),_0x39da14=_0x5e6456['getNext']();let _0x4601f2;_0x1a190b?_0x4601f2=dn(_0x1669c0,_0x4890a1['getCompare']()):_0x4601f2=je;const _0x720833=_0x4890a1['toString'](),_0x2fb70c={...this['indexSet_']};_0x2fb70c[_0x720833]=_0x4890a1;const _0x5a2745={...this['indexes_']};return _0x5a2745[_0x720833]=_0x4601f2,new ee(_0x5a2745,_0x2fb70c);}['addToIndexes'](_0x26c0e3,_0x128b20){const _0x31b4b4=ln(this['indexes_'],(_0x409a2b,_0x530420)=>{const _0x5213e0=Oe(this['indexSet_'],_0x530420);if(f(_0x5213e0,'Missing\x20index\x20implementation\x20for\x20'+_0x530420),_0x409a2b===je){if(_0x5213e0['isDefinedOn'](_0x26c0e3['node'])){const _0x2d05f=[],_0x408251=_0x128b20['getIterator'](E['Wrap']);let _0x7c6811=_0x408251['getNext']();for(;_0x7c6811;)_0x7c6811['name']!==_0x26c0e3['name']&&_0x2d05f['push'](_0x7c6811),_0x7c6811=_0x408251['getNext']();return _0x2d05f['push'](_0x26c0e3),dn(_0x2d05f,_0x5213e0['getCompare']());}else return je;}else{const _0x540623=_0x128b20['get'](_0x26c0e3['name']);let _0x1e29bd=_0x409a2b;return _0x540623&&(_0x1e29bd=_0x1e29bd['remove'](new E(_0x26c0e3['name'],_0x540623))),_0x1e29bd['insert'](_0x26c0e3,_0x26c0e3['node']);}});return new ee(_0x31b4b4,this['indexSet_']);}['removeFromIndexes'](_0xcc3e97,_0x1537bc){const _0xe52d37=ln(this['indexes_'],_0x268e27=>{if(_0x268e27===je)return _0x268e27;{const _0x18c2cd=_0x1537bc['get'](_0xcc3e97['name']);return _0x18c2cd?_0x268e27['remove'](new E(_0xcc3e97['name'],_0x18c2cd)):_0x268e27;}});return new ee(_0xe52d37,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x252119,_0x31037f,_0x580a27){this['children_']=_0x252119,this['priorityNode_']=_0x31037f,this['indexMap_']=_0x580a27,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x2536ff){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2536ff,this['indexMap_']);}['getImmediateChild'](_0x23f132){if(_0x23f132==='.priority')return this['getPriority']();{const _0x3db288=this['children_']['get'](_0x23f132);return _0x3db288===null?gt:_0x3db288;}}['getChild'](_0x5f5cd9){const _0x2cd095=y(_0x5f5cd9);return _0x2cd095===null?this:this['getImmediateChild'](_0x2cd095)['getChild'](b(_0x5f5cd9));}['hasChild'](_0x4859a8){return this['children_']['get'](_0x4859a8)!==null;}['updateImmediateChild'](_0x61d484,_0x3349a7){if(f(_0x3349a7,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x61d484==='.priority')return this['updatePriority'](_0x3349a7);{const _0x2cd255=new E(_0x61d484,_0x3349a7);let _0x463b67,_0x47df58;_0x3349a7['isEmpty']()?(_0x463b67=this['children_']['remove'](_0x61d484),_0x47df58=this['indexMap_']['removeFromIndexes'](_0x2cd255,this['children_'])):(_0x463b67=this['children_']['insert'](_0x61d484,_0x3349a7),_0x47df58=this['indexMap_']['addToIndexes'](_0x2cd255,this['children_']));const _0x267e26=_0x463b67['isEmpty']()?gt:this['priorityNode_'];return new g(_0x463b67,_0x267e26,_0x47df58);}}['updateChild'](_0x326f34,_0x32988c){const _0x47aba5=y(_0x326f34);if(_0x47aba5===null)return _0x32988c;{f(y(_0x326f34)!=='.priority'||we(_0x326f34)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5f0630=this['getImmediateChild'](_0x47aba5)['updateChild'](b(_0x326f34),_0x32988c);return this['updateImmediateChild'](_0x47aba5,_0x5f0630);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2ccbbc){if(this['isEmpty']())return null;const _0x25903a={};let _0x2e16f1=0x0,_0x52fcf4=0x0,_0xb1e312=!0x0;if(this['forEachChild'](R,(_0x429d7d,_0x54f132)=>{_0x25903a[_0x429d7d]=_0x54f132['val'](_0x2ccbbc),_0x2e16f1++,_0xb1e312&&g['INTEGER_REGEXP_']['test'](_0x429d7d)?_0x52fcf4=Math['max'](_0x52fcf4,Number(_0x429d7d)):_0xb1e312=!0x1;}),!_0x2ccbbc&&_0xb1e312&&_0x52fcf4<0x2*_0x2e16f1){const _0x17f52f=[];for(const _0x328a2d in _0x25903a)_0x17f52f[_0x328a2d]=_0x25903a[_0x328a2d];return _0x17f52f;}else return _0x2ccbbc&&!this['getPriority']()['isEmpty']()&&(_0x25903a['.priority']=this['getPriority']()['val']()),_0x25903a;}['hash'](){if(this['lazyHash_']===null){let _0x542c26='';this['getPriority']()['isEmpty']()||(_0x542c26+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4265a5,_0x2011b7)=>{const _0x5198af=_0x2011b7['hash']();_0x5198af!==''&&(_0x542c26+=':'+_0x4265a5+':'+_0x5198af);}),this['lazyHash_']=_0x542c26===''?'':no(_0x542c26);}return this['lazyHash_'];}['getPredecessorChildName'](_0xe9b802,_0x19cba4,_0x43a7b4){const _0x18ebcd=this['resolveIndex_'](_0x43a7b4);if(_0x18ebcd){const _0x1be0fc=_0x18ebcd['getPredecessorKey'](new E(_0xe9b802,_0x19cba4));return _0x1be0fc?_0x1be0fc['name']:null;}else return this['children_']['getPredecessorKey'](_0xe9b802);}['getFirstChildName'](_0x5a479b){const _0x562fe0=this['resolveIndex_'](_0x5a479b);if(_0x562fe0){const _0x3e9824=_0x562fe0['minKey']();return _0x3e9824&&_0x3e9824['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4eb685){const _0x333ed1=this['getFirstChildName'](_0x4eb685);return _0x333ed1?new E(_0x333ed1,this['children_']['get'](_0x333ed1)):null;}['getLastChildName'](_0x5c99ee){const _0x1c020c=this['resolveIndex_'](_0x5c99ee);if(_0x1c020c){const _0x5c4998=_0x1c020c['maxKey']();return _0x5c4998&&_0x5c4998['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x403403){const _0x134f43=this['getLastChildName'](_0x403403);return _0x134f43?new E(_0x134f43,this['children_']['get'](_0x134f43)):null;}['forEachChild'](_0x273b72,_0x5bdd2b){const _0x249818=this['resolveIndex_'](_0x273b72);return _0x249818?_0x249818['inorderTraversal'](_0x3f702f=>_0x5bdd2b(_0x3f702f['name'],_0x3f702f['node'])):this['children_']['inorderTraversal'](_0x5bdd2b);}['getIterator'](_0x3cc4c8){return this['getIteratorFrom'](_0x3cc4c8['minPost'](),_0x3cc4c8);}['getIteratorFrom'](_0x45a3cd,_0x598bae){const _0xc492e3=this['resolveIndex_'](_0x598bae);if(_0xc492e3)return _0xc492e3['getIteratorFrom'](_0x45a3cd,_0x132a7e=>_0x132a7e);{const _0x44934e=this['children_']['getIteratorFrom'](_0x45a3cd['name'],E['Wrap']);let _0x46e998=_0x44934e['peek']();for(;_0x46e998!=null&&_0x598bae['compare'](_0x46e998,_0x45a3cd)<0x0;)_0x44934e['getNext'](),_0x46e998=_0x44934e['peek']();return _0x44934e;}}['getReverseIterator'](_0x3bdf8b){return this['getReverseIteratorFrom'](_0x3bdf8b['maxPost'](),_0x3bdf8b);}['getReverseIteratorFrom'](_0x3a6760,_0x46367a){const _0x569e30=this['resolveIndex_'](_0x46367a);if(_0x569e30)return _0x569e30['getReverseIteratorFrom'](_0x3a6760,_0x32b552=>_0x32b552);{const _0x1127b8=this['children_']['getReverseIteratorFrom'](_0x3a6760['name'],E['Wrap']);let _0xecca8f=_0x1127b8['peek']();for(;_0xecca8f!=null&&_0x46367a['compare'](_0xecca8f,_0x3a6760)>0x0;)_0x1127b8['getNext'](),_0xecca8f=_0x1127b8['peek']();return _0x1127b8;}}['compareTo'](_0x27b013){return this['isEmpty']()?_0x27b013['isEmpty']()?0x0:-0x1:_0x27b013['isLeafNode']()||_0x27b013['isEmpty']()?0x1:_0x27b013===Ht?-0x1:0x0;}['withIndex'](_0xfdb05){if(_0xfdb05===ye||this['indexMap_']['hasIndex'](_0xfdb05))return this;{const _0x5bb93a=this['indexMap_']['addIndex'](_0xfdb05,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5bb93a);}}['isIndexed'](_0x56493b){return _0x56493b===ye||this['indexMap_']['hasIndex'](_0x56493b);}['equals'](_0x294931){if(_0x294931===this)return!0x0;if(_0x294931['isLeafNode']())return!0x1;{const _0x43a067=_0x294931;if(this['getPriority']()['equals'](_0x43a067['getPriority']())){if(this['children_']['count']()===_0x43a067['children_']['count']()){const _0x1507a7=this['getIterator'](R),_0x1fc3a6=_0x43a067['getIterator'](R);let _0x3a7d7d=_0x1507a7['getNext'](),_0x2d59df=_0x1fc3a6['getNext']();for(;_0x3a7d7d&&_0x2d59df;){if(_0x3a7d7d['name']!==_0x2d59df['name']||!_0x3a7d7d['node']['equals'](_0x2d59df['node']))return!0x1;_0x3a7d7d=_0x1507a7['getNext'](),_0x2d59df=_0x1fc3a6['getNext']();}return _0x3a7d7d===null&&_0x2d59df===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xac8d46){return _0xac8d46===ye?null:this['indexMap_']['get'](_0xac8d46['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x211bb9){return _0x211bb9===this?0x0:0x1;}['equals'](_0x2617e1){return _0x2617e1===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5e1660){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5c8e69,_0x172d51=null){if(_0x5c8e69===null)return g['EMPTY_NODE'];if(typeof _0x5c8e69=='object'&&'.priority'in _0x5c8e69&&(_0x172d51=_0x5c8e69['.priority']),f(_0x172d51===null||typeof _0x172d51=='string'||typeof _0x172d51=='number'||typeof _0x172d51=='object'&&'.sv'in _0x172d51,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x172d51),typeof _0x5c8e69=='object'&&'.value'in _0x5c8e69&&_0x5c8e69['.value']!==null&&(_0x5c8e69=_0x5c8e69['.value']),typeof _0x5c8e69!='object'||'.sv'in _0x5c8e69){const _0x187e26=_0x5c8e69;return new D(_0x187e26,N(_0x172d51));}if(!(_0x5c8e69 instanceof Array)&&Vh){const _0x5dabac=[];let _0x162303=!0x1;if(x(_0x5c8e69,(_0x4fea22,_0x20d191)=>{if(_0x4fea22['substring'](0x0,0x1)!=='.'){const _0xae08d8=N(_0x20d191);_0xae08d8['isEmpty']()||(_0x162303=_0x162303||!_0xae08d8['getPriority']()['isEmpty'](),_0x5dabac['push'](new E(_0x4fea22,_0xae08d8)));}}),_0x5dabac['length']===0x0)return g['EMPTY_NODE'];const _0x33c390=dn(_0x5dabac,Dh,_0xed120f=>_0xed120f['name'],ji);if(_0x162303){const _0x2ba962=dn(_0x5dabac,R['getCompare']());return new g(_0x33c390,N(_0x172d51),new ee({'.priority':_0x2ba962},{'.priority':R}));}else return new g(_0x33c390,N(_0x172d51),ee['Default']);}else{let _0x304973=g['EMPTY_NODE'];return x(_0x5c8e69,(_0x34a0fa,_0x5357e9)=>{if(Y(_0x5c8e69,_0x34a0fa)&&_0x34a0fa['substring'](0x0,0x1)!=='.'){const _0x2aad7a=N(_0x5357e9);(_0x2aad7a['isLeafNode']()||!_0x2aad7a['isEmpty']())&&(_0x304973=_0x304973['updateImmediateChild'](_0x34a0fa,_0x2aad7a));}}),_0x304973['updatePriority'](N(_0x172d51));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x4fce12){super(),this['indexPath_']=_0x4fce12,f(!v(_0x4fce12)&&y(_0x4fce12)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x430346){return _0x430346['getChild'](this['indexPath_']);}['isDefinedOn'](_0x42e3df){return!_0x42e3df['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5e1e53,_0x20f80c){const _0x161850=this['extractChild'](_0x5e1e53['node']),_0xe96734=this['extractChild'](_0x20f80c['node']),_0x468a62=_0x161850['compareTo'](_0xe96734);return _0x468a62===0x0?He(_0x5e1e53['name'],_0x20f80c['name']):_0x468a62;}['makePost'](_0x3529f8,_0x573072){const _0x309d62=N(_0x3529f8),_0x2cb622=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x309d62);return new E(_0x573072,_0x2cb622);}['maxPost'](){const _0x44e3cd=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x44e3cd);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x141e84,_0x1b2e7f){const _0x42b8b2=_0x141e84['node']['compareTo'](_0x1b2e7f['node']);return _0x42b8b2===0x0?He(_0x141e84['name'],_0x1b2e7f['name']):_0x42b8b2;}['isDefinedOn'](_0xebde9b){return!0x0;}['indexedValueChanged'](_0x1f81fe,_0x38a32b){return!_0x1f81fe['equals'](_0x38a32b);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5302b0,_0x1a2846){const _0x3963e2=N(_0x5302b0);return new E(_0x1a2846,_0x3963e2);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x58213e){return{'type':'value','snapshotNode':_0x58213e};}function tt(_0x4a7f6a,_0x31bbd3){return{'type':'child_added','snapshotNode':_0x31bbd3,'childName':_0x4a7f6a};}function Nt(_0x2410d4,_0x4aa25e){return{'type':'child_removed','snapshotNode':_0x4aa25e,'childName':_0x2410d4};}function Pt(_0x2830ff,_0x5b4932,_0xcd5df6){return{'type':'child_changed','snapshotNode':_0x5b4932,'childName':_0x2830ff,'oldSnap':_0xcd5df6};}function $h(_0x43012c,_0x1677ea){return{'type':'child_moved','snapshotNode':_0x1677ea,'childName':_0x43012c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0xfcd328){this['index_']=_0xfcd328;}['updateChild'](_0x5542c0,_0x4d9b75,_0x526005,_0x3ef4ab,_0x417551,_0x8489a9){f(_0x5542c0['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5465e3=_0x5542c0['getImmediateChild'](_0x4d9b75);return _0x5465e3['getChild'](_0x3ef4ab)['equals'](_0x526005['getChild'](_0x3ef4ab))&&_0x5465e3['isEmpty']()===_0x526005['isEmpty']()||(_0x8489a9!=null&&(_0x526005['isEmpty']()?_0x5542c0['hasChild'](_0x4d9b75)?_0x8489a9['trackChildChange'](Nt(_0x4d9b75,_0x5465e3)):f(_0x5542c0['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5465e3['isEmpty']()?_0x8489a9['trackChildChange'](tt(_0x4d9b75,_0x526005)):_0x8489a9['trackChildChange'](Pt(_0x4d9b75,_0x526005,_0x5465e3))),_0x5542c0['isLeafNode']()&&_0x526005['isEmpty']())?_0x5542c0:_0x5542c0['updateImmediateChild'](_0x4d9b75,_0x526005)['withIndex'](this['index_']);}['updateFullNode'](_0x586dee,_0x466676,_0x29c9f7){return _0x29c9f7!=null&&(_0x586dee['isLeafNode']()||_0x586dee['forEachChild'](R,(_0x173602,_0x23a4b4)=>{_0x466676['hasChild'](_0x173602)||_0x29c9f7['trackChildChange'](Nt(_0x173602,_0x23a4b4));}),_0x466676['isLeafNode']()||_0x466676['forEachChild'](R,(_0x47ecb3,_0x297199)=>{if(_0x586dee['hasChild'](_0x47ecb3)){const _0x23c337=_0x586dee['getImmediateChild'](_0x47ecb3);_0x23c337['equals'](_0x297199)||_0x29c9f7['trackChildChange'](Pt(_0x47ecb3,_0x297199,_0x23c337));}else _0x29c9f7['trackChildChange'](tt(_0x47ecb3,_0x297199));})),_0x466676['withIndex'](this['index_']);}['updatePriority'](_0x53c784,_0x2b30fd){return _0x53c784['isEmpty']()?g['EMPTY_NODE']:_0x53c784['updatePriority'](_0x2b30fd);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x428a30){this['indexedFilter_']=new Yi(_0x428a30['getIndex']()),this['index_']=_0x428a30['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x428a30),this['endPost_']=Ot['getEndPost_'](_0x428a30),this['startIsInclusive_']=!_0x428a30['startAfterSet_'],this['endIsInclusive_']=!_0x428a30['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x52b0d6){const _0x253f5c=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x52b0d6)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x52b0d6)<0x0,_0x47669f=this['endIsInclusive_']?this['index_']['compare'](_0x52b0d6,this['getEndPost']())<=0x0:this['index_']['compare'](_0x52b0d6,this['getEndPost']())<0x0;return _0x253f5c&&_0x47669f;}['updateChild'](_0xd18614,_0x57d478,_0x1880e6,_0x1a7c54,_0x21ecd6,_0x295bef){return this['matches'](new E(_0x57d478,_0x1880e6))||(_0x1880e6=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xd18614,_0x57d478,_0x1880e6,_0x1a7c54,_0x21ecd6,_0x295bef);}['updateFullNode'](_0x3fdf82,_0x1f6af1,_0x3f26e3){_0x1f6af1['isLeafNode']()&&(_0x1f6af1=g['EMPTY_NODE']);let _0xfe1e50=_0x1f6af1['withIndex'](this['index_']);_0xfe1e50=_0xfe1e50['updatePriority'](g['EMPTY_NODE']);const _0x49bf03=this;return _0x1f6af1['forEachChild'](R,(_0x48ad1a,_0x34c60c)=>{_0x49bf03['matches'](new E(_0x48ad1a,_0x34c60c))||(_0xfe1e50=_0xfe1e50['updateImmediateChild'](_0x48ad1a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3fdf82,_0xfe1e50,_0x3f26e3);}['updatePriority'](_0x246e8e,_0x313767){return _0x246e8e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x51d555){if(_0x51d555['hasStart']()){const _0x500d16=_0x51d555['getIndexStartName']();return _0x51d555['getIndex']()['makePost'](_0x51d555['getIndexStartValue'](),_0x500d16);}else return _0x51d555['getIndex']()['minPost']();}static['getEndPost_'](_0x5639be){if(_0x5639be['hasEnd']()){const _0x2a6085=_0x5639be['getIndexEndName']();return _0x5639be['getIndex']()['makePost'](_0x5639be['getIndexEndValue'](),_0x2a6085);}else return _0x5639be['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x49dc4e){this['withinDirectionalStart']=_0x49442b=>this['reverse_']?this['withinEndPost'](_0x49442b):this['withinStartPost'](_0x49442b),this['withinDirectionalEnd']=_0x2d1c70=>this['reverse_']?this['withinStartPost'](_0x2d1c70):this['withinEndPost'](_0x2d1c70),this['withinStartPost']=_0x468827=>{const _0x186dae=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x468827);return this['startIsInclusive_']?_0x186dae<=0x0:_0x186dae<0x0;},this['withinEndPost']=_0x27ee84=>{const _0x43aa0e=this['index_']['compare'](_0x27ee84,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x43aa0e<=0x0:_0x43aa0e<0x0;},this['rangedFilter_']=new Ot(_0x49dc4e),this['index_']=_0x49dc4e['getIndex'](),this['limit_']=_0x49dc4e['getLimit'](),this['reverse_']=!_0x49dc4e['isViewFromLeft'](),this['startIsInclusive_']=!_0x49dc4e['startAfterSet_'],this['endIsInclusive_']=!_0x49dc4e['endBeforeSet_'];}['updateChild'](_0x305ccc,_0x19aab3,_0x58b41e,_0x3f96c7,_0x44431f,_0x1a794f){return this['rangedFilter_']['matches'](new E(_0x19aab3,_0x58b41e))||(_0x58b41e=g['EMPTY_NODE']),_0x305ccc['getImmediateChild'](_0x19aab3)['equals'](_0x58b41e)?_0x305ccc:_0x305ccc['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x305ccc,_0x19aab3,_0x58b41e,_0x3f96c7,_0x44431f,_0x1a794f):this['fullLimitUpdateChild_'](_0x305ccc,_0x19aab3,_0x58b41e,_0x44431f,_0x1a794f);}['updateFullNode'](_0x1dde9b,_0x55a580,_0x55ea52){let _0x22db5d;if(_0x55a580['isLeafNode']()||_0x55a580['isEmpty']())_0x22db5d=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x55a580['numChildren']()&&_0x55a580['isIndexed'](this['index_'])){_0x22db5d=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4949ef;this['reverse_']?_0x4949ef=_0x55a580['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4949ef=_0x55a580['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x562100=0x0;for(;_0x4949ef['hasNext']()&&_0x562100<this['limit_'];){const _0x259693=_0x4949ef['getNext']();if(this['withinDirectionalStart'](_0x259693)){if(this['withinDirectionalEnd'](_0x259693))_0x22db5d=_0x22db5d['updateImmediateChild'](_0x259693['name'],_0x259693['node']),_0x562100++;else break;}else continue;}}else{_0x22db5d=_0x55a580['withIndex'](this['index_']),_0x22db5d=_0x22db5d['updatePriority'](g['EMPTY_NODE']);let _0x5935bb;this['reverse_']?_0x5935bb=_0x22db5d['getReverseIterator'](this['index_']):_0x5935bb=_0x22db5d['getIterator'](this['index_']);let _0x18e76a=0x0;for(;_0x5935bb['hasNext']();){const _0x411dc2=_0x5935bb['getNext']();_0x18e76a<this['limit_']&&this['withinDirectionalStart'](_0x411dc2)&&this['withinDirectionalEnd'](_0x411dc2)?_0x18e76a++:_0x22db5d=_0x22db5d['updateImmediateChild'](_0x411dc2['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1dde9b,_0x22db5d,_0x55ea52);}['updatePriority'](_0x1d149f,_0x579380){return _0x1d149f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x38100b,_0x77be33,_0x1389aa,_0x391192,_0x2b6507){let _0xb4a0cd;if(this['reverse_']){const _0x32a762=this['index_']['getCompare']();_0xb4a0cd=(_0x4fabf,_0x1a33a5)=>_0x32a762(_0x1a33a5,_0x4fabf);}else _0xb4a0cd=this['index_']['getCompare']();const _0x588201=_0x38100b;f(_0x588201['numChildren']()===this['limit_'],'');const _0x5f2017=new E(_0x77be33,_0x1389aa),_0x307989=this['reverse_']?_0x588201['getFirstChild'](this['index_']):_0x588201['getLastChild'](this['index_']),_0x1a0990=this['rangedFilter_']['matches'](_0x5f2017);if(_0x588201['hasChild'](_0x77be33)){const _0x15c8a9=_0x588201['getImmediateChild'](_0x77be33);let _0x28c6cd=_0x391192['getChildAfterChild'](this['index_'],_0x307989,this['reverse_']);for(;_0x28c6cd!=null&&(_0x28c6cd['name']===_0x77be33||_0x588201['hasChild'](_0x28c6cd['name']));)_0x28c6cd=_0x391192['getChildAfterChild'](this['index_'],_0x28c6cd,this['reverse_']);const _0xbd8838=_0x28c6cd==null?0x1:_0xb4a0cd(_0x28c6cd,_0x5f2017);if(_0x1a0990&&!_0x1389aa['isEmpty']()&&_0xbd8838>=0x0)return _0x2b6507!=null&&_0x2b6507['trackChildChange'](Pt(_0x77be33,_0x1389aa,_0x15c8a9)),_0x588201['updateImmediateChild'](_0x77be33,_0x1389aa);{_0x2b6507!=null&&_0x2b6507['trackChildChange'](Nt(_0x77be33,_0x15c8a9));const _0x2c3da3=_0x588201['updateImmediateChild'](_0x77be33,g['EMPTY_NODE']);return _0x28c6cd!=null&&this['rangedFilter_']['matches'](_0x28c6cd)?(_0x2b6507!=null&&_0x2b6507['trackChildChange'](tt(_0x28c6cd['name'],_0x28c6cd['node'])),_0x2c3da3['updateImmediateChild'](_0x28c6cd['name'],_0x28c6cd['node'])):_0x2c3da3;}}else return _0x1389aa['isEmpty']()?_0x38100b:_0x1a0990&&_0xb4a0cd(_0x307989,_0x5f2017)>=0x0?(_0x2b6507!=null&&(_0x2b6507['trackChildChange'](Nt(_0x307989['name'],_0x307989['node'])),_0x2b6507['trackChildChange'](tt(_0x77be33,_0x1389aa))),_0x588201['updateImmediateChild'](_0x77be33,_0x1389aa)['updateImmediateChild'](_0x307989['name'],g['EMPTY_NODE'])):_0x38100b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x20c65c=new Qi();return _0x20c65c['limitSet_']=this['limitSet_'],_0x20c65c['limit_']=this['limit_'],_0x20c65c['startSet_']=this['startSet_'],_0x20c65c['startAfterSet_']=this['startAfterSet_'],_0x20c65c['indexStartValue_']=this['indexStartValue_'],_0x20c65c['startNameSet_']=this['startNameSet_'],_0x20c65c['indexStartName_']=this['indexStartName_'],_0x20c65c['endSet_']=this['endSet_'],_0x20c65c['endBeforeSet_']=this['endBeforeSet_'],_0x20c65c['indexEndValue_']=this['indexEndValue_'],_0x20c65c['endNameSet_']=this['endNameSet_'],_0x20c65c['indexEndName_']=this['indexEndName_'],_0x20c65c['index_']=this['index_'],_0x20c65c['viewFrom_']=this['viewFrom_'],_0x20c65c;}}function qh(_0x98d6d7){return _0x98d6d7['loadsAllData']()?new Yi(_0x98d6d7['getIndex']()):_0x98d6d7['hasLimit']()?new Gh(_0x98d6d7):new Ot(_0x98d6d7);}function zh(_0x406d9d,_0x574f2b){const _0x2c96f9=_0x406d9d['copy']();return _0x2c96f9['limitSet_']=!0x0,_0x2c96f9['limit_']=_0x574f2b,_0x2c96f9['viewFrom_']='l',_0x2c96f9;}function jh(_0x2dd23c,_0x2fe629,_0x663067){const _0x182289=_0x2dd23c['copy']();return _0x182289['startSet_']=!0x0,_0x2fe629===void 0x0&&(_0x2fe629=null),_0x182289['indexStartValue_']=_0x2fe629,_0x663067!=null?(_0x182289['startNameSet_']=!0x0,_0x182289['indexStartName_']=_0x663067):(_0x182289['startNameSet_']=!0x1,_0x182289['indexStartName_']=''),_0x182289;}function Kh(_0x7a8a62,_0x198c5c,_0x527a9){const _0x5afaf1=_0x7a8a62['copy']();return _0x5afaf1['endSet_']=!0x0,_0x198c5c===void 0x0&&(_0x198c5c=null),_0x5afaf1['indexEndValue_']=_0x198c5c,_0x527a9!==void 0x0?(_0x5afaf1['endNameSet_']=!0x0,_0x5afaf1['indexEndName_']=_0x527a9):(_0x5afaf1['endNameSet_']=!0x1,_0x5afaf1['indexEndName_']=''),_0x5afaf1;}function Do(_0x341127,_0x4a2dc6){const _0x4482b1=_0x341127['copy']();return _0x4482b1['index_']=_0x4a2dc6,_0x4482b1;}function tr(_0x5b83bd){const _0x5ef77b={};if(_0x5b83bd['isDefault']())return _0x5ef77b;let _0x21e829;if(_0x5b83bd['index_']===R?_0x21e829='$priority':_0x5b83bd['index_']===Po?_0x21e829='$value':_0x5b83bd['index_']===ye?_0x21e829='$key':(f(_0x5b83bd['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x21e829=_0x5b83bd['index_']['toString']()),_0x5ef77b['orderBy']=O(_0x21e829),_0x5b83bd['startSet_']){const _0x3f3a5e=_0x5b83bd['startAfterSet_']?'startAfter':'startAt';_0x5ef77b[_0x3f3a5e]=O(_0x5b83bd['indexStartValue_']),_0x5b83bd['startNameSet_']&&(_0x5ef77b[_0x3f3a5e]+=','+O(_0x5b83bd['indexStartName_']));}if(_0x5b83bd['endSet_']){const _0x1d00ab=_0x5b83bd['endBeforeSet_']?'endBefore':'endAt';_0x5ef77b[_0x1d00ab]=O(_0x5b83bd['indexEndValue_']),_0x5b83bd['endNameSet_']&&(_0x5ef77b[_0x1d00ab]+=','+O(_0x5b83bd['indexEndName_']));}return _0x5b83bd['limitSet_']&&(_0x5b83bd['isViewFromLeft']()?_0x5ef77b['limitToFirst']=_0x5b83bd['limit_']:_0x5ef77b['limitToLast']=_0x5b83bd['limit_']),_0x5ef77b;}function nr(_0x29d0ae){const _0x32db4a={};if(_0x29d0ae['startSet_']&&(_0x32db4a['sp']=_0x29d0ae['indexStartValue_'],_0x29d0ae['startNameSet_']&&(_0x32db4a['sn']=_0x29d0ae['indexStartName_']),_0x32db4a['sin']=!_0x29d0ae['startAfterSet_']),_0x29d0ae['endSet_']&&(_0x32db4a['ep']=_0x29d0ae['indexEndValue_'],_0x29d0ae['endNameSet_']&&(_0x32db4a['en']=_0x29d0ae['indexEndName_']),_0x32db4a['ein']=!_0x29d0ae['endBeforeSet_']),_0x29d0ae['limitSet_']){_0x32db4a['l']=_0x29d0ae['limit_'];let _0x560350=_0x29d0ae['viewFrom_'];_0x560350===''&&(_0x29d0ae['isViewFromLeft']()?_0x560350='l':_0x560350='r'),_0x32db4a['vf']=_0x560350;}return _0x29d0ae['index_']!==R&&(_0x32db4a['i']=_0x29d0ae['index_']['toString']()),_0x32db4a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0xb9a0c7){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4295fe,_0x41ee4b){return _0x41ee4b!==void 0x0?'tag$'+_0x41ee4b:(f(_0x4295fe['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4295fe['_path']['toString']());}constructor(_0x574185,_0x18e5dd,_0x1be9c6,_0x404d66){super(),this['repoInfo_']=_0x574185,this['onDataUpdate_']=_0x18e5dd,this['authTokenProvider_']=_0x1be9c6,this['appCheckTokenProvider_']=_0x404d66,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4e2b4f,_0x59af8f,_0x3008da,_0x45a45e){const _0xb3b270=_0x4e2b4f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xb3b270+'\x20'+_0x4e2b4f['_queryIdentifier']);const _0x4a03c0=fn['getListenId_'](_0x4e2b4f,_0x3008da),_0x2e209c={};this['listens_'][_0x4a03c0]=_0x2e209c;const _0x17a5f9=tr(_0x4e2b4f['_queryParams']);this['restRequest_'](_0xb3b270+'.json',_0x17a5f9,(_0x5b121b,_0x343fd5)=>{let _0x393171=_0x343fd5;if(_0x5b121b===0x194&&(_0x393171=null,_0x5b121b=null),_0x5b121b===null&&this['onDataUpdate_'](_0xb3b270,_0x393171,!0x1,_0x3008da),Oe(this['listens_'],_0x4a03c0)===_0x2e209c){let _0x499aac;_0x5b121b?_0x5b121b===0x191?_0x499aac='permission_denied':_0x499aac='rest_error:'+_0x5b121b:_0x499aac='ok',_0x45a45e(_0x499aac,null);}});}['unlisten'](_0x33ecfc,_0xbf6ea3){const _0x5247f4=fn['getListenId_'](_0x33ecfc,_0xbf6ea3);delete this['listens_'][_0x5247f4];}['get'](_0x42f2c2){const _0x3421bc=tr(_0x42f2c2['_queryParams']),_0x26939a=_0x42f2c2['_path']['toString'](),_0x4afa20=new Ve();return this['restRequest_'](_0x26939a+'.json',_0x3421bc,(_0x174752,_0x48ec0e)=>{let _0xbb9652=_0x48ec0e;_0x174752===0x194&&(_0xbb9652=null,_0x174752=null),_0x174752===null?(this['onDataUpdate_'](_0x26939a,_0xbb9652,!0x1,null),_0x4afa20['resolve'](_0xbb9652)):_0x4afa20['reject'](new Error(_0xbb9652));}),_0x4afa20['promise'];}['refreshAuthToken'](_0x5b842f){}['restRequest_'](_0x770b9a,_0x4963e2={},_0x57b3ea){return _0x4963e2['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5abdef,_0x629ddd])=>{_0x5abdef&&_0x5abdef['accessToken']&&(_0x4963e2['auth']=_0x5abdef['accessToken']),_0x629ddd&&_0x629ddd['token']&&(_0x4963e2['ac']=_0x629ddd['token']);const _0x126ff0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x770b9a+'?ns='+this['repoInfo_']['namespace']+at(_0x4963e2);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x126ff0);const _0x108ada=new XMLHttpRequest();_0x108ada['onreadystatechange']=()=>{if(_0x57b3ea&&_0x108ada['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x126ff0+'\x20received.\x20status:',_0x108ada['status'],'response:',_0x108ada['responseText']);let _0x3c2cf1=null;if(_0x108ada['status']>=0xc8&&_0x108ada['status']<0x12c){try{_0x3c2cf1=bt(_0x108ada['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x126ff0+':\x20'+_0x108ada['responseText']);}_0x57b3ea(null,_0x3c2cf1);}else _0x108ada['status']!==0x191&&_0x108ada['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x126ff0+'\x20Status:\x20'+_0x108ada['status']),_0x57b3ea(_0x108ada['status']);_0x57b3ea=null;}},_0x108ada['open']('GET',_0x126ff0,!0x0),_0x108ada['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5ee461){return this['rootNode_']['getChild'](_0x5ee461);}['updateSnapshot'](_0x2cf427,_0x3f5974){this['rootNode_']=this['rootNode_']['updateChild'](_0x2cf427,_0x3f5974);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x39592b,_0x1aaaf5,_0x4eb4fe){if(v(_0x1aaaf5))_0x39592b['value']=_0x4eb4fe,_0x39592b['children']['clear']();else{if(_0x39592b['value']!==null)_0x39592b['value']=_0x39592b['value']['updateChild'](_0x1aaaf5,_0x4eb4fe);else{const _0x5a185a=y(_0x1aaaf5);_0x39592b['children']['has'](_0x5a185a)||_0x39592b['children']['set'](_0x5a185a,pn());const _0x1193b1=_0x39592b['children']['get'](_0x5a185a);_0x1aaaf5=b(_0x1aaaf5),Mo(_0x1193b1,_0x1aaaf5,_0x4eb4fe);}}}function Ei(_0xa41d77,_0x101b94,_0x801d5){_0xa41d77['value']!==null?_0x801d5(_0x101b94,_0xa41d77['value']):Qh(_0xa41d77,(_0x4eb3ae,_0x297dea)=>{const _0x42b693=new C(_0x101b94['toString']()+'/'+_0x4eb3ae);Ei(_0x297dea,_0x42b693,_0x801d5);});}function Qh(_0x58256d,_0x2a5eb7){_0x58256d['children']['forEach']((_0x33b4c9,_0x44f491)=>{_0x2a5eb7(_0x44f491,_0x33b4c9);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0xd165e1){this['collection_']=_0xd165e1,this['last_']=null;}['get'](){const _0x6d3c84=this['collection_']['get'](),_0x33ca28={..._0x6d3c84};return this['last_']&&x(this['last_'],(_0x2d7c02,_0x4909cb)=>{_0x33ca28[_0x2d7c02]=_0x33ca28[_0x2d7c02]-_0x4909cb;}),this['last_']=_0x6d3c84,_0x33ca28;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x76708d,_0x49d8ab){this['server_']=_0x49d8ab,this['statsToReport_']={},this['statsListener_']=new Jh(_0x76708d);const _0x3ebe87=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x3ebe87));}['reportStats_'](){const _0x4b2b1e=this['statsListener_']['get'](),_0x2201b7={};let _0x11693b=!0x1;x(_0x4b2b1e,(_0x1d873f,_0x5d4943)=>{_0x5d4943>0x0&&Y(this['statsToReport_'],_0x1d873f)&&(_0x2201b7[_0x1d873f]=_0x5d4943,_0x11693b=!0x0);}),_0x11693b&&this['server_']['reportStats'](_0x2201b7),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x308835){_0x308835[_0x308835['OVERWRITE']=0x0]='OVERWRITE',_0x308835[_0x308835['MERGE']=0x1]='MERGE',_0x308835[_0x308835['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x308835[_0x308835['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x101a90){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x101a90,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x1b4b23,_0x1ef271,_0x559f3f){this['path']=_0x1b4b23,this['affectedTree']=_0x1ef271,this['revert']=_0x559f3f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x9cb3f3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5ecba1=this['affectedTree']['subtree'](new C(_0x9cb3f3));return new _n(w(),_0x5ecba1,this['revert']);}}else return f(y(this['path'])===_0x9cb3f3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x33ff56,_0x3ae4aa){this['source']=_0x33ff56,this['path']=_0x3ae4aa,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x5043b0){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x30cccd,_0x321187,_0x17f640){this['source']=_0x30cccd,this['path']=_0x321187,this['snap']=_0x17f640,this['type']=q['OVERWRITE'];}['operationForChild'](_0x4c8c7c){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x4c8c7c)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x57fa67,_0x1cdfc0,_0x544219){this['source']=_0x57fa67,this['path']=_0x1cdfc0,this['children']=_0x544219,this['type']=q['MERGE'];}['operationForChild'](_0x368bde){if(v(this['path'])){const _0x5798c1=this['children']['subtree'](new C(_0x368bde));return _0x5798c1['isEmpty']()?null:_0x5798c1['value']?new Fe(this['source'],w(),_0x5798c1['value']):new nt(this['source'],w(),_0x5798c1);}else return f(y(this['path'])===_0x368bde,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x26e25b,_0x2acdfd,_0x28db16){this['node_']=_0x26e25b,this['fullyInitialized_']=_0x2acdfd,this['filtered_']=_0x28db16;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2d20f5){if(v(_0x2d20f5))return this['isFullyInitialized']()&&!this['filtered_'];const _0xa3bf9f=y(_0x2d20f5);return this['isCompleteForChild'](_0xa3bf9f);}['isCompleteForChild'](_0x44042a){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x44042a);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x265181){this['query_']=_0x265181,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4de0b1,_0x2ff267,_0x4d720b,_0x223ff7){const _0x11c68a=[],_0x31be2c=[];return _0x2ff267['forEach'](_0x4d6ad8=>{_0x4d6ad8['type']==='child_changed'&&_0x4de0b1['index_']['indexedValueChanged'](_0x4d6ad8['oldSnap'],_0x4d6ad8['snapshotNode'])&&_0x31be2c['push']($h(_0x4d6ad8['childName'],_0x4d6ad8['snapshotNode']));}),mt(_0x4de0b1,_0x11c68a,'child_removed',_0x2ff267,_0x223ff7,_0x4d720b),mt(_0x4de0b1,_0x11c68a,'child_added',_0x2ff267,_0x223ff7,_0x4d720b),mt(_0x4de0b1,_0x11c68a,'child_moved',_0x31be2c,_0x223ff7,_0x4d720b),mt(_0x4de0b1,_0x11c68a,'child_changed',_0x2ff267,_0x223ff7,_0x4d720b),mt(_0x4de0b1,_0x11c68a,'value',_0x2ff267,_0x223ff7,_0x4d720b),_0x11c68a;}function mt(_0x4e0b2e,_0x4889ba,_0x3acb56,_0x30c0da,_0x1f8eca,_0x34beb5){const _0x4ae2ad=_0x30c0da['filter'](_0x946dc2=>_0x946dc2['type']===_0x3acb56);_0x4ae2ad['sort']((_0x549b48,_0xbbeaa5)=>su(_0x4e0b2e,_0x549b48,_0xbbeaa5)),_0x4ae2ad['forEach'](_0x35180d=>{const _0x56d096=iu(_0x4e0b2e,_0x35180d,_0x34beb5);_0x1f8eca['forEach'](_0x497a85=>{_0x497a85['respondsTo'](_0x35180d['type'])&&_0x4889ba['push'](_0x497a85['createEvent'](_0x56d096,_0x4e0b2e['query_']));});});}function iu(_0x2d726f,_0x56ae5f,_0x4960fc){return _0x56ae5f['type']==='value'||_0x56ae5f['type']==='child_removed'||(_0x56ae5f['prevName']=_0x4960fc['getPredecessorChildName'](_0x56ae5f['childName'],_0x56ae5f['snapshotNode'],_0x2d726f['index_'])),_0x56ae5f;}function su(_0x3d874f,_0x35e5b5,_0x5d2940){if(_0x35e5b5['childName']==null||_0x5d2940['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x4d415d=new E(_0x35e5b5['childName'],_0x35e5b5['snapshotNode']),_0x59df51=new E(_0x5d2940['childName'],_0x5d2940['snapshotNode']);return _0x3d874f['index_']['compare'](_0x4d415d,_0x59df51);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4c07f1,_0x2da3e1){return{'eventCache':_0x4c07f1,'serverCache':_0x2da3e1};}function wt(_0x212494,_0x4157ad,_0x563520,_0x40b766){return Dn(new Ce(_0x4157ad,_0x563520,_0x40b766),_0x212494['serverCache']);}function Lo(_0x33c28c,_0xeceef5,_0x38b419,_0xf9bd4b){return Dn(_0x33c28c['eventCache'],new Ce(_0xeceef5,_0x38b419,_0xf9bd4b));}function gn(_0x49056d){return _0x49056d['eventCache']['isFullyInitialized']()?_0x49056d['eventCache']['getNode']():null;}function Ue(_0x2fc34a){return _0x2fc34a['serverCache']['isFullyInitialized']()?_0x2fc34a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3512d0){let _0x6c0925=new S(null);return x(_0x3512d0,(_0x2452cd,_0x552e2e)=>{_0x6c0925=_0x6c0925['set'](new C(_0x2452cd),_0x552e2e);}),_0x6c0925;}constructor(_0x3a81d9,_0x443958=ru()){this['value']=_0x3a81d9,this['children']=_0x443958;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x47c70c,_0x4fc0b2){if(this['value']!=null&&_0x4fc0b2(this['value']))return{'path':w(),'value':this['value']};if(v(_0x47c70c))return null;{const _0x197881=y(_0x47c70c),_0xe5dd85=this['children']['get'](_0x197881);if(_0xe5dd85!==null){const _0x220d75=_0xe5dd85['findRootMostMatchingPathAndValue'](b(_0x47c70c),_0x4fc0b2);return _0x220d75!=null?{'path':A(new C(_0x197881),_0x220d75['path']),'value':_0x220d75['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xf7f821){return this['findRootMostMatchingPathAndValue'](_0xf7f821,()=>!0x0);}['subtree'](_0x3c251f){if(v(_0x3c251f))return this;{const _0x2cc183=y(_0x3c251f),_0x27fec6=this['children']['get'](_0x2cc183);return _0x27fec6!==null?_0x27fec6['subtree'](b(_0x3c251f)):new S(null);}}['set'](_0x34cee3,_0x5e60d4){if(v(_0x34cee3))return new S(_0x5e60d4,this['children']);{const _0x1f9f6e=y(_0x34cee3),_0x5e8231=(this['children']['get'](_0x1f9f6e)||new S(null))['set'](b(_0x34cee3),_0x5e60d4),_0x3d4beb=this['children']['insert'](_0x1f9f6e,_0x5e8231);return new S(this['value'],_0x3d4beb);}}['remove'](_0x272d0c){if(v(_0x272d0c))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x448690=y(_0x272d0c),_0x5980aa=this['children']['get'](_0x448690);if(_0x5980aa){const _0x5afeec=_0x5980aa['remove'](b(_0x272d0c));let _0x5dc20f;return _0x5afeec['isEmpty']()?_0x5dc20f=this['children']['remove'](_0x448690):_0x5dc20f=this['children']['insert'](_0x448690,_0x5afeec),this['value']===null&&_0x5dc20f['isEmpty']()?new S(null):new S(this['value'],_0x5dc20f);}else return this;}}['get'](_0x54fd99){if(v(_0x54fd99))return this['value'];{const _0x85bd66=y(_0x54fd99),_0x455e94=this['children']['get'](_0x85bd66);return _0x455e94?_0x455e94['get'](b(_0x54fd99)):null;}}['setTree'](_0x46608e,_0x26807f){if(v(_0x46608e))return _0x26807f;{const _0xad55f9=y(_0x46608e),_0x22935f=(this['children']['get'](_0xad55f9)||new S(null))['setTree'](b(_0x46608e),_0x26807f);let _0x35df7a;return _0x22935f['isEmpty']()?_0x35df7a=this['children']['remove'](_0xad55f9):_0x35df7a=this['children']['insert'](_0xad55f9,_0x22935f),new S(this['value'],_0x35df7a);}}['fold'](_0x3492eb){return this['fold_'](w(),_0x3492eb);}['fold_'](_0x43c87f,_0x1e993){const _0x5adea7={};return this['children']['inorderTraversal']((_0x3f6603,_0x1bc8e4)=>{_0x5adea7[_0x3f6603]=_0x1bc8e4['fold_'](A(_0x43c87f,_0x3f6603),_0x1e993);}),_0x1e993(_0x43c87f,this['value'],_0x5adea7);}['findOnPath'](_0x72a725,_0x2934d3){return this['findOnPath_'](_0x72a725,w(),_0x2934d3);}['findOnPath_'](_0x5cc13e,_0x4916dd,_0x4831d0){const _0x7452de=this['value']?_0x4831d0(_0x4916dd,this['value']):!0x1;if(_0x7452de)return _0x7452de;if(v(_0x5cc13e))return null;{const _0x1d2abe=y(_0x5cc13e),_0x2f3b14=this['children']['get'](_0x1d2abe);return _0x2f3b14?_0x2f3b14['findOnPath_'](b(_0x5cc13e),A(_0x4916dd,_0x1d2abe),_0x4831d0):null;}}['foreachOnPath'](_0x436bb4,_0x4d3f4d){return this['foreachOnPath_'](_0x436bb4,w(),_0x4d3f4d);}['foreachOnPath_'](_0x2b2ca2,_0x2427c2,_0x428caa){if(v(_0x2b2ca2))return this;{this['value']&&_0x428caa(_0x2427c2,this['value']);const _0x5ee03d=y(_0x2b2ca2),_0x3b4d73=this['children']['get'](_0x5ee03d);return _0x3b4d73?_0x3b4d73['foreachOnPath_'](b(_0x2b2ca2),A(_0x2427c2,_0x5ee03d),_0x428caa):new S(null);}}['foreach'](_0x265a32){this['foreach_'](w(),_0x265a32);}['foreach_'](_0x569d56,_0x4e3d2c){this['children']['inorderTraversal']((_0x1cde77,_0x52919b)=>{_0x52919b['foreach_'](A(_0x569d56,_0x1cde77),_0x4e3d2c);}),this['value']&&_0x4e3d2c(_0x569d56,this['value']);}['foreachChild'](_0x3e68a3){this['children']['inorderTraversal']((_0x282c3c,_0x2fc791)=>{_0x2fc791['value']&&_0x3e68a3(_0x282c3c,_0x2fc791['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x464dda){this['writeTree_']=_0x464dda;}static['empty'](){return new j(new S(null));}}function Ct(_0x224c7e,_0x5543e6,_0x333367){if(v(_0x5543e6))return new j(new S(_0x333367));{const _0x1adcd2=_0x224c7e['writeTree_']['findRootMostValueAndPath'](_0x5543e6);if(_0x1adcd2!=null){const _0x4d9339=_0x1adcd2['path'];let _0x50d59d=_0x1adcd2['value'];const _0xc6d97e=F(_0x4d9339,_0x5543e6);return _0x50d59d=_0x50d59d['updateChild'](_0xc6d97e,_0x333367),new j(_0x224c7e['writeTree_']['set'](_0x4d9339,_0x50d59d));}else{const _0x14b311=new S(_0x333367),_0xdc738=_0x224c7e['writeTree_']['setTree'](_0x5543e6,_0x14b311);return new j(_0xdc738);}}}function Ii(_0x499e58,_0x1b48ec,_0x29df0e){let _0x186863=_0x499e58;return x(_0x29df0e,(_0x90763d,_0x3108c8)=>{_0x186863=Ct(_0x186863,A(_0x1b48ec,_0x90763d),_0x3108c8);}),_0x186863;}function sr(_0x433721,_0x3d34a9){if(v(_0x3d34a9))return j['empty']();{const _0x55ff6c=_0x433721['writeTree_']['setTree'](_0x3d34a9,new S(null));return new j(_0x55ff6c);}}function wi(_0x217050,_0x50aa81){return $e(_0x217050,_0x50aa81)!=null;}function $e(_0x40a294,_0x30b0b0){const _0x569056=_0x40a294['writeTree_']['findRootMostValueAndPath'](_0x30b0b0);return _0x569056!=null?_0x40a294['writeTree_']['get'](_0x569056['path'])['getChild'](F(_0x569056['path'],_0x30b0b0)):null;}function rr(_0x564fba){const _0x2e0873=[],_0x4fa5c3=_0x564fba['writeTree_']['value'];return _0x4fa5c3!=null?_0x4fa5c3['isLeafNode']()||_0x4fa5c3['forEachChild'](R,(_0x114efc,_0x35cfcc)=>{_0x2e0873['push'](new E(_0x114efc,_0x35cfcc));}):_0x564fba['writeTree_']['children']['inorderTraversal']((_0x2130cc,_0x4bce8d)=>{_0x4bce8d['value']!=null&&_0x2e0873['push'](new E(_0x2130cc,_0x4bce8d['value']));}),_0x2e0873;}function ve(_0x477184,_0x449bba){if(v(_0x449bba))return _0x477184;{const _0x3a47a9=$e(_0x477184,_0x449bba);return _0x3a47a9!=null?new j(new S(_0x3a47a9)):new j(_0x477184['writeTree_']['subtree'](_0x449bba));}}function Ci(_0x52cd07){return _0x52cd07['writeTree_']['isEmpty']();}function it(_0x5f19ac,_0x40b0ae){return xo(w(),_0x5f19ac['writeTree_'],_0x40b0ae);}function xo(_0x433b9a,_0x51beb4,_0xb89792){if(_0x51beb4['value']!=null)return _0xb89792['updateChild'](_0x433b9a,_0x51beb4['value']);{let _0x166374=null;return _0x51beb4['children']['inorderTraversal']((_0x65b934,_0x5dff72)=>{_0x65b934==='.priority'?(f(_0x5dff72['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x166374=_0x5dff72['value']):_0xb89792=xo(A(_0x433b9a,_0x65b934),_0x5dff72,_0xb89792);}),!_0xb89792['getChild'](_0x433b9a)['isEmpty']()&&_0x166374!==null&&(_0xb89792=_0xb89792['updateChild'](A(_0x433b9a,'.priority'),_0x166374)),_0xb89792;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x146e2d,_0x97b58e){return Bo(_0x97b58e,_0x146e2d);}function ou(_0x410608,_0xc3f433,_0x388cff,_0x2c24a1,_0x43d351){f(_0x2c24a1>_0x410608['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x43d351===void 0x0&&(_0x43d351=!0x0),_0x410608['allWrites']['push']({'path':_0xc3f433,'snap':_0x388cff,'writeId':_0x2c24a1,'visible':_0x43d351}),_0x43d351&&(_0x410608['visibleWrites']=Ct(_0x410608['visibleWrites'],_0xc3f433,_0x388cff)),_0x410608['lastWriteId']=_0x2c24a1;}function au(_0x40084e,_0x827558,_0x221b73,_0x5a5f46){f(_0x5a5f46>_0x40084e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x40084e['allWrites']['push']({'path':_0x827558,'children':_0x221b73,'writeId':_0x5a5f46,'visible':!0x0}),_0x40084e['visibleWrites']=Ii(_0x40084e['visibleWrites'],_0x827558,_0x221b73),_0x40084e['lastWriteId']=_0x5a5f46;}function cu(_0x4010f4,_0x401f46){for(let _0x4f3c39=0x0;_0x4f3c39<_0x4010f4['allWrites']['length'];_0x4f3c39++){const _0x397aaf=_0x4010f4['allWrites'][_0x4f3c39];if(_0x397aaf['writeId']===_0x401f46)return _0x397aaf;}return null;}function lu(_0x5bb9f1,_0x329aa9){const _0x50d09a=_0x5bb9f1['allWrites']['findIndex'](_0x19d5dc=>_0x19d5dc['writeId']===_0x329aa9);f(_0x50d09a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5e83cf=_0x5bb9f1['allWrites'][_0x50d09a];_0x5bb9f1['allWrites']['splice'](_0x50d09a,0x1);let _0x5fd80f=_0x5e83cf['visible'],_0x554379=!0x1,_0x2ac0ce=_0x5bb9f1['allWrites']['length']-0x1;for(;_0x5fd80f&&_0x2ac0ce>=0x0;){const _0x2d7be8=_0x5bb9f1['allWrites'][_0x2ac0ce];_0x2d7be8['visible']&&(_0x2ac0ce>=_0x50d09a&&hu(_0x2d7be8,_0x5e83cf['path'])?_0x5fd80f=!0x1:$(_0x5e83cf['path'],_0x2d7be8['path'])&&(_0x554379=!0x0)),_0x2ac0ce--;}if(_0x5fd80f){if(_0x554379)return uu(_0x5bb9f1),!0x0;if(_0x5e83cf['snap'])_0x5bb9f1['visibleWrites']=sr(_0x5bb9f1['visibleWrites'],_0x5e83cf['path']);else{const _0x65faed=_0x5e83cf['children'];x(_0x65faed,_0x57c043=>{_0x5bb9f1['visibleWrites']=sr(_0x5bb9f1['visibleWrites'],A(_0x5e83cf['path'],_0x57c043));});}return!0x0;}else return!0x1;}function hu(_0x50036b,_0xfc91e0){if(_0x50036b['snap'])return $(_0x50036b['path'],_0xfc91e0);for(const _0x7f1339 in _0x50036b['children'])if(_0x50036b['children']['hasOwnProperty'](_0x7f1339)&&$(A(_0x50036b['path'],_0x7f1339),_0xfc91e0))return!0x0;return!0x1;}function uu(_0x52ffb7){_0x52ffb7['visibleWrites']=Fo(_0x52ffb7['allWrites'],du,w()),_0x52ffb7['allWrites']['length']>0x0?_0x52ffb7['lastWriteId']=_0x52ffb7['allWrites'][_0x52ffb7['allWrites']['length']-0x1]['writeId']:_0x52ffb7['lastWriteId']=-0x1;}function du(_0x318f27){return _0x318f27['visible'];}function Fo(_0x543564,_0x3b2d94,_0x4e5fda){let _0x2b7380=j['empty']();for(let _0x3444e1=0x0;_0x3444e1<_0x543564['length'];++_0x3444e1){const _0x138c82=_0x543564[_0x3444e1];if(_0x3b2d94(_0x138c82)){const _0x316b5a=_0x138c82['path'];let _0x6a25a8;if(_0x138c82['snap'])$(_0x4e5fda,_0x316b5a)?(_0x6a25a8=F(_0x4e5fda,_0x316b5a),_0x2b7380=Ct(_0x2b7380,_0x6a25a8,_0x138c82['snap'])):$(_0x316b5a,_0x4e5fda)&&(_0x6a25a8=F(_0x316b5a,_0x4e5fda),_0x2b7380=Ct(_0x2b7380,w(),_0x138c82['snap']['getChild'](_0x6a25a8)));else{if(_0x138c82['children']){if($(_0x4e5fda,_0x316b5a))_0x6a25a8=F(_0x4e5fda,_0x316b5a),_0x2b7380=Ii(_0x2b7380,_0x6a25a8,_0x138c82['children']);else{if($(_0x316b5a,_0x4e5fda)){if(_0x6a25a8=F(_0x316b5a,_0x4e5fda),v(_0x6a25a8))_0x2b7380=Ii(_0x2b7380,w(),_0x138c82['children']);else{const _0x47ec9c=Oe(_0x138c82['children'],y(_0x6a25a8));if(_0x47ec9c){const _0xa175e8=_0x47ec9c['getChild'](b(_0x6a25a8));_0x2b7380=Ct(_0x2b7380,w(),_0xa175e8);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2b7380;}function Uo(_0x16f109,_0x624a3,_0x2ebb55,_0x4aea5f,_0x431e47){if(!_0x4aea5f&&!_0x431e47){const _0x441b18=$e(_0x16f109['visibleWrites'],_0x624a3);if(_0x441b18!=null)return _0x441b18;{const _0x4fa3b9=ve(_0x16f109['visibleWrites'],_0x624a3);if(Ci(_0x4fa3b9))return _0x2ebb55;if(_0x2ebb55==null&&!wi(_0x4fa3b9,w()))return null;{const _0x5cca24=_0x2ebb55||g['EMPTY_NODE'];return it(_0x4fa3b9,_0x5cca24);}}}else{const _0x5ced45=ve(_0x16f109['visibleWrites'],_0x624a3);if(!_0x431e47&&Ci(_0x5ced45))return _0x2ebb55;if(!_0x431e47&&_0x2ebb55==null&&!wi(_0x5ced45,w()))return null;{const _0x7acd81=function(_0x96478b){return(_0x96478b['visible']||_0x431e47)&&(!_0x4aea5f||!~_0x4aea5f['indexOf'](_0x96478b['writeId']))&&($(_0x96478b['path'],_0x624a3)||$(_0x624a3,_0x96478b['path']));},_0xa6b143=Fo(_0x16f109['allWrites'],_0x7acd81,_0x624a3),_0x17feba=_0x2ebb55||g['EMPTY_NODE'];return it(_0xa6b143,_0x17feba);}}}function fu(_0x573fe7,_0x534ada,_0xc1bffc){let _0x2b089e=g['EMPTY_NODE'];const _0x591238=$e(_0x573fe7['visibleWrites'],_0x534ada);if(_0x591238)return _0x591238['isLeafNode']()||_0x591238['forEachChild'](R,(_0x3674f3,_0x483256)=>{_0x2b089e=_0x2b089e['updateImmediateChild'](_0x3674f3,_0x483256);}),_0x2b089e;if(_0xc1bffc){const _0x3be71b=ve(_0x573fe7['visibleWrites'],_0x534ada);return _0xc1bffc['forEachChild'](R,(_0x246a67,_0x579db3)=>{const _0x460e20=it(ve(_0x3be71b,new C(_0x246a67)),_0x579db3);_0x2b089e=_0x2b089e['updateImmediateChild'](_0x246a67,_0x460e20);}),rr(_0x3be71b)['forEach'](_0x55bd0e=>{_0x2b089e=_0x2b089e['updateImmediateChild'](_0x55bd0e['name'],_0x55bd0e['node']);}),_0x2b089e;}else{const _0x121bf0=ve(_0x573fe7['visibleWrites'],_0x534ada);return rr(_0x121bf0)['forEach'](_0x536559=>{_0x2b089e=_0x2b089e['updateImmediateChild'](_0x536559['name'],_0x536559['node']);}),_0x2b089e;}}function pu(_0x1f4e08,_0x5f2d3d,_0x20fab7,_0x26ba92,_0x29860e){f(_0x26ba92||_0x29860e,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4891eb=A(_0x5f2d3d,_0x20fab7);if(wi(_0x1f4e08['visibleWrites'],_0x4891eb))return null;{const _0x12b149=ve(_0x1f4e08['visibleWrites'],_0x4891eb);return Ci(_0x12b149)?_0x29860e['getChild'](_0x20fab7):it(_0x12b149,_0x29860e['getChild'](_0x20fab7));}}function _u(_0x212af1,_0x9c8b11,_0x475a71,_0xe78c6a){const _0x368b29=A(_0x9c8b11,_0x475a71),_0x5cdc77=$e(_0x212af1['visibleWrites'],_0x368b29);if(_0x5cdc77!=null)return _0x5cdc77;if(_0xe78c6a['isCompleteForChild'](_0x475a71)){const _0x29d2aa=ve(_0x212af1['visibleWrites'],_0x368b29);return it(_0x29d2aa,_0xe78c6a['getNode']()['getImmediateChild'](_0x475a71));}else return null;}function gu(_0x408f20,_0x4935d4){return $e(_0x408f20['visibleWrites'],_0x4935d4);}function mu(_0x304752,_0x58178e,_0x1b560e,_0x512ba9,_0x4369a5,_0x2d6be2,_0x5c3b8e){let _0x54fd62;const _0x391b7=ve(_0x304752['visibleWrites'],_0x58178e),_0x595549=$e(_0x391b7,w());if(_0x595549!=null)_0x54fd62=_0x595549;else{if(_0x1b560e!=null)_0x54fd62=it(_0x391b7,_0x1b560e);else return[];}if(_0x54fd62=_0x54fd62['withIndex'](_0x5c3b8e),!_0x54fd62['isEmpty']()&&!_0x54fd62['isLeafNode']()){const _0x239310=[],_0x417672=_0x5c3b8e['getCompare'](),_0x546d67=_0x2d6be2?_0x54fd62['getReverseIteratorFrom'](_0x512ba9,_0x5c3b8e):_0x54fd62['getIteratorFrom'](_0x512ba9,_0x5c3b8e);let _0x8139cb=_0x546d67['getNext']();for(;_0x8139cb&&_0x239310['length']<_0x4369a5;)_0x417672(_0x8139cb,_0x512ba9)!==0x0&&_0x239310['push'](_0x8139cb),_0x8139cb=_0x546d67['getNext']();return _0x239310;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x745af8,_0x3240a6,_0x3fb919,_0x144682){return Uo(_0x745af8['writeTree'],_0x745af8['treePath'],_0x3240a6,_0x3fb919,_0x144682);}function es(_0x422eb7,_0x46fd16){return fu(_0x422eb7['writeTree'],_0x422eb7['treePath'],_0x46fd16);}function or(_0x4394e1,_0x481bf3,_0x35dafc,_0x2cd736){return pu(_0x4394e1['writeTree'],_0x4394e1['treePath'],_0x481bf3,_0x35dafc,_0x2cd736);}function yn(_0x275166,_0x3a1378){return gu(_0x275166['writeTree'],A(_0x275166['treePath'],_0x3a1378));}function vu(_0x5b61ef,_0xbb80d9,_0x39ca3e,_0xa08744,_0x527b15,_0x32474f){return mu(_0x5b61ef['writeTree'],_0x5b61ef['treePath'],_0xbb80d9,_0x39ca3e,_0xa08744,_0x527b15,_0x32474f);}function ts(_0x4e5261,_0x4a67cb,_0x47f0ed){return _u(_0x4e5261['writeTree'],_0x4e5261['treePath'],_0x4a67cb,_0x47f0ed);}function Wo(_0x510795,_0xa11270){return Bo(A(_0x510795['treePath'],_0xa11270),_0x510795['writeTree']);}function Bo(_0x499f41,_0x16f494){return{'treePath':_0x499f41,'writeTree':_0x16f494};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1d0c43){const _0x27d2ce=_0x1d0c43['type'],_0x6d0992=_0x1d0c43['childName'];f(_0x27d2ce==='child_added'||_0x27d2ce==='child_changed'||_0x27d2ce==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x6d0992!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x27972f=this['changeMap']['get'](_0x6d0992);if(_0x27972f){const _0x3b3968=_0x27972f['type'];if(_0x27d2ce==='child_added'&&_0x3b3968==='child_removed')this['changeMap']['set'](_0x6d0992,Pt(_0x6d0992,_0x1d0c43['snapshotNode'],_0x27972f['snapshotNode']));else{if(_0x27d2ce==='child_removed'&&_0x3b3968==='child_added')this['changeMap']['delete'](_0x6d0992);else{if(_0x27d2ce==='child_removed'&&_0x3b3968==='child_changed')this['changeMap']['set'](_0x6d0992,Nt(_0x6d0992,_0x27972f['oldSnap']));else{if(_0x27d2ce==='child_changed'&&_0x3b3968==='child_added')this['changeMap']['set'](_0x6d0992,tt(_0x6d0992,_0x1d0c43['snapshotNode']));else{if(_0x27d2ce==='child_changed'&&_0x3b3968==='child_changed')this['changeMap']['set'](_0x6d0992,Pt(_0x6d0992,_0x1d0c43['snapshotNode'],_0x27972f['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x1d0c43+'\x20occurred\x20after\x20'+_0x27972f);}}}}}else this['changeMap']['set'](_0x6d0992,_0x1d0c43);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x5eaa3e){return null;}['getChildAfterChild'](_0x7b4dd,_0x421269,_0x3699d3){return null;}}const Vo=new Iu();class ns{constructor(_0x19b36d,_0x6120e2,_0x3198ca=null){this['writes_']=_0x19b36d,this['viewCache_']=_0x6120e2,this['optCompleteServerCache_']=_0x3198ca;}['getCompleteChild'](_0x293134){const _0x366da0=this['viewCache_']['eventCache'];if(_0x366da0['isCompleteForChild'](_0x293134))return _0x366da0['getNode']()['getImmediateChild'](_0x293134);{const _0x24c05b=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x293134,_0x24c05b);}}['getChildAfterChild'](_0x2f4bff,_0x3f71dc,_0x54b988){const _0x37ec95=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x15bf7b=vu(this['writes_'],_0x37ec95,_0x3f71dc,0x1,_0x54b988,_0x2f4bff);return _0x15bf7b['length']===0x0?null:_0x15bf7b[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x4c82d7){return{'filter':_0x4c82d7};}function Cu(_0x3700c1,_0x240b2a){f(_0x240b2a['eventCache']['getNode']()['isIndexed'](_0x3700c1['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x240b2a['serverCache']['getNode']()['isIndexed'](_0x3700c1['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x9192e7,_0x2e520a,_0x5d9fb7,_0x2c32ef,_0x3d5c1c){const _0x47ac2d=new Eu();let _0x5cbfa7,_0x279bc5;if(_0x5d9fb7['type']===q['OVERWRITE']){const _0x2c2277=_0x5d9fb7;_0x2c2277['source']['fromUser']?_0x5cbfa7=Ti(_0x9192e7,_0x2e520a,_0x2c2277['path'],_0x2c2277['snap'],_0x2c32ef,_0x3d5c1c,_0x47ac2d):(f(_0x2c2277['source']['fromServer'],'Unknown\x20source.'),_0x279bc5=_0x2c2277['source']['tagged']||_0x2e520a['serverCache']['isFiltered']()&&!v(_0x2c2277['path']),_0x5cbfa7=vn(_0x9192e7,_0x2e520a,_0x2c2277['path'],_0x2c2277['snap'],_0x2c32ef,_0x3d5c1c,_0x279bc5,_0x47ac2d));}else{if(_0x5d9fb7['type']===q['MERGE']){const _0x3f523f=_0x5d9fb7;_0x3f523f['source']['fromUser']?_0x5cbfa7=bu(_0x9192e7,_0x2e520a,_0x3f523f['path'],_0x3f523f['children'],_0x2c32ef,_0x3d5c1c,_0x47ac2d):(f(_0x3f523f['source']['fromServer'],'Unknown\x20source.'),_0x279bc5=_0x3f523f['source']['tagged']||_0x2e520a['serverCache']['isFiltered'](),_0x5cbfa7=Si(_0x9192e7,_0x2e520a,_0x3f523f['path'],_0x3f523f['children'],_0x2c32ef,_0x3d5c1c,_0x279bc5,_0x47ac2d));}else{if(_0x5d9fb7['type']===q['ACK_USER_WRITE']){const _0x2fe5cf=_0x5d9fb7;_0x2fe5cf['revert']?_0x5cbfa7=ku(_0x9192e7,_0x2e520a,_0x2fe5cf['path'],_0x2c32ef,_0x3d5c1c,_0x47ac2d):_0x5cbfa7=Ru(_0x9192e7,_0x2e520a,_0x2fe5cf['path'],_0x2fe5cf['affectedTree'],_0x2c32ef,_0x3d5c1c,_0x47ac2d);}else{if(_0x5d9fb7['type']===q['LISTEN_COMPLETE'])_0x5cbfa7=Au(_0x9192e7,_0x2e520a,_0x5d9fb7['path'],_0x2c32ef,_0x47ac2d);else throw ot('Unknown\x20operation\x20type:\x20'+_0x5d9fb7['type']);}}}const _0x4454bc=_0x47ac2d['getChanges']();return Su(_0x2e520a,_0x5cbfa7,_0x4454bc),{'viewCache':_0x5cbfa7,'changes':_0x4454bc};}function Su(_0x39b790,_0x436f95,_0x59c505){const _0x53f132=_0x436f95['eventCache'];if(_0x53f132['isFullyInitialized']()){const _0x8f38ac=_0x53f132['getNode']()['isLeafNode']()||_0x53f132['getNode']()['isEmpty'](),_0x1ae23f=gn(_0x39b790);(_0x59c505['length']>0x0||!_0x39b790['eventCache']['isFullyInitialized']()||_0x8f38ac&&!_0x53f132['getNode']()['equals'](_0x1ae23f)||!_0x53f132['getNode']()['getPriority']()['equals'](_0x1ae23f['getPriority']()))&&_0x59c505['push'](Oo(gn(_0x436f95)));}}function Ho(_0x1b41fe,_0x171ac8,_0x2375e6,_0x5d4c74,_0x3a9489,_0x8da8cc){const _0x247d0a=_0x171ac8['eventCache'];if(yn(_0x5d4c74,_0x2375e6)!=null)return _0x171ac8;{let _0x426edd,_0x17f443;if(v(_0x2375e6)){if(f(_0x171ac8['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x171ac8['serverCache']['isFiltered']()){const _0x3d55a3=Ue(_0x171ac8),_0xfabe49=_0x3d55a3 instanceof g?_0x3d55a3:g['EMPTY_NODE'],_0x11f3a2=es(_0x5d4c74,_0xfabe49);_0x426edd=_0x1b41fe['filter']['updateFullNode'](_0x171ac8['eventCache']['getNode'](),_0x11f3a2,_0x8da8cc);}else{const _0x5180b1=mn(_0x5d4c74,Ue(_0x171ac8));_0x426edd=_0x1b41fe['filter']['updateFullNode'](_0x171ac8['eventCache']['getNode'](),_0x5180b1,_0x8da8cc);}}else{const _0x406eac=y(_0x2375e6);if(_0x406eac==='.priority'){f(we(_0x2375e6)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x27804b=_0x247d0a['getNode']();_0x17f443=_0x171ac8['serverCache']['getNode']();const _0xcc09b6=or(_0x5d4c74,_0x2375e6,_0x27804b,_0x17f443);_0xcc09b6!=null?_0x426edd=_0x1b41fe['filter']['updatePriority'](_0x27804b,_0xcc09b6):_0x426edd=_0x247d0a['getNode']();}else{const _0x29e788=b(_0x2375e6);let _0x2081fd;if(_0x247d0a['isCompleteForChild'](_0x406eac)){_0x17f443=_0x171ac8['serverCache']['getNode']();const _0x42847a=or(_0x5d4c74,_0x2375e6,_0x247d0a['getNode'](),_0x17f443);_0x42847a!=null?_0x2081fd=_0x247d0a['getNode']()['getImmediateChild'](_0x406eac)['updateChild'](_0x29e788,_0x42847a):_0x2081fd=_0x247d0a['getNode']()['getImmediateChild'](_0x406eac);}else _0x2081fd=ts(_0x5d4c74,_0x406eac,_0x171ac8['serverCache']);_0x2081fd!=null?_0x426edd=_0x1b41fe['filter']['updateChild'](_0x247d0a['getNode'](),_0x406eac,_0x2081fd,_0x29e788,_0x3a9489,_0x8da8cc):_0x426edd=_0x247d0a['getNode']();}}return wt(_0x171ac8,_0x426edd,_0x247d0a['isFullyInitialized']()||v(_0x2375e6),_0x1b41fe['filter']['filtersNodes']());}}function vn(_0x2dd218,_0x208ab3,_0x2e50d0,_0x3723e9,_0x7e828a,_0x5df48d,_0x5e58f3,_0x5a8222){const _0x3c6421=_0x208ab3['serverCache'];let _0x145916;const _0x3844d8=_0x5e58f3?_0x2dd218['filter']:_0x2dd218['filter']['getIndexedFilter']();if(v(_0x2e50d0))_0x145916=_0x3844d8['updateFullNode'](_0x3c6421['getNode'](),_0x3723e9,null);else{if(_0x3844d8['filtersNodes']()&&!_0x3c6421['isFiltered']()){const _0xa4701e=_0x3c6421['getNode']()['updateChild'](_0x2e50d0,_0x3723e9);_0x145916=_0x3844d8['updateFullNode'](_0x3c6421['getNode'](),_0xa4701e,null);}else{const _0xb44322=y(_0x2e50d0);if(!_0x3c6421['isCompleteForPath'](_0x2e50d0)&&we(_0x2e50d0)>0x1)return _0x208ab3;const _0x4cac72=b(_0x2e50d0),_0x4ba0d3=_0x3c6421['getNode']()['getImmediateChild'](_0xb44322)['updateChild'](_0x4cac72,_0x3723e9);_0xb44322==='.priority'?_0x145916=_0x3844d8['updatePriority'](_0x3c6421['getNode'](),_0x4ba0d3):_0x145916=_0x3844d8['updateChild'](_0x3c6421['getNode'](),_0xb44322,_0x4ba0d3,_0x4cac72,Vo,null);}}const _0x27a565=Lo(_0x208ab3,_0x145916,_0x3c6421['isFullyInitialized']()||v(_0x2e50d0),_0x3844d8['filtersNodes']()),_0x570956=new ns(_0x7e828a,_0x27a565,_0x5df48d);return Ho(_0x2dd218,_0x27a565,_0x2e50d0,_0x7e828a,_0x570956,_0x5a8222);}function Ti(_0x5d7f2f,_0x2ced78,_0x4462f4,_0x1b7e83,_0xc3d792,_0x5e5e11,_0x5c1c3b){const _0x287765=_0x2ced78['eventCache'];let _0x5dff98,_0x1591c4;const _0x5cca40=new ns(_0xc3d792,_0x2ced78,_0x5e5e11);if(v(_0x4462f4))_0x1591c4=_0x5d7f2f['filter']['updateFullNode'](_0x2ced78['eventCache']['getNode'](),_0x1b7e83,_0x5c1c3b),_0x5dff98=wt(_0x2ced78,_0x1591c4,!0x0,_0x5d7f2f['filter']['filtersNodes']());else{const _0x41f202=y(_0x4462f4);if(_0x41f202==='.priority')_0x1591c4=_0x5d7f2f['filter']['updatePriority'](_0x2ced78['eventCache']['getNode'](),_0x1b7e83),_0x5dff98=wt(_0x2ced78,_0x1591c4,_0x287765['isFullyInitialized'](),_0x287765['isFiltered']());else{const _0x58fdac=b(_0x4462f4),_0x1211d1=_0x287765['getNode']()['getImmediateChild'](_0x41f202);let _0x3b4303;if(v(_0x58fdac))_0x3b4303=_0x1b7e83;else{const _0x37d29c=_0x5cca40['getCompleteChild'](_0x41f202);_0x37d29c!=null?Gi(_0x58fdac)==='.priority'&&_0x37d29c['getChild'](To(_0x58fdac))['isEmpty']()?_0x3b4303=_0x37d29c:_0x3b4303=_0x37d29c['updateChild'](_0x58fdac,_0x1b7e83):_0x3b4303=g['EMPTY_NODE'];}if(_0x1211d1['equals'](_0x3b4303))_0x5dff98=_0x2ced78;else{const _0x30b0b3=_0x5d7f2f['filter']['updateChild'](_0x287765['getNode'](),_0x41f202,_0x3b4303,_0x58fdac,_0x5cca40,_0x5c1c3b);_0x5dff98=wt(_0x2ced78,_0x30b0b3,_0x287765['isFullyInitialized'](),_0x5d7f2f['filter']['filtersNodes']());}}}return _0x5dff98;}function ar(_0x10f641,_0x1fedb7){return _0x10f641['eventCache']['isCompleteForChild'](_0x1fedb7);}function bu(_0x10aab7,_0x39daf8,_0x28899a,_0x19bc40,_0x50ba12,_0x283995,_0x368365){let _0x2e0fdc=_0x39daf8;return _0x19bc40['foreach']((_0x58a5e9,_0x46b945)=>{const _0x3e1b1b=A(_0x28899a,_0x58a5e9);ar(_0x39daf8,y(_0x3e1b1b))&&(_0x2e0fdc=Ti(_0x10aab7,_0x2e0fdc,_0x3e1b1b,_0x46b945,_0x50ba12,_0x283995,_0x368365));}),_0x19bc40['foreach']((_0x4b6a17,_0x16de57)=>{const _0x37cca2=A(_0x28899a,_0x4b6a17);ar(_0x39daf8,y(_0x37cca2))||(_0x2e0fdc=Ti(_0x10aab7,_0x2e0fdc,_0x37cca2,_0x16de57,_0x50ba12,_0x283995,_0x368365));}),_0x2e0fdc;}function cr(_0x3696ae,_0x363ca8,_0xcd4f3){return _0xcd4f3['foreach']((_0x348aa5,_0x48f036)=>{_0x363ca8=_0x363ca8['updateChild'](_0x348aa5,_0x48f036);}),_0x363ca8;}function Si(_0x573525,_0x274ccd,_0x3c05ae,_0x117b2d,_0x2d050a,_0x403496,_0x19e8e4,_0x58004c){if(_0x274ccd['serverCache']['getNode']()['isEmpty']()&&!_0x274ccd['serverCache']['isFullyInitialized']())return _0x274ccd;let _0x13f962=_0x274ccd,_0xd3a41;v(_0x3c05ae)?_0xd3a41=_0x117b2d:_0xd3a41=new S(null)['setTree'](_0x3c05ae,_0x117b2d);const _0x2e2752=_0x274ccd['serverCache']['getNode']();return _0xd3a41['children']['inorderTraversal']((_0x373afb,_0x154d45)=>{if(_0x2e2752['hasChild'](_0x373afb)){const _0x273a7c=_0x274ccd['serverCache']['getNode']()['getImmediateChild'](_0x373afb),_0x25c0f4=cr(_0x573525,_0x273a7c,_0x154d45);_0x13f962=vn(_0x573525,_0x13f962,new C(_0x373afb),_0x25c0f4,_0x2d050a,_0x403496,_0x19e8e4,_0x58004c);}}),_0xd3a41['children']['inorderTraversal']((_0x36e789,_0x3dc331)=>{const _0x739420=!_0x274ccd['serverCache']['isCompleteForChild'](_0x36e789)&&_0x3dc331['value']===null;if(!_0x2e2752['hasChild'](_0x36e789)&&!_0x739420){const _0x4962fc=_0x274ccd['serverCache']['getNode']()['getImmediateChild'](_0x36e789),_0x15bd49=cr(_0x573525,_0x4962fc,_0x3dc331);_0x13f962=vn(_0x573525,_0x13f962,new C(_0x36e789),_0x15bd49,_0x2d050a,_0x403496,_0x19e8e4,_0x58004c);}}),_0x13f962;}function Ru(_0x12f424,_0xb8b007,_0x4243a0,_0x1ad507,_0x190099,_0x1d1b18,_0x4d623e){if(yn(_0x190099,_0x4243a0)!=null)return _0xb8b007;const _0x1c93d5=_0xb8b007['serverCache']['isFiltered'](),_0x33599f=_0xb8b007['serverCache'];if(_0x1ad507['value']!=null){if(v(_0x4243a0)&&_0x33599f['isFullyInitialized']()||_0x33599f['isCompleteForPath'](_0x4243a0))return vn(_0x12f424,_0xb8b007,_0x4243a0,_0x33599f['getNode']()['getChild'](_0x4243a0),_0x190099,_0x1d1b18,_0x1c93d5,_0x4d623e);if(v(_0x4243a0)){let _0x43842c=new S(null);return _0x33599f['getNode']()['forEachChild'](ye,(_0x27bdc0,_0x216c92)=>{_0x43842c=_0x43842c['set'](new C(_0x27bdc0),_0x216c92);}),Si(_0x12f424,_0xb8b007,_0x4243a0,_0x43842c,_0x190099,_0x1d1b18,_0x1c93d5,_0x4d623e);}else return _0xb8b007;}else{let _0x384577=new S(null);return _0x1ad507['foreach']((_0x308fff,_0x4c7298)=>{const _0x14f0d5=A(_0x4243a0,_0x308fff);_0x33599f['isCompleteForPath'](_0x14f0d5)&&(_0x384577=_0x384577['set'](_0x308fff,_0x33599f['getNode']()['getChild'](_0x14f0d5)));}),Si(_0x12f424,_0xb8b007,_0x4243a0,_0x384577,_0x190099,_0x1d1b18,_0x1c93d5,_0x4d623e);}}function Au(_0x4d3dd7,_0x31c04e,_0x3f607f,_0x29785e,_0x564f05){const _0x132054=_0x31c04e['serverCache'],_0x23e870=Lo(_0x31c04e,_0x132054['getNode'](),_0x132054['isFullyInitialized']()||v(_0x3f607f),_0x132054['isFiltered']());return Ho(_0x4d3dd7,_0x23e870,_0x3f607f,_0x29785e,Vo,_0x564f05);}function ku(_0x2280b3,_0x3cffb8,_0x5510e4,_0x582413,_0x141f2a,_0xd83f00){let _0x4b86ff;if(yn(_0x582413,_0x5510e4)!=null)return _0x3cffb8;{const _0x5432bc=new ns(_0x582413,_0x3cffb8,_0x141f2a),_0x330be6=_0x3cffb8['eventCache']['getNode']();let _0x26aa5b;if(v(_0x5510e4)||y(_0x5510e4)==='.priority'){let _0x129fad;if(_0x3cffb8['serverCache']['isFullyInitialized']())_0x129fad=mn(_0x582413,Ue(_0x3cffb8));else{const _0x32587f=_0x3cffb8['serverCache']['getNode']();f(_0x32587f instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x129fad=es(_0x582413,_0x32587f);}_0x129fad=_0x129fad,_0x26aa5b=_0x2280b3['filter']['updateFullNode'](_0x330be6,_0x129fad,_0xd83f00);}else{const _0x1465f7=y(_0x5510e4);let _0x433895=ts(_0x582413,_0x1465f7,_0x3cffb8['serverCache']);_0x433895==null&&_0x3cffb8['serverCache']['isCompleteForChild'](_0x1465f7)&&(_0x433895=_0x330be6['getImmediateChild'](_0x1465f7)),_0x433895!=null?_0x26aa5b=_0x2280b3['filter']['updateChild'](_0x330be6,_0x1465f7,_0x433895,b(_0x5510e4),_0x5432bc,_0xd83f00):_0x3cffb8['eventCache']['getNode']()['hasChild'](_0x1465f7)?_0x26aa5b=_0x2280b3['filter']['updateChild'](_0x330be6,_0x1465f7,g['EMPTY_NODE'],b(_0x5510e4),_0x5432bc,_0xd83f00):_0x26aa5b=_0x330be6,_0x26aa5b['isEmpty']()&&_0x3cffb8['serverCache']['isFullyInitialized']()&&(_0x4b86ff=mn(_0x582413,Ue(_0x3cffb8)),_0x4b86ff['isLeafNode']()&&(_0x26aa5b=_0x2280b3['filter']['updateFullNode'](_0x26aa5b,_0x4b86ff,_0xd83f00)));}return _0x4b86ff=_0x3cffb8['serverCache']['isFullyInitialized']()||yn(_0x582413,w())!=null,wt(_0x3cffb8,_0x26aa5b,_0x4b86ff,_0x2280b3['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x53dfab,_0x1a23d1){this['query_']=_0x53dfab,this['eventRegistrations_']=[];const _0x427255=this['query_']['_queryParams'],_0x204c7a=new Yi(_0x427255['getIndex']()),_0x11662e=qh(_0x427255);this['processor_']=wu(_0x11662e);const _0x3635cc=_0x1a23d1['serverCache'],_0x141816=_0x1a23d1['eventCache'],_0x1bb41f=_0x204c7a['updateFullNode'](g['EMPTY_NODE'],_0x3635cc['getNode'](),null),_0x3870f7=_0x11662e['updateFullNode'](g['EMPTY_NODE'],_0x141816['getNode'](),null),_0x44e7bb=new Ce(_0x1bb41f,_0x3635cc['isFullyInitialized'](),_0x204c7a['filtersNodes']()),_0x1d2ef6=new Ce(_0x3870f7,_0x141816['isFullyInitialized'](),_0x11662e['filtersNodes']());this['viewCache_']=Dn(_0x1d2ef6,_0x44e7bb),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3ae99b){return _0x3ae99b['viewCache_']['serverCache']['getNode']();}function Ou(_0x2a63c6){return gn(_0x2a63c6['viewCache_']);}function Du(_0x10d6b1,_0x368262){const _0x17570b=Ue(_0x10d6b1['viewCache_']);return _0x17570b&&(_0x10d6b1['query']['_queryParams']['loadsAllData']()||!v(_0x368262)&&!_0x17570b['getImmediateChild'](y(_0x368262))['isEmpty']())?_0x17570b['getChild'](_0x368262):null;}function lr(_0x31b5d9){return _0x31b5d9['eventRegistrations_']['length']===0x0;}function Mu(_0x172a6c,_0x5a6563){_0x172a6c['eventRegistrations_']['push'](_0x5a6563);}function hr(_0x25e4fb,_0x466211,_0x3f79d3){const _0x24e9f9=[];if(_0x3f79d3){f(_0x466211==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x531312=_0x25e4fb['query']['_path'];_0x25e4fb['eventRegistrations_']['forEach'](_0x1d7e8c=>{const _0x154ba7=_0x1d7e8c['createCancelEvent'](_0x3f79d3,_0x531312);_0x154ba7&&_0x24e9f9['push'](_0x154ba7);});}if(_0x466211){let _0x44f8d7=[];for(let _0x106acc=0x0;_0x106acc<_0x25e4fb['eventRegistrations_']['length'];++_0x106acc){const _0x531486=_0x25e4fb['eventRegistrations_'][_0x106acc];if(!_0x531486['matches'](_0x466211))_0x44f8d7['push'](_0x531486);else{if(_0x466211['hasAnyCallback']()){_0x44f8d7=_0x44f8d7['concat'](_0x25e4fb['eventRegistrations_']['slice'](_0x106acc+0x1));break;}}}_0x25e4fb['eventRegistrations_']=_0x44f8d7;}else _0x25e4fb['eventRegistrations_']=[];return _0x24e9f9;}function ur(_0x4c3434,_0x3721a2,_0x3c8ba4,_0x4aa4f3){_0x3721a2['type']===q['MERGE']&&_0x3721a2['source']['queryId']!==null&&(f(Ue(_0x4c3434['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x4c3434['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x59d7fe=_0x4c3434['viewCache_'],_0x56a5af=Tu(_0x4c3434['processor_'],_0x59d7fe,_0x3721a2,_0x3c8ba4,_0x4aa4f3);return Cu(_0x4c3434['processor_'],_0x56a5af['viewCache']),f(_0x56a5af['viewCache']['serverCache']['isFullyInitialized']()||!_0x59d7fe['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4c3434['viewCache_']=_0x56a5af['viewCache'],$o(_0x4c3434,_0x56a5af['changes'],_0x56a5af['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x5724f1,_0x10f40c){const _0x5707bc=_0x5724f1['viewCache_']['eventCache'],_0x2d0548=[];return _0x5707bc['getNode']()['isLeafNode']()||_0x5707bc['getNode']()['forEachChild'](R,(_0x37f6c5,_0x5d75cd)=>{_0x2d0548['push'](tt(_0x37f6c5,_0x5d75cd));}),_0x5707bc['isFullyInitialized']()&&_0x2d0548['push'](Oo(_0x5707bc['getNode']())),$o(_0x5724f1,_0x2d0548,_0x5707bc['getNode'](),_0x10f40c);}function $o(_0x4ba868,_0x2a17bd,_0x2dbbb9,_0x47bab4){const _0x59c7a8=_0x47bab4?[_0x47bab4]:_0x4ba868['eventRegistrations_'];return nu(_0x4ba868['eventGenerator_'],_0x2a17bd,_0x2dbbb9,_0x59c7a8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x3b7f96){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x3b7f96;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x304f5d){return _0x304f5d['views']['size']===0x0;}function is(_0x3869cf,_0x177c85,_0x268934,_0x3e111d){const _0x4552a2=_0x177c85['source']['queryId'];if(_0x4552a2!==null){const _0x9827bd=_0x3869cf['views']['get'](_0x4552a2);return f(_0x9827bd!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x9827bd,_0x177c85,_0x268934,_0x3e111d);}else{let _0x49b615=[];for(const _0x366d18 of _0x3869cf['views']['values']())_0x49b615=_0x49b615['concat'](ur(_0x366d18,_0x177c85,_0x268934,_0x3e111d));return _0x49b615;}}function qo(_0xc9408e,_0x11641e,_0x227a87,_0x29c485,_0x38fefd){const _0x4ed911=_0x11641e['_queryIdentifier'],_0x56b248=_0xc9408e['views']['get'](_0x4ed911);if(!_0x56b248){let _0x3b4224=mn(_0x227a87,_0x38fefd?_0x29c485:null),_0x551853=!0x1;_0x3b4224?_0x551853=!0x0:_0x29c485 instanceof g?(_0x3b4224=es(_0x227a87,_0x29c485),_0x551853=!0x1):(_0x3b4224=g['EMPTY_NODE'],_0x551853=!0x1);const _0x364dee=Dn(new Ce(_0x3b4224,_0x551853,!0x1),new Ce(_0x29c485,_0x38fefd,!0x1));return new Nu(_0x11641e,_0x364dee);}return _0x56b248;}function Wu(_0x342ace,_0x48f94a,_0x49d8c3,_0x5830bd,_0x51bade,_0x576ba2){const _0x30321c=qo(_0x342ace,_0x48f94a,_0x5830bd,_0x51bade,_0x576ba2);return _0x342ace['views']['has'](_0x48f94a['_queryIdentifier'])||_0x342ace['views']['set'](_0x48f94a['_queryIdentifier'],_0x30321c),Mu(_0x30321c,_0x49d8c3),Lu(_0x30321c,_0x49d8c3);}function Bu(_0x298351,_0x58ebd2,_0x6a8594,_0x348873){const _0x5e4ab6=_0x58ebd2['_queryIdentifier'],_0x12fd71=[];let _0x173037=[];const _0x245602=Te(_0x298351);if(_0x5e4ab6==='default'){for(const [_0x3700f5,_0x19f6bb]of _0x298351['views']['entries']())_0x173037=_0x173037['concat'](hr(_0x19f6bb,_0x6a8594,_0x348873)),lr(_0x19f6bb)&&(_0x298351['views']['delete'](_0x3700f5),_0x19f6bb['query']['_queryParams']['loadsAllData']()||_0x12fd71['push'](_0x19f6bb['query']));}else{const _0x333768=_0x298351['views']['get'](_0x5e4ab6);_0x333768&&(_0x173037=_0x173037['concat'](hr(_0x333768,_0x6a8594,_0x348873)),lr(_0x333768)&&(_0x298351['views']['delete'](_0x5e4ab6),_0x333768['query']['_queryParams']['loadsAllData']()||_0x12fd71['push'](_0x333768['query'])));}return _0x245602&&!Te(_0x298351)&&_0x12fd71['push'](new(Fu())(_0x58ebd2['_repo'],_0x58ebd2['_path'])),{'removed':_0x12fd71,'events':_0x173037};}function zo(_0x271c80){const _0x33fe9a=[];for(const _0x184fcd of _0x271c80['views']['values']())_0x184fcd['query']['_queryParams']['loadsAllData']()||_0x33fe9a['push'](_0x184fcd);return _0x33fe9a;}function Ee(_0x605d4a,_0x32a812){let _0x189b6e=null;for(const _0x39c8c8 of _0x605d4a['views']['values']())_0x189b6e=_0x189b6e||Du(_0x39c8c8,_0x32a812);return _0x189b6e;}function jo(_0x52773e,_0x4fd3e0){if(_0x4fd3e0['_queryParams']['loadsAllData']())return Ln(_0x52773e);{const _0x356014=_0x4fd3e0['_queryIdentifier'];return _0x52773e['views']['get'](_0x356014);}}function Ko(_0x206223,_0x3b3f7d){return jo(_0x206223,_0x3b3f7d)!=null;}function Te(_0x3b3ce9){return Ln(_0x3b3ce9)!=null;}function Ln(_0x4d0989){for(const _0x431d0f of _0x4d0989['views']['values']())if(_0x431d0f['query']['_queryParams']['loadsAllData']())return _0x431d0f;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x25a3de){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x25a3de;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2b6b7c){this['listenProvider_']=_0x2b6b7c,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x6ff0da,_0x1be350,_0x1b2384,_0x2f3ea3,_0x20ac00){return ou(_0x6ff0da['pendingWriteTree_'],_0x1be350,_0x1b2384,_0x2f3ea3,_0x20ac00),_0x20ac00?ht(_0x6ff0da,new Fe(Ji(),_0x1be350,_0x1b2384)):[];}function Gu(_0x99f941,_0xb75d28,_0x141a32,_0x111823){au(_0x99f941['pendingWriteTree_'],_0xb75d28,_0x141a32,_0x111823);const _0x4552e7=S['fromObject'](_0x141a32);return ht(_0x99f941,new nt(Ji(),_0xb75d28,_0x4552e7));}function pe(_0x579db7,_0x5b2bf7,_0x55dcf0=!0x1){const _0x498455=cu(_0x579db7['pendingWriteTree_'],_0x5b2bf7);if(lu(_0x579db7['pendingWriteTree_'],_0x5b2bf7)){let _0x3c44e8=new S(null);return _0x498455['snap']!=null?_0x3c44e8=_0x3c44e8['set'](w(),!0x0):x(_0x498455['children'],_0x526e17=>{_0x3c44e8=_0x3c44e8['set'](new C(_0x526e17),!0x0);}),ht(_0x579db7,new _n(_0x498455['path'],_0x3c44e8,_0x55dcf0));}else return[];}function $t(_0x940ee2,_0x4bb1aa,_0x4507e7){return ht(_0x940ee2,new Fe(Xi(),_0x4bb1aa,_0x4507e7));}function qu(_0x4b0db1,_0x1ca48d,_0x219d6e){const _0x4caad1=S['fromObject'](_0x219d6e);return ht(_0x4b0db1,new nt(Xi(),_0x1ca48d,_0x4caad1));}function zu(_0xa51f6c,_0x1da7e3){return ht(_0xa51f6c,new Dt(Xi(),_0x1da7e3));}function ju(_0x30bcc0,_0x9d6784,_0x59fc40){const _0xafcec9=rs(_0x30bcc0,_0x59fc40);if(_0xafcec9){const _0x1eeee7=os(_0xafcec9),_0x3c47db=_0x1eeee7['path'],_0x3d7e33=_0x1eeee7['queryId'],_0x3fb59a=F(_0x3c47db,_0x9d6784),_0x23df93=new Dt(Zi(_0x3d7e33),_0x3fb59a);return as(_0x30bcc0,_0x3c47db,_0x23df93);}else return[];}function wn(_0x29d802,_0x59e704,_0xaa6aff,_0x201aab,_0x39e676=!0x1){const _0x1d8f92=_0x59e704['_path'],_0x1ff0cb=_0x29d802['syncPointTree_']['get'](_0x1d8f92);let _0x2711d9=[];if(_0x1ff0cb&&(_0x59e704['_queryIdentifier']==='default'||Ko(_0x1ff0cb,_0x59e704))){const _0xe8c435=Bu(_0x1ff0cb,_0x59e704,_0xaa6aff,_0x201aab);Uu(_0x1ff0cb)&&(_0x29d802['syncPointTree_']=_0x29d802['syncPointTree_']['remove'](_0x1d8f92));const _0x28c795=_0xe8c435['removed'];if(_0x2711d9=_0xe8c435['events'],!_0x39e676){const _0x3c8d3f=_0x28c795['findIndex'](_0x294cf8=>_0x294cf8['_queryParams']['loadsAllData']())!==-0x1,_0x4808f9=_0x29d802['syncPointTree_']['findOnPath'](_0x1d8f92,(_0x17fb65,_0x4d5db4)=>Te(_0x4d5db4));if(_0x3c8d3f&&!_0x4808f9){const _0x4e6df0=_0x29d802['syncPointTree_']['subtree'](_0x1d8f92);if(!_0x4e6df0['isEmpty']()){const _0x55e1c7=Qu(_0x4e6df0);for(let _0x19a2aa=0x0;_0x19a2aa<_0x55e1c7['length'];++_0x19a2aa){const _0x35dbbe=_0x55e1c7[_0x19a2aa],_0x12a055=_0x35dbbe['query'],_0x18d399=Xo(_0x29d802,_0x35dbbe);_0x29d802['listenProvider_']['startListening'](Tt(_0x12a055),Mt(_0x29d802,_0x12a055),_0x18d399['hashFn'],_0x18d399['onComplete']);}}}!_0x4808f9&&_0x28c795['length']>0x0&&!_0x201aab&&(_0x3c8d3f?_0x29d802['listenProvider_']['stopListening'](Tt(_0x59e704),null):_0x28c795['forEach'](_0x13aa15=>{const _0x3506f5=_0x29d802['queryToTagMap']['get'](Fn(_0x13aa15));_0x29d802['listenProvider_']['stopListening'](Tt(_0x13aa15),_0x3506f5);}));}Ju(_0x29d802,_0x28c795);}return _0x2711d9;}function Yo(_0x28890d,_0x2e5301,_0x130c06,_0x25ff10){const _0x52ed69=rs(_0x28890d,_0x25ff10);if(_0x52ed69!=null){const _0x3f461a=os(_0x52ed69),_0x2b9f05=_0x3f461a['path'],_0x22827e=_0x3f461a['queryId'],_0x45a299=F(_0x2b9f05,_0x2e5301),_0xa32a4=new Fe(Zi(_0x22827e),_0x45a299,_0x130c06);return as(_0x28890d,_0x2b9f05,_0xa32a4);}else return[];}function Ku(_0x4b93d1,_0x26b877,_0x4ac76b,_0xd91d74){const _0x5cb17a=rs(_0x4b93d1,_0xd91d74);if(_0x5cb17a){const _0x124e7b=os(_0x5cb17a),_0x13ade2=_0x124e7b['path'],_0x34294a=_0x124e7b['queryId'],_0x4d6b09=F(_0x13ade2,_0x26b877),_0x4ee379=S['fromObject'](_0x4ac76b),_0x2fbbcc=new nt(Zi(_0x34294a),_0x4d6b09,_0x4ee379);return as(_0x4b93d1,_0x13ade2,_0x2fbbcc);}else return[];}function bi(_0x89731f,_0x565234,_0x2bb9e1,_0x16110c=!0x1){const _0x57e762=_0x565234['_path'];let _0x977da=null,_0xaac60b=!0x1;_0x89731f['syncPointTree_']['foreachOnPath'](_0x57e762,(_0x506605,_0x170b9c)=>{const _0x29671e=F(_0x506605,_0x57e762);_0x977da=_0x977da||Ee(_0x170b9c,_0x29671e),_0xaac60b=_0xaac60b||Te(_0x170b9c);});let _0x5649d0=_0x89731f['syncPointTree_']['get'](_0x57e762);_0x5649d0?(_0xaac60b=_0xaac60b||Te(_0x5649d0),_0x977da=_0x977da||Ee(_0x5649d0,w())):(_0x5649d0=new Go(),_0x89731f['syncPointTree_']=_0x89731f['syncPointTree_']['set'](_0x57e762,_0x5649d0));let _0x251622;_0x977da!=null?_0x251622=!0x0:(_0x251622=!0x1,_0x977da=g['EMPTY_NODE'],_0x89731f['syncPointTree_']['subtree'](_0x57e762)['foreachChild']((_0x3eb787,_0xcca730)=>{const _0x296eb6=Ee(_0xcca730,w());_0x296eb6&&(_0x977da=_0x977da['updateImmediateChild'](_0x3eb787,_0x296eb6));}));const _0x31c35c=Ko(_0x5649d0,_0x565234);if(!_0x31c35c&&!_0x565234['_queryParams']['loadsAllData']()){const _0x44b367=Fn(_0x565234);f(!_0x89731f['queryToTagMap']['has'](_0x44b367),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2b8b01=Xu();_0x89731f['queryToTagMap']['set'](_0x44b367,_0x2b8b01),_0x89731f['tagToQueryMap']['set'](_0x2b8b01,_0x44b367);}const _0x2b60c0=Mn(_0x89731f['pendingWriteTree_'],_0x57e762);let _0x490e5d=Wu(_0x5649d0,_0x565234,_0x2bb9e1,_0x2b60c0,_0x977da,_0x251622);if(!_0x31c35c&&!_0xaac60b&&!_0x16110c){const _0x25db0c=jo(_0x5649d0,_0x565234);_0x490e5d=_0x490e5d['concat'](Zu(_0x89731f,_0x565234,_0x25db0c));}return _0x490e5d;}function xn(_0x198ac9,_0x4a74fe,_0x1da0ca){const _0x2ba475=_0x198ac9['pendingWriteTree_'],_0x2e0fe0=_0x198ac9['syncPointTree_']['findOnPath'](_0x4a74fe,(_0x5284e4,_0x39c011)=>{const _0x46c4cb=F(_0x5284e4,_0x4a74fe),_0xc12db3=Ee(_0x39c011,_0x46c4cb);if(_0xc12db3)return _0xc12db3;});return Uo(_0x2ba475,_0x4a74fe,_0x2e0fe0,_0x1da0ca,!0x0);}function Yu(_0x179397,_0x1504f3){const _0x156abd=_0x1504f3['_path'];let _0x4a28d6=null;_0x179397['syncPointTree_']['foreachOnPath'](_0x156abd,(_0x37d0d3,_0x2e6ae5)=>{const _0x5d1b7a=F(_0x37d0d3,_0x156abd);_0x4a28d6=_0x4a28d6||Ee(_0x2e6ae5,_0x5d1b7a);});let _0x537e51=_0x179397['syncPointTree_']['get'](_0x156abd);_0x537e51?_0x4a28d6=_0x4a28d6||Ee(_0x537e51,w()):(_0x537e51=new Go(),_0x179397['syncPointTree_']=_0x179397['syncPointTree_']['set'](_0x156abd,_0x537e51));const _0x1f24d2=_0x4a28d6!=null,_0x4f63b5=_0x1f24d2?new Ce(_0x4a28d6,!0x0,!0x1):null,_0x555d62=Mn(_0x179397['pendingWriteTree_'],_0x1504f3['_path']),_0x1395db=qo(_0x537e51,_0x1504f3,_0x555d62,_0x1f24d2?_0x4f63b5['getNode']():g['EMPTY_NODE'],_0x1f24d2);return Ou(_0x1395db);}function ht(_0x1286b1,_0x66801f){return Qo(_0x66801f,_0x1286b1['syncPointTree_'],null,Mn(_0x1286b1['pendingWriteTree_'],w()));}function Qo(_0x3d3050,_0x3ac5fb,_0x3d4c9a,_0x312655){if(v(_0x3d3050['path']))return Jo(_0x3d3050,_0x3ac5fb,_0x3d4c9a,_0x312655);{const _0x2acacd=_0x3ac5fb['get'](w());_0x3d4c9a==null&&_0x2acacd!=null&&(_0x3d4c9a=Ee(_0x2acacd,w()));let _0x5cce82=[];const _0x4c82d0=y(_0x3d3050['path']),_0x57a659=_0x3d3050['operationForChild'](_0x4c82d0),_0x8baee2=_0x3ac5fb['children']['get'](_0x4c82d0);if(_0x8baee2&&_0x57a659){const _0xd74960=_0x3d4c9a?_0x3d4c9a['getImmediateChild'](_0x4c82d0):null,_0x420f75=Wo(_0x312655,_0x4c82d0);_0x5cce82=_0x5cce82['concat'](Qo(_0x57a659,_0x8baee2,_0xd74960,_0x420f75));}return _0x2acacd&&(_0x5cce82=_0x5cce82['concat'](is(_0x2acacd,_0x3d3050,_0x312655,_0x3d4c9a))),_0x5cce82;}}function Jo(_0x4ea0df,_0x319b36,_0x5b4982,_0x7b7955){const _0x18c744=_0x319b36['get'](w());_0x5b4982==null&&_0x18c744!=null&&(_0x5b4982=Ee(_0x18c744,w()));let _0x4eb225=[];return _0x319b36['children']['inorderTraversal']((_0x2972d7,_0xa801)=>{const _0x32dde9=_0x5b4982?_0x5b4982['getImmediateChild'](_0x2972d7):null,_0x55a73e=Wo(_0x7b7955,_0x2972d7),_0x53bc74=_0x4ea0df['operationForChild'](_0x2972d7);_0x53bc74&&(_0x4eb225=_0x4eb225['concat'](Jo(_0x53bc74,_0xa801,_0x32dde9,_0x55a73e)));}),_0x18c744&&(_0x4eb225=_0x4eb225['concat'](is(_0x18c744,_0x4ea0df,_0x7b7955,_0x5b4982))),_0x4eb225;}function Xo(_0x2089a6,_0x4dfcb0){const _0x52cfbd=_0x4dfcb0['query'],_0x331eff=Mt(_0x2089a6,_0x52cfbd);return{'hashFn':()=>(Pu(_0x4dfcb0)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x46e5af=>{if(_0x46e5af==='ok')return _0x331eff?ju(_0x2089a6,_0x52cfbd['_path'],_0x331eff):zu(_0x2089a6,_0x52cfbd['_path']);{const _0x2fd20b=ql(_0x46e5af,_0x52cfbd);return wn(_0x2089a6,_0x52cfbd,null,_0x2fd20b);}}};}function Mt(_0x33fda8,_0x50d7cf){const _0x1babfc=Fn(_0x50d7cf);return _0x33fda8['queryToTagMap']['get'](_0x1babfc);}function Fn(_0x315b3a){return _0x315b3a['_path']['toString']()+'$'+_0x315b3a['_queryIdentifier'];}function rs(_0x140081,_0x16bf0c){return _0x140081['tagToQueryMap']['get'](_0x16bf0c);}function os(_0x2263ea){const _0xe04266=_0x2263ea['indexOf']('$');return f(_0xe04266!==-0x1&&_0xe04266<_0x2263ea['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2263ea['substr'](_0xe04266+0x1),'path':new C(_0x2263ea['substr'](0x0,_0xe04266))};}function as(_0x3cf6b9,_0xf32f37,_0x4c3461){const _0xc0288b=_0x3cf6b9['syncPointTree_']['get'](_0xf32f37);f(_0xc0288b,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xb04a66=Mn(_0x3cf6b9['pendingWriteTree_'],_0xf32f37);return is(_0xc0288b,_0x4c3461,_0xb04a66,null);}function Qu(_0x2a344a){return _0x2a344a['fold']((_0x2580a9,_0x22cd26,_0x5259b7)=>{if(_0x22cd26&&Te(_0x22cd26))return[Ln(_0x22cd26)];{let _0x366354=[];return _0x22cd26&&(_0x366354=zo(_0x22cd26)),x(_0x5259b7,(_0x54fc6f,_0x5982f2)=>{_0x366354=_0x366354['concat'](_0x5982f2);}),_0x366354;}});}function Tt(_0x4e4a0c){return _0x4e4a0c['_queryParams']['loadsAllData']()&&!_0x4e4a0c['_queryParams']['isDefault']()?new(Hu())(_0x4e4a0c['_repo'],_0x4e4a0c['_path']):_0x4e4a0c;}function Ju(_0x195f0e,_0x32932a){for(let _0x41f208=0x0;_0x41f208<_0x32932a['length'];++_0x41f208){const _0x314b54=_0x32932a[_0x41f208];if(!_0x314b54['_queryParams']['loadsAllData']()){const _0x1adef8=Fn(_0x314b54),_0x185534=_0x195f0e['queryToTagMap']['get'](_0x1adef8);_0x195f0e['queryToTagMap']['delete'](_0x1adef8),_0x195f0e['tagToQueryMap']['delete'](_0x185534);}}}function Xu(){return $u++;}function Zu(_0x3f2a60,_0x177a69,_0x260248){const _0x4d54b3=_0x177a69['_path'],_0x1eb1bb=Mt(_0x3f2a60,_0x177a69),_0x2d9b0a=Xo(_0x3f2a60,_0x260248),_0xe2ab3c=_0x3f2a60['listenProvider_']['startListening'](Tt(_0x177a69),_0x1eb1bb,_0x2d9b0a['hashFn'],_0x2d9b0a['onComplete']),_0x4e2f29=_0x3f2a60['syncPointTree_']['subtree'](_0x4d54b3);if(_0x1eb1bb)f(!Te(_0x4e2f29['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x257353=_0x4e2f29['fold']((_0x35f2c1,_0x50e36f,_0x2d1668)=>{if(!v(_0x35f2c1)&&_0x50e36f&&Te(_0x50e36f))return[Ln(_0x50e36f)['query']];{let _0x10a84a=[];return _0x50e36f&&(_0x10a84a=_0x10a84a['concat'](zo(_0x50e36f)['map'](_0x36ce90=>_0x36ce90['query']))),x(_0x2d1668,(_0x2817cc,_0x2228ca)=>{_0x10a84a=_0x10a84a['concat'](_0x2228ca);}),_0x10a84a;}});for(let _0x2223a5=0x0;_0x2223a5<_0x257353['length'];++_0x2223a5){const _0x3a0771=_0x257353[_0x2223a5];_0x3f2a60['listenProvider_']['stopListening'](Tt(_0x3a0771),Mt(_0x3f2a60,_0x3a0771));}}return _0xe2ab3c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0xbbe2c9){this['node_']=_0xbbe2c9;}['getImmediateChild'](_0x54532c){const _0x220124=this['node_']['getImmediateChild'](_0x54532c);return new cs(_0x220124);}['node'](){return this['node_'];}}class ls{constructor(_0x1ad18c,_0x24b6a3){this['syncTree_']=_0x1ad18c,this['path_']=_0x24b6a3;}['getImmediateChild'](_0x42667c){const _0x558174=A(this['path_'],_0x42667c);return new ls(this['syncTree_'],_0x558174);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x2c69d9){return _0x2c69d9=_0x2c69d9||{},_0x2c69d9['timestamp']=_0x2c69d9['timestamp']||new Date()['getTime'](),_0x2c69d9;},fr=function(_0x2a2a75,_0x59f138,_0x59ab0a){if(!_0x2a2a75||typeof _0x2a2a75!='object')return _0x2a2a75;if(f('.sv'in _0x2a2a75,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2a2a75['.sv']=='string')return td(_0x2a2a75['.sv'],_0x59f138,_0x59ab0a);if(typeof _0x2a2a75['.sv']=='object')return nd(_0x2a2a75['.sv'],_0x59f138);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2a2a75,null,0x2));},td=function(_0x18bf4e,_0x305d85,_0x38d391){switch(_0x18bf4e){case'timestamp':return _0x38d391['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x18bf4e);}},nd=function(_0x12c0b4,_0x38b382,_0x1a5ca9){_0x12c0b4['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x12c0b4,null,0x2));const _0x269f41=_0x12c0b4['increment'];typeof _0x269f41!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x269f41);const _0x583839=_0x38b382['node']();if(f(_0x583839!==null&&typeof _0x583839<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x583839['isLeafNode']())return _0x269f41;const _0x2e7431=_0x583839['getValue']();return typeof _0x2e7431!='number'?_0x269f41:_0x2e7431+_0x269f41;},Zo=function(_0x4615ab,_0x27a97a,_0xb9b400,_0x1079fc){return us(_0x27a97a,new ls(_0xb9b400,_0x4615ab),_0x1079fc);},hs=function(_0x4d9cc1,_0x12d4e7,_0xa452dd){return us(_0x4d9cc1,new cs(_0x12d4e7),_0xa452dd);};function us(_0x20e07b,_0x506ce5,_0x5701f5){const _0x576c33=_0x20e07b['getPriority']()['val'](),_0x487123=fr(_0x576c33,_0x506ce5['getImmediateChild']('.priority'),_0x5701f5);let _0x1c177e;if(_0x20e07b['isLeafNode']()){const _0x233b95=_0x20e07b,_0x41e01e=fr(_0x233b95['getValue'](),_0x506ce5,_0x5701f5);return _0x41e01e!==_0x233b95['getValue']()||_0x487123!==_0x233b95['getPriority']()['val']()?new D(_0x41e01e,N(_0x487123)):_0x20e07b;}else{const _0x282f1c=_0x20e07b;return _0x1c177e=_0x282f1c,_0x487123!==_0x282f1c['getPriority']()['val']()&&(_0x1c177e=_0x1c177e['updatePriority'](new D(_0x487123))),_0x282f1c['forEachChild'](R,(_0x69fc22,_0x122364)=>{const _0x2c1eaa=us(_0x122364,_0x506ce5['getImmediateChild'](_0x69fc22),_0x5701f5);_0x2c1eaa!==_0x122364&&(_0x1c177e=_0x1c177e['updateImmediateChild'](_0x69fc22,_0x2c1eaa));}),_0x1c177e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3d818b='',_0x18b29c=null,_0x249056={'children':{},'childCount':0x0}){this['name']=_0x3d818b,this['parent']=_0x18b29c,this['node']=_0x249056;}}function Un(_0x3b3b0b,_0x571072){let _0x54d356=_0x571072 instanceof C?_0x571072:new C(_0x571072),_0x56b279=_0x3b3b0b,_0x4ef231=y(_0x54d356);for(;_0x4ef231!==null;){const _0x49763d=Oe(_0x56b279['node']['children'],_0x4ef231)||{'children':{},'childCount':0x0};_0x56b279=new ds(_0x4ef231,_0x56b279,_0x49763d),_0x54d356=b(_0x54d356),_0x4ef231=y(_0x54d356);}return _0x56b279;}function Ge(_0x3232be){return _0x3232be['node']['value'];}function fs(_0x2a60c3,_0x1e3d3d){_0x2a60c3['node']['value']=_0x1e3d3d,Ri(_0x2a60c3);}function ea(_0x3e0a62){return _0x3e0a62['node']['childCount']>0x0;}function id(_0x460fd7){return Ge(_0x460fd7)===void 0x0&&!ea(_0x460fd7);}function Wn(_0x323da2,_0x27bc36){x(_0x323da2['node']['children'],(_0x4dc596,_0x367104)=>{_0x27bc36(new ds(_0x4dc596,_0x323da2,_0x367104));});}function ta(_0x4ec1d7,_0x576fbe,_0xbd54da,_0x622345){_0xbd54da&&_0x576fbe(_0x4ec1d7),Wn(_0x4ec1d7,_0x507afe=>{ta(_0x507afe,_0x576fbe,!0x0);});}function sd(_0x5683bd,_0x2c0ac1,_0x297219){let _0xf73092=_0x5683bd['parent'];for(;_0xf73092!==null;){if(_0x2c0ac1(_0xf73092))return!0x0;_0xf73092=_0xf73092['parent'];}return!0x1;}function Gt(_0x337cf2){return new C(_0x337cf2['parent']===null?_0x337cf2['name']:Gt(_0x337cf2['parent'])+'/'+_0x337cf2['name']);}function Ri(_0x5d7889){_0x5d7889['parent']!==null&&rd(_0x5d7889['parent'],_0x5d7889['name'],_0x5d7889);}function rd(_0x5d10fe,_0x7582c4,_0x180cde){const _0x685e07=id(_0x180cde),_0x188d93=Y(_0x5d10fe['node']['children'],_0x7582c4);_0x685e07&&_0x188d93?(delete _0x5d10fe['node']['children'][_0x7582c4],_0x5d10fe['node']['childCount']--,Ri(_0x5d10fe)):!_0x685e07&&!_0x188d93&&(_0x5d10fe['node']['children'][_0x7582c4]=_0x180cde['node'],_0x5d10fe['node']['childCount']++,Ri(_0x5d10fe));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x6e4aed){return typeof _0x6e4aed=='string'&&_0x6e4aed['length']!==0x0&&!od['test'](_0x6e4aed);},na=function(_0xc56d3e){return typeof _0xc56d3e=='string'&&_0xc56d3e['length']!==0x0&&!ad['test'](_0xc56d3e);},cd=function(_0x512ce7){return _0x512ce7&&(_0x512ce7=_0x512ce7['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x512ce7);},Cn=function(_0x12b2c4){return _0x12b2c4===null||typeof _0x12b2c4=='string'||typeof _0x12b2c4=='number'&&!Wi(_0x12b2c4)||_0x12b2c4&&typeof _0x12b2c4=='object'&&Y(_0x12b2c4,'.sv');},qt=function(_0x49beba,_0x283653,_0x3cae0d,_0x3ed0f9){_0x3ed0f9&&_0x283653===void 0x0||zt(Nn(_0x49beba,'value'),_0x283653,_0x3cae0d);},zt=function(_0x58e7ef,_0x3c9660,_0x19e2fc){const _0x2a3c1f=_0x19e2fc instanceof C?new Sh(_0x19e2fc,_0x58e7ef):_0x19e2fc;if(_0x3c9660===void 0x0)throw new Error(_0x58e7ef+'contains\x20undefined\x20'+Ne(_0x2a3c1f));if(typeof _0x3c9660=='function')throw new Error(_0x58e7ef+'contains\x20a\x20function\x20'+Ne(_0x2a3c1f)+'\x20with\x20contents\x20=\x20'+_0x3c9660['toString']());if(Wi(_0x3c9660))throw new Error(_0x58e7ef+'contains\x20'+_0x3c9660['toString']()+'\x20'+Ne(_0x2a3c1f));if(typeof _0x3c9660=='string'&&_0x3c9660['length']>oi/0x3&&Pn(_0x3c9660)>oi)throw new Error(_0x58e7ef+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x2a3c1f)+'\x20(\x27'+_0x3c9660['substring'](0x0,0x32)+'...\x27)');if(_0x3c9660&&typeof _0x3c9660=='object'){let _0x44eb14=!0x1,_0x1b8dab=!0x1;if(x(_0x3c9660,(_0x379939,_0x68e920)=>{if(_0x379939==='.value')_0x44eb14=!0x0;else{if(_0x379939!=='.priority'&&_0x379939!=='.sv'&&(_0x1b8dab=!0x0,!ps(_0x379939)))throw new Error(_0x58e7ef+'\x20contains\x20an\x20invalid\x20key\x20('+_0x379939+')\x20'+Ne(_0x2a3c1f)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x2a3c1f,_0x379939),zt(_0x58e7ef,_0x68e920,_0x2a3c1f),Rh(_0x2a3c1f);}),_0x44eb14&&_0x1b8dab)throw new Error(_0x58e7ef+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2a3c1f)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0xa578dc,_0x8590c){let _0x27aa75,_0x87ac70;for(_0x27aa75=0x0;_0x27aa75<_0x8590c['length'];_0x27aa75++){_0x87ac70=_0x8590c[_0x27aa75];const _0x1cf338=kt(_0x87ac70);for(let _0x289d36=0x0;_0x289d36<_0x1cf338['length'];_0x289d36++)if(!(_0x1cf338[_0x289d36]==='.priority'&&_0x289d36===_0x1cf338['length']-0x1)){if(!ps(_0x1cf338[_0x289d36]))throw new Error(_0xa578dc+'contains\x20an\x20invalid\x20key\x20('+_0x1cf338[_0x289d36]+')\x20in\x20path\x20'+_0x87ac70['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x8590c['sort'](Th);let _0x32804d=null;for(_0x27aa75=0x0;_0x27aa75<_0x8590c['length'];_0x27aa75++){if(_0x87ac70=_0x8590c[_0x27aa75],_0x32804d!==null&&$(_0x32804d,_0x87ac70))throw new Error(_0xa578dc+'contains\x20a\x20path\x20'+_0x32804d['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x87ac70['toString']());_0x32804d=_0x87ac70;}},hd=function(_0x22f899,_0x57366d,_0x228022,_0x500a39){const _0x1ebbad=Nn(_0x22f899,'values');if(!(_0x57366d&&typeof _0x57366d=='object')||Array['isArray'](_0x57366d))throw new Error(_0x1ebbad+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3b4a3a=[];x(_0x57366d,(_0x3de119,_0x4e6acc)=>{const _0x431b29=new C(_0x3de119);if(zt(_0x1ebbad,_0x4e6acc,A(_0x228022,_0x431b29)),Gi(_0x431b29)==='.priority'&&!Cn(_0x4e6acc))throw new Error(_0x1ebbad+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x431b29['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3b4a3a['push'](_0x431b29);}),ld(_0x1ebbad,_0x3b4a3a);},_s=function(_0x347e65,_0x26e46d,_0x40a2a0,_0x20cd93){if(!na(_0x40a2a0))throw new Error(Nn(_0x347e65,_0x26e46d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x40a2a0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x573f57,_0x3ac6ee,_0x3d6380,_0x43a09d){_0x3d6380&&(_0x3d6380=_0x3d6380['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x573f57,_0x3ac6ee,_0x3d6380);},gs=function(_0xd9aa6a,_0x322c55){if(y(_0x322c55)==='.info')throw new Error(_0xd9aa6a+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x2b7a55,_0x3d2f98){const _0x3dfb8a=_0x3d2f98['path']['toString']();if(typeof _0x3d2f98['repoInfo']['host']!='string'||_0x3d2f98['repoInfo']['host']['length']===0x0||!ps(_0x3d2f98['repoInfo']['namespace'])&&_0x3d2f98['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3dfb8a['length']!==0x0&&!cd(_0x3dfb8a))throw new Error(Nn(_0x2b7a55,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x6d25b0,_0x35744a){let _0x2af180=null;for(let _0x2d838e=0x0;_0x2d838e<_0x35744a['length'];_0x2d838e++){const _0x363da2=_0x35744a[_0x2d838e],_0x5d6eeb=_0x363da2['getPath']();_0x2af180!==null&&!qi(_0x5d6eeb,_0x2af180['path'])&&(_0x6d25b0['eventLists_']['push'](_0x2af180),_0x2af180=null),_0x2af180===null&&(_0x2af180={'events':[],'path':_0x5d6eeb}),_0x2af180['events']['push'](_0x363da2);}_0x2af180&&_0x6d25b0['eventLists_']['push'](_0x2af180);}function ia(_0x2ebff0,_0x36da99,_0x2e760){Bn(_0x2ebff0,_0x2e760),sa(_0x2ebff0,_0x1e6a23=>qi(_0x1e6a23,_0x36da99));}function V(_0x2e9e29,_0x10369e,_0xcf11c9){Bn(_0x2e9e29,_0xcf11c9),sa(_0x2e9e29,_0xb7ddd9=>$(_0xb7ddd9,_0x10369e)||$(_0x10369e,_0xb7ddd9));}function sa(_0x4db15c,_0x3f3ac6){_0x4db15c['recursionDepth_']++;let _0x28bc96=!0x0;for(let _0x4f4ed1=0x0;_0x4f4ed1<_0x4db15c['eventLists_']['length'];_0x4f4ed1++){const _0xd47560=_0x4db15c['eventLists_'][_0x4f4ed1];if(_0xd47560){const _0x3e1eff=_0xd47560['path'];_0x3f3ac6(_0x3e1eff)?(pd(_0x4db15c['eventLists_'][_0x4f4ed1]),_0x4db15c['eventLists_'][_0x4f4ed1]=null):_0x28bc96=!0x1;}}_0x28bc96&&(_0x4db15c['eventLists_']=[]),_0x4db15c['recursionDepth_']--;}function pd(_0x56997f){for(let _0x411dfd=0x0;_0x411dfd<_0x56997f['events']['length'];_0x411dfd++){const _0x2975c6=_0x56997f['events'][_0x411dfd];if(_0x2975c6!==null){_0x56997f['events'][_0x411dfd]=null;const _0x20b6f8=_0x2975c6['getEventRunner']();Et&&L('event:\x20'+_0x2975c6['toString']()),lt(_0x20b6f8);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x2df374,_0x3ca725,_0x41fc7d,_0x3e9c7f){this['repoInfo_']=_0x2df374,this['forceRestClient_']=_0x3ca725,this['authTokenProvider_']=_0x41fc7d,this['appCheckProvider_']=_0x3e9c7f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x127acc,_0x4ce30a,_0xd877c5){if(_0x127acc['stats_']=Hi(_0x127acc['repoInfo_']),_0x127acc['forceRestClient_']||Yl())_0x127acc['server_']=new fn(_0x127acc['repoInfo_'],(_0x4076cd,_0x2d8214,_0x4ccd11,_0x34e38b)=>{pr(_0x127acc,_0x4076cd,_0x2d8214,_0x4ccd11,_0x34e38b);},_0x127acc['authTokenProvider_'],_0x127acc['appCheckProvider_']),setTimeout(()=>_r(_0x127acc,!0x0),0x0);else{if(typeof _0xd877c5<'u'&&_0xd877c5!==null){if(typeof _0xd877c5!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xd877c5);}catch(_0x5f2910){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5f2910);}}_0x127acc['persistentConnection_']=new ie(_0x127acc['repoInfo_'],_0x4ce30a,(_0x493a16,_0x48336e,_0x3db632,_0x572e81)=>{pr(_0x127acc,_0x493a16,_0x48336e,_0x3db632,_0x572e81);},_0x15f429=>{_r(_0x127acc,_0x15f429);},_0x47168e=>{yd(_0x127acc,_0x47168e);},_0x127acc['authTokenProvider_'],_0x127acc['appCheckProvider_'],_0xd877c5),_0x127acc['server_']=_0x127acc['persistentConnection_'];}_0x127acc['authTokenProvider_']['addTokenChangeListener'](_0x3c6964=>{_0x127acc['server_']['refreshAuthToken'](_0x3c6964);}),_0x127acc['appCheckProvider_']['addTokenChangeListener'](_0x215607=>{_0x127acc['server_']['refreshAppCheckToken'](_0x215607['token']);}),_0x127acc['statsReporter_']=eh(_0x127acc['repoInfo_'],()=>new eu(_0x127acc['stats_'],_0x127acc['server_'])),_0x127acc['infoData_']=new Yh(),_0x127acc['infoSyncTree_']=new dr({'startListening':(_0xbe0d30,_0x2f87d8,_0x368cf2,_0x54fb9d)=>{let _0x59c4cb=[];const _0x804a21=_0x127acc['infoData_']['getNode'](_0xbe0d30['_path']);return _0x804a21['isEmpty']()||(_0x59c4cb=$t(_0x127acc['infoSyncTree_'],_0xbe0d30['_path'],_0x804a21),setTimeout(()=>{_0x54fb9d('ok');},0x0)),_0x59c4cb;},'stopListening':()=>{}}),ms(_0x127acc,'connected',!0x1),_0x127acc['serverSyncTree_']=new dr({'startListening':(_0xbbbf21,_0x5b79af,_0x2032a5,_0x93261b)=>(_0x127acc['server_']['listen'](_0xbbbf21,_0x2032a5,_0x5b79af,(_0x1dbdf0,_0x3dc542)=>{const _0x301fd7=_0x93261b(_0x1dbdf0,_0x3dc542);V(_0x127acc['eventQueue_'],_0xbbbf21['_path'],_0x301fd7);}),[]),'stopListening':(_0x28ee48,_0x9512c6)=>{_0x127acc['server_']['unlisten'](_0x28ee48,_0x9512c6);}});}function oa(_0x3b6afb){const _0x3784bf=_0x3b6afb['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3784bf;}function jt(_0x41f4a3){return ed({'timestamp':oa(_0x41f4a3)});}function pr(_0x4d6476,_0x4480ed,_0x5c682f,_0x34c279,_0x59400e){_0x4d6476['dataUpdateCount']++;const _0x249d0f=new C(_0x4480ed);_0x5c682f=_0x4d6476['interceptServerDataCallback_']?_0x4d6476['interceptServerDataCallback_'](_0x4480ed,_0x5c682f):_0x5c682f;let _0x276528=[];if(_0x59400e){if(_0x34c279){const _0x227671=ln(_0x5c682f,_0x248902=>N(_0x248902));_0x276528=Ku(_0x4d6476['serverSyncTree_'],_0x249d0f,_0x227671,_0x59400e);}else{const _0x15fbb2=N(_0x5c682f);_0x276528=Yo(_0x4d6476['serverSyncTree_'],_0x249d0f,_0x15fbb2,_0x59400e);}}else{if(_0x34c279){const _0x35bfbe=ln(_0x5c682f,_0x1fd1e9=>N(_0x1fd1e9));_0x276528=qu(_0x4d6476['serverSyncTree_'],_0x249d0f,_0x35bfbe);}else{const _0x52d9c2=N(_0x5c682f);_0x276528=$t(_0x4d6476['serverSyncTree_'],_0x249d0f,_0x52d9c2);}}let _0x30a999=_0x249d0f;_0x276528['length']>0x0&&(_0x30a999=st(_0x4d6476,_0x249d0f)),V(_0x4d6476['eventQueue_'],_0x30a999,_0x276528);}function _r(_0x56b8cc,_0x174779){ms(_0x56b8cc,'connected',_0x174779),_0x174779===!0x1&&wd(_0x56b8cc);}function yd(_0x3bcaad,_0x433981){x(_0x433981,(_0x34ec8b,_0x376416)=>{ms(_0x3bcaad,_0x34ec8b,_0x376416);});}function ms(_0x476d04,_0x2b48e2,_0x283ece){const _0x15bfc4=new C('/.info/'+_0x2b48e2),_0x16422c=N(_0x283ece);_0x476d04['infoData_']['updateSnapshot'](_0x15bfc4,_0x16422c);const _0x1f9526=$t(_0x476d04['infoSyncTree_'],_0x15bfc4,_0x16422c);V(_0x476d04['eventQueue_'],_0x15bfc4,_0x1f9526);}function Vn(_0xe117e5){return _0xe117e5['nextWriteId_']++;}function vd(_0x40cef7,_0x38062a,_0x2b8976){const _0x4f10e9=Yu(_0x40cef7['serverSyncTree_'],_0x38062a);return _0x4f10e9!=null?Promise['resolve'](_0x4f10e9):_0x40cef7['server_']['get'](_0x38062a)['then'](_0x2fa2cd=>{const _0xe715dd=N(_0x2fa2cd)['withIndex'](_0x38062a['_queryParams']['getIndex']());bi(_0x40cef7['serverSyncTree_'],_0x38062a,_0x2b8976,!0x0);let _0x18383f;if(_0x38062a['_queryParams']['loadsAllData']())_0x18383f=$t(_0x40cef7['serverSyncTree_'],_0x38062a['_path'],_0xe715dd);else{const _0x45194c=Mt(_0x40cef7['serverSyncTree_'],_0x38062a);_0x18383f=Yo(_0x40cef7['serverSyncTree_'],_0x38062a['_path'],_0xe715dd,_0x45194c);}return V(_0x40cef7['eventQueue_'],_0x38062a['_path'],_0x18383f),wn(_0x40cef7['serverSyncTree_'],_0x38062a,_0x2b8976,null,!0x0),_0xe715dd;},_0x15e9f3=>(ut(_0x40cef7,'get\x20for\x20query\x20'+O(_0x38062a)+'\x20failed:\x20'+_0x15e9f3),Promise['reject'](new Error(_0x15e9f3))));}function Ed(_0x58cc55,_0x1cd8ea,_0x49ecbd,_0x3ea857,_0x50ccc7){ut(_0x58cc55,'set',{'path':_0x1cd8ea['toString'](),'value':_0x49ecbd,'priority':_0x3ea857});const _0x1463d4=jt(_0x58cc55),_0x3dfc25=N(_0x49ecbd,_0x3ea857),_0x5a048c=xn(_0x58cc55['serverSyncTree_'],_0x1cd8ea),_0x31fefc=hs(_0x3dfc25,_0x5a048c,_0x1463d4),_0x180723=Vn(_0x58cc55),_0x2beb1c=ss(_0x58cc55['serverSyncTree_'],_0x1cd8ea,_0x31fefc,_0x180723,!0x0);Bn(_0x58cc55['eventQueue_'],_0x2beb1c),_0x58cc55['server_']['put'](_0x1cd8ea['toString'](),_0x3dfc25['val'](!0x0),(_0x4ed380,_0x40918f)=>{const _0x25ac2e=_0x4ed380==='ok';_0x25ac2e||U('set\x20at\x20'+_0x1cd8ea+'\x20failed:\x20'+_0x4ed380);const _0x45189c=pe(_0x58cc55['serverSyncTree_'],_0x180723,!_0x25ac2e);V(_0x58cc55['eventQueue_'],_0x1cd8ea,_0x45189c),Ai(_0x58cc55,_0x50ccc7,_0x4ed380,_0x40918f);});const _0x50fc95=vs(_0x58cc55,_0x1cd8ea);st(_0x58cc55,_0x50fc95),V(_0x58cc55['eventQueue_'],_0x50fc95,[]);}function Id(_0x207643,_0x34306b,_0x1e639d,_0x3b831c){ut(_0x207643,'update',{'path':_0x34306b['toString'](),'value':_0x1e639d});let _0x48a833=!0x0;const _0x911cba=jt(_0x207643),_0x44b145={};if(x(_0x1e639d,(_0x417e91,_0x347f76)=>{_0x48a833=!0x1,_0x44b145[_0x417e91]=Zo(A(_0x34306b,_0x417e91),N(_0x347f76),_0x207643['serverSyncTree_'],_0x911cba);}),_0x48a833)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x207643,_0x3b831c,'ok',void 0x0);else{const _0x445cb1=Vn(_0x207643),_0x15b73c=Gu(_0x207643['serverSyncTree_'],_0x34306b,_0x44b145,_0x445cb1);Bn(_0x207643['eventQueue_'],_0x15b73c),_0x207643['server_']['merge'](_0x34306b['toString'](),_0x1e639d,(_0x4d3c13,_0x2b61ff)=>{const _0x2ba93b=_0x4d3c13==='ok';_0x2ba93b||U('update\x20at\x20'+_0x34306b+'\x20failed:\x20'+_0x4d3c13);const _0x4a896e=pe(_0x207643['serverSyncTree_'],_0x445cb1,!_0x2ba93b),_0x4e5e62=_0x4a896e['length']>0x0?st(_0x207643,_0x34306b):_0x34306b;V(_0x207643['eventQueue_'],_0x4e5e62,_0x4a896e),Ai(_0x207643,_0x3b831c,_0x4d3c13,_0x2b61ff);}),x(_0x1e639d,_0x48bdbc=>{const _0x28a9ef=vs(_0x207643,A(_0x34306b,_0x48bdbc));st(_0x207643,_0x28a9ef);}),V(_0x207643['eventQueue_'],_0x34306b,[]);}}function wd(_0x34441b){ut(_0x34441b,'onDisconnectEvents');const _0x517c48=jt(_0x34441b),_0x190f10=pn();Ei(_0x34441b['onDisconnect_'],w(),(_0x145ad2,_0x34421f)=>{const _0x170840=Zo(_0x145ad2,_0x34421f,_0x34441b['serverSyncTree_'],_0x517c48);Mo(_0x190f10,_0x145ad2,_0x170840);});let _0x3b8af4=[];Ei(_0x190f10,w(),(_0x3313af,_0x2e5d58)=>{_0x3b8af4=_0x3b8af4['concat']($t(_0x34441b['serverSyncTree_'],_0x3313af,_0x2e5d58));const _0xf651aa=vs(_0x34441b,_0x3313af);st(_0x34441b,_0xf651aa);}),_0x34441b['onDisconnect_']=pn(),V(_0x34441b['eventQueue_'],w(),_0x3b8af4);}function Cd(_0xe26d29,_0x1cecbe,_0x352a0c){let _0x482e53;y(_0x1cecbe['_path'])==='.info'?_0x482e53=bi(_0xe26d29['infoSyncTree_'],_0x1cecbe,_0x352a0c):_0x482e53=bi(_0xe26d29['serverSyncTree_'],_0x1cecbe,_0x352a0c),ia(_0xe26d29['eventQueue_'],_0x1cecbe['_path'],_0x482e53);}function Td(_0xd92491,_0x58b995,_0x53ccc5){let _0x3703a5;y(_0x58b995['_path'])==='.info'?_0x3703a5=wn(_0xd92491['infoSyncTree_'],_0x58b995,_0x53ccc5):_0x3703a5=wn(_0xd92491['serverSyncTree_'],_0x58b995,_0x53ccc5),ia(_0xd92491['eventQueue_'],_0x58b995['_path'],_0x3703a5);}function aa(_0x49129b){_0x49129b['persistentConnection_']&&_0x49129b['persistentConnection_']['interrupt'](ra);}function Sd(_0x5fd83a){_0x5fd83a['persistentConnection_']&&_0x5fd83a['persistentConnection_']['resume'](ra);}function ut(_0x150ae5,..._0x404eca){let _0xbcf8b7='';_0x150ae5['persistentConnection_']&&(_0xbcf8b7=_0x150ae5['persistentConnection_']['id']+':'),L(_0xbcf8b7,..._0x404eca);}function Ai(_0x2be298,_0x233696,_0xc18733,_0x4cf352){_0x233696&&lt(()=>{if(_0xc18733==='ok')_0x233696(null);else{const _0x265926=(_0xc18733||'error')['toUpperCase']();let _0x4efe9a=_0x265926;_0x4cf352&&(_0x4efe9a+=':\x20'+_0x4cf352);const _0x260d9a=new Error(_0x4efe9a);_0x260d9a['code']=_0x265926,_0x233696(_0x260d9a);}});}function bd(_0x3d9df3,_0x1add18,_0x31bd29,_0x18e61b,_0x1cb380,_0x1d9b4c){ut(_0x3d9df3,'transaction\x20on\x20'+_0x1add18);const _0xbee903={'path':_0x1add18,'update':_0x31bd29,'onComplete':_0x18e61b,'status':null,'order':to(),'applyLocally':_0x1d9b4c,'retryCount':0x0,'unwatcher':_0x1cb380,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x50a7f5=ys(_0x3d9df3,_0x1add18,void 0x0);_0xbee903['currentInputSnapshot']=_0x50a7f5;const _0x39b299=_0xbee903['update'](_0x50a7f5['val']());if(_0x39b299===void 0x0)_0xbee903['unwatcher'](),_0xbee903['currentOutputSnapshotRaw']=null,_0xbee903['currentOutputSnapshotResolved']=null,_0xbee903['onComplete']&&_0xbee903['onComplete'](null,!0x1,_0xbee903['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x39b299,_0xbee903['path']),_0xbee903['status']=0x0;const _0x2f0e5e=Un(_0x3d9df3['transactionQueueTree_'],_0x1add18),_0x379efc=Ge(_0x2f0e5e)||[];_0x379efc['push'](_0xbee903),fs(_0x2f0e5e,_0x379efc);let _0x2207ae;typeof _0x39b299=='object'&&_0x39b299!==null&&Y(_0x39b299,'.priority')?(_0x2207ae=Oe(_0x39b299,'.priority'),f(Cn(_0x2207ae),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2207ae=(xn(_0x3d9df3['serverSyncTree_'],_0x1add18)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x50f337=jt(_0x3d9df3),_0x407d05=N(_0x39b299,_0x2207ae),_0x167463=hs(_0x407d05,_0x50a7f5,_0x50f337);_0xbee903['currentOutputSnapshotRaw']=_0x407d05,_0xbee903['currentOutputSnapshotResolved']=_0x167463,_0xbee903['currentWriteId']=Vn(_0x3d9df3);const _0x325119=ss(_0x3d9df3['serverSyncTree_'],_0x1add18,_0x167463,_0xbee903['currentWriteId'],_0xbee903['applyLocally']);V(_0x3d9df3['eventQueue_'],_0x1add18,_0x325119),Hn(_0x3d9df3,_0x3d9df3['transactionQueueTree_']);}}function ys(_0x19a320,_0x5438ce,_0x39e6b8){return xn(_0x19a320['serverSyncTree_'],_0x5438ce,_0x39e6b8)||g['EMPTY_NODE'];}function Hn(_0x11ab7a,_0x33b01d=_0x11ab7a['transactionQueueTree_']){if(_0x33b01d||$n(_0x11ab7a,_0x33b01d),Ge(_0x33b01d)){const _0x3cdb51=la(_0x11ab7a,_0x33b01d);f(_0x3cdb51['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3cdb51['every'](_0x18f12b=>_0x18f12b['status']===0x0)&&Rd(_0x11ab7a,Gt(_0x33b01d),_0x3cdb51);}else ea(_0x33b01d)&&Wn(_0x33b01d,_0x45413d=>{Hn(_0x11ab7a,_0x45413d);});}function Rd(_0x335cc7,_0x8cb907,_0x808b37){const _0x5652f4=_0x808b37['map'](_0x17528d=>_0x17528d['currentWriteId']),_0x3587b3=ys(_0x335cc7,_0x8cb907,_0x5652f4);let _0x43e4c0=_0x3587b3;const _0xe8d4be=_0x3587b3['hash']();for(let _0x448500=0x0;_0x448500<_0x808b37['length'];_0x448500++){const _0x243a4d=_0x808b37[_0x448500];f(_0x243a4d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x243a4d['status']=0x1,_0x243a4d['retryCount']++;const _0x4a1001=F(_0x8cb907,_0x243a4d['path']);_0x43e4c0=_0x43e4c0['updateChild'](_0x4a1001,_0x243a4d['currentOutputSnapshotRaw']);}const _0x4372c0=_0x43e4c0['val'](!0x0),_0x7226ac=_0x8cb907;_0x335cc7['server_']['put'](_0x7226ac['toString'](),_0x4372c0,_0xf7dacd=>{ut(_0x335cc7,'transaction\x20put\x20response',{'path':_0x7226ac['toString'](),'status':_0xf7dacd});let _0x1019ca=[];if(_0xf7dacd==='ok'){const _0x221d3c=[];for(let _0x48f7ed=0x0;_0x48f7ed<_0x808b37['length'];_0x48f7ed++)_0x808b37[_0x48f7ed]['status']=0x2,_0x1019ca=_0x1019ca['concat'](pe(_0x335cc7['serverSyncTree_'],_0x808b37[_0x48f7ed]['currentWriteId'])),_0x808b37[_0x48f7ed]['onComplete']&&_0x221d3c['push'](()=>_0x808b37[_0x48f7ed]['onComplete'](null,!0x0,_0x808b37[_0x48f7ed]['currentOutputSnapshotResolved'])),_0x808b37[_0x48f7ed]['unwatcher']();$n(_0x335cc7,Un(_0x335cc7['transactionQueueTree_'],_0x8cb907)),Hn(_0x335cc7,_0x335cc7['transactionQueueTree_']),V(_0x335cc7['eventQueue_'],_0x8cb907,_0x1019ca);for(let _0x122b49=0x0;_0x122b49<_0x221d3c['length'];_0x122b49++)lt(_0x221d3c[_0x122b49]);}else{if(_0xf7dacd==='datastale'){for(let _0x4dd636=0x0;_0x4dd636<_0x808b37['length'];_0x4dd636++)_0x808b37[_0x4dd636]['status']===0x3?_0x808b37[_0x4dd636]['status']=0x4:_0x808b37[_0x4dd636]['status']=0x0;}else{U('transaction\x20at\x20'+_0x7226ac['toString']()+'\x20failed:\x20'+_0xf7dacd);for(let _0x4fc5ef=0x0;_0x4fc5ef<_0x808b37['length'];_0x4fc5ef++)_0x808b37[_0x4fc5ef]['status']=0x4,_0x808b37[_0x4fc5ef]['abortReason']=_0xf7dacd;}st(_0x335cc7,_0x8cb907);}},_0xe8d4be);}function st(_0xb87b4,_0x242335){const _0x9347f7=ca(_0xb87b4,_0x242335),_0x3ed84c=Gt(_0x9347f7),_0x4f3aa3=la(_0xb87b4,_0x9347f7);return Ad(_0xb87b4,_0x4f3aa3,_0x3ed84c),_0x3ed84c;}function Ad(_0x380ced,_0x4d6831,_0x168726){if(_0x4d6831['length']===0x0)return;const _0x2760a9=[];let _0x42aca0=[];const _0x27a87e=_0x4d6831['filter'](_0x2dfe4a=>_0x2dfe4a['status']===0x0)['map'](_0x3d3ebf=>_0x3d3ebf['currentWriteId']);for(let _0x42a71d=0x0;_0x42a71d<_0x4d6831['length'];_0x42a71d++){const _0x2a6065=_0x4d6831[_0x42a71d],_0x1bea17=F(_0x168726,_0x2a6065['path']);let _0x2bbb7b=!0x1,_0x1c72f8;if(f(_0x1bea17!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2a6065['status']===0x4)_0x2bbb7b=!0x0,_0x1c72f8=_0x2a6065['abortReason'],_0x42aca0=_0x42aca0['concat'](pe(_0x380ced['serverSyncTree_'],_0x2a6065['currentWriteId'],!0x0));else{if(_0x2a6065['status']===0x0){if(_0x2a6065['retryCount']>=_d)_0x2bbb7b=!0x0,_0x1c72f8='maxretry',_0x42aca0=_0x42aca0['concat'](pe(_0x380ced['serverSyncTree_'],_0x2a6065['currentWriteId'],!0x0));else{const _0x1f0b0f=ys(_0x380ced,_0x2a6065['path'],_0x27a87e);_0x2a6065['currentInputSnapshot']=_0x1f0b0f;const _0x2ff9ef=_0x4d6831[_0x42a71d]['update'](_0x1f0b0f['val']());if(_0x2ff9ef!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2ff9ef,_0x2a6065['path']);let _0x1fa50f=N(_0x2ff9ef);typeof _0x2ff9ef=='object'&&_0x2ff9ef!=null&&Y(_0x2ff9ef,'.priority')||(_0x1fa50f=_0x1fa50f['updatePriority'](_0x1f0b0f['getPriority']()));const _0x494568=_0x2a6065['currentWriteId'],_0x48f357=jt(_0x380ced),_0x4dc562=hs(_0x1fa50f,_0x1f0b0f,_0x48f357);_0x2a6065['currentOutputSnapshotRaw']=_0x1fa50f,_0x2a6065['currentOutputSnapshotResolved']=_0x4dc562,_0x2a6065['currentWriteId']=Vn(_0x380ced),_0x27a87e['splice'](_0x27a87e['indexOf'](_0x494568),0x1),_0x42aca0=_0x42aca0['concat'](ss(_0x380ced['serverSyncTree_'],_0x2a6065['path'],_0x4dc562,_0x2a6065['currentWriteId'],_0x2a6065['applyLocally'])),_0x42aca0=_0x42aca0['concat'](pe(_0x380ced['serverSyncTree_'],_0x494568,!0x0));}else _0x2bbb7b=!0x0,_0x1c72f8='nodata',_0x42aca0=_0x42aca0['concat'](pe(_0x380ced['serverSyncTree_'],_0x2a6065['currentWriteId'],!0x0));}}}V(_0x380ced['eventQueue_'],_0x168726,_0x42aca0),_0x42aca0=[],_0x2bbb7b&&(_0x4d6831[_0x42a71d]['status']=0x2,function(_0xa20fce){setTimeout(_0xa20fce,Math['floor'](0x0));}(_0x4d6831[_0x42a71d]['unwatcher']),_0x4d6831[_0x42a71d]['onComplete']&&(_0x1c72f8==='nodata'?_0x2760a9['push'](()=>_0x4d6831[_0x42a71d]['onComplete'](null,!0x1,_0x4d6831[_0x42a71d]['currentInputSnapshot'])):_0x2760a9['push'](()=>_0x4d6831[_0x42a71d]['onComplete'](new Error(_0x1c72f8),!0x1,null))));}$n(_0x380ced,_0x380ced['transactionQueueTree_']);for(let _0x2dc9e5=0x0;_0x2dc9e5<_0x2760a9['length'];_0x2dc9e5++)lt(_0x2760a9[_0x2dc9e5]);Hn(_0x380ced,_0x380ced['transactionQueueTree_']);}function ca(_0x47dd8e,_0x911d22){let _0x5c912c,_0x5638e8=_0x47dd8e['transactionQueueTree_'];for(_0x5c912c=y(_0x911d22);_0x5c912c!==null&&Ge(_0x5638e8)===void 0x0;)_0x5638e8=Un(_0x5638e8,_0x5c912c),_0x911d22=b(_0x911d22),_0x5c912c=y(_0x911d22);return _0x5638e8;}function la(_0x107616,_0x3d8756){const _0x5a77ca=[];return ha(_0x107616,_0x3d8756,_0x5a77ca),_0x5a77ca['sort']((_0xa1df62,_0x298c10)=>_0xa1df62['order']-_0x298c10['order']),_0x5a77ca;}function ha(_0x247859,_0x2aa153,_0x483bdc){const _0x58659b=Ge(_0x2aa153);if(_0x58659b){for(let _0x54e040=0x0;_0x54e040<_0x58659b['length'];_0x54e040++)_0x483bdc['push'](_0x58659b[_0x54e040]);}Wn(_0x2aa153,_0x329592=>{ha(_0x247859,_0x329592,_0x483bdc);});}function $n(_0x594f88,_0x47302e){const _0xbd2ce6=Ge(_0x47302e);if(_0xbd2ce6){let _0x580064=0x0;for(let _0xe781e8=0x0;_0xe781e8<_0xbd2ce6['length'];_0xe781e8++)_0xbd2ce6[_0xe781e8]['status']!==0x2&&(_0xbd2ce6[_0x580064]=_0xbd2ce6[_0xe781e8],_0x580064++);_0xbd2ce6['length']=_0x580064,fs(_0x47302e,_0xbd2ce6['length']>0x0?_0xbd2ce6:void 0x0);}Wn(_0x47302e,_0x547fc3=>{$n(_0x594f88,_0x547fc3);});}function vs(_0x59c852,_0x117db9){const _0xd0ce72=Gt(ca(_0x59c852,_0x117db9)),_0x37fe8f=Un(_0x59c852['transactionQueueTree_'],_0x117db9);return sd(_0x37fe8f,_0x3fd33a=>{ai(_0x59c852,_0x3fd33a);}),ai(_0x59c852,_0x37fe8f),ta(_0x37fe8f,_0x572ce7=>{ai(_0x59c852,_0x572ce7);}),_0xd0ce72;}function ai(_0x3b0881,_0x3e698f){const _0x5e1075=Ge(_0x3e698f);if(_0x5e1075){const _0x2f6bea=[];let _0x57c3e2=[],_0x3e1133=-0x1;for(let _0x4245e7=0x0;_0x4245e7<_0x5e1075['length'];_0x4245e7++)_0x5e1075[_0x4245e7]['status']===0x3||(_0x5e1075[_0x4245e7]['status']===0x1?(f(_0x3e1133===_0x4245e7-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3e1133=_0x4245e7,_0x5e1075[_0x4245e7]['status']=0x3,_0x5e1075[_0x4245e7]['abortReason']='set'):(f(_0x5e1075[_0x4245e7]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5e1075[_0x4245e7]['unwatcher'](),_0x57c3e2=_0x57c3e2['concat'](pe(_0x3b0881['serverSyncTree_'],_0x5e1075[_0x4245e7]['currentWriteId'],!0x0)),_0x5e1075[_0x4245e7]['onComplete']&&_0x2f6bea['push'](_0x5e1075[_0x4245e7]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3e1133===-0x1?fs(_0x3e698f,void 0x0):_0x5e1075['length']=_0x3e1133+0x1,V(_0x3b0881['eventQueue_'],Gt(_0x3e698f),_0x57c3e2);for(let _0x689d79=0x0;_0x689d79<_0x2f6bea['length'];_0x689d79++)lt(_0x2f6bea[_0x689d79]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x4c9ed3){let _0x35bad4='';const _0x416865=_0x4c9ed3['split']('/');for(let _0x2e6b3d=0x0;_0x2e6b3d<_0x416865['length'];_0x2e6b3d++)if(_0x416865[_0x2e6b3d]['length']>0x0){let _0x1957a3=_0x416865[_0x2e6b3d];try{_0x1957a3=decodeURIComponent(_0x1957a3['replace'](/\+/g,'\x20'));}catch{}_0x35bad4+='/'+_0x1957a3;}return _0x35bad4;}function Nd(_0xe7575c){const _0xd22660={};_0xe7575c['charAt'](0x0)==='?'&&(_0xe7575c=_0xe7575c['substring'](0x1));for(const _0x3f37d4 of _0xe7575c['split']('&')){if(_0x3f37d4['length']===0x0)continue;const _0x4623b0=_0x3f37d4['split']('=');_0x4623b0['length']===0x2?_0xd22660[decodeURIComponent(_0x4623b0[0x0])]=decodeURIComponent(_0x4623b0[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3f37d4+'\x27\x20in\x20query\x20\x27'+_0xe7575c+'\x27');}return _0xd22660;}const gr=function(_0x390f11,_0x23c28b){const _0x2508cf=Pd(_0x390f11),_0x563cd3=_0x2508cf['namespace'];_0x2508cf['domain']==='firebase.com'&&oe(_0x2508cf['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x563cd3||_0x563cd3==='undefined')&&_0x2508cf['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2508cf['secure']||Bl();const _0x536171=_0x2508cf['scheme']==='ws'||_0x2508cf['scheme']==='wss';return{'repoInfo':new _o(_0x2508cf['host'],_0x2508cf['secure'],_0x563cd3,_0x536171,_0x23c28b,'',_0x563cd3!==_0x2508cf['subdomain']),'path':new C(_0x2508cf['pathString'])};},Pd=function(_0x501737){let _0x49c1be='',_0x4d34a8='',_0x18edc9='',_0x190838='',_0x1d376e='',_0x7b8798=!0x0,_0x24a4ed='https',_0x5cfa13=0x1bb;if(typeof _0x501737=='string'){let _0x27fdd2=_0x501737['indexOf']('//');_0x27fdd2>=0x0&&(_0x24a4ed=_0x501737['substring'](0x0,_0x27fdd2-0x1),_0x501737=_0x501737['substring'](_0x27fdd2+0x2));let _0x202e69=_0x501737['indexOf']('/');_0x202e69===-0x1&&(_0x202e69=_0x501737['length']);let _0x2e9832=_0x501737['indexOf']('?');_0x2e9832===-0x1&&(_0x2e9832=_0x501737['length']),_0x49c1be=_0x501737['substring'](0x0,Math['min'](_0x202e69,_0x2e9832)),_0x202e69<_0x2e9832&&(_0x190838=kd(_0x501737['substring'](_0x202e69,_0x2e9832)));const _0x4456e2=Nd(_0x501737['substring'](Math['min'](_0x501737['length'],_0x2e9832)));_0x27fdd2=_0x49c1be['indexOf'](':'),_0x27fdd2>=0x0?(_0x7b8798=_0x24a4ed==='https'||_0x24a4ed==='wss',_0x5cfa13=parseInt(_0x49c1be['substring'](_0x27fdd2+0x1),0xa)):_0x27fdd2=_0x49c1be['length'];const _0x4af5f5=_0x49c1be['slice'](0x0,_0x27fdd2);if(_0x4af5f5['toLowerCase']()==='localhost')_0x4d34a8='localhost';else{if(_0x4af5f5['split']('.')['length']<=0x2)_0x4d34a8=_0x4af5f5;else{const _0x12d5c1=_0x49c1be['indexOf']('.');_0x18edc9=_0x49c1be['substring'](0x0,_0x12d5c1)['toLowerCase'](),_0x4d34a8=_0x49c1be['substring'](_0x12d5c1+0x1),_0x1d376e=_0x18edc9;}}'ns'in _0x4456e2&&(_0x1d376e=_0x4456e2['ns']);}return{'host':_0x49c1be,'port':_0x5cfa13,'domain':_0x4d34a8,'subdomain':_0x18edc9,'secure':_0x7b8798,'scheme':_0x24a4ed,'pathString':_0x190838,'namespace':_0x1d376e};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x471662=0x0;const _0x58e61b=[];return function(_0x3e37b1){const _0x305711=_0x3e37b1===_0x471662;_0x471662=_0x3e37b1;let _0x29df16;const _0x4da7e3=new Array(0x8);for(_0x29df16=0x7;_0x29df16>=0x0;_0x29df16--)_0x4da7e3[_0x29df16]=mr['charAt'](_0x3e37b1%0x40),_0x3e37b1=Math['floor'](_0x3e37b1/0x40);f(_0x3e37b1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x30c892=_0x4da7e3['join']('');if(_0x305711){for(_0x29df16=0xb;_0x29df16>=0x0&&_0x58e61b[_0x29df16]===0x3f;_0x29df16--)_0x58e61b[_0x29df16]=0x0;_0x58e61b[_0x29df16]++;}else{for(_0x29df16=0x0;_0x29df16<0xc;_0x29df16++)_0x58e61b[_0x29df16]=Math['floor'](Math['random']()*0x40);}for(_0x29df16=0x0;_0x29df16<0xc;_0x29df16++)_0x30c892+=mr['charAt'](_0x58e61b[_0x29df16]);return f(_0x30c892['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x30c892;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x50281e,_0x55094e,_0x249704,_0x59bb16){this['eventType']=_0x50281e,this['eventRegistration']=_0x55094e,this['snapshot']=_0x249704,this['prevName']=_0x59bb16;}['getPath'](){const _0x46dfd9=this['snapshot']['ref'];return this['eventType']==='value'?_0x46dfd9['_path']:_0x46dfd9['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x5f2574,_0x267c54,_0x2d08dd){this['eventRegistration']=_0x5f2574,this['error']=_0x267c54,this['path']=_0x2d08dd;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x2d185b,_0x3bab4b){this['snapshotCallback']=_0x2d185b,this['cancelCallback']=_0x3bab4b;}['onValue'](_0x71ccfd,_0x2e3e28){this['snapshotCallback']['call'](null,_0x71ccfd,_0x2e3e28);}['onCancel'](_0x1bd762){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1bd762);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x319db9){return this['snapshotCallback']===_0x319db9['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x319db9['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x319db9['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xfa0070,_0x513b70,_0x1d93ea,_0x240b1c){this['_repo']=_0xfa0070,this['_path']=_0x513b70,this['_queryParams']=_0x1d93ea,this['_orderByCalled']=_0x240b1c;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x592a75=nr(this['_queryParams']),_0xca2cf5=Bi(_0x592a75);return _0xca2cf5==='{}'?'default':_0xca2cf5;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x5dab38){if(_0x5dab38=k(_0x5dab38),!(_0x5dab38 instanceof be))return!0x1;const _0xaf3823=this['_repo']===_0x5dab38['_repo'],_0x2b4cb3=qi(this['_path'],_0x5dab38['_path']),_0x2a84b3=this['_queryIdentifier']===_0x5dab38['_queryIdentifier'];return _0xaf3823&&_0x2b4cb3&&_0x2a84b3;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x133d50,_0x5f0e83){if(_0x133d50['_orderByCalled']===!0x0)throw new Error(_0x5f0e83+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x335577){let _0x5e80d8=null,_0x54ef41=null;if(_0x335577['hasStart']()&&(_0x5e80d8=_0x335577['getIndexStartValue']()),_0x335577['hasEnd']()&&(_0x54ef41=_0x335577['getIndexEndValue']()),_0x335577['getIndex']()===ye){const _0x34e02c='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x16dca8='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x335577['hasStart']()){if(_0x335577['getIndexStartName']()!==xe)throw new Error(_0x34e02c);if(typeof _0x5e80d8!='string')throw new Error(_0x16dca8);}if(_0x335577['hasEnd']()){if(_0x335577['getIndexEndName']()!==Ie)throw new Error(_0x34e02c);if(typeof _0x54ef41!='string')throw new Error(_0x16dca8);}}else{if(_0x335577['getIndex']()===R){if(_0x5e80d8!=null&&!Cn(_0x5e80d8)||_0x54ef41!=null&&!Cn(_0x54ef41))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x335577['getIndex']()instanceof Ki||_0x335577['getIndex']()===Po,'unknown\x20index\x20type.'),_0x5e80d8!=null&&typeof _0x5e80d8=='object'||_0x54ef41!=null&&typeof _0x54ef41=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x43b05){if(_0x43b05['hasStart']()&&_0x43b05['hasEnd']()&&_0x43b05['hasLimit']()&&!_0x43b05['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2bb4c7,_0x5241e2){super(_0x2bb4c7,_0x5241e2,new Qi(),!0x1);}get['parent'](){const _0x121aa9=To(this['_path']);return _0x121aa9===null?null:new Z(this['_repo'],_0x121aa9);}get['root'](){let _0x1fa631=this;for(;_0x1fa631['parent']!==null;)_0x1fa631=_0x1fa631['parent'];return _0x1fa631;}}class rt{constructor(_0x100c25,_0x2a5a5c,_0x5ca93c){this['_node']=_0x100c25,this['ref']=_0x2a5a5c,this['_index']=_0x5ca93c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x45dda6){const _0x883f82=new C(_0x45dda6),_0x3bca73=Lt(this['ref'],_0x45dda6);return new rt(this['_node']['getChild'](_0x883f82),_0x3bca73,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1f3719){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x68f614,_0x24be68)=>_0x1f3719(new rt(_0x24be68,Lt(this['ref'],_0x68f614),R)));}['hasChild'](_0x21cf7f){const _0x59fd39=new C(_0x21cf7f);return!this['_node']['getChild'](_0x59fd39)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x4bd153,_0x3c0bc4){return _0x4bd153=k(_0x4bd153),_0x4bd153['_checkNotDeleted']('ref'),_0x3c0bc4!==void 0x0?Lt(_0x4bd153['_root'],_0x3c0bc4):_0x4bd153['_root'];}function Lt(_0x38897d,_0xb4a07b){return _0x38897d=k(_0x38897d),y(_0x38897d['_path'])===null?ud('child','path',_0xb4a07b):_s('child','path',_0xb4a07b),new Z(_0x38897d['_repo'],A(_0x38897d['_path'],_0xb4a07b));}function d_(_0x4e67b9,_0x32a715){_0x4e67b9=k(_0x4e67b9),gs('push',_0x4e67b9['_path']),qt('push',_0x32a715,_0x4e67b9['_path'],!0x0);const _0x497e4e=oa(_0x4e67b9['_repo']),_0xfeb60a=Od(_0x497e4e),_0xeb7892=Lt(_0x4e67b9,_0xfeb60a),_0x2c257e=Lt(_0x4e67b9,_0xfeb60a);let _0x322bda;return _0x32a715!=null?_0x322bda=Ld(_0x2c257e,_0x32a715)['then'](()=>_0x2c257e):_0x322bda=Promise['resolve'](_0x2c257e),_0xeb7892['then']=_0x322bda['then']['bind'](_0x322bda),_0xeb7892['catch']=_0x322bda['then']['bind'](_0x322bda,void 0x0),_0xeb7892;}function Ld(_0x222e5f,_0x38df1f){_0x222e5f=k(_0x222e5f),gs('set',_0x222e5f['_path']),qt('set',_0x38df1f,_0x222e5f['_path'],!0x1);const _0x266958=new Ve();return Ed(_0x222e5f['_repo'],_0x222e5f['_path'],_0x38df1f,null,_0x266958['wrapCallback'](()=>{})),_0x266958['promise'];}function f_(_0x15fc57,_0x203cba){hd('update',_0x203cba,_0x15fc57['_path']);const _0x5d0d65=new Ve();return Id(_0x15fc57['_repo'],_0x15fc57['_path'],_0x203cba,_0x5d0d65['wrapCallback'](()=>{})),_0x5d0d65['promise'];}function p_(_0x4b9b88){_0x4b9b88=k(_0x4b9b88);const _0x1ae04f=new ua(()=>{}),_0x389305=new qn(_0x1ae04f);return vd(_0x4b9b88['_repo'],_0x4b9b88,_0x389305)['then'](_0x37288a=>new rt(_0x37288a,new Z(_0x4b9b88['_repo'],_0x4b9b88['_path']),_0x4b9b88['_queryParams']['getIndex']()));}class qn{constructor(_0x5c847a){this['callbackContext']=_0x5c847a;}['respondsTo'](_0x465d4){return _0x465d4==='value';}['createEvent'](_0x3a3291,_0x5d06ae){const _0x578c1d=_0x5d06ae['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x3a3291['snapshotNode'],new Z(_0x5d06ae['_repo'],_0x5d06ae['_path']),_0x578c1d));}['getEventRunner'](_0x1c583c){return _0x1c583c['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1c583c['error']):()=>this['callbackContext']['onValue'](_0x1c583c['snapshot'],null);}['createCancelEvent'](_0x1f977b,_0x54f2e5){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x1f977b,_0x54f2e5):null;}['matches'](_0x1a7a4c){return _0x1a7a4c instanceof qn?!_0x1a7a4c['callbackContext']||!this['callbackContext']?!0x0:_0x1a7a4c['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x57899d,_0x1e82c8,_0x50b429,_0x19a605,_0x16d9c8){const _0x583104=new ua(_0x50b429,void 0x0),_0x1b57bf=new qn(_0x583104);return Cd(_0x57899d['_repo'],_0x57899d,_0x1b57bf),()=>Td(_0x57899d['_repo'],_0x57899d,_0x1b57bf);}function Fd(_0x1e4340,_0x49dd52,_0xd13179,_0xa4036f){return xd(_0x1e4340,'value',_0x49dd52);}class dt{}class pa extends dt{constructor(_0x5b5e2f,_0xefb1c6){super(),this['_value']=_0x5b5e2f,this['_key']=_0xefb1c6,this['type']='endAt';}['_apply'](_0x4a103a){qt('endAt',this['_value'],_0x4a103a['_path'],!0x0);const _0x307dad=Kh(_0x4a103a['_queryParams'],this['_value'],this['_key']);if(fa(_0x307dad),Gn(_0x307dad),_0x4a103a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4a103a['_repo'],_0x4a103a['_path'],_0x307dad,_0x4a103a['_orderByCalled']);}}function __(_0x351596,_0x3be5d8){return new pa(_0x351596,_0x3be5d8);}class _a extends dt{constructor(_0x540c6b,_0x430f8f){super(),this['_value']=_0x540c6b,this['_key']=_0x430f8f,this['type']='startAt';}['_apply'](_0x3799df){qt('startAt',this['_value'],_0x3799df['_path'],!0x0);const _0x2fc100=jh(_0x3799df['_queryParams'],this['_value'],this['_key']);if(fa(_0x2fc100),Gn(_0x2fc100),_0x3799df['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x3799df['_repo'],_0x3799df['_path'],_0x2fc100,_0x3799df['_orderByCalled']);}}function g_(_0x577deb=null,_0x1b3c9b){return new _a(_0x577deb,_0x1b3c9b);}class Ud extends dt{constructor(_0x2240c4){super(),this['_limit']=_0x2240c4,this['type']='limitToFirst';}['_apply'](_0x216cb4){if(_0x216cb4['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x216cb4['_repo'],_0x216cb4['_path'],zh(_0x216cb4['_queryParams'],this['_limit']),_0x216cb4['_orderByCalled']);}}function m_(_0x29168a){if(Math['floor'](_0x29168a)!==_0x29168a||_0x29168a<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x29168a);}class Wd extends dt{constructor(_0x2ad28e){super(),this['_path']=_0x2ad28e,this['type']='orderByChild';}['_apply'](_0x52c644){da(_0x52c644,'orderByChild');const _0x23d651=new C(this['_path']);if(v(_0x23d651))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x417159=new Ki(_0x23d651),_0x2bf34c=Do(_0x52c644['_queryParams'],_0x417159);return Gn(_0x2bf34c),new be(_0x52c644['_repo'],_0x52c644['_path'],_0x2bf34c,!0x0);}}function y_(_0x54e000){if(_0x54e000==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x54e000==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x54e000==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x54e000),new Wd(_0x54e000);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x296876){da(_0x296876,'orderByKey');const _0x5a2214=Do(_0x296876['_queryParams'],ye);return Gn(_0x5a2214),new be(_0x296876['_repo'],_0x296876['_path'],_0x5a2214,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x3ffc4e,_0x1c6ba6){super(),this['_value']=_0x3ffc4e,this['_key']=_0x1c6ba6,this['type']='equalTo';}['_apply'](_0x31ccb5){if(qt('equalTo',this['_value'],_0x31ccb5['_path'],!0x1),_0x31ccb5['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x31ccb5['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x31ccb5));}}function E_(_0x26b766,_0x4f7284){return new Vd(_0x26b766,_0x4f7284);}function I_(_0x2fd75d,..._0x292179){let _0x584b86=k(_0x2fd75d);for(const _0x42a770 of _0x292179)_0x584b86=_0x42a770['_apply'](_0x584b86);return _0x584b86;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x1e46ec,_0x19ff63,_0x563010,_0x29ec78){const _0x26e408=_0x19ff63['lastIndexOf'](':'),_0x212314=_0x19ff63['substring'](0x0,_0x26e408),_0x4e809a=Wt(_0x212314);_0x1e46ec['repoInfo_']=new _o(_0x19ff63,_0x4e809a,_0x1e46ec['repoInfo_']['namespace'],_0x1e46ec['repoInfo_']['webSocketOnly'],_0x1e46ec['repoInfo_']['nodeAdmin'],_0x1e46ec['repoInfo_']['persistenceKey'],_0x1e46ec['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x563010),_0x29ec78&&(_0x1e46ec['authTokenProvider_']=_0x29ec78);}function qd(_0x1fb933,_0x4077b1,_0x102765,_0xc4edad,_0x5af7c4){let _0x16b7fc=_0xc4edad||_0x1fb933['options']['databaseURL'];_0x16b7fc===void 0x0&&(_0x1fb933['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1fb933['options']['projectId']),_0x16b7fc=_0x1fb933['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x56d28d=gr(_0x16b7fc,_0x5af7c4),_0x2afc71=_0x56d28d['repoInfo'],_0x217477;typeof process<'u'&&Us&&(_0x217477=Us[Hd]),_0x217477?(_0x16b7fc='http://'+_0x217477+'?ns='+_0x2afc71['namespace'],_0x56d28d=gr(_0x16b7fc,_0x5af7c4),_0x2afc71=_0x56d28d['repoInfo']):_0x56d28d['repoInfo']['secure'];const _0x23ad7f=new Jl(_0x1fb933['name'],_0x1fb933['options'],_0x4077b1);dd('Invalid\x20Firebase\x20Database\x20URL',_0x56d28d),v(_0x56d28d['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x21e80a=jd(_0x2afc71,_0x1fb933,_0x23ad7f,new Ql(_0x1fb933,_0x102765));return new Kd(_0x21e80a,_0x1fb933);}function zd(_0x31754a,_0x47d973){const _0x38a661=ki[_0x47d973];(!_0x38a661||_0x38a661[_0x31754a['key']]!==_0x31754a)&&oe('Database\x20'+_0x47d973+'('+_0x31754a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x31754a),delete _0x38a661[_0x31754a['key']];}function jd(_0x2f8b26,_0x5f2eab,_0x21e6b6,_0x8eb17f){let _0x237d84=ki[_0x5f2eab['name']];_0x237d84||(_0x237d84={},ki[_0x5f2eab['name']]=_0x237d84);let _0xc345d3=_0x237d84[_0x2f8b26['toURLString']()];return _0xc345d3&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0xc345d3=new gd(_0x2f8b26,$d,_0x21e6b6,_0x8eb17f),_0x237d84[_0x2f8b26['toURLString']()]=_0xc345d3,_0xc345d3;}class Kd{constructor(_0x503b9a,_0x27c50e){this['_repoInternal']=_0x503b9a,this['app']=_0x27c50e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x7e2be9){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x7e2be9+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1aea19=Qr(),_0x774c35){const _0xce24ae=Ui(_0x1aea19,'database')['getImmediate']({'identifier':_0x774c35});if(!_0xce24ae['_instanceStarted']){const _0x111215=ac('database');_0x111215&&Yd(_0xce24ae,..._0x111215);}return _0xce24ae;}function Yd(_0x114dc3,_0x3c77e9,_0x39c1c8,_0x1fd8aa={}){_0x114dc3=k(_0x114dc3),_0x114dc3['_checkNotDeleted']('useEmulator');const _0x585352=_0x3c77e9+':'+_0x39c1c8,_0x263c30=_0x114dc3['_repoInternal'];if(_0x114dc3['_instanceStarted']){if(_0x585352===_0x114dc3['_repoInternal']['repoInfo_']['host']&&De(_0x1fd8aa,_0x263c30['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1af402;if(_0x263c30['repoInfo_']['nodeAdmin'])_0x1fd8aa['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1af402=new tn(tn['OWNER']);else{if(_0x1fd8aa['mockUserToken']){const _0x56f28c=typeof _0x1fd8aa['mockUserToken']=='string'?_0x1fd8aa['mockUserToken']:cc(_0x1fd8aa['mockUserToken'],_0x114dc3['app']['options']['projectId']);_0x1af402=new tn(_0x56f28c);}}Wt(_0x3c77e9)&&jr(_0x3c77e9),Gd(_0x263c30,_0x585352,_0x1fd8aa,_0x1af402);}function C_(_0x8f31d8){_0x8f31d8=k(_0x8f31d8),_0x8f31d8['_checkNotDeleted']('goOffline'),aa(_0x8f31d8['_repo']);}function T_(_0x46d1b0){_0x46d1b0=k(_0x46d1b0),_0x46d1b0['_checkNotDeleted']('goOnline'),Sd(_0x46d1b0['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4e9276){Ll(ct),et(new Me('database',(_0x4fe61a,{instanceIdentifier:_0xd1e8b5})=>{const _0x138a76=_0x4fe61a['getProvider']('app')['getImmediate'](),_0x4833da=_0x4fe61a['getProvider']('auth-internal'),_0x8dbd37=_0x4fe61a['getProvider']('app-check-internal');return qd(_0x138a76,_0x4833da,_0x8dbd37,_0xd1e8b5);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4e9276),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x4d62d5,_0x34195b){this['committed']=_0x4d62d5,this['snapshot']=_0x34195b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3db0a7,_0x2468c6,_0x265da){if(_0x3db0a7=k(_0x3db0a7),gs('Reference.transaction',_0x3db0a7['_path']),_0x3db0a7['key']==='.length'||_0x3db0a7['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3db0a7['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1d1c8b=!0x0,_0x20a483=new Ve(),_0x4f2544=(_0x3f8c5d,_0x4dd1fd,_0x3a5016)=>{let _0xf93f57=null;_0x3f8c5d?_0x20a483['reject'](_0x3f8c5d):(_0xf93f57=new rt(_0x3a5016,new Z(_0x3db0a7['_repo'],_0x3db0a7['_path']),R),_0x20a483['resolve'](new Xd(_0x4dd1fd,_0xf93f57)));},_0x4cf8ef=Fd(_0x3db0a7,()=>{});return bd(_0x3db0a7['_repo'],_0x3db0a7['_path'],_0x2468c6,_0x4f2544,_0x4cf8ef,_0x1d1c8b),_0x20a483['promise'];}ie['prototype']['simpleListen']=function(_0x203103,_0x3571dc){this['sendRequest']('q',{'p':_0x203103},_0x3571dc);},ie['prototype']['echo']=function(_0x56747f,_0x5328d3){this['sendRequest']('echo',{'d':_0x56747f},_0x5328d3);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x5f6a05,..._0xed0cce){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x5f6a05,..._0xed0cce);}function nn(_0x2b96cd,..._0x39028a){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2b96cd,..._0x39028a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x4192fb,..._0x37586c){throw Es(_0x4192fb,..._0x37586c);}function J(_0x20a3f4,..._0x28eabc){return Es(_0x20a3f4,..._0x28eabc);}function ya(_0x5a410f,_0x5d08e4,_0x121649){const _0xab4473={...Zd(),[_0x5d08e4]:_0x121649};return new Ut('auth','Firebase',_0xab4473)['create'](_0x5d08e4,{'appName':_0x5a410f['name']});}function se(_0x37fe1e){return ya(_0x37fe1e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x3f88a0,..._0x32a2c9){if(typeof _0x3f88a0!='string'){const _0xa6b358=_0x32a2c9[0x0],_0x36a834=[..._0x32a2c9['slice'](0x1)];return _0x36a834[0x0]&&(_0x36a834[0x0]['appName']=_0x3f88a0['name']),_0x3f88a0['_errorFactory']['create'](_0xa6b358,..._0x36a834);}return ma['create'](_0x3f88a0,..._0x32a2c9);}function m(_0x27afaf,_0x5eefd0,..._0x298534){if(!_0x27afaf)throw Es(_0x5eefd0,..._0x298534);}function te(_0x3a1c65){const _0x5807dc='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3a1c65;throw nn(_0x5807dc),new Error(_0x5807dc);}function ae(_0x8881f6,_0x556c32){_0x8881f6||te(_0x556c32);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x426c50;return typeof self<'u'&&((_0x426c50=self['location'])==null?void 0x0:_0x426c50['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5a1ae8;return typeof self<'u'&&((_0x5a1ae8=self['location'])==null?void 0x0:_0x5a1ae8['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x3a2740=navigator;return _0x3a2740['languages']&&_0x3a2740['languages'][0x0]||_0x3a2740['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x12403d,_0x32f40c){this['shortDelay']=_0x12403d,this['longDelay']=_0x32f40c,ae(_0x32f40c>_0x12403d,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x376986,_0x119814){ae(_0x376986['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3030c4}=_0x376986['emulator'];return _0x119814?''+_0x3030c4+(_0x119814['startsWith']('/')?_0x119814['slice'](0x1):_0x119814):_0x3030c4;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1390ef,_0x23fb49,_0x246ccd){this['fetchImpl']=_0x1390ef,_0x23fb49&&(this['headersImpl']=_0x23fb49),_0x246ccd&&(this['responseImpl']=_0x246ccd);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x8d2e70,_0xf57124){return _0x8d2e70['tenantId']&&!_0xf57124['tenantId']?{..._0xf57124,'tenantId':_0x8d2e70['tenantId']}:_0xf57124;}async function Ae(_0x1c371e,_0x5f0a12,_0x15c0e1,_0x24399d,_0x5eafc2={}){return Ea(_0x1c371e,_0x5eafc2,async()=>{let _0x20f173={},_0x2be42d={};_0x24399d&&(_0x5f0a12==='GET'?_0x2be42d=_0x24399d:_0x20f173={'body':JSON['stringify'](_0x24399d)});const _0x1e20b8=at({..._0x2be42d,'key':_0x1c371e['config']['apiKey']})['slice'](0x1),_0x431d65=await _0x1c371e['_getAdditionalHeaders']();_0x431d65['Content-Type']='application/json',_0x1c371e['languageCode']&&(_0x431d65['X-Firebase-Locale']=_0x1c371e['languageCode']);const _0x3ef797={'method':_0x5f0a12,'headers':_0x431d65,..._0x20f173};return lc()||(_0x3ef797['referrerPolicy']='strict-origin-when-cross-origin'),_0x1c371e['emulatorConfig']&&Wt(_0x1c371e['emulatorConfig']['host'])&&(_0x3ef797['credentials']='include'),va['fetch']()(await Ia(_0x1c371e,_0x1c371e['config']['apiHost'],_0x15c0e1,_0x1e20b8),_0x3ef797);});}async function Ea(_0x187020,_0x4542dc,_0x502a7d){_0x187020['_canInitEmulator']=!0x1;const _0x28124f={...rf,..._0x4542dc};try{const _0x379405=new lf(_0x187020),_0x5c9b59=await Promise['race']([_0x502a7d(),_0x379405['promise']]);_0x379405['clearNetworkTimeout']();const _0x2b672e=await _0x5c9b59['json']();if('needConfirmation'in _0x2b672e)throw en(_0x187020,'account-exists-with-different-credential',_0x2b672e);if(_0x5c9b59['ok']&&!('errorMessage'in _0x2b672e))return _0x2b672e;{const _0x3e2acf=_0x5c9b59['ok']?_0x2b672e['errorMessage']:_0x2b672e['error']['message'],[_0x30c39a,_0x33a8f7]=_0x3e2acf['split']('\x20:\x20');if(_0x30c39a==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x187020,'credential-already-in-use',_0x2b672e);if(_0x30c39a==='EMAIL_EXISTS')throw en(_0x187020,'email-already-in-use',_0x2b672e);if(_0x30c39a==='USER_DISABLED')throw en(_0x187020,'user-disabled',_0x2b672e);const _0x26e7bd=_0x28124f[_0x30c39a]||_0x30c39a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x33a8f7)throw ya(_0x187020,_0x26e7bd,_0x33a8f7);K(_0x187020,_0x26e7bd);}}catch(_0x54401d){if(_0x54401d instanceof Se)throw _0x54401d;K(_0x187020,'network-request-failed',{'message':String(_0x54401d)});}}async function Yt(_0x402ac7,_0x3c2c36,_0x3c852a,_0x7dd652,_0x33f27f={}){const _0x48d5a9=await Ae(_0x402ac7,_0x3c2c36,_0x3c852a,_0x7dd652,_0x33f27f);return'mfaPendingCredential'in _0x48d5a9&&K(_0x402ac7,'multi-factor-auth-required',{'_serverResponse':_0x48d5a9}),_0x48d5a9;}async function Ia(_0x205500,_0x2861a7,_0x3b83aa,_0x98ebb8){const _0x197358=''+_0x2861a7+_0x3b83aa+'?'+_0x98ebb8,_0x164fc9=_0x205500,_0x334d57=_0x164fc9['config']['emulator']?Is(_0x205500['config'],_0x197358):_0x205500['config']['apiScheme']+'://'+_0x197358;return of['includes'](_0x3b83aa)&&(await _0x164fc9['_persistenceManagerAvailable'],_0x164fc9['_getPersistenceType']()==='COOKIE')?_0x164fc9['_getPersistence']()['_getFinalTarget'](_0x334d57)['toString']():_0x334d57;}function cf(_0x316600){switch(_0x316600){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2ddfa9){this['auth']=_0x2ddfa9,this['timer']=null,this['promise']=new Promise((_0x1ecb94,_0x280ae9)=>{this['timer']=setTimeout(()=>_0x280ae9(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x3adc81,_0x4eb49c,_0x5eb43e){const _0x365e5a={'appName':_0x3adc81['name']};_0x5eb43e['email']&&(_0x365e5a['email']=_0x5eb43e['email']),_0x5eb43e['phoneNumber']&&(_0x365e5a['phoneNumber']=_0x5eb43e['phoneNumber']);const _0x507ecd=J(_0x3adc81,_0x4eb49c,_0x365e5a);return _0x507ecd['customData']['_tokenResponse']=_0x5eb43e,_0x507ecd;}function vr(_0x41d7c6){return _0x41d7c6!==void 0x0&&_0x41d7c6['enterprise']!==void 0x0;}class hf{constructor(_0x49c7dc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x49c7dc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x49c7dc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x49c7dc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2466b9){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2dfb29 of this['recaptchaEnforcementState'])if(_0x2dfb29['provider']&&_0x2dfb29['provider']===_0x2466b9)return cf(_0x2dfb29['enforcementState']);return null;}['isProviderEnabled'](_0x278b13){return this['getProviderEnforcementState'](_0x278b13)==='ENFORCE'||this['getProviderEnforcementState'](_0x278b13)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x2acab0,_0xc9ab30){return Ae(_0x2acab0,'GET','/v2/recaptchaConfig',Re(_0x2acab0,_0xc9ab30));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x5d5c96,_0x234815){return Ae(_0x5d5c96,'POST','/v1/accounts:delete',_0x234815);}async function Sn(_0x51c0d4,_0x96d501){return Ae(_0x51c0d4,'POST','/v1/accounts:lookup',_0x96d501);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x3ccf86){if(_0x3ccf86)try{const _0xdbfe90=new Date(Number(_0x3ccf86));if(!isNaN(_0xdbfe90['getTime']()))return _0xdbfe90['toUTCString']();}catch{}}async function ff(_0xd0013e,_0x209387=!0x1){const _0x4909ba=k(_0xd0013e),_0x45b5e3=await _0x4909ba['getIdToken'](_0x209387),_0x32607e=ws(_0x45b5e3);m(_0x32607e&&_0x32607e['exp']&&_0x32607e['auth_time']&&_0x32607e['iat'],_0x4909ba['auth'],'internal-error');const _0x3012a2=typeof _0x32607e['firebase']=='object'?_0x32607e['firebase']:void 0x0,_0x3061f1=_0x3012a2==null?void 0x0:_0x3012a2['sign_in_provider'];return{'claims':_0x32607e,'token':_0x45b5e3,'authTime':St(ci(_0x32607e['auth_time'])),'issuedAtTime':St(ci(_0x32607e['iat'])),'expirationTime':St(ci(_0x32607e['exp'])),'signInProvider':_0x3061f1||null,'signInSecondFactor':(_0x3012a2==null?void 0x0:_0x3012a2['sign_in_second_factor'])||null};}function ci(_0x59edf7){return Number(_0x59edf7)*0x3e8;}function ws(_0x181f1f){const [_0x3c411d,_0x44c176,_0x4d1a44]=_0x181f1f['split']('.');if(_0x3c411d===void 0x0||_0x44c176===void 0x0||_0x4d1a44===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x8fdf2=cn(_0x44c176);return _0x8fdf2?JSON['parse'](_0x8fdf2):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x1015bd){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x1015bd==null?void 0x0:_0x1015bd['toString']()),null;}}function Er(_0x1e0610){const _0x3554c0=ws(_0x1e0610);return m(_0x3554c0,'internal-error'),m(typeof _0x3554c0['exp']<'u','internal-error'),m(typeof _0x3554c0['iat']<'u','internal-error'),Number(_0x3554c0['exp'])-Number(_0x3554c0['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4820d7,_0x444643,_0x220846=!0x1){if(_0x220846)return _0x444643;try{return await _0x444643;}catch(_0x5625fd){throw _0x5625fd instanceof Se&&pf(_0x5625fd)&&_0x4820d7['auth']['currentUser']===_0x4820d7&&await _0x4820d7['auth']['signOut'](),_0x5625fd;}}function pf({code:_0x4d71af}){return _0x4d71af==='auth/user-disabled'||_0x4d71af==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x1f6907){this['user']=_0x1f6907,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x3f0f39){if(_0x3f0f39){const _0x238713=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x238713;}else{this['errorBackoff']=0x7530;const _0x149a57=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x149a57);}}['schedule'](_0x3fd23d=!0x1){if(!this['isRunning'])return;const _0x505b16=this['getInterval'](_0x3fd23d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x505b16);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4e1038){(_0x4e1038==null?void 0x0:_0x4e1038['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4ebe95,_0x299512){this['createdAt']=_0x4ebe95,this['lastLoginAt']=_0x299512,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4ccc64){this['createdAt']=_0x4ccc64['createdAt'],this['lastLoginAt']=_0x4ccc64['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5debed){var _0x3adb59;const _0x9e42d4=_0x5debed['auth'],_0x1dabf6=await _0x5debed['getIdToken'](),_0x3d9e84=await xt(_0x5debed,Sn(_0x9e42d4,{'idToken':_0x1dabf6}));m(_0x3d9e84==null?void 0x0:_0x3d9e84['users']['length'],_0x9e42d4,'internal-error');const _0x9efc1d=_0x3d9e84['users'][0x0];_0x5debed['_notifyReloadListener'](_0x9efc1d);const _0x29bc72=(_0x3adb59=_0x9efc1d['providerUserInfo'])!=null&&_0x3adb59['length']?wa(_0x9efc1d['providerUserInfo']):[],_0x22647b=mf(_0x5debed['providerData'],_0x29bc72),_0x417c7d=_0x5debed['isAnonymous'],_0x3ab33d=!(_0x5debed['email']&&_0x9efc1d['passwordHash'])&&!(_0x22647b!=null&&_0x22647b['length']),_0x5495db=_0x417c7d?_0x3ab33d:!0x1,_0x5513ae={'uid':_0x9efc1d['localId'],'displayName':_0x9efc1d['displayName']||null,'photoURL':_0x9efc1d['photoUrl']||null,'email':_0x9efc1d['email']||null,'emailVerified':_0x9efc1d['emailVerified']||!0x1,'phoneNumber':_0x9efc1d['phoneNumber']||null,'tenantId':_0x9efc1d['tenantId']||null,'providerData':_0x22647b,'metadata':new Pi(_0x9efc1d['createdAt'],_0x9efc1d['lastLoginAt']),'isAnonymous':_0x5495db};Object['assign'](_0x5debed,_0x5513ae);}async function gf(_0x138716){const _0xe2d34e=k(_0x138716);await bn(_0xe2d34e),await _0xe2d34e['auth']['_persistUserIfCurrent'](_0xe2d34e),_0xe2d34e['auth']['_notifyListenersIfCurrent'](_0xe2d34e);}function mf(_0x4ed796,_0x20aad8){return[..._0x4ed796['filter'](_0x3d35a7=>!_0x20aad8['some'](_0x24068c=>_0x24068c['providerId']===_0x3d35a7['providerId'])),..._0x20aad8];}function wa(_0x39a2bb){return _0x39a2bb['map'](({providerId:_0x159fac,..._0xe1c913})=>({'providerId':_0x159fac,'uid':_0xe1c913['rawId']||'','displayName':_0xe1c913['displayName']||null,'email':_0xe1c913['email']||null,'phoneNumber':_0xe1c913['phoneNumber']||null,'photoURL':_0xe1c913['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x1fae80,_0x37771b){const _0x4ab3a8=await Ea(_0x1fae80,{},async()=>{const _0x56be68=at({'grant_type':'refresh_token','refresh_token':_0x37771b})['slice'](0x1),{tokenApiHost:_0x14d6a0,apiKey:_0x149c5d}=_0x1fae80['config'],_0x5ad2ca=await Ia(_0x1fae80,_0x14d6a0,'/v1/token','key='+_0x149c5d),_0x5dd351=await _0x1fae80['_getAdditionalHeaders']();_0x5dd351['Content-Type']='application/x-www-form-urlencoded';const _0x5a71b0={'method':'POST','headers':_0x5dd351,'body':_0x56be68};return _0x1fae80['emulatorConfig']&&Wt(_0x1fae80['emulatorConfig']['host'])&&(_0x5a71b0['credentials']='include'),va['fetch']()(_0x5ad2ca,_0x5a71b0);});return{'accessToken':_0x4ab3a8['access_token'],'expiresIn':_0x4ab3a8['expires_in'],'refreshToken':_0x4ab3a8['refresh_token']};}async function vf(_0x142321,_0xafa10c){return Ae(_0x142321,'POST','/v2/accounts:revokeToken',Re(_0x142321,_0xafa10c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xb4e392){m(_0xb4e392['idToken'],'internal-error'),m(typeof _0xb4e392['idToken']<'u','internal-error'),m(typeof _0xb4e392['refreshToken']<'u','internal-error');const _0x37603c='expiresIn'in _0xb4e392&&typeof _0xb4e392['expiresIn']<'u'?Number(_0xb4e392['expiresIn']):Er(_0xb4e392['idToken']);this['updateTokensAndExpiration'](_0xb4e392['idToken'],_0xb4e392['refreshToken'],_0x37603c);}['updateFromIdToken'](_0x2f740c){m(_0x2f740c['length']!==0x0,'internal-error');const _0x94f191=Er(_0x2f740c);this['updateTokensAndExpiration'](_0x2f740c,null,_0x94f191);}async['getToken'](_0x54cb04,_0x9bbb7c=!0x1){return!_0x9bbb7c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x54cb04,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x54cb04,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x186e60,_0x1e52de){const {accessToken:_0x38a45e,refreshToken:_0x1d1f39,expiresIn:_0x1446c5}=await yf(_0x186e60,_0x1e52de);this['updateTokensAndExpiration'](_0x38a45e,_0x1d1f39,Number(_0x1446c5));}['updateTokensAndExpiration'](_0x5c59ec,_0x3bc12b,_0x531ace){this['refreshToken']=_0x3bc12b||null,this['accessToken']=_0x5c59ec||null,this['expirationTime']=Date['now']()+_0x531ace*0x3e8;}static['fromJSON'](_0x222cd9,_0x29fd1c){const {refreshToken:_0x2d02a7,accessToken:_0x53219e,expirationTime:_0x432b9a}=_0x29fd1c,_0x229f48=new Je();return _0x2d02a7&&(m(typeof _0x2d02a7=='string','internal-error',{'appName':_0x222cd9}),_0x229f48['refreshToken']=_0x2d02a7),_0x53219e&&(m(typeof _0x53219e=='string','internal-error',{'appName':_0x222cd9}),_0x229f48['accessToken']=_0x53219e),_0x432b9a&&(m(typeof _0x432b9a=='number','internal-error',{'appName':_0x222cd9}),_0x229f48['expirationTime']=_0x432b9a),_0x229f48;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5b448d){this['accessToken']=_0x5b448d['accessToken'],this['refreshToken']=_0x5b448d['refreshToken'],this['expirationTime']=_0x5b448d['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x46eb43,_0x18d0a9){m(typeof _0x46eb43=='string'||typeof _0x46eb43>'u','internal-error',{'appName':_0x18d0a9});}class z{constructor({uid:_0x5190a7,auth:_0x19d4f2,stsTokenManager:_0x111c59,..._0x568deb}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5190a7,this['auth']=_0x19d4f2,this['stsTokenManager']=_0x111c59,this['accessToken']=_0x111c59['accessToken'],this['displayName']=_0x568deb['displayName']||null,this['email']=_0x568deb['email']||null,this['emailVerified']=_0x568deb['emailVerified']||!0x1,this['phoneNumber']=_0x568deb['phoneNumber']||null,this['photoURL']=_0x568deb['photoURL']||null,this['isAnonymous']=_0x568deb['isAnonymous']||!0x1,this['tenantId']=_0x568deb['tenantId']||null,this['providerData']=_0x568deb['providerData']?[..._0x568deb['providerData']]:[],this['metadata']=new Pi(_0x568deb['createdAt']||void 0x0,_0x568deb['lastLoginAt']||void 0x0);}async['getIdToken'](_0x6ac5f3){const _0x1e29c8=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x6ac5f3));return m(_0x1e29c8,this['auth'],'internal-error'),this['accessToken']!==_0x1e29c8&&(this['accessToken']=_0x1e29c8,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1e29c8;}['getIdTokenResult'](_0x466c70){return ff(this,_0x466c70);}['reload'](){return gf(this);}['_assign'](_0x50958a){this!==_0x50958a&&(m(this['uid']===_0x50958a['uid'],this['auth'],'internal-error'),this['displayName']=_0x50958a['displayName'],this['photoURL']=_0x50958a['photoURL'],this['email']=_0x50958a['email'],this['emailVerified']=_0x50958a['emailVerified'],this['phoneNumber']=_0x50958a['phoneNumber'],this['isAnonymous']=_0x50958a['isAnonymous'],this['tenantId']=_0x50958a['tenantId'],this['providerData']=_0x50958a['providerData']['map'](_0x23f0c6=>({..._0x23f0c6})),this['metadata']['_copy'](_0x50958a['metadata']),this['stsTokenManager']['_assign'](_0x50958a['stsTokenManager']));}['_clone'](_0x55862f){const _0x47d085=new z({...this,'auth':_0x55862f,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x47d085['metadata']['_copy'](this['metadata']),_0x47d085;}['_onReload'](_0x1fe095){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1fe095,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3eb731){this['reloadListener']?this['reloadListener'](_0x3eb731):this['reloadUserInfo']=_0x3eb731;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x525eda,_0x3cd39f=!0x1){let _0x58242c=!0x1;_0x525eda['idToken']&&_0x525eda['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x525eda),_0x58242c=!0x0),_0x3cd39f&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x58242c&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2b667d=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2b667d})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x42077c=>({..._0x42077c})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x410795,_0x19cae4){const _0x46f3b8=_0x19cae4['displayName']??void 0x0,_0x5ed7ed=_0x19cae4['email']??void 0x0,_0x2d8707=_0x19cae4['phoneNumber']??void 0x0,_0x2b2e82=_0x19cae4['photoURL']??void 0x0,_0x1ea153=_0x19cae4['tenantId']??void 0x0,_0x1f3882=_0x19cae4['_redirectEventId']??void 0x0,_0x42ac6e=_0x19cae4['createdAt']??void 0x0,_0x179e37=_0x19cae4['lastLoginAt']??void 0x0,{uid:_0x358acd,emailVerified:_0x4b4228,isAnonymous:_0x58ccef,providerData:_0x1584ed,stsTokenManager:_0x45cf8b}=_0x19cae4;m(_0x358acd&&_0x45cf8b,_0x410795,'internal-error');const _0x42b469=Je['fromJSON'](this['name'],_0x45cf8b);m(typeof _0x358acd=='string',_0x410795,'internal-error'),ce(_0x46f3b8,_0x410795['name']),ce(_0x5ed7ed,_0x410795['name']),m(typeof _0x4b4228=='boolean',_0x410795,'internal-error'),m(typeof _0x58ccef=='boolean',_0x410795,'internal-error'),ce(_0x2d8707,_0x410795['name']),ce(_0x2b2e82,_0x410795['name']),ce(_0x1ea153,_0x410795['name']),ce(_0x1f3882,_0x410795['name']),ce(_0x42ac6e,_0x410795['name']),ce(_0x179e37,_0x410795['name']);const _0x4f4adc=new z({'uid':_0x358acd,'auth':_0x410795,'email':_0x5ed7ed,'emailVerified':_0x4b4228,'displayName':_0x46f3b8,'isAnonymous':_0x58ccef,'photoURL':_0x2b2e82,'phoneNumber':_0x2d8707,'tenantId':_0x1ea153,'stsTokenManager':_0x42b469,'createdAt':_0x42ac6e,'lastLoginAt':_0x179e37});return _0x1584ed&&Array['isArray'](_0x1584ed)&&(_0x4f4adc['providerData']=_0x1584ed['map'](_0x26130c=>({..._0x26130c}))),_0x1f3882&&(_0x4f4adc['_redirectEventId']=_0x1f3882),_0x4f4adc;}static async['_fromIdTokenResponse'](_0x5df017,_0x86132f,_0x23596a=!0x1){const _0x1e07c0=new Je();_0x1e07c0['updateFromServerResponse'](_0x86132f);const _0x53f18f=new z({'uid':_0x86132f['localId'],'auth':_0x5df017,'stsTokenManager':_0x1e07c0,'isAnonymous':_0x23596a});return await bn(_0x53f18f),_0x53f18f;}static async['_fromGetAccountInfoResponse'](_0x18116e,_0x268a28,_0x57a97a){const _0x437546=_0x268a28['users'][0x0];m(_0x437546['localId']!==void 0x0,'internal-error');const _0x2988e9=_0x437546['providerUserInfo']!==void 0x0?wa(_0x437546['providerUserInfo']):[],_0xeadfee=!(_0x437546['email']&&_0x437546['passwordHash'])&&!(_0x2988e9!=null&&_0x2988e9['length']),_0x24133c=new Je();_0x24133c['updateFromIdToken'](_0x57a97a);const _0x3f1a49=new z({'uid':_0x437546['localId'],'auth':_0x18116e,'stsTokenManager':_0x24133c,'isAnonymous':_0xeadfee}),_0x144110={'uid':_0x437546['localId'],'displayName':_0x437546['displayName']||null,'photoURL':_0x437546['photoUrl']||null,'email':_0x437546['email']||null,'emailVerified':_0x437546['emailVerified']||!0x1,'phoneNumber':_0x437546['phoneNumber']||null,'tenantId':_0x437546['tenantId']||null,'providerData':_0x2988e9,'metadata':new Pi(_0x437546['createdAt'],_0x437546['lastLoginAt']),'isAnonymous':!(_0x437546['email']&&_0x437546['passwordHash'])&&!(_0x2988e9!=null&&_0x2988e9['length'])};return Object['assign'](_0x3f1a49,_0x144110),_0x3f1a49;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0xd5c6f5){ae(_0xd5c6f5 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1bcf54=Ir['get'](_0xd5c6f5);return _0x1bcf54?(ae(_0x1bcf54 instanceof _0xd5c6f5,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1bcf54):(_0x1bcf54=new _0xd5c6f5(),Ir['set'](_0xd5c6f5,_0x1bcf54),_0x1bcf54);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1b78bc,_0x12fa52){this['storage'][_0x1b78bc]=_0x12fa52;}async['_get'](_0x1af4d3){const _0x187ed6=this['storage'][_0x1af4d3];return _0x187ed6===void 0x0?null:_0x187ed6;}async['_remove'](_0x3eaf5f){delete this['storage'][_0x3eaf5f];}['_addListener'](_0x2d0312,_0x5384f3){}['_removeListener'](_0x4f5f93,_0x43a982){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3faabe,_0x1596e8,_0x47b61e){return'firebase:'+_0x3faabe+':'+_0x1596e8+':'+_0x47b61e;}class Xe{constructor(_0x54db4c,_0x418b37,_0x57243a){this['persistence']=_0x54db4c,this['auth']=_0x418b37,this['userKey']=_0x57243a;const {config:_0x1e5732,name:_0x50638f}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1e5732['apiKey'],_0x50638f),this['fullPersistenceKey']=sn('persistence',_0x1e5732['apiKey'],_0x50638f),this['boundEventHandler']=_0x418b37['_onStorageEvent']['bind'](_0x418b37),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x9b478a){return this['persistence']['_set'](this['fullUserKey'],_0x9b478a['toJSON']());}async['getCurrentUser'](){const _0x5c60cf=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5c60cf)return null;if(typeof _0x5c60cf=='string'){const _0x4efca7=await Sn(this['auth'],{'idToken':_0x5c60cf})['catch'](()=>{});return _0x4efca7?z['_fromGetAccountInfoResponse'](this['auth'],_0x4efca7,_0x5c60cf):null;}return z['_fromJSON'](this['auth'],_0x5c60cf);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2dbecb){if(this['persistence']===_0x2dbecb)return;const _0x62554f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2dbecb,_0x62554f)return this['setCurrentUser'](_0x62554f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x47e5c2,_0x528e04,_0x154042='authUser'){if(!_0x528e04['length'])return new Xe(ne(wr),_0x47e5c2,_0x154042);const _0x13851e=(await Promise['all'](_0x528e04['map'](async _0x36f495=>{if(await _0x36f495['_isAvailable']())return _0x36f495;})))['filter'](_0x5b5882=>_0x5b5882);let _0x5e1619=_0x13851e[0x0]||ne(wr);const _0x556560=sn(_0x154042,_0x47e5c2['config']['apiKey'],_0x47e5c2['name']);let _0x109684=null;for(const _0x547549 of _0x528e04)try{const _0x32e09b=await _0x547549['_get'](_0x556560);if(_0x32e09b){let _0x4b6c46;if(typeof _0x32e09b=='string'){const _0x33959b=await Sn(_0x47e5c2,{'idToken':_0x32e09b})['catch'](()=>{});if(!_0x33959b)break;_0x4b6c46=await z['_fromGetAccountInfoResponse'](_0x47e5c2,_0x33959b,_0x32e09b);}else _0x4b6c46=z['_fromJSON'](_0x47e5c2,_0x32e09b);_0x547549!==_0x5e1619&&(_0x109684=_0x4b6c46),_0x5e1619=_0x547549;break;}}catch{}const _0x1dfcdb=_0x13851e['filter'](_0x1836a2=>_0x1836a2['_shouldAllowMigration']);return!_0x5e1619['_shouldAllowMigration']||!_0x1dfcdb['length']?new Xe(_0x5e1619,_0x47e5c2,_0x154042):(_0x5e1619=_0x1dfcdb[0x0],_0x109684&&await _0x5e1619['_set'](_0x556560,_0x109684['toJSON']()),await Promise['all'](_0x528e04['map'](async _0x22fa46=>{if(_0x22fa46!==_0x5e1619)try{await _0x22fa46['_remove'](_0x556560);}catch{}})),new Xe(_0x5e1619,_0x47e5c2,_0x154042));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x8b3e84){const _0x113ed6=_0x8b3e84['toLowerCase']();if(_0x113ed6['includes']('opera/')||_0x113ed6['includes']('opr/')||_0x113ed6['includes']('opios/'))return'Opera';if(Ra(_0x113ed6))return'IEMobile';if(_0x113ed6['includes']('msie')||_0x113ed6['includes']('trident/'))return'IE';if(_0x113ed6['includes']('edge/'))return'Edge';if(Ta(_0x113ed6))return'Firefox';if(_0x113ed6['includes']('silk/'))return'Silk';if(ka(_0x113ed6))return'Blackberry';if(Na(_0x113ed6))return'Webos';if(Sa(_0x113ed6))return'Safari';if((_0x113ed6['includes']('chrome/')||ba(_0x113ed6))&&!_0x113ed6['includes']('edge/'))return'Chrome';if(Aa(_0x113ed6))return'Android';{const _0x301afc=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1c8ee8=_0x8b3e84['match'](_0x301afc);if((_0x1c8ee8==null?void 0x0:_0x1c8ee8['length'])===0x2)return _0x1c8ee8[0x1];}return'Other';}function Ta(_0x30a305=W()){return/firefox\//i['test'](_0x30a305);}function Sa(_0x5cc145=W()){const _0xca6d8c=_0x5cc145['toLowerCase']();return _0xca6d8c['includes']('safari/')&&!_0xca6d8c['includes']('chrome/')&&!_0xca6d8c['includes']('crios/')&&!_0xca6d8c['includes']('android');}function ba(_0x3c89ee=W()){return/crios\//i['test'](_0x3c89ee);}function Ra(_0x3519a9=W()){return/iemobile/i['test'](_0x3519a9);}function Aa(_0x53b066=W()){return/android/i['test'](_0x53b066);}function ka(_0x2e23eb=W()){return/blackberry/i['test'](_0x2e23eb);}function Na(_0x124b89=W()){return/webos/i['test'](_0x124b89);}function Cs(_0x16444c=W()){return/iphone|ipad|ipod/i['test'](_0x16444c)||/macintosh/i['test'](_0x16444c)&&/mobile/i['test'](_0x16444c);}function Ef(_0x326116=W()){var _0x3036d6;return Cs(_0x326116)&&!!((_0x3036d6=window['navigator'])!=null&&_0x3036d6['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0xb879c4=W()){return Cs(_0xb879c4)||Aa(_0xb879c4)||Na(_0xb879c4)||ka(_0xb879c4)||/windows phone/i['test'](_0xb879c4)||Ra(_0xb879c4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0xd2d6fe,_0x1f3ccc=[]){let _0x4d2c9c;switch(_0xd2d6fe){case'Browser':_0x4d2c9c=Cr(W());break;case'Worker':_0x4d2c9c=Cr(W())+'-'+_0xd2d6fe;break;default:_0x4d2c9c=_0xd2d6fe;}const _0x1c72ea=_0x1f3ccc['length']?_0x1f3ccc['join'](','):'FirebaseCore-web';return _0x4d2c9c+'/JsCore/'+ct+'/'+_0x1c72ea;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4d7ee5){this['auth']=_0x4d7ee5,this['queue']=[];}['pushCallback'](_0x49f459,_0x111801){const _0x567c74=_0x1817d5=>new Promise((_0x3f0350,_0x2107d6)=>{try{const _0x51ebf2=_0x49f459(_0x1817d5);_0x3f0350(_0x51ebf2);}catch(_0x3a8d24){_0x2107d6(_0x3a8d24);}});_0x567c74['onAbort']=_0x111801,this['queue']['push'](_0x567c74);const _0x34e0a1=this['queue']['length']-0x1;return()=>{this['queue'][_0x34e0a1]=()=>Promise['resolve']();};}async['runMiddleware'](_0x45ac1e){if(this['auth']['currentUser']===_0x45ac1e)return;const _0x2740e9=[];try{for(const _0x1fd87b of this['queue'])await _0x1fd87b(_0x45ac1e),_0x1fd87b['onAbort']&&_0x2740e9['push'](_0x1fd87b['onAbort']);}catch(_0x2dcba8){_0x2740e9['reverse']();for(const _0x492545 of _0x2740e9)try{_0x492545();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2dcba8==null?void 0x0:_0x2dcba8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4ff454,_0xd75e7b={}){return Ae(_0x4ff454,'GET','/v2/passwordPolicy',Re(_0x4ff454,_0xd75e7b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x33d470){var _0x59c4f7;const _0x47de0a=_0x33d470['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x47de0a['minPasswordLength']??Tf,_0x47de0a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x47de0a['maxPasswordLength']),_0x47de0a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x47de0a['containsLowercaseCharacter']),_0x47de0a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x47de0a['containsUppercaseCharacter']),_0x47de0a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x47de0a['containsNumericCharacter']),_0x47de0a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x47de0a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x33d470['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x59c4f7=_0x33d470['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x59c4f7['join'](''))??'',this['forceUpgradeOnSignin']=_0x33d470['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x33d470['schemaVersion'];}['validatePassword'](_0x32dd06){const _0x690480={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x32dd06,_0x690480),this['validatePasswordCharacterOptions'](_0x32dd06,_0x690480),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['meetsMinPasswordLength']??!0x0),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['meetsMaxPasswordLength']??!0x0),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['containsLowercaseLetter']??!0x0),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['containsUppercaseLetter']??!0x0),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['containsNumericCharacter']??!0x0),_0x690480['isValid']&&(_0x690480['isValid']=_0x690480['containsNonAlphanumericCharacter']??!0x0),_0x690480;}['validatePasswordLengthOptions'](_0x1c9664,_0x27dce6){const _0x4a788b=this['customStrengthOptions']['minPasswordLength'],_0x1f4e5f=this['customStrengthOptions']['maxPasswordLength'];_0x4a788b&&(_0x27dce6['meetsMinPasswordLength']=_0x1c9664['length']>=_0x4a788b),_0x1f4e5f&&(_0x27dce6['meetsMaxPasswordLength']=_0x1c9664['length']<=_0x1f4e5f);}['validatePasswordCharacterOptions'](_0x43b93e,_0x28c558){this['updatePasswordCharacterOptionsStatuses'](_0x28c558,!0x1,!0x1,!0x1,!0x1);let _0x45296d;for(let _0x4841f3=0x0;_0x4841f3<_0x43b93e['length'];_0x4841f3++)_0x45296d=_0x43b93e['charAt'](_0x4841f3),this['updatePasswordCharacterOptionsStatuses'](_0x28c558,_0x45296d>='a'&&_0x45296d<='z',_0x45296d>='A'&&_0x45296d<='Z',_0x45296d>='0'&&_0x45296d<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x45296d));}['updatePasswordCharacterOptionsStatuses'](_0x1fe269,_0x1e52d5,_0x208e1c,_0x372c2f,_0x3d0a24){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1fe269['containsLowercaseLetter']||(_0x1fe269['containsLowercaseLetter']=_0x1e52d5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1fe269['containsUppercaseLetter']||(_0x1fe269['containsUppercaseLetter']=_0x208e1c)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1fe269['containsNumericCharacter']||(_0x1fe269['containsNumericCharacter']=_0x372c2f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1fe269['containsNonAlphanumericCharacter']||(_0x1fe269['containsNonAlphanumericCharacter']=_0x3d0a24));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1889fc,_0x487761,_0x3b82a8,_0x57d2a5){this['app']=_0x1889fc,this['heartbeatServiceProvider']=_0x487761,this['appCheckServiceProvider']=_0x3b82a8,this['config']=_0x57d2a5,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1889fc['name'],this['clientVersion']=_0x57d2a5['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5c1856=>this['_resolvePersistenceManagerAvailable']=_0x5c1856);}['_initializeWithPersistence'](_0x53eb6f,_0x241670){return _0x241670&&(this['_popupRedirectResolver']=ne(_0x241670)),this['_initializationPromise']=this['queue'](async()=>{var _0x164408,_0x81db48,_0x4b340b;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x53eb6f),(_0x164408=this['_resolvePersistenceManagerAvailable'])==null||_0x164408['call'](this),!this['_deleted'])){if((_0x81db48=this['_popupRedirectResolver'])!=null&&_0x81db48['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x241670),this['lastNotifiedUid']=((_0x4b340b=this['currentUser'])==null?void 0x0:_0x4b340b['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3a5322=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3a5322)){if(this['currentUser']&&_0x3a5322&&this['currentUser']['uid']===_0x3a5322['uid']){this['_currentUser']['_assign'](_0x3a5322),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3a5322,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x30853b){try{const _0x3bcd1d=await Sn(this,{'idToken':_0x30853b}),_0x1e9436=await z['_fromGetAccountInfoResponse'](this,_0x3bcd1d,_0x30853b);await this['directlySetCurrentUser'](_0x1e9436);}catch(_0x308569){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x308569),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xd3caf0){var _0x4272f7;if(H(this['app'])){const _0x5a41c7=this['app']['settings']['authIdToken'];return _0x5a41c7?new Promise(_0x274cf8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5a41c7)['then'](_0x274cf8,_0x274cf8));}):this['directlySetCurrentUser'](null);}const _0xc27084=await this['assertedPersistence']['getCurrentUser']();let _0x398ba9=_0xc27084,_0x8011fe=!0x1;if(_0xd3caf0&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2f54ae=(_0x4272f7=this['redirectUser'])==null?void 0x0:_0x4272f7['_redirectEventId'],_0x2bc5a9=_0x398ba9==null?void 0x0:_0x398ba9['_redirectEventId'],_0x1eb67c=await this['tryRedirectSignIn'](_0xd3caf0);(!_0x2f54ae||_0x2f54ae===_0x2bc5a9)&&(_0x1eb67c!=null&&_0x1eb67c['user'])&&(_0x398ba9=_0x1eb67c['user'],_0x8011fe=!0x0);}if(!_0x398ba9)return this['directlySetCurrentUser'](null);if(!_0x398ba9['_redirectEventId']){if(_0x8011fe)try{await this['beforeStateQueue']['runMiddleware'](_0x398ba9);}catch(_0x325554){_0x398ba9=_0xc27084,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x325554));}return _0x398ba9?this['reloadAndSetCurrentUserOrClear'](_0x398ba9):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x398ba9['_redirectEventId']?this['directlySetCurrentUser'](_0x398ba9):this['reloadAndSetCurrentUserOrClear'](_0x398ba9);}async['tryRedirectSignIn'](_0x3df737){let _0x2b3aec=null;try{_0x2b3aec=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3df737,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2b3aec;}async['reloadAndSetCurrentUserOrClear'](_0x4f0e33){try{await bn(_0x4f0e33);}catch(_0x3000d6){if((_0x3000d6==null?void 0x0:_0x3000d6['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4f0e33);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3d1990){if(H(this['app']))return Promise['reject'](se(this));const _0x469f91=_0x3d1990?k(_0x3d1990):null;return _0x469f91&&m(_0x469f91['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x469f91&&_0x469f91['_clone'](this));}async['_updateCurrentUser'](_0x49b261,_0x1523ed=!0x1){if(!this['_deleted'])return _0x49b261&&m(this['tenantId']===_0x49b261['tenantId'],this,'tenant-id-mismatch'),_0x1523ed||await this['beforeStateQueue']['runMiddleware'](_0x49b261),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x49b261),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x24a266){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x24a266));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1e4520){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x40d96d=this['_getPasswordPolicyInternal']();return _0x40d96d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x40d96d['validatePassword'](_0x1e4520);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2b4f30=await Cf(this),_0x483287=new Sf(_0x2b4f30);this['tenantId']===null?this['_projectPasswordPolicy']=_0x483287:this['_tenantPasswordPolicies'][this['tenantId']]=_0x483287;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x212980){this['_errorFactory']=new Ut('auth','Firebase',_0x212980());}['onAuthStateChanged'](_0x4cf81e,_0x3dadea,_0x50f218){return this['registerStateListener'](this['authStateSubscription'],_0x4cf81e,_0x3dadea,_0x50f218);}['beforeAuthStateChanged'](_0x9499c9,_0x23eab3){return this['beforeStateQueue']['pushCallback'](_0x9499c9,_0x23eab3);}['onIdTokenChanged'](_0x118137,_0x34ef74,_0x1451df){return this['registerStateListener'](this['idTokenSubscription'],_0x118137,_0x34ef74,_0x1451df);}['authStateReady'](){return new Promise((_0x190407,_0x5a168a)=>{if(this['currentUser'])_0x190407();else{const _0x107cb4=this['onAuthStateChanged'](()=>{_0x107cb4(),_0x190407();},_0x5a168a);}});}async['revokeAccessToken'](_0x1f3a60){if(this['currentUser']){const _0x27ff83=await this['currentUser']['getIdToken'](),_0x1d785a={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1f3a60,'idToken':_0x27ff83};this['tenantId']!=null&&(_0x1d785a['tenantId']=this['tenantId']),await vf(this,_0x1d785a);}}['toJSON'](){var _0x8bbd6e;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x8bbd6e=this['_currentUser'])==null?void 0x0:_0x8bbd6e['toJSON']()};}async['_setRedirectUser'](_0xd3b19e,_0x3b89fa){const _0x3aca27=await this['getOrInitRedirectPersistenceManager'](_0x3b89fa);return _0xd3b19e===null?_0x3aca27['removeCurrentUser']():_0x3aca27['setCurrentUser'](_0xd3b19e);}async['getOrInitRedirectPersistenceManager'](_0x384f91){if(!this['redirectPersistenceManager']){const _0x35f979=_0x384f91&&ne(_0x384f91)||this['_popupRedirectResolver'];m(_0x35f979,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x35f979['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x700ede){var _0x6e0514,_0x1c32fa;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x6e0514=this['_currentUser'])==null?void 0x0:_0x6e0514['_redirectEventId'])===_0x700ede?this['_currentUser']:((_0x1c32fa=this['redirectUser'])==null?void 0x0:_0x1c32fa['_redirectEventId'])===_0x700ede?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2b3192){if(_0x2b3192===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2b3192));}['_notifyListenersIfCurrent'](_0x301766){_0x301766===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3ba022;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x49699b=((_0x3ba022=this['currentUser'])==null?void 0x0:_0x3ba022['uid'])??null;this['lastNotifiedUid']!==_0x49699b&&(this['lastNotifiedUid']=_0x49699b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x583d88,_0x30e820,_0x2da85b,_0x549a70){if(this['_deleted'])return()=>{};const _0x1879fe=typeof _0x30e820=='function'?_0x30e820:_0x30e820['next']['bind'](_0x30e820);let _0x174a4d=!0x1;const _0x13f2de=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x13f2de,this,'internal-error'),_0x13f2de['then'](()=>{_0x174a4d||_0x1879fe(this['currentUser']);}),typeof _0x30e820=='function'){const _0x3d53c5=_0x583d88['addObserver'](_0x30e820,_0x2da85b,_0x549a70);return()=>{_0x174a4d=!0x0,_0x3d53c5();};}else{const _0x1fe221=_0x583d88['addObserver'](_0x30e820);return()=>{_0x174a4d=!0x0,_0x1fe221();};}}async['directlySetCurrentUser'](_0x30fa3b){this['currentUser']&&this['currentUser']!==_0x30fa3b&&this['_currentUser']['_stopProactiveRefresh'](),_0x30fa3b&&this['isProactiveRefreshEnabled']&&_0x30fa3b['_startProactiveRefresh'](),this['currentUser']=_0x30fa3b,_0x30fa3b?await this['assertedPersistence']['setCurrentUser'](_0x30fa3b):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x32b8ee){return this['operations']=this['operations']['then'](_0x32b8ee,_0x32b8ee),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x15862c){!_0x15862c||this['frameworks']['includes'](_0x15862c)||(this['frameworks']['push'](_0x15862c),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x43b296;const _0x4578c5={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4578c5['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2cd5fd=await((_0x43b296=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x43b296['getHeartbeatsHeader']());_0x2cd5fd&&(_0x4578c5['X-Firebase-Client']=_0x2cd5fd);const _0x42f4aa=await this['_getAppCheckToken']();return _0x42f4aa&&(_0x4578c5['X-Firebase-AppCheck']=_0x42f4aa),_0x4578c5;}async['_getAppCheckToken'](){var _0x118f7d;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x17a1a7=await((_0x118f7d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x118f7d['getToken']());return _0x17a1a7!=null&&_0x17a1a7['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x17a1a7['error']),_0x17a1a7==null?void 0x0:_0x17a1a7['token'];}}function qe(_0x123b09){return k(_0x123b09);}class Tr{constructor(_0x194a78){this['auth']=_0x194a78,this['observer']=null,this['addObserver']=Ic(_0x84a774=>this['observer']=_0x84a774);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x4db9ca){zn=_0x4db9ca;}function Da(_0x4bd1cb){return zn['loadJS'](_0x4bd1cb);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x5588d2){return'__'+_0x5588d2+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x4f7aa9){_0x4f7aa9();}['execute'](_0x5af797,_0x577697){return Promise['resolve']('token');}['render'](_0x1cb216,_0x28681e){return'';}}class Of{['ready'](_0x26c111){_0x26c111();}['execute'](_0x374571,_0x596ffe){return Promise['resolve']('token');}['render'](_0x45d1e6,_0x53e120){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0xd32434){this['type']=Df,this['auth']=qe(_0xd32434);}async['verify'](_0x395e22='verify',_0x16f009=!0x1){async function _0x594a86(_0x563e6f){if(!_0x16f009){if(_0x563e6f['tenantId']==null&&_0x563e6f['_agentRecaptchaConfig']!=null)return _0x563e6f['_agentRecaptchaConfig']['siteKey'];if(_0x563e6f['tenantId']!=null&&_0x563e6f['_tenantRecaptchaConfigs'][_0x563e6f['tenantId']]!==void 0x0)return _0x563e6f['_tenantRecaptchaConfigs'][_0x563e6f['tenantId']]['siteKey'];}return new Promise(async(_0x469d8c,_0x1d4267)=>{uf(_0x563e6f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4d2458=>{if(_0x4d2458['recaptchaKey']===void 0x0)_0x1d4267(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xed3fbb=new hf(_0x4d2458);return _0x563e6f['tenantId']==null?_0x563e6f['_agentRecaptchaConfig']=_0xed3fbb:_0x563e6f['_tenantRecaptchaConfigs'][_0x563e6f['tenantId']]=_0xed3fbb,_0x469d8c(_0xed3fbb['siteKey']);}})['catch'](_0x5b9259=>{_0x1d4267(_0x5b9259);});});}function _0x1d6ae9(_0x5b5217,_0x45913f,_0x2fbb85){const _0x47b7f8=window['grecaptcha'];vr(_0x47b7f8)?_0x47b7f8['enterprise']['ready'](()=>{_0x47b7f8['enterprise']['execute'](_0x5b5217,{'action':_0x395e22})['then'](_0x4d2fbf=>{_0x45913f(_0x4d2fbf);})['catch'](()=>{_0x45913f(Ma);});}):_0x2fbb85(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4743e3,_0x1bdd23)=>{_0x594a86(this['auth'])['then'](async _0x57007b=>{if(!_0x16f009&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x1d6ae9(_0x57007b,_0x4743e3,_0x1bdd23);else{if(typeof window>'u'){_0x1bdd23(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1dbe71=Af();_0x1dbe71['length']!==0x0&&(_0x1dbe71+=_0x57007b+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x117b40;(_0x117b40=le['scriptInjectionDeferred'])==null||_0x117b40['resolve']();},Da(_0x1dbe71)['then'](()=>{var _0x26877e;return(_0x26877e=le['scriptInjectionDeferred'])==null?void 0x0:_0x26877e['promise'];})['then'](()=>{_0x1d6ae9(_0x57007b,_0x4743e3,_0x1bdd23);})['catch'](_0x39cea4=>{_0x1bdd23(_0x39cea4);});}})['catch'](_0x17886b=>{_0x1bdd23(_0x17886b);});});}}le['scriptInjectionDeferred']=null;async function br(_0x463b02,_0x314cc2,_0x5da7d6,_0x5d47dc=!0x1,_0xb170f=!0x1){const _0x33e860=new le(_0x463b02);let _0x2bceeb;if(_0xb170f)_0x2bceeb=Ma;else try{_0x2bceeb=await _0x33e860['verify'](_0x5da7d6);}catch{_0x2bceeb=await _0x33e860['verify'](_0x5da7d6,!0x0);}const _0x2455ab={..._0x314cc2};if(_0x5da7d6==='mfaSmsEnrollment'||_0x5da7d6==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2455ab){const _0x2cacf9=_0x2455ab['phoneEnrollmentInfo']['phoneNumber'],_0x97e3e3=_0x2455ab['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2455ab,{'phoneEnrollmentInfo':{'phoneNumber':_0x2cacf9,'recaptchaToken':_0x97e3e3,'captchaResponse':_0x2bceeb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2455ab){const _0x819692=_0x2455ab['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2455ab,{'phoneSignInInfo':{'recaptchaToken':_0x819692,'captchaResponse':_0x2bceeb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2455ab;}return _0x5d47dc?Object['assign'](_0x2455ab,{'captchaResp':_0x2bceeb}):Object['assign'](_0x2455ab,{'captchaResponse':_0x2bceeb}),Object['assign'](_0x2455ab,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2455ab,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2455ab;}async function Oi(_0x2dfc46,_0x547202,_0x17c13e,_0x1b3e29,_0x439ecb){var _0x30d24f;if((_0x30d24f=_0x2dfc46['_getRecaptchaConfig']())!=null&&_0x30d24f['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x19a8da=await br(_0x2dfc46,_0x547202,_0x17c13e,_0x17c13e==='getOobCode');return _0x1b3e29(_0x2dfc46,_0x19a8da);}else return _0x1b3e29(_0x2dfc46,_0x547202)['catch'](async _0x5762c7=>{if(_0x5762c7['code']==='auth/missing-recaptcha-token'){console['log'](_0x17c13e+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x36f042=await br(_0x2dfc46,_0x547202,_0x17c13e,_0x17c13e==='getOobCode');return _0x1b3e29(_0x2dfc46,_0x36f042);}else return Promise['reject'](_0x5762c7);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0xfd3cd8,_0x2a8222){const _0x3e5437=Ui(_0xfd3cd8,'auth');if(_0x3e5437['isInitialized']()){const _0x48c7ef=_0x3e5437['getImmediate'](),_0x5579c3=_0x3e5437['getOptions']();if(De(_0x5579c3,_0x2a8222??{}))return _0x48c7ef;K(_0x48c7ef,'already-initialized');}return _0x3e5437['initialize']({'options':_0x2a8222});}function Lf(_0x2430a2,_0x4a9190){const _0x44e1ff=(_0x4a9190==null?void 0x0:_0x4a9190['persistence'])||[],_0x2cdd4d=(Array['isArray'](_0x44e1ff)?_0x44e1ff:[_0x44e1ff])['map'](ne);_0x4a9190!=null&&_0x4a9190['errorMap']&&_0x2430a2['_updateErrorMap'](_0x4a9190['errorMap']),_0x2430a2['_initializeWithPersistence'](_0x2cdd4d,_0x4a9190==null?void 0x0:_0x4a9190['popupRedirectResolver']);}function xf(_0x5a91b2,_0x2fa40a,_0x465f03){const _0x2d5d81=qe(_0x5a91b2);m(/^https?:\/\//['test'](_0x2fa40a),_0x2d5d81,'invalid-emulator-scheme');const _0x3128fb=!0x1,_0x5c8be4=La(_0x2fa40a),{host:_0x398de3,port:_0x5d1632}=Ff(_0x2fa40a),_0x1b0b60=_0x5d1632===null?'':':'+_0x5d1632,_0x2c4c67={'url':_0x5c8be4+'//'+_0x398de3+_0x1b0b60+'/'},_0x4f7743=Object['freeze']({'host':_0x398de3,'port':_0x5d1632,'protocol':_0x5c8be4['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3128fb})});if(!_0x2d5d81['_canInitEmulator']){m(_0x2d5d81['config']['emulator']&&_0x2d5d81['emulatorConfig'],_0x2d5d81,'emulator-config-failed'),m(De(_0x2c4c67,_0x2d5d81['config']['emulator'])&&De(_0x4f7743,_0x2d5d81['emulatorConfig']),_0x2d5d81,'emulator-config-failed');return;}_0x2d5d81['config']['emulator']=_0x2c4c67,_0x2d5d81['emulatorConfig']=_0x4f7743,_0x2d5d81['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x398de3)?jr(_0x5c8be4+'//'+_0x398de3+_0x1b0b60):Uf();}function La(_0x208c11){const _0x5a6409=_0x208c11['indexOf'](':');return _0x5a6409<0x0?'':_0x208c11['substr'](0x0,_0x5a6409+0x1);}function Ff(_0x387dbc){const _0xb2f589=La(_0x387dbc),_0x1bf0a1=/(\/\/)?([^?#/]+)/['exec'](_0x387dbc['substr'](_0xb2f589['length']));if(!_0x1bf0a1)return{'host':'','port':null};const _0x45af0a=_0x1bf0a1[0x2]['split']('@')['pop']()||'',_0x35d7ba=/^(\[[^\]]+\])(:|$)/['exec'](_0x45af0a);if(_0x35d7ba){const _0x1d1458=_0x35d7ba[0x1];return{'host':_0x1d1458,'port':Rr(_0x45af0a['substr'](_0x1d1458['length']+0x1))};}else{const [_0x38ad19,_0x299dd2]=_0x45af0a['split'](':');return{'host':_0x38ad19,'port':Rr(_0x299dd2)};}}function Rr(_0x45cb56){if(!_0x45cb56)return null;const _0x2f9ef6=Number(_0x45cb56);return isNaN(_0x2f9ef6)?null:_0x2f9ef6;}function Uf(){function _0x274b18(){const _0x4fc88e=document['createElement']('p'),_0x4a17a6=_0x4fc88e['style'];_0x4fc88e['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4a17a6['position']='fixed',_0x4a17a6['width']='100%',_0x4a17a6['backgroundColor']='#ffffff',_0x4a17a6['border']='.1em\x20solid\x20#000000',_0x4a17a6['color']='#b50000',_0x4a17a6['bottom']='0px',_0x4a17a6['left']='0px',_0x4a17a6['margin']='0px',_0x4a17a6['zIndex']='10000',_0x4a17a6['textAlign']='center',_0x4fc88e['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4fc88e);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x274b18):_0x274b18());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x47b393,_0x377320){this['providerId']=_0x47b393,this['signInMethod']=_0x377320;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x454200){return te('not\x20implemented');}['_linkToIdToken'](_0x2a49a9,_0x16388e){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x47c0c4){return te('not\x20implemented');}}async function Wf(_0x2ac1c4,_0x2235ff){return Ae(_0x2ac1c4,'POST','/v1/accounts:signUp',_0x2235ff);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x46548e,_0x56a080){return Yt(_0x46548e,'POST','/v1/accounts:signInWithPassword',Re(_0x46548e,_0x56a080));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x1cec6a,_0x44cf2a){return Yt(_0x1cec6a,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1cec6a,_0x44cf2a));}async function Hf(_0x18ceb5,_0x2330b7){return Yt(_0x18ceb5,'POST','/v1/accounts:signInWithEmailLink',Re(_0x18ceb5,_0x2330b7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x239458,_0x2e8b52,_0x574c02,_0x438ee5=null){super('password',_0x574c02),this['_email']=_0x239458,this['_password']=_0x2e8b52,this['_tenantId']=_0x438ee5;}static['_fromEmailAndPassword'](_0xfff7b5,_0x22a013){return new Ft(_0xfff7b5,_0x22a013,'password');}static['_fromEmailAndCode'](_0x24724d,_0x4fe749,_0x2b4247=null){return new Ft(_0x24724d,_0x4fe749,'emailLink',_0x2b4247);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x32256a){const _0x5d66be=typeof _0x32256a=='string'?JSON['parse'](_0x32256a):_0x32256a;if(_0x5d66be!=null&&_0x5d66be['email']&&(_0x5d66be!=null&&_0x5d66be['password'])){if(_0x5d66be['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5d66be['email'],_0x5d66be['password']);if(_0x5d66be['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5d66be['email'],_0x5d66be['password'],_0x5d66be['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1738e4){switch(this['signInMethod']){case'password':const _0x544345={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1738e4,_0x544345,'signInWithPassword',Bf);case'emailLink':return Vf(_0x1738e4,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x1738e4,'internal-error');}}async['_linkToIdToken'](_0x47ffae,_0x9de334){switch(this['signInMethod']){case'password':const _0x54bf48={'idToken':_0x9de334,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x47ffae,_0x54bf48,'signUpPassword',Wf);case'emailLink':return Hf(_0x47ffae,{'idToken':_0x9de334,'email':this['_email'],'oobCode':this['_password']});default:K(_0x47ffae,'internal-error');}}['_getReauthenticationResolver'](_0x53e302){return this['_getIdTokenResponse'](_0x53e302);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3a7229,_0x1b7965){return Yt(_0x3a7229,'POST','/v1/accounts:signInWithIdp',Re(_0x3a7229,_0x1b7965));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x24dc8e){const _0x51c403=new We(_0x24dc8e['providerId'],_0x24dc8e['signInMethod']);return _0x24dc8e['idToken']||_0x24dc8e['accessToken']?(_0x24dc8e['idToken']&&(_0x51c403['idToken']=_0x24dc8e['idToken']),_0x24dc8e['accessToken']&&(_0x51c403['accessToken']=_0x24dc8e['accessToken']),_0x24dc8e['nonce']&&!_0x24dc8e['pendingToken']&&(_0x51c403['nonce']=_0x24dc8e['nonce']),_0x24dc8e['pendingToken']&&(_0x51c403['pendingToken']=_0x24dc8e['pendingToken'])):_0x24dc8e['oauthToken']&&_0x24dc8e['oauthTokenSecret']?(_0x51c403['accessToken']=_0x24dc8e['oauthToken'],_0x51c403['secret']=_0x24dc8e['oauthTokenSecret']):K('argument-error'),_0x51c403;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x396876){const _0xbf4496=typeof _0x396876=='string'?JSON['parse'](_0x396876):_0x396876,{providerId:_0x733c3c,signInMethod:_0x3dc49f,..._0x5a7cd2}=_0xbf4496;if(!_0x733c3c||!_0x3dc49f)return null;const _0x2ddbf2=new We(_0x733c3c,_0x3dc49f);return _0x2ddbf2['idToken']=_0x5a7cd2['idToken']||void 0x0,_0x2ddbf2['accessToken']=_0x5a7cd2['accessToken']||void 0x0,_0x2ddbf2['secret']=_0x5a7cd2['secret'],_0x2ddbf2['nonce']=_0x5a7cd2['nonce'],_0x2ddbf2['pendingToken']=_0x5a7cd2['pendingToken']||null,_0x2ddbf2;}['_getIdTokenResponse'](_0x48fe90){const _0x43503c=this['buildRequest']();return Ze(_0x48fe90,_0x43503c);}['_linkToIdToken'](_0x82186b,_0x5f1a06){const _0x1323f2=this['buildRequest']();return _0x1323f2['idToken']=_0x5f1a06,Ze(_0x82186b,_0x1323f2);}['_getReauthenticationResolver'](_0x45cfba){const _0x2243d5=this['buildRequest']();return _0x2243d5['autoCreate']=!0x1,Ze(_0x45cfba,_0x2243d5);}['buildRequest'](){const _0x44fae3={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x44fae3['pendingToken']=this['pendingToken'];else{const _0x6d6c5b={};this['idToken']&&(_0x6d6c5b['id_token']=this['idToken']),this['accessToken']&&(_0x6d6c5b['access_token']=this['accessToken']),this['secret']&&(_0x6d6c5b['oauth_token_secret']=this['secret']),_0x6d6c5b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x6d6c5b['nonce']=this['nonce']),_0x44fae3['postBody']=at(_0x6d6c5b);}return _0x44fae3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x512f0a){switch(_0x512f0a){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x1dad18){const _0x3ed6cc=yt(vt(_0x1dad18))['link'],_0x283958=_0x3ed6cc?yt(vt(_0x3ed6cc))['deep_link_id']:null,_0x874ea6=yt(vt(_0x1dad18))['deep_link_id'];return(_0x874ea6?yt(vt(_0x874ea6))['link']:null)||_0x874ea6||_0x283958||_0x3ed6cc||_0x1dad18;}class Ss{constructor(_0xdc7e69){const _0x42a565=yt(vt(_0xdc7e69)),_0x1806f3=_0x42a565['apiKey']??null,_0x1e330d=_0x42a565['oobCode']??null,_0xee39fa=Gf(_0x42a565['mode']??null);m(_0x1806f3&&_0x1e330d&&_0xee39fa,'argument-error'),this['apiKey']=_0x1806f3,this['operation']=_0xee39fa,this['code']=_0x1e330d,this['continueUrl']=_0x42a565['continueUrl']??null,this['languageCode']=_0x42a565['lang']??null,this['tenantId']=_0x42a565['tenantId']??null;}static['parseLink'](_0x4f40cd){const _0x3014bf=qf(_0x4f40cd);try{return new Ss(_0x3014bf);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4c964d,_0x394615){return Ft['_fromEmailAndPassword'](_0x4c964d,_0x394615);}static['credentialWithLink'](_0x51380f,_0x337308){const _0x88c48f=Ss['parseLink'](_0x337308);return m(_0x88c48f,'argument-error'),Ft['_fromEmailAndCode'](_0x51380f,_0x88c48f['code'],_0x88c48f['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x36b5a8){this['providerId']=_0x36b5a8,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x517eb4){this['defaultLanguageCode']=_0x517eb4;}['setCustomParameters'](_0x153174){return this['customParameters']=_0x153174,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5228cd){return this['scopes']['includes'](_0x5228cd)||this['scopes']['push'](_0x5228cd),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x10eaca){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x10eaca});}static['credentialFromResult'](_0x585ce6){return he['credentialFromTaggedObject'](_0x585ce6);}static['credentialFromError'](_0x156835){return he['credentialFromTaggedObject'](_0x156835['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x31853f}){if(!_0x31853f||!('oauthAccessToken'in _0x31853f)||!_0x31853f['oauthAccessToken'])return null;try{return he['credential'](_0x31853f['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xb13d83,_0x1652df){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xb13d83,'accessToken':_0x1652df});}static['credentialFromResult'](_0x3394a4){return ue['credentialFromTaggedObject'](_0x3394a4);}static['credentialFromError'](_0x1725bf){return ue['credentialFromTaggedObject'](_0x1725bf['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xa071c2}){if(!_0xa071c2)return null;const {oauthIdToken:_0x37585b,oauthAccessToken:_0x1781f6}=_0xa071c2;if(!_0x37585b&&!_0x1781f6)return null;try{return ue['credential'](_0x37585b,_0x1781f6);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x5833a5){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5833a5});}static['credentialFromResult'](_0x69cbdd){return de['credentialFromTaggedObject'](_0x69cbdd);}static['credentialFromError'](_0x1501a9){return de['credentialFromTaggedObject'](_0x1501a9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b7f77}){if(!_0x4b7f77||!('oauthAccessToken'in _0x4b7f77)||!_0x4b7f77['oauthAccessToken'])return null;try{return de['credential'](_0x4b7f77['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x1f91df,_0x279e9a){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1f91df,'oauthTokenSecret':_0x279e9a});}static['credentialFromResult'](_0x4e5dc){return fe['credentialFromTaggedObject'](_0x4e5dc);}static['credentialFromError'](_0x122a70){return fe['credentialFromTaggedObject'](_0x122a70['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x360b27}){if(!_0x360b27)return null;const {oauthAccessToken:_0x48415c,oauthTokenSecret:_0x144333}=_0x360b27;if(!_0x48415c||!_0x144333)return null;try{return fe['credential'](_0x48415c,_0x144333);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x2b600c,_0x3a9699){return Yt(_0x2b600c,'POST','/v1/accounts:signUp',Re(_0x2b600c,_0x3a9699));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xf910c7){this['user']=_0xf910c7['user'],this['providerId']=_0xf910c7['providerId'],this['_tokenResponse']=_0xf910c7['_tokenResponse'],this['operationType']=_0xf910c7['operationType'];}static async['_fromIdTokenResponse'](_0x59bb8a,_0x4041db,_0x370dfb,_0x4664e3=!0x1){const _0x2641f9=await z['_fromIdTokenResponse'](_0x59bb8a,_0x370dfb,_0x4664e3),_0x1de364=Ar(_0x370dfb);return new Be({'user':_0x2641f9,'providerId':_0x1de364,'_tokenResponse':_0x370dfb,'operationType':_0x4041db});}static async['_forOperation'](_0x4667ce,_0x178109,_0x2ae5c8){await _0x4667ce['_updateTokensIfNecessary'](_0x2ae5c8,!0x0);const _0xfd16de=Ar(_0x2ae5c8);return new Be({'user':_0x4667ce,'providerId':_0xfd16de,'_tokenResponse':_0x2ae5c8,'operationType':_0x178109});}}function Ar(_0xb9aafe){return _0xb9aafe['providerId']?_0xb9aafe['providerId']:'phoneNumber'in _0xb9aafe?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x18ea29,_0x5b915f,_0x1310f2,_0x1596d6){super(_0x5b915f['code'],_0x5b915f['message']),this['operationType']=_0x1310f2,this['user']=_0x1596d6,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x18ea29['name'],'tenantId':_0x18ea29['tenantId']??void 0x0,'_serverResponse':_0x5b915f['customData']['_serverResponse'],'operationType':_0x1310f2};}static['_fromErrorAndOperation'](_0x652570,_0x380543,_0x521ff1,_0x5d8adf){return new Rn(_0x652570,_0x380543,_0x521ff1,_0x5d8adf);}}function Fa(_0x5b8666,_0x48ae33,_0x569d44,_0xf415ff){return(_0x48ae33==='reauthenticate'?_0x569d44['_getReauthenticationResolver'](_0x5b8666):_0x569d44['_getIdTokenResponse'](_0x5b8666))['catch'](_0x425c14=>{throw _0x425c14['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x5b8666,_0x425c14,_0x48ae33,_0xf415ff):_0x425c14;});}async function jf(_0x366d48,_0x1d8ee3,_0x2c31e=!0x1){const _0x4e5691=await xt(_0x366d48,_0x1d8ee3['_linkToIdToken'](_0x366d48['auth'],await _0x366d48['getIdToken']()),_0x2c31e);return Be['_forOperation'](_0x366d48,'link',_0x4e5691);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x39c91d,_0x37e1d2,_0x2338d6=!0x1){const {auth:_0x58c618}=_0x39c91d;if(H(_0x58c618['app']))return Promise['reject'](se(_0x58c618));const _0x285595='reauthenticate';try{const _0x41a562=await xt(_0x39c91d,Fa(_0x58c618,_0x285595,_0x37e1d2,_0x39c91d),_0x2338d6);m(_0x41a562['idToken'],_0x58c618,'internal-error');const _0x1c27d4=ws(_0x41a562['idToken']);m(_0x1c27d4,_0x58c618,'internal-error');const {sub:_0x55ea0f}=_0x1c27d4;return m(_0x39c91d['uid']===_0x55ea0f,_0x58c618,'user-mismatch'),Be['_forOperation'](_0x39c91d,_0x285595,_0x41a562);}catch(_0x1a2230){throw(_0x1a2230==null?void 0x0:_0x1a2230['code'])==='auth/user-not-found'&&K(_0x58c618,'user-mismatch'),_0x1a2230;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x5bb5ba,_0x1d0d88,_0x327b30=!0x1){if(H(_0x5bb5ba['app']))return Promise['reject'](se(_0x5bb5ba));const _0x21f60c='signIn',_0x325bf0=await Fa(_0x5bb5ba,_0x21f60c,_0x1d0d88),_0x8d026c=await Be['_fromIdTokenResponse'](_0x5bb5ba,_0x21f60c,_0x325bf0);return _0x327b30||await _0x5bb5ba['_updateCurrentUser'](_0x8d026c['user']),_0x8d026c;}async function Yf(_0x683210,_0x21ec1c){return Ua(qe(_0x683210),_0x21ec1c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x270c2c){const _0xa97666=qe(_0x270c2c);_0xa97666['_getPasswordPolicyInternal']()&&await _0xa97666['_updatePasswordPolicy']();}async function R_(_0x11b3d7,_0x2acf8e,_0x10143c){if(H(_0x11b3d7['app']))return Promise['reject'](se(_0x11b3d7));const _0x2c7807=qe(_0x11b3d7),_0x2b9909=await Oi(_0x2c7807,{'returnSecureToken':!0x0,'email':_0x2acf8e,'password':_0x10143c,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x1e7833=>{throw _0x1e7833['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x11b3d7),_0x1e7833;}),_0x360a0c=await Be['_fromIdTokenResponse'](_0x2c7807,'signIn',_0x2b9909);return await _0x2c7807['_updateCurrentUser'](_0x360a0c['user']),_0x360a0c;}function A_(_0x304b6a,_0x1b1ffd,_0x2b9f8e){return H(_0x304b6a['app'])?Promise['reject'](se(_0x304b6a)):Yf(k(_0x304b6a),ft['credential'](_0x1b1ffd,_0x2b9f8e))['catch'](async _0x13c1b5=>{throw _0x13c1b5['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x304b6a),_0x13c1b5;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x4b9659,_0x422a5d){return k(_0x4b9659)['setPersistence'](_0x422a5d);}function Qf(_0x59d649,_0x3ca3f1,_0x34d903,_0x426a7f){return k(_0x59d649)['onIdTokenChanged'](_0x3ca3f1,_0x34d903,_0x426a7f);}function Jf(_0x1c3509,_0x6f1ee3,_0x1ea1ad){return k(_0x1c3509)['beforeAuthStateChanged'](_0x6f1ee3,_0x1ea1ad);}function N_(_0x30ad79,_0x483531,_0x22301f,_0x3f59d0){return k(_0x30ad79)['onAuthStateChanged'](_0x483531,_0x22301f,_0x3f59d0);}function P_(_0xd821c1){return k(_0xd821c1)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x17ead7,_0x51a602){this['storageRetriever']=_0x17ead7,this['type']=_0x51a602;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x20012a,_0x5b9541){return this['storage']['setItem'](_0x20012a,JSON['stringify'](_0x5b9541)),Promise['resolve']();}['_get'](_0x44eea5){const _0x2c4879=this['storage']['getItem'](_0x44eea5);return Promise['resolve'](_0x2c4879?JSON['parse'](_0x2c4879):null);}['_remove'](_0x2ef713){return this['storage']['removeItem'](_0x2ef713),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4ab07a,_0xfb25c1)=>this['onStorageEvent'](_0x4ab07a,_0xfb25c1),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3a0536){for(const _0x1cc666 of Object['keys'](this['listeners'])){const _0x3fdddb=this['storage']['getItem'](_0x1cc666),_0x2e0749=this['localCache'][_0x1cc666];_0x3fdddb!==_0x2e0749&&_0x3a0536(_0x1cc666,_0x2e0749,_0x3fdddb);}}['onStorageEvent'](_0x49a431,_0x3788be=!0x1){if(!_0x49a431['key']){this['forAllChangedKeys']((_0x2a4ae3,_0x568071,_0x46dfa8)=>{this['notifyListeners'](_0x2a4ae3,_0x46dfa8);});return;}const _0x5e85f1=_0x49a431['key'];_0x3788be?this['detachListener']():this['stopPolling']();const _0x479114=()=>{const _0x57699c=this['storage']['getItem'](_0x5e85f1);!_0x3788be&&this['localCache'][_0x5e85f1]===_0x57699c||this['notifyListeners'](_0x5e85f1,_0x57699c);},_0x340cd6=this['storage']['getItem'](_0x5e85f1);If()&&_0x340cd6!==_0x49a431['newValue']&&_0x49a431['newValue']!==_0x49a431['oldValue']?setTimeout(_0x479114,Zf):_0x479114();}['notifyListeners'](_0x541787,_0x6f52f1){this['localCache'][_0x541787]=_0x6f52f1;const _0x3db369=this['listeners'][_0x541787];if(_0x3db369){for(const _0x5cd9e4 of Array['from'](_0x3db369))_0x5cd9e4(_0x6f52f1&&JSON['parse'](_0x6f52f1));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5248c9,_0x47bb55,_0x2a124e)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5248c9,'oldValue':_0x47bb55,'newValue':_0x2a124e}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4b6981,_0x2ea6c5){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4b6981]||(this['listeners'][_0x4b6981]=new Set(),this['localCache'][_0x4b6981]=this['storage']['getItem'](_0x4b6981)),this['listeners'][_0x4b6981]['add'](_0x2ea6c5);}['_removeListener'](_0x330ec2,_0x5619d7){this['listeners'][_0x330ec2]&&(this['listeners'][_0x330ec2]['delete'](_0x5619d7),this['listeners'][_0x330ec2]['size']===0x0&&delete this['listeners'][_0x330ec2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x454677,_0x358436){await super['_set'](_0x454677,_0x358436),this['localCache'][_0x454677]=JSON['stringify'](_0x358436);}async['_get'](_0x173632){const _0x1d3cc0=await super['_get'](_0x173632);return this['localCache'][_0x173632]=JSON['stringify'](_0x1d3cc0),_0x1d3cc0;}async['_remove'](_0x187306){await super['_remove'](_0x187306),delete this['localCache'][_0x187306];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x450299,_0x11238b){}['_removeListener'](_0x3dbd89,_0x32e511){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x492f61){return Promise['all'](_0x492f61['map'](async _0x4ed127=>{try{return{'fulfilled':!0x0,'value':await _0x4ed127};}catch(_0x29ed8e){return{'fulfilled':!0x1,'reason':_0x29ed8e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x4fc5cc){this['eventTarget']=_0x4fc5cc,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x59a5d4){const _0xee5046=this['receivers']['find'](_0x10064a=>_0x10064a['isListeningto'](_0x59a5d4));if(_0xee5046)return _0xee5046;const _0x32f9d7=new jn(_0x59a5d4);return this['receivers']['push'](_0x32f9d7),_0x32f9d7;}['isListeningto'](_0x2bd576){return this['eventTarget']===_0x2bd576;}async['handleEvent'](_0x223edb){const _0x10230f=_0x223edb,{eventId:_0x24a257,eventType:_0x51d52d,data:_0x2cbe8c}=_0x10230f['data'],_0x150f57=this['handlersMap'][_0x51d52d];if(!(_0x150f57!=null&&_0x150f57['size']))return;_0x10230f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x24a257,'eventType':_0x51d52d});const _0x2782fc=Array['from'](_0x150f57)['map'](async _0x44fc8e=>_0x44fc8e(_0x10230f['origin'],_0x2cbe8c)),_0x20cf95=await tp(_0x2782fc);_0x10230f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x24a257,'eventType':_0x51d52d,'response':_0x20cf95});}['_subscribe'](_0x4ee9cf,_0x138862){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4ee9cf]||(this['handlersMap'][_0x4ee9cf]=new Set()),this['handlersMap'][_0x4ee9cf]['add'](_0x138862);}['_unsubscribe'](_0xb2d075,_0x14fa89){this['handlersMap'][_0xb2d075]&&_0x14fa89&&this['handlersMap'][_0xb2d075]['delete'](_0x14fa89),(!_0x14fa89||this['handlersMap'][_0xb2d075]['size']===0x0)&&delete this['handlersMap'][_0xb2d075],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x2309be='',_0x461071=0xa){let _0x55dc4b='';for(let _0x513187=0x0;_0x513187<_0x461071;_0x513187++)_0x55dc4b+=Math['floor'](Math['random']()*0xa);return _0x2309be+_0x55dc4b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x115554){this['target']=_0x115554,this['handlers']=new Set();}['removeMessageHandler'](_0x6f3a5e){_0x6f3a5e['messageChannel']&&(_0x6f3a5e['messageChannel']['port1']['removeEventListener']('message',_0x6f3a5e['onMessage']),_0x6f3a5e['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x6f3a5e);}async['_send'](_0x48556a,_0x4c01e5,_0xb6f0c4=0x32){const _0x52de60=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x52de60)throw new Error('connection_unavailable');let _0x5e1049,_0xec592;return new Promise((_0x16ef6a,_0x4ac403)=>{const _0x3059c0=bs('',0x14);_0x52de60['port1']['start']();const _0x5df0c4=setTimeout(()=>{_0x4ac403(new Error('unsupported_event'));},_0xb6f0c4);_0xec592={'messageChannel':_0x52de60,'onMessage'(_0xdabe11){const _0x148c4a=_0xdabe11;if(_0x148c4a['data']['eventId']===_0x3059c0)switch(_0x148c4a['data']['status']){case'ack':clearTimeout(_0x5df0c4),_0x5e1049=setTimeout(()=>{_0x4ac403(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5e1049),_0x16ef6a(_0x148c4a['data']['response']);break;default:clearTimeout(_0x5df0c4),clearTimeout(_0x5e1049),_0x4ac403(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xec592),_0x52de60['port1']['addEventListener']('message',_0xec592['onMessage']),this['target']['postMessage']({'eventType':_0x48556a,'eventId':_0x3059c0,'data':_0x4c01e5},[_0x52de60['port2']]);})['finally'](()=>{_0xec592&&this['removeMessageHandler'](_0xec592);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x566d01){X()['location']['href']=_0x566d01;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x5a4a2b;return((_0x5a4a2b=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5a4a2b['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x380027){this['request']=_0x380027;}['toPromise'](){return new Promise((_0x5ad13a,_0x51ef4f)=>{this['request']['addEventListener']('success',()=>{_0x5ad13a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x51ef4f(this['request']['error']);});});}}function Kn(_0x435f58,_0x4c4cd8){return _0x435f58['transaction']([kn],_0x4c4cd8?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x309f69=indexedDB['deleteDatabase'](qa);return new Jt(_0x309f69)['toPromise']();}function ja(){const _0x2a5afd=indexedDB['open'](qa,ap);return new Promise((_0x4e4db6,_0x57ed67)=>{_0x2a5afd['addEventListener']('error',()=>{_0x57ed67(_0x2a5afd['error']);}),_0x2a5afd['addEventListener']('upgradeneeded',()=>{const _0x3e4be1=_0x2a5afd['result'];try{_0x3e4be1['createObjectStore'](kn,{'keyPath':za});}catch(_0x5278b8){_0x57ed67(_0x5278b8);}}),_0x2a5afd['addEventListener']('success',async()=>{const _0x4038db=_0x2a5afd['result'];_0x4038db['objectStoreNames']['contains'](kn)?_0x4e4db6(_0x4038db):(_0x4038db['close'](),await cp(),_0x4e4db6(await ja()));});});}async function kr(_0x50f6a2,_0x5c2d69,_0x170dcb){const _0x583d6d=Kn(_0x50f6a2,!0x0)['put']({[za]:_0x5c2d69,'value':_0x170dcb});return new Jt(_0x583d6d)['toPromise']();}async function lp(_0x3c9e3d,_0x188564){const _0x19d4d2=Kn(_0x3c9e3d,!0x1)['get'](_0x188564),_0x32ca5b=await new Jt(_0x19d4d2)['toPromise']();return _0x32ca5b===void 0x0?null:_0x32ca5b['value'];}function Nr(_0x4ab020,_0x49ea41){const _0x19cb70=Kn(_0x4ab020,!0x0)['delete'](_0x49ea41);return new Jt(_0x19cb70)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x189648){let _0x4acb12=0x0;for(;;)try{const _0x1ac452=await this['_openDb']();return await _0x189648(_0x1ac452);}catch(_0x11d497){if(_0x4acb12++>up)throw _0x11d497;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x157b47,_0x2f558d)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2f558d['key'])})),this['receiver']['_subscribe']('ping',async(_0x41a5b3,_0x2f55c5)=>['keyChanged']);}async['initializeSender'](){var _0x2e7e37,_0x69c13f;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x30e570=await this['sender']['_send']('ping',{},0x320);_0x30e570&&(_0x2e7e37=_0x30e570[0x0])!=null&&_0x2e7e37['fulfilled']&&(_0x69c13f=_0x30e570[0x0])!=null&&_0x69c13f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2711e7){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2711e7},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1887b7=>{await kr(_0x1887b7,An,'1'),await Nr(_0x1887b7,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3949c5){this['pendingWrites']++;try{await _0x3949c5();}finally{this['pendingWrites']--;}}async['_set'](_0x289393,_0x388263){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x12771a=>kr(_0x12771a,_0x289393,_0x388263)),this['localCache'][_0x289393]=_0x388263,this['notifyServiceWorker'](_0x289393)));}async['_get'](_0x1bdde0){const _0x170ea0=await this['_withRetries'](_0x16e6da=>lp(_0x16e6da,_0x1bdde0));return this['localCache'][_0x1bdde0]=_0x170ea0,_0x170ea0;}async['_remove'](_0x197acc){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x91fc1=>Nr(_0x91fc1,_0x197acc)),delete this['localCache'][_0x197acc],this['notifyServiceWorker'](_0x197acc)));}async['_poll'](){const _0x4dc2bd=await this['_withRetries'](_0x3facda=>{const _0x4b4be5=Kn(_0x3facda,!0x1)['getAll']();return new Jt(_0x4b4be5)['toPromise']();});if(!_0x4dc2bd)return[];if(this['pendingWrites']!==0x0)return[];const _0x3420b0=[],_0x574830=new Set();if(_0x4dc2bd['length']!==0x0){for(const {fbase_key:_0x5463ab,value:_0x5ea4a4}of _0x4dc2bd)_0x574830['add'](_0x5463ab),JSON['stringify'](this['localCache'][_0x5463ab])!==JSON['stringify'](_0x5ea4a4)&&(this['notifyListeners'](_0x5463ab,_0x5ea4a4),_0x3420b0['push'](_0x5463ab));}for(const _0x3baa7e of Object['keys'](this['localCache']))this['localCache'][_0x3baa7e]&&!_0x574830['has'](_0x3baa7e)&&(this['notifyListeners'](_0x3baa7e,null),_0x3420b0['push'](_0x3baa7e));return _0x3420b0;}['notifyListeners'](_0x428052,_0x20bfd9){this['localCache'][_0x428052]=_0x20bfd9;const _0x569b5b=this['listeners'][_0x428052];if(_0x569b5b){for(const _0x3a040f of Array['from'](_0x569b5b))_0x3a040f(_0x20bfd9);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x372ed7,_0x4be5f8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x372ed7]||(this['listeners'][_0x372ed7]=new Set(),this['_get'](_0x372ed7)),this['listeners'][_0x372ed7]['add'](_0x4be5f8);}['_removeListener'](_0x496107,_0x90521){this['listeners'][_0x496107]&&(this['listeners'][_0x496107]['delete'](_0x90521),this['listeners'][_0x496107]['size']===0x0&&delete this['listeners'][_0x496107]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x5451e8,_0x5f3e0f){return _0x5f3e0f?ne(_0x5f3e0f):(m(_0x5451e8['_popupRedirectResolver'],_0x5451e8,'argument-error'),_0x5451e8['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x23a3a6){super('custom','custom'),this['params']=_0x23a3a6;}['_getIdTokenResponse'](_0x4fdc31){return Ze(_0x4fdc31,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1938cf,_0x6fda07){return Ze(_0x1938cf,this['_buildIdpRequest'](_0x6fda07));}['_getReauthenticationResolver'](_0x3de167){return Ze(_0x3de167,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x21bdf4){const _0x476e91={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x21bdf4&&(_0x476e91['idToken']=_0x21bdf4),_0x476e91;}}function pp(_0x1a69ac){return Ua(_0x1a69ac['auth'],new Rs(_0x1a69ac),_0x1a69ac['bypassAuthState']);}function _p(_0xf23ade){const {auth:_0x22acc4,user:_0x3880f6}=_0xf23ade;return m(_0x3880f6,_0x22acc4,'internal-error'),Kf(_0x3880f6,new Rs(_0xf23ade),_0xf23ade['bypassAuthState']);}async function gp(_0x5dffcc){const {auth:_0x4f02a3,user:_0x882031}=_0x5dffcc;return m(_0x882031,_0x4f02a3,'internal-error'),jf(_0x882031,new Rs(_0x5dffcc),_0x5dffcc['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2f2cb5,_0x469906,_0x3e9c53,_0x2ed730,_0x4f30bd=!0x1){this['auth']=_0x2f2cb5,this['resolver']=_0x3e9c53,this['user']=_0x2ed730,this['bypassAuthState']=_0x4f30bd,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x469906)?_0x469906:[_0x469906];}['execute'](){return new Promise(async(_0x5c0060,_0x21e9a1)=>{this['pendingPromise']={'resolve':_0x5c0060,'reject':_0x21e9a1};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4d5fe0){this['reject'](_0x4d5fe0);}});}async['onAuthEvent'](_0x2a8bc4){const {urlResponse:_0x37eb28,sessionId:_0x3d2d81,postBody:_0x4abcaa,tenantId:_0x4e7775,error:_0x347d8a,type:_0x30e284}=_0x2a8bc4;if(_0x347d8a){this['reject'](_0x347d8a);return;}const _0x74b1c4={'auth':this['auth'],'requestUri':_0x37eb28,'sessionId':_0x3d2d81,'tenantId':_0x4e7775||void 0x0,'postBody':_0x4abcaa||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x30e284)(_0x74b1c4));}catch(_0x27670c){this['reject'](_0x27670c);}}['onError'](_0x4dd56d){this['reject'](_0x4dd56d);}['getIdpTask'](_0x22ab6d){switch(_0x22ab6d){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x58b081){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x58b081),this['unregisterAndCleanUp']();}['reject'](_0x3f9796){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3f9796),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x2066c7,_0x2f842c,_0x17815c,_0x1d8afb,_0x33b718){super(_0x2066c7,_0x2f842c,_0x1d8afb,_0x33b718),this['provider']=_0x17815c,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x59f625=await this['execute']();return m(_0x59f625,this['auth'],'internal-error'),_0x59f625;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x7b2887=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x7b2887),this['authWindow']['associatedEvent']=_0x7b2887,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2a5935=>{this['reject'](_0x2a5935);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x556df6=>{_0x556df6||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5ffd02;return((_0x5ffd02=this['authWindow'])==null?void 0x0:_0x5ffd02['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xa7406b=()=>{var _0x5bab5e,_0x205df7;if((_0x205df7=(_0x5bab5e=this['authWindow'])==null?void 0x0:_0x5bab5e['window'])!=null&&_0x205df7['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xa7406b,mp['get']());};_0xa7406b();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x1bebda,_0x4b929e,_0x1c26b5=!0x1){super(_0x1bebda,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4b929e,void 0x0,_0x1c26b5),this['eventId']=null;}async['execute'](){let _0x41ce74=rn['get'](this['auth']['_key']());if(!_0x41ce74){try{const _0x1d0fb7=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x41ce74=()=>Promise['resolve'](_0x1d0fb7);}catch(_0x1edcc5){_0x41ce74=()=>Promise['reject'](_0x1edcc5);}rn['set'](this['auth']['_key'](),_0x41ce74);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x41ce74();}async['onAuthEvent'](_0x51e4b5){if(_0x51e4b5['type']==='signInViaRedirect')return super['onAuthEvent'](_0x51e4b5);if(_0x51e4b5['type']==='unknown'){this['resolve'](null);return;}if(_0x51e4b5['eventId']){const _0xdea67c=await this['auth']['_redirectUserForId'](_0x51e4b5['eventId']);if(_0xdea67c)return this['user']=_0xdea67c,super['onAuthEvent'](_0x51e4b5);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x228df2,_0x140132){const _0x334b43=Cp(_0x140132),_0x198608=wp(_0x228df2);if(!await _0x198608['_isAvailable']())return!0x1;const _0x112641=await _0x198608['_get'](_0x334b43)==='true';return await _0x198608['_remove'](_0x334b43),_0x112641;}function Ip(_0x190809,_0x1478cf){rn['set'](_0x190809['_key'](),_0x1478cf);}function wp(_0x2b3b0a){return ne(_0x2b3b0a['_redirectPersistence']);}function Cp(_0x4b4ab6){return sn(yp,_0x4b4ab6['config']['apiKey'],_0x4b4ab6['name']);}async function Tp(_0x2c411f,_0x41e22a,_0xdb2f62=!0x1){if(H(_0x2c411f['app']))return Promise['reject'](se(_0x2c411f));const _0x3567d4=qe(_0x2c411f),_0x46d32e=fp(_0x3567d4,_0x41e22a),_0xb68b58=await new vp(_0x3567d4,_0x46d32e,_0xdb2f62)['execute']();return _0xb68b58&&!_0xdb2f62&&(delete _0xb68b58['user']['_redirectEventId'],await _0x3567d4['_persistUserIfCurrent'](_0xb68b58['user']),await _0x3567d4['_setRedirectUser'](null,_0x41e22a)),_0xb68b58;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x161ae0){this['auth']=_0x161ae0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3dde3b){this['consumers']['add'](_0x3dde3b),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3dde3b)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3dde3b),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x499f82){this['consumers']['delete'](_0x499f82);}['onEvent'](_0x31468b){if(this['hasEventBeenHandled'](_0x31468b))return!0x1;let _0x3d0bb1=!0x1;return this['consumers']['forEach'](_0x59b68=>{this['isEventForConsumer'](_0x31468b,_0x59b68)&&(_0x3d0bb1=!0x0,this['sendToConsumer'](_0x31468b,_0x59b68),this['saveEventToCache'](_0x31468b));}),this['hasHandledPotentialRedirect']||!Rp(_0x31468b)||(this['hasHandledPotentialRedirect']=!0x0,_0x3d0bb1||(this['queuedRedirectEvent']=_0x31468b,_0x3d0bb1=!0x0)),_0x3d0bb1;}['sendToConsumer'](_0x358d9d,_0x388e2c){var _0x142ef6;if(_0x358d9d['error']&&!Qa(_0x358d9d)){const _0x430c99=((_0x142ef6=_0x358d9d['error']['code'])==null?void 0x0:_0x142ef6['split']('auth/')[0x1])||'internal-error';_0x388e2c['onError'](J(this['auth'],_0x430c99));}else _0x388e2c['onAuthEvent'](_0x358d9d);}['isEventForConsumer'](_0xd64d90,_0x16e7c3){const _0x3b5f5a=_0x16e7c3['eventId']===null||!!_0xd64d90['eventId']&&_0xd64d90['eventId']===_0x16e7c3['eventId'];return _0x16e7c3['filter']['includes'](_0xd64d90['type'])&&_0x3b5f5a;}['hasEventBeenHandled'](_0x2e6d43){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2e6d43));}['saveEventToCache'](_0x2f555b){this['cachedEventUids']['add'](Pr(_0x2f555b)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x383dbb){return[_0x383dbb['type'],_0x383dbb['eventId'],_0x383dbb['sessionId'],_0x383dbb['tenantId']]['filter'](_0x25f46c=>_0x25f46c)['join']('-');}function Qa({type:_0x22c6b2,error:_0xe7884e}){return _0x22c6b2==='unknown'&&(_0xe7884e==null?void 0x0:_0xe7884e['code'])==='auth/no-auth-event';}function Rp(_0x3776c4){switch(_0x3776c4['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3776c4);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3cb498,_0x1e6c86={}){return Ae(_0x3cb498,'GET','/v1/projects',_0x1e6c86);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x33d63e){if(_0x33d63e['config']['emulator'])return;const {authorizedDomains:_0x44233a}=await Ap(_0x33d63e);for(const _0x1d7a94 of _0x44233a)try{if(Op(_0x1d7a94))return;}catch{}K(_0x33d63e,'unauthorized-domain');}function Op(_0x7b6379){const _0x27fd30=Ni(),{protocol:_0x5701fc,hostname:_0x3007b2}=new URL(_0x27fd30);if(_0x7b6379['startsWith']('chrome-extension://')){const _0x400936=new URL(_0x7b6379);return _0x400936['hostname']===''&&_0x3007b2===''?_0x5701fc==='chrome-extension:'&&_0x7b6379['replace']('chrome-extension://','')===_0x27fd30['replace']('chrome-extension://',''):_0x5701fc==='chrome-extension:'&&_0x400936['hostname']===_0x3007b2;}if(!Np['test'](_0x5701fc))return!0x1;if(kp['test'](_0x7b6379))return _0x3007b2===_0x7b6379;const _0x470c4a=_0x7b6379['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x470c4a+'|'+_0x470c4a+')$','i')['test'](_0x3007b2);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x6dbcb7=X()['___jsl'];if(_0x6dbcb7!=null&&_0x6dbcb7['H']){for(const _0x106084 of Object['keys'](_0x6dbcb7['H']))if(_0x6dbcb7['H'][_0x106084]['r']=_0x6dbcb7['H'][_0x106084]['r']||[],_0x6dbcb7['H'][_0x106084]['L']=_0x6dbcb7['H'][_0x106084]['L']||[],_0x6dbcb7['H'][_0x106084]['r']=[..._0x6dbcb7['H'][_0x106084]['L']],_0x6dbcb7['CP']){for(let _0x8a93e0=0x0;_0x8a93e0<_0x6dbcb7['CP']['length'];_0x8a93e0++)_0x6dbcb7['CP'][_0x8a93e0]=null;}}}function Mp(_0x422b8a){return new Promise((_0xe58a9,_0x34af3b)=>{var _0x4b66a5,_0x4a6e31,_0x1210ca;function _0x2662da(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xe58a9(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x34af3b(J(_0x422b8a,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x4a6e31=(_0x4b66a5=X()['gapi'])==null?void 0x0:_0x4b66a5['iframes'])!=null&&_0x4a6e31['Iframe'])_0xe58a9(gapi['iframes']['getContext']());else{if((_0x1210ca=X()['gapi'])!=null&&_0x1210ca['load'])_0x2662da();else{const _0x200c48=Nf('iframefcb');return X()[_0x200c48]=()=>{gapi['load']?_0x2662da():_0x34af3b(J(_0x422b8a,'network-request-failed'));},Da(kf()+'?onload='+_0x200c48)['catch'](_0x7b9f2e=>_0x34af3b(_0x7b9f2e));}}})['catch'](_0x3dcf8c=>{throw on=null,_0x3dcf8c;});}let on=null;function Lp(_0x477753){return on=on||Mp(_0x477753),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3654ae){const _0x4754aa=_0x3654ae['config'];m(_0x4754aa['authDomain'],_0x3654ae,'auth-domain-config-required');const _0x30b3fe=_0x4754aa['emulator']?Is(_0x4754aa,Up):'https://'+_0x3654ae['config']['authDomain']+'/'+Fp,_0x1485c4={'apiKey':_0x4754aa['apiKey'],'appName':_0x3654ae['name'],'v':ct},_0x513c5e=Bp['get'](_0x3654ae['config']['apiHost']);_0x513c5e&&(_0x1485c4['eid']=_0x513c5e);const _0x585a53=_0x3654ae['_getFrameworks']();return _0x585a53['length']&&(_0x1485c4['fw']=_0x585a53['join'](',')),_0x30b3fe+'?'+at(_0x1485c4)['slice'](0x1);}async function Hp(_0x40fe44){const _0xa8e144=await Lp(_0x40fe44),_0x185c07=X()['gapi'];return m(_0x185c07,_0x40fe44,'internal-error'),_0xa8e144['open']({'where':document['body'],'url':Vp(_0x40fe44),'messageHandlersFilter':_0x185c07['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x4994d2=>new Promise(async(_0x252ddb,_0x4d9a99)=>{await _0x4994d2['restyle']({'setHideOnLeave':!0x1});const _0xbe79ad=J(_0x40fe44,'network-request-failed'),_0x1ffc3f=X()['setTimeout'](()=>{_0x4d9a99(_0xbe79ad);},xp['get']());function _0x375463(){X()['clearTimeout'](_0x1ffc3f),_0x252ddb(_0x4994d2);}_0x4994d2['ping'](_0x375463)['then'](_0x375463,()=>{_0x4d9a99(_0xbe79ad);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x28de27){this['window']=_0x28de27,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x1fbc53,_0x50d118,_0x50e009,_0x28d91f=Gp,_0x4979ae=qp){const _0x351d19=Math['max']((window['screen']['availHeight']-_0x4979ae)/0x2,0x0)['toString'](),_0x52f188=Math['max']((window['screen']['availWidth']-_0x28d91f)/0x2,0x0)['toString']();let _0x3e7f51='';const _0x24b2c1={...$p,'width':_0x28d91f['toString'](),'height':_0x4979ae['toString'](),'top':_0x351d19,'left':_0x52f188},_0xdc97d7=W()['toLowerCase']();_0x50e009&&(_0x3e7f51=ba(_0xdc97d7)?zp:_0x50e009),Ta(_0xdc97d7)&&(_0x50d118=_0x50d118||jp,_0x24b2c1['scrollbars']='yes');const _0x2f1e31=Object['entries'](_0x24b2c1)['reduce']((_0x23a1be,[_0x1fb69f,_0x1b625f])=>''+_0x23a1be+_0x1fb69f+'='+_0x1b625f+',','');if(Ef(_0xdc97d7)&&_0x3e7f51!=='_self')return Yp(_0x50d118||'',_0x3e7f51),new Dr(null);const _0x33649c=window['open'](_0x50d118||'',_0x3e7f51,_0x2f1e31);m(_0x33649c,_0x1fbc53,'popup-blocked');try{_0x33649c['focus']();}catch{}return new Dr(_0x33649c);}function Yp(_0x2fd3a9,_0x59e5a4){const _0x1ef636=document['createElement']('a');_0x1ef636['href']=_0x2fd3a9,_0x1ef636['target']=_0x59e5a4;const _0x5e15f1=document['createEvent']('MouseEvent');_0x5e15f1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1ef636['dispatchEvent'](_0x5e15f1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x49fdb9,_0x60f11,_0x227e17,_0x40023b,_0x44379f,_0x5b85a0){m(_0x49fdb9['config']['authDomain'],_0x49fdb9,'auth-domain-config-required'),m(_0x49fdb9['config']['apiKey'],_0x49fdb9,'invalid-api-key');const _0x2f5132={'apiKey':_0x49fdb9['config']['apiKey'],'appName':_0x49fdb9['name'],'authType':_0x227e17,'redirectUrl':_0x40023b,'v':ct,'eventId':_0x44379f};if(_0x60f11 instanceof xa){_0x60f11['setDefaultLanguage'](_0x49fdb9['languageCode']),_0x2f5132['providerId']=_0x60f11['providerId']||'',hi(_0x60f11['getCustomParameters']())||(_0x2f5132['customParameters']=JSON['stringify'](_0x60f11['getCustomParameters']()));for(const [_0x161690,_0xdd60d5]of Object['entries']({}))_0x2f5132[_0x161690]=_0xdd60d5;}if(_0x60f11 instanceof Qt){const _0x46b471=_0x60f11['getScopes']()['filter'](_0x25ec02=>_0x25ec02!=='');_0x46b471['length']>0x0&&(_0x2f5132['scopes']=_0x46b471['join'](','));}_0x49fdb9['tenantId']&&(_0x2f5132['tid']=_0x49fdb9['tenantId']);const _0x2727bd=_0x2f5132;for(const _0x144a91 of Object['keys'](_0x2727bd))_0x2727bd[_0x144a91]===void 0x0&&delete _0x2727bd[_0x144a91];const _0x2e7b62=await _0x49fdb9['_getAppCheckToken'](),_0x34b8c7=_0x2e7b62?'#'+Xp+'='+encodeURIComponent(_0x2e7b62):'';return Zp(_0x49fdb9)+'?'+at(_0x2727bd)['slice'](0x1)+_0x34b8c7;}function Zp({config:_0x580f1}){return _0x580f1['emulator']?Is(_0x580f1,Jp):'https://'+_0x580f1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x56e577,_0x5f3f65,_0x1d62e2,_0x2db2bf){var _0x1f4872;ae((_0x1f4872=this['eventManagers'][_0x56e577['_key']()])==null?void 0x0:_0x1f4872['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x355660=await Mr(_0x56e577,_0x5f3f65,_0x1d62e2,Ni(),_0x2db2bf);return Kp(_0x56e577,_0x355660,bs());}async['_openRedirect'](_0x23eee6,_0x277342,_0x3c0418,_0xa899b){await this['_originValidation'](_0x23eee6);const _0x55a95e=await Mr(_0x23eee6,_0x277342,_0x3c0418,Ni(),_0xa899b);return ip(_0x55a95e),new Promise(()=>{});}['_initialize'](_0x134cc8){const _0x4ce0b4=_0x134cc8['_key']();if(this['eventManagers'][_0x4ce0b4]){const {manager:_0x26cd61,promise:_0x387136}=this['eventManagers'][_0x4ce0b4];return _0x26cd61?Promise['resolve'](_0x26cd61):(ae(_0x387136,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x387136);}const _0x432e4f=this['initAndGetManager'](_0x134cc8);return this['eventManagers'][_0x4ce0b4]={'promise':_0x432e4f},_0x432e4f['catch'](()=>{delete this['eventManagers'][_0x4ce0b4];}),_0x432e4f;}async['initAndGetManager'](_0x340e80){const _0x428f5f=await Hp(_0x340e80),_0x59d326=new bp(_0x340e80);return _0x428f5f['register']('authEvent',_0x29e4b2=>(m(_0x29e4b2==null?void 0x0:_0x29e4b2['authEvent'],_0x340e80,'invalid-auth-event'),{'status':_0x59d326['onEvent'](_0x29e4b2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x340e80['_key']()]={'manager':_0x59d326},this['iframes'][_0x340e80['_key']()]=_0x428f5f,_0x59d326;}['_isIframeWebStorageSupported'](_0x18f008,_0x331621){this['iframes'][_0x18f008['_key']()]['send'](li,{'type':li},_0x185255=>{var _0x19d03b;const _0x4166bf=(_0x19d03b=_0x185255==null?void 0x0:_0x185255[0x0])==null?void 0x0:_0x19d03b[li];_0x4166bf!==void 0x0&&_0x331621(!!_0x4166bf),K(_0x18f008,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x138735){const _0xd756e5=_0x138735['_key']();return this['originValidationPromises'][_0xd756e5]||(this['originValidationPromises'][_0xd756e5]=Pp(_0x138735)),this['originValidationPromises'][_0xd756e5];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x45ff67){this['auth']=_0x45ff67,this['internalListeners']=new Map();}['getUid'](){var _0x40d706;return this['assertAuthConfigured'](),((_0x40d706=this['auth']['currentUser'])==null?void 0x0:_0x40d706['uid'])||null;}async['getToken'](_0x2a3d97){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2a3d97)}:null;}['addAuthTokenListener'](_0x5c0deb){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5c0deb))return;const _0x465ad1=this['auth']['onIdTokenChanged'](_0x29647c=>{_0x5c0deb((_0x29647c==null?void 0x0:_0x29647c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5c0deb,_0x465ad1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1893e9){this['assertAuthConfigured']();const _0x2da882=this['internalListeners']['get'](_0x1893e9);_0x2da882&&(this['internalListeners']['delete'](_0x1893e9),_0x2da882(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x52f5af){switch(_0x52f5af){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0xa5d4ef){et(new Me('auth',(_0x9dc8e5,{options:_0x69d9e})=>{const _0x4a0d71=_0x9dc8e5['getProvider']('app')['getImmediate'](),_0x423596=_0x9dc8e5['getProvider']('heartbeat'),_0xee3bb=_0x9dc8e5['getProvider']('app-check-internal'),{apiKey:_0x215846,authDomain:_0x28cbdb}=_0x4a0d71['options'];m(_0x215846&&!_0x215846['includes'](':'),'invalid-api-key',{'appName':_0x4a0d71['name']});const _0x4e2182={'apiKey':_0x215846,'authDomain':_0x28cbdb,'clientPlatform':_0xa5d4ef,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0xa5d4ef)},_0x2c7e06=new bf(_0x4a0d71,_0x423596,_0xee3bb,_0x4e2182);return Lf(_0x2c7e06,_0x69d9e),_0x2c7e06;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x45c973,_0x3f66fe,_0x2bd56d)=>{_0x45c973['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x119ae3=>{const _0x23c808=qe(_0x119ae3['getProvider']('auth')['getImmediate']());return(_0x4ae411=>new n_(_0x4ae411))(_0x23c808);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0xa5d4ef)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x37283b=>async _0x274a03=>{const _0x5888f5=_0x274a03&&await _0x274a03['getIdTokenResult'](),_0x49612b=_0x5888f5&&(new Date()['getTime']()-Date['parse'](_0x5888f5['issuedAtTime']))/0x3e8;if(_0x49612b&&_0x49612b>o_)return;const _0x244953=_0x5888f5==null?void 0x0:_0x5888f5['token'];Fr!==_0x244953&&(Fr=_0x244953,await fetch(_0x37283b,{'method':_0x244953?'POST':'DELETE','headers':_0x244953?{'Authorization':'Bearer\x20'+_0x244953}:{}}));};function O_(_0x38e346=Qr()){const _0x3cb188=Ui(_0x38e346,'auth');if(_0x3cb188['isInitialized']())return _0x3cb188['getImmediate']();const _0x1d1f2b=Mf(_0x38e346,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4cbb42=Gr('authTokenSyncURL');if(_0x4cbb42&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x7b7db2=new URL(_0x4cbb42,location['origin']);if(location['origin']===_0x7b7db2['origin']){const _0x5f2f37=a_(_0x7b7db2['toString']());Jf(_0x1d1f2b,_0x5f2f37,()=>_0x5f2f37(_0x1d1f2b['currentUser'])),Qf(_0x1d1f2b,_0x55f6c2=>_0x5f2f37(_0x55f6c2));}}const _0x3e7d47=Hr('auth');return _0x3e7d47&&xf(_0x1d1f2b,'http://'+_0x3e7d47),_0x1d1f2b;}function c_(){var _0x5ca04b;return((_0x5ca04b=document['getElementsByTagName']('head'))==null?void 0x0:_0x5ca04b[0x0])??document;}Rf({'loadJS'(_0x15df33){return new Promise((_0x26ad3f,_0x1d1cab)=>{const _0x6f8fa8=document['createElement']('script');_0x6f8fa8['setAttribute']('src',_0x15df33),_0x6f8fa8['onload']=_0x26ad3f,_0x6f8fa8['onerror']=_0x4a5e55=>{const _0x4e18e7=J('internal-error');_0x4e18e7['customData']=_0x4a5e55,_0x1d1cab(_0x4e18e7);},_0x6f8fa8['type']='text/javascript',_0x6f8fa8['charset']='UTF-8',c_()['appendChild'](_0x6f8fa8);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};