const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x790456,_0x4a3c95){if(!_0x790456)throw ot(_0x4a3c95);},ot=function(_0x66704d){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x66704d);},Wr=function(_0x2f10dd){const _0x3f9f1f=[];let _0x1de798=0x0;for(let _0x83f52d=0x0;_0x83f52d<_0x2f10dd['length'];_0x83f52d++){let _0x4d5d98=_0x2f10dd['charCodeAt'](_0x83f52d);_0x4d5d98<0x80?_0x3f9f1f[_0x1de798++]=_0x4d5d98:_0x4d5d98<0x800?(_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0x6|0xc0,_0x3f9f1f[_0x1de798++]=_0x4d5d98&0x3f|0x80):(_0x4d5d98&0xfc00)===0xd800&&_0x83f52d+0x1<_0x2f10dd['length']&&(_0x2f10dd['charCodeAt'](_0x83f52d+0x1)&0xfc00)===0xdc00?(_0x4d5d98=0x10000+((_0x4d5d98&0x3ff)<<0xa)+(_0x2f10dd['charCodeAt'](++_0x83f52d)&0x3ff),_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0x12|0xf0,_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0xc&0x3f|0x80,_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0x6&0x3f|0x80,_0x3f9f1f[_0x1de798++]=_0x4d5d98&0x3f|0x80):(_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0xc|0xe0,_0x3f9f1f[_0x1de798++]=_0x4d5d98>>0x6&0x3f|0x80,_0x3f9f1f[_0x1de798++]=_0x4d5d98&0x3f|0x80);}return _0x3f9f1f;},Za=function(_0x149e10){const _0x3fe40=[];let _0xfd1d5a=0x0,_0x24a0eb=0x0;for(;_0xfd1d5a<_0x149e10['length'];){const _0x4fc1fb=_0x149e10[_0xfd1d5a++];if(_0x4fc1fb<0x80)_0x3fe40[_0x24a0eb++]=String['fromCharCode'](_0x4fc1fb);else{if(_0x4fc1fb>0xbf&&_0x4fc1fb<0xe0){const _0x1ea972=_0x149e10[_0xfd1d5a++];_0x3fe40[_0x24a0eb++]=String['fromCharCode']((_0x4fc1fb&0x1f)<<0x6|_0x1ea972&0x3f);}else{if(_0x4fc1fb>0xef&&_0x4fc1fb<0x16d){const _0x3e1512=_0x149e10[_0xfd1d5a++],_0x411d6b=_0x149e10[_0xfd1d5a++],_0x32c5de=_0x149e10[_0xfd1d5a++],_0x13bee1=((_0x4fc1fb&0x7)<<0x12|(_0x3e1512&0x3f)<<0xc|(_0x411d6b&0x3f)<<0x6|_0x32c5de&0x3f)-0x10000;_0x3fe40[_0x24a0eb++]=String['fromCharCode'](0xd800+(_0x13bee1>>0xa)),_0x3fe40[_0x24a0eb++]=String['fromCharCode'](0xdc00+(_0x13bee1&0x3ff));}else{const _0x676d0a=_0x149e10[_0xfd1d5a++],_0x462d58=_0x149e10[_0xfd1d5a++];_0x3fe40[_0x24a0eb++]=String['fromCharCode']((_0x4fc1fb&0xf)<<0xc|(_0x676d0a&0x3f)<<0x6|_0x462d58&0x3f);}}}}return _0x3fe40['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x357de4,_0x41c5b5){if(!Array['isArray'](_0x357de4))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1c9580=_0x41c5b5?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x54bcf2=[];for(let _0x4bbda2=0x0;_0x4bbda2<_0x357de4['length'];_0x4bbda2+=0x3){const _0x5842e3=_0x357de4[_0x4bbda2],_0x1e1737=_0x4bbda2+0x1<_0x357de4['length'],_0x487605=_0x1e1737?_0x357de4[_0x4bbda2+0x1]:0x0,_0x135bb6=_0x4bbda2+0x2<_0x357de4['length'],_0x3c6f6d=_0x135bb6?_0x357de4[_0x4bbda2+0x2]:0x0,_0x1da518=_0x5842e3>>0x2,_0x3444ac=(_0x5842e3&0x3)<<0x4|_0x487605>>0x4;let _0x35da2e=(_0x487605&0xf)<<0x2|_0x3c6f6d>>0x6,_0x510ccb=_0x3c6f6d&0x3f;_0x135bb6||(_0x510ccb=0x40,_0x1e1737||(_0x35da2e=0x40)),_0x54bcf2['push'](_0x1c9580[_0x1da518],_0x1c9580[_0x3444ac],_0x1c9580[_0x35da2e],_0x1c9580[_0x510ccb]);}return _0x54bcf2['join']('');},'encodeString'(_0x225dff,_0x4af407){return this['HAS_NATIVE_SUPPORT']&&!_0x4af407?btoa(_0x225dff):this['encodeByteArray'](Wr(_0x225dff),_0x4af407);},'decodeString'(_0x1add1b,_0x823ee3){return this['HAS_NATIVE_SUPPORT']&&!_0x823ee3?atob(_0x1add1b):Za(this['decodeStringToByteArray'](_0x1add1b,_0x823ee3));},'decodeStringToByteArray'(_0x48a8f2,_0xd3548e){this['init_']();const _0xcb4156=_0xd3548e?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x111d39=[];for(let _0x185296=0x0;_0x185296<_0x48a8f2['length'];){const _0x19b191=_0xcb4156[_0x48a8f2['charAt'](_0x185296++)],_0x55465c=_0x185296<_0x48a8f2['length']?_0xcb4156[_0x48a8f2['charAt'](_0x185296)]:0x0;++_0x185296;const _0x5eb302=_0x185296<_0x48a8f2['length']?_0xcb4156[_0x48a8f2['charAt'](_0x185296)]:0x40;++_0x185296;const _0x519f82=_0x185296<_0x48a8f2['length']?_0xcb4156[_0x48a8f2['charAt'](_0x185296)]:0x40;if(++_0x185296,_0x19b191==null||_0x55465c==null||_0x5eb302==null||_0x519f82==null)throw new ec();const _0x403c48=_0x19b191<<0x2|_0x55465c>>0x4;if(_0x111d39['push'](_0x403c48),_0x5eb302!==0x40){const _0x4dfb90=_0x55465c<<0x4&0xf0|_0x5eb302>>0x2;if(_0x111d39['push'](_0x4dfb90),_0x519f82!==0x40){const _0x37d70a=_0x5eb302<<0x6&0xc0|_0x519f82;_0x111d39['push'](_0x37d70a);}}}return _0x111d39;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x265e5d=0x0;_0x265e5d<this['ENCODED_VALS']['length'];_0x265e5d++)this['byteToCharMap_'][_0x265e5d]=this['ENCODED_VALS']['charAt'](_0x265e5d),this['charToByteMap_'][this['byteToCharMap_'][_0x265e5d]]=_0x265e5d,this['byteToCharMapWebSafe_'][_0x265e5d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x265e5d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x265e5d]]=_0x265e5d,_0x265e5d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x265e5d)]=_0x265e5d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x265e5d)]=_0x265e5d);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x598d01){const _0x27ab4d=Wr(_0x598d01);return Di['encodeByteArray'](_0x27ab4d,!0x0);},an=function(_0xfa1912){return Br(_0xfa1912)['replace'](/\./g,'');},cn=function(_0x3bfc80){try{return Di['decodeString'](_0x3bfc80,!0x0);}catch(_0x44216d){console['error']('base64Decode\x20failed:\x20',_0x44216d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0xa4a6b6){return Vr(void 0x0,_0xa4a6b6);}function Vr(_0x57889f,_0x36558a){if(!(_0x36558a instanceof Object))return _0x36558a;switch(_0x36558a['constructor']){case Date:const _0x441843=_0x36558a;return new Date(_0x441843['getTime']());case Object:_0x57889f===void 0x0&&(_0x57889f={});break;case Array:_0x57889f=[];break;default:return _0x36558a;}for(const _0x1d7105 in _0x36558a)!_0x36558a['hasOwnProperty'](_0x1d7105)||!nc(_0x1d7105)||(_0x57889f[_0x1d7105]=Vr(_0x57889f[_0x1d7105],_0x36558a[_0x1d7105]));return _0x57889f;}function nc(_0x28187a){return _0x28187a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x1cbcbf=As['__FIREBASE_DEFAULTS__'];if(_0x1cbcbf)return JSON['parse'](_0x1cbcbf);},oc=()=>{if(typeof document>'u')return;let _0x56474c;try{_0x56474c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xb0dd2f=_0x56474c&&cn(_0x56474c[0x1]);return _0xb0dd2f&&JSON['parse'](_0xb0dd2f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x599b02){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x599b02);return;}},Hr=_0x54959c=>{var _0x21ec5d,_0x464ea8;return(_0x464ea8=(_0x21ec5d=Mi())==null?void 0x0:_0x21ec5d['emulatorHosts'])==null?void 0x0:_0x464ea8[_0x54959c];},ac=_0x3eaa5f=>{const _0x40331b=Hr(_0x3eaa5f);if(!_0x40331b)return;const _0x3430cb=_0x40331b['lastIndexOf'](':');if(_0x3430cb<=0x0||_0x3430cb+0x1===_0x40331b['length'])throw new Error('Invalid\x20host\x20'+_0x40331b+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x56c4dd=parseInt(_0x40331b['substring'](_0x3430cb+0x1),0xa);return _0x40331b[0x0]==='['?[_0x40331b['substring'](0x1,_0x3430cb-0x1),_0x56c4dd]:[_0x40331b['substring'](0x0,_0x3430cb),_0x56c4dd];},$r=()=>{var _0x13b656;return(_0x13b656=Mi())==null?void 0x0:_0x13b656['config'];},Gr=_0x376af9=>{var _0x1f42eb;return(_0x1f42eb=Mi())==null?void 0x0:_0x1f42eb['_'+_0x376af9];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x48d93b,_0x297fc6)=>{this['resolve']=_0x48d93b,this['reject']=_0x297fc6;});}['wrapCallback'](_0x1af269){return(_0x3cb1a6,_0x5a1747)=>{_0x3cb1a6?this['reject'](_0x3cb1a6):this['resolve'](_0x5a1747),typeof _0x1af269=='function'&&(this['promise']['catch'](()=>{}),_0x1af269['length']===0x1?_0x1af269(_0x3cb1a6):_0x1af269(_0x3cb1a6,_0x5a1747));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x76a77e,_0x33cd82){if(_0x76a77e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x2c15c8={'alg':'none','type':'JWT'},_0x1067ca=_0x33cd82||'demo-project',_0x53d542=_0x76a77e['iat']||0x0,_0x14d9c1=_0x76a77e['sub']||_0x76a77e['user_id'];if(!_0x14d9c1)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3d04b4={'iss':'https://securetoken.google.com/'+_0x1067ca,'aud':_0x1067ca,'iat':_0x53d542,'exp':_0x53d542+0xe10,'auth_time':_0x53d542,'sub':_0x14d9c1,'user_id':_0x14d9c1,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x76a77e};return[an(JSON['stringify'](_0x2c15c8)),an(JSON['stringify'](_0x3d04b4)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x24a0dd=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x24a0dd=='object'&&_0x24a0dd['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1d20c6=W();return _0x1d20c6['indexOf']('MSIE\x20')>=0x0||_0x1d20c6['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x309447,_0x1bfc41)=>{try{let _0x8cafe2=!0x0;const _0x3c6f70='validate-browser-context-for-indexeddb-analytics-module',_0x5c8e6f=self['indexedDB']['open'](_0x3c6f70);_0x5c8e6f['onsuccess']=()=>{_0x5c8e6f['result']['close'](),_0x8cafe2||self['indexedDB']['deleteDatabase'](_0x3c6f70),_0x309447(!0x0);},_0x5c8e6f['onupgradeneeded']=()=>{_0x8cafe2=!0x1;},_0x5c8e6f['onerror']=()=>{var _0x119527;_0x1bfc41(((_0x119527=_0x5c8e6f['error'])==null?void 0x0:_0x119527['message'])||'');};}catch(_0x568355){_0x1bfc41(_0x568355);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x535c65,_0x5bfcd9,_0x249fb4){super(_0x5bfcd9),this['code']=_0x535c65,this['customData']=_0x249fb4,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0xcd980f,_0x3d550a,_0x341307){this['service']=_0xcd980f,this['serviceName']=_0x3d550a,this['errors']=_0x341307;}['create'](_0x262d3d,..._0x31d3b2){const _0x830c18=_0x31d3b2[0x0]||{},_0x44c02b=this['service']+'/'+_0x262d3d,_0x2166b5=this['errors'][_0x262d3d],_0x553367=_0x2166b5?gc(_0x2166b5,_0x830c18):'Error',_0xa6eeac=this['serviceName']+':\x20'+_0x553367+'\x20('+_0x44c02b+').';return new Se(_0x44c02b,_0xa6eeac,_0x830c18);}}function gc(_0x469242,_0x3bee37){return _0x469242['replace'](mc,(_0x1cf65d,_0x2e7ee3)=>{const _0xc35140=_0x3bee37[_0x2e7ee3];return _0xc35140!=null?String(_0xc35140):'<'+_0x2e7ee3+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4da1c9){return JSON['parse'](_0x4da1c9);}function O(_0x5335e6){return JSON['stringify'](_0x5335e6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xd30227){let _0x34290a={},_0x1c3c63={},_0x32e117={},_0x385b16='';try{const _0x39d49c=_0xd30227['split']('.');_0x34290a=bt(cn(_0x39d49c[0x0])||''),_0x1c3c63=bt(cn(_0x39d49c[0x1])||''),_0x385b16=_0x39d49c[0x2],_0x32e117=_0x1c3c63['d']||{},delete _0x1c3c63['d'];}catch{}return{'header':_0x34290a,'claims':_0x1c3c63,'data':_0x32e117,'signature':_0x385b16};},yc=function(_0x5f1f5c){const _0x4d3886=zr(_0x5f1f5c),_0x40b48f=_0x4d3886['claims'];return!!_0x40b48f&&typeof _0x40b48f=='object'&&_0x40b48f['hasOwnProperty']('iat');},vc=function(_0x459732){const _0x5d2911=zr(_0x459732)['claims'];return typeof _0x5d2911=='object'&&_0x5d2911['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x59d921,_0x483143){return Object['prototype']['hasOwnProperty']['call'](_0x59d921,_0x483143);}function Oe(_0x2ea95a,_0x1934db){if(Object['prototype']['hasOwnProperty']['call'](_0x2ea95a,_0x1934db))return _0x2ea95a[_0x1934db];}function hi(_0x4a6e1e){for(const _0xeaaf07 in _0x4a6e1e)if(Object['prototype']['hasOwnProperty']['call'](_0x4a6e1e,_0xeaaf07))return!0x1;return!0x0;}function ln(_0x309aab,_0x1928fb,_0x2fbc5d){const _0x5a1672={};for(const _0xfac5dc in _0x309aab)Object['prototype']['hasOwnProperty']['call'](_0x309aab,_0xfac5dc)&&(_0x5a1672[_0xfac5dc]=_0x1928fb['call'](_0x2fbc5d,_0x309aab[_0xfac5dc],_0xfac5dc,_0x309aab));return _0x5a1672;}function De(_0x1ab9c6,_0x4062e8){if(_0x1ab9c6===_0x4062e8)return!0x0;const _0x18be35=Object['keys'](_0x1ab9c6),_0x29dd60=Object['keys'](_0x4062e8);for(const _0x13bb51 of _0x18be35){if(!_0x29dd60['includes'](_0x13bb51))return!0x1;const _0x4d4520=_0x1ab9c6[_0x13bb51],_0x52540b=_0x4062e8[_0x13bb51];if(ks(_0x4d4520)&&ks(_0x52540b)){if(!De(_0x4d4520,_0x52540b))return!0x1;}else{if(_0x4d4520!==_0x52540b)return!0x1;}}for(const _0x64dd20 of _0x29dd60)if(!_0x18be35['includes'](_0x64dd20))return!0x1;return!0x0;}function ks(_0x2cf619){return _0x2cf619!==null&&typeof _0x2cf619=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x6fa37a){const _0x1f29e8=[];for(const [_0x45b937,_0x1a2d2c]of Object['entries'](_0x6fa37a))Array['isArray'](_0x1a2d2c)?_0x1a2d2c['forEach'](_0x1e262b=>{_0x1f29e8['push'](encodeURIComponent(_0x45b937)+'='+encodeURIComponent(_0x1e262b));}):_0x1f29e8['push'](encodeURIComponent(_0x45b937)+'='+encodeURIComponent(_0x1a2d2c));return _0x1f29e8['length']?'&'+_0x1f29e8['join']('&'):'';}function yt(_0x3b60eb){const _0x54fb96={};return _0x3b60eb['replace'](/^\?/,'')['split']('&')['forEach'](_0x4e543d=>{if(_0x4e543d){const [_0x344a3a,_0x6ccf7f]=_0x4e543d['split']('=');_0x54fb96[decodeURIComponent(_0x344a3a)]=decodeURIComponent(_0x6ccf7f);}}),_0x54fb96;}function vt(_0x4ea45a){const _0x1513b9=_0x4ea45a['indexOf']('?');if(!_0x1513b9)return'';const _0x5be01d=_0x4ea45a['indexOf']('#',_0x1513b9);return _0x4ea45a['substring'](_0x1513b9,_0x5be01d>0x0?_0x5be01d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1f2bef=0x1;_0x1f2bef<this['blockSize'];++_0x1f2bef)this['pad_'][_0x1f2bef]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x101c9d,_0x1b175c){_0x1b175c||(_0x1b175c=0x0);const _0x43e3f7=this['W_'];if(typeof _0x101c9d=='string'){for(let _0x38f717=0x0;_0x38f717<0x10;_0x38f717++)_0x43e3f7[_0x38f717]=_0x101c9d['charCodeAt'](_0x1b175c)<<0x18|_0x101c9d['charCodeAt'](_0x1b175c+0x1)<<0x10|_0x101c9d['charCodeAt'](_0x1b175c+0x2)<<0x8|_0x101c9d['charCodeAt'](_0x1b175c+0x3),_0x1b175c+=0x4;}else{for(let _0x5419c5=0x0;_0x5419c5<0x10;_0x5419c5++)_0x43e3f7[_0x5419c5]=_0x101c9d[_0x1b175c]<<0x18|_0x101c9d[_0x1b175c+0x1]<<0x10|_0x101c9d[_0x1b175c+0x2]<<0x8|_0x101c9d[_0x1b175c+0x3],_0x1b175c+=0x4;}for(let _0x104ddc=0x10;_0x104ddc<0x50;_0x104ddc++){const _0x490b52=_0x43e3f7[_0x104ddc-0x3]^_0x43e3f7[_0x104ddc-0x8]^_0x43e3f7[_0x104ddc-0xe]^_0x43e3f7[_0x104ddc-0x10];_0x43e3f7[_0x104ddc]=(_0x490b52<<0x1|_0x490b52>>>0x1f)&0xffffffff;}let _0x4c40af=this['chain_'][0x0],_0x3b0ece=this['chain_'][0x1],_0x15730f=this['chain_'][0x2],_0x5e9429=this['chain_'][0x3],_0x4a9624=this['chain_'][0x4],_0x551b14,_0x5654a2;for(let _0x9db965=0x0;_0x9db965<0x50;_0x9db965++){_0x9db965<0x28?_0x9db965<0x14?(_0x551b14=_0x5e9429^_0x3b0ece&(_0x15730f^_0x5e9429),_0x5654a2=0x5a827999):(_0x551b14=_0x3b0ece^_0x15730f^_0x5e9429,_0x5654a2=0x6ed9eba1):_0x9db965<0x3c?(_0x551b14=_0x3b0ece&_0x15730f|_0x5e9429&(_0x3b0ece|_0x15730f),_0x5654a2=0x8f1bbcdc):(_0x551b14=_0x3b0ece^_0x15730f^_0x5e9429,_0x5654a2=0xca62c1d6);const _0x4c3382=(_0x4c40af<<0x5|_0x4c40af>>>0x1b)+_0x551b14+_0x4a9624+_0x5654a2+_0x43e3f7[_0x9db965]&0xffffffff;_0x4a9624=_0x5e9429,_0x5e9429=_0x15730f,_0x15730f=(_0x3b0ece<<0x1e|_0x3b0ece>>>0x2)&0xffffffff,_0x3b0ece=_0x4c40af,_0x4c40af=_0x4c3382;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4c40af&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3b0ece&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x15730f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5e9429&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4a9624&0xffffffff;}['update'](_0xedae10,_0x226a49){if(_0xedae10==null)return;_0x226a49===void 0x0&&(_0x226a49=_0xedae10['length']);const _0x2d9fd4=_0x226a49-this['blockSize'];let _0x39e402=0x0;const _0x37c2aa=this['buf_'];let _0x437f85=this['inbuf_'];for(;_0x39e402<_0x226a49;){if(_0x437f85===0x0){for(;_0x39e402<=_0x2d9fd4;)this['compress_'](_0xedae10,_0x39e402),_0x39e402+=this['blockSize'];}if(typeof _0xedae10=='string'){for(;_0x39e402<_0x226a49;)if(_0x37c2aa[_0x437f85]=_0xedae10['charCodeAt'](_0x39e402),++_0x437f85,++_0x39e402,_0x437f85===this['blockSize']){this['compress_'](_0x37c2aa),_0x437f85=0x0;break;}}else{for(;_0x39e402<_0x226a49;)if(_0x37c2aa[_0x437f85]=_0xedae10[_0x39e402],++_0x437f85,++_0x39e402,_0x437f85===this['blockSize']){this['compress_'](_0x37c2aa),_0x437f85=0x0;break;}}}this['inbuf_']=_0x437f85,this['total_']+=_0x226a49;}['digest'](){const _0x25ed68=[];let _0x3156c0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x513957=this['blockSize']-0x1;_0x513957>=0x38;_0x513957--)this['buf_'][_0x513957]=_0x3156c0&0xff,_0x3156c0/=0x100;this['compress_'](this['buf_']);let _0x5b9636=0x0;for(let _0x2c222b=0x0;_0x2c222b<0x5;_0x2c222b++)for(let _0x2d30da=0x18;_0x2d30da>=0x0;_0x2d30da-=0x8)_0x25ed68[_0x5b9636]=this['chain_'][_0x2c222b]>>_0x2d30da&0xff,++_0x5b9636;return _0x25ed68;}}function Ic(_0x3dc7d1,_0x35096a){const _0x484d63=new wc(_0x3dc7d1,_0x35096a);return _0x484d63['subscribe']['bind'](_0x484d63);}class wc{constructor(_0x4d0b7d,_0x88a984){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x88a984,this['task']['then'](()=>{_0x4d0b7d(this);})['catch'](_0x3e3a3b=>{this['error'](_0x3e3a3b);});}['next'](_0x280dac){this['forEachObserver'](_0x371e35=>{_0x371e35['next'](_0x280dac);});}['error'](_0x3222bf){this['forEachObserver'](_0x52ce11=>{_0x52ce11['error'](_0x3222bf);}),this['close'](_0x3222bf);}['complete'](){this['forEachObserver'](_0x2c8437=>{_0x2c8437['complete']();}),this['close']();}['subscribe'](_0x25c4ca,_0x5a63b7,_0x38c72d){let _0x34a569;if(_0x25c4ca===void 0x0&&_0x5a63b7===void 0x0&&_0x38c72d===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x25c4ca,['next','error','complete'])?_0x34a569=_0x25c4ca:_0x34a569={'next':_0x25c4ca,'error':_0x5a63b7,'complete':_0x38c72d},_0x34a569['next']===void 0x0&&(_0x34a569['next']=Qn),_0x34a569['error']===void 0x0&&(_0x34a569['error']=Qn),_0x34a569['complete']===void 0x0&&(_0x34a569['complete']=Qn);const _0x55ddd2=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x34a569['error'](this['finalError']):_0x34a569['complete']();}catch{}}),this['observers']['push'](_0x34a569),_0x55ddd2;}['unsubscribeOne'](_0x544b32){this['observers']===void 0x0||this['observers'][_0x544b32]===void 0x0||(delete this['observers'][_0x544b32],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x33ffd4){if(!this['finalized']){for(let _0x31d177=0x0;_0x31d177<this['observers']['length'];_0x31d177++)this['sendOne'](_0x31d177,_0x33ffd4);}}['sendOne'](_0x547009,_0x11a467){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x547009]!==void 0x0)try{_0x11a467(this['observers'][_0x547009]);}catch(_0x21f55d){typeof console<'u'&&console['error']&&console['error'](_0x21f55d);}});}['close'](_0x3ad389){this['finalized']||(this['finalized']=!0x0,_0x3ad389!==void 0x0&&(this['finalError']=_0x3ad389),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x20be20,_0x12e9e4){if(typeof _0x20be20!='object'||_0x20be20===null)return!0x1;for(const _0x469ed8 of _0x12e9e4)if(_0x469ed8 in _0x20be20&&typeof _0x20be20[_0x469ed8]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x4853a9,_0x4ada18){return _0x4853a9+'\x20failed:\x20'+_0x4ada18+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2b6e29){const _0x69633f=[];let _0x45da3c=0x0;for(let _0x35e1a1=0x0;_0x35e1a1<_0x2b6e29['length'];_0x35e1a1++){let _0x257e07=_0x2b6e29['charCodeAt'](_0x35e1a1);if(_0x257e07>=0xd800&&_0x257e07<=0xdbff){const _0xa75d39=_0x257e07-0xd800;_0x35e1a1++,f(_0x35e1a1<_0x2b6e29['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5f3520=_0x2b6e29['charCodeAt'](_0x35e1a1)-0xdc00;_0x257e07=0x10000+(_0xa75d39<<0xa)+_0x5f3520;}_0x257e07<0x80?_0x69633f[_0x45da3c++]=_0x257e07:_0x257e07<0x800?(_0x69633f[_0x45da3c++]=_0x257e07>>0x6|0xc0,_0x69633f[_0x45da3c++]=_0x257e07&0x3f|0x80):_0x257e07<0x10000?(_0x69633f[_0x45da3c++]=_0x257e07>>0xc|0xe0,_0x69633f[_0x45da3c++]=_0x257e07>>0x6&0x3f|0x80,_0x69633f[_0x45da3c++]=_0x257e07&0x3f|0x80):(_0x69633f[_0x45da3c++]=_0x257e07>>0x12|0xf0,_0x69633f[_0x45da3c++]=_0x257e07>>0xc&0x3f|0x80,_0x69633f[_0x45da3c++]=_0x257e07>>0x6&0x3f|0x80,_0x69633f[_0x45da3c++]=_0x257e07&0x3f|0x80);}return _0x69633f;},Pn=function(_0x4cf458){let _0x8a4fb4=0x0;for(let _0x5e5134=0x0;_0x5e5134<_0x4cf458['length'];_0x5e5134++){const _0x3a19c4=_0x4cf458['charCodeAt'](_0x5e5134);_0x3a19c4<0x80?_0x8a4fb4++:_0x3a19c4<0x800?_0x8a4fb4+=0x2:_0x3a19c4>=0xd800&&_0x3a19c4<=0xdbff?(_0x8a4fb4+=0x4,_0x5e5134++):_0x8a4fb4+=0x3;}return _0x8a4fb4;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xc796df){return _0xc796df&&_0xc796df['_delegate']?_0xc796df['_delegate']:_0xc796df;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x5b48a2){try{return(_0x5b48a2['startsWith']('http://')||_0x5b48a2['startsWith']('https://')?new URL(_0x5b48a2)['hostname']:_0x5b48a2)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1fa233){return(await fetch(_0x1fa233,{'credentials':'include'}))['ok'];}class Me{constructor(_0x2984d7,_0x22094f,_0x46fd26){this['name']=_0x2984d7,this['instanceFactory']=_0x22094f,this['type']=_0x46fd26,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5ec1ff){return this['instantiationMode']=_0x5ec1ff,this;}['setMultipleInstances'](_0x579588){return this['multipleInstances']=_0x579588,this;}['setServiceProps'](_0x1cb0a2){return this['serviceProps']=_0x1cb0a2,this;}['setInstanceCreatedCallback'](_0x45ecbb){return this['onInstanceCreated']=_0x45ecbb,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xb7a7f1,_0xeb93dc){this['name']=_0xb7a7f1,this['container']=_0xeb93dc,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x451880){const _0x4f9a21=this['normalizeInstanceIdentifier'](_0x451880);if(!this['instancesDeferred']['has'](_0x4f9a21)){const _0x43e7cf=new Ve();if(this['instancesDeferred']['set'](_0x4f9a21,_0x43e7cf),this['isInitialized'](_0x4f9a21)||this['shouldAutoInitialize']())try{const _0x1a807c=this['getOrInitializeService']({'instanceIdentifier':_0x4f9a21});_0x1a807c&&_0x43e7cf['resolve'](_0x1a807c);}catch{}}return this['instancesDeferred']['get'](_0x4f9a21)['promise'];}['getImmediate'](_0x685085){const _0x3d211a=this['normalizeInstanceIdentifier'](_0x685085==null?void 0x0:_0x685085['identifier']),_0x14c0a5=(_0x685085==null?void 0x0:_0x685085['optional'])??!0x1;if(this['isInitialized'](_0x3d211a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3d211a});}catch(_0x1a41c2){if(_0x14c0a5)return null;throw _0x1a41c2;}else{if(_0x14c0a5)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1a5470){if(_0x1a5470['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1a5470['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1a5470,!!this['shouldAutoInitialize']()){if(Rc(_0x1a5470))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0xe49c03,_0x469434]of this['instancesDeferred']['entries']()){const _0x225b3c=this['normalizeInstanceIdentifier'](_0xe49c03);try{const _0x3b0958=this['getOrInitializeService']({'instanceIdentifier':_0x225b3c});_0x469434['resolve'](_0x3b0958);}catch{}}}}['clearInstance'](_0x33a55a=ke){this['instancesDeferred']['delete'](_0x33a55a),this['instancesOptions']['delete'](_0x33a55a),this['instances']['delete'](_0x33a55a);}async['delete'](){const _0x1ba9a7=Array['from'](this['instances']['values']());await Promise['all']([..._0x1ba9a7['filter'](_0x453068=>'INTERNAL'in _0x453068)['map'](_0x4e69e4=>_0x4e69e4['INTERNAL']['delete']()),..._0x1ba9a7['filter'](_0x5a1952=>'_delete'in _0x5a1952)['map'](_0x4bfa0a=>_0x4bfa0a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1c4231=ke){return this['instances']['has'](_0x1c4231);}['getOptions'](_0x4e8e02=ke){return this['instancesOptions']['get'](_0x4e8e02)||{};}['initialize'](_0x4488b6={}){const {options:_0x195444={}}=_0x4488b6,_0x8e5457=this['normalizeInstanceIdentifier'](_0x4488b6['instanceIdentifier']);if(this['isInitialized'](_0x8e5457))throw Error(this['name']+'('+_0x8e5457+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xe5183c=this['getOrInitializeService']({'instanceIdentifier':_0x8e5457,'options':_0x195444});for(const [_0x69c59c,_0x5a40ee]of this['instancesDeferred']['entries']()){const _0x315cd8=this['normalizeInstanceIdentifier'](_0x69c59c);_0x8e5457===_0x315cd8&&_0x5a40ee['resolve'](_0xe5183c);}return _0xe5183c;}['onInit'](_0x4b6e72,_0x316f08){const _0x5d1026=this['normalizeInstanceIdentifier'](_0x316f08),_0x3dbd45=this['onInitCallbacks']['get'](_0x5d1026)??new Set();_0x3dbd45['add'](_0x4b6e72),this['onInitCallbacks']['set'](_0x5d1026,_0x3dbd45);const _0x396b32=this['instances']['get'](_0x5d1026);return _0x396b32&&_0x4b6e72(_0x396b32,_0x5d1026),()=>{_0x3dbd45['delete'](_0x4b6e72);};}['invokeOnInitCallbacks'](_0x10aa66,_0x22d629){const _0x11e4fc=this['onInitCallbacks']['get'](_0x22d629);if(_0x11e4fc){for(const _0x44e2e6 of _0x11e4fc)try{_0x44e2e6(_0x10aa66,_0x22d629);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xf40c5a,options:_0x2d36a9={}}){let _0x4a0f65=this['instances']['get'](_0xf40c5a);if(!_0x4a0f65&&this['component']&&(_0x4a0f65=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xf40c5a),'options':_0x2d36a9}),this['instances']['set'](_0xf40c5a,_0x4a0f65),this['instancesOptions']['set'](_0xf40c5a,_0x2d36a9),this['invokeOnInitCallbacks'](_0x4a0f65,_0xf40c5a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xf40c5a,_0x4a0f65);}catch{}return _0x4a0f65||null;}['normalizeInstanceIdentifier'](_0x359d90=ke){return this['component']?this['component']['multipleInstances']?_0x359d90:ke:_0x359d90;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x4bdd8c){return _0x4bdd8c===ke?void 0x0:_0x4bdd8c;}function Rc(_0x5d2f6e){return _0x5d2f6e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1dd4e5){this['name']=_0x1dd4e5,this['providers']=new Map();}['addComponent'](_0x57150f){const _0x3a505c=this['getProvider'](_0x57150f['name']);if(_0x3a505c['isComponentSet']())throw new Error('Component\x20'+_0x57150f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3a505c['setComponent'](_0x57150f);}['addOrOverwriteComponent'](_0x5c35bb){this['getProvider'](_0x5c35bb['name'])['isComponentSet']()&&this['providers']['delete'](_0x5c35bb['name']),this['addComponent'](_0x5c35bb);}['getProvider'](_0x1f9c55){if(this['providers']['has'](_0x1f9c55))return this['providers']['get'](_0x1f9c55);const _0x1c7235=new Sc(_0x1f9c55,this);return this['providers']['set'](_0x1f9c55,_0x1c7235),_0x1c7235;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x403450){_0x403450[_0x403450['DEBUG']=0x0]='DEBUG',_0x403450[_0x403450['VERBOSE']=0x1]='VERBOSE',_0x403450[_0x403450['INFO']=0x2]='INFO',_0x403450[_0x403450['WARN']=0x3]='WARN',_0x403450[_0x403450['ERROR']=0x4]='ERROR',_0x403450[_0x403450['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xe4af1a,_0x361f70,..._0x21504d)=>{if(_0x361f70<_0xe4af1a['logLevel'])return;const _0x4269ed=new Date()['toISOString'](),_0x285979=Pc[_0x361f70];if(_0x285979)console[_0x285979]('['+_0x4269ed+']\x20\x20'+_0xe4af1a['name']+':',..._0x21504d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x361f70+')');};class xi{constructor(_0x2bdc97){this['name']=_0x2bdc97,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x399009){if(!(_0x399009 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x399009+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x399009;}['setLogLevel'](_0x9a836e){this['_logLevel']=typeof _0x9a836e=='string'?kc[_0x9a836e]:_0x9a836e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5def66){if(typeof _0x5def66!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5def66;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5c5f68){this['_userLogHandler']=_0x5c5f68;}['debug'](..._0x17b812){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x17b812),this['_logHandler'](this,T['DEBUG'],..._0x17b812);}['log'](..._0x111cc8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x111cc8),this['_logHandler'](this,T['VERBOSE'],..._0x111cc8);}['info'](..._0x414131){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x414131),this['_logHandler'](this,T['INFO'],..._0x414131);}['warn'](..._0x8da721){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x8da721),this['_logHandler'](this,T['WARN'],..._0x8da721);}['error'](..._0x5b8761){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5b8761),this['_logHandler'](this,T['ERROR'],..._0x5b8761);}}const Dc=(_0x25bf6a,_0x1ed2ce)=>_0x1ed2ce['some'](_0x3099e9=>_0x25bf6a instanceof _0x3099e9);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x55ba25){const _0x559b1c=new Promise((_0x197baf,_0x269112)=>{const _0x5920dc=()=>{_0x55ba25['removeEventListener']('success',_0x2ff49c),_0x55ba25['removeEventListener']('error',_0x53f452);},_0x2ff49c=()=>{_0x197baf(_e(_0x55ba25['result'])),_0x5920dc();},_0x53f452=()=>{_0x269112(_0x55ba25['error']),_0x5920dc();};_0x55ba25['addEventListener']('success',_0x2ff49c),_0x55ba25['addEventListener']('error',_0x53f452);});return _0x559b1c['then'](_0x311bb3=>{_0x311bb3 instanceof IDBCursor&&Kr['set'](_0x311bb3,_0x55ba25);})['catch'](()=>{}),Fi['set'](_0x559b1c,_0x55ba25),_0x559b1c;}function Fc(_0xddacde){if(ui['has'](_0xddacde))return;const _0x5a44dc=new Promise((_0x54f6dc,_0x562333)=>{const _0x27aa12=()=>{_0xddacde['removeEventListener']('complete',_0x5e3cfc),_0xddacde['removeEventListener']('error',_0x47f2cf),_0xddacde['removeEventListener']('abort',_0x47f2cf);},_0x5e3cfc=()=>{_0x54f6dc(),_0x27aa12();},_0x47f2cf=()=>{_0x562333(_0xddacde['error']||new DOMException('AbortError','AbortError')),_0x27aa12();};_0xddacde['addEventListener']('complete',_0x5e3cfc),_0xddacde['addEventListener']('error',_0x47f2cf),_0xddacde['addEventListener']('abort',_0x47f2cf);});ui['set'](_0xddacde,_0x5a44dc);}let di={'get'(_0x136264,_0x4c24e8,_0x5c477e){if(_0x136264 instanceof IDBTransaction){if(_0x4c24e8==='done')return ui['get'](_0x136264);if(_0x4c24e8==='objectStoreNames')return _0x136264['objectStoreNames']||Yr['get'](_0x136264);if(_0x4c24e8==='store')return _0x5c477e['objectStoreNames'][0x1]?void 0x0:_0x5c477e['objectStore'](_0x5c477e['objectStoreNames'][0x0]);}return _e(_0x136264[_0x4c24e8]);},'set'(_0x59f86c,_0x4f2ae8,_0xf082d){return _0x59f86c[_0x4f2ae8]=_0xf082d,!0x0;},'has'(_0x46a803,_0x2cb03e){return _0x46a803 instanceof IDBTransaction&&(_0x2cb03e==='done'||_0x2cb03e==='store')?!0x0:_0x2cb03e in _0x46a803;}};function Uc(_0x42d93d){di=_0x42d93d(di);}function Wc(_0x333ccb){return _0x333ccb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4c844f,..._0x9435fc){const _0x310e4b=_0x333ccb['call'](Xn(this),_0x4c844f,..._0x9435fc);return Yr['set'](_0x310e4b,_0x4c844f['sort']?_0x4c844f['sort']():[_0x4c844f]),_e(_0x310e4b);}:Lc()['includes'](_0x333ccb)?function(..._0x14c1ed){return _0x333ccb['apply'](Xn(this),_0x14c1ed),_e(Kr['get'](this));}:function(..._0x451074){return _e(_0x333ccb['apply'](Xn(this),_0x451074));};}function Bc(_0x19e67c){return typeof _0x19e67c=='function'?Wc(_0x19e67c):(_0x19e67c instanceof IDBTransaction&&Fc(_0x19e67c),Dc(_0x19e67c,Mc())?new Proxy(_0x19e67c,di):_0x19e67c);}function _e(_0x57d192){if(_0x57d192 instanceof IDBRequest)return xc(_0x57d192);if(Jn['has'](_0x57d192))return Jn['get'](_0x57d192);const _0x5c0698=Bc(_0x57d192);return _0x5c0698!==_0x57d192&&(Jn['set'](_0x57d192,_0x5c0698),Fi['set'](_0x5c0698,_0x57d192)),_0x5c0698;}const Xn=_0x17c80b=>Fi['get'](_0x17c80b);function Vc(_0x306a66,_0x250a2e,{blocked:_0x4a2664,upgrade:_0x79dd3f,blocking:_0x15b890,terminated:_0x2d16a3}={}){const _0xc1e913=indexedDB['open'](_0x306a66,_0x250a2e),_0x5e4d72=_e(_0xc1e913);return _0x79dd3f&&_0xc1e913['addEventListener']('upgradeneeded',_0x2ee0fd=>{_0x79dd3f(_e(_0xc1e913['result']),_0x2ee0fd['oldVersion'],_0x2ee0fd['newVersion'],_e(_0xc1e913['transaction']),_0x2ee0fd);}),_0x4a2664&&_0xc1e913['addEventListener']('blocked',_0x477a7a=>_0x4a2664(_0x477a7a['oldVersion'],_0x477a7a['newVersion'],_0x477a7a)),_0x5e4d72['then'](_0x2ea652=>{_0x2d16a3&&_0x2ea652['addEventListener']('close',()=>_0x2d16a3()),_0x15b890&&_0x2ea652['addEventListener']('versionchange',_0x4ea562=>_0x15b890(_0x4ea562['oldVersion'],_0x4ea562['newVersion'],_0x4ea562));})['catch'](()=>{}),_0x5e4d72;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2a9adb,_0x2fbe8d){if(!(_0x2a9adb instanceof IDBDatabase&&!(_0x2fbe8d in _0x2a9adb)&&typeof _0x2fbe8d=='string'))return;if(Zn['get'](_0x2fbe8d))return Zn['get'](_0x2fbe8d);const _0x48dcb3=_0x2fbe8d['replace'](/FromIndex$/,''),_0x500fcc=_0x2fbe8d!==_0x48dcb3,_0x27369b=$c['includes'](_0x48dcb3);if(!(_0x48dcb3 in(_0x500fcc?IDBIndex:IDBObjectStore)['prototype'])||!(_0x27369b||Hc['includes'](_0x48dcb3)))return;const _0x2008dd=async function(_0x6b3ce9,..._0x266b7c){const _0x2a8886=this['transaction'](_0x6b3ce9,_0x27369b?'readwrite':'readonly');let _0x113a01=_0x2a8886['store'];return _0x500fcc&&(_0x113a01=_0x113a01['index'](_0x266b7c['shift']())),(await Promise['all']([_0x113a01[_0x48dcb3](..._0x266b7c),_0x27369b&&_0x2a8886['done']]))[0x0];};return Zn['set'](_0x2fbe8d,_0x2008dd),_0x2008dd;}Uc(_0xdd0728=>({..._0xdd0728,'get':(_0x5b6874,_0xff1195,_0x2ee28b)=>Os(_0x5b6874,_0xff1195)||_0xdd0728['get'](_0x5b6874,_0xff1195,_0x2ee28b),'has':(_0x278a6f,_0x20630e)=>!!Os(_0x278a6f,_0x20630e)||_0xdd0728['has'](_0x278a6f,_0x20630e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x5d2613){this['container']=_0x5d2613;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x48d6a3=>{if(qc(_0x48d6a3)){const _0x358241=_0x48d6a3['getImmediate']();return _0x358241['library']+'/'+_0x358241['version'];}else return null;})['filter'](_0x4e4e7c=>_0x4e4e7c)['join']('\x20');}}function qc(_0xbc3432){const _0x2d5f72=_0xbc3432['getComponent']();return(_0x2d5f72==null?void 0x0:_0x2d5f72['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x43d0ea,_0x3452ce){try{_0x43d0ea['container']['addComponent'](_0x3452ce);}catch(_0x379253){re['debug']('Component\x20'+_0x3452ce['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x43d0ea['name'],_0x379253);}}function et(_0x2fd3fb){const _0x5eac35=_0x2fd3fb['name'];if(gi['has'](_0x5eac35))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5eac35+'.'),!0x1;gi['set'](_0x5eac35,_0x2fd3fb);for(const _0x52d919 of Le['values']())Ms(_0x52d919,_0x2fd3fb);for(const _0x10ea28 of _i['values']())Ms(_0x10ea28,_0x2fd3fb);return!0x0;}function Ui(_0x1750ac,_0x4c01a5){const _0x24aab5=_0x1750ac['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x24aab5&&_0x24aab5['triggerHeartbeat'](),_0x1750ac['container']['getProvider'](_0x4c01a5);}function H(_0x126f73){return _0x126f73==null?!0x1:_0x126f73['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x1810ff,_0x3398d6,_0x2d42e6){this['_isDeleted']=!0x1,this['_options']={..._0x1810ff},this['_config']={..._0x3398d6},this['_name']=_0x3398d6['name'],this['_automaticDataCollectionEnabled']=_0x3398d6['automaticDataCollectionEnabled'],this['_container']=_0x2d42e6,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x68da4d){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x68da4d;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x525bca){this['_isDeleted']=_0x525bca;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x57f342,_0xd34fd={}){let _0x345c3c=_0x57f342;typeof _0xd34fd!='object'&&(_0xd34fd={'name':_0xd34fd});const _0x8faf60={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0xd34fd},_0x5a7fce=_0x8faf60['name'];if(typeof _0x5a7fce!='string'||!_0x5a7fce)throw ge['create']('bad-app-name',{'appName':String(_0x5a7fce)});if(_0x345c3c||(_0x345c3c=$r()),!_0x345c3c)throw ge['create']('no-options');const _0x4edd43=Le['get'](_0x5a7fce);if(_0x4edd43){if(De(_0x345c3c,_0x4edd43['options'])&&De(_0x8faf60,_0x4edd43['config']))return _0x4edd43;throw ge['create']('duplicate-app',{'appName':_0x5a7fce});}const _0x144fcf=new Ac(_0x5a7fce);for(const _0x4c81cf of gi['values']())_0x144fcf['addComponent'](_0x4c81cf);const _0x4d08fa=new Il(_0x345c3c,_0x8faf60,_0x144fcf);return Le['set'](_0x5a7fce,_0x4d08fa),_0x4d08fa;}function Qr(_0x50b546=pi){const _0x2d6b04=Le['get'](_0x50b546);if(!_0x2d6b04&&_0x50b546===pi&&$r())return wl();if(!_0x2d6b04)throw ge['create']('no-app',{'appName':_0x50b546});return _0x2d6b04;}function l_(){return Array['from'](Le['values']());}async function h_(_0x58d72e){let _0x1332fb=!0x1;const _0xe863af=_0x58d72e['name'];Le['has'](_0xe863af)?(_0x1332fb=!0x0,Le['delete'](_0xe863af)):_i['has'](_0xe863af)&&_0x58d72e['decRefCount']()<=0x0&&(_i['delete'](_0xe863af),_0x1332fb=!0x0),_0x1332fb&&(await Promise['all'](_0x58d72e['container']['getProviders']()['map'](_0x476fa9=>_0x476fa9['delete']())),_0x58d72e['isDeleted']=!0x0);}function me(_0x2ae0b4,_0x4f6928,_0x2bb89c){let _0x14eaa1=vl[_0x2ae0b4]??_0x2ae0b4;_0x2bb89c&&(_0x14eaa1+='-'+_0x2bb89c);const _0x17466c=_0x14eaa1['match'](/\s|\//),_0x3ce19e=_0x4f6928['match'](/\s|\//);if(_0x17466c||_0x3ce19e){const _0x3c5da9=['Unable\x20to\x20register\x20library\x20\x22'+_0x14eaa1+'\x22\x20with\x20version\x20\x22'+_0x4f6928+'\x22:'];_0x17466c&&_0x3c5da9['push']('library\x20name\x20\x22'+_0x14eaa1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x17466c&&_0x3ce19e&&_0x3c5da9['push']('and'),_0x3ce19e&&_0x3c5da9['push']('version\x20name\x20\x22'+_0x4f6928+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3c5da9['join']('\x20'));return;}et(new Me(_0x14eaa1+'-version',()=>({'library':_0x14eaa1,'version':_0x4f6928}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2b350a,_0x411422)=>{switch(_0x411422){case 0x0:try{_0x2b350a['createObjectStore'](Rt);}catch(_0x1b4171){console['warn'](_0x1b4171);}}}})['catch'](_0x5a1179=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5a1179['message']});})),ei;}async function Sl(_0x3a4a84){try{const _0x1df190=(await Jr())['transaction'](Rt),_0x5c1887=await _0x1df190['objectStore'](Rt)['get'](Xr(_0x3a4a84));return await _0x1df190['done'],_0x5c1887;}catch(_0x18db40){if(_0x18db40 instanceof Se)re['warn'](_0x18db40['message']);else{const _0x208cc2=ge['create']('idb-get',{'originalErrorMessage':_0x18db40==null?void 0x0:_0x18db40['message']});re['warn'](_0x208cc2['message']);}}}async function Ls(_0x15ed4e,_0x53cff5){try{const _0x37aaf2=(await Jr())['transaction'](Rt,'readwrite');await _0x37aaf2['objectStore'](Rt)['put'](_0x53cff5,Xr(_0x15ed4e)),await _0x37aaf2['done'];}catch(_0x210042){if(_0x210042 instanceof Se)re['warn'](_0x210042['message']);else{const _0x2cc4a7=ge['create']('idb-set',{'originalErrorMessage':_0x210042==null?void 0x0:_0x210042['message']});re['warn'](_0x2cc4a7['message']);}}}function Xr(_0x27f221){return _0x27f221['name']+'!'+_0x27f221['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x21d2fc){this['container']=_0x21d2fc,this['_heartbeatsCache']=null;const _0x2f7088=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2f7088),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5d569c=>(this['_heartbeatsCache']=_0x5d569c,_0x5d569c));}async['triggerHeartbeat'](){var _0x3f0aa5,_0x133e2b;try{const _0x2c8ab2=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x43919f=xs();if(((_0x3f0aa5=this['_heartbeatsCache'])==null?void 0x0:_0x3f0aa5['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x133e2b=this['_heartbeatsCache'])==null?void 0x0:_0x133e2b['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x43919f||this['_heartbeatsCache']['heartbeats']['some'](_0x5c8ff5=>_0x5c8ff5['date']===_0x43919f))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x43919f,'agent':_0x2c8ab2}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x4c8a79=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4c8a79,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x95def9){re['warn'](_0x95def9);}}async['getHeartbeatsHeader'](){var _0x57cf68;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x57cf68=this['_heartbeatsCache'])==null?void 0x0:_0x57cf68['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xc1d71c=xs(),{heartbeatsToSend:_0xd0bc5a,unsentEntries:_0x5343ce}=kl(this['_heartbeatsCache']['heartbeats']),_0x58337a=an(JSON['stringify']({'version':0x2,'heartbeats':_0xd0bc5a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xc1d71c,_0x5343ce['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5343ce,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x58337a;}catch(_0x9ef2fb){return re['warn'](_0x9ef2fb),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x411a43,_0x546238=bl){const _0x3ab9b9=[];let _0x220838=_0x411a43['slice']();for(const _0x549d22 of _0x411a43){const _0x2184d2=_0x3ab9b9['find'](_0x29fcb4=>_0x29fcb4['agent']===_0x549d22['agent']);if(_0x2184d2){if(_0x2184d2['dates']['push'](_0x549d22['date']),Fs(_0x3ab9b9)>_0x546238){_0x2184d2['dates']['pop']();break;}}else{if(_0x3ab9b9['push']({'agent':_0x549d22['agent'],'dates':[_0x549d22['date']]}),Fs(_0x3ab9b9)>_0x546238){_0x3ab9b9['pop']();break;}}_0x220838=_0x220838['slice'](0x1);}return{'heartbeatsToSend':_0x3ab9b9,'unsentEntries':_0x220838};}class Nl{constructor(_0x3e82e2){this['app']=_0x3e82e2,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5df2a4=await Sl(this['app']);return _0x5df2a4!=null&&_0x5df2a4['heartbeats']?_0x5df2a4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x218906){if(await this['_canUseIndexedDBPromise']){const _0x44c5f1=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x218906['lastSentHeartbeatDate']??_0x44c5f1['lastSentHeartbeatDate'],'heartbeats':_0x218906['heartbeats']});}else return;}async['add'](_0x498a8e){if(await this['_canUseIndexedDBPromise']){const _0x398b7b=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x498a8e['lastSentHeartbeatDate']??_0x398b7b['lastSentHeartbeatDate'],'heartbeats':[..._0x398b7b['heartbeats'],..._0x498a8e['heartbeats']]});}else return;}}function Fs(_0x1dcf62){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1dcf62}))['length'];}function Pl(_0x3dd894){if(_0x3dd894['length']===0x0)return-0x1;let _0xa400e2=0x0,_0x1bae70=_0x3dd894[0x0]['date'];for(let _0x5dd5fd=0x1;_0x5dd5fd<_0x3dd894['length'];_0x5dd5fd++)_0x3dd894[_0x5dd5fd]['date']<_0x1bae70&&(_0x1bae70=_0x3dd894[_0x5dd5fd]['date'],_0xa400e2=_0x5dd5fd);return _0xa400e2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x161648){et(new Me('platform-logger',_0x3ff90f=>new Gc(_0x3ff90f),'PRIVATE')),et(new Me('heartbeat',_0x1e1360=>new Al(_0x1e1360),'PRIVATE')),me(fi,Ds,_0x161648),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x4d1134){Zr=_0x4d1134;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x2d259c){this['domStorage_']=_0x2d259c,this['prefix_']='firebase:';}['set'](_0x331ba0,_0x486528){_0x486528==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x331ba0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x331ba0),O(_0x486528));}['get'](_0xb7c744){const _0x489225=this['domStorage_']['getItem'](this['prefixedName_'](_0xb7c744));return _0x489225==null?null:bt(_0x489225);}['remove'](_0x124e75){this['domStorage_']['removeItem'](this['prefixedName_'](_0x124e75));}['prefixedName_'](_0x45369e){return this['prefix_']+_0x45369e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4bd0fc,_0x216b5f){_0x216b5f==null?delete this['cache_'][_0x4bd0fc]:this['cache_'][_0x4bd0fc]=_0x216b5f;}['get'](_0xfa9c20){return Y(this['cache_'],_0xfa9c20)?this['cache_'][_0xfa9c20]:null;}['remove'](_0x1a5db8){delete this['cache_'][_0x1a5db8];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0xbd83d4){try{if(typeof window<'u'&&typeof window[_0xbd83d4]<'u'){const _0xa8c1d9=window[_0xbd83d4];return _0xa8c1d9['setItem']('firebase:sentinel','cache'),_0xa8c1d9['removeItem']('firebase:sentinel'),new xl(_0xa8c1d9);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x201593=0x1;return function(){return _0x201593++;};}()),no=function(_0x1395fe){const _0x26c00b=Tc(_0x1395fe),_0x1254e9=new Ec();_0x1254e9['update'](_0x26c00b);const _0x3b71b3=_0x1254e9['digest']();return Di['encodeByteArray'](_0x3b71b3);},Bt=function(..._0x525d76){let _0x265ab0='';for(let _0x4cf792=0x0;_0x4cf792<_0x525d76['length'];_0x4cf792++){const _0x379cbd=_0x525d76[_0x4cf792];Array['isArray'](_0x379cbd)||_0x379cbd&&typeof _0x379cbd=='object'&&typeof _0x379cbd['length']=='number'?_0x265ab0+=Bt['apply'](null,_0x379cbd):typeof _0x379cbd=='object'?_0x265ab0+=O(_0x379cbd):_0x265ab0+=_0x379cbd,_0x265ab0+='\x20';}return _0x265ab0;};let Et=null,Vs=!0x0;const Wl=function(_0x55881c,_0x11d6f2){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1b1763){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x28c0f1=Bt['apply'](null,_0x1b1763);Et(_0x28c0f1);}},Vt=function(_0x105d57){return function(..._0x368a78){L(_0x105d57,..._0x368a78);};},mi=function(..._0xbbf99b){const _0xfcf457='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0xbbf99b);Qe['error'](_0xfcf457);},oe=function(..._0x3e59e4){const _0x828c7f='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x3e59e4);throw Qe['error'](_0x828c7f),new Error(_0x828c7f);},U=function(..._0x4c38fc){const _0x56145d='FIREBASE\x20WARNING:\x20'+Bt(..._0x4c38fc);Qe['warn'](_0x56145d);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x2a4dc4){return typeof _0x2a4dc4=='number'&&(_0x2a4dc4!==_0x2a4dc4||_0x2a4dc4===Number['POSITIVE_INFINITY']||_0x2a4dc4===Number['NEGATIVE_INFINITY']);},Vl=function(_0x4d7d6b){if(document['readyState']==='complete')_0x4d7d6b();else{let _0x3d4ce8=!0x1;const _0x8d8b5f=function(){if(!document['body']){setTimeout(_0x8d8b5f,Math['floor'](0xa));return;}_0x3d4ce8||(_0x3d4ce8=!0x0,_0x4d7d6b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x8d8b5f,!0x1),window['addEventListener']('load',_0x8d8b5f,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x8d8b5f();}),window['attachEvent']('onload',_0x8d8b5f));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x674bdc,_0x500ad4){if(_0x674bdc===_0x500ad4)return 0x0;if(_0x674bdc===xe||_0x500ad4===Ie)return-0x1;if(_0x500ad4===xe||_0x674bdc===Ie)return 0x1;{const _0x5612fa=Hs(_0x674bdc),_0x45e4e8=Hs(_0x500ad4);return _0x5612fa!==null?_0x45e4e8!==null?_0x5612fa-_0x45e4e8===0x0?_0x674bdc['length']-_0x500ad4['length']:_0x5612fa-_0x45e4e8:-0x1:_0x45e4e8!==null?0x1:_0x674bdc<_0x500ad4?-0x1:0x1;}},Hl=function(_0x4ef8c8,_0xc1ec43){return _0x4ef8c8===_0xc1ec43?0x0:_0x4ef8c8<_0xc1ec43?-0x1:0x1;},pt=function(_0x52579e,_0x24ca1c){if(_0x24ca1c&&_0x52579e in _0x24ca1c)return _0x24ca1c[_0x52579e];throw new Error('Missing\x20required\x20key\x20('+_0x52579e+')\x20in\x20object:\x20'+O(_0x24ca1c));},Bi=function(_0x344e14){if(typeof _0x344e14!='object'||_0x344e14===null)return O(_0x344e14);const _0x3b1350=[];for(const _0x5ee167 in _0x344e14)_0x3b1350['push'](_0x5ee167);_0x3b1350['sort']();let _0x44010a='{';for(let _0x408eea=0x0;_0x408eea<_0x3b1350['length'];_0x408eea++)_0x408eea!==0x0&&(_0x44010a+=','),_0x44010a+=O(_0x3b1350[_0x408eea]),_0x44010a+=':',_0x44010a+=Bi(_0x344e14[_0x3b1350[_0x408eea]]);return _0x44010a+='}',_0x44010a;},io=function(_0x375ec2,_0x2a15fe){const _0x3b19e7=_0x375ec2['length'];if(_0x3b19e7<=_0x2a15fe)return[_0x375ec2];const _0x384869=[];for(let _0x27d61a=0x0;_0x27d61a<_0x3b19e7;_0x27d61a+=_0x2a15fe)_0x27d61a+_0x2a15fe>_0x3b19e7?_0x384869['push'](_0x375ec2['substring'](_0x27d61a,_0x3b19e7)):_0x384869['push'](_0x375ec2['substring'](_0x27d61a,_0x27d61a+_0x2a15fe));return _0x384869;};function x(_0x4b1eee,_0xac2884){for(const _0x349a47 in _0x4b1eee)_0x4b1eee['hasOwnProperty'](_0x349a47)&&_0xac2884(_0x349a47,_0x4b1eee[_0x349a47]);}const so=function(_0x4fbf1c){f(!Wi(_0x4fbf1c),'Invalid\x20JSON\x20number');const _0x16d3ea=0xb,_0x5b0b76=0x34,_0x507c12=(0x1<<_0x16d3ea-0x1)-0x1;let _0x1f70da,_0x17eb6d,_0x40f8e2,_0x1752a,_0x7c16aa;_0x4fbf1c===0x0?(_0x17eb6d=0x0,_0x40f8e2=0x0,_0x1f70da=0x1/_0x4fbf1c===-0x1/0x0?0x1:0x0):(_0x1f70da=_0x4fbf1c<0x0,_0x4fbf1c=Math['abs'](_0x4fbf1c),_0x4fbf1c>=Math['pow'](0x2,0x1-_0x507c12)?(_0x1752a=Math['min'](Math['floor'](Math['log'](_0x4fbf1c)/Math['LN2']),_0x507c12),_0x17eb6d=_0x1752a+_0x507c12,_0x40f8e2=Math['round'](_0x4fbf1c*Math['pow'](0x2,_0x5b0b76-_0x1752a)-Math['pow'](0x2,_0x5b0b76))):(_0x17eb6d=0x0,_0x40f8e2=Math['round'](_0x4fbf1c/Math['pow'](0x2,0x1-_0x507c12-_0x5b0b76))));const _0x5c7a3a=[];for(_0x7c16aa=_0x5b0b76;_0x7c16aa;_0x7c16aa-=0x1)_0x5c7a3a['push'](_0x40f8e2%0x2?0x1:0x0),_0x40f8e2=Math['floor'](_0x40f8e2/0x2);for(_0x7c16aa=_0x16d3ea;_0x7c16aa;_0x7c16aa-=0x1)_0x5c7a3a['push'](_0x17eb6d%0x2?0x1:0x0),_0x17eb6d=Math['floor'](_0x17eb6d/0x2);_0x5c7a3a['push'](_0x1f70da?0x1:0x0),_0x5c7a3a['reverse']();const _0x5990a6=_0x5c7a3a['join']('');let _0x291c94='';for(_0x7c16aa=0x0;_0x7c16aa<0x40;_0x7c16aa+=0x8){let _0x2a8fb5=parseInt(_0x5990a6['substr'](_0x7c16aa,0x8),0x2)['toString'](0x10);_0x2a8fb5['length']===0x1&&(_0x2a8fb5='0'+_0x2a8fb5),_0x291c94=_0x291c94+_0x2a8fb5;}return _0x291c94['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x578a1d,_0x4a450a){let _0x287861='Unknown\x20Error';_0x578a1d==='too_big'?_0x287861='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x578a1d==='permission_denied'?_0x287861='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x578a1d==='unavailable'&&(_0x287861='The\x20service\x20is\x20unavailable');const _0x46d3c4=new Error(_0x578a1d+'\x20at\x20'+_0x4a450a['_path']['toString']()+':\x20'+_0x287861);return _0x46d3c4['code']=_0x578a1d['toUpperCase'](),_0x46d3c4;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x39fdfd){if(zl['test'](_0x39fdfd)){const _0x4f42a0=Number(_0x39fdfd);if(_0x4f42a0>=jl&&_0x4f42a0<=Kl)return _0x4f42a0;}return null;},lt=function(_0x41450e){try{_0x41450e();}catch(_0x57b7e6){setTimeout(()=>{const _0x323f30=_0x57b7e6['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x323f30),_0x57b7e6;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x2237f2,_0x4c0c1d){const _0x7a5874=setTimeout(_0x2237f2,_0x4c0c1d);return typeof _0x7a5874=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x7a5874):typeof _0x7a5874=='object'&&_0x7a5874['unref']&&_0x7a5874['unref'](),_0x7a5874;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x3c80e6,_0x540489){this['appCheckProvider']=_0x540489,this['appName']=_0x3c80e6['name'],H(_0x3c80e6)&&_0x3c80e6['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3c80e6['settings']['appCheckToken']),this['appCheck']=_0x540489==null?void 0x0:_0x540489['getImmediate']({'optional':!0x0}),this['appCheck']||_0x540489==null||_0x540489['get']()['then'](_0x35bc3f=>this['appCheck']=_0x35bc3f);}['getToken'](_0x27d5e1){if(this['serverAppAppCheckToken']){if(_0x27d5e1)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x27d5e1):new Promise((_0x183773,_0x55d60b)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x27d5e1)['then'](_0x183773,_0x55d60b):_0x183773(null);},0x0);});}['addTokenChangeListener'](_0x2f3a09){var _0x8a1370;(_0x8a1370=this['appCheckProvider'])==null||_0x8a1370['get']()['then'](_0x349d9a=>_0x349d9a['addTokenListener'](_0x2f3a09));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x269f3b,_0xd50641,_0xce27ab){this['appName_']=_0x269f3b,this['firebaseOptions_']=_0xd50641,this['authProvider_']=_0xce27ab,this['auth_']=null,this['auth_']=_0xce27ab['getImmediate']({'optional':!0x0}),this['auth_']||_0xce27ab['onInit'](_0x29fa8a=>this['auth_']=_0x29fa8a);}['getToken'](_0x1582be){return this['auth_']?this['auth_']['getToken'](_0x1582be)['catch'](_0x1061db=>_0x1061db&&_0x1061db['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1061db)):new Promise((_0x1d9d9f,_0x47bd72)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1582be)['then'](_0x1d9d9f,_0x47bd72):_0x1d9d9f(null);},0x0);});}['addTokenChangeListener'](_0x2c8505){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2c8505):this['authProvider_']['get']()['then'](_0x4770e4=>_0x4770e4['addAuthTokenListener'](_0x2c8505));}['removeTokenChangeListener'](_0x4e88a3){this['authProvider_']['get']()['then'](_0x18d83f=>_0x18d83f['removeAuthTokenListener'](_0x4e88a3));}['notifyForInvalidToken'](){let _0x42b6c9='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x42b6c9+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x42b6c9+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x42b6c9+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x42b6c9);}}class tn{constructor(_0x230d6d){this['accessToken']=_0x230d6d;}['getToken'](_0x43592d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x13871d){_0x13871d(this['accessToken']);}['removeTokenChangeListener'](_0x573af5){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1c1b23,_0x59e65b,_0x2a57da,_0x521082,_0x5e166b=!0x1,_0x523678='',_0x161e5d=!0x1,_0x45d94d=!0x1,_0x79c079=null){this['secure']=_0x59e65b,this['namespace']=_0x2a57da,this['webSocketOnly']=_0x521082,this['nodeAdmin']=_0x5e166b,this['persistenceKey']=_0x523678,this['includeNamespaceInQueryParams']=_0x161e5d,this['isUsingEmulator']=_0x45d94d,this['emulatorOptions']=_0x79c079,this['_host']=_0x1c1b23['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1c1b23)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x9e4061){_0x9e4061!==this['internalHost']&&(this['internalHost']=_0x9e4061,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x249ec4=this['toURLString']();return this['persistenceKey']&&(_0x249ec4+='<'+this['persistenceKey']+'>'),_0x249ec4;}['toURLString'](){const _0x1772e8=this['secure']?'https://':'http://',_0x538db6=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1772e8+this['host']+'/'+_0x538db6;}}function Xl(_0xec26c9){return _0xec26c9['host']!==_0xec26c9['internalHost']||_0xec26c9['isCustomHost']()||_0xec26c9['includeNamespaceInQueryParams'];}function go(_0x2d6a0c,_0x1fd16a,_0x96021){f(typeof _0x1fd16a=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x96021=='object','typeof\x20params\x20must\x20==\x20object');let _0x2c0a92;if(_0x1fd16a===fo)_0x2c0a92=(_0x2d6a0c['secure']?'wss://':'ws://')+_0x2d6a0c['internalHost']+'/.ws?';else{if(_0x1fd16a===po)_0x2c0a92=(_0x2d6a0c['secure']?'https://':'http://')+_0x2d6a0c['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1fd16a);}Xl(_0x2d6a0c)&&(_0x96021['ns']=_0x2d6a0c['namespace']);const _0x3c4575=[];return x(_0x96021,(_0x5196b5,_0x4080da)=>{_0x3c4575['push'](_0x5196b5+'='+_0x4080da);}),_0x2c0a92+_0x3c4575['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x380dd3,_0x21d8fc=0x1){Y(this['counters_'],_0x380dd3)||(this['counters_'][_0x380dd3]=0x0),this['counters_'][_0x380dd3]+=_0x21d8fc;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x1f0469){const _0x27d7ac=_0x1f0469['toString']();return ti[_0x27d7ac]||(ti[_0x27d7ac]=new Zl()),ti[_0x27d7ac];}function eh(_0x2056d2,_0x4c91c6){const _0xbb064f=_0x2056d2['toString']();return ni[_0xbb064f]||(ni[_0xbb064f]=_0x4c91c6()),ni[_0xbb064f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x50339c){this['onMessage_']=_0x50339c,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x18d335,_0x39e52b){this['closeAfterResponse']=_0x18d335,this['onClose']=_0x39e52b,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x30095d,_0x24004c){for(this['pendingResponses'][_0x30095d]=_0x24004c;this['pendingResponses'][this['currentResponseNum']];){const _0xccf040=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3c4fc7=0x0;_0x3c4fc7<_0xccf040['length'];++_0x3c4fc7)_0xccf040[_0x3c4fc7]&&lt(()=>{this['onMessage_'](_0xccf040[_0x3c4fc7]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x502557,_0x3802ca,_0x304d5b,_0x40e62f,_0x30a117,_0x3939c4,_0x4bc822){this['connId']=_0x502557,this['repoInfo']=_0x3802ca,this['applicationId']=_0x304d5b,this['appCheckToken']=_0x40e62f,this['authToken']=_0x30a117,this['transportSessionId']=_0x3939c4,this['lastSessionId']=_0x4bc822,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x502557),this['stats_']=Hi(_0x3802ca),this['urlFn']=_0x149234=>(this['appCheckToken']&&(_0x149234[yi]=this['appCheckToken']),go(_0x3802ca,po,_0x149234));}['open'](_0x400a82,_0x37ac84){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x37ac84,this['myPacketOrderer']=new th(_0x400a82),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3f074a)=>{const [_0x1f8f1d,_0x54a862,_0x193b94,_0x1f9f29,_0x2e6c5d]=_0x3f074a;if(this['incrementIncomingBytes_'](_0x3f074a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1f8f1d===$s)this['id']=_0x54a862,this['password']=_0x193b94;else{if(_0x1f8f1d===nh)_0x54a862?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x54a862,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1f8f1d);}}},(..._0xb1a68a)=>{const [_0x27211c,_0x475d08]=_0xb1a68a;this['incrementIncomingBytes_'](_0xb1a68a),this['myPacketOrderer']['handleResponse'](_0x27211c,_0x475d08);},()=>{this['onClosed_']();},this['urlFn']);const _0x4b6d13={};_0x4b6d13[$s]='t',_0x4b6d13[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4b6d13[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4b6d13[ro]=Vi,this['transportSessionId']&&(_0x4b6d13[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4b6d13[ho]=this['lastSessionId']),this['applicationId']&&(_0x4b6d13[uo]=this['applicationId']),this['appCheckToken']&&(_0x4b6d13[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4b6d13[ao]=co);const _0x1c806c=this['urlFn'](_0x4b6d13);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1c806c),this['scriptTagHolder']['addTag'](_0x1c806c,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2443c9){const _0x426d97=O(_0x2443c9);this['bytesSent']+=_0x426d97['length'],this['stats_']['incrementCounter']('bytes_sent',_0x426d97['length']);const _0x427699=Br(_0x426d97),_0x15a400=io(_0x427699,hh);for(let _0x5c78b7=0x0;_0x5c78b7<_0x15a400['length'];_0x5c78b7++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x15a400['length'],_0x15a400[_0x5c78b7]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3461fe,_0x442403){this['myDisconnFrame']=document['createElement']('iframe');const _0x2abbcf={};_0x2abbcf[lh]='t',_0x2abbcf[mo]=_0x3461fe,_0x2abbcf[yo]=_0x442403,this['myDisconnFrame']['src']=this['urlFn'](_0x2abbcf),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x16ac20){const _0x1fd711=O(_0x16ac20)['length'];this['bytesReceived']+=_0x1fd711,this['stats_']['incrementCounter']('bytes_received',_0x1fd711);}}class $i{constructor(_0x12d615,_0x873211,_0x4bce43,_0x32c4f3){this['onDisconnect']=_0x4bce43,this['urlFn']=_0x32c4f3,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x12d615,window[sh+this['uniqueCallbackIdentifier']]=_0x873211,this['myIFrame']=$i['createIFrame_']();let _0x461f1f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x461f1f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x364cc6='<html><body>'+_0x461f1f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x364cc6),this['myIFrame']['doc']['close']();}catch(_0x1d18bb){L('frame\x20writing\x20exception'),_0x1d18bb['stack']&&L(_0x1d18bb['stack']),L(_0x1d18bb);}}}static['createIFrame_'](){const _0x1aff49=document['createElement']('iframe');if(_0x1aff49['style']['display']='none',document['body']){document['body']['appendChild'](_0x1aff49);try{_0x1aff49['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2d7515=document['domain'];_0x1aff49['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2d7515+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1aff49['contentDocument']?_0x1aff49['doc']=_0x1aff49['contentDocument']:_0x1aff49['contentWindow']?_0x1aff49['doc']=_0x1aff49['contentWindow']['document']:_0x1aff49['document']&&(_0x1aff49['doc']=_0x1aff49['document']),_0x1aff49;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x36dd0c=this['onDisconnect'];_0x36dd0c&&(this['onDisconnect']=null,_0x36dd0c());}['startLongPoll'](_0x4a1c34,_0x8dfa97){for(this['myID']=_0x4a1c34,this['myPW']=_0x8dfa97,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x77a1ae={};_0x77a1ae[mo]=this['myID'],_0x77a1ae[yo]=this['myPW'],_0x77a1ae[vo]=this['currentSerial'];let _0x10bb73=this['urlFn'](_0x77a1ae),_0x333e66='',_0x562463=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x333e66['length']<=Eo;){const _0x32c3e2=this['pendingSegs']['shift']();_0x333e66=_0x333e66+'&'+oh+_0x562463+'='+_0x32c3e2['seg']+'&'+ah+_0x562463+'='+_0x32c3e2['ts']+'&'+ch+_0x562463+'='+_0x32c3e2['d'],_0x562463++;}return _0x10bb73=_0x10bb73+_0x333e66,this['addLongPollTag_'](_0x10bb73,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x32ff50,_0x1ac634,_0x55b111){this['pendingSegs']['push']({'seg':_0x32ff50,'ts':_0x1ac634,'d':_0x55b111}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4e5182,_0x873a29){this['outstandingRequests']['add'](_0x873a29);const _0x1074f1=()=>{this['outstandingRequests']['delete'](_0x873a29),this['newRequest_']();},_0x5d4165=setTimeout(_0x1074f1,Math['floor'](uh)),_0x49e468=()=>{clearTimeout(_0x5d4165),_0x1074f1();};this['addTag'](_0x4e5182,_0x49e468);}['addTag'](_0x37f9fd,_0x44877c){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x11a5a4=this['myIFrame']['doc']['createElement']('script');_0x11a5a4['type']='text/javascript',_0x11a5a4['async']=!0x0,_0x11a5a4['src']=_0x37f9fd,_0x11a5a4['onload']=_0x11a5a4['onreadystatechange']=function(){const _0x598989=_0x11a5a4['readyState'];(!_0x598989||_0x598989==='loaded'||_0x598989==='complete')&&(_0x11a5a4['onload']=_0x11a5a4['onreadystatechange']=null,_0x11a5a4['parentNode']&&_0x11a5a4['parentNode']['removeChild'](_0x11a5a4),_0x44877c());},_0x11a5a4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x37f9fd),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x11a5a4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x347a7b,_0x489d5b,_0x548568,_0x151c03,_0x1f7b66,_0x788d50,_0x3cc56f){this['connId']=_0x347a7b,this['applicationId']=_0x548568,this['appCheckToken']=_0x151c03,this['authToken']=_0x1f7b66,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x489d5b),this['connURL']=G['connectionURL_'](_0x489d5b,_0x788d50,_0x3cc56f,_0x151c03,_0x548568),this['nodeAdmin']=_0x489d5b['nodeAdmin'];}static['connectionURL_'](_0x189f0a,_0x5294a6,_0x41eac3,_0x8da258,_0x2daf7e){const _0x315ed6={};return _0x315ed6[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x315ed6[ao]=co),_0x5294a6&&(_0x315ed6[oo]=_0x5294a6),_0x41eac3&&(_0x315ed6[ho]=_0x41eac3),_0x8da258&&(_0x315ed6[yi]=_0x8da258),_0x2daf7e&&(_0x315ed6[uo]=_0x2daf7e),go(_0x189f0a,fo,_0x315ed6);}['open'](_0x4bfdaf,_0x24b7d8){this['onDisconnect']=_0x24b7d8,this['onMessage']=_0x4bfdaf,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x4a4ecb;dc(),this['mySock']=new hn(this['connURL'],[],_0x4a4ecb);}catch(_0x2352d7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1ebe67=_0x2352d7['message']||_0x2352d7['data'];_0x1ebe67&&this['log_'](_0x1ebe67),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x9a4266=>{this['handleIncomingFrame'](_0x9a4266);},this['mySock']['onerror']=_0x22a7d3=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1d5791=_0x22a7d3['message']||_0x22a7d3['data'];_0x1d5791&&this['log_'](_0x1d5791),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x320c64=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5d235d=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4d2165=navigator['userAgent']['match'](_0x5d235d);_0x4d2165&&_0x4d2165['length']>0x1&&parseFloat(_0x4d2165[0x1])<4.4&&(_0x320c64=!0x0);}return!_0x320c64&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5da77b){if(this['frames']['push'](_0x5da77b),this['frames']['length']===this['totalFrames']){const _0xf98bba=this['frames']['join']('');this['frames']=null;const _0x419412=bt(_0xf98bba);this['onMessage'](_0x419412);}}['handleNewFrameCount_'](_0x1225f2){this['totalFrames']=_0x1225f2,this['frames']=[];}['extractFrameCount_'](_0x24b48d){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x24b48d['length']<=0x6){const _0x211db6=Number(_0x24b48d);if(!isNaN(_0x211db6))return this['handleNewFrameCount_'](_0x211db6),null;}return this['handleNewFrameCount_'](0x1),_0x24b48d;}['handleIncomingFrame'](_0x3ccd33){if(this['mySock']===null)return;const _0x2903b0=_0x3ccd33['data'];if(this['bytesReceived']+=_0x2903b0['length'],this['stats_']['incrementCounter']('bytes_received',_0x2903b0['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2903b0);else{const _0x4c46ab=this['extractFrameCount_'](_0x2903b0);_0x4c46ab!==null&&this['appendFrame_'](_0x4c46ab);}}['send'](_0x31f99d){this['resetKeepAlive']();const _0x5c496f=O(_0x31f99d);this['bytesSent']+=_0x5c496f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5c496f['length']);const _0x443705=io(_0x5c496f,fh);_0x443705['length']>0x1&&this['sendString_'](String(_0x443705['length']));for(let _0x405afb=0x0;_0x405afb<_0x443705['length'];_0x405afb++)this['sendString_'](_0x443705[_0x405afb]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x417325){try{this['mySock']['send'](_0x417325);}catch(_0x26a60d){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x26a60d['message']||_0x26a60d['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x56ee8d){this['initTransports_'](_0x56ee8d);}['initTransports_'](_0x4bc7ee){const _0x4dfac4=G&&G['isAvailable']();let _0x378d4b=_0x4dfac4&&!G['previouslyFailed']();if(_0x4bc7ee['webSocketOnly']&&(_0x4dfac4||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x378d4b=!0x0),_0x378d4b)this['transports_']=[G];else{const _0x3b3fe5=this['transports_']=[];for(const _0x13d06c of At['ALL_TRANSPORTS'])_0x13d06c&&_0x13d06c['isAvailable']()&&_0x3b3fe5['push'](_0x13d06c);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x57aa9e,_0x6008bf,_0xa8f2e0,_0xa521ae,_0x21748a,_0x13d4e7,_0x542559,_0xf529a2,_0x57dcaa,_0x21f1f4){this['id']=_0x57aa9e,this['repoInfo_']=_0x6008bf,this['applicationId_']=_0xa8f2e0,this['appCheckToken_']=_0xa521ae,this['authToken_']=_0x21748a,this['onMessage_']=_0x13d4e7,this['onReady_']=_0x542559,this['onDisconnect_']=_0xf529a2,this['onKill_']=_0x57dcaa,this['lastSessionId']=_0x21f1f4,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x6008bf),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2af486=this['transportManager_']['initialTransport']();this['conn_']=new _0x2af486(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2af486['responsesRequiredToBeHealthy']||0x0;const _0x452820=this['connReceiver_'](this['conn_']),_0x334e0e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x452820,_0x334e0e);},Math['floor'](0x0));const _0x2fc8eb=_0x2af486['healthyTimeout']||0x0;_0x2fc8eb>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2fc8eb)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2e90a7){return _0x28b99f=>{_0x2e90a7===this['conn_']?this['onConnectionLost_'](_0x28b99f):_0x2e90a7===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x285cf1){return _0x133120=>{this['state_']!==0x2&&(_0x285cf1===this['rx_']?this['onPrimaryMessageReceived_'](_0x133120):_0x285cf1===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x133120):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5ee044){const _0x1a6bee={'t':'d','d':_0x5ee044};this['sendData_'](_0x1a6bee);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x193614){if(ii in _0x193614){const _0x114751=_0x193614[ii];_0x114751===js?this['upgradeIfSecondaryHealthy_']():_0x114751===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x114751===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x29a8ba){const _0xaac095=pt('t',_0x29a8ba),_0x1003bf=pt('d',_0x29a8ba);if(_0xaac095==='c')this['onSecondaryControl_'](_0x1003bf);else{if(_0xaac095==='d')this['pendingDataMessages']['push'](_0x1003bf);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xaac095);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x44cd6d){const _0x298553=pt('t',_0x44cd6d),_0x1b2c89=pt('d',_0x44cd6d);_0x298553==='c'?this['onControl_'](_0x1b2c89):_0x298553==='d'&&this['onDataMessage_'](_0x1b2c89);}['onDataMessage_'](_0x585762){this['onPrimaryResponse_'](),this['onMessage_'](_0x585762);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x31ec36){const _0x1caff7=pt(ii,_0x31ec36);if(Gs in _0x31ec36){const _0x5f3c8d=_0x31ec36[Gs];if(_0x1caff7===Ih){const _0x50c6cf={..._0x5f3c8d};this['repoInfo_']['isUsingEmulator']&&(_0x50c6cf['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x50c6cf);}else{if(_0x1caff7===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1e812a=0x0;_0x1e812a<this['pendingDataMessages']['length'];++_0x1e812a)this['onDataMessage_'](this['pendingDataMessages'][_0x1e812a]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1caff7===vh?this['onConnectionShutdown_'](_0x5f3c8d):_0x1caff7===qs?this['onReset_'](_0x5f3c8d):_0x1caff7===Eh?mi('Server\x20Error:\x20'+_0x5f3c8d):_0x1caff7===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x1caff7);}}}['onHandshake_'](_0x5f4703){const _0x57887f=_0x5f4703['ts'],_0x3d7979=_0x5f4703['v'],_0x56b127=_0x5f4703['h'];this['sessionId']=_0x5f4703['s'],this['repoInfo_']['host']=_0x56b127,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x57887f),Vi!==_0x3d7979&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x27d1a1=this['transportManager_']['upgradeTransport']();_0x27d1a1&&this['startUpgrade_'](_0x27d1a1);}['startUpgrade_'](_0x3ffbbf){this['secondaryConn_']=new _0x3ffbbf(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3ffbbf['responsesRequiredToBeHealthy']||0x0;const _0x1b8190=this['connReceiver_'](this['secondaryConn_']),_0x20ff5d=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1b8190,_0x20ff5d),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2515f6){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2515f6),this['repoInfo_']['host']=_0x2515f6,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x28933f,_0x2c9713){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x28933f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2c9713,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x15ce02=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x15ce02||this['rx_']===_0x15ce02)&&this['close']();}['onConnectionLost_'](_0x1babb3){this['conn_']=null,!_0x1babb3&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x34c5f7){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x34c5f7),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x384991){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x384991);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x397d34,_0x4a9dea,_0x810d30,_0x1f4e35){}['merge'](_0x27a5da,_0x368b33,_0x4266e9,_0x3adf5e){}['refreshAuthToken'](_0x55ecd9){}['refreshAppCheckToken'](_0x440213){}['onDisconnectPut'](_0x29d95c,_0x187118,_0xa578b6){}['onDisconnectMerge'](_0x517963,_0x563645,_0x10a88b){}['onDisconnectCancel'](_0x2fa87,_0x7b7325){}['reportStats'](_0x36e84a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x57d7e4){this['allowedEvents_']=_0x57d7e4,this['listeners_']={},f(Array['isArray'](_0x57d7e4)&&_0x57d7e4['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1d6829,..._0x270a0c){if(Array['isArray'](this['listeners_'][_0x1d6829])){const _0x5eddb5=[...this['listeners_'][_0x1d6829]];for(let _0x4fcbae=0x0;_0x4fcbae<_0x5eddb5['length'];_0x4fcbae++)_0x5eddb5[_0x4fcbae]['callback']['apply'](_0x5eddb5[_0x4fcbae]['context'],_0x270a0c);}}['on'](_0x39bb06,_0x274ed9,_0x26d584){this['validateEventType_'](_0x39bb06),this['listeners_'][_0x39bb06]=this['listeners_'][_0x39bb06]||[],this['listeners_'][_0x39bb06]['push']({'callback':_0x274ed9,'context':_0x26d584});const _0x17a0be=this['getInitialEvent'](_0x39bb06);_0x17a0be&&_0x274ed9['apply'](_0x26d584,_0x17a0be);}['off'](_0x12dd5d,_0x51bb01,_0x5f3990){this['validateEventType_'](_0x12dd5d);const _0x105351=this['listeners_'][_0x12dd5d]||[];for(let _0x40f2bf=0x0;_0x40f2bf<_0x105351['length'];_0x40f2bf++)if(_0x105351[_0x40f2bf]['callback']===_0x51bb01&&(!_0x5f3990||_0x5f3990===_0x105351[_0x40f2bf]['context'])){_0x105351['splice'](_0x40f2bf,0x1);return;}}['validateEventType_'](_0x5c2831){f(this['allowedEvents_']['find'](_0x5812a9=>_0x5812a9===_0x5c2831),'Unknown\x20event:\x20'+_0x5c2831);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x17e70b){return f(_0x17e70b==='online','Unknown\x20event\x20type:\x20'+_0x17e70b),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x1125f5,_0x2137e5){if(_0x2137e5===void 0x0){this['pieces_']=_0x1125f5['split']('/');let _0xa8ed16=0x0;for(let _0x22aa86=0x0;_0x22aa86<this['pieces_']['length'];_0x22aa86++)this['pieces_'][_0x22aa86]['length']>0x0&&(this['pieces_'][_0xa8ed16]=this['pieces_'][_0x22aa86],_0xa8ed16++);this['pieces_']['length']=_0xa8ed16,this['pieceNum_']=0x0;}else this['pieces_']=_0x1125f5,this['pieceNum_']=_0x2137e5;}['toString'](){let _0x3ce584='';for(let _0x36576e=this['pieceNum_'];_0x36576e<this['pieces_']['length'];_0x36576e++)this['pieces_'][_0x36576e]!==''&&(_0x3ce584+='/'+this['pieces_'][_0x36576e]);return _0x3ce584||'/';}}function w(){return new C('');}function y(_0x573f89){return _0x573f89['pieceNum_']>=_0x573f89['pieces_']['length']?null:_0x573f89['pieces_'][_0x573f89['pieceNum_']];}function we(_0x3106e6){return _0x3106e6['pieces_']['length']-_0x3106e6['pieceNum_'];}function b(_0x4ff339){let _0x162576=_0x4ff339['pieceNum_'];return _0x162576<_0x4ff339['pieces_']['length']&&_0x162576++,new C(_0x4ff339['pieces_'],_0x162576);}function Gi(_0x5bcecc){return _0x5bcecc['pieceNum_']<_0x5bcecc['pieces_']['length']?_0x5bcecc['pieces_'][_0x5bcecc['pieces_']['length']-0x1]:null;}function Ch(_0x26002f){let _0x4034ed='';for(let _0x5f1f40=_0x26002f['pieceNum_'];_0x5f1f40<_0x26002f['pieces_']['length'];_0x5f1f40++)_0x26002f['pieces_'][_0x5f1f40]!==''&&(_0x4034ed+='/'+encodeURIComponent(String(_0x26002f['pieces_'][_0x5f1f40])));return _0x4034ed||'/';}function kt(_0x24411b,_0x33bcd3=0x0){return _0x24411b['pieces_']['slice'](_0x24411b['pieceNum_']+_0x33bcd3);}function To(_0x2de623){if(_0x2de623['pieceNum_']>=_0x2de623['pieces_']['length'])return null;const _0x1c9361=[];for(let _0x47864d=_0x2de623['pieceNum_'];_0x47864d<_0x2de623['pieces_']['length']-0x1;_0x47864d++)_0x1c9361['push'](_0x2de623['pieces_'][_0x47864d]);return new C(_0x1c9361,0x0);}function A(_0x19b11a,_0x163653){const _0x4366f6=[];for(let _0x5cd152=_0x19b11a['pieceNum_'];_0x5cd152<_0x19b11a['pieces_']['length'];_0x5cd152++)_0x4366f6['push'](_0x19b11a['pieces_'][_0x5cd152]);if(_0x163653 instanceof C){for(let _0x38e279=_0x163653['pieceNum_'];_0x38e279<_0x163653['pieces_']['length'];_0x38e279++)_0x4366f6['push'](_0x163653['pieces_'][_0x38e279]);}else{const _0x201c9c=_0x163653['split']('/');for(let _0x2df12c=0x0;_0x2df12c<_0x201c9c['length'];_0x2df12c++)_0x201c9c[_0x2df12c]['length']>0x0&&_0x4366f6['push'](_0x201c9c[_0x2df12c]);}return new C(_0x4366f6,0x0);}function v(_0x49aac9){return _0x49aac9['pieceNum_']>=_0x49aac9['pieces_']['length'];}function F(_0x1c7da5,_0x11faa9){const _0x797b8d=y(_0x1c7da5),_0x222430=y(_0x11faa9);if(_0x797b8d===null)return _0x11faa9;if(_0x797b8d===_0x222430)return F(b(_0x1c7da5),b(_0x11faa9));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x11faa9+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1c7da5+')');}function Th(_0x307c48,_0x26f8bb){const _0x246411=kt(_0x307c48,0x0),_0x39cdea=kt(_0x26f8bb,0x0);for(let _0x4c2960=0x0;_0x4c2960<_0x246411['length']&&_0x4c2960<_0x39cdea['length'];_0x4c2960++){const _0x2ce166=He(_0x246411[_0x4c2960],_0x39cdea[_0x4c2960]);if(_0x2ce166!==0x0)return _0x2ce166;}return _0x246411['length']===_0x39cdea['length']?0x0:_0x246411['length']<_0x39cdea['length']?-0x1:0x1;}function qi(_0xf3bed9,_0x5d18f2){if(we(_0xf3bed9)!==we(_0x5d18f2))return!0x1;for(let _0x20b7d8=_0xf3bed9['pieceNum_'],_0x46d496=_0x5d18f2['pieceNum_'];_0x20b7d8<=_0xf3bed9['pieces_']['length'];_0x20b7d8++,_0x46d496++)if(_0xf3bed9['pieces_'][_0x20b7d8]!==_0x5d18f2['pieces_'][_0x46d496])return!0x1;return!0x0;}function $(_0x1404e8,_0x1332d7){let _0x56ea93=_0x1404e8['pieceNum_'],_0x243bca=_0x1332d7['pieceNum_'];if(we(_0x1404e8)>we(_0x1332d7))return!0x1;for(;_0x56ea93<_0x1404e8['pieces_']['length'];){if(_0x1404e8['pieces_'][_0x56ea93]!==_0x1332d7['pieces_'][_0x243bca])return!0x1;++_0x56ea93,++_0x243bca;}return!0x0;}class Sh{constructor(_0x1f2e0c,_0x12e8b3){this['errorPrefix_']=_0x12e8b3,this['parts_']=kt(_0x1f2e0c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5e7638=0x0;_0x5e7638<this['parts_']['length'];_0x5e7638++)this['byteLength_']+=Pn(this['parts_'][_0x5e7638]);So(this);}}function bh(_0x3e7192,_0x6d0c9c){_0x3e7192['parts_']['length']>0x0&&(_0x3e7192['byteLength_']+=0x1),_0x3e7192['parts_']['push'](_0x6d0c9c),_0x3e7192['byteLength_']+=Pn(_0x6d0c9c),So(_0x3e7192);}function Rh(_0x102468){const _0x50a3c3=_0x102468['parts_']['pop']();_0x102468['byteLength_']-=Pn(_0x50a3c3),_0x102468['parts_']['length']>0x0&&(_0x102468['byteLength_']-=0x1);}function So(_0x40f162){if(_0x40f162['byteLength_']>Js)throw new Error(_0x40f162['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x40f162['byteLength_']+').');if(_0x40f162['parts_']['length']>Qs)throw new Error(_0x40f162['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x40f162));}function Ne(_0x2ec085){return _0x2ec085['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2ec085['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x51c6f2,_0x1d39d3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1d39d3='visibilitychange',_0x51c6f2='hidden'):typeof document['mozHidden']<'u'?(_0x1d39d3='mozvisibilitychange',_0x51c6f2='mozHidden'):typeof document['msHidden']<'u'?(_0x1d39d3='msvisibilitychange',_0x51c6f2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1d39d3='webkitvisibilitychange',_0x51c6f2='webkitHidden')),this['visible_']=!0x0,_0x1d39d3&&document['addEventListener'](_0x1d39d3,()=>{const _0x2a6edf=!document[_0x51c6f2];_0x2a6edf!==this['visible_']&&(this['visible_']=_0x2a6edf,this['trigger']('visible',_0x2a6edf));},!0x1);}['getInitialEvent'](_0x28d504){return f(_0x28d504==='visible','Unknown\x20event\x20type:\x20'+_0x28d504),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0xf3161,_0x5cfc5d,_0x31d932,_0x3bd9b0,_0x321a89,_0xc0d4e4,_0x2f015d,_0x150ee8){if(super(),this['repoInfo_']=_0xf3161,this['applicationId_']=_0x5cfc5d,this['onDataUpdate_']=_0x31d932,this['onConnectStatus_']=_0x3bd9b0,this['onServerInfoUpdate_']=_0x321a89,this['authTokenProvider_']=_0xc0d4e4,this['appCheckTokenProvider_']=_0x2f015d,this['authOverride_']=_0x150ee8,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x150ee8)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0xf3161['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2f050c,_0x51d50b,_0x19ec8c){const _0x1fd1f0=++this['requestNumber_'],_0xc6daf5={'r':_0x1fd1f0,'a':_0x2f050c,'b':_0x51d50b};this['log_'](O(_0xc6daf5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xc6daf5),_0x19ec8c&&(this['requestCBHash_'][_0x1fd1f0]=_0x19ec8c);}['get'](_0x46cce0){this['initConnection_']();const _0x1f0c08=new Ve(),_0x4bc2ea={'action':'g','request':{'p':_0x46cce0['_path']['toString'](),'q':_0x46cce0['_queryObject']},'onComplete':_0x5f01b2=>{const _0x284100=_0x5f01b2['d'];_0x5f01b2['s']==='ok'?_0x1f0c08['resolve'](_0x284100):_0x1f0c08['reject'](_0x284100);}};this['outstandingGets_']['push'](_0x4bc2ea),this['outstandingGetCount_']++;const _0x503939=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x503939),_0x1f0c08['promise'];}['listen'](_0x3f714a,_0x325baf,_0x1b5156,_0x161f55){this['initConnection_']();const _0x5224f5=_0x3f714a['_queryIdentifier'],_0x1a4914=_0x3f714a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1a4914+'\x20'+_0x5224f5),this['listens']['has'](_0x1a4914)||this['listens']['set'](_0x1a4914,new Map()),f(_0x3f714a['_queryParams']['isDefault']()||!_0x3f714a['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1a4914)['has'](_0x5224f5),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x24a954={'onComplete':_0x161f55,'hashFn':_0x325baf,'query':_0x3f714a,'tag':_0x1b5156};this['listens']['get'](_0x1a4914)['set'](_0x5224f5,_0x24a954),this['connected_']&&this['sendListen_'](_0x24a954);}['sendGet_'](_0xdc40cc){const _0x59ae33=this['outstandingGets_'][_0xdc40cc];this['sendRequest']('g',_0x59ae33['request'],_0x1bb473=>{delete this['outstandingGets_'][_0xdc40cc],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x59ae33['onComplete']&&_0x59ae33['onComplete'](_0x1bb473);});}['sendListen_'](_0x3b5bd3){const _0x378f1c=_0x3b5bd3['query'],_0x28c730=_0x378f1c['_path']['toString'](),_0x5a4462=_0x378f1c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x28c730+'\x20for\x20'+_0x5a4462);const _0x229877={'p':_0x28c730},_0x36a799='q';_0x3b5bd3['tag']&&(_0x229877['q']=_0x378f1c['_queryObject'],_0x229877['t']=_0x3b5bd3['tag']),_0x229877['h']=_0x3b5bd3['hashFn'](),this['sendRequest'](_0x36a799,_0x229877,_0x2f753d=>{const _0x50f3bc=_0x2f753d['d'],_0x159b41=_0x2f753d['s'];ie['warnOnListenWarnings_'](_0x50f3bc,_0x378f1c),(this['listens']['get'](_0x28c730)&&this['listens']['get'](_0x28c730)['get'](_0x5a4462))===_0x3b5bd3&&(this['log_']('listen\x20response',_0x2f753d),_0x159b41!=='ok'&&this['removeListen_'](_0x28c730,_0x5a4462),_0x3b5bd3['onComplete']&&_0x3b5bd3['onComplete'](_0x159b41,_0x50f3bc));});}static['warnOnListenWarnings_'](_0x28f97e,_0x33205d){if(_0x28f97e&&typeof _0x28f97e=='object'&&Y(_0x28f97e,'w')){const _0x15d37a=Oe(_0x28f97e,'w');if(Array['isArray'](_0x15d37a)&&~_0x15d37a['indexOf']('no_index')){const _0x1d9be5='\x22.indexOn\x22:\x20\x22'+_0x33205d['_queryParams']['getIndex']()['toString']()+'\x22',_0x247daa=_0x33205d['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1d9be5+'\x20at\x20'+_0x247daa+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x52e2c3){this['authToken_']=_0x52e2c3,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x52e2c3);}['reduceReconnectDelayIfAdminCredential_'](_0x129bf5){(_0x129bf5&&_0x129bf5['length']===0x28||vc(_0x129bf5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x296129){this['appCheckToken_']=_0x296129,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x12b8a0=this['authToken_'],_0x5d3a0f=yc(_0x12b8a0)?'auth':'gauth',_0x1efa8f={'cred':_0x12b8a0};this['authOverride_']===null?_0x1efa8f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1efa8f['authvar']=this['authOverride_']),this['sendRequest'](_0x5d3a0f,_0x1efa8f,_0x1bda7e=>{const _0x58aa6b=_0x1bda7e['s'],_0x263066=_0x1bda7e['d']||'error';this['authToken_']===_0x12b8a0&&(_0x58aa6b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x58aa6b,_0x263066));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1e185b=>{const _0x47c26c=_0x1e185b['s'],_0x123ce0=_0x1e185b['d']||'error';_0x47c26c==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x47c26c,_0x123ce0);});}['unlisten'](_0x36ff18,_0x5b849f){const _0x3f8581=_0x36ff18['_path']['toString'](),_0x5a86a2=_0x36ff18['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3f8581+'\x20'+_0x5a86a2),f(_0x36ff18['_queryParams']['isDefault']()||!_0x36ff18['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3f8581,_0x5a86a2)&&this['connected_']&&this['sendUnlisten_'](_0x3f8581,_0x5a86a2,_0x36ff18['_queryObject'],_0x5b849f);}['sendUnlisten_'](_0x3dc9ad,_0x7e01ed,_0x56d08a,_0x437eae){this['log_']('Unlisten\x20on\x20'+_0x3dc9ad+'\x20for\x20'+_0x7e01ed);const _0x3567a1={'p':_0x3dc9ad},_0x4132ca='n';_0x437eae&&(_0x3567a1['q']=_0x56d08a,_0x3567a1['t']=_0x437eae),this['sendRequest'](_0x4132ca,_0x3567a1);}['onDisconnectPut'](_0x470e70,_0x3b3883,_0x38e8e3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x470e70,_0x3b3883,_0x38e8e3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x470e70,'action':'o','data':_0x3b3883,'onComplete':_0x38e8e3});}['onDisconnectMerge'](_0x18cc3e,_0x5db58a,_0x1f23d5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x18cc3e,_0x5db58a,_0x1f23d5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x18cc3e,'action':'om','data':_0x5db58a,'onComplete':_0x1f23d5});}['onDisconnectCancel'](_0x119172,_0x3930ee){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x119172,null,_0x3930ee):this['onDisconnectRequestQueue_']['push']({'pathString':_0x119172,'action':'oc','data':null,'onComplete':_0x3930ee});}['sendOnDisconnect_'](_0xe24b03,_0x5b755f,_0x2b0d46,_0x91d295){const _0x1043e8={'p':_0x5b755f,'d':_0x2b0d46};this['log_']('onDisconnect\x20'+_0xe24b03,_0x1043e8),this['sendRequest'](_0xe24b03,_0x1043e8,_0x28d3df=>{_0x91d295&&setTimeout(()=>{_0x91d295(_0x28d3df['s'],_0x28d3df['d']);},Math['floor'](0x0));});}['put'](_0x33988a,_0x133adb,_0x1a529c,_0x17c0da){this['putInternal']('p',_0x33988a,_0x133adb,_0x1a529c,_0x17c0da);}['merge'](_0x48552e,_0x1d3855,_0xd01273,_0x5a3a13){this['putInternal']('m',_0x48552e,_0x1d3855,_0xd01273,_0x5a3a13);}['putInternal'](_0xba0d68,_0x3f3f77,_0x32874b,_0x275bbc,_0x1cdfbd){this['initConnection_']();const _0x25d4a1={'p':_0x3f3f77,'d':_0x32874b};_0x1cdfbd!==void 0x0&&(_0x25d4a1['h']=_0x1cdfbd),this['outstandingPuts_']['push']({'action':_0xba0d68,'request':_0x25d4a1,'onComplete':_0x275bbc}),this['outstandingPutCount_']++;const _0x253897=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x253897):this['log_']('Buffering\x20put:\x20'+_0x3f3f77);}['sendPut_'](_0x3fd8e2){const _0x1176c9=this['outstandingPuts_'][_0x3fd8e2]['action'],_0x574719=this['outstandingPuts_'][_0x3fd8e2]['request'],_0x2b0ffc=this['outstandingPuts_'][_0x3fd8e2]['onComplete'];this['outstandingPuts_'][_0x3fd8e2]['queued']=this['connected_'],this['sendRequest'](_0x1176c9,_0x574719,_0x1de6e4=>{this['log_'](_0x1176c9+'\x20response',_0x1de6e4),delete this['outstandingPuts_'][_0x3fd8e2],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2b0ffc&&_0x2b0ffc(_0x1de6e4['s'],_0x1de6e4['d']);});}['reportStats'](_0x1b239c){if(this['connected_']){const _0x1693e4={'c':_0x1b239c};this['log_']('reportStats',_0x1693e4),this['sendRequest']('s',_0x1693e4,_0xed8b0c=>{if(_0xed8b0c['s']!=='ok'){const _0xc8a445=_0xed8b0c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xc8a445);}});}}['onDataMessage_'](_0x2a94bd){if('r'in _0x2a94bd){this['log_']('from\x20server:\x20'+O(_0x2a94bd));const _0x19a705=_0x2a94bd['r'],_0x10da80=this['requestCBHash_'][_0x19a705];_0x10da80&&(delete this['requestCBHash_'][_0x19a705],_0x10da80(_0x2a94bd['b']));}else{if('error'in _0x2a94bd)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2a94bd['error'];'a'in _0x2a94bd&&this['onDataPush_'](_0x2a94bd['a'],_0x2a94bd['b']);}}['onDataPush_'](_0x54c1ae,_0x578881){this['log_']('handleServerMessage',_0x54c1ae,_0x578881),_0x54c1ae==='d'?this['onDataUpdate_'](_0x578881['p'],_0x578881['d'],!0x1,_0x578881['t']):_0x54c1ae==='m'?this['onDataUpdate_'](_0x578881['p'],_0x578881['d'],!0x0,_0x578881['t']):_0x54c1ae==='c'?this['onListenRevoked_'](_0x578881['p'],_0x578881['q']):_0x54c1ae==='ac'?this['onAuthRevoked_'](_0x578881['s'],_0x578881['d']):_0x54c1ae==='apc'?this['onAppCheckRevoked_'](_0x578881['s'],_0x578881['d']):_0x54c1ae==='sd'?this['onSecurityDebugPacket_'](_0x578881):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x54c1ae)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1602fe,_0x35b1bc){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1602fe),this['lastSessionId']=_0x35b1bc,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x30dc85){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x30dc85));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x16bbaa){_0x16bbaa&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x16bbaa;}['onOnline_'](_0x3c300f){_0x3c300f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x320c8a=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x47f82c=Math['max'](0x0,this['reconnectDelay_']-_0x320c8a);_0x47f82c=Math['random']()*_0x47f82c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x47f82c+'ms'),this['scheduleConnect_'](_0x47f82c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3b5b09=this['onDataMessage_']['bind'](this),_0x7f7a91=this['onReady_']['bind'](this),_0x34216e=this['onRealtimeDisconnect_']['bind'](this),_0x1a73eb=this['id']+':'+ie['nextConnectionId_']++,_0x2756a7=this['lastSessionId'];let _0x1086c9=!0x1,_0x27f9a8=null;const _0x29f77d=function(){_0x27f9a8?_0x27f9a8['close']():(_0x1086c9=!0x0,_0x34216e());},_0x2d74b9=function(_0x1cc9bf){f(_0x27f9a8,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x27f9a8['sendRequest'](_0x1cc9bf);};this['realtime_']={'close':_0x29f77d,'sendRequest':_0x2d74b9};const _0x47dda9=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1596fb,_0x3a91d4]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x47dda9),this['appCheckTokenProvider_']['getToken'](_0x47dda9)]);_0x1086c9?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1596fb&&_0x1596fb['accessToken'],this['appCheckToken_']=_0x3a91d4&&_0x3a91d4['token'],_0x27f9a8=new wh(_0x1a73eb,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3b5b09,_0x7f7a91,_0x34216e,_0x18ec27=>{U(_0x18ec27+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x2756a7));}catch(_0x3f9783){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3f9783),_0x1086c9||(this['repoInfo_']['nodeAdmin']&&U(_0x3f9783),_0x29f77d());}}}['interrupt'](_0x4a063c){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4a063c),this['interruptReasons_'][_0x4a063c]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x32eaca){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x32eaca),delete this['interruptReasons_'][_0x32eaca],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x109288){const _0x424681=_0x109288-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x424681});}['cancelSentTransactions_'](){for(let _0x59d178=0x0;_0x59d178<this['outstandingPuts_']['length'];_0x59d178++){const _0x510b4a=this['outstandingPuts_'][_0x59d178];_0x510b4a&&'h'in _0x510b4a['request']&&_0x510b4a['queued']&&(_0x510b4a['onComplete']&&_0x510b4a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x59d178],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2c3be2,_0x5f20cb){let _0x1d8364;_0x5f20cb?_0x1d8364=_0x5f20cb['map'](_0x5c55ca=>Bi(_0x5c55ca))['join']('$'):_0x1d8364='default';const _0x4bef4f=this['removeListen_'](_0x2c3be2,_0x1d8364);_0x4bef4f&&_0x4bef4f['onComplete']&&_0x4bef4f['onComplete']('permission_denied');}['removeListen_'](_0xb8d89,_0x43d56b){const _0x11c0ed=new C(_0xb8d89)['toString']();let _0x5e6fba;if(this['listens']['has'](_0x11c0ed)){const _0x23ea09=this['listens']['get'](_0x11c0ed);_0x5e6fba=_0x23ea09['get'](_0x43d56b),_0x23ea09['delete'](_0x43d56b),_0x23ea09['size']===0x0&&this['listens']['delete'](_0x11c0ed);}else _0x5e6fba=void 0x0;return _0x5e6fba;}['onAuthRevoked_'](_0x6dd795,_0x28d808){L('Auth\x20token\x20revoked:\x20'+_0x6dd795+'/'+_0x28d808),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x6dd795==='invalid_token'||_0x6dd795==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5b9ab9,_0x794144){L('App\x20check\x20token\x20revoked:\x20'+_0x5b9ab9+'/'+_0x794144),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5b9ab9==='invalid_token'||_0x5b9ab9==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x253aa9){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x253aa9):'msg'in _0x253aa9&&console['log']('FIREBASE:\x20'+_0x253aa9['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x9cec7f of this['listens']['values']())for(const _0xfc7db6 of _0x9cec7f['values']())this['sendListen_'](_0xfc7db6);for(let _0x3f5747=0x0;_0x3f5747<this['outstandingPuts_']['length'];_0x3f5747++)this['outstandingPuts_'][_0x3f5747]&&this['sendPut_'](_0x3f5747);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3c4ef8=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3c4ef8['action'],_0x3c4ef8['pathString'],_0x3c4ef8['data'],_0x3c4ef8['onComplete']);}for(let _0x1011b6=0x0;_0x1011b6<this['outstandingGets_']['length'];_0x1011b6++)this['outstandingGets_'][_0x1011b6]&&this['sendGet_'](_0x1011b6);}['sendConnectStats_'](){const _0x4e1ede={};let _0x34c5d9='js';_0x4e1ede['sdk.'+_0x34c5d9+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x4e1ede['framework.cordova']=0x1:qr()&&(_0x4e1ede['framework.reactnative']=0x1),this['reportStats'](_0x4e1ede);}['shouldReconnect_'](){const _0x43fd94=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x43fd94;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x364f8b,_0x3d190b){this['name']=_0x364f8b,this['node']=_0x3d190b;}static['Wrap'](_0x2c4f5a,_0x174168){return new E(_0x2c4f5a,_0x174168);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x32f9e1,_0x134266){const _0x49cae6=new E(xe,_0x32f9e1),_0x3f792c=new E(xe,_0x134266);return this['compare'](_0x49cae6,_0x3f792c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2891d9){Xt=_0x2891d9;}['compare'](_0x584581,_0x2e7e46){return He(_0x584581['name'],_0x2e7e46['name']);}['isDefinedOn'](_0x3049f6){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x10adf5,_0x1693a4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x4e3d9a,_0x47104b){return f(typeof _0x4e3d9a=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4e3d9a,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0xdd3e46,_0x4df4e6,_0x5200c7,_0x32b52a,_0x5bb888=null){this['isReverse_']=_0x32b52a,this['resultGenerator_']=_0x5bb888,this['nodeStack_']=[];let _0x5a261f=0x1;for(;!_0xdd3e46['isEmpty']();)if(_0xdd3e46=_0xdd3e46,_0x5a261f=_0x4df4e6?_0x5200c7(_0xdd3e46['key'],_0x4df4e6):0x1,_0x32b52a&&(_0x5a261f*=-0x1),_0x5a261f<0x0)this['isReverse_']?_0xdd3e46=_0xdd3e46['left']:_0xdd3e46=_0xdd3e46['right'];else{if(_0x5a261f===0x0){this['nodeStack_']['push'](_0xdd3e46);break;}else this['nodeStack_']['push'](_0xdd3e46),this['isReverse_']?_0xdd3e46=_0xdd3e46['right']:_0xdd3e46=_0xdd3e46['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x309306=this['nodeStack_']['pop'](),_0x4924ad;if(this['resultGenerator_']?_0x4924ad=this['resultGenerator_'](_0x309306['key'],_0x309306['value']):_0x4924ad={'key':_0x309306['key'],'value':_0x309306['value']},this['isReverse_']){for(_0x309306=_0x309306['left'];!_0x309306['isEmpty']();)this['nodeStack_']['push'](_0x309306),_0x309306=_0x309306['right'];}else{for(_0x309306=_0x309306['right'];!_0x309306['isEmpty']();)this['nodeStack_']['push'](_0x309306),_0x309306=_0x309306['left'];}return _0x4924ad;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x576ee2=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x576ee2['key'],_0x576ee2['value']):{'key':_0x576ee2['key'],'value':_0x576ee2['value']};}}class M{constructor(_0x1e4297,_0x3663f3,_0x584154,_0x401d85,_0x1f5f2d){this['key']=_0x1e4297,this['value']=_0x3663f3,this['color']=_0x584154??M['RED'],this['left']=_0x401d85??B['EMPTY_NODE'],this['right']=_0x1f5f2d??B['EMPTY_NODE'];}['copy'](_0x273a40,_0x189bf1,_0x5c680f,_0x5aa669,_0xef05c4){return new M(_0x273a40??this['key'],_0x189bf1??this['value'],_0x5c680f??this['color'],_0x5aa669??this['left'],_0xef05c4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2e3694){return this['left']['inorderTraversal'](_0x2e3694)||!!_0x2e3694(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2e3694);}['reverseTraversal'](_0x33716c){return this['right']['reverseTraversal'](_0x33716c)||_0x33716c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x33716c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3513a5,_0x56f77f,_0x118768){let _0x441a2b=this;const _0x434735=_0x118768(_0x3513a5,_0x441a2b['key']);return _0x434735<0x0?_0x441a2b=_0x441a2b['copy'](null,null,null,_0x441a2b['left']['insert'](_0x3513a5,_0x56f77f,_0x118768),null):_0x434735===0x0?_0x441a2b=_0x441a2b['copy'](null,_0x56f77f,null,null,null):_0x441a2b=_0x441a2b['copy'](null,null,null,null,_0x441a2b['right']['insert'](_0x3513a5,_0x56f77f,_0x118768)),_0x441a2b['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4abaa9=this;return!_0x4abaa9['left']['isRed_']()&&!_0x4abaa9['left']['left']['isRed_']()&&(_0x4abaa9=_0x4abaa9['moveRedLeft_']()),_0x4abaa9=_0x4abaa9['copy'](null,null,null,_0x4abaa9['left']['removeMin_'](),null),_0x4abaa9['fixUp_']();}['remove'](_0x564893,_0x3c35dd){let _0x85b404,_0x389dc2;if(_0x85b404=this,_0x3c35dd(_0x564893,_0x85b404['key'])<0x0)!_0x85b404['left']['isEmpty']()&&!_0x85b404['left']['isRed_']()&&!_0x85b404['left']['left']['isRed_']()&&(_0x85b404=_0x85b404['moveRedLeft_']()),_0x85b404=_0x85b404['copy'](null,null,null,_0x85b404['left']['remove'](_0x564893,_0x3c35dd),null);else{if(_0x85b404['left']['isRed_']()&&(_0x85b404=_0x85b404['rotateRight_']()),!_0x85b404['right']['isEmpty']()&&!_0x85b404['right']['isRed_']()&&!_0x85b404['right']['left']['isRed_']()&&(_0x85b404=_0x85b404['moveRedRight_']()),_0x3c35dd(_0x564893,_0x85b404['key'])===0x0){if(_0x85b404['right']['isEmpty']())return B['EMPTY_NODE'];_0x389dc2=_0x85b404['right']['min_'](),_0x85b404=_0x85b404['copy'](_0x389dc2['key'],_0x389dc2['value'],null,null,_0x85b404['right']['removeMin_']());}_0x85b404=_0x85b404['copy'](null,null,null,null,_0x85b404['right']['remove'](_0x564893,_0x3c35dd));}return _0x85b404['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x29bda9=this;return _0x29bda9['right']['isRed_']()&&!_0x29bda9['left']['isRed_']()&&(_0x29bda9=_0x29bda9['rotateLeft_']()),_0x29bda9['left']['isRed_']()&&_0x29bda9['left']['left']['isRed_']()&&(_0x29bda9=_0x29bda9['rotateRight_']()),_0x29bda9['left']['isRed_']()&&_0x29bda9['right']['isRed_']()&&(_0x29bda9=_0x29bda9['colorFlip_']()),_0x29bda9;}['moveRedLeft_'](){let _0x403d68=this['colorFlip_']();return _0x403d68['right']['left']['isRed_']()&&(_0x403d68=_0x403d68['copy'](null,null,null,null,_0x403d68['right']['rotateRight_']()),_0x403d68=_0x403d68['rotateLeft_'](),_0x403d68=_0x403d68['colorFlip_']()),_0x403d68;}['moveRedRight_'](){let _0xcd62f7=this['colorFlip_']();return _0xcd62f7['left']['left']['isRed_']()&&(_0xcd62f7=_0xcd62f7['rotateRight_'](),_0xcd62f7=_0xcd62f7['colorFlip_']()),_0xcd62f7;}['rotateLeft_'](){const _0x3836b0=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3836b0,null);}['rotateRight_'](){const _0x21f218=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x21f218);}['colorFlip_'](){const _0x214a97=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1bc379=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x214a97,_0x1bc379);}['checkMaxDepth_'](){const _0x33b78f=this['check_']();return Math['pow'](0x2,_0x33b78f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x559982=this['left']['check_']();if(_0x559982!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x559982+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x44801d,_0x5c2e6f,_0xc28807,_0x58dc2c,_0xd3485c){return this;}['insert'](_0x242e17,_0x2c7f7d,_0x42ce3d){return new M(_0x242e17,_0x2c7f7d,null);}['remove'](_0x405b65,_0xa0f5b6){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x14fd87){return!0x1;}['reverseTraversal'](_0x1b9ee7){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x470f1b,_0x58c762=B['EMPTY_NODE']){this['comparator_']=_0x470f1b,this['root_']=_0x58c762;}['insert'](_0x40f264,_0x551ac0){return new B(this['comparator_'],this['root_']['insert'](_0x40f264,_0x551ac0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x487e9b){return new B(this['comparator_'],this['root_']['remove'](_0x487e9b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x70cd2d){let _0x8ef34e,_0x5396cf=this['root_'];for(;!_0x5396cf['isEmpty']();){if(_0x8ef34e=this['comparator_'](_0x70cd2d,_0x5396cf['key']),_0x8ef34e===0x0)return _0x5396cf['value'];_0x8ef34e<0x0?_0x5396cf=_0x5396cf['left']:_0x8ef34e>0x0&&(_0x5396cf=_0x5396cf['right']);}return null;}['getPredecessorKey'](_0x564935){let _0x5b1359,_0x1e5430=this['root_'],_0x188d2a=null;for(;!_0x1e5430['isEmpty']();)if(_0x5b1359=this['comparator_'](_0x564935,_0x1e5430['key']),_0x5b1359===0x0){if(_0x1e5430['left']['isEmpty']())return _0x188d2a?_0x188d2a['key']:null;for(_0x1e5430=_0x1e5430['left'];!_0x1e5430['right']['isEmpty']();)_0x1e5430=_0x1e5430['right'];return _0x1e5430['key'];}else _0x5b1359<0x0?_0x1e5430=_0x1e5430['left']:_0x5b1359>0x0&&(_0x188d2a=_0x1e5430,_0x1e5430=_0x1e5430['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x542805){return this['root_']['inorderTraversal'](_0x542805);}['reverseTraversal'](_0x4eb575){return this['root_']['reverseTraversal'](_0x4eb575);}['getIterator'](_0x58e089){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x58e089);}['getIteratorFrom'](_0x517dbf,_0xbf57e7){return new Zt(this['root_'],_0x517dbf,this['comparator_'],!0x1,_0xbf57e7);}['getReverseIteratorFrom'](_0x45599b,_0x3d461b){return new Zt(this['root_'],_0x45599b,this['comparator_'],!0x0,_0x3d461b);}['getReverseIterator'](_0x14097f){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x14097f);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x2dba69,_0x31e8fa){return He(_0x2dba69['name'],_0x31e8fa['name']);}function ji(_0x194b25,_0x42d309){return He(_0x194b25,_0x42d309);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x384c3c){vi=_0x384c3c;}const Ro=function(_0x4d0655){return typeof _0x4d0655=='number'?'number:'+so(_0x4d0655):'string:'+_0x4d0655;},Ao=function(_0xd27859){if(_0xd27859['isLeafNode']()){const _0x2c1a87=_0xd27859['val']();f(typeof _0x2c1a87=='string'||typeof _0x2c1a87=='number'||typeof _0x2c1a87=='object'&&Y(_0x2c1a87,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xd27859===vi||_0xd27859['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xd27859===vi||_0xd27859['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x4ade98){er=_0x4ade98;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x16855d,_0x50cc61=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x16855d,this['priorityNode_']=_0x50cc61,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1f5ced){return new D(this['value_'],_0x1f5ced);}['getImmediateChild'](_0x41d5ed){return _0x41d5ed==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x58e766){return v(_0x58e766)?this:y(_0x58e766)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2f3bf3,_0x1a7b8f){return null;}['updateImmediateChild'](_0x46e354,_0x26912c){return _0x46e354==='.priority'?this['updatePriority'](_0x26912c):_0x26912c['isEmpty']()&&_0x46e354!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x46e354,_0x26912c)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x587bd7,_0x67a891){const _0x32325d=y(_0x587bd7);return _0x32325d===null?_0x67a891:_0x67a891['isEmpty']()&&_0x32325d!=='.priority'?this:(f(_0x32325d!=='.priority'||we(_0x587bd7)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x32325d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x587bd7),_0x67a891)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x220fba,_0x39774c){return!0x1;}['val'](_0x3405b9){return _0x3405b9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2d705b='';this['priorityNode_']['isEmpty']()||(_0x2d705b+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x271f38=typeof this['value_'];_0x2d705b+=_0x271f38+':',_0x271f38==='number'?_0x2d705b+=so(this['value_']):_0x2d705b+=this['value_'],this['lazyHash_']=no(_0x2d705b);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xa99a52){return _0xa99a52===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xa99a52 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xa99a52['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xa99a52));}['compareToLeafNode_'](_0x323bb6){const _0x46ecdd=typeof _0x323bb6['value_'],_0xe041b5=typeof this['value_'],_0x485df2=D['VALUE_TYPE_ORDER']['indexOf'](_0x46ecdd),_0x2a385f=D['VALUE_TYPE_ORDER']['indexOf'](_0xe041b5);return f(_0x485df2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x46ecdd),f(_0x2a385f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xe041b5),_0x485df2===_0x2a385f?_0xe041b5==='object'?0x0:this['value_']<_0x323bb6['value_']?-0x1:this['value_']===_0x323bb6['value_']?0x0:0x1:_0x2a385f-_0x485df2;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2666d6){if(_0x2666d6===this)return!0x0;if(_0x2666d6['isLeafNode']()){const _0x35c6ab=_0x2666d6;return this['value_']===_0x35c6ab['value_']&&this['priorityNode_']['equals'](_0x35c6ab['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x11ea05){ko=_0x11ea05;}function xh(_0x3e708b){No=_0x3e708b;}class Fh extends On{['compare'](_0x2d7f80,_0x32900e){const _0x532a52=_0x2d7f80['node']['getPriority'](),_0x276748=_0x32900e['node']['getPriority'](),_0x356757=_0x532a52['compareTo'](_0x276748);return _0x356757===0x0?He(_0x2d7f80['name'],_0x32900e['name']):_0x356757;}['isDefinedOn'](_0x195816){return!_0x195816['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x17bff7,_0x4f5c3b){return!_0x17bff7['getPriority']()['equals'](_0x4f5c3b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1ed3cf,_0x52b740){const _0x9aadd7=ko(_0x1ed3cf);return new E(_0x52b740,new D('[PRIORITY-POST]',_0x9aadd7));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x3bfb10){const _0x5511bb=_0x51cd61=>parseInt(Math['log'](_0x51cd61)/Uh,0xa),_0xe8b3f3=_0x15b4e2=>parseInt(Array(_0x15b4e2+0x1)['join']('1'),0x2);this['count']=_0x5511bb(_0x3bfb10+0x1),this['current_']=this['count']-0x1;const _0x494b90=_0xe8b3f3(this['count']);this['bits_']=_0x3bfb10+0x1&_0x494b90;}['nextBitIsOne'](){const _0x318949=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x318949;}}const dn=function(_0x5b1f11,_0x8f4dd9,_0x2e4427,_0xb9f783){_0x5b1f11['sort'](_0x8f4dd9);const _0x146e8b=function(_0x23f607,_0x5b6f14){const _0x11ad69=_0x5b6f14-_0x23f607;let _0x14b6ca,_0x1036bb;if(_0x11ad69===0x0)return null;if(_0x11ad69===0x1)return _0x14b6ca=_0x5b1f11[_0x23f607],_0x1036bb=_0x2e4427?_0x2e4427(_0x14b6ca):_0x14b6ca,new M(_0x1036bb,_0x14b6ca['node'],M['BLACK'],null,null);{const _0x2f5165=parseInt(_0x11ad69/0x2,0xa)+_0x23f607,_0x5cf5f0=_0x146e8b(_0x23f607,_0x2f5165),_0xb80ca=_0x146e8b(_0x2f5165+0x1,_0x5b6f14);return _0x14b6ca=_0x5b1f11[_0x2f5165],_0x1036bb=_0x2e4427?_0x2e4427(_0x14b6ca):_0x14b6ca,new M(_0x1036bb,_0x14b6ca['node'],M['BLACK'],_0x5cf5f0,_0xb80ca);}},_0x53e7aa=function(_0x2b88e6){let _0x1a7116=null,_0x2d54be=null,_0x23a57d=_0x5b1f11['length'];const _0xfd5391=function(_0x48996a,_0x1ea28c){const _0x17fcfe=_0x23a57d-_0x48996a,_0x54603b=_0x23a57d;_0x23a57d-=_0x48996a;const _0x403d6c=_0x146e8b(_0x17fcfe+0x1,_0x54603b),_0x3da85a=_0x5b1f11[_0x17fcfe],_0x242cfe=_0x2e4427?_0x2e4427(_0x3da85a):_0x3da85a;_0x18c40f(new M(_0x242cfe,_0x3da85a['node'],_0x1ea28c,null,_0x403d6c));},_0x18c40f=function(_0x117e94){_0x1a7116?(_0x1a7116['left']=_0x117e94,_0x1a7116=_0x117e94):(_0x2d54be=_0x117e94,_0x1a7116=_0x117e94);};for(let _0x580373=0x0;_0x580373<_0x2b88e6['count'];++_0x580373){const _0x218332=_0x2b88e6['nextBitIsOne'](),_0x150280=Math['pow'](0x2,_0x2b88e6['count']-(_0x580373+0x1));_0x218332?_0xfd5391(_0x150280,M['BLACK']):(_0xfd5391(_0x150280,M['BLACK']),_0xfd5391(_0x150280,M['RED']));}return _0x2d54be;},_0x3ea2ef=new Wh(_0x5b1f11['length']),_0x58bc13=_0x53e7aa(_0x3ea2ef);return new B(_0xb9f783||_0x8f4dd9,_0x58bc13);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2ad6ed,_0x5e9d1d){this['indexes_']=_0x2ad6ed,this['indexSet_']=_0x5e9d1d;}['get'](_0x9bcc36){const _0x154b47=Oe(this['indexes_'],_0x9bcc36);if(!_0x154b47)throw new Error('No\x20index\x20defined\x20for\x20'+_0x9bcc36);return _0x154b47 instanceof B?_0x154b47:null;}['hasIndex'](_0x1aaf17){return Y(this['indexSet_'],_0x1aaf17['toString']());}['addIndex'](_0x51c9fb,_0x5a4f5c){f(_0x51c9fb!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xa4a1b5=[];let _0x523e49=!0x1;const _0x4aa084=_0x5a4f5c['getIterator'](E['Wrap']);let _0x40d74e=_0x4aa084['getNext']();for(;_0x40d74e;)_0x523e49=_0x523e49||_0x51c9fb['isDefinedOn'](_0x40d74e['node']),_0xa4a1b5['push'](_0x40d74e),_0x40d74e=_0x4aa084['getNext']();let _0xebba71;_0x523e49?_0xebba71=dn(_0xa4a1b5,_0x51c9fb['getCompare']()):_0xebba71=je;const _0x202fa9=_0x51c9fb['toString'](),_0x415855={...this['indexSet_']};_0x415855[_0x202fa9]=_0x51c9fb;const _0x2265be={...this['indexes_']};return _0x2265be[_0x202fa9]=_0xebba71,new ee(_0x2265be,_0x415855);}['addToIndexes'](_0x1910a5,_0x51609b){const _0xa79bd0=ln(this['indexes_'],(_0x2e2f5d,_0x5a8ca7)=>{const _0x2e059b=Oe(this['indexSet_'],_0x5a8ca7);if(f(_0x2e059b,'Missing\x20index\x20implementation\x20for\x20'+_0x5a8ca7),_0x2e2f5d===je){if(_0x2e059b['isDefinedOn'](_0x1910a5['node'])){const _0x2f1045=[],_0x356afe=_0x51609b['getIterator'](E['Wrap']);let _0xc0ffca=_0x356afe['getNext']();for(;_0xc0ffca;)_0xc0ffca['name']!==_0x1910a5['name']&&_0x2f1045['push'](_0xc0ffca),_0xc0ffca=_0x356afe['getNext']();return _0x2f1045['push'](_0x1910a5),dn(_0x2f1045,_0x2e059b['getCompare']());}else return je;}else{const _0x599e1d=_0x51609b['get'](_0x1910a5['name']);let _0x3468e1=_0x2e2f5d;return _0x599e1d&&(_0x3468e1=_0x3468e1['remove'](new E(_0x1910a5['name'],_0x599e1d))),_0x3468e1['insert'](_0x1910a5,_0x1910a5['node']);}});return new ee(_0xa79bd0,this['indexSet_']);}['removeFromIndexes'](_0x5647b8,_0x14295a){const _0x2e5868=ln(this['indexes_'],_0x35696f=>{if(_0x35696f===je)return _0x35696f;{const _0xd65bfe=_0x14295a['get'](_0x5647b8['name']);return _0xd65bfe?_0x35696f['remove'](new E(_0x5647b8['name'],_0xd65bfe)):_0x35696f;}});return new ee(_0x2e5868,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x211b11,_0xa5b41b,_0x1a969a){this['children_']=_0x211b11,this['priorityNode_']=_0xa5b41b,this['indexMap_']=_0x1a969a,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x2fc42e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2fc42e,this['indexMap_']);}['getImmediateChild'](_0x1e083a){if(_0x1e083a==='.priority')return this['getPriority']();{const _0x5be0a7=this['children_']['get'](_0x1e083a);return _0x5be0a7===null?gt:_0x5be0a7;}}['getChild'](_0x9ae33c){const _0x3efa64=y(_0x9ae33c);return _0x3efa64===null?this:this['getImmediateChild'](_0x3efa64)['getChild'](b(_0x9ae33c));}['hasChild'](_0x112a06){return this['children_']['get'](_0x112a06)!==null;}['updateImmediateChild'](_0x4f73a1,_0x1b40a9){if(f(_0x1b40a9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4f73a1==='.priority')return this['updatePriority'](_0x1b40a9);{const _0x90e728=new E(_0x4f73a1,_0x1b40a9);let _0x2e1325,_0xd5d90c;_0x1b40a9['isEmpty']()?(_0x2e1325=this['children_']['remove'](_0x4f73a1),_0xd5d90c=this['indexMap_']['removeFromIndexes'](_0x90e728,this['children_'])):(_0x2e1325=this['children_']['insert'](_0x4f73a1,_0x1b40a9),_0xd5d90c=this['indexMap_']['addToIndexes'](_0x90e728,this['children_']));const _0xc6f288=_0x2e1325['isEmpty']()?gt:this['priorityNode_'];return new g(_0x2e1325,_0xc6f288,_0xd5d90c);}}['updateChild'](_0x3d69d3,_0x24b2ad){const _0x43ada1=y(_0x3d69d3);if(_0x43ada1===null)return _0x24b2ad;{f(y(_0x3d69d3)!=='.priority'||we(_0x3d69d3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5dbf65=this['getImmediateChild'](_0x43ada1)['updateChild'](b(_0x3d69d3),_0x24b2ad);return this['updateImmediateChild'](_0x43ada1,_0x5dbf65);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2f0ef6){if(this['isEmpty']())return null;const _0x12e4dd={};let _0x11cd53=0x0,_0x1ceecc=0x0,_0x2a3b43=!0x0;if(this['forEachChild'](R,(_0x55ec0b,_0x25ecde)=>{_0x12e4dd[_0x55ec0b]=_0x25ecde['val'](_0x2f0ef6),_0x11cd53++,_0x2a3b43&&g['INTEGER_REGEXP_']['test'](_0x55ec0b)?_0x1ceecc=Math['max'](_0x1ceecc,Number(_0x55ec0b)):_0x2a3b43=!0x1;}),!_0x2f0ef6&&_0x2a3b43&&_0x1ceecc<0x2*_0x11cd53){const _0x5d183c=[];for(const _0x2470ed in _0x12e4dd)_0x5d183c[_0x2470ed]=_0x12e4dd[_0x2470ed];return _0x5d183c;}else return _0x2f0ef6&&!this['getPriority']()['isEmpty']()&&(_0x12e4dd['.priority']=this['getPriority']()['val']()),_0x12e4dd;}['hash'](){if(this['lazyHash_']===null){let _0x27bfbf='';this['getPriority']()['isEmpty']()||(_0x27bfbf+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xfdca42,_0x48416b)=>{const _0x1994c0=_0x48416b['hash']();_0x1994c0!==''&&(_0x27bfbf+=':'+_0xfdca42+':'+_0x1994c0);}),this['lazyHash_']=_0x27bfbf===''?'':no(_0x27bfbf);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3a2ca7,_0x55f85b,_0xa10248){const _0x1632a5=this['resolveIndex_'](_0xa10248);if(_0x1632a5){const _0x4fc468=_0x1632a5['getPredecessorKey'](new E(_0x3a2ca7,_0x55f85b));return _0x4fc468?_0x4fc468['name']:null;}else return this['children_']['getPredecessorKey'](_0x3a2ca7);}['getFirstChildName'](_0x44133f){const _0x408ca7=this['resolveIndex_'](_0x44133f);if(_0x408ca7){const _0x25c987=_0x408ca7['minKey']();return _0x25c987&&_0x25c987['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5a17a5){const _0x535b7f=this['getFirstChildName'](_0x5a17a5);return _0x535b7f?new E(_0x535b7f,this['children_']['get'](_0x535b7f)):null;}['getLastChildName'](_0x46b442){const _0x4813b4=this['resolveIndex_'](_0x46b442);if(_0x4813b4){const _0x55f6cf=_0x4813b4['maxKey']();return _0x55f6cf&&_0x55f6cf['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4b9480){const _0x18d722=this['getLastChildName'](_0x4b9480);return _0x18d722?new E(_0x18d722,this['children_']['get'](_0x18d722)):null;}['forEachChild'](_0x2d33ba,_0x379472){const _0x30bc6f=this['resolveIndex_'](_0x2d33ba);return _0x30bc6f?_0x30bc6f['inorderTraversal'](_0x490f3e=>_0x379472(_0x490f3e['name'],_0x490f3e['node'])):this['children_']['inorderTraversal'](_0x379472);}['getIterator'](_0x2e6087){return this['getIteratorFrom'](_0x2e6087['minPost'](),_0x2e6087);}['getIteratorFrom'](_0x1c7ded,_0x184f88){const _0x5e0f0c=this['resolveIndex_'](_0x184f88);if(_0x5e0f0c)return _0x5e0f0c['getIteratorFrom'](_0x1c7ded,_0x28b0ed=>_0x28b0ed);{const _0x3d66c1=this['children_']['getIteratorFrom'](_0x1c7ded['name'],E['Wrap']);let _0xa21c69=_0x3d66c1['peek']();for(;_0xa21c69!=null&&_0x184f88['compare'](_0xa21c69,_0x1c7ded)<0x0;)_0x3d66c1['getNext'](),_0xa21c69=_0x3d66c1['peek']();return _0x3d66c1;}}['getReverseIterator'](_0x68a997){return this['getReverseIteratorFrom'](_0x68a997['maxPost'](),_0x68a997);}['getReverseIteratorFrom'](_0x2907af,_0x2340ae){const _0x5b6097=this['resolveIndex_'](_0x2340ae);if(_0x5b6097)return _0x5b6097['getReverseIteratorFrom'](_0x2907af,_0x3e8c59=>_0x3e8c59);{const _0x1e7793=this['children_']['getReverseIteratorFrom'](_0x2907af['name'],E['Wrap']);let _0x17bbd8=_0x1e7793['peek']();for(;_0x17bbd8!=null&&_0x2340ae['compare'](_0x17bbd8,_0x2907af)>0x0;)_0x1e7793['getNext'](),_0x17bbd8=_0x1e7793['peek']();return _0x1e7793;}}['compareTo'](_0x4b1065){return this['isEmpty']()?_0x4b1065['isEmpty']()?0x0:-0x1:_0x4b1065['isLeafNode']()||_0x4b1065['isEmpty']()?0x1:_0x4b1065===Ht?-0x1:0x0;}['withIndex'](_0x3a0218){if(_0x3a0218===ye||this['indexMap_']['hasIndex'](_0x3a0218))return this;{const _0x41c9c5=this['indexMap_']['addIndex'](_0x3a0218,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x41c9c5);}}['isIndexed'](_0x1bf11b){return _0x1bf11b===ye||this['indexMap_']['hasIndex'](_0x1bf11b);}['equals'](_0x2210d1){if(_0x2210d1===this)return!0x0;if(_0x2210d1['isLeafNode']())return!0x1;{const _0x2a31a4=_0x2210d1;if(this['getPriority']()['equals'](_0x2a31a4['getPriority']())){if(this['children_']['count']()===_0x2a31a4['children_']['count']()){const _0x241955=this['getIterator'](R),_0x4f0313=_0x2a31a4['getIterator'](R);let _0xf4c755=_0x241955['getNext'](),_0x1c8c0c=_0x4f0313['getNext']();for(;_0xf4c755&&_0x1c8c0c;){if(_0xf4c755['name']!==_0x1c8c0c['name']||!_0xf4c755['node']['equals'](_0x1c8c0c['node']))return!0x1;_0xf4c755=_0x241955['getNext'](),_0x1c8c0c=_0x4f0313['getNext']();}return _0xf4c755===null&&_0x1c8c0c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x387ffc){return _0x387ffc===ye?null:this['indexMap_']['get'](_0x387ffc['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x25d0d4){return _0x25d0d4===this?0x0:0x1;}['equals'](_0x140905){return _0x140905===this;}['getPriority'](){return this;}['getImmediateChild'](_0x15015e){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x32e38b,_0x4139fa=null){if(_0x32e38b===null)return g['EMPTY_NODE'];if(typeof _0x32e38b=='object'&&'.priority'in _0x32e38b&&(_0x4139fa=_0x32e38b['.priority']),f(_0x4139fa===null||typeof _0x4139fa=='string'||typeof _0x4139fa=='number'||typeof _0x4139fa=='object'&&'.sv'in _0x4139fa,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4139fa),typeof _0x32e38b=='object'&&'.value'in _0x32e38b&&_0x32e38b['.value']!==null&&(_0x32e38b=_0x32e38b['.value']),typeof _0x32e38b!='object'||'.sv'in _0x32e38b){const _0x5a58ac=_0x32e38b;return new D(_0x5a58ac,N(_0x4139fa));}if(!(_0x32e38b instanceof Array)&&Vh){const _0x3257e2=[];let _0x1ad9f5=!0x1;if(x(_0x32e38b,(_0x3a25c8,_0x3243ce)=>{if(_0x3a25c8['substring'](0x0,0x1)!=='.'){const _0x288bce=N(_0x3243ce);_0x288bce['isEmpty']()||(_0x1ad9f5=_0x1ad9f5||!_0x288bce['getPriority']()['isEmpty'](),_0x3257e2['push'](new E(_0x3a25c8,_0x288bce)));}}),_0x3257e2['length']===0x0)return g['EMPTY_NODE'];const _0x88a3df=dn(_0x3257e2,Dh,_0x2b4f59=>_0x2b4f59['name'],ji);if(_0x1ad9f5){const _0x2d2d5e=dn(_0x3257e2,R['getCompare']());return new g(_0x88a3df,N(_0x4139fa),new ee({'.priority':_0x2d2d5e},{'.priority':R}));}else return new g(_0x88a3df,N(_0x4139fa),ee['Default']);}else{let _0x9310aa=g['EMPTY_NODE'];return x(_0x32e38b,(_0x2f27ad,_0x479ef1)=>{if(Y(_0x32e38b,_0x2f27ad)&&_0x2f27ad['substring'](0x0,0x1)!=='.'){const _0x376f78=N(_0x479ef1);(_0x376f78['isLeafNode']()||!_0x376f78['isEmpty']())&&(_0x9310aa=_0x9310aa['updateImmediateChild'](_0x2f27ad,_0x376f78));}}),_0x9310aa['updatePriority'](N(_0x4139fa));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x425641){super(),this['indexPath_']=_0x425641,f(!v(_0x425641)&&y(_0x425641)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x18f236){return _0x18f236['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2c3803){return!_0x2c3803['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x12c35d,_0x5918b9){const _0x47dccd=this['extractChild'](_0x12c35d['node']),_0x1fd52f=this['extractChild'](_0x5918b9['node']),_0x129d6d=_0x47dccd['compareTo'](_0x1fd52f);return _0x129d6d===0x0?He(_0x12c35d['name'],_0x5918b9['name']):_0x129d6d;}['makePost'](_0x5bd3ca,_0x1cd07c){const _0x1b2c9d=N(_0x5bd3ca),_0x3e07a9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1b2c9d);return new E(_0x1cd07c,_0x3e07a9);}['maxPost'](){const _0x5a71d4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x5a71d4);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0xa7b20c,_0x2e19d7){const _0x197cee=_0xa7b20c['node']['compareTo'](_0x2e19d7['node']);return _0x197cee===0x0?He(_0xa7b20c['name'],_0x2e19d7['name']):_0x197cee;}['isDefinedOn'](_0x458077){return!0x0;}['indexedValueChanged'](_0x1e9143,_0x108b5e){return!_0x1e9143['equals'](_0x108b5e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x366bb2,_0x403001){const _0x57906c=N(_0x366bb2);return new E(_0x403001,_0x57906c);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x14b066){return{'type':'value','snapshotNode':_0x14b066};}function tt(_0x4d7aba,_0xb8d06a){return{'type':'child_added','snapshotNode':_0xb8d06a,'childName':_0x4d7aba};}function Nt(_0x38fb19,_0x3f432e){return{'type':'child_removed','snapshotNode':_0x3f432e,'childName':_0x38fb19};}function Pt(_0x17b045,_0x578673,_0x51ffa7){return{'type':'child_changed','snapshotNode':_0x578673,'childName':_0x17b045,'oldSnap':_0x51ffa7};}function $h(_0x699545,_0x5768bd){return{'type':'child_moved','snapshotNode':_0x5768bd,'childName':_0x699545};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x5d632f){this['index_']=_0x5d632f;}['updateChild'](_0x34fde9,_0x358ab4,_0x16e684,_0x1cf227,_0x22f76c,_0x3c5c90){f(_0x34fde9['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x193c80=_0x34fde9['getImmediateChild'](_0x358ab4);return _0x193c80['getChild'](_0x1cf227)['equals'](_0x16e684['getChild'](_0x1cf227))&&_0x193c80['isEmpty']()===_0x16e684['isEmpty']()||(_0x3c5c90!=null&&(_0x16e684['isEmpty']()?_0x34fde9['hasChild'](_0x358ab4)?_0x3c5c90['trackChildChange'](Nt(_0x358ab4,_0x193c80)):f(_0x34fde9['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x193c80['isEmpty']()?_0x3c5c90['trackChildChange'](tt(_0x358ab4,_0x16e684)):_0x3c5c90['trackChildChange'](Pt(_0x358ab4,_0x16e684,_0x193c80))),_0x34fde9['isLeafNode']()&&_0x16e684['isEmpty']())?_0x34fde9:_0x34fde9['updateImmediateChild'](_0x358ab4,_0x16e684)['withIndex'](this['index_']);}['updateFullNode'](_0x1bdf06,_0x1cfe8f,_0x4766f8){return _0x4766f8!=null&&(_0x1bdf06['isLeafNode']()||_0x1bdf06['forEachChild'](R,(_0x23a2d9,_0x59df74)=>{_0x1cfe8f['hasChild'](_0x23a2d9)||_0x4766f8['trackChildChange'](Nt(_0x23a2d9,_0x59df74));}),_0x1cfe8f['isLeafNode']()||_0x1cfe8f['forEachChild'](R,(_0x3ad6c1,_0x2a3c27)=>{if(_0x1bdf06['hasChild'](_0x3ad6c1)){const _0x3315e6=_0x1bdf06['getImmediateChild'](_0x3ad6c1);_0x3315e6['equals'](_0x2a3c27)||_0x4766f8['trackChildChange'](Pt(_0x3ad6c1,_0x2a3c27,_0x3315e6));}else _0x4766f8['trackChildChange'](tt(_0x3ad6c1,_0x2a3c27));})),_0x1cfe8f['withIndex'](this['index_']);}['updatePriority'](_0x4c2572,_0x1276db){return _0x4c2572['isEmpty']()?g['EMPTY_NODE']:_0x4c2572['updatePriority'](_0x1276db);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x3cb56a){this['indexedFilter_']=new Yi(_0x3cb56a['getIndex']()),this['index_']=_0x3cb56a['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x3cb56a),this['endPost_']=Ot['getEndPost_'](_0x3cb56a),this['startIsInclusive_']=!_0x3cb56a['startAfterSet_'],this['endIsInclusive_']=!_0x3cb56a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1bb774){const _0x3bcd59=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1bb774)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1bb774)<0x0,_0x2f369f=this['endIsInclusive_']?this['index_']['compare'](_0x1bb774,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1bb774,this['getEndPost']())<0x0;return _0x3bcd59&&_0x2f369f;}['updateChild'](_0x375f49,_0x5529f4,_0x3d362c,_0x31191f,_0x6eef3,_0x46b8af){return this['matches'](new E(_0x5529f4,_0x3d362c))||(_0x3d362c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x375f49,_0x5529f4,_0x3d362c,_0x31191f,_0x6eef3,_0x46b8af);}['updateFullNode'](_0x57e94b,_0x44c226,_0x36b687){_0x44c226['isLeafNode']()&&(_0x44c226=g['EMPTY_NODE']);let _0xb9d31f=_0x44c226['withIndex'](this['index_']);_0xb9d31f=_0xb9d31f['updatePriority'](g['EMPTY_NODE']);const _0x359553=this;return _0x44c226['forEachChild'](R,(_0x4c00a1,_0x1552fd)=>{_0x359553['matches'](new E(_0x4c00a1,_0x1552fd))||(_0xb9d31f=_0xb9d31f['updateImmediateChild'](_0x4c00a1,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x57e94b,_0xb9d31f,_0x36b687);}['updatePriority'](_0x3d1c2c,_0xb3942e){return _0x3d1c2c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1a360c){if(_0x1a360c['hasStart']()){const _0x2d224d=_0x1a360c['getIndexStartName']();return _0x1a360c['getIndex']()['makePost'](_0x1a360c['getIndexStartValue'](),_0x2d224d);}else return _0x1a360c['getIndex']()['minPost']();}static['getEndPost_'](_0x244860){if(_0x244860['hasEnd']()){const _0x17647a=_0x244860['getIndexEndName']();return _0x244860['getIndex']()['makePost'](_0x244860['getIndexEndValue'](),_0x17647a);}else return _0x244860['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x2fe93f){this['withinDirectionalStart']=_0xdc04f9=>this['reverse_']?this['withinEndPost'](_0xdc04f9):this['withinStartPost'](_0xdc04f9),this['withinDirectionalEnd']=_0x196d47=>this['reverse_']?this['withinStartPost'](_0x196d47):this['withinEndPost'](_0x196d47),this['withinStartPost']=_0x59b931=>{const _0x1e383b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x59b931);return this['startIsInclusive_']?_0x1e383b<=0x0:_0x1e383b<0x0;},this['withinEndPost']=_0x30dfcf=>{const _0xf4ff4e=this['index_']['compare'](_0x30dfcf,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xf4ff4e<=0x0:_0xf4ff4e<0x0;},this['rangedFilter_']=new Ot(_0x2fe93f),this['index_']=_0x2fe93f['getIndex'](),this['limit_']=_0x2fe93f['getLimit'](),this['reverse_']=!_0x2fe93f['isViewFromLeft'](),this['startIsInclusive_']=!_0x2fe93f['startAfterSet_'],this['endIsInclusive_']=!_0x2fe93f['endBeforeSet_'];}['updateChild'](_0x54f67e,_0xb5a9b0,_0x13f546,_0x51223a,_0x551a12,_0x3b1636){return this['rangedFilter_']['matches'](new E(_0xb5a9b0,_0x13f546))||(_0x13f546=g['EMPTY_NODE']),_0x54f67e['getImmediateChild'](_0xb5a9b0)['equals'](_0x13f546)?_0x54f67e:_0x54f67e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x54f67e,_0xb5a9b0,_0x13f546,_0x51223a,_0x551a12,_0x3b1636):this['fullLimitUpdateChild_'](_0x54f67e,_0xb5a9b0,_0x13f546,_0x551a12,_0x3b1636);}['updateFullNode'](_0x476662,_0x5e2632,_0x509433){let _0x3354d3;if(_0x5e2632['isLeafNode']()||_0x5e2632['isEmpty']())_0x3354d3=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5e2632['numChildren']()&&_0x5e2632['isIndexed'](this['index_'])){_0x3354d3=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x292f1f;this['reverse_']?_0x292f1f=_0x5e2632['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x292f1f=_0x5e2632['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xbcfd38=0x0;for(;_0x292f1f['hasNext']()&&_0xbcfd38<this['limit_'];){const _0x2639f2=_0x292f1f['getNext']();if(this['withinDirectionalStart'](_0x2639f2)){if(this['withinDirectionalEnd'](_0x2639f2))_0x3354d3=_0x3354d3['updateImmediateChild'](_0x2639f2['name'],_0x2639f2['node']),_0xbcfd38++;else break;}else continue;}}else{_0x3354d3=_0x5e2632['withIndex'](this['index_']),_0x3354d3=_0x3354d3['updatePriority'](g['EMPTY_NODE']);let _0x206766;this['reverse_']?_0x206766=_0x3354d3['getReverseIterator'](this['index_']):_0x206766=_0x3354d3['getIterator'](this['index_']);let _0x3f56db=0x0;for(;_0x206766['hasNext']();){const _0x37a776=_0x206766['getNext']();_0x3f56db<this['limit_']&&this['withinDirectionalStart'](_0x37a776)&&this['withinDirectionalEnd'](_0x37a776)?_0x3f56db++:_0x3354d3=_0x3354d3['updateImmediateChild'](_0x37a776['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x476662,_0x3354d3,_0x509433);}['updatePriority'](_0x423c40,_0x30553e){return _0x423c40;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1f43b7,_0x2f7c99,_0x5db588,_0x21a787,_0x106d9a){let _0x5a9464;if(this['reverse_']){const _0x3e6e6e=this['index_']['getCompare']();_0x5a9464=(_0x3fb39b,_0x50f8ec)=>_0x3e6e6e(_0x50f8ec,_0x3fb39b);}else _0x5a9464=this['index_']['getCompare']();const _0xfafc90=_0x1f43b7;f(_0xfafc90['numChildren']()===this['limit_'],'');const _0x1f355a=new E(_0x2f7c99,_0x5db588),_0x2cbdae=this['reverse_']?_0xfafc90['getFirstChild'](this['index_']):_0xfafc90['getLastChild'](this['index_']),_0x102621=this['rangedFilter_']['matches'](_0x1f355a);if(_0xfafc90['hasChild'](_0x2f7c99)){const _0x631e09=_0xfafc90['getImmediateChild'](_0x2f7c99);let _0x3a10b6=_0x21a787['getChildAfterChild'](this['index_'],_0x2cbdae,this['reverse_']);for(;_0x3a10b6!=null&&(_0x3a10b6['name']===_0x2f7c99||_0xfafc90['hasChild'](_0x3a10b6['name']));)_0x3a10b6=_0x21a787['getChildAfterChild'](this['index_'],_0x3a10b6,this['reverse_']);const _0x5bea99=_0x3a10b6==null?0x1:_0x5a9464(_0x3a10b6,_0x1f355a);if(_0x102621&&!_0x5db588['isEmpty']()&&_0x5bea99>=0x0)return _0x106d9a!=null&&_0x106d9a['trackChildChange'](Pt(_0x2f7c99,_0x5db588,_0x631e09)),_0xfafc90['updateImmediateChild'](_0x2f7c99,_0x5db588);{_0x106d9a!=null&&_0x106d9a['trackChildChange'](Nt(_0x2f7c99,_0x631e09));const _0x25a9bf=_0xfafc90['updateImmediateChild'](_0x2f7c99,g['EMPTY_NODE']);return _0x3a10b6!=null&&this['rangedFilter_']['matches'](_0x3a10b6)?(_0x106d9a!=null&&_0x106d9a['trackChildChange'](tt(_0x3a10b6['name'],_0x3a10b6['node'])),_0x25a9bf['updateImmediateChild'](_0x3a10b6['name'],_0x3a10b6['node'])):_0x25a9bf;}}else return _0x5db588['isEmpty']()?_0x1f43b7:_0x102621&&_0x5a9464(_0x2cbdae,_0x1f355a)>=0x0?(_0x106d9a!=null&&(_0x106d9a['trackChildChange'](Nt(_0x2cbdae['name'],_0x2cbdae['node'])),_0x106d9a['trackChildChange'](tt(_0x2f7c99,_0x5db588))),_0xfafc90['updateImmediateChild'](_0x2f7c99,_0x5db588)['updateImmediateChild'](_0x2cbdae['name'],g['EMPTY_NODE'])):_0x1f43b7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5e5b2c=new Qi();return _0x5e5b2c['limitSet_']=this['limitSet_'],_0x5e5b2c['limit_']=this['limit_'],_0x5e5b2c['startSet_']=this['startSet_'],_0x5e5b2c['startAfterSet_']=this['startAfterSet_'],_0x5e5b2c['indexStartValue_']=this['indexStartValue_'],_0x5e5b2c['startNameSet_']=this['startNameSet_'],_0x5e5b2c['indexStartName_']=this['indexStartName_'],_0x5e5b2c['endSet_']=this['endSet_'],_0x5e5b2c['endBeforeSet_']=this['endBeforeSet_'],_0x5e5b2c['indexEndValue_']=this['indexEndValue_'],_0x5e5b2c['endNameSet_']=this['endNameSet_'],_0x5e5b2c['indexEndName_']=this['indexEndName_'],_0x5e5b2c['index_']=this['index_'],_0x5e5b2c['viewFrom_']=this['viewFrom_'],_0x5e5b2c;}}function qh(_0x1b6d84){return _0x1b6d84['loadsAllData']()?new Yi(_0x1b6d84['getIndex']()):_0x1b6d84['hasLimit']()?new Gh(_0x1b6d84):new Ot(_0x1b6d84);}function zh(_0x55475e,_0x5e083a){const _0x2723c8=_0x55475e['copy']();return _0x2723c8['limitSet_']=!0x0,_0x2723c8['limit_']=_0x5e083a,_0x2723c8['viewFrom_']='l',_0x2723c8;}function jh(_0x80e422,_0x35edd9,_0x3b1da4){const _0x53d6cc=_0x80e422['copy']();return _0x53d6cc['startSet_']=!0x0,_0x35edd9===void 0x0&&(_0x35edd9=null),_0x53d6cc['indexStartValue_']=_0x35edd9,_0x3b1da4!=null?(_0x53d6cc['startNameSet_']=!0x0,_0x53d6cc['indexStartName_']=_0x3b1da4):(_0x53d6cc['startNameSet_']=!0x1,_0x53d6cc['indexStartName_']=''),_0x53d6cc;}function Kh(_0x46b9a0,_0x138ba0,_0x19db74){const _0x149232=_0x46b9a0['copy']();return _0x149232['endSet_']=!0x0,_0x138ba0===void 0x0&&(_0x138ba0=null),_0x149232['indexEndValue_']=_0x138ba0,_0x19db74!==void 0x0?(_0x149232['endNameSet_']=!0x0,_0x149232['indexEndName_']=_0x19db74):(_0x149232['endNameSet_']=!0x1,_0x149232['indexEndName_']=''),_0x149232;}function Do(_0x5cbf35,_0x27cb1d){const _0x311431=_0x5cbf35['copy']();return _0x311431['index_']=_0x27cb1d,_0x311431;}function tr(_0x5b3edb){const _0x48e8b0={};if(_0x5b3edb['isDefault']())return _0x48e8b0;let _0x5ebe2e;if(_0x5b3edb['index_']===R?_0x5ebe2e='$priority':_0x5b3edb['index_']===Po?_0x5ebe2e='$value':_0x5b3edb['index_']===ye?_0x5ebe2e='$key':(f(_0x5b3edb['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5ebe2e=_0x5b3edb['index_']['toString']()),_0x48e8b0['orderBy']=O(_0x5ebe2e),_0x5b3edb['startSet_']){const _0x430509=_0x5b3edb['startAfterSet_']?'startAfter':'startAt';_0x48e8b0[_0x430509]=O(_0x5b3edb['indexStartValue_']),_0x5b3edb['startNameSet_']&&(_0x48e8b0[_0x430509]+=','+O(_0x5b3edb['indexStartName_']));}if(_0x5b3edb['endSet_']){const _0x58b388=_0x5b3edb['endBeforeSet_']?'endBefore':'endAt';_0x48e8b0[_0x58b388]=O(_0x5b3edb['indexEndValue_']),_0x5b3edb['endNameSet_']&&(_0x48e8b0[_0x58b388]+=','+O(_0x5b3edb['indexEndName_']));}return _0x5b3edb['limitSet_']&&(_0x5b3edb['isViewFromLeft']()?_0x48e8b0['limitToFirst']=_0x5b3edb['limit_']:_0x48e8b0['limitToLast']=_0x5b3edb['limit_']),_0x48e8b0;}function nr(_0x63e279){const _0x378ad7={};if(_0x63e279['startSet_']&&(_0x378ad7['sp']=_0x63e279['indexStartValue_'],_0x63e279['startNameSet_']&&(_0x378ad7['sn']=_0x63e279['indexStartName_']),_0x378ad7['sin']=!_0x63e279['startAfterSet_']),_0x63e279['endSet_']&&(_0x378ad7['ep']=_0x63e279['indexEndValue_'],_0x63e279['endNameSet_']&&(_0x378ad7['en']=_0x63e279['indexEndName_']),_0x378ad7['ein']=!_0x63e279['endBeforeSet_']),_0x63e279['limitSet_']){_0x378ad7['l']=_0x63e279['limit_'];let _0x2c689f=_0x63e279['viewFrom_'];_0x2c689f===''&&(_0x63e279['isViewFromLeft']()?_0x2c689f='l':_0x2c689f='r'),_0x378ad7['vf']=_0x2c689f;}return _0x63e279['index_']!==R&&(_0x378ad7['i']=_0x63e279['index_']['toString']()),_0x378ad7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x5ae010){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5d8c0b,_0x2616d4){return _0x2616d4!==void 0x0?'tag$'+_0x2616d4:(f(_0x5d8c0b['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5d8c0b['_path']['toString']());}constructor(_0x2e55e2,_0x37b422,_0x2fa393,_0x3f5e70){super(),this['repoInfo_']=_0x2e55e2,this['onDataUpdate_']=_0x37b422,this['authTokenProvider_']=_0x2fa393,this['appCheckTokenProvider_']=_0x3f5e70,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x3701f6,_0xf14b6,_0x2216c2,_0x21c0db){const _0x42d1e7=_0x3701f6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x42d1e7+'\x20'+_0x3701f6['_queryIdentifier']);const _0x4705f0=fn['getListenId_'](_0x3701f6,_0x2216c2),_0x146f16={};this['listens_'][_0x4705f0]=_0x146f16;const _0x4fa8f6=tr(_0x3701f6['_queryParams']);this['restRequest_'](_0x42d1e7+'.json',_0x4fa8f6,(_0x2c6458,_0x1f0ac8)=>{let _0x142bac=_0x1f0ac8;if(_0x2c6458===0x194&&(_0x142bac=null,_0x2c6458=null),_0x2c6458===null&&this['onDataUpdate_'](_0x42d1e7,_0x142bac,!0x1,_0x2216c2),Oe(this['listens_'],_0x4705f0)===_0x146f16){let _0xf22a01;_0x2c6458?_0x2c6458===0x191?_0xf22a01='permission_denied':_0xf22a01='rest_error:'+_0x2c6458:_0xf22a01='ok',_0x21c0db(_0xf22a01,null);}});}['unlisten'](_0x291b25,_0x34ed99){const _0x17703=fn['getListenId_'](_0x291b25,_0x34ed99);delete this['listens_'][_0x17703];}['get'](_0x21fa9d){const _0x1a01cc=tr(_0x21fa9d['_queryParams']),_0x5a045e=_0x21fa9d['_path']['toString'](),_0x514052=new Ve();return this['restRequest_'](_0x5a045e+'.json',_0x1a01cc,(_0x53593b,_0x444792)=>{let _0x38ee47=_0x444792;_0x53593b===0x194&&(_0x38ee47=null,_0x53593b=null),_0x53593b===null?(this['onDataUpdate_'](_0x5a045e,_0x38ee47,!0x1,null),_0x514052['resolve'](_0x38ee47)):_0x514052['reject'](new Error(_0x38ee47));}),_0x514052['promise'];}['refreshAuthToken'](_0xa94105){}['restRequest_'](_0x49ece5,_0x45a27b={},_0x5b3dbb){return _0x45a27b['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xc4087c,_0x3c7b94])=>{_0xc4087c&&_0xc4087c['accessToken']&&(_0x45a27b['auth']=_0xc4087c['accessToken']),_0x3c7b94&&_0x3c7b94['token']&&(_0x45a27b['ac']=_0x3c7b94['token']);const _0x33464f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x49ece5+'?ns='+this['repoInfo_']['namespace']+at(_0x45a27b);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x33464f);const _0xcabc1b=new XMLHttpRequest();_0xcabc1b['onreadystatechange']=()=>{if(_0x5b3dbb&&_0xcabc1b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x33464f+'\x20received.\x20status:',_0xcabc1b['status'],'response:',_0xcabc1b['responseText']);let _0x5995a1=null;if(_0xcabc1b['status']>=0xc8&&_0xcabc1b['status']<0x12c){try{_0x5995a1=bt(_0xcabc1b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x33464f+':\x20'+_0xcabc1b['responseText']);}_0x5b3dbb(null,_0x5995a1);}else _0xcabc1b['status']!==0x191&&_0xcabc1b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x33464f+'\x20Status:\x20'+_0xcabc1b['status']),_0x5b3dbb(_0xcabc1b['status']);_0x5b3dbb=null;}},_0xcabc1b['open']('GET',_0x33464f,!0x0),_0xcabc1b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x45548b){return this['rootNode_']['getChild'](_0x45548b);}['updateSnapshot'](_0x1b54dc,_0x3de291){this['rootNode_']=this['rootNode_']['updateChild'](_0x1b54dc,_0x3de291);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x40cc8b,_0x5a02d5,_0x253cbd){if(v(_0x5a02d5))_0x40cc8b['value']=_0x253cbd,_0x40cc8b['children']['clear']();else{if(_0x40cc8b['value']!==null)_0x40cc8b['value']=_0x40cc8b['value']['updateChild'](_0x5a02d5,_0x253cbd);else{const _0x162e12=y(_0x5a02d5);_0x40cc8b['children']['has'](_0x162e12)||_0x40cc8b['children']['set'](_0x162e12,pn());const _0x969b05=_0x40cc8b['children']['get'](_0x162e12);_0x5a02d5=b(_0x5a02d5),Mo(_0x969b05,_0x5a02d5,_0x253cbd);}}}function Ei(_0x5be524,_0x302ba3,_0x4506d5){_0x5be524['value']!==null?_0x4506d5(_0x302ba3,_0x5be524['value']):Qh(_0x5be524,(_0x2c9c4f,_0xc4783d)=>{const _0x41908d=new C(_0x302ba3['toString']()+'/'+_0x2c9c4f);Ei(_0xc4783d,_0x41908d,_0x4506d5);});}function Qh(_0x29fedf,_0x55e2ce){_0x29fedf['children']['forEach']((_0x283b7b,_0xaab09b)=>{_0x55e2ce(_0xaab09b,_0x283b7b);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x15876a){this['collection_']=_0x15876a,this['last_']=null;}['get'](){const _0x52d40c=this['collection_']['get'](),_0x4b8495={..._0x52d40c};return this['last_']&&x(this['last_'],(_0x57a01a,_0x18303d)=>{_0x4b8495[_0x57a01a]=_0x4b8495[_0x57a01a]-_0x18303d;}),this['last_']=_0x52d40c,_0x4b8495;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x42b0ca,_0x5a2967){this['server_']=_0x5a2967,this['statsToReport_']={},this['statsListener_']=new Jh(_0x42b0ca);const _0x2a0472=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2a0472));}['reportStats_'](){const _0x3bea85=this['statsListener_']['get'](),_0x2baf09={};let _0x4b218a=!0x1;x(_0x3bea85,(_0x4aba7f,_0x4acd72)=>{_0x4acd72>0x0&&Y(this['statsToReport_'],_0x4aba7f)&&(_0x2baf09[_0x4aba7f]=_0x4acd72,_0x4b218a=!0x0);}),_0x4b218a&&this['server_']['reportStats'](_0x2baf09),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x439219){_0x439219[_0x439219['OVERWRITE']=0x0]='OVERWRITE',_0x439219[_0x439219['MERGE']=0x1]='MERGE',_0x439219[_0x439219['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x439219[_0x439219['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x34f771){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x34f771,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4a0a6a,_0x5bb5e4,_0x106946){this['path']=_0x4a0a6a,this['affectedTree']=_0x5bb5e4,this['revert']=_0x106946,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x4fc974){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x594b41=this['affectedTree']['subtree'](new C(_0x4fc974));return new _n(w(),_0x594b41,this['revert']);}}else return f(y(this['path'])===_0x4fc974,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5e5155,_0x25e637){this['source']=_0x5e5155,this['path']=_0x25e637,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x21c1f9){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x303c33,_0x1fb01e,_0x270c07){this['source']=_0x303c33,this['path']=_0x1fb01e,this['snap']=_0x270c07,this['type']=q['OVERWRITE'];}['operationForChild'](_0xfeb99c){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0xfeb99c)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xa9614c,_0x13dffe,_0x2cf93d){this['source']=_0xa9614c,this['path']=_0x13dffe,this['children']=_0x2cf93d,this['type']=q['MERGE'];}['operationForChild'](_0x171997){if(v(this['path'])){const _0x5a7307=this['children']['subtree'](new C(_0x171997));return _0x5a7307['isEmpty']()?null:_0x5a7307['value']?new Fe(this['source'],w(),_0x5a7307['value']):new nt(this['source'],w(),_0x5a7307);}else return f(y(this['path'])===_0x171997,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x4293fd,_0x3e535d,_0x10af60){this['node_']=_0x4293fd,this['fullyInitialized_']=_0x3e535d,this['filtered_']=_0x10af60;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3858de){if(v(_0x3858de))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1c96d6=y(_0x3858de);return this['isCompleteForChild'](_0x1c96d6);}['isCompleteForChild'](_0x510b24){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x510b24);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x5affa3){this['query_']=_0x5affa3,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5a6415,_0x3d4343,_0x13a8af,_0x4d4b3e){const _0x5baef8=[],_0x49d61b=[];return _0x3d4343['forEach'](_0xb9436b=>{_0xb9436b['type']==='child_changed'&&_0x5a6415['index_']['indexedValueChanged'](_0xb9436b['oldSnap'],_0xb9436b['snapshotNode'])&&_0x49d61b['push']($h(_0xb9436b['childName'],_0xb9436b['snapshotNode']));}),mt(_0x5a6415,_0x5baef8,'child_removed',_0x3d4343,_0x4d4b3e,_0x13a8af),mt(_0x5a6415,_0x5baef8,'child_added',_0x3d4343,_0x4d4b3e,_0x13a8af),mt(_0x5a6415,_0x5baef8,'child_moved',_0x49d61b,_0x4d4b3e,_0x13a8af),mt(_0x5a6415,_0x5baef8,'child_changed',_0x3d4343,_0x4d4b3e,_0x13a8af),mt(_0x5a6415,_0x5baef8,'value',_0x3d4343,_0x4d4b3e,_0x13a8af),_0x5baef8;}function mt(_0x4d9147,_0x325b04,_0x4c51e4,_0x1b898b,_0x114f33,_0x43cf6a){const _0x3038be=_0x1b898b['filter'](_0x23079a=>_0x23079a['type']===_0x4c51e4);_0x3038be['sort']((_0x43a17f,_0x345cc1)=>su(_0x4d9147,_0x43a17f,_0x345cc1)),_0x3038be['forEach'](_0x26c3d9=>{const _0x5160d9=iu(_0x4d9147,_0x26c3d9,_0x43cf6a);_0x114f33['forEach'](_0x1a634e=>{_0x1a634e['respondsTo'](_0x26c3d9['type'])&&_0x325b04['push'](_0x1a634e['createEvent'](_0x5160d9,_0x4d9147['query_']));});});}function iu(_0x4a15fc,_0xc035e,_0x4e4981){return _0xc035e['type']==='value'||_0xc035e['type']==='child_removed'||(_0xc035e['prevName']=_0x4e4981['getPredecessorChildName'](_0xc035e['childName'],_0xc035e['snapshotNode'],_0x4a15fc['index_'])),_0xc035e;}function su(_0x4d785f,_0x32fd6a,_0x525f2d){if(_0x32fd6a['childName']==null||_0x525f2d['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3549d7=new E(_0x32fd6a['childName'],_0x32fd6a['snapshotNode']),_0x3ebe53=new E(_0x525f2d['childName'],_0x525f2d['snapshotNode']);return _0x4d785f['index_']['compare'](_0x3549d7,_0x3ebe53);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4d9c54,_0x47deb8){return{'eventCache':_0x4d9c54,'serverCache':_0x47deb8};}function wt(_0x2ca46b,_0x53e0ad,_0x26b28f,_0x3a3228){return Dn(new Ce(_0x53e0ad,_0x26b28f,_0x3a3228),_0x2ca46b['serverCache']);}function Lo(_0x539c10,_0x2c22e6,_0x30b6a8,_0xd2b9c1){return Dn(_0x539c10['eventCache'],new Ce(_0x2c22e6,_0x30b6a8,_0xd2b9c1));}function gn(_0x1121ff){return _0x1121ff['eventCache']['isFullyInitialized']()?_0x1121ff['eventCache']['getNode']():null;}function Ue(_0x5821a1){return _0x5821a1['serverCache']['isFullyInitialized']()?_0x5821a1['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x4c4591){let _0x8aee7a=new S(null);return x(_0x4c4591,(_0x3edcb9,_0x1bf71f)=>{_0x8aee7a=_0x8aee7a['set'](new C(_0x3edcb9),_0x1bf71f);}),_0x8aee7a;}constructor(_0x4e4386,_0xd7bdba=ru()){this['value']=_0x4e4386,this['children']=_0xd7bdba;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1bf9f8,_0xb5ebe5){if(this['value']!=null&&_0xb5ebe5(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1bf9f8))return null;{const _0x5dd013=y(_0x1bf9f8),_0x1ca4e3=this['children']['get'](_0x5dd013);if(_0x1ca4e3!==null){const _0x85b7c2=_0x1ca4e3['findRootMostMatchingPathAndValue'](b(_0x1bf9f8),_0xb5ebe5);return _0x85b7c2!=null?{'path':A(new C(_0x5dd013),_0x85b7c2['path']),'value':_0x85b7c2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x319613){return this['findRootMostMatchingPathAndValue'](_0x319613,()=>!0x0);}['subtree'](_0x2deeaf){if(v(_0x2deeaf))return this;{const _0x8cd275=y(_0x2deeaf),_0xbad74d=this['children']['get'](_0x8cd275);return _0xbad74d!==null?_0xbad74d['subtree'](b(_0x2deeaf)):new S(null);}}['set'](_0x38a745,_0x2d64ec){if(v(_0x38a745))return new S(_0x2d64ec,this['children']);{const _0x13c6fa=y(_0x38a745),_0x467d8f=(this['children']['get'](_0x13c6fa)||new S(null))['set'](b(_0x38a745),_0x2d64ec),_0x2b9ed1=this['children']['insert'](_0x13c6fa,_0x467d8f);return new S(this['value'],_0x2b9ed1);}}['remove'](_0xb0573b){if(v(_0xb0573b))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x27fd97=y(_0xb0573b),_0x49602f=this['children']['get'](_0x27fd97);if(_0x49602f){const _0x4f827a=_0x49602f['remove'](b(_0xb0573b));let _0x514665;return _0x4f827a['isEmpty']()?_0x514665=this['children']['remove'](_0x27fd97):_0x514665=this['children']['insert'](_0x27fd97,_0x4f827a),this['value']===null&&_0x514665['isEmpty']()?new S(null):new S(this['value'],_0x514665);}else return this;}}['get'](_0x1fcf6a){if(v(_0x1fcf6a))return this['value'];{const _0x43a5b8=y(_0x1fcf6a),_0x3f4d46=this['children']['get'](_0x43a5b8);return _0x3f4d46?_0x3f4d46['get'](b(_0x1fcf6a)):null;}}['setTree'](_0xa28270,_0x32c6a7){if(v(_0xa28270))return _0x32c6a7;{const _0x5d8967=y(_0xa28270),_0x8549dd=(this['children']['get'](_0x5d8967)||new S(null))['setTree'](b(_0xa28270),_0x32c6a7);let _0x2b41df;return _0x8549dd['isEmpty']()?_0x2b41df=this['children']['remove'](_0x5d8967):_0x2b41df=this['children']['insert'](_0x5d8967,_0x8549dd),new S(this['value'],_0x2b41df);}}['fold'](_0x343df2){return this['fold_'](w(),_0x343df2);}['fold_'](_0x5b7414,_0x5964f0){const _0x29612c={};return this['children']['inorderTraversal']((_0x97f885,_0xcb0700)=>{_0x29612c[_0x97f885]=_0xcb0700['fold_'](A(_0x5b7414,_0x97f885),_0x5964f0);}),_0x5964f0(_0x5b7414,this['value'],_0x29612c);}['findOnPath'](_0x552362,_0x2472e0){return this['findOnPath_'](_0x552362,w(),_0x2472e0);}['findOnPath_'](_0x1579f3,_0x12896f,_0x5021fa){const _0x419f0d=this['value']?_0x5021fa(_0x12896f,this['value']):!0x1;if(_0x419f0d)return _0x419f0d;if(v(_0x1579f3))return null;{const _0x4e9b40=y(_0x1579f3),_0x12028d=this['children']['get'](_0x4e9b40);return _0x12028d?_0x12028d['findOnPath_'](b(_0x1579f3),A(_0x12896f,_0x4e9b40),_0x5021fa):null;}}['foreachOnPath'](_0xe60ace,_0x4270d1){return this['foreachOnPath_'](_0xe60ace,w(),_0x4270d1);}['foreachOnPath_'](_0x9cca9e,_0x49fb8f,_0x48f713){if(v(_0x9cca9e))return this;{this['value']&&_0x48f713(_0x49fb8f,this['value']);const _0x12dabf=y(_0x9cca9e),_0x491fff=this['children']['get'](_0x12dabf);return _0x491fff?_0x491fff['foreachOnPath_'](b(_0x9cca9e),A(_0x49fb8f,_0x12dabf),_0x48f713):new S(null);}}['foreach'](_0x48655c){this['foreach_'](w(),_0x48655c);}['foreach_'](_0x19c42b,_0xc55561){this['children']['inorderTraversal']((_0xd4885,_0x20b667)=>{_0x20b667['foreach_'](A(_0x19c42b,_0xd4885),_0xc55561);}),this['value']&&_0xc55561(_0x19c42b,this['value']);}['foreachChild'](_0x3b0c1f){this['children']['inorderTraversal']((_0x5bcf10,_0x553988)=>{_0x553988['value']&&_0x3b0c1f(_0x5bcf10,_0x553988['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x181ed6){this['writeTree_']=_0x181ed6;}static['empty'](){return new j(new S(null));}}function Ct(_0x1eb4e7,_0x1c9e3a,_0x334227){if(v(_0x1c9e3a))return new j(new S(_0x334227));{const _0x45066e=_0x1eb4e7['writeTree_']['findRootMostValueAndPath'](_0x1c9e3a);if(_0x45066e!=null){const _0x353b67=_0x45066e['path'];let _0x44983a=_0x45066e['value'];const _0x363aa7=F(_0x353b67,_0x1c9e3a);return _0x44983a=_0x44983a['updateChild'](_0x363aa7,_0x334227),new j(_0x1eb4e7['writeTree_']['set'](_0x353b67,_0x44983a));}else{const _0x245e6d=new S(_0x334227),_0x820e6f=_0x1eb4e7['writeTree_']['setTree'](_0x1c9e3a,_0x245e6d);return new j(_0x820e6f);}}}function Ii(_0x4aff83,_0x599c0a,_0xd150e5){let _0x5c7ca8=_0x4aff83;return x(_0xd150e5,(_0x26dce5,_0x49b85c)=>{_0x5c7ca8=Ct(_0x5c7ca8,A(_0x599c0a,_0x26dce5),_0x49b85c);}),_0x5c7ca8;}function sr(_0x3ea2ad,_0x2c3b67){if(v(_0x2c3b67))return j['empty']();{const _0x4bf53b=_0x3ea2ad['writeTree_']['setTree'](_0x2c3b67,new S(null));return new j(_0x4bf53b);}}function wi(_0x555b16,_0x179501){return $e(_0x555b16,_0x179501)!=null;}function $e(_0x25dd78,_0x43b2b8){const _0x5b49ea=_0x25dd78['writeTree_']['findRootMostValueAndPath'](_0x43b2b8);return _0x5b49ea!=null?_0x25dd78['writeTree_']['get'](_0x5b49ea['path'])['getChild'](F(_0x5b49ea['path'],_0x43b2b8)):null;}function rr(_0x46f167){const _0x2ace60=[],_0x5ce18e=_0x46f167['writeTree_']['value'];return _0x5ce18e!=null?_0x5ce18e['isLeafNode']()||_0x5ce18e['forEachChild'](R,(_0x139fc1,_0x85f0ad)=>{_0x2ace60['push'](new E(_0x139fc1,_0x85f0ad));}):_0x46f167['writeTree_']['children']['inorderTraversal']((_0x1839bf,_0x147e6f)=>{_0x147e6f['value']!=null&&_0x2ace60['push'](new E(_0x1839bf,_0x147e6f['value']));}),_0x2ace60;}function ve(_0x158dcc,_0x534a8a){if(v(_0x534a8a))return _0x158dcc;{const _0x18effb=$e(_0x158dcc,_0x534a8a);return _0x18effb!=null?new j(new S(_0x18effb)):new j(_0x158dcc['writeTree_']['subtree'](_0x534a8a));}}function Ci(_0x283ab4){return _0x283ab4['writeTree_']['isEmpty']();}function it(_0x30c896,_0xefb5fa){return xo(w(),_0x30c896['writeTree_'],_0xefb5fa);}function xo(_0x5b7557,_0x101565,_0x3137ad){if(_0x101565['value']!=null)return _0x3137ad['updateChild'](_0x5b7557,_0x101565['value']);{let _0x3c1757=null;return _0x101565['children']['inorderTraversal']((_0x397249,_0x358cd4)=>{_0x397249==='.priority'?(f(_0x358cd4['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3c1757=_0x358cd4['value']):_0x3137ad=xo(A(_0x5b7557,_0x397249),_0x358cd4,_0x3137ad);}),!_0x3137ad['getChild'](_0x5b7557)['isEmpty']()&&_0x3c1757!==null&&(_0x3137ad=_0x3137ad['updateChild'](A(_0x5b7557,'.priority'),_0x3c1757)),_0x3137ad;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1bb14d,_0x19135d){return Bo(_0x19135d,_0x1bb14d);}function ou(_0x4078db,_0x225b56,_0x2c2882,_0x17010f,_0x608737){f(_0x17010f>_0x4078db['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x608737===void 0x0&&(_0x608737=!0x0),_0x4078db['allWrites']['push']({'path':_0x225b56,'snap':_0x2c2882,'writeId':_0x17010f,'visible':_0x608737}),_0x608737&&(_0x4078db['visibleWrites']=Ct(_0x4078db['visibleWrites'],_0x225b56,_0x2c2882)),_0x4078db['lastWriteId']=_0x17010f;}function au(_0xbddd2d,_0x310ccb,_0x53b857,_0x3a3e4c){f(_0x3a3e4c>_0xbddd2d['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xbddd2d['allWrites']['push']({'path':_0x310ccb,'children':_0x53b857,'writeId':_0x3a3e4c,'visible':!0x0}),_0xbddd2d['visibleWrites']=Ii(_0xbddd2d['visibleWrites'],_0x310ccb,_0x53b857),_0xbddd2d['lastWriteId']=_0x3a3e4c;}function cu(_0x4a7f81,_0x18d233){for(let _0x33fe03=0x0;_0x33fe03<_0x4a7f81['allWrites']['length'];_0x33fe03++){const _0x172e69=_0x4a7f81['allWrites'][_0x33fe03];if(_0x172e69['writeId']===_0x18d233)return _0x172e69;}return null;}function lu(_0x1b9ff5,_0x9ed265){const _0x4ccc7a=_0x1b9ff5['allWrites']['findIndex'](_0x58ff8a=>_0x58ff8a['writeId']===_0x9ed265);f(_0x4ccc7a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3c87e7=_0x1b9ff5['allWrites'][_0x4ccc7a];_0x1b9ff5['allWrites']['splice'](_0x4ccc7a,0x1);let _0x2893e1=_0x3c87e7['visible'],_0x11320a=!0x1,_0xc1730b=_0x1b9ff5['allWrites']['length']-0x1;for(;_0x2893e1&&_0xc1730b>=0x0;){const _0x1b1383=_0x1b9ff5['allWrites'][_0xc1730b];_0x1b1383['visible']&&(_0xc1730b>=_0x4ccc7a&&hu(_0x1b1383,_0x3c87e7['path'])?_0x2893e1=!0x1:$(_0x3c87e7['path'],_0x1b1383['path'])&&(_0x11320a=!0x0)),_0xc1730b--;}if(_0x2893e1){if(_0x11320a)return uu(_0x1b9ff5),!0x0;if(_0x3c87e7['snap'])_0x1b9ff5['visibleWrites']=sr(_0x1b9ff5['visibleWrites'],_0x3c87e7['path']);else{const _0x4a4970=_0x3c87e7['children'];x(_0x4a4970,_0x3176eb=>{_0x1b9ff5['visibleWrites']=sr(_0x1b9ff5['visibleWrites'],A(_0x3c87e7['path'],_0x3176eb));});}return!0x0;}else return!0x1;}function hu(_0x4ef695,_0x4ac77c){if(_0x4ef695['snap'])return $(_0x4ef695['path'],_0x4ac77c);for(const _0x4a190a in _0x4ef695['children'])if(_0x4ef695['children']['hasOwnProperty'](_0x4a190a)&&$(A(_0x4ef695['path'],_0x4a190a),_0x4ac77c))return!0x0;return!0x1;}function uu(_0x15eb24){_0x15eb24['visibleWrites']=Fo(_0x15eb24['allWrites'],du,w()),_0x15eb24['allWrites']['length']>0x0?_0x15eb24['lastWriteId']=_0x15eb24['allWrites'][_0x15eb24['allWrites']['length']-0x1]['writeId']:_0x15eb24['lastWriteId']=-0x1;}function du(_0x24a9a){return _0x24a9a['visible'];}function Fo(_0x354db5,_0x43a1bd,_0x5878f7){let _0x3e068d=j['empty']();for(let _0x390aa6=0x0;_0x390aa6<_0x354db5['length'];++_0x390aa6){const _0x1a172c=_0x354db5[_0x390aa6];if(_0x43a1bd(_0x1a172c)){const _0xf5bbac=_0x1a172c['path'];let _0x343365;if(_0x1a172c['snap'])$(_0x5878f7,_0xf5bbac)?(_0x343365=F(_0x5878f7,_0xf5bbac),_0x3e068d=Ct(_0x3e068d,_0x343365,_0x1a172c['snap'])):$(_0xf5bbac,_0x5878f7)&&(_0x343365=F(_0xf5bbac,_0x5878f7),_0x3e068d=Ct(_0x3e068d,w(),_0x1a172c['snap']['getChild'](_0x343365)));else{if(_0x1a172c['children']){if($(_0x5878f7,_0xf5bbac))_0x343365=F(_0x5878f7,_0xf5bbac),_0x3e068d=Ii(_0x3e068d,_0x343365,_0x1a172c['children']);else{if($(_0xf5bbac,_0x5878f7)){if(_0x343365=F(_0xf5bbac,_0x5878f7),v(_0x343365))_0x3e068d=Ii(_0x3e068d,w(),_0x1a172c['children']);else{const _0x11d39f=Oe(_0x1a172c['children'],y(_0x343365));if(_0x11d39f){const _0x4bbb10=_0x11d39f['getChild'](b(_0x343365));_0x3e068d=Ct(_0x3e068d,w(),_0x4bbb10);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3e068d;}function Uo(_0x11ce37,_0x17d61c,_0x5cfdc0,_0x339dd6,_0x262bea){if(!_0x339dd6&&!_0x262bea){const _0x1247dd=$e(_0x11ce37['visibleWrites'],_0x17d61c);if(_0x1247dd!=null)return _0x1247dd;{const _0x3e5378=ve(_0x11ce37['visibleWrites'],_0x17d61c);if(Ci(_0x3e5378))return _0x5cfdc0;if(_0x5cfdc0==null&&!wi(_0x3e5378,w()))return null;{const _0xac184f=_0x5cfdc0||g['EMPTY_NODE'];return it(_0x3e5378,_0xac184f);}}}else{const _0x31ad0b=ve(_0x11ce37['visibleWrites'],_0x17d61c);if(!_0x262bea&&Ci(_0x31ad0b))return _0x5cfdc0;if(!_0x262bea&&_0x5cfdc0==null&&!wi(_0x31ad0b,w()))return null;{const _0xf3ff42=function(_0x58f438){return(_0x58f438['visible']||_0x262bea)&&(!_0x339dd6||!~_0x339dd6['indexOf'](_0x58f438['writeId']))&&($(_0x58f438['path'],_0x17d61c)||$(_0x17d61c,_0x58f438['path']));},_0x2a4e67=Fo(_0x11ce37['allWrites'],_0xf3ff42,_0x17d61c),_0x52be89=_0x5cfdc0||g['EMPTY_NODE'];return it(_0x2a4e67,_0x52be89);}}}function fu(_0x1eafd1,_0x1cd0eb,_0x514382){let _0x40d7c6=g['EMPTY_NODE'];const _0x26fd47=$e(_0x1eafd1['visibleWrites'],_0x1cd0eb);if(_0x26fd47)return _0x26fd47['isLeafNode']()||_0x26fd47['forEachChild'](R,(_0x1d7709,_0x2d91c5)=>{_0x40d7c6=_0x40d7c6['updateImmediateChild'](_0x1d7709,_0x2d91c5);}),_0x40d7c6;if(_0x514382){const _0x2fbf2a=ve(_0x1eafd1['visibleWrites'],_0x1cd0eb);return _0x514382['forEachChild'](R,(_0x13fcb6,_0x22796f)=>{const _0x1525ac=it(ve(_0x2fbf2a,new C(_0x13fcb6)),_0x22796f);_0x40d7c6=_0x40d7c6['updateImmediateChild'](_0x13fcb6,_0x1525ac);}),rr(_0x2fbf2a)['forEach'](_0x53ab90=>{_0x40d7c6=_0x40d7c6['updateImmediateChild'](_0x53ab90['name'],_0x53ab90['node']);}),_0x40d7c6;}else{const _0x212fee=ve(_0x1eafd1['visibleWrites'],_0x1cd0eb);return rr(_0x212fee)['forEach'](_0x17190f=>{_0x40d7c6=_0x40d7c6['updateImmediateChild'](_0x17190f['name'],_0x17190f['node']);}),_0x40d7c6;}}function pu(_0x5b2d7c,_0x3ee3c5,_0x1cea2c,_0x89df81,_0x37617a){f(_0x89df81||_0x37617a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5579b6=A(_0x3ee3c5,_0x1cea2c);if(wi(_0x5b2d7c['visibleWrites'],_0x5579b6))return null;{const _0x3c669d=ve(_0x5b2d7c['visibleWrites'],_0x5579b6);return Ci(_0x3c669d)?_0x37617a['getChild'](_0x1cea2c):it(_0x3c669d,_0x37617a['getChild'](_0x1cea2c));}}function _u(_0x1383f5,_0x2eb2c6,_0x241105,_0x1e1e6b){const _0x57812e=A(_0x2eb2c6,_0x241105),_0x53c142=$e(_0x1383f5['visibleWrites'],_0x57812e);if(_0x53c142!=null)return _0x53c142;if(_0x1e1e6b['isCompleteForChild'](_0x241105)){const _0x49e87d=ve(_0x1383f5['visibleWrites'],_0x57812e);return it(_0x49e87d,_0x1e1e6b['getNode']()['getImmediateChild'](_0x241105));}else return null;}function gu(_0x3b354d,_0x2b54f3){return $e(_0x3b354d['visibleWrites'],_0x2b54f3);}function mu(_0x4c8f66,_0x14fe94,_0x7592d3,_0x5b86fa,_0x183951,_0x12b6b4,_0x44f8e9){let _0x346724;const _0x4f5c9c=ve(_0x4c8f66['visibleWrites'],_0x14fe94),_0x30ba88=$e(_0x4f5c9c,w());if(_0x30ba88!=null)_0x346724=_0x30ba88;else{if(_0x7592d3!=null)_0x346724=it(_0x4f5c9c,_0x7592d3);else return[];}if(_0x346724=_0x346724['withIndex'](_0x44f8e9),!_0x346724['isEmpty']()&&!_0x346724['isLeafNode']()){const _0x3c9786=[],_0x76853c=_0x44f8e9['getCompare'](),_0x3c8510=_0x12b6b4?_0x346724['getReverseIteratorFrom'](_0x5b86fa,_0x44f8e9):_0x346724['getIteratorFrom'](_0x5b86fa,_0x44f8e9);let _0x305a0c=_0x3c8510['getNext']();for(;_0x305a0c&&_0x3c9786['length']<_0x183951;)_0x76853c(_0x305a0c,_0x5b86fa)!==0x0&&_0x3c9786['push'](_0x305a0c),_0x305a0c=_0x3c8510['getNext']();return _0x3c9786;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5cd835,_0x2fde71,_0x2a7951,_0x33bec7){return Uo(_0x5cd835['writeTree'],_0x5cd835['treePath'],_0x2fde71,_0x2a7951,_0x33bec7);}function es(_0x1cd606,_0x362ac3){return fu(_0x1cd606['writeTree'],_0x1cd606['treePath'],_0x362ac3);}function or(_0x58c6a1,_0x34a7e9,_0x1f21b1,_0xf4c38a){return pu(_0x58c6a1['writeTree'],_0x58c6a1['treePath'],_0x34a7e9,_0x1f21b1,_0xf4c38a);}function yn(_0x349647,_0x177ea8){return gu(_0x349647['writeTree'],A(_0x349647['treePath'],_0x177ea8));}function vu(_0x111284,_0x40e5e2,_0x45dbb5,_0x1bcc10,_0xc1971f,_0x32539d){return mu(_0x111284['writeTree'],_0x111284['treePath'],_0x40e5e2,_0x45dbb5,_0x1bcc10,_0xc1971f,_0x32539d);}function ts(_0x354fcf,_0x24a5be,_0x47b2f4){return _u(_0x354fcf['writeTree'],_0x354fcf['treePath'],_0x24a5be,_0x47b2f4);}function Wo(_0x4aef65,_0x208772){return Bo(A(_0x4aef65['treePath'],_0x208772),_0x4aef65['writeTree']);}function Bo(_0x24a2aa,_0x367697){return{'treePath':_0x24a2aa,'writeTree':_0x367697};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x29bb81){const _0x5292ae=_0x29bb81['type'],_0x4de3d5=_0x29bb81['childName'];f(_0x5292ae==='child_added'||_0x5292ae==='child_changed'||_0x5292ae==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4de3d5!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x43ee38=this['changeMap']['get'](_0x4de3d5);if(_0x43ee38){const _0x58ac40=_0x43ee38['type'];if(_0x5292ae==='child_added'&&_0x58ac40==='child_removed')this['changeMap']['set'](_0x4de3d5,Pt(_0x4de3d5,_0x29bb81['snapshotNode'],_0x43ee38['snapshotNode']));else{if(_0x5292ae==='child_removed'&&_0x58ac40==='child_added')this['changeMap']['delete'](_0x4de3d5);else{if(_0x5292ae==='child_removed'&&_0x58ac40==='child_changed')this['changeMap']['set'](_0x4de3d5,Nt(_0x4de3d5,_0x43ee38['oldSnap']));else{if(_0x5292ae==='child_changed'&&_0x58ac40==='child_added')this['changeMap']['set'](_0x4de3d5,tt(_0x4de3d5,_0x29bb81['snapshotNode']));else{if(_0x5292ae==='child_changed'&&_0x58ac40==='child_changed')this['changeMap']['set'](_0x4de3d5,Pt(_0x4de3d5,_0x29bb81['snapshotNode'],_0x43ee38['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x29bb81+'\x20occurred\x20after\x20'+_0x43ee38);}}}}}else this['changeMap']['set'](_0x4de3d5,_0x29bb81);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x2dea13){return null;}['getChildAfterChild'](_0x68c11,_0x3a7fe6,_0x228587){return null;}}const Vo=new Iu();class ns{constructor(_0x50c2e7,_0x3b3983,_0x81f9fc=null){this['writes_']=_0x50c2e7,this['viewCache_']=_0x3b3983,this['optCompleteServerCache_']=_0x81f9fc;}['getCompleteChild'](_0xc0f25b){const _0x422f9e=this['viewCache_']['eventCache'];if(_0x422f9e['isCompleteForChild'](_0xc0f25b))return _0x422f9e['getNode']()['getImmediateChild'](_0xc0f25b);{const _0x1be238=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0xc0f25b,_0x1be238);}}['getChildAfterChild'](_0x3edc1b,_0x207619,_0x207453){const _0x4666cd=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5d0116=vu(this['writes_'],_0x4666cd,_0x207619,0x1,_0x207453,_0x3edc1b);return _0x5d0116['length']===0x0?null:_0x5d0116[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x462f44){return{'filter':_0x462f44};}function Cu(_0x5eb74e,_0x5a189f){f(_0x5a189f['eventCache']['getNode']()['isIndexed'](_0x5eb74e['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5a189f['serverCache']['getNode']()['isIndexed'](_0x5eb74e['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x85946e,_0x1e1d40,_0x3d5657,_0x4240c7,_0x220ffa){const _0x2a4fbc=new Eu();let _0x5a53ad,_0x4a16fc;if(_0x3d5657['type']===q['OVERWRITE']){const _0x3964bd=_0x3d5657;_0x3964bd['source']['fromUser']?_0x5a53ad=Ti(_0x85946e,_0x1e1d40,_0x3964bd['path'],_0x3964bd['snap'],_0x4240c7,_0x220ffa,_0x2a4fbc):(f(_0x3964bd['source']['fromServer'],'Unknown\x20source.'),_0x4a16fc=_0x3964bd['source']['tagged']||_0x1e1d40['serverCache']['isFiltered']()&&!v(_0x3964bd['path']),_0x5a53ad=vn(_0x85946e,_0x1e1d40,_0x3964bd['path'],_0x3964bd['snap'],_0x4240c7,_0x220ffa,_0x4a16fc,_0x2a4fbc));}else{if(_0x3d5657['type']===q['MERGE']){const _0x5c84c7=_0x3d5657;_0x5c84c7['source']['fromUser']?_0x5a53ad=bu(_0x85946e,_0x1e1d40,_0x5c84c7['path'],_0x5c84c7['children'],_0x4240c7,_0x220ffa,_0x2a4fbc):(f(_0x5c84c7['source']['fromServer'],'Unknown\x20source.'),_0x4a16fc=_0x5c84c7['source']['tagged']||_0x1e1d40['serverCache']['isFiltered'](),_0x5a53ad=Si(_0x85946e,_0x1e1d40,_0x5c84c7['path'],_0x5c84c7['children'],_0x4240c7,_0x220ffa,_0x4a16fc,_0x2a4fbc));}else{if(_0x3d5657['type']===q['ACK_USER_WRITE']){const _0x58b628=_0x3d5657;_0x58b628['revert']?_0x5a53ad=ku(_0x85946e,_0x1e1d40,_0x58b628['path'],_0x4240c7,_0x220ffa,_0x2a4fbc):_0x5a53ad=Ru(_0x85946e,_0x1e1d40,_0x58b628['path'],_0x58b628['affectedTree'],_0x4240c7,_0x220ffa,_0x2a4fbc);}else{if(_0x3d5657['type']===q['LISTEN_COMPLETE'])_0x5a53ad=Au(_0x85946e,_0x1e1d40,_0x3d5657['path'],_0x4240c7,_0x2a4fbc);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3d5657['type']);}}}const _0x36d23c=_0x2a4fbc['getChanges']();return Su(_0x1e1d40,_0x5a53ad,_0x36d23c),{'viewCache':_0x5a53ad,'changes':_0x36d23c};}function Su(_0x35113c,_0x2e6daa,_0x465a39){const _0x3bcae9=_0x2e6daa['eventCache'];if(_0x3bcae9['isFullyInitialized']()){const _0x4561b1=_0x3bcae9['getNode']()['isLeafNode']()||_0x3bcae9['getNode']()['isEmpty'](),_0x4d1ace=gn(_0x35113c);(_0x465a39['length']>0x0||!_0x35113c['eventCache']['isFullyInitialized']()||_0x4561b1&&!_0x3bcae9['getNode']()['equals'](_0x4d1ace)||!_0x3bcae9['getNode']()['getPriority']()['equals'](_0x4d1ace['getPriority']()))&&_0x465a39['push'](Oo(gn(_0x2e6daa)));}}function Ho(_0x60ea10,_0x48765e,_0x5e5c54,_0x352e38,_0x3ed733,_0x4e22e3){const _0x5c2b15=_0x48765e['eventCache'];if(yn(_0x352e38,_0x5e5c54)!=null)return _0x48765e;{let _0x1359a4,_0xac21ab;if(v(_0x5e5c54)){if(f(_0x48765e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x48765e['serverCache']['isFiltered']()){const _0x313087=Ue(_0x48765e),_0x5e74a1=_0x313087 instanceof g?_0x313087:g['EMPTY_NODE'],_0x1f166c=es(_0x352e38,_0x5e74a1);_0x1359a4=_0x60ea10['filter']['updateFullNode'](_0x48765e['eventCache']['getNode'](),_0x1f166c,_0x4e22e3);}else{const _0x121ff9=mn(_0x352e38,Ue(_0x48765e));_0x1359a4=_0x60ea10['filter']['updateFullNode'](_0x48765e['eventCache']['getNode'](),_0x121ff9,_0x4e22e3);}}else{const _0x49bd71=y(_0x5e5c54);if(_0x49bd71==='.priority'){f(we(_0x5e5c54)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x5ea59c=_0x5c2b15['getNode']();_0xac21ab=_0x48765e['serverCache']['getNode']();const _0x53d885=or(_0x352e38,_0x5e5c54,_0x5ea59c,_0xac21ab);_0x53d885!=null?_0x1359a4=_0x60ea10['filter']['updatePriority'](_0x5ea59c,_0x53d885):_0x1359a4=_0x5c2b15['getNode']();}else{const _0x294b35=b(_0x5e5c54);let _0x267f46;if(_0x5c2b15['isCompleteForChild'](_0x49bd71)){_0xac21ab=_0x48765e['serverCache']['getNode']();const _0x54192f=or(_0x352e38,_0x5e5c54,_0x5c2b15['getNode'](),_0xac21ab);_0x54192f!=null?_0x267f46=_0x5c2b15['getNode']()['getImmediateChild'](_0x49bd71)['updateChild'](_0x294b35,_0x54192f):_0x267f46=_0x5c2b15['getNode']()['getImmediateChild'](_0x49bd71);}else _0x267f46=ts(_0x352e38,_0x49bd71,_0x48765e['serverCache']);_0x267f46!=null?_0x1359a4=_0x60ea10['filter']['updateChild'](_0x5c2b15['getNode'](),_0x49bd71,_0x267f46,_0x294b35,_0x3ed733,_0x4e22e3):_0x1359a4=_0x5c2b15['getNode']();}}return wt(_0x48765e,_0x1359a4,_0x5c2b15['isFullyInitialized']()||v(_0x5e5c54),_0x60ea10['filter']['filtersNodes']());}}function vn(_0x4722eb,_0x137f21,_0x4ec99a,_0x4f5fdc,_0x222485,_0x1e1b65,_0x1ecc6d,_0x154a39){const _0x57bb59=_0x137f21['serverCache'];let _0x19fe30;const _0x31e6ad=_0x1ecc6d?_0x4722eb['filter']:_0x4722eb['filter']['getIndexedFilter']();if(v(_0x4ec99a))_0x19fe30=_0x31e6ad['updateFullNode'](_0x57bb59['getNode'](),_0x4f5fdc,null);else{if(_0x31e6ad['filtersNodes']()&&!_0x57bb59['isFiltered']()){const _0x4b9387=_0x57bb59['getNode']()['updateChild'](_0x4ec99a,_0x4f5fdc);_0x19fe30=_0x31e6ad['updateFullNode'](_0x57bb59['getNode'](),_0x4b9387,null);}else{const _0x298e4e=y(_0x4ec99a);if(!_0x57bb59['isCompleteForPath'](_0x4ec99a)&&we(_0x4ec99a)>0x1)return _0x137f21;const _0x15affe=b(_0x4ec99a),_0x182a2c=_0x57bb59['getNode']()['getImmediateChild'](_0x298e4e)['updateChild'](_0x15affe,_0x4f5fdc);_0x298e4e==='.priority'?_0x19fe30=_0x31e6ad['updatePriority'](_0x57bb59['getNode'](),_0x182a2c):_0x19fe30=_0x31e6ad['updateChild'](_0x57bb59['getNode'](),_0x298e4e,_0x182a2c,_0x15affe,Vo,null);}}const _0x477951=Lo(_0x137f21,_0x19fe30,_0x57bb59['isFullyInitialized']()||v(_0x4ec99a),_0x31e6ad['filtersNodes']()),_0x5ad2be=new ns(_0x222485,_0x477951,_0x1e1b65);return Ho(_0x4722eb,_0x477951,_0x4ec99a,_0x222485,_0x5ad2be,_0x154a39);}function Ti(_0x24e905,_0x37949c,_0x5ebb6c,_0xc0a467,_0x3d85bb,_0x1535fd,_0x5abcd1){const _0x2d229c=_0x37949c['eventCache'];let _0x22423a,_0x42a60a;const _0x441e25=new ns(_0x3d85bb,_0x37949c,_0x1535fd);if(v(_0x5ebb6c))_0x42a60a=_0x24e905['filter']['updateFullNode'](_0x37949c['eventCache']['getNode'](),_0xc0a467,_0x5abcd1),_0x22423a=wt(_0x37949c,_0x42a60a,!0x0,_0x24e905['filter']['filtersNodes']());else{const _0x2b6ff4=y(_0x5ebb6c);if(_0x2b6ff4==='.priority')_0x42a60a=_0x24e905['filter']['updatePriority'](_0x37949c['eventCache']['getNode'](),_0xc0a467),_0x22423a=wt(_0x37949c,_0x42a60a,_0x2d229c['isFullyInitialized'](),_0x2d229c['isFiltered']());else{const _0x341634=b(_0x5ebb6c),_0x425da8=_0x2d229c['getNode']()['getImmediateChild'](_0x2b6ff4);let _0x117791;if(v(_0x341634))_0x117791=_0xc0a467;else{const _0x527bb8=_0x441e25['getCompleteChild'](_0x2b6ff4);_0x527bb8!=null?Gi(_0x341634)==='.priority'&&_0x527bb8['getChild'](To(_0x341634))['isEmpty']()?_0x117791=_0x527bb8:_0x117791=_0x527bb8['updateChild'](_0x341634,_0xc0a467):_0x117791=g['EMPTY_NODE'];}if(_0x425da8['equals'](_0x117791))_0x22423a=_0x37949c;else{const _0x9fc365=_0x24e905['filter']['updateChild'](_0x2d229c['getNode'](),_0x2b6ff4,_0x117791,_0x341634,_0x441e25,_0x5abcd1);_0x22423a=wt(_0x37949c,_0x9fc365,_0x2d229c['isFullyInitialized'](),_0x24e905['filter']['filtersNodes']());}}}return _0x22423a;}function ar(_0x534f9a,_0x24a210){return _0x534f9a['eventCache']['isCompleteForChild'](_0x24a210);}function bu(_0x3b0425,_0x57f524,_0x491f11,_0x45277c,_0x2a6981,_0x53d60d,_0x416e38){let _0x28ed5a=_0x57f524;return _0x45277c['foreach']((_0x190e70,_0x517f95)=>{const _0x1c51d9=A(_0x491f11,_0x190e70);ar(_0x57f524,y(_0x1c51d9))&&(_0x28ed5a=Ti(_0x3b0425,_0x28ed5a,_0x1c51d9,_0x517f95,_0x2a6981,_0x53d60d,_0x416e38));}),_0x45277c['foreach']((_0x222167,_0x1ecf1a)=>{const _0x5c447f=A(_0x491f11,_0x222167);ar(_0x57f524,y(_0x5c447f))||(_0x28ed5a=Ti(_0x3b0425,_0x28ed5a,_0x5c447f,_0x1ecf1a,_0x2a6981,_0x53d60d,_0x416e38));}),_0x28ed5a;}function cr(_0x4d0cb3,_0x5af67d,_0x7e8b50){return _0x7e8b50['foreach']((_0x5cf1f5,_0x1f05ab)=>{_0x5af67d=_0x5af67d['updateChild'](_0x5cf1f5,_0x1f05ab);}),_0x5af67d;}function Si(_0x11d464,_0x264174,_0xf76f27,_0x48f977,_0x3ff753,_0x31c92e,_0x529193,_0x285b9f){if(_0x264174['serverCache']['getNode']()['isEmpty']()&&!_0x264174['serverCache']['isFullyInitialized']())return _0x264174;let _0x3b21ab=_0x264174,_0x5ddf63;v(_0xf76f27)?_0x5ddf63=_0x48f977:_0x5ddf63=new S(null)['setTree'](_0xf76f27,_0x48f977);const _0x4ab0f2=_0x264174['serverCache']['getNode']();return _0x5ddf63['children']['inorderTraversal']((_0x33474e,_0x60857d)=>{if(_0x4ab0f2['hasChild'](_0x33474e)){const _0x48851e=_0x264174['serverCache']['getNode']()['getImmediateChild'](_0x33474e),_0x51fcb9=cr(_0x11d464,_0x48851e,_0x60857d);_0x3b21ab=vn(_0x11d464,_0x3b21ab,new C(_0x33474e),_0x51fcb9,_0x3ff753,_0x31c92e,_0x529193,_0x285b9f);}}),_0x5ddf63['children']['inorderTraversal']((_0x16436b,_0x317753)=>{const _0x26c8ec=!_0x264174['serverCache']['isCompleteForChild'](_0x16436b)&&_0x317753['value']===null;if(!_0x4ab0f2['hasChild'](_0x16436b)&&!_0x26c8ec){const _0x41963b=_0x264174['serverCache']['getNode']()['getImmediateChild'](_0x16436b),_0xab4579=cr(_0x11d464,_0x41963b,_0x317753);_0x3b21ab=vn(_0x11d464,_0x3b21ab,new C(_0x16436b),_0xab4579,_0x3ff753,_0x31c92e,_0x529193,_0x285b9f);}}),_0x3b21ab;}function Ru(_0x43bb70,_0x347fa9,_0x59d941,_0x52e7c7,_0x5de64e,_0x3578e4,_0x3f408b){if(yn(_0x5de64e,_0x59d941)!=null)return _0x347fa9;const _0xa7d9bc=_0x347fa9['serverCache']['isFiltered'](),_0x51a415=_0x347fa9['serverCache'];if(_0x52e7c7['value']!=null){if(v(_0x59d941)&&_0x51a415['isFullyInitialized']()||_0x51a415['isCompleteForPath'](_0x59d941))return vn(_0x43bb70,_0x347fa9,_0x59d941,_0x51a415['getNode']()['getChild'](_0x59d941),_0x5de64e,_0x3578e4,_0xa7d9bc,_0x3f408b);if(v(_0x59d941)){let _0x20a00e=new S(null);return _0x51a415['getNode']()['forEachChild'](ye,(_0x237c8d,_0x2a1c39)=>{_0x20a00e=_0x20a00e['set'](new C(_0x237c8d),_0x2a1c39);}),Si(_0x43bb70,_0x347fa9,_0x59d941,_0x20a00e,_0x5de64e,_0x3578e4,_0xa7d9bc,_0x3f408b);}else return _0x347fa9;}else{let _0xc0a811=new S(null);return _0x52e7c7['foreach']((_0x2598d8,_0x5a3d4d)=>{const _0x5e6829=A(_0x59d941,_0x2598d8);_0x51a415['isCompleteForPath'](_0x5e6829)&&(_0xc0a811=_0xc0a811['set'](_0x2598d8,_0x51a415['getNode']()['getChild'](_0x5e6829)));}),Si(_0x43bb70,_0x347fa9,_0x59d941,_0xc0a811,_0x5de64e,_0x3578e4,_0xa7d9bc,_0x3f408b);}}function Au(_0x1e1fc5,_0x2f4ab5,_0x2df913,_0x44bb2a,_0x4a83fd){const _0x3d3dc9=_0x2f4ab5['serverCache'],_0x199155=Lo(_0x2f4ab5,_0x3d3dc9['getNode'](),_0x3d3dc9['isFullyInitialized']()||v(_0x2df913),_0x3d3dc9['isFiltered']());return Ho(_0x1e1fc5,_0x199155,_0x2df913,_0x44bb2a,Vo,_0x4a83fd);}function ku(_0x52cc16,_0x577e09,_0x2797c1,_0x7de1a6,_0x186706,_0x1711bb){let _0x2c46a2;if(yn(_0x7de1a6,_0x2797c1)!=null)return _0x577e09;{const _0x14a868=new ns(_0x7de1a6,_0x577e09,_0x186706),_0x3cb808=_0x577e09['eventCache']['getNode']();let _0x4e257f;if(v(_0x2797c1)||y(_0x2797c1)==='.priority'){let _0x36f7d5;if(_0x577e09['serverCache']['isFullyInitialized']())_0x36f7d5=mn(_0x7de1a6,Ue(_0x577e09));else{const _0x45d982=_0x577e09['serverCache']['getNode']();f(_0x45d982 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x36f7d5=es(_0x7de1a6,_0x45d982);}_0x36f7d5=_0x36f7d5,_0x4e257f=_0x52cc16['filter']['updateFullNode'](_0x3cb808,_0x36f7d5,_0x1711bb);}else{const _0x7383ee=y(_0x2797c1);let _0x37290a=ts(_0x7de1a6,_0x7383ee,_0x577e09['serverCache']);_0x37290a==null&&_0x577e09['serverCache']['isCompleteForChild'](_0x7383ee)&&(_0x37290a=_0x3cb808['getImmediateChild'](_0x7383ee)),_0x37290a!=null?_0x4e257f=_0x52cc16['filter']['updateChild'](_0x3cb808,_0x7383ee,_0x37290a,b(_0x2797c1),_0x14a868,_0x1711bb):_0x577e09['eventCache']['getNode']()['hasChild'](_0x7383ee)?_0x4e257f=_0x52cc16['filter']['updateChild'](_0x3cb808,_0x7383ee,g['EMPTY_NODE'],b(_0x2797c1),_0x14a868,_0x1711bb):_0x4e257f=_0x3cb808,_0x4e257f['isEmpty']()&&_0x577e09['serverCache']['isFullyInitialized']()&&(_0x2c46a2=mn(_0x7de1a6,Ue(_0x577e09)),_0x2c46a2['isLeafNode']()&&(_0x4e257f=_0x52cc16['filter']['updateFullNode'](_0x4e257f,_0x2c46a2,_0x1711bb)));}return _0x2c46a2=_0x577e09['serverCache']['isFullyInitialized']()||yn(_0x7de1a6,w())!=null,wt(_0x577e09,_0x4e257f,_0x2c46a2,_0x52cc16['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x16162f,_0x3f4176){this['query_']=_0x16162f,this['eventRegistrations_']=[];const _0x1f0c26=this['query_']['_queryParams'],_0x23f271=new Yi(_0x1f0c26['getIndex']()),_0xa04612=qh(_0x1f0c26);this['processor_']=wu(_0xa04612);const _0x918b24=_0x3f4176['serverCache'],_0x3c5584=_0x3f4176['eventCache'],_0x5dd2b0=_0x23f271['updateFullNode'](g['EMPTY_NODE'],_0x918b24['getNode'](),null),_0x5a1ae9=_0xa04612['updateFullNode'](g['EMPTY_NODE'],_0x3c5584['getNode'](),null),_0x540390=new Ce(_0x5dd2b0,_0x918b24['isFullyInitialized'](),_0x23f271['filtersNodes']()),_0xb60e13=new Ce(_0x5a1ae9,_0x3c5584['isFullyInitialized'](),_0xa04612['filtersNodes']());this['viewCache_']=Dn(_0xb60e13,_0x540390),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x57e5dc){return _0x57e5dc['viewCache_']['serverCache']['getNode']();}function Ou(_0x4ed093){return gn(_0x4ed093['viewCache_']);}function Du(_0x3d20a3,_0x2a2fb4){const _0x2c94d9=Ue(_0x3d20a3['viewCache_']);return _0x2c94d9&&(_0x3d20a3['query']['_queryParams']['loadsAllData']()||!v(_0x2a2fb4)&&!_0x2c94d9['getImmediateChild'](y(_0x2a2fb4))['isEmpty']())?_0x2c94d9['getChild'](_0x2a2fb4):null;}function lr(_0x3f37dc){return _0x3f37dc['eventRegistrations_']['length']===0x0;}function Mu(_0x46a486,_0x1602f0){_0x46a486['eventRegistrations_']['push'](_0x1602f0);}function hr(_0x3cc12c,_0x34213d,_0xa4f3ae){const _0x4f0a75=[];if(_0xa4f3ae){f(_0x34213d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x432e24=_0x3cc12c['query']['_path'];_0x3cc12c['eventRegistrations_']['forEach'](_0x56ab79=>{const _0x20ee63=_0x56ab79['createCancelEvent'](_0xa4f3ae,_0x432e24);_0x20ee63&&_0x4f0a75['push'](_0x20ee63);});}if(_0x34213d){let _0x5ee2f2=[];for(let _0x4c7ce0=0x0;_0x4c7ce0<_0x3cc12c['eventRegistrations_']['length'];++_0x4c7ce0){const _0x286939=_0x3cc12c['eventRegistrations_'][_0x4c7ce0];if(!_0x286939['matches'](_0x34213d))_0x5ee2f2['push'](_0x286939);else{if(_0x34213d['hasAnyCallback']()){_0x5ee2f2=_0x5ee2f2['concat'](_0x3cc12c['eventRegistrations_']['slice'](_0x4c7ce0+0x1));break;}}}_0x3cc12c['eventRegistrations_']=_0x5ee2f2;}else _0x3cc12c['eventRegistrations_']=[];return _0x4f0a75;}function ur(_0x523427,_0x738862,_0x38bbc3,_0x330868){_0x738862['type']===q['MERGE']&&_0x738862['source']['queryId']!==null&&(f(Ue(_0x523427['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x523427['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x506e7c=_0x523427['viewCache_'],_0x17cc27=Tu(_0x523427['processor_'],_0x506e7c,_0x738862,_0x38bbc3,_0x330868);return Cu(_0x523427['processor_'],_0x17cc27['viewCache']),f(_0x17cc27['viewCache']['serverCache']['isFullyInitialized']()||!_0x506e7c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x523427['viewCache_']=_0x17cc27['viewCache'],$o(_0x523427,_0x17cc27['changes'],_0x17cc27['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x1cf0d9,_0x520a11){const _0x509b03=_0x1cf0d9['viewCache_']['eventCache'],_0x5a548a=[];return _0x509b03['getNode']()['isLeafNode']()||_0x509b03['getNode']()['forEachChild'](R,(_0x1f6621,_0x297f1f)=>{_0x5a548a['push'](tt(_0x1f6621,_0x297f1f));}),_0x509b03['isFullyInitialized']()&&_0x5a548a['push'](Oo(_0x509b03['getNode']())),$o(_0x1cf0d9,_0x5a548a,_0x509b03['getNode'](),_0x520a11);}function $o(_0x4b9dbf,_0x13bda5,_0x15b28d,_0x5bf84b){const _0x1e1646=_0x5bf84b?[_0x5bf84b]:_0x4b9dbf['eventRegistrations_'];return nu(_0x4b9dbf['eventGenerator_'],_0x13bda5,_0x15b28d,_0x1e1646);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x1d3bdd){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x1d3bdd;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x2d21fb){return _0x2d21fb['views']['size']===0x0;}function is(_0x1b4979,_0x4445e6,_0x1255ba,_0x123b2d){const _0x4a815a=_0x4445e6['source']['queryId'];if(_0x4a815a!==null){const _0x2417ba=_0x1b4979['views']['get'](_0x4a815a);return f(_0x2417ba!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2417ba,_0x4445e6,_0x1255ba,_0x123b2d);}else{let _0x3e5f92=[];for(const _0x4128b3 of _0x1b4979['views']['values']())_0x3e5f92=_0x3e5f92['concat'](ur(_0x4128b3,_0x4445e6,_0x1255ba,_0x123b2d));return _0x3e5f92;}}function qo(_0x4f14ac,_0x5cca38,_0x4ebc6d,_0x1e7d63,_0x24924b){const _0x2f520b=_0x5cca38['_queryIdentifier'],_0x510fb5=_0x4f14ac['views']['get'](_0x2f520b);if(!_0x510fb5){let _0x191f75=mn(_0x4ebc6d,_0x24924b?_0x1e7d63:null),_0x923ef7=!0x1;_0x191f75?_0x923ef7=!0x0:_0x1e7d63 instanceof g?(_0x191f75=es(_0x4ebc6d,_0x1e7d63),_0x923ef7=!0x1):(_0x191f75=g['EMPTY_NODE'],_0x923ef7=!0x1);const _0x464414=Dn(new Ce(_0x191f75,_0x923ef7,!0x1),new Ce(_0x1e7d63,_0x24924b,!0x1));return new Nu(_0x5cca38,_0x464414);}return _0x510fb5;}function Wu(_0x24707d,_0x6ae709,_0x5de0f5,_0x52c33d,_0x235900,_0x496752){const _0x2c94b6=qo(_0x24707d,_0x6ae709,_0x52c33d,_0x235900,_0x496752);return _0x24707d['views']['has'](_0x6ae709['_queryIdentifier'])||_0x24707d['views']['set'](_0x6ae709['_queryIdentifier'],_0x2c94b6),Mu(_0x2c94b6,_0x5de0f5),Lu(_0x2c94b6,_0x5de0f5);}function Bu(_0x5057cc,_0x1edcd1,_0x556571,_0x540f90){const _0x4d16fb=_0x1edcd1['_queryIdentifier'],_0x3b8516=[];let _0x5c6922=[];const _0x1f7072=Te(_0x5057cc);if(_0x4d16fb==='default'){for(const [_0x35b013,_0x4d198e]of _0x5057cc['views']['entries']())_0x5c6922=_0x5c6922['concat'](hr(_0x4d198e,_0x556571,_0x540f90)),lr(_0x4d198e)&&(_0x5057cc['views']['delete'](_0x35b013),_0x4d198e['query']['_queryParams']['loadsAllData']()||_0x3b8516['push'](_0x4d198e['query']));}else{const _0x50f5af=_0x5057cc['views']['get'](_0x4d16fb);_0x50f5af&&(_0x5c6922=_0x5c6922['concat'](hr(_0x50f5af,_0x556571,_0x540f90)),lr(_0x50f5af)&&(_0x5057cc['views']['delete'](_0x4d16fb),_0x50f5af['query']['_queryParams']['loadsAllData']()||_0x3b8516['push'](_0x50f5af['query'])));}return _0x1f7072&&!Te(_0x5057cc)&&_0x3b8516['push'](new(Fu())(_0x1edcd1['_repo'],_0x1edcd1['_path'])),{'removed':_0x3b8516,'events':_0x5c6922};}function zo(_0xa17124){const _0x529194=[];for(const _0x8a7914 of _0xa17124['views']['values']())_0x8a7914['query']['_queryParams']['loadsAllData']()||_0x529194['push'](_0x8a7914);return _0x529194;}function Ee(_0x2f564f,_0x3c3b37){let _0x1f7fc1=null;for(const _0x55769c of _0x2f564f['views']['values']())_0x1f7fc1=_0x1f7fc1||Du(_0x55769c,_0x3c3b37);return _0x1f7fc1;}function jo(_0x4deecd,_0x4a9a50){if(_0x4a9a50['_queryParams']['loadsAllData']())return Ln(_0x4deecd);{const _0x48c5fc=_0x4a9a50['_queryIdentifier'];return _0x4deecd['views']['get'](_0x48c5fc);}}function Ko(_0x34c6a4,_0x8dc218){return jo(_0x34c6a4,_0x8dc218)!=null;}function Te(_0x6fee2d){return Ln(_0x6fee2d)!=null;}function Ln(_0x18c879){for(const _0x14131c of _0x18c879['views']['values']())if(_0x14131c['query']['_queryParams']['loadsAllData']())return _0x14131c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xb0c42){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xb0c42;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x25f164){this['listenProvider_']=_0x25f164,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x67d9f9,_0x5ea9b7,_0x2b7657,_0x54453d,_0x3f39fc){return ou(_0x67d9f9['pendingWriteTree_'],_0x5ea9b7,_0x2b7657,_0x54453d,_0x3f39fc),_0x3f39fc?ht(_0x67d9f9,new Fe(Ji(),_0x5ea9b7,_0x2b7657)):[];}function Gu(_0x3662db,_0x4e89db,_0x42cc32,_0x24a8f7){au(_0x3662db['pendingWriteTree_'],_0x4e89db,_0x42cc32,_0x24a8f7);const _0x2c0a05=S['fromObject'](_0x42cc32);return ht(_0x3662db,new nt(Ji(),_0x4e89db,_0x2c0a05));}function pe(_0x3d7d7d,_0x22d8cf,_0x326728=!0x1){const _0x255b3d=cu(_0x3d7d7d['pendingWriteTree_'],_0x22d8cf);if(lu(_0x3d7d7d['pendingWriteTree_'],_0x22d8cf)){let _0x1d25eb=new S(null);return _0x255b3d['snap']!=null?_0x1d25eb=_0x1d25eb['set'](w(),!0x0):x(_0x255b3d['children'],_0x175109=>{_0x1d25eb=_0x1d25eb['set'](new C(_0x175109),!0x0);}),ht(_0x3d7d7d,new _n(_0x255b3d['path'],_0x1d25eb,_0x326728));}else return[];}function $t(_0x4a7a1f,_0x1dd485,_0x1f2a21){return ht(_0x4a7a1f,new Fe(Xi(),_0x1dd485,_0x1f2a21));}function qu(_0x265342,_0x538ddc,_0x286d28){const _0x27b9d4=S['fromObject'](_0x286d28);return ht(_0x265342,new nt(Xi(),_0x538ddc,_0x27b9d4));}function zu(_0x445750,_0x4e153c){return ht(_0x445750,new Dt(Xi(),_0x4e153c));}function ju(_0x5f23cd,_0x6c7c3b,_0x541463){const _0x334663=rs(_0x5f23cd,_0x541463);if(_0x334663){const _0x465073=os(_0x334663),_0x548c87=_0x465073['path'],_0x4cc82d=_0x465073['queryId'],_0x2dec69=F(_0x548c87,_0x6c7c3b),_0x1ef2f1=new Dt(Zi(_0x4cc82d),_0x2dec69);return as(_0x5f23cd,_0x548c87,_0x1ef2f1);}else return[];}function wn(_0x196114,_0x51b0ba,_0x41748f,_0x106fde,_0x1719d5=!0x1){const _0x27da0f=_0x51b0ba['_path'],_0x441a36=_0x196114['syncPointTree_']['get'](_0x27da0f);let _0x3f3b30=[];if(_0x441a36&&(_0x51b0ba['_queryIdentifier']==='default'||Ko(_0x441a36,_0x51b0ba))){const _0xc12e38=Bu(_0x441a36,_0x51b0ba,_0x41748f,_0x106fde);Uu(_0x441a36)&&(_0x196114['syncPointTree_']=_0x196114['syncPointTree_']['remove'](_0x27da0f));const _0x140d0d=_0xc12e38['removed'];if(_0x3f3b30=_0xc12e38['events'],!_0x1719d5){const _0x1f6037=_0x140d0d['findIndex'](_0x408b0f=>_0x408b0f['_queryParams']['loadsAllData']())!==-0x1,_0x11dc8e=_0x196114['syncPointTree_']['findOnPath'](_0x27da0f,(_0xd4288d,_0x18c7fb)=>Te(_0x18c7fb));if(_0x1f6037&&!_0x11dc8e){const _0x2614af=_0x196114['syncPointTree_']['subtree'](_0x27da0f);if(!_0x2614af['isEmpty']()){const _0x472243=Qu(_0x2614af);for(let _0x9f3fab=0x0;_0x9f3fab<_0x472243['length'];++_0x9f3fab){const _0x17fbdc=_0x472243[_0x9f3fab],_0x1126b8=_0x17fbdc['query'],_0x7fbc51=Xo(_0x196114,_0x17fbdc);_0x196114['listenProvider_']['startListening'](Tt(_0x1126b8),Mt(_0x196114,_0x1126b8),_0x7fbc51['hashFn'],_0x7fbc51['onComplete']);}}}!_0x11dc8e&&_0x140d0d['length']>0x0&&!_0x106fde&&(_0x1f6037?_0x196114['listenProvider_']['stopListening'](Tt(_0x51b0ba),null):_0x140d0d['forEach'](_0x940df8=>{const _0x2db35d=_0x196114['queryToTagMap']['get'](Fn(_0x940df8));_0x196114['listenProvider_']['stopListening'](Tt(_0x940df8),_0x2db35d);}));}Ju(_0x196114,_0x140d0d);}return _0x3f3b30;}function Yo(_0x30e0e7,_0x41dfe1,_0xd1f08e,_0x2464fc){const _0x7005d1=rs(_0x30e0e7,_0x2464fc);if(_0x7005d1!=null){const _0x9ef585=os(_0x7005d1),_0x32de1b=_0x9ef585['path'],_0xf25b2=_0x9ef585['queryId'],_0x4be59f=F(_0x32de1b,_0x41dfe1),_0x4c8325=new Fe(Zi(_0xf25b2),_0x4be59f,_0xd1f08e);return as(_0x30e0e7,_0x32de1b,_0x4c8325);}else return[];}function Ku(_0x20725e,_0x117dea,_0x5cb9e9,_0x4800ce){const _0x33f358=rs(_0x20725e,_0x4800ce);if(_0x33f358){const _0xd0d278=os(_0x33f358),_0x2b249f=_0xd0d278['path'],_0x502cd0=_0xd0d278['queryId'],_0x3b9341=F(_0x2b249f,_0x117dea),_0x4b3e1d=S['fromObject'](_0x5cb9e9),_0x4122dc=new nt(Zi(_0x502cd0),_0x3b9341,_0x4b3e1d);return as(_0x20725e,_0x2b249f,_0x4122dc);}else return[];}function bi(_0x4d0a6e,_0x15bceb,_0xf0ce8e,_0x39f908=!0x1){const _0x36e857=_0x15bceb['_path'];let _0x40604e=null,_0x5443d4=!0x1;_0x4d0a6e['syncPointTree_']['foreachOnPath'](_0x36e857,(_0x47405e,_0x49ec28)=>{const _0x418957=F(_0x47405e,_0x36e857);_0x40604e=_0x40604e||Ee(_0x49ec28,_0x418957),_0x5443d4=_0x5443d4||Te(_0x49ec28);});let _0x78a8a4=_0x4d0a6e['syncPointTree_']['get'](_0x36e857);_0x78a8a4?(_0x5443d4=_0x5443d4||Te(_0x78a8a4),_0x40604e=_0x40604e||Ee(_0x78a8a4,w())):(_0x78a8a4=new Go(),_0x4d0a6e['syncPointTree_']=_0x4d0a6e['syncPointTree_']['set'](_0x36e857,_0x78a8a4));let _0x389b8f;_0x40604e!=null?_0x389b8f=!0x0:(_0x389b8f=!0x1,_0x40604e=g['EMPTY_NODE'],_0x4d0a6e['syncPointTree_']['subtree'](_0x36e857)['foreachChild']((_0x2bf7be,_0x277d42)=>{const _0x4cdf45=Ee(_0x277d42,w());_0x4cdf45&&(_0x40604e=_0x40604e['updateImmediateChild'](_0x2bf7be,_0x4cdf45));}));const _0x5587eb=Ko(_0x78a8a4,_0x15bceb);if(!_0x5587eb&&!_0x15bceb['_queryParams']['loadsAllData']()){const _0x59ed1d=Fn(_0x15bceb);f(!_0x4d0a6e['queryToTagMap']['has'](_0x59ed1d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5177dd=Xu();_0x4d0a6e['queryToTagMap']['set'](_0x59ed1d,_0x5177dd),_0x4d0a6e['tagToQueryMap']['set'](_0x5177dd,_0x59ed1d);}const _0x9f0280=Mn(_0x4d0a6e['pendingWriteTree_'],_0x36e857);let _0x3332c1=Wu(_0x78a8a4,_0x15bceb,_0xf0ce8e,_0x9f0280,_0x40604e,_0x389b8f);if(!_0x5587eb&&!_0x5443d4&&!_0x39f908){const _0x84812c=jo(_0x78a8a4,_0x15bceb);_0x3332c1=_0x3332c1['concat'](Zu(_0x4d0a6e,_0x15bceb,_0x84812c));}return _0x3332c1;}function xn(_0x1ec65b,_0xa66d23,_0xe6981a){const _0x3aa86b=_0x1ec65b['pendingWriteTree_'],_0x52a0ab=_0x1ec65b['syncPointTree_']['findOnPath'](_0xa66d23,(_0x580eba,_0x810bb)=>{const _0xa14070=F(_0x580eba,_0xa66d23),_0x564f3b=Ee(_0x810bb,_0xa14070);if(_0x564f3b)return _0x564f3b;});return Uo(_0x3aa86b,_0xa66d23,_0x52a0ab,_0xe6981a,!0x0);}function Yu(_0x3df2bf,_0xac8c7c){const _0x28dfba=_0xac8c7c['_path'];let _0x305381=null;_0x3df2bf['syncPointTree_']['foreachOnPath'](_0x28dfba,(_0x11a45e,_0x1cc300)=>{const _0xe0f4a=F(_0x11a45e,_0x28dfba);_0x305381=_0x305381||Ee(_0x1cc300,_0xe0f4a);});let _0x4fff22=_0x3df2bf['syncPointTree_']['get'](_0x28dfba);_0x4fff22?_0x305381=_0x305381||Ee(_0x4fff22,w()):(_0x4fff22=new Go(),_0x3df2bf['syncPointTree_']=_0x3df2bf['syncPointTree_']['set'](_0x28dfba,_0x4fff22));const _0x113ddf=_0x305381!=null,_0x45215f=_0x113ddf?new Ce(_0x305381,!0x0,!0x1):null,_0x46b9e3=Mn(_0x3df2bf['pendingWriteTree_'],_0xac8c7c['_path']),_0xaf8228=qo(_0x4fff22,_0xac8c7c,_0x46b9e3,_0x113ddf?_0x45215f['getNode']():g['EMPTY_NODE'],_0x113ddf);return Ou(_0xaf8228);}function ht(_0x461a98,_0x3ca040){return Qo(_0x3ca040,_0x461a98['syncPointTree_'],null,Mn(_0x461a98['pendingWriteTree_'],w()));}function Qo(_0xdbf882,_0x48f86b,_0x14c4f9,_0x25ed98){if(v(_0xdbf882['path']))return Jo(_0xdbf882,_0x48f86b,_0x14c4f9,_0x25ed98);{const _0xb091e9=_0x48f86b['get'](w());_0x14c4f9==null&&_0xb091e9!=null&&(_0x14c4f9=Ee(_0xb091e9,w()));let _0x48f3a4=[];const _0x404a24=y(_0xdbf882['path']),_0x30e190=_0xdbf882['operationForChild'](_0x404a24),_0xcb08d5=_0x48f86b['children']['get'](_0x404a24);if(_0xcb08d5&&_0x30e190){const _0x588c63=_0x14c4f9?_0x14c4f9['getImmediateChild'](_0x404a24):null,_0x1fd440=Wo(_0x25ed98,_0x404a24);_0x48f3a4=_0x48f3a4['concat'](Qo(_0x30e190,_0xcb08d5,_0x588c63,_0x1fd440));}return _0xb091e9&&(_0x48f3a4=_0x48f3a4['concat'](is(_0xb091e9,_0xdbf882,_0x25ed98,_0x14c4f9))),_0x48f3a4;}}function Jo(_0x7fe9bd,_0x3cb78e,_0x2b4f47,_0x422b23){const _0x44ef2e=_0x3cb78e['get'](w());_0x2b4f47==null&&_0x44ef2e!=null&&(_0x2b4f47=Ee(_0x44ef2e,w()));let _0x4c7210=[];return _0x3cb78e['children']['inorderTraversal']((_0x2d0229,_0x5b8a92)=>{const _0x329a5c=_0x2b4f47?_0x2b4f47['getImmediateChild'](_0x2d0229):null,_0x447f2e=Wo(_0x422b23,_0x2d0229),_0x583d78=_0x7fe9bd['operationForChild'](_0x2d0229);_0x583d78&&(_0x4c7210=_0x4c7210['concat'](Jo(_0x583d78,_0x5b8a92,_0x329a5c,_0x447f2e)));}),_0x44ef2e&&(_0x4c7210=_0x4c7210['concat'](is(_0x44ef2e,_0x7fe9bd,_0x422b23,_0x2b4f47))),_0x4c7210;}function Xo(_0x4fba6e,_0x43a21c){const _0x4e9e73=_0x43a21c['query'],_0x354799=Mt(_0x4fba6e,_0x4e9e73);return{'hashFn':()=>(Pu(_0x43a21c)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x59068b=>{if(_0x59068b==='ok')return _0x354799?ju(_0x4fba6e,_0x4e9e73['_path'],_0x354799):zu(_0x4fba6e,_0x4e9e73['_path']);{const _0x54b988=ql(_0x59068b,_0x4e9e73);return wn(_0x4fba6e,_0x4e9e73,null,_0x54b988);}}};}function Mt(_0x24930c,_0x534987){const _0x251e46=Fn(_0x534987);return _0x24930c['queryToTagMap']['get'](_0x251e46);}function Fn(_0x3a53da){return _0x3a53da['_path']['toString']()+'$'+_0x3a53da['_queryIdentifier'];}function rs(_0x1070ed,_0x15d028){return _0x1070ed['tagToQueryMap']['get'](_0x15d028);}function os(_0x1a372d){const _0x201a37=_0x1a372d['indexOf']('$');return f(_0x201a37!==-0x1&&_0x201a37<_0x1a372d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1a372d['substr'](_0x201a37+0x1),'path':new C(_0x1a372d['substr'](0x0,_0x201a37))};}function as(_0x2a6b10,_0x3003bd,_0x341ba4){const _0x55df06=_0x2a6b10['syncPointTree_']['get'](_0x3003bd);f(_0x55df06,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xd615ba=Mn(_0x2a6b10['pendingWriteTree_'],_0x3003bd);return is(_0x55df06,_0x341ba4,_0xd615ba,null);}function Qu(_0x3bfdfa){return _0x3bfdfa['fold']((_0x528e44,_0xad678e,_0x30098d)=>{if(_0xad678e&&Te(_0xad678e))return[Ln(_0xad678e)];{let _0x3a2899=[];return _0xad678e&&(_0x3a2899=zo(_0xad678e)),x(_0x30098d,(_0x17b6ee,_0xf393fd)=>{_0x3a2899=_0x3a2899['concat'](_0xf393fd);}),_0x3a2899;}});}function Tt(_0x3e53d0){return _0x3e53d0['_queryParams']['loadsAllData']()&&!_0x3e53d0['_queryParams']['isDefault']()?new(Hu())(_0x3e53d0['_repo'],_0x3e53d0['_path']):_0x3e53d0;}function Ju(_0x27dd83,_0x1001bc){for(let _0x54dc84=0x0;_0x54dc84<_0x1001bc['length'];++_0x54dc84){const _0x34e58d=_0x1001bc[_0x54dc84];if(!_0x34e58d['_queryParams']['loadsAllData']()){const _0x311476=Fn(_0x34e58d),_0x40e87a=_0x27dd83['queryToTagMap']['get'](_0x311476);_0x27dd83['queryToTagMap']['delete'](_0x311476),_0x27dd83['tagToQueryMap']['delete'](_0x40e87a);}}}function Xu(){return $u++;}function Zu(_0x2344c2,_0x57d679,_0x149c98){const _0x239c40=_0x57d679['_path'],_0x494945=Mt(_0x2344c2,_0x57d679),_0x4850c0=Xo(_0x2344c2,_0x149c98),_0x4a83d0=_0x2344c2['listenProvider_']['startListening'](Tt(_0x57d679),_0x494945,_0x4850c0['hashFn'],_0x4850c0['onComplete']),_0x302491=_0x2344c2['syncPointTree_']['subtree'](_0x239c40);if(_0x494945)f(!Te(_0x302491['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xe1191=_0x302491['fold']((_0xbd9b1c,_0x28909d,_0x5dc114)=>{if(!v(_0xbd9b1c)&&_0x28909d&&Te(_0x28909d))return[Ln(_0x28909d)['query']];{let _0x4a7215=[];return _0x28909d&&(_0x4a7215=_0x4a7215['concat'](zo(_0x28909d)['map'](_0x25329d=>_0x25329d['query']))),x(_0x5dc114,(_0x38109d,_0x2a2e92)=>{_0x4a7215=_0x4a7215['concat'](_0x2a2e92);}),_0x4a7215;}});for(let _0x4ccfb0=0x0;_0x4ccfb0<_0xe1191['length'];++_0x4ccfb0){const _0x5bd4e5=_0xe1191[_0x4ccfb0];_0x2344c2['listenProvider_']['stopListening'](Tt(_0x5bd4e5),Mt(_0x2344c2,_0x5bd4e5));}}return _0x4a83d0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x381b1e){this['node_']=_0x381b1e;}['getImmediateChild'](_0x1d3ec6){const _0x145963=this['node_']['getImmediateChild'](_0x1d3ec6);return new cs(_0x145963);}['node'](){return this['node_'];}}class ls{constructor(_0x57d050,_0x41c109){this['syncTree_']=_0x57d050,this['path_']=_0x41c109;}['getImmediateChild'](_0x4348ac){const _0xa7b100=A(this['path_'],_0x4348ac);return new ls(this['syncTree_'],_0xa7b100);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x5b7b43){return _0x5b7b43=_0x5b7b43||{},_0x5b7b43['timestamp']=_0x5b7b43['timestamp']||new Date()['getTime'](),_0x5b7b43;},fr=function(_0x18b356,_0x55658a,_0x402718){if(!_0x18b356||typeof _0x18b356!='object')return _0x18b356;if(f('.sv'in _0x18b356,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x18b356['.sv']=='string')return td(_0x18b356['.sv'],_0x55658a,_0x402718);if(typeof _0x18b356['.sv']=='object')return nd(_0x18b356['.sv'],_0x55658a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x18b356,null,0x2));},td=function(_0x575697,_0xb0feee,_0x1aaf8b){switch(_0x575697){case'timestamp':return _0x1aaf8b['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x575697);}},nd=function(_0x17bca8,_0x2a9da6,_0x4e45c1){_0x17bca8['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x17bca8,null,0x2));const _0x1e5922=_0x17bca8['increment'];typeof _0x1e5922!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1e5922);const _0x4c82e7=_0x2a9da6['node']();if(f(_0x4c82e7!==null&&typeof _0x4c82e7<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4c82e7['isLeafNode']())return _0x1e5922;const _0x80ea61=_0x4c82e7['getValue']();return typeof _0x80ea61!='number'?_0x1e5922:_0x80ea61+_0x1e5922;},Zo=function(_0x49086a,_0x305739,_0x483f41,_0x4fc0dd){return us(_0x305739,new ls(_0x483f41,_0x49086a),_0x4fc0dd);},hs=function(_0x385c8d,_0x1b802f,_0x5a2b96){return us(_0x385c8d,new cs(_0x1b802f),_0x5a2b96);};function us(_0x28e96f,_0x41a905,_0x193ae7){const _0x184857=_0x28e96f['getPriority']()['val'](),_0x2d144e=fr(_0x184857,_0x41a905['getImmediateChild']('.priority'),_0x193ae7);let _0x1f4fce;if(_0x28e96f['isLeafNode']()){const _0x5717ed=_0x28e96f,_0x9d7ac7=fr(_0x5717ed['getValue'](),_0x41a905,_0x193ae7);return _0x9d7ac7!==_0x5717ed['getValue']()||_0x2d144e!==_0x5717ed['getPriority']()['val']()?new D(_0x9d7ac7,N(_0x2d144e)):_0x28e96f;}else{const _0x3e95ff=_0x28e96f;return _0x1f4fce=_0x3e95ff,_0x2d144e!==_0x3e95ff['getPriority']()['val']()&&(_0x1f4fce=_0x1f4fce['updatePriority'](new D(_0x2d144e))),_0x3e95ff['forEachChild'](R,(_0x176fa0,_0xacfa8e)=>{const _0x29ef0c=us(_0xacfa8e,_0x41a905['getImmediateChild'](_0x176fa0),_0x193ae7);_0x29ef0c!==_0xacfa8e&&(_0x1f4fce=_0x1f4fce['updateImmediateChild'](_0x176fa0,_0x29ef0c));}),_0x1f4fce;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4eafa6='',_0x172edc=null,_0x21fdf3={'children':{},'childCount':0x0}){this['name']=_0x4eafa6,this['parent']=_0x172edc,this['node']=_0x21fdf3;}}function Un(_0x2b443a,_0x6b82d3){let _0x441704=_0x6b82d3 instanceof C?_0x6b82d3:new C(_0x6b82d3),_0x4dbaea=_0x2b443a,_0x535f99=y(_0x441704);for(;_0x535f99!==null;){const _0x35e5fe=Oe(_0x4dbaea['node']['children'],_0x535f99)||{'children':{},'childCount':0x0};_0x4dbaea=new ds(_0x535f99,_0x4dbaea,_0x35e5fe),_0x441704=b(_0x441704),_0x535f99=y(_0x441704);}return _0x4dbaea;}function Ge(_0x33c09e){return _0x33c09e['node']['value'];}function fs(_0x8eff91,_0x4b66fa){_0x8eff91['node']['value']=_0x4b66fa,Ri(_0x8eff91);}function ea(_0x5d0bdc){return _0x5d0bdc['node']['childCount']>0x0;}function id(_0x389f55){return Ge(_0x389f55)===void 0x0&&!ea(_0x389f55);}function Wn(_0x11743c,_0x5b118e){x(_0x11743c['node']['children'],(_0x904ef6,_0x44851b)=>{_0x5b118e(new ds(_0x904ef6,_0x11743c,_0x44851b));});}function ta(_0x1a97e8,_0x4eb82f,_0x55c702,_0x5c69d3){_0x55c702&&_0x4eb82f(_0x1a97e8),Wn(_0x1a97e8,_0xd9be85=>{ta(_0xd9be85,_0x4eb82f,!0x0);});}function sd(_0x47b0ac,_0x343fc7,_0x251a2f){let _0x5d906d=_0x47b0ac['parent'];for(;_0x5d906d!==null;){if(_0x343fc7(_0x5d906d))return!0x0;_0x5d906d=_0x5d906d['parent'];}return!0x1;}function Gt(_0x318699){return new C(_0x318699['parent']===null?_0x318699['name']:Gt(_0x318699['parent'])+'/'+_0x318699['name']);}function Ri(_0xbe9a2){_0xbe9a2['parent']!==null&&rd(_0xbe9a2['parent'],_0xbe9a2['name'],_0xbe9a2);}function rd(_0x4e1e3f,_0x4e97e4,_0xf75929){const _0x9fbabc=id(_0xf75929),_0x3c0041=Y(_0x4e1e3f['node']['children'],_0x4e97e4);_0x9fbabc&&_0x3c0041?(delete _0x4e1e3f['node']['children'][_0x4e97e4],_0x4e1e3f['node']['childCount']--,Ri(_0x4e1e3f)):!_0x9fbabc&&!_0x3c0041&&(_0x4e1e3f['node']['children'][_0x4e97e4]=_0xf75929['node'],_0x4e1e3f['node']['childCount']++,Ri(_0x4e1e3f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0xe0c1cb){return typeof _0xe0c1cb=='string'&&_0xe0c1cb['length']!==0x0&&!od['test'](_0xe0c1cb);},na=function(_0x351880){return typeof _0x351880=='string'&&_0x351880['length']!==0x0&&!ad['test'](_0x351880);},cd=function(_0x4f9f84){return _0x4f9f84&&(_0x4f9f84=_0x4f9f84['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x4f9f84);},Cn=function(_0x1c6b3f){return _0x1c6b3f===null||typeof _0x1c6b3f=='string'||typeof _0x1c6b3f=='number'&&!Wi(_0x1c6b3f)||_0x1c6b3f&&typeof _0x1c6b3f=='object'&&Y(_0x1c6b3f,'.sv');},qt=function(_0x83a7d6,_0x2cd5a8,_0x2bd0ee,_0x80a61a){_0x80a61a&&_0x2cd5a8===void 0x0||zt(Nn(_0x83a7d6,'value'),_0x2cd5a8,_0x2bd0ee);},zt=function(_0x43baa6,_0x263438,_0x24924f){const _0x44cfe4=_0x24924f instanceof C?new Sh(_0x24924f,_0x43baa6):_0x24924f;if(_0x263438===void 0x0)throw new Error(_0x43baa6+'contains\x20undefined\x20'+Ne(_0x44cfe4));if(typeof _0x263438=='function')throw new Error(_0x43baa6+'contains\x20a\x20function\x20'+Ne(_0x44cfe4)+'\x20with\x20contents\x20=\x20'+_0x263438['toString']());if(Wi(_0x263438))throw new Error(_0x43baa6+'contains\x20'+_0x263438['toString']()+'\x20'+Ne(_0x44cfe4));if(typeof _0x263438=='string'&&_0x263438['length']>oi/0x3&&Pn(_0x263438)>oi)throw new Error(_0x43baa6+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x44cfe4)+'\x20(\x27'+_0x263438['substring'](0x0,0x32)+'...\x27)');if(_0x263438&&typeof _0x263438=='object'){let _0x3c54df=!0x1,_0x743780=!0x1;if(x(_0x263438,(_0x240225,_0x340da9)=>{if(_0x240225==='.value')_0x3c54df=!0x0;else{if(_0x240225!=='.priority'&&_0x240225!=='.sv'&&(_0x743780=!0x0,!ps(_0x240225)))throw new Error(_0x43baa6+'\x20contains\x20an\x20invalid\x20key\x20('+_0x240225+')\x20'+Ne(_0x44cfe4)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x44cfe4,_0x240225),zt(_0x43baa6,_0x340da9,_0x44cfe4),Rh(_0x44cfe4);}),_0x3c54df&&_0x743780)throw new Error(_0x43baa6+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x44cfe4)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x581d86,_0x3e5aec){let _0x6f17f9,_0xb8d81c;for(_0x6f17f9=0x0;_0x6f17f9<_0x3e5aec['length'];_0x6f17f9++){_0xb8d81c=_0x3e5aec[_0x6f17f9];const _0x27b8ab=kt(_0xb8d81c);for(let _0x214452=0x0;_0x214452<_0x27b8ab['length'];_0x214452++)if(!(_0x27b8ab[_0x214452]==='.priority'&&_0x214452===_0x27b8ab['length']-0x1)){if(!ps(_0x27b8ab[_0x214452]))throw new Error(_0x581d86+'contains\x20an\x20invalid\x20key\x20('+_0x27b8ab[_0x214452]+')\x20in\x20path\x20'+_0xb8d81c['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x3e5aec['sort'](Th);let _0x15c486=null;for(_0x6f17f9=0x0;_0x6f17f9<_0x3e5aec['length'];_0x6f17f9++){if(_0xb8d81c=_0x3e5aec[_0x6f17f9],_0x15c486!==null&&$(_0x15c486,_0xb8d81c))throw new Error(_0x581d86+'contains\x20a\x20path\x20'+_0x15c486['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xb8d81c['toString']());_0x15c486=_0xb8d81c;}},hd=function(_0x2a9817,_0x57571f,_0x51d005,_0x16f0da){const _0x14918c=Nn(_0x2a9817,'values');if(!(_0x57571f&&typeof _0x57571f=='object')||Array['isArray'](_0x57571f))throw new Error(_0x14918c+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1bb11d=[];x(_0x57571f,(_0x42be48,_0x121261)=>{const _0x3f9a4c=new C(_0x42be48);if(zt(_0x14918c,_0x121261,A(_0x51d005,_0x3f9a4c)),Gi(_0x3f9a4c)==='.priority'&&!Cn(_0x121261))throw new Error(_0x14918c+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3f9a4c['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1bb11d['push'](_0x3f9a4c);}),ld(_0x14918c,_0x1bb11d);},_s=function(_0x4c7345,_0x213b0d,_0x2cbaba,_0x4c5901){if(!na(_0x2cbaba))throw new Error(Nn(_0x4c7345,_0x213b0d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2cbaba+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5ca771,_0x16b800,_0x31aea7,_0x4a31f3){_0x31aea7&&(_0x31aea7=_0x31aea7['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5ca771,_0x16b800,_0x31aea7);},gs=function(_0x4acabf,_0x209f35){if(y(_0x209f35)==='.info')throw new Error(_0x4acabf+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x4c6a36,_0x576c0e){const _0x5a4c9e=_0x576c0e['path']['toString']();if(typeof _0x576c0e['repoInfo']['host']!='string'||_0x576c0e['repoInfo']['host']['length']===0x0||!ps(_0x576c0e['repoInfo']['namespace'])&&_0x576c0e['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5a4c9e['length']!==0x0&&!cd(_0x5a4c9e))throw new Error(Nn(_0x4c6a36,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x4bae01,_0x4cd11b){let _0x531472=null;for(let _0x4e4e0d=0x0;_0x4e4e0d<_0x4cd11b['length'];_0x4e4e0d++){const _0x58825b=_0x4cd11b[_0x4e4e0d],_0x390d43=_0x58825b['getPath']();_0x531472!==null&&!qi(_0x390d43,_0x531472['path'])&&(_0x4bae01['eventLists_']['push'](_0x531472),_0x531472=null),_0x531472===null&&(_0x531472={'events':[],'path':_0x390d43}),_0x531472['events']['push'](_0x58825b);}_0x531472&&_0x4bae01['eventLists_']['push'](_0x531472);}function ia(_0x1eb210,_0xa402f7,_0x3609e0){Bn(_0x1eb210,_0x3609e0),sa(_0x1eb210,_0x359c46=>qi(_0x359c46,_0xa402f7));}function V(_0x4006c5,_0x482fa0,_0xf33213){Bn(_0x4006c5,_0xf33213),sa(_0x4006c5,_0x1a7f07=>$(_0x1a7f07,_0x482fa0)||$(_0x482fa0,_0x1a7f07));}function sa(_0x4135e0,_0x39fa2b){_0x4135e0['recursionDepth_']++;let _0x45de92=!0x0;for(let _0x34a1b3=0x0;_0x34a1b3<_0x4135e0['eventLists_']['length'];_0x34a1b3++){const _0x258491=_0x4135e0['eventLists_'][_0x34a1b3];if(_0x258491){const _0x5a7bc8=_0x258491['path'];_0x39fa2b(_0x5a7bc8)?(pd(_0x4135e0['eventLists_'][_0x34a1b3]),_0x4135e0['eventLists_'][_0x34a1b3]=null):_0x45de92=!0x1;}}_0x45de92&&(_0x4135e0['eventLists_']=[]),_0x4135e0['recursionDepth_']--;}function pd(_0x30c691){for(let _0x49daff=0x0;_0x49daff<_0x30c691['events']['length'];_0x49daff++){const _0x5d1fde=_0x30c691['events'][_0x49daff];if(_0x5d1fde!==null){_0x30c691['events'][_0x49daff]=null;const _0x41345c=_0x5d1fde['getEventRunner']();Et&&L('event:\x20'+_0x5d1fde['toString']()),lt(_0x41345c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x592c80,_0x2c92c5,_0x2f7abb,_0x2c520a){this['repoInfo_']=_0x592c80,this['forceRestClient_']=_0x2c92c5,this['authTokenProvider_']=_0x2f7abb,this['appCheckProvider_']=_0x2c520a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x493696,_0x523b6b,_0x1011e6){if(_0x493696['stats_']=Hi(_0x493696['repoInfo_']),_0x493696['forceRestClient_']||Yl())_0x493696['server_']=new fn(_0x493696['repoInfo_'],(_0x58fdaf,_0x215f6e,_0x461a21,_0x56ef91)=>{pr(_0x493696,_0x58fdaf,_0x215f6e,_0x461a21,_0x56ef91);},_0x493696['authTokenProvider_'],_0x493696['appCheckProvider_']),setTimeout(()=>_r(_0x493696,!0x0),0x0);else{if(typeof _0x1011e6<'u'&&_0x1011e6!==null){if(typeof _0x1011e6!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1011e6);}catch(_0x5caa1c){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5caa1c);}}_0x493696['persistentConnection_']=new ie(_0x493696['repoInfo_'],_0x523b6b,(_0x2114fa,_0x14cb5f,_0x49175d,_0x491bb5)=>{pr(_0x493696,_0x2114fa,_0x14cb5f,_0x49175d,_0x491bb5);},_0x3d540b=>{_r(_0x493696,_0x3d540b);},_0x569f39=>{yd(_0x493696,_0x569f39);},_0x493696['authTokenProvider_'],_0x493696['appCheckProvider_'],_0x1011e6),_0x493696['server_']=_0x493696['persistentConnection_'];}_0x493696['authTokenProvider_']['addTokenChangeListener'](_0x56fcef=>{_0x493696['server_']['refreshAuthToken'](_0x56fcef);}),_0x493696['appCheckProvider_']['addTokenChangeListener'](_0x193563=>{_0x493696['server_']['refreshAppCheckToken'](_0x193563['token']);}),_0x493696['statsReporter_']=eh(_0x493696['repoInfo_'],()=>new eu(_0x493696['stats_'],_0x493696['server_'])),_0x493696['infoData_']=new Yh(),_0x493696['infoSyncTree_']=new dr({'startListening':(_0x2fd38e,_0x20aca9,_0x402fc2,_0x397ff2)=>{let _0x14ab2c=[];const _0x5427e9=_0x493696['infoData_']['getNode'](_0x2fd38e['_path']);return _0x5427e9['isEmpty']()||(_0x14ab2c=$t(_0x493696['infoSyncTree_'],_0x2fd38e['_path'],_0x5427e9),setTimeout(()=>{_0x397ff2('ok');},0x0)),_0x14ab2c;},'stopListening':()=>{}}),ms(_0x493696,'connected',!0x1),_0x493696['serverSyncTree_']=new dr({'startListening':(_0x3f7c5a,_0x5ef310,_0x30b2b3,_0x8d39f1)=>(_0x493696['server_']['listen'](_0x3f7c5a,_0x30b2b3,_0x5ef310,(_0x1340b5,_0x17b32a)=>{const _0x57f850=_0x8d39f1(_0x1340b5,_0x17b32a);V(_0x493696['eventQueue_'],_0x3f7c5a['_path'],_0x57f850);}),[]),'stopListening':(_0x33e107,_0x20eae9)=>{_0x493696['server_']['unlisten'](_0x33e107,_0x20eae9);}});}function oa(_0x286be0){const _0x46a007=_0x286be0['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x46a007;}function jt(_0x561250){return ed({'timestamp':oa(_0x561250)});}function pr(_0xc441f8,_0x275939,_0x5ed2b0,_0x411a6a,_0x2c1353){_0xc441f8['dataUpdateCount']++;const _0x3ec595=new C(_0x275939);_0x5ed2b0=_0xc441f8['interceptServerDataCallback_']?_0xc441f8['interceptServerDataCallback_'](_0x275939,_0x5ed2b0):_0x5ed2b0;let _0x11808c=[];if(_0x2c1353){if(_0x411a6a){const _0x2b4ae5=ln(_0x5ed2b0,_0x5d4edf=>N(_0x5d4edf));_0x11808c=Ku(_0xc441f8['serverSyncTree_'],_0x3ec595,_0x2b4ae5,_0x2c1353);}else{const _0x153350=N(_0x5ed2b0);_0x11808c=Yo(_0xc441f8['serverSyncTree_'],_0x3ec595,_0x153350,_0x2c1353);}}else{if(_0x411a6a){const _0x40abe5=ln(_0x5ed2b0,_0x5c3393=>N(_0x5c3393));_0x11808c=qu(_0xc441f8['serverSyncTree_'],_0x3ec595,_0x40abe5);}else{const _0x1462ec=N(_0x5ed2b0);_0x11808c=$t(_0xc441f8['serverSyncTree_'],_0x3ec595,_0x1462ec);}}let _0x1f7c51=_0x3ec595;_0x11808c['length']>0x0&&(_0x1f7c51=st(_0xc441f8,_0x3ec595)),V(_0xc441f8['eventQueue_'],_0x1f7c51,_0x11808c);}function _r(_0x485d9a,_0xf6d47d){ms(_0x485d9a,'connected',_0xf6d47d),_0xf6d47d===!0x1&&wd(_0x485d9a);}function yd(_0x2688fc,_0x3b357b){x(_0x3b357b,(_0x10de58,_0x33fd3e)=>{ms(_0x2688fc,_0x10de58,_0x33fd3e);});}function ms(_0x43ae04,_0x1ac38d,_0x2af7b7){const _0x58455b=new C('/.info/'+_0x1ac38d),_0x5745f6=N(_0x2af7b7);_0x43ae04['infoData_']['updateSnapshot'](_0x58455b,_0x5745f6);const _0xf35ce8=$t(_0x43ae04['infoSyncTree_'],_0x58455b,_0x5745f6);V(_0x43ae04['eventQueue_'],_0x58455b,_0xf35ce8);}function Vn(_0x2051b1){return _0x2051b1['nextWriteId_']++;}function vd(_0x155873,_0x5216f4,_0x18c232){const _0x133524=Yu(_0x155873['serverSyncTree_'],_0x5216f4);return _0x133524!=null?Promise['resolve'](_0x133524):_0x155873['server_']['get'](_0x5216f4)['then'](_0x3755b1=>{const _0xfe2f82=N(_0x3755b1)['withIndex'](_0x5216f4['_queryParams']['getIndex']());bi(_0x155873['serverSyncTree_'],_0x5216f4,_0x18c232,!0x0);let _0x83bdae;if(_0x5216f4['_queryParams']['loadsAllData']())_0x83bdae=$t(_0x155873['serverSyncTree_'],_0x5216f4['_path'],_0xfe2f82);else{const _0x4b77a5=Mt(_0x155873['serverSyncTree_'],_0x5216f4);_0x83bdae=Yo(_0x155873['serverSyncTree_'],_0x5216f4['_path'],_0xfe2f82,_0x4b77a5);}return V(_0x155873['eventQueue_'],_0x5216f4['_path'],_0x83bdae),wn(_0x155873['serverSyncTree_'],_0x5216f4,_0x18c232,null,!0x0),_0xfe2f82;},_0x141a32=>(ut(_0x155873,'get\x20for\x20query\x20'+O(_0x5216f4)+'\x20failed:\x20'+_0x141a32),Promise['reject'](new Error(_0x141a32))));}function Ed(_0x5781cc,_0x18ccc3,_0x52a704,_0x18b2e8,_0x4cf2b9){ut(_0x5781cc,'set',{'path':_0x18ccc3['toString'](),'value':_0x52a704,'priority':_0x18b2e8});const _0x141f1d=jt(_0x5781cc),_0x3bcbc9=N(_0x52a704,_0x18b2e8),_0x10a046=xn(_0x5781cc['serverSyncTree_'],_0x18ccc3),_0x265d10=hs(_0x3bcbc9,_0x10a046,_0x141f1d),_0x4f5204=Vn(_0x5781cc),_0xc8022d=ss(_0x5781cc['serverSyncTree_'],_0x18ccc3,_0x265d10,_0x4f5204,!0x0);Bn(_0x5781cc['eventQueue_'],_0xc8022d),_0x5781cc['server_']['put'](_0x18ccc3['toString'](),_0x3bcbc9['val'](!0x0),(_0x4d0d1f,_0x5e3f1)=>{const _0x208385=_0x4d0d1f==='ok';_0x208385||U('set\x20at\x20'+_0x18ccc3+'\x20failed:\x20'+_0x4d0d1f);const _0xce97c3=pe(_0x5781cc['serverSyncTree_'],_0x4f5204,!_0x208385);V(_0x5781cc['eventQueue_'],_0x18ccc3,_0xce97c3),Ai(_0x5781cc,_0x4cf2b9,_0x4d0d1f,_0x5e3f1);});const _0x7eb068=vs(_0x5781cc,_0x18ccc3);st(_0x5781cc,_0x7eb068),V(_0x5781cc['eventQueue_'],_0x7eb068,[]);}function Id(_0x530b69,_0x5d7bcf,_0x5d809a,_0x3ad214){ut(_0x530b69,'update',{'path':_0x5d7bcf['toString'](),'value':_0x5d809a});let _0x30dd2f=!0x0;const _0x430415=jt(_0x530b69),_0x723348={};if(x(_0x5d809a,(_0x7221a2,_0x4d0ef3)=>{_0x30dd2f=!0x1,_0x723348[_0x7221a2]=Zo(A(_0x5d7bcf,_0x7221a2),N(_0x4d0ef3),_0x530b69['serverSyncTree_'],_0x430415);}),_0x30dd2f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x530b69,_0x3ad214,'ok',void 0x0);else{const _0x5e8796=Vn(_0x530b69),_0x55a81a=Gu(_0x530b69['serverSyncTree_'],_0x5d7bcf,_0x723348,_0x5e8796);Bn(_0x530b69['eventQueue_'],_0x55a81a),_0x530b69['server_']['merge'](_0x5d7bcf['toString'](),_0x5d809a,(_0x4b9e3e,_0x23b5a7)=>{const _0x3150d9=_0x4b9e3e==='ok';_0x3150d9||U('update\x20at\x20'+_0x5d7bcf+'\x20failed:\x20'+_0x4b9e3e);const _0x1a5010=pe(_0x530b69['serverSyncTree_'],_0x5e8796,!_0x3150d9),_0x3221ea=_0x1a5010['length']>0x0?st(_0x530b69,_0x5d7bcf):_0x5d7bcf;V(_0x530b69['eventQueue_'],_0x3221ea,_0x1a5010),Ai(_0x530b69,_0x3ad214,_0x4b9e3e,_0x23b5a7);}),x(_0x5d809a,_0xbe02bf=>{const _0x46dde1=vs(_0x530b69,A(_0x5d7bcf,_0xbe02bf));st(_0x530b69,_0x46dde1);}),V(_0x530b69['eventQueue_'],_0x5d7bcf,[]);}}function wd(_0x3cf094){ut(_0x3cf094,'onDisconnectEvents');const _0x3e2604=jt(_0x3cf094),_0x584721=pn();Ei(_0x3cf094['onDisconnect_'],w(),(_0x1adace,_0x405230)=>{const _0x561550=Zo(_0x1adace,_0x405230,_0x3cf094['serverSyncTree_'],_0x3e2604);Mo(_0x584721,_0x1adace,_0x561550);});let _0x30ce2c=[];Ei(_0x584721,w(),(_0x1b2c3b,_0x1be157)=>{_0x30ce2c=_0x30ce2c['concat']($t(_0x3cf094['serverSyncTree_'],_0x1b2c3b,_0x1be157));const _0x561686=vs(_0x3cf094,_0x1b2c3b);st(_0x3cf094,_0x561686);}),_0x3cf094['onDisconnect_']=pn(),V(_0x3cf094['eventQueue_'],w(),_0x30ce2c);}function Cd(_0x53d0d6,_0xc8113f,_0x92e042){let _0x10d2e6;y(_0xc8113f['_path'])==='.info'?_0x10d2e6=bi(_0x53d0d6['infoSyncTree_'],_0xc8113f,_0x92e042):_0x10d2e6=bi(_0x53d0d6['serverSyncTree_'],_0xc8113f,_0x92e042),ia(_0x53d0d6['eventQueue_'],_0xc8113f['_path'],_0x10d2e6);}function Td(_0x193aaa,_0x9b3b73,_0x30b6ed){let _0x5c597f;y(_0x9b3b73['_path'])==='.info'?_0x5c597f=wn(_0x193aaa['infoSyncTree_'],_0x9b3b73,_0x30b6ed):_0x5c597f=wn(_0x193aaa['serverSyncTree_'],_0x9b3b73,_0x30b6ed),ia(_0x193aaa['eventQueue_'],_0x9b3b73['_path'],_0x5c597f);}function aa(_0x496c33){_0x496c33['persistentConnection_']&&_0x496c33['persistentConnection_']['interrupt'](ra);}function Sd(_0x579b90){_0x579b90['persistentConnection_']&&_0x579b90['persistentConnection_']['resume'](ra);}function ut(_0x34334e,..._0x4dfd6e){let _0x35f304='';_0x34334e['persistentConnection_']&&(_0x35f304=_0x34334e['persistentConnection_']['id']+':'),L(_0x35f304,..._0x4dfd6e);}function Ai(_0x4c57f5,_0x439350,_0xd8632d,_0x5e543e){_0x439350&&lt(()=>{if(_0xd8632d==='ok')_0x439350(null);else{const _0x5e6baa=(_0xd8632d||'error')['toUpperCase']();let _0x39fdbd=_0x5e6baa;_0x5e543e&&(_0x39fdbd+=':\x20'+_0x5e543e);const _0x1a1bce=new Error(_0x39fdbd);_0x1a1bce['code']=_0x5e6baa,_0x439350(_0x1a1bce);}});}function bd(_0x334d7a,_0x589a92,_0xbc2236,_0x3ac310,_0x4d79a4,_0x282347){ut(_0x334d7a,'transaction\x20on\x20'+_0x589a92);const _0xc9cbd4={'path':_0x589a92,'update':_0xbc2236,'onComplete':_0x3ac310,'status':null,'order':to(),'applyLocally':_0x282347,'retryCount':0x0,'unwatcher':_0x4d79a4,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x193439=ys(_0x334d7a,_0x589a92,void 0x0);_0xc9cbd4['currentInputSnapshot']=_0x193439;const _0x330145=_0xc9cbd4['update'](_0x193439['val']());if(_0x330145===void 0x0)_0xc9cbd4['unwatcher'](),_0xc9cbd4['currentOutputSnapshotRaw']=null,_0xc9cbd4['currentOutputSnapshotResolved']=null,_0xc9cbd4['onComplete']&&_0xc9cbd4['onComplete'](null,!0x1,_0xc9cbd4['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x330145,_0xc9cbd4['path']),_0xc9cbd4['status']=0x0;const _0x44fc47=Un(_0x334d7a['transactionQueueTree_'],_0x589a92),_0x554d3f=Ge(_0x44fc47)||[];_0x554d3f['push'](_0xc9cbd4),fs(_0x44fc47,_0x554d3f);let _0x43d689;typeof _0x330145=='object'&&_0x330145!==null&&Y(_0x330145,'.priority')?(_0x43d689=Oe(_0x330145,'.priority'),f(Cn(_0x43d689),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x43d689=(xn(_0x334d7a['serverSyncTree_'],_0x589a92)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x51367f=jt(_0x334d7a),_0x4b94f4=N(_0x330145,_0x43d689),_0x57f64f=hs(_0x4b94f4,_0x193439,_0x51367f);_0xc9cbd4['currentOutputSnapshotRaw']=_0x4b94f4,_0xc9cbd4['currentOutputSnapshotResolved']=_0x57f64f,_0xc9cbd4['currentWriteId']=Vn(_0x334d7a);const _0x2a5947=ss(_0x334d7a['serverSyncTree_'],_0x589a92,_0x57f64f,_0xc9cbd4['currentWriteId'],_0xc9cbd4['applyLocally']);V(_0x334d7a['eventQueue_'],_0x589a92,_0x2a5947),Hn(_0x334d7a,_0x334d7a['transactionQueueTree_']);}}function ys(_0x47c104,_0x2a7d6c,_0x2a75a8){return xn(_0x47c104['serverSyncTree_'],_0x2a7d6c,_0x2a75a8)||g['EMPTY_NODE'];}function Hn(_0x5c1e74,_0x123f04=_0x5c1e74['transactionQueueTree_']){if(_0x123f04||$n(_0x5c1e74,_0x123f04),Ge(_0x123f04)){const _0x5c6cc8=la(_0x5c1e74,_0x123f04);f(_0x5c6cc8['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5c6cc8['every'](_0x537c5a=>_0x537c5a['status']===0x0)&&Rd(_0x5c1e74,Gt(_0x123f04),_0x5c6cc8);}else ea(_0x123f04)&&Wn(_0x123f04,_0x5cfb59=>{Hn(_0x5c1e74,_0x5cfb59);});}function Rd(_0x4a7986,_0x43f694,_0xf35240){const _0xf56905=_0xf35240['map'](_0x1d104a=>_0x1d104a['currentWriteId']),_0x3424be=ys(_0x4a7986,_0x43f694,_0xf56905);let _0x8a0f52=_0x3424be;const _0x36d0bc=_0x3424be['hash']();for(let _0x38626b=0x0;_0x38626b<_0xf35240['length'];_0x38626b++){const _0x17f01c=_0xf35240[_0x38626b];f(_0x17f01c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x17f01c['status']=0x1,_0x17f01c['retryCount']++;const _0x31e047=F(_0x43f694,_0x17f01c['path']);_0x8a0f52=_0x8a0f52['updateChild'](_0x31e047,_0x17f01c['currentOutputSnapshotRaw']);}const _0x52cb00=_0x8a0f52['val'](!0x0),_0x7e85a0=_0x43f694;_0x4a7986['server_']['put'](_0x7e85a0['toString'](),_0x52cb00,_0x13f706=>{ut(_0x4a7986,'transaction\x20put\x20response',{'path':_0x7e85a0['toString'](),'status':_0x13f706});let _0x541249=[];if(_0x13f706==='ok'){const _0x1b3932=[];for(let _0x4ccf27=0x0;_0x4ccf27<_0xf35240['length'];_0x4ccf27++)_0xf35240[_0x4ccf27]['status']=0x2,_0x541249=_0x541249['concat'](pe(_0x4a7986['serverSyncTree_'],_0xf35240[_0x4ccf27]['currentWriteId'])),_0xf35240[_0x4ccf27]['onComplete']&&_0x1b3932['push'](()=>_0xf35240[_0x4ccf27]['onComplete'](null,!0x0,_0xf35240[_0x4ccf27]['currentOutputSnapshotResolved'])),_0xf35240[_0x4ccf27]['unwatcher']();$n(_0x4a7986,Un(_0x4a7986['transactionQueueTree_'],_0x43f694)),Hn(_0x4a7986,_0x4a7986['transactionQueueTree_']),V(_0x4a7986['eventQueue_'],_0x43f694,_0x541249);for(let _0x203ab7=0x0;_0x203ab7<_0x1b3932['length'];_0x203ab7++)lt(_0x1b3932[_0x203ab7]);}else{if(_0x13f706==='datastale'){for(let _0x3899ab=0x0;_0x3899ab<_0xf35240['length'];_0x3899ab++)_0xf35240[_0x3899ab]['status']===0x3?_0xf35240[_0x3899ab]['status']=0x4:_0xf35240[_0x3899ab]['status']=0x0;}else{U('transaction\x20at\x20'+_0x7e85a0['toString']()+'\x20failed:\x20'+_0x13f706);for(let _0x153b35=0x0;_0x153b35<_0xf35240['length'];_0x153b35++)_0xf35240[_0x153b35]['status']=0x4,_0xf35240[_0x153b35]['abortReason']=_0x13f706;}st(_0x4a7986,_0x43f694);}},_0x36d0bc);}function st(_0x39c683,_0x29f798){const _0x3ae82f=ca(_0x39c683,_0x29f798),_0x447e84=Gt(_0x3ae82f),_0x51db66=la(_0x39c683,_0x3ae82f);return Ad(_0x39c683,_0x51db66,_0x447e84),_0x447e84;}function Ad(_0x572450,_0x3b1eda,_0x542dd1){if(_0x3b1eda['length']===0x0)return;const _0x56b6b1=[];let _0x2d8c23=[];const _0x4d0702=_0x3b1eda['filter'](_0x5bb6d8=>_0x5bb6d8['status']===0x0)['map'](_0x1d9954=>_0x1d9954['currentWriteId']);for(let _0x53b879=0x0;_0x53b879<_0x3b1eda['length'];_0x53b879++){const _0x2dc2ee=_0x3b1eda[_0x53b879],_0xd7e3fb=F(_0x542dd1,_0x2dc2ee['path']);let _0x3a3811=!0x1,_0x47e6e1;if(f(_0xd7e3fb!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2dc2ee['status']===0x4)_0x3a3811=!0x0,_0x47e6e1=_0x2dc2ee['abortReason'],_0x2d8c23=_0x2d8c23['concat'](pe(_0x572450['serverSyncTree_'],_0x2dc2ee['currentWriteId'],!0x0));else{if(_0x2dc2ee['status']===0x0){if(_0x2dc2ee['retryCount']>=_d)_0x3a3811=!0x0,_0x47e6e1='maxretry',_0x2d8c23=_0x2d8c23['concat'](pe(_0x572450['serverSyncTree_'],_0x2dc2ee['currentWriteId'],!0x0));else{const _0x58726b=ys(_0x572450,_0x2dc2ee['path'],_0x4d0702);_0x2dc2ee['currentInputSnapshot']=_0x58726b;const _0x36aee4=_0x3b1eda[_0x53b879]['update'](_0x58726b['val']());if(_0x36aee4!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x36aee4,_0x2dc2ee['path']);let _0x59bb3a=N(_0x36aee4);typeof _0x36aee4=='object'&&_0x36aee4!=null&&Y(_0x36aee4,'.priority')||(_0x59bb3a=_0x59bb3a['updatePriority'](_0x58726b['getPriority']()));const _0x500862=_0x2dc2ee['currentWriteId'],_0x154c17=jt(_0x572450),_0x2f95ee=hs(_0x59bb3a,_0x58726b,_0x154c17);_0x2dc2ee['currentOutputSnapshotRaw']=_0x59bb3a,_0x2dc2ee['currentOutputSnapshotResolved']=_0x2f95ee,_0x2dc2ee['currentWriteId']=Vn(_0x572450),_0x4d0702['splice'](_0x4d0702['indexOf'](_0x500862),0x1),_0x2d8c23=_0x2d8c23['concat'](ss(_0x572450['serverSyncTree_'],_0x2dc2ee['path'],_0x2f95ee,_0x2dc2ee['currentWriteId'],_0x2dc2ee['applyLocally'])),_0x2d8c23=_0x2d8c23['concat'](pe(_0x572450['serverSyncTree_'],_0x500862,!0x0));}else _0x3a3811=!0x0,_0x47e6e1='nodata',_0x2d8c23=_0x2d8c23['concat'](pe(_0x572450['serverSyncTree_'],_0x2dc2ee['currentWriteId'],!0x0));}}}V(_0x572450['eventQueue_'],_0x542dd1,_0x2d8c23),_0x2d8c23=[],_0x3a3811&&(_0x3b1eda[_0x53b879]['status']=0x2,function(_0xe81564){setTimeout(_0xe81564,Math['floor'](0x0));}(_0x3b1eda[_0x53b879]['unwatcher']),_0x3b1eda[_0x53b879]['onComplete']&&(_0x47e6e1==='nodata'?_0x56b6b1['push'](()=>_0x3b1eda[_0x53b879]['onComplete'](null,!0x1,_0x3b1eda[_0x53b879]['currentInputSnapshot'])):_0x56b6b1['push'](()=>_0x3b1eda[_0x53b879]['onComplete'](new Error(_0x47e6e1),!0x1,null))));}$n(_0x572450,_0x572450['transactionQueueTree_']);for(let _0x1a405c=0x0;_0x1a405c<_0x56b6b1['length'];_0x1a405c++)lt(_0x56b6b1[_0x1a405c]);Hn(_0x572450,_0x572450['transactionQueueTree_']);}function ca(_0x28a8ef,_0x2f3819){let _0x28e347,_0x137a43=_0x28a8ef['transactionQueueTree_'];for(_0x28e347=y(_0x2f3819);_0x28e347!==null&&Ge(_0x137a43)===void 0x0;)_0x137a43=Un(_0x137a43,_0x28e347),_0x2f3819=b(_0x2f3819),_0x28e347=y(_0x2f3819);return _0x137a43;}function la(_0x1a168a,_0x106bd0){const _0x934dd8=[];return ha(_0x1a168a,_0x106bd0,_0x934dd8),_0x934dd8['sort']((_0x1c5615,_0x4bef60)=>_0x1c5615['order']-_0x4bef60['order']),_0x934dd8;}function ha(_0x55d04f,_0x1e7e0f,_0xc36812){const _0x2d1066=Ge(_0x1e7e0f);if(_0x2d1066){for(let _0xdce663=0x0;_0xdce663<_0x2d1066['length'];_0xdce663++)_0xc36812['push'](_0x2d1066[_0xdce663]);}Wn(_0x1e7e0f,_0x5e2165=>{ha(_0x55d04f,_0x5e2165,_0xc36812);});}function $n(_0x220e8b,_0x575465){const _0x4f44b6=Ge(_0x575465);if(_0x4f44b6){let _0x3645f1=0x0;for(let _0x640bb8=0x0;_0x640bb8<_0x4f44b6['length'];_0x640bb8++)_0x4f44b6[_0x640bb8]['status']!==0x2&&(_0x4f44b6[_0x3645f1]=_0x4f44b6[_0x640bb8],_0x3645f1++);_0x4f44b6['length']=_0x3645f1,fs(_0x575465,_0x4f44b6['length']>0x0?_0x4f44b6:void 0x0);}Wn(_0x575465,_0x1d8758=>{$n(_0x220e8b,_0x1d8758);});}function vs(_0x2cf10b,_0xe67905){const _0x3ca5c5=Gt(ca(_0x2cf10b,_0xe67905)),_0xdd9236=Un(_0x2cf10b['transactionQueueTree_'],_0xe67905);return sd(_0xdd9236,_0x42605f=>{ai(_0x2cf10b,_0x42605f);}),ai(_0x2cf10b,_0xdd9236),ta(_0xdd9236,_0x3ae045=>{ai(_0x2cf10b,_0x3ae045);}),_0x3ca5c5;}function ai(_0x29e1e8,_0x48618f){const _0x455f92=Ge(_0x48618f);if(_0x455f92){const _0x4bfcbd=[];let _0x3f08ed=[],_0x4c626d=-0x1;for(let _0x1b918b=0x0;_0x1b918b<_0x455f92['length'];_0x1b918b++)_0x455f92[_0x1b918b]['status']===0x3||(_0x455f92[_0x1b918b]['status']===0x1?(f(_0x4c626d===_0x1b918b-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4c626d=_0x1b918b,_0x455f92[_0x1b918b]['status']=0x3,_0x455f92[_0x1b918b]['abortReason']='set'):(f(_0x455f92[_0x1b918b]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x455f92[_0x1b918b]['unwatcher'](),_0x3f08ed=_0x3f08ed['concat'](pe(_0x29e1e8['serverSyncTree_'],_0x455f92[_0x1b918b]['currentWriteId'],!0x0)),_0x455f92[_0x1b918b]['onComplete']&&_0x4bfcbd['push'](_0x455f92[_0x1b918b]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4c626d===-0x1?fs(_0x48618f,void 0x0):_0x455f92['length']=_0x4c626d+0x1,V(_0x29e1e8['eventQueue_'],Gt(_0x48618f),_0x3f08ed);for(let _0x233b03=0x0;_0x233b03<_0x4bfcbd['length'];_0x233b03++)lt(_0x4bfcbd[_0x233b03]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x17af45){let _0x216154='';const _0x349255=_0x17af45['split']('/');for(let _0x2d7446=0x0;_0x2d7446<_0x349255['length'];_0x2d7446++)if(_0x349255[_0x2d7446]['length']>0x0){let _0x580452=_0x349255[_0x2d7446];try{_0x580452=decodeURIComponent(_0x580452['replace'](/\+/g,'\x20'));}catch{}_0x216154+='/'+_0x580452;}return _0x216154;}function Nd(_0xa7ad1){const _0x5267f7={};_0xa7ad1['charAt'](0x0)==='?'&&(_0xa7ad1=_0xa7ad1['substring'](0x1));for(const _0xbd0e54 of _0xa7ad1['split']('&')){if(_0xbd0e54['length']===0x0)continue;const _0x45f839=_0xbd0e54['split']('=');_0x45f839['length']===0x2?_0x5267f7[decodeURIComponent(_0x45f839[0x0])]=decodeURIComponent(_0x45f839[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xbd0e54+'\x27\x20in\x20query\x20\x27'+_0xa7ad1+'\x27');}return _0x5267f7;}const gr=function(_0x5df650,_0x57ca9c){const _0xc28188=Pd(_0x5df650),_0x5c7724=_0xc28188['namespace'];_0xc28188['domain']==='firebase.com'&&oe(_0xc28188['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5c7724||_0x5c7724==='undefined')&&_0xc28188['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xc28188['secure']||Bl();const _0x429ae4=_0xc28188['scheme']==='ws'||_0xc28188['scheme']==='wss';return{'repoInfo':new _o(_0xc28188['host'],_0xc28188['secure'],_0x5c7724,_0x429ae4,_0x57ca9c,'',_0x5c7724!==_0xc28188['subdomain']),'path':new C(_0xc28188['pathString'])};},Pd=function(_0x2e6072){let _0x5dd1a4='',_0x13a12b='',_0x525459='',_0x47c995='',_0xc40964='',_0x2189bd=!0x0,_0x2f781a='https',_0x417ca6=0x1bb;if(typeof _0x2e6072=='string'){let _0x47df80=_0x2e6072['indexOf']('//');_0x47df80>=0x0&&(_0x2f781a=_0x2e6072['substring'](0x0,_0x47df80-0x1),_0x2e6072=_0x2e6072['substring'](_0x47df80+0x2));let _0x404835=_0x2e6072['indexOf']('/');_0x404835===-0x1&&(_0x404835=_0x2e6072['length']);let _0x2983a9=_0x2e6072['indexOf']('?');_0x2983a9===-0x1&&(_0x2983a9=_0x2e6072['length']),_0x5dd1a4=_0x2e6072['substring'](0x0,Math['min'](_0x404835,_0x2983a9)),_0x404835<_0x2983a9&&(_0x47c995=kd(_0x2e6072['substring'](_0x404835,_0x2983a9)));const _0x17f550=Nd(_0x2e6072['substring'](Math['min'](_0x2e6072['length'],_0x2983a9)));_0x47df80=_0x5dd1a4['indexOf'](':'),_0x47df80>=0x0?(_0x2189bd=_0x2f781a==='https'||_0x2f781a==='wss',_0x417ca6=parseInt(_0x5dd1a4['substring'](_0x47df80+0x1),0xa)):_0x47df80=_0x5dd1a4['length'];const _0x3d0aaf=_0x5dd1a4['slice'](0x0,_0x47df80);if(_0x3d0aaf['toLowerCase']()==='localhost')_0x13a12b='localhost';else{if(_0x3d0aaf['split']('.')['length']<=0x2)_0x13a12b=_0x3d0aaf;else{const _0x5cd63a=_0x5dd1a4['indexOf']('.');_0x525459=_0x5dd1a4['substring'](0x0,_0x5cd63a)['toLowerCase'](),_0x13a12b=_0x5dd1a4['substring'](_0x5cd63a+0x1),_0xc40964=_0x525459;}}'ns'in _0x17f550&&(_0xc40964=_0x17f550['ns']);}return{'host':_0x5dd1a4,'port':_0x417ca6,'domain':_0x13a12b,'subdomain':_0x525459,'secure':_0x2189bd,'scheme':_0x2f781a,'pathString':_0x47c995,'namespace':_0xc40964};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x2ae93e=0x0;const _0x4ece43=[];return function(_0x1173c5){const _0x1a77db=_0x1173c5===_0x2ae93e;_0x2ae93e=_0x1173c5;let _0x4f8792;const _0x1edb17=new Array(0x8);for(_0x4f8792=0x7;_0x4f8792>=0x0;_0x4f8792--)_0x1edb17[_0x4f8792]=mr['charAt'](_0x1173c5%0x40),_0x1173c5=Math['floor'](_0x1173c5/0x40);f(_0x1173c5===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5072ce=_0x1edb17['join']('');if(_0x1a77db){for(_0x4f8792=0xb;_0x4f8792>=0x0&&_0x4ece43[_0x4f8792]===0x3f;_0x4f8792--)_0x4ece43[_0x4f8792]=0x0;_0x4ece43[_0x4f8792]++;}else{for(_0x4f8792=0x0;_0x4f8792<0xc;_0x4f8792++)_0x4ece43[_0x4f8792]=Math['floor'](Math['random']()*0x40);}for(_0x4f8792=0x0;_0x4f8792<0xc;_0x4f8792++)_0x5072ce+=mr['charAt'](_0x4ece43[_0x4f8792]);return f(_0x5072ce['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5072ce;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x11123a,_0x5cef14,_0x58cd43,_0xff5c8e){this['eventType']=_0x11123a,this['eventRegistration']=_0x5cef14,this['snapshot']=_0x58cd43,this['prevName']=_0xff5c8e;}['getPath'](){const _0x36ba1d=this['snapshot']['ref'];return this['eventType']==='value'?_0x36ba1d['_path']:_0x36ba1d['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x604024,_0x358b37,_0x51a741){this['eventRegistration']=_0x604024,this['error']=_0x358b37,this['path']=_0x51a741;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x351eed,_0x566166){this['snapshotCallback']=_0x351eed,this['cancelCallback']=_0x566166;}['onValue'](_0x53a519,_0x3fa368){this['snapshotCallback']['call'](null,_0x53a519,_0x3fa368);}['onCancel'](_0x3e86ea){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3e86ea);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1ebdfe){return this['snapshotCallback']===_0x1ebdfe['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1ebdfe['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1ebdfe['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x14390a,_0x49fc92,_0x1295b9,_0x38e37d){this['_repo']=_0x14390a,this['_path']=_0x49fc92,this['_queryParams']=_0x1295b9,this['_orderByCalled']=_0x38e37d;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3ff390=nr(this['_queryParams']),_0x184f28=Bi(_0x3ff390);return _0x184f28==='{}'?'default':_0x184f28;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x389e9b){if(_0x389e9b=k(_0x389e9b),!(_0x389e9b instanceof be))return!0x1;const _0x1aa150=this['_repo']===_0x389e9b['_repo'],_0x4b7e9f=qi(this['_path'],_0x389e9b['_path']),_0x23a245=this['_queryIdentifier']===_0x389e9b['_queryIdentifier'];return _0x1aa150&&_0x4b7e9f&&_0x23a245;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x4a9bdb,_0x1285d3){if(_0x4a9bdb['_orderByCalled']===!0x0)throw new Error(_0x1285d3+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x74b94b){let _0x4e47e7=null,_0x35cf6a=null;if(_0x74b94b['hasStart']()&&(_0x4e47e7=_0x74b94b['getIndexStartValue']()),_0x74b94b['hasEnd']()&&(_0x35cf6a=_0x74b94b['getIndexEndValue']()),_0x74b94b['getIndex']()===ye){const _0x506a39='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3389cf='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x74b94b['hasStart']()){if(_0x74b94b['getIndexStartName']()!==xe)throw new Error(_0x506a39);if(typeof _0x4e47e7!='string')throw new Error(_0x3389cf);}if(_0x74b94b['hasEnd']()){if(_0x74b94b['getIndexEndName']()!==Ie)throw new Error(_0x506a39);if(typeof _0x35cf6a!='string')throw new Error(_0x3389cf);}}else{if(_0x74b94b['getIndex']()===R){if(_0x4e47e7!=null&&!Cn(_0x4e47e7)||_0x35cf6a!=null&&!Cn(_0x35cf6a))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x74b94b['getIndex']()instanceof Ki||_0x74b94b['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4e47e7!=null&&typeof _0x4e47e7=='object'||_0x35cf6a!=null&&typeof _0x35cf6a=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x7fa0cb){if(_0x7fa0cb['hasStart']()&&_0x7fa0cb['hasEnd']()&&_0x7fa0cb['hasLimit']()&&!_0x7fa0cb['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x477ba7,_0x1e7130){super(_0x477ba7,_0x1e7130,new Qi(),!0x1);}get['parent'](){const _0x4743d9=To(this['_path']);return _0x4743d9===null?null:new Z(this['_repo'],_0x4743d9);}get['root'](){let _0x2a92b8=this;for(;_0x2a92b8['parent']!==null;)_0x2a92b8=_0x2a92b8['parent'];return _0x2a92b8;}}class rt{constructor(_0x4a68ee,_0x1a85e4,_0x3eb1a2){this['_node']=_0x4a68ee,this['ref']=_0x1a85e4,this['_index']=_0x3eb1a2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x20dcc1){const _0x399a08=new C(_0x20dcc1),_0x49d366=Lt(this['ref'],_0x20dcc1);return new rt(this['_node']['getChild'](_0x399a08),_0x49d366,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x3b9cf4){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2dc84c,_0x30a4d9)=>_0x3b9cf4(new rt(_0x30a4d9,Lt(this['ref'],_0x2dc84c),R)));}['hasChild'](_0x173c7b){const _0xf319a=new C(_0x173c7b);return!this['_node']['getChild'](_0xf319a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x30ef2c,_0x31ac9a){return _0x30ef2c=k(_0x30ef2c),_0x30ef2c['_checkNotDeleted']('ref'),_0x31ac9a!==void 0x0?Lt(_0x30ef2c['_root'],_0x31ac9a):_0x30ef2c['_root'];}function Lt(_0x48399e,_0x5ad2f1){return _0x48399e=k(_0x48399e),y(_0x48399e['_path'])===null?ud('child','path',_0x5ad2f1):_s('child','path',_0x5ad2f1),new Z(_0x48399e['_repo'],A(_0x48399e['_path'],_0x5ad2f1));}function d_(_0x1d2c09,_0x2d6a13){_0x1d2c09=k(_0x1d2c09),gs('push',_0x1d2c09['_path']),qt('push',_0x2d6a13,_0x1d2c09['_path'],!0x0);const _0x3957dc=oa(_0x1d2c09['_repo']),_0x183c4c=Od(_0x3957dc),_0x25daf5=Lt(_0x1d2c09,_0x183c4c),_0x966d9f=Lt(_0x1d2c09,_0x183c4c);let _0x2df902;return _0x2d6a13!=null?_0x2df902=Ld(_0x966d9f,_0x2d6a13)['then'](()=>_0x966d9f):_0x2df902=Promise['resolve'](_0x966d9f),_0x25daf5['then']=_0x2df902['then']['bind'](_0x2df902),_0x25daf5['catch']=_0x2df902['then']['bind'](_0x2df902,void 0x0),_0x25daf5;}function Ld(_0x2c7e31,_0x3919f){_0x2c7e31=k(_0x2c7e31),gs('set',_0x2c7e31['_path']),qt('set',_0x3919f,_0x2c7e31['_path'],!0x1);const _0x24bce5=new Ve();return Ed(_0x2c7e31['_repo'],_0x2c7e31['_path'],_0x3919f,null,_0x24bce5['wrapCallback'](()=>{})),_0x24bce5['promise'];}function f_(_0x165315,_0x215bf3){hd('update',_0x215bf3,_0x165315['_path']);const _0xe53d57=new Ve();return Id(_0x165315['_repo'],_0x165315['_path'],_0x215bf3,_0xe53d57['wrapCallback'](()=>{})),_0xe53d57['promise'];}function p_(_0x5cfb68){_0x5cfb68=k(_0x5cfb68);const _0x32710c=new ua(()=>{}),_0x21904b=new qn(_0x32710c);return vd(_0x5cfb68['_repo'],_0x5cfb68,_0x21904b)['then'](_0x29b6e8=>new rt(_0x29b6e8,new Z(_0x5cfb68['_repo'],_0x5cfb68['_path']),_0x5cfb68['_queryParams']['getIndex']()));}class qn{constructor(_0x49f948){this['callbackContext']=_0x49f948;}['respondsTo'](_0x118e0c){return _0x118e0c==='value';}['createEvent'](_0x28f4fd,_0x532d81){const _0x3b4b83=_0x532d81['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x28f4fd['snapshotNode'],new Z(_0x532d81['_repo'],_0x532d81['_path']),_0x3b4b83));}['getEventRunner'](_0x51a10b){return _0x51a10b['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x51a10b['error']):()=>this['callbackContext']['onValue'](_0x51a10b['snapshot'],null);}['createCancelEvent'](_0x2e9d52,_0x2d0a36){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x2e9d52,_0x2d0a36):null;}['matches'](_0x440f40){return _0x440f40 instanceof qn?!_0x440f40['callbackContext']||!this['callbackContext']?!0x0:_0x440f40['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3c38d1,_0xcffe31,_0x319ed1,_0x11c2d4,_0x5b1721){const _0x975569=new ua(_0x319ed1,void 0x0),_0x2ad032=new qn(_0x975569);return Cd(_0x3c38d1['_repo'],_0x3c38d1,_0x2ad032),()=>Td(_0x3c38d1['_repo'],_0x3c38d1,_0x2ad032);}function Fd(_0x2ddece,_0x43763b,_0x176cdf,_0x3dbae0){return xd(_0x2ddece,'value',_0x43763b);}class dt{}class pa extends dt{constructor(_0x3ebf27,_0x5aa76a){super(),this['_value']=_0x3ebf27,this['_key']=_0x5aa76a,this['type']='endAt';}['_apply'](_0x3981b8){qt('endAt',this['_value'],_0x3981b8['_path'],!0x0);const _0x2ddf9a=Kh(_0x3981b8['_queryParams'],this['_value'],this['_key']);if(fa(_0x2ddf9a),Gn(_0x2ddf9a),_0x3981b8['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x3981b8['_repo'],_0x3981b8['_path'],_0x2ddf9a,_0x3981b8['_orderByCalled']);}}function __(_0x191dfc,_0x582399){return new pa(_0x191dfc,_0x582399);}class _a extends dt{constructor(_0x3d0d72,_0x3c7650){super(),this['_value']=_0x3d0d72,this['_key']=_0x3c7650,this['type']='startAt';}['_apply'](_0x1bbd2c){qt('startAt',this['_value'],_0x1bbd2c['_path'],!0x0);const _0x46c0f5=jh(_0x1bbd2c['_queryParams'],this['_value'],this['_key']);if(fa(_0x46c0f5),Gn(_0x46c0f5),_0x1bbd2c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1bbd2c['_repo'],_0x1bbd2c['_path'],_0x46c0f5,_0x1bbd2c['_orderByCalled']);}}function g_(_0x3c4202=null,_0x49e96c){return new _a(_0x3c4202,_0x49e96c);}class Ud extends dt{constructor(_0x118cdd){super(),this['_limit']=_0x118cdd,this['type']='limitToFirst';}['_apply'](_0x51fcb8){if(_0x51fcb8['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x51fcb8['_repo'],_0x51fcb8['_path'],zh(_0x51fcb8['_queryParams'],this['_limit']),_0x51fcb8['_orderByCalled']);}}function m_(_0xb23634){if(Math['floor'](_0xb23634)!==_0xb23634||_0xb23634<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0xb23634);}class Wd extends dt{constructor(_0x19f459){super(),this['_path']=_0x19f459,this['type']='orderByChild';}['_apply'](_0x2ff891){da(_0x2ff891,'orderByChild');const _0x1fea71=new C(this['_path']);if(v(_0x1fea71))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5cb8cc=new Ki(_0x1fea71),_0x47094b=Do(_0x2ff891['_queryParams'],_0x5cb8cc);return Gn(_0x47094b),new be(_0x2ff891['_repo'],_0x2ff891['_path'],_0x47094b,!0x0);}}function y_(_0x2d51df){if(_0x2d51df==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2d51df==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2d51df==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2d51df),new Wd(_0x2d51df);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2291f8){da(_0x2291f8,'orderByKey');const _0x166a72=Do(_0x2291f8['_queryParams'],ye);return Gn(_0x166a72),new be(_0x2291f8['_repo'],_0x2291f8['_path'],_0x166a72,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x55e392,_0x2ee7cc){super(),this['_value']=_0x55e392,this['_key']=_0x2ee7cc,this['type']='equalTo';}['_apply'](_0x431482){if(qt('equalTo',this['_value'],_0x431482['_path'],!0x1),_0x431482['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x431482['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x431482));}}function E_(_0x4468be,_0x4b87bf){return new Vd(_0x4468be,_0x4b87bf);}function I_(_0x25248a,..._0x1e2f66){let _0x4fbfbf=k(_0x25248a);for(const _0x2ba602 of _0x1e2f66)_0x4fbfbf=_0x2ba602['_apply'](_0x4fbfbf);return _0x4fbfbf;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x26d671,_0x130056,_0x384d16,_0xc3a51c){const _0x1f505f=_0x130056['lastIndexOf'](':'),_0x3e8e6a=_0x130056['substring'](0x0,_0x1f505f),_0x530433=Wt(_0x3e8e6a);_0x26d671['repoInfo_']=new _o(_0x130056,_0x530433,_0x26d671['repoInfo_']['namespace'],_0x26d671['repoInfo_']['webSocketOnly'],_0x26d671['repoInfo_']['nodeAdmin'],_0x26d671['repoInfo_']['persistenceKey'],_0x26d671['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x384d16),_0xc3a51c&&(_0x26d671['authTokenProvider_']=_0xc3a51c);}function qd(_0x7447f1,_0x667fd1,_0x3badef,_0x412d28,_0x3f885e){let _0x2205ca=_0x412d28||_0x7447f1['options']['databaseURL'];_0x2205ca===void 0x0&&(_0x7447f1['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x7447f1['options']['projectId']),_0x2205ca=_0x7447f1['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x33b2da=gr(_0x2205ca,_0x3f885e),_0x28917a=_0x33b2da['repoInfo'],_0xbba5e1;typeof process<'u'&&Us&&(_0xbba5e1=Us[Hd]),_0xbba5e1?(_0x2205ca='http://'+_0xbba5e1+'?ns='+_0x28917a['namespace'],_0x33b2da=gr(_0x2205ca,_0x3f885e),_0x28917a=_0x33b2da['repoInfo']):_0x33b2da['repoInfo']['secure'];const _0x56aaab=new Jl(_0x7447f1['name'],_0x7447f1['options'],_0x667fd1);dd('Invalid\x20Firebase\x20Database\x20URL',_0x33b2da),v(_0x33b2da['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5a552d=jd(_0x28917a,_0x7447f1,_0x56aaab,new Ql(_0x7447f1,_0x3badef));return new Kd(_0x5a552d,_0x7447f1);}function zd(_0x1e9d89,_0x5a09ef){const _0x54a38e=ki[_0x5a09ef];(!_0x54a38e||_0x54a38e[_0x1e9d89['key']]!==_0x1e9d89)&&oe('Database\x20'+_0x5a09ef+'('+_0x1e9d89['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x1e9d89),delete _0x54a38e[_0x1e9d89['key']];}function jd(_0x495f88,_0x4864f6,_0x1f4522,_0x5293d3){let _0x523d45=ki[_0x4864f6['name']];_0x523d45||(_0x523d45={},ki[_0x4864f6['name']]=_0x523d45);let _0x4de15f=_0x523d45[_0x495f88['toURLString']()];return _0x4de15f&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4de15f=new gd(_0x495f88,$d,_0x1f4522,_0x5293d3),_0x523d45[_0x495f88['toURLString']()]=_0x4de15f,_0x4de15f;}class Kd{constructor(_0x107ebf,_0x4b70ce){this['_repoInternal']=_0x107ebf,this['app']=_0x4b70ce,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5888ab){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5888ab+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x5a398b=Qr(),_0x10d4c2){const _0x3ef4fc=Ui(_0x5a398b,'database')['getImmediate']({'identifier':_0x10d4c2});if(!_0x3ef4fc['_instanceStarted']){const _0x4ef955=ac('database');_0x4ef955&&Yd(_0x3ef4fc,..._0x4ef955);}return _0x3ef4fc;}function Yd(_0x271036,_0xb4b117,_0x3e8bc8,_0x40eeb7={}){_0x271036=k(_0x271036),_0x271036['_checkNotDeleted']('useEmulator');const _0x44dcce=_0xb4b117+':'+_0x3e8bc8,_0x17076e=_0x271036['_repoInternal'];if(_0x271036['_instanceStarted']){if(_0x44dcce===_0x271036['_repoInternal']['repoInfo_']['host']&&De(_0x40eeb7,_0x17076e['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x59182e;if(_0x17076e['repoInfo_']['nodeAdmin'])_0x40eeb7['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x59182e=new tn(tn['OWNER']);else{if(_0x40eeb7['mockUserToken']){const _0x2e2a35=typeof _0x40eeb7['mockUserToken']=='string'?_0x40eeb7['mockUserToken']:cc(_0x40eeb7['mockUserToken'],_0x271036['app']['options']['projectId']);_0x59182e=new tn(_0x2e2a35);}}Wt(_0xb4b117)&&jr(_0xb4b117),Gd(_0x17076e,_0x44dcce,_0x40eeb7,_0x59182e);}function C_(_0xd0ea69){_0xd0ea69=k(_0xd0ea69),_0xd0ea69['_checkNotDeleted']('goOffline'),aa(_0xd0ea69['_repo']);}function T_(_0x2ea9ca){_0x2ea9ca=k(_0x2ea9ca),_0x2ea9ca['_checkNotDeleted']('goOnline'),Sd(_0x2ea9ca['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4cde35){Ll(ct),et(new Me('database',(_0x13e7fb,{instanceIdentifier:_0x11c96c})=>{const _0x26ea9c=_0x13e7fb['getProvider']('app')['getImmediate'](),_0x5b6018=_0x13e7fb['getProvider']('auth-internal'),_0x18756c=_0x13e7fb['getProvider']('app-check-internal');return qd(_0x26ea9c,_0x5b6018,_0x18756c,_0x11c96c);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4cde35),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1c6c65,_0xa4531a){this['committed']=_0x1c6c65,this['snapshot']=_0xa4531a;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3f3614,_0x1f1c92,_0x53fcc0){if(_0x3f3614=k(_0x3f3614),gs('Reference.transaction',_0x3f3614['_path']),_0x3f3614['key']==='.length'||_0x3f3614['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3f3614['key']+'\x20is\x20a\x20read-only\x20object.';const _0x66e84f=!0x0,_0x3c7d19=new Ve(),_0x52b506=(_0x484652,_0x362097,_0x57d5e0)=>{let _0x55859c=null;_0x484652?_0x3c7d19['reject'](_0x484652):(_0x55859c=new rt(_0x57d5e0,new Z(_0x3f3614['_repo'],_0x3f3614['_path']),R),_0x3c7d19['resolve'](new Xd(_0x362097,_0x55859c)));},_0xba8756=Fd(_0x3f3614,()=>{});return bd(_0x3f3614['_repo'],_0x3f3614['_path'],_0x1f1c92,_0x52b506,_0xba8756,_0x66e84f),_0x3c7d19['promise'];}ie['prototype']['simpleListen']=function(_0x1322e5,_0x3b3ea1){this['sendRequest']('q',{'p':_0x1322e5},_0x3b3ea1);},ie['prototype']['echo']=function(_0x1edcfb,_0x123c69){this['sendRequest']('echo',{'d':_0x1edcfb},_0x123c69);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x32994d,..._0x43667a){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x32994d,..._0x43667a);}function nn(_0x2e21f8,..._0x21cb3b){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2e21f8,..._0x21cb3b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x375649,..._0x1a1d63){throw Es(_0x375649,..._0x1a1d63);}function J(_0x597193,..._0x211ab6){return Es(_0x597193,..._0x211ab6);}function ya(_0x59fd24,_0x497b90,_0x37a592){const _0x511b0e={...Zd(),[_0x497b90]:_0x37a592};return new Ut('auth','Firebase',_0x511b0e)['create'](_0x497b90,{'appName':_0x59fd24['name']});}function se(_0x3d71fb){return ya(_0x3d71fb,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x210c80,..._0x852f10){if(typeof _0x210c80!='string'){const _0x3f20da=_0x852f10[0x0],_0xdf02d0=[..._0x852f10['slice'](0x1)];return _0xdf02d0[0x0]&&(_0xdf02d0[0x0]['appName']=_0x210c80['name']),_0x210c80['_errorFactory']['create'](_0x3f20da,..._0xdf02d0);}return ma['create'](_0x210c80,..._0x852f10);}function m(_0x3ce788,_0x12fa53,..._0x443dba){if(!_0x3ce788)throw Es(_0x12fa53,..._0x443dba);}function te(_0x1dbf3d){const _0x2b4950='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1dbf3d;throw nn(_0x2b4950),new Error(_0x2b4950);}function ae(_0x19dad6,_0x481569){_0x19dad6||te(_0x481569);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x2cb4f3;return typeof self<'u'&&((_0x2cb4f3=self['location'])==null?void 0x0:_0x2cb4f3['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x305ff0;return typeof self<'u'&&((_0x305ff0=self['location'])==null?void 0x0:_0x305ff0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x4c76ca=navigator;return _0x4c76ca['languages']&&_0x4c76ca['languages'][0x0]||_0x4c76ca['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x290ade,_0x538161){this['shortDelay']=_0x290ade,this['longDelay']=_0x538161,ae(_0x538161>_0x290ade,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0xd03eae,_0x917c59){ae(_0xd03eae['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4c487f}=_0xd03eae['emulator'];return _0x917c59?''+_0x4c487f+(_0x917c59['startsWith']('/')?_0x917c59['slice'](0x1):_0x917c59):_0x4c487f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x107bb6,_0x1dc266,_0x155554){this['fetchImpl']=_0x107bb6,_0x1dc266&&(this['headersImpl']=_0x1dc266),_0x155554&&(this['responseImpl']=_0x155554);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x58f19c,_0x4d39a7){return _0x58f19c['tenantId']&&!_0x4d39a7['tenantId']?{..._0x4d39a7,'tenantId':_0x58f19c['tenantId']}:_0x4d39a7;}async function Ae(_0x42fbb0,_0x3d13ef,_0x19474a,_0xbaf07e,_0x2e1643={}){return Ea(_0x42fbb0,_0x2e1643,async()=>{let _0x4e5a87={},_0x535e49={};_0xbaf07e&&(_0x3d13ef==='GET'?_0x535e49=_0xbaf07e:_0x4e5a87={'body':JSON['stringify'](_0xbaf07e)});const _0x41ae87=at({..._0x535e49,'key':_0x42fbb0['config']['apiKey']})['slice'](0x1),_0x9858b1=await _0x42fbb0['_getAdditionalHeaders']();_0x9858b1['Content-Type']='application/json',_0x42fbb0['languageCode']&&(_0x9858b1['X-Firebase-Locale']=_0x42fbb0['languageCode']);const _0x9f361d={'method':_0x3d13ef,'headers':_0x9858b1,..._0x4e5a87};return lc()||(_0x9f361d['referrerPolicy']='strict-origin-when-cross-origin'),_0x42fbb0['emulatorConfig']&&Wt(_0x42fbb0['emulatorConfig']['host'])&&(_0x9f361d['credentials']='include'),va['fetch']()(await Ia(_0x42fbb0,_0x42fbb0['config']['apiHost'],_0x19474a,_0x41ae87),_0x9f361d);});}async function Ea(_0x5805f3,_0xaa2e1d,_0x46ccdd){_0x5805f3['_canInitEmulator']=!0x1;const _0x2d36af={...rf,..._0xaa2e1d};try{const _0x572733=new lf(_0x5805f3),_0x57b607=await Promise['race']([_0x46ccdd(),_0x572733['promise']]);_0x572733['clearNetworkTimeout']();const _0x187309=await _0x57b607['json']();if('needConfirmation'in _0x187309)throw en(_0x5805f3,'account-exists-with-different-credential',_0x187309);if(_0x57b607['ok']&&!('errorMessage'in _0x187309))return _0x187309;{const _0x48a65f=_0x57b607['ok']?_0x187309['errorMessage']:_0x187309['error']['message'],[_0x1de251,_0x26d9f2]=_0x48a65f['split']('\x20:\x20');if(_0x1de251==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5805f3,'credential-already-in-use',_0x187309);if(_0x1de251==='EMAIL_EXISTS')throw en(_0x5805f3,'email-already-in-use',_0x187309);if(_0x1de251==='USER_DISABLED')throw en(_0x5805f3,'user-disabled',_0x187309);const _0x1ebf45=_0x2d36af[_0x1de251]||_0x1de251['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x26d9f2)throw ya(_0x5805f3,_0x1ebf45,_0x26d9f2);K(_0x5805f3,_0x1ebf45);}}catch(_0x3064bb){if(_0x3064bb instanceof Se)throw _0x3064bb;K(_0x5805f3,'network-request-failed',{'message':String(_0x3064bb)});}}async function Yt(_0x172a8b,_0x24df07,_0x4760d7,_0xe3c21c,_0x3e66fb={}){const _0x5a382b=await Ae(_0x172a8b,_0x24df07,_0x4760d7,_0xe3c21c,_0x3e66fb);return'mfaPendingCredential'in _0x5a382b&&K(_0x172a8b,'multi-factor-auth-required',{'_serverResponse':_0x5a382b}),_0x5a382b;}async function Ia(_0x4aa9e9,_0x440034,_0x5c8d7e,_0x1735d5){const _0x190150=''+_0x440034+_0x5c8d7e+'?'+_0x1735d5,_0x390f64=_0x4aa9e9,_0x4547ee=_0x390f64['config']['emulator']?Is(_0x4aa9e9['config'],_0x190150):_0x4aa9e9['config']['apiScheme']+'://'+_0x190150;return of['includes'](_0x5c8d7e)&&(await _0x390f64['_persistenceManagerAvailable'],_0x390f64['_getPersistenceType']()==='COOKIE')?_0x390f64['_getPersistence']()['_getFinalTarget'](_0x4547ee)['toString']():_0x4547ee;}function cf(_0x21315c){switch(_0x21315c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x24e9c6){this['auth']=_0x24e9c6,this['timer']=null,this['promise']=new Promise((_0x4e174d,_0x14b903)=>{this['timer']=setTimeout(()=>_0x14b903(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x2e34ab,_0x4b0d4a,_0x229273){const _0x4b1632={'appName':_0x2e34ab['name']};_0x229273['email']&&(_0x4b1632['email']=_0x229273['email']),_0x229273['phoneNumber']&&(_0x4b1632['phoneNumber']=_0x229273['phoneNumber']);const _0x532ecc=J(_0x2e34ab,_0x4b0d4a,_0x4b1632);return _0x532ecc['customData']['_tokenResponse']=_0x229273,_0x532ecc;}function vr(_0x1dd080){return _0x1dd080!==void 0x0&&_0x1dd080['enterprise']!==void 0x0;}class hf{constructor(_0x59a97b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x59a97b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x59a97b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x59a97b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5d3664){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4dfeeb of this['recaptchaEnforcementState'])if(_0x4dfeeb['provider']&&_0x4dfeeb['provider']===_0x5d3664)return cf(_0x4dfeeb['enforcementState']);return null;}['isProviderEnabled'](_0x3cb74a){return this['getProviderEnforcementState'](_0x3cb74a)==='ENFORCE'||this['getProviderEnforcementState'](_0x3cb74a)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x535441,_0x199d7f){return Ae(_0x535441,'GET','/v2/recaptchaConfig',Re(_0x535441,_0x199d7f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x5618eb,_0x47d627){return Ae(_0x5618eb,'POST','/v1/accounts:delete',_0x47d627);}async function Sn(_0x2b57d8,_0x1cfdb9){return Ae(_0x2b57d8,'POST','/v1/accounts:lookup',_0x1cfdb9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x597793){if(_0x597793)try{const _0x40b230=new Date(Number(_0x597793));if(!isNaN(_0x40b230['getTime']()))return _0x40b230['toUTCString']();}catch{}}async function ff(_0x59457a,_0x34e5c0=!0x1){const _0x352366=k(_0x59457a),_0x51c526=await _0x352366['getIdToken'](_0x34e5c0),_0x1a4fa0=ws(_0x51c526);m(_0x1a4fa0&&_0x1a4fa0['exp']&&_0x1a4fa0['auth_time']&&_0x1a4fa0['iat'],_0x352366['auth'],'internal-error');const _0x1ed43c=typeof _0x1a4fa0['firebase']=='object'?_0x1a4fa0['firebase']:void 0x0,_0x13e410=_0x1ed43c==null?void 0x0:_0x1ed43c['sign_in_provider'];return{'claims':_0x1a4fa0,'token':_0x51c526,'authTime':St(ci(_0x1a4fa0['auth_time'])),'issuedAtTime':St(ci(_0x1a4fa0['iat'])),'expirationTime':St(ci(_0x1a4fa0['exp'])),'signInProvider':_0x13e410||null,'signInSecondFactor':(_0x1ed43c==null?void 0x0:_0x1ed43c['sign_in_second_factor'])||null};}function ci(_0x17d089){return Number(_0x17d089)*0x3e8;}function ws(_0x277843){const [_0x59eb09,_0x365733,_0x6dc202]=_0x277843['split']('.');if(_0x59eb09===void 0x0||_0x365733===void 0x0||_0x6dc202===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x35de74=cn(_0x365733);return _0x35de74?JSON['parse'](_0x35de74):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3b257c){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3b257c==null?void 0x0:_0x3b257c['toString']()),null;}}function Er(_0x139f5b){const _0x29b6=ws(_0x139f5b);return m(_0x29b6,'internal-error'),m(typeof _0x29b6['exp']<'u','internal-error'),m(typeof _0x29b6['iat']<'u','internal-error'),Number(_0x29b6['exp'])-Number(_0x29b6['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x576ad2,_0x568351,_0xbcc88e=!0x1){if(_0xbcc88e)return _0x568351;try{return await _0x568351;}catch(_0x4a1af3){throw _0x4a1af3 instanceof Se&&pf(_0x4a1af3)&&_0x576ad2['auth']['currentUser']===_0x576ad2&&await _0x576ad2['auth']['signOut'](),_0x4a1af3;}}function pf({code:_0x5f1517}){return _0x5f1517==='auth/user-disabled'||_0x5f1517==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x238f4e){this['user']=_0x238f4e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5bed73){if(_0x5bed73){const _0x1f405f=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1f405f;}else{this['errorBackoff']=0x7530;const _0x2f595e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2f595e);}}['schedule'](_0x385fbc=!0x1){if(!this['isRunning'])return;const _0x254b4f=this['getInterval'](_0x385fbc);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x254b4f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3399b1){(_0x3399b1==null?void 0x0:_0x3399b1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x3f5f13,_0x405365){this['createdAt']=_0x3f5f13,this['lastLoginAt']=_0x405365,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4a98d7){this['createdAt']=_0x4a98d7['createdAt'],this['lastLoginAt']=_0x4a98d7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x2c1518){var _0x19569c;const _0x5c224b=_0x2c1518['auth'],_0x273b91=await _0x2c1518['getIdToken'](),_0x49268b=await xt(_0x2c1518,Sn(_0x5c224b,{'idToken':_0x273b91}));m(_0x49268b==null?void 0x0:_0x49268b['users']['length'],_0x5c224b,'internal-error');const _0x3b8749=_0x49268b['users'][0x0];_0x2c1518['_notifyReloadListener'](_0x3b8749);const _0x403e61=(_0x19569c=_0x3b8749['providerUserInfo'])!=null&&_0x19569c['length']?wa(_0x3b8749['providerUserInfo']):[],_0x584820=mf(_0x2c1518['providerData'],_0x403e61),_0x36a2b2=_0x2c1518['isAnonymous'],_0x4064e3=!(_0x2c1518['email']&&_0x3b8749['passwordHash'])&&!(_0x584820!=null&&_0x584820['length']),_0x406c7c=_0x36a2b2?_0x4064e3:!0x1,_0x120995={'uid':_0x3b8749['localId'],'displayName':_0x3b8749['displayName']||null,'photoURL':_0x3b8749['photoUrl']||null,'email':_0x3b8749['email']||null,'emailVerified':_0x3b8749['emailVerified']||!0x1,'phoneNumber':_0x3b8749['phoneNumber']||null,'tenantId':_0x3b8749['tenantId']||null,'providerData':_0x584820,'metadata':new Pi(_0x3b8749['createdAt'],_0x3b8749['lastLoginAt']),'isAnonymous':_0x406c7c};Object['assign'](_0x2c1518,_0x120995);}async function gf(_0x4d3274){const _0x40f932=k(_0x4d3274);await bn(_0x40f932),await _0x40f932['auth']['_persistUserIfCurrent'](_0x40f932),_0x40f932['auth']['_notifyListenersIfCurrent'](_0x40f932);}function mf(_0x31d1a7,_0x1e8f60){return[..._0x31d1a7['filter'](_0xc929ce=>!_0x1e8f60['some'](_0x316f40=>_0x316f40['providerId']===_0xc929ce['providerId'])),..._0x1e8f60];}function wa(_0x351841){return _0x351841['map'](({providerId:_0x82f037,..._0x2043f2})=>({'providerId':_0x82f037,'uid':_0x2043f2['rawId']||'','displayName':_0x2043f2['displayName']||null,'email':_0x2043f2['email']||null,'phoneNumber':_0x2043f2['phoneNumber']||null,'photoURL':_0x2043f2['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x413d7a,_0x3895f7){const _0x57d884=await Ea(_0x413d7a,{},async()=>{const _0x3ab754=at({'grant_type':'refresh_token','refresh_token':_0x3895f7})['slice'](0x1),{tokenApiHost:_0x26b74d,apiKey:_0x27a675}=_0x413d7a['config'],_0x1338b4=await Ia(_0x413d7a,_0x26b74d,'/v1/token','key='+_0x27a675),_0x59f709=await _0x413d7a['_getAdditionalHeaders']();_0x59f709['Content-Type']='application/x-www-form-urlencoded';const _0x2dcb8a={'method':'POST','headers':_0x59f709,'body':_0x3ab754};return _0x413d7a['emulatorConfig']&&Wt(_0x413d7a['emulatorConfig']['host'])&&(_0x2dcb8a['credentials']='include'),va['fetch']()(_0x1338b4,_0x2dcb8a);});return{'accessToken':_0x57d884['access_token'],'expiresIn':_0x57d884['expires_in'],'refreshToken':_0x57d884['refresh_token']};}async function vf(_0x149071,_0x3905aa){return Ae(_0x149071,'POST','/v2/accounts:revokeToken',Re(_0x149071,_0x3905aa));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2ef605){m(_0x2ef605['idToken'],'internal-error'),m(typeof _0x2ef605['idToken']<'u','internal-error'),m(typeof _0x2ef605['refreshToken']<'u','internal-error');const _0x451720='expiresIn'in _0x2ef605&&typeof _0x2ef605['expiresIn']<'u'?Number(_0x2ef605['expiresIn']):Er(_0x2ef605['idToken']);this['updateTokensAndExpiration'](_0x2ef605['idToken'],_0x2ef605['refreshToken'],_0x451720);}['updateFromIdToken'](_0x50b501){m(_0x50b501['length']!==0x0,'internal-error');const _0x3a1565=Er(_0x50b501);this['updateTokensAndExpiration'](_0x50b501,null,_0x3a1565);}async['getToken'](_0x123ab3,_0x33cc38=!0x1){return!_0x33cc38&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x123ab3,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x123ab3,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3054e9,_0x223d1e){const {accessToken:_0x1e7c5d,refreshToken:_0x5c6714,expiresIn:_0x4a8f2c}=await yf(_0x3054e9,_0x223d1e);this['updateTokensAndExpiration'](_0x1e7c5d,_0x5c6714,Number(_0x4a8f2c));}['updateTokensAndExpiration'](_0x4b4ecf,_0x50b167,_0x2af7c6){this['refreshToken']=_0x50b167||null,this['accessToken']=_0x4b4ecf||null,this['expirationTime']=Date['now']()+_0x2af7c6*0x3e8;}static['fromJSON'](_0x39ca85,_0x39aebc){const {refreshToken:_0x4a7471,accessToken:_0x43c14b,expirationTime:_0x1daf29}=_0x39aebc,_0x57a166=new Je();return _0x4a7471&&(m(typeof _0x4a7471=='string','internal-error',{'appName':_0x39ca85}),_0x57a166['refreshToken']=_0x4a7471),_0x43c14b&&(m(typeof _0x43c14b=='string','internal-error',{'appName':_0x39ca85}),_0x57a166['accessToken']=_0x43c14b),_0x1daf29&&(m(typeof _0x1daf29=='number','internal-error',{'appName':_0x39ca85}),_0x57a166['expirationTime']=_0x1daf29),_0x57a166;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4ae4d5){this['accessToken']=_0x4ae4d5['accessToken'],this['refreshToken']=_0x4ae4d5['refreshToken'],this['expirationTime']=_0x4ae4d5['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x54edca,_0x34505a){m(typeof _0x54edca=='string'||typeof _0x54edca>'u','internal-error',{'appName':_0x34505a});}class z{constructor({uid:_0x5bb917,auth:_0x1ac328,stsTokenManager:_0x3f77ac,..._0x205874}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5bb917,this['auth']=_0x1ac328,this['stsTokenManager']=_0x3f77ac,this['accessToken']=_0x3f77ac['accessToken'],this['displayName']=_0x205874['displayName']||null,this['email']=_0x205874['email']||null,this['emailVerified']=_0x205874['emailVerified']||!0x1,this['phoneNumber']=_0x205874['phoneNumber']||null,this['photoURL']=_0x205874['photoURL']||null,this['isAnonymous']=_0x205874['isAnonymous']||!0x1,this['tenantId']=_0x205874['tenantId']||null,this['providerData']=_0x205874['providerData']?[..._0x205874['providerData']]:[],this['metadata']=new Pi(_0x205874['createdAt']||void 0x0,_0x205874['lastLoginAt']||void 0x0);}async['getIdToken'](_0x599956){const _0x478953=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x599956));return m(_0x478953,this['auth'],'internal-error'),this['accessToken']!==_0x478953&&(this['accessToken']=_0x478953,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x478953;}['getIdTokenResult'](_0x313177){return ff(this,_0x313177);}['reload'](){return gf(this);}['_assign'](_0x2ea519){this!==_0x2ea519&&(m(this['uid']===_0x2ea519['uid'],this['auth'],'internal-error'),this['displayName']=_0x2ea519['displayName'],this['photoURL']=_0x2ea519['photoURL'],this['email']=_0x2ea519['email'],this['emailVerified']=_0x2ea519['emailVerified'],this['phoneNumber']=_0x2ea519['phoneNumber'],this['isAnonymous']=_0x2ea519['isAnonymous'],this['tenantId']=_0x2ea519['tenantId'],this['providerData']=_0x2ea519['providerData']['map'](_0x4962ec=>({..._0x4962ec})),this['metadata']['_copy'](_0x2ea519['metadata']),this['stsTokenManager']['_assign'](_0x2ea519['stsTokenManager']));}['_clone'](_0x1d099e){const _0x49d497=new z({...this,'auth':_0x1d099e,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x49d497['metadata']['_copy'](this['metadata']),_0x49d497;}['_onReload'](_0x2d29f8){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2d29f8,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4fa172){this['reloadListener']?this['reloadListener'](_0x4fa172):this['reloadUserInfo']=_0x4fa172;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x122221,_0x228ceb=!0x1){let _0x484196=!0x1;_0x122221['idToken']&&_0x122221['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x122221),_0x484196=!0x0),_0x228ceb&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x484196&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x130297=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x130297})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x51c4f0=>({..._0x51c4f0})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x68da8d,_0xcb54dd){const _0x3e5e13=_0xcb54dd['displayName']??void 0x0,_0xc62c8f=_0xcb54dd['email']??void 0x0,_0x1f2d13=_0xcb54dd['phoneNumber']??void 0x0,_0x1b3e41=_0xcb54dd['photoURL']??void 0x0,_0x10bc85=_0xcb54dd['tenantId']??void 0x0,_0x3f4069=_0xcb54dd['_redirectEventId']??void 0x0,_0x2bf75f=_0xcb54dd['createdAt']??void 0x0,_0x274ec5=_0xcb54dd['lastLoginAt']??void 0x0,{uid:_0x4f5bf1,emailVerified:_0x35b99f,isAnonymous:_0x157ef5,providerData:_0x43a89c,stsTokenManager:_0xf36329}=_0xcb54dd;m(_0x4f5bf1&&_0xf36329,_0x68da8d,'internal-error');const _0x48c616=Je['fromJSON'](this['name'],_0xf36329);m(typeof _0x4f5bf1=='string',_0x68da8d,'internal-error'),ce(_0x3e5e13,_0x68da8d['name']),ce(_0xc62c8f,_0x68da8d['name']),m(typeof _0x35b99f=='boolean',_0x68da8d,'internal-error'),m(typeof _0x157ef5=='boolean',_0x68da8d,'internal-error'),ce(_0x1f2d13,_0x68da8d['name']),ce(_0x1b3e41,_0x68da8d['name']),ce(_0x10bc85,_0x68da8d['name']),ce(_0x3f4069,_0x68da8d['name']),ce(_0x2bf75f,_0x68da8d['name']),ce(_0x274ec5,_0x68da8d['name']);const _0xc4da30=new z({'uid':_0x4f5bf1,'auth':_0x68da8d,'email':_0xc62c8f,'emailVerified':_0x35b99f,'displayName':_0x3e5e13,'isAnonymous':_0x157ef5,'photoURL':_0x1b3e41,'phoneNumber':_0x1f2d13,'tenantId':_0x10bc85,'stsTokenManager':_0x48c616,'createdAt':_0x2bf75f,'lastLoginAt':_0x274ec5});return _0x43a89c&&Array['isArray'](_0x43a89c)&&(_0xc4da30['providerData']=_0x43a89c['map'](_0x1b510c=>({..._0x1b510c}))),_0x3f4069&&(_0xc4da30['_redirectEventId']=_0x3f4069),_0xc4da30;}static async['_fromIdTokenResponse'](_0x2f3573,_0x3a00dd,_0x41054f=!0x1){const _0x5f5a14=new Je();_0x5f5a14['updateFromServerResponse'](_0x3a00dd);const _0x503564=new z({'uid':_0x3a00dd['localId'],'auth':_0x2f3573,'stsTokenManager':_0x5f5a14,'isAnonymous':_0x41054f});return await bn(_0x503564),_0x503564;}static async['_fromGetAccountInfoResponse'](_0xd59a09,_0x452bcc,_0x15f111){const _0x5ea8c5=_0x452bcc['users'][0x0];m(_0x5ea8c5['localId']!==void 0x0,'internal-error');const _0x13e100=_0x5ea8c5['providerUserInfo']!==void 0x0?wa(_0x5ea8c5['providerUserInfo']):[],_0x408f4e=!(_0x5ea8c5['email']&&_0x5ea8c5['passwordHash'])&&!(_0x13e100!=null&&_0x13e100['length']),_0x31cf11=new Je();_0x31cf11['updateFromIdToken'](_0x15f111);const _0x2df64f=new z({'uid':_0x5ea8c5['localId'],'auth':_0xd59a09,'stsTokenManager':_0x31cf11,'isAnonymous':_0x408f4e}),_0xe94389={'uid':_0x5ea8c5['localId'],'displayName':_0x5ea8c5['displayName']||null,'photoURL':_0x5ea8c5['photoUrl']||null,'email':_0x5ea8c5['email']||null,'emailVerified':_0x5ea8c5['emailVerified']||!0x1,'phoneNumber':_0x5ea8c5['phoneNumber']||null,'tenantId':_0x5ea8c5['tenantId']||null,'providerData':_0x13e100,'metadata':new Pi(_0x5ea8c5['createdAt'],_0x5ea8c5['lastLoginAt']),'isAnonymous':!(_0x5ea8c5['email']&&_0x5ea8c5['passwordHash'])&&!(_0x13e100!=null&&_0x13e100['length'])};return Object['assign'](_0x2df64f,_0xe94389),_0x2df64f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x4d6fae){ae(_0x4d6fae instanceof Function,'Expected\x20a\x20class\x20definition');let _0x8ea45a=Ir['get'](_0x4d6fae);return _0x8ea45a?(ae(_0x8ea45a instanceof _0x4d6fae,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x8ea45a):(_0x8ea45a=new _0x4d6fae(),Ir['set'](_0x4d6fae,_0x8ea45a),_0x8ea45a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4a132e,_0x327507){this['storage'][_0x4a132e]=_0x327507;}async['_get'](_0x5e6ffa){const _0x560c19=this['storage'][_0x5e6ffa];return _0x560c19===void 0x0?null:_0x560c19;}async['_remove'](_0x441c69){delete this['storage'][_0x441c69];}['_addListener'](_0x2ce9ea,_0x4880c4){}['_removeListener'](_0x40e4b9,_0x4fd33d){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3fbe30,_0x111841,_0x1d3769){return'firebase:'+_0x3fbe30+':'+_0x111841+':'+_0x1d3769;}class Xe{constructor(_0x4e5619,_0xf348b6,_0x19fdf2){this['persistence']=_0x4e5619,this['auth']=_0xf348b6,this['userKey']=_0x19fdf2;const {config:_0xfe5886,name:_0x1328fb}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0xfe5886['apiKey'],_0x1328fb),this['fullPersistenceKey']=sn('persistence',_0xfe5886['apiKey'],_0x1328fb),this['boundEventHandler']=_0xf348b6['_onStorageEvent']['bind'](_0xf348b6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xf76643){return this['persistence']['_set'](this['fullUserKey'],_0xf76643['toJSON']());}async['getCurrentUser'](){const _0x1d7767=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1d7767)return null;if(typeof _0x1d7767=='string'){const _0x15bbf9=await Sn(this['auth'],{'idToken':_0x1d7767})['catch'](()=>{});return _0x15bbf9?z['_fromGetAccountInfoResponse'](this['auth'],_0x15bbf9,_0x1d7767):null;}return z['_fromJSON'](this['auth'],_0x1d7767);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5e3079){if(this['persistence']===_0x5e3079)return;const _0x45d9d6=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5e3079,_0x45d9d6)return this['setCurrentUser'](_0x45d9d6);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xec4d0,_0x3106c0,_0x20b4a1='authUser'){if(!_0x3106c0['length'])return new Xe(ne(wr),_0xec4d0,_0x20b4a1);const _0x42344c=(await Promise['all'](_0x3106c0['map'](async _0x571fe9=>{if(await _0x571fe9['_isAvailable']())return _0x571fe9;})))['filter'](_0x48c1ec=>_0x48c1ec);let _0x35056c=_0x42344c[0x0]||ne(wr);const _0x118c7f=sn(_0x20b4a1,_0xec4d0['config']['apiKey'],_0xec4d0['name']);let _0x5a1d5f=null;for(const _0x191925 of _0x3106c0)try{const _0x5aa44c=await _0x191925['_get'](_0x118c7f);if(_0x5aa44c){let _0x13d73f;if(typeof _0x5aa44c=='string'){const _0x8b7736=await Sn(_0xec4d0,{'idToken':_0x5aa44c})['catch'](()=>{});if(!_0x8b7736)break;_0x13d73f=await z['_fromGetAccountInfoResponse'](_0xec4d0,_0x8b7736,_0x5aa44c);}else _0x13d73f=z['_fromJSON'](_0xec4d0,_0x5aa44c);_0x191925!==_0x35056c&&(_0x5a1d5f=_0x13d73f),_0x35056c=_0x191925;break;}}catch{}const _0x402ce2=_0x42344c['filter'](_0x47ba48=>_0x47ba48['_shouldAllowMigration']);return!_0x35056c['_shouldAllowMigration']||!_0x402ce2['length']?new Xe(_0x35056c,_0xec4d0,_0x20b4a1):(_0x35056c=_0x402ce2[0x0],_0x5a1d5f&&await _0x35056c['_set'](_0x118c7f,_0x5a1d5f['toJSON']()),await Promise['all'](_0x3106c0['map'](async _0x50430e=>{if(_0x50430e!==_0x35056c)try{await _0x50430e['_remove'](_0x118c7f);}catch{}})),new Xe(_0x35056c,_0xec4d0,_0x20b4a1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x12ce0c){const _0x15db23=_0x12ce0c['toLowerCase']();if(_0x15db23['includes']('opera/')||_0x15db23['includes']('opr/')||_0x15db23['includes']('opios/'))return'Opera';if(Ra(_0x15db23))return'IEMobile';if(_0x15db23['includes']('msie')||_0x15db23['includes']('trident/'))return'IE';if(_0x15db23['includes']('edge/'))return'Edge';if(Ta(_0x15db23))return'Firefox';if(_0x15db23['includes']('silk/'))return'Silk';if(ka(_0x15db23))return'Blackberry';if(Na(_0x15db23))return'Webos';if(Sa(_0x15db23))return'Safari';if((_0x15db23['includes']('chrome/')||ba(_0x15db23))&&!_0x15db23['includes']('edge/'))return'Chrome';if(Aa(_0x15db23))return'Android';{const _0x136391=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x15b6a6=_0x12ce0c['match'](_0x136391);if((_0x15b6a6==null?void 0x0:_0x15b6a6['length'])===0x2)return _0x15b6a6[0x1];}return'Other';}function Ta(_0xded8d6=W()){return/firefox\//i['test'](_0xded8d6);}function Sa(_0x36225c=W()){const _0x4facfe=_0x36225c['toLowerCase']();return _0x4facfe['includes']('safari/')&&!_0x4facfe['includes']('chrome/')&&!_0x4facfe['includes']('crios/')&&!_0x4facfe['includes']('android');}function ba(_0x3337da=W()){return/crios\//i['test'](_0x3337da);}function Ra(_0x234bc3=W()){return/iemobile/i['test'](_0x234bc3);}function Aa(_0x5c5a4e=W()){return/android/i['test'](_0x5c5a4e);}function ka(_0x104cf9=W()){return/blackberry/i['test'](_0x104cf9);}function Na(_0x39e7be=W()){return/webos/i['test'](_0x39e7be);}function Cs(_0x19fcf4=W()){return/iphone|ipad|ipod/i['test'](_0x19fcf4)||/macintosh/i['test'](_0x19fcf4)&&/mobile/i['test'](_0x19fcf4);}function Ef(_0x4d24d0=W()){var _0x377782;return Cs(_0x4d24d0)&&!!((_0x377782=window['navigator'])!=null&&_0x377782['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4b2404=W()){return Cs(_0x4b2404)||Aa(_0x4b2404)||Na(_0x4b2404)||ka(_0x4b2404)||/windows phone/i['test'](_0x4b2404)||Ra(_0x4b2404);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x3c68ed,_0xbf292a=[]){let _0x5dd6d6;switch(_0x3c68ed){case'Browser':_0x5dd6d6=Cr(W());break;case'Worker':_0x5dd6d6=Cr(W())+'-'+_0x3c68ed;break;default:_0x5dd6d6=_0x3c68ed;}const _0x4fd50a=_0xbf292a['length']?_0xbf292a['join'](','):'FirebaseCore-web';return _0x5dd6d6+'/JsCore/'+ct+'/'+_0x4fd50a;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x285536){this['auth']=_0x285536,this['queue']=[];}['pushCallback'](_0x281f07,_0x5b2e4e){const _0x4787d0=_0x212ffe=>new Promise((_0x5109a7,_0x9ac3bf)=>{try{const _0x2c7df1=_0x281f07(_0x212ffe);_0x5109a7(_0x2c7df1);}catch(_0x4dcce8){_0x9ac3bf(_0x4dcce8);}});_0x4787d0['onAbort']=_0x5b2e4e,this['queue']['push'](_0x4787d0);const _0xb9e1d5=this['queue']['length']-0x1;return()=>{this['queue'][_0xb9e1d5]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5dacb2){if(this['auth']['currentUser']===_0x5dacb2)return;const _0x16d4cb=[];try{for(const _0x5a1a48 of this['queue'])await _0x5a1a48(_0x5dacb2),_0x5a1a48['onAbort']&&_0x16d4cb['push'](_0x5a1a48['onAbort']);}catch(_0x362000){_0x16d4cb['reverse']();for(const _0x1b2de2 of _0x16d4cb)try{_0x1b2de2();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x362000==null?void 0x0:_0x362000['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x3dccbf,_0x564ce6={}){return Ae(_0x3dccbf,'GET','/v2/passwordPolicy',Re(_0x3dccbf,_0x564ce6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x1c1b17){var _0x2dc56a;const _0x4cb7dd=_0x1c1b17['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4cb7dd['minPasswordLength']??Tf,_0x4cb7dd['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4cb7dd['maxPasswordLength']),_0x4cb7dd['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4cb7dd['containsLowercaseCharacter']),_0x4cb7dd['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4cb7dd['containsUppercaseCharacter']),_0x4cb7dd['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4cb7dd['containsNumericCharacter']),_0x4cb7dd['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4cb7dd['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1c1b17['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2dc56a=_0x1c1b17['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2dc56a['join'](''))??'',this['forceUpgradeOnSignin']=_0x1c1b17['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1c1b17['schemaVersion'];}['validatePassword'](_0x3c26d6){const _0x47044c={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x3c26d6,_0x47044c),this['validatePasswordCharacterOptions'](_0x3c26d6,_0x47044c),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['meetsMinPasswordLength']??!0x0),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['meetsMaxPasswordLength']??!0x0),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['containsLowercaseLetter']??!0x0),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['containsUppercaseLetter']??!0x0),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['containsNumericCharacter']??!0x0),_0x47044c['isValid']&&(_0x47044c['isValid']=_0x47044c['containsNonAlphanumericCharacter']??!0x0),_0x47044c;}['validatePasswordLengthOptions'](_0x473bc6,_0x3ca352){const _0x11c4da=this['customStrengthOptions']['minPasswordLength'],_0x201560=this['customStrengthOptions']['maxPasswordLength'];_0x11c4da&&(_0x3ca352['meetsMinPasswordLength']=_0x473bc6['length']>=_0x11c4da),_0x201560&&(_0x3ca352['meetsMaxPasswordLength']=_0x473bc6['length']<=_0x201560);}['validatePasswordCharacterOptions'](_0x270f00,_0x35e866){this['updatePasswordCharacterOptionsStatuses'](_0x35e866,!0x1,!0x1,!0x1,!0x1);let _0x1fd57b;for(let _0x3a40c9=0x0;_0x3a40c9<_0x270f00['length'];_0x3a40c9++)_0x1fd57b=_0x270f00['charAt'](_0x3a40c9),this['updatePasswordCharacterOptionsStatuses'](_0x35e866,_0x1fd57b>='a'&&_0x1fd57b<='z',_0x1fd57b>='A'&&_0x1fd57b<='Z',_0x1fd57b>='0'&&_0x1fd57b<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1fd57b));}['updatePasswordCharacterOptionsStatuses'](_0x22b8e5,_0x51dc6d,_0x2d3367,_0x22fe46,_0x50d263){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x22b8e5['containsLowercaseLetter']||(_0x22b8e5['containsLowercaseLetter']=_0x51dc6d)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x22b8e5['containsUppercaseLetter']||(_0x22b8e5['containsUppercaseLetter']=_0x2d3367)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x22b8e5['containsNumericCharacter']||(_0x22b8e5['containsNumericCharacter']=_0x22fe46)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x22b8e5['containsNonAlphanumericCharacter']||(_0x22b8e5['containsNonAlphanumericCharacter']=_0x50d263));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x9b9c23,_0x32a2dd,_0x1c0f70,_0x1e4dce){this['app']=_0x9b9c23,this['heartbeatServiceProvider']=_0x32a2dd,this['appCheckServiceProvider']=_0x1c0f70,this['config']=_0x1e4dce,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x9b9c23['name'],this['clientVersion']=_0x1e4dce['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2e0e52=>this['_resolvePersistenceManagerAvailable']=_0x2e0e52);}['_initializeWithPersistence'](_0x44acb4,_0x2eed81){return _0x2eed81&&(this['_popupRedirectResolver']=ne(_0x2eed81)),this['_initializationPromise']=this['queue'](async()=>{var _0x3c13ef,_0x94219,_0x300d83;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x44acb4),(_0x3c13ef=this['_resolvePersistenceManagerAvailable'])==null||_0x3c13ef['call'](this),!this['_deleted'])){if((_0x94219=this['_popupRedirectResolver'])!=null&&_0x94219['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2eed81),this['lastNotifiedUid']=((_0x300d83=this['currentUser'])==null?void 0x0:_0x300d83['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x48fe7d=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x48fe7d)){if(this['currentUser']&&_0x48fe7d&&this['currentUser']['uid']===_0x48fe7d['uid']){this['_currentUser']['_assign'](_0x48fe7d),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x48fe7d,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x56c3c3){try{const _0x84ab4b=await Sn(this,{'idToken':_0x56c3c3}),_0x2fe9f6=await z['_fromGetAccountInfoResponse'](this,_0x84ab4b,_0x56c3c3);await this['directlySetCurrentUser'](_0x2fe9f6);}catch(_0x1ceb15){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1ceb15),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2e0eb5){var _0x5aa40c;if(H(this['app'])){const _0x2d7e0e=this['app']['settings']['authIdToken'];return _0x2d7e0e?new Promise(_0x448469=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2d7e0e)['then'](_0x448469,_0x448469));}):this['directlySetCurrentUser'](null);}const _0x935101=await this['assertedPersistence']['getCurrentUser']();let _0x40c5a6=_0x935101,_0x8742f6=!0x1;if(_0x2e0eb5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3c4103=(_0x5aa40c=this['redirectUser'])==null?void 0x0:_0x5aa40c['_redirectEventId'],_0x593b5b=_0x40c5a6==null?void 0x0:_0x40c5a6['_redirectEventId'],_0x3e9565=await this['tryRedirectSignIn'](_0x2e0eb5);(!_0x3c4103||_0x3c4103===_0x593b5b)&&(_0x3e9565!=null&&_0x3e9565['user'])&&(_0x40c5a6=_0x3e9565['user'],_0x8742f6=!0x0);}if(!_0x40c5a6)return this['directlySetCurrentUser'](null);if(!_0x40c5a6['_redirectEventId']){if(_0x8742f6)try{await this['beforeStateQueue']['runMiddleware'](_0x40c5a6);}catch(_0x572154){_0x40c5a6=_0x935101,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x572154));}return _0x40c5a6?this['reloadAndSetCurrentUserOrClear'](_0x40c5a6):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x40c5a6['_redirectEventId']?this['directlySetCurrentUser'](_0x40c5a6):this['reloadAndSetCurrentUserOrClear'](_0x40c5a6);}async['tryRedirectSignIn'](_0x388f70){let _0x5108c4=null;try{_0x5108c4=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x388f70,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5108c4;}async['reloadAndSetCurrentUserOrClear'](_0x15323c){try{await bn(_0x15323c);}catch(_0x18afae){if((_0x18afae==null?void 0x0:_0x18afae['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x15323c);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x431f7e){if(H(this['app']))return Promise['reject'](se(this));const _0x4bf9c4=_0x431f7e?k(_0x431f7e):null;return _0x4bf9c4&&m(_0x4bf9c4['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4bf9c4&&_0x4bf9c4['_clone'](this));}async['_updateCurrentUser'](_0x9a909,_0x123072=!0x1){if(!this['_deleted'])return _0x9a909&&m(this['tenantId']===_0x9a909['tenantId'],this,'tenant-id-mismatch'),_0x123072||await this['beforeStateQueue']['runMiddleware'](_0x9a909),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x9a909),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xbcf98f){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xbcf98f));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5c9fe0){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x17599b=this['_getPasswordPolicyInternal']();return _0x17599b['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x17599b['validatePassword'](_0x5c9fe0);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2c5626=await Cf(this),_0x1cc69c=new Sf(_0x2c5626);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1cc69c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1cc69c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2fbb9b){this['_errorFactory']=new Ut('auth','Firebase',_0x2fbb9b());}['onAuthStateChanged'](_0x362d3a,_0x586756,_0x41ffcf){return this['registerStateListener'](this['authStateSubscription'],_0x362d3a,_0x586756,_0x41ffcf);}['beforeAuthStateChanged'](_0x33b33d,_0x58932f){return this['beforeStateQueue']['pushCallback'](_0x33b33d,_0x58932f);}['onIdTokenChanged'](_0xf35c78,_0xa3e30f,_0x3aa0fa){return this['registerStateListener'](this['idTokenSubscription'],_0xf35c78,_0xa3e30f,_0x3aa0fa);}['authStateReady'](){return new Promise((_0x3c998b,_0x408470)=>{if(this['currentUser'])_0x3c998b();else{const _0x2859d0=this['onAuthStateChanged'](()=>{_0x2859d0(),_0x3c998b();},_0x408470);}});}async['revokeAccessToken'](_0x57135b){if(this['currentUser']){const _0x5c7002=await this['currentUser']['getIdToken'](),_0x2dd346={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x57135b,'idToken':_0x5c7002};this['tenantId']!=null&&(_0x2dd346['tenantId']=this['tenantId']),await vf(this,_0x2dd346);}}['toJSON'](){var _0x439174;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x439174=this['_currentUser'])==null?void 0x0:_0x439174['toJSON']()};}async['_setRedirectUser'](_0x5177bb,_0x19c28a){const _0x4e2634=await this['getOrInitRedirectPersistenceManager'](_0x19c28a);return _0x5177bb===null?_0x4e2634['removeCurrentUser']():_0x4e2634['setCurrentUser'](_0x5177bb);}async['getOrInitRedirectPersistenceManager'](_0x44e1b6){if(!this['redirectPersistenceManager']){const _0x1edd8e=_0x44e1b6&&ne(_0x44e1b6)||this['_popupRedirectResolver'];m(_0x1edd8e,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x1edd8e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xb37755){var _0x44bcd8,_0x5a1ce7;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x44bcd8=this['_currentUser'])==null?void 0x0:_0x44bcd8['_redirectEventId'])===_0xb37755?this['_currentUser']:((_0x5a1ce7=this['redirectUser'])==null?void 0x0:_0x5a1ce7['_redirectEventId'])===_0xb37755?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2f486a){if(_0x2f486a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2f486a));}['_notifyListenersIfCurrent'](_0x3c2176){_0x3c2176===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1f8cac;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1c2799=((_0x1f8cac=this['currentUser'])==null?void 0x0:_0x1f8cac['uid'])??null;this['lastNotifiedUid']!==_0x1c2799&&(this['lastNotifiedUid']=_0x1c2799,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x25ab6b,_0x40f831,_0x28ab6b,_0x4b163c){if(this['_deleted'])return()=>{};const _0x353547=typeof _0x40f831=='function'?_0x40f831:_0x40f831['next']['bind'](_0x40f831);let _0xe4095a=!0x1;const _0x429579=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x429579,this,'internal-error'),_0x429579['then'](()=>{_0xe4095a||_0x353547(this['currentUser']);}),typeof _0x40f831=='function'){const _0x190704=_0x25ab6b['addObserver'](_0x40f831,_0x28ab6b,_0x4b163c);return()=>{_0xe4095a=!0x0,_0x190704();};}else{const _0x4805b4=_0x25ab6b['addObserver'](_0x40f831);return()=>{_0xe4095a=!0x0,_0x4805b4();};}}async['directlySetCurrentUser'](_0x1cc00e){this['currentUser']&&this['currentUser']!==_0x1cc00e&&this['_currentUser']['_stopProactiveRefresh'](),_0x1cc00e&&this['isProactiveRefreshEnabled']&&_0x1cc00e['_startProactiveRefresh'](),this['currentUser']=_0x1cc00e,_0x1cc00e?await this['assertedPersistence']['setCurrentUser'](_0x1cc00e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x45f6b4){return this['operations']=this['operations']['then'](_0x45f6b4,_0x45f6b4),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x58f9d3){!_0x58f9d3||this['frameworks']['includes'](_0x58f9d3)||(this['frameworks']['push'](_0x58f9d3),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2cb4a1;const _0x20be87={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x20be87['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x390dfe=await((_0x2cb4a1=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2cb4a1['getHeartbeatsHeader']());_0x390dfe&&(_0x20be87['X-Firebase-Client']=_0x390dfe);const _0x5243=await this['_getAppCheckToken']();return _0x5243&&(_0x20be87['X-Firebase-AppCheck']=_0x5243),_0x20be87;}async['_getAppCheckToken'](){var _0x4c2ddd;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x38ef35=await((_0x4c2ddd=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4c2ddd['getToken']());return _0x38ef35!=null&&_0x38ef35['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x38ef35['error']),_0x38ef35==null?void 0x0:_0x38ef35['token'];}}function qe(_0x1bc5f9){return k(_0x1bc5f9);}class Tr{constructor(_0x26d131){this['auth']=_0x26d131,this['observer']=null,this['addObserver']=Ic(_0x47e0e6=>this['observer']=_0x47e0e6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x16d151){zn=_0x16d151;}function Da(_0x373d3c){return zn['loadJS'](_0x373d3c);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x53306a){return'__'+_0x53306a+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x350c3d){_0x350c3d();}['execute'](_0x19c3f3,_0x2ee457){return Promise['resolve']('token');}['render'](_0x12f806,_0x5eeb0f){return'';}}class Of{['ready'](_0x3cd800){_0x3cd800();}['execute'](_0x6ccf5a,_0x57ff98){return Promise['resolve']('token');}['render'](_0x15e2fb,_0x3c0a09){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5e3861){this['type']=Df,this['auth']=qe(_0x5e3861);}async['verify'](_0x525797='verify',_0x7757e3=!0x1){async function _0x545154(_0x458eaa){if(!_0x7757e3){if(_0x458eaa['tenantId']==null&&_0x458eaa['_agentRecaptchaConfig']!=null)return _0x458eaa['_agentRecaptchaConfig']['siteKey'];if(_0x458eaa['tenantId']!=null&&_0x458eaa['_tenantRecaptchaConfigs'][_0x458eaa['tenantId']]!==void 0x0)return _0x458eaa['_tenantRecaptchaConfigs'][_0x458eaa['tenantId']]['siteKey'];}return new Promise(async(_0x51e1ec,_0x3476c4)=>{uf(_0x458eaa,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x45b157=>{if(_0x45b157['recaptchaKey']===void 0x0)_0x3476c4(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2f080f=new hf(_0x45b157);return _0x458eaa['tenantId']==null?_0x458eaa['_agentRecaptchaConfig']=_0x2f080f:_0x458eaa['_tenantRecaptchaConfigs'][_0x458eaa['tenantId']]=_0x2f080f,_0x51e1ec(_0x2f080f['siteKey']);}})['catch'](_0x1c4f86=>{_0x3476c4(_0x1c4f86);});});}function _0x5086d9(_0x17ecfa,_0x3285bb,_0x7701a1){const _0xd937ec=window['grecaptcha'];vr(_0xd937ec)?_0xd937ec['enterprise']['ready'](()=>{_0xd937ec['enterprise']['execute'](_0x17ecfa,{'action':_0x525797})['then'](_0x15dd8f=>{_0x3285bb(_0x15dd8f);})['catch'](()=>{_0x3285bb(Ma);});}):_0x7701a1(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x31d66c,_0x532cc9)=>{_0x545154(this['auth'])['then'](async _0x55908d=>{if(!_0x7757e3&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5086d9(_0x55908d,_0x31d66c,_0x532cc9);else{if(typeof window>'u'){_0x532cc9(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2f9767=Af();_0x2f9767['length']!==0x0&&(_0x2f9767+=_0x55908d+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x30ca47;(_0x30ca47=le['scriptInjectionDeferred'])==null||_0x30ca47['resolve']();},Da(_0x2f9767)['then'](()=>{var _0x59c328;return(_0x59c328=le['scriptInjectionDeferred'])==null?void 0x0:_0x59c328['promise'];})['then'](()=>{_0x5086d9(_0x55908d,_0x31d66c,_0x532cc9);})['catch'](_0x5389e4=>{_0x532cc9(_0x5389e4);});}})['catch'](_0x38ae44=>{_0x532cc9(_0x38ae44);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1ba3f0,_0x5a9492,_0x1bb364,_0x558709=!0x1,_0x1a9725=!0x1){const _0x4196c0=new le(_0x1ba3f0);let _0x139b00;if(_0x1a9725)_0x139b00=Ma;else try{_0x139b00=await _0x4196c0['verify'](_0x1bb364);}catch{_0x139b00=await _0x4196c0['verify'](_0x1bb364,!0x0);}const _0x2ec9af={..._0x5a9492};if(_0x1bb364==='mfaSmsEnrollment'||_0x1bb364==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2ec9af){const _0x58b3cb=_0x2ec9af['phoneEnrollmentInfo']['phoneNumber'],_0x21710b=_0x2ec9af['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2ec9af,{'phoneEnrollmentInfo':{'phoneNumber':_0x58b3cb,'recaptchaToken':_0x21710b,'captchaResponse':_0x139b00,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2ec9af){const _0x36d9b4=_0x2ec9af['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2ec9af,{'phoneSignInInfo':{'recaptchaToken':_0x36d9b4,'captchaResponse':_0x139b00,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2ec9af;}return _0x558709?Object['assign'](_0x2ec9af,{'captchaResp':_0x139b00}):Object['assign'](_0x2ec9af,{'captchaResponse':_0x139b00}),Object['assign'](_0x2ec9af,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2ec9af,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2ec9af;}async function Oi(_0x941b62,_0x1337c8,_0x5ad1cc,_0xaee485,_0xa7fc86){var _0x579b12;if((_0x579b12=_0x941b62['_getRecaptchaConfig']())!=null&&_0x579b12['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x37cbd1=await br(_0x941b62,_0x1337c8,_0x5ad1cc,_0x5ad1cc==='getOobCode');return _0xaee485(_0x941b62,_0x37cbd1);}else return _0xaee485(_0x941b62,_0x1337c8)['catch'](async _0x28c00b=>{if(_0x28c00b['code']==='auth/missing-recaptcha-token'){console['log'](_0x5ad1cc+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xa92670=await br(_0x941b62,_0x1337c8,_0x5ad1cc,_0x5ad1cc==='getOobCode');return _0xaee485(_0x941b62,_0xa92670);}else return Promise['reject'](_0x28c00b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5f2e99,_0x4e2123){const _0x47990f=Ui(_0x5f2e99,'auth');if(_0x47990f['isInitialized']()){const _0x339df2=_0x47990f['getImmediate'](),_0x5bb1cc=_0x47990f['getOptions']();if(De(_0x5bb1cc,_0x4e2123??{}))return _0x339df2;K(_0x339df2,'already-initialized');}return _0x47990f['initialize']({'options':_0x4e2123});}function Lf(_0x3230f2,_0x5d2c76){const _0xbcec9d=(_0x5d2c76==null?void 0x0:_0x5d2c76['persistence'])||[],_0x5cd391=(Array['isArray'](_0xbcec9d)?_0xbcec9d:[_0xbcec9d])['map'](ne);_0x5d2c76!=null&&_0x5d2c76['errorMap']&&_0x3230f2['_updateErrorMap'](_0x5d2c76['errorMap']),_0x3230f2['_initializeWithPersistence'](_0x5cd391,_0x5d2c76==null?void 0x0:_0x5d2c76['popupRedirectResolver']);}function xf(_0x24d7ed,_0x478343,_0x454d6c){const _0x207e0e=qe(_0x24d7ed);m(/^https?:\/\//['test'](_0x478343),_0x207e0e,'invalid-emulator-scheme');const _0x3a384f=!0x1,_0x45b258=La(_0x478343),{host:_0x4695f6,port:_0x58337d}=Ff(_0x478343),_0x365ddf=_0x58337d===null?'':':'+_0x58337d,_0x4e7ee6={'url':_0x45b258+'//'+_0x4695f6+_0x365ddf+'/'},_0x130f20=Object['freeze']({'host':_0x4695f6,'port':_0x58337d,'protocol':_0x45b258['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3a384f})});if(!_0x207e0e['_canInitEmulator']){m(_0x207e0e['config']['emulator']&&_0x207e0e['emulatorConfig'],_0x207e0e,'emulator-config-failed'),m(De(_0x4e7ee6,_0x207e0e['config']['emulator'])&&De(_0x130f20,_0x207e0e['emulatorConfig']),_0x207e0e,'emulator-config-failed');return;}_0x207e0e['config']['emulator']=_0x4e7ee6,_0x207e0e['emulatorConfig']=_0x130f20,_0x207e0e['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x4695f6)?jr(_0x45b258+'//'+_0x4695f6+_0x365ddf):Uf();}function La(_0x1877e5){const _0x3100cb=_0x1877e5['indexOf'](':');return _0x3100cb<0x0?'':_0x1877e5['substr'](0x0,_0x3100cb+0x1);}function Ff(_0x1a8127){const _0x48a74f=La(_0x1a8127),_0x1a5d04=/(\/\/)?([^?#/]+)/['exec'](_0x1a8127['substr'](_0x48a74f['length']));if(!_0x1a5d04)return{'host':'','port':null};const _0x1b84a9=_0x1a5d04[0x2]['split']('@')['pop']()||'',_0x2de55f=/^(\[[^\]]+\])(:|$)/['exec'](_0x1b84a9);if(_0x2de55f){const _0xfdc1f8=_0x2de55f[0x1];return{'host':_0xfdc1f8,'port':Rr(_0x1b84a9['substr'](_0xfdc1f8['length']+0x1))};}else{const [_0x16a759,_0x2e0ed6]=_0x1b84a9['split'](':');return{'host':_0x16a759,'port':Rr(_0x2e0ed6)};}}function Rr(_0x45768b){if(!_0x45768b)return null;const _0xcf637a=Number(_0x45768b);return isNaN(_0xcf637a)?null:_0xcf637a;}function Uf(){function _0x2fcab2(){const _0x3442b6=document['createElement']('p'),_0x4c518b=_0x3442b6['style'];_0x3442b6['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4c518b['position']='fixed',_0x4c518b['width']='100%',_0x4c518b['backgroundColor']='#ffffff',_0x4c518b['border']='.1em\x20solid\x20#000000',_0x4c518b['color']='#b50000',_0x4c518b['bottom']='0px',_0x4c518b['left']='0px',_0x4c518b['margin']='0px',_0x4c518b['zIndex']='10000',_0x4c518b['textAlign']='center',_0x3442b6['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3442b6);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2fcab2):_0x2fcab2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x56e2c2,_0x1d549f){this['providerId']=_0x56e2c2,this['signInMethod']=_0x1d549f;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x59328e){return te('not\x20implemented');}['_linkToIdToken'](_0x12d5f3,_0x4ed29a){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1ccbb2){return te('not\x20implemented');}}async function Wf(_0x58e58c,_0x4f5844){return Ae(_0x58e58c,'POST','/v1/accounts:signUp',_0x4f5844);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x443867,_0xcbe740){return Yt(_0x443867,'POST','/v1/accounts:signInWithPassword',Re(_0x443867,_0xcbe740));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x45125a,_0x52e20e){return Yt(_0x45125a,'POST','/v1/accounts:signInWithEmailLink',Re(_0x45125a,_0x52e20e));}async function Hf(_0x112440,_0x1a6ea7){return Yt(_0x112440,'POST','/v1/accounts:signInWithEmailLink',Re(_0x112440,_0x1a6ea7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x5d6c89,_0x26fc7c,_0x2e9934,_0x151917=null){super('password',_0x2e9934),this['_email']=_0x5d6c89,this['_password']=_0x26fc7c,this['_tenantId']=_0x151917;}static['_fromEmailAndPassword'](_0x2fd655,_0x6854d1){return new Ft(_0x2fd655,_0x6854d1,'password');}static['_fromEmailAndCode'](_0x51dd1d,_0x264565,_0x5d891b=null){return new Ft(_0x51dd1d,_0x264565,'emailLink',_0x5d891b);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x16cd8b){const _0x58ba8b=typeof _0x16cd8b=='string'?JSON['parse'](_0x16cd8b):_0x16cd8b;if(_0x58ba8b!=null&&_0x58ba8b['email']&&(_0x58ba8b!=null&&_0x58ba8b['password'])){if(_0x58ba8b['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x58ba8b['email'],_0x58ba8b['password']);if(_0x58ba8b['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x58ba8b['email'],_0x58ba8b['password'],_0x58ba8b['tenantId']);}return null;}async['_getIdTokenResponse'](_0x7aacd4){switch(this['signInMethod']){case'password':const _0x596a4={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x7aacd4,_0x596a4,'signInWithPassword',Bf);case'emailLink':return Vf(_0x7aacd4,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x7aacd4,'internal-error');}}async['_linkToIdToken'](_0x2805ba,_0x26d70b){switch(this['signInMethod']){case'password':const _0x41ec0b={'idToken':_0x26d70b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2805ba,_0x41ec0b,'signUpPassword',Wf);case'emailLink':return Hf(_0x2805ba,{'idToken':_0x26d70b,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2805ba,'internal-error');}}['_getReauthenticationResolver'](_0x4e0089){return this['_getIdTokenResponse'](_0x4e0089);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3ffc70,_0x523cbc){return Yt(_0x3ffc70,'POST','/v1/accounts:signInWithIdp',Re(_0x3ffc70,_0x523cbc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2e1216){const _0x384fa8=new We(_0x2e1216['providerId'],_0x2e1216['signInMethod']);return _0x2e1216['idToken']||_0x2e1216['accessToken']?(_0x2e1216['idToken']&&(_0x384fa8['idToken']=_0x2e1216['idToken']),_0x2e1216['accessToken']&&(_0x384fa8['accessToken']=_0x2e1216['accessToken']),_0x2e1216['nonce']&&!_0x2e1216['pendingToken']&&(_0x384fa8['nonce']=_0x2e1216['nonce']),_0x2e1216['pendingToken']&&(_0x384fa8['pendingToken']=_0x2e1216['pendingToken'])):_0x2e1216['oauthToken']&&_0x2e1216['oauthTokenSecret']?(_0x384fa8['accessToken']=_0x2e1216['oauthToken'],_0x384fa8['secret']=_0x2e1216['oauthTokenSecret']):K('argument-error'),_0x384fa8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x311189){const _0x1240f1=typeof _0x311189=='string'?JSON['parse'](_0x311189):_0x311189,{providerId:_0x572deb,signInMethod:_0x5c0915,..._0x5ba7f5}=_0x1240f1;if(!_0x572deb||!_0x5c0915)return null;const _0x175818=new We(_0x572deb,_0x5c0915);return _0x175818['idToken']=_0x5ba7f5['idToken']||void 0x0,_0x175818['accessToken']=_0x5ba7f5['accessToken']||void 0x0,_0x175818['secret']=_0x5ba7f5['secret'],_0x175818['nonce']=_0x5ba7f5['nonce'],_0x175818['pendingToken']=_0x5ba7f5['pendingToken']||null,_0x175818;}['_getIdTokenResponse'](_0xf8146f){const _0x3be4f4=this['buildRequest']();return Ze(_0xf8146f,_0x3be4f4);}['_linkToIdToken'](_0xaed50a,_0x2df58a){const _0xdcf9b0=this['buildRequest']();return _0xdcf9b0['idToken']=_0x2df58a,Ze(_0xaed50a,_0xdcf9b0);}['_getReauthenticationResolver'](_0x497471){const _0x4d9186=this['buildRequest']();return _0x4d9186['autoCreate']=!0x1,Ze(_0x497471,_0x4d9186);}['buildRequest'](){const _0x11538d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x11538d['pendingToken']=this['pendingToken'];else{const _0x4ccec8={};this['idToken']&&(_0x4ccec8['id_token']=this['idToken']),this['accessToken']&&(_0x4ccec8['access_token']=this['accessToken']),this['secret']&&(_0x4ccec8['oauth_token_secret']=this['secret']),_0x4ccec8['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4ccec8['nonce']=this['nonce']),_0x11538d['postBody']=at(_0x4ccec8);}return _0x11538d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x3352e5){switch(_0x3352e5){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x422e98){const _0x3e8016=yt(vt(_0x422e98))['link'],_0x1c08c1=_0x3e8016?yt(vt(_0x3e8016))['deep_link_id']:null,_0xbed6c1=yt(vt(_0x422e98))['deep_link_id'];return(_0xbed6c1?yt(vt(_0xbed6c1))['link']:null)||_0xbed6c1||_0x1c08c1||_0x3e8016||_0x422e98;}class Ss{constructor(_0x41020c){const _0x30bed9=yt(vt(_0x41020c)),_0x1dfef0=_0x30bed9['apiKey']??null,_0x59c1bd=_0x30bed9['oobCode']??null,_0x1e6b31=Gf(_0x30bed9['mode']??null);m(_0x1dfef0&&_0x59c1bd&&_0x1e6b31,'argument-error'),this['apiKey']=_0x1dfef0,this['operation']=_0x1e6b31,this['code']=_0x59c1bd,this['continueUrl']=_0x30bed9['continueUrl']??null,this['languageCode']=_0x30bed9['lang']??null,this['tenantId']=_0x30bed9['tenantId']??null;}static['parseLink'](_0x59cde3){const _0xbcd7f9=qf(_0x59cde3);try{return new Ss(_0xbcd7f9);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4a9053,_0x56dc23){return Ft['_fromEmailAndPassword'](_0x4a9053,_0x56dc23);}static['credentialWithLink'](_0x32fd96,_0x4f924b){const _0x355c74=Ss['parseLink'](_0x4f924b);return m(_0x355c74,'argument-error'),Ft['_fromEmailAndCode'](_0x32fd96,_0x355c74['code'],_0x355c74['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x1d5eaa){this['providerId']=_0x1d5eaa,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2c941b){this['defaultLanguageCode']=_0x2c941b;}['setCustomParameters'](_0x50c6d9){return this['customParameters']=_0x50c6d9,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x158878){return this['scopes']['includes'](_0x158878)||this['scopes']['push'](_0x158878),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x2fb2f1){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2fb2f1});}static['credentialFromResult'](_0x3e2ee9){return he['credentialFromTaggedObject'](_0x3e2ee9);}static['credentialFromError'](_0x49fafd){return he['credentialFromTaggedObject'](_0x49fafd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1f687c}){if(!_0x1f687c||!('oauthAccessToken'in _0x1f687c)||!_0x1f687c['oauthAccessToken'])return null;try{return he['credential'](_0x1f687c['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x52c814,_0x24df31){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x52c814,'accessToken':_0x24df31});}static['credentialFromResult'](_0xe5458c){return ue['credentialFromTaggedObject'](_0xe5458c);}static['credentialFromError'](_0x278d39){return ue['credentialFromTaggedObject'](_0x278d39['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x270caf}){if(!_0x270caf)return null;const {oauthIdToken:_0xe6be45,oauthAccessToken:_0x4161ef}=_0x270caf;if(!_0xe6be45&&!_0x4161ef)return null;try{return ue['credential'](_0xe6be45,_0x4161ef);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x37fdfc){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x37fdfc});}static['credentialFromResult'](_0x19a8a8){return de['credentialFromTaggedObject'](_0x19a8a8);}static['credentialFromError'](_0x1b049d){return de['credentialFromTaggedObject'](_0x1b049d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x54cf85}){if(!_0x54cf85||!('oauthAccessToken'in _0x54cf85)||!_0x54cf85['oauthAccessToken'])return null;try{return de['credential'](_0x54cf85['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x474120,_0x47f6c6){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x474120,'oauthTokenSecret':_0x47f6c6});}static['credentialFromResult'](_0x382be5){return fe['credentialFromTaggedObject'](_0x382be5);}static['credentialFromError'](_0x26277b){return fe['credentialFromTaggedObject'](_0x26277b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x160f11}){if(!_0x160f11)return null;const {oauthAccessToken:_0x4880cd,oauthTokenSecret:_0x3d0589}=_0x160f11;if(!_0x4880cd||!_0x3d0589)return null;try{return fe['credential'](_0x4880cd,_0x3d0589);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x53e304,_0x16be01){return Yt(_0x53e304,'POST','/v1/accounts:signUp',Re(_0x53e304,_0x16be01));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5f15b6){this['user']=_0x5f15b6['user'],this['providerId']=_0x5f15b6['providerId'],this['_tokenResponse']=_0x5f15b6['_tokenResponse'],this['operationType']=_0x5f15b6['operationType'];}static async['_fromIdTokenResponse'](_0x26c46f,_0x3e28aa,_0x180eb9,_0xe1b99e=!0x1){const _0x2b3cce=await z['_fromIdTokenResponse'](_0x26c46f,_0x180eb9,_0xe1b99e),_0x5b7a4a=Ar(_0x180eb9);return new Be({'user':_0x2b3cce,'providerId':_0x5b7a4a,'_tokenResponse':_0x180eb9,'operationType':_0x3e28aa});}static async['_forOperation'](_0x2fc24b,_0x24d21f,_0x5681db){await _0x2fc24b['_updateTokensIfNecessary'](_0x5681db,!0x0);const _0x1f9e88=Ar(_0x5681db);return new Be({'user':_0x2fc24b,'providerId':_0x1f9e88,'_tokenResponse':_0x5681db,'operationType':_0x24d21f});}}function Ar(_0x5ed4fc){return _0x5ed4fc['providerId']?_0x5ed4fc['providerId']:'phoneNumber'in _0x5ed4fc?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x226eae,_0x4b7741,_0x182e36,_0x2825fe){super(_0x4b7741['code'],_0x4b7741['message']),this['operationType']=_0x182e36,this['user']=_0x2825fe,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x226eae['name'],'tenantId':_0x226eae['tenantId']??void 0x0,'_serverResponse':_0x4b7741['customData']['_serverResponse'],'operationType':_0x182e36};}static['_fromErrorAndOperation'](_0x5c3717,_0x5013d3,_0x5c897d,_0x321477){return new Rn(_0x5c3717,_0x5013d3,_0x5c897d,_0x321477);}}function Fa(_0x33fbfd,_0x5b5170,_0x20908a,_0x5f37e3){return(_0x5b5170==='reauthenticate'?_0x20908a['_getReauthenticationResolver'](_0x33fbfd):_0x20908a['_getIdTokenResponse'](_0x33fbfd))['catch'](_0x4097b0=>{throw _0x4097b0['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x33fbfd,_0x4097b0,_0x5b5170,_0x5f37e3):_0x4097b0;});}async function jf(_0x558b14,_0x3297b1,_0x2bf5bb=!0x1){const _0x45a197=await xt(_0x558b14,_0x3297b1['_linkToIdToken'](_0x558b14['auth'],await _0x558b14['getIdToken']()),_0x2bf5bb);return Be['_forOperation'](_0x558b14,'link',_0x45a197);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x25d972,_0x14213a,_0x3c6691=!0x1){const {auth:_0x578d8d}=_0x25d972;if(H(_0x578d8d['app']))return Promise['reject'](se(_0x578d8d));const _0x52e336='reauthenticate';try{const _0x42f627=await xt(_0x25d972,Fa(_0x578d8d,_0x52e336,_0x14213a,_0x25d972),_0x3c6691);m(_0x42f627['idToken'],_0x578d8d,'internal-error');const _0x261e00=ws(_0x42f627['idToken']);m(_0x261e00,_0x578d8d,'internal-error');const {sub:_0x489b1a}=_0x261e00;return m(_0x25d972['uid']===_0x489b1a,_0x578d8d,'user-mismatch'),Be['_forOperation'](_0x25d972,_0x52e336,_0x42f627);}catch(_0x39f345){throw(_0x39f345==null?void 0x0:_0x39f345['code'])==='auth/user-not-found'&&K(_0x578d8d,'user-mismatch'),_0x39f345;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x302bdb,_0xe6a04,_0x1e1677=!0x1){if(H(_0x302bdb['app']))return Promise['reject'](se(_0x302bdb));const _0x5c8034='signIn',_0x49b106=await Fa(_0x302bdb,_0x5c8034,_0xe6a04),_0x39c9b8=await Be['_fromIdTokenResponse'](_0x302bdb,_0x5c8034,_0x49b106);return _0x1e1677||await _0x302bdb['_updateCurrentUser'](_0x39c9b8['user']),_0x39c9b8;}async function Yf(_0x16aa3f,_0x20e1f4){return Ua(qe(_0x16aa3f),_0x20e1f4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2cdfaf){const _0xf91f96=qe(_0x2cdfaf);_0xf91f96['_getPasswordPolicyInternal']()&&await _0xf91f96['_updatePasswordPolicy']();}async function R_(_0x4023f7,_0x102855,_0x58e13b){if(H(_0x4023f7['app']))return Promise['reject'](se(_0x4023f7));const _0x453e26=qe(_0x4023f7),_0xbaa06=await Oi(_0x453e26,{'returnSecureToken':!0x0,'email':_0x102855,'password':_0x58e13b,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x49683f=>{throw _0x49683f['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4023f7),_0x49683f;}),_0x1822cd=await Be['_fromIdTokenResponse'](_0x453e26,'signIn',_0xbaa06);return await _0x453e26['_updateCurrentUser'](_0x1822cd['user']),_0x1822cd;}function A_(_0xb637cd,_0x634398,_0x1be3f8){return H(_0xb637cd['app'])?Promise['reject'](se(_0xb637cd)):Yf(k(_0xb637cd),ft['credential'](_0x634398,_0x1be3f8))['catch'](async _0x2263e8=>{throw _0x2263e8['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xb637cd),_0x2263e8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5c60db,_0x4b8312){return k(_0x5c60db)['setPersistence'](_0x4b8312);}function Qf(_0x2c83bf,_0x1de880,_0x8022c7,_0x31c011){return k(_0x2c83bf)['onIdTokenChanged'](_0x1de880,_0x8022c7,_0x31c011);}function Jf(_0x3d8066,_0x5ccbaf,_0x37ebdd){return k(_0x3d8066)['beforeAuthStateChanged'](_0x5ccbaf,_0x37ebdd);}function N_(_0x2d342e,_0x1205d2,_0x476d94,_0x108063){return k(_0x2d342e)['onAuthStateChanged'](_0x1205d2,_0x476d94,_0x108063);}function P_(_0x5563c2){return k(_0x5563c2)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x58d9e2,_0x23dbb2){this['storageRetriever']=_0x58d9e2,this['type']=_0x23dbb2;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x260c6a,_0x45faf9){return this['storage']['setItem'](_0x260c6a,JSON['stringify'](_0x45faf9)),Promise['resolve']();}['_get'](_0x292f69){const _0xfc1a08=this['storage']['getItem'](_0x292f69);return Promise['resolve'](_0xfc1a08?JSON['parse'](_0xfc1a08):null);}['_remove'](_0x249910){return this['storage']['removeItem'](_0x249910),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1e8775,_0xdae123)=>this['onStorageEvent'](_0x1e8775,_0xdae123),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x740a47){for(const _0x4d35af of Object['keys'](this['listeners'])){const _0x322ca4=this['storage']['getItem'](_0x4d35af),_0x414fef=this['localCache'][_0x4d35af];_0x322ca4!==_0x414fef&&_0x740a47(_0x4d35af,_0x414fef,_0x322ca4);}}['onStorageEvent'](_0x4bd444,_0x5f982f=!0x1){if(!_0x4bd444['key']){this['forAllChangedKeys']((_0x54f48d,_0x5331e1,_0x510258)=>{this['notifyListeners'](_0x54f48d,_0x510258);});return;}const _0x417e85=_0x4bd444['key'];_0x5f982f?this['detachListener']():this['stopPolling']();const _0x3b9cc7=()=>{const _0x16f062=this['storage']['getItem'](_0x417e85);!_0x5f982f&&this['localCache'][_0x417e85]===_0x16f062||this['notifyListeners'](_0x417e85,_0x16f062);},_0x287b41=this['storage']['getItem'](_0x417e85);If()&&_0x287b41!==_0x4bd444['newValue']&&_0x4bd444['newValue']!==_0x4bd444['oldValue']?setTimeout(_0x3b9cc7,Zf):_0x3b9cc7();}['notifyListeners'](_0x1e0123,_0x46ebfd){this['localCache'][_0x1e0123]=_0x46ebfd;const _0x30f011=this['listeners'][_0x1e0123];if(_0x30f011){for(const _0x587b77 of Array['from'](_0x30f011))_0x587b77(_0x46ebfd&&JSON['parse'](_0x46ebfd));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x447526,_0x3de642,_0x5cdab3)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x447526,'oldValue':_0x3de642,'newValue':_0x5cdab3}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3bc615,_0x302e95){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3bc615]||(this['listeners'][_0x3bc615]=new Set(),this['localCache'][_0x3bc615]=this['storage']['getItem'](_0x3bc615)),this['listeners'][_0x3bc615]['add'](_0x302e95);}['_removeListener'](_0x5f15b1,_0x530399){this['listeners'][_0x5f15b1]&&(this['listeners'][_0x5f15b1]['delete'](_0x530399),this['listeners'][_0x5f15b1]['size']===0x0&&delete this['listeners'][_0x5f15b1]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x437f35,_0x5cb1c4){await super['_set'](_0x437f35,_0x5cb1c4),this['localCache'][_0x437f35]=JSON['stringify'](_0x5cb1c4);}async['_get'](_0x2b2fe2){const _0x28ad96=await super['_get'](_0x2b2fe2);return this['localCache'][_0x2b2fe2]=JSON['stringify'](_0x28ad96),_0x28ad96;}async['_remove'](_0x141f49){await super['_remove'](_0x141f49),delete this['localCache'][_0x141f49];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x25d4da,_0xd48215){}['_removeListener'](_0x52c77b,_0x22219a){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x3bbdc9){return Promise['all'](_0x3bbdc9['map'](async _0x269ae5=>{try{return{'fulfilled':!0x0,'value':await _0x269ae5};}catch(_0x28f19b){return{'fulfilled':!0x1,'reason':_0x28f19b};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x36601c){this['eventTarget']=_0x36601c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1e1757){const _0xbbd3da=this['receivers']['find'](_0x438d56=>_0x438d56['isListeningto'](_0x1e1757));if(_0xbbd3da)return _0xbbd3da;const _0x513b3d=new jn(_0x1e1757);return this['receivers']['push'](_0x513b3d),_0x513b3d;}['isListeningto'](_0x5bcc48){return this['eventTarget']===_0x5bcc48;}async['handleEvent'](_0x6ca1e){const _0xa788ff=_0x6ca1e,{eventId:_0x125fa8,eventType:_0x2d4d3e,data:_0x85941a}=_0xa788ff['data'],_0x32b451=this['handlersMap'][_0x2d4d3e];if(!(_0x32b451!=null&&_0x32b451['size']))return;_0xa788ff['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x125fa8,'eventType':_0x2d4d3e});const _0x560d8b=Array['from'](_0x32b451)['map'](async _0x348d5e=>_0x348d5e(_0xa788ff['origin'],_0x85941a)),_0x44f832=await tp(_0x560d8b);_0xa788ff['ports'][0x0]['postMessage']({'status':'done','eventId':_0x125fa8,'eventType':_0x2d4d3e,'response':_0x44f832});}['_subscribe'](_0x39237c,_0x411004){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x39237c]||(this['handlersMap'][_0x39237c]=new Set()),this['handlersMap'][_0x39237c]['add'](_0x411004);}['_unsubscribe'](_0x2acfee,_0x1abb44){this['handlersMap'][_0x2acfee]&&_0x1abb44&&this['handlersMap'][_0x2acfee]['delete'](_0x1abb44),(!_0x1abb44||this['handlersMap'][_0x2acfee]['size']===0x0)&&delete this['handlersMap'][_0x2acfee],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x6a7e4='',_0x685391=0xa){let _0x8cf46b='';for(let _0x1dfc99=0x0;_0x1dfc99<_0x685391;_0x1dfc99++)_0x8cf46b+=Math['floor'](Math['random']()*0xa);return _0x6a7e4+_0x8cf46b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x97902a){this['target']=_0x97902a,this['handlers']=new Set();}['removeMessageHandler'](_0x4faf0c){_0x4faf0c['messageChannel']&&(_0x4faf0c['messageChannel']['port1']['removeEventListener']('message',_0x4faf0c['onMessage']),_0x4faf0c['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4faf0c);}async['_send'](_0x144678,_0xd5891,_0x5daeca=0x32){const _0x53d45d=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x53d45d)throw new Error('connection_unavailable');let _0x1bddc5,_0x2b17df;return new Promise((_0x4a3259,_0x43780c)=>{const _0x28ec66=bs('',0x14);_0x53d45d['port1']['start']();const _0x4ce8d4=setTimeout(()=>{_0x43780c(new Error('unsupported_event'));},_0x5daeca);_0x2b17df={'messageChannel':_0x53d45d,'onMessage'(_0x44cb3e){const _0x3bdc5a=_0x44cb3e;if(_0x3bdc5a['data']['eventId']===_0x28ec66)switch(_0x3bdc5a['data']['status']){case'ack':clearTimeout(_0x4ce8d4),_0x1bddc5=setTimeout(()=>{_0x43780c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1bddc5),_0x4a3259(_0x3bdc5a['data']['response']);break;default:clearTimeout(_0x4ce8d4),clearTimeout(_0x1bddc5),_0x43780c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2b17df),_0x53d45d['port1']['addEventListener']('message',_0x2b17df['onMessage']),this['target']['postMessage']({'eventType':_0x144678,'eventId':_0x28ec66,'data':_0xd5891},[_0x53d45d['port2']]);})['finally'](()=>{_0x2b17df&&this['removeMessageHandler'](_0x2b17df);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x32e1e3){X()['location']['href']=_0x32e1e3;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x15b8ae;return((_0x15b8ae=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x15b8ae['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3380e3){this['request']=_0x3380e3;}['toPromise'](){return new Promise((_0x2aa1a0,_0x522f06)=>{this['request']['addEventListener']('success',()=>{_0x2aa1a0(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x522f06(this['request']['error']);});});}}function Kn(_0x44be7c,_0x229122){return _0x44be7c['transaction']([kn],_0x229122?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x57d975=indexedDB['deleteDatabase'](qa);return new Jt(_0x57d975)['toPromise']();}function ja(){const _0x3df8a2=indexedDB['open'](qa,ap);return new Promise((_0xad0133,_0xdf8c58)=>{_0x3df8a2['addEventListener']('error',()=>{_0xdf8c58(_0x3df8a2['error']);}),_0x3df8a2['addEventListener']('upgradeneeded',()=>{const _0x51e15c=_0x3df8a2['result'];try{_0x51e15c['createObjectStore'](kn,{'keyPath':za});}catch(_0x5b00f0){_0xdf8c58(_0x5b00f0);}}),_0x3df8a2['addEventListener']('success',async()=>{const _0x45ea0e=_0x3df8a2['result'];_0x45ea0e['objectStoreNames']['contains'](kn)?_0xad0133(_0x45ea0e):(_0x45ea0e['close'](),await cp(),_0xad0133(await ja()));});});}async function kr(_0x4a8480,_0x5539d0,_0x1cd9a8){const _0xda47a1=Kn(_0x4a8480,!0x0)['put']({[za]:_0x5539d0,'value':_0x1cd9a8});return new Jt(_0xda47a1)['toPromise']();}async function lp(_0x231a04,_0x1daf56){const _0x52b6ca=Kn(_0x231a04,!0x1)['get'](_0x1daf56),_0x1bb283=await new Jt(_0x52b6ca)['toPromise']();return _0x1bb283===void 0x0?null:_0x1bb283['value'];}function Nr(_0x1b5d41,_0x466bc6){const _0x524db4=Kn(_0x1b5d41,!0x0)['delete'](_0x466bc6);return new Jt(_0x524db4)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3ba409){let _0x4d2460=0x0;for(;;)try{const _0x2ac5c5=await this['_openDb']();return await _0x3ba409(_0x2ac5c5);}catch(_0x31adb5){if(_0x4d2460++>up)throw _0x31adb5;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3397f7,_0x5770cd)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5770cd['key'])})),this['receiver']['_subscribe']('ping',async(_0xd5b38f,_0xc615d0)=>['keyChanged']);}async['initializeSender'](){var _0x1a7133,_0x6c08ad;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4dd536=await this['sender']['_send']('ping',{},0x320);_0x4dd536&&(_0x1a7133=_0x4dd536[0x0])!=null&&_0x1a7133['fulfilled']&&(_0x6c08ad=_0x4dd536[0x0])!=null&&_0x6c08ad['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x165b7b){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x165b7b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x20a5c0=>{await kr(_0x20a5c0,An,'1'),await Nr(_0x20a5c0,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4765fd){this['pendingWrites']++;try{await _0x4765fd();}finally{this['pendingWrites']--;}}async['_set'](_0x4b1730,_0x37902d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4eeb63=>kr(_0x4eeb63,_0x4b1730,_0x37902d)),this['localCache'][_0x4b1730]=_0x37902d,this['notifyServiceWorker'](_0x4b1730)));}async['_get'](_0x3c124f){const _0x36fcc6=await this['_withRetries'](_0x3dc0e4=>lp(_0x3dc0e4,_0x3c124f));return this['localCache'][_0x3c124f]=_0x36fcc6,_0x36fcc6;}async['_remove'](_0x3f8162){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x283ae3=>Nr(_0x283ae3,_0x3f8162)),delete this['localCache'][_0x3f8162],this['notifyServiceWorker'](_0x3f8162)));}async['_poll'](){const _0x886211=await this['_withRetries'](_0x2689de=>{const _0x3ca70d=Kn(_0x2689de,!0x1)['getAll']();return new Jt(_0x3ca70d)['toPromise']();});if(!_0x886211)return[];if(this['pendingWrites']!==0x0)return[];const _0x13a687=[],_0x1e3c47=new Set();if(_0x886211['length']!==0x0){for(const {fbase_key:_0x2eb37d,value:_0x5e4e90}of _0x886211)_0x1e3c47['add'](_0x2eb37d),JSON['stringify'](this['localCache'][_0x2eb37d])!==JSON['stringify'](_0x5e4e90)&&(this['notifyListeners'](_0x2eb37d,_0x5e4e90),_0x13a687['push'](_0x2eb37d));}for(const _0x969a1f of Object['keys'](this['localCache']))this['localCache'][_0x969a1f]&&!_0x1e3c47['has'](_0x969a1f)&&(this['notifyListeners'](_0x969a1f,null),_0x13a687['push'](_0x969a1f));return _0x13a687;}['notifyListeners'](_0x2b671b,_0x2d02de){this['localCache'][_0x2b671b]=_0x2d02de;const _0x4a5141=this['listeners'][_0x2b671b];if(_0x4a5141){for(const _0x3a20a3 of Array['from'](_0x4a5141))_0x3a20a3(_0x2d02de);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5f0217,_0x2c7057){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5f0217]||(this['listeners'][_0x5f0217]=new Set(),this['_get'](_0x5f0217)),this['listeners'][_0x5f0217]['add'](_0x2c7057);}['_removeListener'](_0x55da79,_0x512228){this['listeners'][_0x55da79]&&(this['listeners'][_0x55da79]['delete'](_0x512228),this['listeners'][_0x55da79]['size']===0x0&&delete this['listeners'][_0x55da79]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x13c24a,_0x47b6af){return _0x47b6af?ne(_0x47b6af):(m(_0x13c24a['_popupRedirectResolver'],_0x13c24a,'argument-error'),_0x13c24a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2caced){super('custom','custom'),this['params']=_0x2caced;}['_getIdTokenResponse'](_0x18037f){return Ze(_0x18037f,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5d2a5b,_0x291a24){return Ze(_0x5d2a5b,this['_buildIdpRequest'](_0x291a24));}['_getReauthenticationResolver'](_0x333ecc){return Ze(_0x333ecc,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x54aaf0){const _0x5c68b2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x54aaf0&&(_0x5c68b2['idToken']=_0x54aaf0),_0x5c68b2;}}function pp(_0x28f7b9){return Ua(_0x28f7b9['auth'],new Rs(_0x28f7b9),_0x28f7b9['bypassAuthState']);}function _p(_0x5e3f81){const {auth:_0x354fc7,user:_0x31fe52}=_0x5e3f81;return m(_0x31fe52,_0x354fc7,'internal-error'),Kf(_0x31fe52,new Rs(_0x5e3f81),_0x5e3f81['bypassAuthState']);}async function gp(_0x5be518){const {auth:_0x3f58a,user:_0x1dbdf1}=_0x5be518;return m(_0x1dbdf1,_0x3f58a,'internal-error'),jf(_0x1dbdf1,new Rs(_0x5be518),_0x5be518['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x10ffc1,_0x48ca4c,_0x33e113,_0x3dd4a5,_0x189b1f=!0x1){this['auth']=_0x10ffc1,this['resolver']=_0x33e113,this['user']=_0x3dd4a5,this['bypassAuthState']=_0x189b1f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x48ca4c)?_0x48ca4c:[_0x48ca4c];}['execute'](){return new Promise(async(_0x3fc926,_0x40350d)=>{this['pendingPromise']={'resolve':_0x3fc926,'reject':_0x40350d};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x23179a){this['reject'](_0x23179a);}});}async['onAuthEvent'](_0x4ec8e8){const {urlResponse:_0x36e206,sessionId:_0x170bbb,postBody:_0x5bb4f9,tenantId:_0x381d3a,error:_0x166891,type:_0x5af300}=_0x4ec8e8;if(_0x166891){this['reject'](_0x166891);return;}const _0x1b583d={'auth':this['auth'],'requestUri':_0x36e206,'sessionId':_0x170bbb,'tenantId':_0x381d3a||void 0x0,'postBody':_0x5bb4f9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5af300)(_0x1b583d));}catch(_0x5abd63){this['reject'](_0x5abd63);}}['onError'](_0x322edc){this['reject'](_0x322edc);}['getIdpTask'](_0x511eb9){switch(_0x511eb9){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0xa64a57){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xa64a57),this['unregisterAndCleanUp']();}['reject'](_0x46046d){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x46046d),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x2884da,_0x487d5f,_0x559bad,_0x4ff42a,_0x9f15e6){super(_0x2884da,_0x487d5f,_0x4ff42a,_0x9f15e6),this['provider']=_0x559bad,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x186be3=await this['execute']();return m(_0x186be3,this['auth'],'internal-error'),_0x186be3;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x50ad14=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x50ad14),this['authWindow']['associatedEvent']=_0x50ad14,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4c1ca3=>{this['reject'](_0x4c1ca3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5daeb6=>{_0x5daeb6||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x340277;return((_0x340277=this['authWindow'])==null?void 0x0:_0x340277['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x20754c=()=>{var _0x1683ba,_0x54879a;if((_0x54879a=(_0x1683ba=this['authWindow'])==null?void 0x0:_0x1683ba['window'])!=null&&_0x54879a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x20754c,mp['get']());};_0x20754c();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x23b70b,_0x2f0709,_0x4a86db=!0x1){super(_0x23b70b,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2f0709,void 0x0,_0x4a86db),this['eventId']=null;}async['execute'](){let _0x5c7df9=rn['get'](this['auth']['_key']());if(!_0x5c7df9){try{const _0xbe3307=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5c7df9=()=>Promise['resolve'](_0xbe3307);}catch(_0x1d8e08){_0x5c7df9=()=>Promise['reject'](_0x1d8e08);}rn['set'](this['auth']['_key'](),_0x5c7df9);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5c7df9();}async['onAuthEvent'](_0xa580c){if(_0xa580c['type']==='signInViaRedirect')return super['onAuthEvent'](_0xa580c);if(_0xa580c['type']==='unknown'){this['resolve'](null);return;}if(_0xa580c['eventId']){const _0x1e5486=await this['auth']['_redirectUserForId'](_0xa580c['eventId']);if(_0x1e5486)return this['user']=_0x1e5486,super['onAuthEvent'](_0xa580c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x330b9a,_0x3cf7ad){const _0xb38ef6=Cp(_0x3cf7ad),_0x4eead8=wp(_0x330b9a);if(!await _0x4eead8['_isAvailable']())return!0x1;const _0x47499d=await _0x4eead8['_get'](_0xb38ef6)==='true';return await _0x4eead8['_remove'](_0xb38ef6),_0x47499d;}function Ip(_0x5a9b81,_0x1dbcfc){rn['set'](_0x5a9b81['_key'](),_0x1dbcfc);}function wp(_0x202006){return ne(_0x202006['_redirectPersistence']);}function Cp(_0x2532a7){return sn(yp,_0x2532a7['config']['apiKey'],_0x2532a7['name']);}async function Tp(_0x5e5307,_0x34e9e4,_0x19496d=!0x1){if(H(_0x5e5307['app']))return Promise['reject'](se(_0x5e5307));const _0x51241a=qe(_0x5e5307),_0x5b9459=fp(_0x51241a,_0x34e9e4),_0x10fa81=await new vp(_0x51241a,_0x5b9459,_0x19496d)['execute']();return _0x10fa81&&!_0x19496d&&(delete _0x10fa81['user']['_redirectEventId'],await _0x51241a['_persistUserIfCurrent'](_0x10fa81['user']),await _0x51241a['_setRedirectUser'](null,_0x34e9e4)),_0x10fa81;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xd135c0){this['auth']=_0xd135c0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x571667){this['consumers']['add'](_0x571667),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x571667)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x571667),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x20c328){this['consumers']['delete'](_0x20c328);}['onEvent'](_0x131976){if(this['hasEventBeenHandled'](_0x131976))return!0x1;let _0x2a9cd0=!0x1;return this['consumers']['forEach'](_0x4dd4dd=>{this['isEventForConsumer'](_0x131976,_0x4dd4dd)&&(_0x2a9cd0=!0x0,this['sendToConsumer'](_0x131976,_0x4dd4dd),this['saveEventToCache'](_0x131976));}),this['hasHandledPotentialRedirect']||!Rp(_0x131976)||(this['hasHandledPotentialRedirect']=!0x0,_0x2a9cd0||(this['queuedRedirectEvent']=_0x131976,_0x2a9cd0=!0x0)),_0x2a9cd0;}['sendToConsumer'](_0x208f04,_0x4ffba1){var _0x2be726;if(_0x208f04['error']&&!Qa(_0x208f04)){const _0x3dd7d5=((_0x2be726=_0x208f04['error']['code'])==null?void 0x0:_0x2be726['split']('auth/')[0x1])||'internal-error';_0x4ffba1['onError'](J(this['auth'],_0x3dd7d5));}else _0x4ffba1['onAuthEvent'](_0x208f04);}['isEventForConsumer'](_0x503d0e,_0x4338a2){const _0x251ad3=_0x4338a2['eventId']===null||!!_0x503d0e['eventId']&&_0x503d0e['eventId']===_0x4338a2['eventId'];return _0x4338a2['filter']['includes'](_0x503d0e['type'])&&_0x251ad3;}['hasEventBeenHandled'](_0x4ee130){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x4ee130));}['saveEventToCache'](_0x2724b5){this['cachedEventUids']['add'](Pr(_0x2724b5)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x943034){return[_0x943034['type'],_0x943034['eventId'],_0x943034['sessionId'],_0x943034['tenantId']]['filter'](_0x3b8379=>_0x3b8379)['join']('-');}function Qa({type:_0x3bbd10,error:_0x308c6e}){return _0x3bbd10==='unknown'&&(_0x308c6e==null?void 0x0:_0x308c6e['code'])==='auth/no-auth-event';}function Rp(_0x58c2e3){switch(_0x58c2e3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x58c2e3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3b1fca,_0x5cc376={}){return Ae(_0x3b1fca,'GET','/v1/projects',_0x5cc376);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0xa61348){if(_0xa61348['config']['emulator'])return;const {authorizedDomains:_0x3a13cd}=await Ap(_0xa61348);for(const _0x66c91f of _0x3a13cd)try{if(Op(_0x66c91f))return;}catch{}K(_0xa61348,'unauthorized-domain');}function Op(_0x8e3372){const _0x3ca584=Ni(),{protocol:_0x250705,hostname:_0x4a8b34}=new URL(_0x3ca584);if(_0x8e3372['startsWith']('chrome-extension://')){const _0x337ca6=new URL(_0x8e3372);return _0x337ca6['hostname']===''&&_0x4a8b34===''?_0x250705==='chrome-extension:'&&_0x8e3372['replace']('chrome-extension://','')===_0x3ca584['replace']('chrome-extension://',''):_0x250705==='chrome-extension:'&&_0x337ca6['hostname']===_0x4a8b34;}if(!Np['test'](_0x250705))return!0x1;if(kp['test'](_0x8e3372))return _0x4a8b34===_0x8e3372;const _0x4de35b=_0x8e3372['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4de35b+'|'+_0x4de35b+')$','i')['test'](_0x4a8b34);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x42a7ee=X()['___jsl'];if(_0x42a7ee!=null&&_0x42a7ee['H']){for(const _0x3f58f0 of Object['keys'](_0x42a7ee['H']))if(_0x42a7ee['H'][_0x3f58f0]['r']=_0x42a7ee['H'][_0x3f58f0]['r']||[],_0x42a7ee['H'][_0x3f58f0]['L']=_0x42a7ee['H'][_0x3f58f0]['L']||[],_0x42a7ee['H'][_0x3f58f0]['r']=[..._0x42a7ee['H'][_0x3f58f0]['L']],_0x42a7ee['CP']){for(let _0x5ee1d9=0x0;_0x5ee1d9<_0x42a7ee['CP']['length'];_0x5ee1d9++)_0x42a7ee['CP'][_0x5ee1d9]=null;}}}function Mp(_0x3bbdd6){return new Promise((_0x1440cd,_0xd4e054)=>{var _0x423a73,_0x59d718,_0x241417;function _0x112333(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1440cd(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0xd4e054(J(_0x3bbdd6,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x59d718=(_0x423a73=X()['gapi'])==null?void 0x0:_0x423a73['iframes'])!=null&&_0x59d718['Iframe'])_0x1440cd(gapi['iframes']['getContext']());else{if((_0x241417=X()['gapi'])!=null&&_0x241417['load'])_0x112333();else{const _0x3c25e1=Nf('iframefcb');return X()[_0x3c25e1]=()=>{gapi['load']?_0x112333():_0xd4e054(J(_0x3bbdd6,'network-request-failed'));},Da(kf()+'?onload='+_0x3c25e1)['catch'](_0x11c7ec=>_0xd4e054(_0x11c7ec));}}})['catch'](_0x2843a3=>{throw on=null,_0x2843a3;});}let on=null;function Lp(_0x43423e){return on=on||Mp(_0x43423e),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3c38cb){const _0x17996a=_0x3c38cb['config'];m(_0x17996a['authDomain'],_0x3c38cb,'auth-domain-config-required');const _0x2e4aba=_0x17996a['emulator']?Is(_0x17996a,Up):'https://'+_0x3c38cb['config']['authDomain']+'/'+Fp,_0x210df7={'apiKey':_0x17996a['apiKey'],'appName':_0x3c38cb['name'],'v':ct},_0x21c7fc=Bp['get'](_0x3c38cb['config']['apiHost']);_0x21c7fc&&(_0x210df7['eid']=_0x21c7fc);const _0x43306f=_0x3c38cb['_getFrameworks']();return _0x43306f['length']&&(_0x210df7['fw']=_0x43306f['join'](',')),_0x2e4aba+'?'+at(_0x210df7)['slice'](0x1);}async function Hp(_0x3fb8ea){const _0x10221d=await Lp(_0x3fb8ea),_0x326293=X()['gapi'];return m(_0x326293,_0x3fb8ea,'internal-error'),_0x10221d['open']({'where':document['body'],'url':Vp(_0x3fb8ea),'messageHandlersFilter':_0x326293['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x47524d=>new Promise(async(_0x2a3ee5,_0x5a706d)=>{await _0x47524d['restyle']({'setHideOnLeave':!0x1});const _0x3a4d6c=J(_0x3fb8ea,'network-request-failed'),_0x321cf7=X()['setTimeout'](()=>{_0x5a706d(_0x3a4d6c);},xp['get']());function _0x362787(){X()['clearTimeout'](_0x321cf7),_0x2a3ee5(_0x47524d);}_0x47524d['ping'](_0x362787)['then'](_0x362787,()=>{_0x5a706d(_0x3a4d6c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1a9058){this['window']=_0x1a9058,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x10d955,_0x29619f,_0x3d0a10,_0x590def=Gp,_0x24ed7b=qp){const _0x3a7a92=Math['max']((window['screen']['availHeight']-_0x24ed7b)/0x2,0x0)['toString'](),_0x4d95b3=Math['max']((window['screen']['availWidth']-_0x590def)/0x2,0x0)['toString']();let _0x40a2f6='';const _0x56b0d2={...$p,'width':_0x590def['toString'](),'height':_0x24ed7b['toString'](),'top':_0x3a7a92,'left':_0x4d95b3},_0x29954b=W()['toLowerCase']();_0x3d0a10&&(_0x40a2f6=ba(_0x29954b)?zp:_0x3d0a10),Ta(_0x29954b)&&(_0x29619f=_0x29619f||jp,_0x56b0d2['scrollbars']='yes');const _0x3ae372=Object['entries'](_0x56b0d2)['reduce']((_0x53125b,[_0x3b9521,_0x178f5e])=>''+_0x53125b+_0x3b9521+'='+_0x178f5e+',','');if(Ef(_0x29954b)&&_0x40a2f6!=='_self')return Yp(_0x29619f||'',_0x40a2f6),new Dr(null);const _0x1e679a=window['open'](_0x29619f||'',_0x40a2f6,_0x3ae372);m(_0x1e679a,_0x10d955,'popup-blocked');try{_0x1e679a['focus']();}catch{}return new Dr(_0x1e679a);}function Yp(_0x3f8d26,_0x5c4f18){const _0x458850=document['createElement']('a');_0x458850['href']=_0x3f8d26,_0x458850['target']=_0x5c4f18;const _0x4d8f40=document['createEvent']('MouseEvent');_0x4d8f40['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x458850['dispatchEvent'](_0x4d8f40);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0xcca054,_0x5e6e57,_0x3663e2,_0x4de30f,_0x52a016,_0x2f096f){m(_0xcca054['config']['authDomain'],_0xcca054,'auth-domain-config-required'),m(_0xcca054['config']['apiKey'],_0xcca054,'invalid-api-key');const _0x142a5f={'apiKey':_0xcca054['config']['apiKey'],'appName':_0xcca054['name'],'authType':_0x3663e2,'redirectUrl':_0x4de30f,'v':ct,'eventId':_0x52a016};if(_0x5e6e57 instanceof xa){_0x5e6e57['setDefaultLanguage'](_0xcca054['languageCode']),_0x142a5f['providerId']=_0x5e6e57['providerId']||'',hi(_0x5e6e57['getCustomParameters']())||(_0x142a5f['customParameters']=JSON['stringify'](_0x5e6e57['getCustomParameters']()));for(const [_0x183f04,_0x2c39a7]of Object['entries']({}))_0x142a5f[_0x183f04]=_0x2c39a7;}if(_0x5e6e57 instanceof Qt){const _0x704a66=_0x5e6e57['getScopes']()['filter'](_0x4654fb=>_0x4654fb!=='');_0x704a66['length']>0x0&&(_0x142a5f['scopes']=_0x704a66['join'](','));}_0xcca054['tenantId']&&(_0x142a5f['tid']=_0xcca054['tenantId']);const _0x3c8d60=_0x142a5f;for(const _0x425c67 of Object['keys'](_0x3c8d60))_0x3c8d60[_0x425c67]===void 0x0&&delete _0x3c8d60[_0x425c67];const _0x59e7ab=await _0xcca054['_getAppCheckToken'](),_0x2cd5f7=_0x59e7ab?'#'+Xp+'='+encodeURIComponent(_0x59e7ab):'';return Zp(_0xcca054)+'?'+at(_0x3c8d60)['slice'](0x1)+_0x2cd5f7;}function Zp({config:_0x43ddd7}){return _0x43ddd7['emulator']?Is(_0x43ddd7,Jp):'https://'+_0x43ddd7['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x38d6b9,_0x5d4782,_0x434b3f,_0x219142){var _0x4d1487;ae((_0x4d1487=this['eventManagers'][_0x38d6b9['_key']()])==null?void 0x0:_0x4d1487['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x265efe=await Mr(_0x38d6b9,_0x5d4782,_0x434b3f,Ni(),_0x219142);return Kp(_0x38d6b9,_0x265efe,bs());}async['_openRedirect'](_0x301745,_0x80051d,_0x4ce281,_0x434bb5){await this['_originValidation'](_0x301745);const _0x44a229=await Mr(_0x301745,_0x80051d,_0x4ce281,Ni(),_0x434bb5);return ip(_0x44a229),new Promise(()=>{});}['_initialize'](_0x2afc9e){const _0x532fb0=_0x2afc9e['_key']();if(this['eventManagers'][_0x532fb0]){const {manager:_0x35e208,promise:_0xb15e64}=this['eventManagers'][_0x532fb0];return _0x35e208?Promise['resolve'](_0x35e208):(ae(_0xb15e64,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xb15e64);}const _0x5a0d47=this['initAndGetManager'](_0x2afc9e);return this['eventManagers'][_0x532fb0]={'promise':_0x5a0d47},_0x5a0d47['catch'](()=>{delete this['eventManagers'][_0x532fb0];}),_0x5a0d47;}async['initAndGetManager'](_0x309e87){const _0x580e5e=await Hp(_0x309e87),_0x466ea1=new bp(_0x309e87);return _0x580e5e['register']('authEvent',_0x42a701=>(m(_0x42a701==null?void 0x0:_0x42a701['authEvent'],_0x309e87,'invalid-auth-event'),{'status':_0x466ea1['onEvent'](_0x42a701['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x309e87['_key']()]={'manager':_0x466ea1},this['iframes'][_0x309e87['_key']()]=_0x580e5e,_0x466ea1;}['_isIframeWebStorageSupported'](_0x10aee2,_0x1fa4f9){this['iframes'][_0x10aee2['_key']()]['send'](li,{'type':li},_0x376954=>{var _0x248ad4;const _0x5255c7=(_0x248ad4=_0x376954==null?void 0x0:_0x376954[0x0])==null?void 0x0:_0x248ad4[li];_0x5255c7!==void 0x0&&_0x1fa4f9(!!_0x5255c7),K(_0x10aee2,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x185819){const _0x9365e4=_0x185819['_key']();return this['originValidationPromises'][_0x9365e4]||(this['originValidationPromises'][_0x9365e4]=Pp(_0x185819)),this['originValidationPromises'][_0x9365e4];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x110ba8){this['auth']=_0x110ba8,this['internalListeners']=new Map();}['getUid'](){var _0x32c279;return this['assertAuthConfigured'](),((_0x32c279=this['auth']['currentUser'])==null?void 0x0:_0x32c279['uid'])||null;}async['getToken'](_0x24ce9c){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x24ce9c)}:null;}['addAuthTokenListener'](_0x799cc2){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x799cc2))return;const _0x46ae74=this['auth']['onIdTokenChanged'](_0x2e743f=>{_0x799cc2((_0x2e743f==null?void 0x0:_0x2e743f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x799cc2,_0x46ae74),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x159d3b){this['assertAuthConfigured']();const _0x147f15=this['internalListeners']['get'](_0x159d3b);_0x147f15&&(this['internalListeners']['delete'](_0x159d3b),_0x147f15(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x3e10ec){switch(_0x3e10ec){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x5798c7){et(new Me('auth',(_0x1bee09,{options:_0x2525f9})=>{const _0x364b2f=_0x1bee09['getProvider']('app')['getImmediate'](),_0x5cd5e3=_0x1bee09['getProvider']('heartbeat'),_0x20b0da=_0x1bee09['getProvider']('app-check-internal'),{apiKey:_0x1349c9,authDomain:_0x8db0c3}=_0x364b2f['options'];m(_0x1349c9&&!_0x1349c9['includes'](':'),'invalid-api-key',{'appName':_0x364b2f['name']});const _0xdfe4d5={'apiKey':_0x1349c9,'authDomain':_0x8db0c3,'clientPlatform':_0x5798c7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x5798c7)},_0x314153=new bf(_0x364b2f,_0x5cd5e3,_0x20b0da,_0xdfe4d5);return Lf(_0x314153,_0x2525f9),_0x314153;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x488057,_0x41fcb8,_0x24358e)=>{_0x488057['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x391e87=>{const _0x4f4fa2=qe(_0x391e87['getProvider']('auth')['getImmediate']());return(_0x37856d=>new n_(_0x37856d))(_0x4f4fa2);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x5798c7)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4e072a=>async _0x42fa65=>{const _0x3d40fe=_0x42fa65&&await _0x42fa65['getIdTokenResult'](),_0x57c888=_0x3d40fe&&(new Date()['getTime']()-Date['parse'](_0x3d40fe['issuedAtTime']))/0x3e8;if(_0x57c888&&_0x57c888>o_)return;const _0x354c8c=_0x3d40fe==null?void 0x0:_0x3d40fe['token'];Fr!==_0x354c8c&&(Fr=_0x354c8c,await fetch(_0x4e072a,{'method':_0x354c8c?'POST':'DELETE','headers':_0x354c8c?{'Authorization':'Bearer\x20'+_0x354c8c}:{}}));};function O_(_0x492b1b=Qr()){const _0x4a3be1=Ui(_0x492b1b,'auth');if(_0x4a3be1['isInitialized']())return _0x4a3be1['getImmediate']();const _0x584c0d=Mf(_0x492b1b,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x12fcfc=Gr('authTokenSyncURL');if(_0x12fcfc&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3574c6=new URL(_0x12fcfc,location['origin']);if(location['origin']===_0x3574c6['origin']){const _0x926ad3=a_(_0x3574c6['toString']());Jf(_0x584c0d,_0x926ad3,()=>_0x926ad3(_0x584c0d['currentUser'])),Qf(_0x584c0d,_0x4b05bf=>_0x926ad3(_0x4b05bf));}}const _0x42be3e=Hr('auth');return _0x42be3e&&xf(_0x584c0d,'http://'+_0x42be3e),_0x584c0d;}function c_(){var _0xf9c743;return((_0xf9c743=document['getElementsByTagName']('head'))==null?void 0x0:_0xf9c743[0x0])??document;}Rf({'loadJS'(_0x597c99){return new Promise((_0x286ce2,_0x9c2ffe)=>{const _0x3f0952=document['createElement']('script');_0x3f0952['setAttribute']('src',_0x597c99),_0x3f0952['onload']=_0x286ce2,_0x3f0952['onerror']=_0x6fa6da=>{const _0x2c76e1=J('internal-error');_0x2c76e1['customData']=_0x6fa6da,_0x9c2ffe(_0x2c76e1);},_0x3f0952['type']='text/javascript',_0x3f0952['charset']='UTF-8',c_()['appendChild'](_0x3f0952);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};