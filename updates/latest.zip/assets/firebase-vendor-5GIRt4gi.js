const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1ffaab,_0x4ee49f){if(!_0x1ffaab)throw ot(_0x4ee49f);},ot=function(_0x27d4b0){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x27d4b0);},Wr=function(_0xf1c29a){const _0x144774=[];let _0x5046a1=0x0;for(let _0x20048e=0x0;_0x20048e<_0xf1c29a['length'];_0x20048e++){let _0x247853=_0xf1c29a['charCodeAt'](_0x20048e);_0x247853<0x80?_0x144774[_0x5046a1++]=_0x247853:_0x247853<0x800?(_0x144774[_0x5046a1++]=_0x247853>>0x6|0xc0,_0x144774[_0x5046a1++]=_0x247853&0x3f|0x80):(_0x247853&0xfc00)===0xd800&&_0x20048e+0x1<_0xf1c29a['length']&&(_0xf1c29a['charCodeAt'](_0x20048e+0x1)&0xfc00)===0xdc00?(_0x247853=0x10000+((_0x247853&0x3ff)<<0xa)+(_0xf1c29a['charCodeAt'](++_0x20048e)&0x3ff),_0x144774[_0x5046a1++]=_0x247853>>0x12|0xf0,_0x144774[_0x5046a1++]=_0x247853>>0xc&0x3f|0x80,_0x144774[_0x5046a1++]=_0x247853>>0x6&0x3f|0x80,_0x144774[_0x5046a1++]=_0x247853&0x3f|0x80):(_0x144774[_0x5046a1++]=_0x247853>>0xc|0xe0,_0x144774[_0x5046a1++]=_0x247853>>0x6&0x3f|0x80,_0x144774[_0x5046a1++]=_0x247853&0x3f|0x80);}return _0x144774;},Za=function(_0x42ec12){const _0x22ac12=[];let _0x2122eb=0x0,_0x2645a0=0x0;for(;_0x2122eb<_0x42ec12['length'];){const _0x22e408=_0x42ec12[_0x2122eb++];if(_0x22e408<0x80)_0x22ac12[_0x2645a0++]=String['fromCharCode'](_0x22e408);else{if(_0x22e408>0xbf&&_0x22e408<0xe0){const _0x45307f=_0x42ec12[_0x2122eb++];_0x22ac12[_0x2645a0++]=String['fromCharCode']((_0x22e408&0x1f)<<0x6|_0x45307f&0x3f);}else{if(_0x22e408>0xef&&_0x22e408<0x16d){const _0x4b2d03=_0x42ec12[_0x2122eb++],_0x110ce4=_0x42ec12[_0x2122eb++],_0x582047=_0x42ec12[_0x2122eb++],_0x14f1de=((_0x22e408&0x7)<<0x12|(_0x4b2d03&0x3f)<<0xc|(_0x110ce4&0x3f)<<0x6|_0x582047&0x3f)-0x10000;_0x22ac12[_0x2645a0++]=String['fromCharCode'](0xd800+(_0x14f1de>>0xa)),_0x22ac12[_0x2645a0++]=String['fromCharCode'](0xdc00+(_0x14f1de&0x3ff));}else{const _0x94709c=_0x42ec12[_0x2122eb++],_0x5de608=_0x42ec12[_0x2122eb++];_0x22ac12[_0x2645a0++]=String['fromCharCode']((_0x22e408&0xf)<<0xc|(_0x94709c&0x3f)<<0x6|_0x5de608&0x3f);}}}}return _0x22ac12['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x17a2a3,_0x428aa1){if(!Array['isArray'](_0x17a2a3))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x931290=_0x428aa1?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2bdfe0=[];for(let _0x525446=0x0;_0x525446<_0x17a2a3['length'];_0x525446+=0x3){const _0x1b10ef=_0x17a2a3[_0x525446],_0x45a21e=_0x525446+0x1<_0x17a2a3['length'],_0x2dbdc6=_0x45a21e?_0x17a2a3[_0x525446+0x1]:0x0,_0x557883=_0x525446+0x2<_0x17a2a3['length'],_0x2972b0=_0x557883?_0x17a2a3[_0x525446+0x2]:0x0,_0x57975d=_0x1b10ef>>0x2,_0x926994=(_0x1b10ef&0x3)<<0x4|_0x2dbdc6>>0x4;let _0x45ba70=(_0x2dbdc6&0xf)<<0x2|_0x2972b0>>0x6,_0xd6556=_0x2972b0&0x3f;_0x557883||(_0xd6556=0x40,_0x45a21e||(_0x45ba70=0x40)),_0x2bdfe0['push'](_0x931290[_0x57975d],_0x931290[_0x926994],_0x931290[_0x45ba70],_0x931290[_0xd6556]);}return _0x2bdfe0['join']('');},'encodeString'(_0x132860,_0x44a060){return this['HAS_NATIVE_SUPPORT']&&!_0x44a060?btoa(_0x132860):this['encodeByteArray'](Wr(_0x132860),_0x44a060);},'decodeString'(_0x16e1a7,_0x25c2cd){return this['HAS_NATIVE_SUPPORT']&&!_0x25c2cd?atob(_0x16e1a7):Za(this['decodeStringToByteArray'](_0x16e1a7,_0x25c2cd));},'decodeStringToByteArray'(_0x48b322,_0xa13c9){this['init_']();const _0x35cea0=_0xa13c9?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1a9fc4=[];for(let _0x5ce4e5=0x0;_0x5ce4e5<_0x48b322['length'];){const _0x3a69ea=_0x35cea0[_0x48b322['charAt'](_0x5ce4e5++)],_0x220114=_0x5ce4e5<_0x48b322['length']?_0x35cea0[_0x48b322['charAt'](_0x5ce4e5)]:0x0;++_0x5ce4e5;const _0x211c28=_0x5ce4e5<_0x48b322['length']?_0x35cea0[_0x48b322['charAt'](_0x5ce4e5)]:0x40;++_0x5ce4e5;const _0x121031=_0x5ce4e5<_0x48b322['length']?_0x35cea0[_0x48b322['charAt'](_0x5ce4e5)]:0x40;if(++_0x5ce4e5,_0x3a69ea==null||_0x220114==null||_0x211c28==null||_0x121031==null)throw new ec();const _0x85271b=_0x3a69ea<<0x2|_0x220114>>0x4;if(_0x1a9fc4['push'](_0x85271b),_0x211c28!==0x40){const _0x1e1a3c=_0x220114<<0x4&0xf0|_0x211c28>>0x2;if(_0x1a9fc4['push'](_0x1e1a3c),_0x121031!==0x40){const _0x1f629e=_0x211c28<<0x6&0xc0|_0x121031;_0x1a9fc4['push'](_0x1f629e);}}}return _0x1a9fc4;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x29036b=0x0;_0x29036b<this['ENCODED_VALS']['length'];_0x29036b++)this['byteToCharMap_'][_0x29036b]=this['ENCODED_VALS']['charAt'](_0x29036b),this['charToByteMap_'][this['byteToCharMap_'][_0x29036b]]=_0x29036b,this['byteToCharMapWebSafe_'][_0x29036b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x29036b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x29036b]]=_0x29036b,_0x29036b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x29036b)]=_0x29036b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x29036b)]=_0x29036b);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x217f8f){const _0x817907=Wr(_0x217f8f);return Di['encodeByteArray'](_0x817907,!0x0);},an=function(_0x4b11a5){return Br(_0x4b11a5)['replace'](/\./g,'');},cn=function(_0xfab2db){try{return Di['decodeString'](_0xfab2db,!0x0);}catch(_0x440058){console['error']('base64Decode\x20failed:\x20',_0x440058);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x292bc9){return Vr(void 0x0,_0x292bc9);}function Vr(_0xb51b48,_0x556e5f){if(!(_0x556e5f instanceof Object))return _0x556e5f;switch(_0x556e5f['constructor']){case Date:const _0x205b86=_0x556e5f;return new Date(_0x205b86['getTime']());case Object:_0xb51b48===void 0x0&&(_0xb51b48={});break;case Array:_0xb51b48=[];break;default:return _0x556e5f;}for(const _0x283f0b in _0x556e5f)!_0x556e5f['hasOwnProperty'](_0x283f0b)||!nc(_0x283f0b)||(_0xb51b48[_0x283f0b]=Vr(_0xb51b48[_0x283f0b],_0x556e5f[_0x283f0b]));return _0xb51b48;}function nc(_0x3ceb86){return _0x3ceb86!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x5e62e0=As['__FIREBASE_DEFAULTS__'];if(_0x5e62e0)return JSON['parse'](_0x5e62e0);},oc=()=>{if(typeof document>'u')return;let _0x129000;try{_0x129000=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x27a34f=_0x129000&&cn(_0x129000[0x1]);return _0x27a34f&&JSON['parse'](_0x27a34f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4c1d14){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4c1d14);return;}},Hr=_0x3a4582=>{var _0x2a5455,_0x4d3f72;return(_0x4d3f72=(_0x2a5455=Mi())==null?void 0x0:_0x2a5455['emulatorHosts'])==null?void 0x0:_0x4d3f72[_0x3a4582];},ac=_0x1be680=>{const _0x19da12=Hr(_0x1be680);if(!_0x19da12)return;const _0x573c5d=_0x19da12['lastIndexOf'](':');if(_0x573c5d<=0x0||_0x573c5d+0x1===_0x19da12['length'])throw new Error('Invalid\x20host\x20'+_0x19da12+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x499632=parseInt(_0x19da12['substring'](_0x573c5d+0x1),0xa);return _0x19da12[0x0]==='['?[_0x19da12['substring'](0x1,_0x573c5d-0x1),_0x499632]:[_0x19da12['substring'](0x0,_0x573c5d),_0x499632];},$r=()=>{var _0x55d281;return(_0x55d281=Mi())==null?void 0x0:_0x55d281['config'];},Gr=_0x5d4f74=>{var _0x2daea3;return(_0x2daea3=Mi())==null?void 0x0:_0x2daea3['_'+_0x5d4f74];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x27c837,_0x39685a)=>{this['resolve']=_0x27c837,this['reject']=_0x39685a;});}['wrapCallback'](_0x152ce4){return(_0x4edda2,_0x1e6af3)=>{_0x4edda2?this['reject'](_0x4edda2):this['resolve'](_0x1e6af3),typeof _0x152ce4=='function'&&(this['promise']['catch'](()=>{}),_0x152ce4['length']===0x1?_0x152ce4(_0x4edda2):_0x152ce4(_0x4edda2,_0x1e6af3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x5ae7eb,_0x37c80a){if(_0x5ae7eb['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xcd379d={'alg':'none','type':'JWT'},_0x22d4a2=_0x37c80a||'demo-project',_0x22b2ee=_0x5ae7eb['iat']||0x0,_0x454a7d=_0x5ae7eb['sub']||_0x5ae7eb['user_id'];if(!_0x454a7d)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3bfa8d={'iss':'https://securetoken.google.com/'+_0x22d4a2,'aud':_0x22d4a2,'iat':_0x22b2ee,'exp':_0x22b2ee+0xe10,'auth_time':_0x22b2ee,'sub':_0x454a7d,'user_id':_0x454a7d,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5ae7eb};return[an(JSON['stringify'](_0xcd379d)),an(JSON['stringify'](_0x3bfa8d)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x66e4f5=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x66e4f5=='object'&&_0x66e4f5['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x335612=W();return _0x335612['indexOf']('MSIE\x20')>=0x0||_0x335612['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4db579,_0x1916ed)=>{try{let _0x2f3e95=!0x0;const _0x20eec6='validate-browser-context-for-indexeddb-analytics-module',_0x20755f=self['indexedDB']['open'](_0x20eec6);_0x20755f['onsuccess']=()=>{_0x20755f['result']['close'](),_0x2f3e95||self['indexedDB']['deleteDatabase'](_0x20eec6),_0x4db579(!0x0);},_0x20755f['onupgradeneeded']=()=>{_0x2f3e95=!0x1;},_0x20755f['onerror']=()=>{var _0x3df5fb;_0x1916ed(((_0x3df5fb=_0x20755f['error'])==null?void 0x0:_0x3df5fb['message'])||'');};}catch(_0x5bd9a8){_0x1916ed(_0x5bd9a8);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xc0c2e4,_0x3eecce,_0x3c91f9){super(_0x3eecce),this['code']=_0xc0c2e4,this['customData']=_0x3c91f9,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x157766,_0x3b422b,_0x12ce49){this['service']=_0x157766,this['serviceName']=_0x3b422b,this['errors']=_0x12ce49;}['create'](_0xf5872a,..._0x60608e){const _0x458e2d=_0x60608e[0x0]||{},_0x5376bb=this['service']+'/'+_0xf5872a,_0x4fce7a=this['errors'][_0xf5872a],_0x4ae3f3=_0x4fce7a?gc(_0x4fce7a,_0x458e2d):'Error',_0x3bc282=this['serviceName']+':\x20'+_0x4ae3f3+'\x20('+_0x5376bb+').';return new Se(_0x5376bb,_0x3bc282,_0x458e2d);}}function gc(_0x5734a3,_0x1b42c5){return _0x5734a3['replace'](mc,(_0x415f9f,_0x5a6802)=>{const _0x315feb=_0x1b42c5[_0x5a6802];return _0x315feb!=null?String(_0x315feb):'<'+_0x5a6802+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xf39f25){return JSON['parse'](_0xf39f25);}function O(_0x526fda){return JSON['stringify'](_0x526fda);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x7a03d7){let _0xcc6b6f={},_0x4836a8={},_0x2ddac6={},_0x783672='';try{const _0x30ce1e=_0x7a03d7['split']('.');_0xcc6b6f=bt(cn(_0x30ce1e[0x0])||''),_0x4836a8=bt(cn(_0x30ce1e[0x1])||''),_0x783672=_0x30ce1e[0x2],_0x2ddac6=_0x4836a8['d']||{},delete _0x4836a8['d'];}catch{}return{'header':_0xcc6b6f,'claims':_0x4836a8,'data':_0x2ddac6,'signature':_0x783672};},yc=function(_0x34342f){const _0x375363=zr(_0x34342f),_0x18df66=_0x375363['claims'];return!!_0x18df66&&typeof _0x18df66=='object'&&_0x18df66['hasOwnProperty']('iat');},vc=function(_0x220200){const _0x1ada5d=zr(_0x220200)['claims'];return typeof _0x1ada5d=='object'&&_0x1ada5d['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3724b4,_0x335ec6){return Object['prototype']['hasOwnProperty']['call'](_0x3724b4,_0x335ec6);}function Oe(_0x133e88,_0x4958e5){if(Object['prototype']['hasOwnProperty']['call'](_0x133e88,_0x4958e5))return _0x133e88[_0x4958e5];}function hi(_0x1ba5c5){for(const _0x359508 in _0x1ba5c5)if(Object['prototype']['hasOwnProperty']['call'](_0x1ba5c5,_0x359508))return!0x1;return!0x0;}function ln(_0x4c92fc,_0x21ce03,_0x1f4430){const _0x1db2d9={};for(const _0x1d2e9c in _0x4c92fc)Object['prototype']['hasOwnProperty']['call'](_0x4c92fc,_0x1d2e9c)&&(_0x1db2d9[_0x1d2e9c]=_0x21ce03['call'](_0x1f4430,_0x4c92fc[_0x1d2e9c],_0x1d2e9c,_0x4c92fc));return _0x1db2d9;}function De(_0x2b5751,_0x1fe5d4){if(_0x2b5751===_0x1fe5d4)return!0x0;const _0x49691f=Object['keys'](_0x2b5751),_0x30d53d=Object['keys'](_0x1fe5d4);for(const _0x4a3018 of _0x49691f){if(!_0x30d53d['includes'](_0x4a3018))return!0x1;const _0x30d4ab=_0x2b5751[_0x4a3018],_0x3323af=_0x1fe5d4[_0x4a3018];if(ks(_0x30d4ab)&&ks(_0x3323af)){if(!De(_0x30d4ab,_0x3323af))return!0x1;}else{if(_0x30d4ab!==_0x3323af)return!0x1;}}for(const _0x267af1 of _0x30d53d)if(!_0x49691f['includes'](_0x267af1))return!0x1;return!0x0;}function ks(_0x50d5a5){return _0x50d5a5!==null&&typeof _0x50d5a5=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1dc412){const _0x5ea48c=[];for(const [_0x579561,_0x13ea0f]of Object['entries'](_0x1dc412))Array['isArray'](_0x13ea0f)?_0x13ea0f['forEach'](_0x14d91b=>{_0x5ea48c['push'](encodeURIComponent(_0x579561)+'='+encodeURIComponent(_0x14d91b));}):_0x5ea48c['push'](encodeURIComponent(_0x579561)+'='+encodeURIComponent(_0x13ea0f));return _0x5ea48c['length']?'&'+_0x5ea48c['join']('&'):'';}function yt(_0x117a2d){const _0x27237b={};return _0x117a2d['replace'](/^\?/,'')['split']('&')['forEach'](_0xa54f93=>{if(_0xa54f93){const [_0x45db87,_0x417ef7]=_0xa54f93['split']('=');_0x27237b[decodeURIComponent(_0x45db87)]=decodeURIComponent(_0x417ef7);}}),_0x27237b;}function vt(_0x55a96a){const _0x52f3b8=_0x55a96a['indexOf']('?');if(!_0x52f3b8)return'';const _0x2d788c=_0x55a96a['indexOf']('#',_0x52f3b8);return _0x55a96a['substring'](_0x52f3b8,_0x2d788c>0x0?_0x2d788c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5b2710=0x1;_0x5b2710<this['blockSize'];++_0x5b2710)this['pad_'][_0x5b2710]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3fd90e,_0x9a162b){_0x9a162b||(_0x9a162b=0x0);const _0x144e11=this['W_'];if(typeof _0x3fd90e=='string'){for(let _0x3741fc=0x0;_0x3741fc<0x10;_0x3741fc++)_0x144e11[_0x3741fc]=_0x3fd90e['charCodeAt'](_0x9a162b)<<0x18|_0x3fd90e['charCodeAt'](_0x9a162b+0x1)<<0x10|_0x3fd90e['charCodeAt'](_0x9a162b+0x2)<<0x8|_0x3fd90e['charCodeAt'](_0x9a162b+0x3),_0x9a162b+=0x4;}else{for(let _0x4dd557=0x0;_0x4dd557<0x10;_0x4dd557++)_0x144e11[_0x4dd557]=_0x3fd90e[_0x9a162b]<<0x18|_0x3fd90e[_0x9a162b+0x1]<<0x10|_0x3fd90e[_0x9a162b+0x2]<<0x8|_0x3fd90e[_0x9a162b+0x3],_0x9a162b+=0x4;}for(let _0x4d53aa=0x10;_0x4d53aa<0x50;_0x4d53aa++){const _0x497180=_0x144e11[_0x4d53aa-0x3]^_0x144e11[_0x4d53aa-0x8]^_0x144e11[_0x4d53aa-0xe]^_0x144e11[_0x4d53aa-0x10];_0x144e11[_0x4d53aa]=(_0x497180<<0x1|_0x497180>>>0x1f)&0xffffffff;}let _0x1eee0a=this['chain_'][0x0],_0x5196c9=this['chain_'][0x1],_0x5ab91c=this['chain_'][0x2],_0x495e26=this['chain_'][0x3],_0x13b704=this['chain_'][0x4],_0x2d6dc4,_0x4d1cbf;for(let _0x28086c=0x0;_0x28086c<0x50;_0x28086c++){_0x28086c<0x28?_0x28086c<0x14?(_0x2d6dc4=_0x495e26^_0x5196c9&(_0x5ab91c^_0x495e26),_0x4d1cbf=0x5a827999):(_0x2d6dc4=_0x5196c9^_0x5ab91c^_0x495e26,_0x4d1cbf=0x6ed9eba1):_0x28086c<0x3c?(_0x2d6dc4=_0x5196c9&_0x5ab91c|_0x495e26&(_0x5196c9|_0x5ab91c),_0x4d1cbf=0x8f1bbcdc):(_0x2d6dc4=_0x5196c9^_0x5ab91c^_0x495e26,_0x4d1cbf=0xca62c1d6);const _0x29b2a3=(_0x1eee0a<<0x5|_0x1eee0a>>>0x1b)+_0x2d6dc4+_0x13b704+_0x4d1cbf+_0x144e11[_0x28086c]&0xffffffff;_0x13b704=_0x495e26,_0x495e26=_0x5ab91c,_0x5ab91c=(_0x5196c9<<0x1e|_0x5196c9>>>0x2)&0xffffffff,_0x5196c9=_0x1eee0a,_0x1eee0a=_0x29b2a3;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1eee0a&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5196c9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5ab91c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x495e26&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x13b704&0xffffffff;}['update'](_0xba79,_0x24002){if(_0xba79==null)return;_0x24002===void 0x0&&(_0x24002=_0xba79['length']);const _0x2ea134=_0x24002-this['blockSize'];let _0x3a62fe=0x0;const _0x4b6dce=this['buf_'];let _0x3116a8=this['inbuf_'];for(;_0x3a62fe<_0x24002;){if(_0x3116a8===0x0){for(;_0x3a62fe<=_0x2ea134;)this['compress_'](_0xba79,_0x3a62fe),_0x3a62fe+=this['blockSize'];}if(typeof _0xba79=='string'){for(;_0x3a62fe<_0x24002;)if(_0x4b6dce[_0x3116a8]=_0xba79['charCodeAt'](_0x3a62fe),++_0x3116a8,++_0x3a62fe,_0x3116a8===this['blockSize']){this['compress_'](_0x4b6dce),_0x3116a8=0x0;break;}}else{for(;_0x3a62fe<_0x24002;)if(_0x4b6dce[_0x3116a8]=_0xba79[_0x3a62fe],++_0x3116a8,++_0x3a62fe,_0x3116a8===this['blockSize']){this['compress_'](_0x4b6dce),_0x3116a8=0x0;break;}}}this['inbuf_']=_0x3116a8,this['total_']+=_0x24002;}['digest'](){const _0x5f04bb=[];let _0x31bf25=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xa8d35=this['blockSize']-0x1;_0xa8d35>=0x38;_0xa8d35--)this['buf_'][_0xa8d35]=_0x31bf25&0xff,_0x31bf25/=0x100;this['compress_'](this['buf_']);let _0x5e1fe2=0x0;for(let _0x435460=0x0;_0x435460<0x5;_0x435460++)for(let _0xfc3806=0x18;_0xfc3806>=0x0;_0xfc3806-=0x8)_0x5f04bb[_0x5e1fe2]=this['chain_'][_0x435460]>>_0xfc3806&0xff,++_0x5e1fe2;return _0x5f04bb;}}function Ic(_0x35abf6,_0x5920e4){const _0x9724f4=new wc(_0x35abf6,_0x5920e4);return _0x9724f4['subscribe']['bind'](_0x9724f4);}class wc{constructor(_0x588b78,_0x510479){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x510479,this['task']['then'](()=>{_0x588b78(this);})['catch'](_0x4bc165=>{this['error'](_0x4bc165);});}['next'](_0x1b7072){this['forEachObserver'](_0x42bea6=>{_0x42bea6['next'](_0x1b7072);});}['error'](_0x4151d4){this['forEachObserver'](_0x4eb6e0=>{_0x4eb6e0['error'](_0x4151d4);}),this['close'](_0x4151d4);}['complete'](){this['forEachObserver'](_0x204e0b=>{_0x204e0b['complete']();}),this['close']();}['subscribe'](_0x42f384,_0x40cf1e,_0x10f9bd){let _0x25344d;if(_0x42f384===void 0x0&&_0x40cf1e===void 0x0&&_0x10f9bd===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x42f384,['next','error','complete'])?_0x25344d=_0x42f384:_0x25344d={'next':_0x42f384,'error':_0x40cf1e,'complete':_0x10f9bd},_0x25344d['next']===void 0x0&&(_0x25344d['next']=Qn),_0x25344d['error']===void 0x0&&(_0x25344d['error']=Qn),_0x25344d['complete']===void 0x0&&(_0x25344d['complete']=Qn);const _0x5625e2=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x25344d['error'](this['finalError']):_0x25344d['complete']();}catch{}}),this['observers']['push'](_0x25344d),_0x5625e2;}['unsubscribeOne'](_0xfd24a8){this['observers']===void 0x0||this['observers'][_0xfd24a8]===void 0x0||(delete this['observers'][_0xfd24a8],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2f71ed){if(!this['finalized']){for(let _0x24792c=0x0;_0x24792c<this['observers']['length'];_0x24792c++)this['sendOne'](_0x24792c,_0x2f71ed);}}['sendOne'](_0x193b34,_0x339e1a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x193b34]!==void 0x0)try{_0x339e1a(this['observers'][_0x193b34]);}catch(_0x2a648e){typeof console<'u'&&console['error']&&console['error'](_0x2a648e);}});}['close'](_0x56add8){this['finalized']||(this['finalized']=!0x0,_0x56add8!==void 0x0&&(this['finalError']=_0x56add8),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x30c2d2,_0xa6e635){if(typeof _0x30c2d2!='object'||_0x30c2d2===null)return!0x1;for(const _0x3052be of _0xa6e635)if(_0x3052be in _0x30c2d2&&typeof _0x30c2d2[_0x3052be]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x4d67ef,_0x769bce){return _0x4d67ef+'\x20failed:\x20'+_0x769bce+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x4d0b91){const _0x43ac60=[];let _0x4b90d4=0x0;for(let _0x66f068=0x0;_0x66f068<_0x4d0b91['length'];_0x66f068++){let _0xfa240d=_0x4d0b91['charCodeAt'](_0x66f068);if(_0xfa240d>=0xd800&&_0xfa240d<=0xdbff){const _0x43efc1=_0xfa240d-0xd800;_0x66f068++,f(_0x66f068<_0x4d0b91['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x146525=_0x4d0b91['charCodeAt'](_0x66f068)-0xdc00;_0xfa240d=0x10000+(_0x43efc1<<0xa)+_0x146525;}_0xfa240d<0x80?_0x43ac60[_0x4b90d4++]=_0xfa240d:_0xfa240d<0x800?(_0x43ac60[_0x4b90d4++]=_0xfa240d>>0x6|0xc0,_0x43ac60[_0x4b90d4++]=_0xfa240d&0x3f|0x80):_0xfa240d<0x10000?(_0x43ac60[_0x4b90d4++]=_0xfa240d>>0xc|0xe0,_0x43ac60[_0x4b90d4++]=_0xfa240d>>0x6&0x3f|0x80,_0x43ac60[_0x4b90d4++]=_0xfa240d&0x3f|0x80):(_0x43ac60[_0x4b90d4++]=_0xfa240d>>0x12|0xf0,_0x43ac60[_0x4b90d4++]=_0xfa240d>>0xc&0x3f|0x80,_0x43ac60[_0x4b90d4++]=_0xfa240d>>0x6&0x3f|0x80,_0x43ac60[_0x4b90d4++]=_0xfa240d&0x3f|0x80);}return _0x43ac60;},Pn=function(_0x47bcb3){let _0x19ad4b=0x0;for(let _0x21228c=0x0;_0x21228c<_0x47bcb3['length'];_0x21228c++){const _0x95a9f=_0x47bcb3['charCodeAt'](_0x21228c);_0x95a9f<0x80?_0x19ad4b++:_0x95a9f<0x800?_0x19ad4b+=0x2:_0x95a9f>=0xd800&&_0x95a9f<=0xdbff?(_0x19ad4b+=0x4,_0x21228c++):_0x19ad4b+=0x3;}return _0x19ad4b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x323236){return _0x323236&&_0x323236['_delegate']?_0x323236['_delegate']:_0x323236;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x420e10){try{return(_0x420e10['startsWith']('http://')||_0x420e10['startsWith']('https://')?new URL(_0x420e10)['hostname']:_0x420e10)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x153f76){return(await fetch(_0x153f76,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4ea9a2,_0x4f9b5b,_0x1cdc7d){this['name']=_0x4ea9a2,this['instanceFactory']=_0x4f9b5b,this['type']=_0x1cdc7d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x57af2f){return this['instantiationMode']=_0x57af2f,this;}['setMultipleInstances'](_0x51f37e){return this['multipleInstances']=_0x51f37e,this;}['setServiceProps'](_0x513541){return this['serviceProps']=_0x513541,this;}['setInstanceCreatedCallback'](_0x22058f){return this['onInstanceCreated']=_0x22058f,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xb45d5a,_0x5a7807){this['name']=_0xb45d5a,this['container']=_0x5a7807,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x18d965){const _0x40ab83=this['normalizeInstanceIdentifier'](_0x18d965);if(!this['instancesDeferred']['has'](_0x40ab83)){const _0x849a92=new Ve();if(this['instancesDeferred']['set'](_0x40ab83,_0x849a92),this['isInitialized'](_0x40ab83)||this['shouldAutoInitialize']())try{const _0x3c8fc8=this['getOrInitializeService']({'instanceIdentifier':_0x40ab83});_0x3c8fc8&&_0x849a92['resolve'](_0x3c8fc8);}catch{}}return this['instancesDeferred']['get'](_0x40ab83)['promise'];}['getImmediate'](_0x1968da){const _0xcdbdba=this['normalizeInstanceIdentifier'](_0x1968da==null?void 0x0:_0x1968da['identifier']),_0x32dfbf=(_0x1968da==null?void 0x0:_0x1968da['optional'])??!0x1;if(this['isInitialized'](_0xcdbdba)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xcdbdba});}catch(_0x18bf14){if(_0x32dfbf)return null;throw _0x18bf14;}else{if(_0x32dfbf)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x49b0d7){if(_0x49b0d7['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x49b0d7['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x49b0d7,!!this['shouldAutoInitialize']()){if(Rc(_0x49b0d7))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x192e0a,_0xf53d5]of this['instancesDeferred']['entries']()){const _0x18f0df=this['normalizeInstanceIdentifier'](_0x192e0a);try{const _0x1c4383=this['getOrInitializeService']({'instanceIdentifier':_0x18f0df});_0xf53d5['resolve'](_0x1c4383);}catch{}}}}['clearInstance'](_0x215be9=ke){this['instancesDeferred']['delete'](_0x215be9),this['instancesOptions']['delete'](_0x215be9),this['instances']['delete'](_0x215be9);}async['delete'](){const _0x33bfc8=Array['from'](this['instances']['values']());await Promise['all']([..._0x33bfc8['filter'](_0x3a2231=>'INTERNAL'in _0x3a2231)['map'](_0x21a397=>_0x21a397['INTERNAL']['delete']()),..._0x33bfc8['filter'](_0x274caf=>'_delete'in _0x274caf)['map'](_0xb1b59=>_0xb1b59['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2121bd=ke){return this['instances']['has'](_0x2121bd);}['getOptions'](_0x355e9d=ke){return this['instancesOptions']['get'](_0x355e9d)||{};}['initialize'](_0x226389={}){const {options:_0x36d999={}}=_0x226389,_0x16bab2=this['normalizeInstanceIdentifier'](_0x226389['instanceIdentifier']);if(this['isInitialized'](_0x16bab2))throw Error(this['name']+'('+_0x16bab2+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2d4ef2=this['getOrInitializeService']({'instanceIdentifier':_0x16bab2,'options':_0x36d999});for(const [_0x823b3,_0x9e9a64]of this['instancesDeferred']['entries']()){const _0x48498e=this['normalizeInstanceIdentifier'](_0x823b3);_0x16bab2===_0x48498e&&_0x9e9a64['resolve'](_0x2d4ef2);}return _0x2d4ef2;}['onInit'](_0x495094,_0x3fdc9c){const _0x39355b=this['normalizeInstanceIdentifier'](_0x3fdc9c),_0x592728=this['onInitCallbacks']['get'](_0x39355b)??new Set();_0x592728['add'](_0x495094),this['onInitCallbacks']['set'](_0x39355b,_0x592728);const _0x1413aa=this['instances']['get'](_0x39355b);return _0x1413aa&&_0x495094(_0x1413aa,_0x39355b),()=>{_0x592728['delete'](_0x495094);};}['invokeOnInitCallbacks'](_0x368454,_0x13d9b1){const _0x59c60c=this['onInitCallbacks']['get'](_0x13d9b1);if(_0x59c60c){for(const _0x3deb2f of _0x59c60c)try{_0x3deb2f(_0x368454,_0x13d9b1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3b9588,options:_0x320d94={}}){let _0x3f9a57=this['instances']['get'](_0x3b9588);if(!_0x3f9a57&&this['component']&&(_0x3f9a57=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x3b9588),'options':_0x320d94}),this['instances']['set'](_0x3b9588,_0x3f9a57),this['instancesOptions']['set'](_0x3b9588,_0x320d94),this['invokeOnInitCallbacks'](_0x3f9a57,_0x3b9588),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3b9588,_0x3f9a57);}catch{}return _0x3f9a57||null;}['normalizeInstanceIdentifier'](_0x4e77c2=ke){return this['component']?this['component']['multipleInstances']?_0x4e77c2:ke:_0x4e77c2;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x1255c1){return _0x1255c1===ke?void 0x0:_0x1255c1;}function Rc(_0x5040ad){return _0x5040ad['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x58efc5){this['name']=_0x58efc5,this['providers']=new Map();}['addComponent'](_0x3a750c){const _0x36af43=this['getProvider'](_0x3a750c['name']);if(_0x36af43['isComponentSet']())throw new Error('Component\x20'+_0x3a750c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x36af43['setComponent'](_0x3a750c);}['addOrOverwriteComponent'](_0x1ff8b8){this['getProvider'](_0x1ff8b8['name'])['isComponentSet']()&&this['providers']['delete'](_0x1ff8b8['name']),this['addComponent'](_0x1ff8b8);}['getProvider'](_0x362f47){if(this['providers']['has'](_0x362f47))return this['providers']['get'](_0x362f47);const _0x5a5925=new Sc(_0x362f47,this);return this['providers']['set'](_0x362f47,_0x5a5925),_0x5a5925;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x19a8b9){_0x19a8b9[_0x19a8b9['DEBUG']=0x0]='DEBUG',_0x19a8b9[_0x19a8b9['VERBOSE']=0x1]='VERBOSE',_0x19a8b9[_0x19a8b9['INFO']=0x2]='INFO',_0x19a8b9[_0x19a8b9['WARN']=0x3]='WARN',_0x19a8b9[_0x19a8b9['ERROR']=0x4]='ERROR',_0x19a8b9[_0x19a8b9['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x1612ed,_0x41c729,..._0x414755)=>{if(_0x41c729<_0x1612ed['logLevel'])return;const _0x2b4926=new Date()['toISOString'](),_0x1b175b=Pc[_0x41c729];if(_0x1b175b)console[_0x1b175b]('['+_0x2b4926+']\x20\x20'+_0x1612ed['name']+':',..._0x414755);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x41c729+')');};class xi{constructor(_0x596d31){this['name']=_0x596d31,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3c6ff8){if(!(_0x3c6ff8 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3c6ff8+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3c6ff8;}['setLogLevel'](_0x3ce0aa){this['_logLevel']=typeof _0x3ce0aa=='string'?kc[_0x3ce0aa]:_0x3ce0aa;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4ad1dd){if(typeof _0x4ad1dd!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4ad1dd;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2f8fdb){this['_userLogHandler']=_0x2f8fdb;}['debug'](..._0x5241b5){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5241b5),this['_logHandler'](this,T['DEBUG'],..._0x5241b5);}['log'](..._0x14d187){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x14d187),this['_logHandler'](this,T['VERBOSE'],..._0x14d187);}['info'](..._0x418113){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x418113),this['_logHandler'](this,T['INFO'],..._0x418113);}['warn'](..._0x295d92){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x295d92),this['_logHandler'](this,T['WARN'],..._0x295d92);}['error'](..._0x2caffd){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2caffd),this['_logHandler'](this,T['ERROR'],..._0x2caffd);}}const Dc=(_0x3167ee,_0x316a71)=>_0x316a71['some'](_0x17ff1e=>_0x3167ee instanceof _0x17ff1e);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2c86bd){const _0x2fb507=new Promise((_0x5014b8,_0x3a9fe8)=>{const _0x3e92be=()=>{_0x2c86bd['removeEventListener']('success',_0x4ad2ba),_0x2c86bd['removeEventListener']('error',_0x373483);},_0x4ad2ba=()=>{_0x5014b8(_e(_0x2c86bd['result'])),_0x3e92be();},_0x373483=()=>{_0x3a9fe8(_0x2c86bd['error']),_0x3e92be();};_0x2c86bd['addEventListener']('success',_0x4ad2ba),_0x2c86bd['addEventListener']('error',_0x373483);});return _0x2fb507['then'](_0x389e7d=>{_0x389e7d instanceof IDBCursor&&Kr['set'](_0x389e7d,_0x2c86bd);})['catch'](()=>{}),Fi['set'](_0x2fb507,_0x2c86bd),_0x2fb507;}function Fc(_0x44e3d9){if(ui['has'](_0x44e3d9))return;const _0x1c4ea4=new Promise((_0x218dd7,_0x23c691)=>{const _0x5117ea=()=>{_0x44e3d9['removeEventListener']('complete',_0x5e75ac),_0x44e3d9['removeEventListener']('error',_0x1dcf7d),_0x44e3d9['removeEventListener']('abort',_0x1dcf7d);},_0x5e75ac=()=>{_0x218dd7(),_0x5117ea();},_0x1dcf7d=()=>{_0x23c691(_0x44e3d9['error']||new DOMException('AbortError','AbortError')),_0x5117ea();};_0x44e3d9['addEventListener']('complete',_0x5e75ac),_0x44e3d9['addEventListener']('error',_0x1dcf7d),_0x44e3d9['addEventListener']('abort',_0x1dcf7d);});ui['set'](_0x44e3d9,_0x1c4ea4);}let di={'get'(_0x1d4d4b,_0x3cf7e6,_0x2c9c8f){if(_0x1d4d4b instanceof IDBTransaction){if(_0x3cf7e6==='done')return ui['get'](_0x1d4d4b);if(_0x3cf7e6==='objectStoreNames')return _0x1d4d4b['objectStoreNames']||Yr['get'](_0x1d4d4b);if(_0x3cf7e6==='store')return _0x2c9c8f['objectStoreNames'][0x1]?void 0x0:_0x2c9c8f['objectStore'](_0x2c9c8f['objectStoreNames'][0x0]);}return _e(_0x1d4d4b[_0x3cf7e6]);},'set'(_0x2408dd,_0x4d5ef4,_0x1cce9c){return _0x2408dd[_0x4d5ef4]=_0x1cce9c,!0x0;},'has'(_0x5f38f3,_0x19da19){return _0x5f38f3 instanceof IDBTransaction&&(_0x19da19==='done'||_0x19da19==='store')?!0x0:_0x19da19 in _0x5f38f3;}};function Uc(_0xe734c5){di=_0xe734c5(di);}function Wc(_0x25ce56){return _0x25ce56===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x42f290,..._0x5b66f8){const _0x41a897=_0x25ce56['call'](Xn(this),_0x42f290,..._0x5b66f8);return Yr['set'](_0x41a897,_0x42f290['sort']?_0x42f290['sort']():[_0x42f290]),_e(_0x41a897);}:Lc()['includes'](_0x25ce56)?function(..._0x3185fb){return _0x25ce56['apply'](Xn(this),_0x3185fb),_e(Kr['get'](this));}:function(..._0x4585a0){return _e(_0x25ce56['apply'](Xn(this),_0x4585a0));};}function Bc(_0xc7e0a9){return typeof _0xc7e0a9=='function'?Wc(_0xc7e0a9):(_0xc7e0a9 instanceof IDBTransaction&&Fc(_0xc7e0a9),Dc(_0xc7e0a9,Mc())?new Proxy(_0xc7e0a9,di):_0xc7e0a9);}function _e(_0x1a0dd7){if(_0x1a0dd7 instanceof IDBRequest)return xc(_0x1a0dd7);if(Jn['has'](_0x1a0dd7))return Jn['get'](_0x1a0dd7);const _0x5d6f05=Bc(_0x1a0dd7);return _0x5d6f05!==_0x1a0dd7&&(Jn['set'](_0x1a0dd7,_0x5d6f05),Fi['set'](_0x5d6f05,_0x1a0dd7)),_0x5d6f05;}const Xn=_0x5231f8=>Fi['get'](_0x5231f8);function Vc(_0x55a8d0,_0x5a6860,{blocked:_0x471957,upgrade:_0x176bcf,blocking:_0x277af8,terminated:_0x3e9f3d}={}){const _0x351bda=indexedDB['open'](_0x55a8d0,_0x5a6860),_0x2fad7c=_e(_0x351bda);return _0x176bcf&&_0x351bda['addEventListener']('upgradeneeded',_0x348d32=>{_0x176bcf(_e(_0x351bda['result']),_0x348d32['oldVersion'],_0x348d32['newVersion'],_e(_0x351bda['transaction']),_0x348d32);}),_0x471957&&_0x351bda['addEventListener']('blocked',_0x3841c5=>_0x471957(_0x3841c5['oldVersion'],_0x3841c5['newVersion'],_0x3841c5)),_0x2fad7c['then'](_0x3321b5=>{_0x3e9f3d&&_0x3321b5['addEventListener']('close',()=>_0x3e9f3d()),_0x277af8&&_0x3321b5['addEventListener']('versionchange',_0x3acf2a=>_0x277af8(_0x3acf2a['oldVersion'],_0x3acf2a['newVersion'],_0x3acf2a));})['catch'](()=>{}),_0x2fad7c;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0xce3fa3,_0x3ef770){if(!(_0xce3fa3 instanceof IDBDatabase&&!(_0x3ef770 in _0xce3fa3)&&typeof _0x3ef770=='string'))return;if(Zn['get'](_0x3ef770))return Zn['get'](_0x3ef770);const _0x2ec6f7=_0x3ef770['replace'](/FromIndex$/,''),_0x5bc6e0=_0x3ef770!==_0x2ec6f7,_0x3e59ce=$c['includes'](_0x2ec6f7);if(!(_0x2ec6f7 in(_0x5bc6e0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3e59ce||Hc['includes'](_0x2ec6f7)))return;const _0x557226=async function(_0x36dd62,..._0x22396e){const _0x864ce0=this['transaction'](_0x36dd62,_0x3e59ce?'readwrite':'readonly');let _0x44b276=_0x864ce0['store'];return _0x5bc6e0&&(_0x44b276=_0x44b276['index'](_0x22396e['shift']())),(await Promise['all']([_0x44b276[_0x2ec6f7](..._0x22396e),_0x3e59ce&&_0x864ce0['done']]))[0x0];};return Zn['set'](_0x3ef770,_0x557226),_0x557226;}Uc(_0x3f17f2=>({..._0x3f17f2,'get':(_0x4cd31c,_0x5792c9,_0x3d86b6)=>Os(_0x4cd31c,_0x5792c9)||_0x3f17f2['get'](_0x4cd31c,_0x5792c9,_0x3d86b6),'has':(_0x37e574,_0x4ccaef)=>!!Os(_0x37e574,_0x4ccaef)||_0x3f17f2['has'](_0x37e574,_0x4ccaef)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x4bc035){this['container']=_0x4bc035;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5ee405=>{if(qc(_0x5ee405)){const _0x33054a=_0x5ee405['getImmediate']();return _0x33054a['library']+'/'+_0x33054a['version'];}else return null;})['filter'](_0x51ce6d=>_0x51ce6d)['join']('\x20');}}function qc(_0x171c40){const _0x3edc1a=_0x171c40['getComponent']();return(_0x3edc1a==null?void 0x0:_0x3edc1a['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2376eb,_0x98c541){try{_0x2376eb['container']['addComponent'](_0x98c541);}catch(_0x2a361d){re['debug']('Component\x20'+_0x98c541['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2376eb['name'],_0x2a361d);}}function et(_0x16d5f2){const _0x3bd946=_0x16d5f2['name'];if(gi['has'](_0x3bd946))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3bd946+'.'),!0x1;gi['set'](_0x3bd946,_0x16d5f2);for(const _0x379587 of Le['values']())Ms(_0x379587,_0x16d5f2);for(const _0x3565dc of _i['values']())Ms(_0x3565dc,_0x16d5f2);return!0x0;}function Ui(_0x3c1d37,_0xf158c7){const _0x598ffd=_0x3c1d37['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x598ffd&&_0x598ffd['triggerHeartbeat'](),_0x3c1d37['container']['getProvider'](_0xf158c7);}function H(_0x45d7d8){return _0x45d7d8==null?!0x1:_0x45d7d8['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5050b1,_0x2d590a,_0x30cf61){this['_isDeleted']=!0x1,this['_options']={..._0x5050b1},this['_config']={..._0x2d590a},this['_name']=_0x2d590a['name'],this['_automaticDataCollectionEnabled']=_0x2d590a['automaticDataCollectionEnabled'],this['_container']=_0x30cf61,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3a91bf){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3a91bf;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x572462){this['_isDeleted']=_0x572462;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x1029e5,_0x212479={}){let _0x11adc4=_0x1029e5;typeof _0x212479!='object'&&(_0x212479={'name':_0x212479});const _0x2b6e90={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x212479},_0x4df6e0=_0x2b6e90['name'];if(typeof _0x4df6e0!='string'||!_0x4df6e0)throw ge['create']('bad-app-name',{'appName':String(_0x4df6e0)});if(_0x11adc4||(_0x11adc4=$r()),!_0x11adc4)throw ge['create']('no-options');const _0x48823d=Le['get'](_0x4df6e0);if(_0x48823d){if(De(_0x11adc4,_0x48823d['options'])&&De(_0x2b6e90,_0x48823d['config']))return _0x48823d;throw ge['create']('duplicate-app',{'appName':_0x4df6e0});}const _0x1d5e2d=new Ac(_0x4df6e0);for(const _0x1387e7 of gi['values']())_0x1d5e2d['addComponent'](_0x1387e7);const _0x5ec26d=new Il(_0x11adc4,_0x2b6e90,_0x1d5e2d);return Le['set'](_0x4df6e0,_0x5ec26d),_0x5ec26d;}function Qr(_0x5c8ee6=pi){const _0x5c91dc=Le['get'](_0x5c8ee6);if(!_0x5c91dc&&_0x5c8ee6===pi&&$r())return wl();if(!_0x5c91dc)throw ge['create']('no-app',{'appName':_0x5c8ee6});return _0x5c91dc;}function l_(){return Array['from'](Le['values']());}async function h_(_0x531553){let _0x1d80c3=!0x1;const _0x5adb45=_0x531553['name'];Le['has'](_0x5adb45)?(_0x1d80c3=!0x0,Le['delete'](_0x5adb45)):_i['has'](_0x5adb45)&&_0x531553['decRefCount']()<=0x0&&(_i['delete'](_0x5adb45),_0x1d80c3=!0x0),_0x1d80c3&&(await Promise['all'](_0x531553['container']['getProviders']()['map'](_0x50a386=>_0x50a386['delete']())),_0x531553['isDeleted']=!0x0);}function me(_0x56ee4c,_0x1d1f24,_0x1c596e){let _0x15681d=vl[_0x56ee4c]??_0x56ee4c;_0x1c596e&&(_0x15681d+='-'+_0x1c596e);const _0x30f419=_0x15681d['match'](/\s|\//),_0x34c619=_0x1d1f24['match'](/\s|\//);if(_0x30f419||_0x34c619){const _0x3d9fa6=['Unable\x20to\x20register\x20library\x20\x22'+_0x15681d+'\x22\x20with\x20version\x20\x22'+_0x1d1f24+'\x22:'];_0x30f419&&_0x3d9fa6['push']('library\x20name\x20\x22'+_0x15681d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x30f419&&_0x34c619&&_0x3d9fa6['push']('and'),_0x34c619&&_0x3d9fa6['push']('version\x20name\x20\x22'+_0x1d1f24+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3d9fa6['join']('\x20'));return;}et(new Me(_0x15681d+'-version',()=>({'library':_0x15681d,'version':_0x1d1f24}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x446dc3,_0x3d5f9c)=>{switch(_0x3d5f9c){case 0x0:try{_0x446dc3['createObjectStore'](Rt);}catch(_0x3481cc){console['warn'](_0x3481cc);}}}})['catch'](_0x821b3c=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x821b3c['message']});})),ei;}async function Sl(_0x3617d8){try{const _0x54787f=(await Jr())['transaction'](Rt),_0x578197=await _0x54787f['objectStore'](Rt)['get'](Xr(_0x3617d8));return await _0x54787f['done'],_0x578197;}catch(_0x66487){if(_0x66487 instanceof Se)re['warn'](_0x66487['message']);else{const _0x31e827=ge['create']('idb-get',{'originalErrorMessage':_0x66487==null?void 0x0:_0x66487['message']});re['warn'](_0x31e827['message']);}}}async function Ls(_0x1dd64a,_0x265b83){try{const _0x4aeb88=(await Jr())['transaction'](Rt,'readwrite');await _0x4aeb88['objectStore'](Rt)['put'](_0x265b83,Xr(_0x1dd64a)),await _0x4aeb88['done'];}catch(_0x4a75e1){if(_0x4a75e1 instanceof Se)re['warn'](_0x4a75e1['message']);else{const _0x1be9a7=ge['create']('idb-set',{'originalErrorMessage':_0x4a75e1==null?void 0x0:_0x4a75e1['message']});re['warn'](_0x1be9a7['message']);}}}function Xr(_0x46a512){return _0x46a512['name']+'!'+_0x46a512['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x5aade4){this['container']=_0x5aade4,this['_heartbeatsCache']=null;const _0x58679a=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x58679a),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x30c42c=>(this['_heartbeatsCache']=_0x30c42c,_0x30c42c));}async['triggerHeartbeat'](){var _0x116d53,_0x553e79;try{const _0x5bc435=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x35648a=xs();if(((_0x116d53=this['_heartbeatsCache'])==null?void 0x0:_0x116d53['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x553e79=this['_heartbeatsCache'])==null?void 0x0:_0x553e79['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x35648a||this['_heartbeatsCache']['heartbeats']['some'](_0x262b9c=>_0x262b9c['date']===_0x35648a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x35648a,'agent':_0x5bc435}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x214590=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x214590,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4703cb){re['warn'](_0x4703cb);}}async['getHeartbeatsHeader'](){var _0xf48cc2;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xf48cc2=this['_heartbeatsCache'])==null?void 0x0:_0xf48cc2['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5af362=xs(),{heartbeatsToSend:_0x828f2f,unsentEntries:_0x378b62}=kl(this['_heartbeatsCache']['heartbeats']),_0x4bdaed=an(JSON['stringify']({'version':0x2,'heartbeats':_0x828f2f}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5af362,_0x378b62['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x378b62,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4bdaed;}catch(_0x76c149){return re['warn'](_0x76c149),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x50b5e3,_0x3f1673=bl){const _0x2e7fcb=[];let _0x46381f=_0x50b5e3['slice']();for(const _0x553398 of _0x50b5e3){const _0x3fe67f=_0x2e7fcb['find'](_0x272919=>_0x272919['agent']===_0x553398['agent']);if(_0x3fe67f){if(_0x3fe67f['dates']['push'](_0x553398['date']),Fs(_0x2e7fcb)>_0x3f1673){_0x3fe67f['dates']['pop']();break;}}else{if(_0x2e7fcb['push']({'agent':_0x553398['agent'],'dates':[_0x553398['date']]}),Fs(_0x2e7fcb)>_0x3f1673){_0x2e7fcb['pop']();break;}}_0x46381f=_0x46381f['slice'](0x1);}return{'heartbeatsToSend':_0x2e7fcb,'unsentEntries':_0x46381f};}class Nl{constructor(_0x321b07){this['app']=_0x321b07,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x51164f=await Sl(this['app']);return _0x51164f!=null&&_0x51164f['heartbeats']?_0x51164f:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x46f6e5){if(await this['_canUseIndexedDBPromise']){const _0x45477f=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x46f6e5['lastSentHeartbeatDate']??_0x45477f['lastSentHeartbeatDate'],'heartbeats':_0x46f6e5['heartbeats']});}else return;}async['add'](_0x206d93){if(await this['_canUseIndexedDBPromise']){const _0x1bd0e8=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x206d93['lastSentHeartbeatDate']??_0x1bd0e8['lastSentHeartbeatDate'],'heartbeats':[..._0x1bd0e8['heartbeats'],..._0x206d93['heartbeats']]});}else return;}}function Fs(_0x202a9e){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x202a9e}))['length'];}function Pl(_0x3ceca5){if(_0x3ceca5['length']===0x0)return-0x1;let _0x5288e8=0x0,_0x434252=_0x3ceca5[0x0]['date'];for(let _0x4bad7b=0x1;_0x4bad7b<_0x3ceca5['length'];_0x4bad7b++)_0x3ceca5[_0x4bad7b]['date']<_0x434252&&(_0x434252=_0x3ceca5[_0x4bad7b]['date'],_0x5288e8=_0x4bad7b);return _0x5288e8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x2b7099){et(new Me('platform-logger',_0x19c287=>new Gc(_0x19c287),'PRIVATE')),et(new Me('heartbeat',_0x55976c=>new Al(_0x55976c),'PRIVATE')),me(fi,Ds,_0x2b7099),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x3784d6){Zr=_0x3784d6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x3637ca){this['domStorage_']=_0x3637ca,this['prefix_']='firebase:';}['set'](_0x1c8c3b,_0x39b32d){_0x39b32d==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1c8c3b)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1c8c3b),O(_0x39b32d));}['get'](_0x4784c9){const _0x2d7791=this['domStorage_']['getItem'](this['prefixedName_'](_0x4784c9));return _0x2d7791==null?null:bt(_0x2d7791);}['remove'](_0x2c4248){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2c4248));}['prefixedName_'](_0x4256b6){return this['prefix_']+_0x4256b6;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x478e50,_0x59867c){_0x59867c==null?delete this['cache_'][_0x478e50]:this['cache_'][_0x478e50]=_0x59867c;}['get'](_0x409ffa){return Y(this['cache_'],_0x409ffa)?this['cache_'][_0x409ffa]:null;}['remove'](_0x234cd8){delete this['cache_'][_0x234cd8];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x35448c){try{if(typeof window<'u'&&typeof window[_0x35448c]<'u'){const _0x4957dd=window[_0x35448c];return _0x4957dd['setItem']('firebase:sentinel','cache'),_0x4957dd['removeItem']('firebase:sentinel'),new xl(_0x4957dd);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x1222f4=0x1;return function(){return _0x1222f4++;};}()),no=function(_0x2829cc){const _0x5913e3=Tc(_0x2829cc),_0x102be6=new Ec();_0x102be6['update'](_0x5913e3);const _0x1abe81=_0x102be6['digest']();return Di['encodeByteArray'](_0x1abe81);},Bt=function(..._0x4763b8){let _0x3acb8c='';for(let _0x3958a6=0x0;_0x3958a6<_0x4763b8['length'];_0x3958a6++){const _0x1e674f=_0x4763b8[_0x3958a6];Array['isArray'](_0x1e674f)||_0x1e674f&&typeof _0x1e674f=='object'&&typeof _0x1e674f['length']=='number'?_0x3acb8c+=Bt['apply'](null,_0x1e674f):typeof _0x1e674f=='object'?_0x3acb8c+=O(_0x1e674f):_0x3acb8c+=_0x1e674f,_0x3acb8c+='\x20';}return _0x3acb8c;};let Et=null,Vs=!0x0;const Wl=function(_0x12087f,_0x4880ef){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x4521a2){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x42eaa7=Bt['apply'](null,_0x4521a2);Et(_0x42eaa7);}},Vt=function(_0x4ab647){return function(..._0x19dfcf){L(_0x4ab647,..._0x19dfcf);};},mi=function(..._0xda586f){const _0x1646eb='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0xda586f);Qe['error'](_0x1646eb);},oe=function(..._0x3d347c){const _0x2acb54='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x3d347c);throw Qe['error'](_0x2acb54),new Error(_0x2acb54);},U=function(..._0x5b46ad){const _0x376084='FIREBASE\x20WARNING:\x20'+Bt(..._0x5b46ad);Qe['warn'](_0x376084);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x5b575b){return typeof _0x5b575b=='number'&&(_0x5b575b!==_0x5b575b||_0x5b575b===Number['POSITIVE_INFINITY']||_0x5b575b===Number['NEGATIVE_INFINITY']);},Vl=function(_0x1cc5f2){if(document['readyState']==='complete')_0x1cc5f2();else{let _0xc7ebcf=!0x1;const _0x435d88=function(){if(!document['body']){setTimeout(_0x435d88,Math['floor'](0xa));return;}_0xc7ebcf||(_0xc7ebcf=!0x0,_0x1cc5f2());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x435d88,!0x1),window['addEventListener']('load',_0x435d88,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x435d88();}),window['attachEvent']('onload',_0x435d88));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2e4d05,_0x3d4a62){if(_0x2e4d05===_0x3d4a62)return 0x0;if(_0x2e4d05===xe||_0x3d4a62===Ie)return-0x1;if(_0x3d4a62===xe||_0x2e4d05===Ie)return 0x1;{const _0x1181a3=Hs(_0x2e4d05),_0x1942e1=Hs(_0x3d4a62);return _0x1181a3!==null?_0x1942e1!==null?_0x1181a3-_0x1942e1===0x0?_0x2e4d05['length']-_0x3d4a62['length']:_0x1181a3-_0x1942e1:-0x1:_0x1942e1!==null?0x1:_0x2e4d05<_0x3d4a62?-0x1:0x1;}},Hl=function(_0x2b23d1,_0x40a766){return _0x2b23d1===_0x40a766?0x0:_0x2b23d1<_0x40a766?-0x1:0x1;},pt=function(_0x3d4c8b,_0x34db6a){if(_0x34db6a&&_0x3d4c8b in _0x34db6a)return _0x34db6a[_0x3d4c8b];throw new Error('Missing\x20required\x20key\x20('+_0x3d4c8b+')\x20in\x20object:\x20'+O(_0x34db6a));},Bi=function(_0x5023cb){if(typeof _0x5023cb!='object'||_0x5023cb===null)return O(_0x5023cb);const _0xe915a1=[];for(const _0xa3191a in _0x5023cb)_0xe915a1['push'](_0xa3191a);_0xe915a1['sort']();let _0x512b28='{';for(let _0x62305b=0x0;_0x62305b<_0xe915a1['length'];_0x62305b++)_0x62305b!==0x0&&(_0x512b28+=','),_0x512b28+=O(_0xe915a1[_0x62305b]),_0x512b28+=':',_0x512b28+=Bi(_0x5023cb[_0xe915a1[_0x62305b]]);return _0x512b28+='}',_0x512b28;},io=function(_0x2c476f,_0x5d9b83){const _0x4910c5=_0x2c476f['length'];if(_0x4910c5<=_0x5d9b83)return[_0x2c476f];const _0x98fab9=[];for(let _0x110b3c=0x0;_0x110b3c<_0x4910c5;_0x110b3c+=_0x5d9b83)_0x110b3c+_0x5d9b83>_0x4910c5?_0x98fab9['push'](_0x2c476f['substring'](_0x110b3c,_0x4910c5)):_0x98fab9['push'](_0x2c476f['substring'](_0x110b3c,_0x110b3c+_0x5d9b83));return _0x98fab9;};function x(_0x3f4d62,_0x3ddbb2){for(const _0xbc558c in _0x3f4d62)_0x3f4d62['hasOwnProperty'](_0xbc558c)&&_0x3ddbb2(_0xbc558c,_0x3f4d62[_0xbc558c]);}const so=function(_0x374722){f(!Wi(_0x374722),'Invalid\x20JSON\x20number');const _0x43f600=0xb,_0x51916b=0x34,_0x439c1e=(0x1<<_0x43f600-0x1)-0x1;let _0x512901,_0x4ed540,_0xfeb11c,_0x1c7148,_0x331dc4;_0x374722===0x0?(_0x4ed540=0x0,_0xfeb11c=0x0,_0x512901=0x1/_0x374722===-0x1/0x0?0x1:0x0):(_0x512901=_0x374722<0x0,_0x374722=Math['abs'](_0x374722),_0x374722>=Math['pow'](0x2,0x1-_0x439c1e)?(_0x1c7148=Math['min'](Math['floor'](Math['log'](_0x374722)/Math['LN2']),_0x439c1e),_0x4ed540=_0x1c7148+_0x439c1e,_0xfeb11c=Math['round'](_0x374722*Math['pow'](0x2,_0x51916b-_0x1c7148)-Math['pow'](0x2,_0x51916b))):(_0x4ed540=0x0,_0xfeb11c=Math['round'](_0x374722/Math['pow'](0x2,0x1-_0x439c1e-_0x51916b))));const _0x2d2790=[];for(_0x331dc4=_0x51916b;_0x331dc4;_0x331dc4-=0x1)_0x2d2790['push'](_0xfeb11c%0x2?0x1:0x0),_0xfeb11c=Math['floor'](_0xfeb11c/0x2);for(_0x331dc4=_0x43f600;_0x331dc4;_0x331dc4-=0x1)_0x2d2790['push'](_0x4ed540%0x2?0x1:0x0),_0x4ed540=Math['floor'](_0x4ed540/0x2);_0x2d2790['push'](_0x512901?0x1:0x0),_0x2d2790['reverse']();const _0xf6a1f2=_0x2d2790['join']('');let _0x5ee8e1='';for(_0x331dc4=0x0;_0x331dc4<0x40;_0x331dc4+=0x8){let _0x4d39d0=parseInt(_0xf6a1f2['substr'](_0x331dc4,0x8),0x2)['toString'](0x10);_0x4d39d0['length']===0x1&&(_0x4d39d0='0'+_0x4d39d0),_0x5ee8e1=_0x5ee8e1+_0x4d39d0;}return _0x5ee8e1['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x1576f5,_0x41f89){let _0x210662='Unknown\x20Error';_0x1576f5==='too_big'?_0x210662='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1576f5==='permission_denied'?_0x210662='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1576f5==='unavailable'&&(_0x210662='The\x20service\x20is\x20unavailable');const _0x3aec82=new Error(_0x1576f5+'\x20at\x20'+_0x41f89['_path']['toString']()+':\x20'+_0x210662);return _0x3aec82['code']=_0x1576f5['toUpperCase'](),_0x3aec82;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2d6330){if(zl['test'](_0x2d6330)){const _0x3bb14e=Number(_0x2d6330);if(_0x3bb14e>=jl&&_0x3bb14e<=Kl)return _0x3bb14e;}return null;},lt=function(_0x3e2a6e){try{_0x3e2a6e();}catch(_0x94e0bb){setTimeout(()=>{const _0x428de5=_0x94e0bb['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x428de5),_0x94e0bb;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x54e01d,_0x362107){const _0xf53e6e=setTimeout(_0x54e01d,_0x362107);return typeof _0xf53e6e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xf53e6e):typeof _0xf53e6e=='object'&&_0xf53e6e['unref']&&_0xf53e6e['unref'](),_0xf53e6e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x5cce55,_0x1ac632){this['appCheckProvider']=_0x1ac632,this['appName']=_0x5cce55['name'],H(_0x5cce55)&&_0x5cce55['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5cce55['settings']['appCheckToken']),this['appCheck']=_0x1ac632==null?void 0x0:_0x1ac632['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1ac632==null||_0x1ac632['get']()['then'](_0x569dde=>this['appCheck']=_0x569dde);}['getToken'](_0xe8ecd6){if(this['serverAppAppCheckToken']){if(_0xe8ecd6)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xe8ecd6):new Promise((_0x3bba1b,_0x28c671)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xe8ecd6)['then'](_0x3bba1b,_0x28c671):_0x3bba1b(null);},0x0);});}['addTokenChangeListener'](_0x12b347){var _0x259fc7;(_0x259fc7=this['appCheckProvider'])==null||_0x259fc7['get']()['then'](_0x52fb31=>_0x52fb31['addTokenListener'](_0x12b347));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x5d5559,_0x53cb44,_0x155df6){this['appName_']=_0x5d5559,this['firebaseOptions_']=_0x53cb44,this['authProvider_']=_0x155df6,this['auth_']=null,this['auth_']=_0x155df6['getImmediate']({'optional':!0x0}),this['auth_']||_0x155df6['onInit'](_0x573ba2=>this['auth_']=_0x573ba2);}['getToken'](_0x51bfae){return this['auth_']?this['auth_']['getToken'](_0x51bfae)['catch'](_0x3b8291=>_0x3b8291&&_0x3b8291['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3b8291)):new Promise((_0x5b6e21,_0xd7bdc1)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x51bfae)['then'](_0x5b6e21,_0xd7bdc1):_0x5b6e21(null);},0x0);});}['addTokenChangeListener'](_0x472ec7){this['auth_']?this['auth_']['addAuthTokenListener'](_0x472ec7):this['authProvider_']['get']()['then'](_0xaba63f=>_0xaba63f['addAuthTokenListener'](_0x472ec7));}['removeTokenChangeListener'](_0x39442b){this['authProvider_']['get']()['then'](_0x378a5f=>_0x378a5f['removeAuthTokenListener'](_0x39442b));}['notifyForInvalidToken'](){let _0x15ec43='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x15ec43+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x15ec43+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x15ec43+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x15ec43);}}class tn{constructor(_0x4ce37f){this['accessToken']=_0x4ce37f;}['getToken'](_0x55da43){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3e7ebd){_0x3e7ebd(this['accessToken']);}['removeTokenChangeListener'](_0x5ae973){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x40b873,_0x5955e9,_0x12c0c8,_0x1ce273,_0x3a0583=!0x1,_0x15ca9e='',_0x4a2adc=!0x1,_0x224b76=!0x1,_0x1b2487=null){this['secure']=_0x5955e9,this['namespace']=_0x12c0c8,this['webSocketOnly']=_0x1ce273,this['nodeAdmin']=_0x3a0583,this['persistenceKey']=_0x15ca9e,this['includeNamespaceInQueryParams']=_0x4a2adc,this['isUsingEmulator']=_0x224b76,this['emulatorOptions']=_0x1b2487,this['_host']=_0x40b873['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x40b873)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x115573){_0x115573!==this['internalHost']&&(this['internalHost']=_0x115573,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3141cc=this['toURLString']();return this['persistenceKey']&&(_0x3141cc+='<'+this['persistenceKey']+'>'),_0x3141cc;}['toURLString'](){const _0x129e15=this['secure']?'https://':'http://',_0x207cf0=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x129e15+this['host']+'/'+_0x207cf0;}}function Xl(_0x7c9fc1){return _0x7c9fc1['host']!==_0x7c9fc1['internalHost']||_0x7c9fc1['isCustomHost']()||_0x7c9fc1['includeNamespaceInQueryParams'];}function go(_0x3bbd31,_0x241ce1,_0x3b8c3d){f(typeof _0x241ce1=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3b8c3d=='object','typeof\x20params\x20must\x20==\x20object');let _0x33acc5;if(_0x241ce1===fo)_0x33acc5=(_0x3bbd31['secure']?'wss://':'ws://')+_0x3bbd31['internalHost']+'/.ws?';else{if(_0x241ce1===po)_0x33acc5=(_0x3bbd31['secure']?'https://':'http://')+_0x3bbd31['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x241ce1);}Xl(_0x3bbd31)&&(_0x3b8c3d['ns']=_0x3bbd31['namespace']);const _0x5e6d71=[];return x(_0x3b8c3d,(_0x403085,_0x4979ad)=>{_0x5e6d71['push'](_0x403085+'='+_0x4979ad);}),_0x33acc5+_0x5e6d71['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x4a5404,_0x3bdea8=0x1){Y(this['counters_'],_0x4a5404)||(this['counters_'][_0x4a5404]=0x0),this['counters_'][_0x4a5404]+=_0x3bdea8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x1d6c47){const _0x2abcd4=_0x1d6c47['toString']();return ti[_0x2abcd4]||(ti[_0x2abcd4]=new Zl()),ti[_0x2abcd4];}function eh(_0x1cd63b,_0x277ad8){const _0x1f62dd=_0x1cd63b['toString']();return ni[_0x1f62dd]||(ni[_0x1f62dd]=_0x277ad8()),ni[_0x1f62dd];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x297793){this['onMessage_']=_0x297793,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x8b438c,_0x39a692){this['closeAfterResponse']=_0x8b438c,this['onClose']=_0x39a692,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xdd3b5f,_0x3400b8){for(this['pendingResponses'][_0xdd3b5f]=_0x3400b8;this['pendingResponses'][this['currentResponseNum']];){const _0x5ca394=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4d90d8=0x0;_0x4d90d8<_0x5ca394['length'];++_0x4d90d8)_0x5ca394[_0x4d90d8]&&lt(()=>{this['onMessage_'](_0x5ca394[_0x4d90d8]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1a1c00,_0x1dc487,_0x4debf9,_0x1bfb92,_0x3f621a,_0x16ddd3,_0x29e4ff){this['connId']=_0x1a1c00,this['repoInfo']=_0x1dc487,this['applicationId']=_0x4debf9,this['appCheckToken']=_0x1bfb92,this['authToken']=_0x3f621a,this['transportSessionId']=_0x16ddd3,this['lastSessionId']=_0x29e4ff,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1a1c00),this['stats_']=Hi(_0x1dc487),this['urlFn']=_0x48812f=>(this['appCheckToken']&&(_0x48812f[yi]=this['appCheckToken']),go(_0x1dc487,po,_0x48812f));}['open'](_0x1f2141,_0x2f334e){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2f334e,this['myPacketOrderer']=new th(_0x1f2141),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x567884)=>{const [_0x286447,_0x6227d4,_0xfcecb3,_0x59f055,_0x1495ff]=_0x567884;if(this['incrementIncomingBytes_'](_0x567884),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x286447===$s)this['id']=_0x6227d4,this['password']=_0xfcecb3;else{if(_0x286447===nh)_0x6227d4?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x6227d4,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x286447);}}},(..._0xf7e89d)=>{const [_0x1207b0,_0x56eaf2]=_0xf7e89d;this['incrementIncomingBytes_'](_0xf7e89d),this['myPacketOrderer']['handleResponse'](_0x1207b0,_0x56eaf2);},()=>{this['onClosed_']();},this['urlFn']);const _0x1d7c51={};_0x1d7c51[$s]='t',_0x1d7c51[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1d7c51[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1d7c51[ro]=Vi,this['transportSessionId']&&(_0x1d7c51[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1d7c51[ho]=this['lastSessionId']),this['applicationId']&&(_0x1d7c51[uo]=this['applicationId']),this['appCheckToken']&&(_0x1d7c51[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1d7c51[ao]=co);const _0x4b948d=this['urlFn'](_0x1d7c51);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4b948d),this['scriptTagHolder']['addTag'](_0x4b948d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x53478c){const _0x5c366f=O(_0x53478c);this['bytesSent']+=_0x5c366f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5c366f['length']);const _0xf37fb7=Br(_0x5c366f),_0x2a90e4=io(_0xf37fb7,hh);for(let _0x320840=0x0;_0x320840<_0x2a90e4['length'];_0x320840++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2a90e4['length'],_0x2a90e4[_0x320840]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x38d7d1,_0x3a02ac){this['myDisconnFrame']=document['createElement']('iframe');const _0x554634={};_0x554634[lh]='t',_0x554634[mo]=_0x38d7d1,_0x554634[yo]=_0x3a02ac,this['myDisconnFrame']['src']=this['urlFn'](_0x554634),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3ab085){const _0x21f5b8=O(_0x3ab085)['length'];this['bytesReceived']+=_0x21f5b8,this['stats_']['incrementCounter']('bytes_received',_0x21f5b8);}}class $i{constructor(_0x37e8af,_0x263044,_0x653e32,_0x1d2f22){this['onDisconnect']=_0x653e32,this['urlFn']=_0x1d2f22,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x37e8af,window[sh+this['uniqueCallbackIdentifier']]=_0x263044,this['myIFrame']=$i['createIFrame_']();let _0x4509ab='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4509ab='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5d44d3='<html><body>'+_0x4509ab+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5d44d3),this['myIFrame']['doc']['close']();}catch(_0x176e32){L('frame\x20writing\x20exception'),_0x176e32['stack']&&L(_0x176e32['stack']),L(_0x176e32);}}}static['createIFrame_'](){const _0x4ab482=document['createElement']('iframe');if(_0x4ab482['style']['display']='none',document['body']){document['body']['appendChild'](_0x4ab482);try{_0x4ab482['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2a205c=document['domain'];_0x4ab482['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2a205c+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4ab482['contentDocument']?_0x4ab482['doc']=_0x4ab482['contentDocument']:_0x4ab482['contentWindow']?_0x4ab482['doc']=_0x4ab482['contentWindow']['document']:_0x4ab482['document']&&(_0x4ab482['doc']=_0x4ab482['document']),_0x4ab482;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1fe43e=this['onDisconnect'];_0x1fe43e&&(this['onDisconnect']=null,_0x1fe43e());}['startLongPoll'](_0x12f7d7,_0x49cf95){for(this['myID']=_0x12f7d7,this['myPW']=_0x49cf95,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x150167={};_0x150167[mo]=this['myID'],_0x150167[yo]=this['myPW'],_0x150167[vo]=this['currentSerial'];let _0x3222b6=this['urlFn'](_0x150167),_0xb2a0a1='',_0x357c09=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0xb2a0a1['length']<=Eo;){const _0x1a8c3c=this['pendingSegs']['shift']();_0xb2a0a1=_0xb2a0a1+'&'+oh+_0x357c09+'='+_0x1a8c3c['seg']+'&'+ah+_0x357c09+'='+_0x1a8c3c['ts']+'&'+ch+_0x357c09+'='+_0x1a8c3c['d'],_0x357c09++;}return _0x3222b6=_0x3222b6+_0xb2a0a1,this['addLongPollTag_'](_0x3222b6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x598b27,_0x40d502,_0x30d742){this['pendingSegs']['push']({'seg':_0x598b27,'ts':_0x40d502,'d':_0x30d742}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x509831,_0xe7cae8){this['outstandingRequests']['add'](_0xe7cae8);const _0x1222c1=()=>{this['outstandingRequests']['delete'](_0xe7cae8),this['newRequest_']();},_0x44afb1=setTimeout(_0x1222c1,Math['floor'](uh)),_0x4f459=()=>{clearTimeout(_0x44afb1),_0x1222c1();};this['addTag'](_0x509831,_0x4f459);}['addTag'](_0x3bfe04,_0x34d903){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xb70dfb=this['myIFrame']['doc']['createElement']('script');_0xb70dfb['type']='text/javascript',_0xb70dfb['async']=!0x0,_0xb70dfb['src']=_0x3bfe04,_0xb70dfb['onload']=_0xb70dfb['onreadystatechange']=function(){const _0x3ce5a6=_0xb70dfb['readyState'];(!_0x3ce5a6||_0x3ce5a6==='loaded'||_0x3ce5a6==='complete')&&(_0xb70dfb['onload']=_0xb70dfb['onreadystatechange']=null,_0xb70dfb['parentNode']&&_0xb70dfb['parentNode']['removeChild'](_0xb70dfb),_0x34d903());},_0xb70dfb['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3bfe04),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xb70dfb);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x481c64,_0x26ee28,_0x267a26,_0x4d94af,_0x4d2adc,_0x973fb2,_0x2e0fa2){this['connId']=_0x481c64,this['applicationId']=_0x267a26,this['appCheckToken']=_0x4d94af,this['authToken']=_0x4d2adc,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x26ee28),this['connURL']=G['connectionURL_'](_0x26ee28,_0x973fb2,_0x2e0fa2,_0x4d94af,_0x267a26),this['nodeAdmin']=_0x26ee28['nodeAdmin'];}static['connectionURL_'](_0x7d88b,_0x297ce2,_0x4a0576,_0x51cd56,_0x5d0feb){const _0x46d31c={};return _0x46d31c[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x46d31c[ao]=co),_0x297ce2&&(_0x46d31c[oo]=_0x297ce2),_0x4a0576&&(_0x46d31c[ho]=_0x4a0576),_0x51cd56&&(_0x46d31c[yi]=_0x51cd56),_0x5d0feb&&(_0x46d31c[uo]=_0x5d0feb),go(_0x7d88b,fo,_0x46d31c);}['open'](_0x400fd5,_0x2efa49){this['onDisconnect']=_0x2efa49,this['onMessage']=_0x400fd5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x4e8715;dc(),this['mySock']=new hn(this['connURL'],[],_0x4e8715);}catch(_0x5a0e28){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x40aab6=_0x5a0e28['message']||_0x5a0e28['data'];_0x40aab6&&this['log_'](_0x40aab6),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x50a79f=>{this['handleIncomingFrame'](_0x50a79f);},this['mySock']['onerror']=_0x2857b5=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2cd0f4=_0x2857b5['message']||_0x2857b5['data'];_0x2cd0f4&&this['log_'](_0x2cd0f4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x44fa64=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5d83e4=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xcfd206=navigator['userAgent']['match'](_0x5d83e4);_0xcfd206&&_0xcfd206['length']>0x1&&parseFloat(_0xcfd206[0x1])<4.4&&(_0x44fa64=!0x0);}return!_0x44fa64&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x308796){if(this['frames']['push'](_0x308796),this['frames']['length']===this['totalFrames']){const _0x2aad93=this['frames']['join']('');this['frames']=null;const _0x390861=bt(_0x2aad93);this['onMessage'](_0x390861);}}['handleNewFrameCount_'](_0x495762){this['totalFrames']=_0x495762,this['frames']=[];}['extractFrameCount_'](_0x2c900e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2c900e['length']<=0x6){const _0xe7d8e8=Number(_0x2c900e);if(!isNaN(_0xe7d8e8))return this['handleNewFrameCount_'](_0xe7d8e8),null;}return this['handleNewFrameCount_'](0x1),_0x2c900e;}['handleIncomingFrame'](_0x5cf2a3){if(this['mySock']===null)return;const _0x13622b=_0x5cf2a3['data'];if(this['bytesReceived']+=_0x13622b['length'],this['stats_']['incrementCounter']('bytes_received',_0x13622b['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x13622b);else{const _0x281c9d=this['extractFrameCount_'](_0x13622b);_0x281c9d!==null&&this['appendFrame_'](_0x281c9d);}}['send'](_0x3aebf4){this['resetKeepAlive']();const _0x1993a3=O(_0x3aebf4);this['bytesSent']+=_0x1993a3['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1993a3['length']);const _0x28fca0=io(_0x1993a3,fh);_0x28fca0['length']>0x1&&this['sendString_'](String(_0x28fca0['length']));for(let _0x30dbf1=0x0;_0x30dbf1<_0x28fca0['length'];_0x30dbf1++)this['sendString_'](_0x28fca0[_0x30dbf1]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x1f5088){try{this['mySock']['send'](_0x1f5088);}catch(_0x1f0d5){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1f0d5['message']||_0x1f0d5['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x47f830){this['initTransports_'](_0x47f830);}['initTransports_'](_0x1bf5b6){const _0x194f89=G&&G['isAvailable']();let _0x16dc7c=_0x194f89&&!G['previouslyFailed']();if(_0x1bf5b6['webSocketOnly']&&(_0x194f89||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x16dc7c=!0x0),_0x16dc7c)this['transports_']=[G];else{const _0x266c8f=this['transports_']=[];for(const _0x30feee of At['ALL_TRANSPORTS'])_0x30feee&&_0x30feee['isAvailable']()&&_0x266c8f['push'](_0x30feee);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x46ed51,_0x522d0f,_0x191573,_0x1a5c43,_0x5c2e5f,_0x4b7194,_0x3a1bec,_0xa0d27d,_0x3b5fd8,_0x5e4388){this['id']=_0x46ed51,this['repoInfo_']=_0x522d0f,this['applicationId_']=_0x191573,this['appCheckToken_']=_0x1a5c43,this['authToken_']=_0x5c2e5f,this['onMessage_']=_0x4b7194,this['onReady_']=_0x3a1bec,this['onDisconnect_']=_0xa0d27d,this['onKill_']=_0x3b5fd8,this['lastSessionId']=_0x5e4388,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x522d0f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5d5c8f=this['transportManager_']['initialTransport']();this['conn_']=new _0x5d5c8f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5d5c8f['responsesRequiredToBeHealthy']||0x0;const _0x130e2f=this['connReceiver_'](this['conn_']),_0x3d4fd7=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x130e2f,_0x3d4fd7);},Math['floor'](0x0));const _0x3553a8=_0x5d5c8f['healthyTimeout']||0x0;_0x3553a8>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3553a8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4086f9){return _0x23c5e4=>{_0x4086f9===this['conn_']?this['onConnectionLost_'](_0x23c5e4):_0x4086f9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xdcf98e){return _0x4e6ff9=>{this['state_']!==0x2&&(_0xdcf98e===this['rx_']?this['onPrimaryMessageReceived_'](_0x4e6ff9):_0xdcf98e===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4e6ff9):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x48282f){const _0x163bec={'t':'d','d':_0x48282f};this['sendData_'](_0x163bec);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x50ecf4){if(ii in _0x50ecf4){const _0x4ca961=_0x50ecf4[ii];_0x4ca961===js?this['upgradeIfSecondaryHealthy_']():_0x4ca961===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4ca961===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xc1fae){const _0x3a3da3=pt('t',_0xc1fae),_0x667866=pt('d',_0xc1fae);if(_0x3a3da3==='c')this['onSecondaryControl_'](_0x667866);else{if(_0x3a3da3==='d')this['pendingDataMessages']['push'](_0x667866);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3a3da3);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x178409){const _0x27a982=pt('t',_0x178409),_0x582a30=pt('d',_0x178409);_0x27a982==='c'?this['onControl_'](_0x582a30):_0x27a982==='d'&&this['onDataMessage_'](_0x582a30);}['onDataMessage_'](_0x1f2d0e){this['onPrimaryResponse_'](),this['onMessage_'](_0x1f2d0e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x90fd99){const _0x552b6f=pt(ii,_0x90fd99);if(Gs in _0x90fd99){const _0x1685ce=_0x90fd99[Gs];if(_0x552b6f===Ih){const _0x19392e={..._0x1685ce};this['repoInfo_']['isUsingEmulator']&&(_0x19392e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x19392e);}else{if(_0x552b6f===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1624f4=0x0;_0x1624f4<this['pendingDataMessages']['length'];++_0x1624f4)this['onDataMessage_'](this['pendingDataMessages'][_0x1624f4]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x552b6f===vh?this['onConnectionShutdown_'](_0x1685ce):_0x552b6f===qs?this['onReset_'](_0x1685ce):_0x552b6f===Eh?mi('Server\x20Error:\x20'+_0x1685ce):_0x552b6f===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x552b6f);}}}['onHandshake_'](_0x2192cc){const _0x295292=_0x2192cc['ts'],_0x436fd1=_0x2192cc['v'],_0x58efd7=_0x2192cc['h'];this['sessionId']=_0x2192cc['s'],this['repoInfo_']['host']=_0x58efd7,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x295292),Vi!==_0x436fd1&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x17a02b=this['transportManager_']['upgradeTransport']();_0x17a02b&&this['startUpgrade_'](_0x17a02b);}['startUpgrade_'](_0x37c4c9){this['secondaryConn_']=new _0x37c4c9(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x37c4c9['responsesRequiredToBeHealthy']||0x0;const _0x516af7=this['connReceiver_'](this['secondaryConn_']),_0x485ede=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x516af7,_0x485ede),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x292a01){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x292a01),this['repoInfo_']['host']=_0x292a01,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x308eac,_0x1e19ab){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x308eac,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1e19ab,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x47ab63=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x47ab63||this['rx_']===_0x47ab63)&&this['close']();}['onConnectionLost_'](_0x263271){this['conn_']=null,!_0x263271&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2d2925){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2d2925),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xde0d69){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xde0d69);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x4ca841,_0x1b6d18,_0x52cdb1,_0x3444ca){}['merge'](_0x120018,_0x5c76ba,_0x499f68,_0x3d1e1a){}['refreshAuthToken'](_0x24a60c){}['refreshAppCheckToken'](_0x166b2c){}['onDisconnectPut'](_0x5f2aef,_0x2b6d3f,_0x37ef36){}['onDisconnectMerge'](_0x568533,_0x17dae9,_0x189517){}['onDisconnectCancel'](_0x478835,_0x2de60d){}['reportStats'](_0xb6c317){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x3151fa){this['allowedEvents_']=_0x3151fa,this['listeners_']={},f(Array['isArray'](_0x3151fa)&&_0x3151fa['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4bc4eb,..._0x1ae7d4){if(Array['isArray'](this['listeners_'][_0x4bc4eb])){const _0xdb7126=[...this['listeners_'][_0x4bc4eb]];for(let _0x122678=0x0;_0x122678<_0xdb7126['length'];_0x122678++)_0xdb7126[_0x122678]['callback']['apply'](_0xdb7126[_0x122678]['context'],_0x1ae7d4);}}['on'](_0x21bf67,_0x4d211b,_0x21f452){this['validateEventType_'](_0x21bf67),this['listeners_'][_0x21bf67]=this['listeners_'][_0x21bf67]||[],this['listeners_'][_0x21bf67]['push']({'callback':_0x4d211b,'context':_0x21f452});const _0x1668ca=this['getInitialEvent'](_0x21bf67);_0x1668ca&&_0x4d211b['apply'](_0x21f452,_0x1668ca);}['off'](_0x2cc85d,_0xb59b2b,_0x32afd1){this['validateEventType_'](_0x2cc85d);const _0x4f9e19=this['listeners_'][_0x2cc85d]||[];for(let _0x4b1b70=0x0;_0x4b1b70<_0x4f9e19['length'];_0x4b1b70++)if(_0x4f9e19[_0x4b1b70]['callback']===_0xb59b2b&&(!_0x32afd1||_0x32afd1===_0x4f9e19[_0x4b1b70]['context'])){_0x4f9e19['splice'](_0x4b1b70,0x1);return;}}['validateEventType_'](_0x170ae9){f(this['allowedEvents_']['find'](_0x283cff=>_0x283cff===_0x170ae9),'Unknown\x20event:\x20'+_0x170ae9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1413d3){return f(_0x1413d3==='online','Unknown\x20event\x20type:\x20'+_0x1413d3),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x3612c9,_0xa26ee2){if(_0xa26ee2===void 0x0){this['pieces_']=_0x3612c9['split']('/');let _0x18ba8b=0x0;for(let _0x237004=0x0;_0x237004<this['pieces_']['length'];_0x237004++)this['pieces_'][_0x237004]['length']>0x0&&(this['pieces_'][_0x18ba8b]=this['pieces_'][_0x237004],_0x18ba8b++);this['pieces_']['length']=_0x18ba8b,this['pieceNum_']=0x0;}else this['pieces_']=_0x3612c9,this['pieceNum_']=_0xa26ee2;}['toString'](){let _0x501480='';for(let _0x47f4a5=this['pieceNum_'];_0x47f4a5<this['pieces_']['length'];_0x47f4a5++)this['pieces_'][_0x47f4a5]!==''&&(_0x501480+='/'+this['pieces_'][_0x47f4a5]);return _0x501480||'/';}}function w(){return new C('');}function y(_0x5f2f3b){return _0x5f2f3b['pieceNum_']>=_0x5f2f3b['pieces_']['length']?null:_0x5f2f3b['pieces_'][_0x5f2f3b['pieceNum_']];}function we(_0x5b8c49){return _0x5b8c49['pieces_']['length']-_0x5b8c49['pieceNum_'];}function b(_0x33c711){let _0xe1d69a=_0x33c711['pieceNum_'];return _0xe1d69a<_0x33c711['pieces_']['length']&&_0xe1d69a++,new C(_0x33c711['pieces_'],_0xe1d69a);}function Gi(_0x52a0b0){return _0x52a0b0['pieceNum_']<_0x52a0b0['pieces_']['length']?_0x52a0b0['pieces_'][_0x52a0b0['pieces_']['length']-0x1]:null;}function Ch(_0x2bf6b6){let _0xb88477='';for(let _0x5ee944=_0x2bf6b6['pieceNum_'];_0x5ee944<_0x2bf6b6['pieces_']['length'];_0x5ee944++)_0x2bf6b6['pieces_'][_0x5ee944]!==''&&(_0xb88477+='/'+encodeURIComponent(String(_0x2bf6b6['pieces_'][_0x5ee944])));return _0xb88477||'/';}function kt(_0x59af54,_0x50dcd5=0x0){return _0x59af54['pieces_']['slice'](_0x59af54['pieceNum_']+_0x50dcd5);}function To(_0x5f4156){if(_0x5f4156['pieceNum_']>=_0x5f4156['pieces_']['length'])return null;const _0xa582b2=[];for(let _0x298168=_0x5f4156['pieceNum_'];_0x298168<_0x5f4156['pieces_']['length']-0x1;_0x298168++)_0xa582b2['push'](_0x5f4156['pieces_'][_0x298168]);return new C(_0xa582b2,0x0);}function A(_0x196027,_0x26a2e3){const _0x23b64e=[];for(let _0x78346f=_0x196027['pieceNum_'];_0x78346f<_0x196027['pieces_']['length'];_0x78346f++)_0x23b64e['push'](_0x196027['pieces_'][_0x78346f]);if(_0x26a2e3 instanceof C){for(let _0x5dd543=_0x26a2e3['pieceNum_'];_0x5dd543<_0x26a2e3['pieces_']['length'];_0x5dd543++)_0x23b64e['push'](_0x26a2e3['pieces_'][_0x5dd543]);}else{const _0x18ec95=_0x26a2e3['split']('/');for(let _0x1598d1=0x0;_0x1598d1<_0x18ec95['length'];_0x1598d1++)_0x18ec95[_0x1598d1]['length']>0x0&&_0x23b64e['push'](_0x18ec95[_0x1598d1]);}return new C(_0x23b64e,0x0);}function v(_0x1e5192){return _0x1e5192['pieceNum_']>=_0x1e5192['pieces_']['length'];}function F(_0x1d8f29,_0x8be043){const _0x112e2b=y(_0x1d8f29),_0x12ff01=y(_0x8be043);if(_0x112e2b===null)return _0x8be043;if(_0x112e2b===_0x12ff01)return F(b(_0x1d8f29),b(_0x8be043));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x8be043+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1d8f29+')');}function Th(_0xb62f0f,_0x57ee05){const _0x221c46=kt(_0xb62f0f,0x0),_0x545262=kt(_0x57ee05,0x0);for(let _0x27d319=0x0;_0x27d319<_0x221c46['length']&&_0x27d319<_0x545262['length'];_0x27d319++){const _0x17c829=He(_0x221c46[_0x27d319],_0x545262[_0x27d319]);if(_0x17c829!==0x0)return _0x17c829;}return _0x221c46['length']===_0x545262['length']?0x0:_0x221c46['length']<_0x545262['length']?-0x1:0x1;}function qi(_0x131d1d,_0x2c9ae7){if(we(_0x131d1d)!==we(_0x2c9ae7))return!0x1;for(let _0x4df42d=_0x131d1d['pieceNum_'],_0x4bc470=_0x2c9ae7['pieceNum_'];_0x4df42d<=_0x131d1d['pieces_']['length'];_0x4df42d++,_0x4bc470++)if(_0x131d1d['pieces_'][_0x4df42d]!==_0x2c9ae7['pieces_'][_0x4bc470])return!0x1;return!0x0;}function $(_0x4834c8,_0x32d463){let _0x6fea78=_0x4834c8['pieceNum_'],_0x370fe4=_0x32d463['pieceNum_'];if(we(_0x4834c8)>we(_0x32d463))return!0x1;for(;_0x6fea78<_0x4834c8['pieces_']['length'];){if(_0x4834c8['pieces_'][_0x6fea78]!==_0x32d463['pieces_'][_0x370fe4])return!0x1;++_0x6fea78,++_0x370fe4;}return!0x0;}class Sh{constructor(_0x7b010a,_0x3ff3ee){this['errorPrefix_']=_0x3ff3ee,this['parts_']=kt(_0x7b010a,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x37427c=0x0;_0x37427c<this['parts_']['length'];_0x37427c++)this['byteLength_']+=Pn(this['parts_'][_0x37427c]);So(this);}}function bh(_0x3d388a,_0x51d644){_0x3d388a['parts_']['length']>0x0&&(_0x3d388a['byteLength_']+=0x1),_0x3d388a['parts_']['push'](_0x51d644),_0x3d388a['byteLength_']+=Pn(_0x51d644),So(_0x3d388a);}function Rh(_0x587bec){const _0x386d57=_0x587bec['parts_']['pop']();_0x587bec['byteLength_']-=Pn(_0x386d57),_0x587bec['parts_']['length']>0x0&&(_0x587bec['byteLength_']-=0x1);}function So(_0x42d47c){if(_0x42d47c['byteLength_']>Js)throw new Error(_0x42d47c['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x42d47c['byteLength_']+').');if(_0x42d47c['parts_']['length']>Qs)throw new Error(_0x42d47c['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x42d47c));}function Ne(_0x4b383e){return _0x4b383e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4b383e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x200eca,_0x2ffb69;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2ffb69='visibilitychange',_0x200eca='hidden'):typeof document['mozHidden']<'u'?(_0x2ffb69='mozvisibilitychange',_0x200eca='mozHidden'):typeof document['msHidden']<'u'?(_0x2ffb69='msvisibilitychange',_0x200eca='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2ffb69='webkitvisibilitychange',_0x200eca='webkitHidden')),this['visible_']=!0x0,_0x2ffb69&&document['addEventListener'](_0x2ffb69,()=>{const _0x1a026f=!document[_0x200eca];_0x1a026f!==this['visible_']&&(this['visible_']=_0x1a026f,this['trigger']('visible',_0x1a026f));},!0x1);}['getInitialEvent'](_0x5b029f){return f(_0x5b029f==='visible','Unknown\x20event\x20type:\x20'+_0x5b029f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x37c3da,_0x48e5ff,_0x11ad33,_0x57f31b,_0x5ca368,_0x2b17b5,_0x47c79e,_0x59ce01){if(super(),this['repoInfo_']=_0x37c3da,this['applicationId_']=_0x48e5ff,this['onDataUpdate_']=_0x11ad33,this['onConnectStatus_']=_0x57f31b,this['onServerInfoUpdate_']=_0x5ca368,this['authTokenProvider_']=_0x2b17b5,this['appCheckTokenProvider_']=_0x47c79e,this['authOverride_']=_0x59ce01,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x59ce01)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x37c3da['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3d1c58,_0x29baed,_0x50c430){const _0xb6f00=++this['requestNumber_'],_0x55acdc={'r':_0xb6f00,'a':_0x3d1c58,'b':_0x29baed};this['log_'](O(_0x55acdc)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x55acdc),_0x50c430&&(this['requestCBHash_'][_0xb6f00]=_0x50c430);}['get'](_0x5d2529){this['initConnection_']();const _0x593ef5=new Ve(),_0x36ba72={'action':'g','request':{'p':_0x5d2529['_path']['toString'](),'q':_0x5d2529['_queryObject']},'onComplete':_0x326cd5=>{const _0x18ae5c=_0x326cd5['d'];_0x326cd5['s']==='ok'?_0x593ef5['resolve'](_0x18ae5c):_0x593ef5['reject'](_0x18ae5c);}};this['outstandingGets_']['push'](_0x36ba72),this['outstandingGetCount_']++;const _0x47461e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x47461e),_0x593ef5['promise'];}['listen'](_0x59ea3f,_0x399cf4,_0x13d35c,_0x5bfe00){this['initConnection_']();const _0x344ee1=_0x59ea3f['_queryIdentifier'],_0x1f6f03=_0x59ea3f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f6f03+'\x20'+_0x344ee1),this['listens']['has'](_0x1f6f03)||this['listens']['set'](_0x1f6f03,new Map()),f(_0x59ea3f['_queryParams']['isDefault']()||!_0x59ea3f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1f6f03)['has'](_0x344ee1),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x787adb={'onComplete':_0x5bfe00,'hashFn':_0x399cf4,'query':_0x59ea3f,'tag':_0x13d35c};this['listens']['get'](_0x1f6f03)['set'](_0x344ee1,_0x787adb),this['connected_']&&this['sendListen_'](_0x787adb);}['sendGet_'](_0xc6f8b2){const _0x570529=this['outstandingGets_'][_0xc6f8b2];this['sendRequest']('g',_0x570529['request'],_0x24c7b2=>{delete this['outstandingGets_'][_0xc6f8b2],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x570529['onComplete']&&_0x570529['onComplete'](_0x24c7b2);});}['sendListen_'](_0x54a4d4){const _0x5b01ab=_0x54a4d4['query'],_0x4abcff=_0x5b01ab['_path']['toString'](),_0x95df55=_0x5b01ab['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4abcff+'\x20for\x20'+_0x95df55);const _0x5e43c={'p':_0x4abcff},_0x3c43ce='q';_0x54a4d4['tag']&&(_0x5e43c['q']=_0x5b01ab['_queryObject'],_0x5e43c['t']=_0x54a4d4['tag']),_0x5e43c['h']=_0x54a4d4['hashFn'](),this['sendRequest'](_0x3c43ce,_0x5e43c,_0x1ab129=>{const _0xa65233=_0x1ab129['d'],_0x374741=_0x1ab129['s'];ie['warnOnListenWarnings_'](_0xa65233,_0x5b01ab),(this['listens']['get'](_0x4abcff)&&this['listens']['get'](_0x4abcff)['get'](_0x95df55))===_0x54a4d4&&(this['log_']('listen\x20response',_0x1ab129),_0x374741!=='ok'&&this['removeListen_'](_0x4abcff,_0x95df55),_0x54a4d4['onComplete']&&_0x54a4d4['onComplete'](_0x374741,_0xa65233));});}static['warnOnListenWarnings_'](_0x41deab,_0x161d66){if(_0x41deab&&typeof _0x41deab=='object'&&Y(_0x41deab,'w')){const _0x4d1b88=Oe(_0x41deab,'w');if(Array['isArray'](_0x4d1b88)&&~_0x4d1b88['indexOf']('no_index')){const _0x182030='\x22.indexOn\x22:\x20\x22'+_0x161d66['_queryParams']['getIndex']()['toString']()+'\x22',_0x36f9a3=_0x161d66['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x182030+'\x20at\x20'+_0x36f9a3+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5e2ec0){this['authToken_']=_0x5e2ec0,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5e2ec0);}['reduceReconnectDelayIfAdminCredential_'](_0x1af32c){(_0x1af32c&&_0x1af32c['length']===0x28||vc(_0x1af32c))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x224f71){this['appCheckToken_']=_0x224f71,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x34e366=this['authToken_'],_0x53208c=yc(_0x34e366)?'auth':'gauth',_0x183980={'cred':_0x34e366};this['authOverride_']===null?_0x183980['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x183980['authvar']=this['authOverride_']),this['sendRequest'](_0x53208c,_0x183980,_0x2b58ef=>{const _0x5cef98=_0x2b58ef['s'],_0x150fa2=_0x2b58ef['d']||'error';this['authToken_']===_0x34e366&&(_0x5cef98==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5cef98,_0x150fa2));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x379bc6=>{const _0x3399eb=_0x379bc6['s'],_0x6fa31=_0x379bc6['d']||'error';_0x3399eb==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3399eb,_0x6fa31);});}['unlisten'](_0x2f23a,_0x448732){const _0xd1b498=_0x2f23a['_path']['toString'](),_0x2f9038=_0x2f23a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xd1b498+'\x20'+_0x2f9038),f(_0x2f23a['_queryParams']['isDefault']()||!_0x2f23a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xd1b498,_0x2f9038)&&this['connected_']&&this['sendUnlisten_'](_0xd1b498,_0x2f9038,_0x2f23a['_queryObject'],_0x448732);}['sendUnlisten_'](_0x595f8c,_0x129819,_0x2b85ba,_0x5ca959){this['log_']('Unlisten\x20on\x20'+_0x595f8c+'\x20for\x20'+_0x129819);const _0x5b3d00={'p':_0x595f8c},_0x4d7642='n';_0x5ca959&&(_0x5b3d00['q']=_0x2b85ba,_0x5b3d00['t']=_0x5ca959),this['sendRequest'](_0x4d7642,_0x5b3d00);}['onDisconnectPut'](_0x460045,_0x2c9bd8,_0x6d09ab){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x460045,_0x2c9bd8,_0x6d09ab):this['onDisconnectRequestQueue_']['push']({'pathString':_0x460045,'action':'o','data':_0x2c9bd8,'onComplete':_0x6d09ab});}['onDisconnectMerge'](_0x512125,_0x32df5f,_0x17a71d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x512125,_0x32df5f,_0x17a71d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x512125,'action':'om','data':_0x32df5f,'onComplete':_0x17a71d});}['onDisconnectCancel'](_0x1dd27b,_0x44da63){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1dd27b,null,_0x44da63):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1dd27b,'action':'oc','data':null,'onComplete':_0x44da63});}['sendOnDisconnect_'](_0x3d3eea,_0x37ec77,_0x249ef6,_0x50a843){const _0x4459d1={'p':_0x37ec77,'d':_0x249ef6};this['log_']('onDisconnect\x20'+_0x3d3eea,_0x4459d1),this['sendRequest'](_0x3d3eea,_0x4459d1,_0x1c4357=>{_0x50a843&&setTimeout(()=>{_0x50a843(_0x1c4357['s'],_0x1c4357['d']);},Math['floor'](0x0));});}['put'](_0x341fdd,_0x8bf868,_0x4874bd,_0x2b2275){this['putInternal']('p',_0x341fdd,_0x8bf868,_0x4874bd,_0x2b2275);}['merge'](_0x1689f4,_0x174fb2,_0x3087ac,_0x55c529){this['putInternal']('m',_0x1689f4,_0x174fb2,_0x3087ac,_0x55c529);}['putInternal'](_0x3918de,_0x18af8e,_0x57ae55,_0x2900a0,_0x2e422c){this['initConnection_']();const _0x1fd100={'p':_0x18af8e,'d':_0x57ae55};_0x2e422c!==void 0x0&&(_0x1fd100['h']=_0x2e422c),this['outstandingPuts_']['push']({'action':_0x3918de,'request':_0x1fd100,'onComplete':_0x2900a0}),this['outstandingPutCount_']++;const _0x4a37b3=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4a37b3):this['log_']('Buffering\x20put:\x20'+_0x18af8e);}['sendPut_'](_0x272410){const _0xf8c963=this['outstandingPuts_'][_0x272410]['action'],_0x3d255a=this['outstandingPuts_'][_0x272410]['request'],_0x449a93=this['outstandingPuts_'][_0x272410]['onComplete'];this['outstandingPuts_'][_0x272410]['queued']=this['connected_'],this['sendRequest'](_0xf8c963,_0x3d255a,_0x53e267=>{this['log_'](_0xf8c963+'\x20response',_0x53e267),delete this['outstandingPuts_'][_0x272410],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x449a93&&_0x449a93(_0x53e267['s'],_0x53e267['d']);});}['reportStats'](_0x480aef){if(this['connected_']){const _0x19f95d={'c':_0x480aef};this['log_']('reportStats',_0x19f95d),this['sendRequest']('s',_0x19f95d,_0x2dd28a=>{if(_0x2dd28a['s']!=='ok'){const _0x1f0c78=_0x2dd28a['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x1f0c78);}});}}['onDataMessage_'](_0xb0fdb1){if('r'in _0xb0fdb1){this['log_']('from\x20server:\x20'+O(_0xb0fdb1));const _0x5d19cd=_0xb0fdb1['r'],_0x4f3701=this['requestCBHash_'][_0x5d19cd];_0x4f3701&&(delete this['requestCBHash_'][_0x5d19cd],_0x4f3701(_0xb0fdb1['b']));}else{if('error'in _0xb0fdb1)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xb0fdb1['error'];'a'in _0xb0fdb1&&this['onDataPush_'](_0xb0fdb1['a'],_0xb0fdb1['b']);}}['onDataPush_'](_0x136239,_0x1db08e){this['log_']('handleServerMessage',_0x136239,_0x1db08e),_0x136239==='d'?this['onDataUpdate_'](_0x1db08e['p'],_0x1db08e['d'],!0x1,_0x1db08e['t']):_0x136239==='m'?this['onDataUpdate_'](_0x1db08e['p'],_0x1db08e['d'],!0x0,_0x1db08e['t']):_0x136239==='c'?this['onListenRevoked_'](_0x1db08e['p'],_0x1db08e['q']):_0x136239==='ac'?this['onAuthRevoked_'](_0x1db08e['s'],_0x1db08e['d']):_0x136239==='apc'?this['onAppCheckRevoked_'](_0x1db08e['s'],_0x1db08e['d']):_0x136239==='sd'?this['onSecurityDebugPacket_'](_0x1db08e):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x136239)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5a647e,_0x51e17b){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5a647e),this['lastSessionId']=_0x51e17b,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x6c896e){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x6c896e));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1a969b){_0x1a969b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1a969b;}['onOnline_'](_0x3e1ec1){_0x3e1ec1?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x464c0d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x30ac6b=Math['max'](0x0,this['reconnectDelay_']-_0x464c0d);_0x30ac6b=Math['random']()*_0x30ac6b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x30ac6b+'ms'),this['scheduleConnect_'](_0x30ac6b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1078f0=this['onDataMessage_']['bind'](this),_0x699dca=this['onReady_']['bind'](this),_0x1b8e0d=this['onRealtimeDisconnect_']['bind'](this),_0x4c2a8c=this['id']+':'+ie['nextConnectionId_']++,_0x38fe86=this['lastSessionId'];let _0x3b444f=!0x1,_0x2f74f0=null;const _0xb945e2=function(){_0x2f74f0?_0x2f74f0['close']():(_0x3b444f=!0x0,_0x1b8e0d());},_0x3ab268=function(_0x57b7ce){f(_0x2f74f0,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2f74f0['sendRequest'](_0x57b7ce);};this['realtime_']={'close':_0xb945e2,'sendRequest':_0x3ab268};const _0x10fb74=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1dfeb,_0x1b4b9f]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x10fb74),this['appCheckTokenProvider_']['getToken'](_0x10fb74)]);_0x3b444f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1dfeb&&_0x1dfeb['accessToken'],this['appCheckToken_']=_0x1b4b9f&&_0x1b4b9f['token'],_0x2f74f0=new wh(_0x4c2a8c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1078f0,_0x699dca,_0x1b8e0d,_0x555436=>{U(_0x555436+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x38fe86));}catch(_0x83a2af){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x83a2af),_0x3b444f||(this['repoInfo_']['nodeAdmin']&&U(_0x83a2af),_0xb945e2());}}}['interrupt'](_0x5d7252){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5d7252),this['interruptReasons_'][_0x5d7252]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x115b14){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x115b14),delete this['interruptReasons_'][_0x115b14],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x798979){const _0x58e4de=_0x798979-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x58e4de});}['cancelSentTransactions_'](){for(let _0x31591f=0x0;_0x31591f<this['outstandingPuts_']['length'];_0x31591f++){const _0x16447a=this['outstandingPuts_'][_0x31591f];_0x16447a&&'h'in _0x16447a['request']&&_0x16447a['queued']&&(_0x16447a['onComplete']&&_0x16447a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x31591f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x59f404,_0x23ef01){let _0x4a5462;_0x23ef01?_0x4a5462=_0x23ef01['map'](_0x53acc0=>Bi(_0x53acc0))['join']('$'):_0x4a5462='default';const _0x4541af=this['removeListen_'](_0x59f404,_0x4a5462);_0x4541af&&_0x4541af['onComplete']&&_0x4541af['onComplete']('permission_denied');}['removeListen_'](_0x384790,_0x2603de){const _0x53f43d=new C(_0x384790)['toString']();let _0x238933;if(this['listens']['has'](_0x53f43d)){const _0x31f482=this['listens']['get'](_0x53f43d);_0x238933=_0x31f482['get'](_0x2603de),_0x31f482['delete'](_0x2603de),_0x31f482['size']===0x0&&this['listens']['delete'](_0x53f43d);}else _0x238933=void 0x0;return _0x238933;}['onAuthRevoked_'](_0x1866e7,_0x5e57fa){L('Auth\x20token\x20revoked:\x20'+_0x1866e7+'/'+_0x5e57fa),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1866e7==='invalid_token'||_0x1866e7==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1d3cd3,_0x3dea51){L('App\x20check\x20token\x20revoked:\x20'+_0x1d3cd3+'/'+_0x3dea51),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1d3cd3==='invalid_token'||_0x1d3cd3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4cbe59){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4cbe59):'msg'in _0x4cbe59&&console['log']('FIREBASE:\x20'+_0x4cbe59['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x9d0301 of this['listens']['values']())for(const _0x9358f0 of _0x9d0301['values']())this['sendListen_'](_0x9358f0);for(let _0x2853b0=0x0;_0x2853b0<this['outstandingPuts_']['length'];_0x2853b0++)this['outstandingPuts_'][_0x2853b0]&&this['sendPut_'](_0x2853b0);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3fb480=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3fb480['action'],_0x3fb480['pathString'],_0x3fb480['data'],_0x3fb480['onComplete']);}for(let _0x59d861=0x0;_0x59d861<this['outstandingGets_']['length'];_0x59d861++)this['outstandingGets_'][_0x59d861]&&this['sendGet_'](_0x59d861);}['sendConnectStats_'](){const _0x2583dc={};let _0x3e77ad='js';_0x2583dc['sdk.'+_0x3e77ad+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x2583dc['framework.cordova']=0x1:qr()&&(_0x2583dc['framework.reactnative']=0x1),this['reportStats'](_0x2583dc);}['shouldReconnect_'](){const _0x2fa687=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x2fa687;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4dbede,_0x210ccf){this['name']=_0x4dbede,this['node']=_0x210ccf;}static['Wrap'](_0x688072,_0x3aaefc){return new E(_0x688072,_0x3aaefc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x117f89,_0x14db35){const _0x3e2813=new E(xe,_0x117f89),_0x17822a=new E(xe,_0x14db35);return this['compare'](_0x3e2813,_0x17822a)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1719b4){Xt=_0x1719b4;}['compare'](_0x4ddad7,_0x19e93e){return He(_0x4ddad7['name'],_0x19e93e['name']);}['isDefinedOn'](_0x30385d){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3df2f8,_0x410e34){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x119dc0,_0x26fee8){return f(typeof _0x119dc0=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x119dc0,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x36d7c0,_0x571bd3,_0x4a605c,_0x31144d,_0x284d33=null){this['isReverse_']=_0x31144d,this['resultGenerator_']=_0x284d33,this['nodeStack_']=[];let _0x45a0e3=0x1;for(;!_0x36d7c0['isEmpty']();)if(_0x36d7c0=_0x36d7c0,_0x45a0e3=_0x571bd3?_0x4a605c(_0x36d7c0['key'],_0x571bd3):0x1,_0x31144d&&(_0x45a0e3*=-0x1),_0x45a0e3<0x0)this['isReverse_']?_0x36d7c0=_0x36d7c0['left']:_0x36d7c0=_0x36d7c0['right'];else{if(_0x45a0e3===0x0){this['nodeStack_']['push'](_0x36d7c0);break;}else this['nodeStack_']['push'](_0x36d7c0),this['isReverse_']?_0x36d7c0=_0x36d7c0['right']:_0x36d7c0=_0x36d7c0['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x639894=this['nodeStack_']['pop'](),_0x5923a4;if(this['resultGenerator_']?_0x5923a4=this['resultGenerator_'](_0x639894['key'],_0x639894['value']):_0x5923a4={'key':_0x639894['key'],'value':_0x639894['value']},this['isReverse_']){for(_0x639894=_0x639894['left'];!_0x639894['isEmpty']();)this['nodeStack_']['push'](_0x639894),_0x639894=_0x639894['right'];}else{for(_0x639894=_0x639894['right'];!_0x639894['isEmpty']();)this['nodeStack_']['push'](_0x639894),_0x639894=_0x639894['left'];}return _0x5923a4;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5ee4c7=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5ee4c7['key'],_0x5ee4c7['value']):{'key':_0x5ee4c7['key'],'value':_0x5ee4c7['value']};}}class M{constructor(_0x3a4d30,_0x5cdb61,_0xe7b924,_0x2a5d1c,_0x4cca71){this['key']=_0x3a4d30,this['value']=_0x5cdb61,this['color']=_0xe7b924??M['RED'],this['left']=_0x2a5d1c??B['EMPTY_NODE'],this['right']=_0x4cca71??B['EMPTY_NODE'];}['copy'](_0x322414,_0x19109f,_0x12b6bb,_0x5cfa46,_0x2250dc){return new M(_0x322414??this['key'],_0x19109f??this['value'],_0x12b6bb??this['color'],_0x5cfa46??this['left'],_0x2250dc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2631ec){return this['left']['inorderTraversal'](_0x2631ec)||!!_0x2631ec(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2631ec);}['reverseTraversal'](_0x1142f8){return this['right']['reverseTraversal'](_0x1142f8)||_0x1142f8(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1142f8);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x253428,_0x59a8f9,_0x3bbdc4){let _0x556d84=this;const _0x485e6a=_0x3bbdc4(_0x253428,_0x556d84['key']);return _0x485e6a<0x0?_0x556d84=_0x556d84['copy'](null,null,null,_0x556d84['left']['insert'](_0x253428,_0x59a8f9,_0x3bbdc4),null):_0x485e6a===0x0?_0x556d84=_0x556d84['copy'](null,_0x59a8f9,null,null,null):_0x556d84=_0x556d84['copy'](null,null,null,null,_0x556d84['right']['insert'](_0x253428,_0x59a8f9,_0x3bbdc4)),_0x556d84['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x36de90=this;return!_0x36de90['left']['isRed_']()&&!_0x36de90['left']['left']['isRed_']()&&(_0x36de90=_0x36de90['moveRedLeft_']()),_0x36de90=_0x36de90['copy'](null,null,null,_0x36de90['left']['removeMin_'](),null),_0x36de90['fixUp_']();}['remove'](_0x1d6442,_0x67fa28){let _0x37310f,_0x46bad1;if(_0x37310f=this,_0x67fa28(_0x1d6442,_0x37310f['key'])<0x0)!_0x37310f['left']['isEmpty']()&&!_0x37310f['left']['isRed_']()&&!_0x37310f['left']['left']['isRed_']()&&(_0x37310f=_0x37310f['moveRedLeft_']()),_0x37310f=_0x37310f['copy'](null,null,null,_0x37310f['left']['remove'](_0x1d6442,_0x67fa28),null);else{if(_0x37310f['left']['isRed_']()&&(_0x37310f=_0x37310f['rotateRight_']()),!_0x37310f['right']['isEmpty']()&&!_0x37310f['right']['isRed_']()&&!_0x37310f['right']['left']['isRed_']()&&(_0x37310f=_0x37310f['moveRedRight_']()),_0x67fa28(_0x1d6442,_0x37310f['key'])===0x0){if(_0x37310f['right']['isEmpty']())return B['EMPTY_NODE'];_0x46bad1=_0x37310f['right']['min_'](),_0x37310f=_0x37310f['copy'](_0x46bad1['key'],_0x46bad1['value'],null,null,_0x37310f['right']['removeMin_']());}_0x37310f=_0x37310f['copy'](null,null,null,null,_0x37310f['right']['remove'](_0x1d6442,_0x67fa28));}return _0x37310f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x43be59=this;return _0x43be59['right']['isRed_']()&&!_0x43be59['left']['isRed_']()&&(_0x43be59=_0x43be59['rotateLeft_']()),_0x43be59['left']['isRed_']()&&_0x43be59['left']['left']['isRed_']()&&(_0x43be59=_0x43be59['rotateRight_']()),_0x43be59['left']['isRed_']()&&_0x43be59['right']['isRed_']()&&(_0x43be59=_0x43be59['colorFlip_']()),_0x43be59;}['moveRedLeft_'](){let _0x10a75c=this['colorFlip_']();return _0x10a75c['right']['left']['isRed_']()&&(_0x10a75c=_0x10a75c['copy'](null,null,null,null,_0x10a75c['right']['rotateRight_']()),_0x10a75c=_0x10a75c['rotateLeft_'](),_0x10a75c=_0x10a75c['colorFlip_']()),_0x10a75c;}['moveRedRight_'](){let _0x510c87=this['colorFlip_']();return _0x510c87['left']['left']['isRed_']()&&(_0x510c87=_0x510c87['rotateRight_'](),_0x510c87=_0x510c87['colorFlip_']()),_0x510c87;}['rotateLeft_'](){const _0x5d058a=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5d058a,null);}['rotateRight_'](){const _0x1b5290=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1b5290);}['colorFlip_'](){const _0x446adf=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x7ea70d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x446adf,_0x7ea70d);}['checkMaxDepth_'](){const _0x5854c4=this['check_']();return Math['pow'](0x2,_0x5854c4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x37089f=this['left']['check_']();if(_0x37089f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x37089f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x52a572,_0x129f9e,_0x27d9d5,_0x1464c1,_0x44a37a){return this;}['insert'](_0x42a1f1,_0x154904,_0x2013ed){return new M(_0x42a1f1,_0x154904,null);}['remove'](_0x3e63b8,_0x46a197){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4248b6){return!0x1;}['reverseTraversal'](_0x36fb8c){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4b4de5,_0x1cb648=B['EMPTY_NODE']){this['comparator_']=_0x4b4de5,this['root_']=_0x1cb648;}['insert'](_0x20c47a,_0x4aca67){return new B(this['comparator_'],this['root_']['insert'](_0x20c47a,_0x4aca67,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x24e88a){return new B(this['comparator_'],this['root_']['remove'](_0x24e88a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x38e990){let _0x167ab9,_0x48d5fc=this['root_'];for(;!_0x48d5fc['isEmpty']();){if(_0x167ab9=this['comparator_'](_0x38e990,_0x48d5fc['key']),_0x167ab9===0x0)return _0x48d5fc['value'];_0x167ab9<0x0?_0x48d5fc=_0x48d5fc['left']:_0x167ab9>0x0&&(_0x48d5fc=_0x48d5fc['right']);}return null;}['getPredecessorKey'](_0x35c5d9){let _0x345fbb,_0x4a6f7e=this['root_'],_0x2ed6ae=null;for(;!_0x4a6f7e['isEmpty']();)if(_0x345fbb=this['comparator_'](_0x35c5d9,_0x4a6f7e['key']),_0x345fbb===0x0){if(_0x4a6f7e['left']['isEmpty']())return _0x2ed6ae?_0x2ed6ae['key']:null;for(_0x4a6f7e=_0x4a6f7e['left'];!_0x4a6f7e['right']['isEmpty']();)_0x4a6f7e=_0x4a6f7e['right'];return _0x4a6f7e['key'];}else _0x345fbb<0x0?_0x4a6f7e=_0x4a6f7e['left']:_0x345fbb>0x0&&(_0x2ed6ae=_0x4a6f7e,_0x4a6f7e=_0x4a6f7e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x11d0dc){return this['root_']['inorderTraversal'](_0x11d0dc);}['reverseTraversal'](_0x5461a7){return this['root_']['reverseTraversal'](_0x5461a7);}['getIterator'](_0x467d79){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x467d79);}['getIteratorFrom'](_0x370a55,_0x65f2cb){return new Zt(this['root_'],_0x370a55,this['comparator_'],!0x1,_0x65f2cb);}['getReverseIteratorFrom'](_0x5ed89e,_0x45352b){return new Zt(this['root_'],_0x5ed89e,this['comparator_'],!0x0,_0x45352b);}['getReverseIterator'](_0x20e431){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x20e431);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xe00270,_0x74d508){return He(_0xe00270['name'],_0x74d508['name']);}function ji(_0x4bc356,_0x454998){return He(_0x4bc356,_0x454998);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x51dc0e){vi=_0x51dc0e;}const Ro=function(_0x5e750e){return typeof _0x5e750e=='number'?'number:'+so(_0x5e750e):'string:'+_0x5e750e;},Ao=function(_0x29984f){if(_0x29984f['isLeafNode']()){const _0x1fc95e=_0x29984f['val']();f(typeof _0x1fc95e=='string'||typeof _0x1fc95e=='number'||typeof _0x1fc95e=='object'&&Y(_0x1fc95e,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x29984f===vi||_0x29984f['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x29984f===vi||_0x29984f['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x319ecd){er=_0x319ecd;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x16b3f2,_0x4b78d7=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x16b3f2,this['priorityNode_']=_0x4b78d7,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4d7be3){return new D(this['value_'],_0x4d7be3);}['getImmediateChild'](_0x4b9f9b){return _0x4b9f9b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3f3cdf){return v(_0x3f3cdf)?this:y(_0x3f3cdf)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x31c3f6,_0x5c15a7){return null;}['updateImmediateChild'](_0x298e8f,_0x41bbd2){return _0x298e8f==='.priority'?this['updatePriority'](_0x41bbd2):_0x41bbd2['isEmpty']()&&_0x298e8f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x298e8f,_0x41bbd2)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x12f7e,_0x4ce6ff){const _0x144e75=y(_0x12f7e);return _0x144e75===null?_0x4ce6ff:_0x4ce6ff['isEmpty']()&&_0x144e75!=='.priority'?this:(f(_0x144e75!=='.priority'||we(_0x12f7e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x144e75,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x12f7e),_0x4ce6ff)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1d5b30,_0x3d2e09){return!0x1;}['val'](_0xf3c2a8){return _0xf3c2a8&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1c025e='';this['priorityNode_']['isEmpty']()||(_0x1c025e+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x20b34c=typeof this['value_'];_0x1c025e+=_0x20b34c+':',_0x20b34c==='number'?_0x1c025e+=so(this['value_']):_0x1c025e+=this['value_'],this['lazyHash_']=no(_0x1c025e);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4343c9){return _0x4343c9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4343c9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4343c9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4343c9));}['compareToLeafNode_'](_0x5b3685){const _0x17922b=typeof _0x5b3685['value_'],_0x58ab4d=typeof this['value_'],_0x2c4f7f=D['VALUE_TYPE_ORDER']['indexOf'](_0x17922b),_0x5262c5=D['VALUE_TYPE_ORDER']['indexOf'](_0x58ab4d);return f(_0x2c4f7f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x17922b),f(_0x5262c5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x58ab4d),_0x2c4f7f===_0x5262c5?_0x58ab4d==='object'?0x0:this['value_']<_0x5b3685['value_']?-0x1:this['value_']===_0x5b3685['value_']?0x0:0x1:_0x5262c5-_0x2c4f7f;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x38855b){if(_0x38855b===this)return!0x0;if(_0x38855b['isLeafNode']()){const _0x51aa86=_0x38855b;return this['value_']===_0x51aa86['value_']&&this['priorityNode_']['equals'](_0x51aa86['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3d7455){ko=_0x3d7455;}function xh(_0x48ecca){No=_0x48ecca;}class Fh extends On{['compare'](_0x3fd44a,_0x331c96){const _0x100002=_0x3fd44a['node']['getPriority'](),_0x141a2f=_0x331c96['node']['getPriority'](),_0x423b4c=_0x100002['compareTo'](_0x141a2f);return _0x423b4c===0x0?He(_0x3fd44a['name'],_0x331c96['name']):_0x423b4c;}['isDefinedOn'](_0xae492b){return!_0xae492b['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x46fc42,_0x4ee0ab){return!_0x46fc42['getPriority']()['equals'](_0x4ee0ab['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2f1e76,_0x34060b){const _0x2eae45=ko(_0x2f1e76);return new E(_0x34060b,new D('[PRIORITY-POST]',_0x2eae45));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x298f13){const _0x167ad7=_0x1b1dd6=>parseInt(Math['log'](_0x1b1dd6)/Uh,0xa),_0x44c8a4=_0x35dc29=>parseInt(Array(_0x35dc29+0x1)['join']('1'),0x2);this['count']=_0x167ad7(_0x298f13+0x1),this['current_']=this['count']-0x1;const _0x2e23f2=_0x44c8a4(this['count']);this['bits_']=_0x298f13+0x1&_0x2e23f2;}['nextBitIsOne'](){const _0x250790=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x250790;}}const dn=function(_0xc241ba,_0x3a4072,_0x57a6e3,_0x3cbd56){_0xc241ba['sort'](_0x3a4072);const _0x57717e=function(_0x3b992f,_0x2d688d){const _0x2ca456=_0x2d688d-_0x3b992f;let _0x5de5dd,_0x342d84;if(_0x2ca456===0x0)return null;if(_0x2ca456===0x1)return _0x5de5dd=_0xc241ba[_0x3b992f],_0x342d84=_0x57a6e3?_0x57a6e3(_0x5de5dd):_0x5de5dd,new M(_0x342d84,_0x5de5dd['node'],M['BLACK'],null,null);{const _0x9ca276=parseInt(_0x2ca456/0x2,0xa)+_0x3b992f,_0x426afe=_0x57717e(_0x3b992f,_0x9ca276),_0xd5631a=_0x57717e(_0x9ca276+0x1,_0x2d688d);return _0x5de5dd=_0xc241ba[_0x9ca276],_0x342d84=_0x57a6e3?_0x57a6e3(_0x5de5dd):_0x5de5dd,new M(_0x342d84,_0x5de5dd['node'],M['BLACK'],_0x426afe,_0xd5631a);}},_0x2fb346=function(_0x36581f){let _0x45bcf7=null,_0x2bfbad=null,_0x1826ed=_0xc241ba['length'];const _0x5b73ff=function(_0x198283,_0x38e3d6){const _0x4aecb9=_0x1826ed-_0x198283,_0x444671=_0x1826ed;_0x1826ed-=_0x198283;const _0x459579=_0x57717e(_0x4aecb9+0x1,_0x444671),_0x1ac0e4=_0xc241ba[_0x4aecb9],_0x464114=_0x57a6e3?_0x57a6e3(_0x1ac0e4):_0x1ac0e4;_0x3fb4dd(new M(_0x464114,_0x1ac0e4['node'],_0x38e3d6,null,_0x459579));},_0x3fb4dd=function(_0xe3f4e7){_0x45bcf7?(_0x45bcf7['left']=_0xe3f4e7,_0x45bcf7=_0xe3f4e7):(_0x2bfbad=_0xe3f4e7,_0x45bcf7=_0xe3f4e7);};for(let _0x1a55c5=0x0;_0x1a55c5<_0x36581f['count'];++_0x1a55c5){const _0x428dfe=_0x36581f['nextBitIsOne'](),_0x329106=Math['pow'](0x2,_0x36581f['count']-(_0x1a55c5+0x1));_0x428dfe?_0x5b73ff(_0x329106,M['BLACK']):(_0x5b73ff(_0x329106,M['BLACK']),_0x5b73ff(_0x329106,M['RED']));}return _0x2bfbad;},_0x30a903=new Wh(_0xc241ba['length']),_0x505dee=_0x2fb346(_0x30a903);return new B(_0x3cbd56||_0x3a4072,_0x505dee);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2337df,_0x3ada36){this['indexes_']=_0x2337df,this['indexSet_']=_0x3ada36;}['get'](_0x59f31d){const _0x1b2757=Oe(this['indexes_'],_0x59f31d);if(!_0x1b2757)throw new Error('No\x20index\x20defined\x20for\x20'+_0x59f31d);return _0x1b2757 instanceof B?_0x1b2757:null;}['hasIndex'](_0x44bb40){return Y(this['indexSet_'],_0x44bb40['toString']());}['addIndex'](_0x1778db,_0x16c916){f(_0x1778db!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4aa1dd=[];let _0x5c427a=!0x1;const _0x4a5f9d=_0x16c916['getIterator'](E['Wrap']);let _0xfbfd8b=_0x4a5f9d['getNext']();for(;_0xfbfd8b;)_0x5c427a=_0x5c427a||_0x1778db['isDefinedOn'](_0xfbfd8b['node']),_0x4aa1dd['push'](_0xfbfd8b),_0xfbfd8b=_0x4a5f9d['getNext']();let _0x4fa5fb;_0x5c427a?_0x4fa5fb=dn(_0x4aa1dd,_0x1778db['getCompare']()):_0x4fa5fb=je;const _0x2edc40=_0x1778db['toString'](),_0x5b1f95={...this['indexSet_']};_0x5b1f95[_0x2edc40]=_0x1778db;const _0x27dba6={...this['indexes_']};return _0x27dba6[_0x2edc40]=_0x4fa5fb,new ee(_0x27dba6,_0x5b1f95);}['addToIndexes'](_0x293cb1,_0x58512c){const _0x2d805f=ln(this['indexes_'],(_0x39faa6,_0x391407)=>{const _0x535339=Oe(this['indexSet_'],_0x391407);if(f(_0x535339,'Missing\x20index\x20implementation\x20for\x20'+_0x391407),_0x39faa6===je){if(_0x535339['isDefinedOn'](_0x293cb1['node'])){const _0x622af=[],_0xc49502=_0x58512c['getIterator'](E['Wrap']);let _0x3dce0d=_0xc49502['getNext']();for(;_0x3dce0d;)_0x3dce0d['name']!==_0x293cb1['name']&&_0x622af['push'](_0x3dce0d),_0x3dce0d=_0xc49502['getNext']();return _0x622af['push'](_0x293cb1),dn(_0x622af,_0x535339['getCompare']());}else return je;}else{const _0xa4214b=_0x58512c['get'](_0x293cb1['name']);let _0xfbe8ae=_0x39faa6;return _0xa4214b&&(_0xfbe8ae=_0xfbe8ae['remove'](new E(_0x293cb1['name'],_0xa4214b))),_0xfbe8ae['insert'](_0x293cb1,_0x293cb1['node']);}});return new ee(_0x2d805f,this['indexSet_']);}['removeFromIndexes'](_0x40318f,_0x3e021e){const _0x2c5f48=ln(this['indexes_'],_0x4df5da=>{if(_0x4df5da===je)return _0x4df5da;{const _0xd3ccfb=_0x3e021e['get'](_0x40318f['name']);return _0xd3ccfb?_0x4df5da['remove'](new E(_0x40318f['name'],_0xd3ccfb)):_0x4df5da;}});return new ee(_0x2c5f48,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x421255,_0x2cf7fd,_0x3e5b57){this['children_']=_0x421255,this['priorityNode_']=_0x2cf7fd,this['indexMap_']=_0x3e5b57,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x17dab4){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x17dab4,this['indexMap_']);}['getImmediateChild'](_0x1c7ea2){if(_0x1c7ea2==='.priority')return this['getPriority']();{const _0x2a076d=this['children_']['get'](_0x1c7ea2);return _0x2a076d===null?gt:_0x2a076d;}}['getChild'](_0x1e9851){const _0x63d98c=y(_0x1e9851);return _0x63d98c===null?this:this['getImmediateChild'](_0x63d98c)['getChild'](b(_0x1e9851));}['hasChild'](_0x5ccf01){return this['children_']['get'](_0x5ccf01)!==null;}['updateImmediateChild'](_0x799a13,_0x16e1f6){if(f(_0x16e1f6,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x799a13==='.priority')return this['updatePriority'](_0x16e1f6);{const _0xfa75a8=new E(_0x799a13,_0x16e1f6);let _0x226ee7,_0x5cafe3;_0x16e1f6['isEmpty']()?(_0x226ee7=this['children_']['remove'](_0x799a13),_0x5cafe3=this['indexMap_']['removeFromIndexes'](_0xfa75a8,this['children_'])):(_0x226ee7=this['children_']['insert'](_0x799a13,_0x16e1f6),_0x5cafe3=this['indexMap_']['addToIndexes'](_0xfa75a8,this['children_']));const _0x1bd7d8=_0x226ee7['isEmpty']()?gt:this['priorityNode_'];return new g(_0x226ee7,_0x1bd7d8,_0x5cafe3);}}['updateChild'](_0x226065,_0x14afaa){const _0x15e39d=y(_0x226065);if(_0x15e39d===null)return _0x14afaa;{f(y(_0x226065)!=='.priority'||we(_0x226065)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x521bab=this['getImmediateChild'](_0x15e39d)['updateChild'](b(_0x226065),_0x14afaa);return this['updateImmediateChild'](_0x15e39d,_0x521bab);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x31a884){if(this['isEmpty']())return null;const _0xeec3fb={};let _0x47d7e5=0x0,_0x21ac2e=0x0,_0x4ea239=!0x0;if(this['forEachChild'](R,(_0x328268,_0x199e42)=>{_0xeec3fb[_0x328268]=_0x199e42['val'](_0x31a884),_0x47d7e5++,_0x4ea239&&g['INTEGER_REGEXP_']['test'](_0x328268)?_0x21ac2e=Math['max'](_0x21ac2e,Number(_0x328268)):_0x4ea239=!0x1;}),!_0x31a884&&_0x4ea239&&_0x21ac2e<0x2*_0x47d7e5){const _0xdf631c=[];for(const _0xd66449 in _0xeec3fb)_0xdf631c[_0xd66449]=_0xeec3fb[_0xd66449];return _0xdf631c;}else return _0x31a884&&!this['getPriority']()['isEmpty']()&&(_0xeec3fb['.priority']=this['getPriority']()['val']()),_0xeec3fb;}['hash'](){if(this['lazyHash_']===null){let _0x5cb311='';this['getPriority']()['isEmpty']()||(_0x5cb311+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x438040,_0x2bfea2)=>{const _0x5c6244=_0x2bfea2['hash']();_0x5c6244!==''&&(_0x5cb311+=':'+_0x438040+':'+_0x5c6244);}),this['lazyHash_']=_0x5cb311===''?'':no(_0x5cb311);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4160bb,_0x25ba0f,_0x1d1b3e){const _0x598604=this['resolveIndex_'](_0x1d1b3e);if(_0x598604){const _0x49a38d=_0x598604['getPredecessorKey'](new E(_0x4160bb,_0x25ba0f));return _0x49a38d?_0x49a38d['name']:null;}else return this['children_']['getPredecessorKey'](_0x4160bb);}['getFirstChildName'](_0x589bf8){const _0x432119=this['resolveIndex_'](_0x589bf8);if(_0x432119){const _0x101f45=_0x432119['minKey']();return _0x101f45&&_0x101f45['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xc96a3f){const _0x5a17e9=this['getFirstChildName'](_0xc96a3f);return _0x5a17e9?new E(_0x5a17e9,this['children_']['get'](_0x5a17e9)):null;}['getLastChildName'](_0x494ee8){const _0x4b9dd3=this['resolveIndex_'](_0x494ee8);if(_0x4b9dd3){const _0x40748a=_0x4b9dd3['maxKey']();return _0x40748a&&_0x40748a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5b9508){const _0x2b5c83=this['getLastChildName'](_0x5b9508);return _0x2b5c83?new E(_0x2b5c83,this['children_']['get'](_0x2b5c83)):null;}['forEachChild'](_0x26cd54,_0x2cce14){const _0x178d3c=this['resolveIndex_'](_0x26cd54);return _0x178d3c?_0x178d3c['inorderTraversal'](_0xc0636f=>_0x2cce14(_0xc0636f['name'],_0xc0636f['node'])):this['children_']['inorderTraversal'](_0x2cce14);}['getIterator'](_0x2617c9){return this['getIteratorFrom'](_0x2617c9['minPost'](),_0x2617c9);}['getIteratorFrom'](_0x5d31ed,_0x1eca0c){const _0x12c985=this['resolveIndex_'](_0x1eca0c);if(_0x12c985)return _0x12c985['getIteratorFrom'](_0x5d31ed,_0x9f643b=>_0x9f643b);{const _0x530131=this['children_']['getIteratorFrom'](_0x5d31ed['name'],E['Wrap']);let _0x14f44d=_0x530131['peek']();for(;_0x14f44d!=null&&_0x1eca0c['compare'](_0x14f44d,_0x5d31ed)<0x0;)_0x530131['getNext'](),_0x14f44d=_0x530131['peek']();return _0x530131;}}['getReverseIterator'](_0x40e953){return this['getReverseIteratorFrom'](_0x40e953['maxPost'](),_0x40e953);}['getReverseIteratorFrom'](_0x44a98a,_0x1bedfd){const _0x6d5c04=this['resolveIndex_'](_0x1bedfd);if(_0x6d5c04)return _0x6d5c04['getReverseIteratorFrom'](_0x44a98a,_0xcf9571=>_0xcf9571);{const _0x154366=this['children_']['getReverseIteratorFrom'](_0x44a98a['name'],E['Wrap']);let _0x49e3fa=_0x154366['peek']();for(;_0x49e3fa!=null&&_0x1bedfd['compare'](_0x49e3fa,_0x44a98a)>0x0;)_0x154366['getNext'](),_0x49e3fa=_0x154366['peek']();return _0x154366;}}['compareTo'](_0x4690bc){return this['isEmpty']()?_0x4690bc['isEmpty']()?0x0:-0x1:_0x4690bc['isLeafNode']()||_0x4690bc['isEmpty']()?0x1:_0x4690bc===Ht?-0x1:0x0;}['withIndex'](_0x2e2d0f){if(_0x2e2d0f===ye||this['indexMap_']['hasIndex'](_0x2e2d0f))return this;{const _0x282b4d=this['indexMap_']['addIndex'](_0x2e2d0f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x282b4d);}}['isIndexed'](_0x37013c){return _0x37013c===ye||this['indexMap_']['hasIndex'](_0x37013c);}['equals'](_0x535b6f){if(_0x535b6f===this)return!0x0;if(_0x535b6f['isLeafNode']())return!0x1;{const _0x4008ab=_0x535b6f;if(this['getPriority']()['equals'](_0x4008ab['getPriority']())){if(this['children_']['count']()===_0x4008ab['children_']['count']()){const _0x4eecc4=this['getIterator'](R),_0xb86a17=_0x4008ab['getIterator'](R);let _0x521936=_0x4eecc4['getNext'](),_0x56c43c=_0xb86a17['getNext']();for(;_0x521936&&_0x56c43c;){if(_0x521936['name']!==_0x56c43c['name']||!_0x521936['node']['equals'](_0x56c43c['node']))return!0x1;_0x521936=_0x4eecc4['getNext'](),_0x56c43c=_0xb86a17['getNext']();}return _0x521936===null&&_0x56c43c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x375dd1){return _0x375dd1===ye?null:this['indexMap_']['get'](_0x375dd1['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x805c56){return _0x805c56===this?0x0:0x1;}['equals'](_0x47b350){return _0x47b350===this;}['getPriority'](){return this;}['getImmediateChild'](_0xf7238c){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x303e24,_0x382a67=null){if(_0x303e24===null)return g['EMPTY_NODE'];if(typeof _0x303e24=='object'&&'.priority'in _0x303e24&&(_0x382a67=_0x303e24['.priority']),f(_0x382a67===null||typeof _0x382a67=='string'||typeof _0x382a67=='number'||typeof _0x382a67=='object'&&'.sv'in _0x382a67,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x382a67),typeof _0x303e24=='object'&&'.value'in _0x303e24&&_0x303e24['.value']!==null&&(_0x303e24=_0x303e24['.value']),typeof _0x303e24!='object'||'.sv'in _0x303e24){const _0x9076fb=_0x303e24;return new D(_0x9076fb,N(_0x382a67));}if(!(_0x303e24 instanceof Array)&&Vh){const _0x555101=[];let _0x479ac6=!0x1;if(x(_0x303e24,(_0x3280a7,_0x1e6272)=>{if(_0x3280a7['substring'](0x0,0x1)!=='.'){const _0x5da5e0=N(_0x1e6272);_0x5da5e0['isEmpty']()||(_0x479ac6=_0x479ac6||!_0x5da5e0['getPriority']()['isEmpty'](),_0x555101['push'](new E(_0x3280a7,_0x5da5e0)));}}),_0x555101['length']===0x0)return g['EMPTY_NODE'];const _0x54721f=dn(_0x555101,Dh,_0xb74653=>_0xb74653['name'],ji);if(_0x479ac6){const _0x3b139e=dn(_0x555101,R['getCompare']());return new g(_0x54721f,N(_0x382a67),new ee({'.priority':_0x3b139e},{'.priority':R}));}else return new g(_0x54721f,N(_0x382a67),ee['Default']);}else{let _0x3e09d1=g['EMPTY_NODE'];return x(_0x303e24,(_0x406223,_0x26c98f)=>{if(Y(_0x303e24,_0x406223)&&_0x406223['substring'](0x0,0x1)!=='.'){const _0x46c318=N(_0x26c98f);(_0x46c318['isLeafNode']()||!_0x46c318['isEmpty']())&&(_0x3e09d1=_0x3e09d1['updateImmediateChild'](_0x406223,_0x46c318));}}),_0x3e09d1['updatePriority'](N(_0x382a67));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x1b083c){super(),this['indexPath_']=_0x1b083c,f(!v(_0x1b083c)&&y(_0x1b083c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x58f500){return _0x58f500['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1d54ba){return!_0x1d54ba['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x11372a,_0x1f5ff5){const _0xccd3ad=this['extractChild'](_0x11372a['node']),_0x3d9dd3=this['extractChild'](_0x1f5ff5['node']),_0x5ce3ae=_0xccd3ad['compareTo'](_0x3d9dd3);return _0x5ce3ae===0x0?He(_0x11372a['name'],_0x1f5ff5['name']):_0x5ce3ae;}['makePost'](_0x579809,_0x2ac777){const _0x51d908=N(_0x579809),_0x4ffa2a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x51d908);return new E(_0x2ac777,_0x4ffa2a);}['maxPost'](){const _0x34edf5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x34edf5);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x39be5c,_0xb4637){const _0x1ccd22=_0x39be5c['node']['compareTo'](_0xb4637['node']);return _0x1ccd22===0x0?He(_0x39be5c['name'],_0xb4637['name']):_0x1ccd22;}['isDefinedOn'](_0x3e64d2){return!0x0;}['indexedValueChanged'](_0x27f614,_0x5c20b8){return!_0x27f614['equals'](_0x5c20b8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x346ba7,_0x30c116){const _0x21fdfa=N(_0x346ba7);return new E(_0x30c116,_0x21fdfa);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x346739){return{'type':'value','snapshotNode':_0x346739};}function tt(_0x4eda2d,_0x5cbd4c){return{'type':'child_added','snapshotNode':_0x5cbd4c,'childName':_0x4eda2d};}function Nt(_0xe0d2ff,_0x24bed8){return{'type':'child_removed','snapshotNode':_0x24bed8,'childName':_0xe0d2ff};}function Pt(_0x14f606,_0x498bcd,_0x4a9a03){return{'type':'child_changed','snapshotNode':_0x498bcd,'childName':_0x14f606,'oldSnap':_0x4a9a03};}function $h(_0x462892,_0x55a10e){return{'type':'child_moved','snapshotNode':_0x55a10e,'childName':_0x462892};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x40851a){this['index_']=_0x40851a;}['updateChild'](_0x56a33b,_0x1b2780,_0x5d62cd,_0x21eea0,_0x2ab9df,_0x1b7319){f(_0x56a33b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x73811f=_0x56a33b['getImmediateChild'](_0x1b2780);return _0x73811f['getChild'](_0x21eea0)['equals'](_0x5d62cd['getChild'](_0x21eea0))&&_0x73811f['isEmpty']()===_0x5d62cd['isEmpty']()||(_0x1b7319!=null&&(_0x5d62cd['isEmpty']()?_0x56a33b['hasChild'](_0x1b2780)?_0x1b7319['trackChildChange'](Nt(_0x1b2780,_0x73811f)):f(_0x56a33b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x73811f['isEmpty']()?_0x1b7319['trackChildChange'](tt(_0x1b2780,_0x5d62cd)):_0x1b7319['trackChildChange'](Pt(_0x1b2780,_0x5d62cd,_0x73811f))),_0x56a33b['isLeafNode']()&&_0x5d62cd['isEmpty']())?_0x56a33b:_0x56a33b['updateImmediateChild'](_0x1b2780,_0x5d62cd)['withIndex'](this['index_']);}['updateFullNode'](_0x137f2c,_0x5d27b5,_0x155ab9){return _0x155ab9!=null&&(_0x137f2c['isLeafNode']()||_0x137f2c['forEachChild'](R,(_0x1dff00,_0x580e8c)=>{_0x5d27b5['hasChild'](_0x1dff00)||_0x155ab9['trackChildChange'](Nt(_0x1dff00,_0x580e8c));}),_0x5d27b5['isLeafNode']()||_0x5d27b5['forEachChild'](R,(_0x500d5d,_0x17ef7d)=>{if(_0x137f2c['hasChild'](_0x500d5d)){const _0x42ca52=_0x137f2c['getImmediateChild'](_0x500d5d);_0x42ca52['equals'](_0x17ef7d)||_0x155ab9['trackChildChange'](Pt(_0x500d5d,_0x17ef7d,_0x42ca52));}else _0x155ab9['trackChildChange'](tt(_0x500d5d,_0x17ef7d));})),_0x5d27b5['withIndex'](this['index_']);}['updatePriority'](_0x331965,_0x3894ef){return _0x331965['isEmpty']()?g['EMPTY_NODE']:_0x331965['updatePriority'](_0x3894ef);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x193e02){this['indexedFilter_']=new Yi(_0x193e02['getIndex']()),this['index_']=_0x193e02['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x193e02),this['endPost_']=Ot['getEndPost_'](_0x193e02),this['startIsInclusive_']=!_0x193e02['startAfterSet_'],this['endIsInclusive_']=!_0x193e02['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x45e8ff){const _0x4cb9ca=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x45e8ff)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x45e8ff)<0x0,_0x20f118=this['endIsInclusive_']?this['index_']['compare'](_0x45e8ff,this['getEndPost']())<=0x0:this['index_']['compare'](_0x45e8ff,this['getEndPost']())<0x0;return _0x4cb9ca&&_0x20f118;}['updateChild'](_0x4e2caa,_0x333a04,_0x35fc74,_0x40c344,_0xf3a7b7,_0x24c892){return this['matches'](new E(_0x333a04,_0x35fc74))||(_0x35fc74=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4e2caa,_0x333a04,_0x35fc74,_0x40c344,_0xf3a7b7,_0x24c892);}['updateFullNode'](_0x2d1974,_0x48d3d8,_0x182f29){_0x48d3d8['isLeafNode']()&&(_0x48d3d8=g['EMPTY_NODE']);let _0x3ddbbe=_0x48d3d8['withIndex'](this['index_']);_0x3ddbbe=_0x3ddbbe['updatePriority'](g['EMPTY_NODE']);const _0x766de4=this;return _0x48d3d8['forEachChild'](R,(_0x2ba1bd,_0x40de28)=>{_0x766de4['matches'](new E(_0x2ba1bd,_0x40de28))||(_0x3ddbbe=_0x3ddbbe['updateImmediateChild'](_0x2ba1bd,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2d1974,_0x3ddbbe,_0x182f29);}['updatePriority'](_0x179926,_0x3f8cc9){return _0x179926;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x49b309){if(_0x49b309['hasStart']()){const _0x5f36b2=_0x49b309['getIndexStartName']();return _0x49b309['getIndex']()['makePost'](_0x49b309['getIndexStartValue'](),_0x5f36b2);}else return _0x49b309['getIndex']()['minPost']();}static['getEndPost_'](_0x114e49){if(_0x114e49['hasEnd']()){const _0x3038fe=_0x114e49['getIndexEndName']();return _0x114e49['getIndex']()['makePost'](_0x114e49['getIndexEndValue'](),_0x3038fe);}else return _0x114e49['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x4ad287){this['withinDirectionalStart']=_0x2aea9c=>this['reverse_']?this['withinEndPost'](_0x2aea9c):this['withinStartPost'](_0x2aea9c),this['withinDirectionalEnd']=_0x5d68a7=>this['reverse_']?this['withinStartPost'](_0x5d68a7):this['withinEndPost'](_0x5d68a7),this['withinStartPost']=_0x21ffb5=>{const _0x59e957=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x21ffb5);return this['startIsInclusive_']?_0x59e957<=0x0:_0x59e957<0x0;},this['withinEndPost']=_0x4e34b8=>{const _0x53994d=this['index_']['compare'](_0x4e34b8,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x53994d<=0x0:_0x53994d<0x0;},this['rangedFilter_']=new Ot(_0x4ad287),this['index_']=_0x4ad287['getIndex'](),this['limit_']=_0x4ad287['getLimit'](),this['reverse_']=!_0x4ad287['isViewFromLeft'](),this['startIsInclusive_']=!_0x4ad287['startAfterSet_'],this['endIsInclusive_']=!_0x4ad287['endBeforeSet_'];}['updateChild'](_0x1ae4ba,_0x352911,_0x1673bb,_0x4d3468,_0x22c302,_0x499a30){return this['rangedFilter_']['matches'](new E(_0x352911,_0x1673bb))||(_0x1673bb=g['EMPTY_NODE']),_0x1ae4ba['getImmediateChild'](_0x352911)['equals'](_0x1673bb)?_0x1ae4ba:_0x1ae4ba['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1ae4ba,_0x352911,_0x1673bb,_0x4d3468,_0x22c302,_0x499a30):this['fullLimitUpdateChild_'](_0x1ae4ba,_0x352911,_0x1673bb,_0x22c302,_0x499a30);}['updateFullNode'](_0x1e4a04,_0x5cc4ec,_0x16eff8){let _0x42d130;if(_0x5cc4ec['isLeafNode']()||_0x5cc4ec['isEmpty']())_0x42d130=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5cc4ec['numChildren']()&&_0x5cc4ec['isIndexed'](this['index_'])){_0x42d130=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3569e5;this['reverse_']?_0x3569e5=_0x5cc4ec['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3569e5=_0x5cc4ec['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x572a2d=0x0;for(;_0x3569e5['hasNext']()&&_0x572a2d<this['limit_'];){const _0xe6ec47=_0x3569e5['getNext']();if(this['withinDirectionalStart'](_0xe6ec47)){if(this['withinDirectionalEnd'](_0xe6ec47))_0x42d130=_0x42d130['updateImmediateChild'](_0xe6ec47['name'],_0xe6ec47['node']),_0x572a2d++;else break;}else continue;}}else{_0x42d130=_0x5cc4ec['withIndex'](this['index_']),_0x42d130=_0x42d130['updatePriority'](g['EMPTY_NODE']);let _0x10156d;this['reverse_']?_0x10156d=_0x42d130['getReverseIterator'](this['index_']):_0x10156d=_0x42d130['getIterator'](this['index_']);let _0x4909a7=0x0;for(;_0x10156d['hasNext']();){const _0x524586=_0x10156d['getNext']();_0x4909a7<this['limit_']&&this['withinDirectionalStart'](_0x524586)&&this['withinDirectionalEnd'](_0x524586)?_0x4909a7++:_0x42d130=_0x42d130['updateImmediateChild'](_0x524586['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1e4a04,_0x42d130,_0x16eff8);}['updatePriority'](_0x5842d1,_0x56a812){return _0x5842d1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x11936c,_0x5901e3,_0xbde462,_0x555e87,_0x4b4c1c){let _0x9b3dc9;if(this['reverse_']){const _0xe03802=this['index_']['getCompare']();_0x9b3dc9=(_0x5bcb96,_0x227015)=>_0xe03802(_0x227015,_0x5bcb96);}else _0x9b3dc9=this['index_']['getCompare']();const _0x43a95f=_0x11936c;f(_0x43a95f['numChildren']()===this['limit_'],'');const _0x48fb9f=new E(_0x5901e3,_0xbde462),_0x4545da=this['reverse_']?_0x43a95f['getFirstChild'](this['index_']):_0x43a95f['getLastChild'](this['index_']),_0x1dfd68=this['rangedFilter_']['matches'](_0x48fb9f);if(_0x43a95f['hasChild'](_0x5901e3)){const _0x4e8be0=_0x43a95f['getImmediateChild'](_0x5901e3);let _0x5bb7f2=_0x555e87['getChildAfterChild'](this['index_'],_0x4545da,this['reverse_']);for(;_0x5bb7f2!=null&&(_0x5bb7f2['name']===_0x5901e3||_0x43a95f['hasChild'](_0x5bb7f2['name']));)_0x5bb7f2=_0x555e87['getChildAfterChild'](this['index_'],_0x5bb7f2,this['reverse_']);const _0x10a133=_0x5bb7f2==null?0x1:_0x9b3dc9(_0x5bb7f2,_0x48fb9f);if(_0x1dfd68&&!_0xbde462['isEmpty']()&&_0x10a133>=0x0)return _0x4b4c1c!=null&&_0x4b4c1c['trackChildChange'](Pt(_0x5901e3,_0xbde462,_0x4e8be0)),_0x43a95f['updateImmediateChild'](_0x5901e3,_0xbde462);{_0x4b4c1c!=null&&_0x4b4c1c['trackChildChange'](Nt(_0x5901e3,_0x4e8be0));const _0x3b1252=_0x43a95f['updateImmediateChild'](_0x5901e3,g['EMPTY_NODE']);return _0x5bb7f2!=null&&this['rangedFilter_']['matches'](_0x5bb7f2)?(_0x4b4c1c!=null&&_0x4b4c1c['trackChildChange'](tt(_0x5bb7f2['name'],_0x5bb7f2['node'])),_0x3b1252['updateImmediateChild'](_0x5bb7f2['name'],_0x5bb7f2['node'])):_0x3b1252;}}else return _0xbde462['isEmpty']()?_0x11936c:_0x1dfd68&&_0x9b3dc9(_0x4545da,_0x48fb9f)>=0x0?(_0x4b4c1c!=null&&(_0x4b4c1c['trackChildChange'](Nt(_0x4545da['name'],_0x4545da['node'])),_0x4b4c1c['trackChildChange'](tt(_0x5901e3,_0xbde462))),_0x43a95f['updateImmediateChild'](_0x5901e3,_0xbde462)['updateImmediateChild'](_0x4545da['name'],g['EMPTY_NODE'])):_0x11936c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2f51d3=new Qi();return _0x2f51d3['limitSet_']=this['limitSet_'],_0x2f51d3['limit_']=this['limit_'],_0x2f51d3['startSet_']=this['startSet_'],_0x2f51d3['startAfterSet_']=this['startAfterSet_'],_0x2f51d3['indexStartValue_']=this['indexStartValue_'],_0x2f51d3['startNameSet_']=this['startNameSet_'],_0x2f51d3['indexStartName_']=this['indexStartName_'],_0x2f51d3['endSet_']=this['endSet_'],_0x2f51d3['endBeforeSet_']=this['endBeforeSet_'],_0x2f51d3['indexEndValue_']=this['indexEndValue_'],_0x2f51d3['endNameSet_']=this['endNameSet_'],_0x2f51d3['indexEndName_']=this['indexEndName_'],_0x2f51d3['index_']=this['index_'],_0x2f51d3['viewFrom_']=this['viewFrom_'],_0x2f51d3;}}function qh(_0x3abb44){return _0x3abb44['loadsAllData']()?new Yi(_0x3abb44['getIndex']()):_0x3abb44['hasLimit']()?new Gh(_0x3abb44):new Ot(_0x3abb44);}function zh(_0x7cc5a6,_0x20d696){const _0x19e3c1=_0x7cc5a6['copy']();return _0x19e3c1['limitSet_']=!0x0,_0x19e3c1['limit_']=_0x20d696,_0x19e3c1['viewFrom_']='l',_0x19e3c1;}function jh(_0x13d52f,_0x43e95c,_0x59b985){const _0x353c3c=_0x13d52f['copy']();return _0x353c3c['startSet_']=!0x0,_0x43e95c===void 0x0&&(_0x43e95c=null),_0x353c3c['indexStartValue_']=_0x43e95c,_0x59b985!=null?(_0x353c3c['startNameSet_']=!0x0,_0x353c3c['indexStartName_']=_0x59b985):(_0x353c3c['startNameSet_']=!0x1,_0x353c3c['indexStartName_']=''),_0x353c3c;}function Kh(_0x1a92eb,_0x5f12ce,_0x2d565d){const _0x37ca29=_0x1a92eb['copy']();return _0x37ca29['endSet_']=!0x0,_0x5f12ce===void 0x0&&(_0x5f12ce=null),_0x37ca29['indexEndValue_']=_0x5f12ce,_0x2d565d!==void 0x0?(_0x37ca29['endNameSet_']=!0x0,_0x37ca29['indexEndName_']=_0x2d565d):(_0x37ca29['endNameSet_']=!0x1,_0x37ca29['indexEndName_']=''),_0x37ca29;}function Do(_0x2f901c,_0x2c7aff){const _0x348762=_0x2f901c['copy']();return _0x348762['index_']=_0x2c7aff,_0x348762;}function tr(_0xf70ce8){const _0x4e6e45={};if(_0xf70ce8['isDefault']())return _0x4e6e45;let _0x11330a;if(_0xf70ce8['index_']===R?_0x11330a='$priority':_0xf70ce8['index_']===Po?_0x11330a='$value':_0xf70ce8['index_']===ye?_0x11330a='$key':(f(_0xf70ce8['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x11330a=_0xf70ce8['index_']['toString']()),_0x4e6e45['orderBy']=O(_0x11330a),_0xf70ce8['startSet_']){const _0x41aada=_0xf70ce8['startAfterSet_']?'startAfter':'startAt';_0x4e6e45[_0x41aada]=O(_0xf70ce8['indexStartValue_']),_0xf70ce8['startNameSet_']&&(_0x4e6e45[_0x41aada]+=','+O(_0xf70ce8['indexStartName_']));}if(_0xf70ce8['endSet_']){const _0x2f22cb=_0xf70ce8['endBeforeSet_']?'endBefore':'endAt';_0x4e6e45[_0x2f22cb]=O(_0xf70ce8['indexEndValue_']),_0xf70ce8['endNameSet_']&&(_0x4e6e45[_0x2f22cb]+=','+O(_0xf70ce8['indexEndName_']));}return _0xf70ce8['limitSet_']&&(_0xf70ce8['isViewFromLeft']()?_0x4e6e45['limitToFirst']=_0xf70ce8['limit_']:_0x4e6e45['limitToLast']=_0xf70ce8['limit_']),_0x4e6e45;}function nr(_0x562275){const _0x4b5969={};if(_0x562275['startSet_']&&(_0x4b5969['sp']=_0x562275['indexStartValue_'],_0x562275['startNameSet_']&&(_0x4b5969['sn']=_0x562275['indexStartName_']),_0x4b5969['sin']=!_0x562275['startAfterSet_']),_0x562275['endSet_']&&(_0x4b5969['ep']=_0x562275['indexEndValue_'],_0x562275['endNameSet_']&&(_0x4b5969['en']=_0x562275['indexEndName_']),_0x4b5969['ein']=!_0x562275['endBeforeSet_']),_0x562275['limitSet_']){_0x4b5969['l']=_0x562275['limit_'];let _0x1065d8=_0x562275['viewFrom_'];_0x1065d8===''&&(_0x562275['isViewFromLeft']()?_0x1065d8='l':_0x1065d8='r'),_0x4b5969['vf']=_0x1065d8;}return _0x562275['index_']!==R&&(_0x4b5969['i']=_0x562275['index_']['toString']()),_0x4b5969;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2a1358){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1c5316,_0x44a734){return _0x44a734!==void 0x0?'tag$'+_0x44a734:(f(_0x1c5316['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1c5316['_path']['toString']());}constructor(_0x17ad17,_0x15df91,_0x406d1a,_0x3d0f7e){super(),this['repoInfo_']=_0x17ad17,this['onDataUpdate_']=_0x15df91,this['authTokenProvider_']=_0x406d1a,this['appCheckTokenProvider_']=_0x3d0f7e,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2c0323,_0x34e414,_0x5d6f1c,_0xa05b25){const _0x5eb153=_0x2c0323['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5eb153+'\x20'+_0x2c0323['_queryIdentifier']);const _0x320f19=fn['getListenId_'](_0x2c0323,_0x5d6f1c),_0x36ebbd={};this['listens_'][_0x320f19]=_0x36ebbd;const _0xccde3c=tr(_0x2c0323['_queryParams']);this['restRequest_'](_0x5eb153+'.json',_0xccde3c,(_0x4e4214,_0x1e3c9a)=>{let _0x4df052=_0x1e3c9a;if(_0x4e4214===0x194&&(_0x4df052=null,_0x4e4214=null),_0x4e4214===null&&this['onDataUpdate_'](_0x5eb153,_0x4df052,!0x1,_0x5d6f1c),Oe(this['listens_'],_0x320f19)===_0x36ebbd){let _0xf6e25f;_0x4e4214?_0x4e4214===0x191?_0xf6e25f='permission_denied':_0xf6e25f='rest_error:'+_0x4e4214:_0xf6e25f='ok',_0xa05b25(_0xf6e25f,null);}});}['unlisten'](_0x4f0b0e,_0x43a8b9){const _0x142934=fn['getListenId_'](_0x4f0b0e,_0x43a8b9);delete this['listens_'][_0x142934];}['get'](_0x2587bb){const _0x5f418a=tr(_0x2587bb['_queryParams']),_0x5811dc=_0x2587bb['_path']['toString'](),_0x350754=new Ve();return this['restRequest_'](_0x5811dc+'.json',_0x5f418a,(_0x4c2146,_0x482db3)=>{let _0x32a2b9=_0x482db3;_0x4c2146===0x194&&(_0x32a2b9=null,_0x4c2146=null),_0x4c2146===null?(this['onDataUpdate_'](_0x5811dc,_0x32a2b9,!0x1,null),_0x350754['resolve'](_0x32a2b9)):_0x350754['reject'](new Error(_0x32a2b9));}),_0x350754['promise'];}['refreshAuthToken'](_0x44f732){}['restRequest_'](_0x1c614b,_0x5622f9={},_0x1db236){return _0x5622f9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2f239a,_0x4302e4])=>{_0x2f239a&&_0x2f239a['accessToken']&&(_0x5622f9['auth']=_0x2f239a['accessToken']),_0x4302e4&&_0x4302e4['token']&&(_0x5622f9['ac']=_0x4302e4['token']);const _0x23cca4=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1c614b+'?ns='+this['repoInfo_']['namespace']+at(_0x5622f9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x23cca4);const _0x1171b1=new XMLHttpRequest();_0x1171b1['onreadystatechange']=()=>{if(_0x1db236&&_0x1171b1['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x23cca4+'\x20received.\x20status:',_0x1171b1['status'],'response:',_0x1171b1['responseText']);let _0x5296e7=null;if(_0x1171b1['status']>=0xc8&&_0x1171b1['status']<0x12c){try{_0x5296e7=bt(_0x1171b1['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x23cca4+':\x20'+_0x1171b1['responseText']);}_0x1db236(null,_0x5296e7);}else _0x1171b1['status']!==0x191&&_0x1171b1['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x23cca4+'\x20Status:\x20'+_0x1171b1['status']),_0x1db236(_0x1171b1['status']);_0x1db236=null;}},_0x1171b1['open']('GET',_0x23cca4,!0x0),_0x1171b1['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xd0bcbe){return this['rootNode_']['getChild'](_0xd0bcbe);}['updateSnapshot'](_0x1e3fd9,_0x1a0125){this['rootNode_']=this['rootNode_']['updateChild'](_0x1e3fd9,_0x1a0125);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x12704b,_0x4eb149,_0x3a8093){if(v(_0x4eb149))_0x12704b['value']=_0x3a8093,_0x12704b['children']['clear']();else{if(_0x12704b['value']!==null)_0x12704b['value']=_0x12704b['value']['updateChild'](_0x4eb149,_0x3a8093);else{const _0x36f225=y(_0x4eb149);_0x12704b['children']['has'](_0x36f225)||_0x12704b['children']['set'](_0x36f225,pn());const _0x525b5f=_0x12704b['children']['get'](_0x36f225);_0x4eb149=b(_0x4eb149),Mo(_0x525b5f,_0x4eb149,_0x3a8093);}}}function Ei(_0x2d1c64,_0x11725f,_0x19b8a2){_0x2d1c64['value']!==null?_0x19b8a2(_0x11725f,_0x2d1c64['value']):Qh(_0x2d1c64,(_0x43a182,_0x7b4dfb)=>{const _0xb7be94=new C(_0x11725f['toString']()+'/'+_0x43a182);Ei(_0x7b4dfb,_0xb7be94,_0x19b8a2);});}function Qh(_0x1752f0,_0x3f4b3d){_0x1752f0['children']['forEach']((_0x1a4b22,_0x388717)=>{_0x3f4b3d(_0x388717,_0x1a4b22);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x1580f1){this['collection_']=_0x1580f1,this['last_']=null;}['get'](){const _0x1e352d=this['collection_']['get'](),_0x42dedf={..._0x1e352d};return this['last_']&&x(this['last_'],(_0x45334a,_0x2f9c01)=>{_0x42dedf[_0x45334a]=_0x42dedf[_0x45334a]-_0x2f9c01;}),this['last_']=_0x1e352d,_0x42dedf;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x420b86,_0x573eb7){this['server_']=_0x573eb7,this['statsToReport_']={},this['statsListener_']=new Jh(_0x420b86);const _0x192c3a=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x192c3a));}['reportStats_'](){const _0x516cfc=this['statsListener_']['get'](),_0x4ce1c5={};let _0x48a925=!0x1;x(_0x516cfc,(_0x4b8ed6,_0x1e443b)=>{_0x1e443b>0x0&&Y(this['statsToReport_'],_0x4b8ed6)&&(_0x4ce1c5[_0x4b8ed6]=_0x1e443b,_0x48a925=!0x0);}),_0x48a925&&this['server_']['reportStats'](_0x4ce1c5),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x5ca579){_0x5ca579[_0x5ca579['OVERWRITE']=0x0]='OVERWRITE',_0x5ca579[_0x5ca579['MERGE']=0x1]='MERGE',_0x5ca579[_0x5ca579['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5ca579[_0x5ca579['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2b0577){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2b0577,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3c9321,_0x22b64b,_0x2d1b5f){this['path']=_0x3c9321,this['affectedTree']=_0x22b64b,this['revert']=_0x2d1b5f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x32524d){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1e3de3=this['affectedTree']['subtree'](new C(_0x32524d));return new _n(w(),_0x1e3de3,this['revert']);}}else return f(y(this['path'])===_0x32524d,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x4224cb,_0x41ae39){this['source']=_0x4224cb,this['path']=_0x41ae39,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4b9dde){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x175122,_0x1616a5,_0x52fc5f){this['source']=_0x175122,this['path']=_0x1616a5,this['snap']=_0x52fc5f,this['type']=q['OVERWRITE'];}['operationForChild'](_0x5a233a){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x5a233a)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x2f4e89,_0x6867a1,_0xdc164e){this['source']=_0x2f4e89,this['path']=_0x6867a1,this['children']=_0xdc164e,this['type']=q['MERGE'];}['operationForChild'](_0x5b3f35){if(v(this['path'])){const _0x5ef615=this['children']['subtree'](new C(_0x5b3f35));return _0x5ef615['isEmpty']()?null:_0x5ef615['value']?new Fe(this['source'],w(),_0x5ef615['value']):new nt(this['source'],w(),_0x5ef615);}else return f(y(this['path'])===_0x5b3f35,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x18eadc,_0x13a7e7,_0x485194){this['node_']=_0x18eadc,this['fullyInitialized_']=_0x13a7e7,this['filtered_']=_0x485194;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4547f4){if(v(_0x4547f4))return this['isFullyInitialized']()&&!this['filtered_'];const _0x20e08=y(_0x4547f4);return this['isCompleteForChild'](_0x20e08);}['isCompleteForChild'](_0x12beeb){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x12beeb);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x5063ea){this['query_']=_0x5063ea,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x50dc28,_0x1191d0,_0x5a741b,_0x3784bf){const _0x2a2e78=[],_0x597e08=[];return _0x1191d0['forEach'](_0x456735=>{_0x456735['type']==='child_changed'&&_0x50dc28['index_']['indexedValueChanged'](_0x456735['oldSnap'],_0x456735['snapshotNode'])&&_0x597e08['push']($h(_0x456735['childName'],_0x456735['snapshotNode']));}),mt(_0x50dc28,_0x2a2e78,'child_removed',_0x1191d0,_0x3784bf,_0x5a741b),mt(_0x50dc28,_0x2a2e78,'child_added',_0x1191d0,_0x3784bf,_0x5a741b),mt(_0x50dc28,_0x2a2e78,'child_moved',_0x597e08,_0x3784bf,_0x5a741b),mt(_0x50dc28,_0x2a2e78,'child_changed',_0x1191d0,_0x3784bf,_0x5a741b),mt(_0x50dc28,_0x2a2e78,'value',_0x1191d0,_0x3784bf,_0x5a741b),_0x2a2e78;}function mt(_0x453475,_0x3087bd,_0xb51bc4,_0x1b8f1f,_0x5331eb,_0x404777){const _0x4cc34b=_0x1b8f1f['filter'](_0x3b7ef4=>_0x3b7ef4['type']===_0xb51bc4);_0x4cc34b['sort']((_0x17f5d0,_0x556d0d)=>su(_0x453475,_0x17f5d0,_0x556d0d)),_0x4cc34b['forEach'](_0x5da3a8=>{const _0x3578bf=iu(_0x453475,_0x5da3a8,_0x404777);_0x5331eb['forEach'](_0x3a6a6b=>{_0x3a6a6b['respondsTo'](_0x5da3a8['type'])&&_0x3087bd['push'](_0x3a6a6b['createEvent'](_0x3578bf,_0x453475['query_']));});});}function iu(_0x506e63,_0x5001ca,_0x24106e){return _0x5001ca['type']==='value'||_0x5001ca['type']==='child_removed'||(_0x5001ca['prevName']=_0x24106e['getPredecessorChildName'](_0x5001ca['childName'],_0x5001ca['snapshotNode'],_0x506e63['index_'])),_0x5001ca;}function su(_0x18a7cd,_0xb415de,_0x51cc0d){if(_0xb415de['childName']==null||_0x51cc0d['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x36b434=new E(_0xb415de['childName'],_0xb415de['snapshotNode']),_0x1f16b6=new E(_0x51cc0d['childName'],_0x51cc0d['snapshotNode']);return _0x18a7cd['index_']['compare'](_0x36b434,_0x1f16b6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xf71ef2,_0x588649){return{'eventCache':_0xf71ef2,'serverCache':_0x588649};}function wt(_0x341c42,_0x646ccd,_0x29c1aa,_0x3f6503){return Dn(new Ce(_0x646ccd,_0x29c1aa,_0x3f6503),_0x341c42['serverCache']);}function Lo(_0x5c3699,_0x10cbf7,_0x5e16f0,_0x599d57){return Dn(_0x5c3699['eventCache'],new Ce(_0x10cbf7,_0x5e16f0,_0x599d57));}function gn(_0x766703){return _0x766703['eventCache']['isFullyInitialized']()?_0x766703['eventCache']['getNode']():null;}function Ue(_0x327b7a){return _0x327b7a['serverCache']['isFullyInitialized']()?_0x327b7a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x11a0b){let _0x556c8c=new S(null);return x(_0x11a0b,(_0x3d9319,_0x4f74c8)=>{_0x556c8c=_0x556c8c['set'](new C(_0x3d9319),_0x4f74c8);}),_0x556c8c;}constructor(_0x245b62,_0x4276ab=ru()){this['value']=_0x245b62,this['children']=_0x4276ab;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x14baac,_0xf455eb){if(this['value']!=null&&_0xf455eb(this['value']))return{'path':w(),'value':this['value']};if(v(_0x14baac))return null;{const _0x54c789=y(_0x14baac),_0xa5205a=this['children']['get'](_0x54c789);if(_0xa5205a!==null){const _0x2ff8cf=_0xa5205a['findRootMostMatchingPathAndValue'](b(_0x14baac),_0xf455eb);return _0x2ff8cf!=null?{'path':A(new C(_0x54c789),_0x2ff8cf['path']),'value':_0x2ff8cf['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4725df){return this['findRootMostMatchingPathAndValue'](_0x4725df,()=>!0x0);}['subtree'](_0x247424){if(v(_0x247424))return this;{const _0x3ebf25=y(_0x247424),_0x3dbc00=this['children']['get'](_0x3ebf25);return _0x3dbc00!==null?_0x3dbc00['subtree'](b(_0x247424)):new S(null);}}['set'](_0x1b80cb,_0x187b7a){if(v(_0x1b80cb))return new S(_0x187b7a,this['children']);{const _0x41c6ed=y(_0x1b80cb),_0x3176ec=(this['children']['get'](_0x41c6ed)||new S(null))['set'](b(_0x1b80cb),_0x187b7a),_0x10cf8e=this['children']['insert'](_0x41c6ed,_0x3176ec);return new S(this['value'],_0x10cf8e);}}['remove'](_0x5cce5b){if(v(_0x5cce5b))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x35c08f=y(_0x5cce5b),_0x5971ce=this['children']['get'](_0x35c08f);if(_0x5971ce){const _0x26c645=_0x5971ce['remove'](b(_0x5cce5b));let _0x279e83;return _0x26c645['isEmpty']()?_0x279e83=this['children']['remove'](_0x35c08f):_0x279e83=this['children']['insert'](_0x35c08f,_0x26c645),this['value']===null&&_0x279e83['isEmpty']()?new S(null):new S(this['value'],_0x279e83);}else return this;}}['get'](_0x54644a){if(v(_0x54644a))return this['value'];{const _0x44b00d=y(_0x54644a),_0x2ff129=this['children']['get'](_0x44b00d);return _0x2ff129?_0x2ff129['get'](b(_0x54644a)):null;}}['setTree'](_0x2df2c3,_0x8188fd){if(v(_0x2df2c3))return _0x8188fd;{const _0x24da34=y(_0x2df2c3),_0x390b42=(this['children']['get'](_0x24da34)||new S(null))['setTree'](b(_0x2df2c3),_0x8188fd);let _0x5c6b94;return _0x390b42['isEmpty']()?_0x5c6b94=this['children']['remove'](_0x24da34):_0x5c6b94=this['children']['insert'](_0x24da34,_0x390b42),new S(this['value'],_0x5c6b94);}}['fold'](_0x43cf00){return this['fold_'](w(),_0x43cf00);}['fold_'](_0x418603,_0x576d32){const _0x4a8651={};return this['children']['inorderTraversal']((_0x1895a6,_0x30dc93)=>{_0x4a8651[_0x1895a6]=_0x30dc93['fold_'](A(_0x418603,_0x1895a6),_0x576d32);}),_0x576d32(_0x418603,this['value'],_0x4a8651);}['findOnPath'](_0x4b7452,_0x1a77fe){return this['findOnPath_'](_0x4b7452,w(),_0x1a77fe);}['findOnPath_'](_0x255182,_0x14cc97,_0xc115a0){const _0x4607c6=this['value']?_0xc115a0(_0x14cc97,this['value']):!0x1;if(_0x4607c6)return _0x4607c6;if(v(_0x255182))return null;{const _0x630d98=y(_0x255182),_0x4453d2=this['children']['get'](_0x630d98);return _0x4453d2?_0x4453d2['findOnPath_'](b(_0x255182),A(_0x14cc97,_0x630d98),_0xc115a0):null;}}['foreachOnPath'](_0x21d20d,_0x5d4dfc){return this['foreachOnPath_'](_0x21d20d,w(),_0x5d4dfc);}['foreachOnPath_'](_0x4d28c6,_0xacbcee,_0x5259b2){if(v(_0x4d28c6))return this;{this['value']&&_0x5259b2(_0xacbcee,this['value']);const _0xa5ccbc=y(_0x4d28c6),_0xf92c7b=this['children']['get'](_0xa5ccbc);return _0xf92c7b?_0xf92c7b['foreachOnPath_'](b(_0x4d28c6),A(_0xacbcee,_0xa5ccbc),_0x5259b2):new S(null);}}['foreach'](_0x5dbcc2){this['foreach_'](w(),_0x5dbcc2);}['foreach_'](_0x152392,_0x14258d){this['children']['inorderTraversal']((_0x4b759b,_0x4f4da3)=>{_0x4f4da3['foreach_'](A(_0x152392,_0x4b759b),_0x14258d);}),this['value']&&_0x14258d(_0x152392,this['value']);}['foreachChild'](_0x5cd5ea){this['children']['inorderTraversal']((_0x20ae93,_0x5616cd)=>{_0x5616cd['value']&&_0x5cd5ea(_0x20ae93,_0x5616cd['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x416ab9){this['writeTree_']=_0x416ab9;}static['empty'](){return new j(new S(null));}}function Ct(_0x46a87b,_0xb75f56,_0x2c0044){if(v(_0xb75f56))return new j(new S(_0x2c0044));{const _0x4991e0=_0x46a87b['writeTree_']['findRootMostValueAndPath'](_0xb75f56);if(_0x4991e0!=null){const _0x5b3478=_0x4991e0['path'];let _0x508526=_0x4991e0['value'];const _0x16c1ed=F(_0x5b3478,_0xb75f56);return _0x508526=_0x508526['updateChild'](_0x16c1ed,_0x2c0044),new j(_0x46a87b['writeTree_']['set'](_0x5b3478,_0x508526));}else{const _0x5b74eb=new S(_0x2c0044),_0x2c3ded=_0x46a87b['writeTree_']['setTree'](_0xb75f56,_0x5b74eb);return new j(_0x2c3ded);}}}function Ii(_0x3b5d10,_0x2d7d64,_0x23606a){let _0x24a473=_0x3b5d10;return x(_0x23606a,(_0x57cdbf,_0x51b3c1)=>{_0x24a473=Ct(_0x24a473,A(_0x2d7d64,_0x57cdbf),_0x51b3c1);}),_0x24a473;}function sr(_0x56c82b,_0x1e06f1){if(v(_0x1e06f1))return j['empty']();{const _0x296f48=_0x56c82b['writeTree_']['setTree'](_0x1e06f1,new S(null));return new j(_0x296f48);}}function wi(_0x10db26,_0x301225){return $e(_0x10db26,_0x301225)!=null;}function $e(_0x22e8d5,_0x116724){const _0x3aae2a=_0x22e8d5['writeTree_']['findRootMostValueAndPath'](_0x116724);return _0x3aae2a!=null?_0x22e8d5['writeTree_']['get'](_0x3aae2a['path'])['getChild'](F(_0x3aae2a['path'],_0x116724)):null;}function rr(_0x48fa56){const _0x4fc1f6=[],_0x4ab031=_0x48fa56['writeTree_']['value'];return _0x4ab031!=null?_0x4ab031['isLeafNode']()||_0x4ab031['forEachChild'](R,(_0x184c32,_0x2f4d3c)=>{_0x4fc1f6['push'](new E(_0x184c32,_0x2f4d3c));}):_0x48fa56['writeTree_']['children']['inorderTraversal']((_0x131522,_0x22e8a1)=>{_0x22e8a1['value']!=null&&_0x4fc1f6['push'](new E(_0x131522,_0x22e8a1['value']));}),_0x4fc1f6;}function ve(_0xb2f022,_0x4a2de7){if(v(_0x4a2de7))return _0xb2f022;{const _0x42e0e3=$e(_0xb2f022,_0x4a2de7);return _0x42e0e3!=null?new j(new S(_0x42e0e3)):new j(_0xb2f022['writeTree_']['subtree'](_0x4a2de7));}}function Ci(_0x4ba2cd){return _0x4ba2cd['writeTree_']['isEmpty']();}function it(_0x92951f,_0x272ce8){return xo(w(),_0x92951f['writeTree_'],_0x272ce8);}function xo(_0x3f8e6c,_0x1ca672,_0x1cb0ba){if(_0x1ca672['value']!=null)return _0x1cb0ba['updateChild'](_0x3f8e6c,_0x1ca672['value']);{let _0x4e9390=null;return _0x1ca672['children']['inorderTraversal']((_0x330b88,_0xcff1e)=>{_0x330b88==='.priority'?(f(_0xcff1e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4e9390=_0xcff1e['value']):_0x1cb0ba=xo(A(_0x3f8e6c,_0x330b88),_0xcff1e,_0x1cb0ba);}),!_0x1cb0ba['getChild'](_0x3f8e6c)['isEmpty']()&&_0x4e9390!==null&&(_0x1cb0ba=_0x1cb0ba['updateChild'](A(_0x3f8e6c,'.priority'),_0x4e9390)),_0x1cb0ba;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3b5a6e,_0x53138a){return Bo(_0x53138a,_0x3b5a6e);}function ou(_0x2ccd71,_0x57bd9b,_0x3b4a40,_0x4fce51,_0x5b089c){f(_0x4fce51>_0x2ccd71['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5b089c===void 0x0&&(_0x5b089c=!0x0),_0x2ccd71['allWrites']['push']({'path':_0x57bd9b,'snap':_0x3b4a40,'writeId':_0x4fce51,'visible':_0x5b089c}),_0x5b089c&&(_0x2ccd71['visibleWrites']=Ct(_0x2ccd71['visibleWrites'],_0x57bd9b,_0x3b4a40)),_0x2ccd71['lastWriteId']=_0x4fce51;}function au(_0x504874,_0x23076a,_0x1fbcd2,_0x8b4e57){f(_0x8b4e57>_0x504874['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x504874['allWrites']['push']({'path':_0x23076a,'children':_0x1fbcd2,'writeId':_0x8b4e57,'visible':!0x0}),_0x504874['visibleWrites']=Ii(_0x504874['visibleWrites'],_0x23076a,_0x1fbcd2),_0x504874['lastWriteId']=_0x8b4e57;}function cu(_0x203141,_0x2b0561){for(let _0x14132d=0x0;_0x14132d<_0x203141['allWrites']['length'];_0x14132d++){const _0x504b31=_0x203141['allWrites'][_0x14132d];if(_0x504b31['writeId']===_0x2b0561)return _0x504b31;}return null;}function lu(_0x31e4c9,_0x3c97be){const _0x2a2a0f=_0x31e4c9['allWrites']['findIndex'](_0x1aae19=>_0x1aae19['writeId']===_0x3c97be);f(_0x2a2a0f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x41bcfc=_0x31e4c9['allWrites'][_0x2a2a0f];_0x31e4c9['allWrites']['splice'](_0x2a2a0f,0x1);let _0x19b806=_0x41bcfc['visible'],_0x3277d6=!0x1,_0x2c2d06=_0x31e4c9['allWrites']['length']-0x1;for(;_0x19b806&&_0x2c2d06>=0x0;){const _0x44bf3a=_0x31e4c9['allWrites'][_0x2c2d06];_0x44bf3a['visible']&&(_0x2c2d06>=_0x2a2a0f&&hu(_0x44bf3a,_0x41bcfc['path'])?_0x19b806=!0x1:$(_0x41bcfc['path'],_0x44bf3a['path'])&&(_0x3277d6=!0x0)),_0x2c2d06--;}if(_0x19b806){if(_0x3277d6)return uu(_0x31e4c9),!0x0;if(_0x41bcfc['snap'])_0x31e4c9['visibleWrites']=sr(_0x31e4c9['visibleWrites'],_0x41bcfc['path']);else{const _0x2ff369=_0x41bcfc['children'];x(_0x2ff369,_0x681f1a=>{_0x31e4c9['visibleWrites']=sr(_0x31e4c9['visibleWrites'],A(_0x41bcfc['path'],_0x681f1a));});}return!0x0;}else return!0x1;}function hu(_0x3cd9c7,_0x5ea9bf){if(_0x3cd9c7['snap'])return $(_0x3cd9c7['path'],_0x5ea9bf);for(const _0x374cc9 in _0x3cd9c7['children'])if(_0x3cd9c7['children']['hasOwnProperty'](_0x374cc9)&&$(A(_0x3cd9c7['path'],_0x374cc9),_0x5ea9bf))return!0x0;return!0x1;}function uu(_0x34b69e){_0x34b69e['visibleWrites']=Fo(_0x34b69e['allWrites'],du,w()),_0x34b69e['allWrites']['length']>0x0?_0x34b69e['lastWriteId']=_0x34b69e['allWrites'][_0x34b69e['allWrites']['length']-0x1]['writeId']:_0x34b69e['lastWriteId']=-0x1;}function du(_0x338498){return _0x338498['visible'];}function Fo(_0x2e6679,_0x30e368,_0x16416d){let _0xc0638e=j['empty']();for(let _0x518961=0x0;_0x518961<_0x2e6679['length'];++_0x518961){const _0x1acb06=_0x2e6679[_0x518961];if(_0x30e368(_0x1acb06)){const _0x1c423b=_0x1acb06['path'];let _0x54116c;if(_0x1acb06['snap'])$(_0x16416d,_0x1c423b)?(_0x54116c=F(_0x16416d,_0x1c423b),_0xc0638e=Ct(_0xc0638e,_0x54116c,_0x1acb06['snap'])):$(_0x1c423b,_0x16416d)&&(_0x54116c=F(_0x1c423b,_0x16416d),_0xc0638e=Ct(_0xc0638e,w(),_0x1acb06['snap']['getChild'](_0x54116c)));else{if(_0x1acb06['children']){if($(_0x16416d,_0x1c423b))_0x54116c=F(_0x16416d,_0x1c423b),_0xc0638e=Ii(_0xc0638e,_0x54116c,_0x1acb06['children']);else{if($(_0x1c423b,_0x16416d)){if(_0x54116c=F(_0x1c423b,_0x16416d),v(_0x54116c))_0xc0638e=Ii(_0xc0638e,w(),_0x1acb06['children']);else{const _0xb626c3=Oe(_0x1acb06['children'],y(_0x54116c));if(_0xb626c3){const _0x163739=_0xb626c3['getChild'](b(_0x54116c));_0xc0638e=Ct(_0xc0638e,w(),_0x163739);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xc0638e;}function Uo(_0x2df547,_0x5aaaf2,_0x1d1f28,_0x1f30a8,_0x255e34){if(!_0x1f30a8&&!_0x255e34){const _0x4ad2b8=$e(_0x2df547['visibleWrites'],_0x5aaaf2);if(_0x4ad2b8!=null)return _0x4ad2b8;{const _0x4a359d=ve(_0x2df547['visibleWrites'],_0x5aaaf2);if(Ci(_0x4a359d))return _0x1d1f28;if(_0x1d1f28==null&&!wi(_0x4a359d,w()))return null;{const _0x167eea=_0x1d1f28||g['EMPTY_NODE'];return it(_0x4a359d,_0x167eea);}}}else{const _0x9c22db=ve(_0x2df547['visibleWrites'],_0x5aaaf2);if(!_0x255e34&&Ci(_0x9c22db))return _0x1d1f28;if(!_0x255e34&&_0x1d1f28==null&&!wi(_0x9c22db,w()))return null;{const _0x562e8a=function(_0x500396){return(_0x500396['visible']||_0x255e34)&&(!_0x1f30a8||!~_0x1f30a8['indexOf'](_0x500396['writeId']))&&($(_0x500396['path'],_0x5aaaf2)||$(_0x5aaaf2,_0x500396['path']));},_0x18bc4a=Fo(_0x2df547['allWrites'],_0x562e8a,_0x5aaaf2),_0x2da7bf=_0x1d1f28||g['EMPTY_NODE'];return it(_0x18bc4a,_0x2da7bf);}}}function fu(_0x26d48a,_0x332caa,_0x1c3d43){let _0x1eba15=g['EMPTY_NODE'];const _0x3be8ac=$e(_0x26d48a['visibleWrites'],_0x332caa);if(_0x3be8ac)return _0x3be8ac['isLeafNode']()||_0x3be8ac['forEachChild'](R,(_0x28aa12,_0x36a6fa)=>{_0x1eba15=_0x1eba15['updateImmediateChild'](_0x28aa12,_0x36a6fa);}),_0x1eba15;if(_0x1c3d43){const _0x443db1=ve(_0x26d48a['visibleWrites'],_0x332caa);return _0x1c3d43['forEachChild'](R,(_0x5832f8,_0x1c5b56)=>{const _0x26969a=it(ve(_0x443db1,new C(_0x5832f8)),_0x1c5b56);_0x1eba15=_0x1eba15['updateImmediateChild'](_0x5832f8,_0x26969a);}),rr(_0x443db1)['forEach'](_0x501e0a=>{_0x1eba15=_0x1eba15['updateImmediateChild'](_0x501e0a['name'],_0x501e0a['node']);}),_0x1eba15;}else{const _0x245171=ve(_0x26d48a['visibleWrites'],_0x332caa);return rr(_0x245171)['forEach'](_0x3a2d01=>{_0x1eba15=_0x1eba15['updateImmediateChild'](_0x3a2d01['name'],_0x3a2d01['node']);}),_0x1eba15;}}function pu(_0x369597,_0x1e0b7f,_0x22a7ac,_0x178a29,_0x1586b7){f(_0x178a29||_0x1586b7,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2b445a=A(_0x1e0b7f,_0x22a7ac);if(wi(_0x369597['visibleWrites'],_0x2b445a))return null;{const _0x2047ca=ve(_0x369597['visibleWrites'],_0x2b445a);return Ci(_0x2047ca)?_0x1586b7['getChild'](_0x22a7ac):it(_0x2047ca,_0x1586b7['getChild'](_0x22a7ac));}}function _u(_0x4c2d51,_0x39c050,_0x69c92f,_0x1776b8){const _0x2913b0=A(_0x39c050,_0x69c92f),_0x301f38=$e(_0x4c2d51['visibleWrites'],_0x2913b0);if(_0x301f38!=null)return _0x301f38;if(_0x1776b8['isCompleteForChild'](_0x69c92f)){const _0x1a0d79=ve(_0x4c2d51['visibleWrites'],_0x2913b0);return it(_0x1a0d79,_0x1776b8['getNode']()['getImmediateChild'](_0x69c92f));}else return null;}function gu(_0x425509,_0x4f4305){return $e(_0x425509['visibleWrites'],_0x4f4305);}function mu(_0x35800c,_0x3dc7bb,_0x4c2153,_0x20c7e3,_0x2d2aa7,_0x298ae9,_0x363efe){let _0x25b1db;const _0x204eb1=ve(_0x35800c['visibleWrites'],_0x3dc7bb),_0xb6107f=$e(_0x204eb1,w());if(_0xb6107f!=null)_0x25b1db=_0xb6107f;else{if(_0x4c2153!=null)_0x25b1db=it(_0x204eb1,_0x4c2153);else return[];}if(_0x25b1db=_0x25b1db['withIndex'](_0x363efe),!_0x25b1db['isEmpty']()&&!_0x25b1db['isLeafNode']()){const _0x301647=[],_0x2ce2df=_0x363efe['getCompare'](),_0x5745a6=_0x298ae9?_0x25b1db['getReverseIteratorFrom'](_0x20c7e3,_0x363efe):_0x25b1db['getIteratorFrom'](_0x20c7e3,_0x363efe);let _0x2cfdcc=_0x5745a6['getNext']();for(;_0x2cfdcc&&_0x301647['length']<_0x2d2aa7;)_0x2ce2df(_0x2cfdcc,_0x20c7e3)!==0x0&&_0x301647['push'](_0x2cfdcc),_0x2cfdcc=_0x5745a6['getNext']();return _0x301647;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1a68ea,_0x3b2812,_0x5d8d55,_0x57eb4c){return Uo(_0x1a68ea['writeTree'],_0x1a68ea['treePath'],_0x3b2812,_0x5d8d55,_0x57eb4c);}function es(_0x285736,_0x273848){return fu(_0x285736['writeTree'],_0x285736['treePath'],_0x273848);}function or(_0x4efd56,_0x2774b0,_0x5cf21f,_0x30b58a){return pu(_0x4efd56['writeTree'],_0x4efd56['treePath'],_0x2774b0,_0x5cf21f,_0x30b58a);}function yn(_0x206957,_0x4ee8e3){return gu(_0x206957['writeTree'],A(_0x206957['treePath'],_0x4ee8e3));}function vu(_0x1e18bc,_0xf6f9ef,_0xb7318b,_0x1cc1f1,_0x4b34ae,_0xd02ad9){return mu(_0x1e18bc['writeTree'],_0x1e18bc['treePath'],_0xf6f9ef,_0xb7318b,_0x1cc1f1,_0x4b34ae,_0xd02ad9);}function ts(_0x2b8c84,_0x592294,_0xf38be7){return _u(_0x2b8c84['writeTree'],_0x2b8c84['treePath'],_0x592294,_0xf38be7);}function Wo(_0x3358f6,_0xbb6c5b){return Bo(A(_0x3358f6['treePath'],_0xbb6c5b),_0x3358f6['writeTree']);}function Bo(_0x2b6355,_0x20ef0b){return{'treePath':_0x2b6355,'writeTree':_0x20ef0b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x367a2c){const _0x22fc57=_0x367a2c['type'],_0xd3c0a9=_0x367a2c['childName'];f(_0x22fc57==='child_added'||_0x22fc57==='child_changed'||_0x22fc57==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xd3c0a9!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x558fa8=this['changeMap']['get'](_0xd3c0a9);if(_0x558fa8){const _0x374dd1=_0x558fa8['type'];if(_0x22fc57==='child_added'&&_0x374dd1==='child_removed')this['changeMap']['set'](_0xd3c0a9,Pt(_0xd3c0a9,_0x367a2c['snapshotNode'],_0x558fa8['snapshotNode']));else{if(_0x22fc57==='child_removed'&&_0x374dd1==='child_added')this['changeMap']['delete'](_0xd3c0a9);else{if(_0x22fc57==='child_removed'&&_0x374dd1==='child_changed')this['changeMap']['set'](_0xd3c0a9,Nt(_0xd3c0a9,_0x558fa8['oldSnap']));else{if(_0x22fc57==='child_changed'&&_0x374dd1==='child_added')this['changeMap']['set'](_0xd3c0a9,tt(_0xd3c0a9,_0x367a2c['snapshotNode']));else{if(_0x22fc57==='child_changed'&&_0x374dd1==='child_changed')this['changeMap']['set'](_0xd3c0a9,Pt(_0xd3c0a9,_0x367a2c['snapshotNode'],_0x558fa8['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x367a2c+'\x20occurred\x20after\x20'+_0x558fa8);}}}}}else this['changeMap']['set'](_0xd3c0a9,_0x367a2c);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x3954d0){return null;}['getChildAfterChild'](_0x495e77,_0x3b6c9d,_0x49a48d){return null;}}const Vo=new Iu();class ns{constructor(_0x462aa9,_0x21b77f,_0x423e2c=null){this['writes_']=_0x462aa9,this['viewCache_']=_0x21b77f,this['optCompleteServerCache_']=_0x423e2c;}['getCompleteChild'](_0x2eaa57){const _0x5c076b=this['viewCache_']['eventCache'];if(_0x5c076b['isCompleteForChild'](_0x2eaa57))return _0x5c076b['getNode']()['getImmediateChild'](_0x2eaa57);{const _0xf23e12=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x2eaa57,_0xf23e12);}}['getChildAfterChild'](_0x1c64f8,_0x15bae6,_0x1937ac){const _0x37110e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x43b87d=vu(this['writes_'],_0x37110e,_0x15bae6,0x1,_0x1937ac,_0x1c64f8);return _0x43b87d['length']===0x0?null:_0x43b87d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3eaf00){return{'filter':_0x3eaf00};}function Cu(_0x1c4bd1,_0x33db65){f(_0x33db65['eventCache']['getNode']()['isIndexed'](_0x1c4bd1['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x33db65['serverCache']['getNode']()['isIndexed'](_0x1c4bd1['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5caad5,_0x2d5373,_0x29048a,_0x1c2834,_0x23c951){const _0x18068b=new Eu();let _0x35d043,_0x6782a8;if(_0x29048a['type']===q['OVERWRITE']){const _0x5556df=_0x29048a;_0x5556df['source']['fromUser']?_0x35d043=Ti(_0x5caad5,_0x2d5373,_0x5556df['path'],_0x5556df['snap'],_0x1c2834,_0x23c951,_0x18068b):(f(_0x5556df['source']['fromServer'],'Unknown\x20source.'),_0x6782a8=_0x5556df['source']['tagged']||_0x2d5373['serverCache']['isFiltered']()&&!v(_0x5556df['path']),_0x35d043=vn(_0x5caad5,_0x2d5373,_0x5556df['path'],_0x5556df['snap'],_0x1c2834,_0x23c951,_0x6782a8,_0x18068b));}else{if(_0x29048a['type']===q['MERGE']){const _0x29fcd4=_0x29048a;_0x29fcd4['source']['fromUser']?_0x35d043=bu(_0x5caad5,_0x2d5373,_0x29fcd4['path'],_0x29fcd4['children'],_0x1c2834,_0x23c951,_0x18068b):(f(_0x29fcd4['source']['fromServer'],'Unknown\x20source.'),_0x6782a8=_0x29fcd4['source']['tagged']||_0x2d5373['serverCache']['isFiltered'](),_0x35d043=Si(_0x5caad5,_0x2d5373,_0x29fcd4['path'],_0x29fcd4['children'],_0x1c2834,_0x23c951,_0x6782a8,_0x18068b));}else{if(_0x29048a['type']===q['ACK_USER_WRITE']){const _0x31ca3f=_0x29048a;_0x31ca3f['revert']?_0x35d043=ku(_0x5caad5,_0x2d5373,_0x31ca3f['path'],_0x1c2834,_0x23c951,_0x18068b):_0x35d043=Ru(_0x5caad5,_0x2d5373,_0x31ca3f['path'],_0x31ca3f['affectedTree'],_0x1c2834,_0x23c951,_0x18068b);}else{if(_0x29048a['type']===q['LISTEN_COMPLETE'])_0x35d043=Au(_0x5caad5,_0x2d5373,_0x29048a['path'],_0x1c2834,_0x18068b);else throw ot('Unknown\x20operation\x20type:\x20'+_0x29048a['type']);}}}const _0x416d44=_0x18068b['getChanges']();return Su(_0x2d5373,_0x35d043,_0x416d44),{'viewCache':_0x35d043,'changes':_0x416d44};}function Su(_0x16d539,_0x2fa548,_0x1ea047){const _0x12806b=_0x2fa548['eventCache'];if(_0x12806b['isFullyInitialized']()){const _0x4ce33b=_0x12806b['getNode']()['isLeafNode']()||_0x12806b['getNode']()['isEmpty'](),_0x12942f=gn(_0x16d539);(_0x1ea047['length']>0x0||!_0x16d539['eventCache']['isFullyInitialized']()||_0x4ce33b&&!_0x12806b['getNode']()['equals'](_0x12942f)||!_0x12806b['getNode']()['getPriority']()['equals'](_0x12942f['getPriority']()))&&_0x1ea047['push'](Oo(gn(_0x2fa548)));}}function Ho(_0x442fb5,_0x125af6,_0xda4a58,_0x380705,_0x193be3,_0x1075af){const _0x2b67d2=_0x125af6['eventCache'];if(yn(_0x380705,_0xda4a58)!=null)return _0x125af6;{let _0x6eea47,_0x5e81a1;if(v(_0xda4a58)){if(f(_0x125af6['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x125af6['serverCache']['isFiltered']()){const _0x1bade6=Ue(_0x125af6),_0x7f6d02=_0x1bade6 instanceof g?_0x1bade6:g['EMPTY_NODE'],_0x170651=es(_0x380705,_0x7f6d02);_0x6eea47=_0x442fb5['filter']['updateFullNode'](_0x125af6['eventCache']['getNode'](),_0x170651,_0x1075af);}else{const _0x346666=mn(_0x380705,Ue(_0x125af6));_0x6eea47=_0x442fb5['filter']['updateFullNode'](_0x125af6['eventCache']['getNode'](),_0x346666,_0x1075af);}}else{const _0x157b79=y(_0xda4a58);if(_0x157b79==='.priority'){f(we(_0xda4a58)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x43df37=_0x2b67d2['getNode']();_0x5e81a1=_0x125af6['serverCache']['getNode']();const _0x7c1527=or(_0x380705,_0xda4a58,_0x43df37,_0x5e81a1);_0x7c1527!=null?_0x6eea47=_0x442fb5['filter']['updatePriority'](_0x43df37,_0x7c1527):_0x6eea47=_0x2b67d2['getNode']();}else{const _0x28361b=b(_0xda4a58);let _0xe5a901;if(_0x2b67d2['isCompleteForChild'](_0x157b79)){_0x5e81a1=_0x125af6['serverCache']['getNode']();const _0x584625=or(_0x380705,_0xda4a58,_0x2b67d2['getNode'](),_0x5e81a1);_0x584625!=null?_0xe5a901=_0x2b67d2['getNode']()['getImmediateChild'](_0x157b79)['updateChild'](_0x28361b,_0x584625):_0xe5a901=_0x2b67d2['getNode']()['getImmediateChild'](_0x157b79);}else _0xe5a901=ts(_0x380705,_0x157b79,_0x125af6['serverCache']);_0xe5a901!=null?_0x6eea47=_0x442fb5['filter']['updateChild'](_0x2b67d2['getNode'](),_0x157b79,_0xe5a901,_0x28361b,_0x193be3,_0x1075af):_0x6eea47=_0x2b67d2['getNode']();}}return wt(_0x125af6,_0x6eea47,_0x2b67d2['isFullyInitialized']()||v(_0xda4a58),_0x442fb5['filter']['filtersNodes']());}}function vn(_0x17d6b8,_0x4ca6f4,_0x35bb29,_0xc04917,_0x26974e,_0x38aea8,_0x3356f1,_0x857c0b){const _0x3db1b5=_0x4ca6f4['serverCache'];let _0x6f1136;const _0x3a3a58=_0x3356f1?_0x17d6b8['filter']:_0x17d6b8['filter']['getIndexedFilter']();if(v(_0x35bb29))_0x6f1136=_0x3a3a58['updateFullNode'](_0x3db1b5['getNode'](),_0xc04917,null);else{if(_0x3a3a58['filtersNodes']()&&!_0x3db1b5['isFiltered']()){const _0x567b25=_0x3db1b5['getNode']()['updateChild'](_0x35bb29,_0xc04917);_0x6f1136=_0x3a3a58['updateFullNode'](_0x3db1b5['getNode'](),_0x567b25,null);}else{const _0x91cc34=y(_0x35bb29);if(!_0x3db1b5['isCompleteForPath'](_0x35bb29)&&we(_0x35bb29)>0x1)return _0x4ca6f4;const _0x2ffe8c=b(_0x35bb29),_0x1ea643=_0x3db1b5['getNode']()['getImmediateChild'](_0x91cc34)['updateChild'](_0x2ffe8c,_0xc04917);_0x91cc34==='.priority'?_0x6f1136=_0x3a3a58['updatePriority'](_0x3db1b5['getNode'](),_0x1ea643):_0x6f1136=_0x3a3a58['updateChild'](_0x3db1b5['getNode'](),_0x91cc34,_0x1ea643,_0x2ffe8c,Vo,null);}}const _0x2ca41a=Lo(_0x4ca6f4,_0x6f1136,_0x3db1b5['isFullyInitialized']()||v(_0x35bb29),_0x3a3a58['filtersNodes']()),_0x5fe634=new ns(_0x26974e,_0x2ca41a,_0x38aea8);return Ho(_0x17d6b8,_0x2ca41a,_0x35bb29,_0x26974e,_0x5fe634,_0x857c0b);}function Ti(_0x293e6c,_0x3fb91c,_0x4b3213,_0x44992a,_0x456231,_0x3b1723,_0x28fcbd){const _0x17fd84=_0x3fb91c['eventCache'];let _0x589d0f,_0x2b0fa8;const _0x2b0eb6=new ns(_0x456231,_0x3fb91c,_0x3b1723);if(v(_0x4b3213))_0x2b0fa8=_0x293e6c['filter']['updateFullNode'](_0x3fb91c['eventCache']['getNode'](),_0x44992a,_0x28fcbd),_0x589d0f=wt(_0x3fb91c,_0x2b0fa8,!0x0,_0x293e6c['filter']['filtersNodes']());else{const _0x22dc12=y(_0x4b3213);if(_0x22dc12==='.priority')_0x2b0fa8=_0x293e6c['filter']['updatePriority'](_0x3fb91c['eventCache']['getNode'](),_0x44992a),_0x589d0f=wt(_0x3fb91c,_0x2b0fa8,_0x17fd84['isFullyInitialized'](),_0x17fd84['isFiltered']());else{const _0x2b31df=b(_0x4b3213),_0x507d03=_0x17fd84['getNode']()['getImmediateChild'](_0x22dc12);let _0x3533ef;if(v(_0x2b31df))_0x3533ef=_0x44992a;else{const _0x48f4cd=_0x2b0eb6['getCompleteChild'](_0x22dc12);_0x48f4cd!=null?Gi(_0x2b31df)==='.priority'&&_0x48f4cd['getChild'](To(_0x2b31df))['isEmpty']()?_0x3533ef=_0x48f4cd:_0x3533ef=_0x48f4cd['updateChild'](_0x2b31df,_0x44992a):_0x3533ef=g['EMPTY_NODE'];}if(_0x507d03['equals'](_0x3533ef))_0x589d0f=_0x3fb91c;else{const _0x4c9534=_0x293e6c['filter']['updateChild'](_0x17fd84['getNode'](),_0x22dc12,_0x3533ef,_0x2b31df,_0x2b0eb6,_0x28fcbd);_0x589d0f=wt(_0x3fb91c,_0x4c9534,_0x17fd84['isFullyInitialized'](),_0x293e6c['filter']['filtersNodes']());}}}return _0x589d0f;}function ar(_0x32537b,_0x36eab9){return _0x32537b['eventCache']['isCompleteForChild'](_0x36eab9);}function bu(_0x4eee99,_0x399948,_0x45b792,_0x88dd7c,_0xfce16b,_0x19d7ea,_0x19d3d1){let _0xace3bc=_0x399948;return _0x88dd7c['foreach']((_0x2beb5d,_0xe50a63)=>{const _0x217291=A(_0x45b792,_0x2beb5d);ar(_0x399948,y(_0x217291))&&(_0xace3bc=Ti(_0x4eee99,_0xace3bc,_0x217291,_0xe50a63,_0xfce16b,_0x19d7ea,_0x19d3d1));}),_0x88dd7c['foreach']((_0x7258ef,_0x30964f)=>{const _0x4c1441=A(_0x45b792,_0x7258ef);ar(_0x399948,y(_0x4c1441))||(_0xace3bc=Ti(_0x4eee99,_0xace3bc,_0x4c1441,_0x30964f,_0xfce16b,_0x19d7ea,_0x19d3d1));}),_0xace3bc;}function cr(_0x18f555,_0x3b1f1e,_0x46c235){return _0x46c235['foreach']((_0x1a3a48,_0x2474df)=>{_0x3b1f1e=_0x3b1f1e['updateChild'](_0x1a3a48,_0x2474df);}),_0x3b1f1e;}function Si(_0x358734,_0x1b33d8,_0x2e42dc,_0x5c7026,_0x1c05df,_0x22c09e,_0x24c73b,_0x3f67ee){if(_0x1b33d8['serverCache']['getNode']()['isEmpty']()&&!_0x1b33d8['serverCache']['isFullyInitialized']())return _0x1b33d8;let _0x62cef6=_0x1b33d8,_0xe11e94;v(_0x2e42dc)?_0xe11e94=_0x5c7026:_0xe11e94=new S(null)['setTree'](_0x2e42dc,_0x5c7026);const _0x4b2524=_0x1b33d8['serverCache']['getNode']();return _0xe11e94['children']['inorderTraversal']((_0x2d6332,_0x35cc41)=>{if(_0x4b2524['hasChild'](_0x2d6332)){const _0x2b043e=_0x1b33d8['serverCache']['getNode']()['getImmediateChild'](_0x2d6332),_0x2c9335=cr(_0x358734,_0x2b043e,_0x35cc41);_0x62cef6=vn(_0x358734,_0x62cef6,new C(_0x2d6332),_0x2c9335,_0x1c05df,_0x22c09e,_0x24c73b,_0x3f67ee);}}),_0xe11e94['children']['inorderTraversal']((_0x58ec8d,_0xfbd18a)=>{const _0x56beca=!_0x1b33d8['serverCache']['isCompleteForChild'](_0x58ec8d)&&_0xfbd18a['value']===null;if(!_0x4b2524['hasChild'](_0x58ec8d)&&!_0x56beca){const _0xc9b440=_0x1b33d8['serverCache']['getNode']()['getImmediateChild'](_0x58ec8d),_0x4afa5f=cr(_0x358734,_0xc9b440,_0xfbd18a);_0x62cef6=vn(_0x358734,_0x62cef6,new C(_0x58ec8d),_0x4afa5f,_0x1c05df,_0x22c09e,_0x24c73b,_0x3f67ee);}}),_0x62cef6;}function Ru(_0x46d71b,_0x156a52,_0x4650d6,_0x94847b,_0x243b6b,_0x20d603,_0x5be2f7){if(yn(_0x243b6b,_0x4650d6)!=null)return _0x156a52;const _0x176d1b=_0x156a52['serverCache']['isFiltered'](),_0x2648d1=_0x156a52['serverCache'];if(_0x94847b['value']!=null){if(v(_0x4650d6)&&_0x2648d1['isFullyInitialized']()||_0x2648d1['isCompleteForPath'](_0x4650d6))return vn(_0x46d71b,_0x156a52,_0x4650d6,_0x2648d1['getNode']()['getChild'](_0x4650d6),_0x243b6b,_0x20d603,_0x176d1b,_0x5be2f7);if(v(_0x4650d6)){let _0x596716=new S(null);return _0x2648d1['getNode']()['forEachChild'](ye,(_0x50451a,_0x2fac42)=>{_0x596716=_0x596716['set'](new C(_0x50451a),_0x2fac42);}),Si(_0x46d71b,_0x156a52,_0x4650d6,_0x596716,_0x243b6b,_0x20d603,_0x176d1b,_0x5be2f7);}else return _0x156a52;}else{let _0x22bb32=new S(null);return _0x94847b['foreach']((_0x878332,_0x3a4f85)=>{const _0x5337d6=A(_0x4650d6,_0x878332);_0x2648d1['isCompleteForPath'](_0x5337d6)&&(_0x22bb32=_0x22bb32['set'](_0x878332,_0x2648d1['getNode']()['getChild'](_0x5337d6)));}),Si(_0x46d71b,_0x156a52,_0x4650d6,_0x22bb32,_0x243b6b,_0x20d603,_0x176d1b,_0x5be2f7);}}function Au(_0x3535c2,_0x38100a,_0x5923fe,_0x1a7ae1,_0x19ddc6){const _0x5dcc39=_0x38100a['serverCache'],_0x14dcb7=Lo(_0x38100a,_0x5dcc39['getNode'](),_0x5dcc39['isFullyInitialized']()||v(_0x5923fe),_0x5dcc39['isFiltered']());return Ho(_0x3535c2,_0x14dcb7,_0x5923fe,_0x1a7ae1,Vo,_0x19ddc6);}function ku(_0x472e52,_0x30626d,_0x440dd2,_0x569b95,_0x3ff486,_0x137513){let _0x723c26;if(yn(_0x569b95,_0x440dd2)!=null)return _0x30626d;{const _0x3a388b=new ns(_0x569b95,_0x30626d,_0x3ff486),_0x21490c=_0x30626d['eventCache']['getNode']();let _0x4790a7;if(v(_0x440dd2)||y(_0x440dd2)==='.priority'){let _0x3230b5;if(_0x30626d['serverCache']['isFullyInitialized']())_0x3230b5=mn(_0x569b95,Ue(_0x30626d));else{const _0x330cf1=_0x30626d['serverCache']['getNode']();f(_0x330cf1 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3230b5=es(_0x569b95,_0x330cf1);}_0x3230b5=_0x3230b5,_0x4790a7=_0x472e52['filter']['updateFullNode'](_0x21490c,_0x3230b5,_0x137513);}else{const _0x3c7545=y(_0x440dd2);let _0x4f6c8a=ts(_0x569b95,_0x3c7545,_0x30626d['serverCache']);_0x4f6c8a==null&&_0x30626d['serverCache']['isCompleteForChild'](_0x3c7545)&&(_0x4f6c8a=_0x21490c['getImmediateChild'](_0x3c7545)),_0x4f6c8a!=null?_0x4790a7=_0x472e52['filter']['updateChild'](_0x21490c,_0x3c7545,_0x4f6c8a,b(_0x440dd2),_0x3a388b,_0x137513):_0x30626d['eventCache']['getNode']()['hasChild'](_0x3c7545)?_0x4790a7=_0x472e52['filter']['updateChild'](_0x21490c,_0x3c7545,g['EMPTY_NODE'],b(_0x440dd2),_0x3a388b,_0x137513):_0x4790a7=_0x21490c,_0x4790a7['isEmpty']()&&_0x30626d['serverCache']['isFullyInitialized']()&&(_0x723c26=mn(_0x569b95,Ue(_0x30626d)),_0x723c26['isLeafNode']()&&(_0x4790a7=_0x472e52['filter']['updateFullNode'](_0x4790a7,_0x723c26,_0x137513)));}return _0x723c26=_0x30626d['serverCache']['isFullyInitialized']()||yn(_0x569b95,w())!=null,wt(_0x30626d,_0x4790a7,_0x723c26,_0x472e52['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0xdfa82d,_0x1963d9){this['query_']=_0xdfa82d,this['eventRegistrations_']=[];const _0x3d6566=this['query_']['_queryParams'],_0x504d5f=new Yi(_0x3d6566['getIndex']()),_0x55e36b=qh(_0x3d6566);this['processor_']=wu(_0x55e36b);const _0xd4bf6c=_0x1963d9['serverCache'],_0x545521=_0x1963d9['eventCache'],_0x19af56=_0x504d5f['updateFullNode'](g['EMPTY_NODE'],_0xd4bf6c['getNode'](),null),_0x28eb5b=_0x55e36b['updateFullNode'](g['EMPTY_NODE'],_0x545521['getNode'](),null),_0x4b7c47=new Ce(_0x19af56,_0xd4bf6c['isFullyInitialized'](),_0x504d5f['filtersNodes']()),_0x35662b=new Ce(_0x28eb5b,_0x545521['isFullyInitialized'](),_0x55e36b['filtersNodes']());this['viewCache_']=Dn(_0x35662b,_0x4b7c47),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x42c214){return _0x42c214['viewCache_']['serverCache']['getNode']();}function Ou(_0x172b7a){return gn(_0x172b7a['viewCache_']);}function Du(_0x3d369a,_0x3df63d){const _0x5e1caa=Ue(_0x3d369a['viewCache_']);return _0x5e1caa&&(_0x3d369a['query']['_queryParams']['loadsAllData']()||!v(_0x3df63d)&&!_0x5e1caa['getImmediateChild'](y(_0x3df63d))['isEmpty']())?_0x5e1caa['getChild'](_0x3df63d):null;}function lr(_0x586f92){return _0x586f92['eventRegistrations_']['length']===0x0;}function Mu(_0x203e06,_0x411797){_0x203e06['eventRegistrations_']['push'](_0x411797);}function hr(_0x36ac2b,_0x3de1e1,_0xd36744){const _0x13ab79=[];if(_0xd36744){f(_0x3de1e1==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1c470b=_0x36ac2b['query']['_path'];_0x36ac2b['eventRegistrations_']['forEach'](_0xd09d9f=>{const _0x5d7c22=_0xd09d9f['createCancelEvent'](_0xd36744,_0x1c470b);_0x5d7c22&&_0x13ab79['push'](_0x5d7c22);});}if(_0x3de1e1){let _0x1ed550=[];for(let _0x6ffd18=0x0;_0x6ffd18<_0x36ac2b['eventRegistrations_']['length'];++_0x6ffd18){const _0x4147f3=_0x36ac2b['eventRegistrations_'][_0x6ffd18];if(!_0x4147f3['matches'](_0x3de1e1))_0x1ed550['push'](_0x4147f3);else{if(_0x3de1e1['hasAnyCallback']()){_0x1ed550=_0x1ed550['concat'](_0x36ac2b['eventRegistrations_']['slice'](_0x6ffd18+0x1));break;}}}_0x36ac2b['eventRegistrations_']=_0x1ed550;}else _0x36ac2b['eventRegistrations_']=[];return _0x13ab79;}function ur(_0x2c60ac,_0x41a902,_0xf67600,_0x5242ff){_0x41a902['type']===q['MERGE']&&_0x41a902['source']['queryId']!==null&&(f(Ue(_0x2c60ac['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2c60ac['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x22ef79=_0x2c60ac['viewCache_'],_0x35a1ca=Tu(_0x2c60ac['processor_'],_0x22ef79,_0x41a902,_0xf67600,_0x5242ff);return Cu(_0x2c60ac['processor_'],_0x35a1ca['viewCache']),f(_0x35a1ca['viewCache']['serverCache']['isFullyInitialized']()||!_0x22ef79['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2c60ac['viewCache_']=_0x35a1ca['viewCache'],$o(_0x2c60ac,_0x35a1ca['changes'],_0x35a1ca['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x49c6a2,_0x25946f){const _0x4ad48b=_0x49c6a2['viewCache_']['eventCache'],_0x1c70d8=[];return _0x4ad48b['getNode']()['isLeafNode']()||_0x4ad48b['getNode']()['forEachChild'](R,(_0x492c50,_0x662c69)=>{_0x1c70d8['push'](tt(_0x492c50,_0x662c69));}),_0x4ad48b['isFullyInitialized']()&&_0x1c70d8['push'](Oo(_0x4ad48b['getNode']())),$o(_0x49c6a2,_0x1c70d8,_0x4ad48b['getNode'](),_0x25946f);}function $o(_0x12499e,_0x472aa6,_0x2445ec,_0x2a581b){const _0x1c441f=_0x2a581b?[_0x2a581b]:_0x12499e['eventRegistrations_'];return nu(_0x12499e['eventGenerator_'],_0x472aa6,_0x2445ec,_0x1c441f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x34d6af){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x34d6af;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x598526){return _0x598526['views']['size']===0x0;}function is(_0x225d53,_0x3f9867,_0x42e235,_0x133d62){const _0x1a6733=_0x3f9867['source']['queryId'];if(_0x1a6733!==null){const _0x1e30c5=_0x225d53['views']['get'](_0x1a6733);return f(_0x1e30c5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x1e30c5,_0x3f9867,_0x42e235,_0x133d62);}else{let _0x294ff3=[];for(const _0x396733 of _0x225d53['views']['values']())_0x294ff3=_0x294ff3['concat'](ur(_0x396733,_0x3f9867,_0x42e235,_0x133d62));return _0x294ff3;}}function qo(_0x909d71,_0x4ea6f7,_0x6c289b,_0xab3070,_0x3c92cf){const _0x2dcd49=_0x4ea6f7['_queryIdentifier'],_0x4b31d8=_0x909d71['views']['get'](_0x2dcd49);if(!_0x4b31d8){let _0x360049=mn(_0x6c289b,_0x3c92cf?_0xab3070:null),_0x350ec7=!0x1;_0x360049?_0x350ec7=!0x0:_0xab3070 instanceof g?(_0x360049=es(_0x6c289b,_0xab3070),_0x350ec7=!0x1):(_0x360049=g['EMPTY_NODE'],_0x350ec7=!0x1);const _0x5c8eae=Dn(new Ce(_0x360049,_0x350ec7,!0x1),new Ce(_0xab3070,_0x3c92cf,!0x1));return new Nu(_0x4ea6f7,_0x5c8eae);}return _0x4b31d8;}function Wu(_0x4cbb1f,_0x4045ca,_0x3ba19f,_0x95b836,_0x53dab0,_0x1f1874){const _0x1d550e=qo(_0x4cbb1f,_0x4045ca,_0x95b836,_0x53dab0,_0x1f1874);return _0x4cbb1f['views']['has'](_0x4045ca['_queryIdentifier'])||_0x4cbb1f['views']['set'](_0x4045ca['_queryIdentifier'],_0x1d550e),Mu(_0x1d550e,_0x3ba19f),Lu(_0x1d550e,_0x3ba19f);}function Bu(_0x2723cc,_0x3fbbb1,_0x11d8bb,_0x12c489){const _0x342f3a=_0x3fbbb1['_queryIdentifier'],_0x2341fe=[];let _0x4c7435=[];const _0x38303d=Te(_0x2723cc);if(_0x342f3a==='default'){for(const [_0x3700fd,_0x5132ce]of _0x2723cc['views']['entries']())_0x4c7435=_0x4c7435['concat'](hr(_0x5132ce,_0x11d8bb,_0x12c489)),lr(_0x5132ce)&&(_0x2723cc['views']['delete'](_0x3700fd),_0x5132ce['query']['_queryParams']['loadsAllData']()||_0x2341fe['push'](_0x5132ce['query']));}else{const _0xb17fdf=_0x2723cc['views']['get'](_0x342f3a);_0xb17fdf&&(_0x4c7435=_0x4c7435['concat'](hr(_0xb17fdf,_0x11d8bb,_0x12c489)),lr(_0xb17fdf)&&(_0x2723cc['views']['delete'](_0x342f3a),_0xb17fdf['query']['_queryParams']['loadsAllData']()||_0x2341fe['push'](_0xb17fdf['query'])));}return _0x38303d&&!Te(_0x2723cc)&&_0x2341fe['push'](new(Fu())(_0x3fbbb1['_repo'],_0x3fbbb1['_path'])),{'removed':_0x2341fe,'events':_0x4c7435};}function zo(_0x36635e){const _0x526f8c=[];for(const _0x4b84a7 of _0x36635e['views']['values']())_0x4b84a7['query']['_queryParams']['loadsAllData']()||_0x526f8c['push'](_0x4b84a7);return _0x526f8c;}function Ee(_0x4b699f,_0xaaf4){let _0x22097a=null;for(const _0x578ace of _0x4b699f['views']['values']())_0x22097a=_0x22097a||Du(_0x578ace,_0xaaf4);return _0x22097a;}function jo(_0x5c816a,_0x330d27){if(_0x330d27['_queryParams']['loadsAllData']())return Ln(_0x5c816a);{const _0x2cd3ba=_0x330d27['_queryIdentifier'];return _0x5c816a['views']['get'](_0x2cd3ba);}}function Ko(_0x36ad56,_0x5aac83){return jo(_0x36ad56,_0x5aac83)!=null;}function Te(_0x788122){return Ln(_0x788122)!=null;}function Ln(_0x4dd8d8){for(const _0x1c3798 of _0x4dd8d8['views']['values']())if(_0x1c3798['query']['_queryParams']['loadsAllData']())return _0x1c3798;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x83e7a2){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x83e7a2;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x4e23da){this['listenProvider_']=_0x4e23da,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x5f50c8,_0x5c4ea5,_0xff086f,_0x28ebf0,_0x478163){return ou(_0x5f50c8['pendingWriteTree_'],_0x5c4ea5,_0xff086f,_0x28ebf0,_0x478163),_0x478163?ht(_0x5f50c8,new Fe(Ji(),_0x5c4ea5,_0xff086f)):[];}function Gu(_0x3256e4,_0x2a3df9,_0x199685,_0x3c8330){au(_0x3256e4['pendingWriteTree_'],_0x2a3df9,_0x199685,_0x3c8330);const _0x200e12=S['fromObject'](_0x199685);return ht(_0x3256e4,new nt(Ji(),_0x2a3df9,_0x200e12));}function pe(_0x227b07,_0x296454,_0x467ff0=!0x1){const _0x4114ad=cu(_0x227b07['pendingWriteTree_'],_0x296454);if(lu(_0x227b07['pendingWriteTree_'],_0x296454)){let _0x1b24c3=new S(null);return _0x4114ad['snap']!=null?_0x1b24c3=_0x1b24c3['set'](w(),!0x0):x(_0x4114ad['children'],_0x101884=>{_0x1b24c3=_0x1b24c3['set'](new C(_0x101884),!0x0);}),ht(_0x227b07,new _n(_0x4114ad['path'],_0x1b24c3,_0x467ff0));}else return[];}function $t(_0x18bea7,_0x2d5e58,_0x498fc7){return ht(_0x18bea7,new Fe(Xi(),_0x2d5e58,_0x498fc7));}function qu(_0x511a08,_0x1d766d,_0x25fd39){const _0x9c4342=S['fromObject'](_0x25fd39);return ht(_0x511a08,new nt(Xi(),_0x1d766d,_0x9c4342));}function zu(_0x5cfb27,_0x25d6d0){return ht(_0x5cfb27,new Dt(Xi(),_0x25d6d0));}function ju(_0x6b120f,_0x3e63e2,_0x4c1670){const _0x180045=rs(_0x6b120f,_0x4c1670);if(_0x180045){const _0x16655c=os(_0x180045),_0x34b283=_0x16655c['path'],_0x56dcae=_0x16655c['queryId'],_0x39185f=F(_0x34b283,_0x3e63e2),_0x400b4a=new Dt(Zi(_0x56dcae),_0x39185f);return as(_0x6b120f,_0x34b283,_0x400b4a);}else return[];}function wn(_0x1e34ec,_0x2e9ca0,_0x4914f0,_0x38b7e2,_0x1d81f4=!0x1){const _0x819593=_0x2e9ca0['_path'],_0x3cbf8a=_0x1e34ec['syncPointTree_']['get'](_0x819593);let _0x363b88=[];if(_0x3cbf8a&&(_0x2e9ca0['_queryIdentifier']==='default'||Ko(_0x3cbf8a,_0x2e9ca0))){const _0x30d01a=Bu(_0x3cbf8a,_0x2e9ca0,_0x4914f0,_0x38b7e2);Uu(_0x3cbf8a)&&(_0x1e34ec['syncPointTree_']=_0x1e34ec['syncPointTree_']['remove'](_0x819593));const _0x376397=_0x30d01a['removed'];if(_0x363b88=_0x30d01a['events'],!_0x1d81f4){const _0x54bee2=_0x376397['findIndex'](_0x5e4d02=>_0x5e4d02['_queryParams']['loadsAllData']())!==-0x1,_0x304f7a=_0x1e34ec['syncPointTree_']['findOnPath'](_0x819593,(_0x2c0bde,_0x38a819)=>Te(_0x38a819));if(_0x54bee2&&!_0x304f7a){const _0x1e5d85=_0x1e34ec['syncPointTree_']['subtree'](_0x819593);if(!_0x1e5d85['isEmpty']()){const _0x4f349f=Qu(_0x1e5d85);for(let _0x1c5c4c=0x0;_0x1c5c4c<_0x4f349f['length'];++_0x1c5c4c){const _0x1576d0=_0x4f349f[_0x1c5c4c],_0x5ab58a=_0x1576d0['query'],_0x4f0bd4=Xo(_0x1e34ec,_0x1576d0);_0x1e34ec['listenProvider_']['startListening'](Tt(_0x5ab58a),Mt(_0x1e34ec,_0x5ab58a),_0x4f0bd4['hashFn'],_0x4f0bd4['onComplete']);}}}!_0x304f7a&&_0x376397['length']>0x0&&!_0x38b7e2&&(_0x54bee2?_0x1e34ec['listenProvider_']['stopListening'](Tt(_0x2e9ca0),null):_0x376397['forEach'](_0x371e32=>{const _0x518e8e=_0x1e34ec['queryToTagMap']['get'](Fn(_0x371e32));_0x1e34ec['listenProvider_']['stopListening'](Tt(_0x371e32),_0x518e8e);}));}Ju(_0x1e34ec,_0x376397);}return _0x363b88;}function Yo(_0x44c42e,_0x13cef9,_0x1dfd2d,_0x3d97f0){const _0x5aab4e=rs(_0x44c42e,_0x3d97f0);if(_0x5aab4e!=null){const _0x3b430a=os(_0x5aab4e),_0x5c35b1=_0x3b430a['path'],_0x20bb65=_0x3b430a['queryId'],_0x5905ab=F(_0x5c35b1,_0x13cef9),_0x5dcd3c=new Fe(Zi(_0x20bb65),_0x5905ab,_0x1dfd2d);return as(_0x44c42e,_0x5c35b1,_0x5dcd3c);}else return[];}function Ku(_0x52e33c,_0xd9bd5e,_0x47047c,_0x4e2992){const _0x570ef5=rs(_0x52e33c,_0x4e2992);if(_0x570ef5){const _0x377dc8=os(_0x570ef5),_0x3bf644=_0x377dc8['path'],_0x1a7cdd=_0x377dc8['queryId'],_0x18f1fe=F(_0x3bf644,_0xd9bd5e),_0x4234ab=S['fromObject'](_0x47047c),_0x2f798d=new nt(Zi(_0x1a7cdd),_0x18f1fe,_0x4234ab);return as(_0x52e33c,_0x3bf644,_0x2f798d);}else return[];}function bi(_0x50d965,_0x45ff6d,_0x56add2,_0x5c95f1=!0x1){const _0x11099a=_0x45ff6d['_path'];let _0x13d5b2=null,_0x5cb16f=!0x1;_0x50d965['syncPointTree_']['foreachOnPath'](_0x11099a,(_0x46f94e,_0x5e9cfc)=>{const _0x1a15ac=F(_0x46f94e,_0x11099a);_0x13d5b2=_0x13d5b2||Ee(_0x5e9cfc,_0x1a15ac),_0x5cb16f=_0x5cb16f||Te(_0x5e9cfc);});let _0x356b4f=_0x50d965['syncPointTree_']['get'](_0x11099a);_0x356b4f?(_0x5cb16f=_0x5cb16f||Te(_0x356b4f),_0x13d5b2=_0x13d5b2||Ee(_0x356b4f,w())):(_0x356b4f=new Go(),_0x50d965['syncPointTree_']=_0x50d965['syncPointTree_']['set'](_0x11099a,_0x356b4f));let _0x19644d;_0x13d5b2!=null?_0x19644d=!0x0:(_0x19644d=!0x1,_0x13d5b2=g['EMPTY_NODE'],_0x50d965['syncPointTree_']['subtree'](_0x11099a)['foreachChild']((_0x576e04,_0xfc0468)=>{const _0x563daf=Ee(_0xfc0468,w());_0x563daf&&(_0x13d5b2=_0x13d5b2['updateImmediateChild'](_0x576e04,_0x563daf));}));const _0x171e12=Ko(_0x356b4f,_0x45ff6d);if(!_0x171e12&&!_0x45ff6d['_queryParams']['loadsAllData']()){const _0x53d8e3=Fn(_0x45ff6d);f(!_0x50d965['queryToTagMap']['has'](_0x53d8e3),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x133a82=Xu();_0x50d965['queryToTagMap']['set'](_0x53d8e3,_0x133a82),_0x50d965['tagToQueryMap']['set'](_0x133a82,_0x53d8e3);}const _0x3b7841=Mn(_0x50d965['pendingWriteTree_'],_0x11099a);let _0x34e3ee=Wu(_0x356b4f,_0x45ff6d,_0x56add2,_0x3b7841,_0x13d5b2,_0x19644d);if(!_0x171e12&&!_0x5cb16f&&!_0x5c95f1){const _0x5b1935=jo(_0x356b4f,_0x45ff6d);_0x34e3ee=_0x34e3ee['concat'](Zu(_0x50d965,_0x45ff6d,_0x5b1935));}return _0x34e3ee;}function xn(_0x53ba37,_0x47f1a1,_0x54c53e){const _0x17d79b=_0x53ba37['pendingWriteTree_'],_0x1c6cc6=_0x53ba37['syncPointTree_']['findOnPath'](_0x47f1a1,(_0x4012d3,_0x5c5dae)=>{const _0x42da22=F(_0x4012d3,_0x47f1a1),_0x586848=Ee(_0x5c5dae,_0x42da22);if(_0x586848)return _0x586848;});return Uo(_0x17d79b,_0x47f1a1,_0x1c6cc6,_0x54c53e,!0x0);}function Yu(_0x9957bd,_0xb581a7){const _0x4680a8=_0xb581a7['_path'];let _0x343c9a=null;_0x9957bd['syncPointTree_']['foreachOnPath'](_0x4680a8,(_0x379771,_0x3b9b1a)=>{const _0x4d6445=F(_0x379771,_0x4680a8);_0x343c9a=_0x343c9a||Ee(_0x3b9b1a,_0x4d6445);});let _0x50329a=_0x9957bd['syncPointTree_']['get'](_0x4680a8);_0x50329a?_0x343c9a=_0x343c9a||Ee(_0x50329a,w()):(_0x50329a=new Go(),_0x9957bd['syncPointTree_']=_0x9957bd['syncPointTree_']['set'](_0x4680a8,_0x50329a));const _0x2ff610=_0x343c9a!=null,_0x16149c=_0x2ff610?new Ce(_0x343c9a,!0x0,!0x1):null,_0x1135cc=Mn(_0x9957bd['pendingWriteTree_'],_0xb581a7['_path']),_0x4d067a=qo(_0x50329a,_0xb581a7,_0x1135cc,_0x2ff610?_0x16149c['getNode']():g['EMPTY_NODE'],_0x2ff610);return Ou(_0x4d067a);}function ht(_0x496617,_0x30df6c){return Qo(_0x30df6c,_0x496617['syncPointTree_'],null,Mn(_0x496617['pendingWriteTree_'],w()));}function Qo(_0x5c53af,_0x1d2fa4,_0xe65afb,_0xe0339e){if(v(_0x5c53af['path']))return Jo(_0x5c53af,_0x1d2fa4,_0xe65afb,_0xe0339e);{const _0x300d5e=_0x1d2fa4['get'](w());_0xe65afb==null&&_0x300d5e!=null&&(_0xe65afb=Ee(_0x300d5e,w()));let _0x537de1=[];const _0x24a61a=y(_0x5c53af['path']),_0x29f38a=_0x5c53af['operationForChild'](_0x24a61a),_0x159593=_0x1d2fa4['children']['get'](_0x24a61a);if(_0x159593&&_0x29f38a){const _0x6f7392=_0xe65afb?_0xe65afb['getImmediateChild'](_0x24a61a):null,_0x4ae0af=Wo(_0xe0339e,_0x24a61a);_0x537de1=_0x537de1['concat'](Qo(_0x29f38a,_0x159593,_0x6f7392,_0x4ae0af));}return _0x300d5e&&(_0x537de1=_0x537de1['concat'](is(_0x300d5e,_0x5c53af,_0xe0339e,_0xe65afb))),_0x537de1;}}function Jo(_0x99d0c0,_0x48ac5b,_0x327994,_0x594a4e){const _0x1c7fa3=_0x48ac5b['get'](w());_0x327994==null&&_0x1c7fa3!=null&&(_0x327994=Ee(_0x1c7fa3,w()));let _0x1fa59d=[];return _0x48ac5b['children']['inorderTraversal']((_0x31541b,_0x56fd02)=>{const _0xd619ef=_0x327994?_0x327994['getImmediateChild'](_0x31541b):null,_0x5d5f08=Wo(_0x594a4e,_0x31541b),_0x2e6137=_0x99d0c0['operationForChild'](_0x31541b);_0x2e6137&&(_0x1fa59d=_0x1fa59d['concat'](Jo(_0x2e6137,_0x56fd02,_0xd619ef,_0x5d5f08)));}),_0x1c7fa3&&(_0x1fa59d=_0x1fa59d['concat'](is(_0x1c7fa3,_0x99d0c0,_0x594a4e,_0x327994))),_0x1fa59d;}function Xo(_0x5ab620,_0x4cf4b4){const _0x1e23ff=_0x4cf4b4['query'],_0x32ef36=Mt(_0x5ab620,_0x1e23ff);return{'hashFn':()=>(Pu(_0x4cf4b4)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x475ce3=>{if(_0x475ce3==='ok')return _0x32ef36?ju(_0x5ab620,_0x1e23ff['_path'],_0x32ef36):zu(_0x5ab620,_0x1e23ff['_path']);{const _0x28fc82=ql(_0x475ce3,_0x1e23ff);return wn(_0x5ab620,_0x1e23ff,null,_0x28fc82);}}};}function Mt(_0x1a307e,_0x2c4f08){const _0x248961=Fn(_0x2c4f08);return _0x1a307e['queryToTagMap']['get'](_0x248961);}function Fn(_0x443965){return _0x443965['_path']['toString']()+'$'+_0x443965['_queryIdentifier'];}function rs(_0x4199d0,_0x5157d7){return _0x4199d0['tagToQueryMap']['get'](_0x5157d7);}function os(_0x1bb714){const _0x55e6fa=_0x1bb714['indexOf']('$');return f(_0x55e6fa!==-0x1&&_0x55e6fa<_0x1bb714['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1bb714['substr'](_0x55e6fa+0x1),'path':new C(_0x1bb714['substr'](0x0,_0x55e6fa))};}function as(_0x22302f,_0x4c7810,_0x2febd8){const _0x120ae1=_0x22302f['syncPointTree_']['get'](_0x4c7810);f(_0x120ae1,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2e3b5e=Mn(_0x22302f['pendingWriteTree_'],_0x4c7810);return is(_0x120ae1,_0x2febd8,_0x2e3b5e,null);}function Qu(_0x883025){return _0x883025['fold']((_0x920bd0,_0xd7af7e,_0x5cefaf)=>{if(_0xd7af7e&&Te(_0xd7af7e))return[Ln(_0xd7af7e)];{let _0x3c4613=[];return _0xd7af7e&&(_0x3c4613=zo(_0xd7af7e)),x(_0x5cefaf,(_0x277f81,_0x4be365)=>{_0x3c4613=_0x3c4613['concat'](_0x4be365);}),_0x3c4613;}});}function Tt(_0x49a9d4){return _0x49a9d4['_queryParams']['loadsAllData']()&&!_0x49a9d4['_queryParams']['isDefault']()?new(Hu())(_0x49a9d4['_repo'],_0x49a9d4['_path']):_0x49a9d4;}function Ju(_0x4eaf8c,_0x2085ee){for(let _0x59f0ce=0x0;_0x59f0ce<_0x2085ee['length'];++_0x59f0ce){const _0x4f1efd=_0x2085ee[_0x59f0ce];if(!_0x4f1efd['_queryParams']['loadsAllData']()){const _0x371953=Fn(_0x4f1efd),_0x1e1d40=_0x4eaf8c['queryToTagMap']['get'](_0x371953);_0x4eaf8c['queryToTagMap']['delete'](_0x371953),_0x4eaf8c['tagToQueryMap']['delete'](_0x1e1d40);}}}function Xu(){return $u++;}function Zu(_0x42b68e,_0x352c8e,_0x40ab5f){const _0xd65bca=_0x352c8e['_path'],_0x44bf51=Mt(_0x42b68e,_0x352c8e),_0x5a227f=Xo(_0x42b68e,_0x40ab5f),_0x2e7f9e=_0x42b68e['listenProvider_']['startListening'](Tt(_0x352c8e),_0x44bf51,_0x5a227f['hashFn'],_0x5a227f['onComplete']),_0x3318fe=_0x42b68e['syncPointTree_']['subtree'](_0xd65bca);if(_0x44bf51)f(!Te(_0x3318fe['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x1bb1eb=_0x3318fe['fold']((_0x2aad5a,_0x5e6923,_0xb45b5b)=>{if(!v(_0x2aad5a)&&_0x5e6923&&Te(_0x5e6923))return[Ln(_0x5e6923)['query']];{let _0x58a422=[];return _0x5e6923&&(_0x58a422=_0x58a422['concat'](zo(_0x5e6923)['map'](_0x29419d=>_0x29419d['query']))),x(_0xb45b5b,(_0x1ccba7,_0x161572)=>{_0x58a422=_0x58a422['concat'](_0x161572);}),_0x58a422;}});for(let _0x394912=0x0;_0x394912<_0x1bb1eb['length'];++_0x394912){const _0x4c5efe=_0x1bb1eb[_0x394912];_0x42b68e['listenProvider_']['stopListening'](Tt(_0x4c5efe),Mt(_0x42b68e,_0x4c5efe));}}return _0x2e7f9e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x400a81){this['node_']=_0x400a81;}['getImmediateChild'](_0x166f99){const _0x38cc1c=this['node_']['getImmediateChild'](_0x166f99);return new cs(_0x38cc1c);}['node'](){return this['node_'];}}class ls{constructor(_0x127975,_0x30d76a){this['syncTree_']=_0x127975,this['path_']=_0x30d76a;}['getImmediateChild'](_0x3d9e56){const _0x20d913=A(this['path_'],_0x3d9e56);return new ls(this['syncTree_'],_0x20d913);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x415131){return _0x415131=_0x415131||{},_0x415131['timestamp']=_0x415131['timestamp']||new Date()['getTime'](),_0x415131;},fr=function(_0x54d55b,_0x4b66c4,_0x94c461){if(!_0x54d55b||typeof _0x54d55b!='object')return _0x54d55b;if(f('.sv'in _0x54d55b,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x54d55b['.sv']=='string')return td(_0x54d55b['.sv'],_0x4b66c4,_0x94c461);if(typeof _0x54d55b['.sv']=='object')return nd(_0x54d55b['.sv'],_0x4b66c4);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x54d55b,null,0x2));},td=function(_0x402020,_0x2f218b,_0x184e78){switch(_0x402020){case'timestamp':return _0x184e78['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x402020);}},nd=function(_0x1febed,_0x4882b0,_0x270c9f){_0x1febed['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1febed,null,0x2));const _0x4f71cf=_0x1febed['increment'];typeof _0x4f71cf!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4f71cf);const _0x33dacb=_0x4882b0['node']();if(f(_0x33dacb!==null&&typeof _0x33dacb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x33dacb['isLeafNode']())return _0x4f71cf;const _0x4c0cbf=_0x33dacb['getValue']();return typeof _0x4c0cbf!='number'?_0x4f71cf:_0x4c0cbf+_0x4f71cf;},Zo=function(_0x1fb8bc,_0x105d01,_0x116172,_0x230c5f){return us(_0x105d01,new ls(_0x116172,_0x1fb8bc),_0x230c5f);},hs=function(_0x21977a,_0x739fa1,_0x36d32d){return us(_0x21977a,new cs(_0x739fa1),_0x36d32d);};function us(_0x5befe1,_0x1d4582,_0x299901){const _0x585f47=_0x5befe1['getPriority']()['val'](),_0x1edb47=fr(_0x585f47,_0x1d4582['getImmediateChild']('.priority'),_0x299901);let _0x2590aa;if(_0x5befe1['isLeafNode']()){const _0x2adedb=_0x5befe1,_0x3e21b0=fr(_0x2adedb['getValue'](),_0x1d4582,_0x299901);return _0x3e21b0!==_0x2adedb['getValue']()||_0x1edb47!==_0x2adedb['getPriority']()['val']()?new D(_0x3e21b0,N(_0x1edb47)):_0x5befe1;}else{const _0x360fb8=_0x5befe1;return _0x2590aa=_0x360fb8,_0x1edb47!==_0x360fb8['getPriority']()['val']()&&(_0x2590aa=_0x2590aa['updatePriority'](new D(_0x1edb47))),_0x360fb8['forEachChild'](R,(_0x1d0346,_0x130e20)=>{const _0x4d4c55=us(_0x130e20,_0x1d4582['getImmediateChild'](_0x1d0346),_0x299901);_0x4d4c55!==_0x130e20&&(_0x2590aa=_0x2590aa['updateImmediateChild'](_0x1d0346,_0x4d4c55));}),_0x2590aa;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x29c294='',_0x49e7da=null,_0x4afabc={'children':{},'childCount':0x0}){this['name']=_0x29c294,this['parent']=_0x49e7da,this['node']=_0x4afabc;}}function Un(_0x4de7dc,_0x9f08d3){let _0x36d1d3=_0x9f08d3 instanceof C?_0x9f08d3:new C(_0x9f08d3),_0x6f62e2=_0x4de7dc,_0x13dce6=y(_0x36d1d3);for(;_0x13dce6!==null;){const _0x414f64=Oe(_0x6f62e2['node']['children'],_0x13dce6)||{'children':{},'childCount':0x0};_0x6f62e2=new ds(_0x13dce6,_0x6f62e2,_0x414f64),_0x36d1d3=b(_0x36d1d3),_0x13dce6=y(_0x36d1d3);}return _0x6f62e2;}function Ge(_0x480bb5){return _0x480bb5['node']['value'];}function fs(_0x1c6c4b,_0x3cbf9d){_0x1c6c4b['node']['value']=_0x3cbf9d,Ri(_0x1c6c4b);}function ea(_0x1f039c){return _0x1f039c['node']['childCount']>0x0;}function id(_0x5f170f){return Ge(_0x5f170f)===void 0x0&&!ea(_0x5f170f);}function Wn(_0x3a74a2,_0x295386){x(_0x3a74a2['node']['children'],(_0x3ef456,_0x33d230)=>{_0x295386(new ds(_0x3ef456,_0x3a74a2,_0x33d230));});}function ta(_0x429d17,_0x452d4c,_0x15f54a,_0x29f9c7){_0x15f54a&&_0x452d4c(_0x429d17),Wn(_0x429d17,_0x3a1d03=>{ta(_0x3a1d03,_0x452d4c,!0x0);});}function sd(_0x5c9450,_0x5990ff,_0x311ba6){let _0x3a0e52=_0x5c9450['parent'];for(;_0x3a0e52!==null;){if(_0x5990ff(_0x3a0e52))return!0x0;_0x3a0e52=_0x3a0e52['parent'];}return!0x1;}function Gt(_0x46711b){return new C(_0x46711b['parent']===null?_0x46711b['name']:Gt(_0x46711b['parent'])+'/'+_0x46711b['name']);}function Ri(_0x54e194){_0x54e194['parent']!==null&&rd(_0x54e194['parent'],_0x54e194['name'],_0x54e194);}function rd(_0x182d5b,_0x310291,_0x855518){const _0x21fd92=id(_0x855518),_0x552b7f=Y(_0x182d5b['node']['children'],_0x310291);_0x21fd92&&_0x552b7f?(delete _0x182d5b['node']['children'][_0x310291],_0x182d5b['node']['childCount']--,Ri(_0x182d5b)):!_0x21fd92&&!_0x552b7f&&(_0x182d5b['node']['children'][_0x310291]=_0x855518['node'],_0x182d5b['node']['childCount']++,Ri(_0x182d5b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x42b2bd){return typeof _0x42b2bd=='string'&&_0x42b2bd['length']!==0x0&&!od['test'](_0x42b2bd);},na=function(_0x4f48d0){return typeof _0x4f48d0=='string'&&_0x4f48d0['length']!==0x0&&!ad['test'](_0x4f48d0);},cd=function(_0x14d537){return _0x14d537&&(_0x14d537=_0x14d537['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x14d537);},Cn=function(_0x1a341e){return _0x1a341e===null||typeof _0x1a341e=='string'||typeof _0x1a341e=='number'&&!Wi(_0x1a341e)||_0x1a341e&&typeof _0x1a341e=='object'&&Y(_0x1a341e,'.sv');},qt=function(_0xb420ac,_0x23d7c1,_0x438370,_0x5b6ec1){_0x5b6ec1&&_0x23d7c1===void 0x0||zt(Nn(_0xb420ac,'value'),_0x23d7c1,_0x438370);},zt=function(_0x78a31e,_0x2a94b0,_0x264ccc){const _0x4fd3a6=_0x264ccc instanceof C?new Sh(_0x264ccc,_0x78a31e):_0x264ccc;if(_0x2a94b0===void 0x0)throw new Error(_0x78a31e+'contains\x20undefined\x20'+Ne(_0x4fd3a6));if(typeof _0x2a94b0=='function')throw new Error(_0x78a31e+'contains\x20a\x20function\x20'+Ne(_0x4fd3a6)+'\x20with\x20contents\x20=\x20'+_0x2a94b0['toString']());if(Wi(_0x2a94b0))throw new Error(_0x78a31e+'contains\x20'+_0x2a94b0['toString']()+'\x20'+Ne(_0x4fd3a6));if(typeof _0x2a94b0=='string'&&_0x2a94b0['length']>oi/0x3&&Pn(_0x2a94b0)>oi)throw new Error(_0x78a31e+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4fd3a6)+'\x20(\x27'+_0x2a94b0['substring'](0x0,0x32)+'...\x27)');if(_0x2a94b0&&typeof _0x2a94b0=='object'){let _0x369315=!0x1,_0xbad9a8=!0x1;if(x(_0x2a94b0,(_0x30a079,_0xb75eee)=>{if(_0x30a079==='.value')_0x369315=!0x0;else{if(_0x30a079!=='.priority'&&_0x30a079!=='.sv'&&(_0xbad9a8=!0x0,!ps(_0x30a079)))throw new Error(_0x78a31e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x30a079+')\x20'+Ne(_0x4fd3a6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4fd3a6,_0x30a079),zt(_0x78a31e,_0xb75eee,_0x4fd3a6),Rh(_0x4fd3a6);}),_0x369315&&_0xbad9a8)throw new Error(_0x78a31e+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4fd3a6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0xab7389,_0x520d3f){let _0x124dd2,_0x10a8df;for(_0x124dd2=0x0;_0x124dd2<_0x520d3f['length'];_0x124dd2++){_0x10a8df=_0x520d3f[_0x124dd2];const _0x3ca951=kt(_0x10a8df);for(let _0x1fbd59=0x0;_0x1fbd59<_0x3ca951['length'];_0x1fbd59++)if(!(_0x3ca951[_0x1fbd59]==='.priority'&&_0x1fbd59===_0x3ca951['length']-0x1)){if(!ps(_0x3ca951[_0x1fbd59]))throw new Error(_0xab7389+'contains\x20an\x20invalid\x20key\x20('+_0x3ca951[_0x1fbd59]+')\x20in\x20path\x20'+_0x10a8df['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x520d3f['sort'](Th);let _0x5e67c3=null;for(_0x124dd2=0x0;_0x124dd2<_0x520d3f['length'];_0x124dd2++){if(_0x10a8df=_0x520d3f[_0x124dd2],_0x5e67c3!==null&&$(_0x5e67c3,_0x10a8df))throw new Error(_0xab7389+'contains\x20a\x20path\x20'+_0x5e67c3['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x10a8df['toString']());_0x5e67c3=_0x10a8df;}},hd=function(_0x3ba740,_0x19f313,_0x20d2e5,_0x465d10){const _0x456846=Nn(_0x3ba740,'values');if(!(_0x19f313&&typeof _0x19f313=='object')||Array['isArray'](_0x19f313))throw new Error(_0x456846+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x32ad5e=[];x(_0x19f313,(_0x466374,_0x38d9fa)=>{const _0x7ddd03=new C(_0x466374);if(zt(_0x456846,_0x38d9fa,A(_0x20d2e5,_0x7ddd03)),Gi(_0x7ddd03)==='.priority'&&!Cn(_0x38d9fa))throw new Error(_0x456846+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x7ddd03['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x32ad5e['push'](_0x7ddd03);}),ld(_0x456846,_0x32ad5e);},_s=function(_0x49c5e9,_0x2ec079,_0x37e9d9,_0x309f94){if(!na(_0x37e9d9))throw new Error(Nn(_0x49c5e9,_0x2ec079)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x37e9d9+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x45fa48,_0x141612,_0x163ad3,_0x192dc1){_0x163ad3&&(_0x163ad3=_0x163ad3['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x45fa48,_0x141612,_0x163ad3);},gs=function(_0x32f4df,_0x4eff73){if(y(_0x4eff73)==='.info')throw new Error(_0x32f4df+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0xfd624a,_0x1f21cd){const _0x1c1de6=_0x1f21cd['path']['toString']();if(typeof _0x1f21cd['repoInfo']['host']!='string'||_0x1f21cd['repoInfo']['host']['length']===0x0||!ps(_0x1f21cd['repoInfo']['namespace'])&&_0x1f21cd['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1c1de6['length']!==0x0&&!cd(_0x1c1de6))throw new Error(Nn(_0xfd624a,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x399d89,_0x3f0dd3){let _0x255cbd=null;for(let _0x3b75ab=0x0;_0x3b75ab<_0x3f0dd3['length'];_0x3b75ab++){const _0x46eebd=_0x3f0dd3[_0x3b75ab],_0x240fb1=_0x46eebd['getPath']();_0x255cbd!==null&&!qi(_0x240fb1,_0x255cbd['path'])&&(_0x399d89['eventLists_']['push'](_0x255cbd),_0x255cbd=null),_0x255cbd===null&&(_0x255cbd={'events':[],'path':_0x240fb1}),_0x255cbd['events']['push'](_0x46eebd);}_0x255cbd&&_0x399d89['eventLists_']['push'](_0x255cbd);}function ia(_0x8edc58,_0x46d696,_0x20cc6a){Bn(_0x8edc58,_0x20cc6a),sa(_0x8edc58,_0x48df2a=>qi(_0x48df2a,_0x46d696));}function V(_0x37f493,_0x1559be,_0x8eccea){Bn(_0x37f493,_0x8eccea),sa(_0x37f493,_0xe24d93=>$(_0xe24d93,_0x1559be)||$(_0x1559be,_0xe24d93));}function sa(_0x36c8fb,_0x441328){_0x36c8fb['recursionDepth_']++;let _0x10e961=!0x0;for(let _0x2e5174=0x0;_0x2e5174<_0x36c8fb['eventLists_']['length'];_0x2e5174++){const _0x25a4fe=_0x36c8fb['eventLists_'][_0x2e5174];if(_0x25a4fe){const _0x267209=_0x25a4fe['path'];_0x441328(_0x267209)?(pd(_0x36c8fb['eventLists_'][_0x2e5174]),_0x36c8fb['eventLists_'][_0x2e5174]=null):_0x10e961=!0x1;}}_0x10e961&&(_0x36c8fb['eventLists_']=[]),_0x36c8fb['recursionDepth_']--;}function pd(_0x3c1757){for(let _0x1f10a1=0x0;_0x1f10a1<_0x3c1757['events']['length'];_0x1f10a1++){const _0x3eb3ea=_0x3c1757['events'][_0x1f10a1];if(_0x3eb3ea!==null){_0x3c1757['events'][_0x1f10a1]=null;const _0x467d2d=_0x3eb3ea['getEventRunner']();Et&&L('event:\x20'+_0x3eb3ea['toString']()),lt(_0x467d2d);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x3a50df,_0x3b0891,_0x474108,_0x5c9477){this['repoInfo_']=_0x3a50df,this['forceRestClient_']=_0x3b0891,this['authTokenProvider_']=_0x474108,this['appCheckProvider_']=_0x5c9477,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x1436ee,_0x333f96,_0x198423){if(_0x1436ee['stats_']=Hi(_0x1436ee['repoInfo_']),_0x1436ee['forceRestClient_']||Yl())_0x1436ee['server_']=new fn(_0x1436ee['repoInfo_'],(_0x3d049a,_0x4e4962,_0x1677fa,_0x4a4989)=>{pr(_0x1436ee,_0x3d049a,_0x4e4962,_0x1677fa,_0x4a4989);},_0x1436ee['authTokenProvider_'],_0x1436ee['appCheckProvider_']),setTimeout(()=>_r(_0x1436ee,!0x0),0x0);else{if(typeof _0x198423<'u'&&_0x198423!==null){if(typeof _0x198423!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x198423);}catch(_0x13da7b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x13da7b);}}_0x1436ee['persistentConnection_']=new ie(_0x1436ee['repoInfo_'],_0x333f96,(_0x1917a6,_0x34b1b4,_0x58f4ea,_0x4cd0d9)=>{pr(_0x1436ee,_0x1917a6,_0x34b1b4,_0x58f4ea,_0x4cd0d9);},_0x2ad9fa=>{_r(_0x1436ee,_0x2ad9fa);},_0xeabdda=>{yd(_0x1436ee,_0xeabdda);},_0x1436ee['authTokenProvider_'],_0x1436ee['appCheckProvider_'],_0x198423),_0x1436ee['server_']=_0x1436ee['persistentConnection_'];}_0x1436ee['authTokenProvider_']['addTokenChangeListener'](_0x29ede6=>{_0x1436ee['server_']['refreshAuthToken'](_0x29ede6);}),_0x1436ee['appCheckProvider_']['addTokenChangeListener'](_0x5c2649=>{_0x1436ee['server_']['refreshAppCheckToken'](_0x5c2649['token']);}),_0x1436ee['statsReporter_']=eh(_0x1436ee['repoInfo_'],()=>new eu(_0x1436ee['stats_'],_0x1436ee['server_'])),_0x1436ee['infoData_']=new Yh(),_0x1436ee['infoSyncTree_']=new dr({'startListening':(_0x41e9fe,_0x234387,_0x6e2bae,_0x4ff017)=>{let _0x52ca27=[];const _0x58f9d6=_0x1436ee['infoData_']['getNode'](_0x41e9fe['_path']);return _0x58f9d6['isEmpty']()||(_0x52ca27=$t(_0x1436ee['infoSyncTree_'],_0x41e9fe['_path'],_0x58f9d6),setTimeout(()=>{_0x4ff017('ok');},0x0)),_0x52ca27;},'stopListening':()=>{}}),ms(_0x1436ee,'connected',!0x1),_0x1436ee['serverSyncTree_']=new dr({'startListening':(_0x5d7a53,_0x31d01f,_0x2350a2,_0x9c6588)=>(_0x1436ee['server_']['listen'](_0x5d7a53,_0x2350a2,_0x31d01f,(_0x49fedf,_0x4f4e11)=>{const _0x31019a=_0x9c6588(_0x49fedf,_0x4f4e11);V(_0x1436ee['eventQueue_'],_0x5d7a53['_path'],_0x31019a);}),[]),'stopListening':(_0x5b6c5b,_0x40c89c)=>{_0x1436ee['server_']['unlisten'](_0x5b6c5b,_0x40c89c);}});}function oa(_0x1d6b71){const _0x24f655=_0x1d6b71['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x24f655;}function jt(_0x38462f){return ed({'timestamp':oa(_0x38462f)});}function pr(_0x31fdf0,_0x39a637,_0x3f0b55,_0xca9f4f,_0x4c87e1){_0x31fdf0['dataUpdateCount']++;const _0x46e733=new C(_0x39a637);_0x3f0b55=_0x31fdf0['interceptServerDataCallback_']?_0x31fdf0['interceptServerDataCallback_'](_0x39a637,_0x3f0b55):_0x3f0b55;let _0x1529e5=[];if(_0x4c87e1){if(_0xca9f4f){const _0x28e4cc=ln(_0x3f0b55,_0x15beb2=>N(_0x15beb2));_0x1529e5=Ku(_0x31fdf0['serverSyncTree_'],_0x46e733,_0x28e4cc,_0x4c87e1);}else{const _0x14c27f=N(_0x3f0b55);_0x1529e5=Yo(_0x31fdf0['serverSyncTree_'],_0x46e733,_0x14c27f,_0x4c87e1);}}else{if(_0xca9f4f){const _0x410fd1=ln(_0x3f0b55,_0x5122dd=>N(_0x5122dd));_0x1529e5=qu(_0x31fdf0['serverSyncTree_'],_0x46e733,_0x410fd1);}else{const _0x1d9739=N(_0x3f0b55);_0x1529e5=$t(_0x31fdf0['serverSyncTree_'],_0x46e733,_0x1d9739);}}let _0x31d54b=_0x46e733;_0x1529e5['length']>0x0&&(_0x31d54b=st(_0x31fdf0,_0x46e733)),V(_0x31fdf0['eventQueue_'],_0x31d54b,_0x1529e5);}function _r(_0x23d8e2,_0x5ac866){ms(_0x23d8e2,'connected',_0x5ac866),_0x5ac866===!0x1&&wd(_0x23d8e2);}function yd(_0x3b7298,_0x4ac7e9){x(_0x4ac7e9,(_0x5ee2e0,_0x4b4ad9)=>{ms(_0x3b7298,_0x5ee2e0,_0x4b4ad9);});}function ms(_0x5044b2,_0x9e664d,_0x3ab044){const _0x245139=new C('/.info/'+_0x9e664d),_0xf5e068=N(_0x3ab044);_0x5044b2['infoData_']['updateSnapshot'](_0x245139,_0xf5e068);const _0x4d6c7c=$t(_0x5044b2['infoSyncTree_'],_0x245139,_0xf5e068);V(_0x5044b2['eventQueue_'],_0x245139,_0x4d6c7c);}function Vn(_0x2a3334){return _0x2a3334['nextWriteId_']++;}function vd(_0x35f06b,_0x5a6cb9,_0x147027){const _0xa91d4e=Yu(_0x35f06b['serverSyncTree_'],_0x5a6cb9);return _0xa91d4e!=null?Promise['resolve'](_0xa91d4e):_0x35f06b['server_']['get'](_0x5a6cb9)['then'](_0x3ffd59=>{const _0x3acec3=N(_0x3ffd59)['withIndex'](_0x5a6cb9['_queryParams']['getIndex']());bi(_0x35f06b['serverSyncTree_'],_0x5a6cb9,_0x147027,!0x0);let _0x40e492;if(_0x5a6cb9['_queryParams']['loadsAllData']())_0x40e492=$t(_0x35f06b['serverSyncTree_'],_0x5a6cb9['_path'],_0x3acec3);else{const _0x7a0e6b=Mt(_0x35f06b['serverSyncTree_'],_0x5a6cb9);_0x40e492=Yo(_0x35f06b['serverSyncTree_'],_0x5a6cb9['_path'],_0x3acec3,_0x7a0e6b);}return V(_0x35f06b['eventQueue_'],_0x5a6cb9['_path'],_0x40e492),wn(_0x35f06b['serverSyncTree_'],_0x5a6cb9,_0x147027,null,!0x0),_0x3acec3;},_0x57ccad=>(ut(_0x35f06b,'get\x20for\x20query\x20'+O(_0x5a6cb9)+'\x20failed:\x20'+_0x57ccad),Promise['reject'](new Error(_0x57ccad))));}function Ed(_0x38f94b,_0x984fbe,_0x114c71,_0x4281d1,_0x49868c){ut(_0x38f94b,'set',{'path':_0x984fbe['toString'](),'value':_0x114c71,'priority':_0x4281d1});const _0x310c8c=jt(_0x38f94b),_0x1fa121=N(_0x114c71,_0x4281d1),_0x4ab70f=xn(_0x38f94b['serverSyncTree_'],_0x984fbe),_0x2e3177=hs(_0x1fa121,_0x4ab70f,_0x310c8c),_0x1431cc=Vn(_0x38f94b),_0x2b59e3=ss(_0x38f94b['serverSyncTree_'],_0x984fbe,_0x2e3177,_0x1431cc,!0x0);Bn(_0x38f94b['eventQueue_'],_0x2b59e3),_0x38f94b['server_']['put'](_0x984fbe['toString'](),_0x1fa121['val'](!0x0),(_0x2d5011,_0x3d10db)=>{const _0x5cc841=_0x2d5011==='ok';_0x5cc841||U('set\x20at\x20'+_0x984fbe+'\x20failed:\x20'+_0x2d5011);const _0x30800a=pe(_0x38f94b['serverSyncTree_'],_0x1431cc,!_0x5cc841);V(_0x38f94b['eventQueue_'],_0x984fbe,_0x30800a),Ai(_0x38f94b,_0x49868c,_0x2d5011,_0x3d10db);});const _0x1d341f=vs(_0x38f94b,_0x984fbe);st(_0x38f94b,_0x1d341f),V(_0x38f94b['eventQueue_'],_0x1d341f,[]);}function Id(_0x250e1a,_0x21ab06,_0x4a26ae,_0x418338){ut(_0x250e1a,'update',{'path':_0x21ab06['toString'](),'value':_0x4a26ae});let _0x5a4952=!0x0;const _0x212751=jt(_0x250e1a),_0x41a728={};if(x(_0x4a26ae,(_0x41bec1,_0xab4816)=>{_0x5a4952=!0x1,_0x41a728[_0x41bec1]=Zo(A(_0x21ab06,_0x41bec1),N(_0xab4816),_0x250e1a['serverSyncTree_'],_0x212751);}),_0x5a4952)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x250e1a,_0x418338,'ok',void 0x0);else{const _0x17a56f=Vn(_0x250e1a),_0x110fce=Gu(_0x250e1a['serverSyncTree_'],_0x21ab06,_0x41a728,_0x17a56f);Bn(_0x250e1a['eventQueue_'],_0x110fce),_0x250e1a['server_']['merge'](_0x21ab06['toString'](),_0x4a26ae,(_0x593936,_0x2ef426)=>{const _0x183e25=_0x593936==='ok';_0x183e25||U('update\x20at\x20'+_0x21ab06+'\x20failed:\x20'+_0x593936);const _0x1673c1=pe(_0x250e1a['serverSyncTree_'],_0x17a56f,!_0x183e25),_0x393381=_0x1673c1['length']>0x0?st(_0x250e1a,_0x21ab06):_0x21ab06;V(_0x250e1a['eventQueue_'],_0x393381,_0x1673c1),Ai(_0x250e1a,_0x418338,_0x593936,_0x2ef426);}),x(_0x4a26ae,_0x4203a7=>{const _0x1f5e90=vs(_0x250e1a,A(_0x21ab06,_0x4203a7));st(_0x250e1a,_0x1f5e90);}),V(_0x250e1a['eventQueue_'],_0x21ab06,[]);}}function wd(_0x23bc12){ut(_0x23bc12,'onDisconnectEvents');const _0x4d7bc3=jt(_0x23bc12),_0x5c2ff1=pn();Ei(_0x23bc12['onDisconnect_'],w(),(_0x116cf6,_0x470486)=>{const _0x1c02a5=Zo(_0x116cf6,_0x470486,_0x23bc12['serverSyncTree_'],_0x4d7bc3);Mo(_0x5c2ff1,_0x116cf6,_0x1c02a5);});let _0x15d324=[];Ei(_0x5c2ff1,w(),(_0x26baa0,_0x5b7533)=>{_0x15d324=_0x15d324['concat']($t(_0x23bc12['serverSyncTree_'],_0x26baa0,_0x5b7533));const _0x124012=vs(_0x23bc12,_0x26baa0);st(_0x23bc12,_0x124012);}),_0x23bc12['onDisconnect_']=pn(),V(_0x23bc12['eventQueue_'],w(),_0x15d324);}function Cd(_0x4a9b49,_0x196934,_0x221fae){let _0x6ddcfd;y(_0x196934['_path'])==='.info'?_0x6ddcfd=bi(_0x4a9b49['infoSyncTree_'],_0x196934,_0x221fae):_0x6ddcfd=bi(_0x4a9b49['serverSyncTree_'],_0x196934,_0x221fae),ia(_0x4a9b49['eventQueue_'],_0x196934['_path'],_0x6ddcfd);}function Td(_0x536e67,_0x263f32,_0x5052ba){let _0x243477;y(_0x263f32['_path'])==='.info'?_0x243477=wn(_0x536e67['infoSyncTree_'],_0x263f32,_0x5052ba):_0x243477=wn(_0x536e67['serverSyncTree_'],_0x263f32,_0x5052ba),ia(_0x536e67['eventQueue_'],_0x263f32['_path'],_0x243477);}function aa(_0xd7c629){_0xd7c629['persistentConnection_']&&_0xd7c629['persistentConnection_']['interrupt'](ra);}function Sd(_0x567656){_0x567656['persistentConnection_']&&_0x567656['persistentConnection_']['resume'](ra);}function ut(_0x2c739f,..._0x5df2f4){let _0x53a5ec='';_0x2c739f['persistentConnection_']&&(_0x53a5ec=_0x2c739f['persistentConnection_']['id']+':'),L(_0x53a5ec,..._0x5df2f4);}function Ai(_0x3d891a,_0xbdcb26,_0x4b0c25,_0xf6c6c6){_0xbdcb26&&lt(()=>{if(_0x4b0c25==='ok')_0xbdcb26(null);else{const _0x37498f=(_0x4b0c25||'error')['toUpperCase']();let _0x136344=_0x37498f;_0xf6c6c6&&(_0x136344+=':\x20'+_0xf6c6c6);const _0x261cec=new Error(_0x136344);_0x261cec['code']=_0x37498f,_0xbdcb26(_0x261cec);}});}function bd(_0x49bf31,_0x380c0a,_0x4ffeb4,_0x2fbb36,_0x31e572,_0x1d69da){ut(_0x49bf31,'transaction\x20on\x20'+_0x380c0a);const _0x234897={'path':_0x380c0a,'update':_0x4ffeb4,'onComplete':_0x2fbb36,'status':null,'order':to(),'applyLocally':_0x1d69da,'retryCount':0x0,'unwatcher':_0x31e572,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2b9bb4=ys(_0x49bf31,_0x380c0a,void 0x0);_0x234897['currentInputSnapshot']=_0x2b9bb4;const _0x5a5b81=_0x234897['update'](_0x2b9bb4['val']());if(_0x5a5b81===void 0x0)_0x234897['unwatcher'](),_0x234897['currentOutputSnapshotRaw']=null,_0x234897['currentOutputSnapshotResolved']=null,_0x234897['onComplete']&&_0x234897['onComplete'](null,!0x1,_0x234897['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5a5b81,_0x234897['path']),_0x234897['status']=0x0;const _0x4e243b=Un(_0x49bf31['transactionQueueTree_'],_0x380c0a),_0x579784=Ge(_0x4e243b)||[];_0x579784['push'](_0x234897),fs(_0x4e243b,_0x579784);let _0x5a8212;typeof _0x5a5b81=='object'&&_0x5a5b81!==null&&Y(_0x5a5b81,'.priority')?(_0x5a8212=Oe(_0x5a5b81,'.priority'),f(Cn(_0x5a8212),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5a8212=(xn(_0x49bf31['serverSyncTree_'],_0x380c0a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x231ab6=jt(_0x49bf31),_0x5237dd=N(_0x5a5b81,_0x5a8212),_0x103081=hs(_0x5237dd,_0x2b9bb4,_0x231ab6);_0x234897['currentOutputSnapshotRaw']=_0x5237dd,_0x234897['currentOutputSnapshotResolved']=_0x103081,_0x234897['currentWriteId']=Vn(_0x49bf31);const _0x5d1fea=ss(_0x49bf31['serverSyncTree_'],_0x380c0a,_0x103081,_0x234897['currentWriteId'],_0x234897['applyLocally']);V(_0x49bf31['eventQueue_'],_0x380c0a,_0x5d1fea),Hn(_0x49bf31,_0x49bf31['transactionQueueTree_']);}}function ys(_0x33c839,_0x21eeb9,_0x501e26){return xn(_0x33c839['serverSyncTree_'],_0x21eeb9,_0x501e26)||g['EMPTY_NODE'];}function Hn(_0x5bb33c,_0x1b3b7b=_0x5bb33c['transactionQueueTree_']){if(_0x1b3b7b||$n(_0x5bb33c,_0x1b3b7b),Ge(_0x1b3b7b)){const _0x5eba3e=la(_0x5bb33c,_0x1b3b7b);f(_0x5eba3e['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5eba3e['every'](_0xa2be1c=>_0xa2be1c['status']===0x0)&&Rd(_0x5bb33c,Gt(_0x1b3b7b),_0x5eba3e);}else ea(_0x1b3b7b)&&Wn(_0x1b3b7b,_0x52bd0f=>{Hn(_0x5bb33c,_0x52bd0f);});}function Rd(_0x52ef2b,_0x1eafcc,_0x595064){const _0x25bfb2=_0x595064['map'](_0x2edd57=>_0x2edd57['currentWriteId']),_0x2db787=ys(_0x52ef2b,_0x1eafcc,_0x25bfb2);let _0x451875=_0x2db787;const _0x439753=_0x2db787['hash']();for(let _0x4b3940=0x0;_0x4b3940<_0x595064['length'];_0x4b3940++){const _0x28d7f7=_0x595064[_0x4b3940];f(_0x28d7f7['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x28d7f7['status']=0x1,_0x28d7f7['retryCount']++;const _0x5ef3c8=F(_0x1eafcc,_0x28d7f7['path']);_0x451875=_0x451875['updateChild'](_0x5ef3c8,_0x28d7f7['currentOutputSnapshotRaw']);}const _0x5b4390=_0x451875['val'](!0x0),_0x2501e2=_0x1eafcc;_0x52ef2b['server_']['put'](_0x2501e2['toString'](),_0x5b4390,_0x23b93d=>{ut(_0x52ef2b,'transaction\x20put\x20response',{'path':_0x2501e2['toString'](),'status':_0x23b93d});let _0x5acf2b=[];if(_0x23b93d==='ok'){const _0x38d54b=[];for(let _0x4e2d0a=0x0;_0x4e2d0a<_0x595064['length'];_0x4e2d0a++)_0x595064[_0x4e2d0a]['status']=0x2,_0x5acf2b=_0x5acf2b['concat'](pe(_0x52ef2b['serverSyncTree_'],_0x595064[_0x4e2d0a]['currentWriteId'])),_0x595064[_0x4e2d0a]['onComplete']&&_0x38d54b['push'](()=>_0x595064[_0x4e2d0a]['onComplete'](null,!0x0,_0x595064[_0x4e2d0a]['currentOutputSnapshotResolved'])),_0x595064[_0x4e2d0a]['unwatcher']();$n(_0x52ef2b,Un(_0x52ef2b['transactionQueueTree_'],_0x1eafcc)),Hn(_0x52ef2b,_0x52ef2b['transactionQueueTree_']),V(_0x52ef2b['eventQueue_'],_0x1eafcc,_0x5acf2b);for(let _0x23a9ee=0x0;_0x23a9ee<_0x38d54b['length'];_0x23a9ee++)lt(_0x38d54b[_0x23a9ee]);}else{if(_0x23b93d==='datastale'){for(let _0x31fcce=0x0;_0x31fcce<_0x595064['length'];_0x31fcce++)_0x595064[_0x31fcce]['status']===0x3?_0x595064[_0x31fcce]['status']=0x4:_0x595064[_0x31fcce]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2501e2['toString']()+'\x20failed:\x20'+_0x23b93d);for(let _0x46fe5a=0x0;_0x46fe5a<_0x595064['length'];_0x46fe5a++)_0x595064[_0x46fe5a]['status']=0x4,_0x595064[_0x46fe5a]['abortReason']=_0x23b93d;}st(_0x52ef2b,_0x1eafcc);}},_0x439753);}function st(_0x1a9cdf,_0x2038b2){const _0x182661=ca(_0x1a9cdf,_0x2038b2),_0x99bb94=Gt(_0x182661),_0x3bc75f=la(_0x1a9cdf,_0x182661);return Ad(_0x1a9cdf,_0x3bc75f,_0x99bb94),_0x99bb94;}function Ad(_0x389958,_0x7874bd,_0x83b093){if(_0x7874bd['length']===0x0)return;const _0x22055e=[];let _0x509a7c=[];const _0x19ae2c=_0x7874bd['filter'](_0x116b0f=>_0x116b0f['status']===0x0)['map'](_0x55df87=>_0x55df87['currentWriteId']);for(let _0x2613c7=0x0;_0x2613c7<_0x7874bd['length'];_0x2613c7++){const _0x5c18ff=_0x7874bd[_0x2613c7],_0xdccd26=F(_0x83b093,_0x5c18ff['path']);let _0x4fbf3e=!0x1,_0xb82ce0;if(f(_0xdccd26!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5c18ff['status']===0x4)_0x4fbf3e=!0x0,_0xb82ce0=_0x5c18ff['abortReason'],_0x509a7c=_0x509a7c['concat'](pe(_0x389958['serverSyncTree_'],_0x5c18ff['currentWriteId'],!0x0));else{if(_0x5c18ff['status']===0x0){if(_0x5c18ff['retryCount']>=_d)_0x4fbf3e=!0x0,_0xb82ce0='maxretry',_0x509a7c=_0x509a7c['concat'](pe(_0x389958['serverSyncTree_'],_0x5c18ff['currentWriteId'],!0x0));else{const _0x37c300=ys(_0x389958,_0x5c18ff['path'],_0x19ae2c);_0x5c18ff['currentInputSnapshot']=_0x37c300;const _0x2da8ed=_0x7874bd[_0x2613c7]['update'](_0x37c300['val']());if(_0x2da8ed!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2da8ed,_0x5c18ff['path']);let _0x1a6195=N(_0x2da8ed);typeof _0x2da8ed=='object'&&_0x2da8ed!=null&&Y(_0x2da8ed,'.priority')||(_0x1a6195=_0x1a6195['updatePriority'](_0x37c300['getPriority']()));const _0x13d9b0=_0x5c18ff['currentWriteId'],_0x1a498b=jt(_0x389958),_0x10d0af=hs(_0x1a6195,_0x37c300,_0x1a498b);_0x5c18ff['currentOutputSnapshotRaw']=_0x1a6195,_0x5c18ff['currentOutputSnapshotResolved']=_0x10d0af,_0x5c18ff['currentWriteId']=Vn(_0x389958),_0x19ae2c['splice'](_0x19ae2c['indexOf'](_0x13d9b0),0x1),_0x509a7c=_0x509a7c['concat'](ss(_0x389958['serverSyncTree_'],_0x5c18ff['path'],_0x10d0af,_0x5c18ff['currentWriteId'],_0x5c18ff['applyLocally'])),_0x509a7c=_0x509a7c['concat'](pe(_0x389958['serverSyncTree_'],_0x13d9b0,!0x0));}else _0x4fbf3e=!0x0,_0xb82ce0='nodata',_0x509a7c=_0x509a7c['concat'](pe(_0x389958['serverSyncTree_'],_0x5c18ff['currentWriteId'],!0x0));}}}V(_0x389958['eventQueue_'],_0x83b093,_0x509a7c),_0x509a7c=[],_0x4fbf3e&&(_0x7874bd[_0x2613c7]['status']=0x2,function(_0x3f8cfb){setTimeout(_0x3f8cfb,Math['floor'](0x0));}(_0x7874bd[_0x2613c7]['unwatcher']),_0x7874bd[_0x2613c7]['onComplete']&&(_0xb82ce0==='nodata'?_0x22055e['push'](()=>_0x7874bd[_0x2613c7]['onComplete'](null,!0x1,_0x7874bd[_0x2613c7]['currentInputSnapshot'])):_0x22055e['push'](()=>_0x7874bd[_0x2613c7]['onComplete'](new Error(_0xb82ce0),!0x1,null))));}$n(_0x389958,_0x389958['transactionQueueTree_']);for(let _0x9db014=0x0;_0x9db014<_0x22055e['length'];_0x9db014++)lt(_0x22055e[_0x9db014]);Hn(_0x389958,_0x389958['transactionQueueTree_']);}function ca(_0x48e7e4,_0x3c7c91){let _0x290238,_0x11af49=_0x48e7e4['transactionQueueTree_'];for(_0x290238=y(_0x3c7c91);_0x290238!==null&&Ge(_0x11af49)===void 0x0;)_0x11af49=Un(_0x11af49,_0x290238),_0x3c7c91=b(_0x3c7c91),_0x290238=y(_0x3c7c91);return _0x11af49;}function la(_0x348182,_0x38a3eb){const _0xa5c7f=[];return ha(_0x348182,_0x38a3eb,_0xa5c7f),_0xa5c7f['sort']((_0x422444,_0x42b5ef)=>_0x422444['order']-_0x42b5ef['order']),_0xa5c7f;}function ha(_0x3277b8,_0x5a13bb,_0x3edbfc){const _0x155b4a=Ge(_0x5a13bb);if(_0x155b4a){for(let _0x3be0d7=0x0;_0x3be0d7<_0x155b4a['length'];_0x3be0d7++)_0x3edbfc['push'](_0x155b4a[_0x3be0d7]);}Wn(_0x5a13bb,_0x677f4=>{ha(_0x3277b8,_0x677f4,_0x3edbfc);});}function $n(_0x481a03,_0x5ccda0){const _0x515f43=Ge(_0x5ccda0);if(_0x515f43){let _0x5328cc=0x0;for(let _0x21ee60=0x0;_0x21ee60<_0x515f43['length'];_0x21ee60++)_0x515f43[_0x21ee60]['status']!==0x2&&(_0x515f43[_0x5328cc]=_0x515f43[_0x21ee60],_0x5328cc++);_0x515f43['length']=_0x5328cc,fs(_0x5ccda0,_0x515f43['length']>0x0?_0x515f43:void 0x0);}Wn(_0x5ccda0,_0x520b7f=>{$n(_0x481a03,_0x520b7f);});}function vs(_0x15d566,_0x5772a4){const _0x54b7b0=Gt(ca(_0x15d566,_0x5772a4)),_0x64d453=Un(_0x15d566['transactionQueueTree_'],_0x5772a4);return sd(_0x64d453,_0x4bfa41=>{ai(_0x15d566,_0x4bfa41);}),ai(_0x15d566,_0x64d453),ta(_0x64d453,_0x2e7f25=>{ai(_0x15d566,_0x2e7f25);}),_0x54b7b0;}function ai(_0x3ba54f,_0xb43eab){const _0x3a7d83=Ge(_0xb43eab);if(_0x3a7d83){const _0x17bee3=[];let _0xc874c3=[],_0xbd0c6=-0x1;for(let _0x3785eb=0x0;_0x3785eb<_0x3a7d83['length'];_0x3785eb++)_0x3a7d83[_0x3785eb]['status']===0x3||(_0x3a7d83[_0x3785eb]['status']===0x1?(f(_0xbd0c6===_0x3785eb-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xbd0c6=_0x3785eb,_0x3a7d83[_0x3785eb]['status']=0x3,_0x3a7d83[_0x3785eb]['abortReason']='set'):(f(_0x3a7d83[_0x3785eb]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3a7d83[_0x3785eb]['unwatcher'](),_0xc874c3=_0xc874c3['concat'](pe(_0x3ba54f['serverSyncTree_'],_0x3a7d83[_0x3785eb]['currentWriteId'],!0x0)),_0x3a7d83[_0x3785eb]['onComplete']&&_0x17bee3['push'](_0x3a7d83[_0x3785eb]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xbd0c6===-0x1?fs(_0xb43eab,void 0x0):_0x3a7d83['length']=_0xbd0c6+0x1,V(_0x3ba54f['eventQueue_'],Gt(_0xb43eab),_0xc874c3);for(let _0x45e361=0x0;_0x45e361<_0x17bee3['length'];_0x45e361++)lt(_0x17bee3[_0x45e361]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5afddc){let _0x34441d='';const _0x22016b=_0x5afddc['split']('/');for(let _0x2b6d6b=0x0;_0x2b6d6b<_0x22016b['length'];_0x2b6d6b++)if(_0x22016b[_0x2b6d6b]['length']>0x0){let _0x42502d=_0x22016b[_0x2b6d6b];try{_0x42502d=decodeURIComponent(_0x42502d['replace'](/\+/g,'\x20'));}catch{}_0x34441d+='/'+_0x42502d;}return _0x34441d;}function Nd(_0x4d4904){const _0x133957={};_0x4d4904['charAt'](0x0)==='?'&&(_0x4d4904=_0x4d4904['substring'](0x1));for(const _0x35d20f of _0x4d4904['split']('&')){if(_0x35d20f['length']===0x0)continue;const _0x50871d=_0x35d20f['split']('=');_0x50871d['length']===0x2?_0x133957[decodeURIComponent(_0x50871d[0x0])]=decodeURIComponent(_0x50871d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x35d20f+'\x27\x20in\x20query\x20\x27'+_0x4d4904+'\x27');}return _0x133957;}const gr=function(_0x43ec35,_0x10b171){const _0x2e48f1=Pd(_0x43ec35),_0x371775=_0x2e48f1['namespace'];_0x2e48f1['domain']==='firebase.com'&&oe(_0x2e48f1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x371775||_0x371775==='undefined')&&_0x2e48f1['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2e48f1['secure']||Bl();const _0x1789fe=_0x2e48f1['scheme']==='ws'||_0x2e48f1['scheme']==='wss';return{'repoInfo':new _o(_0x2e48f1['host'],_0x2e48f1['secure'],_0x371775,_0x1789fe,_0x10b171,'',_0x371775!==_0x2e48f1['subdomain']),'path':new C(_0x2e48f1['pathString'])};},Pd=function(_0x5f1059){let _0x2ab5fe='',_0x29cbc8='',_0x344f18='',_0x58528b='',_0x27be81='',_0x5197af=!0x0,_0x4f5260='https',_0x23b370=0x1bb;if(typeof _0x5f1059=='string'){let _0x1b4ce0=_0x5f1059['indexOf']('//');_0x1b4ce0>=0x0&&(_0x4f5260=_0x5f1059['substring'](0x0,_0x1b4ce0-0x1),_0x5f1059=_0x5f1059['substring'](_0x1b4ce0+0x2));let _0x3e84f1=_0x5f1059['indexOf']('/');_0x3e84f1===-0x1&&(_0x3e84f1=_0x5f1059['length']);let _0xe55b74=_0x5f1059['indexOf']('?');_0xe55b74===-0x1&&(_0xe55b74=_0x5f1059['length']),_0x2ab5fe=_0x5f1059['substring'](0x0,Math['min'](_0x3e84f1,_0xe55b74)),_0x3e84f1<_0xe55b74&&(_0x58528b=kd(_0x5f1059['substring'](_0x3e84f1,_0xe55b74)));const _0x368577=Nd(_0x5f1059['substring'](Math['min'](_0x5f1059['length'],_0xe55b74)));_0x1b4ce0=_0x2ab5fe['indexOf'](':'),_0x1b4ce0>=0x0?(_0x5197af=_0x4f5260==='https'||_0x4f5260==='wss',_0x23b370=parseInt(_0x2ab5fe['substring'](_0x1b4ce0+0x1),0xa)):_0x1b4ce0=_0x2ab5fe['length'];const _0x21e88e=_0x2ab5fe['slice'](0x0,_0x1b4ce0);if(_0x21e88e['toLowerCase']()==='localhost')_0x29cbc8='localhost';else{if(_0x21e88e['split']('.')['length']<=0x2)_0x29cbc8=_0x21e88e;else{const _0x3990a8=_0x2ab5fe['indexOf']('.');_0x344f18=_0x2ab5fe['substring'](0x0,_0x3990a8)['toLowerCase'](),_0x29cbc8=_0x2ab5fe['substring'](_0x3990a8+0x1),_0x27be81=_0x344f18;}}'ns'in _0x368577&&(_0x27be81=_0x368577['ns']);}return{'host':_0x2ab5fe,'port':_0x23b370,'domain':_0x29cbc8,'subdomain':_0x344f18,'secure':_0x5197af,'scheme':_0x4f5260,'pathString':_0x58528b,'namespace':_0x27be81};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x3c27fa=0x0;const _0x13ac87=[];return function(_0x2915d9){const _0x5a2749=_0x2915d9===_0x3c27fa;_0x3c27fa=_0x2915d9;let _0x220b73;const _0xc8a877=new Array(0x8);for(_0x220b73=0x7;_0x220b73>=0x0;_0x220b73--)_0xc8a877[_0x220b73]=mr['charAt'](_0x2915d9%0x40),_0x2915d9=Math['floor'](_0x2915d9/0x40);f(_0x2915d9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x50e666=_0xc8a877['join']('');if(_0x5a2749){for(_0x220b73=0xb;_0x220b73>=0x0&&_0x13ac87[_0x220b73]===0x3f;_0x220b73--)_0x13ac87[_0x220b73]=0x0;_0x13ac87[_0x220b73]++;}else{for(_0x220b73=0x0;_0x220b73<0xc;_0x220b73++)_0x13ac87[_0x220b73]=Math['floor'](Math['random']()*0x40);}for(_0x220b73=0x0;_0x220b73<0xc;_0x220b73++)_0x50e666+=mr['charAt'](_0x13ac87[_0x220b73]);return f(_0x50e666['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x50e666;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2cdd35,_0x488e96,_0x4efeb7,_0x523488){this['eventType']=_0x2cdd35,this['eventRegistration']=_0x488e96,this['snapshot']=_0x4efeb7,this['prevName']=_0x523488;}['getPath'](){const _0x442e4a=this['snapshot']['ref'];return this['eventType']==='value'?_0x442e4a['_path']:_0x442e4a['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x53b4e2,_0xca9322,_0x5b83fe){this['eventRegistration']=_0x53b4e2,this['error']=_0xca9322,this['path']=_0x5b83fe;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x3371f8,_0x5dcac3){this['snapshotCallback']=_0x3371f8,this['cancelCallback']=_0x5dcac3;}['onValue'](_0x5545bd,_0x5c3641){this['snapshotCallback']['call'](null,_0x5545bd,_0x5c3641);}['onCancel'](_0x2451fd){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2451fd);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x504dc7){return this['snapshotCallback']===_0x504dc7['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x504dc7['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x504dc7['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5f5186,_0x413a41,_0x3ae275,_0x28c2da){this['_repo']=_0x5f5186,this['_path']=_0x413a41,this['_queryParams']=_0x3ae275,this['_orderByCalled']=_0x28c2da;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2876df=nr(this['_queryParams']),_0x291512=Bi(_0x2876df);return _0x291512==='{}'?'default':_0x291512;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x326e91){if(_0x326e91=k(_0x326e91),!(_0x326e91 instanceof be))return!0x1;const _0x5701f0=this['_repo']===_0x326e91['_repo'],_0x52d05b=qi(this['_path'],_0x326e91['_path']),_0x17f981=this['_queryIdentifier']===_0x326e91['_queryIdentifier'];return _0x5701f0&&_0x52d05b&&_0x17f981;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x4a182d,_0x27c2aa){if(_0x4a182d['_orderByCalled']===!0x0)throw new Error(_0x27c2aa+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x50d2f8){let _0x40b319=null,_0x3d832f=null;if(_0x50d2f8['hasStart']()&&(_0x40b319=_0x50d2f8['getIndexStartValue']()),_0x50d2f8['hasEnd']()&&(_0x3d832f=_0x50d2f8['getIndexEndValue']()),_0x50d2f8['getIndex']()===ye){const _0x2bc065='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5f37a8='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x50d2f8['hasStart']()){if(_0x50d2f8['getIndexStartName']()!==xe)throw new Error(_0x2bc065);if(typeof _0x40b319!='string')throw new Error(_0x5f37a8);}if(_0x50d2f8['hasEnd']()){if(_0x50d2f8['getIndexEndName']()!==Ie)throw new Error(_0x2bc065);if(typeof _0x3d832f!='string')throw new Error(_0x5f37a8);}}else{if(_0x50d2f8['getIndex']()===R){if(_0x40b319!=null&&!Cn(_0x40b319)||_0x3d832f!=null&&!Cn(_0x3d832f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x50d2f8['getIndex']()instanceof Ki||_0x50d2f8['getIndex']()===Po,'unknown\x20index\x20type.'),_0x40b319!=null&&typeof _0x40b319=='object'||_0x3d832f!=null&&typeof _0x3d832f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2cb07a){if(_0x2cb07a['hasStart']()&&_0x2cb07a['hasEnd']()&&_0x2cb07a['hasLimit']()&&!_0x2cb07a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x486c0f,_0x1fd823){super(_0x486c0f,_0x1fd823,new Qi(),!0x1);}get['parent'](){const _0x6f2ab9=To(this['_path']);return _0x6f2ab9===null?null:new Z(this['_repo'],_0x6f2ab9);}get['root'](){let _0x2365f8=this;for(;_0x2365f8['parent']!==null;)_0x2365f8=_0x2365f8['parent'];return _0x2365f8;}}class rt{constructor(_0x2b7a0c,_0x41a3e6,_0x2b3cce){this['_node']=_0x2b7a0c,this['ref']=_0x41a3e6,this['_index']=_0x2b3cce;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x42c2cd){const _0x405e15=new C(_0x42c2cd),_0x212522=Lt(this['ref'],_0x42c2cd);return new rt(this['_node']['getChild'](_0x405e15),_0x212522,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x19ef0b){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x401150,_0x51233d)=>_0x19ef0b(new rt(_0x51233d,Lt(this['ref'],_0x401150),R)));}['hasChild'](_0x27c738){const _0x3af3a9=new C(_0x27c738);return!this['_node']['getChild'](_0x3af3a9)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1bf9ea,_0x3dad85){return _0x1bf9ea=k(_0x1bf9ea),_0x1bf9ea['_checkNotDeleted']('ref'),_0x3dad85!==void 0x0?Lt(_0x1bf9ea['_root'],_0x3dad85):_0x1bf9ea['_root'];}function Lt(_0x2ccb10,_0x8e1e39){return _0x2ccb10=k(_0x2ccb10),y(_0x2ccb10['_path'])===null?ud('child','path',_0x8e1e39):_s('child','path',_0x8e1e39),new Z(_0x2ccb10['_repo'],A(_0x2ccb10['_path'],_0x8e1e39));}function d_(_0x2a43af,_0x435bad){_0x2a43af=k(_0x2a43af),gs('push',_0x2a43af['_path']),qt('push',_0x435bad,_0x2a43af['_path'],!0x0);const _0x56004c=oa(_0x2a43af['_repo']),_0x3643ac=Od(_0x56004c),_0x4eeb57=Lt(_0x2a43af,_0x3643ac),_0x1140e3=Lt(_0x2a43af,_0x3643ac);let _0x1bdc44;return _0x435bad!=null?_0x1bdc44=Ld(_0x1140e3,_0x435bad)['then'](()=>_0x1140e3):_0x1bdc44=Promise['resolve'](_0x1140e3),_0x4eeb57['then']=_0x1bdc44['then']['bind'](_0x1bdc44),_0x4eeb57['catch']=_0x1bdc44['then']['bind'](_0x1bdc44,void 0x0),_0x4eeb57;}function Ld(_0x44a55b,_0x392df8){_0x44a55b=k(_0x44a55b),gs('set',_0x44a55b['_path']),qt('set',_0x392df8,_0x44a55b['_path'],!0x1);const _0x431229=new Ve();return Ed(_0x44a55b['_repo'],_0x44a55b['_path'],_0x392df8,null,_0x431229['wrapCallback'](()=>{})),_0x431229['promise'];}function f_(_0xe06350,_0x10ae26){hd('update',_0x10ae26,_0xe06350['_path']);const _0x2bb92a=new Ve();return Id(_0xe06350['_repo'],_0xe06350['_path'],_0x10ae26,_0x2bb92a['wrapCallback'](()=>{})),_0x2bb92a['promise'];}function p_(_0x4f422c){_0x4f422c=k(_0x4f422c);const _0xfd525c=new ua(()=>{}),_0x20658a=new qn(_0xfd525c);return vd(_0x4f422c['_repo'],_0x4f422c,_0x20658a)['then'](_0x55f416=>new rt(_0x55f416,new Z(_0x4f422c['_repo'],_0x4f422c['_path']),_0x4f422c['_queryParams']['getIndex']()));}class qn{constructor(_0x1df0ab){this['callbackContext']=_0x1df0ab;}['respondsTo'](_0x11e6e0){return _0x11e6e0==='value';}['createEvent'](_0x4af0b0,_0x521f61){const _0x2588e3=_0x521f61['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x4af0b0['snapshotNode'],new Z(_0x521f61['_repo'],_0x521f61['_path']),_0x2588e3));}['getEventRunner'](_0x5cafda){return _0x5cafda['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5cafda['error']):()=>this['callbackContext']['onValue'](_0x5cafda['snapshot'],null);}['createCancelEvent'](_0x3e37d8,_0x4348e6){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x3e37d8,_0x4348e6):null;}['matches'](_0xee29ad){return _0xee29ad instanceof qn?!_0xee29ad['callbackContext']||!this['callbackContext']?!0x0:_0xee29ad['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3e2790,_0x189138,_0x8e5350,_0x4f6684,_0x2c8b7c){const _0x232cbd=new ua(_0x8e5350,void 0x0),_0x3c6fbb=new qn(_0x232cbd);return Cd(_0x3e2790['_repo'],_0x3e2790,_0x3c6fbb),()=>Td(_0x3e2790['_repo'],_0x3e2790,_0x3c6fbb);}function Fd(_0x56a26e,_0x4b3f01,_0x567d60,_0x2c4fd1){return xd(_0x56a26e,'value',_0x4b3f01);}class dt{}class pa extends dt{constructor(_0x2c8b02,_0x1b994f){super(),this['_value']=_0x2c8b02,this['_key']=_0x1b994f,this['type']='endAt';}['_apply'](_0xccac61){qt('endAt',this['_value'],_0xccac61['_path'],!0x0);const _0x173eeb=Kh(_0xccac61['_queryParams'],this['_value'],this['_key']);if(fa(_0x173eeb),Gn(_0x173eeb),_0xccac61['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0xccac61['_repo'],_0xccac61['_path'],_0x173eeb,_0xccac61['_orderByCalled']);}}function __(_0x305337,_0x411d50){return new pa(_0x305337,_0x411d50);}class _a extends dt{constructor(_0x3e5b1f,_0x11ecc0){super(),this['_value']=_0x3e5b1f,this['_key']=_0x11ecc0,this['type']='startAt';}['_apply'](_0x4c8fa0){qt('startAt',this['_value'],_0x4c8fa0['_path'],!0x0);const _0x8f924d=jh(_0x4c8fa0['_queryParams'],this['_value'],this['_key']);if(fa(_0x8f924d),Gn(_0x8f924d),_0x4c8fa0['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4c8fa0['_repo'],_0x4c8fa0['_path'],_0x8f924d,_0x4c8fa0['_orderByCalled']);}}function g_(_0x1689f6=null,_0x2b1d3e){return new _a(_0x1689f6,_0x2b1d3e);}class Ud extends dt{constructor(_0x380f11){super(),this['_limit']=_0x380f11,this['type']='limitToFirst';}['_apply'](_0x8c5274){if(_0x8c5274['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x8c5274['_repo'],_0x8c5274['_path'],zh(_0x8c5274['_queryParams'],this['_limit']),_0x8c5274['_orderByCalled']);}}function m_(_0x339278){if(Math['floor'](_0x339278)!==_0x339278||_0x339278<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x339278);}class Wd extends dt{constructor(_0x399567){super(),this['_path']=_0x399567,this['type']='orderByChild';}['_apply'](_0x2baa9e){da(_0x2baa9e,'orderByChild');const _0x5dfd62=new C(this['_path']);if(v(_0x5dfd62))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2b0f37=new Ki(_0x5dfd62),_0x4edb67=Do(_0x2baa9e['_queryParams'],_0x2b0f37);return Gn(_0x4edb67),new be(_0x2baa9e['_repo'],_0x2baa9e['_path'],_0x4edb67,!0x0);}}function y_(_0x315895){if(_0x315895==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x315895==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x315895==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x315895),new Wd(_0x315895);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5418be){da(_0x5418be,'orderByKey');const _0x2686a3=Do(_0x5418be['_queryParams'],ye);return Gn(_0x2686a3),new be(_0x5418be['_repo'],_0x5418be['_path'],_0x2686a3,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x38c984,_0x5e19ca){super(),this['_value']=_0x38c984,this['_key']=_0x5e19ca,this['type']='equalTo';}['_apply'](_0x107ff8){if(qt('equalTo',this['_value'],_0x107ff8['_path'],!0x1),_0x107ff8['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x107ff8['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x107ff8));}}function E_(_0x155e9a,_0x1fcc3){return new Vd(_0x155e9a,_0x1fcc3);}function I_(_0x237538,..._0x5df614){let _0x2038b5=k(_0x237538);for(const _0x4c7e3f of _0x5df614)_0x2038b5=_0x4c7e3f['_apply'](_0x2038b5);return _0x2038b5;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3e7b7a,_0x2cf287,_0x1b3349,_0x20ea76){const _0x2d80cc=_0x2cf287['lastIndexOf'](':'),_0x381ec8=_0x2cf287['substring'](0x0,_0x2d80cc),_0x278053=Wt(_0x381ec8);_0x3e7b7a['repoInfo_']=new _o(_0x2cf287,_0x278053,_0x3e7b7a['repoInfo_']['namespace'],_0x3e7b7a['repoInfo_']['webSocketOnly'],_0x3e7b7a['repoInfo_']['nodeAdmin'],_0x3e7b7a['repoInfo_']['persistenceKey'],_0x3e7b7a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1b3349),_0x20ea76&&(_0x3e7b7a['authTokenProvider_']=_0x20ea76);}function qd(_0x3266ae,_0x3dd776,_0x2c2e68,_0x4b0948,_0x394e12){let _0x4dd601=_0x4b0948||_0x3266ae['options']['databaseURL'];_0x4dd601===void 0x0&&(_0x3266ae['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3266ae['options']['projectId']),_0x4dd601=_0x3266ae['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x28bfd6=gr(_0x4dd601,_0x394e12),_0x4cfe8a=_0x28bfd6['repoInfo'],_0x5bc720;typeof process<'u'&&Us&&(_0x5bc720=Us[Hd]),_0x5bc720?(_0x4dd601='http://'+_0x5bc720+'?ns='+_0x4cfe8a['namespace'],_0x28bfd6=gr(_0x4dd601,_0x394e12),_0x4cfe8a=_0x28bfd6['repoInfo']):_0x28bfd6['repoInfo']['secure'];const _0x3c7ed1=new Jl(_0x3266ae['name'],_0x3266ae['options'],_0x3dd776);dd('Invalid\x20Firebase\x20Database\x20URL',_0x28bfd6),v(_0x28bfd6['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2fb489=jd(_0x4cfe8a,_0x3266ae,_0x3c7ed1,new Ql(_0x3266ae,_0x2c2e68));return new Kd(_0x2fb489,_0x3266ae);}function zd(_0xb5e03d,_0x4d7b09){const _0x891113=ki[_0x4d7b09];(!_0x891113||_0x891113[_0xb5e03d['key']]!==_0xb5e03d)&&oe('Database\x20'+_0x4d7b09+'('+_0xb5e03d['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0xb5e03d),delete _0x891113[_0xb5e03d['key']];}function jd(_0x5dfa50,_0x4c48ae,_0x3bf7ca,_0x2a3bbb){let _0x16298d=ki[_0x4c48ae['name']];_0x16298d||(_0x16298d={},ki[_0x4c48ae['name']]=_0x16298d);let _0x502533=_0x16298d[_0x5dfa50['toURLString']()];return _0x502533&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x502533=new gd(_0x5dfa50,$d,_0x3bf7ca,_0x2a3bbb),_0x16298d[_0x5dfa50['toURLString']()]=_0x502533,_0x502533;}class Kd{constructor(_0xad0114,_0x3ee143){this['_repoInternal']=_0xad0114,this['app']=_0x3ee143,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5d03c4){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5d03c4+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x4db995=Qr(),_0x1f4cdf){const _0x37298e=Ui(_0x4db995,'database')['getImmediate']({'identifier':_0x1f4cdf});if(!_0x37298e['_instanceStarted']){const _0x5595e9=ac('database');_0x5595e9&&Yd(_0x37298e,..._0x5595e9);}return _0x37298e;}function Yd(_0x47609a,_0x3ad3d2,_0x30dbec,_0x2e73bf={}){_0x47609a=k(_0x47609a),_0x47609a['_checkNotDeleted']('useEmulator');const _0x2125b2=_0x3ad3d2+':'+_0x30dbec,_0x3caa66=_0x47609a['_repoInternal'];if(_0x47609a['_instanceStarted']){if(_0x2125b2===_0x47609a['_repoInternal']['repoInfo_']['host']&&De(_0x2e73bf,_0x3caa66['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x18ecab;if(_0x3caa66['repoInfo_']['nodeAdmin'])_0x2e73bf['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x18ecab=new tn(tn['OWNER']);else{if(_0x2e73bf['mockUserToken']){const _0x4b1bee=typeof _0x2e73bf['mockUserToken']=='string'?_0x2e73bf['mockUserToken']:cc(_0x2e73bf['mockUserToken'],_0x47609a['app']['options']['projectId']);_0x18ecab=new tn(_0x4b1bee);}}Wt(_0x3ad3d2)&&jr(_0x3ad3d2),Gd(_0x3caa66,_0x2125b2,_0x2e73bf,_0x18ecab);}function C_(_0x42e9f7){_0x42e9f7=k(_0x42e9f7),_0x42e9f7['_checkNotDeleted']('goOffline'),aa(_0x42e9f7['_repo']);}function T_(_0x2ab9a2){_0x2ab9a2=k(_0x2ab9a2),_0x2ab9a2['_checkNotDeleted']('goOnline'),Sd(_0x2ab9a2['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x2e863d){Ll(ct),et(new Me('database',(_0x326d14,{instanceIdentifier:_0x481443})=>{const _0x3e44ce=_0x326d14['getProvider']('app')['getImmediate'](),_0x2dfdcd=_0x326d14['getProvider']('auth-internal'),_0x1d4d62=_0x326d14['getProvider']('app-check-internal');return qd(_0x3e44ce,_0x2dfdcd,_0x1d4d62,_0x481443);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x2e863d),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x5a9f04,_0x46436e){this['committed']=_0x5a9f04,this['snapshot']=_0x46436e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x27a0dd,_0x53a4f2,_0x1dcf8b){if(_0x27a0dd=k(_0x27a0dd),gs('Reference.transaction',_0x27a0dd['_path']),_0x27a0dd['key']==='.length'||_0x27a0dd['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x27a0dd['key']+'\x20is\x20a\x20read-only\x20object.';const _0x39ec27=!0x0,_0x4061a1=new Ve(),_0x4e98e8=(_0x4161ea,_0x5888a4,_0x460e6e)=>{let _0x252a51=null;_0x4161ea?_0x4061a1['reject'](_0x4161ea):(_0x252a51=new rt(_0x460e6e,new Z(_0x27a0dd['_repo'],_0x27a0dd['_path']),R),_0x4061a1['resolve'](new Xd(_0x5888a4,_0x252a51)));},_0x4ee21a=Fd(_0x27a0dd,()=>{});return bd(_0x27a0dd['_repo'],_0x27a0dd['_path'],_0x53a4f2,_0x4e98e8,_0x4ee21a,_0x39ec27),_0x4061a1['promise'];}ie['prototype']['simpleListen']=function(_0x45be41,_0x295db2){this['sendRequest']('q',{'p':_0x45be41},_0x295db2);},ie['prototype']['echo']=function(_0x462481,_0x5d0129){this['sendRequest']('echo',{'d':_0x462481},_0x5d0129);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x5de355,..._0x5147e2){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x5de355,..._0x5147e2);}function nn(_0x344490,..._0x1f327d){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x344490,..._0x1f327d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5de027,..._0x698f67){throw Es(_0x5de027,..._0x698f67);}function J(_0x100f32,..._0x13ffce){return Es(_0x100f32,..._0x13ffce);}function ya(_0x475531,_0x5caaf2,_0x33ff5b){const _0x1b747c={...Zd(),[_0x5caaf2]:_0x33ff5b};return new Ut('auth','Firebase',_0x1b747c)['create'](_0x5caaf2,{'appName':_0x475531['name']});}function se(_0x203f69){return ya(_0x203f69,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x32cef1,..._0x48e18f){if(typeof _0x32cef1!='string'){const _0x4d5193=_0x48e18f[0x0],_0x1e68e9=[..._0x48e18f['slice'](0x1)];return _0x1e68e9[0x0]&&(_0x1e68e9[0x0]['appName']=_0x32cef1['name']),_0x32cef1['_errorFactory']['create'](_0x4d5193,..._0x1e68e9);}return ma['create'](_0x32cef1,..._0x48e18f);}function m(_0x3487ed,_0x1fe891,..._0x40bb77){if(!_0x3487ed)throw Es(_0x1fe891,..._0x40bb77);}function te(_0x39e9e7){const _0x23c5e3='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x39e9e7;throw nn(_0x23c5e3),new Error(_0x23c5e3);}function ae(_0x2e8a4f,_0x3425b3){_0x2e8a4f||te(_0x3425b3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x250c95;return typeof self<'u'&&((_0x250c95=self['location'])==null?void 0x0:_0x250c95['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x592243;return typeof self<'u'&&((_0x592243=self['location'])==null?void 0x0:_0x592243['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x37bf43=navigator;return _0x37bf43['languages']&&_0x37bf43['languages'][0x0]||_0x37bf43['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x560526,_0x21224f){this['shortDelay']=_0x560526,this['longDelay']=_0x21224f,ae(_0x21224f>_0x560526,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x184dc3,_0x213d4e){ae(_0x184dc3['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xe0126d}=_0x184dc3['emulator'];return _0x213d4e?''+_0xe0126d+(_0x213d4e['startsWith']('/')?_0x213d4e['slice'](0x1):_0x213d4e):_0xe0126d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1842df,_0xea7fb7,_0x589bd0){this['fetchImpl']=_0x1842df,_0xea7fb7&&(this['headersImpl']=_0xea7fb7),_0x589bd0&&(this['responseImpl']=_0x589bd0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1fb2aa,_0xf5b9a5){return _0x1fb2aa['tenantId']&&!_0xf5b9a5['tenantId']?{..._0xf5b9a5,'tenantId':_0x1fb2aa['tenantId']}:_0xf5b9a5;}async function Ae(_0x23e655,_0x37a2e1,_0x57e826,_0xdfd325,_0x88151e={}){return Ea(_0x23e655,_0x88151e,async()=>{let _0x23f583={},_0x17dc38={};_0xdfd325&&(_0x37a2e1==='GET'?_0x17dc38=_0xdfd325:_0x23f583={'body':JSON['stringify'](_0xdfd325)});const _0x48fefe=at({..._0x17dc38,'key':_0x23e655['config']['apiKey']})['slice'](0x1),_0xdec467=await _0x23e655['_getAdditionalHeaders']();_0xdec467['Content-Type']='application/json',_0x23e655['languageCode']&&(_0xdec467['X-Firebase-Locale']=_0x23e655['languageCode']);const _0x31680a={'method':_0x37a2e1,'headers':_0xdec467,..._0x23f583};return lc()||(_0x31680a['referrerPolicy']='strict-origin-when-cross-origin'),_0x23e655['emulatorConfig']&&Wt(_0x23e655['emulatorConfig']['host'])&&(_0x31680a['credentials']='include'),va['fetch']()(await Ia(_0x23e655,_0x23e655['config']['apiHost'],_0x57e826,_0x48fefe),_0x31680a);});}async function Ea(_0x463318,_0x38012c,_0x12f558){_0x463318['_canInitEmulator']=!0x1;const _0x304226={...rf,..._0x38012c};try{const _0x5df766=new lf(_0x463318),_0x3a5ae2=await Promise['race']([_0x12f558(),_0x5df766['promise']]);_0x5df766['clearNetworkTimeout']();const _0x173e8e=await _0x3a5ae2['json']();if('needConfirmation'in _0x173e8e)throw en(_0x463318,'account-exists-with-different-credential',_0x173e8e);if(_0x3a5ae2['ok']&&!('errorMessage'in _0x173e8e))return _0x173e8e;{const _0x5679c5=_0x3a5ae2['ok']?_0x173e8e['errorMessage']:_0x173e8e['error']['message'],[_0x2dc72a,_0x4aa7e2]=_0x5679c5['split']('\x20:\x20');if(_0x2dc72a==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x463318,'credential-already-in-use',_0x173e8e);if(_0x2dc72a==='EMAIL_EXISTS')throw en(_0x463318,'email-already-in-use',_0x173e8e);if(_0x2dc72a==='USER_DISABLED')throw en(_0x463318,'user-disabled',_0x173e8e);const _0x530163=_0x304226[_0x2dc72a]||_0x2dc72a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4aa7e2)throw ya(_0x463318,_0x530163,_0x4aa7e2);K(_0x463318,_0x530163);}}catch(_0x3a0194){if(_0x3a0194 instanceof Se)throw _0x3a0194;K(_0x463318,'network-request-failed',{'message':String(_0x3a0194)});}}async function Yt(_0x1ff6cf,_0x58c4a5,_0x229da8,_0x44a33e,_0x324e19={}){const _0x3e19ae=await Ae(_0x1ff6cf,_0x58c4a5,_0x229da8,_0x44a33e,_0x324e19);return'mfaPendingCredential'in _0x3e19ae&&K(_0x1ff6cf,'multi-factor-auth-required',{'_serverResponse':_0x3e19ae}),_0x3e19ae;}async function Ia(_0x31df12,_0x33a391,_0x5d008c,_0x202c86){const _0x5b6651=''+_0x33a391+_0x5d008c+'?'+_0x202c86,_0x5f0f65=_0x31df12,_0x52883a=_0x5f0f65['config']['emulator']?Is(_0x31df12['config'],_0x5b6651):_0x31df12['config']['apiScheme']+'://'+_0x5b6651;return of['includes'](_0x5d008c)&&(await _0x5f0f65['_persistenceManagerAvailable'],_0x5f0f65['_getPersistenceType']()==='COOKIE')?_0x5f0f65['_getPersistence']()['_getFinalTarget'](_0x52883a)['toString']():_0x52883a;}function cf(_0x2ba6bf){switch(_0x2ba6bf){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x251194){this['auth']=_0x251194,this['timer']=null,this['promise']=new Promise((_0x15bd1f,_0x454fe4)=>{this['timer']=setTimeout(()=>_0x454fe4(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x25990c,_0x11f0a2,_0x53bfe9){const _0x59997f={'appName':_0x25990c['name']};_0x53bfe9['email']&&(_0x59997f['email']=_0x53bfe9['email']),_0x53bfe9['phoneNumber']&&(_0x59997f['phoneNumber']=_0x53bfe9['phoneNumber']);const _0x2ac8f3=J(_0x25990c,_0x11f0a2,_0x59997f);return _0x2ac8f3['customData']['_tokenResponse']=_0x53bfe9,_0x2ac8f3;}function vr(_0x15a054){return _0x15a054!==void 0x0&&_0x15a054['enterprise']!==void 0x0;}class hf{constructor(_0x2d050e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2d050e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2d050e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2d050e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3bdddf){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4826d4 of this['recaptchaEnforcementState'])if(_0x4826d4['provider']&&_0x4826d4['provider']===_0x3bdddf)return cf(_0x4826d4['enforcementState']);return null;}['isProviderEnabled'](_0x22ea44){return this['getProviderEnforcementState'](_0x22ea44)==='ENFORCE'||this['getProviderEnforcementState'](_0x22ea44)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x194ae,_0x258d32){return Ae(_0x194ae,'GET','/v2/recaptchaConfig',Re(_0x194ae,_0x258d32));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x1d96a9,_0x1651ee){return Ae(_0x1d96a9,'POST','/v1/accounts:delete',_0x1651ee);}async function Sn(_0x240f6c,_0x1d1a0f){return Ae(_0x240f6c,'POST','/v1/accounts:lookup',_0x1d1a0f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x292fc0){if(_0x292fc0)try{const _0x4f1b83=new Date(Number(_0x292fc0));if(!isNaN(_0x4f1b83['getTime']()))return _0x4f1b83['toUTCString']();}catch{}}async function ff(_0x2ed4de,_0x4a07ce=!0x1){const _0x3c4d15=k(_0x2ed4de),_0x47d58a=await _0x3c4d15['getIdToken'](_0x4a07ce),_0x26c831=ws(_0x47d58a);m(_0x26c831&&_0x26c831['exp']&&_0x26c831['auth_time']&&_0x26c831['iat'],_0x3c4d15['auth'],'internal-error');const _0x41bfd0=typeof _0x26c831['firebase']=='object'?_0x26c831['firebase']:void 0x0,_0x43c681=_0x41bfd0==null?void 0x0:_0x41bfd0['sign_in_provider'];return{'claims':_0x26c831,'token':_0x47d58a,'authTime':St(ci(_0x26c831['auth_time'])),'issuedAtTime':St(ci(_0x26c831['iat'])),'expirationTime':St(ci(_0x26c831['exp'])),'signInProvider':_0x43c681||null,'signInSecondFactor':(_0x41bfd0==null?void 0x0:_0x41bfd0['sign_in_second_factor'])||null};}function ci(_0x2f6e44){return Number(_0x2f6e44)*0x3e8;}function ws(_0x1cfeee){const [_0x24fb64,_0x2a682b,_0x1b0c38]=_0x1cfeee['split']('.');if(_0x24fb64===void 0x0||_0x2a682b===void 0x0||_0x1b0c38===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x20949e=cn(_0x2a682b);return _0x20949e?JSON['parse'](_0x20949e):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2e054f){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2e054f==null?void 0x0:_0x2e054f['toString']()),null;}}function Er(_0x28c2c1){const _0x4f1775=ws(_0x28c2c1);return m(_0x4f1775,'internal-error'),m(typeof _0x4f1775['exp']<'u','internal-error'),m(typeof _0x4f1775['iat']<'u','internal-error'),Number(_0x4f1775['exp'])-Number(_0x4f1775['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x59afaf,_0x545fba,_0xcb4240=!0x1){if(_0xcb4240)return _0x545fba;try{return await _0x545fba;}catch(_0x5d04f5){throw _0x5d04f5 instanceof Se&&pf(_0x5d04f5)&&_0x59afaf['auth']['currentUser']===_0x59afaf&&await _0x59afaf['auth']['signOut'](),_0x5d04f5;}}function pf({code:_0xe17dd0}){return _0xe17dd0==='auth/user-disabled'||_0xe17dd0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x5d68a2){this['user']=_0x5d68a2,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x9c49f8){if(_0x9c49f8){const _0x2a9886=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2a9886;}else{this['errorBackoff']=0x7530;const _0x2a647d=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2a647d);}}['schedule'](_0x23b913=!0x1){if(!this['isRunning'])return;const _0x145019=this['getInterval'](_0x23b913);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x145019);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x194a01){(_0x194a01==null?void 0x0:_0x194a01['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x273263,_0x1c2cd8){this['createdAt']=_0x273263,this['lastLoginAt']=_0x1c2cd8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x9653a4){this['createdAt']=_0x9653a4['createdAt'],this['lastLoginAt']=_0x9653a4['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x2360e7){var _0x91a5dd;const _0x12a9cd=_0x2360e7['auth'],_0x45fd98=await _0x2360e7['getIdToken'](),_0x14464e=await xt(_0x2360e7,Sn(_0x12a9cd,{'idToken':_0x45fd98}));m(_0x14464e==null?void 0x0:_0x14464e['users']['length'],_0x12a9cd,'internal-error');const _0x37ac43=_0x14464e['users'][0x0];_0x2360e7['_notifyReloadListener'](_0x37ac43);const _0x48ab6a=(_0x91a5dd=_0x37ac43['providerUserInfo'])!=null&&_0x91a5dd['length']?wa(_0x37ac43['providerUserInfo']):[],_0x1cf762=mf(_0x2360e7['providerData'],_0x48ab6a),_0x461152=_0x2360e7['isAnonymous'],_0x4ebbeb=!(_0x2360e7['email']&&_0x37ac43['passwordHash'])&&!(_0x1cf762!=null&&_0x1cf762['length']),_0x2c7e2d=_0x461152?_0x4ebbeb:!0x1,_0x4955c7={'uid':_0x37ac43['localId'],'displayName':_0x37ac43['displayName']||null,'photoURL':_0x37ac43['photoUrl']||null,'email':_0x37ac43['email']||null,'emailVerified':_0x37ac43['emailVerified']||!0x1,'phoneNumber':_0x37ac43['phoneNumber']||null,'tenantId':_0x37ac43['tenantId']||null,'providerData':_0x1cf762,'metadata':new Pi(_0x37ac43['createdAt'],_0x37ac43['lastLoginAt']),'isAnonymous':_0x2c7e2d};Object['assign'](_0x2360e7,_0x4955c7);}async function gf(_0xe850c7){const _0x360a04=k(_0xe850c7);await bn(_0x360a04),await _0x360a04['auth']['_persistUserIfCurrent'](_0x360a04),_0x360a04['auth']['_notifyListenersIfCurrent'](_0x360a04);}function mf(_0x5b5a70,_0x322896){return[..._0x5b5a70['filter'](_0x518d70=>!_0x322896['some'](_0x2b2732=>_0x2b2732['providerId']===_0x518d70['providerId'])),..._0x322896];}function wa(_0x56fc2f){return _0x56fc2f['map'](({providerId:_0x365991,..._0x42d34d})=>({'providerId':_0x365991,'uid':_0x42d34d['rawId']||'','displayName':_0x42d34d['displayName']||null,'email':_0x42d34d['email']||null,'phoneNumber':_0x42d34d['phoneNumber']||null,'photoURL':_0x42d34d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x537f5c,_0x396198){const _0x57b3b0=await Ea(_0x537f5c,{},async()=>{const _0x2e5ac3=at({'grant_type':'refresh_token','refresh_token':_0x396198})['slice'](0x1),{tokenApiHost:_0x2bdc3b,apiKey:_0x5a77a1}=_0x537f5c['config'],_0x38c279=await Ia(_0x537f5c,_0x2bdc3b,'/v1/token','key='+_0x5a77a1),_0x55f9c6=await _0x537f5c['_getAdditionalHeaders']();_0x55f9c6['Content-Type']='application/x-www-form-urlencoded';const _0xa31a34={'method':'POST','headers':_0x55f9c6,'body':_0x2e5ac3};return _0x537f5c['emulatorConfig']&&Wt(_0x537f5c['emulatorConfig']['host'])&&(_0xa31a34['credentials']='include'),va['fetch']()(_0x38c279,_0xa31a34);});return{'accessToken':_0x57b3b0['access_token'],'expiresIn':_0x57b3b0['expires_in'],'refreshToken':_0x57b3b0['refresh_token']};}async function vf(_0x228124,_0x269b5c){return Ae(_0x228124,'POST','/v2/accounts:revokeToken',Re(_0x228124,_0x269b5c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xf0bb3d){m(_0xf0bb3d['idToken'],'internal-error'),m(typeof _0xf0bb3d['idToken']<'u','internal-error'),m(typeof _0xf0bb3d['refreshToken']<'u','internal-error');const _0x2070c2='expiresIn'in _0xf0bb3d&&typeof _0xf0bb3d['expiresIn']<'u'?Number(_0xf0bb3d['expiresIn']):Er(_0xf0bb3d['idToken']);this['updateTokensAndExpiration'](_0xf0bb3d['idToken'],_0xf0bb3d['refreshToken'],_0x2070c2);}['updateFromIdToken'](_0x5453bc){m(_0x5453bc['length']!==0x0,'internal-error');const _0xa7fc84=Er(_0x5453bc);this['updateTokensAndExpiration'](_0x5453bc,null,_0xa7fc84);}async['getToken'](_0xb6951a,_0x5b1b56=!0x1){return!_0x5b1b56&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xb6951a,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xb6951a,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x96b2e5,_0x3c823d){const {accessToken:_0x4db80b,refreshToken:_0x4942d7,expiresIn:_0x5da3b2}=await yf(_0x96b2e5,_0x3c823d);this['updateTokensAndExpiration'](_0x4db80b,_0x4942d7,Number(_0x5da3b2));}['updateTokensAndExpiration'](_0x434f3d,_0x293236,_0x472a3f){this['refreshToken']=_0x293236||null,this['accessToken']=_0x434f3d||null,this['expirationTime']=Date['now']()+_0x472a3f*0x3e8;}static['fromJSON'](_0x3a13d1,_0x3ac403){const {refreshToken:_0x3c4b5d,accessToken:_0x566225,expirationTime:_0x1af52e}=_0x3ac403,_0x26dc7c=new Je();return _0x3c4b5d&&(m(typeof _0x3c4b5d=='string','internal-error',{'appName':_0x3a13d1}),_0x26dc7c['refreshToken']=_0x3c4b5d),_0x566225&&(m(typeof _0x566225=='string','internal-error',{'appName':_0x3a13d1}),_0x26dc7c['accessToken']=_0x566225),_0x1af52e&&(m(typeof _0x1af52e=='number','internal-error',{'appName':_0x3a13d1}),_0x26dc7c['expirationTime']=_0x1af52e),_0x26dc7c;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x178b08){this['accessToken']=_0x178b08['accessToken'],this['refreshToken']=_0x178b08['refreshToken'],this['expirationTime']=_0x178b08['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x23faae,_0x3cca28){m(typeof _0x23faae=='string'||typeof _0x23faae>'u','internal-error',{'appName':_0x3cca28});}class z{constructor({uid:_0x1e5d3d,auth:_0x568767,stsTokenManager:_0x44e67b,..._0x2c6fbb}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1e5d3d,this['auth']=_0x568767,this['stsTokenManager']=_0x44e67b,this['accessToken']=_0x44e67b['accessToken'],this['displayName']=_0x2c6fbb['displayName']||null,this['email']=_0x2c6fbb['email']||null,this['emailVerified']=_0x2c6fbb['emailVerified']||!0x1,this['phoneNumber']=_0x2c6fbb['phoneNumber']||null,this['photoURL']=_0x2c6fbb['photoURL']||null,this['isAnonymous']=_0x2c6fbb['isAnonymous']||!0x1,this['tenantId']=_0x2c6fbb['tenantId']||null,this['providerData']=_0x2c6fbb['providerData']?[..._0x2c6fbb['providerData']]:[],this['metadata']=new Pi(_0x2c6fbb['createdAt']||void 0x0,_0x2c6fbb['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4832a6){const _0x36152e=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4832a6));return m(_0x36152e,this['auth'],'internal-error'),this['accessToken']!==_0x36152e&&(this['accessToken']=_0x36152e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x36152e;}['getIdTokenResult'](_0x58dc2f){return ff(this,_0x58dc2f);}['reload'](){return gf(this);}['_assign'](_0x1f2aae){this!==_0x1f2aae&&(m(this['uid']===_0x1f2aae['uid'],this['auth'],'internal-error'),this['displayName']=_0x1f2aae['displayName'],this['photoURL']=_0x1f2aae['photoURL'],this['email']=_0x1f2aae['email'],this['emailVerified']=_0x1f2aae['emailVerified'],this['phoneNumber']=_0x1f2aae['phoneNumber'],this['isAnonymous']=_0x1f2aae['isAnonymous'],this['tenantId']=_0x1f2aae['tenantId'],this['providerData']=_0x1f2aae['providerData']['map'](_0x1a3c86=>({..._0x1a3c86})),this['metadata']['_copy'](_0x1f2aae['metadata']),this['stsTokenManager']['_assign'](_0x1f2aae['stsTokenManager']));}['_clone'](_0x3ff115){const _0x461365=new z({...this,'auth':_0x3ff115,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x461365['metadata']['_copy'](this['metadata']),_0x461365;}['_onReload'](_0x3cd775){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x3cd775,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x487df8){this['reloadListener']?this['reloadListener'](_0x487df8):this['reloadUserInfo']=_0x487df8;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5d0c80,_0x65d51f=!0x1){let _0x492a1f=!0x1;_0x5d0c80['idToken']&&_0x5d0c80['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5d0c80),_0x492a1f=!0x0),_0x65d51f&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x492a1f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x504b23=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x504b23})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x5a43c3=>({..._0x5a43c3})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x42bfd6,_0x3bbcd0){const _0x49fd40=_0x3bbcd0['displayName']??void 0x0,_0x7c1b7f=_0x3bbcd0['email']??void 0x0,_0x3330a1=_0x3bbcd0['phoneNumber']??void 0x0,_0x3910af=_0x3bbcd0['photoURL']??void 0x0,_0x528072=_0x3bbcd0['tenantId']??void 0x0,_0x2e2c05=_0x3bbcd0['_redirectEventId']??void 0x0,_0x33511e=_0x3bbcd0['createdAt']??void 0x0,_0x14c6b3=_0x3bbcd0['lastLoginAt']??void 0x0,{uid:_0x4a4dab,emailVerified:_0x545186,isAnonymous:_0x573cbd,providerData:_0x51ba6a,stsTokenManager:_0x58a8d6}=_0x3bbcd0;m(_0x4a4dab&&_0x58a8d6,_0x42bfd6,'internal-error');const _0x506346=Je['fromJSON'](this['name'],_0x58a8d6);m(typeof _0x4a4dab=='string',_0x42bfd6,'internal-error'),ce(_0x49fd40,_0x42bfd6['name']),ce(_0x7c1b7f,_0x42bfd6['name']),m(typeof _0x545186=='boolean',_0x42bfd6,'internal-error'),m(typeof _0x573cbd=='boolean',_0x42bfd6,'internal-error'),ce(_0x3330a1,_0x42bfd6['name']),ce(_0x3910af,_0x42bfd6['name']),ce(_0x528072,_0x42bfd6['name']),ce(_0x2e2c05,_0x42bfd6['name']),ce(_0x33511e,_0x42bfd6['name']),ce(_0x14c6b3,_0x42bfd6['name']);const _0xf2201d=new z({'uid':_0x4a4dab,'auth':_0x42bfd6,'email':_0x7c1b7f,'emailVerified':_0x545186,'displayName':_0x49fd40,'isAnonymous':_0x573cbd,'photoURL':_0x3910af,'phoneNumber':_0x3330a1,'tenantId':_0x528072,'stsTokenManager':_0x506346,'createdAt':_0x33511e,'lastLoginAt':_0x14c6b3});return _0x51ba6a&&Array['isArray'](_0x51ba6a)&&(_0xf2201d['providerData']=_0x51ba6a['map'](_0x20e341=>({..._0x20e341}))),_0x2e2c05&&(_0xf2201d['_redirectEventId']=_0x2e2c05),_0xf2201d;}static async['_fromIdTokenResponse'](_0x1f553e,_0x674d6e,_0x26d9f4=!0x1){const _0x9f8cb6=new Je();_0x9f8cb6['updateFromServerResponse'](_0x674d6e);const _0x2dfde0=new z({'uid':_0x674d6e['localId'],'auth':_0x1f553e,'stsTokenManager':_0x9f8cb6,'isAnonymous':_0x26d9f4});return await bn(_0x2dfde0),_0x2dfde0;}static async['_fromGetAccountInfoResponse'](_0x176b40,_0x2e07dc,_0x2bdc05){const _0x30a6d6=_0x2e07dc['users'][0x0];m(_0x30a6d6['localId']!==void 0x0,'internal-error');const _0x149e1c=_0x30a6d6['providerUserInfo']!==void 0x0?wa(_0x30a6d6['providerUserInfo']):[],_0x57f668=!(_0x30a6d6['email']&&_0x30a6d6['passwordHash'])&&!(_0x149e1c!=null&&_0x149e1c['length']),_0x4bdb3f=new Je();_0x4bdb3f['updateFromIdToken'](_0x2bdc05);const _0x4f846f=new z({'uid':_0x30a6d6['localId'],'auth':_0x176b40,'stsTokenManager':_0x4bdb3f,'isAnonymous':_0x57f668}),_0x1595b3={'uid':_0x30a6d6['localId'],'displayName':_0x30a6d6['displayName']||null,'photoURL':_0x30a6d6['photoUrl']||null,'email':_0x30a6d6['email']||null,'emailVerified':_0x30a6d6['emailVerified']||!0x1,'phoneNumber':_0x30a6d6['phoneNumber']||null,'tenantId':_0x30a6d6['tenantId']||null,'providerData':_0x149e1c,'metadata':new Pi(_0x30a6d6['createdAt'],_0x30a6d6['lastLoginAt']),'isAnonymous':!(_0x30a6d6['email']&&_0x30a6d6['passwordHash'])&&!(_0x149e1c!=null&&_0x149e1c['length'])};return Object['assign'](_0x4f846f,_0x1595b3),_0x4f846f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0xe2170c){ae(_0xe2170c instanceof Function,'Expected\x20a\x20class\x20definition');let _0x20e315=Ir['get'](_0xe2170c);return _0x20e315?(ae(_0x20e315 instanceof _0xe2170c,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x20e315):(_0x20e315=new _0xe2170c(),Ir['set'](_0xe2170c,_0x20e315),_0x20e315);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x33a1c9,_0x1dada2){this['storage'][_0x33a1c9]=_0x1dada2;}async['_get'](_0x49a399){const _0x2d4d56=this['storage'][_0x49a399];return _0x2d4d56===void 0x0?null:_0x2d4d56;}async['_remove'](_0x19cdad){delete this['storage'][_0x19cdad];}['_addListener'](_0x42a749,_0x342c94){}['_removeListener'](_0x32b0f2,_0x4bf137){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3cbb0b,_0x54a14b,_0x17fb96){return'firebase:'+_0x3cbb0b+':'+_0x54a14b+':'+_0x17fb96;}class Xe{constructor(_0x383138,_0x30f4e6,_0x536710){this['persistence']=_0x383138,this['auth']=_0x30f4e6,this['userKey']=_0x536710;const {config:_0x4b63ca,name:_0x4a1789}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x4b63ca['apiKey'],_0x4a1789),this['fullPersistenceKey']=sn('persistence',_0x4b63ca['apiKey'],_0x4a1789),this['boundEventHandler']=_0x30f4e6['_onStorageEvent']['bind'](_0x30f4e6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x36cd7f){return this['persistence']['_set'](this['fullUserKey'],_0x36cd7f['toJSON']());}async['getCurrentUser'](){const _0x51c03b=await this['persistence']['_get'](this['fullUserKey']);if(!_0x51c03b)return null;if(typeof _0x51c03b=='string'){const _0x54031a=await Sn(this['auth'],{'idToken':_0x51c03b})['catch'](()=>{});return _0x54031a?z['_fromGetAccountInfoResponse'](this['auth'],_0x54031a,_0x51c03b):null;}return z['_fromJSON'](this['auth'],_0x51c03b);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x23efca){if(this['persistence']===_0x23efca)return;const _0x44debb=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x23efca,_0x44debb)return this['setCurrentUser'](_0x44debb);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5924c0,_0x3b6621,_0x1785a4='authUser'){if(!_0x3b6621['length'])return new Xe(ne(wr),_0x5924c0,_0x1785a4);const _0x5de493=(await Promise['all'](_0x3b6621['map'](async _0x26f7d2=>{if(await _0x26f7d2['_isAvailable']())return _0x26f7d2;})))['filter'](_0xdccf69=>_0xdccf69);let _0x372761=_0x5de493[0x0]||ne(wr);const _0x2ef5b8=sn(_0x1785a4,_0x5924c0['config']['apiKey'],_0x5924c0['name']);let _0x50bbd7=null;for(const _0x2fa227 of _0x3b6621)try{const _0x1fc148=await _0x2fa227['_get'](_0x2ef5b8);if(_0x1fc148){let _0x48ebe3;if(typeof _0x1fc148=='string'){const _0x2f235c=await Sn(_0x5924c0,{'idToken':_0x1fc148})['catch'](()=>{});if(!_0x2f235c)break;_0x48ebe3=await z['_fromGetAccountInfoResponse'](_0x5924c0,_0x2f235c,_0x1fc148);}else _0x48ebe3=z['_fromJSON'](_0x5924c0,_0x1fc148);_0x2fa227!==_0x372761&&(_0x50bbd7=_0x48ebe3),_0x372761=_0x2fa227;break;}}catch{}const _0x23bbcc=_0x5de493['filter'](_0x156bff=>_0x156bff['_shouldAllowMigration']);return!_0x372761['_shouldAllowMigration']||!_0x23bbcc['length']?new Xe(_0x372761,_0x5924c0,_0x1785a4):(_0x372761=_0x23bbcc[0x0],_0x50bbd7&&await _0x372761['_set'](_0x2ef5b8,_0x50bbd7['toJSON']()),await Promise['all'](_0x3b6621['map'](async _0x42c8bc=>{if(_0x42c8bc!==_0x372761)try{await _0x42c8bc['_remove'](_0x2ef5b8);}catch{}})),new Xe(_0x372761,_0x5924c0,_0x1785a4));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x343186){const _0x3ebd9a=_0x343186['toLowerCase']();if(_0x3ebd9a['includes']('opera/')||_0x3ebd9a['includes']('opr/')||_0x3ebd9a['includes']('opios/'))return'Opera';if(Ra(_0x3ebd9a))return'IEMobile';if(_0x3ebd9a['includes']('msie')||_0x3ebd9a['includes']('trident/'))return'IE';if(_0x3ebd9a['includes']('edge/'))return'Edge';if(Ta(_0x3ebd9a))return'Firefox';if(_0x3ebd9a['includes']('silk/'))return'Silk';if(ka(_0x3ebd9a))return'Blackberry';if(Na(_0x3ebd9a))return'Webos';if(Sa(_0x3ebd9a))return'Safari';if((_0x3ebd9a['includes']('chrome/')||ba(_0x3ebd9a))&&!_0x3ebd9a['includes']('edge/'))return'Chrome';if(Aa(_0x3ebd9a))return'Android';{const _0x3488aa=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x46d9ec=_0x343186['match'](_0x3488aa);if((_0x46d9ec==null?void 0x0:_0x46d9ec['length'])===0x2)return _0x46d9ec[0x1];}return'Other';}function Ta(_0x2381e3=W()){return/firefox\//i['test'](_0x2381e3);}function Sa(_0x7135dd=W()){const _0x23c9b8=_0x7135dd['toLowerCase']();return _0x23c9b8['includes']('safari/')&&!_0x23c9b8['includes']('chrome/')&&!_0x23c9b8['includes']('crios/')&&!_0x23c9b8['includes']('android');}function ba(_0x2ae77f=W()){return/crios\//i['test'](_0x2ae77f);}function Ra(_0x387c78=W()){return/iemobile/i['test'](_0x387c78);}function Aa(_0x3b8073=W()){return/android/i['test'](_0x3b8073);}function ka(_0x346ea0=W()){return/blackberry/i['test'](_0x346ea0);}function Na(_0x305152=W()){return/webos/i['test'](_0x305152);}function Cs(_0x20c472=W()){return/iphone|ipad|ipod/i['test'](_0x20c472)||/macintosh/i['test'](_0x20c472)&&/mobile/i['test'](_0x20c472);}function Ef(_0x115ed0=W()){var _0x252207;return Cs(_0x115ed0)&&!!((_0x252207=window['navigator'])!=null&&_0x252207['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x423ec3=W()){return Cs(_0x423ec3)||Aa(_0x423ec3)||Na(_0x423ec3)||ka(_0x423ec3)||/windows phone/i['test'](_0x423ec3)||Ra(_0x423ec3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x5577cc,_0x4ef75d=[]){let _0x4f5cf6;switch(_0x5577cc){case'Browser':_0x4f5cf6=Cr(W());break;case'Worker':_0x4f5cf6=Cr(W())+'-'+_0x5577cc;break;default:_0x4f5cf6=_0x5577cc;}const _0x414bfc=_0x4ef75d['length']?_0x4ef75d['join'](','):'FirebaseCore-web';return _0x4f5cf6+'/JsCore/'+ct+'/'+_0x414bfc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4a4e0b){this['auth']=_0x4a4e0b,this['queue']=[];}['pushCallback'](_0x2a0d9f,_0x4c6a77){const _0x46124c=_0x5b9406=>new Promise((_0x428f65,_0x2ad0b6)=>{try{const _0x596fe9=_0x2a0d9f(_0x5b9406);_0x428f65(_0x596fe9);}catch(_0x3e8c63){_0x2ad0b6(_0x3e8c63);}});_0x46124c['onAbort']=_0x4c6a77,this['queue']['push'](_0x46124c);const _0x3cfe3c=this['queue']['length']-0x1;return()=>{this['queue'][_0x3cfe3c]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2fe88e){if(this['auth']['currentUser']===_0x2fe88e)return;const _0x26b7b3=[];try{for(const _0x320935 of this['queue'])await _0x320935(_0x2fe88e),_0x320935['onAbort']&&_0x26b7b3['push'](_0x320935['onAbort']);}catch(_0xabd9d9){_0x26b7b3['reverse']();for(const _0x41266a of _0x26b7b3)try{_0x41266a();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xabd9d9==null?void 0x0:_0xabd9d9['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5d04c9,_0x30075c={}){return Ae(_0x5d04c9,'GET','/v2/passwordPolicy',Re(_0x5d04c9,_0x30075c));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x23c3ac){var _0x8bc946;const _0x46ae1d=_0x23c3ac['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x46ae1d['minPasswordLength']??Tf,_0x46ae1d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x46ae1d['maxPasswordLength']),_0x46ae1d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x46ae1d['containsLowercaseCharacter']),_0x46ae1d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x46ae1d['containsUppercaseCharacter']),_0x46ae1d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x46ae1d['containsNumericCharacter']),_0x46ae1d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x46ae1d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x23c3ac['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x8bc946=_0x23c3ac['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x8bc946['join'](''))??'',this['forceUpgradeOnSignin']=_0x23c3ac['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x23c3ac['schemaVersion'];}['validatePassword'](_0x5d64f7){const _0x382d55={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5d64f7,_0x382d55),this['validatePasswordCharacterOptions'](_0x5d64f7,_0x382d55),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['meetsMinPasswordLength']??!0x0),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['meetsMaxPasswordLength']??!0x0),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['containsLowercaseLetter']??!0x0),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['containsUppercaseLetter']??!0x0),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['containsNumericCharacter']??!0x0),_0x382d55['isValid']&&(_0x382d55['isValid']=_0x382d55['containsNonAlphanumericCharacter']??!0x0),_0x382d55;}['validatePasswordLengthOptions'](_0x2e2be1,_0x46b495){const _0x14e67d=this['customStrengthOptions']['minPasswordLength'],_0x6b51c8=this['customStrengthOptions']['maxPasswordLength'];_0x14e67d&&(_0x46b495['meetsMinPasswordLength']=_0x2e2be1['length']>=_0x14e67d),_0x6b51c8&&(_0x46b495['meetsMaxPasswordLength']=_0x2e2be1['length']<=_0x6b51c8);}['validatePasswordCharacterOptions'](_0x2cb8dd,_0x441d6e){this['updatePasswordCharacterOptionsStatuses'](_0x441d6e,!0x1,!0x1,!0x1,!0x1);let _0x470c19;for(let _0x2b952b=0x0;_0x2b952b<_0x2cb8dd['length'];_0x2b952b++)_0x470c19=_0x2cb8dd['charAt'](_0x2b952b),this['updatePasswordCharacterOptionsStatuses'](_0x441d6e,_0x470c19>='a'&&_0x470c19<='z',_0x470c19>='A'&&_0x470c19<='Z',_0x470c19>='0'&&_0x470c19<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x470c19));}['updatePasswordCharacterOptionsStatuses'](_0x2e5dbe,_0x3ea5dd,_0x1c8993,_0x1c484b,_0x306a50){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2e5dbe['containsLowercaseLetter']||(_0x2e5dbe['containsLowercaseLetter']=_0x3ea5dd)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2e5dbe['containsUppercaseLetter']||(_0x2e5dbe['containsUppercaseLetter']=_0x1c8993)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2e5dbe['containsNumericCharacter']||(_0x2e5dbe['containsNumericCharacter']=_0x1c484b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2e5dbe['containsNonAlphanumericCharacter']||(_0x2e5dbe['containsNonAlphanumericCharacter']=_0x306a50));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x5d8f6a,_0x34c416,_0x2dc692,_0x344e30){this['app']=_0x5d8f6a,this['heartbeatServiceProvider']=_0x34c416,this['appCheckServiceProvider']=_0x2dc692,this['config']=_0x344e30,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5d8f6a['name'],this['clientVersion']=_0x344e30['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xb5b37c=>this['_resolvePersistenceManagerAvailable']=_0xb5b37c);}['_initializeWithPersistence'](_0x23466b,_0x355662){return _0x355662&&(this['_popupRedirectResolver']=ne(_0x355662)),this['_initializationPromise']=this['queue'](async()=>{var _0x78e8ee,_0x590d03,_0x14da1c;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x23466b),(_0x78e8ee=this['_resolvePersistenceManagerAvailable'])==null||_0x78e8ee['call'](this),!this['_deleted'])){if((_0x590d03=this['_popupRedirectResolver'])!=null&&_0x590d03['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x355662),this['lastNotifiedUid']=((_0x14da1c=this['currentUser'])==null?void 0x0:_0x14da1c['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x46c5c3=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x46c5c3)){if(this['currentUser']&&_0x46c5c3&&this['currentUser']['uid']===_0x46c5c3['uid']){this['_currentUser']['_assign'](_0x46c5c3),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x46c5c3,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x34f574){try{const _0xc886fc=await Sn(this,{'idToken':_0x34f574}),_0x2954c1=await z['_fromGetAccountInfoResponse'](this,_0xc886fc,_0x34f574);await this['directlySetCurrentUser'](_0x2954c1);}catch(_0x450bff){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x450bff),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x868b57){var _0x56296e;if(H(this['app'])){const _0xfba46a=this['app']['settings']['authIdToken'];return _0xfba46a?new Promise(_0x4b500c=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xfba46a)['then'](_0x4b500c,_0x4b500c));}):this['directlySetCurrentUser'](null);}const _0x4cc459=await this['assertedPersistence']['getCurrentUser']();let _0x4c088b=_0x4cc459,_0x6f5a46=!0x1;if(_0x868b57&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1f2c96=(_0x56296e=this['redirectUser'])==null?void 0x0:_0x56296e['_redirectEventId'],_0x13e1bd=_0x4c088b==null?void 0x0:_0x4c088b['_redirectEventId'],_0x5efb78=await this['tryRedirectSignIn'](_0x868b57);(!_0x1f2c96||_0x1f2c96===_0x13e1bd)&&(_0x5efb78!=null&&_0x5efb78['user'])&&(_0x4c088b=_0x5efb78['user'],_0x6f5a46=!0x0);}if(!_0x4c088b)return this['directlySetCurrentUser'](null);if(!_0x4c088b['_redirectEventId']){if(_0x6f5a46)try{await this['beforeStateQueue']['runMiddleware'](_0x4c088b);}catch(_0x1098ce){_0x4c088b=_0x4cc459,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1098ce));}return _0x4c088b?this['reloadAndSetCurrentUserOrClear'](_0x4c088b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4c088b['_redirectEventId']?this['directlySetCurrentUser'](_0x4c088b):this['reloadAndSetCurrentUserOrClear'](_0x4c088b);}async['tryRedirectSignIn'](_0x5b9a09){let _0x4bccb5=null;try{_0x4bccb5=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5b9a09,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4bccb5;}async['reloadAndSetCurrentUserOrClear'](_0x52aabe){try{await bn(_0x52aabe);}catch(_0x3aeb41){if((_0x3aeb41==null?void 0x0:_0x3aeb41['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x52aabe);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x315998){if(H(this['app']))return Promise['reject'](se(this));const _0x336156=_0x315998?k(_0x315998):null;return _0x336156&&m(_0x336156['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x336156&&_0x336156['_clone'](this));}async['_updateCurrentUser'](_0x355a4a,_0x24b314=!0x1){if(!this['_deleted'])return _0x355a4a&&m(this['tenantId']===_0x355a4a['tenantId'],this,'tenant-id-mismatch'),_0x24b314||await this['beforeStateQueue']['runMiddleware'](_0x355a4a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x355a4a),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x349e23){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x349e23));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1c0315){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3da36d=this['_getPasswordPolicyInternal']();return _0x3da36d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3da36d['validatePassword'](_0x1c0315);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x59659f=await Cf(this),_0x335e49=new Sf(_0x59659f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x335e49:this['_tenantPasswordPolicies'][this['tenantId']]=_0x335e49;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x112d61){this['_errorFactory']=new Ut('auth','Firebase',_0x112d61());}['onAuthStateChanged'](_0x542cea,_0x204859,_0x242ab0){return this['registerStateListener'](this['authStateSubscription'],_0x542cea,_0x204859,_0x242ab0);}['beforeAuthStateChanged'](_0x3a6bf3,_0x3d9039){return this['beforeStateQueue']['pushCallback'](_0x3a6bf3,_0x3d9039);}['onIdTokenChanged'](_0x1c0a24,_0x19be87,_0x5b3a2a){return this['registerStateListener'](this['idTokenSubscription'],_0x1c0a24,_0x19be87,_0x5b3a2a);}['authStateReady'](){return new Promise((_0x10b205,_0x131dff)=>{if(this['currentUser'])_0x10b205();else{const _0x3ef968=this['onAuthStateChanged'](()=>{_0x3ef968(),_0x10b205();},_0x131dff);}});}async['revokeAccessToken'](_0x3f2166){if(this['currentUser']){const _0x5d17d8=await this['currentUser']['getIdToken'](),_0x389b14={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3f2166,'idToken':_0x5d17d8};this['tenantId']!=null&&(_0x389b14['tenantId']=this['tenantId']),await vf(this,_0x389b14);}}['toJSON'](){var _0x43c610;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x43c610=this['_currentUser'])==null?void 0x0:_0x43c610['toJSON']()};}async['_setRedirectUser'](_0x1bb08b,_0xe82680){const _0x4b14ca=await this['getOrInitRedirectPersistenceManager'](_0xe82680);return _0x1bb08b===null?_0x4b14ca['removeCurrentUser']():_0x4b14ca['setCurrentUser'](_0x1bb08b);}async['getOrInitRedirectPersistenceManager'](_0x3070d6){if(!this['redirectPersistenceManager']){const _0x4cef0b=_0x3070d6&&ne(_0x3070d6)||this['_popupRedirectResolver'];m(_0x4cef0b,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4cef0b['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1442de){var _0x5d29f4,_0x34b174;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5d29f4=this['_currentUser'])==null?void 0x0:_0x5d29f4['_redirectEventId'])===_0x1442de?this['_currentUser']:((_0x34b174=this['redirectUser'])==null?void 0x0:_0x34b174['_redirectEventId'])===_0x1442de?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x216b4e){if(_0x216b4e===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x216b4e));}['_notifyListenersIfCurrent'](_0x1d18ab){_0x1d18ab===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x484356;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4c806d=((_0x484356=this['currentUser'])==null?void 0x0:_0x484356['uid'])??null;this['lastNotifiedUid']!==_0x4c806d&&(this['lastNotifiedUid']=_0x4c806d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1acffb,_0x2eb98a,_0x2bcbcb,_0xec8cdd){if(this['_deleted'])return()=>{};const _0x25acf1=typeof _0x2eb98a=='function'?_0x2eb98a:_0x2eb98a['next']['bind'](_0x2eb98a);let _0x5a85ea=!0x1;const _0xc96df0=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xc96df0,this,'internal-error'),_0xc96df0['then'](()=>{_0x5a85ea||_0x25acf1(this['currentUser']);}),typeof _0x2eb98a=='function'){const _0x327ebd=_0x1acffb['addObserver'](_0x2eb98a,_0x2bcbcb,_0xec8cdd);return()=>{_0x5a85ea=!0x0,_0x327ebd();};}else{const _0x7f28f=_0x1acffb['addObserver'](_0x2eb98a);return()=>{_0x5a85ea=!0x0,_0x7f28f();};}}async['directlySetCurrentUser'](_0x185156){this['currentUser']&&this['currentUser']!==_0x185156&&this['_currentUser']['_stopProactiveRefresh'](),_0x185156&&this['isProactiveRefreshEnabled']&&_0x185156['_startProactiveRefresh'](),this['currentUser']=_0x185156,_0x185156?await this['assertedPersistence']['setCurrentUser'](_0x185156):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1f28cb){return this['operations']=this['operations']['then'](_0x1f28cb,_0x1f28cb),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1dcf91){!_0x1dcf91||this['frameworks']['includes'](_0x1dcf91)||(this['frameworks']['push'](_0x1dcf91),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4a944c;const _0x20c00a={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x20c00a['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1a4e53=await((_0x4a944c=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4a944c['getHeartbeatsHeader']());_0x1a4e53&&(_0x20c00a['X-Firebase-Client']=_0x1a4e53);const _0x9cfdd=await this['_getAppCheckToken']();return _0x9cfdd&&(_0x20c00a['X-Firebase-AppCheck']=_0x9cfdd),_0x20c00a;}async['_getAppCheckToken'](){var _0x34eff4;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x17eaf8=await((_0x34eff4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x34eff4['getToken']());return _0x17eaf8!=null&&_0x17eaf8['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x17eaf8['error']),_0x17eaf8==null?void 0x0:_0x17eaf8['token'];}}function qe(_0x436069){return k(_0x436069);}class Tr{constructor(_0x15bf3a){this['auth']=_0x15bf3a,this['observer']=null,this['addObserver']=Ic(_0x3c7f2e=>this['observer']=_0x3c7f2e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x59ca4c){zn=_0x59ca4c;}function Da(_0xfe2b7a){return zn['loadJS'](_0xfe2b7a);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4ca0fa){return'__'+_0x4ca0fa+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x13e6b8){_0x13e6b8();}['execute'](_0x422672,_0x30fe6f){return Promise['resolve']('token');}['render'](_0x42e923,_0x1cd653){return'';}}class Of{['ready'](_0x2c5abe){_0x2c5abe();}['execute'](_0xc5e25,_0x1fe7d2){return Promise['resolve']('token');}['render'](_0x339128,_0x571ff6){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0xabc977){this['type']=Df,this['auth']=qe(_0xabc977);}async['verify'](_0x5a574f='verify',_0x2dd2b5=!0x1){async function _0x53d849(_0x4031a0){if(!_0x2dd2b5){if(_0x4031a0['tenantId']==null&&_0x4031a0['_agentRecaptchaConfig']!=null)return _0x4031a0['_agentRecaptchaConfig']['siteKey'];if(_0x4031a0['tenantId']!=null&&_0x4031a0['_tenantRecaptchaConfigs'][_0x4031a0['tenantId']]!==void 0x0)return _0x4031a0['_tenantRecaptchaConfigs'][_0x4031a0['tenantId']]['siteKey'];}return new Promise(async(_0x158343,_0x3bc605)=>{uf(_0x4031a0,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x23b8f8=>{if(_0x23b8f8['recaptchaKey']===void 0x0)_0x3bc605(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5ee44b=new hf(_0x23b8f8);return _0x4031a0['tenantId']==null?_0x4031a0['_agentRecaptchaConfig']=_0x5ee44b:_0x4031a0['_tenantRecaptchaConfigs'][_0x4031a0['tenantId']]=_0x5ee44b,_0x158343(_0x5ee44b['siteKey']);}})['catch'](_0x5513e0=>{_0x3bc605(_0x5513e0);});});}function _0x59376f(_0x2e6062,_0x5c842b,_0x31f01c){const _0x25770a=window['grecaptcha'];vr(_0x25770a)?_0x25770a['enterprise']['ready'](()=>{_0x25770a['enterprise']['execute'](_0x2e6062,{'action':_0x5a574f})['then'](_0x59490b=>{_0x5c842b(_0x59490b);})['catch'](()=>{_0x5c842b(Ma);});}):_0x31f01c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1382f6,_0x43d968)=>{_0x53d849(this['auth'])['then'](async _0x422375=>{if(!_0x2dd2b5&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x59376f(_0x422375,_0x1382f6,_0x43d968);else{if(typeof window>'u'){_0x43d968(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x43abae=Af();_0x43abae['length']!==0x0&&(_0x43abae+=_0x422375+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x418347;(_0x418347=le['scriptInjectionDeferred'])==null||_0x418347['resolve']();},Da(_0x43abae)['then'](()=>{var _0x3d2f85;return(_0x3d2f85=le['scriptInjectionDeferred'])==null?void 0x0:_0x3d2f85['promise'];})['then'](()=>{_0x59376f(_0x422375,_0x1382f6,_0x43d968);})['catch'](_0xe52b95=>{_0x43d968(_0xe52b95);});}})['catch'](_0x4cdaf0=>{_0x43d968(_0x4cdaf0);});});}}le['scriptInjectionDeferred']=null;async function br(_0x44bef2,_0xaeb477,_0x4c41c2,_0x572be2=!0x1,_0x5c589b=!0x1){const _0xe4c28c=new le(_0x44bef2);let _0x438f88;if(_0x5c589b)_0x438f88=Ma;else try{_0x438f88=await _0xe4c28c['verify'](_0x4c41c2);}catch{_0x438f88=await _0xe4c28c['verify'](_0x4c41c2,!0x0);}const _0x513f28={..._0xaeb477};if(_0x4c41c2==='mfaSmsEnrollment'||_0x4c41c2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x513f28){const _0x1a8627=_0x513f28['phoneEnrollmentInfo']['phoneNumber'],_0x4a6867=_0x513f28['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x513f28,{'phoneEnrollmentInfo':{'phoneNumber':_0x1a8627,'recaptchaToken':_0x4a6867,'captchaResponse':_0x438f88,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x513f28){const _0x34fb88=_0x513f28['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x513f28,{'phoneSignInInfo':{'recaptchaToken':_0x34fb88,'captchaResponse':_0x438f88,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x513f28;}return _0x572be2?Object['assign'](_0x513f28,{'captchaResp':_0x438f88}):Object['assign'](_0x513f28,{'captchaResponse':_0x438f88}),Object['assign'](_0x513f28,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x513f28,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x513f28;}async function Oi(_0x164f1a,_0x37bf7d,_0x1f757a,_0x5d8740,_0x42d8ee){var _0x3a39b2;if((_0x3a39b2=_0x164f1a['_getRecaptchaConfig']())!=null&&_0x3a39b2['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x20056e=await br(_0x164f1a,_0x37bf7d,_0x1f757a,_0x1f757a==='getOobCode');return _0x5d8740(_0x164f1a,_0x20056e);}else return _0x5d8740(_0x164f1a,_0x37bf7d)['catch'](async _0x27f680=>{if(_0x27f680['code']==='auth/missing-recaptcha-token'){console['log'](_0x1f757a+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1dfae8=await br(_0x164f1a,_0x37bf7d,_0x1f757a,_0x1f757a==='getOobCode');return _0x5d8740(_0x164f1a,_0x1dfae8);}else return Promise['reject'](_0x27f680);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0xcb5785,_0x520acb){const _0xc95c7f=Ui(_0xcb5785,'auth');if(_0xc95c7f['isInitialized']()){const _0x407100=_0xc95c7f['getImmediate'](),_0x36add3=_0xc95c7f['getOptions']();if(De(_0x36add3,_0x520acb??{}))return _0x407100;K(_0x407100,'already-initialized');}return _0xc95c7f['initialize']({'options':_0x520acb});}function Lf(_0x429de2,_0x444dbf){const _0x586ecc=(_0x444dbf==null?void 0x0:_0x444dbf['persistence'])||[],_0x2df297=(Array['isArray'](_0x586ecc)?_0x586ecc:[_0x586ecc])['map'](ne);_0x444dbf!=null&&_0x444dbf['errorMap']&&_0x429de2['_updateErrorMap'](_0x444dbf['errorMap']),_0x429de2['_initializeWithPersistence'](_0x2df297,_0x444dbf==null?void 0x0:_0x444dbf['popupRedirectResolver']);}function xf(_0x559e64,_0x4598c9,_0x2d2c33){const _0x40b4f9=qe(_0x559e64);m(/^https?:\/\//['test'](_0x4598c9),_0x40b4f9,'invalid-emulator-scheme');const _0x5d03bd=!0x1,_0x14be01=La(_0x4598c9),{host:_0x434786,port:_0x3d0707}=Ff(_0x4598c9),_0xad01e2=_0x3d0707===null?'':':'+_0x3d0707,_0x41b3ee={'url':_0x14be01+'//'+_0x434786+_0xad01e2+'/'},_0x3208eb=Object['freeze']({'host':_0x434786,'port':_0x3d0707,'protocol':_0x14be01['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5d03bd})});if(!_0x40b4f9['_canInitEmulator']){m(_0x40b4f9['config']['emulator']&&_0x40b4f9['emulatorConfig'],_0x40b4f9,'emulator-config-failed'),m(De(_0x41b3ee,_0x40b4f9['config']['emulator'])&&De(_0x3208eb,_0x40b4f9['emulatorConfig']),_0x40b4f9,'emulator-config-failed');return;}_0x40b4f9['config']['emulator']=_0x41b3ee,_0x40b4f9['emulatorConfig']=_0x3208eb,_0x40b4f9['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x434786)?jr(_0x14be01+'//'+_0x434786+_0xad01e2):Uf();}function La(_0x5ef159){const _0x10211d=_0x5ef159['indexOf'](':');return _0x10211d<0x0?'':_0x5ef159['substr'](0x0,_0x10211d+0x1);}function Ff(_0x1f3e09){const _0x9bc8e4=La(_0x1f3e09),_0x486663=/(\/\/)?([^?#/]+)/['exec'](_0x1f3e09['substr'](_0x9bc8e4['length']));if(!_0x486663)return{'host':'','port':null};const _0x3fdb46=_0x486663[0x2]['split']('@')['pop']()||'',_0x1109fe=/^(\[[^\]]+\])(:|$)/['exec'](_0x3fdb46);if(_0x1109fe){const _0x53bb60=_0x1109fe[0x1];return{'host':_0x53bb60,'port':Rr(_0x3fdb46['substr'](_0x53bb60['length']+0x1))};}else{const [_0x2dead6,_0x157496]=_0x3fdb46['split'](':');return{'host':_0x2dead6,'port':Rr(_0x157496)};}}function Rr(_0x26aaaf){if(!_0x26aaaf)return null;const _0x5799ac=Number(_0x26aaaf);return isNaN(_0x5799ac)?null:_0x5799ac;}function Uf(){function _0x108e8d(){const _0x4bef81=document['createElement']('p'),_0x59b446=_0x4bef81['style'];_0x4bef81['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x59b446['position']='fixed',_0x59b446['width']='100%',_0x59b446['backgroundColor']='#ffffff',_0x59b446['border']='.1em\x20solid\x20#000000',_0x59b446['color']='#b50000',_0x59b446['bottom']='0px',_0x59b446['left']='0px',_0x59b446['margin']='0px',_0x59b446['zIndex']='10000',_0x59b446['textAlign']='center',_0x4bef81['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4bef81);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x108e8d):_0x108e8d());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1c6718,_0x45dfc0){this['providerId']=_0x1c6718,this['signInMethod']=_0x45dfc0;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x11c687){return te('not\x20implemented');}['_linkToIdToken'](_0x583e3e,_0x2bba20){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x120144){return te('not\x20implemented');}}async function Wf(_0x326eb5,_0x5a2309){return Ae(_0x326eb5,'POST','/v1/accounts:signUp',_0x5a2309);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0xa73d79,_0xc1d69b){return Yt(_0xa73d79,'POST','/v1/accounts:signInWithPassword',Re(_0xa73d79,_0xc1d69b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x113a4f,_0x4cbd7b){return Yt(_0x113a4f,'POST','/v1/accounts:signInWithEmailLink',Re(_0x113a4f,_0x4cbd7b));}async function Hf(_0x1956ec,_0x4af721){return Yt(_0x1956ec,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1956ec,_0x4af721));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x592839,_0x460b92,_0x4aadd9,_0x4cd158=null){super('password',_0x4aadd9),this['_email']=_0x592839,this['_password']=_0x460b92,this['_tenantId']=_0x4cd158;}static['_fromEmailAndPassword'](_0x263d87,_0x541f25){return new Ft(_0x263d87,_0x541f25,'password');}static['_fromEmailAndCode'](_0xf66007,_0x427938,_0x2fa520=null){return new Ft(_0xf66007,_0x427938,'emailLink',_0x2fa520);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x36e032){const _0x3ff842=typeof _0x36e032=='string'?JSON['parse'](_0x36e032):_0x36e032;if(_0x3ff842!=null&&_0x3ff842['email']&&(_0x3ff842!=null&&_0x3ff842['password'])){if(_0x3ff842['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3ff842['email'],_0x3ff842['password']);if(_0x3ff842['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3ff842['email'],_0x3ff842['password'],_0x3ff842['tenantId']);}return null;}async['_getIdTokenResponse'](_0x56f7cc){switch(this['signInMethod']){case'password':const _0x40d2a0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x56f7cc,_0x40d2a0,'signInWithPassword',Bf);case'emailLink':return Vf(_0x56f7cc,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x56f7cc,'internal-error');}}async['_linkToIdToken'](_0x5bd29d,_0x145cbb){switch(this['signInMethod']){case'password':const _0x4302de={'idToken':_0x145cbb,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5bd29d,_0x4302de,'signUpPassword',Wf);case'emailLink':return Hf(_0x5bd29d,{'idToken':_0x145cbb,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5bd29d,'internal-error');}}['_getReauthenticationResolver'](_0x1e4a65){return this['_getIdTokenResponse'](_0x1e4a65);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x246a91,_0xdabc13){return Yt(_0x246a91,'POST','/v1/accounts:signInWithIdp',Re(_0x246a91,_0xdabc13));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x537c85){const _0x5a772c=new We(_0x537c85['providerId'],_0x537c85['signInMethod']);return _0x537c85['idToken']||_0x537c85['accessToken']?(_0x537c85['idToken']&&(_0x5a772c['idToken']=_0x537c85['idToken']),_0x537c85['accessToken']&&(_0x5a772c['accessToken']=_0x537c85['accessToken']),_0x537c85['nonce']&&!_0x537c85['pendingToken']&&(_0x5a772c['nonce']=_0x537c85['nonce']),_0x537c85['pendingToken']&&(_0x5a772c['pendingToken']=_0x537c85['pendingToken'])):_0x537c85['oauthToken']&&_0x537c85['oauthTokenSecret']?(_0x5a772c['accessToken']=_0x537c85['oauthToken'],_0x5a772c['secret']=_0x537c85['oauthTokenSecret']):K('argument-error'),_0x5a772c;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x35abb9){const _0x138f81=typeof _0x35abb9=='string'?JSON['parse'](_0x35abb9):_0x35abb9,{providerId:_0x163a25,signInMethod:_0x112af4,..._0x4b8a93}=_0x138f81;if(!_0x163a25||!_0x112af4)return null;const _0x258156=new We(_0x163a25,_0x112af4);return _0x258156['idToken']=_0x4b8a93['idToken']||void 0x0,_0x258156['accessToken']=_0x4b8a93['accessToken']||void 0x0,_0x258156['secret']=_0x4b8a93['secret'],_0x258156['nonce']=_0x4b8a93['nonce'],_0x258156['pendingToken']=_0x4b8a93['pendingToken']||null,_0x258156;}['_getIdTokenResponse'](_0x49c8e4){const _0x186dd9=this['buildRequest']();return Ze(_0x49c8e4,_0x186dd9);}['_linkToIdToken'](_0x5e8098,_0xbe1df4){const _0x42abf6=this['buildRequest']();return _0x42abf6['idToken']=_0xbe1df4,Ze(_0x5e8098,_0x42abf6);}['_getReauthenticationResolver'](_0x1d420b){const _0x28b125=this['buildRequest']();return _0x28b125['autoCreate']=!0x1,Ze(_0x1d420b,_0x28b125);}['buildRequest'](){const _0x22304e={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x22304e['pendingToken']=this['pendingToken'];else{const _0x5c9c4e={};this['idToken']&&(_0x5c9c4e['id_token']=this['idToken']),this['accessToken']&&(_0x5c9c4e['access_token']=this['accessToken']),this['secret']&&(_0x5c9c4e['oauth_token_secret']=this['secret']),_0x5c9c4e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5c9c4e['nonce']=this['nonce']),_0x22304e['postBody']=at(_0x5c9c4e);}return _0x22304e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0xb922ce){switch(_0xb922ce){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x19f1c4){const _0x10b9d7=yt(vt(_0x19f1c4))['link'],_0x36fc7f=_0x10b9d7?yt(vt(_0x10b9d7))['deep_link_id']:null,_0x14386d=yt(vt(_0x19f1c4))['deep_link_id'];return(_0x14386d?yt(vt(_0x14386d))['link']:null)||_0x14386d||_0x36fc7f||_0x10b9d7||_0x19f1c4;}class Ss{constructor(_0x15274f){const _0x2835ea=yt(vt(_0x15274f)),_0x2ab2b0=_0x2835ea['apiKey']??null,_0x1f894c=_0x2835ea['oobCode']??null,_0x20f3cf=Gf(_0x2835ea['mode']??null);m(_0x2ab2b0&&_0x1f894c&&_0x20f3cf,'argument-error'),this['apiKey']=_0x2ab2b0,this['operation']=_0x20f3cf,this['code']=_0x1f894c,this['continueUrl']=_0x2835ea['continueUrl']??null,this['languageCode']=_0x2835ea['lang']??null,this['tenantId']=_0x2835ea['tenantId']??null;}static['parseLink'](_0x93f670){const _0x5dddd7=qf(_0x93f670);try{return new Ss(_0x5dddd7);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x45e82a,_0x577330){return Ft['_fromEmailAndPassword'](_0x45e82a,_0x577330);}static['credentialWithLink'](_0x2afa76,_0x4e8ccb){const _0x4fa345=Ss['parseLink'](_0x4e8ccb);return m(_0x4fa345,'argument-error'),Ft['_fromEmailAndCode'](_0x2afa76,_0x4fa345['code'],_0x4fa345['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x1148f0){this['providerId']=_0x1148f0,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4b14b9){this['defaultLanguageCode']=_0x4b14b9;}['setCustomParameters'](_0x3b75f9){return this['customParameters']=_0x3b75f9,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2e97ab){return this['scopes']['includes'](_0x2e97ab)||this['scopes']['push'](_0x2e97ab),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x1d3a24){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1d3a24});}static['credentialFromResult'](_0x44b97d){return he['credentialFromTaggedObject'](_0x44b97d);}static['credentialFromError'](_0x295046){return he['credentialFromTaggedObject'](_0x295046['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xc5b392}){if(!_0xc5b392||!('oauthAccessToken'in _0xc5b392)||!_0xc5b392['oauthAccessToken'])return null;try{return he['credential'](_0xc5b392['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2d46af,_0x3c01b9){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2d46af,'accessToken':_0x3c01b9});}static['credentialFromResult'](_0x482a5e){return ue['credentialFromTaggedObject'](_0x482a5e);}static['credentialFromError'](_0x25e831){return ue['credentialFromTaggedObject'](_0x25e831['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4ccbd9}){if(!_0x4ccbd9)return null;const {oauthIdToken:_0x4e27bc,oauthAccessToken:_0x4ed4e7}=_0x4ccbd9;if(!_0x4e27bc&&!_0x4ed4e7)return null;try{return ue['credential'](_0x4e27bc,_0x4ed4e7);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x36dcb3){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x36dcb3});}static['credentialFromResult'](_0x195f81){return de['credentialFromTaggedObject'](_0x195f81);}static['credentialFromError'](_0x2d3671){return de['credentialFromTaggedObject'](_0x2d3671['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x33ffcb}){if(!_0x33ffcb||!('oauthAccessToken'in _0x33ffcb)||!_0x33ffcb['oauthAccessToken'])return null;try{return de['credential'](_0x33ffcb['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x5e6eae,_0x429cd2){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5e6eae,'oauthTokenSecret':_0x429cd2});}static['credentialFromResult'](_0x435706){return fe['credentialFromTaggedObject'](_0x435706);}static['credentialFromError'](_0x3c7df6){return fe['credentialFromTaggedObject'](_0x3c7df6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x70427}){if(!_0x70427)return null;const {oauthAccessToken:_0x1637f0,oauthTokenSecret:_0x49d431}=_0x70427;if(!_0x1637f0||!_0x49d431)return null;try{return fe['credential'](_0x1637f0,_0x49d431);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x289a6c,_0x212bba){return Yt(_0x289a6c,'POST','/v1/accounts:signUp',Re(_0x289a6c,_0x212bba));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x343ea0){this['user']=_0x343ea0['user'],this['providerId']=_0x343ea0['providerId'],this['_tokenResponse']=_0x343ea0['_tokenResponse'],this['operationType']=_0x343ea0['operationType'];}static async['_fromIdTokenResponse'](_0x15da0e,_0x7c584f,_0x469f66,_0x54f4a5=!0x1){const _0x12f5bc=await z['_fromIdTokenResponse'](_0x15da0e,_0x469f66,_0x54f4a5),_0x29b5e3=Ar(_0x469f66);return new Be({'user':_0x12f5bc,'providerId':_0x29b5e3,'_tokenResponse':_0x469f66,'operationType':_0x7c584f});}static async['_forOperation'](_0x3112ce,_0x456fc0,_0x1a40a6){await _0x3112ce['_updateTokensIfNecessary'](_0x1a40a6,!0x0);const _0x525fb3=Ar(_0x1a40a6);return new Be({'user':_0x3112ce,'providerId':_0x525fb3,'_tokenResponse':_0x1a40a6,'operationType':_0x456fc0});}}function Ar(_0xfe0a48){return _0xfe0a48['providerId']?_0xfe0a48['providerId']:'phoneNumber'in _0xfe0a48?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x4870ce,_0x3660ed,_0x42b8d1,_0x1f9baa){super(_0x3660ed['code'],_0x3660ed['message']),this['operationType']=_0x42b8d1,this['user']=_0x1f9baa,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x4870ce['name'],'tenantId':_0x4870ce['tenantId']??void 0x0,'_serverResponse':_0x3660ed['customData']['_serverResponse'],'operationType':_0x42b8d1};}static['_fromErrorAndOperation'](_0x64025d,_0x416f2b,_0x1dc173,_0x2d3018){return new Rn(_0x64025d,_0x416f2b,_0x1dc173,_0x2d3018);}}function Fa(_0x3ec4a4,_0x36636d,_0x34ea55,_0x49b6ef){return(_0x36636d==='reauthenticate'?_0x34ea55['_getReauthenticationResolver'](_0x3ec4a4):_0x34ea55['_getIdTokenResponse'](_0x3ec4a4))['catch'](_0x118095=>{throw _0x118095['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3ec4a4,_0x118095,_0x36636d,_0x49b6ef):_0x118095;});}async function jf(_0x592736,_0x2a33c1,_0x50a0a2=!0x1){const _0x39032b=await xt(_0x592736,_0x2a33c1['_linkToIdToken'](_0x592736['auth'],await _0x592736['getIdToken']()),_0x50a0a2);return Be['_forOperation'](_0x592736,'link',_0x39032b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5692b3,_0x9c30aa,_0x325d0b=!0x1){const {auth:_0x1739d1}=_0x5692b3;if(H(_0x1739d1['app']))return Promise['reject'](se(_0x1739d1));const _0x3b829a='reauthenticate';try{const _0x318399=await xt(_0x5692b3,Fa(_0x1739d1,_0x3b829a,_0x9c30aa,_0x5692b3),_0x325d0b);m(_0x318399['idToken'],_0x1739d1,'internal-error');const _0x22b6c9=ws(_0x318399['idToken']);m(_0x22b6c9,_0x1739d1,'internal-error');const {sub:_0x453305}=_0x22b6c9;return m(_0x5692b3['uid']===_0x453305,_0x1739d1,'user-mismatch'),Be['_forOperation'](_0x5692b3,_0x3b829a,_0x318399);}catch(_0x4de774){throw(_0x4de774==null?void 0x0:_0x4de774['code'])==='auth/user-not-found'&&K(_0x1739d1,'user-mismatch'),_0x4de774;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x1d8ca1,_0xcc7066,_0x36f92f=!0x1){if(H(_0x1d8ca1['app']))return Promise['reject'](se(_0x1d8ca1));const _0x11e499='signIn',_0x3beddb=await Fa(_0x1d8ca1,_0x11e499,_0xcc7066),_0x298ede=await Be['_fromIdTokenResponse'](_0x1d8ca1,_0x11e499,_0x3beddb);return _0x36f92f||await _0x1d8ca1['_updateCurrentUser'](_0x298ede['user']),_0x298ede;}async function Yf(_0x355316,_0x10f763){return Ua(qe(_0x355316),_0x10f763);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x4456e1){const _0x285076=qe(_0x4456e1);_0x285076['_getPasswordPolicyInternal']()&&await _0x285076['_updatePasswordPolicy']();}async function R_(_0x322e46,_0x1ceb7c,_0x5299c6){if(H(_0x322e46['app']))return Promise['reject'](se(_0x322e46));const _0x5d280c=qe(_0x322e46),_0x15be12=await Oi(_0x5d280c,{'returnSecureToken':!0x0,'email':_0x1ceb7c,'password':_0x5299c6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x5d83f6=>{throw _0x5d83f6['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x322e46),_0x5d83f6;}),_0xffc1f1=await Be['_fromIdTokenResponse'](_0x5d280c,'signIn',_0x15be12);return await _0x5d280c['_updateCurrentUser'](_0xffc1f1['user']),_0xffc1f1;}function A_(_0x5bbbdc,_0x1c7a1e,_0xe6f681){return H(_0x5bbbdc['app'])?Promise['reject'](se(_0x5bbbdc)):Yf(k(_0x5bbbdc),ft['credential'](_0x1c7a1e,_0xe6f681))['catch'](async _0x207657=>{throw _0x207657['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5bbbdc),_0x207657;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x588688,_0x3f3111){return k(_0x588688)['setPersistence'](_0x3f3111);}function Qf(_0x4b778a,_0x2c30a9,_0xb6b3be,_0x5345d5){return k(_0x4b778a)['onIdTokenChanged'](_0x2c30a9,_0xb6b3be,_0x5345d5);}function Jf(_0x311eb6,_0x52881e,_0x59e580){return k(_0x311eb6)['beforeAuthStateChanged'](_0x52881e,_0x59e580);}function N_(_0xebe450,_0x266f54,_0x577a36,_0x308cde){return k(_0xebe450)['onAuthStateChanged'](_0x266f54,_0x577a36,_0x308cde);}function P_(_0x3c3dbe){return k(_0x3c3dbe)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x44198b,_0xc7532){this['storageRetriever']=_0x44198b,this['type']=_0xc7532;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x23f856,_0x1e01f1){return this['storage']['setItem'](_0x23f856,JSON['stringify'](_0x1e01f1)),Promise['resolve']();}['_get'](_0x2fa465){const _0x9b4be6=this['storage']['getItem'](_0x2fa465);return Promise['resolve'](_0x9b4be6?JSON['parse'](_0x9b4be6):null);}['_remove'](_0xc00ab9){return this['storage']['removeItem'](_0xc00ab9),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x28bcd6,_0x5ab72b)=>this['onStorageEvent'](_0x28bcd6,_0x5ab72b),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x587154){for(const _0x2b749b of Object['keys'](this['listeners'])){const _0x592fc6=this['storage']['getItem'](_0x2b749b),_0x268958=this['localCache'][_0x2b749b];_0x592fc6!==_0x268958&&_0x587154(_0x2b749b,_0x268958,_0x592fc6);}}['onStorageEvent'](_0x2cd3e3,_0x1869e4=!0x1){if(!_0x2cd3e3['key']){this['forAllChangedKeys']((_0xa1e599,_0x3f16e2,_0x32f818)=>{this['notifyListeners'](_0xa1e599,_0x32f818);});return;}const _0x1c7817=_0x2cd3e3['key'];_0x1869e4?this['detachListener']():this['stopPolling']();const _0x4572cd=()=>{const _0x171334=this['storage']['getItem'](_0x1c7817);!_0x1869e4&&this['localCache'][_0x1c7817]===_0x171334||this['notifyListeners'](_0x1c7817,_0x171334);},_0x5df21f=this['storage']['getItem'](_0x1c7817);If()&&_0x5df21f!==_0x2cd3e3['newValue']&&_0x2cd3e3['newValue']!==_0x2cd3e3['oldValue']?setTimeout(_0x4572cd,Zf):_0x4572cd();}['notifyListeners'](_0x21515d,_0x30fd90){this['localCache'][_0x21515d]=_0x30fd90;const _0x45dbf=this['listeners'][_0x21515d];if(_0x45dbf){for(const _0x2abd80 of Array['from'](_0x45dbf))_0x2abd80(_0x30fd90&&JSON['parse'](_0x30fd90));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x302eca,_0x39d5da,_0x4a0f15)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x302eca,'oldValue':_0x39d5da,'newValue':_0x4a0f15}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xe8c6ad,_0x411934){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xe8c6ad]||(this['listeners'][_0xe8c6ad]=new Set(),this['localCache'][_0xe8c6ad]=this['storage']['getItem'](_0xe8c6ad)),this['listeners'][_0xe8c6ad]['add'](_0x411934);}['_removeListener'](_0x1ba378,_0x35c386){this['listeners'][_0x1ba378]&&(this['listeners'][_0x1ba378]['delete'](_0x35c386),this['listeners'][_0x1ba378]['size']===0x0&&delete this['listeners'][_0x1ba378]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x18c3b9,_0x5bd300){await super['_set'](_0x18c3b9,_0x5bd300),this['localCache'][_0x18c3b9]=JSON['stringify'](_0x5bd300);}async['_get'](_0x441c9a){const _0xb8fd00=await super['_get'](_0x441c9a);return this['localCache'][_0x441c9a]=JSON['stringify'](_0xb8fd00),_0xb8fd00;}async['_remove'](_0x3bc67c){await super['_remove'](_0x3bc67c),delete this['localCache'][_0x3bc67c];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2527b8,_0x4b968c){}['_removeListener'](_0x2a5edf,_0x34f1bf){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x15775b){return Promise['all'](_0x15775b['map'](async _0x4c7782=>{try{return{'fulfilled':!0x0,'value':await _0x4c7782};}catch(_0x108f4e){return{'fulfilled':!0x1,'reason':_0x108f4e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1881e3){this['eventTarget']=_0x1881e3,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3f5e53){const _0x44a2c1=this['receivers']['find'](_0x1d9ee1=>_0x1d9ee1['isListeningto'](_0x3f5e53));if(_0x44a2c1)return _0x44a2c1;const _0x56adfe=new jn(_0x3f5e53);return this['receivers']['push'](_0x56adfe),_0x56adfe;}['isListeningto'](_0x4f82e4){return this['eventTarget']===_0x4f82e4;}async['handleEvent'](_0x362bf7){const _0x45c6c4=_0x362bf7,{eventId:_0x2f7520,eventType:_0xe91621,data:_0x5ac3c5}=_0x45c6c4['data'],_0x302c30=this['handlersMap'][_0xe91621];if(!(_0x302c30!=null&&_0x302c30['size']))return;_0x45c6c4['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2f7520,'eventType':_0xe91621});const _0x36caa3=Array['from'](_0x302c30)['map'](async _0xcf3383=>_0xcf3383(_0x45c6c4['origin'],_0x5ac3c5)),_0x309afc=await tp(_0x36caa3);_0x45c6c4['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2f7520,'eventType':_0xe91621,'response':_0x309afc});}['_subscribe'](_0x327611,_0x68c534){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x327611]||(this['handlersMap'][_0x327611]=new Set()),this['handlersMap'][_0x327611]['add'](_0x68c534);}['_unsubscribe'](_0x2916aa,_0x2f67dc){this['handlersMap'][_0x2916aa]&&_0x2f67dc&&this['handlersMap'][_0x2916aa]['delete'](_0x2f67dc),(!_0x2f67dc||this['handlersMap'][_0x2916aa]['size']===0x0)&&delete this['handlersMap'][_0x2916aa],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x342de7='',_0x296f4b=0xa){let _0x2d62fd='';for(let _0x54da67=0x0;_0x54da67<_0x296f4b;_0x54da67++)_0x2d62fd+=Math['floor'](Math['random']()*0xa);return _0x342de7+_0x2d62fd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x4a07bb){this['target']=_0x4a07bb,this['handlers']=new Set();}['removeMessageHandler'](_0xf3605b){_0xf3605b['messageChannel']&&(_0xf3605b['messageChannel']['port1']['removeEventListener']('message',_0xf3605b['onMessage']),_0xf3605b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xf3605b);}async['_send'](_0x5da450,_0x3e33cb,_0x3692ce=0x32){const _0x2d1553=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2d1553)throw new Error('connection_unavailable');let _0x22aa5d,_0x47381b;return new Promise((_0x58a9f4,_0xd9fb66)=>{const _0x13dde8=bs('',0x14);_0x2d1553['port1']['start']();const _0x3f813e=setTimeout(()=>{_0xd9fb66(new Error('unsupported_event'));},_0x3692ce);_0x47381b={'messageChannel':_0x2d1553,'onMessage'(_0x3af478){const _0x2b57a4=_0x3af478;if(_0x2b57a4['data']['eventId']===_0x13dde8)switch(_0x2b57a4['data']['status']){case'ack':clearTimeout(_0x3f813e),_0x22aa5d=setTimeout(()=>{_0xd9fb66(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x22aa5d),_0x58a9f4(_0x2b57a4['data']['response']);break;default:clearTimeout(_0x3f813e),clearTimeout(_0x22aa5d),_0xd9fb66(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x47381b),_0x2d1553['port1']['addEventListener']('message',_0x47381b['onMessage']),this['target']['postMessage']({'eventType':_0x5da450,'eventId':_0x13dde8,'data':_0x3e33cb},[_0x2d1553['port2']]);})['finally'](()=>{_0x47381b&&this['removeMessageHandler'](_0x47381b);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x538e48){X()['location']['href']=_0x538e48;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x8cb224;return((_0x8cb224=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x8cb224['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x1a9e8e){this['request']=_0x1a9e8e;}['toPromise'](){return new Promise((_0x53a1db,_0x3009e3)=>{this['request']['addEventListener']('success',()=>{_0x53a1db(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3009e3(this['request']['error']);});});}}function Kn(_0x3f7af3,_0x2d67d6){return _0x3f7af3['transaction']([kn],_0x2d67d6?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x431834=indexedDB['deleteDatabase'](qa);return new Jt(_0x431834)['toPromise']();}function ja(){const _0x1689e2=indexedDB['open'](qa,ap);return new Promise((_0x18ca7a,_0x2d9272)=>{_0x1689e2['addEventListener']('error',()=>{_0x2d9272(_0x1689e2['error']);}),_0x1689e2['addEventListener']('upgradeneeded',()=>{const _0x55985a=_0x1689e2['result'];try{_0x55985a['createObjectStore'](kn,{'keyPath':za});}catch(_0x27caf6){_0x2d9272(_0x27caf6);}}),_0x1689e2['addEventListener']('success',async()=>{const _0x1de23c=_0x1689e2['result'];_0x1de23c['objectStoreNames']['contains'](kn)?_0x18ca7a(_0x1de23c):(_0x1de23c['close'](),await cp(),_0x18ca7a(await ja()));});});}async function kr(_0x24bea1,_0x1079cf,_0x269f98){const _0x2d84b1=Kn(_0x24bea1,!0x0)['put']({[za]:_0x1079cf,'value':_0x269f98});return new Jt(_0x2d84b1)['toPromise']();}async function lp(_0x3d0db4,_0xc1b663){const _0x3abf73=Kn(_0x3d0db4,!0x1)['get'](_0xc1b663),_0x23e101=await new Jt(_0x3abf73)['toPromise']();return _0x23e101===void 0x0?null:_0x23e101['value'];}function Nr(_0x44dd7c,_0x1d8e79){const _0x23f039=Kn(_0x44dd7c,!0x0)['delete'](_0x1d8e79);return new Jt(_0x23f039)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3ccc1d){let _0x5daaca=0x0;for(;;)try{const _0x50979e=await this['_openDb']();return await _0x3ccc1d(_0x50979e);}catch(_0x31b016){if(_0x5daaca++>up)throw _0x31b016;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x572443,_0x10c5a8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x10c5a8['key'])})),this['receiver']['_subscribe']('ping',async(_0x456f43,_0x3aa491)=>['keyChanged']);}async['initializeSender'](){var _0x9d511b,_0x497370;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x3e9f38=await this['sender']['_send']('ping',{},0x320);_0x3e9f38&&(_0x9d511b=_0x3e9f38[0x0])!=null&&_0x9d511b['fulfilled']&&(_0x497370=_0x3e9f38[0x0])!=null&&_0x497370['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xa6877b){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xa6877b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xb536ad=>{await kr(_0xb536ad,An,'1'),await Nr(_0xb536ad,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x34f6ea){this['pendingWrites']++;try{await _0x34f6ea();}finally{this['pendingWrites']--;}}async['_set'](_0x81648c,_0x1f0b88){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x487d59=>kr(_0x487d59,_0x81648c,_0x1f0b88)),this['localCache'][_0x81648c]=_0x1f0b88,this['notifyServiceWorker'](_0x81648c)));}async['_get'](_0x3ad4a5){const _0x1a87ec=await this['_withRetries'](_0x1a28e6=>lp(_0x1a28e6,_0x3ad4a5));return this['localCache'][_0x3ad4a5]=_0x1a87ec,_0x1a87ec;}async['_remove'](_0x2752b6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xc41aa6=>Nr(_0xc41aa6,_0x2752b6)),delete this['localCache'][_0x2752b6],this['notifyServiceWorker'](_0x2752b6)));}async['_poll'](){const _0x57466e=await this['_withRetries'](_0x4cb2b1=>{const _0x4efe3f=Kn(_0x4cb2b1,!0x1)['getAll']();return new Jt(_0x4efe3f)['toPromise']();});if(!_0x57466e)return[];if(this['pendingWrites']!==0x0)return[];const _0x2689c2=[],_0x247821=new Set();if(_0x57466e['length']!==0x0){for(const {fbase_key:_0x58c201,value:_0xc02a7d}of _0x57466e)_0x247821['add'](_0x58c201),JSON['stringify'](this['localCache'][_0x58c201])!==JSON['stringify'](_0xc02a7d)&&(this['notifyListeners'](_0x58c201,_0xc02a7d),_0x2689c2['push'](_0x58c201));}for(const _0x134786 of Object['keys'](this['localCache']))this['localCache'][_0x134786]&&!_0x247821['has'](_0x134786)&&(this['notifyListeners'](_0x134786,null),_0x2689c2['push'](_0x134786));return _0x2689c2;}['notifyListeners'](_0x511463,_0x2c589c){this['localCache'][_0x511463]=_0x2c589c;const _0x45d66b=this['listeners'][_0x511463];if(_0x45d66b){for(const _0x3828a2 of Array['from'](_0x45d66b))_0x3828a2(_0x2c589c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x734c15,_0x1baf96){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x734c15]||(this['listeners'][_0x734c15]=new Set(),this['_get'](_0x734c15)),this['listeners'][_0x734c15]['add'](_0x1baf96);}['_removeListener'](_0x57b799,_0x449867){this['listeners'][_0x57b799]&&(this['listeners'][_0x57b799]['delete'](_0x449867),this['listeners'][_0x57b799]['size']===0x0&&delete this['listeners'][_0x57b799]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x74bc4c,_0x21f0dd){return _0x21f0dd?ne(_0x21f0dd):(m(_0x74bc4c['_popupRedirectResolver'],_0x74bc4c,'argument-error'),_0x74bc4c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x44efb1){super('custom','custom'),this['params']=_0x44efb1;}['_getIdTokenResponse'](_0x32270c){return Ze(_0x32270c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x8858bb,_0x5c9c5c){return Ze(_0x8858bb,this['_buildIdpRequest'](_0x5c9c5c));}['_getReauthenticationResolver'](_0x500a85){return Ze(_0x500a85,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x569bb8){const _0x5f1bf1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x569bb8&&(_0x5f1bf1['idToken']=_0x569bb8),_0x5f1bf1;}}function pp(_0x748216){return Ua(_0x748216['auth'],new Rs(_0x748216),_0x748216['bypassAuthState']);}function _p(_0x2231cf){const {auth:_0x5b59a5,user:_0x3acca9}=_0x2231cf;return m(_0x3acca9,_0x5b59a5,'internal-error'),Kf(_0x3acca9,new Rs(_0x2231cf),_0x2231cf['bypassAuthState']);}async function gp(_0x45c861){const {auth:_0x59bf29,user:_0x237b6d}=_0x45c861;return m(_0x237b6d,_0x59bf29,'internal-error'),jf(_0x237b6d,new Rs(_0x45c861),_0x45c861['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x3b8710,_0x451df4,_0x2aed0b,_0x2e5afc,_0x1bf639=!0x1){this['auth']=_0x3b8710,this['resolver']=_0x2aed0b,this['user']=_0x2e5afc,this['bypassAuthState']=_0x1bf639,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x451df4)?_0x451df4:[_0x451df4];}['execute'](){return new Promise(async(_0x50d045,_0x2f15cc)=>{this['pendingPromise']={'resolve':_0x50d045,'reject':_0x2f15cc};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3f7597){this['reject'](_0x3f7597);}});}async['onAuthEvent'](_0x112492){const {urlResponse:_0x23b52c,sessionId:_0x4e65a4,postBody:_0x597a9b,tenantId:_0x5a43e7,error:_0x497708,type:_0x3a2d02}=_0x112492;if(_0x497708){this['reject'](_0x497708);return;}const _0x24d775={'auth':this['auth'],'requestUri':_0x23b52c,'sessionId':_0x4e65a4,'tenantId':_0x5a43e7||void 0x0,'postBody':_0x597a9b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3a2d02)(_0x24d775));}catch(_0x2d32f5){this['reject'](_0x2d32f5);}}['onError'](_0x4da80f){this['reject'](_0x4da80f);}['getIdpTask'](_0x113594){switch(_0x113594){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x9f8536){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x9f8536),this['unregisterAndCleanUp']();}['reject'](_0x38cef5){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x38cef5),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x2b111f,_0x5cc6e0,_0x4dc989,_0x533d47,_0x1eb92d){super(_0x2b111f,_0x5cc6e0,_0x533d47,_0x1eb92d),this['provider']=_0x4dc989,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x167ca2=await this['execute']();return m(_0x167ca2,this['auth'],'internal-error'),_0x167ca2;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5ce623=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5ce623),this['authWindow']['associatedEvent']=_0x5ce623,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1fff42=>{this['reject'](_0x1fff42);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0xa9633b=>{_0xa9633b||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1888d3;return((_0x1888d3=this['authWindow'])==null?void 0x0:_0x1888d3['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5b0598=()=>{var _0x18ac6f,_0x282594;if((_0x282594=(_0x18ac6f=this['authWindow'])==null?void 0x0:_0x18ac6f['window'])!=null&&_0x282594['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5b0598,mp['get']());};_0x5b0598();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x227659,_0x5b707b,_0x28eef6=!0x1){super(_0x227659,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5b707b,void 0x0,_0x28eef6),this['eventId']=null;}async['execute'](){let _0x3b588d=rn['get'](this['auth']['_key']());if(!_0x3b588d){try{const _0x588a75=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3b588d=()=>Promise['resolve'](_0x588a75);}catch(_0x9d2e21){_0x3b588d=()=>Promise['reject'](_0x9d2e21);}rn['set'](this['auth']['_key'](),_0x3b588d);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3b588d();}async['onAuthEvent'](_0x4c8661){if(_0x4c8661['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4c8661);if(_0x4c8661['type']==='unknown'){this['resolve'](null);return;}if(_0x4c8661['eventId']){const _0x9b22f2=await this['auth']['_redirectUserForId'](_0x4c8661['eventId']);if(_0x9b22f2)return this['user']=_0x9b22f2,super['onAuthEvent'](_0x4c8661);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x38c9fc,_0x37a056){const _0xe6b536=Cp(_0x37a056),_0x3fde3b=wp(_0x38c9fc);if(!await _0x3fde3b['_isAvailable']())return!0x1;const _0x294da7=await _0x3fde3b['_get'](_0xe6b536)==='true';return await _0x3fde3b['_remove'](_0xe6b536),_0x294da7;}function Ip(_0x505cf4,_0x34ce61){rn['set'](_0x505cf4['_key'](),_0x34ce61);}function wp(_0x391341){return ne(_0x391341['_redirectPersistence']);}function Cp(_0x42f737){return sn(yp,_0x42f737['config']['apiKey'],_0x42f737['name']);}async function Tp(_0x5f44b1,_0x5ba920,_0x29d1a8=!0x1){if(H(_0x5f44b1['app']))return Promise['reject'](se(_0x5f44b1));const _0x351079=qe(_0x5f44b1),_0x396eec=fp(_0x351079,_0x5ba920),_0x176456=await new vp(_0x351079,_0x396eec,_0x29d1a8)['execute']();return _0x176456&&!_0x29d1a8&&(delete _0x176456['user']['_redirectEventId'],await _0x351079['_persistUserIfCurrent'](_0x176456['user']),await _0x351079['_setRedirectUser'](null,_0x5ba920)),_0x176456;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x3efff3){this['auth']=_0x3efff3,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x18e530){this['consumers']['add'](_0x18e530),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x18e530)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x18e530),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3a587f){this['consumers']['delete'](_0x3a587f);}['onEvent'](_0x57e018){if(this['hasEventBeenHandled'](_0x57e018))return!0x1;let _0x8d80bb=!0x1;return this['consumers']['forEach'](_0x14f6e4=>{this['isEventForConsumer'](_0x57e018,_0x14f6e4)&&(_0x8d80bb=!0x0,this['sendToConsumer'](_0x57e018,_0x14f6e4),this['saveEventToCache'](_0x57e018));}),this['hasHandledPotentialRedirect']||!Rp(_0x57e018)||(this['hasHandledPotentialRedirect']=!0x0,_0x8d80bb||(this['queuedRedirectEvent']=_0x57e018,_0x8d80bb=!0x0)),_0x8d80bb;}['sendToConsumer'](_0x5d77d3,_0x4006c8){var _0x480ec6;if(_0x5d77d3['error']&&!Qa(_0x5d77d3)){const _0x3db547=((_0x480ec6=_0x5d77d3['error']['code'])==null?void 0x0:_0x480ec6['split']('auth/')[0x1])||'internal-error';_0x4006c8['onError'](J(this['auth'],_0x3db547));}else _0x4006c8['onAuthEvent'](_0x5d77d3);}['isEventForConsumer'](_0x7df9ad,_0x352ee2){const _0x125680=_0x352ee2['eventId']===null||!!_0x7df9ad['eventId']&&_0x7df9ad['eventId']===_0x352ee2['eventId'];return _0x352ee2['filter']['includes'](_0x7df9ad['type'])&&_0x125680;}['hasEventBeenHandled'](_0x56e2d0){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x56e2d0));}['saveEventToCache'](_0x1d49a3){this['cachedEventUids']['add'](Pr(_0x1d49a3)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0xbc10db){return[_0xbc10db['type'],_0xbc10db['eventId'],_0xbc10db['sessionId'],_0xbc10db['tenantId']]['filter'](_0x4508aa=>_0x4508aa)['join']('-');}function Qa({type:_0x227bc4,error:_0x375839}){return _0x227bc4==='unknown'&&(_0x375839==null?void 0x0:_0x375839['code'])==='auth/no-auth-event';}function Rp(_0x150519){switch(_0x150519['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x150519);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2daec8,_0x409223={}){return Ae(_0x2daec8,'GET','/v1/projects',_0x409223);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x41802e){if(_0x41802e['config']['emulator'])return;const {authorizedDomains:_0x11e849}=await Ap(_0x41802e);for(const _0xb3d694 of _0x11e849)try{if(Op(_0xb3d694))return;}catch{}K(_0x41802e,'unauthorized-domain');}function Op(_0x2dad9a){const _0x4e3120=Ni(),{protocol:_0x21cb24,hostname:_0x455482}=new URL(_0x4e3120);if(_0x2dad9a['startsWith']('chrome-extension://')){const _0x1111ac=new URL(_0x2dad9a);return _0x1111ac['hostname']===''&&_0x455482===''?_0x21cb24==='chrome-extension:'&&_0x2dad9a['replace']('chrome-extension://','')===_0x4e3120['replace']('chrome-extension://',''):_0x21cb24==='chrome-extension:'&&_0x1111ac['hostname']===_0x455482;}if(!Np['test'](_0x21cb24))return!0x1;if(kp['test'](_0x2dad9a))return _0x455482===_0x2dad9a;const _0x5624fa=_0x2dad9a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5624fa+'|'+_0x5624fa+')$','i')['test'](_0x455482);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x273857=X()['___jsl'];if(_0x273857!=null&&_0x273857['H']){for(const _0x3a0a51 of Object['keys'](_0x273857['H']))if(_0x273857['H'][_0x3a0a51]['r']=_0x273857['H'][_0x3a0a51]['r']||[],_0x273857['H'][_0x3a0a51]['L']=_0x273857['H'][_0x3a0a51]['L']||[],_0x273857['H'][_0x3a0a51]['r']=[..._0x273857['H'][_0x3a0a51]['L']],_0x273857['CP']){for(let _0x42216d=0x0;_0x42216d<_0x273857['CP']['length'];_0x42216d++)_0x273857['CP'][_0x42216d]=null;}}}function Mp(_0x5c3b51){return new Promise((_0x55e00c,_0x3a52f6)=>{var _0x5f1ad4,_0x2e0641,_0x4197cb;function _0x4515e6(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x55e00c(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x3a52f6(J(_0x5c3b51,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x2e0641=(_0x5f1ad4=X()['gapi'])==null?void 0x0:_0x5f1ad4['iframes'])!=null&&_0x2e0641['Iframe'])_0x55e00c(gapi['iframes']['getContext']());else{if((_0x4197cb=X()['gapi'])!=null&&_0x4197cb['load'])_0x4515e6();else{const _0x1aba20=Nf('iframefcb');return X()[_0x1aba20]=()=>{gapi['load']?_0x4515e6():_0x3a52f6(J(_0x5c3b51,'network-request-failed'));},Da(kf()+'?onload='+_0x1aba20)['catch'](_0x13fbe6=>_0x3a52f6(_0x13fbe6));}}})['catch'](_0x503e80=>{throw on=null,_0x503e80;});}let on=null;function Lp(_0x1f076c){return on=on||Mp(_0x1f076c),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x45c72b){const _0xad334d=_0x45c72b['config'];m(_0xad334d['authDomain'],_0x45c72b,'auth-domain-config-required');const _0x1703a5=_0xad334d['emulator']?Is(_0xad334d,Up):'https://'+_0x45c72b['config']['authDomain']+'/'+Fp,_0x4b380f={'apiKey':_0xad334d['apiKey'],'appName':_0x45c72b['name'],'v':ct},_0x2f1d92=Bp['get'](_0x45c72b['config']['apiHost']);_0x2f1d92&&(_0x4b380f['eid']=_0x2f1d92);const _0x4dcba8=_0x45c72b['_getFrameworks']();return _0x4dcba8['length']&&(_0x4b380f['fw']=_0x4dcba8['join'](',')),_0x1703a5+'?'+at(_0x4b380f)['slice'](0x1);}async function Hp(_0x363ea1){const _0x3439dc=await Lp(_0x363ea1),_0x3348b2=X()['gapi'];return m(_0x3348b2,_0x363ea1,'internal-error'),_0x3439dc['open']({'where':document['body'],'url':Vp(_0x363ea1),'messageHandlersFilter':_0x3348b2['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x532a09=>new Promise(async(_0x5a33d0,_0x421355)=>{await _0x532a09['restyle']({'setHideOnLeave':!0x1});const _0xce9b30=J(_0x363ea1,'network-request-failed'),_0xdb69af=X()['setTimeout'](()=>{_0x421355(_0xce9b30);},xp['get']());function _0x3aebec(){X()['clearTimeout'](_0xdb69af),_0x5a33d0(_0x532a09);}_0x532a09['ping'](_0x3aebec)['then'](_0x3aebec,()=>{_0x421355(_0xce9b30);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1cd2eb){this['window']=_0x1cd2eb,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x2ccba0,_0x159729,_0x3f6c2b,_0x227f8c=Gp,_0x51eaca=qp){const _0x16a9b8=Math['max']((window['screen']['availHeight']-_0x51eaca)/0x2,0x0)['toString'](),_0x204aa6=Math['max']((window['screen']['availWidth']-_0x227f8c)/0x2,0x0)['toString']();let _0x517c42='';const _0x35a89c={...$p,'width':_0x227f8c['toString'](),'height':_0x51eaca['toString'](),'top':_0x16a9b8,'left':_0x204aa6},_0x39ee6b=W()['toLowerCase']();_0x3f6c2b&&(_0x517c42=ba(_0x39ee6b)?zp:_0x3f6c2b),Ta(_0x39ee6b)&&(_0x159729=_0x159729||jp,_0x35a89c['scrollbars']='yes');const _0x17798d=Object['entries'](_0x35a89c)['reduce']((_0x2f94af,[_0x54f011,_0x282e4e])=>''+_0x2f94af+_0x54f011+'='+_0x282e4e+',','');if(Ef(_0x39ee6b)&&_0x517c42!=='_self')return Yp(_0x159729||'',_0x517c42),new Dr(null);const _0x191d3f=window['open'](_0x159729||'',_0x517c42,_0x17798d);m(_0x191d3f,_0x2ccba0,'popup-blocked');try{_0x191d3f['focus']();}catch{}return new Dr(_0x191d3f);}function Yp(_0xe497cc,_0x5a25ba){const _0x186d24=document['createElement']('a');_0x186d24['href']=_0xe497cc,_0x186d24['target']=_0x5a25ba;const _0x4daf6d=document['createEvent']('MouseEvent');_0x4daf6d['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x186d24['dispatchEvent'](_0x4daf6d);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x3b8302,_0x3d5309,_0x339188,_0x347faf,_0xdd54a3,_0x5d39cc){m(_0x3b8302['config']['authDomain'],_0x3b8302,'auth-domain-config-required'),m(_0x3b8302['config']['apiKey'],_0x3b8302,'invalid-api-key');const _0x3b804b={'apiKey':_0x3b8302['config']['apiKey'],'appName':_0x3b8302['name'],'authType':_0x339188,'redirectUrl':_0x347faf,'v':ct,'eventId':_0xdd54a3};if(_0x3d5309 instanceof xa){_0x3d5309['setDefaultLanguage'](_0x3b8302['languageCode']),_0x3b804b['providerId']=_0x3d5309['providerId']||'',hi(_0x3d5309['getCustomParameters']())||(_0x3b804b['customParameters']=JSON['stringify'](_0x3d5309['getCustomParameters']()));for(const [_0x567017,_0x50766b]of Object['entries']({}))_0x3b804b[_0x567017]=_0x50766b;}if(_0x3d5309 instanceof Qt){const _0x33f5fa=_0x3d5309['getScopes']()['filter'](_0x5c00b3=>_0x5c00b3!=='');_0x33f5fa['length']>0x0&&(_0x3b804b['scopes']=_0x33f5fa['join'](','));}_0x3b8302['tenantId']&&(_0x3b804b['tid']=_0x3b8302['tenantId']);const _0x14fe7c=_0x3b804b;for(const _0xade638 of Object['keys'](_0x14fe7c))_0x14fe7c[_0xade638]===void 0x0&&delete _0x14fe7c[_0xade638];const _0x1adc32=await _0x3b8302['_getAppCheckToken'](),_0x6cf0a5=_0x1adc32?'#'+Xp+'='+encodeURIComponent(_0x1adc32):'';return Zp(_0x3b8302)+'?'+at(_0x14fe7c)['slice'](0x1)+_0x6cf0a5;}function Zp({config:_0x43cd29}){return _0x43cd29['emulator']?Is(_0x43cd29,Jp):'https://'+_0x43cd29['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x23e9fc,_0x5e2f39,_0x48bc06,_0x24db63){var _0x441a1c;ae((_0x441a1c=this['eventManagers'][_0x23e9fc['_key']()])==null?void 0x0:_0x441a1c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4898ae=await Mr(_0x23e9fc,_0x5e2f39,_0x48bc06,Ni(),_0x24db63);return Kp(_0x23e9fc,_0x4898ae,bs());}async['_openRedirect'](_0xa5afb3,_0x433de1,_0x315f59,_0x2589ae){await this['_originValidation'](_0xa5afb3);const _0x4fe743=await Mr(_0xa5afb3,_0x433de1,_0x315f59,Ni(),_0x2589ae);return ip(_0x4fe743),new Promise(()=>{});}['_initialize'](_0x446f9a){const _0x11ec57=_0x446f9a['_key']();if(this['eventManagers'][_0x11ec57]){const {manager:_0x28aa93,promise:_0x3138d7}=this['eventManagers'][_0x11ec57];return _0x28aa93?Promise['resolve'](_0x28aa93):(ae(_0x3138d7,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3138d7);}const _0x2fcecc=this['initAndGetManager'](_0x446f9a);return this['eventManagers'][_0x11ec57]={'promise':_0x2fcecc},_0x2fcecc['catch'](()=>{delete this['eventManagers'][_0x11ec57];}),_0x2fcecc;}async['initAndGetManager'](_0x3052d0){const _0xb4ec1=await Hp(_0x3052d0),_0x484ce9=new bp(_0x3052d0);return _0xb4ec1['register']('authEvent',_0x525ebd=>(m(_0x525ebd==null?void 0x0:_0x525ebd['authEvent'],_0x3052d0,'invalid-auth-event'),{'status':_0x484ce9['onEvent'](_0x525ebd['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3052d0['_key']()]={'manager':_0x484ce9},this['iframes'][_0x3052d0['_key']()]=_0xb4ec1,_0x484ce9;}['_isIframeWebStorageSupported'](_0x203a34,_0x32578b){this['iframes'][_0x203a34['_key']()]['send'](li,{'type':li},_0x3c8152=>{var _0x16185c;const _0x124a2c=(_0x16185c=_0x3c8152==null?void 0x0:_0x3c8152[0x0])==null?void 0x0:_0x16185c[li];_0x124a2c!==void 0x0&&_0x32578b(!!_0x124a2c),K(_0x203a34,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x83465){const _0x3ecb58=_0x83465['_key']();return this['originValidationPromises'][_0x3ecb58]||(this['originValidationPromises'][_0x3ecb58]=Pp(_0x83465)),this['originValidationPromises'][_0x3ecb58];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x4eb78c){this['auth']=_0x4eb78c,this['internalListeners']=new Map();}['getUid'](){var _0x795bb0;return this['assertAuthConfigured'](),((_0x795bb0=this['auth']['currentUser'])==null?void 0x0:_0x795bb0['uid'])||null;}async['getToken'](_0x3ff3be){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3ff3be)}:null;}['addAuthTokenListener'](_0xfb285b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xfb285b))return;const _0x46da19=this['auth']['onIdTokenChanged'](_0x8a7df0=>{_0xfb285b((_0x8a7df0==null?void 0x0:_0x8a7df0['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xfb285b,_0x46da19),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x502a1e){this['assertAuthConfigured']();const _0x4fa146=this['internalListeners']['get'](_0x502a1e);_0x4fa146&&(this['internalListeners']['delete'](_0x502a1e),_0x4fa146(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x369ce7){switch(_0x369ce7){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3d8d7b){et(new Me('auth',(_0x5c6258,{options:_0x3aa630})=>{const _0x26fc69=_0x5c6258['getProvider']('app')['getImmediate'](),_0x4d6949=_0x5c6258['getProvider']('heartbeat'),_0x313255=_0x5c6258['getProvider']('app-check-internal'),{apiKey:_0x217e7f,authDomain:_0x815c52}=_0x26fc69['options'];m(_0x217e7f&&!_0x217e7f['includes'](':'),'invalid-api-key',{'appName':_0x26fc69['name']});const _0x1f3c8f={'apiKey':_0x217e7f,'authDomain':_0x815c52,'clientPlatform':_0x3d8d7b,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3d8d7b)},_0x24643a=new bf(_0x26fc69,_0x4d6949,_0x313255,_0x1f3c8f);return Lf(_0x24643a,_0x3aa630),_0x24643a;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x569447,_0x1b4047,_0x566239)=>{_0x569447['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x558e25=>{const _0x43ad22=qe(_0x558e25['getProvider']('auth')['getImmediate']());return(_0x155bec=>new n_(_0x155bec))(_0x43ad22);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3d8d7b)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1f41a5=>async _0x3f6a87=>{const _0x1b895a=_0x3f6a87&&await _0x3f6a87['getIdTokenResult'](),_0x5e68de=_0x1b895a&&(new Date()['getTime']()-Date['parse'](_0x1b895a['issuedAtTime']))/0x3e8;if(_0x5e68de&&_0x5e68de>o_)return;const _0x2f8014=_0x1b895a==null?void 0x0:_0x1b895a['token'];Fr!==_0x2f8014&&(Fr=_0x2f8014,await fetch(_0x1f41a5,{'method':_0x2f8014?'POST':'DELETE','headers':_0x2f8014?{'Authorization':'Bearer\x20'+_0x2f8014}:{}}));};function O_(_0x1725e5=Qr()){const _0x3de4f7=Ui(_0x1725e5,'auth');if(_0x3de4f7['isInitialized']())return _0x3de4f7['getImmediate']();const _0x3f369f=Mf(_0x1725e5,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x26c0b5=Gr('authTokenSyncURL');if(_0x26c0b5&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x583a05=new URL(_0x26c0b5,location['origin']);if(location['origin']===_0x583a05['origin']){const _0x4d624c=a_(_0x583a05['toString']());Jf(_0x3f369f,_0x4d624c,()=>_0x4d624c(_0x3f369f['currentUser'])),Qf(_0x3f369f,_0x525a15=>_0x4d624c(_0x525a15));}}const _0x11daa5=Hr('auth');return _0x11daa5&&xf(_0x3f369f,'http://'+_0x11daa5),_0x3f369f;}function c_(){var _0x31b8eb;return((_0x31b8eb=document['getElementsByTagName']('head'))==null?void 0x0:_0x31b8eb[0x0])??document;}Rf({'loadJS'(_0x1996e6){return new Promise((_0x186bf,_0x2d81e2)=>{const _0x2e0c39=document['createElement']('script');_0x2e0c39['setAttribute']('src',_0x1996e6),_0x2e0c39['onload']=_0x186bf,_0x2e0c39['onerror']=_0x88c913=>{const _0x5e73be=J('internal-error');_0x5e73be['customData']=_0x88c913,_0x2d81e2(_0x5e73be);},_0x2e0c39['type']='text/javascript',_0x2e0c39['charset']='UTF-8',c_()['appendChild'](_0x2e0c39);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};