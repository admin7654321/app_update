const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x7c79f,_0x21381b){if(!_0x7c79f)throw ot(_0x21381b);},ot=function(_0x4ad8b4){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4ad8b4);},Wr=function(_0x5e0dbc){const _0x5c9ee9=[];let _0x3f02f5=0x0;for(let _0x57572f=0x0;_0x57572f<_0x5e0dbc['length'];_0x57572f++){let _0xeaa6f=_0x5e0dbc['charCodeAt'](_0x57572f);_0xeaa6f<0x80?_0x5c9ee9[_0x3f02f5++]=_0xeaa6f:_0xeaa6f<0x800?(_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0x6|0xc0,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f&0x3f|0x80):(_0xeaa6f&0xfc00)===0xd800&&_0x57572f+0x1<_0x5e0dbc['length']&&(_0x5e0dbc['charCodeAt'](_0x57572f+0x1)&0xfc00)===0xdc00?(_0xeaa6f=0x10000+((_0xeaa6f&0x3ff)<<0xa)+(_0x5e0dbc['charCodeAt'](++_0x57572f)&0x3ff),_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0x12|0xf0,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0xc&0x3f|0x80,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0x6&0x3f|0x80,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f&0x3f|0x80):(_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0xc|0xe0,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f>>0x6&0x3f|0x80,_0x5c9ee9[_0x3f02f5++]=_0xeaa6f&0x3f|0x80);}return _0x5c9ee9;},Za=function(_0x39613c){const _0x18b9b3=[];let _0x450bbc=0x0,_0x12919d=0x0;for(;_0x450bbc<_0x39613c['length'];){const _0x424b31=_0x39613c[_0x450bbc++];if(_0x424b31<0x80)_0x18b9b3[_0x12919d++]=String['fromCharCode'](_0x424b31);else{if(_0x424b31>0xbf&&_0x424b31<0xe0){const _0x69f75d=_0x39613c[_0x450bbc++];_0x18b9b3[_0x12919d++]=String['fromCharCode']((_0x424b31&0x1f)<<0x6|_0x69f75d&0x3f);}else{if(_0x424b31>0xef&&_0x424b31<0x16d){const _0x27b4e5=_0x39613c[_0x450bbc++],_0x295ae9=_0x39613c[_0x450bbc++],_0x27ada6=_0x39613c[_0x450bbc++],_0x525e91=((_0x424b31&0x7)<<0x12|(_0x27b4e5&0x3f)<<0xc|(_0x295ae9&0x3f)<<0x6|_0x27ada6&0x3f)-0x10000;_0x18b9b3[_0x12919d++]=String['fromCharCode'](0xd800+(_0x525e91>>0xa)),_0x18b9b3[_0x12919d++]=String['fromCharCode'](0xdc00+(_0x525e91&0x3ff));}else{const _0x2fc156=_0x39613c[_0x450bbc++],_0x28c596=_0x39613c[_0x450bbc++];_0x18b9b3[_0x12919d++]=String['fromCharCode']((_0x424b31&0xf)<<0xc|(_0x2fc156&0x3f)<<0x6|_0x28c596&0x3f);}}}}return _0x18b9b3['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x104658,_0xe2e3c5){if(!Array['isArray'](_0x104658))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xd7a6da=_0xe2e3c5?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4e2913=[];for(let _0x2566dd=0x0;_0x2566dd<_0x104658['length'];_0x2566dd+=0x3){const _0x9db373=_0x104658[_0x2566dd],_0x2f32e5=_0x2566dd+0x1<_0x104658['length'],_0x3cc517=_0x2f32e5?_0x104658[_0x2566dd+0x1]:0x0,_0x22fb18=_0x2566dd+0x2<_0x104658['length'],_0x2b0439=_0x22fb18?_0x104658[_0x2566dd+0x2]:0x0,_0xde010b=_0x9db373>>0x2,_0x17d897=(_0x9db373&0x3)<<0x4|_0x3cc517>>0x4;let _0x463dcb=(_0x3cc517&0xf)<<0x2|_0x2b0439>>0x6,_0x34dc45=_0x2b0439&0x3f;_0x22fb18||(_0x34dc45=0x40,_0x2f32e5||(_0x463dcb=0x40)),_0x4e2913['push'](_0xd7a6da[_0xde010b],_0xd7a6da[_0x17d897],_0xd7a6da[_0x463dcb],_0xd7a6da[_0x34dc45]);}return _0x4e2913['join']('');},'encodeString'(_0xf418ce,_0x28bd16){return this['HAS_NATIVE_SUPPORT']&&!_0x28bd16?btoa(_0xf418ce):this['encodeByteArray'](Wr(_0xf418ce),_0x28bd16);},'decodeString'(_0xb800f6,_0x382531){return this['HAS_NATIVE_SUPPORT']&&!_0x382531?atob(_0xb800f6):Za(this['decodeStringToByteArray'](_0xb800f6,_0x382531));},'decodeStringToByteArray'(_0x9ef4f8,_0x5f2e99){this['init_']();const _0x58941a=_0x5f2e99?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x10a524=[];for(let _0x4d8473=0x0;_0x4d8473<_0x9ef4f8['length'];){const _0x52cc7b=_0x58941a[_0x9ef4f8['charAt'](_0x4d8473++)],_0x263ee0=_0x4d8473<_0x9ef4f8['length']?_0x58941a[_0x9ef4f8['charAt'](_0x4d8473)]:0x0;++_0x4d8473;const _0x320301=_0x4d8473<_0x9ef4f8['length']?_0x58941a[_0x9ef4f8['charAt'](_0x4d8473)]:0x40;++_0x4d8473;const _0x556b1f=_0x4d8473<_0x9ef4f8['length']?_0x58941a[_0x9ef4f8['charAt'](_0x4d8473)]:0x40;if(++_0x4d8473,_0x52cc7b==null||_0x263ee0==null||_0x320301==null||_0x556b1f==null)throw new ec();const _0x53fc7a=_0x52cc7b<<0x2|_0x263ee0>>0x4;if(_0x10a524['push'](_0x53fc7a),_0x320301!==0x40){const _0x5dad88=_0x263ee0<<0x4&0xf0|_0x320301>>0x2;if(_0x10a524['push'](_0x5dad88),_0x556b1f!==0x40){const _0x4924ed=_0x320301<<0x6&0xc0|_0x556b1f;_0x10a524['push'](_0x4924ed);}}}return _0x10a524;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x263dc1=0x0;_0x263dc1<this['ENCODED_VALS']['length'];_0x263dc1++)this['byteToCharMap_'][_0x263dc1]=this['ENCODED_VALS']['charAt'](_0x263dc1),this['charToByteMap_'][this['byteToCharMap_'][_0x263dc1]]=_0x263dc1,this['byteToCharMapWebSafe_'][_0x263dc1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x263dc1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x263dc1]]=_0x263dc1,_0x263dc1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x263dc1)]=_0x263dc1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x263dc1)]=_0x263dc1);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x35814b){const _0x467fdd=Wr(_0x35814b);return Di['encodeByteArray'](_0x467fdd,!0x0);},an=function(_0x18fb25){return Br(_0x18fb25)['replace'](/\./g,'');},cn=function(_0x21dde6){try{return Di['decodeString'](_0x21dde6,!0x0);}catch(_0x4143f8){console['error']('base64Decode\x20failed:\x20',_0x4143f8);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x304c64){return Vr(void 0x0,_0x304c64);}function Vr(_0x3d13fe,_0x3ebb5a){if(!(_0x3ebb5a instanceof Object))return _0x3ebb5a;switch(_0x3ebb5a['constructor']){case Date:const _0x4e0bcc=_0x3ebb5a;return new Date(_0x4e0bcc['getTime']());case Object:_0x3d13fe===void 0x0&&(_0x3d13fe={});break;case Array:_0x3d13fe=[];break;default:return _0x3ebb5a;}for(const _0x2229db in _0x3ebb5a)!_0x3ebb5a['hasOwnProperty'](_0x2229db)||!nc(_0x2229db)||(_0x3d13fe[_0x2229db]=Vr(_0x3d13fe[_0x2229db],_0x3ebb5a[_0x2229db]));return _0x3d13fe;}function nc(_0x2a4397){return _0x2a4397!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0xc447f8=As['__FIREBASE_DEFAULTS__'];if(_0xc447f8)return JSON['parse'](_0xc447f8);},oc=()=>{if(typeof document>'u')return;let _0x37f7a6;try{_0x37f7a6=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x20019a=_0x37f7a6&&cn(_0x37f7a6[0x1]);return _0x20019a&&JSON['parse'](_0x20019a);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4ce252){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4ce252);return;}},Hr=_0x1cde50=>{var _0x217c52,_0x4d2850;return(_0x4d2850=(_0x217c52=Mi())==null?void 0x0:_0x217c52['emulatorHosts'])==null?void 0x0:_0x4d2850[_0x1cde50];},ac=_0x45a46c=>{const _0x78138e=Hr(_0x45a46c);if(!_0x78138e)return;const _0x5bd46d=_0x78138e['lastIndexOf'](':');if(_0x5bd46d<=0x0||_0x5bd46d+0x1===_0x78138e['length'])throw new Error('Invalid\x20host\x20'+_0x78138e+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x383929=parseInt(_0x78138e['substring'](_0x5bd46d+0x1),0xa);return _0x78138e[0x0]==='['?[_0x78138e['substring'](0x1,_0x5bd46d-0x1),_0x383929]:[_0x78138e['substring'](0x0,_0x5bd46d),_0x383929];},$r=()=>{var _0x2ab79b;return(_0x2ab79b=Mi())==null?void 0x0:_0x2ab79b['config'];},Gr=_0x164d02=>{var _0x4be9f1;return(_0x4be9f1=Mi())==null?void 0x0:_0x4be9f1['_'+_0x164d02];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1f1fa8,_0x5148dd)=>{this['resolve']=_0x1f1fa8,this['reject']=_0x5148dd;});}['wrapCallback'](_0x5e3dcf){return(_0x1e1c6f,_0x227602)=>{_0x1e1c6f?this['reject'](_0x1e1c6f):this['resolve'](_0x227602),typeof _0x5e3dcf=='function'&&(this['promise']['catch'](()=>{}),_0x5e3dcf['length']===0x1?_0x5e3dcf(_0x1e1c6f):_0x5e3dcf(_0x1e1c6f,_0x227602));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x39fddd,_0x39d4fb){if(_0x39fddd['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1c2bff={'alg':'none','type':'JWT'},_0x2b8062=_0x39d4fb||'demo-project',_0x50d1a5=_0x39fddd['iat']||0x0,_0x36fe64=_0x39fddd['sub']||_0x39fddd['user_id'];if(!_0x36fe64)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2a718d={'iss':'https://securetoken.google.com/'+_0x2b8062,'aud':_0x2b8062,'iat':_0x50d1a5,'exp':_0x50d1a5+0xe10,'auth_time':_0x50d1a5,'sub':_0x36fe64,'user_id':_0x36fe64,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x39fddd};return[an(JSON['stringify'](_0x1c2bff)),an(JSON['stringify'](_0x2a718d)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x88ed3a=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x88ed3a=='object'&&_0x88ed3a['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x101e53=W();return _0x101e53['indexOf']('MSIE\x20')>=0x0||_0x101e53['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x5debc6,_0xf698de)=>{try{let _0x7dbf99=!0x0;const _0x374e79='validate-browser-context-for-indexeddb-analytics-module',_0x49d8bc=self['indexedDB']['open'](_0x374e79);_0x49d8bc['onsuccess']=()=>{_0x49d8bc['result']['close'](),_0x7dbf99||self['indexedDB']['deleteDatabase'](_0x374e79),_0x5debc6(!0x0);},_0x49d8bc['onupgradeneeded']=()=>{_0x7dbf99=!0x1;},_0x49d8bc['onerror']=()=>{var _0x12fab0;_0xf698de(((_0x12fab0=_0x49d8bc['error'])==null?void 0x0:_0x12fab0['message'])||'');};}catch(_0x3ca65b){_0xf698de(_0x3ca65b);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x18e17d,_0x45dedd,_0x56d621){super(_0x45dedd),this['code']=_0x18e17d,this['customData']=_0x56d621,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x323771,_0x4e1258,_0x1473e9){this['service']=_0x323771,this['serviceName']=_0x4e1258,this['errors']=_0x1473e9;}['create'](_0x1ac1b6,..._0x297641){const _0x6e2020=_0x297641[0x0]||{},_0x28bdf5=this['service']+'/'+_0x1ac1b6,_0x1ec858=this['errors'][_0x1ac1b6],_0xdd9c44=_0x1ec858?gc(_0x1ec858,_0x6e2020):'Error',_0xc89174=this['serviceName']+':\x20'+_0xdd9c44+'\x20('+_0x28bdf5+').';return new Se(_0x28bdf5,_0xc89174,_0x6e2020);}}function gc(_0x2645b5,_0x164bce){return _0x2645b5['replace'](mc,(_0x72a7e,_0x42ff6a)=>{const _0x3eae60=_0x164bce[_0x42ff6a];return _0x3eae60!=null?String(_0x3eae60):'<'+_0x42ff6a+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x3bfde6){return JSON['parse'](_0x3bfde6);}function O(_0x148d6a){return JSON['stringify'](_0x148d6a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x2099f0){let _0x1e6912={},_0x10d5a5={},_0x32a850={},_0x2529c8='';try{const _0x5bfb06=_0x2099f0['split']('.');_0x1e6912=bt(cn(_0x5bfb06[0x0])||''),_0x10d5a5=bt(cn(_0x5bfb06[0x1])||''),_0x2529c8=_0x5bfb06[0x2],_0x32a850=_0x10d5a5['d']||{},delete _0x10d5a5['d'];}catch{}return{'header':_0x1e6912,'claims':_0x10d5a5,'data':_0x32a850,'signature':_0x2529c8};},yc=function(_0x1c38d2){const _0x5b0a7e=zr(_0x1c38d2),_0x1baa1a=_0x5b0a7e['claims'];return!!_0x1baa1a&&typeof _0x1baa1a=='object'&&_0x1baa1a['hasOwnProperty']('iat');},vc=function(_0x3144a1){const _0x4b094f=zr(_0x3144a1)['claims'];return typeof _0x4b094f=='object'&&_0x4b094f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x2e782f,_0x4db30b){return Object['prototype']['hasOwnProperty']['call'](_0x2e782f,_0x4db30b);}function Oe(_0x2dcd56,_0x336236){if(Object['prototype']['hasOwnProperty']['call'](_0x2dcd56,_0x336236))return _0x2dcd56[_0x336236];}function hi(_0x1d1917){for(const _0x91a1df in _0x1d1917)if(Object['prototype']['hasOwnProperty']['call'](_0x1d1917,_0x91a1df))return!0x1;return!0x0;}function ln(_0xa9a1e5,_0x7dde4b,_0x14b6b0){const _0x16a214={};for(const _0xe75503 in _0xa9a1e5)Object['prototype']['hasOwnProperty']['call'](_0xa9a1e5,_0xe75503)&&(_0x16a214[_0xe75503]=_0x7dde4b['call'](_0x14b6b0,_0xa9a1e5[_0xe75503],_0xe75503,_0xa9a1e5));return _0x16a214;}function De(_0x5a66f0,_0x514e38){if(_0x5a66f0===_0x514e38)return!0x0;const _0xad758c=Object['keys'](_0x5a66f0),_0x213d46=Object['keys'](_0x514e38);for(const _0xe92232 of _0xad758c){if(!_0x213d46['includes'](_0xe92232))return!0x1;const _0xaa2cfc=_0x5a66f0[_0xe92232],_0x59fabd=_0x514e38[_0xe92232];if(ks(_0xaa2cfc)&&ks(_0x59fabd)){if(!De(_0xaa2cfc,_0x59fabd))return!0x1;}else{if(_0xaa2cfc!==_0x59fabd)return!0x1;}}for(const _0x462298 of _0x213d46)if(!_0xad758c['includes'](_0x462298))return!0x1;return!0x0;}function ks(_0x5652cd){return _0x5652cd!==null&&typeof _0x5652cd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5d1af7){const _0x11d6d4=[];for(const [_0x4773bc,_0x55c8d9]of Object['entries'](_0x5d1af7))Array['isArray'](_0x55c8d9)?_0x55c8d9['forEach'](_0x2ec8c6=>{_0x11d6d4['push'](encodeURIComponent(_0x4773bc)+'='+encodeURIComponent(_0x2ec8c6));}):_0x11d6d4['push'](encodeURIComponent(_0x4773bc)+'='+encodeURIComponent(_0x55c8d9));return _0x11d6d4['length']?'&'+_0x11d6d4['join']('&'):'';}function yt(_0xb8c5be){const _0x15c39f={};return _0xb8c5be['replace'](/^\?/,'')['split']('&')['forEach'](_0x5ce6ac=>{if(_0x5ce6ac){const [_0x2c3e46,_0x1c02bc]=_0x5ce6ac['split']('=');_0x15c39f[decodeURIComponent(_0x2c3e46)]=decodeURIComponent(_0x1c02bc);}}),_0x15c39f;}function vt(_0x323f21){const _0x412143=_0x323f21['indexOf']('?');if(!_0x412143)return'';const _0x344608=_0x323f21['indexOf']('#',_0x412143);return _0x323f21['substring'](_0x412143,_0x344608>0x0?_0x344608:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x531933=0x1;_0x531933<this['blockSize'];++_0x531933)this['pad_'][_0x531933]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xdb4e73,_0x40d876){_0x40d876||(_0x40d876=0x0);const _0x223786=this['W_'];if(typeof _0xdb4e73=='string'){for(let _0x3d7ae3=0x0;_0x3d7ae3<0x10;_0x3d7ae3++)_0x223786[_0x3d7ae3]=_0xdb4e73['charCodeAt'](_0x40d876)<<0x18|_0xdb4e73['charCodeAt'](_0x40d876+0x1)<<0x10|_0xdb4e73['charCodeAt'](_0x40d876+0x2)<<0x8|_0xdb4e73['charCodeAt'](_0x40d876+0x3),_0x40d876+=0x4;}else{for(let _0x34a9f7=0x0;_0x34a9f7<0x10;_0x34a9f7++)_0x223786[_0x34a9f7]=_0xdb4e73[_0x40d876]<<0x18|_0xdb4e73[_0x40d876+0x1]<<0x10|_0xdb4e73[_0x40d876+0x2]<<0x8|_0xdb4e73[_0x40d876+0x3],_0x40d876+=0x4;}for(let _0x28255a=0x10;_0x28255a<0x50;_0x28255a++){const _0x474e85=_0x223786[_0x28255a-0x3]^_0x223786[_0x28255a-0x8]^_0x223786[_0x28255a-0xe]^_0x223786[_0x28255a-0x10];_0x223786[_0x28255a]=(_0x474e85<<0x1|_0x474e85>>>0x1f)&0xffffffff;}let _0x215950=this['chain_'][0x0],_0x5e609e=this['chain_'][0x1],_0x158ac1=this['chain_'][0x2],_0x417729=this['chain_'][0x3],_0x346207=this['chain_'][0x4],_0x2e6f2e,_0x501788;for(let _0x139dc0=0x0;_0x139dc0<0x50;_0x139dc0++){_0x139dc0<0x28?_0x139dc0<0x14?(_0x2e6f2e=_0x417729^_0x5e609e&(_0x158ac1^_0x417729),_0x501788=0x5a827999):(_0x2e6f2e=_0x5e609e^_0x158ac1^_0x417729,_0x501788=0x6ed9eba1):_0x139dc0<0x3c?(_0x2e6f2e=_0x5e609e&_0x158ac1|_0x417729&(_0x5e609e|_0x158ac1),_0x501788=0x8f1bbcdc):(_0x2e6f2e=_0x5e609e^_0x158ac1^_0x417729,_0x501788=0xca62c1d6);const _0xe630b7=(_0x215950<<0x5|_0x215950>>>0x1b)+_0x2e6f2e+_0x346207+_0x501788+_0x223786[_0x139dc0]&0xffffffff;_0x346207=_0x417729,_0x417729=_0x158ac1,_0x158ac1=(_0x5e609e<<0x1e|_0x5e609e>>>0x2)&0xffffffff,_0x5e609e=_0x215950,_0x215950=_0xe630b7;}this['chain_'][0x0]=this['chain_'][0x0]+_0x215950&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5e609e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x158ac1&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x417729&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x346207&0xffffffff;}['update'](_0x4baf82,_0x55f385){if(_0x4baf82==null)return;_0x55f385===void 0x0&&(_0x55f385=_0x4baf82['length']);const _0x155665=_0x55f385-this['blockSize'];let _0x10b115=0x0;const _0x4a0e75=this['buf_'];let _0x5e25d7=this['inbuf_'];for(;_0x10b115<_0x55f385;){if(_0x5e25d7===0x0){for(;_0x10b115<=_0x155665;)this['compress_'](_0x4baf82,_0x10b115),_0x10b115+=this['blockSize'];}if(typeof _0x4baf82=='string'){for(;_0x10b115<_0x55f385;)if(_0x4a0e75[_0x5e25d7]=_0x4baf82['charCodeAt'](_0x10b115),++_0x5e25d7,++_0x10b115,_0x5e25d7===this['blockSize']){this['compress_'](_0x4a0e75),_0x5e25d7=0x0;break;}}else{for(;_0x10b115<_0x55f385;)if(_0x4a0e75[_0x5e25d7]=_0x4baf82[_0x10b115],++_0x5e25d7,++_0x10b115,_0x5e25d7===this['blockSize']){this['compress_'](_0x4a0e75),_0x5e25d7=0x0;break;}}}this['inbuf_']=_0x5e25d7,this['total_']+=_0x55f385;}['digest'](){const _0x1d8ebd=[];let _0x36d474=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x15005c=this['blockSize']-0x1;_0x15005c>=0x38;_0x15005c--)this['buf_'][_0x15005c]=_0x36d474&0xff,_0x36d474/=0x100;this['compress_'](this['buf_']);let _0x59d5aa=0x0;for(let _0x131bc5=0x0;_0x131bc5<0x5;_0x131bc5++)for(let _0x293bf4=0x18;_0x293bf4>=0x0;_0x293bf4-=0x8)_0x1d8ebd[_0x59d5aa]=this['chain_'][_0x131bc5]>>_0x293bf4&0xff,++_0x59d5aa;return _0x1d8ebd;}}function Ic(_0x80afae,_0x2ff1cb){const _0x1d5528=new wc(_0x80afae,_0x2ff1cb);return _0x1d5528['subscribe']['bind'](_0x1d5528);}class wc{constructor(_0x414165,_0x21f42a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x21f42a,this['task']['then'](()=>{_0x414165(this);})['catch'](_0xe04d67=>{this['error'](_0xe04d67);});}['next'](_0x25cfa6){this['forEachObserver'](_0x43bf14=>{_0x43bf14['next'](_0x25cfa6);});}['error'](_0x589db7){this['forEachObserver'](_0x20fef7=>{_0x20fef7['error'](_0x589db7);}),this['close'](_0x589db7);}['complete'](){this['forEachObserver'](_0x2328cd=>{_0x2328cd['complete']();}),this['close']();}['subscribe'](_0x4d57ec,_0x473602,_0x5d7898){let _0x1d27bb;if(_0x4d57ec===void 0x0&&_0x473602===void 0x0&&_0x5d7898===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4d57ec,['next','error','complete'])?_0x1d27bb=_0x4d57ec:_0x1d27bb={'next':_0x4d57ec,'error':_0x473602,'complete':_0x5d7898},_0x1d27bb['next']===void 0x0&&(_0x1d27bb['next']=Qn),_0x1d27bb['error']===void 0x0&&(_0x1d27bb['error']=Qn),_0x1d27bb['complete']===void 0x0&&(_0x1d27bb['complete']=Qn);const _0xdbfe52=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1d27bb['error'](this['finalError']):_0x1d27bb['complete']();}catch{}}),this['observers']['push'](_0x1d27bb),_0xdbfe52;}['unsubscribeOne'](_0x1770bb){this['observers']===void 0x0||this['observers'][_0x1770bb]===void 0x0||(delete this['observers'][_0x1770bb],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1c5539){if(!this['finalized']){for(let _0x286c28=0x0;_0x286c28<this['observers']['length'];_0x286c28++)this['sendOne'](_0x286c28,_0x1c5539);}}['sendOne'](_0x1d7484,_0x12e947){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1d7484]!==void 0x0)try{_0x12e947(this['observers'][_0x1d7484]);}catch(_0x2230af){typeof console<'u'&&console['error']&&console['error'](_0x2230af);}});}['close'](_0x54cdb6){this['finalized']||(this['finalized']=!0x0,_0x54cdb6!==void 0x0&&(this['finalError']=_0x54cdb6),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3cf6a4,_0x44ebb4){if(typeof _0x3cf6a4!='object'||_0x3cf6a4===null)return!0x1;for(const _0x5ae7fd of _0x44ebb4)if(_0x5ae7fd in _0x3cf6a4&&typeof _0x3cf6a4[_0x5ae7fd]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x52c530,_0x217ba8){return _0x52c530+'\x20failed:\x20'+_0x217ba8+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2d124d){const _0x5bd2ea=[];let _0x1cf004=0x0;for(let _0xc7c403=0x0;_0xc7c403<_0x2d124d['length'];_0xc7c403++){let _0x3b0297=_0x2d124d['charCodeAt'](_0xc7c403);if(_0x3b0297>=0xd800&&_0x3b0297<=0xdbff){const _0x166869=_0x3b0297-0xd800;_0xc7c403++,f(_0xc7c403<_0x2d124d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x48b226=_0x2d124d['charCodeAt'](_0xc7c403)-0xdc00;_0x3b0297=0x10000+(_0x166869<<0xa)+_0x48b226;}_0x3b0297<0x80?_0x5bd2ea[_0x1cf004++]=_0x3b0297:_0x3b0297<0x800?(_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0x6|0xc0,_0x5bd2ea[_0x1cf004++]=_0x3b0297&0x3f|0x80):_0x3b0297<0x10000?(_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0xc|0xe0,_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0x6&0x3f|0x80,_0x5bd2ea[_0x1cf004++]=_0x3b0297&0x3f|0x80):(_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0x12|0xf0,_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0xc&0x3f|0x80,_0x5bd2ea[_0x1cf004++]=_0x3b0297>>0x6&0x3f|0x80,_0x5bd2ea[_0x1cf004++]=_0x3b0297&0x3f|0x80);}return _0x5bd2ea;},Pn=function(_0x537613){let _0x2dc055=0x0;for(let _0xca2cdf=0x0;_0xca2cdf<_0x537613['length'];_0xca2cdf++){const _0x37d8d7=_0x537613['charCodeAt'](_0xca2cdf);_0x37d8d7<0x80?_0x2dc055++:_0x37d8d7<0x800?_0x2dc055+=0x2:_0x37d8d7>=0xd800&&_0x37d8d7<=0xdbff?(_0x2dc055+=0x4,_0xca2cdf++):_0x2dc055+=0x3;}return _0x2dc055;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x2c9131){return _0x2c9131&&_0x2c9131['_delegate']?_0x2c9131['_delegate']:_0x2c9131;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x4f85c5){try{return(_0x4f85c5['startsWith']('http://')||_0x4f85c5['startsWith']('https://')?new URL(_0x4f85c5)['hostname']:_0x4f85c5)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x5cd8e8){return(await fetch(_0x5cd8e8,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4ad6f8,_0x513b3e,_0x2e4601){this['name']=_0x4ad6f8,this['instanceFactory']=_0x513b3e,this['type']=_0x2e4601,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x33febe){return this['instantiationMode']=_0x33febe,this;}['setMultipleInstances'](_0x1d3dca){return this['multipleInstances']=_0x1d3dca,this;}['setServiceProps'](_0x29fdc1){return this['serviceProps']=_0x29fdc1,this;}['setInstanceCreatedCallback'](_0x133256){return this['onInstanceCreated']=_0x133256,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x3fe3ff,_0x41427c){this['name']=_0x3fe3ff,this['container']=_0x41427c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x170c7f){const _0x116501=this['normalizeInstanceIdentifier'](_0x170c7f);if(!this['instancesDeferred']['has'](_0x116501)){const _0xfca117=new Ve();if(this['instancesDeferred']['set'](_0x116501,_0xfca117),this['isInitialized'](_0x116501)||this['shouldAutoInitialize']())try{const _0x13c3b7=this['getOrInitializeService']({'instanceIdentifier':_0x116501});_0x13c3b7&&_0xfca117['resolve'](_0x13c3b7);}catch{}}return this['instancesDeferred']['get'](_0x116501)['promise'];}['getImmediate'](_0x414a02){const _0x86d634=this['normalizeInstanceIdentifier'](_0x414a02==null?void 0x0:_0x414a02['identifier']),_0x4faf1d=(_0x414a02==null?void 0x0:_0x414a02['optional'])??!0x1;if(this['isInitialized'](_0x86d634)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x86d634});}catch(_0x15cd2b){if(_0x4faf1d)return null;throw _0x15cd2b;}else{if(_0x4faf1d)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x5e15c1){if(_0x5e15c1['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x5e15c1['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x5e15c1,!!this['shouldAutoInitialize']()){if(Rc(_0x5e15c1))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3bfbe3,_0x5557b8]of this['instancesDeferred']['entries']()){const _0x3d4906=this['normalizeInstanceIdentifier'](_0x3bfbe3);try{const _0x2f1a2e=this['getOrInitializeService']({'instanceIdentifier':_0x3d4906});_0x5557b8['resolve'](_0x2f1a2e);}catch{}}}}['clearInstance'](_0x36350e=ke){this['instancesDeferred']['delete'](_0x36350e),this['instancesOptions']['delete'](_0x36350e),this['instances']['delete'](_0x36350e);}async['delete'](){const _0x4f54b7=Array['from'](this['instances']['values']());await Promise['all']([..._0x4f54b7['filter'](_0xe7b48a=>'INTERNAL'in _0xe7b48a)['map'](_0x5c849f=>_0x5c849f['INTERNAL']['delete']()),..._0x4f54b7['filter'](_0x386ffb=>'_delete'in _0x386ffb)['map'](_0x1d9ae9=>_0x1d9ae9['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xaa9709=ke){return this['instances']['has'](_0xaa9709);}['getOptions'](_0x22960d=ke){return this['instancesOptions']['get'](_0x22960d)||{};}['initialize'](_0x25a6c8={}){const {options:_0x529cf4={}}=_0x25a6c8,_0x175662=this['normalizeInstanceIdentifier'](_0x25a6c8['instanceIdentifier']);if(this['isInitialized'](_0x175662))throw Error(this['name']+'('+_0x175662+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5039a8=this['getOrInitializeService']({'instanceIdentifier':_0x175662,'options':_0x529cf4});for(const [_0x565393,_0x25b833]of this['instancesDeferred']['entries']()){const _0x5ebe7d=this['normalizeInstanceIdentifier'](_0x565393);_0x175662===_0x5ebe7d&&_0x25b833['resolve'](_0x5039a8);}return _0x5039a8;}['onInit'](_0x2942aa,_0x2761d9){const _0x25616b=this['normalizeInstanceIdentifier'](_0x2761d9),_0x343cbc=this['onInitCallbacks']['get'](_0x25616b)??new Set();_0x343cbc['add'](_0x2942aa),this['onInitCallbacks']['set'](_0x25616b,_0x343cbc);const _0x5e972b=this['instances']['get'](_0x25616b);return _0x5e972b&&_0x2942aa(_0x5e972b,_0x25616b),()=>{_0x343cbc['delete'](_0x2942aa);};}['invokeOnInitCallbacks'](_0x251afd,_0x22add9){const _0x3341f4=this['onInitCallbacks']['get'](_0x22add9);if(_0x3341f4){for(const _0x506807 of _0x3341f4)try{_0x506807(_0x251afd,_0x22add9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5368b6,options:_0x3c73f8={}}){let _0x4978f9=this['instances']['get'](_0x5368b6);if(!_0x4978f9&&this['component']&&(_0x4978f9=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5368b6),'options':_0x3c73f8}),this['instances']['set'](_0x5368b6,_0x4978f9),this['instancesOptions']['set'](_0x5368b6,_0x3c73f8),this['invokeOnInitCallbacks'](_0x4978f9,_0x5368b6),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5368b6,_0x4978f9);}catch{}return _0x4978f9||null;}['normalizeInstanceIdentifier'](_0x4268ad=ke){return this['component']?this['component']['multipleInstances']?_0x4268ad:ke:_0x4268ad;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2a6b65){return _0x2a6b65===ke?void 0x0:_0x2a6b65;}function Rc(_0x3f2ed5){return _0x3f2ed5['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2a9c6d){this['name']=_0x2a9c6d,this['providers']=new Map();}['addComponent'](_0x4ffb35){const _0x1474b7=this['getProvider'](_0x4ffb35['name']);if(_0x1474b7['isComponentSet']())throw new Error('Component\x20'+_0x4ffb35['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1474b7['setComponent'](_0x4ffb35);}['addOrOverwriteComponent'](_0x451d8a){this['getProvider'](_0x451d8a['name'])['isComponentSet']()&&this['providers']['delete'](_0x451d8a['name']),this['addComponent'](_0x451d8a);}['getProvider'](_0x2731ce){if(this['providers']['has'](_0x2731ce))return this['providers']['get'](_0x2731ce);const _0x174695=new Sc(_0x2731ce,this);return this['providers']['set'](_0x2731ce,_0x174695),_0x174695;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3deec8){_0x3deec8[_0x3deec8['DEBUG']=0x0]='DEBUG',_0x3deec8[_0x3deec8['VERBOSE']=0x1]='VERBOSE',_0x3deec8[_0x3deec8['INFO']=0x2]='INFO',_0x3deec8[_0x3deec8['WARN']=0x3]='WARN',_0x3deec8[_0x3deec8['ERROR']=0x4]='ERROR',_0x3deec8[_0x3deec8['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x417bd3,_0x3537c4,..._0x3e335d)=>{if(_0x3537c4<_0x417bd3['logLevel'])return;const _0x3e2dba=new Date()['toISOString'](),_0x2abacc=Pc[_0x3537c4];if(_0x2abacc)console[_0x2abacc]('['+_0x3e2dba+']\x20\x20'+_0x417bd3['name']+':',..._0x3e335d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3537c4+')');};class xi{constructor(_0x2f17a7){this['name']=_0x2f17a7,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x359319){if(!(_0x359319 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x359319+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x359319;}['setLogLevel'](_0x1cbdcd){this['_logLevel']=typeof _0x1cbdcd=='string'?kc[_0x1cbdcd]:_0x1cbdcd;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x57d6fa){if(typeof _0x57d6fa!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x57d6fa;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x59faa9){this['_userLogHandler']=_0x59faa9;}['debug'](..._0x915140){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x915140),this['_logHandler'](this,T['DEBUG'],..._0x915140);}['log'](..._0x47707a){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x47707a),this['_logHandler'](this,T['VERBOSE'],..._0x47707a);}['info'](..._0x31391c){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x31391c),this['_logHandler'](this,T['INFO'],..._0x31391c);}['warn'](..._0x4a726d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4a726d),this['_logHandler'](this,T['WARN'],..._0x4a726d);}['error'](..._0x36cc16){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x36cc16),this['_logHandler'](this,T['ERROR'],..._0x36cc16);}}const Dc=(_0xabcfbf,_0x5a272a)=>_0x5a272a['some'](_0x19b3a0=>_0xabcfbf instanceof _0x19b3a0);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x5a728d){const _0x5b996e=new Promise((_0x1e0f3b,_0x13bc1b)=>{const _0x530705=()=>{_0x5a728d['removeEventListener']('success',_0x14c63c),_0x5a728d['removeEventListener']('error',_0x3228dd);},_0x14c63c=()=>{_0x1e0f3b(_e(_0x5a728d['result'])),_0x530705();},_0x3228dd=()=>{_0x13bc1b(_0x5a728d['error']),_0x530705();};_0x5a728d['addEventListener']('success',_0x14c63c),_0x5a728d['addEventListener']('error',_0x3228dd);});return _0x5b996e['then'](_0x5e31b9=>{_0x5e31b9 instanceof IDBCursor&&Kr['set'](_0x5e31b9,_0x5a728d);})['catch'](()=>{}),Fi['set'](_0x5b996e,_0x5a728d),_0x5b996e;}function Fc(_0x5720b0){if(ui['has'](_0x5720b0))return;const _0xcbe93a=new Promise((_0x374537,_0x20b4b3)=>{const _0xff8e2=()=>{_0x5720b0['removeEventListener']('complete',_0x4a3640),_0x5720b0['removeEventListener']('error',_0xdf1abc),_0x5720b0['removeEventListener']('abort',_0xdf1abc);},_0x4a3640=()=>{_0x374537(),_0xff8e2();},_0xdf1abc=()=>{_0x20b4b3(_0x5720b0['error']||new DOMException('AbortError','AbortError')),_0xff8e2();};_0x5720b0['addEventListener']('complete',_0x4a3640),_0x5720b0['addEventListener']('error',_0xdf1abc),_0x5720b0['addEventListener']('abort',_0xdf1abc);});ui['set'](_0x5720b0,_0xcbe93a);}let di={'get'(_0x5c51ac,_0x2b1e42,_0x478b33){if(_0x5c51ac instanceof IDBTransaction){if(_0x2b1e42==='done')return ui['get'](_0x5c51ac);if(_0x2b1e42==='objectStoreNames')return _0x5c51ac['objectStoreNames']||Yr['get'](_0x5c51ac);if(_0x2b1e42==='store')return _0x478b33['objectStoreNames'][0x1]?void 0x0:_0x478b33['objectStore'](_0x478b33['objectStoreNames'][0x0]);}return _e(_0x5c51ac[_0x2b1e42]);},'set'(_0x5d1cb7,_0x4120af,_0x50cc7d){return _0x5d1cb7[_0x4120af]=_0x50cc7d,!0x0;},'has'(_0xc1c2f0,_0x128e3b){return _0xc1c2f0 instanceof IDBTransaction&&(_0x128e3b==='done'||_0x128e3b==='store')?!0x0:_0x128e3b in _0xc1c2f0;}};function Uc(_0x5cafea){di=_0x5cafea(di);}function Wc(_0x336b82){return _0x336b82===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2c75fd,..._0x15fb4f){const _0x33f172=_0x336b82['call'](Xn(this),_0x2c75fd,..._0x15fb4f);return Yr['set'](_0x33f172,_0x2c75fd['sort']?_0x2c75fd['sort']():[_0x2c75fd]),_e(_0x33f172);}:Lc()['includes'](_0x336b82)?function(..._0x5a6614){return _0x336b82['apply'](Xn(this),_0x5a6614),_e(Kr['get'](this));}:function(..._0x242901){return _e(_0x336b82['apply'](Xn(this),_0x242901));};}function Bc(_0x2352a3){return typeof _0x2352a3=='function'?Wc(_0x2352a3):(_0x2352a3 instanceof IDBTransaction&&Fc(_0x2352a3),Dc(_0x2352a3,Mc())?new Proxy(_0x2352a3,di):_0x2352a3);}function _e(_0x4dd359){if(_0x4dd359 instanceof IDBRequest)return xc(_0x4dd359);if(Jn['has'](_0x4dd359))return Jn['get'](_0x4dd359);const _0x344ef7=Bc(_0x4dd359);return _0x344ef7!==_0x4dd359&&(Jn['set'](_0x4dd359,_0x344ef7),Fi['set'](_0x344ef7,_0x4dd359)),_0x344ef7;}const Xn=_0x603788=>Fi['get'](_0x603788);function Vc(_0x4e9f18,_0x3bdb8d,{blocked:_0x29b316,upgrade:_0x23c107,blocking:_0x1dacbf,terminated:_0x473d27}={}){const _0x1d28f3=indexedDB['open'](_0x4e9f18,_0x3bdb8d),_0x123572=_e(_0x1d28f3);return _0x23c107&&_0x1d28f3['addEventListener']('upgradeneeded',_0x5856bc=>{_0x23c107(_e(_0x1d28f3['result']),_0x5856bc['oldVersion'],_0x5856bc['newVersion'],_e(_0x1d28f3['transaction']),_0x5856bc);}),_0x29b316&&_0x1d28f3['addEventListener']('blocked',_0x575a39=>_0x29b316(_0x575a39['oldVersion'],_0x575a39['newVersion'],_0x575a39)),_0x123572['then'](_0x30b3d7=>{_0x473d27&&_0x30b3d7['addEventListener']('close',()=>_0x473d27()),_0x1dacbf&&_0x30b3d7['addEventListener']('versionchange',_0x3eb209=>_0x1dacbf(_0x3eb209['oldVersion'],_0x3eb209['newVersion'],_0x3eb209));})['catch'](()=>{}),_0x123572;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1f8c38,_0x2246f1){if(!(_0x1f8c38 instanceof IDBDatabase&&!(_0x2246f1 in _0x1f8c38)&&typeof _0x2246f1=='string'))return;if(Zn['get'](_0x2246f1))return Zn['get'](_0x2246f1);const _0xf26abf=_0x2246f1['replace'](/FromIndex$/,''),_0x1152fe=_0x2246f1!==_0xf26abf,_0x198759=$c['includes'](_0xf26abf);if(!(_0xf26abf in(_0x1152fe?IDBIndex:IDBObjectStore)['prototype'])||!(_0x198759||Hc['includes'](_0xf26abf)))return;const _0x115de8=async function(_0x2d9574,..._0x423d7a){const _0x27078c=this['transaction'](_0x2d9574,_0x198759?'readwrite':'readonly');let _0x6c2a4b=_0x27078c['store'];return _0x1152fe&&(_0x6c2a4b=_0x6c2a4b['index'](_0x423d7a['shift']())),(await Promise['all']([_0x6c2a4b[_0xf26abf](..._0x423d7a),_0x198759&&_0x27078c['done']]))[0x0];};return Zn['set'](_0x2246f1,_0x115de8),_0x115de8;}Uc(_0x4e3065=>({..._0x4e3065,'get':(_0x235186,_0x44ac02,_0x4cc7cf)=>Os(_0x235186,_0x44ac02)||_0x4e3065['get'](_0x235186,_0x44ac02,_0x4cc7cf),'has':(_0x4303c0,_0x2c05e5)=>!!Os(_0x4303c0,_0x2c05e5)||_0x4e3065['has'](_0x4303c0,_0x2c05e5)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0xa51a63){this['container']=_0xa51a63;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x260478=>{if(qc(_0x260478)){const _0x125594=_0x260478['getImmediate']();return _0x125594['library']+'/'+_0x125594['version'];}else return null;})['filter'](_0x485b9e=>_0x485b9e)['join']('\x20');}}function qc(_0x48a90e){const _0x56ba97=_0x48a90e['getComponent']();return(_0x56ba97==null?void 0x0:_0x56ba97['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x5104e9,_0x39308e){try{_0x5104e9['container']['addComponent'](_0x39308e);}catch(_0x3b87b4){re['debug']('Component\x20'+_0x39308e['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5104e9['name'],_0x3b87b4);}}function et(_0x38c218){const _0x4cf8e2=_0x38c218['name'];if(gi['has'](_0x4cf8e2))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4cf8e2+'.'),!0x1;gi['set'](_0x4cf8e2,_0x38c218);for(const _0x212a62 of Le['values']())Ms(_0x212a62,_0x38c218);for(const _0x42b72c of _i['values']())Ms(_0x42b72c,_0x38c218);return!0x0;}function Ui(_0x1577fd,_0x7fe409){const _0x730e5a=_0x1577fd['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x730e5a&&_0x730e5a['triggerHeartbeat'](),_0x1577fd['container']['getProvider'](_0x7fe409);}function H(_0x5aed66){return _0x5aed66==null?!0x1:_0x5aed66['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x3534ed,_0x476b5f,_0x493aad){this['_isDeleted']=!0x1,this['_options']={..._0x3534ed},this['_config']={..._0x476b5f},this['_name']=_0x476b5f['name'],this['_automaticDataCollectionEnabled']=_0x476b5f['automaticDataCollectionEnabled'],this['_container']=_0x493aad,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2e96ef){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2e96ef;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x409c93){this['_isDeleted']=_0x409c93;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x7830c0,_0x77e64={}){let _0x7dec7a=_0x7830c0;typeof _0x77e64!='object'&&(_0x77e64={'name':_0x77e64});const _0x1b5272={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x77e64},_0x5e60a4=_0x1b5272['name'];if(typeof _0x5e60a4!='string'||!_0x5e60a4)throw ge['create']('bad-app-name',{'appName':String(_0x5e60a4)});if(_0x7dec7a||(_0x7dec7a=$r()),!_0x7dec7a)throw ge['create']('no-options');const _0x36742d=Le['get'](_0x5e60a4);if(_0x36742d){if(De(_0x7dec7a,_0x36742d['options'])&&De(_0x1b5272,_0x36742d['config']))return _0x36742d;throw ge['create']('duplicate-app',{'appName':_0x5e60a4});}const _0x56fc7f=new Ac(_0x5e60a4);for(const _0x2e3abf of gi['values']())_0x56fc7f['addComponent'](_0x2e3abf);const _0x253b9d=new Il(_0x7dec7a,_0x1b5272,_0x56fc7f);return Le['set'](_0x5e60a4,_0x253b9d),_0x253b9d;}function Qr(_0xe01b76=pi){const _0x252c5c=Le['get'](_0xe01b76);if(!_0x252c5c&&_0xe01b76===pi&&$r())return wl();if(!_0x252c5c)throw ge['create']('no-app',{'appName':_0xe01b76});return _0x252c5c;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5a906b){let _0x391135=!0x1;const _0x258b64=_0x5a906b['name'];Le['has'](_0x258b64)?(_0x391135=!0x0,Le['delete'](_0x258b64)):_i['has'](_0x258b64)&&_0x5a906b['decRefCount']()<=0x0&&(_i['delete'](_0x258b64),_0x391135=!0x0),_0x391135&&(await Promise['all'](_0x5a906b['container']['getProviders']()['map'](_0x49051e=>_0x49051e['delete']())),_0x5a906b['isDeleted']=!0x0);}function me(_0x29e3b4,_0x4cb887,_0x122447){let _0x211d72=vl[_0x29e3b4]??_0x29e3b4;_0x122447&&(_0x211d72+='-'+_0x122447);const _0x4cdff0=_0x211d72['match'](/\s|\//),_0x3ba697=_0x4cb887['match'](/\s|\//);if(_0x4cdff0||_0x3ba697){const _0x44fc5e=['Unable\x20to\x20register\x20library\x20\x22'+_0x211d72+'\x22\x20with\x20version\x20\x22'+_0x4cb887+'\x22:'];_0x4cdff0&&_0x44fc5e['push']('library\x20name\x20\x22'+_0x211d72+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4cdff0&&_0x3ba697&&_0x44fc5e['push']('and'),_0x3ba697&&_0x44fc5e['push']('version\x20name\x20\x22'+_0x4cb887+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x44fc5e['join']('\x20'));return;}et(new Me(_0x211d72+'-version',()=>({'library':_0x211d72,'version':_0x4cb887}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x129fee,_0x36352b)=>{switch(_0x36352b){case 0x0:try{_0x129fee['createObjectStore'](Rt);}catch(_0x43d74){console['warn'](_0x43d74);}}}})['catch'](_0x383ef4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x383ef4['message']});})),ei;}async function Sl(_0xede9df){try{const _0x2d6ff1=(await Jr())['transaction'](Rt),_0x455b16=await _0x2d6ff1['objectStore'](Rt)['get'](Xr(_0xede9df));return await _0x2d6ff1['done'],_0x455b16;}catch(_0x20c2f4){if(_0x20c2f4 instanceof Se)re['warn'](_0x20c2f4['message']);else{const _0x755b0e=ge['create']('idb-get',{'originalErrorMessage':_0x20c2f4==null?void 0x0:_0x20c2f4['message']});re['warn'](_0x755b0e['message']);}}}async function Ls(_0x24953f,_0x1e1b39){try{const _0x4f07b4=(await Jr())['transaction'](Rt,'readwrite');await _0x4f07b4['objectStore'](Rt)['put'](_0x1e1b39,Xr(_0x24953f)),await _0x4f07b4['done'];}catch(_0x3c85bb){if(_0x3c85bb instanceof Se)re['warn'](_0x3c85bb['message']);else{const _0x340937=ge['create']('idb-set',{'originalErrorMessage':_0x3c85bb==null?void 0x0:_0x3c85bb['message']});re['warn'](_0x340937['message']);}}}function Xr(_0x55676f){return _0x55676f['name']+'!'+_0x55676f['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x532633){this['container']=_0x532633,this['_heartbeatsCache']=null;const _0x8c5890=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x8c5890),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x25dff6=>(this['_heartbeatsCache']=_0x25dff6,_0x25dff6));}async['triggerHeartbeat'](){var _0x25b872,_0x5c36b5;try{const _0x539b9e=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x803b21=xs();if(((_0x25b872=this['_heartbeatsCache'])==null?void 0x0:_0x25b872['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5c36b5=this['_heartbeatsCache'])==null?void 0x0:_0x5c36b5['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x803b21||this['_heartbeatsCache']['heartbeats']['some'](_0x542f32=>_0x542f32['date']===_0x803b21))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x803b21,'agent':_0x539b9e}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x5129ba=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5129ba,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x581cdb){re['warn'](_0x581cdb);}}async['getHeartbeatsHeader'](){var _0xa62d55;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xa62d55=this['_heartbeatsCache'])==null?void 0x0:_0xa62d55['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x49406c=xs(),{heartbeatsToSend:_0x3d77c4,unsentEntries:_0x7b439c}=kl(this['_heartbeatsCache']['heartbeats']),_0x115b35=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3d77c4}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x49406c,_0x7b439c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x7b439c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x115b35;}catch(_0x2ea3c5){return re['warn'](_0x2ea3c5),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x5b39a4,_0x56bd95=bl){const _0x106e24=[];let _0x107dc0=_0x5b39a4['slice']();for(const _0x12faa7 of _0x5b39a4){const _0x41d23f=_0x106e24['find'](_0x4d5b97=>_0x4d5b97['agent']===_0x12faa7['agent']);if(_0x41d23f){if(_0x41d23f['dates']['push'](_0x12faa7['date']),Fs(_0x106e24)>_0x56bd95){_0x41d23f['dates']['pop']();break;}}else{if(_0x106e24['push']({'agent':_0x12faa7['agent'],'dates':[_0x12faa7['date']]}),Fs(_0x106e24)>_0x56bd95){_0x106e24['pop']();break;}}_0x107dc0=_0x107dc0['slice'](0x1);}return{'heartbeatsToSend':_0x106e24,'unsentEntries':_0x107dc0};}class Nl{constructor(_0x1dadba){this['app']=_0x1dadba,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3c8162=await Sl(this['app']);return _0x3c8162!=null&&_0x3c8162['heartbeats']?_0x3c8162:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x36ab7b){if(await this['_canUseIndexedDBPromise']){const _0xcd89af=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x36ab7b['lastSentHeartbeatDate']??_0xcd89af['lastSentHeartbeatDate'],'heartbeats':_0x36ab7b['heartbeats']});}else return;}async['add'](_0x31782f){if(await this['_canUseIndexedDBPromise']){const _0x115c89=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x31782f['lastSentHeartbeatDate']??_0x115c89['lastSentHeartbeatDate'],'heartbeats':[..._0x115c89['heartbeats'],..._0x31782f['heartbeats']]});}else return;}}function Fs(_0x1d10f0){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1d10f0}))['length'];}function Pl(_0x575d23){if(_0x575d23['length']===0x0)return-0x1;let _0x5b96a5=0x0,_0x3d9972=_0x575d23[0x0]['date'];for(let _0x34aed8=0x1;_0x34aed8<_0x575d23['length'];_0x34aed8++)_0x575d23[_0x34aed8]['date']<_0x3d9972&&(_0x3d9972=_0x575d23[_0x34aed8]['date'],_0x5b96a5=_0x34aed8);return _0x5b96a5;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4d6503){et(new Me('platform-logger',_0x1fd5d4=>new Gc(_0x1fd5d4),'PRIVATE')),et(new Me('heartbeat',_0x12a17a=>new Al(_0x12a17a),'PRIVATE')),me(fi,Ds,_0x4d6503),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x1d4f7c){Zr=_0x1d4f7c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x4db722){this['domStorage_']=_0x4db722,this['prefix_']='firebase:';}['set'](_0x17e3d7,_0x90c16b){_0x90c16b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x17e3d7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x17e3d7),O(_0x90c16b));}['get'](_0x437192){const _0x36e3fd=this['domStorage_']['getItem'](this['prefixedName_'](_0x437192));return _0x36e3fd==null?null:bt(_0x36e3fd);}['remove'](_0xada428){this['domStorage_']['removeItem'](this['prefixedName_'](_0xada428));}['prefixedName_'](_0x47f26b){return this['prefix_']+_0x47f26b;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x186e72,_0x5307c6){_0x5307c6==null?delete this['cache_'][_0x186e72]:this['cache_'][_0x186e72]=_0x5307c6;}['get'](_0x5db997){return Y(this['cache_'],_0x5db997)?this['cache_'][_0x5db997]:null;}['remove'](_0x4f3e31){delete this['cache_'][_0x4f3e31];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5a302b){try{if(typeof window<'u'&&typeof window[_0x5a302b]<'u'){const _0x184e47=window[_0x5a302b];return _0x184e47['setItem']('firebase:sentinel','cache'),_0x184e47['removeItem']('firebase:sentinel'),new xl(_0x184e47);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x5e0a10=0x1;return function(){return _0x5e0a10++;};}()),no=function(_0xb23547){const _0x36e38f=Tc(_0xb23547),_0x5e7a56=new Ec();_0x5e7a56['update'](_0x36e38f);const _0x943b4f=_0x5e7a56['digest']();return Di['encodeByteArray'](_0x943b4f);},Bt=function(..._0x1ad7a5){let _0x5d0f40='';for(let _0x48126b=0x0;_0x48126b<_0x1ad7a5['length'];_0x48126b++){const _0x5563df=_0x1ad7a5[_0x48126b];Array['isArray'](_0x5563df)||_0x5563df&&typeof _0x5563df=='object'&&typeof _0x5563df['length']=='number'?_0x5d0f40+=Bt['apply'](null,_0x5563df):typeof _0x5563df=='object'?_0x5d0f40+=O(_0x5563df):_0x5d0f40+=_0x5563df,_0x5d0f40+='\x20';}return _0x5d0f40;};let Et=null,Vs=!0x0;const Wl=function(_0x4a9da4,_0x1e1539){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x31ee02){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x17f233=Bt['apply'](null,_0x31ee02);Et(_0x17f233);}},Vt=function(_0xf1ecc0){return function(..._0x383ba8){L(_0xf1ecc0,..._0x383ba8);};},mi=function(..._0x25c864){const _0x272aa8='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x25c864);Qe['error'](_0x272aa8);},oe=function(..._0x134abf){const _0x34fcd6='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x134abf);throw Qe['error'](_0x34fcd6),new Error(_0x34fcd6);},U=function(..._0x228fed){const _0x23c42b='FIREBASE\x20WARNING:\x20'+Bt(..._0x228fed);Qe['warn'](_0x23c42b);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x46c2b6){return typeof _0x46c2b6=='number'&&(_0x46c2b6!==_0x46c2b6||_0x46c2b6===Number['POSITIVE_INFINITY']||_0x46c2b6===Number['NEGATIVE_INFINITY']);},Vl=function(_0x5d353c){if(document['readyState']==='complete')_0x5d353c();else{let _0x34f313=!0x1;const _0x488c50=function(){if(!document['body']){setTimeout(_0x488c50,Math['floor'](0xa));return;}_0x34f313||(_0x34f313=!0x0,_0x5d353c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x488c50,!0x1),window['addEventListener']('load',_0x488c50,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x488c50();}),window['attachEvent']('onload',_0x488c50));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4e4302,_0x587161){if(_0x4e4302===_0x587161)return 0x0;if(_0x4e4302===xe||_0x587161===Ie)return-0x1;if(_0x587161===xe||_0x4e4302===Ie)return 0x1;{const _0x27d77b=Hs(_0x4e4302),_0x29572c=Hs(_0x587161);return _0x27d77b!==null?_0x29572c!==null?_0x27d77b-_0x29572c===0x0?_0x4e4302['length']-_0x587161['length']:_0x27d77b-_0x29572c:-0x1:_0x29572c!==null?0x1:_0x4e4302<_0x587161?-0x1:0x1;}},Hl=function(_0x142679,_0xec8c7){return _0x142679===_0xec8c7?0x0:_0x142679<_0xec8c7?-0x1:0x1;},pt=function(_0x390226,_0x5a833e){if(_0x5a833e&&_0x390226 in _0x5a833e)return _0x5a833e[_0x390226];throw new Error('Missing\x20required\x20key\x20('+_0x390226+')\x20in\x20object:\x20'+O(_0x5a833e));},Bi=function(_0x149ddf){if(typeof _0x149ddf!='object'||_0x149ddf===null)return O(_0x149ddf);const _0x2b1865=[];for(const _0x547e9a in _0x149ddf)_0x2b1865['push'](_0x547e9a);_0x2b1865['sort']();let _0x189d1e='{';for(let _0x21d66f=0x0;_0x21d66f<_0x2b1865['length'];_0x21d66f++)_0x21d66f!==0x0&&(_0x189d1e+=','),_0x189d1e+=O(_0x2b1865[_0x21d66f]),_0x189d1e+=':',_0x189d1e+=Bi(_0x149ddf[_0x2b1865[_0x21d66f]]);return _0x189d1e+='}',_0x189d1e;},io=function(_0x2febb3,_0x490083){const _0x199434=_0x2febb3['length'];if(_0x199434<=_0x490083)return[_0x2febb3];const _0x4423ce=[];for(let _0x3de1d7=0x0;_0x3de1d7<_0x199434;_0x3de1d7+=_0x490083)_0x3de1d7+_0x490083>_0x199434?_0x4423ce['push'](_0x2febb3['substring'](_0x3de1d7,_0x199434)):_0x4423ce['push'](_0x2febb3['substring'](_0x3de1d7,_0x3de1d7+_0x490083));return _0x4423ce;};function x(_0x4be0fe,_0x291184){for(const _0x24052a in _0x4be0fe)_0x4be0fe['hasOwnProperty'](_0x24052a)&&_0x291184(_0x24052a,_0x4be0fe[_0x24052a]);}const so=function(_0x202910){f(!Wi(_0x202910),'Invalid\x20JSON\x20number');const _0x5839f6=0xb,_0x5cd993=0x34,_0x7eb0b2=(0x1<<_0x5839f6-0x1)-0x1;let _0x221a94,_0x22695c,_0x3630c5,_0x2a9fad,_0x3d66b2;_0x202910===0x0?(_0x22695c=0x0,_0x3630c5=0x0,_0x221a94=0x1/_0x202910===-0x1/0x0?0x1:0x0):(_0x221a94=_0x202910<0x0,_0x202910=Math['abs'](_0x202910),_0x202910>=Math['pow'](0x2,0x1-_0x7eb0b2)?(_0x2a9fad=Math['min'](Math['floor'](Math['log'](_0x202910)/Math['LN2']),_0x7eb0b2),_0x22695c=_0x2a9fad+_0x7eb0b2,_0x3630c5=Math['round'](_0x202910*Math['pow'](0x2,_0x5cd993-_0x2a9fad)-Math['pow'](0x2,_0x5cd993))):(_0x22695c=0x0,_0x3630c5=Math['round'](_0x202910/Math['pow'](0x2,0x1-_0x7eb0b2-_0x5cd993))));const _0x4efbd1=[];for(_0x3d66b2=_0x5cd993;_0x3d66b2;_0x3d66b2-=0x1)_0x4efbd1['push'](_0x3630c5%0x2?0x1:0x0),_0x3630c5=Math['floor'](_0x3630c5/0x2);for(_0x3d66b2=_0x5839f6;_0x3d66b2;_0x3d66b2-=0x1)_0x4efbd1['push'](_0x22695c%0x2?0x1:0x0),_0x22695c=Math['floor'](_0x22695c/0x2);_0x4efbd1['push'](_0x221a94?0x1:0x0),_0x4efbd1['reverse']();const _0x4f6f9f=_0x4efbd1['join']('');let _0x29639b='';for(_0x3d66b2=0x0;_0x3d66b2<0x40;_0x3d66b2+=0x8){let _0x247945=parseInt(_0x4f6f9f['substr'](_0x3d66b2,0x8),0x2)['toString'](0x10);_0x247945['length']===0x1&&(_0x247945='0'+_0x247945),_0x29639b=_0x29639b+_0x247945;}return _0x29639b['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x5ca6fc,_0x578aaf){let _0x4e64f8='Unknown\x20Error';_0x5ca6fc==='too_big'?_0x4e64f8='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5ca6fc==='permission_denied'?_0x4e64f8='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5ca6fc==='unavailable'&&(_0x4e64f8='The\x20service\x20is\x20unavailable');const _0x2b3b95=new Error(_0x5ca6fc+'\x20at\x20'+_0x578aaf['_path']['toString']()+':\x20'+_0x4e64f8);return _0x2b3b95['code']=_0x5ca6fc['toUpperCase'](),_0x2b3b95;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2def3f){if(zl['test'](_0x2def3f)){const _0x307658=Number(_0x2def3f);if(_0x307658>=jl&&_0x307658<=Kl)return _0x307658;}return null;},lt=function(_0x154ae6){try{_0x154ae6();}catch(_0xdc2701){setTimeout(()=>{const _0xebacd8=_0xdc2701['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xebacd8),_0xdc2701;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x8de8f0,_0x36befd){const _0x5d41c0=setTimeout(_0x8de8f0,_0x36befd);return typeof _0x5d41c0=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5d41c0):typeof _0x5d41c0=='object'&&_0x5d41c0['unref']&&_0x5d41c0['unref'](),_0x5d41c0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x576082,_0x47f8f7){this['appCheckProvider']=_0x47f8f7,this['appName']=_0x576082['name'],H(_0x576082)&&_0x576082['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x576082['settings']['appCheckToken']),this['appCheck']=_0x47f8f7==null?void 0x0:_0x47f8f7['getImmediate']({'optional':!0x0}),this['appCheck']||_0x47f8f7==null||_0x47f8f7['get']()['then'](_0x4ba1c8=>this['appCheck']=_0x4ba1c8);}['getToken'](_0x4f389d){if(this['serverAppAppCheckToken']){if(_0x4f389d)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x4f389d):new Promise((_0x3c3ea4,_0x24a843)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x4f389d)['then'](_0x3c3ea4,_0x24a843):_0x3c3ea4(null);},0x0);});}['addTokenChangeListener'](_0x22a8b3){var _0x93bbb3;(_0x93bbb3=this['appCheckProvider'])==null||_0x93bbb3['get']()['then'](_0x4bac69=>_0x4bac69['addTokenListener'](_0x22a8b3));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4b03a3,_0x4c0990,_0x34741e){this['appName_']=_0x4b03a3,this['firebaseOptions_']=_0x4c0990,this['authProvider_']=_0x34741e,this['auth_']=null,this['auth_']=_0x34741e['getImmediate']({'optional':!0x0}),this['auth_']||_0x34741e['onInit'](_0x3be19c=>this['auth_']=_0x3be19c);}['getToken'](_0x38725b){return this['auth_']?this['auth_']['getToken'](_0x38725b)['catch'](_0x2cc648=>_0x2cc648&&_0x2cc648['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2cc648)):new Promise((_0x5b57b0,_0x45e6b1)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x38725b)['then'](_0x5b57b0,_0x45e6b1):_0x5b57b0(null);},0x0);});}['addTokenChangeListener'](_0xee566a){this['auth_']?this['auth_']['addAuthTokenListener'](_0xee566a):this['authProvider_']['get']()['then'](_0x4faf8e=>_0x4faf8e['addAuthTokenListener'](_0xee566a));}['removeTokenChangeListener'](_0xdd86af){this['authProvider_']['get']()['then'](_0x2c5eac=>_0x2c5eac['removeAuthTokenListener'](_0xdd86af));}['notifyForInvalidToken'](){let _0x2e120d='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2e120d+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2e120d+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2e120d+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2e120d);}}class tn{constructor(_0x41090b){this['accessToken']=_0x41090b;}['getToken'](_0x4326ec){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x193615){_0x193615(this['accessToken']);}['removeTokenChangeListener'](_0x54b25d){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x3919be,_0x317602,_0x5d1a1d,_0x22ac90,_0x449e0a=!0x1,_0x482d9a='',_0x61c70f=!0x1,_0x5d05bb=!0x1,_0x1e3fb0=null){this['secure']=_0x317602,this['namespace']=_0x5d1a1d,this['webSocketOnly']=_0x22ac90,this['nodeAdmin']=_0x449e0a,this['persistenceKey']=_0x482d9a,this['includeNamespaceInQueryParams']=_0x61c70f,this['isUsingEmulator']=_0x5d05bb,this['emulatorOptions']=_0x1e3fb0,this['_host']=_0x3919be['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x3919be)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x49c3e2){_0x49c3e2!==this['internalHost']&&(this['internalHost']=_0x49c3e2,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3fe608=this['toURLString']();return this['persistenceKey']&&(_0x3fe608+='<'+this['persistenceKey']+'>'),_0x3fe608;}['toURLString'](){const _0x5e3358=this['secure']?'https://':'http://',_0x28c221=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5e3358+this['host']+'/'+_0x28c221;}}function Xl(_0x559e28){return _0x559e28['host']!==_0x559e28['internalHost']||_0x559e28['isCustomHost']()||_0x559e28['includeNamespaceInQueryParams'];}function go(_0xd2da65,_0x4d5e0a,_0x3dd9aa){f(typeof _0x4d5e0a=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3dd9aa=='object','typeof\x20params\x20must\x20==\x20object');let _0x3330a8;if(_0x4d5e0a===fo)_0x3330a8=(_0xd2da65['secure']?'wss://':'ws://')+_0xd2da65['internalHost']+'/.ws?';else{if(_0x4d5e0a===po)_0x3330a8=(_0xd2da65['secure']?'https://':'http://')+_0xd2da65['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4d5e0a);}Xl(_0xd2da65)&&(_0x3dd9aa['ns']=_0xd2da65['namespace']);const _0x1947f1=[];return x(_0x3dd9aa,(_0x4cd048,_0x78c6d0)=>{_0x1947f1['push'](_0x4cd048+'='+_0x78c6d0);}),_0x3330a8+_0x1947f1['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5851d8,_0x5991b0=0x1){Y(this['counters_'],_0x5851d8)||(this['counters_'][_0x5851d8]=0x0),this['counters_'][_0x5851d8]+=_0x5991b0;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x349c3f){const _0x515a00=_0x349c3f['toString']();return ti[_0x515a00]||(ti[_0x515a00]=new Zl()),ti[_0x515a00];}function eh(_0x4cbea4,_0x313bc6){const _0x457c22=_0x4cbea4['toString']();return ni[_0x457c22]||(ni[_0x457c22]=_0x313bc6()),ni[_0x457c22];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x47b307){this['onMessage_']=_0x47b307,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x215da2,_0x3c5ac1){this['closeAfterResponse']=_0x215da2,this['onClose']=_0x3c5ac1,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x22bc44,_0x691085){for(this['pendingResponses'][_0x22bc44]=_0x691085;this['pendingResponses'][this['currentResponseNum']];){const _0x4e4ea4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5e74f1=0x0;_0x5e74f1<_0x4e4ea4['length'];++_0x5e74f1)_0x4e4ea4[_0x5e74f1]&&lt(()=>{this['onMessage_'](_0x4e4ea4[_0x5e74f1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x57238d,_0x3bf589,_0x8d66b3,_0x28c64d,_0x23e547,_0xa659fb,_0x5944c1){this['connId']=_0x57238d,this['repoInfo']=_0x3bf589,this['applicationId']=_0x8d66b3,this['appCheckToken']=_0x28c64d,this['authToken']=_0x23e547,this['transportSessionId']=_0xa659fb,this['lastSessionId']=_0x5944c1,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x57238d),this['stats_']=Hi(_0x3bf589),this['urlFn']=_0x112597=>(this['appCheckToken']&&(_0x112597[yi]=this['appCheckToken']),go(_0x3bf589,po,_0x112597));}['open'](_0x74d392,_0x391142){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x391142,this['myPacketOrderer']=new th(_0x74d392),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x395e7f)=>{const [_0x4f679e,_0x1f2091,_0x4f9540,_0x2441b9,_0x14e8d6]=_0x395e7f;if(this['incrementIncomingBytes_'](_0x395e7f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4f679e===$s)this['id']=_0x1f2091,this['password']=_0x4f9540;else{if(_0x4f679e===nh)_0x1f2091?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1f2091,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4f679e);}}},(..._0x4b4a05)=>{const [_0x51cfe1,_0x58d498]=_0x4b4a05;this['incrementIncomingBytes_'](_0x4b4a05),this['myPacketOrderer']['handleResponse'](_0x51cfe1,_0x58d498);},()=>{this['onClosed_']();},this['urlFn']);const _0x56bb4a={};_0x56bb4a[$s]='t',_0x56bb4a[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x56bb4a[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x56bb4a[ro]=Vi,this['transportSessionId']&&(_0x56bb4a[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x56bb4a[ho]=this['lastSessionId']),this['applicationId']&&(_0x56bb4a[uo]=this['applicationId']),this['appCheckToken']&&(_0x56bb4a[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x56bb4a[ao]=co);const _0x1f3436=this['urlFn'](_0x56bb4a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1f3436),this['scriptTagHolder']['addTag'](_0x1f3436,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x275709){const _0x4777a1=O(_0x275709);this['bytesSent']+=_0x4777a1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4777a1['length']);const _0xaf0647=Br(_0x4777a1),_0xee3d23=io(_0xaf0647,hh);for(let _0xca1e30=0x0;_0xca1e30<_0xee3d23['length'];_0xca1e30++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xee3d23['length'],_0xee3d23[_0xca1e30]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xccddc0,_0x40cd14){this['myDisconnFrame']=document['createElement']('iframe');const _0xbb843={};_0xbb843[lh]='t',_0xbb843[mo]=_0xccddc0,_0xbb843[yo]=_0x40cd14,this['myDisconnFrame']['src']=this['urlFn'](_0xbb843),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5a0642){const _0x584409=O(_0x5a0642)['length'];this['bytesReceived']+=_0x584409,this['stats_']['incrementCounter']('bytes_received',_0x584409);}}class $i{constructor(_0xac7dbf,_0x292212,_0x292def,_0x561332){this['onDisconnect']=_0x292def,this['urlFn']=_0x561332,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0xac7dbf,window[sh+this['uniqueCallbackIdentifier']]=_0x292212,this['myIFrame']=$i['createIFrame_']();let _0x3e7d7b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3e7d7b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xaa868a='<html><body>'+_0x3e7d7b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xaa868a),this['myIFrame']['doc']['close']();}catch(_0x4bd52b){L('frame\x20writing\x20exception'),_0x4bd52b['stack']&&L(_0x4bd52b['stack']),L(_0x4bd52b);}}}static['createIFrame_'](){const _0x469e21=document['createElement']('iframe');if(_0x469e21['style']['display']='none',document['body']){document['body']['appendChild'](_0x469e21);try{_0x469e21['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5e45d0=document['domain'];_0x469e21['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5e45d0+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x469e21['contentDocument']?_0x469e21['doc']=_0x469e21['contentDocument']:_0x469e21['contentWindow']?_0x469e21['doc']=_0x469e21['contentWindow']['document']:_0x469e21['document']&&(_0x469e21['doc']=_0x469e21['document']),_0x469e21;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3789c4=this['onDisconnect'];_0x3789c4&&(this['onDisconnect']=null,_0x3789c4());}['startLongPoll'](_0x757c9b,_0x573778){for(this['myID']=_0x757c9b,this['myPW']=_0x573778,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5465dd={};_0x5465dd[mo]=this['myID'],_0x5465dd[yo]=this['myPW'],_0x5465dd[vo]=this['currentSerial'];let _0x1dab41=this['urlFn'](_0x5465dd),_0x2d0828='',_0x50a47d=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2d0828['length']<=Eo;){const _0x3a3f6d=this['pendingSegs']['shift']();_0x2d0828=_0x2d0828+'&'+oh+_0x50a47d+'='+_0x3a3f6d['seg']+'&'+ah+_0x50a47d+'='+_0x3a3f6d['ts']+'&'+ch+_0x50a47d+'='+_0x3a3f6d['d'],_0x50a47d++;}return _0x1dab41=_0x1dab41+_0x2d0828,this['addLongPollTag_'](_0x1dab41,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3787e4,_0x5dadd1,_0x4eb23){this['pendingSegs']['push']({'seg':_0x3787e4,'ts':_0x5dadd1,'d':_0x4eb23}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x47c005,_0x4aebd0){this['outstandingRequests']['add'](_0x4aebd0);const _0x5221ad=()=>{this['outstandingRequests']['delete'](_0x4aebd0),this['newRequest_']();},_0xfcd9d7=setTimeout(_0x5221ad,Math['floor'](uh)),_0xc86bcd=()=>{clearTimeout(_0xfcd9d7),_0x5221ad();};this['addTag'](_0x47c005,_0xc86bcd);}['addTag'](_0x5596aa,_0x22395f){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x11b2b0=this['myIFrame']['doc']['createElement']('script');_0x11b2b0['type']='text/javascript',_0x11b2b0['async']=!0x0,_0x11b2b0['src']=_0x5596aa,_0x11b2b0['onload']=_0x11b2b0['onreadystatechange']=function(){const _0x2c4a89=_0x11b2b0['readyState'];(!_0x2c4a89||_0x2c4a89==='loaded'||_0x2c4a89==='complete')&&(_0x11b2b0['onload']=_0x11b2b0['onreadystatechange']=null,_0x11b2b0['parentNode']&&_0x11b2b0['parentNode']['removeChild'](_0x11b2b0),_0x22395f());},_0x11b2b0['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5596aa),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x11b2b0);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x4eb95d,_0x44ac40,_0x15c416,_0x3ff869,_0x577711,_0x1d9ab2,_0x5d30c8){this['connId']=_0x4eb95d,this['applicationId']=_0x15c416,this['appCheckToken']=_0x3ff869,this['authToken']=_0x577711,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x44ac40),this['connURL']=G['connectionURL_'](_0x44ac40,_0x1d9ab2,_0x5d30c8,_0x3ff869,_0x15c416),this['nodeAdmin']=_0x44ac40['nodeAdmin'];}static['connectionURL_'](_0x14fd98,_0x4b1687,_0x137072,_0x4dce35,_0x17903c){const _0x3518e2={};return _0x3518e2[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3518e2[ao]=co),_0x4b1687&&(_0x3518e2[oo]=_0x4b1687),_0x137072&&(_0x3518e2[ho]=_0x137072),_0x4dce35&&(_0x3518e2[yi]=_0x4dce35),_0x17903c&&(_0x3518e2[uo]=_0x17903c),go(_0x14fd98,fo,_0x3518e2);}['open'](_0x3ef4a7,_0x4c98b7){this['onDisconnect']=_0x4c98b7,this['onMessage']=_0x3ef4a7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1334cb;dc(),this['mySock']=new hn(this['connURL'],[],_0x1334cb);}catch(_0x381811){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2c3100=_0x381811['message']||_0x381811['data'];_0x2c3100&&this['log_'](_0x2c3100),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x379fbe=>{this['handleIncomingFrame'](_0x379fbe);},this['mySock']['onerror']=_0xda1dae=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x201e61=_0xda1dae['message']||_0xda1dae['data'];_0x201e61&&this['log_'](_0x201e61),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x407192=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4c8f78=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x122af4=navigator['userAgent']['match'](_0x4c8f78);_0x122af4&&_0x122af4['length']>0x1&&parseFloat(_0x122af4[0x1])<4.4&&(_0x407192=!0x0);}return!_0x407192&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x269e52){if(this['frames']['push'](_0x269e52),this['frames']['length']===this['totalFrames']){const _0x53ee26=this['frames']['join']('');this['frames']=null;const _0x31e1d8=bt(_0x53ee26);this['onMessage'](_0x31e1d8);}}['handleNewFrameCount_'](_0x35d920){this['totalFrames']=_0x35d920,this['frames']=[];}['extractFrameCount_'](_0x37b494){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x37b494['length']<=0x6){const _0x4cce1b=Number(_0x37b494);if(!isNaN(_0x4cce1b))return this['handleNewFrameCount_'](_0x4cce1b),null;}return this['handleNewFrameCount_'](0x1),_0x37b494;}['handleIncomingFrame'](_0x45af4b){if(this['mySock']===null)return;const _0x567e06=_0x45af4b['data'];if(this['bytesReceived']+=_0x567e06['length'],this['stats_']['incrementCounter']('bytes_received',_0x567e06['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x567e06);else{const _0x57d9b3=this['extractFrameCount_'](_0x567e06);_0x57d9b3!==null&&this['appendFrame_'](_0x57d9b3);}}['send'](_0x2870b5){this['resetKeepAlive']();const _0x4de891=O(_0x2870b5);this['bytesSent']+=_0x4de891['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4de891['length']);const _0x4ddc77=io(_0x4de891,fh);_0x4ddc77['length']>0x1&&this['sendString_'](String(_0x4ddc77['length']));for(let _0x42b884=0x0;_0x42b884<_0x4ddc77['length'];_0x42b884++)this['sendString_'](_0x4ddc77[_0x42b884]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x313d0d){try{this['mySock']['send'](_0x313d0d);}catch(_0x9abceb){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x9abceb['message']||_0x9abceb['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2efbe1){this['initTransports_'](_0x2efbe1);}['initTransports_'](_0x31b7bf){const _0x332925=G&&G['isAvailable']();let _0x4d81f6=_0x332925&&!G['previouslyFailed']();if(_0x31b7bf['webSocketOnly']&&(_0x332925||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4d81f6=!0x0),_0x4d81f6)this['transports_']=[G];else{const _0x349c2e=this['transports_']=[];for(const _0x288152 of At['ALL_TRANSPORTS'])_0x288152&&_0x288152['isAvailable']()&&_0x349c2e['push'](_0x288152);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x18aac4,_0x4e6fef,_0x3251db,_0x2084b7,_0x56f523,_0x52bf0c,_0x28b5f0,_0x814e84,_0x4b9913,_0x43ec50){this['id']=_0x18aac4,this['repoInfo_']=_0x4e6fef,this['applicationId_']=_0x3251db,this['appCheckToken_']=_0x2084b7,this['authToken_']=_0x56f523,this['onMessage_']=_0x52bf0c,this['onReady_']=_0x28b5f0,this['onDisconnect_']=_0x814e84,this['onKill_']=_0x4b9913,this['lastSessionId']=_0x43ec50,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x4e6fef),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x46f044=this['transportManager_']['initialTransport']();this['conn_']=new _0x46f044(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x46f044['responsesRequiredToBeHealthy']||0x0;const _0x33f257=this['connReceiver_'](this['conn_']),_0x8faf74=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x33f257,_0x8faf74);},Math['floor'](0x0));const _0x283121=_0x46f044['healthyTimeout']||0x0;_0x283121>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x283121)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4b11cd){return _0x3459d3=>{_0x4b11cd===this['conn_']?this['onConnectionLost_'](_0x3459d3):_0x4b11cd===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5b5bc6){return _0x297515=>{this['state_']!==0x2&&(_0x5b5bc6===this['rx_']?this['onPrimaryMessageReceived_'](_0x297515):_0x5b5bc6===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x297515):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x18ecc3){const _0x4ecbe9={'t':'d','d':_0x18ecc3};this['sendData_'](_0x4ecbe9);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1c87b0){if(ii in _0x1c87b0){const _0x460f0d=_0x1c87b0[ii];_0x460f0d===js?this['upgradeIfSecondaryHealthy_']():_0x460f0d===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x460f0d===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3e0561){const _0x564801=pt('t',_0x3e0561),_0x3794ae=pt('d',_0x3e0561);if(_0x564801==='c')this['onSecondaryControl_'](_0x3794ae);else{if(_0x564801==='d')this['pendingDataMessages']['push'](_0x3794ae);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x564801);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1f114d){const _0x310175=pt('t',_0x1f114d),_0x47562c=pt('d',_0x1f114d);_0x310175==='c'?this['onControl_'](_0x47562c):_0x310175==='d'&&this['onDataMessage_'](_0x47562c);}['onDataMessage_'](_0x2551f1){this['onPrimaryResponse_'](),this['onMessage_'](_0x2551f1);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x47b9a6){const _0x40f9ca=pt(ii,_0x47b9a6);if(Gs in _0x47b9a6){const _0x3489e8=_0x47b9a6[Gs];if(_0x40f9ca===Ih){const _0x3c580b={..._0x3489e8};this['repoInfo_']['isUsingEmulator']&&(_0x3c580b['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3c580b);}else{if(_0x40f9ca===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2feced=0x0;_0x2feced<this['pendingDataMessages']['length'];++_0x2feced)this['onDataMessage_'](this['pendingDataMessages'][_0x2feced]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x40f9ca===vh?this['onConnectionShutdown_'](_0x3489e8):_0x40f9ca===qs?this['onReset_'](_0x3489e8):_0x40f9ca===Eh?mi('Server\x20Error:\x20'+_0x3489e8):_0x40f9ca===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x40f9ca);}}}['onHandshake_'](_0x183b47){const _0xb862ef=_0x183b47['ts'],_0x35d8bd=_0x183b47['v'],_0x59860b=_0x183b47['h'];this['sessionId']=_0x183b47['s'],this['repoInfo_']['host']=_0x59860b,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xb862ef),Vi!==_0x35d8bd&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x32f022=this['transportManager_']['upgradeTransport']();_0x32f022&&this['startUpgrade_'](_0x32f022);}['startUpgrade_'](_0x4d7da3){this['secondaryConn_']=new _0x4d7da3(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4d7da3['responsesRequiredToBeHealthy']||0x0;const _0x3756e5=this['connReceiver_'](this['secondaryConn_']),_0xeda94=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3756e5,_0xeda94),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x13ecd8){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x13ecd8),this['repoInfo_']['host']=_0x13ecd8,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4a867c,_0x1f1c6e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4a867c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1f1c6e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4ebf1f=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4ebf1f||this['rx_']===_0x4ebf1f)&&this['close']();}['onConnectionLost_'](_0x26f75b){this['conn_']=null,!_0x26f75b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5cadba){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5cadba),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x42241c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x42241c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x40da8,_0x42c60a,_0x1f63ee,_0x5051f9){}['merge'](_0x2e7cbb,_0x163d1d,_0x5d51db,_0x419522){}['refreshAuthToken'](_0x5ce361){}['refreshAppCheckToken'](_0x2ed1cf){}['onDisconnectPut'](_0x4bce96,_0x2590a3,_0x2ee018){}['onDisconnectMerge'](_0x4c45d6,_0x3979a6,_0x42c90e){}['onDisconnectCancel'](_0x364804,_0x2a7205){}['reportStats'](_0x3c8cce){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2bf8f6){this['allowedEvents_']=_0x2bf8f6,this['listeners_']={},f(Array['isArray'](_0x2bf8f6)&&_0x2bf8f6['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3a1664,..._0x5c0c11){if(Array['isArray'](this['listeners_'][_0x3a1664])){const _0x4bbb21=[...this['listeners_'][_0x3a1664]];for(let _0x18093d=0x0;_0x18093d<_0x4bbb21['length'];_0x18093d++)_0x4bbb21[_0x18093d]['callback']['apply'](_0x4bbb21[_0x18093d]['context'],_0x5c0c11);}}['on'](_0x981aa,_0xc0f99b,_0x49e6a1){this['validateEventType_'](_0x981aa),this['listeners_'][_0x981aa]=this['listeners_'][_0x981aa]||[],this['listeners_'][_0x981aa]['push']({'callback':_0xc0f99b,'context':_0x49e6a1});const _0x3e0dcd=this['getInitialEvent'](_0x981aa);_0x3e0dcd&&_0xc0f99b['apply'](_0x49e6a1,_0x3e0dcd);}['off'](_0x202c66,_0x21a9a4,_0x108612){this['validateEventType_'](_0x202c66);const _0x132580=this['listeners_'][_0x202c66]||[];for(let _0x4eb3ca=0x0;_0x4eb3ca<_0x132580['length'];_0x4eb3ca++)if(_0x132580[_0x4eb3ca]['callback']===_0x21a9a4&&(!_0x108612||_0x108612===_0x132580[_0x4eb3ca]['context'])){_0x132580['splice'](_0x4eb3ca,0x1);return;}}['validateEventType_'](_0x75fe80){f(this['allowedEvents_']['find'](_0xe7a5cc=>_0xe7a5cc===_0x75fe80),'Unknown\x20event:\x20'+_0x75fe80);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2f36dd){return f(_0x2f36dd==='online','Unknown\x20event\x20type:\x20'+_0x2f36dd),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x52dccd,_0x131c21){if(_0x131c21===void 0x0){this['pieces_']=_0x52dccd['split']('/');let _0x5954eb=0x0;for(let _0x3e18fb=0x0;_0x3e18fb<this['pieces_']['length'];_0x3e18fb++)this['pieces_'][_0x3e18fb]['length']>0x0&&(this['pieces_'][_0x5954eb]=this['pieces_'][_0x3e18fb],_0x5954eb++);this['pieces_']['length']=_0x5954eb,this['pieceNum_']=0x0;}else this['pieces_']=_0x52dccd,this['pieceNum_']=_0x131c21;}['toString'](){let _0x1d9d93='';for(let _0x2c871e=this['pieceNum_'];_0x2c871e<this['pieces_']['length'];_0x2c871e++)this['pieces_'][_0x2c871e]!==''&&(_0x1d9d93+='/'+this['pieces_'][_0x2c871e]);return _0x1d9d93||'/';}}function w(){return new C('');}function y(_0x39db94){return _0x39db94['pieceNum_']>=_0x39db94['pieces_']['length']?null:_0x39db94['pieces_'][_0x39db94['pieceNum_']];}function we(_0x3efb18){return _0x3efb18['pieces_']['length']-_0x3efb18['pieceNum_'];}function b(_0x8d22f7){let _0x562eb5=_0x8d22f7['pieceNum_'];return _0x562eb5<_0x8d22f7['pieces_']['length']&&_0x562eb5++,new C(_0x8d22f7['pieces_'],_0x562eb5);}function Gi(_0x333b9a){return _0x333b9a['pieceNum_']<_0x333b9a['pieces_']['length']?_0x333b9a['pieces_'][_0x333b9a['pieces_']['length']-0x1]:null;}function Ch(_0x486b69){let _0x41cbbe='';for(let _0x9416bf=_0x486b69['pieceNum_'];_0x9416bf<_0x486b69['pieces_']['length'];_0x9416bf++)_0x486b69['pieces_'][_0x9416bf]!==''&&(_0x41cbbe+='/'+encodeURIComponent(String(_0x486b69['pieces_'][_0x9416bf])));return _0x41cbbe||'/';}function kt(_0x2e157b,_0x4b8f2c=0x0){return _0x2e157b['pieces_']['slice'](_0x2e157b['pieceNum_']+_0x4b8f2c);}function To(_0x56d43f){if(_0x56d43f['pieceNum_']>=_0x56d43f['pieces_']['length'])return null;const _0x486212=[];for(let _0x5cac79=_0x56d43f['pieceNum_'];_0x5cac79<_0x56d43f['pieces_']['length']-0x1;_0x5cac79++)_0x486212['push'](_0x56d43f['pieces_'][_0x5cac79]);return new C(_0x486212,0x0);}function A(_0x1e306a,_0x12e0bd){const _0x3b109e=[];for(let _0x2eee05=_0x1e306a['pieceNum_'];_0x2eee05<_0x1e306a['pieces_']['length'];_0x2eee05++)_0x3b109e['push'](_0x1e306a['pieces_'][_0x2eee05]);if(_0x12e0bd instanceof C){for(let _0x2772bf=_0x12e0bd['pieceNum_'];_0x2772bf<_0x12e0bd['pieces_']['length'];_0x2772bf++)_0x3b109e['push'](_0x12e0bd['pieces_'][_0x2772bf]);}else{const _0x4bc4e7=_0x12e0bd['split']('/');for(let _0x5e4937=0x0;_0x5e4937<_0x4bc4e7['length'];_0x5e4937++)_0x4bc4e7[_0x5e4937]['length']>0x0&&_0x3b109e['push'](_0x4bc4e7[_0x5e4937]);}return new C(_0x3b109e,0x0);}function v(_0x296a84){return _0x296a84['pieceNum_']>=_0x296a84['pieces_']['length'];}function F(_0x36be33,_0x211b66){const _0x5bac95=y(_0x36be33),_0x39849b=y(_0x211b66);if(_0x5bac95===null)return _0x211b66;if(_0x5bac95===_0x39849b)return F(b(_0x36be33),b(_0x211b66));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x211b66+')\x20is\x20not\x20within\x20outerPath\x20('+_0x36be33+')');}function Th(_0x146b6e,_0x1f068d){const _0x174de6=kt(_0x146b6e,0x0),_0x342280=kt(_0x1f068d,0x0);for(let _0xc3d020=0x0;_0xc3d020<_0x174de6['length']&&_0xc3d020<_0x342280['length'];_0xc3d020++){const _0x590534=He(_0x174de6[_0xc3d020],_0x342280[_0xc3d020]);if(_0x590534!==0x0)return _0x590534;}return _0x174de6['length']===_0x342280['length']?0x0:_0x174de6['length']<_0x342280['length']?-0x1:0x1;}function qi(_0x29a406,_0x1e66ec){if(we(_0x29a406)!==we(_0x1e66ec))return!0x1;for(let _0x513891=_0x29a406['pieceNum_'],_0xfb0ccb=_0x1e66ec['pieceNum_'];_0x513891<=_0x29a406['pieces_']['length'];_0x513891++,_0xfb0ccb++)if(_0x29a406['pieces_'][_0x513891]!==_0x1e66ec['pieces_'][_0xfb0ccb])return!0x1;return!0x0;}function $(_0x1323fa,_0x3e6d81){let _0x164d9b=_0x1323fa['pieceNum_'],_0x3894f8=_0x3e6d81['pieceNum_'];if(we(_0x1323fa)>we(_0x3e6d81))return!0x1;for(;_0x164d9b<_0x1323fa['pieces_']['length'];){if(_0x1323fa['pieces_'][_0x164d9b]!==_0x3e6d81['pieces_'][_0x3894f8])return!0x1;++_0x164d9b,++_0x3894f8;}return!0x0;}class Sh{constructor(_0x1644e0,_0x5666da){this['errorPrefix_']=_0x5666da,this['parts_']=kt(_0x1644e0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4a8c2c=0x0;_0x4a8c2c<this['parts_']['length'];_0x4a8c2c++)this['byteLength_']+=Pn(this['parts_'][_0x4a8c2c]);So(this);}}function bh(_0x77af5,_0xa836a){_0x77af5['parts_']['length']>0x0&&(_0x77af5['byteLength_']+=0x1),_0x77af5['parts_']['push'](_0xa836a),_0x77af5['byteLength_']+=Pn(_0xa836a),So(_0x77af5);}function Rh(_0x313487){const _0x1f7cde=_0x313487['parts_']['pop']();_0x313487['byteLength_']-=Pn(_0x1f7cde),_0x313487['parts_']['length']>0x0&&(_0x313487['byteLength_']-=0x1);}function So(_0x1d6422){if(_0x1d6422['byteLength_']>Js)throw new Error(_0x1d6422['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x1d6422['byteLength_']+').');if(_0x1d6422['parts_']['length']>Qs)throw new Error(_0x1d6422['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x1d6422));}function Ne(_0x31f2ca){return _0x31f2ca['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x31f2ca['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x152da2,_0x387464;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x387464='visibilitychange',_0x152da2='hidden'):typeof document['mozHidden']<'u'?(_0x387464='mozvisibilitychange',_0x152da2='mozHidden'):typeof document['msHidden']<'u'?(_0x387464='msvisibilitychange',_0x152da2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x387464='webkitvisibilitychange',_0x152da2='webkitHidden')),this['visible_']=!0x0,_0x387464&&document['addEventListener'](_0x387464,()=>{const _0x1b3c7e=!document[_0x152da2];_0x1b3c7e!==this['visible_']&&(this['visible_']=_0x1b3c7e,this['trigger']('visible',_0x1b3c7e));},!0x1);}['getInitialEvent'](_0x1c8cd3){return f(_0x1c8cd3==='visible','Unknown\x20event\x20type:\x20'+_0x1c8cd3),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x33b1bb,_0xdceca0,_0x452e6b,_0x2c9592,_0x2b31a4,_0x2047e3,_0x4fcdd1,_0x390434){if(super(),this['repoInfo_']=_0x33b1bb,this['applicationId_']=_0xdceca0,this['onDataUpdate_']=_0x452e6b,this['onConnectStatus_']=_0x2c9592,this['onServerInfoUpdate_']=_0x2b31a4,this['authTokenProvider_']=_0x2047e3,this['appCheckTokenProvider_']=_0x4fcdd1,this['authOverride_']=_0x390434,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x390434)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x33b1bb['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x191ec8,_0x4ba660,_0x7ac43c){const _0x572d5d=++this['requestNumber_'],_0x3e9871={'r':_0x572d5d,'a':_0x191ec8,'b':_0x4ba660};this['log_'](O(_0x3e9871)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3e9871),_0x7ac43c&&(this['requestCBHash_'][_0x572d5d]=_0x7ac43c);}['get'](_0x50e4ca){this['initConnection_']();const _0x37f81f=new Ve(),_0x1ca14c={'action':'g','request':{'p':_0x50e4ca['_path']['toString'](),'q':_0x50e4ca['_queryObject']},'onComplete':_0x52dbc6=>{const _0x5072d8=_0x52dbc6['d'];_0x52dbc6['s']==='ok'?_0x37f81f['resolve'](_0x5072d8):_0x37f81f['reject'](_0x5072d8);}};this['outstandingGets_']['push'](_0x1ca14c),this['outstandingGetCount_']++;const _0x407162=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x407162),_0x37f81f['promise'];}['listen'](_0x4b4df0,_0x5d4c4e,_0x2175a9,_0x21cbb8){this['initConnection_']();const _0x1e452f=_0x4b4df0['_queryIdentifier'],_0x23e80f=_0x4b4df0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x23e80f+'\x20'+_0x1e452f),this['listens']['has'](_0x23e80f)||this['listens']['set'](_0x23e80f,new Map()),f(_0x4b4df0['_queryParams']['isDefault']()||!_0x4b4df0['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x23e80f)['has'](_0x1e452f),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x26d0cc={'onComplete':_0x21cbb8,'hashFn':_0x5d4c4e,'query':_0x4b4df0,'tag':_0x2175a9};this['listens']['get'](_0x23e80f)['set'](_0x1e452f,_0x26d0cc),this['connected_']&&this['sendListen_'](_0x26d0cc);}['sendGet_'](_0x36e246){const _0x28cf4b=this['outstandingGets_'][_0x36e246];this['sendRequest']('g',_0x28cf4b['request'],_0x13973f=>{delete this['outstandingGets_'][_0x36e246],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x28cf4b['onComplete']&&_0x28cf4b['onComplete'](_0x13973f);});}['sendListen_'](_0x203107){const _0xaf3a8e=_0x203107['query'],_0x5cdfcc=_0xaf3a8e['_path']['toString'](),_0x29983b=_0xaf3a8e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5cdfcc+'\x20for\x20'+_0x29983b);const _0x50a658={'p':_0x5cdfcc},_0x33e175='q';_0x203107['tag']&&(_0x50a658['q']=_0xaf3a8e['_queryObject'],_0x50a658['t']=_0x203107['tag']),_0x50a658['h']=_0x203107['hashFn'](),this['sendRequest'](_0x33e175,_0x50a658,_0x4316e9=>{const _0x47c58a=_0x4316e9['d'],_0x47153c=_0x4316e9['s'];ie['warnOnListenWarnings_'](_0x47c58a,_0xaf3a8e),(this['listens']['get'](_0x5cdfcc)&&this['listens']['get'](_0x5cdfcc)['get'](_0x29983b))===_0x203107&&(this['log_']('listen\x20response',_0x4316e9),_0x47153c!=='ok'&&this['removeListen_'](_0x5cdfcc,_0x29983b),_0x203107['onComplete']&&_0x203107['onComplete'](_0x47153c,_0x47c58a));});}static['warnOnListenWarnings_'](_0x3fbff9,_0x31af6c){if(_0x3fbff9&&typeof _0x3fbff9=='object'&&Y(_0x3fbff9,'w')){const _0x2d5b28=Oe(_0x3fbff9,'w');if(Array['isArray'](_0x2d5b28)&&~_0x2d5b28['indexOf']('no_index')){const _0x2ba646='\x22.indexOn\x22:\x20\x22'+_0x31af6c['_queryParams']['getIndex']()['toString']()+'\x22',_0x48a508=_0x31af6c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2ba646+'\x20at\x20'+_0x48a508+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1d737b){this['authToken_']=_0x1d737b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1d737b);}['reduceReconnectDelayIfAdminCredential_'](_0x3f5558){(_0x3f5558&&_0x3f5558['length']===0x28||vc(_0x3f5558))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4e2719){this['appCheckToken_']=_0x4e2719,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5bd59a=this['authToken_'],_0x45715e=yc(_0x5bd59a)?'auth':'gauth',_0x491623={'cred':_0x5bd59a};this['authOverride_']===null?_0x491623['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x491623['authvar']=this['authOverride_']),this['sendRequest'](_0x45715e,_0x491623,_0x1d10f4=>{const _0x418c74=_0x1d10f4['s'],_0x22bd9d=_0x1d10f4['d']||'error';this['authToken_']===_0x5bd59a&&(_0x418c74==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x418c74,_0x22bd9d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x295381=>{const _0x1787a=_0x295381['s'],_0x1cd15f=_0x295381['d']||'error';_0x1787a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1787a,_0x1cd15f);});}['unlisten'](_0x199af5,_0x666369){const _0x47c79c=_0x199af5['_path']['toString'](),_0x2905e5=_0x199af5['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x47c79c+'\x20'+_0x2905e5),f(_0x199af5['_queryParams']['isDefault']()||!_0x199af5['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x47c79c,_0x2905e5)&&this['connected_']&&this['sendUnlisten_'](_0x47c79c,_0x2905e5,_0x199af5['_queryObject'],_0x666369);}['sendUnlisten_'](_0x3be24c,_0x1968e0,_0x426934,_0x454a44){this['log_']('Unlisten\x20on\x20'+_0x3be24c+'\x20for\x20'+_0x1968e0);const _0x2878d3={'p':_0x3be24c},_0x212874='n';_0x454a44&&(_0x2878d3['q']=_0x426934,_0x2878d3['t']=_0x454a44),this['sendRequest'](_0x212874,_0x2878d3);}['onDisconnectPut'](_0x2c0cea,_0x320be2,_0x18eed7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2c0cea,_0x320be2,_0x18eed7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2c0cea,'action':'o','data':_0x320be2,'onComplete':_0x18eed7});}['onDisconnectMerge'](_0x4841b0,_0x3deb5c,_0x1ffbc2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4841b0,_0x3deb5c,_0x1ffbc2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4841b0,'action':'om','data':_0x3deb5c,'onComplete':_0x1ffbc2});}['onDisconnectCancel'](_0x86e6cc,_0x3cc6e4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x86e6cc,null,_0x3cc6e4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x86e6cc,'action':'oc','data':null,'onComplete':_0x3cc6e4});}['sendOnDisconnect_'](_0x17aaa6,_0x5c4227,_0xc47f38,_0x110b7b){const _0x5b4b92={'p':_0x5c4227,'d':_0xc47f38};this['log_']('onDisconnect\x20'+_0x17aaa6,_0x5b4b92),this['sendRequest'](_0x17aaa6,_0x5b4b92,_0x2f35af=>{_0x110b7b&&setTimeout(()=>{_0x110b7b(_0x2f35af['s'],_0x2f35af['d']);},Math['floor'](0x0));});}['put'](_0xdf7962,_0x2ee7ac,_0x1e1fdd,_0x1e0a7a){this['putInternal']('p',_0xdf7962,_0x2ee7ac,_0x1e1fdd,_0x1e0a7a);}['merge'](_0x19b7e4,_0x364c2c,_0xa674f8,_0x4594c8){this['putInternal']('m',_0x19b7e4,_0x364c2c,_0xa674f8,_0x4594c8);}['putInternal'](_0x2546ed,_0x50e355,_0x5b71ed,_0x4640fa,_0x15a282){this['initConnection_']();const _0x185a61={'p':_0x50e355,'d':_0x5b71ed};_0x15a282!==void 0x0&&(_0x185a61['h']=_0x15a282),this['outstandingPuts_']['push']({'action':_0x2546ed,'request':_0x185a61,'onComplete':_0x4640fa}),this['outstandingPutCount_']++;const _0x317029=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x317029):this['log_']('Buffering\x20put:\x20'+_0x50e355);}['sendPut_'](_0x1bbdc1){const _0x4c5f3d=this['outstandingPuts_'][_0x1bbdc1]['action'],_0x479c26=this['outstandingPuts_'][_0x1bbdc1]['request'],_0x2f6a41=this['outstandingPuts_'][_0x1bbdc1]['onComplete'];this['outstandingPuts_'][_0x1bbdc1]['queued']=this['connected_'],this['sendRequest'](_0x4c5f3d,_0x479c26,_0x2645f2=>{this['log_'](_0x4c5f3d+'\x20response',_0x2645f2),delete this['outstandingPuts_'][_0x1bbdc1],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2f6a41&&_0x2f6a41(_0x2645f2['s'],_0x2645f2['d']);});}['reportStats'](_0x3d789c){if(this['connected_']){const _0x2373f7={'c':_0x3d789c};this['log_']('reportStats',_0x2373f7),this['sendRequest']('s',_0x2373f7,_0x15b7fe=>{if(_0x15b7fe['s']!=='ok'){const _0x18dd0b=_0x15b7fe['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x18dd0b);}});}}['onDataMessage_'](_0x2a506b){if('r'in _0x2a506b){this['log_']('from\x20server:\x20'+O(_0x2a506b));const _0x4ea5d7=_0x2a506b['r'],_0x39a6d6=this['requestCBHash_'][_0x4ea5d7];_0x39a6d6&&(delete this['requestCBHash_'][_0x4ea5d7],_0x39a6d6(_0x2a506b['b']));}else{if('error'in _0x2a506b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2a506b['error'];'a'in _0x2a506b&&this['onDataPush_'](_0x2a506b['a'],_0x2a506b['b']);}}['onDataPush_'](_0x5bbae4,_0x6703cb){this['log_']('handleServerMessage',_0x5bbae4,_0x6703cb),_0x5bbae4==='d'?this['onDataUpdate_'](_0x6703cb['p'],_0x6703cb['d'],!0x1,_0x6703cb['t']):_0x5bbae4==='m'?this['onDataUpdate_'](_0x6703cb['p'],_0x6703cb['d'],!0x0,_0x6703cb['t']):_0x5bbae4==='c'?this['onListenRevoked_'](_0x6703cb['p'],_0x6703cb['q']):_0x5bbae4==='ac'?this['onAuthRevoked_'](_0x6703cb['s'],_0x6703cb['d']):_0x5bbae4==='apc'?this['onAppCheckRevoked_'](_0x6703cb['s'],_0x6703cb['d']):_0x5bbae4==='sd'?this['onSecurityDebugPacket_'](_0x6703cb):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5bbae4)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x6bbbc9,_0x195db1){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x6bbbc9),this['lastSessionId']=_0x195db1,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x344c3a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x344c3a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x49bcc3){_0x49bcc3&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x49bcc3;}['onOnline_'](_0x4e8b91){_0x4e8b91?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x51071b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x534e2e=Math['max'](0x0,this['reconnectDelay_']-_0x51071b);_0x534e2e=Math['random']()*_0x534e2e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x534e2e+'ms'),this['scheduleConnect_'](_0x534e2e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x44f98a=this['onDataMessage_']['bind'](this),_0x451e79=this['onReady_']['bind'](this),_0x9b3ad7=this['onRealtimeDisconnect_']['bind'](this),_0x13d21c=this['id']+':'+ie['nextConnectionId_']++,_0x32dd7a=this['lastSessionId'];let _0x3176f1=!0x1,_0x583de0=null;const _0x25660d=function(){_0x583de0?_0x583de0['close']():(_0x3176f1=!0x0,_0x9b3ad7());},_0x5281e0=function(_0x55f3ec){f(_0x583de0,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x583de0['sendRequest'](_0x55f3ec);};this['realtime_']={'close':_0x25660d,'sendRequest':_0x5281e0};const _0x203a86=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x7e8213,_0x19e7d9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x203a86),this['appCheckTokenProvider_']['getToken'](_0x203a86)]);_0x3176f1?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x7e8213&&_0x7e8213['accessToken'],this['appCheckToken_']=_0x19e7d9&&_0x19e7d9['token'],_0x583de0=new wh(_0x13d21c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x44f98a,_0x451e79,_0x9b3ad7,_0x1dc976=>{U(_0x1dc976+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x32dd7a));}catch(_0xc7dcda){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xc7dcda),_0x3176f1||(this['repoInfo_']['nodeAdmin']&&U(_0xc7dcda),_0x25660d());}}}['interrupt'](_0x31624c){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x31624c),this['interruptReasons_'][_0x31624c]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4432b7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4432b7),delete this['interruptReasons_'][_0x4432b7],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x121fe6){const _0x408ea9=_0x121fe6-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x408ea9});}['cancelSentTransactions_'](){for(let _0x393a69=0x0;_0x393a69<this['outstandingPuts_']['length'];_0x393a69++){const _0x3d95e5=this['outstandingPuts_'][_0x393a69];_0x3d95e5&&'h'in _0x3d95e5['request']&&_0x3d95e5['queued']&&(_0x3d95e5['onComplete']&&_0x3d95e5['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x393a69],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x43fa25,_0xbd0f74){let _0x371d2f;_0xbd0f74?_0x371d2f=_0xbd0f74['map'](_0x52c85a=>Bi(_0x52c85a))['join']('$'):_0x371d2f='default';const _0x11dbaf=this['removeListen_'](_0x43fa25,_0x371d2f);_0x11dbaf&&_0x11dbaf['onComplete']&&_0x11dbaf['onComplete']('permission_denied');}['removeListen_'](_0x162415,_0x347d31){const _0x5ab5b8=new C(_0x162415)['toString']();let _0x4fff6f;if(this['listens']['has'](_0x5ab5b8)){const _0xdffee8=this['listens']['get'](_0x5ab5b8);_0x4fff6f=_0xdffee8['get'](_0x347d31),_0xdffee8['delete'](_0x347d31),_0xdffee8['size']===0x0&&this['listens']['delete'](_0x5ab5b8);}else _0x4fff6f=void 0x0;return _0x4fff6f;}['onAuthRevoked_'](_0x450364,_0x4ff66c){L('Auth\x20token\x20revoked:\x20'+_0x450364+'/'+_0x4ff66c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x450364==='invalid_token'||_0x450364==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x254814,_0x36417d){L('App\x20check\x20token\x20revoked:\x20'+_0x254814+'/'+_0x36417d),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x254814==='invalid_token'||_0x254814==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x26e02a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x26e02a):'msg'in _0x26e02a&&console['log']('FIREBASE:\x20'+_0x26e02a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x51477b of this['listens']['values']())for(const _0x337b28 of _0x51477b['values']())this['sendListen_'](_0x337b28);for(let _0x338ea1=0x0;_0x338ea1<this['outstandingPuts_']['length'];_0x338ea1++)this['outstandingPuts_'][_0x338ea1]&&this['sendPut_'](_0x338ea1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x12239=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x12239['action'],_0x12239['pathString'],_0x12239['data'],_0x12239['onComplete']);}for(let _0x53ef01=0x0;_0x53ef01<this['outstandingGets_']['length'];_0x53ef01++)this['outstandingGets_'][_0x53ef01]&&this['sendGet_'](_0x53ef01);}['sendConnectStats_'](){const _0x398b6b={};let _0x571262='js';_0x398b6b['sdk.'+_0x571262+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x398b6b['framework.cordova']=0x1:qr()&&(_0x398b6b['framework.reactnative']=0x1),this['reportStats'](_0x398b6b);}['shouldReconnect_'](){const _0x5a9d9e=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x5a9d9e;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x14caa5,_0x4db129){this['name']=_0x14caa5,this['node']=_0x4db129;}static['Wrap'](_0x599f41,_0x3b62ad){return new E(_0x599f41,_0x3b62ad);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1f7290,_0x2edc6a){const _0xd6c572=new E(xe,_0x1f7290),_0x587df0=new E(xe,_0x2edc6a);return this['compare'](_0xd6c572,_0x587df0)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x576285){Xt=_0x576285;}['compare'](_0x4064fc,_0x4b2c86){return He(_0x4064fc['name'],_0x4b2c86['name']);}['isDefinedOn'](_0x5569f7){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x129032,_0x240308){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x106fe1,_0x1e61e7){return f(typeof _0x106fe1=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x106fe1,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2480e6,_0x1ec894,_0x1c4a62,_0x14ceb3,_0x36e6c3=null){this['isReverse_']=_0x14ceb3,this['resultGenerator_']=_0x36e6c3,this['nodeStack_']=[];let _0x1b096e=0x1;for(;!_0x2480e6['isEmpty']();)if(_0x2480e6=_0x2480e6,_0x1b096e=_0x1ec894?_0x1c4a62(_0x2480e6['key'],_0x1ec894):0x1,_0x14ceb3&&(_0x1b096e*=-0x1),_0x1b096e<0x0)this['isReverse_']?_0x2480e6=_0x2480e6['left']:_0x2480e6=_0x2480e6['right'];else{if(_0x1b096e===0x0){this['nodeStack_']['push'](_0x2480e6);break;}else this['nodeStack_']['push'](_0x2480e6),this['isReverse_']?_0x2480e6=_0x2480e6['right']:_0x2480e6=_0x2480e6['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1a5cb6=this['nodeStack_']['pop'](),_0x320b1f;if(this['resultGenerator_']?_0x320b1f=this['resultGenerator_'](_0x1a5cb6['key'],_0x1a5cb6['value']):_0x320b1f={'key':_0x1a5cb6['key'],'value':_0x1a5cb6['value']},this['isReverse_']){for(_0x1a5cb6=_0x1a5cb6['left'];!_0x1a5cb6['isEmpty']();)this['nodeStack_']['push'](_0x1a5cb6),_0x1a5cb6=_0x1a5cb6['right'];}else{for(_0x1a5cb6=_0x1a5cb6['right'];!_0x1a5cb6['isEmpty']();)this['nodeStack_']['push'](_0x1a5cb6),_0x1a5cb6=_0x1a5cb6['left'];}return _0x320b1f;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x485514=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x485514['key'],_0x485514['value']):{'key':_0x485514['key'],'value':_0x485514['value']};}}class M{constructor(_0x137953,_0x2d3583,_0x51a132,_0x15575a,_0x2fcae0){this['key']=_0x137953,this['value']=_0x2d3583,this['color']=_0x51a132??M['RED'],this['left']=_0x15575a??B['EMPTY_NODE'],this['right']=_0x2fcae0??B['EMPTY_NODE'];}['copy'](_0x4dd5d7,_0x431b5c,_0xf089f4,_0x5e900e,_0x1a915f){return new M(_0x4dd5d7??this['key'],_0x431b5c??this['value'],_0xf089f4??this['color'],_0x5e900e??this['left'],_0x1a915f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x49cf5c){return this['left']['inorderTraversal'](_0x49cf5c)||!!_0x49cf5c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x49cf5c);}['reverseTraversal'](_0x217343){return this['right']['reverseTraversal'](_0x217343)||_0x217343(this['key'],this['value'])||this['left']['reverseTraversal'](_0x217343);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x203990,_0x56631a,_0x366e95){let _0x1731db=this;const _0x373d71=_0x366e95(_0x203990,_0x1731db['key']);return _0x373d71<0x0?_0x1731db=_0x1731db['copy'](null,null,null,_0x1731db['left']['insert'](_0x203990,_0x56631a,_0x366e95),null):_0x373d71===0x0?_0x1731db=_0x1731db['copy'](null,_0x56631a,null,null,null):_0x1731db=_0x1731db['copy'](null,null,null,null,_0x1731db['right']['insert'](_0x203990,_0x56631a,_0x366e95)),_0x1731db['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x56c69c=this;return!_0x56c69c['left']['isRed_']()&&!_0x56c69c['left']['left']['isRed_']()&&(_0x56c69c=_0x56c69c['moveRedLeft_']()),_0x56c69c=_0x56c69c['copy'](null,null,null,_0x56c69c['left']['removeMin_'](),null),_0x56c69c['fixUp_']();}['remove'](_0x48dec7,_0x1594eb){let _0x3adbb7,_0x407740;if(_0x3adbb7=this,_0x1594eb(_0x48dec7,_0x3adbb7['key'])<0x0)!_0x3adbb7['left']['isEmpty']()&&!_0x3adbb7['left']['isRed_']()&&!_0x3adbb7['left']['left']['isRed_']()&&(_0x3adbb7=_0x3adbb7['moveRedLeft_']()),_0x3adbb7=_0x3adbb7['copy'](null,null,null,_0x3adbb7['left']['remove'](_0x48dec7,_0x1594eb),null);else{if(_0x3adbb7['left']['isRed_']()&&(_0x3adbb7=_0x3adbb7['rotateRight_']()),!_0x3adbb7['right']['isEmpty']()&&!_0x3adbb7['right']['isRed_']()&&!_0x3adbb7['right']['left']['isRed_']()&&(_0x3adbb7=_0x3adbb7['moveRedRight_']()),_0x1594eb(_0x48dec7,_0x3adbb7['key'])===0x0){if(_0x3adbb7['right']['isEmpty']())return B['EMPTY_NODE'];_0x407740=_0x3adbb7['right']['min_'](),_0x3adbb7=_0x3adbb7['copy'](_0x407740['key'],_0x407740['value'],null,null,_0x3adbb7['right']['removeMin_']());}_0x3adbb7=_0x3adbb7['copy'](null,null,null,null,_0x3adbb7['right']['remove'](_0x48dec7,_0x1594eb));}return _0x3adbb7['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1ebaac=this;return _0x1ebaac['right']['isRed_']()&&!_0x1ebaac['left']['isRed_']()&&(_0x1ebaac=_0x1ebaac['rotateLeft_']()),_0x1ebaac['left']['isRed_']()&&_0x1ebaac['left']['left']['isRed_']()&&(_0x1ebaac=_0x1ebaac['rotateRight_']()),_0x1ebaac['left']['isRed_']()&&_0x1ebaac['right']['isRed_']()&&(_0x1ebaac=_0x1ebaac['colorFlip_']()),_0x1ebaac;}['moveRedLeft_'](){let _0x14d2a0=this['colorFlip_']();return _0x14d2a0['right']['left']['isRed_']()&&(_0x14d2a0=_0x14d2a0['copy'](null,null,null,null,_0x14d2a0['right']['rotateRight_']()),_0x14d2a0=_0x14d2a0['rotateLeft_'](),_0x14d2a0=_0x14d2a0['colorFlip_']()),_0x14d2a0;}['moveRedRight_'](){let _0x4a9e72=this['colorFlip_']();return _0x4a9e72['left']['left']['isRed_']()&&(_0x4a9e72=_0x4a9e72['rotateRight_'](),_0x4a9e72=_0x4a9e72['colorFlip_']()),_0x4a9e72;}['rotateLeft_'](){const _0x1e06c5=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1e06c5,null);}['rotateRight_'](){const _0xf6fdb4=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xf6fdb4);}['colorFlip_'](){const _0x161857=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xfd4bd2=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x161857,_0xfd4bd2);}['checkMaxDepth_'](){const _0x547d49=this['check_']();return Math['pow'](0x2,_0x547d49)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2d97b4=this['left']['check_']();if(_0x2d97b4!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2d97b4+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x1d26f5,_0x219baa,_0x18a11c,_0x129221,_0x4faed7){return this;}['insert'](_0x291e45,_0x2dd4c9,_0x5580c8){return new M(_0x291e45,_0x2dd4c9,null);}['remove'](_0x2d1d9d,_0xe08197){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1c90da){return!0x1;}['reverseTraversal'](_0x5e9f95){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x293696,_0x538970=B['EMPTY_NODE']){this['comparator_']=_0x293696,this['root_']=_0x538970;}['insert'](_0xd6489e,_0x36b6db){return new B(this['comparator_'],this['root_']['insert'](_0xd6489e,_0x36b6db,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xcc3476){return new B(this['comparator_'],this['root_']['remove'](_0xcc3476,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1cfbd8){let _0x1e5245,_0x2d2ce2=this['root_'];for(;!_0x2d2ce2['isEmpty']();){if(_0x1e5245=this['comparator_'](_0x1cfbd8,_0x2d2ce2['key']),_0x1e5245===0x0)return _0x2d2ce2['value'];_0x1e5245<0x0?_0x2d2ce2=_0x2d2ce2['left']:_0x1e5245>0x0&&(_0x2d2ce2=_0x2d2ce2['right']);}return null;}['getPredecessorKey'](_0x12d37a){let _0x57a78d,_0x412acc=this['root_'],_0x5a4c37=null;for(;!_0x412acc['isEmpty']();)if(_0x57a78d=this['comparator_'](_0x12d37a,_0x412acc['key']),_0x57a78d===0x0){if(_0x412acc['left']['isEmpty']())return _0x5a4c37?_0x5a4c37['key']:null;for(_0x412acc=_0x412acc['left'];!_0x412acc['right']['isEmpty']();)_0x412acc=_0x412acc['right'];return _0x412acc['key'];}else _0x57a78d<0x0?_0x412acc=_0x412acc['left']:_0x57a78d>0x0&&(_0x5a4c37=_0x412acc,_0x412acc=_0x412acc['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x282f18){return this['root_']['inorderTraversal'](_0x282f18);}['reverseTraversal'](_0x3ec0dd){return this['root_']['reverseTraversal'](_0x3ec0dd);}['getIterator'](_0x22180c){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x22180c);}['getIteratorFrom'](_0x4c568e,_0x3509e9){return new Zt(this['root_'],_0x4c568e,this['comparator_'],!0x1,_0x3509e9);}['getReverseIteratorFrom'](_0x4e18e,_0x58d117){return new Zt(this['root_'],_0x4e18e,this['comparator_'],!0x0,_0x58d117);}['getReverseIterator'](_0x3b155a){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3b155a);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x208730,_0x58681e){return He(_0x208730['name'],_0x58681e['name']);}function ji(_0x5e7cdf,_0x1461ac){return He(_0x5e7cdf,_0x1461ac);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x46e139){vi=_0x46e139;}const Ro=function(_0x206fbd){return typeof _0x206fbd=='number'?'number:'+so(_0x206fbd):'string:'+_0x206fbd;},Ao=function(_0x27e781){if(_0x27e781['isLeafNode']()){const _0x58afe7=_0x27e781['val']();f(typeof _0x58afe7=='string'||typeof _0x58afe7=='number'||typeof _0x58afe7=='object'&&Y(_0x58afe7,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x27e781===vi||_0x27e781['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x27e781===vi||_0x27e781['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5afb7b){er=_0x5afb7b;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x27ac5d,_0xff0cf3=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x27ac5d,this['priorityNode_']=_0xff0cf3,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x32fcd3){return new D(this['value_'],_0x32fcd3);}['getImmediateChild'](_0x45a862){return _0x45a862==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5c9540){return v(_0x5c9540)?this:y(_0x5c9540)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1486f0,_0x5b8e08){return null;}['updateImmediateChild'](_0x8eb488,_0x39b4c1){return _0x8eb488==='.priority'?this['updatePriority'](_0x39b4c1):_0x39b4c1['isEmpty']()&&_0x8eb488!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x8eb488,_0x39b4c1)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2f2cbb,_0x1d0665){const _0x24503a=y(_0x2f2cbb);return _0x24503a===null?_0x1d0665:_0x1d0665['isEmpty']()&&_0x24503a!=='.priority'?this:(f(_0x24503a!=='.priority'||we(_0x2f2cbb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x24503a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2f2cbb),_0x1d0665)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x8fd410,_0x433cdd){return!0x1;}['val'](_0x203517){return _0x203517&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3e18d8='';this['priorityNode_']['isEmpty']()||(_0x3e18d8+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x31e818=typeof this['value_'];_0x3e18d8+=_0x31e818+':',_0x31e818==='number'?_0x3e18d8+=so(this['value_']):_0x3e18d8+=this['value_'],this['lazyHash_']=no(_0x3e18d8);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1a491d){return _0x1a491d===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1a491d instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1a491d['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1a491d));}['compareToLeafNode_'](_0x1cc7f2){const _0x5bd1fa=typeof _0x1cc7f2['value_'],_0x15b0d4=typeof this['value_'],_0x46d5c8=D['VALUE_TYPE_ORDER']['indexOf'](_0x5bd1fa),_0x565c08=D['VALUE_TYPE_ORDER']['indexOf'](_0x15b0d4);return f(_0x46d5c8>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5bd1fa),f(_0x565c08>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x15b0d4),_0x46d5c8===_0x565c08?_0x15b0d4==='object'?0x0:this['value_']<_0x1cc7f2['value_']?-0x1:this['value_']===_0x1cc7f2['value_']?0x0:0x1:_0x565c08-_0x46d5c8;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x41203d){if(_0x41203d===this)return!0x0;if(_0x41203d['isLeafNode']()){const _0x3d3033=_0x41203d;return this['value_']===_0x3d3033['value_']&&this['priorityNode_']['equals'](_0x3d3033['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x240442){ko=_0x240442;}function xh(_0x4be93a){No=_0x4be93a;}class Fh extends On{['compare'](_0x16e92a,_0x473349){const _0x2239fe=_0x16e92a['node']['getPriority'](),_0x3bdf16=_0x473349['node']['getPriority'](),_0x56cd35=_0x2239fe['compareTo'](_0x3bdf16);return _0x56cd35===0x0?He(_0x16e92a['name'],_0x473349['name']):_0x56cd35;}['isDefinedOn'](_0x36eada){return!_0x36eada['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1ac6e2,_0x535a2a){return!_0x1ac6e2['getPriority']()['equals'](_0x535a2a['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x3e99d8,_0x3d29f0){const _0x489afe=ko(_0x3e99d8);return new E(_0x3d29f0,new D('[PRIORITY-POST]',_0x489afe));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x23dd29){const _0x4f6319=_0x10a87f=>parseInt(Math['log'](_0x10a87f)/Uh,0xa),_0x27d146=_0x343df5=>parseInt(Array(_0x343df5+0x1)['join']('1'),0x2);this['count']=_0x4f6319(_0x23dd29+0x1),this['current_']=this['count']-0x1;const _0x143c51=_0x27d146(this['count']);this['bits_']=_0x23dd29+0x1&_0x143c51;}['nextBitIsOne'](){const _0x92cb08=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x92cb08;}}const dn=function(_0x1bf238,_0x3222d0,_0x2b6e1c,_0x10c209){_0x1bf238['sort'](_0x3222d0);const _0x5d06d3=function(_0x11772e,_0x335cc8){const _0x1caf38=_0x335cc8-_0x11772e;let _0x5969e9,_0x4b95db;if(_0x1caf38===0x0)return null;if(_0x1caf38===0x1)return _0x5969e9=_0x1bf238[_0x11772e],_0x4b95db=_0x2b6e1c?_0x2b6e1c(_0x5969e9):_0x5969e9,new M(_0x4b95db,_0x5969e9['node'],M['BLACK'],null,null);{const _0x582c32=parseInt(_0x1caf38/0x2,0xa)+_0x11772e,_0x2640a7=_0x5d06d3(_0x11772e,_0x582c32),_0x2cacf6=_0x5d06d3(_0x582c32+0x1,_0x335cc8);return _0x5969e9=_0x1bf238[_0x582c32],_0x4b95db=_0x2b6e1c?_0x2b6e1c(_0x5969e9):_0x5969e9,new M(_0x4b95db,_0x5969e9['node'],M['BLACK'],_0x2640a7,_0x2cacf6);}},_0x24b573=function(_0x55aaac){let _0x384fb9=null,_0x23d7f6=null,_0x41c8ab=_0x1bf238['length'];const _0x2902b6=function(_0x52a991,_0x219741){const _0x29b775=_0x41c8ab-_0x52a991,_0x52f620=_0x41c8ab;_0x41c8ab-=_0x52a991;const _0x46b3da=_0x5d06d3(_0x29b775+0x1,_0x52f620),_0x54422d=_0x1bf238[_0x29b775],_0x14cb9f=_0x2b6e1c?_0x2b6e1c(_0x54422d):_0x54422d;_0xb4e440(new M(_0x14cb9f,_0x54422d['node'],_0x219741,null,_0x46b3da));},_0xb4e440=function(_0x1f16a7){_0x384fb9?(_0x384fb9['left']=_0x1f16a7,_0x384fb9=_0x1f16a7):(_0x23d7f6=_0x1f16a7,_0x384fb9=_0x1f16a7);};for(let _0xca0f0a=0x0;_0xca0f0a<_0x55aaac['count'];++_0xca0f0a){const _0x540e09=_0x55aaac['nextBitIsOne'](),_0x4a2ab8=Math['pow'](0x2,_0x55aaac['count']-(_0xca0f0a+0x1));_0x540e09?_0x2902b6(_0x4a2ab8,M['BLACK']):(_0x2902b6(_0x4a2ab8,M['BLACK']),_0x2902b6(_0x4a2ab8,M['RED']));}return _0x23d7f6;},_0x39eed3=new Wh(_0x1bf238['length']),_0xb387bf=_0x24b573(_0x39eed3);return new B(_0x10c209||_0x3222d0,_0xb387bf);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x17bcad,_0xc3ec2c){this['indexes_']=_0x17bcad,this['indexSet_']=_0xc3ec2c;}['get'](_0x5953b9){const _0x37531a=Oe(this['indexes_'],_0x5953b9);if(!_0x37531a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5953b9);return _0x37531a instanceof B?_0x37531a:null;}['hasIndex'](_0x54049d){return Y(this['indexSet_'],_0x54049d['toString']());}['addIndex'](_0x411547,_0x57aa6d){f(_0x411547!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x15a818=[];let _0x2e8b8a=!0x1;const _0x2ef85a=_0x57aa6d['getIterator'](E['Wrap']);let _0x3301e7=_0x2ef85a['getNext']();for(;_0x3301e7;)_0x2e8b8a=_0x2e8b8a||_0x411547['isDefinedOn'](_0x3301e7['node']),_0x15a818['push'](_0x3301e7),_0x3301e7=_0x2ef85a['getNext']();let _0x25e514;_0x2e8b8a?_0x25e514=dn(_0x15a818,_0x411547['getCompare']()):_0x25e514=je;const _0x498639=_0x411547['toString'](),_0x496eb6={...this['indexSet_']};_0x496eb6[_0x498639]=_0x411547;const _0x15c9a6={...this['indexes_']};return _0x15c9a6[_0x498639]=_0x25e514,new ee(_0x15c9a6,_0x496eb6);}['addToIndexes'](_0x1f60e7,_0x525425){const _0x539023=ln(this['indexes_'],(_0x6ee3b5,_0x16127d)=>{const _0x35fdfd=Oe(this['indexSet_'],_0x16127d);if(f(_0x35fdfd,'Missing\x20index\x20implementation\x20for\x20'+_0x16127d),_0x6ee3b5===je){if(_0x35fdfd['isDefinedOn'](_0x1f60e7['node'])){const _0x27525f=[],_0xafd8c5=_0x525425['getIterator'](E['Wrap']);let _0x1b29e3=_0xafd8c5['getNext']();for(;_0x1b29e3;)_0x1b29e3['name']!==_0x1f60e7['name']&&_0x27525f['push'](_0x1b29e3),_0x1b29e3=_0xafd8c5['getNext']();return _0x27525f['push'](_0x1f60e7),dn(_0x27525f,_0x35fdfd['getCompare']());}else return je;}else{const _0x55eda7=_0x525425['get'](_0x1f60e7['name']);let _0x40377c=_0x6ee3b5;return _0x55eda7&&(_0x40377c=_0x40377c['remove'](new E(_0x1f60e7['name'],_0x55eda7))),_0x40377c['insert'](_0x1f60e7,_0x1f60e7['node']);}});return new ee(_0x539023,this['indexSet_']);}['removeFromIndexes'](_0x1e0dbd,_0x1a48c6){const _0x594cd9=ln(this['indexes_'],_0x30fa79=>{if(_0x30fa79===je)return _0x30fa79;{const _0xb6f426=_0x1a48c6['get'](_0x1e0dbd['name']);return _0xb6f426?_0x30fa79['remove'](new E(_0x1e0dbd['name'],_0xb6f426)):_0x30fa79;}});return new ee(_0x594cd9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2cef0c,_0x7befc6,_0x4e11f1){this['children_']=_0x2cef0c,this['priorityNode_']=_0x7befc6,this['indexMap_']=_0x4e11f1,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x5486b3){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5486b3,this['indexMap_']);}['getImmediateChild'](_0x356062){if(_0x356062==='.priority')return this['getPriority']();{const _0x3e72c9=this['children_']['get'](_0x356062);return _0x3e72c9===null?gt:_0x3e72c9;}}['getChild'](_0x48293c){const _0x4466a2=y(_0x48293c);return _0x4466a2===null?this:this['getImmediateChild'](_0x4466a2)['getChild'](b(_0x48293c));}['hasChild'](_0x52f0af){return this['children_']['get'](_0x52f0af)!==null;}['updateImmediateChild'](_0x1fde04,_0x259f9f){if(f(_0x259f9f,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1fde04==='.priority')return this['updatePriority'](_0x259f9f);{const _0x27f956=new E(_0x1fde04,_0x259f9f);let _0x4fc770,_0x52ad84;_0x259f9f['isEmpty']()?(_0x4fc770=this['children_']['remove'](_0x1fde04),_0x52ad84=this['indexMap_']['removeFromIndexes'](_0x27f956,this['children_'])):(_0x4fc770=this['children_']['insert'](_0x1fde04,_0x259f9f),_0x52ad84=this['indexMap_']['addToIndexes'](_0x27f956,this['children_']));const _0x3e47e0=_0x4fc770['isEmpty']()?gt:this['priorityNode_'];return new g(_0x4fc770,_0x3e47e0,_0x52ad84);}}['updateChild'](_0x137ff1,_0x229493){const _0x3b96d8=y(_0x137ff1);if(_0x3b96d8===null)return _0x229493;{f(y(_0x137ff1)!=='.priority'||we(_0x137ff1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x45b055=this['getImmediateChild'](_0x3b96d8)['updateChild'](b(_0x137ff1),_0x229493);return this['updateImmediateChild'](_0x3b96d8,_0x45b055);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x349f16){if(this['isEmpty']())return null;const _0xf7662={};let _0x5b12ea=0x0,_0x5078d8=0x0,_0x419a0c=!0x0;if(this['forEachChild'](R,(_0x50fb1d,_0x47cc7a)=>{_0xf7662[_0x50fb1d]=_0x47cc7a['val'](_0x349f16),_0x5b12ea++,_0x419a0c&&g['INTEGER_REGEXP_']['test'](_0x50fb1d)?_0x5078d8=Math['max'](_0x5078d8,Number(_0x50fb1d)):_0x419a0c=!0x1;}),!_0x349f16&&_0x419a0c&&_0x5078d8<0x2*_0x5b12ea){const _0x300ab2=[];for(const _0x33680c in _0xf7662)_0x300ab2[_0x33680c]=_0xf7662[_0x33680c];return _0x300ab2;}else return _0x349f16&&!this['getPriority']()['isEmpty']()&&(_0xf7662['.priority']=this['getPriority']()['val']()),_0xf7662;}['hash'](){if(this['lazyHash_']===null){let _0x56329f='';this['getPriority']()['isEmpty']()||(_0x56329f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1ee9e2,_0x608dcf)=>{const _0x1ba545=_0x608dcf['hash']();_0x1ba545!==''&&(_0x56329f+=':'+_0x1ee9e2+':'+_0x1ba545);}),this['lazyHash_']=_0x56329f===''?'':no(_0x56329f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x444196,_0xf320c1,_0x265727){const _0x260d70=this['resolveIndex_'](_0x265727);if(_0x260d70){const _0x1a35f8=_0x260d70['getPredecessorKey'](new E(_0x444196,_0xf320c1));return _0x1a35f8?_0x1a35f8['name']:null;}else return this['children_']['getPredecessorKey'](_0x444196);}['getFirstChildName'](_0x1ccb09){const _0x43ede7=this['resolveIndex_'](_0x1ccb09);if(_0x43ede7){const _0x90feb5=_0x43ede7['minKey']();return _0x90feb5&&_0x90feb5['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x54db8a){const _0x351394=this['getFirstChildName'](_0x54db8a);return _0x351394?new E(_0x351394,this['children_']['get'](_0x351394)):null;}['getLastChildName'](_0x330c53){const _0x58926f=this['resolveIndex_'](_0x330c53);if(_0x58926f){const _0x511839=_0x58926f['maxKey']();return _0x511839&&_0x511839['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x54addf){const _0x3ed7c4=this['getLastChildName'](_0x54addf);return _0x3ed7c4?new E(_0x3ed7c4,this['children_']['get'](_0x3ed7c4)):null;}['forEachChild'](_0x1e7f5b,_0x20841a){const _0x438e3d=this['resolveIndex_'](_0x1e7f5b);return _0x438e3d?_0x438e3d['inorderTraversal'](_0x50e78b=>_0x20841a(_0x50e78b['name'],_0x50e78b['node'])):this['children_']['inorderTraversal'](_0x20841a);}['getIterator'](_0x20cc6f){return this['getIteratorFrom'](_0x20cc6f['minPost'](),_0x20cc6f);}['getIteratorFrom'](_0x3a1dcb,_0x47497b){const _0xdcd9c6=this['resolveIndex_'](_0x47497b);if(_0xdcd9c6)return _0xdcd9c6['getIteratorFrom'](_0x3a1dcb,_0x2b7fac=>_0x2b7fac);{const _0x4aa1a2=this['children_']['getIteratorFrom'](_0x3a1dcb['name'],E['Wrap']);let _0xa782f=_0x4aa1a2['peek']();for(;_0xa782f!=null&&_0x47497b['compare'](_0xa782f,_0x3a1dcb)<0x0;)_0x4aa1a2['getNext'](),_0xa782f=_0x4aa1a2['peek']();return _0x4aa1a2;}}['getReverseIterator'](_0x160195){return this['getReverseIteratorFrom'](_0x160195['maxPost'](),_0x160195);}['getReverseIteratorFrom'](_0x1290aa,_0x4e1022){const _0x3ca363=this['resolveIndex_'](_0x4e1022);if(_0x3ca363)return _0x3ca363['getReverseIteratorFrom'](_0x1290aa,_0x57b8f4=>_0x57b8f4);{const _0x44ff94=this['children_']['getReverseIteratorFrom'](_0x1290aa['name'],E['Wrap']);let _0x2f1c6e=_0x44ff94['peek']();for(;_0x2f1c6e!=null&&_0x4e1022['compare'](_0x2f1c6e,_0x1290aa)>0x0;)_0x44ff94['getNext'](),_0x2f1c6e=_0x44ff94['peek']();return _0x44ff94;}}['compareTo'](_0x5cb4de){return this['isEmpty']()?_0x5cb4de['isEmpty']()?0x0:-0x1:_0x5cb4de['isLeafNode']()||_0x5cb4de['isEmpty']()?0x1:_0x5cb4de===Ht?-0x1:0x0;}['withIndex'](_0x5a7d7f){if(_0x5a7d7f===ye||this['indexMap_']['hasIndex'](_0x5a7d7f))return this;{const _0x366e20=this['indexMap_']['addIndex'](_0x5a7d7f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x366e20);}}['isIndexed'](_0x44f679){return _0x44f679===ye||this['indexMap_']['hasIndex'](_0x44f679);}['equals'](_0x669cf6){if(_0x669cf6===this)return!0x0;if(_0x669cf6['isLeafNode']())return!0x1;{const _0x23a039=_0x669cf6;if(this['getPriority']()['equals'](_0x23a039['getPriority']())){if(this['children_']['count']()===_0x23a039['children_']['count']()){const _0x509931=this['getIterator'](R),_0x2626c3=_0x23a039['getIterator'](R);let _0x1eaf35=_0x509931['getNext'](),_0x4658fb=_0x2626c3['getNext']();for(;_0x1eaf35&&_0x4658fb;){if(_0x1eaf35['name']!==_0x4658fb['name']||!_0x1eaf35['node']['equals'](_0x4658fb['node']))return!0x1;_0x1eaf35=_0x509931['getNext'](),_0x4658fb=_0x2626c3['getNext']();}return _0x1eaf35===null&&_0x4658fb===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x828291){return _0x828291===ye?null:this['indexMap_']['get'](_0x828291['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x141eb6){return _0x141eb6===this?0x0:0x1;}['equals'](_0x5995a5){return _0x5995a5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3ccec7){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5344e5,_0x59bb08=null){if(_0x5344e5===null)return g['EMPTY_NODE'];if(typeof _0x5344e5=='object'&&'.priority'in _0x5344e5&&(_0x59bb08=_0x5344e5['.priority']),f(_0x59bb08===null||typeof _0x59bb08=='string'||typeof _0x59bb08=='number'||typeof _0x59bb08=='object'&&'.sv'in _0x59bb08,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x59bb08),typeof _0x5344e5=='object'&&'.value'in _0x5344e5&&_0x5344e5['.value']!==null&&(_0x5344e5=_0x5344e5['.value']),typeof _0x5344e5!='object'||'.sv'in _0x5344e5){const _0x54823a=_0x5344e5;return new D(_0x54823a,N(_0x59bb08));}if(!(_0x5344e5 instanceof Array)&&Vh){const _0x2a7bc8=[];let _0x54a882=!0x1;if(x(_0x5344e5,(_0x5f084c,_0x1b99cc)=>{if(_0x5f084c['substring'](0x0,0x1)!=='.'){const _0xc1df8f=N(_0x1b99cc);_0xc1df8f['isEmpty']()||(_0x54a882=_0x54a882||!_0xc1df8f['getPriority']()['isEmpty'](),_0x2a7bc8['push'](new E(_0x5f084c,_0xc1df8f)));}}),_0x2a7bc8['length']===0x0)return g['EMPTY_NODE'];const _0x1950da=dn(_0x2a7bc8,Dh,_0x5e104e=>_0x5e104e['name'],ji);if(_0x54a882){const _0x15edd6=dn(_0x2a7bc8,R['getCompare']());return new g(_0x1950da,N(_0x59bb08),new ee({'.priority':_0x15edd6},{'.priority':R}));}else return new g(_0x1950da,N(_0x59bb08),ee['Default']);}else{let _0x345eea=g['EMPTY_NODE'];return x(_0x5344e5,(_0x5a5ede,_0x5d6547)=>{if(Y(_0x5344e5,_0x5a5ede)&&_0x5a5ede['substring'](0x0,0x1)!=='.'){const _0x42c25c=N(_0x5d6547);(_0x42c25c['isLeafNode']()||!_0x42c25c['isEmpty']())&&(_0x345eea=_0x345eea['updateImmediateChild'](_0x5a5ede,_0x42c25c));}}),_0x345eea['updatePriority'](N(_0x59bb08));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3b3e3a){super(),this['indexPath_']=_0x3b3e3a,f(!v(_0x3b3e3a)&&y(_0x3b3e3a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x199c24){return _0x199c24['getChild'](this['indexPath_']);}['isDefinedOn'](_0x5a566f){return!_0x5a566f['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4e7a2f,_0x36fc21){const _0x43b06f=this['extractChild'](_0x4e7a2f['node']),_0x16cb3b=this['extractChild'](_0x36fc21['node']),_0x5b8843=_0x43b06f['compareTo'](_0x16cb3b);return _0x5b8843===0x0?He(_0x4e7a2f['name'],_0x36fc21['name']):_0x5b8843;}['makePost'](_0x31a2ce,_0x4984fb){const _0xca039e=N(_0x31a2ce),_0xc8d100=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xca039e);return new E(_0x4984fb,_0xc8d100);}['maxPost'](){const _0x75c16e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x75c16e);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x3cd697,_0x4a916b){const _0x3f1b63=_0x3cd697['node']['compareTo'](_0x4a916b['node']);return _0x3f1b63===0x0?He(_0x3cd697['name'],_0x4a916b['name']):_0x3f1b63;}['isDefinedOn'](_0x3b4432){return!0x0;}['indexedValueChanged'](_0x4558b4,_0x4a206f){return!_0x4558b4['equals'](_0x4a206f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5e722a,_0x143de6){const _0x280fd3=N(_0x5e722a);return new E(_0x143de6,_0x280fd3);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x26f8bf){return{'type':'value','snapshotNode':_0x26f8bf};}function tt(_0x2eff4d,_0x2fdcae){return{'type':'child_added','snapshotNode':_0x2fdcae,'childName':_0x2eff4d};}function Nt(_0xb1416c,_0x440f42){return{'type':'child_removed','snapshotNode':_0x440f42,'childName':_0xb1416c};}function Pt(_0x3bbeb4,_0x15a151,_0x28cef4){return{'type':'child_changed','snapshotNode':_0x15a151,'childName':_0x3bbeb4,'oldSnap':_0x28cef4};}function $h(_0x12bbf8,_0x1d85d8){return{'type':'child_moved','snapshotNode':_0x1d85d8,'childName':_0x12bbf8};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x19f55b){this['index_']=_0x19f55b;}['updateChild'](_0x5e71a4,_0x573f40,_0x19a52d,_0x48a41c,_0x2ca080,_0xf0991){f(_0x5e71a4['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x394fa7=_0x5e71a4['getImmediateChild'](_0x573f40);return _0x394fa7['getChild'](_0x48a41c)['equals'](_0x19a52d['getChild'](_0x48a41c))&&_0x394fa7['isEmpty']()===_0x19a52d['isEmpty']()||(_0xf0991!=null&&(_0x19a52d['isEmpty']()?_0x5e71a4['hasChild'](_0x573f40)?_0xf0991['trackChildChange'](Nt(_0x573f40,_0x394fa7)):f(_0x5e71a4['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x394fa7['isEmpty']()?_0xf0991['trackChildChange'](tt(_0x573f40,_0x19a52d)):_0xf0991['trackChildChange'](Pt(_0x573f40,_0x19a52d,_0x394fa7))),_0x5e71a4['isLeafNode']()&&_0x19a52d['isEmpty']())?_0x5e71a4:_0x5e71a4['updateImmediateChild'](_0x573f40,_0x19a52d)['withIndex'](this['index_']);}['updateFullNode'](_0x5687c2,_0x3025ea,_0x30e636){return _0x30e636!=null&&(_0x5687c2['isLeafNode']()||_0x5687c2['forEachChild'](R,(_0x1b760e,_0x213892)=>{_0x3025ea['hasChild'](_0x1b760e)||_0x30e636['trackChildChange'](Nt(_0x1b760e,_0x213892));}),_0x3025ea['isLeafNode']()||_0x3025ea['forEachChild'](R,(_0x3b9481,_0x580c57)=>{if(_0x5687c2['hasChild'](_0x3b9481)){const _0x37db3=_0x5687c2['getImmediateChild'](_0x3b9481);_0x37db3['equals'](_0x580c57)||_0x30e636['trackChildChange'](Pt(_0x3b9481,_0x580c57,_0x37db3));}else _0x30e636['trackChildChange'](tt(_0x3b9481,_0x580c57));})),_0x3025ea['withIndex'](this['index_']);}['updatePriority'](_0x127592,_0x4776fb){return _0x127592['isEmpty']()?g['EMPTY_NODE']:_0x127592['updatePriority'](_0x4776fb);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x303a0f){this['indexedFilter_']=new Yi(_0x303a0f['getIndex']()),this['index_']=_0x303a0f['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x303a0f),this['endPost_']=Ot['getEndPost_'](_0x303a0f),this['startIsInclusive_']=!_0x303a0f['startAfterSet_'],this['endIsInclusive_']=!_0x303a0f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x17be85){const _0x2c32c3=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x17be85)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x17be85)<0x0,_0x416b80=this['endIsInclusive_']?this['index_']['compare'](_0x17be85,this['getEndPost']())<=0x0:this['index_']['compare'](_0x17be85,this['getEndPost']())<0x0;return _0x2c32c3&&_0x416b80;}['updateChild'](_0x58612d,_0x417209,_0x3f88bf,_0x488660,_0x58725b,_0x5449be){return this['matches'](new E(_0x417209,_0x3f88bf))||(_0x3f88bf=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x58612d,_0x417209,_0x3f88bf,_0x488660,_0x58725b,_0x5449be);}['updateFullNode'](_0x3d7cc2,_0x1a44a8,_0x46da0a){_0x1a44a8['isLeafNode']()&&(_0x1a44a8=g['EMPTY_NODE']);let _0x3bc068=_0x1a44a8['withIndex'](this['index_']);_0x3bc068=_0x3bc068['updatePriority'](g['EMPTY_NODE']);const _0x1b7815=this;return _0x1a44a8['forEachChild'](R,(_0x3abbbb,_0x202a66)=>{_0x1b7815['matches'](new E(_0x3abbbb,_0x202a66))||(_0x3bc068=_0x3bc068['updateImmediateChild'](_0x3abbbb,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3d7cc2,_0x3bc068,_0x46da0a);}['updatePriority'](_0x186e18,_0x3e2907){return _0x186e18;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x590a32){if(_0x590a32['hasStart']()){const _0x1321f0=_0x590a32['getIndexStartName']();return _0x590a32['getIndex']()['makePost'](_0x590a32['getIndexStartValue'](),_0x1321f0);}else return _0x590a32['getIndex']()['minPost']();}static['getEndPost_'](_0x6005d0){if(_0x6005d0['hasEnd']()){const _0x56bda6=_0x6005d0['getIndexEndName']();return _0x6005d0['getIndex']()['makePost'](_0x6005d0['getIndexEndValue'](),_0x56bda6);}else return _0x6005d0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x4db349){this['withinDirectionalStart']=_0x1838be=>this['reverse_']?this['withinEndPost'](_0x1838be):this['withinStartPost'](_0x1838be),this['withinDirectionalEnd']=_0x3ae470=>this['reverse_']?this['withinStartPost'](_0x3ae470):this['withinEndPost'](_0x3ae470),this['withinStartPost']=_0x4aa6e1=>{const _0x3efc25=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4aa6e1);return this['startIsInclusive_']?_0x3efc25<=0x0:_0x3efc25<0x0;},this['withinEndPost']=_0x417a79=>{const _0x409cb0=this['index_']['compare'](_0x417a79,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x409cb0<=0x0:_0x409cb0<0x0;},this['rangedFilter_']=new Ot(_0x4db349),this['index_']=_0x4db349['getIndex'](),this['limit_']=_0x4db349['getLimit'](),this['reverse_']=!_0x4db349['isViewFromLeft'](),this['startIsInclusive_']=!_0x4db349['startAfterSet_'],this['endIsInclusive_']=!_0x4db349['endBeforeSet_'];}['updateChild'](_0x3da2d6,_0x371bbb,_0x48681d,_0x17ae30,_0x1bafa9,_0x214ed8){return this['rangedFilter_']['matches'](new E(_0x371bbb,_0x48681d))||(_0x48681d=g['EMPTY_NODE']),_0x3da2d6['getImmediateChild'](_0x371bbb)['equals'](_0x48681d)?_0x3da2d6:_0x3da2d6['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x3da2d6,_0x371bbb,_0x48681d,_0x17ae30,_0x1bafa9,_0x214ed8):this['fullLimitUpdateChild_'](_0x3da2d6,_0x371bbb,_0x48681d,_0x1bafa9,_0x214ed8);}['updateFullNode'](_0x4a2c9b,_0x4d3dc8,_0x178526){let _0x201bfe;if(_0x4d3dc8['isLeafNode']()||_0x4d3dc8['isEmpty']())_0x201bfe=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4d3dc8['numChildren']()&&_0x4d3dc8['isIndexed'](this['index_'])){_0x201bfe=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xb0d1a5;this['reverse_']?_0xb0d1a5=_0x4d3dc8['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xb0d1a5=_0x4d3dc8['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1fe5fc=0x0;for(;_0xb0d1a5['hasNext']()&&_0x1fe5fc<this['limit_'];){const _0x1bb5d3=_0xb0d1a5['getNext']();if(this['withinDirectionalStart'](_0x1bb5d3)){if(this['withinDirectionalEnd'](_0x1bb5d3))_0x201bfe=_0x201bfe['updateImmediateChild'](_0x1bb5d3['name'],_0x1bb5d3['node']),_0x1fe5fc++;else break;}else continue;}}else{_0x201bfe=_0x4d3dc8['withIndex'](this['index_']),_0x201bfe=_0x201bfe['updatePriority'](g['EMPTY_NODE']);let _0x226896;this['reverse_']?_0x226896=_0x201bfe['getReverseIterator'](this['index_']):_0x226896=_0x201bfe['getIterator'](this['index_']);let _0x439da0=0x0;for(;_0x226896['hasNext']();){const _0x5f57bd=_0x226896['getNext']();_0x439da0<this['limit_']&&this['withinDirectionalStart'](_0x5f57bd)&&this['withinDirectionalEnd'](_0x5f57bd)?_0x439da0++:_0x201bfe=_0x201bfe['updateImmediateChild'](_0x5f57bd['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4a2c9b,_0x201bfe,_0x178526);}['updatePriority'](_0x42c075,_0x117205){return _0x42c075;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x463903,_0x18271c,_0x168d0a,_0x47a0e7,_0x4de73b){let _0x37ad79;if(this['reverse_']){const _0x4b899e=this['index_']['getCompare']();_0x37ad79=(_0xfab47,_0x500836)=>_0x4b899e(_0x500836,_0xfab47);}else _0x37ad79=this['index_']['getCompare']();const _0x3eb36b=_0x463903;f(_0x3eb36b['numChildren']()===this['limit_'],'');const _0x500af4=new E(_0x18271c,_0x168d0a),_0x4e5ab9=this['reverse_']?_0x3eb36b['getFirstChild'](this['index_']):_0x3eb36b['getLastChild'](this['index_']),_0x571aae=this['rangedFilter_']['matches'](_0x500af4);if(_0x3eb36b['hasChild'](_0x18271c)){const _0x50425b=_0x3eb36b['getImmediateChild'](_0x18271c);let _0x249550=_0x47a0e7['getChildAfterChild'](this['index_'],_0x4e5ab9,this['reverse_']);for(;_0x249550!=null&&(_0x249550['name']===_0x18271c||_0x3eb36b['hasChild'](_0x249550['name']));)_0x249550=_0x47a0e7['getChildAfterChild'](this['index_'],_0x249550,this['reverse_']);const _0x55ce5c=_0x249550==null?0x1:_0x37ad79(_0x249550,_0x500af4);if(_0x571aae&&!_0x168d0a['isEmpty']()&&_0x55ce5c>=0x0)return _0x4de73b!=null&&_0x4de73b['trackChildChange'](Pt(_0x18271c,_0x168d0a,_0x50425b)),_0x3eb36b['updateImmediateChild'](_0x18271c,_0x168d0a);{_0x4de73b!=null&&_0x4de73b['trackChildChange'](Nt(_0x18271c,_0x50425b));const _0x27fcd7=_0x3eb36b['updateImmediateChild'](_0x18271c,g['EMPTY_NODE']);return _0x249550!=null&&this['rangedFilter_']['matches'](_0x249550)?(_0x4de73b!=null&&_0x4de73b['trackChildChange'](tt(_0x249550['name'],_0x249550['node'])),_0x27fcd7['updateImmediateChild'](_0x249550['name'],_0x249550['node'])):_0x27fcd7;}}else return _0x168d0a['isEmpty']()?_0x463903:_0x571aae&&_0x37ad79(_0x4e5ab9,_0x500af4)>=0x0?(_0x4de73b!=null&&(_0x4de73b['trackChildChange'](Nt(_0x4e5ab9['name'],_0x4e5ab9['node'])),_0x4de73b['trackChildChange'](tt(_0x18271c,_0x168d0a))),_0x3eb36b['updateImmediateChild'](_0x18271c,_0x168d0a)['updateImmediateChild'](_0x4e5ab9['name'],g['EMPTY_NODE'])):_0x463903;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xe3185d=new Qi();return _0xe3185d['limitSet_']=this['limitSet_'],_0xe3185d['limit_']=this['limit_'],_0xe3185d['startSet_']=this['startSet_'],_0xe3185d['startAfterSet_']=this['startAfterSet_'],_0xe3185d['indexStartValue_']=this['indexStartValue_'],_0xe3185d['startNameSet_']=this['startNameSet_'],_0xe3185d['indexStartName_']=this['indexStartName_'],_0xe3185d['endSet_']=this['endSet_'],_0xe3185d['endBeforeSet_']=this['endBeforeSet_'],_0xe3185d['indexEndValue_']=this['indexEndValue_'],_0xe3185d['endNameSet_']=this['endNameSet_'],_0xe3185d['indexEndName_']=this['indexEndName_'],_0xe3185d['index_']=this['index_'],_0xe3185d['viewFrom_']=this['viewFrom_'],_0xe3185d;}}function qh(_0x2052dc){return _0x2052dc['loadsAllData']()?new Yi(_0x2052dc['getIndex']()):_0x2052dc['hasLimit']()?new Gh(_0x2052dc):new Ot(_0x2052dc);}function zh(_0x431e65,_0x1c1fc7){const _0x15ec61=_0x431e65['copy']();return _0x15ec61['limitSet_']=!0x0,_0x15ec61['limit_']=_0x1c1fc7,_0x15ec61['viewFrom_']='l',_0x15ec61;}function jh(_0x158ad7,_0x41fcd7,_0x2c8dc0){const _0x3c6c6a=_0x158ad7['copy']();return _0x3c6c6a['startSet_']=!0x0,_0x41fcd7===void 0x0&&(_0x41fcd7=null),_0x3c6c6a['indexStartValue_']=_0x41fcd7,_0x2c8dc0!=null?(_0x3c6c6a['startNameSet_']=!0x0,_0x3c6c6a['indexStartName_']=_0x2c8dc0):(_0x3c6c6a['startNameSet_']=!0x1,_0x3c6c6a['indexStartName_']=''),_0x3c6c6a;}function Kh(_0x3b29e4,_0x280043,_0x2b8de2){const _0x79bec6=_0x3b29e4['copy']();return _0x79bec6['endSet_']=!0x0,_0x280043===void 0x0&&(_0x280043=null),_0x79bec6['indexEndValue_']=_0x280043,_0x2b8de2!==void 0x0?(_0x79bec6['endNameSet_']=!0x0,_0x79bec6['indexEndName_']=_0x2b8de2):(_0x79bec6['endNameSet_']=!0x1,_0x79bec6['indexEndName_']=''),_0x79bec6;}function Do(_0xacbc9e,_0x3a8376){const _0x2605a9=_0xacbc9e['copy']();return _0x2605a9['index_']=_0x3a8376,_0x2605a9;}function tr(_0xa90dfc){const _0x4b1198={};if(_0xa90dfc['isDefault']())return _0x4b1198;let _0x57a036;if(_0xa90dfc['index_']===R?_0x57a036='$priority':_0xa90dfc['index_']===Po?_0x57a036='$value':_0xa90dfc['index_']===ye?_0x57a036='$key':(f(_0xa90dfc['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x57a036=_0xa90dfc['index_']['toString']()),_0x4b1198['orderBy']=O(_0x57a036),_0xa90dfc['startSet_']){const _0x3c6832=_0xa90dfc['startAfterSet_']?'startAfter':'startAt';_0x4b1198[_0x3c6832]=O(_0xa90dfc['indexStartValue_']),_0xa90dfc['startNameSet_']&&(_0x4b1198[_0x3c6832]+=','+O(_0xa90dfc['indexStartName_']));}if(_0xa90dfc['endSet_']){const _0x4747f8=_0xa90dfc['endBeforeSet_']?'endBefore':'endAt';_0x4b1198[_0x4747f8]=O(_0xa90dfc['indexEndValue_']),_0xa90dfc['endNameSet_']&&(_0x4b1198[_0x4747f8]+=','+O(_0xa90dfc['indexEndName_']));}return _0xa90dfc['limitSet_']&&(_0xa90dfc['isViewFromLeft']()?_0x4b1198['limitToFirst']=_0xa90dfc['limit_']:_0x4b1198['limitToLast']=_0xa90dfc['limit_']),_0x4b1198;}function nr(_0x6a0a68){const _0x59f6cc={};if(_0x6a0a68['startSet_']&&(_0x59f6cc['sp']=_0x6a0a68['indexStartValue_'],_0x6a0a68['startNameSet_']&&(_0x59f6cc['sn']=_0x6a0a68['indexStartName_']),_0x59f6cc['sin']=!_0x6a0a68['startAfterSet_']),_0x6a0a68['endSet_']&&(_0x59f6cc['ep']=_0x6a0a68['indexEndValue_'],_0x6a0a68['endNameSet_']&&(_0x59f6cc['en']=_0x6a0a68['indexEndName_']),_0x59f6cc['ein']=!_0x6a0a68['endBeforeSet_']),_0x6a0a68['limitSet_']){_0x59f6cc['l']=_0x6a0a68['limit_'];let _0x263db4=_0x6a0a68['viewFrom_'];_0x263db4===''&&(_0x6a0a68['isViewFromLeft']()?_0x263db4='l':_0x263db4='r'),_0x59f6cc['vf']=_0x263db4;}return _0x6a0a68['index_']!==R&&(_0x59f6cc['i']=_0x6a0a68['index_']['toString']()),_0x59f6cc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x261996){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4a830d,_0x305ddf){return _0x305ddf!==void 0x0?'tag$'+_0x305ddf:(f(_0x4a830d['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4a830d['_path']['toString']());}constructor(_0x583a5d,_0x1cf430,_0x4f9ce5,_0x395970){super(),this['repoInfo_']=_0x583a5d,this['onDataUpdate_']=_0x1cf430,this['authTokenProvider_']=_0x4f9ce5,this['appCheckTokenProvider_']=_0x395970,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x29f507,_0x5358d3,_0x36cf92,_0x2f690d){const _0x297bda=_0x29f507['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x297bda+'\x20'+_0x29f507['_queryIdentifier']);const _0x291d62=fn['getListenId_'](_0x29f507,_0x36cf92),_0x3d7038={};this['listens_'][_0x291d62]=_0x3d7038;const _0x48d8f9=tr(_0x29f507['_queryParams']);this['restRequest_'](_0x297bda+'.json',_0x48d8f9,(_0x1b3b11,_0x4c1925)=>{let _0xf124c2=_0x4c1925;if(_0x1b3b11===0x194&&(_0xf124c2=null,_0x1b3b11=null),_0x1b3b11===null&&this['onDataUpdate_'](_0x297bda,_0xf124c2,!0x1,_0x36cf92),Oe(this['listens_'],_0x291d62)===_0x3d7038){let _0x59bb5c;_0x1b3b11?_0x1b3b11===0x191?_0x59bb5c='permission_denied':_0x59bb5c='rest_error:'+_0x1b3b11:_0x59bb5c='ok',_0x2f690d(_0x59bb5c,null);}});}['unlisten'](_0x5795e3,_0xf6273d){const _0x1e1f88=fn['getListenId_'](_0x5795e3,_0xf6273d);delete this['listens_'][_0x1e1f88];}['get'](_0x5a4945){const _0x30fe9e=tr(_0x5a4945['_queryParams']),_0x5564b3=_0x5a4945['_path']['toString'](),_0x2c92e3=new Ve();return this['restRequest_'](_0x5564b3+'.json',_0x30fe9e,(_0x487ad2,_0x18dca5)=>{let _0x5e2a2f=_0x18dca5;_0x487ad2===0x194&&(_0x5e2a2f=null,_0x487ad2=null),_0x487ad2===null?(this['onDataUpdate_'](_0x5564b3,_0x5e2a2f,!0x1,null),_0x2c92e3['resolve'](_0x5e2a2f)):_0x2c92e3['reject'](new Error(_0x5e2a2f));}),_0x2c92e3['promise'];}['refreshAuthToken'](_0x275ae8){}['restRequest_'](_0x108f77,_0x9d095c={},_0x1fc937){return _0x9d095c['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x291adc,_0x3b83e9])=>{_0x291adc&&_0x291adc['accessToken']&&(_0x9d095c['auth']=_0x291adc['accessToken']),_0x3b83e9&&_0x3b83e9['token']&&(_0x9d095c['ac']=_0x3b83e9['token']);const _0x48fe71=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x108f77+'?ns='+this['repoInfo_']['namespace']+at(_0x9d095c);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x48fe71);const _0x42fc06=new XMLHttpRequest();_0x42fc06['onreadystatechange']=()=>{if(_0x1fc937&&_0x42fc06['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x48fe71+'\x20received.\x20status:',_0x42fc06['status'],'response:',_0x42fc06['responseText']);let _0x316a69=null;if(_0x42fc06['status']>=0xc8&&_0x42fc06['status']<0x12c){try{_0x316a69=bt(_0x42fc06['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x48fe71+':\x20'+_0x42fc06['responseText']);}_0x1fc937(null,_0x316a69);}else _0x42fc06['status']!==0x191&&_0x42fc06['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x48fe71+'\x20Status:\x20'+_0x42fc06['status']),_0x1fc937(_0x42fc06['status']);_0x1fc937=null;}},_0x42fc06['open']('GET',_0x48fe71,!0x0),_0x42fc06['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x37a027){return this['rootNode_']['getChild'](_0x37a027);}['updateSnapshot'](_0x5cbbd8,_0x478d95){this['rootNode_']=this['rootNode_']['updateChild'](_0x5cbbd8,_0x478d95);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x47b769,_0x277c85,_0x3d4b28){if(v(_0x277c85))_0x47b769['value']=_0x3d4b28,_0x47b769['children']['clear']();else{if(_0x47b769['value']!==null)_0x47b769['value']=_0x47b769['value']['updateChild'](_0x277c85,_0x3d4b28);else{const _0x22d6c0=y(_0x277c85);_0x47b769['children']['has'](_0x22d6c0)||_0x47b769['children']['set'](_0x22d6c0,pn());const _0x5db8bc=_0x47b769['children']['get'](_0x22d6c0);_0x277c85=b(_0x277c85),Mo(_0x5db8bc,_0x277c85,_0x3d4b28);}}}function Ei(_0x8c93e8,_0x3a2875,_0x15f702){_0x8c93e8['value']!==null?_0x15f702(_0x3a2875,_0x8c93e8['value']):Qh(_0x8c93e8,(_0x1ef72c,_0xb4db01)=>{const _0x486d9b=new C(_0x3a2875['toString']()+'/'+_0x1ef72c);Ei(_0xb4db01,_0x486d9b,_0x15f702);});}function Qh(_0x31b0b7,_0x9c32c6){_0x31b0b7['children']['forEach']((_0x5be3af,_0x5cd2e2)=>{_0x9c32c6(_0x5cd2e2,_0x5be3af);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x3260e4){this['collection_']=_0x3260e4,this['last_']=null;}['get'](){const _0x3d32b0=this['collection_']['get'](),_0x4da373={..._0x3d32b0};return this['last_']&&x(this['last_'],(_0x401780,_0x17b6ac)=>{_0x4da373[_0x401780]=_0x4da373[_0x401780]-_0x17b6ac;}),this['last_']=_0x3d32b0,_0x4da373;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x26e878,_0x5864f9){this['server_']=_0x5864f9,this['statsToReport_']={},this['statsListener_']=new Jh(_0x26e878);const _0x2c4059=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2c4059));}['reportStats_'](){const _0x5a3c76=this['statsListener_']['get'](),_0x2006c2={};let _0x1717f8=!0x1;x(_0x5a3c76,(_0x44ebed,_0x46d5dc)=>{_0x46d5dc>0x0&&Y(this['statsToReport_'],_0x44ebed)&&(_0x2006c2[_0x44ebed]=_0x46d5dc,_0x1717f8=!0x0);}),_0x1717f8&&this['server_']['reportStats'](_0x2006c2),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x3e6304){_0x3e6304[_0x3e6304['OVERWRITE']=0x0]='OVERWRITE',_0x3e6304[_0x3e6304['MERGE']=0x1]='MERGE',_0x3e6304[_0x3e6304['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3e6304[_0x3e6304['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x320d4e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x320d4e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x39f330,_0x131a2c,_0x5aea96){this['path']=_0x39f330,this['affectedTree']=_0x131a2c,this['revert']=_0x5aea96,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x558130){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2068ea=this['affectedTree']['subtree'](new C(_0x558130));return new _n(w(),_0x2068ea,this['revert']);}}else return f(y(this['path'])===_0x558130,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x1ad05c,_0x43f1e5){this['source']=_0x1ad05c,this['path']=_0x43f1e5,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1dd5b8){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2c0ed6,_0x2007b2,_0x2ced18){this['source']=_0x2c0ed6,this['path']=_0x2007b2,this['snap']=_0x2ced18,this['type']=q['OVERWRITE'];}['operationForChild'](_0x3a561b){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x3a561b)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xa3ac3d,_0x565eb3,_0x5514b6){this['source']=_0xa3ac3d,this['path']=_0x565eb3,this['children']=_0x5514b6,this['type']=q['MERGE'];}['operationForChild'](_0x362bc0){if(v(this['path'])){const _0x8d0eef=this['children']['subtree'](new C(_0x362bc0));return _0x8d0eef['isEmpty']()?null:_0x8d0eef['value']?new Fe(this['source'],w(),_0x8d0eef['value']):new nt(this['source'],w(),_0x8d0eef);}else return f(y(this['path'])===_0x362bc0,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x45400a,_0x5cf58a,_0x14dda5){this['node_']=_0x45400a,this['fullyInitialized_']=_0x5cf58a,this['filtered_']=_0x14dda5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x40d8dd){if(v(_0x40d8dd))return this['isFullyInitialized']()&&!this['filtered_'];const _0x427c93=y(_0x40d8dd);return this['isCompleteForChild'](_0x427c93);}['isCompleteForChild'](_0x5721ea){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5721ea);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0xeed977){this['query_']=_0xeed977,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5a10cc,_0xfd48bf,_0x4cd254,_0x5cc2c0){const _0x38d547=[],_0x38b433=[];return _0xfd48bf['forEach'](_0x28517a=>{_0x28517a['type']==='child_changed'&&_0x5a10cc['index_']['indexedValueChanged'](_0x28517a['oldSnap'],_0x28517a['snapshotNode'])&&_0x38b433['push']($h(_0x28517a['childName'],_0x28517a['snapshotNode']));}),mt(_0x5a10cc,_0x38d547,'child_removed',_0xfd48bf,_0x5cc2c0,_0x4cd254),mt(_0x5a10cc,_0x38d547,'child_added',_0xfd48bf,_0x5cc2c0,_0x4cd254),mt(_0x5a10cc,_0x38d547,'child_moved',_0x38b433,_0x5cc2c0,_0x4cd254),mt(_0x5a10cc,_0x38d547,'child_changed',_0xfd48bf,_0x5cc2c0,_0x4cd254),mt(_0x5a10cc,_0x38d547,'value',_0xfd48bf,_0x5cc2c0,_0x4cd254),_0x38d547;}function mt(_0x4b0050,_0x4f40a0,_0x14b6a0,_0x2f10bd,_0xe40e63,_0x86b24a){const _0x3adafa=_0x2f10bd['filter'](_0x4fadf2=>_0x4fadf2['type']===_0x14b6a0);_0x3adafa['sort']((_0xcae04,_0x2d05c6)=>su(_0x4b0050,_0xcae04,_0x2d05c6)),_0x3adafa['forEach'](_0x55632a=>{const _0x146f4d=iu(_0x4b0050,_0x55632a,_0x86b24a);_0xe40e63['forEach'](_0x20a3ed=>{_0x20a3ed['respondsTo'](_0x55632a['type'])&&_0x4f40a0['push'](_0x20a3ed['createEvent'](_0x146f4d,_0x4b0050['query_']));});});}function iu(_0x4ec54e,_0x1d8842,_0x1b3eda){return _0x1d8842['type']==='value'||_0x1d8842['type']==='child_removed'||(_0x1d8842['prevName']=_0x1b3eda['getPredecessorChildName'](_0x1d8842['childName'],_0x1d8842['snapshotNode'],_0x4ec54e['index_'])),_0x1d8842;}function su(_0x218cca,_0x1c94cc,_0x370763){if(_0x1c94cc['childName']==null||_0x370763['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x29001f=new E(_0x1c94cc['childName'],_0x1c94cc['snapshotNode']),_0x2cbc16=new E(_0x370763['childName'],_0x370763['snapshotNode']);return _0x218cca['index_']['compare'](_0x29001f,_0x2cbc16);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xfa7986,_0x3ae0aa){return{'eventCache':_0xfa7986,'serverCache':_0x3ae0aa};}function wt(_0x44a1b2,_0x18700c,_0x384e3d,_0x52e8c9){return Dn(new Ce(_0x18700c,_0x384e3d,_0x52e8c9),_0x44a1b2['serverCache']);}function Lo(_0x3d19de,_0x2dae85,_0x15fc53,_0x4b7164){return Dn(_0x3d19de['eventCache'],new Ce(_0x2dae85,_0x15fc53,_0x4b7164));}function gn(_0x2930cc){return _0x2930cc['eventCache']['isFullyInitialized']()?_0x2930cc['eventCache']['getNode']():null;}function Ue(_0x53ccb4){return _0x53ccb4['serverCache']['isFullyInitialized']()?_0x53ccb4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3e7bd8){let _0x1f5833=new S(null);return x(_0x3e7bd8,(_0x46f99c,_0x592a21)=>{_0x1f5833=_0x1f5833['set'](new C(_0x46f99c),_0x592a21);}),_0x1f5833;}constructor(_0x5b6894,_0x1ebd7b=ru()){this['value']=_0x5b6894,this['children']=_0x1ebd7b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2317be,_0x527107){if(this['value']!=null&&_0x527107(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2317be))return null;{const _0x166c95=y(_0x2317be),_0x1bac93=this['children']['get'](_0x166c95);if(_0x1bac93!==null){const _0xff259d=_0x1bac93['findRootMostMatchingPathAndValue'](b(_0x2317be),_0x527107);return _0xff259d!=null?{'path':A(new C(_0x166c95),_0xff259d['path']),'value':_0xff259d['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x33c803){return this['findRootMostMatchingPathAndValue'](_0x33c803,()=>!0x0);}['subtree'](_0x40495c){if(v(_0x40495c))return this;{const _0xb426d9=y(_0x40495c),_0x11f602=this['children']['get'](_0xb426d9);return _0x11f602!==null?_0x11f602['subtree'](b(_0x40495c)):new S(null);}}['set'](_0x26b9cd,_0x2a51f6){if(v(_0x26b9cd))return new S(_0x2a51f6,this['children']);{const _0x310e36=y(_0x26b9cd),_0x4a3da2=(this['children']['get'](_0x310e36)||new S(null))['set'](b(_0x26b9cd),_0x2a51f6),_0x88e760=this['children']['insert'](_0x310e36,_0x4a3da2);return new S(this['value'],_0x88e760);}}['remove'](_0xb658dc){if(v(_0xb658dc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x429d09=y(_0xb658dc),_0x427302=this['children']['get'](_0x429d09);if(_0x427302){const _0x2c257c=_0x427302['remove'](b(_0xb658dc));let _0x4db8de;return _0x2c257c['isEmpty']()?_0x4db8de=this['children']['remove'](_0x429d09):_0x4db8de=this['children']['insert'](_0x429d09,_0x2c257c),this['value']===null&&_0x4db8de['isEmpty']()?new S(null):new S(this['value'],_0x4db8de);}else return this;}}['get'](_0x4e4e6d){if(v(_0x4e4e6d))return this['value'];{const _0x563335=y(_0x4e4e6d),_0x4cccb=this['children']['get'](_0x563335);return _0x4cccb?_0x4cccb['get'](b(_0x4e4e6d)):null;}}['setTree'](_0x516cde,_0x5937e5){if(v(_0x516cde))return _0x5937e5;{const _0x76cfbd=y(_0x516cde),_0x502670=(this['children']['get'](_0x76cfbd)||new S(null))['setTree'](b(_0x516cde),_0x5937e5);let _0xae72da;return _0x502670['isEmpty']()?_0xae72da=this['children']['remove'](_0x76cfbd):_0xae72da=this['children']['insert'](_0x76cfbd,_0x502670),new S(this['value'],_0xae72da);}}['fold'](_0x20231b){return this['fold_'](w(),_0x20231b);}['fold_'](_0x5c5df1,_0x355cd7){const _0x3617a5={};return this['children']['inorderTraversal']((_0x5a933c,_0x557d76)=>{_0x3617a5[_0x5a933c]=_0x557d76['fold_'](A(_0x5c5df1,_0x5a933c),_0x355cd7);}),_0x355cd7(_0x5c5df1,this['value'],_0x3617a5);}['findOnPath'](_0x38d094,_0x1c3c8b){return this['findOnPath_'](_0x38d094,w(),_0x1c3c8b);}['findOnPath_'](_0x2a4067,_0x45e2ac,_0x32e859){const _0x201012=this['value']?_0x32e859(_0x45e2ac,this['value']):!0x1;if(_0x201012)return _0x201012;if(v(_0x2a4067))return null;{const _0x3504e1=y(_0x2a4067),_0x19b734=this['children']['get'](_0x3504e1);return _0x19b734?_0x19b734['findOnPath_'](b(_0x2a4067),A(_0x45e2ac,_0x3504e1),_0x32e859):null;}}['foreachOnPath'](_0x2fb2e0,_0xefa979){return this['foreachOnPath_'](_0x2fb2e0,w(),_0xefa979);}['foreachOnPath_'](_0x2c4865,_0x3d93f8,_0x24baa9){if(v(_0x2c4865))return this;{this['value']&&_0x24baa9(_0x3d93f8,this['value']);const _0x5385ce=y(_0x2c4865),_0x4815c5=this['children']['get'](_0x5385ce);return _0x4815c5?_0x4815c5['foreachOnPath_'](b(_0x2c4865),A(_0x3d93f8,_0x5385ce),_0x24baa9):new S(null);}}['foreach'](_0x560f6f){this['foreach_'](w(),_0x560f6f);}['foreach_'](_0x2f6806,_0x2e8252){this['children']['inorderTraversal']((_0x53e603,_0xded39a)=>{_0xded39a['foreach_'](A(_0x2f6806,_0x53e603),_0x2e8252);}),this['value']&&_0x2e8252(_0x2f6806,this['value']);}['foreachChild'](_0x213215){this['children']['inorderTraversal']((_0x5e0d89,_0x42b26f)=>{_0x42b26f['value']&&_0x213215(_0x5e0d89,_0x42b26f['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x25f3af){this['writeTree_']=_0x25f3af;}static['empty'](){return new j(new S(null));}}function Ct(_0x20fb27,_0x544d1b,_0x43d822){if(v(_0x544d1b))return new j(new S(_0x43d822));{const _0xe42be6=_0x20fb27['writeTree_']['findRootMostValueAndPath'](_0x544d1b);if(_0xe42be6!=null){const _0x1c71c8=_0xe42be6['path'];let _0x8300d9=_0xe42be6['value'];const _0x1c7f73=F(_0x1c71c8,_0x544d1b);return _0x8300d9=_0x8300d9['updateChild'](_0x1c7f73,_0x43d822),new j(_0x20fb27['writeTree_']['set'](_0x1c71c8,_0x8300d9));}else{const _0x314318=new S(_0x43d822),_0x5eff90=_0x20fb27['writeTree_']['setTree'](_0x544d1b,_0x314318);return new j(_0x5eff90);}}}function Ii(_0x3ba529,_0x763a06,_0x535770){let _0x1b1961=_0x3ba529;return x(_0x535770,(_0x2c9f06,_0x26454f)=>{_0x1b1961=Ct(_0x1b1961,A(_0x763a06,_0x2c9f06),_0x26454f);}),_0x1b1961;}function sr(_0x5f2548,_0x309189){if(v(_0x309189))return j['empty']();{const _0x59649b=_0x5f2548['writeTree_']['setTree'](_0x309189,new S(null));return new j(_0x59649b);}}function wi(_0x27500b,_0x358978){return $e(_0x27500b,_0x358978)!=null;}function $e(_0x5dac86,_0x18d520){const _0x5851f3=_0x5dac86['writeTree_']['findRootMostValueAndPath'](_0x18d520);return _0x5851f3!=null?_0x5dac86['writeTree_']['get'](_0x5851f3['path'])['getChild'](F(_0x5851f3['path'],_0x18d520)):null;}function rr(_0x2c11de){const _0x649dc7=[],_0xf19ed3=_0x2c11de['writeTree_']['value'];return _0xf19ed3!=null?_0xf19ed3['isLeafNode']()||_0xf19ed3['forEachChild'](R,(_0x56b59d,_0x14b5f7)=>{_0x649dc7['push'](new E(_0x56b59d,_0x14b5f7));}):_0x2c11de['writeTree_']['children']['inorderTraversal']((_0x1440d9,_0x2ef335)=>{_0x2ef335['value']!=null&&_0x649dc7['push'](new E(_0x1440d9,_0x2ef335['value']));}),_0x649dc7;}function ve(_0xf4e07e,_0x10787b){if(v(_0x10787b))return _0xf4e07e;{const _0x50d369=$e(_0xf4e07e,_0x10787b);return _0x50d369!=null?new j(new S(_0x50d369)):new j(_0xf4e07e['writeTree_']['subtree'](_0x10787b));}}function Ci(_0x5702ea){return _0x5702ea['writeTree_']['isEmpty']();}function it(_0x525429,_0x438911){return xo(w(),_0x525429['writeTree_'],_0x438911);}function xo(_0x3beea5,_0x2d18f2,_0x360eeb){if(_0x2d18f2['value']!=null)return _0x360eeb['updateChild'](_0x3beea5,_0x2d18f2['value']);{let _0xaf1731=null;return _0x2d18f2['children']['inorderTraversal']((_0x2b4a69,_0x21ef95)=>{_0x2b4a69==='.priority'?(f(_0x21ef95['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xaf1731=_0x21ef95['value']):_0x360eeb=xo(A(_0x3beea5,_0x2b4a69),_0x21ef95,_0x360eeb);}),!_0x360eeb['getChild'](_0x3beea5)['isEmpty']()&&_0xaf1731!==null&&(_0x360eeb=_0x360eeb['updateChild'](A(_0x3beea5,'.priority'),_0xaf1731)),_0x360eeb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x2e1305,_0x1dfa87){return Bo(_0x1dfa87,_0x2e1305);}function ou(_0xaff30,_0x17da31,_0x360939,_0x163698,_0x20ba1d){f(_0x163698>_0xaff30['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x20ba1d===void 0x0&&(_0x20ba1d=!0x0),_0xaff30['allWrites']['push']({'path':_0x17da31,'snap':_0x360939,'writeId':_0x163698,'visible':_0x20ba1d}),_0x20ba1d&&(_0xaff30['visibleWrites']=Ct(_0xaff30['visibleWrites'],_0x17da31,_0x360939)),_0xaff30['lastWriteId']=_0x163698;}function au(_0x355d1a,_0x31ba7d,_0x5ade28,_0xa35ba){f(_0xa35ba>_0x355d1a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x355d1a['allWrites']['push']({'path':_0x31ba7d,'children':_0x5ade28,'writeId':_0xa35ba,'visible':!0x0}),_0x355d1a['visibleWrites']=Ii(_0x355d1a['visibleWrites'],_0x31ba7d,_0x5ade28),_0x355d1a['lastWriteId']=_0xa35ba;}function cu(_0x4a492a,_0x27d9f3){for(let _0x448096=0x0;_0x448096<_0x4a492a['allWrites']['length'];_0x448096++){const _0x23979b=_0x4a492a['allWrites'][_0x448096];if(_0x23979b['writeId']===_0x27d9f3)return _0x23979b;}return null;}function lu(_0x56bd32,_0x125cb1){const _0x3a46e6=_0x56bd32['allWrites']['findIndex'](_0x4ba6df=>_0x4ba6df['writeId']===_0x125cb1);f(_0x3a46e6>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4c2228=_0x56bd32['allWrites'][_0x3a46e6];_0x56bd32['allWrites']['splice'](_0x3a46e6,0x1);let _0x28722c=_0x4c2228['visible'],_0x3b1923=!0x1,_0x5bfc3c=_0x56bd32['allWrites']['length']-0x1;for(;_0x28722c&&_0x5bfc3c>=0x0;){const _0x3465b3=_0x56bd32['allWrites'][_0x5bfc3c];_0x3465b3['visible']&&(_0x5bfc3c>=_0x3a46e6&&hu(_0x3465b3,_0x4c2228['path'])?_0x28722c=!0x1:$(_0x4c2228['path'],_0x3465b3['path'])&&(_0x3b1923=!0x0)),_0x5bfc3c--;}if(_0x28722c){if(_0x3b1923)return uu(_0x56bd32),!0x0;if(_0x4c2228['snap'])_0x56bd32['visibleWrites']=sr(_0x56bd32['visibleWrites'],_0x4c2228['path']);else{const _0x300604=_0x4c2228['children'];x(_0x300604,_0x3cd00d=>{_0x56bd32['visibleWrites']=sr(_0x56bd32['visibleWrites'],A(_0x4c2228['path'],_0x3cd00d));});}return!0x0;}else return!0x1;}function hu(_0x27be96,_0x578370){if(_0x27be96['snap'])return $(_0x27be96['path'],_0x578370);for(const _0x16a14f in _0x27be96['children'])if(_0x27be96['children']['hasOwnProperty'](_0x16a14f)&&$(A(_0x27be96['path'],_0x16a14f),_0x578370))return!0x0;return!0x1;}function uu(_0x4c14a7){_0x4c14a7['visibleWrites']=Fo(_0x4c14a7['allWrites'],du,w()),_0x4c14a7['allWrites']['length']>0x0?_0x4c14a7['lastWriteId']=_0x4c14a7['allWrites'][_0x4c14a7['allWrites']['length']-0x1]['writeId']:_0x4c14a7['lastWriteId']=-0x1;}function du(_0xca7bc3){return _0xca7bc3['visible'];}function Fo(_0x33c85b,_0x34713d,_0xd0f45e){let _0x4682b2=j['empty']();for(let _0x57b122=0x0;_0x57b122<_0x33c85b['length'];++_0x57b122){const _0x4a080f=_0x33c85b[_0x57b122];if(_0x34713d(_0x4a080f)){const _0xb667d5=_0x4a080f['path'];let _0x2e7d69;if(_0x4a080f['snap'])$(_0xd0f45e,_0xb667d5)?(_0x2e7d69=F(_0xd0f45e,_0xb667d5),_0x4682b2=Ct(_0x4682b2,_0x2e7d69,_0x4a080f['snap'])):$(_0xb667d5,_0xd0f45e)&&(_0x2e7d69=F(_0xb667d5,_0xd0f45e),_0x4682b2=Ct(_0x4682b2,w(),_0x4a080f['snap']['getChild'](_0x2e7d69)));else{if(_0x4a080f['children']){if($(_0xd0f45e,_0xb667d5))_0x2e7d69=F(_0xd0f45e,_0xb667d5),_0x4682b2=Ii(_0x4682b2,_0x2e7d69,_0x4a080f['children']);else{if($(_0xb667d5,_0xd0f45e)){if(_0x2e7d69=F(_0xb667d5,_0xd0f45e),v(_0x2e7d69))_0x4682b2=Ii(_0x4682b2,w(),_0x4a080f['children']);else{const _0x56dc5e=Oe(_0x4a080f['children'],y(_0x2e7d69));if(_0x56dc5e){const _0x2f90eb=_0x56dc5e['getChild'](b(_0x2e7d69));_0x4682b2=Ct(_0x4682b2,w(),_0x2f90eb);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4682b2;}function Uo(_0x508949,_0x38c2b4,_0x4ef9b8,_0x2dec34,_0x459f67){if(!_0x2dec34&&!_0x459f67){const _0x13ea54=$e(_0x508949['visibleWrites'],_0x38c2b4);if(_0x13ea54!=null)return _0x13ea54;{const _0x22a65f=ve(_0x508949['visibleWrites'],_0x38c2b4);if(Ci(_0x22a65f))return _0x4ef9b8;if(_0x4ef9b8==null&&!wi(_0x22a65f,w()))return null;{const _0x2d2dac=_0x4ef9b8||g['EMPTY_NODE'];return it(_0x22a65f,_0x2d2dac);}}}else{const _0x6466b4=ve(_0x508949['visibleWrites'],_0x38c2b4);if(!_0x459f67&&Ci(_0x6466b4))return _0x4ef9b8;if(!_0x459f67&&_0x4ef9b8==null&&!wi(_0x6466b4,w()))return null;{const _0x45bec9=function(_0x4efd4d){return(_0x4efd4d['visible']||_0x459f67)&&(!_0x2dec34||!~_0x2dec34['indexOf'](_0x4efd4d['writeId']))&&($(_0x4efd4d['path'],_0x38c2b4)||$(_0x38c2b4,_0x4efd4d['path']));},_0x12536c=Fo(_0x508949['allWrites'],_0x45bec9,_0x38c2b4),_0x3b7fe0=_0x4ef9b8||g['EMPTY_NODE'];return it(_0x12536c,_0x3b7fe0);}}}function fu(_0x594392,_0xa682c8,_0x418f71){let _0x1ac991=g['EMPTY_NODE'];const _0x169168=$e(_0x594392['visibleWrites'],_0xa682c8);if(_0x169168)return _0x169168['isLeafNode']()||_0x169168['forEachChild'](R,(_0x163b86,_0x9cfb1d)=>{_0x1ac991=_0x1ac991['updateImmediateChild'](_0x163b86,_0x9cfb1d);}),_0x1ac991;if(_0x418f71){const _0xd8fecc=ve(_0x594392['visibleWrites'],_0xa682c8);return _0x418f71['forEachChild'](R,(_0x48d8f0,_0x51725c)=>{const _0x14fe00=it(ve(_0xd8fecc,new C(_0x48d8f0)),_0x51725c);_0x1ac991=_0x1ac991['updateImmediateChild'](_0x48d8f0,_0x14fe00);}),rr(_0xd8fecc)['forEach'](_0x31375e=>{_0x1ac991=_0x1ac991['updateImmediateChild'](_0x31375e['name'],_0x31375e['node']);}),_0x1ac991;}else{const _0x148f27=ve(_0x594392['visibleWrites'],_0xa682c8);return rr(_0x148f27)['forEach'](_0x2dbaf6=>{_0x1ac991=_0x1ac991['updateImmediateChild'](_0x2dbaf6['name'],_0x2dbaf6['node']);}),_0x1ac991;}}function pu(_0x31fa1d,_0x4a5a0d,_0x5e8128,_0x3bff68,_0x4c5095){f(_0x3bff68||_0x4c5095,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4a7212=A(_0x4a5a0d,_0x5e8128);if(wi(_0x31fa1d['visibleWrites'],_0x4a7212))return null;{const _0x4b7a87=ve(_0x31fa1d['visibleWrites'],_0x4a7212);return Ci(_0x4b7a87)?_0x4c5095['getChild'](_0x5e8128):it(_0x4b7a87,_0x4c5095['getChild'](_0x5e8128));}}function _u(_0x4b2440,_0x27c12d,_0x100884,_0x15bf4b){const _0x400d53=A(_0x27c12d,_0x100884),_0x2ce586=$e(_0x4b2440['visibleWrites'],_0x400d53);if(_0x2ce586!=null)return _0x2ce586;if(_0x15bf4b['isCompleteForChild'](_0x100884)){const _0x3ac094=ve(_0x4b2440['visibleWrites'],_0x400d53);return it(_0x3ac094,_0x15bf4b['getNode']()['getImmediateChild'](_0x100884));}else return null;}function gu(_0x419eb6,_0x2b0832){return $e(_0x419eb6['visibleWrites'],_0x2b0832);}function mu(_0x578c38,_0x18554d,_0x54de68,_0x33f7df,_0x5b4047,_0x235a6d,_0x3e4437){let _0x421b67;const _0xf71177=ve(_0x578c38['visibleWrites'],_0x18554d),_0x18e7c6=$e(_0xf71177,w());if(_0x18e7c6!=null)_0x421b67=_0x18e7c6;else{if(_0x54de68!=null)_0x421b67=it(_0xf71177,_0x54de68);else return[];}if(_0x421b67=_0x421b67['withIndex'](_0x3e4437),!_0x421b67['isEmpty']()&&!_0x421b67['isLeafNode']()){const _0x3dfdb2=[],_0x207ae6=_0x3e4437['getCompare'](),_0x599ec3=_0x235a6d?_0x421b67['getReverseIteratorFrom'](_0x33f7df,_0x3e4437):_0x421b67['getIteratorFrom'](_0x33f7df,_0x3e4437);let _0x462a94=_0x599ec3['getNext']();for(;_0x462a94&&_0x3dfdb2['length']<_0x5b4047;)_0x207ae6(_0x462a94,_0x33f7df)!==0x0&&_0x3dfdb2['push'](_0x462a94),_0x462a94=_0x599ec3['getNext']();return _0x3dfdb2;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5763f8,_0xae1cac,_0x1b3c31,_0x53c35c){return Uo(_0x5763f8['writeTree'],_0x5763f8['treePath'],_0xae1cac,_0x1b3c31,_0x53c35c);}function es(_0x149131,_0x368bcc){return fu(_0x149131['writeTree'],_0x149131['treePath'],_0x368bcc);}function or(_0x5733ab,_0x50bda5,_0x6586e6,_0x4b0e95){return pu(_0x5733ab['writeTree'],_0x5733ab['treePath'],_0x50bda5,_0x6586e6,_0x4b0e95);}function yn(_0xb0a849,_0x1a3100){return gu(_0xb0a849['writeTree'],A(_0xb0a849['treePath'],_0x1a3100));}function vu(_0xa684d0,_0x2e9c4f,_0x37bffe,_0x542995,_0x2ed109,_0x36c508){return mu(_0xa684d0['writeTree'],_0xa684d0['treePath'],_0x2e9c4f,_0x37bffe,_0x542995,_0x2ed109,_0x36c508);}function ts(_0x1feac6,_0x392a21,_0x1f542c){return _u(_0x1feac6['writeTree'],_0x1feac6['treePath'],_0x392a21,_0x1f542c);}function Wo(_0x4d6136,_0x425da6){return Bo(A(_0x4d6136['treePath'],_0x425da6),_0x4d6136['writeTree']);}function Bo(_0x56f3e5,_0x517f2b){return{'treePath':_0x56f3e5,'writeTree':_0x517f2b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5bb222){const _0x2753e4=_0x5bb222['type'],_0x4f6141=_0x5bb222['childName'];f(_0x2753e4==='child_added'||_0x2753e4==='child_changed'||_0x2753e4==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4f6141!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2f4afe=this['changeMap']['get'](_0x4f6141);if(_0x2f4afe){const _0x3ab107=_0x2f4afe['type'];if(_0x2753e4==='child_added'&&_0x3ab107==='child_removed')this['changeMap']['set'](_0x4f6141,Pt(_0x4f6141,_0x5bb222['snapshotNode'],_0x2f4afe['snapshotNode']));else{if(_0x2753e4==='child_removed'&&_0x3ab107==='child_added')this['changeMap']['delete'](_0x4f6141);else{if(_0x2753e4==='child_removed'&&_0x3ab107==='child_changed')this['changeMap']['set'](_0x4f6141,Nt(_0x4f6141,_0x2f4afe['oldSnap']));else{if(_0x2753e4==='child_changed'&&_0x3ab107==='child_added')this['changeMap']['set'](_0x4f6141,tt(_0x4f6141,_0x5bb222['snapshotNode']));else{if(_0x2753e4==='child_changed'&&_0x3ab107==='child_changed')this['changeMap']['set'](_0x4f6141,Pt(_0x4f6141,_0x5bb222['snapshotNode'],_0x2f4afe['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x5bb222+'\x20occurred\x20after\x20'+_0x2f4afe);}}}}}else this['changeMap']['set'](_0x4f6141,_0x5bb222);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x3b5c32){return null;}['getChildAfterChild'](_0xf94630,_0x4d121a,_0x18066d){return null;}}const Vo=new Iu();class ns{constructor(_0x46ef3d,_0x616158,_0x4f2182=null){this['writes_']=_0x46ef3d,this['viewCache_']=_0x616158,this['optCompleteServerCache_']=_0x4f2182;}['getCompleteChild'](_0x76ec69){const _0x37e667=this['viewCache_']['eventCache'];if(_0x37e667['isCompleteForChild'](_0x76ec69))return _0x37e667['getNode']()['getImmediateChild'](_0x76ec69);{const _0x3a2907=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x76ec69,_0x3a2907);}}['getChildAfterChild'](_0x5c0601,_0x1e125d,_0x34ab71){const _0x4e338d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x34c20d=vu(this['writes_'],_0x4e338d,_0x1e125d,0x1,_0x34ab71,_0x5c0601);return _0x34c20d['length']===0x0?null:_0x34c20d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x2114f1){return{'filter':_0x2114f1};}function Cu(_0x1daec8,_0x26692f){f(_0x26692f['eventCache']['getNode']()['isIndexed'](_0x1daec8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x26692f['serverCache']['getNode']()['isIndexed'](_0x1daec8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x342c7e,_0x4ebb54,_0x4678b7,_0x1fadc0,_0x3185d0){const _0x1077de=new Eu();let _0xe31156,_0x53adae;if(_0x4678b7['type']===q['OVERWRITE']){const _0x2291a1=_0x4678b7;_0x2291a1['source']['fromUser']?_0xe31156=Ti(_0x342c7e,_0x4ebb54,_0x2291a1['path'],_0x2291a1['snap'],_0x1fadc0,_0x3185d0,_0x1077de):(f(_0x2291a1['source']['fromServer'],'Unknown\x20source.'),_0x53adae=_0x2291a1['source']['tagged']||_0x4ebb54['serverCache']['isFiltered']()&&!v(_0x2291a1['path']),_0xe31156=vn(_0x342c7e,_0x4ebb54,_0x2291a1['path'],_0x2291a1['snap'],_0x1fadc0,_0x3185d0,_0x53adae,_0x1077de));}else{if(_0x4678b7['type']===q['MERGE']){const _0x2db9d5=_0x4678b7;_0x2db9d5['source']['fromUser']?_0xe31156=bu(_0x342c7e,_0x4ebb54,_0x2db9d5['path'],_0x2db9d5['children'],_0x1fadc0,_0x3185d0,_0x1077de):(f(_0x2db9d5['source']['fromServer'],'Unknown\x20source.'),_0x53adae=_0x2db9d5['source']['tagged']||_0x4ebb54['serverCache']['isFiltered'](),_0xe31156=Si(_0x342c7e,_0x4ebb54,_0x2db9d5['path'],_0x2db9d5['children'],_0x1fadc0,_0x3185d0,_0x53adae,_0x1077de));}else{if(_0x4678b7['type']===q['ACK_USER_WRITE']){const _0x78821b=_0x4678b7;_0x78821b['revert']?_0xe31156=ku(_0x342c7e,_0x4ebb54,_0x78821b['path'],_0x1fadc0,_0x3185d0,_0x1077de):_0xe31156=Ru(_0x342c7e,_0x4ebb54,_0x78821b['path'],_0x78821b['affectedTree'],_0x1fadc0,_0x3185d0,_0x1077de);}else{if(_0x4678b7['type']===q['LISTEN_COMPLETE'])_0xe31156=Au(_0x342c7e,_0x4ebb54,_0x4678b7['path'],_0x1fadc0,_0x1077de);else throw ot('Unknown\x20operation\x20type:\x20'+_0x4678b7['type']);}}}const _0x1286e9=_0x1077de['getChanges']();return Su(_0x4ebb54,_0xe31156,_0x1286e9),{'viewCache':_0xe31156,'changes':_0x1286e9};}function Su(_0xef6f57,_0xf6aa9,_0x4b3f31){const _0x1c1e8f=_0xf6aa9['eventCache'];if(_0x1c1e8f['isFullyInitialized']()){const _0x47ac29=_0x1c1e8f['getNode']()['isLeafNode']()||_0x1c1e8f['getNode']()['isEmpty'](),_0x76a86=gn(_0xef6f57);(_0x4b3f31['length']>0x0||!_0xef6f57['eventCache']['isFullyInitialized']()||_0x47ac29&&!_0x1c1e8f['getNode']()['equals'](_0x76a86)||!_0x1c1e8f['getNode']()['getPriority']()['equals'](_0x76a86['getPriority']()))&&_0x4b3f31['push'](Oo(gn(_0xf6aa9)));}}function Ho(_0x5c6834,_0x28329e,_0x2d0888,_0x121c9c,_0x2f1cb0,_0x5e97f1){const _0x401b81=_0x28329e['eventCache'];if(yn(_0x121c9c,_0x2d0888)!=null)return _0x28329e;{let _0x2fc188,_0x2fe923;if(v(_0x2d0888)){if(f(_0x28329e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x28329e['serverCache']['isFiltered']()){const _0x299255=Ue(_0x28329e),_0x5f02da=_0x299255 instanceof g?_0x299255:g['EMPTY_NODE'],_0x4a80cb=es(_0x121c9c,_0x5f02da);_0x2fc188=_0x5c6834['filter']['updateFullNode'](_0x28329e['eventCache']['getNode'](),_0x4a80cb,_0x5e97f1);}else{const _0x5615db=mn(_0x121c9c,Ue(_0x28329e));_0x2fc188=_0x5c6834['filter']['updateFullNode'](_0x28329e['eventCache']['getNode'](),_0x5615db,_0x5e97f1);}}else{const _0x465a3e=y(_0x2d0888);if(_0x465a3e==='.priority'){f(we(_0x2d0888)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4b897a=_0x401b81['getNode']();_0x2fe923=_0x28329e['serverCache']['getNode']();const _0x5224fb=or(_0x121c9c,_0x2d0888,_0x4b897a,_0x2fe923);_0x5224fb!=null?_0x2fc188=_0x5c6834['filter']['updatePriority'](_0x4b897a,_0x5224fb):_0x2fc188=_0x401b81['getNode']();}else{const _0x2e479a=b(_0x2d0888);let _0x385f6a;if(_0x401b81['isCompleteForChild'](_0x465a3e)){_0x2fe923=_0x28329e['serverCache']['getNode']();const _0x3dea88=or(_0x121c9c,_0x2d0888,_0x401b81['getNode'](),_0x2fe923);_0x3dea88!=null?_0x385f6a=_0x401b81['getNode']()['getImmediateChild'](_0x465a3e)['updateChild'](_0x2e479a,_0x3dea88):_0x385f6a=_0x401b81['getNode']()['getImmediateChild'](_0x465a3e);}else _0x385f6a=ts(_0x121c9c,_0x465a3e,_0x28329e['serverCache']);_0x385f6a!=null?_0x2fc188=_0x5c6834['filter']['updateChild'](_0x401b81['getNode'](),_0x465a3e,_0x385f6a,_0x2e479a,_0x2f1cb0,_0x5e97f1):_0x2fc188=_0x401b81['getNode']();}}return wt(_0x28329e,_0x2fc188,_0x401b81['isFullyInitialized']()||v(_0x2d0888),_0x5c6834['filter']['filtersNodes']());}}function vn(_0x4f84d8,_0x5dab43,_0x2e8578,_0x5a86c6,_0xdb0f9d,_0xabc915,_0x389fc2,_0x1f409f){const _0xb42f9d=_0x5dab43['serverCache'];let _0x4a2cea;const _0x185aba=_0x389fc2?_0x4f84d8['filter']:_0x4f84d8['filter']['getIndexedFilter']();if(v(_0x2e8578))_0x4a2cea=_0x185aba['updateFullNode'](_0xb42f9d['getNode'](),_0x5a86c6,null);else{if(_0x185aba['filtersNodes']()&&!_0xb42f9d['isFiltered']()){const _0x36c917=_0xb42f9d['getNode']()['updateChild'](_0x2e8578,_0x5a86c6);_0x4a2cea=_0x185aba['updateFullNode'](_0xb42f9d['getNode'](),_0x36c917,null);}else{const _0xa6550f=y(_0x2e8578);if(!_0xb42f9d['isCompleteForPath'](_0x2e8578)&&we(_0x2e8578)>0x1)return _0x5dab43;const _0x2d06c3=b(_0x2e8578),_0x56bfb8=_0xb42f9d['getNode']()['getImmediateChild'](_0xa6550f)['updateChild'](_0x2d06c3,_0x5a86c6);_0xa6550f==='.priority'?_0x4a2cea=_0x185aba['updatePriority'](_0xb42f9d['getNode'](),_0x56bfb8):_0x4a2cea=_0x185aba['updateChild'](_0xb42f9d['getNode'](),_0xa6550f,_0x56bfb8,_0x2d06c3,Vo,null);}}const _0x300e62=Lo(_0x5dab43,_0x4a2cea,_0xb42f9d['isFullyInitialized']()||v(_0x2e8578),_0x185aba['filtersNodes']()),_0x6e89f2=new ns(_0xdb0f9d,_0x300e62,_0xabc915);return Ho(_0x4f84d8,_0x300e62,_0x2e8578,_0xdb0f9d,_0x6e89f2,_0x1f409f);}function Ti(_0x150201,_0xa2670c,_0x1ed3cf,_0xb2f590,_0x3a000a,_0x3f923b,_0x228c97){const _0x2f154c=_0xa2670c['eventCache'];let _0x555d93,_0x33553c;const _0x166f0d=new ns(_0x3a000a,_0xa2670c,_0x3f923b);if(v(_0x1ed3cf))_0x33553c=_0x150201['filter']['updateFullNode'](_0xa2670c['eventCache']['getNode'](),_0xb2f590,_0x228c97),_0x555d93=wt(_0xa2670c,_0x33553c,!0x0,_0x150201['filter']['filtersNodes']());else{const _0x50e24a=y(_0x1ed3cf);if(_0x50e24a==='.priority')_0x33553c=_0x150201['filter']['updatePriority'](_0xa2670c['eventCache']['getNode'](),_0xb2f590),_0x555d93=wt(_0xa2670c,_0x33553c,_0x2f154c['isFullyInitialized'](),_0x2f154c['isFiltered']());else{const _0x441bd6=b(_0x1ed3cf),_0x213e17=_0x2f154c['getNode']()['getImmediateChild'](_0x50e24a);let _0x35ed09;if(v(_0x441bd6))_0x35ed09=_0xb2f590;else{const _0x4b8e85=_0x166f0d['getCompleteChild'](_0x50e24a);_0x4b8e85!=null?Gi(_0x441bd6)==='.priority'&&_0x4b8e85['getChild'](To(_0x441bd6))['isEmpty']()?_0x35ed09=_0x4b8e85:_0x35ed09=_0x4b8e85['updateChild'](_0x441bd6,_0xb2f590):_0x35ed09=g['EMPTY_NODE'];}if(_0x213e17['equals'](_0x35ed09))_0x555d93=_0xa2670c;else{const _0x4dafba=_0x150201['filter']['updateChild'](_0x2f154c['getNode'](),_0x50e24a,_0x35ed09,_0x441bd6,_0x166f0d,_0x228c97);_0x555d93=wt(_0xa2670c,_0x4dafba,_0x2f154c['isFullyInitialized'](),_0x150201['filter']['filtersNodes']());}}}return _0x555d93;}function ar(_0x4ebebf,_0x9d515d){return _0x4ebebf['eventCache']['isCompleteForChild'](_0x9d515d);}function bu(_0x1eb742,_0x52a913,_0x2a5a04,_0x4e3a21,_0x51d669,_0x3cfa91,_0x47f292){let _0x598637=_0x52a913;return _0x4e3a21['foreach']((_0x236fd1,_0x52395d)=>{const _0x436dc8=A(_0x2a5a04,_0x236fd1);ar(_0x52a913,y(_0x436dc8))&&(_0x598637=Ti(_0x1eb742,_0x598637,_0x436dc8,_0x52395d,_0x51d669,_0x3cfa91,_0x47f292));}),_0x4e3a21['foreach']((_0x281f07,_0x186476)=>{const _0x1eea5f=A(_0x2a5a04,_0x281f07);ar(_0x52a913,y(_0x1eea5f))||(_0x598637=Ti(_0x1eb742,_0x598637,_0x1eea5f,_0x186476,_0x51d669,_0x3cfa91,_0x47f292));}),_0x598637;}function cr(_0x393bd9,_0x3ba2b2,_0x5c6e8d){return _0x5c6e8d['foreach']((_0x79454f,_0x18e09a)=>{_0x3ba2b2=_0x3ba2b2['updateChild'](_0x79454f,_0x18e09a);}),_0x3ba2b2;}function Si(_0xda437d,_0xd2f7f8,_0x3a633f,_0x18a650,_0x3ff459,_0xc5ef06,_0x51937c,_0x531743){if(_0xd2f7f8['serverCache']['getNode']()['isEmpty']()&&!_0xd2f7f8['serverCache']['isFullyInitialized']())return _0xd2f7f8;let _0x4182d1=_0xd2f7f8,_0x364b72;v(_0x3a633f)?_0x364b72=_0x18a650:_0x364b72=new S(null)['setTree'](_0x3a633f,_0x18a650);const _0x54eb29=_0xd2f7f8['serverCache']['getNode']();return _0x364b72['children']['inorderTraversal']((_0x5a58df,_0x322221)=>{if(_0x54eb29['hasChild'](_0x5a58df)){const _0x189e75=_0xd2f7f8['serverCache']['getNode']()['getImmediateChild'](_0x5a58df),_0x44fc5a=cr(_0xda437d,_0x189e75,_0x322221);_0x4182d1=vn(_0xda437d,_0x4182d1,new C(_0x5a58df),_0x44fc5a,_0x3ff459,_0xc5ef06,_0x51937c,_0x531743);}}),_0x364b72['children']['inorderTraversal']((_0x5b64f7,_0x505dac)=>{const _0x220aaf=!_0xd2f7f8['serverCache']['isCompleteForChild'](_0x5b64f7)&&_0x505dac['value']===null;if(!_0x54eb29['hasChild'](_0x5b64f7)&&!_0x220aaf){const _0x231503=_0xd2f7f8['serverCache']['getNode']()['getImmediateChild'](_0x5b64f7),_0x28b056=cr(_0xda437d,_0x231503,_0x505dac);_0x4182d1=vn(_0xda437d,_0x4182d1,new C(_0x5b64f7),_0x28b056,_0x3ff459,_0xc5ef06,_0x51937c,_0x531743);}}),_0x4182d1;}function Ru(_0x53a1d2,_0x1ab83b,_0x561ed2,_0x56d7d2,_0x52d1db,_0x118a02,_0x2cb73b){if(yn(_0x52d1db,_0x561ed2)!=null)return _0x1ab83b;const _0x302bd0=_0x1ab83b['serverCache']['isFiltered'](),_0x5de424=_0x1ab83b['serverCache'];if(_0x56d7d2['value']!=null){if(v(_0x561ed2)&&_0x5de424['isFullyInitialized']()||_0x5de424['isCompleteForPath'](_0x561ed2))return vn(_0x53a1d2,_0x1ab83b,_0x561ed2,_0x5de424['getNode']()['getChild'](_0x561ed2),_0x52d1db,_0x118a02,_0x302bd0,_0x2cb73b);if(v(_0x561ed2)){let _0x427a6b=new S(null);return _0x5de424['getNode']()['forEachChild'](ye,(_0x22723d,_0x15b107)=>{_0x427a6b=_0x427a6b['set'](new C(_0x22723d),_0x15b107);}),Si(_0x53a1d2,_0x1ab83b,_0x561ed2,_0x427a6b,_0x52d1db,_0x118a02,_0x302bd0,_0x2cb73b);}else return _0x1ab83b;}else{let _0x2cce36=new S(null);return _0x56d7d2['foreach']((_0x548c3e,_0x5c5adf)=>{const _0x473387=A(_0x561ed2,_0x548c3e);_0x5de424['isCompleteForPath'](_0x473387)&&(_0x2cce36=_0x2cce36['set'](_0x548c3e,_0x5de424['getNode']()['getChild'](_0x473387)));}),Si(_0x53a1d2,_0x1ab83b,_0x561ed2,_0x2cce36,_0x52d1db,_0x118a02,_0x302bd0,_0x2cb73b);}}function Au(_0x2091fc,_0x633ae0,_0x429eec,_0xb1e716,_0x330816){const _0x57d83a=_0x633ae0['serverCache'],_0x14811d=Lo(_0x633ae0,_0x57d83a['getNode'](),_0x57d83a['isFullyInitialized']()||v(_0x429eec),_0x57d83a['isFiltered']());return Ho(_0x2091fc,_0x14811d,_0x429eec,_0xb1e716,Vo,_0x330816);}function ku(_0x5eef5d,_0xcef2d,_0x3b4920,_0x579b37,_0x1b28d5,_0x7a0f9a){let _0x3f95ae;if(yn(_0x579b37,_0x3b4920)!=null)return _0xcef2d;{const _0x59a076=new ns(_0x579b37,_0xcef2d,_0x1b28d5),_0x3d66cb=_0xcef2d['eventCache']['getNode']();let _0x48bcfe;if(v(_0x3b4920)||y(_0x3b4920)==='.priority'){let _0x24cdb8;if(_0xcef2d['serverCache']['isFullyInitialized']())_0x24cdb8=mn(_0x579b37,Ue(_0xcef2d));else{const _0x294951=_0xcef2d['serverCache']['getNode']();f(_0x294951 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x24cdb8=es(_0x579b37,_0x294951);}_0x24cdb8=_0x24cdb8,_0x48bcfe=_0x5eef5d['filter']['updateFullNode'](_0x3d66cb,_0x24cdb8,_0x7a0f9a);}else{const _0x1712eb=y(_0x3b4920);let _0x3c1d8e=ts(_0x579b37,_0x1712eb,_0xcef2d['serverCache']);_0x3c1d8e==null&&_0xcef2d['serverCache']['isCompleteForChild'](_0x1712eb)&&(_0x3c1d8e=_0x3d66cb['getImmediateChild'](_0x1712eb)),_0x3c1d8e!=null?_0x48bcfe=_0x5eef5d['filter']['updateChild'](_0x3d66cb,_0x1712eb,_0x3c1d8e,b(_0x3b4920),_0x59a076,_0x7a0f9a):_0xcef2d['eventCache']['getNode']()['hasChild'](_0x1712eb)?_0x48bcfe=_0x5eef5d['filter']['updateChild'](_0x3d66cb,_0x1712eb,g['EMPTY_NODE'],b(_0x3b4920),_0x59a076,_0x7a0f9a):_0x48bcfe=_0x3d66cb,_0x48bcfe['isEmpty']()&&_0xcef2d['serverCache']['isFullyInitialized']()&&(_0x3f95ae=mn(_0x579b37,Ue(_0xcef2d)),_0x3f95ae['isLeafNode']()&&(_0x48bcfe=_0x5eef5d['filter']['updateFullNode'](_0x48bcfe,_0x3f95ae,_0x7a0f9a)));}return _0x3f95ae=_0xcef2d['serverCache']['isFullyInitialized']()||yn(_0x579b37,w())!=null,wt(_0xcef2d,_0x48bcfe,_0x3f95ae,_0x5eef5d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x2e0852,_0x428f8e){this['query_']=_0x2e0852,this['eventRegistrations_']=[];const _0x24e366=this['query_']['_queryParams'],_0x1c0358=new Yi(_0x24e366['getIndex']()),_0x23f683=qh(_0x24e366);this['processor_']=wu(_0x23f683);const _0x111479=_0x428f8e['serverCache'],_0x5b3102=_0x428f8e['eventCache'],_0xe8acc5=_0x1c0358['updateFullNode'](g['EMPTY_NODE'],_0x111479['getNode'](),null),_0x1be7c2=_0x23f683['updateFullNode'](g['EMPTY_NODE'],_0x5b3102['getNode'](),null),_0xc34a85=new Ce(_0xe8acc5,_0x111479['isFullyInitialized'](),_0x1c0358['filtersNodes']()),_0xbfd3da=new Ce(_0x1be7c2,_0x5b3102['isFullyInitialized'](),_0x23f683['filtersNodes']());this['viewCache_']=Dn(_0xbfd3da,_0xc34a85),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4ebcc7){return _0x4ebcc7['viewCache_']['serverCache']['getNode']();}function Ou(_0x315185){return gn(_0x315185['viewCache_']);}function Du(_0x51ee8a,_0x599847){const _0x851a90=Ue(_0x51ee8a['viewCache_']);return _0x851a90&&(_0x51ee8a['query']['_queryParams']['loadsAllData']()||!v(_0x599847)&&!_0x851a90['getImmediateChild'](y(_0x599847))['isEmpty']())?_0x851a90['getChild'](_0x599847):null;}function lr(_0x5c0c1a){return _0x5c0c1a['eventRegistrations_']['length']===0x0;}function Mu(_0x2fd6b9,_0x5efca3){_0x2fd6b9['eventRegistrations_']['push'](_0x5efca3);}function hr(_0x531c9a,_0x369ff2,_0x3fc9da){const _0x5498ee=[];if(_0x3fc9da){f(_0x369ff2==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1904c4=_0x531c9a['query']['_path'];_0x531c9a['eventRegistrations_']['forEach'](_0x171f22=>{const _0x201ada=_0x171f22['createCancelEvent'](_0x3fc9da,_0x1904c4);_0x201ada&&_0x5498ee['push'](_0x201ada);});}if(_0x369ff2){let _0x582f0e=[];for(let _0x59dba5=0x0;_0x59dba5<_0x531c9a['eventRegistrations_']['length'];++_0x59dba5){const _0x202948=_0x531c9a['eventRegistrations_'][_0x59dba5];if(!_0x202948['matches'](_0x369ff2))_0x582f0e['push'](_0x202948);else{if(_0x369ff2['hasAnyCallback']()){_0x582f0e=_0x582f0e['concat'](_0x531c9a['eventRegistrations_']['slice'](_0x59dba5+0x1));break;}}}_0x531c9a['eventRegistrations_']=_0x582f0e;}else _0x531c9a['eventRegistrations_']=[];return _0x5498ee;}function ur(_0xdbebbf,_0x480261,_0x303838,_0x36044e){_0x480261['type']===q['MERGE']&&_0x480261['source']['queryId']!==null&&(f(Ue(_0xdbebbf['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0xdbebbf['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x284e1d=_0xdbebbf['viewCache_'],_0x4b8dd1=Tu(_0xdbebbf['processor_'],_0x284e1d,_0x480261,_0x303838,_0x36044e);return Cu(_0xdbebbf['processor_'],_0x4b8dd1['viewCache']),f(_0x4b8dd1['viewCache']['serverCache']['isFullyInitialized']()||!_0x284e1d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xdbebbf['viewCache_']=_0x4b8dd1['viewCache'],$o(_0xdbebbf,_0x4b8dd1['changes'],_0x4b8dd1['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x292dcc,_0x8786bc){const _0x4629d2=_0x292dcc['viewCache_']['eventCache'],_0x108c79=[];return _0x4629d2['getNode']()['isLeafNode']()||_0x4629d2['getNode']()['forEachChild'](R,(_0x2dd540,_0x506e94)=>{_0x108c79['push'](tt(_0x2dd540,_0x506e94));}),_0x4629d2['isFullyInitialized']()&&_0x108c79['push'](Oo(_0x4629d2['getNode']())),$o(_0x292dcc,_0x108c79,_0x4629d2['getNode'](),_0x8786bc);}function $o(_0x5f5a37,_0x1d8105,_0x53fe2d,_0x4d1713){const _0x42ba26=_0x4d1713?[_0x4d1713]:_0x5f5a37['eventRegistrations_'];return nu(_0x5f5a37['eventGenerator_'],_0x1d8105,_0x53fe2d,_0x42ba26);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x339f4f){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x339f4f;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x3ebf37){return _0x3ebf37['views']['size']===0x0;}function is(_0x92343,_0x437980,_0x55c3b3,_0x2b65e7){const _0x2fc420=_0x437980['source']['queryId'];if(_0x2fc420!==null){const _0x5ca5d5=_0x92343['views']['get'](_0x2fc420);return f(_0x5ca5d5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x5ca5d5,_0x437980,_0x55c3b3,_0x2b65e7);}else{let _0x4bcb7e=[];for(const _0x45ad23 of _0x92343['views']['values']())_0x4bcb7e=_0x4bcb7e['concat'](ur(_0x45ad23,_0x437980,_0x55c3b3,_0x2b65e7));return _0x4bcb7e;}}function qo(_0x18e4cc,_0x5aa924,_0x455697,_0x476da6,_0x48cdea){const _0x3721c6=_0x5aa924['_queryIdentifier'],_0x269423=_0x18e4cc['views']['get'](_0x3721c6);if(!_0x269423){let _0x442a73=mn(_0x455697,_0x48cdea?_0x476da6:null),_0x10dad7=!0x1;_0x442a73?_0x10dad7=!0x0:_0x476da6 instanceof g?(_0x442a73=es(_0x455697,_0x476da6),_0x10dad7=!0x1):(_0x442a73=g['EMPTY_NODE'],_0x10dad7=!0x1);const _0x56ee21=Dn(new Ce(_0x442a73,_0x10dad7,!0x1),new Ce(_0x476da6,_0x48cdea,!0x1));return new Nu(_0x5aa924,_0x56ee21);}return _0x269423;}function Wu(_0x2e1fdd,_0x40444e,_0x308490,_0x2f96ab,_0x330f21,_0x4133be){const _0x440133=qo(_0x2e1fdd,_0x40444e,_0x2f96ab,_0x330f21,_0x4133be);return _0x2e1fdd['views']['has'](_0x40444e['_queryIdentifier'])||_0x2e1fdd['views']['set'](_0x40444e['_queryIdentifier'],_0x440133),Mu(_0x440133,_0x308490),Lu(_0x440133,_0x308490);}function Bu(_0x506ec1,_0x44bafb,_0x23d662,_0x431619){const _0x2c1ea4=_0x44bafb['_queryIdentifier'],_0x501877=[];let _0x33b47b=[];const _0x37a3d1=Te(_0x506ec1);if(_0x2c1ea4==='default'){for(const [_0x42cf96,_0x4f7f97]of _0x506ec1['views']['entries']())_0x33b47b=_0x33b47b['concat'](hr(_0x4f7f97,_0x23d662,_0x431619)),lr(_0x4f7f97)&&(_0x506ec1['views']['delete'](_0x42cf96),_0x4f7f97['query']['_queryParams']['loadsAllData']()||_0x501877['push'](_0x4f7f97['query']));}else{const _0xab248a=_0x506ec1['views']['get'](_0x2c1ea4);_0xab248a&&(_0x33b47b=_0x33b47b['concat'](hr(_0xab248a,_0x23d662,_0x431619)),lr(_0xab248a)&&(_0x506ec1['views']['delete'](_0x2c1ea4),_0xab248a['query']['_queryParams']['loadsAllData']()||_0x501877['push'](_0xab248a['query'])));}return _0x37a3d1&&!Te(_0x506ec1)&&_0x501877['push'](new(Fu())(_0x44bafb['_repo'],_0x44bafb['_path'])),{'removed':_0x501877,'events':_0x33b47b};}function zo(_0x3c1c27){const _0x23027d=[];for(const _0x5aa4c6 of _0x3c1c27['views']['values']())_0x5aa4c6['query']['_queryParams']['loadsAllData']()||_0x23027d['push'](_0x5aa4c6);return _0x23027d;}function Ee(_0x104be6,_0x50e017){let _0x258d01=null;for(const _0x16d8f8 of _0x104be6['views']['values']())_0x258d01=_0x258d01||Du(_0x16d8f8,_0x50e017);return _0x258d01;}function jo(_0x321ae2,_0xf8d8e6){if(_0xf8d8e6['_queryParams']['loadsAllData']())return Ln(_0x321ae2);{const _0x1a0561=_0xf8d8e6['_queryIdentifier'];return _0x321ae2['views']['get'](_0x1a0561);}}function Ko(_0x475d2b,_0x42c5f8){return jo(_0x475d2b,_0x42c5f8)!=null;}function Te(_0xdf53e3){return Ln(_0xdf53e3)!=null;}function Ln(_0x1e17ac){for(const _0x38dc8b of _0x1e17ac['views']['values']())if(_0x38dc8b['query']['_queryParams']['loadsAllData']())return _0x38dc8b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x16a4d1){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x16a4d1;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2409eb){this['listenProvider_']=_0x2409eb,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x27235f,_0x26b9ef,_0x591c6e,_0x3e68b2,_0x1ad4cc){return ou(_0x27235f['pendingWriteTree_'],_0x26b9ef,_0x591c6e,_0x3e68b2,_0x1ad4cc),_0x1ad4cc?ht(_0x27235f,new Fe(Ji(),_0x26b9ef,_0x591c6e)):[];}function Gu(_0x196ad0,_0x24bd5f,_0x501e15,_0x57a4d4){au(_0x196ad0['pendingWriteTree_'],_0x24bd5f,_0x501e15,_0x57a4d4);const _0x2c4a7d=S['fromObject'](_0x501e15);return ht(_0x196ad0,new nt(Ji(),_0x24bd5f,_0x2c4a7d));}function pe(_0x1d696a,_0x1b13a2,_0x2bd664=!0x1){const _0x102914=cu(_0x1d696a['pendingWriteTree_'],_0x1b13a2);if(lu(_0x1d696a['pendingWriteTree_'],_0x1b13a2)){let _0x4e675e=new S(null);return _0x102914['snap']!=null?_0x4e675e=_0x4e675e['set'](w(),!0x0):x(_0x102914['children'],_0x387229=>{_0x4e675e=_0x4e675e['set'](new C(_0x387229),!0x0);}),ht(_0x1d696a,new _n(_0x102914['path'],_0x4e675e,_0x2bd664));}else return[];}function $t(_0x37947b,_0x54a1e8,_0x44a93b){return ht(_0x37947b,new Fe(Xi(),_0x54a1e8,_0x44a93b));}function qu(_0x4b2667,_0x1e6300,_0x3f31ce){const _0x95ac98=S['fromObject'](_0x3f31ce);return ht(_0x4b2667,new nt(Xi(),_0x1e6300,_0x95ac98));}function zu(_0x5ec2af,_0x395ce2){return ht(_0x5ec2af,new Dt(Xi(),_0x395ce2));}function ju(_0x1449e9,_0x511b5b,_0x23776c){const _0x1de21d=rs(_0x1449e9,_0x23776c);if(_0x1de21d){const _0x870a45=os(_0x1de21d),_0x178da4=_0x870a45['path'],_0x35d228=_0x870a45['queryId'],_0x1cab27=F(_0x178da4,_0x511b5b),_0x494f25=new Dt(Zi(_0x35d228),_0x1cab27);return as(_0x1449e9,_0x178da4,_0x494f25);}else return[];}function wn(_0x1b57d1,_0x27f854,_0x2e57b9,_0x115a5b,_0x1db51c=!0x1){const _0x266f89=_0x27f854['_path'],_0x38cae3=_0x1b57d1['syncPointTree_']['get'](_0x266f89);let _0x57088d=[];if(_0x38cae3&&(_0x27f854['_queryIdentifier']==='default'||Ko(_0x38cae3,_0x27f854))){const _0x16f0a2=Bu(_0x38cae3,_0x27f854,_0x2e57b9,_0x115a5b);Uu(_0x38cae3)&&(_0x1b57d1['syncPointTree_']=_0x1b57d1['syncPointTree_']['remove'](_0x266f89));const _0x336fdb=_0x16f0a2['removed'];if(_0x57088d=_0x16f0a2['events'],!_0x1db51c){const _0x4c9b3b=_0x336fdb['findIndex'](_0x2594fa=>_0x2594fa['_queryParams']['loadsAllData']())!==-0x1,_0x1d21ab=_0x1b57d1['syncPointTree_']['findOnPath'](_0x266f89,(_0x472a10,_0x4fbdfe)=>Te(_0x4fbdfe));if(_0x4c9b3b&&!_0x1d21ab){const _0x3e854c=_0x1b57d1['syncPointTree_']['subtree'](_0x266f89);if(!_0x3e854c['isEmpty']()){const _0x51fa61=Qu(_0x3e854c);for(let _0x28e6b9=0x0;_0x28e6b9<_0x51fa61['length'];++_0x28e6b9){const _0x4f1f43=_0x51fa61[_0x28e6b9],_0x636534=_0x4f1f43['query'],_0x18e663=Xo(_0x1b57d1,_0x4f1f43);_0x1b57d1['listenProvider_']['startListening'](Tt(_0x636534),Mt(_0x1b57d1,_0x636534),_0x18e663['hashFn'],_0x18e663['onComplete']);}}}!_0x1d21ab&&_0x336fdb['length']>0x0&&!_0x115a5b&&(_0x4c9b3b?_0x1b57d1['listenProvider_']['stopListening'](Tt(_0x27f854),null):_0x336fdb['forEach'](_0x48b1f3=>{const _0x428440=_0x1b57d1['queryToTagMap']['get'](Fn(_0x48b1f3));_0x1b57d1['listenProvider_']['stopListening'](Tt(_0x48b1f3),_0x428440);}));}Ju(_0x1b57d1,_0x336fdb);}return _0x57088d;}function Yo(_0x1c39c2,_0x14996c,_0x4e690a,_0x66ae5c){const _0x1a0056=rs(_0x1c39c2,_0x66ae5c);if(_0x1a0056!=null){const _0x23ba58=os(_0x1a0056),_0x1424bb=_0x23ba58['path'],_0x5cc20e=_0x23ba58['queryId'],_0xf47ac2=F(_0x1424bb,_0x14996c),_0x18b6a4=new Fe(Zi(_0x5cc20e),_0xf47ac2,_0x4e690a);return as(_0x1c39c2,_0x1424bb,_0x18b6a4);}else return[];}function Ku(_0x8dd237,_0x52d01a,_0x3154ff,_0x5f340a){const _0xb639d5=rs(_0x8dd237,_0x5f340a);if(_0xb639d5){const _0x9851cb=os(_0xb639d5),_0xfad246=_0x9851cb['path'],_0x38f5a6=_0x9851cb['queryId'],_0x3f5024=F(_0xfad246,_0x52d01a),_0x4689dc=S['fromObject'](_0x3154ff),_0x233c0e=new nt(Zi(_0x38f5a6),_0x3f5024,_0x4689dc);return as(_0x8dd237,_0xfad246,_0x233c0e);}else return[];}function bi(_0x333b62,_0x3f30c4,_0x115c35,_0x293e39=!0x1){const _0x555e25=_0x3f30c4['_path'];let _0x4991cb=null,_0x7ed847=!0x1;_0x333b62['syncPointTree_']['foreachOnPath'](_0x555e25,(_0x215389,_0x3c2756)=>{const _0x194f0d=F(_0x215389,_0x555e25);_0x4991cb=_0x4991cb||Ee(_0x3c2756,_0x194f0d),_0x7ed847=_0x7ed847||Te(_0x3c2756);});let _0x26576a=_0x333b62['syncPointTree_']['get'](_0x555e25);_0x26576a?(_0x7ed847=_0x7ed847||Te(_0x26576a),_0x4991cb=_0x4991cb||Ee(_0x26576a,w())):(_0x26576a=new Go(),_0x333b62['syncPointTree_']=_0x333b62['syncPointTree_']['set'](_0x555e25,_0x26576a));let _0x5e1df4;_0x4991cb!=null?_0x5e1df4=!0x0:(_0x5e1df4=!0x1,_0x4991cb=g['EMPTY_NODE'],_0x333b62['syncPointTree_']['subtree'](_0x555e25)['foreachChild']((_0x40e8e1,_0x1b9f37)=>{const _0x164a73=Ee(_0x1b9f37,w());_0x164a73&&(_0x4991cb=_0x4991cb['updateImmediateChild'](_0x40e8e1,_0x164a73));}));const _0xc01b22=Ko(_0x26576a,_0x3f30c4);if(!_0xc01b22&&!_0x3f30c4['_queryParams']['loadsAllData']()){const _0x2aafb7=Fn(_0x3f30c4);f(!_0x333b62['queryToTagMap']['has'](_0x2aafb7),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2e3fd2=Xu();_0x333b62['queryToTagMap']['set'](_0x2aafb7,_0x2e3fd2),_0x333b62['tagToQueryMap']['set'](_0x2e3fd2,_0x2aafb7);}const _0x4ebef9=Mn(_0x333b62['pendingWriteTree_'],_0x555e25);let _0x1a8b59=Wu(_0x26576a,_0x3f30c4,_0x115c35,_0x4ebef9,_0x4991cb,_0x5e1df4);if(!_0xc01b22&&!_0x7ed847&&!_0x293e39){const _0x1b52ea=jo(_0x26576a,_0x3f30c4);_0x1a8b59=_0x1a8b59['concat'](Zu(_0x333b62,_0x3f30c4,_0x1b52ea));}return _0x1a8b59;}function xn(_0x508cc6,_0xfaf417,_0x47a751){const _0x17cd1a=_0x508cc6['pendingWriteTree_'],_0x140acd=_0x508cc6['syncPointTree_']['findOnPath'](_0xfaf417,(_0x380f38,_0x1ba978)=>{const _0xb6c206=F(_0x380f38,_0xfaf417),_0x24d3d0=Ee(_0x1ba978,_0xb6c206);if(_0x24d3d0)return _0x24d3d0;});return Uo(_0x17cd1a,_0xfaf417,_0x140acd,_0x47a751,!0x0);}function Yu(_0x1a3b63,_0x4622fa){const _0x16393c=_0x4622fa['_path'];let _0x339b82=null;_0x1a3b63['syncPointTree_']['foreachOnPath'](_0x16393c,(_0xc86cdb,_0x25dc11)=>{const _0xe7ea25=F(_0xc86cdb,_0x16393c);_0x339b82=_0x339b82||Ee(_0x25dc11,_0xe7ea25);});let _0x73b50a=_0x1a3b63['syncPointTree_']['get'](_0x16393c);_0x73b50a?_0x339b82=_0x339b82||Ee(_0x73b50a,w()):(_0x73b50a=new Go(),_0x1a3b63['syncPointTree_']=_0x1a3b63['syncPointTree_']['set'](_0x16393c,_0x73b50a));const _0x3da971=_0x339b82!=null,_0x24242c=_0x3da971?new Ce(_0x339b82,!0x0,!0x1):null,_0x47b0d0=Mn(_0x1a3b63['pendingWriteTree_'],_0x4622fa['_path']),_0x5c5e3d=qo(_0x73b50a,_0x4622fa,_0x47b0d0,_0x3da971?_0x24242c['getNode']():g['EMPTY_NODE'],_0x3da971);return Ou(_0x5c5e3d);}function ht(_0x9e876b,_0x174ae2){return Qo(_0x174ae2,_0x9e876b['syncPointTree_'],null,Mn(_0x9e876b['pendingWriteTree_'],w()));}function Qo(_0x28a279,_0x40fc5e,_0x4ca122,_0x18b0ed){if(v(_0x28a279['path']))return Jo(_0x28a279,_0x40fc5e,_0x4ca122,_0x18b0ed);{const _0x58d688=_0x40fc5e['get'](w());_0x4ca122==null&&_0x58d688!=null&&(_0x4ca122=Ee(_0x58d688,w()));let _0x3b434e=[];const _0x2f63e5=y(_0x28a279['path']),_0x51b76e=_0x28a279['operationForChild'](_0x2f63e5),_0x2c80b3=_0x40fc5e['children']['get'](_0x2f63e5);if(_0x2c80b3&&_0x51b76e){const _0x530cd1=_0x4ca122?_0x4ca122['getImmediateChild'](_0x2f63e5):null,_0x16981e=Wo(_0x18b0ed,_0x2f63e5);_0x3b434e=_0x3b434e['concat'](Qo(_0x51b76e,_0x2c80b3,_0x530cd1,_0x16981e));}return _0x58d688&&(_0x3b434e=_0x3b434e['concat'](is(_0x58d688,_0x28a279,_0x18b0ed,_0x4ca122))),_0x3b434e;}}function Jo(_0x1a33fd,_0x3308af,_0x1fe1db,_0xdfe82f){const _0xaab233=_0x3308af['get'](w());_0x1fe1db==null&&_0xaab233!=null&&(_0x1fe1db=Ee(_0xaab233,w()));let _0x50cb5f=[];return _0x3308af['children']['inorderTraversal']((_0x2ee393,_0x2ce033)=>{const _0x1a7672=_0x1fe1db?_0x1fe1db['getImmediateChild'](_0x2ee393):null,_0x257da4=Wo(_0xdfe82f,_0x2ee393),_0x2e95a3=_0x1a33fd['operationForChild'](_0x2ee393);_0x2e95a3&&(_0x50cb5f=_0x50cb5f['concat'](Jo(_0x2e95a3,_0x2ce033,_0x1a7672,_0x257da4)));}),_0xaab233&&(_0x50cb5f=_0x50cb5f['concat'](is(_0xaab233,_0x1a33fd,_0xdfe82f,_0x1fe1db))),_0x50cb5f;}function Xo(_0x10adf7,_0x3d0a59){const _0x8856fe=_0x3d0a59['query'],_0x50f4fa=Mt(_0x10adf7,_0x8856fe);return{'hashFn':()=>(Pu(_0x3d0a59)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x347cd4=>{if(_0x347cd4==='ok')return _0x50f4fa?ju(_0x10adf7,_0x8856fe['_path'],_0x50f4fa):zu(_0x10adf7,_0x8856fe['_path']);{const _0x105235=ql(_0x347cd4,_0x8856fe);return wn(_0x10adf7,_0x8856fe,null,_0x105235);}}};}function Mt(_0x72d2f9,_0x1e7672){const _0x52b22d=Fn(_0x1e7672);return _0x72d2f9['queryToTagMap']['get'](_0x52b22d);}function Fn(_0x590abb){return _0x590abb['_path']['toString']()+'$'+_0x590abb['_queryIdentifier'];}function rs(_0x2137d2,_0x40a703){return _0x2137d2['tagToQueryMap']['get'](_0x40a703);}function os(_0x868e3b){const _0x423f72=_0x868e3b['indexOf']('$');return f(_0x423f72!==-0x1&&_0x423f72<_0x868e3b['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x868e3b['substr'](_0x423f72+0x1),'path':new C(_0x868e3b['substr'](0x0,_0x423f72))};}function as(_0x4bd3ea,_0x3f64ea,_0x18e259){const _0x3a62fd=_0x4bd3ea['syncPointTree_']['get'](_0x3f64ea);f(_0x3a62fd,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x523f58=Mn(_0x4bd3ea['pendingWriteTree_'],_0x3f64ea);return is(_0x3a62fd,_0x18e259,_0x523f58,null);}function Qu(_0x422f1a){return _0x422f1a['fold']((_0x2704df,_0x5661b9,_0x24d02f)=>{if(_0x5661b9&&Te(_0x5661b9))return[Ln(_0x5661b9)];{let _0x15439b=[];return _0x5661b9&&(_0x15439b=zo(_0x5661b9)),x(_0x24d02f,(_0x3929e0,_0x5ec6b3)=>{_0x15439b=_0x15439b['concat'](_0x5ec6b3);}),_0x15439b;}});}function Tt(_0x4dcdaa){return _0x4dcdaa['_queryParams']['loadsAllData']()&&!_0x4dcdaa['_queryParams']['isDefault']()?new(Hu())(_0x4dcdaa['_repo'],_0x4dcdaa['_path']):_0x4dcdaa;}function Ju(_0x54389f,_0x4a3694){for(let _0x178b9b=0x0;_0x178b9b<_0x4a3694['length'];++_0x178b9b){const _0x3a8f9c=_0x4a3694[_0x178b9b];if(!_0x3a8f9c['_queryParams']['loadsAllData']()){const _0x5eb08b=Fn(_0x3a8f9c),_0x515673=_0x54389f['queryToTagMap']['get'](_0x5eb08b);_0x54389f['queryToTagMap']['delete'](_0x5eb08b),_0x54389f['tagToQueryMap']['delete'](_0x515673);}}}function Xu(){return $u++;}function Zu(_0x28877f,_0xd7fc91,_0x3c445d){const _0x15f054=_0xd7fc91['_path'],_0x3ee976=Mt(_0x28877f,_0xd7fc91),_0x29f825=Xo(_0x28877f,_0x3c445d),_0x14a5dd=_0x28877f['listenProvider_']['startListening'](Tt(_0xd7fc91),_0x3ee976,_0x29f825['hashFn'],_0x29f825['onComplete']),_0x2eb822=_0x28877f['syncPointTree_']['subtree'](_0x15f054);if(_0x3ee976)f(!Te(_0x2eb822['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x1782af=_0x2eb822['fold']((_0x1e9e74,_0x3ee51a,_0xd8da3d)=>{if(!v(_0x1e9e74)&&_0x3ee51a&&Te(_0x3ee51a))return[Ln(_0x3ee51a)['query']];{let _0xff176a=[];return _0x3ee51a&&(_0xff176a=_0xff176a['concat'](zo(_0x3ee51a)['map'](_0x48163c=>_0x48163c['query']))),x(_0xd8da3d,(_0x24365c,_0x51b839)=>{_0xff176a=_0xff176a['concat'](_0x51b839);}),_0xff176a;}});for(let _0xc51210=0x0;_0xc51210<_0x1782af['length'];++_0xc51210){const _0x49251c=_0x1782af[_0xc51210];_0x28877f['listenProvider_']['stopListening'](Tt(_0x49251c),Mt(_0x28877f,_0x49251c));}}return _0x14a5dd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x418151){this['node_']=_0x418151;}['getImmediateChild'](_0x564f88){const _0x27d06e=this['node_']['getImmediateChild'](_0x564f88);return new cs(_0x27d06e);}['node'](){return this['node_'];}}class ls{constructor(_0x286ac7,_0x5c2e8f){this['syncTree_']=_0x286ac7,this['path_']=_0x5c2e8f;}['getImmediateChild'](_0x5b6e05){const _0x5ae497=A(this['path_'],_0x5b6e05);return new ls(this['syncTree_'],_0x5ae497);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x23eafa){return _0x23eafa=_0x23eafa||{},_0x23eafa['timestamp']=_0x23eafa['timestamp']||new Date()['getTime'](),_0x23eafa;},fr=function(_0x5b1a66,_0x1c1bc9,_0x272ed1){if(!_0x5b1a66||typeof _0x5b1a66!='object')return _0x5b1a66;if(f('.sv'in _0x5b1a66,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5b1a66['.sv']=='string')return td(_0x5b1a66['.sv'],_0x1c1bc9,_0x272ed1);if(typeof _0x5b1a66['.sv']=='object')return nd(_0x5b1a66['.sv'],_0x1c1bc9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5b1a66,null,0x2));},td=function(_0x39f25f,_0x3bdce5,_0x15e2eb){switch(_0x39f25f){case'timestamp':return _0x15e2eb['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x39f25f);}},nd=function(_0x3ce578,_0x466ae9,_0x4ef0ea){_0x3ce578['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3ce578,null,0x2));const _0x42441a=_0x3ce578['increment'];typeof _0x42441a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x42441a);const _0x4d3258=_0x466ae9['node']();if(f(_0x4d3258!==null&&typeof _0x4d3258<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4d3258['isLeafNode']())return _0x42441a;const _0x383936=_0x4d3258['getValue']();return typeof _0x383936!='number'?_0x42441a:_0x383936+_0x42441a;},Zo=function(_0x4e6eab,_0x488851,_0x29d168,_0x4dea5d){return us(_0x488851,new ls(_0x29d168,_0x4e6eab),_0x4dea5d);},hs=function(_0x543c77,_0x21f2b2,_0x105278){return us(_0x543c77,new cs(_0x21f2b2),_0x105278);};function us(_0x325a3b,_0x5cf0e3,_0x2495e2){const _0xf2f983=_0x325a3b['getPriority']()['val'](),_0x5554ac=fr(_0xf2f983,_0x5cf0e3['getImmediateChild']('.priority'),_0x2495e2);let _0x111e9e;if(_0x325a3b['isLeafNode']()){const _0x4c9a02=_0x325a3b,_0x34798e=fr(_0x4c9a02['getValue'](),_0x5cf0e3,_0x2495e2);return _0x34798e!==_0x4c9a02['getValue']()||_0x5554ac!==_0x4c9a02['getPriority']()['val']()?new D(_0x34798e,N(_0x5554ac)):_0x325a3b;}else{const _0x48d124=_0x325a3b;return _0x111e9e=_0x48d124,_0x5554ac!==_0x48d124['getPriority']()['val']()&&(_0x111e9e=_0x111e9e['updatePriority'](new D(_0x5554ac))),_0x48d124['forEachChild'](R,(_0x1fec65,_0x138672)=>{const _0x29bdd7=us(_0x138672,_0x5cf0e3['getImmediateChild'](_0x1fec65),_0x2495e2);_0x29bdd7!==_0x138672&&(_0x111e9e=_0x111e9e['updateImmediateChild'](_0x1fec65,_0x29bdd7));}),_0x111e9e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x154460='',_0x3f5831=null,_0x2ed50e={'children':{},'childCount':0x0}){this['name']=_0x154460,this['parent']=_0x3f5831,this['node']=_0x2ed50e;}}function Un(_0x19861a,_0x2db0cb){let _0x43f3b8=_0x2db0cb instanceof C?_0x2db0cb:new C(_0x2db0cb),_0x11e940=_0x19861a,_0x4913b1=y(_0x43f3b8);for(;_0x4913b1!==null;){const _0x4f2ef8=Oe(_0x11e940['node']['children'],_0x4913b1)||{'children':{},'childCount':0x0};_0x11e940=new ds(_0x4913b1,_0x11e940,_0x4f2ef8),_0x43f3b8=b(_0x43f3b8),_0x4913b1=y(_0x43f3b8);}return _0x11e940;}function Ge(_0x86bd8c){return _0x86bd8c['node']['value'];}function fs(_0x2ad345,_0x298ee9){_0x2ad345['node']['value']=_0x298ee9,Ri(_0x2ad345);}function ea(_0x34b73){return _0x34b73['node']['childCount']>0x0;}function id(_0x115399){return Ge(_0x115399)===void 0x0&&!ea(_0x115399);}function Wn(_0x19a8f4,_0x3d0a42){x(_0x19a8f4['node']['children'],(_0x2245e3,_0xed2cb5)=>{_0x3d0a42(new ds(_0x2245e3,_0x19a8f4,_0xed2cb5));});}function ta(_0x2c9bdb,_0x43cf4a,_0x4d4128,_0x135fa6){_0x4d4128&&_0x43cf4a(_0x2c9bdb),Wn(_0x2c9bdb,_0x3947a2=>{ta(_0x3947a2,_0x43cf4a,!0x0);});}function sd(_0x4ebb58,_0x4db09d,_0x3c6689){let _0x290f9f=_0x4ebb58['parent'];for(;_0x290f9f!==null;){if(_0x4db09d(_0x290f9f))return!0x0;_0x290f9f=_0x290f9f['parent'];}return!0x1;}function Gt(_0x115db4){return new C(_0x115db4['parent']===null?_0x115db4['name']:Gt(_0x115db4['parent'])+'/'+_0x115db4['name']);}function Ri(_0x43f3d4){_0x43f3d4['parent']!==null&&rd(_0x43f3d4['parent'],_0x43f3d4['name'],_0x43f3d4);}function rd(_0x591bac,_0xc8cbe9,_0x31999a){const _0x492837=id(_0x31999a),_0x83a03f=Y(_0x591bac['node']['children'],_0xc8cbe9);_0x492837&&_0x83a03f?(delete _0x591bac['node']['children'][_0xc8cbe9],_0x591bac['node']['childCount']--,Ri(_0x591bac)):!_0x492837&&!_0x83a03f&&(_0x591bac['node']['children'][_0xc8cbe9]=_0x31999a['node'],_0x591bac['node']['childCount']++,Ri(_0x591bac));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2fe907){return typeof _0x2fe907=='string'&&_0x2fe907['length']!==0x0&&!od['test'](_0x2fe907);},na=function(_0xedc4c8){return typeof _0xedc4c8=='string'&&_0xedc4c8['length']!==0x0&&!ad['test'](_0xedc4c8);},cd=function(_0xae886f){return _0xae886f&&(_0xae886f=_0xae886f['replace'](/^\/*\.info(\/|$)/,'/')),na(_0xae886f);},Cn=function(_0x28a128){return _0x28a128===null||typeof _0x28a128=='string'||typeof _0x28a128=='number'&&!Wi(_0x28a128)||_0x28a128&&typeof _0x28a128=='object'&&Y(_0x28a128,'.sv');},qt=function(_0xa5ea8e,_0x8236f,_0x17dfb0,_0x24e7c8){_0x24e7c8&&_0x8236f===void 0x0||zt(Nn(_0xa5ea8e,'value'),_0x8236f,_0x17dfb0);},zt=function(_0x1e575e,_0x199c25,_0x474382){const _0x3c0601=_0x474382 instanceof C?new Sh(_0x474382,_0x1e575e):_0x474382;if(_0x199c25===void 0x0)throw new Error(_0x1e575e+'contains\x20undefined\x20'+Ne(_0x3c0601));if(typeof _0x199c25=='function')throw new Error(_0x1e575e+'contains\x20a\x20function\x20'+Ne(_0x3c0601)+'\x20with\x20contents\x20=\x20'+_0x199c25['toString']());if(Wi(_0x199c25))throw new Error(_0x1e575e+'contains\x20'+_0x199c25['toString']()+'\x20'+Ne(_0x3c0601));if(typeof _0x199c25=='string'&&_0x199c25['length']>oi/0x3&&Pn(_0x199c25)>oi)throw new Error(_0x1e575e+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x3c0601)+'\x20(\x27'+_0x199c25['substring'](0x0,0x32)+'...\x27)');if(_0x199c25&&typeof _0x199c25=='object'){let _0x5694ad=!0x1,_0x4feb5d=!0x1;if(x(_0x199c25,(_0x4781d6,_0x2e7bb2)=>{if(_0x4781d6==='.value')_0x5694ad=!0x0;else{if(_0x4781d6!=='.priority'&&_0x4781d6!=='.sv'&&(_0x4feb5d=!0x0,!ps(_0x4781d6)))throw new Error(_0x1e575e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4781d6+')\x20'+Ne(_0x3c0601)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x3c0601,_0x4781d6),zt(_0x1e575e,_0x2e7bb2,_0x3c0601),Rh(_0x3c0601);}),_0x5694ad&&_0x4feb5d)throw new Error(_0x1e575e+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x3c0601)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x4fb624,_0x44548d){let _0x6a10b6,_0x4604d0;for(_0x6a10b6=0x0;_0x6a10b6<_0x44548d['length'];_0x6a10b6++){_0x4604d0=_0x44548d[_0x6a10b6];const _0x2933e6=kt(_0x4604d0);for(let _0x48784d=0x0;_0x48784d<_0x2933e6['length'];_0x48784d++)if(!(_0x2933e6[_0x48784d]==='.priority'&&_0x48784d===_0x2933e6['length']-0x1)){if(!ps(_0x2933e6[_0x48784d]))throw new Error(_0x4fb624+'contains\x20an\x20invalid\x20key\x20('+_0x2933e6[_0x48784d]+')\x20in\x20path\x20'+_0x4604d0['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x44548d['sort'](Th);let _0x5607bc=null;for(_0x6a10b6=0x0;_0x6a10b6<_0x44548d['length'];_0x6a10b6++){if(_0x4604d0=_0x44548d[_0x6a10b6],_0x5607bc!==null&&$(_0x5607bc,_0x4604d0))throw new Error(_0x4fb624+'contains\x20a\x20path\x20'+_0x5607bc['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4604d0['toString']());_0x5607bc=_0x4604d0;}},hd=function(_0x503581,_0x4043a2,_0x1556b5,_0x1a5ab7){const _0x44a453=Nn(_0x503581,'values');if(!(_0x4043a2&&typeof _0x4043a2=='object')||Array['isArray'](_0x4043a2))throw new Error(_0x44a453+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x35a788=[];x(_0x4043a2,(_0x262de8,_0x1d2ab1)=>{const _0x4db7fb=new C(_0x262de8);if(zt(_0x44a453,_0x1d2ab1,A(_0x1556b5,_0x4db7fb)),Gi(_0x4db7fb)==='.priority'&&!Cn(_0x1d2ab1))throw new Error(_0x44a453+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4db7fb['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x35a788['push'](_0x4db7fb);}),ld(_0x44a453,_0x35a788);},_s=function(_0x211ebf,_0x49d340,_0x2f443e,_0x5e2ab3){if(!na(_0x2f443e))throw new Error(Nn(_0x211ebf,_0x49d340)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2f443e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x3b7d94,_0x1566d0,_0x482441,_0x28a68d){_0x482441&&(_0x482441=_0x482441['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x3b7d94,_0x1566d0,_0x482441);},gs=function(_0x4b7a0d,_0x4fa31f){if(y(_0x4fa31f)==='.info')throw new Error(_0x4b7a0d+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x456047,_0x58202f){const _0xa5c2a2=_0x58202f['path']['toString']();if(typeof _0x58202f['repoInfo']['host']!='string'||_0x58202f['repoInfo']['host']['length']===0x0||!ps(_0x58202f['repoInfo']['namespace'])&&_0x58202f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xa5c2a2['length']!==0x0&&!cd(_0xa5c2a2))throw new Error(Nn(_0x456047,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x34a7e3,_0x460bac){let _0x3cc396=null;for(let _0x28d649=0x0;_0x28d649<_0x460bac['length'];_0x28d649++){const _0x5312b4=_0x460bac[_0x28d649],_0x1ee860=_0x5312b4['getPath']();_0x3cc396!==null&&!qi(_0x1ee860,_0x3cc396['path'])&&(_0x34a7e3['eventLists_']['push'](_0x3cc396),_0x3cc396=null),_0x3cc396===null&&(_0x3cc396={'events':[],'path':_0x1ee860}),_0x3cc396['events']['push'](_0x5312b4);}_0x3cc396&&_0x34a7e3['eventLists_']['push'](_0x3cc396);}function ia(_0x4591d5,_0x327249,_0x55e064){Bn(_0x4591d5,_0x55e064),sa(_0x4591d5,_0x4f70ec=>qi(_0x4f70ec,_0x327249));}function V(_0x46b8c3,_0x1b22ec,_0x18c6e4){Bn(_0x46b8c3,_0x18c6e4),sa(_0x46b8c3,_0x3cd05d=>$(_0x3cd05d,_0x1b22ec)||$(_0x1b22ec,_0x3cd05d));}function sa(_0xf26d5d,_0x52d4ff){_0xf26d5d['recursionDepth_']++;let _0x2d7116=!0x0;for(let _0x3006eb=0x0;_0x3006eb<_0xf26d5d['eventLists_']['length'];_0x3006eb++){const _0x4efc5b=_0xf26d5d['eventLists_'][_0x3006eb];if(_0x4efc5b){const _0x341420=_0x4efc5b['path'];_0x52d4ff(_0x341420)?(pd(_0xf26d5d['eventLists_'][_0x3006eb]),_0xf26d5d['eventLists_'][_0x3006eb]=null):_0x2d7116=!0x1;}}_0x2d7116&&(_0xf26d5d['eventLists_']=[]),_0xf26d5d['recursionDepth_']--;}function pd(_0x425e70){for(let _0x2abd57=0x0;_0x2abd57<_0x425e70['events']['length'];_0x2abd57++){const _0x1849c4=_0x425e70['events'][_0x2abd57];if(_0x1849c4!==null){_0x425e70['events'][_0x2abd57]=null;const _0xff66a7=_0x1849c4['getEventRunner']();Et&&L('event:\x20'+_0x1849c4['toString']()),lt(_0xff66a7);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x3e0b97,_0x1b9956,_0x5c5264,_0x4e8de7){this['repoInfo_']=_0x3e0b97,this['forceRestClient_']=_0x1b9956,this['authTokenProvider_']=_0x5c5264,this['appCheckProvider_']=_0x4e8de7,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x5869c2,_0x45b92d,_0x593522){if(_0x5869c2['stats_']=Hi(_0x5869c2['repoInfo_']),_0x5869c2['forceRestClient_']||Yl())_0x5869c2['server_']=new fn(_0x5869c2['repoInfo_'],(_0x352a2e,_0x1f23c8,_0x496eb9,_0x3da09b)=>{pr(_0x5869c2,_0x352a2e,_0x1f23c8,_0x496eb9,_0x3da09b);},_0x5869c2['authTokenProvider_'],_0x5869c2['appCheckProvider_']),setTimeout(()=>_r(_0x5869c2,!0x0),0x0);else{if(typeof _0x593522<'u'&&_0x593522!==null){if(typeof _0x593522!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x593522);}catch(_0x25dd91){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x25dd91);}}_0x5869c2['persistentConnection_']=new ie(_0x5869c2['repoInfo_'],_0x45b92d,(_0x5b465b,_0x1b1dac,_0x57f1e5,_0x1e5f70)=>{pr(_0x5869c2,_0x5b465b,_0x1b1dac,_0x57f1e5,_0x1e5f70);},_0x418f53=>{_r(_0x5869c2,_0x418f53);},_0x24e1c5=>{yd(_0x5869c2,_0x24e1c5);},_0x5869c2['authTokenProvider_'],_0x5869c2['appCheckProvider_'],_0x593522),_0x5869c2['server_']=_0x5869c2['persistentConnection_'];}_0x5869c2['authTokenProvider_']['addTokenChangeListener'](_0x287c66=>{_0x5869c2['server_']['refreshAuthToken'](_0x287c66);}),_0x5869c2['appCheckProvider_']['addTokenChangeListener'](_0x21ca00=>{_0x5869c2['server_']['refreshAppCheckToken'](_0x21ca00['token']);}),_0x5869c2['statsReporter_']=eh(_0x5869c2['repoInfo_'],()=>new eu(_0x5869c2['stats_'],_0x5869c2['server_'])),_0x5869c2['infoData_']=new Yh(),_0x5869c2['infoSyncTree_']=new dr({'startListening':(_0x575e0e,_0x1ee39f,_0x4899ac,_0xd656e)=>{let _0x12ff76=[];const _0x40b00a=_0x5869c2['infoData_']['getNode'](_0x575e0e['_path']);return _0x40b00a['isEmpty']()||(_0x12ff76=$t(_0x5869c2['infoSyncTree_'],_0x575e0e['_path'],_0x40b00a),setTimeout(()=>{_0xd656e('ok');},0x0)),_0x12ff76;},'stopListening':()=>{}}),ms(_0x5869c2,'connected',!0x1),_0x5869c2['serverSyncTree_']=new dr({'startListening':(_0x51997e,_0x6464d4,_0x5c658a,_0x593c48)=>(_0x5869c2['server_']['listen'](_0x51997e,_0x5c658a,_0x6464d4,(_0x2e7040,_0x4cf818)=>{const _0x1baee0=_0x593c48(_0x2e7040,_0x4cf818);V(_0x5869c2['eventQueue_'],_0x51997e['_path'],_0x1baee0);}),[]),'stopListening':(_0x1ab6e5,_0x415662)=>{_0x5869c2['server_']['unlisten'](_0x1ab6e5,_0x415662);}});}function oa(_0x1a170e){const _0x232d07=_0x1a170e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x232d07;}function jt(_0x45fee7){return ed({'timestamp':oa(_0x45fee7)});}function pr(_0x5e8c75,_0x4968c3,_0x1a47ed,_0x5d06bc,_0xa8e4cd){_0x5e8c75['dataUpdateCount']++;const _0x537050=new C(_0x4968c3);_0x1a47ed=_0x5e8c75['interceptServerDataCallback_']?_0x5e8c75['interceptServerDataCallback_'](_0x4968c3,_0x1a47ed):_0x1a47ed;let _0xc578ee=[];if(_0xa8e4cd){if(_0x5d06bc){const _0x232e41=ln(_0x1a47ed,_0xe92d95=>N(_0xe92d95));_0xc578ee=Ku(_0x5e8c75['serverSyncTree_'],_0x537050,_0x232e41,_0xa8e4cd);}else{const _0x237e12=N(_0x1a47ed);_0xc578ee=Yo(_0x5e8c75['serverSyncTree_'],_0x537050,_0x237e12,_0xa8e4cd);}}else{if(_0x5d06bc){const _0x569fd0=ln(_0x1a47ed,_0x49ecc3=>N(_0x49ecc3));_0xc578ee=qu(_0x5e8c75['serverSyncTree_'],_0x537050,_0x569fd0);}else{const _0x2e8e23=N(_0x1a47ed);_0xc578ee=$t(_0x5e8c75['serverSyncTree_'],_0x537050,_0x2e8e23);}}let _0x335b33=_0x537050;_0xc578ee['length']>0x0&&(_0x335b33=st(_0x5e8c75,_0x537050)),V(_0x5e8c75['eventQueue_'],_0x335b33,_0xc578ee);}function _r(_0x49cbc9,_0x4b78e7){ms(_0x49cbc9,'connected',_0x4b78e7),_0x4b78e7===!0x1&&wd(_0x49cbc9);}function yd(_0x20de6b,_0x5c5a34){x(_0x5c5a34,(_0x31d7b0,_0x51f6fd)=>{ms(_0x20de6b,_0x31d7b0,_0x51f6fd);});}function ms(_0x27e570,_0x543c99,_0x4a90a7){const _0x4c1f99=new C('/.info/'+_0x543c99),_0x5ee794=N(_0x4a90a7);_0x27e570['infoData_']['updateSnapshot'](_0x4c1f99,_0x5ee794);const _0xf9d0e9=$t(_0x27e570['infoSyncTree_'],_0x4c1f99,_0x5ee794);V(_0x27e570['eventQueue_'],_0x4c1f99,_0xf9d0e9);}function Vn(_0x25098c){return _0x25098c['nextWriteId_']++;}function vd(_0x2639bc,_0x181c8f,_0x1a5b1a){const _0xe4f2b6=Yu(_0x2639bc['serverSyncTree_'],_0x181c8f);return _0xe4f2b6!=null?Promise['resolve'](_0xe4f2b6):_0x2639bc['server_']['get'](_0x181c8f)['then'](_0x28f96d=>{const _0x1818f4=N(_0x28f96d)['withIndex'](_0x181c8f['_queryParams']['getIndex']());bi(_0x2639bc['serverSyncTree_'],_0x181c8f,_0x1a5b1a,!0x0);let _0x1d34c8;if(_0x181c8f['_queryParams']['loadsAllData']())_0x1d34c8=$t(_0x2639bc['serverSyncTree_'],_0x181c8f['_path'],_0x1818f4);else{const _0x5d9a08=Mt(_0x2639bc['serverSyncTree_'],_0x181c8f);_0x1d34c8=Yo(_0x2639bc['serverSyncTree_'],_0x181c8f['_path'],_0x1818f4,_0x5d9a08);}return V(_0x2639bc['eventQueue_'],_0x181c8f['_path'],_0x1d34c8),wn(_0x2639bc['serverSyncTree_'],_0x181c8f,_0x1a5b1a,null,!0x0),_0x1818f4;},_0x1086c5=>(ut(_0x2639bc,'get\x20for\x20query\x20'+O(_0x181c8f)+'\x20failed:\x20'+_0x1086c5),Promise['reject'](new Error(_0x1086c5))));}function Ed(_0x34f56c,_0x234f21,_0x1005fe,_0x47f9dc,_0x4979b8){ut(_0x34f56c,'set',{'path':_0x234f21['toString'](),'value':_0x1005fe,'priority':_0x47f9dc});const _0x4136a2=jt(_0x34f56c),_0x32a704=N(_0x1005fe,_0x47f9dc),_0x25d673=xn(_0x34f56c['serverSyncTree_'],_0x234f21),_0x48ab7b=hs(_0x32a704,_0x25d673,_0x4136a2),_0x159b0e=Vn(_0x34f56c),_0x17e0db=ss(_0x34f56c['serverSyncTree_'],_0x234f21,_0x48ab7b,_0x159b0e,!0x0);Bn(_0x34f56c['eventQueue_'],_0x17e0db),_0x34f56c['server_']['put'](_0x234f21['toString'](),_0x32a704['val'](!0x0),(_0xb65129,_0x243710)=>{const _0x1875fb=_0xb65129==='ok';_0x1875fb||U('set\x20at\x20'+_0x234f21+'\x20failed:\x20'+_0xb65129);const _0xcd97f7=pe(_0x34f56c['serverSyncTree_'],_0x159b0e,!_0x1875fb);V(_0x34f56c['eventQueue_'],_0x234f21,_0xcd97f7),Ai(_0x34f56c,_0x4979b8,_0xb65129,_0x243710);});const _0x383249=vs(_0x34f56c,_0x234f21);st(_0x34f56c,_0x383249),V(_0x34f56c['eventQueue_'],_0x383249,[]);}function Id(_0x327c90,_0x971b31,_0x12f02e,_0x19a924){ut(_0x327c90,'update',{'path':_0x971b31['toString'](),'value':_0x12f02e});let _0x4a0da2=!0x0;const _0x234144=jt(_0x327c90),_0x49c276={};if(x(_0x12f02e,(_0x89a987,_0x33a739)=>{_0x4a0da2=!0x1,_0x49c276[_0x89a987]=Zo(A(_0x971b31,_0x89a987),N(_0x33a739),_0x327c90['serverSyncTree_'],_0x234144);}),_0x4a0da2)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x327c90,_0x19a924,'ok',void 0x0);else{const _0x56c37a=Vn(_0x327c90),_0x111b04=Gu(_0x327c90['serverSyncTree_'],_0x971b31,_0x49c276,_0x56c37a);Bn(_0x327c90['eventQueue_'],_0x111b04),_0x327c90['server_']['merge'](_0x971b31['toString'](),_0x12f02e,(_0x37eb74,_0x702fd0)=>{const _0x3829a0=_0x37eb74==='ok';_0x3829a0||U('update\x20at\x20'+_0x971b31+'\x20failed:\x20'+_0x37eb74);const _0x4b9bda=pe(_0x327c90['serverSyncTree_'],_0x56c37a,!_0x3829a0),_0x5991ab=_0x4b9bda['length']>0x0?st(_0x327c90,_0x971b31):_0x971b31;V(_0x327c90['eventQueue_'],_0x5991ab,_0x4b9bda),Ai(_0x327c90,_0x19a924,_0x37eb74,_0x702fd0);}),x(_0x12f02e,_0x146511=>{const _0x598777=vs(_0x327c90,A(_0x971b31,_0x146511));st(_0x327c90,_0x598777);}),V(_0x327c90['eventQueue_'],_0x971b31,[]);}}function wd(_0x818a0c){ut(_0x818a0c,'onDisconnectEvents');const _0x2eb986=jt(_0x818a0c),_0xa08f12=pn();Ei(_0x818a0c['onDisconnect_'],w(),(_0x30d26c,_0x5bd7fa)=>{const _0x1bf00f=Zo(_0x30d26c,_0x5bd7fa,_0x818a0c['serverSyncTree_'],_0x2eb986);Mo(_0xa08f12,_0x30d26c,_0x1bf00f);});let _0xd66ef=[];Ei(_0xa08f12,w(),(_0x3b03bc,_0xe12fc6)=>{_0xd66ef=_0xd66ef['concat']($t(_0x818a0c['serverSyncTree_'],_0x3b03bc,_0xe12fc6));const _0x5a501a=vs(_0x818a0c,_0x3b03bc);st(_0x818a0c,_0x5a501a);}),_0x818a0c['onDisconnect_']=pn(),V(_0x818a0c['eventQueue_'],w(),_0xd66ef);}function Cd(_0x2f6408,_0x4f592e,_0x91327){let _0x4aa916;y(_0x4f592e['_path'])==='.info'?_0x4aa916=bi(_0x2f6408['infoSyncTree_'],_0x4f592e,_0x91327):_0x4aa916=bi(_0x2f6408['serverSyncTree_'],_0x4f592e,_0x91327),ia(_0x2f6408['eventQueue_'],_0x4f592e['_path'],_0x4aa916);}function Td(_0x316812,_0x44c23e,_0x2866ff){let _0x1aea5d;y(_0x44c23e['_path'])==='.info'?_0x1aea5d=wn(_0x316812['infoSyncTree_'],_0x44c23e,_0x2866ff):_0x1aea5d=wn(_0x316812['serverSyncTree_'],_0x44c23e,_0x2866ff),ia(_0x316812['eventQueue_'],_0x44c23e['_path'],_0x1aea5d);}function aa(_0x63844e){_0x63844e['persistentConnection_']&&_0x63844e['persistentConnection_']['interrupt'](ra);}function Sd(_0x5311d6){_0x5311d6['persistentConnection_']&&_0x5311d6['persistentConnection_']['resume'](ra);}function ut(_0x228341,..._0x1f8529){let _0x870c37='';_0x228341['persistentConnection_']&&(_0x870c37=_0x228341['persistentConnection_']['id']+':'),L(_0x870c37,..._0x1f8529);}function Ai(_0x246e1e,_0x9cb3f3,_0x1fd774,_0x17cc27){_0x9cb3f3&&lt(()=>{if(_0x1fd774==='ok')_0x9cb3f3(null);else{const _0x3c334a=(_0x1fd774||'error')['toUpperCase']();let _0x134725=_0x3c334a;_0x17cc27&&(_0x134725+=':\x20'+_0x17cc27);const _0xa619f2=new Error(_0x134725);_0xa619f2['code']=_0x3c334a,_0x9cb3f3(_0xa619f2);}});}function bd(_0x24ea74,_0x1405f1,_0x32540d,_0x20099f,_0x33f0c8,_0x163fd9){ut(_0x24ea74,'transaction\x20on\x20'+_0x1405f1);const _0x583ec1={'path':_0x1405f1,'update':_0x32540d,'onComplete':_0x20099f,'status':null,'order':to(),'applyLocally':_0x163fd9,'retryCount':0x0,'unwatcher':_0x33f0c8,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2fb3ef=ys(_0x24ea74,_0x1405f1,void 0x0);_0x583ec1['currentInputSnapshot']=_0x2fb3ef;const _0x144a84=_0x583ec1['update'](_0x2fb3ef['val']());if(_0x144a84===void 0x0)_0x583ec1['unwatcher'](),_0x583ec1['currentOutputSnapshotRaw']=null,_0x583ec1['currentOutputSnapshotResolved']=null,_0x583ec1['onComplete']&&_0x583ec1['onComplete'](null,!0x1,_0x583ec1['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x144a84,_0x583ec1['path']),_0x583ec1['status']=0x0;const _0x592591=Un(_0x24ea74['transactionQueueTree_'],_0x1405f1),_0x3efb54=Ge(_0x592591)||[];_0x3efb54['push'](_0x583ec1),fs(_0x592591,_0x3efb54);let _0x976b2c;typeof _0x144a84=='object'&&_0x144a84!==null&&Y(_0x144a84,'.priority')?(_0x976b2c=Oe(_0x144a84,'.priority'),f(Cn(_0x976b2c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x976b2c=(xn(_0x24ea74['serverSyncTree_'],_0x1405f1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x936ee4=jt(_0x24ea74),_0x304c59=N(_0x144a84,_0x976b2c),_0x50260a=hs(_0x304c59,_0x2fb3ef,_0x936ee4);_0x583ec1['currentOutputSnapshotRaw']=_0x304c59,_0x583ec1['currentOutputSnapshotResolved']=_0x50260a,_0x583ec1['currentWriteId']=Vn(_0x24ea74);const _0x2026bd=ss(_0x24ea74['serverSyncTree_'],_0x1405f1,_0x50260a,_0x583ec1['currentWriteId'],_0x583ec1['applyLocally']);V(_0x24ea74['eventQueue_'],_0x1405f1,_0x2026bd),Hn(_0x24ea74,_0x24ea74['transactionQueueTree_']);}}function ys(_0x3257ea,_0x2bce42,_0x51bc49){return xn(_0x3257ea['serverSyncTree_'],_0x2bce42,_0x51bc49)||g['EMPTY_NODE'];}function Hn(_0xc9c4dc,_0x398f9f=_0xc9c4dc['transactionQueueTree_']){if(_0x398f9f||$n(_0xc9c4dc,_0x398f9f),Ge(_0x398f9f)){const _0x4bdeda=la(_0xc9c4dc,_0x398f9f);f(_0x4bdeda['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4bdeda['every'](_0x38d585=>_0x38d585['status']===0x0)&&Rd(_0xc9c4dc,Gt(_0x398f9f),_0x4bdeda);}else ea(_0x398f9f)&&Wn(_0x398f9f,_0x5e4b12=>{Hn(_0xc9c4dc,_0x5e4b12);});}function Rd(_0x1fc50f,_0x48be8b,_0x5ea8cf){const _0x371f8b=_0x5ea8cf['map'](_0x5e6aeb=>_0x5e6aeb['currentWriteId']),_0x41799d=ys(_0x1fc50f,_0x48be8b,_0x371f8b);let _0x457d43=_0x41799d;const _0x4d8bb4=_0x41799d['hash']();for(let _0x245916=0x0;_0x245916<_0x5ea8cf['length'];_0x245916++){const _0x710368=_0x5ea8cf[_0x245916];f(_0x710368['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x710368['status']=0x1,_0x710368['retryCount']++;const _0x2b0700=F(_0x48be8b,_0x710368['path']);_0x457d43=_0x457d43['updateChild'](_0x2b0700,_0x710368['currentOutputSnapshotRaw']);}const _0x4bbdf8=_0x457d43['val'](!0x0),_0x1142d8=_0x48be8b;_0x1fc50f['server_']['put'](_0x1142d8['toString'](),_0x4bbdf8,_0x53557e=>{ut(_0x1fc50f,'transaction\x20put\x20response',{'path':_0x1142d8['toString'](),'status':_0x53557e});let _0x3d0ce4=[];if(_0x53557e==='ok'){const _0x4030bf=[];for(let _0x4ddc70=0x0;_0x4ddc70<_0x5ea8cf['length'];_0x4ddc70++)_0x5ea8cf[_0x4ddc70]['status']=0x2,_0x3d0ce4=_0x3d0ce4['concat'](pe(_0x1fc50f['serverSyncTree_'],_0x5ea8cf[_0x4ddc70]['currentWriteId'])),_0x5ea8cf[_0x4ddc70]['onComplete']&&_0x4030bf['push'](()=>_0x5ea8cf[_0x4ddc70]['onComplete'](null,!0x0,_0x5ea8cf[_0x4ddc70]['currentOutputSnapshotResolved'])),_0x5ea8cf[_0x4ddc70]['unwatcher']();$n(_0x1fc50f,Un(_0x1fc50f['transactionQueueTree_'],_0x48be8b)),Hn(_0x1fc50f,_0x1fc50f['transactionQueueTree_']),V(_0x1fc50f['eventQueue_'],_0x48be8b,_0x3d0ce4);for(let _0x2a60d8=0x0;_0x2a60d8<_0x4030bf['length'];_0x2a60d8++)lt(_0x4030bf[_0x2a60d8]);}else{if(_0x53557e==='datastale'){for(let _0x5c09cd=0x0;_0x5c09cd<_0x5ea8cf['length'];_0x5c09cd++)_0x5ea8cf[_0x5c09cd]['status']===0x3?_0x5ea8cf[_0x5c09cd]['status']=0x4:_0x5ea8cf[_0x5c09cd]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1142d8['toString']()+'\x20failed:\x20'+_0x53557e);for(let _0x8d2330=0x0;_0x8d2330<_0x5ea8cf['length'];_0x8d2330++)_0x5ea8cf[_0x8d2330]['status']=0x4,_0x5ea8cf[_0x8d2330]['abortReason']=_0x53557e;}st(_0x1fc50f,_0x48be8b);}},_0x4d8bb4);}function st(_0x2ab425,_0x2d59a1){const _0x33ec4a=ca(_0x2ab425,_0x2d59a1),_0x14d41b=Gt(_0x33ec4a),_0x551fa2=la(_0x2ab425,_0x33ec4a);return Ad(_0x2ab425,_0x551fa2,_0x14d41b),_0x14d41b;}function Ad(_0x53b15d,_0x159b1f,_0x4d1bd8){if(_0x159b1f['length']===0x0)return;const _0x1d1a63=[];let _0x2d9149=[];const _0x123f2d=_0x159b1f['filter'](_0x3128bc=>_0x3128bc['status']===0x0)['map'](_0x5ace93=>_0x5ace93['currentWriteId']);for(let _0x42b6dc=0x0;_0x42b6dc<_0x159b1f['length'];_0x42b6dc++){const _0xbf756b=_0x159b1f[_0x42b6dc],_0x18f639=F(_0x4d1bd8,_0xbf756b['path']);let _0x310130=!0x1,_0x46a172;if(f(_0x18f639!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xbf756b['status']===0x4)_0x310130=!0x0,_0x46a172=_0xbf756b['abortReason'],_0x2d9149=_0x2d9149['concat'](pe(_0x53b15d['serverSyncTree_'],_0xbf756b['currentWriteId'],!0x0));else{if(_0xbf756b['status']===0x0){if(_0xbf756b['retryCount']>=_d)_0x310130=!0x0,_0x46a172='maxretry',_0x2d9149=_0x2d9149['concat'](pe(_0x53b15d['serverSyncTree_'],_0xbf756b['currentWriteId'],!0x0));else{const _0x32625e=ys(_0x53b15d,_0xbf756b['path'],_0x123f2d);_0xbf756b['currentInputSnapshot']=_0x32625e;const _0xba2a1=_0x159b1f[_0x42b6dc]['update'](_0x32625e['val']());if(_0xba2a1!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xba2a1,_0xbf756b['path']);let _0x4baa25=N(_0xba2a1);typeof _0xba2a1=='object'&&_0xba2a1!=null&&Y(_0xba2a1,'.priority')||(_0x4baa25=_0x4baa25['updatePriority'](_0x32625e['getPriority']()));const _0x22425e=_0xbf756b['currentWriteId'],_0x3b679b=jt(_0x53b15d),_0x166499=hs(_0x4baa25,_0x32625e,_0x3b679b);_0xbf756b['currentOutputSnapshotRaw']=_0x4baa25,_0xbf756b['currentOutputSnapshotResolved']=_0x166499,_0xbf756b['currentWriteId']=Vn(_0x53b15d),_0x123f2d['splice'](_0x123f2d['indexOf'](_0x22425e),0x1),_0x2d9149=_0x2d9149['concat'](ss(_0x53b15d['serverSyncTree_'],_0xbf756b['path'],_0x166499,_0xbf756b['currentWriteId'],_0xbf756b['applyLocally'])),_0x2d9149=_0x2d9149['concat'](pe(_0x53b15d['serverSyncTree_'],_0x22425e,!0x0));}else _0x310130=!0x0,_0x46a172='nodata',_0x2d9149=_0x2d9149['concat'](pe(_0x53b15d['serverSyncTree_'],_0xbf756b['currentWriteId'],!0x0));}}}V(_0x53b15d['eventQueue_'],_0x4d1bd8,_0x2d9149),_0x2d9149=[],_0x310130&&(_0x159b1f[_0x42b6dc]['status']=0x2,function(_0x2bd56d){setTimeout(_0x2bd56d,Math['floor'](0x0));}(_0x159b1f[_0x42b6dc]['unwatcher']),_0x159b1f[_0x42b6dc]['onComplete']&&(_0x46a172==='nodata'?_0x1d1a63['push'](()=>_0x159b1f[_0x42b6dc]['onComplete'](null,!0x1,_0x159b1f[_0x42b6dc]['currentInputSnapshot'])):_0x1d1a63['push'](()=>_0x159b1f[_0x42b6dc]['onComplete'](new Error(_0x46a172),!0x1,null))));}$n(_0x53b15d,_0x53b15d['transactionQueueTree_']);for(let _0x4e5f7f=0x0;_0x4e5f7f<_0x1d1a63['length'];_0x4e5f7f++)lt(_0x1d1a63[_0x4e5f7f]);Hn(_0x53b15d,_0x53b15d['transactionQueueTree_']);}function ca(_0x20c5eb,_0x1df4a2){let _0x54c1ee,_0x15e025=_0x20c5eb['transactionQueueTree_'];for(_0x54c1ee=y(_0x1df4a2);_0x54c1ee!==null&&Ge(_0x15e025)===void 0x0;)_0x15e025=Un(_0x15e025,_0x54c1ee),_0x1df4a2=b(_0x1df4a2),_0x54c1ee=y(_0x1df4a2);return _0x15e025;}function la(_0x1248f6,_0x1802bc){const _0x444453=[];return ha(_0x1248f6,_0x1802bc,_0x444453),_0x444453['sort']((_0x2125e8,_0x3ef11c)=>_0x2125e8['order']-_0x3ef11c['order']),_0x444453;}function ha(_0x49c146,_0x4d2f92,_0x2e6dc5){const _0x5c9b21=Ge(_0x4d2f92);if(_0x5c9b21){for(let _0x390c5e=0x0;_0x390c5e<_0x5c9b21['length'];_0x390c5e++)_0x2e6dc5['push'](_0x5c9b21[_0x390c5e]);}Wn(_0x4d2f92,_0x1a896c=>{ha(_0x49c146,_0x1a896c,_0x2e6dc5);});}function $n(_0x2ec59c,_0x21a41a){const _0x10ac95=Ge(_0x21a41a);if(_0x10ac95){let _0x427edd=0x0;for(let _0x293c7e=0x0;_0x293c7e<_0x10ac95['length'];_0x293c7e++)_0x10ac95[_0x293c7e]['status']!==0x2&&(_0x10ac95[_0x427edd]=_0x10ac95[_0x293c7e],_0x427edd++);_0x10ac95['length']=_0x427edd,fs(_0x21a41a,_0x10ac95['length']>0x0?_0x10ac95:void 0x0);}Wn(_0x21a41a,_0x5a93ef=>{$n(_0x2ec59c,_0x5a93ef);});}function vs(_0xf4c809,_0x2d905f){const _0x369086=Gt(ca(_0xf4c809,_0x2d905f)),_0xec3d11=Un(_0xf4c809['transactionQueueTree_'],_0x2d905f);return sd(_0xec3d11,_0x5a9d39=>{ai(_0xf4c809,_0x5a9d39);}),ai(_0xf4c809,_0xec3d11),ta(_0xec3d11,_0x58900e=>{ai(_0xf4c809,_0x58900e);}),_0x369086;}function ai(_0x50b763,_0x5a29f7){const _0x28a809=Ge(_0x5a29f7);if(_0x28a809){const _0x51aa17=[];let _0x123a8c=[],_0x2e1f94=-0x1;for(let _0x10f6f2=0x0;_0x10f6f2<_0x28a809['length'];_0x10f6f2++)_0x28a809[_0x10f6f2]['status']===0x3||(_0x28a809[_0x10f6f2]['status']===0x1?(f(_0x2e1f94===_0x10f6f2-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2e1f94=_0x10f6f2,_0x28a809[_0x10f6f2]['status']=0x3,_0x28a809[_0x10f6f2]['abortReason']='set'):(f(_0x28a809[_0x10f6f2]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x28a809[_0x10f6f2]['unwatcher'](),_0x123a8c=_0x123a8c['concat'](pe(_0x50b763['serverSyncTree_'],_0x28a809[_0x10f6f2]['currentWriteId'],!0x0)),_0x28a809[_0x10f6f2]['onComplete']&&_0x51aa17['push'](_0x28a809[_0x10f6f2]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2e1f94===-0x1?fs(_0x5a29f7,void 0x0):_0x28a809['length']=_0x2e1f94+0x1,V(_0x50b763['eventQueue_'],Gt(_0x5a29f7),_0x123a8c);for(let _0x28479a=0x0;_0x28479a<_0x51aa17['length'];_0x28479a++)lt(_0x51aa17[_0x28479a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5b176b){let _0x4056fc='';const _0x5c85e1=_0x5b176b['split']('/');for(let _0x565477=0x0;_0x565477<_0x5c85e1['length'];_0x565477++)if(_0x5c85e1[_0x565477]['length']>0x0){let _0x1688db=_0x5c85e1[_0x565477];try{_0x1688db=decodeURIComponent(_0x1688db['replace'](/\+/g,'\x20'));}catch{}_0x4056fc+='/'+_0x1688db;}return _0x4056fc;}function Nd(_0x5fc68a){const _0x58a794={};_0x5fc68a['charAt'](0x0)==='?'&&(_0x5fc68a=_0x5fc68a['substring'](0x1));for(const _0x526238 of _0x5fc68a['split']('&')){if(_0x526238['length']===0x0)continue;const _0x13c126=_0x526238['split']('=');_0x13c126['length']===0x2?_0x58a794[decodeURIComponent(_0x13c126[0x0])]=decodeURIComponent(_0x13c126[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x526238+'\x27\x20in\x20query\x20\x27'+_0x5fc68a+'\x27');}return _0x58a794;}const gr=function(_0x1f3ca5,_0x391ec0){const _0x32afc6=Pd(_0x1f3ca5),_0x4ed6ac=_0x32afc6['namespace'];_0x32afc6['domain']==='firebase.com'&&oe(_0x32afc6['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4ed6ac||_0x4ed6ac==='undefined')&&_0x32afc6['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x32afc6['secure']||Bl();const _0xe31019=_0x32afc6['scheme']==='ws'||_0x32afc6['scheme']==='wss';return{'repoInfo':new _o(_0x32afc6['host'],_0x32afc6['secure'],_0x4ed6ac,_0xe31019,_0x391ec0,'',_0x4ed6ac!==_0x32afc6['subdomain']),'path':new C(_0x32afc6['pathString'])};},Pd=function(_0x8ce517){let _0xa10be2='',_0x42df5b='',_0xa233af='',_0x5283ee='',_0x559d11='',_0x2d0e7a=!0x0,_0x265f2f='https',_0x5d90f2=0x1bb;if(typeof _0x8ce517=='string'){let _0x16d531=_0x8ce517['indexOf']('//');_0x16d531>=0x0&&(_0x265f2f=_0x8ce517['substring'](0x0,_0x16d531-0x1),_0x8ce517=_0x8ce517['substring'](_0x16d531+0x2));let _0x1e403f=_0x8ce517['indexOf']('/');_0x1e403f===-0x1&&(_0x1e403f=_0x8ce517['length']);let _0x59d750=_0x8ce517['indexOf']('?');_0x59d750===-0x1&&(_0x59d750=_0x8ce517['length']),_0xa10be2=_0x8ce517['substring'](0x0,Math['min'](_0x1e403f,_0x59d750)),_0x1e403f<_0x59d750&&(_0x5283ee=kd(_0x8ce517['substring'](_0x1e403f,_0x59d750)));const _0x58b743=Nd(_0x8ce517['substring'](Math['min'](_0x8ce517['length'],_0x59d750)));_0x16d531=_0xa10be2['indexOf'](':'),_0x16d531>=0x0?(_0x2d0e7a=_0x265f2f==='https'||_0x265f2f==='wss',_0x5d90f2=parseInt(_0xa10be2['substring'](_0x16d531+0x1),0xa)):_0x16d531=_0xa10be2['length'];const _0x5ad5be=_0xa10be2['slice'](0x0,_0x16d531);if(_0x5ad5be['toLowerCase']()==='localhost')_0x42df5b='localhost';else{if(_0x5ad5be['split']('.')['length']<=0x2)_0x42df5b=_0x5ad5be;else{const _0x4bd7b6=_0xa10be2['indexOf']('.');_0xa233af=_0xa10be2['substring'](0x0,_0x4bd7b6)['toLowerCase'](),_0x42df5b=_0xa10be2['substring'](_0x4bd7b6+0x1),_0x559d11=_0xa233af;}}'ns'in _0x58b743&&(_0x559d11=_0x58b743['ns']);}return{'host':_0xa10be2,'port':_0x5d90f2,'domain':_0x42df5b,'subdomain':_0xa233af,'secure':_0x2d0e7a,'scheme':_0x265f2f,'pathString':_0x5283ee,'namespace':_0x559d11};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x2d4ec3=0x0;const _0x2ec0d0=[];return function(_0x35e389){const _0x10524c=_0x35e389===_0x2d4ec3;_0x2d4ec3=_0x35e389;let _0x2bafd7;const _0x5adb88=new Array(0x8);for(_0x2bafd7=0x7;_0x2bafd7>=0x0;_0x2bafd7--)_0x5adb88[_0x2bafd7]=mr['charAt'](_0x35e389%0x40),_0x35e389=Math['floor'](_0x35e389/0x40);f(_0x35e389===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x395f8e=_0x5adb88['join']('');if(_0x10524c){for(_0x2bafd7=0xb;_0x2bafd7>=0x0&&_0x2ec0d0[_0x2bafd7]===0x3f;_0x2bafd7--)_0x2ec0d0[_0x2bafd7]=0x0;_0x2ec0d0[_0x2bafd7]++;}else{for(_0x2bafd7=0x0;_0x2bafd7<0xc;_0x2bafd7++)_0x2ec0d0[_0x2bafd7]=Math['floor'](Math['random']()*0x40);}for(_0x2bafd7=0x0;_0x2bafd7<0xc;_0x2bafd7++)_0x395f8e+=mr['charAt'](_0x2ec0d0[_0x2bafd7]);return f(_0x395f8e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x395f8e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2f024f,_0x19b589,_0x3f389a,_0xc08538){this['eventType']=_0x2f024f,this['eventRegistration']=_0x19b589,this['snapshot']=_0x3f389a,this['prevName']=_0xc08538;}['getPath'](){const _0x347f10=this['snapshot']['ref'];return this['eventType']==='value'?_0x347f10['_path']:_0x347f10['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1438eb,_0x37cfd8,_0x2ff541){this['eventRegistration']=_0x1438eb,this['error']=_0x37cfd8,this['path']=_0x2ff541;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0xd741a3,_0x461b15){this['snapshotCallback']=_0xd741a3,this['cancelCallback']=_0x461b15;}['onValue'](_0x1314ed,_0xd30ef3){this['snapshotCallback']['call'](null,_0x1314ed,_0xd30ef3);}['onCancel'](_0x36cad0){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x36cad0);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3e9228){return this['snapshotCallback']===_0x3e9228['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3e9228['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3e9228['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x25d90c,_0x1036f4,_0x5dbc7d,_0x27d102){this['_repo']=_0x25d90c,this['_path']=_0x1036f4,this['_queryParams']=_0x5dbc7d,this['_orderByCalled']=_0x27d102;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xaa206c=nr(this['_queryParams']),_0x2bc612=Bi(_0xaa206c);return _0x2bc612==='{}'?'default':_0x2bc612;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x22d547){if(_0x22d547=k(_0x22d547),!(_0x22d547 instanceof be))return!0x1;const _0x47820d=this['_repo']===_0x22d547['_repo'],_0x1bed65=qi(this['_path'],_0x22d547['_path']),_0x477d53=this['_queryIdentifier']===_0x22d547['_queryIdentifier'];return _0x47820d&&_0x1bed65&&_0x477d53;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x2167ce,_0x15497b){if(_0x2167ce['_orderByCalled']===!0x0)throw new Error(_0x15497b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x2a77bf){let _0x52cda0=null,_0x4419b1=null;if(_0x2a77bf['hasStart']()&&(_0x52cda0=_0x2a77bf['getIndexStartValue']()),_0x2a77bf['hasEnd']()&&(_0x4419b1=_0x2a77bf['getIndexEndValue']()),_0x2a77bf['getIndex']()===ye){const _0x23cb93='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5ceb8b='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2a77bf['hasStart']()){if(_0x2a77bf['getIndexStartName']()!==xe)throw new Error(_0x23cb93);if(typeof _0x52cda0!='string')throw new Error(_0x5ceb8b);}if(_0x2a77bf['hasEnd']()){if(_0x2a77bf['getIndexEndName']()!==Ie)throw new Error(_0x23cb93);if(typeof _0x4419b1!='string')throw new Error(_0x5ceb8b);}}else{if(_0x2a77bf['getIndex']()===R){if(_0x52cda0!=null&&!Cn(_0x52cda0)||_0x4419b1!=null&&!Cn(_0x4419b1))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2a77bf['getIndex']()instanceof Ki||_0x2a77bf['getIndex']()===Po,'unknown\x20index\x20type.'),_0x52cda0!=null&&typeof _0x52cda0=='object'||_0x4419b1!=null&&typeof _0x4419b1=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x261d08){if(_0x261d08['hasStart']()&&_0x261d08['hasEnd']()&&_0x261d08['hasLimit']()&&!_0x261d08['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x1e33e7,_0x19b1a6){super(_0x1e33e7,_0x19b1a6,new Qi(),!0x1);}get['parent'](){const _0xf4653b=To(this['_path']);return _0xf4653b===null?null:new Z(this['_repo'],_0xf4653b);}get['root'](){let _0x4ac70b=this;for(;_0x4ac70b['parent']!==null;)_0x4ac70b=_0x4ac70b['parent'];return _0x4ac70b;}}class rt{constructor(_0x5724bd,_0x5df49d,_0x10b5bc){this['_node']=_0x5724bd,this['ref']=_0x5df49d,this['_index']=_0x10b5bc;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x535a3e){const _0x21b3fb=new C(_0x535a3e),_0x4e945f=Lt(this['ref'],_0x535a3e);return new rt(this['_node']['getChild'](_0x21b3fb),_0x4e945f,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x135965){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xabdc34,_0x5315e0)=>_0x135965(new rt(_0x5315e0,Lt(this['ref'],_0xabdc34),R)));}['hasChild'](_0x2c6225){const _0x223a30=new C(_0x2c6225);return!this['_node']['getChild'](_0x223a30)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0xb1642e,_0x4b10cb){return _0xb1642e=k(_0xb1642e),_0xb1642e['_checkNotDeleted']('ref'),_0x4b10cb!==void 0x0?Lt(_0xb1642e['_root'],_0x4b10cb):_0xb1642e['_root'];}function Lt(_0x19a6df,_0x3c40c3){return _0x19a6df=k(_0x19a6df),y(_0x19a6df['_path'])===null?ud('child','path',_0x3c40c3):_s('child','path',_0x3c40c3),new Z(_0x19a6df['_repo'],A(_0x19a6df['_path'],_0x3c40c3));}function d_(_0x33ecf3,_0x5789f5){_0x33ecf3=k(_0x33ecf3),gs('push',_0x33ecf3['_path']),qt('push',_0x5789f5,_0x33ecf3['_path'],!0x0);const _0x4ae4d8=oa(_0x33ecf3['_repo']),_0x183106=Od(_0x4ae4d8),_0x5514ea=Lt(_0x33ecf3,_0x183106),_0x2896af=Lt(_0x33ecf3,_0x183106);let _0x594dba;return _0x5789f5!=null?_0x594dba=Ld(_0x2896af,_0x5789f5)['then'](()=>_0x2896af):_0x594dba=Promise['resolve'](_0x2896af),_0x5514ea['then']=_0x594dba['then']['bind'](_0x594dba),_0x5514ea['catch']=_0x594dba['then']['bind'](_0x594dba,void 0x0),_0x5514ea;}function Ld(_0x2b3482,_0x42dbe2){_0x2b3482=k(_0x2b3482),gs('set',_0x2b3482['_path']),qt('set',_0x42dbe2,_0x2b3482['_path'],!0x1);const _0x1322b1=new Ve();return Ed(_0x2b3482['_repo'],_0x2b3482['_path'],_0x42dbe2,null,_0x1322b1['wrapCallback'](()=>{})),_0x1322b1['promise'];}function f_(_0x1c8f57,_0x4fe1f5){hd('update',_0x4fe1f5,_0x1c8f57['_path']);const _0x2ea175=new Ve();return Id(_0x1c8f57['_repo'],_0x1c8f57['_path'],_0x4fe1f5,_0x2ea175['wrapCallback'](()=>{})),_0x2ea175['promise'];}function p_(_0x476691){_0x476691=k(_0x476691);const _0x170f31=new ua(()=>{}),_0x33adff=new qn(_0x170f31);return vd(_0x476691['_repo'],_0x476691,_0x33adff)['then'](_0x38ec7b=>new rt(_0x38ec7b,new Z(_0x476691['_repo'],_0x476691['_path']),_0x476691['_queryParams']['getIndex']()));}class qn{constructor(_0x1e0eee){this['callbackContext']=_0x1e0eee;}['respondsTo'](_0x3ae792){return _0x3ae792==='value';}['createEvent'](_0x16b9e9,_0x1dd776){const _0x180bcb=_0x1dd776['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x16b9e9['snapshotNode'],new Z(_0x1dd776['_repo'],_0x1dd776['_path']),_0x180bcb));}['getEventRunner'](_0x1b9e53){return _0x1b9e53['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1b9e53['error']):()=>this['callbackContext']['onValue'](_0x1b9e53['snapshot'],null);}['createCancelEvent'](_0x310e08,_0xfddab1){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x310e08,_0xfddab1):null;}['matches'](_0x200f5c){return _0x200f5c instanceof qn?!_0x200f5c['callbackContext']||!this['callbackContext']?!0x0:_0x200f5c['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x31002b,_0x130918,_0x3ba534,_0x389770,_0x5527b0){const _0x42e816=new ua(_0x3ba534,void 0x0),_0x4c2e40=new qn(_0x42e816);return Cd(_0x31002b['_repo'],_0x31002b,_0x4c2e40),()=>Td(_0x31002b['_repo'],_0x31002b,_0x4c2e40);}function Fd(_0x44e225,_0x441030,_0x1b7748,_0x4eb6a5){return xd(_0x44e225,'value',_0x441030);}class dt{}class pa extends dt{constructor(_0x202949,_0x4e8153){super(),this['_value']=_0x202949,this['_key']=_0x4e8153,this['type']='endAt';}['_apply'](_0x43c521){qt('endAt',this['_value'],_0x43c521['_path'],!0x0);const _0x101779=Kh(_0x43c521['_queryParams'],this['_value'],this['_key']);if(fa(_0x101779),Gn(_0x101779),_0x43c521['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x43c521['_repo'],_0x43c521['_path'],_0x101779,_0x43c521['_orderByCalled']);}}function __(_0x2e17cb,_0x515c09){return new pa(_0x2e17cb,_0x515c09);}class _a extends dt{constructor(_0x2f1fa4,_0x24e425){super(),this['_value']=_0x2f1fa4,this['_key']=_0x24e425,this['type']='startAt';}['_apply'](_0xc4202e){qt('startAt',this['_value'],_0xc4202e['_path'],!0x0);const _0xee25dc=jh(_0xc4202e['_queryParams'],this['_value'],this['_key']);if(fa(_0xee25dc),Gn(_0xee25dc),_0xc4202e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0xc4202e['_repo'],_0xc4202e['_path'],_0xee25dc,_0xc4202e['_orderByCalled']);}}function g_(_0x5daa90=null,_0x26133c){return new _a(_0x5daa90,_0x26133c);}class Ud extends dt{constructor(_0x1015f0){super(),this['_limit']=_0x1015f0,this['type']='limitToFirst';}['_apply'](_0x1daacb){if(_0x1daacb['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1daacb['_repo'],_0x1daacb['_path'],zh(_0x1daacb['_queryParams'],this['_limit']),_0x1daacb['_orderByCalled']);}}function m_(_0xa7a5a2){if(Math['floor'](_0xa7a5a2)!==_0xa7a5a2||_0xa7a5a2<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0xa7a5a2);}class Wd extends dt{constructor(_0x278562){super(),this['_path']=_0x278562,this['type']='orderByChild';}['_apply'](_0x2e05c8){da(_0x2e05c8,'orderByChild');const _0xbd6a9a=new C(this['_path']);if(v(_0xbd6a9a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x19ea6b=new Ki(_0xbd6a9a),_0x5a2996=Do(_0x2e05c8['_queryParams'],_0x19ea6b);return Gn(_0x5a2996),new be(_0x2e05c8['_repo'],_0x2e05c8['_path'],_0x5a2996,!0x0);}}function y_(_0x12035a){if(_0x12035a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x12035a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x12035a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x12035a),new Wd(_0x12035a);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1fe3ec){da(_0x1fe3ec,'orderByKey');const _0x2d1f31=Do(_0x1fe3ec['_queryParams'],ye);return Gn(_0x2d1f31),new be(_0x1fe3ec['_repo'],_0x1fe3ec['_path'],_0x2d1f31,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x14d0f5,_0x4a9b09){super(),this['_value']=_0x14d0f5,this['_key']=_0x4a9b09,this['type']='equalTo';}['_apply'](_0x473121){if(qt('equalTo',this['_value'],_0x473121['_path'],!0x1),_0x473121['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x473121['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x473121));}}function E_(_0x1392f9,_0x164074){return new Vd(_0x1392f9,_0x164074);}function I_(_0x2f709a,..._0x286705){let _0x2ad676=k(_0x2f709a);for(const _0x202bed of _0x286705)_0x2ad676=_0x202bed['_apply'](_0x2ad676);return _0x2ad676;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x26f947,_0x17b916,_0x3f65e2,_0xef7b33){const _0xb24d3d=_0x17b916['lastIndexOf'](':'),_0x318972=_0x17b916['substring'](0x0,_0xb24d3d),_0x1fe8f4=Wt(_0x318972);_0x26f947['repoInfo_']=new _o(_0x17b916,_0x1fe8f4,_0x26f947['repoInfo_']['namespace'],_0x26f947['repoInfo_']['webSocketOnly'],_0x26f947['repoInfo_']['nodeAdmin'],_0x26f947['repoInfo_']['persistenceKey'],_0x26f947['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3f65e2),_0xef7b33&&(_0x26f947['authTokenProvider_']=_0xef7b33);}function qd(_0x293c5c,_0x5c0a1d,_0x4c2734,_0x968309,_0x404c25){let _0x45f034=_0x968309||_0x293c5c['options']['databaseURL'];_0x45f034===void 0x0&&(_0x293c5c['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x293c5c['options']['projectId']),_0x45f034=_0x293c5c['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x40075f=gr(_0x45f034,_0x404c25),_0x56b3f0=_0x40075f['repoInfo'],_0x1535e1;typeof process<'u'&&Us&&(_0x1535e1=Us[Hd]),_0x1535e1?(_0x45f034='http://'+_0x1535e1+'?ns='+_0x56b3f0['namespace'],_0x40075f=gr(_0x45f034,_0x404c25),_0x56b3f0=_0x40075f['repoInfo']):_0x40075f['repoInfo']['secure'];const _0x200a47=new Jl(_0x293c5c['name'],_0x293c5c['options'],_0x5c0a1d);dd('Invalid\x20Firebase\x20Database\x20URL',_0x40075f),v(_0x40075f['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x51e71e=jd(_0x56b3f0,_0x293c5c,_0x200a47,new Ql(_0x293c5c,_0x4c2734));return new Kd(_0x51e71e,_0x293c5c);}function zd(_0x5f0f8c,_0x4bc71f){const _0x48ed88=ki[_0x4bc71f];(!_0x48ed88||_0x48ed88[_0x5f0f8c['key']]!==_0x5f0f8c)&&oe('Database\x20'+_0x4bc71f+'('+_0x5f0f8c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5f0f8c),delete _0x48ed88[_0x5f0f8c['key']];}function jd(_0x1c90c1,_0x5ba428,_0x1c13b0,_0x3c0ded){let _0xe1bc0e=ki[_0x5ba428['name']];_0xe1bc0e||(_0xe1bc0e={},ki[_0x5ba428['name']]=_0xe1bc0e);let _0x256af0=_0xe1bc0e[_0x1c90c1['toURLString']()];return _0x256af0&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x256af0=new gd(_0x1c90c1,$d,_0x1c13b0,_0x3c0ded),_0xe1bc0e[_0x1c90c1['toURLString']()]=_0x256af0,_0x256af0;}class Kd{constructor(_0x3cf61a,_0xad6ae0){this['_repoInternal']=_0x3cf61a,this['app']=_0xad6ae0,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1e4ebe){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1e4ebe+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0xd8654=Qr(),_0x1aaa96){const _0x292b7a=Ui(_0xd8654,'database')['getImmediate']({'identifier':_0x1aaa96});if(!_0x292b7a['_instanceStarted']){const _0x30e66f=ac('database');_0x30e66f&&Yd(_0x292b7a,..._0x30e66f);}return _0x292b7a;}function Yd(_0x239d09,_0x31f6c8,_0x49fd4d,_0x544d98={}){_0x239d09=k(_0x239d09),_0x239d09['_checkNotDeleted']('useEmulator');const _0x2224ce=_0x31f6c8+':'+_0x49fd4d,_0x1f81d4=_0x239d09['_repoInternal'];if(_0x239d09['_instanceStarted']){if(_0x2224ce===_0x239d09['_repoInternal']['repoInfo_']['host']&&De(_0x544d98,_0x1f81d4['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3f9447;if(_0x1f81d4['repoInfo_']['nodeAdmin'])_0x544d98['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3f9447=new tn(tn['OWNER']);else{if(_0x544d98['mockUserToken']){const _0x56a4e7=typeof _0x544d98['mockUserToken']=='string'?_0x544d98['mockUserToken']:cc(_0x544d98['mockUserToken'],_0x239d09['app']['options']['projectId']);_0x3f9447=new tn(_0x56a4e7);}}Wt(_0x31f6c8)&&jr(_0x31f6c8),Gd(_0x1f81d4,_0x2224ce,_0x544d98,_0x3f9447);}function C_(_0x551482){_0x551482=k(_0x551482),_0x551482['_checkNotDeleted']('goOffline'),aa(_0x551482['_repo']);}function T_(_0x2208bc){_0x2208bc=k(_0x2208bc),_0x2208bc['_checkNotDeleted']('goOnline'),Sd(_0x2208bc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x2862ce){Ll(ct),et(new Me('database',(_0x435efb,{instanceIdentifier:_0x34c385})=>{const _0x342029=_0x435efb['getProvider']('app')['getImmediate'](),_0x5a1e88=_0x435efb['getProvider']('auth-internal'),_0x59a5de=_0x435efb['getProvider']('app-check-internal');return qd(_0x342029,_0x5a1e88,_0x59a5de,_0x34c385);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x2862ce),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x5da14b,_0x3a0007){this['committed']=_0x5da14b,this['snapshot']=_0x3a0007;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0xb00e79,_0x1aa610,_0x18ebe3){if(_0xb00e79=k(_0xb00e79),gs('Reference.transaction',_0xb00e79['_path']),_0xb00e79['key']==='.length'||_0xb00e79['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xb00e79['key']+'\x20is\x20a\x20read-only\x20object.';const _0xf0b517=!0x0,_0x51c554=new Ve(),_0x16e5b7=(_0x4bded4,_0x5f411a,_0x40e27a)=>{let _0x1494d0=null;_0x4bded4?_0x51c554['reject'](_0x4bded4):(_0x1494d0=new rt(_0x40e27a,new Z(_0xb00e79['_repo'],_0xb00e79['_path']),R),_0x51c554['resolve'](new Xd(_0x5f411a,_0x1494d0)));},_0x5d7109=Fd(_0xb00e79,()=>{});return bd(_0xb00e79['_repo'],_0xb00e79['_path'],_0x1aa610,_0x16e5b7,_0x5d7109,_0xf0b517),_0x51c554['promise'];}ie['prototype']['simpleListen']=function(_0x319e81,_0x11804b){this['sendRequest']('q',{'p':_0x319e81},_0x11804b);},ie['prototype']['echo']=function(_0x201f87,_0x37510f){this['sendRequest']('echo',{'d':_0x201f87},_0x37510f);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1aae24,..._0x370659){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1aae24,..._0x370659);}function nn(_0x754281,..._0x409b26){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x754281,..._0x409b26);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0xf879ea,..._0x111919){throw Es(_0xf879ea,..._0x111919);}function J(_0x4c7cc3,..._0x12e9e7){return Es(_0x4c7cc3,..._0x12e9e7);}function ya(_0x10ab38,_0x1f7d02,_0x2a6e3d){const _0x1527d4={...Zd(),[_0x1f7d02]:_0x2a6e3d};return new Ut('auth','Firebase',_0x1527d4)['create'](_0x1f7d02,{'appName':_0x10ab38['name']});}function se(_0x435407){return ya(_0x435407,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x2d220c,..._0x4e1c24){if(typeof _0x2d220c!='string'){const _0x5b0395=_0x4e1c24[0x0],_0x304940=[..._0x4e1c24['slice'](0x1)];return _0x304940[0x0]&&(_0x304940[0x0]['appName']=_0x2d220c['name']),_0x2d220c['_errorFactory']['create'](_0x5b0395,..._0x304940);}return ma['create'](_0x2d220c,..._0x4e1c24);}function m(_0x40d5ab,_0xae199,..._0x432ab7){if(!_0x40d5ab)throw Es(_0xae199,..._0x432ab7);}function te(_0x3ab825){const _0xf3eca5='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3ab825;throw nn(_0xf3eca5),new Error(_0xf3eca5);}function ae(_0x72f8f5,_0x395950){_0x72f8f5||te(_0x395950);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x105fcc;return typeof self<'u'&&((_0x105fcc=self['location'])==null?void 0x0:_0x105fcc['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x104d15;return typeof self<'u'&&((_0x104d15=self['location'])==null?void 0x0:_0x104d15['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x359acc=navigator;return _0x359acc['languages']&&_0x359acc['languages'][0x0]||_0x359acc['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xab1164,_0xbb8f5f){this['shortDelay']=_0xab1164,this['longDelay']=_0xbb8f5f,ae(_0xbb8f5f>_0xab1164,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x79d279,_0xeb33d9){ae(_0x79d279['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2ede1c}=_0x79d279['emulator'];return _0xeb33d9?''+_0x2ede1c+(_0xeb33d9['startsWith']('/')?_0xeb33d9['slice'](0x1):_0xeb33d9):_0x2ede1c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5b6014,_0xdc5415,_0x27556e){this['fetchImpl']=_0x5b6014,_0xdc5415&&(this['headersImpl']=_0xdc5415),_0x27556e&&(this['responseImpl']=_0x27556e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x2da9cb,_0x3c2455){return _0x2da9cb['tenantId']&&!_0x3c2455['tenantId']?{..._0x3c2455,'tenantId':_0x2da9cb['tenantId']}:_0x3c2455;}async function Ae(_0x44e2f2,_0x13ea2e,_0x52ef44,_0x2de180,_0x551d88={}){return Ea(_0x44e2f2,_0x551d88,async()=>{let _0x1528c1={},_0x5a0451={};_0x2de180&&(_0x13ea2e==='GET'?_0x5a0451=_0x2de180:_0x1528c1={'body':JSON['stringify'](_0x2de180)});const _0x55b44c=at({..._0x5a0451,'key':_0x44e2f2['config']['apiKey']})['slice'](0x1),_0x389e33=await _0x44e2f2['_getAdditionalHeaders']();_0x389e33['Content-Type']='application/json',_0x44e2f2['languageCode']&&(_0x389e33['X-Firebase-Locale']=_0x44e2f2['languageCode']);const _0x14b013={'method':_0x13ea2e,'headers':_0x389e33,..._0x1528c1};return lc()||(_0x14b013['referrerPolicy']='strict-origin-when-cross-origin'),_0x44e2f2['emulatorConfig']&&Wt(_0x44e2f2['emulatorConfig']['host'])&&(_0x14b013['credentials']='include'),va['fetch']()(await Ia(_0x44e2f2,_0x44e2f2['config']['apiHost'],_0x52ef44,_0x55b44c),_0x14b013);});}async function Ea(_0x3e201a,_0x47667e,_0x39c9e2){_0x3e201a['_canInitEmulator']=!0x1;const _0x165fdd={...rf,..._0x47667e};try{const _0x1c2f35=new lf(_0x3e201a),_0x1eb0dd=await Promise['race']([_0x39c9e2(),_0x1c2f35['promise']]);_0x1c2f35['clearNetworkTimeout']();const _0x505dd3=await _0x1eb0dd['json']();if('needConfirmation'in _0x505dd3)throw en(_0x3e201a,'account-exists-with-different-credential',_0x505dd3);if(_0x1eb0dd['ok']&&!('errorMessage'in _0x505dd3))return _0x505dd3;{const _0x25c275=_0x1eb0dd['ok']?_0x505dd3['errorMessage']:_0x505dd3['error']['message'],[_0x2240ab,_0x215cb8]=_0x25c275['split']('\x20:\x20');if(_0x2240ab==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x3e201a,'credential-already-in-use',_0x505dd3);if(_0x2240ab==='EMAIL_EXISTS')throw en(_0x3e201a,'email-already-in-use',_0x505dd3);if(_0x2240ab==='USER_DISABLED')throw en(_0x3e201a,'user-disabled',_0x505dd3);const _0x61eb5=_0x165fdd[_0x2240ab]||_0x2240ab['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x215cb8)throw ya(_0x3e201a,_0x61eb5,_0x215cb8);K(_0x3e201a,_0x61eb5);}}catch(_0x5b8f9b){if(_0x5b8f9b instanceof Se)throw _0x5b8f9b;K(_0x3e201a,'network-request-failed',{'message':String(_0x5b8f9b)});}}async function Yt(_0xb99c98,_0x35896f,_0x15c9df,_0x3ad827,_0x5381be={}){const _0x4a77a4=await Ae(_0xb99c98,_0x35896f,_0x15c9df,_0x3ad827,_0x5381be);return'mfaPendingCredential'in _0x4a77a4&&K(_0xb99c98,'multi-factor-auth-required',{'_serverResponse':_0x4a77a4}),_0x4a77a4;}async function Ia(_0x29510a,_0x3d6f31,_0x1f916f,_0x13b626){const _0x5eee51=''+_0x3d6f31+_0x1f916f+'?'+_0x13b626,_0x165e7e=_0x29510a,_0x231bc2=_0x165e7e['config']['emulator']?Is(_0x29510a['config'],_0x5eee51):_0x29510a['config']['apiScheme']+'://'+_0x5eee51;return of['includes'](_0x1f916f)&&(await _0x165e7e['_persistenceManagerAvailable'],_0x165e7e['_getPersistenceType']()==='COOKIE')?_0x165e7e['_getPersistence']()['_getFinalTarget'](_0x231bc2)['toString']():_0x231bc2;}function cf(_0x5e9be2){switch(_0x5e9be2){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x21fb08){this['auth']=_0x21fb08,this['timer']=null,this['promise']=new Promise((_0x4a13b3,_0x365126)=>{this['timer']=setTimeout(()=>_0x365126(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x464008,_0x5244a7,_0x50495a){const _0x52e22c={'appName':_0x464008['name']};_0x50495a['email']&&(_0x52e22c['email']=_0x50495a['email']),_0x50495a['phoneNumber']&&(_0x52e22c['phoneNumber']=_0x50495a['phoneNumber']);const _0x2dcec0=J(_0x464008,_0x5244a7,_0x52e22c);return _0x2dcec0['customData']['_tokenResponse']=_0x50495a,_0x2dcec0;}function vr(_0x3573a1){return _0x3573a1!==void 0x0&&_0x3573a1['enterprise']!==void 0x0;}class hf{constructor(_0x34a98e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x34a98e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x34a98e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x34a98e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2b5503){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x54ca6a of this['recaptchaEnforcementState'])if(_0x54ca6a['provider']&&_0x54ca6a['provider']===_0x2b5503)return cf(_0x54ca6a['enforcementState']);return null;}['isProviderEnabled'](_0xd2421c){return this['getProviderEnforcementState'](_0xd2421c)==='ENFORCE'||this['getProviderEnforcementState'](_0xd2421c)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x22cea8,_0x163f05){return Ae(_0x22cea8,'GET','/v2/recaptchaConfig',Re(_0x22cea8,_0x163f05));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x3df902,_0x474221){return Ae(_0x3df902,'POST','/v1/accounts:delete',_0x474221);}async function Sn(_0x473161,_0x57e999){return Ae(_0x473161,'POST','/v1/accounts:lookup',_0x57e999);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x192c13){if(_0x192c13)try{const _0x8e32d1=new Date(Number(_0x192c13));if(!isNaN(_0x8e32d1['getTime']()))return _0x8e32d1['toUTCString']();}catch{}}async function ff(_0x3aa350,_0x86985e=!0x1){const _0x491694=k(_0x3aa350),_0x57587f=await _0x491694['getIdToken'](_0x86985e),_0x1477e5=ws(_0x57587f);m(_0x1477e5&&_0x1477e5['exp']&&_0x1477e5['auth_time']&&_0x1477e5['iat'],_0x491694['auth'],'internal-error');const _0x456528=typeof _0x1477e5['firebase']=='object'?_0x1477e5['firebase']:void 0x0,_0x50982f=_0x456528==null?void 0x0:_0x456528['sign_in_provider'];return{'claims':_0x1477e5,'token':_0x57587f,'authTime':St(ci(_0x1477e5['auth_time'])),'issuedAtTime':St(ci(_0x1477e5['iat'])),'expirationTime':St(ci(_0x1477e5['exp'])),'signInProvider':_0x50982f||null,'signInSecondFactor':(_0x456528==null?void 0x0:_0x456528['sign_in_second_factor'])||null};}function ci(_0x5f3c10){return Number(_0x5f3c10)*0x3e8;}function ws(_0x4f774d){const [_0x47b7ea,_0x41901a,_0x400193]=_0x4f774d['split']('.');if(_0x47b7ea===void 0x0||_0x41901a===void 0x0||_0x400193===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x40c8c7=cn(_0x41901a);return _0x40c8c7?JSON['parse'](_0x40c8c7):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4f7c4a){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4f7c4a==null?void 0x0:_0x4f7c4a['toString']()),null;}}function Er(_0x5d2c64){const _0x50c0e4=ws(_0x5d2c64);return m(_0x50c0e4,'internal-error'),m(typeof _0x50c0e4['exp']<'u','internal-error'),m(typeof _0x50c0e4['iat']<'u','internal-error'),Number(_0x50c0e4['exp'])-Number(_0x50c0e4['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4421cf,_0x17ef42,_0x63735d=!0x1){if(_0x63735d)return _0x17ef42;try{return await _0x17ef42;}catch(_0x3f7abf){throw _0x3f7abf instanceof Se&&pf(_0x3f7abf)&&_0x4421cf['auth']['currentUser']===_0x4421cf&&await _0x4421cf['auth']['signOut'](),_0x3f7abf;}}function pf({code:_0x293873}){return _0x293873==='auth/user-disabled'||_0x293873==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3962de){this['user']=_0x3962de,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5061d4){if(_0x5061d4){const _0x594293=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x594293;}else{this['errorBackoff']=0x7530;const _0x40be25=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x40be25);}}['schedule'](_0x5bcd75=!0x1){if(!this['isRunning'])return;const _0x5feab0=this['getInterval'](_0x5bcd75);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5feab0);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5bd2c5){(_0x5bd2c5==null?void 0x0:_0x5bd2c5['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0xc300b,_0x38e7dd){this['createdAt']=_0xc300b,this['lastLoginAt']=_0x38e7dd,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x24f027){this['createdAt']=_0x24f027['createdAt'],this['lastLoginAt']=_0x24f027['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x34d205){var _0x15ee9e;const _0x2fcc62=_0x34d205['auth'],_0x1461a0=await _0x34d205['getIdToken'](),_0x51024d=await xt(_0x34d205,Sn(_0x2fcc62,{'idToken':_0x1461a0}));m(_0x51024d==null?void 0x0:_0x51024d['users']['length'],_0x2fcc62,'internal-error');const _0x35ba83=_0x51024d['users'][0x0];_0x34d205['_notifyReloadListener'](_0x35ba83);const _0x2d0196=(_0x15ee9e=_0x35ba83['providerUserInfo'])!=null&&_0x15ee9e['length']?wa(_0x35ba83['providerUserInfo']):[],_0x14e152=mf(_0x34d205['providerData'],_0x2d0196),_0x17ec35=_0x34d205['isAnonymous'],_0x3ae7d8=!(_0x34d205['email']&&_0x35ba83['passwordHash'])&&!(_0x14e152!=null&&_0x14e152['length']),_0xdc4ab6=_0x17ec35?_0x3ae7d8:!0x1,_0x215064={'uid':_0x35ba83['localId'],'displayName':_0x35ba83['displayName']||null,'photoURL':_0x35ba83['photoUrl']||null,'email':_0x35ba83['email']||null,'emailVerified':_0x35ba83['emailVerified']||!0x1,'phoneNumber':_0x35ba83['phoneNumber']||null,'tenantId':_0x35ba83['tenantId']||null,'providerData':_0x14e152,'metadata':new Pi(_0x35ba83['createdAt'],_0x35ba83['lastLoginAt']),'isAnonymous':_0xdc4ab6};Object['assign'](_0x34d205,_0x215064);}async function gf(_0xee288b){const _0x28cd43=k(_0xee288b);await bn(_0x28cd43),await _0x28cd43['auth']['_persistUserIfCurrent'](_0x28cd43),_0x28cd43['auth']['_notifyListenersIfCurrent'](_0x28cd43);}function mf(_0x245a37,_0x56b0bc){return[..._0x245a37['filter'](_0x13ae92=>!_0x56b0bc['some'](_0x144f81=>_0x144f81['providerId']===_0x13ae92['providerId'])),..._0x56b0bc];}function wa(_0x2dc4f5){return _0x2dc4f5['map'](({providerId:_0xda0aa0,..._0xf5e01b})=>({'providerId':_0xda0aa0,'uid':_0xf5e01b['rawId']||'','displayName':_0xf5e01b['displayName']||null,'email':_0xf5e01b['email']||null,'phoneNumber':_0xf5e01b['phoneNumber']||null,'photoURL':_0xf5e01b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x15c47b,_0x741361){const _0x3ca3ff=await Ea(_0x15c47b,{},async()=>{const _0x380383=at({'grant_type':'refresh_token','refresh_token':_0x741361})['slice'](0x1),{tokenApiHost:_0x4f6845,apiKey:_0x49eec9}=_0x15c47b['config'],_0x55168c=await Ia(_0x15c47b,_0x4f6845,'/v1/token','key='+_0x49eec9),_0x56781b=await _0x15c47b['_getAdditionalHeaders']();_0x56781b['Content-Type']='application/x-www-form-urlencoded';const _0x146de2={'method':'POST','headers':_0x56781b,'body':_0x380383};return _0x15c47b['emulatorConfig']&&Wt(_0x15c47b['emulatorConfig']['host'])&&(_0x146de2['credentials']='include'),va['fetch']()(_0x55168c,_0x146de2);});return{'accessToken':_0x3ca3ff['access_token'],'expiresIn':_0x3ca3ff['expires_in'],'refreshToken':_0x3ca3ff['refresh_token']};}async function vf(_0x16a6ed,_0x546ffd){return Ae(_0x16a6ed,'POST','/v2/accounts:revokeToken',Re(_0x16a6ed,_0x546ffd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x121f54){m(_0x121f54['idToken'],'internal-error'),m(typeof _0x121f54['idToken']<'u','internal-error'),m(typeof _0x121f54['refreshToken']<'u','internal-error');const _0x4b12de='expiresIn'in _0x121f54&&typeof _0x121f54['expiresIn']<'u'?Number(_0x121f54['expiresIn']):Er(_0x121f54['idToken']);this['updateTokensAndExpiration'](_0x121f54['idToken'],_0x121f54['refreshToken'],_0x4b12de);}['updateFromIdToken'](_0x1df390){m(_0x1df390['length']!==0x0,'internal-error');const _0x2072de=Er(_0x1df390);this['updateTokensAndExpiration'](_0x1df390,null,_0x2072de);}async['getToken'](_0xe0c98a,_0x19bc87=!0x1){return!_0x19bc87&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xe0c98a,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xe0c98a,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x56d781,_0x520d08){const {accessToken:_0x90bf8c,refreshToken:_0x3012a9,expiresIn:_0x2c321d}=await yf(_0x56d781,_0x520d08);this['updateTokensAndExpiration'](_0x90bf8c,_0x3012a9,Number(_0x2c321d));}['updateTokensAndExpiration'](_0x2e8ff6,_0x57dc42,_0x101205){this['refreshToken']=_0x57dc42||null,this['accessToken']=_0x2e8ff6||null,this['expirationTime']=Date['now']()+_0x101205*0x3e8;}static['fromJSON'](_0x3c84bf,_0x1b336a){const {refreshToken:_0x47217e,accessToken:_0x5037c4,expirationTime:_0x217b6c}=_0x1b336a,_0x1f10bb=new Je();return _0x47217e&&(m(typeof _0x47217e=='string','internal-error',{'appName':_0x3c84bf}),_0x1f10bb['refreshToken']=_0x47217e),_0x5037c4&&(m(typeof _0x5037c4=='string','internal-error',{'appName':_0x3c84bf}),_0x1f10bb['accessToken']=_0x5037c4),_0x217b6c&&(m(typeof _0x217b6c=='number','internal-error',{'appName':_0x3c84bf}),_0x1f10bb['expirationTime']=_0x217b6c),_0x1f10bb;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2fe046){this['accessToken']=_0x2fe046['accessToken'],this['refreshToken']=_0x2fe046['refreshToken'],this['expirationTime']=_0x2fe046['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x2c8ab7,_0x313c8b){m(typeof _0x2c8ab7=='string'||typeof _0x2c8ab7>'u','internal-error',{'appName':_0x313c8b});}class z{constructor({uid:_0x2fc334,auth:_0x304a6b,stsTokenManager:_0x4c1912,..._0x3d8b1d}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2fc334,this['auth']=_0x304a6b,this['stsTokenManager']=_0x4c1912,this['accessToken']=_0x4c1912['accessToken'],this['displayName']=_0x3d8b1d['displayName']||null,this['email']=_0x3d8b1d['email']||null,this['emailVerified']=_0x3d8b1d['emailVerified']||!0x1,this['phoneNumber']=_0x3d8b1d['phoneNumber']||null,this['photoURL']=_0x3d8b1d['photoURL']||null,this['isAnonymous']=_0x3d8b1d['isAnonymous']||!0x1,this['tenantId']=_0x3d8b1d['tenantId']||null,this['providerData']=_0x3d8b1d['providerData']?[..._0x3d8b1d['providerData']]:[],this['metadata']=new Pi(_0x3d8b1d['createdAt']||void 0x0,_0x3d8b1d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1aaf34){const _0x289d81=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1aaf34));return m(_0x289d81,this['auth'],'internal-error'),this['accessToken']!==_0x289d81&&(this['accessToken']=_0x289d81,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x289d81;}['getIdTokenResult'](_0x5ad31c){return ff(this,_0x5ad31c);}['reload'](){return gf(this);}['_assign'](_0x1ee29b){this!==_0x1ee29b&&(m(this['uid']===_0x1ee29b['uid'],this['auth'],'internal-error'),this['displayName']=_0x1ee29b['displayName'],this['photoURL']=_0x1ee29b['photoURL'],this['email']=_0x1ee29b['email'],this['emailVerified']=_0x1ee29b['emailVerified'],this['phoneNumber']=_0x1ee29b['phoneNumber'],this['isAnonymous']=_0x1ee29b['isAnonymous'],this['tenantId']=_0x1ee29b['tenantId'],this['providerData']=_0x1ee29b['providerData']['map'](_0x3260ca=>({..._0x3260ca})),this['metadata']['_copy'](_0x1ee29b['metadata']),this['stsTokenManager']['_assign'](_0x1ee29b['stsTokenManager']));}['_clone'](_0x46db5d){const _0x4c705f=new z({...this,'auth':_0x46db5d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4c705f['metadata']['_copy'](this['metadata']),_0x4c705f;}['_onReload'](_0x136d33){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x136d33,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2ae04a){this['reloadListener']?this['reloadListener'](_0x2ae04a):this['reloadUserInfo']=_0x2ae04a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x451831,_0x3ad854=!0x1){let _0x8eef7e=!0x1;_0x451831['idToken']&&_0x451831['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x451831),_0x8eef7e=!0x0),_0x3ad854&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x8eef7e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2bcefa=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2bcefa})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x39b1fc=>({..._0x39b1fc})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x3ba2d5,_0x238e9e){const _0x4d4790=_0x238e9e['displayName']??void 0x0,_0xd38869=_0x238e9e['email']??void 0x0,_0x16b343=_0x238e9e['phoneNumber']??void 0x0,_0x4e8ab1=_0x238e9e['photoURL']??void 0x0,_0x217a6e=_0x238e9e['tenantId']??void 0x0,_0x3614ce=_0x238e9e['_redirectEventId']??void 0x0,_0x57cfbc=_0x238e9e['createdAt']??void 0x0,_0x8b92cd=_0x238e9e['lastLoginAt']??void 0x0,{uid:_0x2bc9f5,emailVerified:_0x312b67,isAnonymous:_0x3055e6,providerData:_0x4cbcd3,stsTokenManager:_0x5d1efd}=_0x238e9e;m(_0x2bc9f5&&_0x5d1efd,_0x3ba2d5,'internal-error');const _0x5ae8ed=Je['fromJSON'](this['name'],_0x5d1efd);m(typeof _0x2bc9f5=='string',_0x3ba2d5,'internal-error'),ce(_0x4d4790,_0x3ba2d5['name']),ce(_0xd38869,_0x3ba2d5['name']),m(typeof _0x312b67=='boolean',_0x3ba2d5,'internal-error'),m(typeof _0x3055e6=='boolean',_0x3ba2d5,'internal-error'),ce(_0x16b343,_0x3ba2d5['name']),ce(_0x4e8ab1,_0x3ba2d5['name']),ce(_0x217a6e,_0x3ba2d5['name']),ce(_0x3614ce,_0x3ba2d5['name']),ce(_0x57cfbc,_0x3ba2d5['name']),ce(_0x8b92cd,_0x3ba2d5['name']);const _0x4907d1=new z({'uid':_0x2bc9f5,'auth':_0x3ba2d5,'email':_0xd38869,'emailVerified':_0x312b67,'displayName':_0x4d4790,'isAnonymous':_0x3055e6,'photoURL':_0x4e8ab1,'phoneNumber':_0x16b343,'tenantId':_0x217a6e,'stsTokenManager':_0x5ae8ed,'createdAt':_0x57cfbc,'lastLoginAt':_0x8b92cd});return _0x4cbcd3&&Array['isArray'](_0x4cbcd3)&&(_0x4907d1['providerData']=_0x4cbcd3['map'](_0xf9b1aa=>({..._0xf9b1aa}))),_0x3614ce&&(_0x4907d1['_redirectEventId']=_0x3614ce),_0x4907d1;}static async['_fromIdTokenResponse'](_0x59ab39,_0x24fc0d,_0x2f007f=!0x1){const _0x3f7cc8=new Je();_0x3f7cc8['updateFromServerResponse'](_0x24fc0d);const _0x9b81e5=new z({'uid':_0x24fc0d['localId'],'auth':_0x59ab39,'stsTokenManager':_0x3f7cc8,'isAnonymous':_0x2f007f});return await bn(_0x9b81e5),_0x9b81e5;}static async['_fromGetAccountInfoResponse'](_0x599c9c,_0x44dcb7,_0x4030a0){const _0x5714a3=_0x44dcb7['users'][0x0];m(_0x5714a3['localId']!==void 0x0,'internal-error');const _0x33973c=_0x5714a3['providerUserInfo']!==void 0x0?wa(_0x5714a3['providerUserInfo']):[],_0x3a1dfa=!(_0x5714a3['email']&&_0x5714a3['passwordHash'])&&!(_0x33973c!=null&&_0x33973c['length']),_0x1f6096=new Je();_0x1f6096['updateFromIdToken'](_0x4030a0);const _0x19e086=new z({'uid':_0x5714a3['localId'],'auth':_0x599c9c,'stsTokenManager':_0x1f6096,'isAnonymous':_0x3a1dfa}),_0x4d6e21={'uid':_0x5714a3['localId'],'displayName':_0x5714a3['displayName']||null,'photoURL':_0x5714a3['photoUrl']||null,'email':_0x5714a3['email']||null,'emailVerified':_0x5714a3['emailVerified']||!0x1,'phoneNumber':_0x5714a3['phoneNumber']||null,'tenantId':_0x5714a3['tenantId']||null,'providerData':_0x33973c,'metadata':new Pi(_0x5714a3['createdAt'],_0x5714a3['lastLoginAt']),'isAnonymous':!(_0x5714a3['email']&&_0x5714a3['passwordHash'])&&!(_0x33973c!=null&&_0x33973c['length'])};return Object['assign'](_0x19e086,_0x4d6e21),_0x19e086;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x31a75e){ae(_0x31a75e instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2fe9de=Ir['get'](_0x31a75e);return _0x2fe9de?(ae(_0x2fe9de instanceof _0x31a75e,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2fe9de):(_0x2fe9de=new _0x31a75e(),Ir['set'](_0x31a75e,_0x2fe9de),_0x2fe9de);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3eed6d,_0x323b0b){this['storage'][_0x3eed6d]=_0x323b0b;}async['_get'](_0x26b3f6){const _0x42d928=this['storage'][_0x26b3f6];return _0x42d928===void 0x0?null:_0x42d928;}async['_remove'](_0x3c7437){delete this['storage'][_0x3c7437];}['_addListener'](_0x18154d,_0x2442cb){}['_removeListener'](_0x58cb62,_0x569ea8){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x175d22,_0xfff3d5,_0x310a8f){return'firebase:'+_0x175d22+':'+_0xfff3d5+':'+_0x310a8f;}class Xe{constructor(_0x135d82,_0x222b3c,_0x53ff40){this['persistence']=_0x135d82,this['auth']=_0x222b3c,this['userKey']=_0x53ff40;const {config:_0x2a4ac3,name:_0x3e0004}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x2a4ac3['apiKey'],_0x3e0004),this['fullPersistenceKey']=sn('persistence',_0x2a4ac3['apiKey'],_0x3e0004),this['boundEventHandler']=_0x222b3c['_onStorageEvent']['bind'](_0x222b3c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3028c2){return this['persistence']['_set'](this['fullUserKey'],_0x3028c2['toJSON']());}async['getCurrentUser'](){const _0x3ebbda=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3ebbda)return null;if(typeof _0x3ebbda=='string'){const _0x1bf484=await Sn(this['auth'],{'idToken':_0x3ebbda})['catch'](()=>{});return _0x1bf484?z['_fromGetAccountInfoResponse'](this['auth'],_0x1bf484,_0x3ebbda):null;}return z['_fromJSON'](this['auth'],_0x3ebbda);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x54dd19){if(this['persistence']===_0x54dd19)return;const _0x23e300=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x54dd19,_0x23e300)return this['setCurrentUser'](_0x23e300);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3d7e71,_0x385834,_0x6ba4eb='authUser'){if(!_0x385834['length'])return new Xe(ne(wr),_0x3d7e71,_0x6ba4eb);const _0x3fd7cd=(await Promise['all'](_0x385834['map'](async _0x4fe643=>{if(await _0x4fe643['_isAvailable']())return _0x4fe643;})))['filter'](_0x501360=>_0x501360);let _0x4f8643=_0x3fd7cd[0x0]||ne(wr);const _0xfc50da=sn(_0x6ba4eb,_0x3d7e71['config']['apiKey'],_0x3d7e71['name']);let _0x4d6e19=null;for(const _0x6c81fa of _0x385834)try{const _0x100482=await _0x6c81fa['_get'](_0xfc50da);if(_0x100482){let _0x3d9e03;if(typeof _0x100482=='string'){const _0x345202=await Sn(_0x3d7e71,{'idToken':_0x100482})['catch'](()=>{});if(!_0x345202)break;_0x3d9e03=await z['_fromGetAccountInfoResponse'](_0x3d7e71,_0x345202,_0x100482);}else _0x3d9e03=z['_fromJSON'](_0x3d7e71,_0x100482);_0x6c81fa!==_0x4f8643&&(_0x4d6e19=_0x3d9e03),_0x4f8643=_0x6c81fa;break;}}catch{}const _0x50cdc9=_0x3fd7cd['filter'](_0x5f0958=>_0x5f0958['_shouldAllowMigration']);return!_0x4f8643['_shouldAllowMigration']||!_0x50cdc9['length']?new Xe(_0x4f8643,_0x3d7e71,_0x6ba4eb):(_0x4f8643=_0x50cdc9[0x0],_0x4d6e19&&await _0x4f8643['_set'](_0xfc50da,_0x4d6e19['toJSON']()),await Promise['all'](_0x385834['map'](async _0x1936fe=>{if(_0x1936fe!==_0x4f8643)try{await _0x1936fe['_remove'](_0xfc50da);}catch{}})),new Xe(_0x4f8643,_0x3d7e71,_0x6ba4eb));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4795ec){const _0x18dc85=_0x4795ec['toLowerCase']();if(_0x18dc85['includes']('opera/')||_0x18dc85['includes']('opr/')||_0x18dc85['includes']('opios/'))return'Opera';if(Ra(_0x18dc85))return'IEMobile';if(_0x18dc85['includes']('msie')||_0x18dc85['includes']('trident/'))return'IE';if(_0x18dc85['includes']('edge/'))return'Edge';if(Ta(_0x18dc85))return'Firefox';if(_0x18dc85['includes']('silk/'))return'Silk';if(ka(_0x18dc85))return'Blackberry';if(Na(_0x18dc85))return'Webos';if(Sa(_0x18dc85))return'Safari';if((_0x18dc85['includes']('chrome/')||ba(_0x18dc85))&&!_0x18dc85['includes']('edge/'))return'Chrome';if(Aa(_0x18dc85))return'Android';{const _0x2e9d64=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1a07be=_0x4795ec['match'](_0x2e9d64);if((_0x1a07be==null?void 0x0:_0x1a07be['length'])===0x2)return _0x1a07be[0x1];}return'Other';}function Ta(_0x204f8f=W()){return/firefox\//i['test'](_0x204f8f);}function Sa(_0x89ba01=W()){const _0x565610=_0x89ba01['toLowerCase']();return _0x565610['includes']('safari/')&&!_0x565610['includes']('chrome/')&&!_0x565610['includes']('crios/')&&!_0x565610['includes']('android');}function ba(_0x4c4eb6=W()){return/crios\//i['test'](_0x4c4eb6);}function Ra(_0x15ca71=W()){return/iemobile/i['test'](_0x15ca71);}function Aa(_0x27bf18=W()){return/android/i['test'](_0x27bf18);}function ka(_0x4f8f63=W()){return/blackberry/i['test'](_0x4f8f63);}function Na(_0x1ff4b8=W()){return/webos/i['test'](_0x1ff4b8);}function Cs(_0x2818a6=W()){return/iphone|ipad|ipod/i['test'](_0x2818a6)||/macintosh/i['test'](_0x2818a6)&&/mobile/i['test'](_0x2818a6);}function Ef(_0x47546a=W()){var _0x543235;return Cs(_0x47546a)&&!!((_0x543235=window['navigator'])!=null&&_0x543235['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x485e06=W()){return Cs(_0x485e06)||Aa(_0x485e06)||Na(_0x485e06)||ka(_0x485e06)||/windows phone/i['test'](_0x485e06)||Ra(_0x485e06);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0xc7fcef,_0x54f4e8=[]){let _0x24d957;switch(_0xc7fcef){case'Browser':_0x24d957=Cr(W());break;case'Worker':_0x24d957=Cr(W())+'-'+_0xc7fcef;break;default:_0x24d957=_0xc7fcef;}const _0x3dd4fa=_0x54f4e8['length']?_0x54f4e8['join'](','):'FirebaseCore-web';return _0x24d957+'/JsCore/'+ct+'/'+_0x3dd4fa;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4cc6ec){this['auth']=_0x4cc6ec,this['queue']=[];}['pushCallback'](_0x393d3b,_0x1a3a24){const _0x520b23=_0x788b6d=>new Promise((_0x5bb474,_0x37ad1d)=>{try{const _0x2185ba=_0x393d3b(_0x788b6d);_0x5bb474(_0x2185ba);}catch(_0x12b4fd){_0x37ad1d(_0x12b4fd);}});_0x520b23['onAbort']=_0x1a3a24,this['queue']['push'](_0x520b23);const _0x5b350d=this['queue']['length']-0x1;return()=>{this['queue'][_0x5b350d]=()=>Promise['resolve']();};}async['runMiddleware'](_0x316608){if(this['auth']['currentUser']===_0x316608)return;const _0x331402=[];try{for(const _0x67da91 of this['queue'])await _0x67da91(_0x316608),_0x67da91['onAbort']&&_0x331402['push'](_0x67da91['onAbort']);}catch(_0x5541eb){_0x331402['reverse']();for(const _0x1c0c1d of _0x331402)try{_0x1c0c1d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5541eb==null?void 0x0:_0x5541eb['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x35f497,_0x3a718d={}){return Ae(_0x35f497,'GET','/v2/passwordPolicy',Re(_0x35f497,_0x3a718d));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x5d777e){var _0x4dffcb;const _0x37902a=_0x5d777e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x37902a['minPasswordLength']??Tf,_0x37902a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x37902a['maxPasswordLength']),_0x37902a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x37902a['containsLowercaseCharacter']),_0x37902a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x37902a['containsUppercaseCharacter']),_0x37902a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x37902a['containsNumericCharacter']),_0x37902a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x37902a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5d777e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4dffcb=_0x5d777e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4dffcb['join'](''))??'',this['forceUpgradeOnSignin']=_0x5d777e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5d777e['schemaVersion'];}['validatePassword'](_0x137ccd){const _0x42b0db={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x137ccd,_0x42b0db),this['validatePasswordCharacterOptions'](_0x137ccd,_0x42b0db),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['meetsMinPasswordLength']??!0x0),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['meetsMaxPasswordLength']??!0x0),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['containsLowercaseLetter']??!0x0),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['containsUppercaseLetter']??!0x0),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['containsNumericCharacter']??!0x0),_0x42b0db['isValid']&&(_0x42b0db['isValid']=_0x42b0db['containsNonAlphanumericCharacter']??!0x0),_0x42b0db;}['validatePasswordLengthOptions'](_0x5e0e30,_0x26ae8e){const _0x34ad94=this['customStrengthOptions']['minPasswordLength'],_0x322cf7=this['customStrengthOptions']['maxPasswordLength'];_0x34ad94&&(_0x26ae8e['meetsMinPasswordLength']=_0x5e0e30['length']>=_0x34ad94),_0x322cf7&&(_0x26ae8e['meetsMaxPasswordLength']=_0x5e0e30['length']<=_0x322cf7);}['validatePasswordCharacterOptions'](_0x59572f,_0x403534){this['updatePasswordCharacterOptionsStatuses'](_0x403534,!0x1,!0x1,!0x1,!0x1);let _0x4623dc;for(let _0x1e1d41=0x0;_0x1e1d41<_0x59572f['length'];_0x1e1d41++)_0x4623dc=_0x59572f['charAt'](_0x1e1d41),this['updatePasswordCharacterOptionsStatuses'](_0x403534,_0x4623dc>='a'&&_0x4623dc<='z',_0x4623dc>='A'&&_0x4623dc<='Z',_0x4623dc>='0'&&_0x4623dc<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4623dc));}['updatePasswordCharacterOptionsStatuses'](_0x48c570,_0x522c16,_0x42ae3c,_0x662457,_0x54dce3){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x48c570['containsLowercaseLetter']||(_0x48c570['containsLowercaseLetter']=_0x522c16)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x48c570['containsUppercaseLetter']||(_0x48c570['containsUppercaseLetter']=_0x42ae3c)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x48c570['containsNumericCharacter']||(_0x48c570['containsNumericCharacter']=_0x662457)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x48c570['containsNonAlphanumericCharacter']||(_0x48c570['containsNonAlphanumericCharacter']=_0x54dce3));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0xe94355,_0x3424dd,_0x3c7e58,_0x35a994){this['app']=_0xe94355,this['heartbeatServiceProvider']=_0x3424dd,this['appCheckServiceProvider']=_0x3c7e58,this['config']=_0x35a994,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xe94355['name'],this['clientVersion']=_0x35a994['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x47e8ac=>this['_resolvePersistenceManagerAvailable']=_0x47e8ac);}['_initializeWithPersistence'](_0x4a4207,_0x424546){return _0x424546&&(this['_popupRedirectResolver']=ne(_0x424546)),this['_initializationPromise']=this['queue'](async()=>{var _0x239573,_0x4a558b,_0x18d573;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4a4207),(_0x239573=this['_resolvePersistenceManagerAvailable'])==null||_0x239573['call'](this),!this['_deleted'])){if((_0x4a558b=this['_popupRedirectResolver'])!=null&&_0x4a558b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x424546),this['lastNotifiedUid']=((_0x18d573=this['currentUser'])==null?void 0x0:_0x18d573['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2ba019=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2ba019)){if(this['currentUser']&&_0x2ba019&&this['currentUser']['uid']===_0x2ba019['uid']){this['_currentUser']['_assign'](_0x2ba019),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2ba019,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x40b3df){try{const _0x462860=await Sn(this,{'idToken':_0x40b3df}),_0x23ecbf=await z['_fromGetAccountInfoResponse'](this,_0x462860,_0x40b3df);await this['directlySetCurrentUser'](_0x23ecbf);}catch(_0xc9d96a){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xc9d96a),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xf35518){var _0x364fb3;if(H(this['app'])){const _0x12a012=this['app']['settings']['authIdToken'];return _0x12a012?new Promise(_0x1fd3c6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x12a012)['then'](_0x1fd3c6,_0x1fd3c6));}):this['directlySetCurrentUser'](null);}const _0x5307ab=await this['assertedPersistence']['getCurrentUser']();let _0x5998eb=_0x5307ab,_0x13e1bb=!0x1;if(_0xf35518&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x374ef9=(_0x364fb3=this['redirectUser'])==null?void 0x0:_0x364fb3['_redirectEventId'],_0x297214=_0x5998eb==null?void 0x0:_0x5998eb['_redirectEventId'],_0x54f24b=await this['tryRedirectSignIn'](_0xf35518);(!_0x374ef9||_0x374ef9===_0x297214)&&(_0x54f24b!=null&&_0x54f24b['user'])&&(_0x5998eb=_0x54f24b['user'],_0x13e1bb=!0x0);}if(!_0x5998eb)return this['directlySetCurrentUser'](null);if(!_0x5998eb['_redirectEventId']){if(_0x13e1bb)try{await this['beforeStateQueue']['runMiddleware'](_0x5998eb);}catch(_0x4bfc08){_0x5998eb=_0x5307ab,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4bfc08));}return _0x5998eb?this['reloadAndSetCurrentUserOrClear'](_0x5998eb):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5998eb['_redirectEventId']?this['directlySetCurrentUser'](_0x5998eb):this['reloadAndSetCurrentUserOrClear'](_0x5998eb);}async['tryRedirectSignIn'](_0x16ab9b){let _0x33807d=null;try{_0x33807d=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x16ab9b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x33807d;}async['reloadAndSetCurrentUserOrClear'](_0x3dce8b){try{await bn(_0x3dce8b);}catch(_0xa24dd){if((_0xa24dd==null?void 0x0:_0xa24dd['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3dce8b);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x39d82e){if(H(this['app']))return Promise['reject'](se(this));const _0x38db42=_0x39d82e?k(_0x39d82e):null;return _0x38db42&&m(_0x38db42['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x38db42&&_0x38db42['_clone'](this));}async['_updateCurrentUser'](_0x44022b,_0x1e8a6b=!0x1){if(!this['_deleted'])return _0x44022b&&m(this['tenantId']===_0x44022b['tenantId'],this,'tenant-id-mismatch'),_0x1e8a6b||await this['beforeStateQueue']['runMiddleware'](_0x44022b),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x44022b),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1aa7f9){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x1aa7f9));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x281fce){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4aa4e5=this['_getPasswordPolicyInternal']();return _0x4aa4e5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4aa4e5['validatePassword'](_0x281fce);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1a00e4=await Cf(this),_0x1eb89c=new Sf(_0x1a00e4);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1eb89c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1eb89c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x20cafd){this['_errorFactory']=new Ut('auth','Firebase',_0x20cafd());}['onAuthStateChanged'](_0x38588b,_0x3461b8,_0x3b8914){return this['registerStateListener'](this['authStateSubscription'],_0x38588b,_0x3461b8,_0x3b8914);}['beforeAuthStateChanged'](_0x1ce475,_0xaf8338){return this['beforeStateQueue']['pushCallback'](_0x1ce475,_0xaf8338);}['onIdTokenChanged'](_0x2517eb,_0x1d7ac8,_0x19bdfd){return this['registerStateListener'](this['idTokenSubscription'],_0x2517eb,_0x1d7ac8,_0x19bdfd);}['authStateReady'](){return new Promise((_0x5f123c,_0x426870)=>{if(this['currentUser'])_0x5f123c();else{const _0x78e020=this['onAuthStateChanged'](()=>{_0x78e020(),_0x5f123c();},_0x426870);}});}async['revokeAccessToken'](_0xe4909b){if(this['currentUser']){const _0x5b591e=await this['currentUser']['getIdToken'](),_0xde1129={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0xe4909b,'idToken':_0x5b591e};this['tenantId']!=null&&(_0xde1129['tenantId']=this['tenantId']),await vf(this,_0xde1129);}}['toJSON'](){var _0x5bc04e;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5bc04e=this['_currentUser'])==null?void 0x0:_0x5bc04e['toJSON']()};}async['_setRedirectUser'](_0x21ead3,_0x2dd4d1){const _0x1222fc=await this['getOrInitRedirectPersistenceManager'](_0x2dd4d1);return _0x21ead3===null?_0x1222fc['removeCurrentUser']():_0x1222fc['setCurrentUser'](_0x21ead3);}async['getOrInitRedirectPersistenceManager'](_0x422ac9){if(!this['redirectPersistenceManager']){const _0x8ebd4b=_0x422ac9&&ne(_0x422ac9)||this['_popupRedirectResolver'];m(_0x8ebd4b,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x8ebd4b['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1ac860){var _0x16614b,_0x836a52;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x16614b=this['_currentUser'])==null?void 0x0:_0x16614b['_redirectEventId'])===_0x1ac860?this['_currentUser']:((_0x836a52=this['redirectUser'])==null?void 0x0:_0x836a52['_redirectEventId'])===_0x1ac860?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3a3738){if(_0x3a3738===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3a3738));}['_notifyListenersIfCurrent'](_0x170c2c){_0x170c2c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x18940b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x321d4d=((_0x18940b=this['currentUser'])==null?void 0x0:_0x18940b['uid'])??null;this['lastNotifiedUid']!==_0x321d4d&&(this['lastNotifiedUid']=_0x321d4d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x211c9f,_0x16475d,_0x219ba7,_0x119d58){if(this['_deleted'])return()=>{};const _0x5c642a=typeof _0x16475d=='function'?_0x16475d:_0x16475d['next']['bind'](_0x16475d);let _0x2db742=!0x1;const _0x3a5668=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3a5668,this,'internal-error'),_0x3a5668['then'](()=>{_0x2db742||_0x5c642a(this['currentUser']);}),typeof _0x16475d=='function'){const _0xa15ab1=_0x211c9f['addObserver'](_0x16475d,_0x219ba7,_0x119d58);return()=>{_0x2db742=!0x0,_0xa15ab1();};}else{const _0x3d8e3b=_0x211c9f['addObserver'](_0x16475d);return()=>{_0x2db742=!0x0,_0x3d8e3b();};}}async['directlySetCurrentUser'](_0x10edda){this['currentUser']&&this['currentUser']!==_0x10edda&&this['_currentUser']['_stopProactiveRefresh'](),_0x10edda&&this['isProactiveRefreshEnabled']&&_0x10edda['_startProactiveRefresh'](),this['currentUser']=_0x10edda,_0x10edda?await this['assertedPersistence']['setCurrentUser'](_0x10edda):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4cca1a){return this['operations']=this['operations']['then'](_0x4cca1a,_0x4cca1a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4d9cf7){!_0x4d9cf7||this['frameworks']['includes'](_0x4d9cf7)||(this['frameworks']['push'](_0x4d9cf7),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x23f207;const _0x5c909f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5c909f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2ed7e6=await((_0x23f207=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x23f207['getHeartbeatsHeader']());_0x2ed7e6&&(_0x5c909f['X-Firebase-Client']=_0x2ed7e6);const _0x245fa1=await this['_getAppCheckToken']();return _0x245fa1&&(_0x5c909f['X-Firebase-AppCheck']=_0x245fa1),_0x5c909f;}async['_getAppCheckToken'](){var _0x56f413;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x59fa60=await((_0x56f413=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x56f413['getToken']());return _0x59fa60!=null&&_0x59fa60['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x59fa60['error']),_0x59fa60==null?void 0x0:_0x59fa60['token'];}}function qe(_0x12218d){return k(_0x12218d);}class Tr{constructor(_0x284791){this['auth']=_0x284791,this['observer']=null,this['addObserver']=Ic(_0x44f986=>this['observer']=_0x44f986);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x5a25a0){zn=_0x5a25a0;}function Da(_0x8313de){return zn['loadJS'](_0x8313de);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x510156){return'__'+_0x510156+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x8fe3d1){_0x8fe3d1();}['execute'](_0x5b9beb,_0x4ae7c5){return Promise['resolve']('token');}['render'](_0x3894db,_0x252666){return'';}}class Of{['ready'](_0x130e98){_0x130e98();}['execute'](_0x5a0178,_0x44d322){return Promise['resolve']('token');}['render'](_0x348fd8,_0x24ebd5){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x353ac8){this['type']=Df,this['auth']=qe(_0x353ac8);}async['verify'](_0x3c95da='verify',_0x4bc6b9=!0x1){async function _0x99d642(_0x1aa562){if(!_0x4bc6b9){if(_0x1aa562['tenantId']==null&&_0x1aa562['_agentRecaptchaConfig']!=null)return _0x1aa562['_agentRecaptchaConfig']['siteKey'];if(_0x1aa562['tenantId']!=null&&_0x1aa562['_tenantRecaptchaConfigs'][_0x1aa562['tenantId']]!==void 0x0)return _0x1aa562['_tenantRecaptchaConfigs'][_0x1aa562['tenantId']]['siteKey'];}return new Promise(async(_0x5496e9,_0x900c1c)=>{uf(_0x1aa562,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4c2cfb=>{if(_0x4c2cfb['recaptchaKey']===void 0x0)_0x900c1c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x49065e=new hf(_0x4c2cfb);return _0x1aa562['tenantId']==null?_0x1aa562['_agentRecaptchaConfig']=_0x49065e:_0x1aa562['_tenantRecaptchaConfigs'][_0x1aa562['tenantId']]=_0x49065e,_0x5496e9(_0x49065e['siteKey']);}})['catch'](_0x4fc470=>{_0x900c1c(_0x4fc470);});});}function _0x1b1a9e(_0x4a87f8,_0x1c2c5b,_0x96d4a9){const _0x526b4f=window['grecaptcha'];vr(_0x526b4f)?_0x526b4f['enterprise']['ready'](()=>{_0x526b4f['enterprise']['execute'](_0x4a87f8,{'action':_0x3c95da})['then'](_0x153e1c=>{_0x1c2c5b(_0x153e1c);})['catch'](()=>{_0x1c2c5b(Ma);});}):_0x96d4a9(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3ffd7f,_0x541f86)=>{_0x99d642(this['auth'])['then'](async _0xf1a0c6=>{if(!_0x4bc6b9&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x1b1a9e(_0xf1a0c6,_0x3ffd7f,_0x541f86);else{if(typeof window>'u'){_0x541f86(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5757c3=Af();_0x5757c3['length']!==0x0&&(_0x5757c3+=_0xf1a0c6+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x55fa22;(_0x55fa22=le['scriptInjectionDeferred'])==null||_0x55fa22['resolve']();},Da(_0x5757c3)['then'](()=>{var _0x4b9c6a;return(_0x4b9c6a=le['scriptInjectionDeferred'])==null?void 0x0:_0x4b9c6a['promise'];})['then'](()=>{_0x1b1a9e(_0xf1a0c6,_0x3ffd7f,_0x541f86);})['catch'](_0x2c4859=>{_0x541f86(_0x2c4859);});}})['catch'](_0x579648=>{_0x541f86(_0x579648);});});}}le['scriptInjectionDeferred']=null;async function br(_0xea273c,_0x553fb4,_0x429c8e,_0x5dceae=!0x1,_0x4afdd5=!0x1){const _0x5aa132=new le(_0xea273c);let _0x23caa8;if(_0x4afdd5)_0x23caa8=Ma;else try{_0x23caa8=await _0x5aa132['verify'](_0x429c8e);}catch{_0x23caa8=await _0x5aa132['verify'](_0x429c8e,!0x0);}const _0x41a46a={..._0x553fb4};if(_0x429c8e==='mfaSmsEnrollment'||_0x429c8e==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x41a46a){const _0x414cde=_0x41a46a['phoneEnrollmentInfo']['phoneNumber'],_0x3f1c94=_0x41a46a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x41a46a,{'phoneEnrollmentInfo':{'phoneNumber':_0x414cde,'recaptchaToken':_0x3f1c94,'captchaResponse':_0x23caa8,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x41a46a){const _0x4f0411=_0x41a46a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x41a46a,{'phoneSignInInfo':{'recaptchaToken':_0x4f0411,'captchaResponse':_0x23caa8,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x41a46a;}return _0x5dceae?Object['assign'](_0x41a46a,{'captchaResp':_0x23caa8}):Object['assign'](_0x41a46a,{'captchaResponse':_0x23caa8}),Object['assign'](_0x41a46a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x41a46a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x41a46a;}async function Oi(_0x4652ca,_0x155f87,_0x221faf,_0x19f85d,_0x4d39d2){var _0x585e51;if((_0x585e51=_0x4652ca['_getRecaptchaConfig']())!=null&&_0x585e51['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xc9ea6=await br(_0x4652ca,_0x155f87,_0x221faf,_0x221faf==='getOobCode');return _0x19f85d(_0x4652ca,_0xc9ea6);}else return _0x19f85d(_0x4652ca,_0x155f87)['catch'](async _0x3135fb=>{if(_0x3135fb['code']==='auth/missing-recaptcha-token'){console['log'](_0x221faf+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x38882c=await br(_0x4652ca,_0x155f87,_0x221faf,_0x221faf==='getOobCode');return _0x19f85d(_0x4652ca,_0x38882c);}else return Promise['reject'](_0x3135fb);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x369c6c,_0x3a42eb){const _0x262658=Ui(_0x369c6c,'auth');if(_0x262658['isInitialized']()){const _0x412180=_0x262658['getImmediate'](),_0x18d7e1=_0x262658['getOptions']();if(De(_0x18d7e1,_0x3a42eb??{}))return _0x412180;K(_0x412180,'already-initialized');}return _0x262658['initialize']({'options':_0x3a42eb});}function Lf(_0x222d15,_0x292a44){const _0x3e6445=(_0x292a44==null?void 0x0:_0x292a44['persistence'])||[],_0x3547aa=(Array['isArray'](_0x3e6445)?_0x3e6445:[_0x3e6445])['map'](ne);_0x292a44!=null&&_0x292a44['errorMap']&&_0x222d15['_updateErrorMap'](_0x292a44['errorMap']),_0x222d15['_initializeWithPersistence'](_0x3547aa,_0x292a44==null?void 0x0:_0x292a44['popupRedirectResolver']);}function xf(_0x360448,_0x31276d,_0x1bdb10){const _0x133a83=qe(_0x360448);m(/^https?:\/\//['test'](_0x31276d),_0x133a83,'invalid-emulator-scheme');const _0x31cc3b=!0x1,_0x3f3019=La(_0x31276d),{host:_0x4e3faf,port:_0x26d2a6}=Ff(_0x31276d),_0x560df0=_0x26d2a6===null?'':':'+_0x26d2a6,_0x1fddb4={'url':_0x3f3019+'//'+_0x4e3faf+_0x560df0+'/'},_0x14ac5d=Object['freeze']({'host':_0x4e3faf,'port':_0x26d2a6,'protocol':_0x3f3019['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x31cc3b})});if(!_0x133a83['_canInitEmulator']){m(_0x133a83['config']['emulator']&&_0x133a83['emulatorConfig'],_0x133a83,'emulator-config-failed'),m(De(_0x1fddb4,_0x133a83['config']['emulator'])&&De(_0x14ac5d,_0x133a83['emulatorConfig']),_0x133a83,'emulator-config-failed');return;}_0x133a83['config']['emulator']=_0x1fddb4,_0x133a83['emulatorConfig']=_0x14ac5d,_0x133a83['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x4e3faf)?jr(_0x3f3019+'//'+_0x4e3faf+_0x560df0):Uf();}function La(_0x1733a4){const _0x26c309=_0x1733a4['indexOf'](':');return _0x26c309<0x0?'':_0x1733a4['substr'](0x0,_0x26c309+0x1);}function Ff(_0x506143){const _0x2b81f3=La(_0x506143),_0x4249ac=/(\/\/)?([^?#/]+)/['exec'](_0x506143['substr'](_0x2b81f3['length']));if(!_0x4249ac)return{'host':'','port':null};const _0x471159=_0x4249ac[0x2]['split']('@')['pop']()||'',_0x5ff270=/^(\[[^\]]+\])(:|$)/['exec'](_0x471159);if(_0x5ff270){const _0x4cdf09=_0x5ff270[0x1];return{'host':_0x4cdf09,'port':Rr(_0x471159['substr'](_0x4cdf09['length']+0x1))};}else{const [_0x1f2e14,_0x26f5a4]=_0x471159['split'](':');return{'host':_0x1f2e14,'port':Rr(_0x26f5a4)};}}function Rr(_0xf43780){if(!_0xf43780)return null;const _0x129ad0=Number(_0xf43780);return isNaN(_0x129ad0)?null:_0x129ad0;}function Uf(){function _0xa44cca(){const _0x2f2cc5=document['createElement']('p'),_0x5248df=_0x2f2cc5['style'];_0x2f2cc5['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5248df['position']='fixed',_0x5248df['width']='100%',_0x5248df['backgroundColor']='#ffffff',_0x5248df['border']='.1em\x20solid\x20#000000',_0x5248df['color']='#b50000',_0x5248df['bottom']='0px',_0x5248df['left']='0px',_0x5248df['margin']='0px',_0x5248df['zIndex']='10000',_0x5248df['textAlign']='center',_0x2f2cc5['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2f2cc5);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xa44cca):_0xa44cca());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1f0b60,_0x152ff2){this['providerId']=_0x1f0b60,this['signInMethod']=_0x152ff2;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xb07925){return te('not\x20implemented');}['_linkToIdToken'](_0x48a683,_0x2ef5a2){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x3cc164){return te('not\x20implemented');}}async function Wf(_0x1cae76,_0x3cc719){return Ae(_0x1cae76,'POST','/v1/accounts:signUp',_0x3cc719);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1c3ecb,_0x4b0cd3){return Yt(_0x1c3ecb,'POST','/v1/accounts:signInWithPassword',Re(_0x1c3ecb,_0x4b0cd3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x49de73,_0x9fc063){return Yt(_0x49de73,'POST','/v1/accounts:signInWithEmailLink',Re(_0x49de73,_0x9fc063));}async function Hf(_0x4bfeae,_0x4f2ac3){return Yt(_0x4bfeae,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4bfeae,_0x4f2ac3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x23dcd8,_0x2ace64,_0x2dc023,_0x4ca8ef=null){super('password',_0x2dc023),this['_email']=_0x23dcd8,this['_password']=_0x2ace64,this['_tenantId']=_0x4ca8ef;}static['_fromEmailAndPassword'](_0x28254e,_0x29bb3f){return new Ft(_0x28254e,_0x29bb3f,'password');}static['_fromEmailAndCode'](_0x359e51,_0xa349ef,_0x3e2ec1=null){return new Ft(_0x359e51,_0xa349ef,'emailLink',_0x3e2ec1);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1850b4){const _0x158a75=typeof _0x1850b4=='string'?JSON['parse'](_0x1850b4):_0x1850b4;if(_0x158a75!=null&&_0x158a75['email']&&(_0x158a75!=null&&_0x158a75['password'])){if(_0x158a75['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x158a75['email'],_0x158a75['password']);if(_0x158a75['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x158a75['email'],_0x158a75['password'],_0x158a75['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5de4d5){switch(this['signInMethod']){case'password':const _0x4d7aba={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5de4d5,_0x4d7aba,'signInWithPassword',Bf);case'emailLink':return Vf(_0x5de4d5,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x5de4d5,'internal-error');}}async['_linkToIdToken'](_0x523774,_0x5e8d5d){switch(this['signInMethod']){case'password':const _0x6f0812={'idToken':_0x5e8d5d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x523774,_0x6f0812,'signUpPassword',Wf);case'emailLink':return Hf(_0x523774,{'idToken':_0x5e8d5d,'email':this['_email'],'oobCode':this['_password']});default:K(_0x523774,'internal-error');}}['_getReauthenticationResolver'](_0x3d594f){return this['_getIdTokenResponse'](_0x3d594f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x30c0d1,_0x3ab66a){return Yt(_0x30c0d1,'POST','/v1/accounts:signInWithIdp',Re(_0x30c0d1,_0x3ab66a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2eb0d7){const _0x3ab29b=new We(_0x2eb0d7['providerId'],_0x2eb0d7['signInMethod']);return _0x2eb0d7['idToken']||_0x2eb0d7['accessToken']?(_0x2eb0d7['idToken']&&(_0x3ab29b['idToken']=_0x2eb0d7['idToken']),_0x2eb0d7['accessToken']&&(_0x3ab29b['accessToken']=_0x2eb0d7['accessToken']),_0x2eb0d7['nonce']&&!_0x2eb0d7['pendingToken']&&(_0x3ab29b['nonce']=_0x2eb0d7['nonce']),_0x2eb0d7['pendingToken']&&(_0x3ab29b['pendingToken']=_0x2eb0d7['pendingToken'])):_0x2eb0d7['oauthToken']&&_0x2eb0d7['oauthTokenSecret']?(_0x3ab29b['accessToken']=_0x2eb0d7['oauthToken'],_0x3ab29b['secret']=_0x2eb0d7['oauthTokenSecret']):K('argument-error'),_0x3ab29b;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x202f5e){const _0x52f798=typeof _0x202f5e=='string'?JSON['parse'](_0x202f5e):_0x202f5e,{providerId:_0x2cc4d5,signInMethod:_0xe7c23,..._0x27ad22}=_0x52f798;if(!_0x2cc4d5||!_0xe7c23)return null;const _0x5038a8=new We(_0x2cc4d5,_0xe7c23);return _0x5038a8['idToken']=_0x27ad22['idToken']||void 0x0,_0x5038a8['accessToken']=_0x27ad22['accessToken']||void 0x0,_0x5038a8['secret']=_0x27ad22['secret'],_0x5038a8['nonce']=_0x27ad22['nonce'],_0x5038a8['pendingToken']=_0x27ad22['pendingToken']||null,_0x5038a8;}['_getIdTokenResponse'](_0x502d16){const _0x8281d6=this['buildRequest']();return Ze(_0x502d16,_0x8281d6);}['_linkToIdToken'](_0x1e294e,_0x4d3160){const _0x36c84a=this['buildRequest']();return _0x36c84a['idToken']=_0x4d3160,Ze(_0x1e294e,_0x36c84a);}['_getReauthenticationResolver'](_0xa6ad57){const _0x51e2a6=this['buildRequest']();return _0x51e2a6['autoCreate']=!0x1,Ze(_0xa6ad57,_0x51e2a6);}['buildRequest'](){const _0x32f265={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x32f265['pendingToken']=this['pendingToken'];else{const _0x12ef81={};this['idToken']&&(_0x12ef81['id_token']=this['idToken']),this['accessToken']&&(_0x12ef81['access_token']=this['accessToken']),this['secret']&&(_0x12ef81['oauth_token_secret']=this['secret']),_0x12ef81['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x12ef81['nonce']=this['nonce']),_0x32f265['postBody']=at(_0x12ef81);}return _0x32f265;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x18332a){switch(_0x18332a){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x587e9f){const _0x276796=yt(vt(_0x587e9f))['link'],_0x1a3de0=_0x276796?yt(vt(_0x276796))['deep_link_id']:null,_0x32b3fd=yt(vt(_0x587e9f))['deep_link_id'];return(_0x32b3fd?yt(vt(_0x32b3fd))['link']:null)||_0x32b3fd||_0x1a3de0||_0x276796||_0x587e9f;}class Ss{constructor(_0x12cbfd){const _0x5b6c6f=yt(vt(_0x12cbfd)),_0x4b41e2=_0x5b6c6f['apiKey']??null,_0x231381=_0x5b6c6f['oobCode']??null,_0x1478e5=Gf(_0x5b6c6f['mode']??null);m(_0x4b41e2&&_0x231381&&_0x1478e5,'argument-error'),this['apiKey']=_0x4b41e2,this['operation']=_0x1478e5,this['code']=_0x231381,this['continueUrl']=_0x5b6c6f['continueUrl']??null,this['languageCode']=_0x5b6c6f['lang']??null,this['tenantId']=_0x5b6c6f['tenantId']??null;}static['parseLink'](_0x2a7c81){const _0x178663=qf(_0x2a7c81);try{return new Ss(_0x178663);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4ac0a1,_0x5ed6ac){return Ft['_fromEmailAndPassword'](_0x4ac0a1,_0x5ed6ac);}static['credentialWithLink'](_0x37952b,_0x513f28){const _0x2d022e=Ss['parseLink'](_0x513f28);return m(_0x2d022e,'argument-error'),Ft['_fromEmailAndCode'](_0x37952b,_0x2d022e['code'],_0x2d022e['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x2ef816){this['providerId']=_0x2ef816,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3353d8){this['defaultLanguageCode']=_0x3353d8;}['setCustomParameters'](_0x20983e){return this['customParameters']=_0x20983e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5bef42){return this['scopes']['includes'](_0x5bef42)||this['scopes']['push'](_0x5bef42),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xb8b7ef){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xb8b7ef});}static['credentialFromResult'](_0x9f87f2){return he['credentialFromTaggedObject'](_0x9f87f2);}static['credentialFromError'](_0x377bcf){return he['credentialFromTaggedObject'](_0x377bcf['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e492f}){if(!_0x5e492f||!('oauthAccessToken'in _0x5e492f)||!_0x5e492f['oauthAccessToken'])return null;try{return he['credential'](_0x5e492f['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2fb5ab,_0x1f2a5e){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2fb5ab,'accessToken':_0x1f2a5e});}static['credentialFromResult'](_0x21ee07){return ue['credentialFromTaggedObject'](_0x21ee07);}static['credentialFromError'](_0x4b59b1){return ue['credentialFromTaggedObject'](_0x4b59b1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1c9d63}){if(!_0x1c9d63)return null;const {oauthIdToken:_0x574060,oauthAccessToken:_0x501b12}=_0x1c9d63;if(!_0x574060&&!_0x501b12)return null;try{return ue['credential'](_0x574060,_0x501b12);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x9bf497){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x9bf497});}static['credentialFromResult'](_0xbc3d3b){return de['credentialFromTaggedObject'](_0xbc3d3b);}static['credentialFromError'](_0x5bbe0b){return de['credentialFromTaggedObject'](_0x5bbe0b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4bc710}){if(!_0x4bc710||!('oauthAccessToken'in _0x4bc710)||!_0x4bc710['oauthAccessToken'])return null;try{return de['credential'](_0x4bc710['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x401ec4,_0x3fb1bd){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x401ec4,'oauthTokenSecret':_0x3fb1bd});}static['credentialFromResult'](_0x40a49b){return fe['credentialFromTaggedObject'](_0x40a49b);}static['credentialFromError'](_0x11cb4f){return fe['credentialFromTaggedObject'](_0x11cb4f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd13470}){if(!_0xd13470)return null;const {oauthAccessToken:_0x42f240,oauthTokenSecret:_0x5001af}=_0xd13470;if(!_0x42f240||!_0x5001af)return null;try{return fe['credential'](_0x42f240,_0x5001af);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x2af8bb,_0x483e1d){return Yt(_0x2af8bb,'POST','/v1/accounts:signUp',Re(_0x2af8bb,_0x483e1d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3559ed){this['user']=_0x3559ed['user'],this['providerId']=_0x3559ed['providerId'],this['_tokenResponse']=_0x3559ed['_tokenResponse'],this['operationType']=_0x3559ed['operationType'];}static async['_fromIdTokenResponse'](_0x54bd76,_0x5f2598,_0x2a5017,_0x6ff862=!0x1){const _0xdaf9ab=await z['_fromIdTokenResponse'](_0x54bd76,_0x2a5017,_0x6ff862),_0x552b47=Ar(_0x2a5017);return new Be({'user':_0xdaf9ab,'providerId':_0x552b47,'_tokenResponse':_0x2a5017,'operationType':_0x5f2598});}static async['_forOperation'](_0x1dd617,_0x5d38a2,_0x2e25b8){await _0x1dd617['_updateTokensIfNecessary'](_0x2e25b8,!0x0);const _0x271813=Ar(_0x2e25b8);return new Be({'user':_0x1dd617,'providerId':_0x271813,'_tokenResponse':_0x2e25b8,'operationType':_0x5d38a2});}}function Ar(_0x36f6a3){return _0x36f6a3['providerId']?_0x36f6a3['providerId']:'phoneNumber'in _0x36f6a3?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x1c1d27,_0x1f42be,_0x3be624,_0x267791){super(_0x1f42be['code'],_0x1f42be['message']),this['operationType']=_0x3be624,this['user']=_0x267791,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x1c1d27['name'],'tenantId':_0x1c1d27['tenantId']??void 0x0,'_serverResponse':_0x1f42be['customData']['_serverResponse'],'operationType':_0x3be624};}static['_fromErrorAndOperation'](_0x548a19,_0x50549e,_0x5b1495,_0x823c63){return new Rn(_0x548a19,_0x50549e,_0x5b1495,_0x823c63);}}function Fa(_0x1373a1,_0x20bfc2,_0x4ed204,_0x1877cc){return(_0x20bfc2==='reauthenticate'?_0x4ed204['_getReauthenticationResolver'](_0x1373a1):_0x4ed204['_getIdTokenResponse'](_0x1373a1))['catch'](_0x158866=>{throw _0x158866['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x1373a1,_0x158866,_0x20bfc2,_0x1877cc):_0x158866;});}async function jf(_0x44b7a9,_0x53bc09,_0xfd20a3=!0x1){const _0x5ece83=await xt(_0x44b7a9,_0x53bc09['_linkToIdToken'](_0x44b7a9['auth'],await _0x44b7a9['getIdToken']()),_0xfd20a3);return Be['_forOperation'](_0x44b7a9,'link',_0x5ece83);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2991f1,_0x2959a6,_0x32aa11=!0x1){const {auth:_0x200591}=_0x2991f1;if(H(_0x200591['app']))return Promise['reject'](se(_0x200591));const _0x2f4cee='reauthenticate';try{const _0x41b6c9=await xt(_0x2991f1,Fa(_0x200591,_0x2f4cee,_0x2959a6,_0x2991f1),_0x32aa11);m(_0x41b6c9['idToken'],_0x200591,'internal-error');const _0x2069f7=ws(_0x41b6c9['idToken']);m(_0x2069f7,_0x200591,'internal-error');const {sub:_0xf0581a}=_0x2069f7;return m(_0x2991f1['uid']===_0xf0581a,_0x200591,'user-mismatch'),Be['_forOperation'](_0x2991f1,_0x2f4cee,_0x41b6c9);}catch(_0x33237c){throw(_0x33237c==null?void 0x0:_0x33237c['code'])==='auth/user-not-found'&&K(_0x200591,'user-mismatch'),_0x33237c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4a6fa9,_0x2dfd57,_0x33fd62=!0x1){if(H(_0x4a6fa9['app']))return Promise['reject'](se(_0x4a6fa9));const _0x145aa8='signIn',_0x54d07d=await Fa(_0x4a6fa9,_0x145aa8,_0x2dfd57),_0x1fe1b1=await Be['_fromIdTokenResponse'](_0x4a6fa9,_0x145aa8,_0x54d07d);return _0x33fd62||await _0x4a6fa9['_updateCurrentUser'](_0x1fe1b1['user']),_0x1fe1b1;}async function Yf(_0x559aec,_0x2f8397){return Ua(qe(_0x559aec),_0x2f8397);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x20581e){const _0x23647f=qe(_0x20581e);_0x23647f['_getPasswordPolicyInternal']()&&await _0x23647f['_updatePasswordPolicy']();}async function R_(_0x425b7a,_0x47b184,_0x431acb){if(H(_0x425b7a['app']))return Promise['reject'](se(_0x425b7a));const _0x583438=qe(_0x425b7a),_0x1202be=await Oi(_0x583438,{'returnSecureToken':!0x0,'email':_0x47b184,'password':_0x431acb,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3a49d0=>{throw _0x3a49d0['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x425b7a),_0x3a49d0;}),_0xe99932=await Be['_fromIdTokenResponse'](_0x583438,'signIn',_0x1202be);return await _0x583438['_updateCurrentUser'](_0xe99932['user']),_0xe99932;}function A_(_0x19ce29,_0x4442eb,_0x337af5){return H(_0x19ce29['app'])?Promise['reject'](se(_0x19ce29)):Yf(k(_0x19ce29),ft['credential'](_0x4442eb,_0x337af5))['catch'](async _0x4b0324=>{throw _0x4b0324['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x19ce29),_0x4b0324;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x35e4ef,_0x560b3a){return k(_0x35e4ef)['setPersistence'](_0x560b3a);}function Qf(_0x12212e,_0x62e921,_0x2b71df,_0x23b4a3){return k(_0x12212e)['onIdTokenChanged'](_0x62e921,_0x2b71df,_0x23b4a3);}function Jf(_0x25238d,_0xd44261,_0xae6107){return k(_0x25238d)['beforeAuthStateChanged'](_0xd44261,_0xae6107);}function N_(_0x164818,_0x3ead7d,_0x12eccd,_0x5e77cf){return k(_0x164818)['onAuthStateChanged'](_0x3ead7d,_0x12eccd,_0x5e77cf);}function P_(_0x4acd45){return k(_0x4acd45)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x56c309,_0x23267e){this['storageRetriever']=_0x56c309,this['type']=_0x23267e;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3223d1,_0x14f7b5){return this['storage']['setItem'](_0x3223d1,JSON['stringify'](_0x14f7b5)),Promise['resolve']();}['_get'](_0x9690c0){const _0x1b0b4a=this['storage']['getItem'](_0x9690c0);return Promise['resolve'](_0x1b0b4a?JSON['parse'](_0x1b0b4a):null);}['_remove'](_0x1c6b94){return this['storage']['removeItem'](_0x1c6b94),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x26c6ab,_0xf23fe9)=>this['onStorageEvent'](_0x26c6ab,_0xf23fe9),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x30da7c){for(const _0x45292d of Object['keys'](this['listeners'])){const _0x43df46=this['storage']['getItem'](_0x45292d),_0x27d39f=this['localCache'][_0x45292d];_0x43df46!==_0x27d39f&&_0x30da7c(_0x45292d,_0x27d39f,_0x43df46);}}['onStorageEvent'](_0x290c86,_0x2a0812=!0x1){if(!_0x290c86['key']){this['forAllChangedKeys']((_0x2ccb63,_0x6ea7d,_0x48d660)=>{this['notifyListeners'](_0x2ccb63,_0x48d660);});return;}const _0x5e96cf=_0x290c86['key'];_0x2a0812?this['detachListener']():this['stopPolling']();const _0x432855=()=>{const _0xd1cced=this['storage']['getItem'](_0x5e96cf);!_0x2a0812&&this['localCache'][_0x5e96cf]===_0xd1cced||this['notifyListeners'](_0x5e96cf,_0xd1cced);},_0x2c804c=this['storage']['getItem'](_0x5e96cf);If()&&_0x2c804c!==_0x290c86['newValue']&&_0x290c86['newValue']!==_0x290c86['oldValue']?setTimeout(_0x432855,Zf):_0x432855();}['notifyListeners'](_0x1b27f6,_0x36592c){this['localCache'][_0x1b27f6]=_0x36592c;const _0x38c2bd=this['listeners'][_0x1b27f6];if(_0x38c2bd){for(const _0x1796c8 of Array['from'](_0x38c2bd))_0x1796c8(_0x36592c&&JSON['parse'](_0x36592c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xa28226,_0x39d81c,_0x1288ff)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xa28226,'oldValue':_0x39d81c,'newValue':_0x1288ff}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x5c750a,_0x33467a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x5c750a]||(this['listeners'][_0x5c750a]=new Set(),this['localCache'][_0x5c750a]=this['storage']['getItem'](_0x5c750a)),this['listeners'][_0x5c750a]['add'](_0x33467a);}['_removeListener'](_0x244029,_0x16b6f6){this['listeners'][_0x244029]&&(this['listeners'][_0x244029]['delete'](_0x16b6f6),this['listeners'][_0x244029]['size']===0x0&&delete this['listeners'][_0x244029]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4f19c1,_0x2cd4fd){await super['_set'](_0x4f19c1,_0x2cd4fd),this['localCache'][_0x4f19c1]=JSON['stringify'](_0x2cd4fd);}async['_get'](_0x539b0f){const _0xc48f4c=await super['_get'](_0x539b0f);return this['localCache'][_0x539b0f]=JSON['stringify'](_0xc48f4c),_0xc48f4c;}async['_remove'](_0x20b5b2){await super['_remove'](_0x20b5b2),delete this['localCache'][_0x20b5b2];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3a0d7c,_0x4b0bb3){}['_removeListener'](_0x2a5057,_0x1096b7){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xb9a782){return Promise['all'](_0xb9a782['map'](async _0x5f2f19=>{try{return{'fulfilled':!0x0,'value':await _0x5f2f19};}catch(_0xc0bd3){return{'fulfilled':!0x1,'reason':_0xc0bd3};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1ab4ca){this['eventTarget']=_0x1ab4ca,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x525b5b){const _0x427845=this['receivers']['find'](_0xf27632=>_0xf27632['isListeningto'](_0x525b5b));if(_0x427845)return _0x427845;const _0x2e7871=new jn(_0x525b5b);return this['receivers']['push'](_0x2e7871),_0x2e7871;}['isListeningto'](_0x5d0d8f){return this['eventTarget']===_0x5d0d8f;}async['handleEvent'](_0x37d703){const _0x2eb603=_0x37d703,{eventId:_0x465398,eventType:_0x24b929,data:_0x27b442}=_0x2eb603['data'],_0x52a853=this['handlersMap'][_0x24b929];if(!(_0x52a853!=null&&_0x52a853['size']))return;_0x2eb603['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x465398,'eventType':_0x24b929});const _0x108b21=Array['from'](_0x52a853)['map'](async _0x39e753=>_0x39e753(_0x2eb603['origin'],_0x27b442)),_0x45985e=await tp(_0x108b21);_0x2eb603['ports'][0x0]['postMessage']({'status':'done','eventId':_0x465398,'eventType':_0x24b929,'response':_0x45985e});}['_subscribe'](_0x2b6681,_0xe5591e){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2b6681]||(this['handlersMap'][_0x2b6681]=new Set()),this['handlersMap'][_0x2b6681]['add'](_0xe5591e);}['_unsubscribe'](_0x226ff2,_0x303a1f){this['handlersMap'][_0x226ff2]&&_0x303a1f&&this['handlersMap'][_0x226ff2]['delete'](_0x303a1f),(!_0x303a1f||this['handlersMap'][_0x226ff2]['size']===0x0)&&delete this['handlersMap'][_0x226ff2],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x39d4c3='',_0x2cbcc=0xa){let _0x3873e7='';for(let _0xdeff3=0x0;_0xdeff3<_0x2cbcc;_0xdeff3++)_0x3873e7+=Math['floor'](Math['random']()*0xa);return _0x39d4c3+_0x3873e7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x3a1ba7){this['target']=_0x3a1ba7,this['handlers']=new Set();}['removeMessageHandler'](_0x372ff2){_0x372ff2['messageChannel']&&(_0x372ff2['messageChannel']['port1']['removeEventListener']('message',_0x372ff2['onMessage']),_0x372ff2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x372ff2);}async['_send'](_0x3c95e3,_0x9df36c,_0x3fd4df=0x32){const _0x51a2ea=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x51a2ea)throw new Error('connection_unavailable');let _0x294a3d,_0xfae796;return new Promise((_0x1dac1e,_0x3d2cd6)=>{const _0x1d6632=bs('',0x14);_0x51a2ea['port1']['start']();const _0x3e9cf1=setTimeout(()=>{_0x3d2cd6(new Error('unsupported_event'));},_0x3fd4df);_0xfae796={'messageChannel':_0x51a2ea,'onMessage'(_0x1995a5){const _0x32b61d=_0x1995a5;if(_0x32b61d['data']['eventId']===_0x1d6632)switch(_0x32b61d['data']['status']){case'ack':clearTimeout(_0x3e9cf1),_0x294a3d=setTimeout(()=>{_0x3d2cd6(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x294a3d),_0x1dac1e(_0x32b61d['data']['response']);break;default:clearTimeout(_0x3e9cf1),clearTimeout(_0x294a3d),_0x3d2cd6(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xfae796),_0x51a2ea['port1']['addEventListener']('message',_0xfae796['onMessage']),this['target']['postMessage']({'eventType':_0x3c95e3,'eventId':_0x1d6632,'data':_0x9df36c},[_0x51a2ea['port2']]);})['finally'](()=>{_0xfae796&&this['removeMessageHandler'](_0xfae796);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x78d741){X()['location']['href']=_0x78d741;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0xb082b4;return((_0xb082b4=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xb082b4['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x84e47e){this['request']=_0x84e47e;}['toPromise'](){return new Promise((_0xd0c8cf,_0x2ac48c)=>{this['request']['addEventListener']('success',()=>{_0xd0c8cf(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2ac48c(this['request']['error']);});});}}function Kn(_0x370e6,_0x25d809){return _0x370e6['transaction']([kn],_0x25d809?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x398bdd=indexedDB['deleteDatabase'](qa);return new Jt(_0x398bdd)['toPromise']();}function ja(){const _0x5da298=indexedDB['open'](qa,ap);return new Promise((_0x2cce2f,_0x37ce40)=>{_0x5da298['addEventListener']('error',()=>{_0x37ce40(_0x5da298['error']);}),_0x5da298['addEventListener']('upgradeneeded',()=>{const _0x5e93b4=_0x5da298['result'];try{_0x5e93b4['createObjectStore'](kn,{'keyPath':za});}catch(_0x55cd76){_0x37ce40(_0x55cd76);}}),_0x5da298['addEventListener']('success',async()=>{const _0x174d48=_0x5da298['result'];_0x174d48['objectStoreNames']['contains'](kn)?_0x2cce2f(_0x174d48):(_0x174d48['close'](),await cp(),_0x2cce2f(await ja()));});});}async function kr(_0x3e9c86,_0x52e786,_0x472462){const _0x46fcda=Kn(_0x3e9c86,!0x0)['put']({[za]:_0x52e786,'value':_0x472462});return new Jt(_0x46fcda)['toPromise']();}async function lp(_0x45db0b,_0x3552c6){const _0x11a48c=Kn(_0x45db0b,!0x1)['get'](_0x3552c6),_0x5aef3c=await new Jt(_0x11a48c)['toPromise']();return _0x5aef3c===void 0x0?null:_0x5aef3c['value'];}function Nr(_0x30bbba,_0x565aef){const _0x5cbf4e=Kn(_0x30bbba,!0x0)['delete'](_0x565aef);return new Jt(_0x5cbf4e)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1ad390){let _0x3dc39d=0x0;for(;;)try{const _0x3b27b7=await this['_openDb']();return await _0x1ad390(_0x3b27b7);}catch(_0x594ba1){if(_0x3dc39d++>up)throw _0x594ba1;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x9504b3,_0x53cd76)=>({'keyProcessed':(await this['_poll']())['includes'](_0x53cd76['key'])})),this['receiver']['_subscribe']('ping',async(_0x561808,_0x428273)=>['keyChanged']);}async['initializeSender'](){var _0x82d1dd,_0x229e9e;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x282b91=await this['sender']['_send']('ping',{},0x320);_0x282b91&&(_0x82d1dd=_0x282b91[0x0])!=null&&_0x82d1dd['fulfilled']&&(_0x229e9e=_0x282b91[0x0])!=null&&_0x229e9e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x10d59f){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x10d59f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x53dda9=>{await kr(_0x53dda9,An,'1'),await Nr(_0x53dda9,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4b8d53){this['pendingWrites']++;try{await _0x4b8d53();}finally{this['pendingWrites']--;}}async['_set'](_0x401a43,_0x5a57f5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4f4700=>kr(_0x4f4700,_0x401a43,_0x5a57f5)),this['localCache'][_0x401a43]=_0x5a57f5,this['notifyServiceWorker'](_0x401a43)));}async['_get'](_0xd2ee59){const _0x1d31e8=await this['_withRetries'](_0x3f6f94=>lp(_0x3f6f94,_0xd2ee59));return this['localCache'][_0xd2ee59]=_0x1d31e8,_0x1d31e8;}async['_remove'](_0x5270e7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2ad7dd=>Nr(_0x2ad7dd,_0x5270e7)),delete this['localCache'][_0x5270e7],this['notifyServiceWorker'](_0x5270e7)));}async['_poll'](){const _0x3dfcd3=await this['_withRetries'](_0x2be6d9=>{const _0x9759ce=Kn(_0x2be6d9,!0x1)['getAll']();return new Jt(_0x9759ce)['toPromise']();});if(!_0x3dfcd3)return[];if(this['pendingWrites']!==0x0)return[];const _0x11079e=[],_0x3b0e5c=new Set();if(_0x3dfcd3['length']!==0x0){for(const {fbase_key:_0x38f42b,value:_0x5b2de2}of _0x3dfcd3)_0x3b0e5c['add'](_0x38f42b),JSON['stringify'](this['localCache'][_0x38f42b])!==JSON['stringify'](_0x5b2de2)&&(this['notifyListeners'](_0x38f42b,_0x5b2de2),_0x11079e['push'](_0x38f42b));}for(const _0x296ead of Object['keys'](this['localCache']))this['localCache'][_0x296ead]&&!_0x3b0e5c['has'](_0x296ead)&&(this['notifyListeners'](_0x296ead,null),_0x11079e['push'](_0x296ead));return _0x11079e;}['notifyListeners'](_0x104553,_0x2e7861){this['localCache'][_0x104553]=_0x2e7861;const _0x188b7b=this['listeners'][_0x104553];if(_0x188b7b){for(const _0x17605f of Array['from'](_0x188b7b))_0x17605f(_0x2e7861);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x18f274,_0x2e184e){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x18f274]||(this['listeners'][_0x18f274]=new Set(),this['_get'](_0x18f274)),this['listeners'][_0x18f274]['add'](_0x2e184e);}['_removeListener'](_0x282dc6,_0x30d219){this['listeners'][_0x282dc6]&&(this['listeners'][_0x282dc6]['delete'](_0x30d219),this['listeners'][_0x282dc6]['size']===0x0&&delete this['listeners'][_0x282dc6]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x4bca70,_0x1e2dbc){return _0x1e2dbc?ne(_0x1e2dbc):(m(_0x4bca70['_popupRedirectResolver'],_0x4bca70,'argument-error'),_0x4bca70['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4c07d0){super('custom','custom'),this['params']=_0x4c07d0;}['_getIdTokenResponse'](_0x4e0d58){return Ze(_0x4e0d58,this['_buildIdpRequest']());}['_linkToIdToken'](_0x33b1db,_0x3c59f3){return Ze(_0x33b1db,this['_buildIdpRequest'](_0x3c59f3));}['_getReauthenticationResolver'](_0x10a4f7){return Ze(_0x10a4f7,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x18d5a5){const _0x1618c3={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x18d5a5&&(_0x1618c3['idToken']=_0x18d5a5),_0x1618c3;}}function pp(_0x12cca7){return Ua(_0x12cca7['auth'],new Rs(_0x12cca7),_0x12cca7['bypassAuthState']);}function _p(_0x1a473b){const {auth:_0x450689,user:_0x510964}=_0x1a473b;return m(_0x510964,_0x450689,'internal-error'),Kf(_0x510964,new Rs(_0x1a473b),_0x1a473b['bypassAuthState']);}async function gp(_0x19eb9c){const {auth:_0x39fdfc,user:_0x1a2353}=_0x19eb9c;return m(_0x1a2353,_0x39fdfc,'internal-error'),jf(_0x1a2353,new Rs(_0x19eb9c),_0x19eb9c['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x4ebaca,_0x49f327,_0x67f7be,_0xd1e870,_0x3902e1=!0x1){this['auth']=_0x4ebaca,this['resolver']=_0x67f7be,this['user']=_0xd1e870,this['bypassAuthState']=_0x3902e1,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x49f327)?_0x49f327:[_0x49f327];}['execute'](){return new Promise(async(_0x32a734,_0x30a699)=>{this['pendingPromise']={'resolve':_0x32a734,'reject':_0x30a699};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2f07e5){this['reject'](_0x2f07e5);}});}async['onAuthEvent'](_0x161b19){const {urlResponse:_0x25c522,sessionId:_0x145e91,postBody:_0x51e231,tenantId:_0x286afe,error:_0x566f72,type:_0x22460e}=_0x161b19;if(_0x566f72){this['reject'](_0x566f72);return;}const _0x2c0320={'auth':this['auth'],'requestUri':_0x25c522,'sessionId':_0x145e91,'tenantId':_0x286afe||void 0x0,'postBody':_0x51e231||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x22460e)(_0x2c0320));}catch(_0x249de8){this['reject'](_0x249de8);}}['onError'](_0x2a5884){this['reject'](_0x2a5884);}['getIdpTask'](_0x3c5785){switch(_0x3c5785){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x5404e0){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5404e0),this['unregisterAndCleanUp']();}['reject'](_0x1d450a){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1d450a),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3b1b23,_0x188f3f,_0x5c6380,_0x13a457,_0x96d26c){super(_0x3b1b23,_0x188f3f,_0x13a457,_0x96d26c),this['provider']=_0x5c6380,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x3ec339=await this['execute']();return m(_0x3ec339,this['auth'],'internal-error'),_0x3ec339;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x233286=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x233286),this['authWindow']['associatedEvent']=_0x233286,this['resolver']['_originValidation'](this['auth'])['catch'](_0x480956=>{this['reject'](_0x480956);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1d7e55=>{_0x1d7e55||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2e9173;return((_0x2e9173=this['authWindow'])==null?void 0x0:_0x2e9173['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x134e42=()=>{var _0x2111cc,_0xa2f2c4;if((_0xa2f2c4=(_0x2111cc=this['authWindow'])==null?void 0x0:_0x2111cc['window'])!=null&&_0xa2f2c4['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x134e42,mp['get']());};_0x134e42();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x473682,_0x55c14e,_0x307266=!0x1){super(_0x473682,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x55c14e,void 0x0,_0x307266),this['eventId']=null;}async['execute'](){let _0x1fa2e4=rn['get'](this['auth']['_key']());if(!_0x1fa2e4){try{const _0x140434=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x1fa2e4=()=>Promise['resolve'](_0x140434);}catch(_0x16008b){_0x1fa2e4=()=>Promise['reject'](_0x16008b);}rn['set'](this['auth']['_key'](),_0x1fa2e4);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1fa2e4();}async['onAuthEvent'](_0x12e7c8){if(_0x12e7c8['type']==='signInViaRedirect')return super['onAuthEvent'](_0x12e7c8);if(_0x12e7c8['type']==='unknown'){this['resolve'](null);return;}if(_0x12e7c8['eventId']){const _0x17177e=await this['auth']['_redirectUserForId'](_0x12e7c8['eventId']);if(_0x17177e)return this['user']=_0x17177e,super['onAuthEvent'](_0x12e7c8);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x326d6e,_0x5eb391){const _0x3b08e4=Cp(_0x5eb391),_0x4a51bd=wp(_0x326d6e);if(!await _0x4a51bd['_isAvailable']())return!0x1;const _0xefedba=await _0x4a51bd['_get'](_0x3b08e4)==='true';return await _0x4a51bd['_remove'](_0x3b08e4),_0xefedba;}function Ip(_0x36cc59,_0x21eb76){rn['set'](_0x36cc59['_key'](),_0x21eb76);}function wp(_0xc91948){return ne(_0xc91948['_redirectPersistence']);}function Cp(_0x3cbf12){return sn(yp,_0x3cbf12['config']['apiKey'],_0x3cbf12['name']);}async function Tp(_0x4f1b93,_0x1c8a7d,_0x25a223=!0x1){if(H(_0x4f1b93['app']))return Promise['reject'](se(_0x4f1b93));const _0x2f4528=qe(_0x4f1b93),_0x1e14aa=fp(_0x2f4528,_0x1c8a7d),_0x4759e0=await new vp(_0x2f4528,_0x1e14aa,_0x25a223)['execute']();return _0x4759e0&&!_0x25a223&&(delete _0x4759e0['user']['_redirectEventId'],await _0x2f4528['_persistUserIfCurrent'](_0x4759e0['user']),await _0x2f4528['_setRedirectUser'](null,_0x1c8a7d)),_0x4759e0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x210ac5){this['auth']=_0x210ac5,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4431cd){this['consumers']['add'](_0x4431cd),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4431cd)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4431cd),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1f8c13){this['consumers']['delete'](_0x1f8c13);}['onEvent'](_0x21a7f4){if(this['hasEventBeenHandled'](_0x21a7f4))return!0x1;let _0x30a81c=!0x1;return this['consumers']['forEach'](_0x1a4984=>{this['isEventForConsumer'](_0x21a7f4,_0x1a4984)&&(_0x30a81c=!0x0,this['sendToConsumer'](_0x21a7f4,_0x1a4984),this['saveEventToCache'](_0x21a7f4));}),this['hasHandledPotentialRedirect']||!Rp(_0x21a7f4)||(this['hasHandledPotentialRedirect']=!0x0,_0x30a81c||(this['queuedRedirectEvent']=_0x21a7f4,_0x30a81c=!0x0)),_0x30a81c;}['sendToConsumer'](_0x25bdea,_0x4bec04){var _0x4d6b7a;if(_0x25bdea['error']&&!Qa(_0x25bdea)){const _0x175084=((_0x4d6b7a=_0x25bdea['error']['code'])==null?void 0x0:_0x4d6b7a['split']('auth/')[0x1])||'internal-error';_0x4bec04['onError'](J(this['auth'],_0x175084));}else _0x4bec04['onAuthEvent'](_0x25bdea);}['isEventForConsumer'](_0x57b5f2,_0x56be80){const _0x21371b=_0x56be80['eventId']===null||!!_0x57b5f2['eventId']&&_0x57b5f2['eventId']===_0x56be80['eventId'];return _0x56be80['filter']['includes'](_0x57b5f2['type'])&&_0x21371b;}['hasEventBeenHandled'](_0x136ca0){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x136ca0));}['saveEventToCache'](_0x5ab15b){this['cachedEventUids']['add'](Pr(_0x5ab15b)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x33a509){return[_0x33a509['type'],_0x33a509['eventId'],_0x33a509['sessionId'],_0x33a509['tenantId']]['filter'](_0x46039e=>_0x46039e)['join']('-');}function Qa({type:_0x3da56a,error:_0x53e1b1}){return _0x3da56a==='unknown'&&(_0x53e1b1==null?void 0x0:_0x53e1b1['code'])==='auth/no-auth-event';}function Rp(_0x4cb63c){switch(_0x4cb63c['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4cb63c);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3b1ec3,_0x4a3821={}){return Ae(_0x3b1ec3,'GET','/v1/projects',_0x4a3821);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x155add){if(_0x155add['config']['emulator'])return;const {authorizedDomains:_0x49a081}=await Ap(_0x155add);for(const _0x2dde71 of _0x49a081)try{if(Op(_0x2dde71))return;}catch{}K(_0x155add,'unauthorized-domain');}function Op(_0x2d5fc8){const _0x1547ad=Ni(),{protocol:_0x219f21,hostname:_0x337cd5}=new URL(_0x1547ad);if(_0x2d5fc8['startsWith']('chrome-extension://')){const _0x91ca4b=new URL(_0x2d5fc8);return _0x91ca4b['hostname']===''&&_0x337cd5===''?_0x219f21==='chrome-extension:'&&_0x2d5fc8['replace']('chrome-extension://','')===_0x1547ad['replace']('chrome-extension://',''):_0x219f21==='chrome-extension:'&&_0x91ca4b['hostname']===_0x337cd5;}if(!Np['test'](_0x219f21))return!0x1;if(kp['test'](_0x2d5fc8))return _0x337cd5===_0x2d5fc8;const _0x207037=_0x2d5fc8['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x207037+'|'+_0x207037+')$','i')['test'](_0x337cd5);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x3eaf60=X()['___jsl'];if(_0x3eaf60!=null&&_0x3eaf60['H']){for(const _0x2d97cd of Object['keys'](_0x3eaf60['H']))if(_0x3eaf60['H'][_0x2d97cd]['r']=_0x3eaf60['H'][_0x2d97cd]['r']||[],_0x3eaf60['H'][_0x2d97cd]['L']=_0x3eaf60['H'][_0x2d97cd]['L']||[],_0x3eaf60['H'][_0x2d97cd]['r']=[..._0x3eaf60['H'][_0x2d97cd]['L']],_0x3eaf60['CP']){for(let _0x18a7de=0x0;_0x18a7de<_0x3eaf60['CP']['length'];_0x18a7de++)_0x3eaf60['CP'][_0x18a7de]=null;}}}function Mp(_0x3893ff){return new Promise((_0x32b6f7,_0x3c9f06)=>{var _0x1fda22,_0x42296f,_0x7ef1e0;function _0x1771eb(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x32b6f7(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x3c9f06(J(_0x3893ff,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x42296f=(_0x1fda22=X()['gapi'])==null?void 0x0:_0x1fda22['iframes'])!=null&&_0x42296f['Iframe'])_0x32b6f7(gapi['iframes']['getContext']());else{if((_0x7ef1e0=X()['gapi'])!=null&&_0x7ef1e0['load'])_0x1771eb();else{const _0x36e313=Nf('iframefcb');return X()[_0x36e313]=()=>{gapi['load']?_0x1771eb():_0x3c9f06(J(_0x3893ff,'network-request-failed'));},Da(kf()+'?onload='+_0x36e313)['catch'](_0x36efd3=>_0x3c9f06(_0x36efd3));}}})['catch'](_0x3152a7=>{throw on=null,_0x3152a7;});}let on=null;function Lp(_0x161125){return on=on||Mp(_0x161125),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0xe9be22){const _0x40e163=_0xe9be22['config'];m(_0x40e163['authDomain'],_0xe9be22,'auth-domain-config-required');const _0x1c6969=_0x40e163['emulator']?Is(_0x40e163,Up):'https://'+_0xe9be22['config']['authDomain']+'/'+Fp,_0x4939ec={'apiKey':_0x40e163['apiKey'],'appName':_0xe9be22['name'],'v':ct},_0x23a932=Bp['get'](_0xe9be22['config']['apiHost']);_0x23a932&&(_0x4939ec['eid']=_0x23a932);const _0x2bfb6e=_0xe9be22['_getFrameworks']();return _0x2bfb6e['length']&&(_0x4939ec['fw']=_0x2bfb6e['join'](',')),_0x1c6969+'?'+at(_0x4939ec)['slice'](0x1);}async function Hp(_0x2ca351){const _0x3c2a0f=await Lp(_0x2ca351),_0x592b62=X()['gapi'];return m(_0x592b62,_0x2ca351,'internal-error'),_0x3c2a0f['open']({'where':document['body'],'url':Vp(_0x2ca351),'messageHandlersFilter':_0x592b62['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0xb3d81=>new Promise(async(_0x7ea011,_0xb86a48)=>{await _0xb3d81['restyle']({'setHideOnLeave':!0x1});const _0x47f3a4=J(_0x2ca351,'network-request-failed'),_0x31f3d5=X()['setTimeout'](()=>{_0xb86a48(_0x47f3a4);},xp['get']());function _0x19acd7(){X()['clearTimeout'](_0x31f3d5),_0x7ea011(_0xb3d81);}_0xb3d81['ping'](_0x19acd7)['then'](_0x19acd7,()=>{_0xb86a48(_0x47f3a4);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x599338){this['window']=_0x599338,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x40f749,_0x15a68e,_0x59a1d6,_0xd4b624=Gp,_0x46ac92=qp){const _0x36ab12=Math['max']((window['screen']['availHeight']-_0x46ac92)/0x2,0x0)['toString'](),_0x1e21ea=Math['max']((window['screen']['availWidth']-_0xd4b624)/0x2,0x0)['toString']();let _0x144628='';const _0x317fdd={...$p,'width':_0xd4b624['toString'](),'height':_0x46ac92['toString'](),'top':_0x36ab12,'left':_0x1e21ea},_0x5d346c=W()['toLowerCase']();_0x59a1d6&&(_0x144628=ba(_0x5d346c)?zp:_0x59a1d6),Ta(_0x5d346c)&&(_0x15a68e=_0x15a68e||jp,_0x317fdd['scrollbars']='yes');const _0x4df067=Object['entries'](_0x317fdd)['reduce']((_0x5dbdda,[_0x71d991,_0x41b07f])=>''+_0x5dbdda+_0x71d991+'='+_0x41b07f+',','');if(Ef(_0x5d346c)&&_0x144628!=='_self')return Yp(_0x15a68e||'',_0x144628),new Dr(null);const _0x2addb7=window['open'](_0x15a68e||'',_0x144628,_0x4df067);m(_0x2addb7,_0x40f749,'popup-blocked');try{_0x2addb7['focus']();}catch{}return new Dr(_0x2addb7);}function Yp(_0x20c085,_0x2260bc){const _0x1222ca=document['createElement']('a');_0x1222ca['href']=_0x20c085,_0x1222ca['target']=_0x2260bc;const _0x45e9a7=document['createEvent']('MouseEvent');_0x45e9a7['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1222ca['dispatchEvent'](_0x45e9a7);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x596ff0,_0x5409b5,_0x4b87b2,_0x58f8dc,_0x48295a,_0x4bb6e0){m(_0x596ff0['config']['authDomain'],_0x596ff0,'auth-domain-config-required'),m(_0x596ff0['config']['apiKey'],_0x596ff0,'invalid-api-key');const _0x3e5a91={'apiKey':_0x596ff0['config']['apiKey'],'appName':_0x596ff0['name'],'authType':_0x4b87b2,'redirectUrl':_0x58f8dc,'v':ct,'eventId':_0x48295a};if(_0x5409b5 instanceof xa){_0x5409b5['setDefaultLanguage'](_0x596ff0['languageCode']),_0x3e5a91['providerId']=_0x5409b5['providerId']||'',hi(_0x5409b5['getCustomParameters']())||(_0x3e5a91['customParameters']=JSON['stringify'](_0x5409b5['getCustomParameters']()));for(const [_0x25a430,_0x3b0742]of Object['entries']({}))_0x3e5a91[_0x25a430]=_0x3b0742;}if(_0x5409b5 instanceof Qt){const _0x3fda99=_0x5409b5['getScopes']()['filter'](_0x5ad8a6=>_0x5ad8a6!=='');_0x3fda99['length']>0x0&&(_0x3e5a91['scopes']=_0x3fda99['join'](','));}_0x596ff0['tenantId']&&(_0x3e5a91['tid']=_0x596ff0['tenantId']);const _0x183c16=_0x3e5a91;for(const _0x1255ff of Object['keys'](_0x183c16))_0x183c16[_0x1255ff]===void 0x0&&delete _0x183c16[_0x1255ff];const _0x126c11=await _0x596ff0['_getAppCheckToken'](),_0xd1b7af=_0x126c11?'#'+Xp+'='+encodeURIComponent(_0x126c11):'';return Zp(_0x596ff0)+'?'+at(_0x183c16)['slice'](0x1)+_0xd1b7af;}function Zp({config:_0x268b3b}){return _0x268b3b['emulator']?Is(_0x268b3b,Jp):'https://'+_0x268b3b['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x38dc08,_0x1b4f62,_0x32bd8d,_0x12e136){var _0x216853;ae((_0x216853=this['eventManagers'][_0x38dc08['_key']()])==null?void 0x0:_0x216853['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3527c4=await Mr(_0x38dc08,_0x1b4f62,_0x32bd8d,Ni(),_0x12e136);return Kp(_0x38dc08,_0x3527c4,bs());}async['_openRedirect'](_0x36e3ca,_0x155278,_0x541f59,_0x1e870d){await this['_originValidation'](_0x36e3ca);const _0x5703f0=await Mr(_0x36e3ca,_0x155278,_0x541f59,Ni(),_0x1e870d);return ip(_0x5703f0),new Promise(()=>{});}['_initialize'](_0xda98f6){const _0x37a8ea=_0xda98f6['_key']();if(this['eventManagers'][_0x37a8ea]){const {manager:_0x364ae0,promise:_0x2dc8ef}=this['eventManagers'][_0x37a8ea];return _0x364ae0?Promise['resolve'](_0x364ae0):(ae(_0x2dc8ef,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2dc8ef);}const _0x416ba5=this['initAndGetManager'](_0xda98f6);return this['eventManagers'][_0x37a8ea]={'promise':_0x416ba5},_0x416ba5['catch'](()=>{delete this['eventManagers'][_0x37a8ea];}),_0x416ba5;}async['initAndGetManager'](_0x3c013b){const _0x44961c=await Hp(_0x3c013b),_0x36caf1=new bp(_0x3c013b);return _0x44961c['register']('authEvent',_0x24921a=>(m(_0x24921a==null?void 0x0:_0x24921a['authEvent'],_0x3c013b,'invalid-auth-event'),{'status':_0x36caf1['onEvent'](_0x24921a['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3c013b['_key']()]={'manager':_0x36caf1},this['iframes'][_0x3c013b['_key']()]=_0x44961c,_0x36caf1;}['_isIframeWebStorageSupported'](_0x3b4975,_0x1627e7){this['iframes'][_0x3b4975['_key']()]['send'](li,{'type':li},_0x650d8b=>{var _0x35daf6;const _0x164590=(_0x35daf6=_0x650d8b==null?void 0x0:_0x650d8b[0x0])==null?void 0x0:_0x35daf6[li];_0x164590!==void 0x0&&_0x1627e7(!!_0x164590),K(_0x3b4975,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1d4da5){const _0x64e43b=_0x1d4da5['_key']();return this['originValidationPromises'][_0x64e43b]||(this['originValidationPromises'][_0x64e43b]=Pp(_0x1d4da5)),this['originValidationPromises'][_0x64e43b];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x52fdcd){this['auth']=_0x52fdcd,this['internalListeners']=new Map();}['getUid'](){var _0x2e187d;return this['assertAuthConfigured'](),((_0x2e187d=this['auth']['currentUser'])==null?void 0x0:_0x2e187d['uid'])||null;}async['getToken'](_0x2791c2){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2791c2)}:null;}['addAuthTokenListener'](_0x55c89b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x55c89b))return;const _0xd47995=this['auth']['onIdTokenChanged'](_0x2367df=>{_0x55c89b((_0x2367df==null?void 0x0:_0x2367df['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x55c89b,_0xd47995),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x70e55b){this['assertAuthConfigured']();const _0x1c98cc=this['internalListeners']['get'](_0x70e55b);_0x1c98cc&&(this['internalListeners']['delete'](_0x70e55b),_0x1c98cc(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x51ccc5){switch(_0x51ccc5){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x267d5f){et(new Me('auth',(_0x4c9b03,{options:_0x4031d1})=>{const _0x1c42f3=_0x4c9b03['getProvider']('app')['getImmediate'](),_0x4bb246=_0x4c9b03['getProvider']('heartbeat'),_0x556f84=_0x4c9b03['getProvider']('app-check-internal'),{apiKey:_0x2aeb78,authDomain:_0x463395}=_0x1c42f3['options'];m(_0x2aeb78&&!_0x2aeb78['includes'](':'),'invalid-api-key',{'appName':_0x1c42f3['name']});const _0x36c28b={'apiKey':_0x2aeb78,'authDomain':_0x463395,'clientPlatform':_0x267d5f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x267d5f)},_0x4dec79=new bf(_0x1c42f3,_0x4bb246,_0x556f84,_0x36c28b);return Lf(_0x4dec79,_0x4031d1),_0x4dec79;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x43febd,_0x51d7b7,_0x5eb17d)=>{_0x43febd['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x29dd02=>{const _0x1ef84e=qe(_0x29dd02['getProvider']('auth')['getImmediate']());return(_0x28cfc6=>new n_(_0x28cfc6))(_0x1ef84e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x267d5f)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x55ad3c=>async _0x492a69=>{const _0x14e2f6=_0x492a69&&await _0x492a69['getIdTokenResult'](),_0x5682e5=_0x14e2f6&&(new Date()['getTime']()-Date['parse'](_0x14e2f6['issuedAtTime']))/0x3e8;if(_0x5682e5&&_0x5682e5>o_)return;const _0x7437ed=_0x14e2f6==null?void 0x0:_0x14e2f6['token'];Fr!==_0x7437ed&&(Fr=_0x7437ed,await fetch(_0x55ad3c,{'method':_0x7437ed?'POST':'DELETE','headers':_0x7437ed?{'Authorization':'Bearer\x20'+_0x7437ed}:{}}));};function O_(_0x2b0b15=Qr()){const _0x3d3b7b=Ui(_0x2b0b15,'auth');if(_0x3d3b7b['isInitialized']())return _0x3d3b7b['getImmediate']();const _0x39da21=Mf(_0x2b0b15,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x15e553=Gr('authTokenSyncURL');if(_0x15e553&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xa55723=new URL(_0x15e553,location['origin']);if(location['origin']===_0xa55723['origin']){const _0xf22d3a=a_(_0xa55723['toString']());Jf(_0x39da21,_0xf22d3a,()=>_0xf22d3a(_0x39da21['currentUser'])),Qf(_0x39da21,_0x4876c6=>_0xf22d3a(_0x4876c6));}}const _0x57811c=Hr('auth');return _0x57811c&&xf(_0x39da21,'http://'+_0x57811c),_0x39da21;}function c_(){var _0x4b62f5;return((_0x4b62f5=document['getElementsByTagName']('head'))==null?void 0x0:_0x4b62f5[0x0])??document;}Rf({'loadJS'(_0x26ec80){return new Promise((_0x16fff7,_0x2273f8)=>{const _0x9d3230=document['createElement']('script');_0x9d3230['setAttribute']('src',_0x26ec80),_0x9d3230['onload']=_0x16fff7,_0x9d3230['onerror']=_0x3affc0=>{const _0x557342=J('internal-error');_0x557342['customData']=_0x3affc0,_0x2273f8(_0x557342);},_0x9d3230['type']='text/javascript',_0x9d3230['charset']='UTF-8',c_()['appendChild'](_0x9d3230);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};