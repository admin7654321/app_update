const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3e73b8,_0x109b9c){if(!_0x3e73b8)throw ot(_0x109b9c);},ot=function(_0x221b35){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x221b35);},Wr=function(_0x4d8017){const _0x76cbb7=[];let _0x1611a2=0x0;for(let _0x588d33=0x0;_0x588d33<_0x4d8017['length'];_0x588d33++){let _0x1c604d=_0x4d8017['charCodeAt'](_0x588d33);_0x1c604d<0x80?_0x76cbb7[_0x1611a2++]=_0x1c604d:_0x1c604d<0x800?(_0x76cbb7[_0x1611a2++]=_0x1c604d>>0x6|0xc0,_0x76cbb7[_0x1611a2++]=_0x1c604d&0x3f|0x80):(_0x1c604d&0xfc00)===0xd800&&_0x588d33+0x1<_0x4d8017['length']&&(_0x4d8017['charCodeAt'](_0x588d33+0x1)&0xfc00)===0xdc00?(_0x1c604d=0x10000+((_0x1c604d&0x3ff)<<0xa)+(_0x4d8017['charCodeAt'](++_0x588d33)&0x3ff),_0x76cbb7[_0x1611a2++]=_0x1c604d>>0x12|0xf0,_0x76cbb7[_0x1611a2++]=_0x1c604d>>0xc&0x3f|0x80,_0x76cbb7[_0x1611a2++]=_0x1c604d>>0x6&0x3f|0x80,_0x76cbb7[_0x1611a2++]=_0x1c604d&0x3f|0x80):(_0x76cbb7[_0x1611a2++]=_0x1c604d>>0xc|0xe0,_0x76cbb7[_0x1611a2++]=_0x1c604d>>0x6&0x3f|0x80,_0x76cbb7[_0x1611a2++]=_0x1c604d&0x3f|0x80);}return _0x76cbb7;},Za=function(_0x549cba){const _0x53b478=[];let _0x553b3f=0x0,_0x55c005=0x0;for(;_0x553b3f<_0x549cba['length'];){const _0x24abca=_0x549cba[_0x553b3f++];if(_0x24abca<0x80)_0x53b478[_0x55c005++]=String['fromCharCode'](_0x24abca);else{if(_0x24abca>0xbf&&_0x24abca<0xe0){const _0x2690b3=_0x549cba[_0x553b3f++];_0x53b478[_0x55c005++]=String['fromCharCode']((_0x24abca&0x1f)<<0x6|_0x2690b3&0x3f);}else{if(_0x24abca>0xef&&_0x24abca<0x16d){const _0x15b2e2=_0x549cba[_0x553b3f++],_0x177c8b=_0x549cba[_0x553b3f++],_0x2be27f=_0x549cba[_0x553b3f++],_0xa7ce25=((_0x24abca&0x7)<<0x12|(_0x15b2e2&0x3f)<<0xc|(_0x177c8b&0x3f)<<0x6|_0x2be27f&0x3f)-0x10000;_0x53b478[_0x55c005++]=String['fromCharCode'](0xd800+(_0xa7ce25>>0xa)),_0x53b478[_0x55c005++]=String['fromCharCode'](0xdc00+(_0xa7ce25&0x3ff));}else{const _0x385a70=_0x549cba[_0x553b3f++],_0x58bd09=_0x549cba[_0x553b3f++];_0x53b478[_0x55c005++]=String['fromCharCode']((_0x24abca&0xf)<<0xc|(_0x385a70&0x3f)<<0x6|_0x58bd09&0x3f);}}}}return _0x53b478['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4cbb54,_0x18d270){if(!Array['isArray'](_0x4cbb54))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2736c1=_0x18d270?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2bdac1=[];for(let _0x4623a2=0x0;_0x4623a2<_0x4cbb54['length'];_0x4623a2+=0x3){const _0x304123=_0x4cbb54[_0x4623a2],_0x14609b=_0x4623a2+0x1<_0x4cbb54['length'],_0x4c5865=_0x14609b?_0x4cbb54[_0x4623a2+0x1]:0x0,_0x2e13fc=_0x4623a2+0x2<_0x4cbb54['length'],_0x2cae1e=_0x2e13fc?_0x4cbb54[_0x4623a2+0x2]:0x0,_0x52e45f=_0x304123>>0x2,_0x16ab5e=(_0x304123&0x3)<<0x4|_0x4c5865>>0x4;let _0x5ee76f=(_0x4c5865&0xf)<<0x2|_0x2cae1e>>0x6,_0x45c4a8=_0x2cae1e&0x3f;_0x2e13fc||(_0x45c4a8=0x40,_0x14609b||(_0x5ee76f=0x40)),_0x2bdac1['push'](_0x2736c1[_0x52e45f],_0x2736c1[_0x16ab5e],_0x2736c1[_0x5ee76f],_0x2736c1[_0x45c4a8]);}return _0x2bdac1['join']('');},'encodeString'(_0x23427a,_0x3f9cd0){return this['HAS_NATIVE_SUPPORT']&&!_0x3f9cd0?btoa(_0x23427a):this['encodeByteArray'](Wr(_0x23427a),_0x3f9cd0);},'decodeString'(_0xe790cc,_0x16ec8c){return this['HAS_NATIVE_SUPPORT']&&!_0x16ec8c?atob(_0xe790cc):Za(this['decodeStringToByteArray'](_0xe790cc,_0x16ec8c));},'decodeStringToByteArray'(_0x1055f0,_0x5861f3){this['init_']();const _0x891feb=_0x5861f3?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x570f7f=[];for(let _0x3bd170=0x0;_0x3bd170<_0x1055f0['length'];){const _0x39e08f=_0x891feb[_0x1055f0['charAt'](_0x3bd170++)],_0x215ff6=_0x3bd170<_0x1055f0['length']?_0x891feb[_0x1055f0['charAt'](_0x3bd170)]:0x0;++_0x3bd170;const _0x18dee0=_0x3bd170<_0x1055f0['length']?_0x891feb[_0x1055f0['charAt'](_0x3bd170)]:0x40;++_0x3bd170;const _0x1d536b=_0x3bd170<_0x1055f0['length']?_0x891feb[_0x1055f0['charAt'](_0x3bd170)]:0x40;if(++_0x3bd170,_0x39e08f==null||_0x215ff6==null||_0x18dee0==null||_0x1d536b==null)throw new ec();const _0x40f8b7=_0x39e08f<<0x2|_0x215ff6>>0x4;if(_0x570f7f['push'](_0x40f8b7),_0x18dee0!==0x40){const _0x235d81=_0x215ff6<<0x4&0xf0|_0x18dee0>>0x2;if(_0x570f7f['push'](_0x235d81),_0x1d536b!==0x40){const _0x592fc4=_0x18dee0<<0x6&0xc0|_0x1d536b;_0x570f7f['push'](_0x592fc4);}}}return _0x570f7f;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x76d9c0=0x0;_0x76d9c0<this['ENCODED_VALS']['length'];_0x76d9c0++)this['byteToCharMap_'][_0x76d9c0]=this['ENCODED_VALS']['charAt'](_0x76d9c0),this['charToByteMap_'][this['byteToCharMap_'][_0x76d9c0]]=_0x76d9c0,this['byteToCharMapWebSafe_'][_0x76d9c0]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x76d9c0),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x76d9c0]]=_0x76d9c0,_0x76d9c0>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x76d9c0)]=_0x76d9c0,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x76d9c0)]=_0x76d9c0);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x227fb4){const _0x189aa8=Wr(_0x227fb4);return Di['encodeByteArray'](_0x189aa8,!0x0);},an=function(_0x5931c5){return Br(_0x5931c5)['replace'](/\./g,'');},cn=function(_0x537924){try{return Di['decodeString'](_0x537924,!0x0);}catch(_0x510e15){console['error']('base64Decode\x20failed:\x20',_0x510e15);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x350539){return Vr(void 0x0,_0x350539);}function Vr(_0x47bf57,_0x1138aa){if(!(_0x1138aa instanceof Object))return _0x1138aa;switch(_0x1138aa['constructor']){case Date:const _0x512c96=_0x1138aa;return new Date(_0x512c96['getTime']());case Object:_0x47bf57===void 0x0&&(_0x47bf57={});break;case Array:_0x47bf57=[];break;default:return _0x1138aa;}for(const _0x3faab5 in _0x1138aa)!_0x1138aa['hasOwnProperty'](_0x3faab5)||!nc(_0x3faab5)||(_0x47bf57[_0x3faab5]=Vr(_0x47bf57[_0x3faab5],_0x1138aa[_0x3faab5]));return _0x47bf57;}function nc(_0x38c445){return _0x38c445!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x46abfc=As['__FIREBASE_DEFAULTS__'];if(_0x46abfc)return JSON['parse'](_0x46abfc);},oc=()=>{if(typeof document>'u')return;let _0xf6a03;try{_0xf6a03=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x43d0d4=_0xf6a03&&cn(_0xf6a03[0x1]);return _0x43d0d4&&JSON['parse'](_0x43d0d4);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x429be6){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x429be6);return;}},Hr=_0x23a91f=>{var _0x5b99c5,_0x463316;return(_0x463316=(_0x5b99c5=Mi())==null?void 0x0:_0x5b99c5['emulatorHosts'])==null?void 0x0:_0x463316[_0x23a91f];},ac=_0x3d1cdc=>{const _0x464262=Hr(_0x3d1cdc);if(!_0x464262)return;const _0x679e0a=_0x464262['lastIndexOf'](':');if(_0x679e0a<=0x0||_0x679e0a+0x1===_0x464262['length'])throw new Error('Invalid\x20host\x20'+_0x464262+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x194151=parseInt(_0x464262['substring'](_0x679e0a+0x1),0xa);return _0x464262[0x0]==='['?[_0x464262['substring'](0x1,_0x679e0a-0x1),_0x194151]:[_0x464262['substring'](0x0,_0x679e0a),_0x194151];},$r=()=>{var _0x57961a;return(_0x57961a=Mi())==null?void 0x0:_0x57961a['config'];},Gr=_0x4dd271=>{var _0x51dcc3;return(_0x51dcc3=Mi())==null?void 0x0:_0x51dcc3['_'+_0x4dd271];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3dcbaa,_0x490edc)=>{this['resolve']=_0x3dcbaa,this['reject']=_0x490edc;});}['wrapCallback'](_0x31a570){return(_0x331229,_0x50738f)=>{_0x331229?this['reject'](_0x331229):this['resolve'](_0x50738f),typeof _0x31a570=='function'&&(this['promise']['catch'](()=>{}),_0x31a570['length']===0x1?_0x31a570(_0x331229):_0x31a570(_0x331229,_0x50738f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x210d16,_0x445646){if(_0x210d16['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4c51c8={'alg':'none','type':'JWT'},_0x4186dc=_0x445646||'demo-project',_0x2d4c38=_0x210d16['iat']||0x0,_0x25dd21=_0x210d16['sub']||_0x210d16['user_id'];if(!_0x25dd21)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4ac99c={'iss':'https://securetoken.google.com/'+_0x4186dc,'aud':_0x4186dc,'iat':_0x2d4c38,'exp':_0x2d4c38+0xe10,'auth_time':_0x2d4c38,'sub':_0x25dd21,'user_id':_0x25dd21,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x210d16};return[an(JSON['stringify'](_0x4c51c8)),an(JSON['stringify'](_0x4ac99c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x113761=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x113761=='object'&&_0x113761['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x2bd657=W();return _0x2bd657['indexOf']('MSIE\x20')>=0x0||_0x2bd657['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x2b6f38,_0x45323f)=>{try{let _0x127240=!0x0;const _0xa193a='validate-browser-context-for-indexeddb-analytics-module',_0x2c22c0=self['indexedDB']['open'](_0xa193a);_0x2c22c0['onsuccess']=()=>{_0x2c22c0['result']['close'](),_0x127240||self['indexedDB']['deleteDatabase'](_0xa193a),_0x2b6f38(!0x0);},_0x2c22c0['onupgradeneeded']=()=>{_0x127240=!0x1;},_0x2c22c0['onerror']=()=>{var _0x5bdd3e;_0x45323f(((_0x5bdd3e=_0x2c22c0['error'])==null?void 0x0:_0x5bdd3e['message'])||'');};}catch(_0x4d429f){_0x45323f(_0x4d429f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x24adee,_0x27569a,_0x1bb635){super(_0x27569a),this['code']=_0x24adee,this['customData']=_0x1bb635,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x380b76,_0x38dd27,_0xea4474){this['service']=_0x380b76,this['serviceName']=_0x38dd27,this['errors']=_0xea4474;}['create'](_0xd95f0d,..._0x4e9123){const _0x2145e4=_0x4e9123[0x0]||{},_0x2fca5f=this['service']+'/'+_0xd95f0d,_0x39e0b1=this['errors'][_0xd95f0d],_0x5e7fd1=_0x39e0b1?gc(_0x39e0b1,_0x2145e4):'Error',_0x3378d=this['serviceName']+':\x20'+_0x5e7fd1+'\x20('+_0x2fca5f+').';return new Se(_0x2fca5f,_0x3378d,_0x2145e4);}}function gc(_0x52fb44,_0x4f3ae3){return _0x52fb44['replace'](mc,(_0x2f4ed4,_0x51c699)=>{const _0x4b947e=_0x4f3ae3[_0x51c699];return _0x4b947e!=null?String(_0x4b947e):'<'+_0x51c699+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x2e8457){return JSON['parse'](_0x2e8457);}function O(_0x570505){return JSON['stringify'](_0x570505);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x367c6b){let _0x5b37fc={},_0x517b91={},_0x1d99b9={},_0x55f0ff='';try{const _0x547adb=_0x367c6b['split']('.');_0x5b37fc=bt(cn(_0x547adb[0x0])||''),_0x517b91=bt(cn(_0x547adb[0x1])||''),_0x55f0ff=_0x547adb[0x2],_0x1d99b9=_0x517b91['d']||{},delete _0x517b91['d'];}catch{}return{'header':_0x5b37fc,'claims':_0x517b91,'data':_0x1d99b9,'signature':_0x55f0ff};},yc=function(_0x4c7e81){const _0x4c0bbd=zr(_0x4c7e81),_0x4a574a=_0x4c0bbd['claims'];return!!_0x4a574a&&typeof _0x4a574a=='object'&&_0x4a574a['hasOwnProperty']('iat');},vc=function(_0x46d17c){const _0xa1c68f=zr(_0x46d17c)['claims'];return typeof _0xa1c68f=='object'&&_0xa1c68f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x563e67,_0x42354d){return Object['prototype']['hasOwnProperty']['call'](_0x563e67,_0x42354d);}function Oe(_0x4413d2,_0x395b40){if(Object['prototype']['hasOwnProperty']['call'](_0x4413d2,_0x395b40))return _0x4413d2[_0x395b40];}function hi(_0xc6f3e1){for(const _0x1a19f4 in _0xc6f3e1)if(Object['prototype']['hasOwnProperty']['call'](_0xc6f3e1,_0x1a19f4))return!0x1;return!0x0;}function ln(_0x231860,_0xe8f1da,_0x570301){const _0x35e300={};for(const _0x2b0855 in _0x231860)Object['prototype']['hasOwnProperty']['call'](_0x231860,_0x2b0855)&&(_0x35e300[_0x2b0855]=_0xe8f1da['call'](_0x570301,_0x231860[_0x2b0855],_0x2b0855,_0x231860));return _0x35e300;}function De(_0x270e27,_0x2df72e){if(_0x270e27===_0x2df72e)return!0x0;const _0x12eccd=Object['keys'](_0x270e27),_0x220bc7=Object['keys'](_0x2df72e);for(const _0x56667e of _0x12eccd){if(!_0x220bc7['includes'](_0x56667e))return!0x1;const _0x2ba38b=_0x270e27[_0x56667e],_0x50e4f9=_0x2df72e[_0x56667e];if(ks(_0x2ba38b)&&ks(_0x50e4f9)){if(!De(_0x2ba38b,_0x50e4f9))return!0x1;}else{if(_0x2ba38b!==_0x50e4f9)return!0x1;}}for(const _0x5146ab of _0x220bc7)if(!_0x12eccd['includes'](_0x5146ab))return!0x1;return!0x0;}function ks(_0xad3519){return _0xad3519!==null&&typeof _0xad3519=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3d7350){const _0xde766f=[];for(const [_0x216164,_0x25e982]of Object['entries'](_0x3d7350))Array['isArray'](_0x25e982)?_0x25e982['forEach'](_0x11b1b7=>{_0xde766f['push'](encodeURIComponent(_0x216164)+'='+encodeURIComponent(_0x11b1b7));}):_0xde766f['push'](encodeURIComponent(_0x216164)+'='+encodeURIComponent(_0x25e982));return _0xde766f['length']?'&'+_0xde766f['join']('&'):'';}function yt(_0x31a03b){const _0x5740d8={};return _0x31a03b['replace'](/^\?/,'')['split']('&')['forEach'](_0x1c2658=>{if(_0x1c2658){const [_0x4baedc,_0x2d6d3b]=_0x1c2658['split']('=');_0x5740d8[decodeURIComponent(_0x4baedc)]=decodeURIComponent(_0x2d6d3b);}}),_0x5740d8;}function vt(_0x36d8e8){const _0x460518=_0x36d8e8['indexOf']('?');if(!_0x460518)return'';const _0xd0b49f=_0x36d8e8['indexOf']('#',_0x460518);return _0x36d8e8['substring'](_0x460518,_0xd0b49f>0x0?_0xd0b49f:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3d123d=0x1;_0x3d123d<this['blockSize'];++_0x3d123d)this['pad_'][_0x3d123d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1b1f26,_0x4bd242){_0x4bd242||(_0x4bd242=0x0);const _0x51a46e=this['W_'];if(typeof _0x1b1f26=='string'){for(let _0x33aa49=0x0;_0x33aa49<0x10;_0x33aa49++)_0x51a46e[_0x33aa49]=_0x1b1f26['charCodeAt'](_0x4bd242)<<0x18|_0x1b1f26['charCodeAt'](_0x4bd242+0x1)<<0x10|_0x1b1f26['charCodeAt'](_0x4bd242+0x2)<<0x8|_0x1b1f26['charCodeAt'](_0x4bd242+0x3),_0x4bd242+=0x4;}else{for(let _0x2da975=0x0;_0x2da975<0x10;_0x2da975++)_0x51a46e[_0x2da975]=_0x1b1f26[_0x4bd242]<<0x18|_0x1b1f26[_0x4bd242+0x1]<<0x10|_0x1b1f26[_0x4bd242+0x2]<<0x8|_0x1b1f26[_0x4bd242+0x3],_0x4bd242+=0x4;}for(let _0x97bc02=0x10;_0x97bc02<0x50;_0x97bc02++){const _0x3c78c7=_0x51a46e[_0x97bc02-0x3]^_0x51a46e[_0x97bc02-0x8]^_0x51a46e[_0x97bc02-0xe]^_0x51a46e[_0x97bc02-0x10];_0x51a46e[_0x97bc02]=(_0x3c78c7<<0x1|_0x3c78c7>>>0x1f)&0xffffffff;}let _0x22cb99=this['chain_'][0x0],_0x5ab4a5=this['chain_'][0x1],_0x3796e0=this['chain_'][0x2],_0x4b139e=this['chain_'][0x3],_0x46c1eb=this['chain_'][0x4],_0x4929c0,_0x222d0c;for(let _0x2c0bd7=0x0;_0x2c0bd7<0x50;_0x2c0bd7++){_0x2c0bd7<0x28?_0x2c0bd7<0x14?(_0x4929c0=_0x4b139e^_0x5ab4a5&(_0x3796e0^_0x4b139e),_0x222d0c=0x5a827999):(_0x4929c0=_0x5ab4a5^_0x3796e0^_0x4b139e,_0x222d0c=0x6ed9eba1):_0x2c0bd7<0x3c?(_0x4929c0=_0x5ab4a5&_0x3796e0|_0x4b139e&(_0x5ab4a5|_0x3796e0),_0x222d0c=0x8f1bbcdc):(_0x4929c0=_0x5ab4a5^_0x3796e0^_0x4b139e,_0x222d0c=0xca62c1d6);const _0x1b6501=(_0x22cb99<<0x5|_0x22cb99>>>0x1b)+_0x4929c0+_0x46c1eb+_0x222d0c+_0x51a46e[_0x2c0bd7]&0xffffffff;_0x46c1eb=_0x4b139e,_0x4b139e=_0x3796e0,_0x3796e0=(_0x5ab4a5<<0x1e|_0x5ab4a5>>>0x2)&0xffffffff,_0x5ab4a5=_0x22cb99,_0x22cb99=_0x1b6501;}this['chain_'][0x0]=this['chain_'][0x0]+_0x22cb99&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5ab4a5&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3796e0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4b139e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x46c1eb&0xffffffff;}['update'](_0x5dcc51,_0x2c5aea){if(_0x5dcc51==null)return;_0x2c5aea===void 0x0&&(_0x2c5aea=_0x5dcc51['length']);const _0x462cde=_0x2c5aea-this['blockSize'];let _0x1cbb48=0x0;const _0x7f28fd=this['buf_'];let _0x395ddf=this['inbuf_'];for(;_0x1cbb48<_0x2c5aea;){if(_0x395ddf===0x0){for(;_0x1cbb48<=_0x462cde;)this['compress_'](_0x5dcc51,_0x1cbb48),_0x1cbb48+=this['blockSize'];}if(typeof _0x5dcc51=='string'){for(;_0x1cbb48<_0x2c5aea;)if(_0x7f28fd[_0x395ddf]=_0x5dcc51['charCodeAt'](_0x1cbb48),++_0x395ddf,++_0x1cbb48,_0x395ddf===this['blockSize']){this['compress_'](_0x7f28fd),_0x395ddf=0x0;break;}}else{for(;_0x1cbb48<_0x2c5aea;)if(_0x7f28fd[_0x395ddf]=_0x5dcc51[_0x1cbb48],++_0x395ddf,++_0x1cbb48,_0x395ddf===this['blockSize']){this['compress_'](_0x7f28fd),_0x395ddf=0x0;break;}}}this['inbuf_']=_0x395ddf,this['total_']+=_0x2c5aea;}['digest'](){const _0x59d1df=[];let _0x33b2f0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3d01c5=this['blockSize']-0x1;_0x3d01c5>=0x38;_0x3d01c5--)this['buf_'][_0x3d01c5]=_0x33b2f0&0xff,_0x33b2f0/=0x100;this['compress_'](this['buf_']);let _0x19c543=0x0;for(let _0x202ab6=0x0;_0x202ab6<0x5;_0x202ab6++)for(let _0x24b52c=0x18;_0x24b52c>=0x0;_0x24b52c-=0x8)_0x59d1df[_0x19c543]=this['chain_'][_0x202ab6]>>_0x24b52c&0xff,++_0x19c543;return _0x59d1df;}}function Ic(_0x1b84ca,_0x4dd86a){const _0x7591f=new wc(_0x1b84ca,_0x4dd86a);return _0x7591f['subscribe']['bind'](_0x7591f);}class wc{constructor(_0x1b1eae,_0x1984ff){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1984ff,this['task']['then'](()=>{_0x1b1eae(this);})['catch'](_0x4b53bb=>{this['error'](_0x4b53bb);});}['next'](_0x14e955){this['forEachObserver'](_0x22921e=>{_0x22921e['next'](_0x14e955);});}['error'](_0x9a59c2){this['forEachObserver'](_0x477e5b=>{_0x477e5b['error'](_0x9a59c2);}),this['close'](_0x9a59c2);}['complete'](){this['forEachObserver'](_0x18924d=>{_0x18924d['complete']();}),this['close']();}['subscribe'](_0x4db950,_0x4e8608,_0x685514){let _0x5f1f33;if(_0x4db950===void 0x0&&_0x4e8608===void 0x0&&_0x685514===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4db950,['next','error','complete'])?_0x5f1f33=_0x4db950:_0x5f1f33={'next':_0x4db950,'error':_0x4e8608,'complete':_0x685514},_0x5f1f33['next']===void 0x0&&(_0x5f1f33['next']=Qn),_0x5f1f33['error']===void 0x0&&(_0x5f1f33['error']=Qn),_0x5f1f33['complete']===void 0x0&&(_0x5f1f33['complete']=Qn);const _0xe180c4=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5f1f33['error'](this['finalError']):_0x5f1f33['complete']();}catch{}}),this['observers']['push'](_0x5f1f33),_0xe180c4;}['unsubscribeOne'](_0x24cf63){this['observers']===void 0x0||this['observers'][_0x24cf63]===void 0x0||(delete this['observers'][_0x24cf63],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x265063){if(!this['finalized']){for(let _0x22c756=0x0;_0x22c756<this['observers']['length'];_0x22c756++)this['sendOne'](_0x22c756,_0x265063);}}['sendOne'](_0x5f40b3,_0x46a55e){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5f40b3]!==void 0x0)try{_0x46a55e(this['observers'][_0x5f40b3]);}catch(_0x900c47){typeof console<'u'&&console['error']&&console['error'](_0x900c47);}});}['close'](_0x290b9f){this['finalized']||(this['finalized']=!0x0,_0x290b9f!==void 0x0&&(this['finalError']=_0x290b9f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x84cacb,_0x20c692){if(typeof _0x84cacb!='object'||_0x84cacb===null)return!0x1;for(const _0x364446 of _0x20c692)if(_0x364446 in _0x84cacb&&typeof _0x84cacb[_0x364446]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x578feb,_0x174f16){return _0x578feb+'\x20failed:\x20'+_0x174f16+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x554d59){const _0x86116e=[];let _0x4ac372=0x0;for(let _0x1e7045=0x0;_0x1e7045<_0x554d59['length'];_0x1e7045++){let _0x6c31eb=_0x554d59['charCodeAt'](_0x1e7045);if(_0x6c31eb>=0xd800&&_0x6c31eb<=0xdbff){const _0x1c7504=_0x6c31eb-0xd800;_0x1e7045++,f(_0x1e7045<_0x554d59['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x572952=_0x554d59['charCodeAt'](_0x1e7045)-0xdc00;_0x6c31eb=0x10000+(_0x1c7504<<0xa)+_0x572952;}_0x6c31eb<0x80?_0x86116e[_0x4ac372++]=_0x6c31eb:_0x6c31eb<0x800?(_0x86116e[_0x4ac372++]=_0x6c31eb>>0x6|0xc0,_0x86116e[_0x4ac372++]=_0x6c31eb&0x3f|0x80):_0x6c31eb<0x10000?(_0x86116e[_0x4ac372++]=_0x6c31eb>>0xc|0xe0,_0x86116e[_0x4ac372++]=_0x6c31eb>>0x6&0x3f|0x80,_0x86116e[_0x4ac372++]=_0x6c31eb&0x3f|0x80):(_0x86116e[_0x4ac372++]=_0x6c31eb>>0x12|0xf0,_0x86116e[_0x4ac372++]=_0x6c31eb>>0xc&0x3f|0x80,_0x86116e[_0x4ac372++]=_0x6c31eb>>0x6&0x3f|0x80,_0x86116e[_0x4ac372++]=_0x6c31eb&0x3f|0x80);}return _0x86116e;},Pn=function(_0x2fe311){let _0x258587=0x0;for(let _0x57fcd1=0x0;_0x57fcd1<_0x2fe311['length'];_0x57fcd1++){const _0x15e711=_0x2fe311['charCodeAt'](_0x57fcd1);_0x15e711<0x80?_0x258587++:_0x15e711<0x800?_0x258587+=0x2:_0x15e711>=0xd800&&_0x15e711<=0xdbff?(_0x258587+=0x4,_0x57fcd1++):_0x258587+=0x3;}return _0x258587;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x3e6ef8){return _0x3e6ef8&&_0x3e6ef8['_delegate']?_0x3e6ef8['_delegate']:_0x3e6ef8;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x414d46){try{return(_0x414d46['startsWith']('http://')||_0x414d46['startsWith']('https://')?new URL(_0x414d46)['hostname']:_0x414d46)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x183047){return(await fetch(_0x183047,{'credentials':'include'}))['ok'];}class Me{constructor(_0x1de0b9,_0x487fef,_0x142efe){this['name']=_0x1de0b9,this['instanceFactory']=_0x487fef,this['type']=_0x142efe,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4fbf2a){return this['instantiationMode']=_0x4fbf2a,this;}['setMultipleInstances'](_0x410761){return this['multipleInstances']=_0x410761,this;}['setServiceProps'](_0x326653){return this['serviceProps']=_0x326653,this;}['setInstanceCreatedCallback'](_0x1d3633){return this['onInstanceCreated']=_0x1d3633,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x2c255c,_0x437cfd){this['name']=_0x2c255c,this['container']=_0x437cfd,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x30c1fa){const _0x143927=this['normalizeInstanceIdentifier'](_0x30c1fa);if(!this['instancesDeferred']['has'](_0x143927)){const _0x2062d6=new Ve();if(this['instancesDeferred']['set'](_0x143927,_0x2062d6),this['isInitialized'](_0x143927)||this['shouldAutoInitialize']())try{const _0xf8352f=this['getOrInitializeService']({'instanceIdentifier':_0x143927});_0xf8352f&&_0x2062d6['resolve'](_0xf8352f);}catch{}}return this['instancesDeferred']['get'](_0x143927)['promise'];}['getImmediate'](_0x260aa4){const _0x41e17a=this['normalizeInstanceIdentifier'](_0x260aa4==null?void 0x0:_0x260aa4['identifier']),_0x2fef70=(_0x260aa4==null?void 0x0:_0x260aa4['optional'])??!0x1;if(this['isInitialized'](_0x41e17a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x41e17a});}catch(_0x4e572d){if(_0x2fef70)return null;throw _0x4e572d;}else{if(_0x2fef70)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x210bf6){if(_0x210bf6['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x210bf6['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x210bf6,!!this['shouldAutoInitialize']()){if(Rc(_0x210bf6))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5e2c90,_0x3fef63]of this['instancesDeferred']['entries']()){const _0x2f87c6=this['normalizeInstanceIdentifier'](_0x5e2c90);try{const _0x2fb0fa=this['getOrInitializeService']({'instanceIdentifier':_0x2f87c6});_0x3fef63['resolve'](_0x2fb0fa);}catch{}}}}['clearInstance'](_0xadb1ea=ke){this['instancesDeferred']['delete'](_0xadb1ea),this['instancesOptions']['delete'](_0xadb1ea),this['instances']['delete'](_0xadb1ea);}async['delete'](){const _0x56fd92=Array['from'](this['instances']['values']());await Promise['all']([..._0x56fd92['filter'](_0x5dd81f=>'INTERNAL'in _0x5dd81f)['map'](_0x36e4af=>_0x36e4af['INTERNAL']['delete']()),..._0x56fd92['filter'](_0x20a9e7=>'_delete'in _0x20a9e7)['map'](_0xb57fd6=>_0xb57fd6['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x387b0f=ke){return this['instances']['has'](_0x387b0f);}['getOptions'](_0x3a8621=ke){return this['instancesOptions']['get'](_0x3a8621)||{};}['initialize'](_0x277153={}){const {options:_0x270766={}}=_0x277153,_0x1f4135=this['normalizeInstanceIdentifier'](_0x277153['instanceIdentifier']);if(this['isInitialized'](_0x1f4135))throw Error(this['name']+'('+_0x1f4135+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5627f2=this['getOrInitializeService']({'instanceIdentifier':_0x1f4135,'options':_0x270766});for(const [_0x34bfcf,_0x1f4e94]of this['instancesDeferred']['entries']()){const _0x5d04e7=this['normalizeInstanceIdentifier'](_0x34bfcf);_0x1f4135===_0x5d04e7&&_0x1f4e94['resolve'](_0x5627f2);}return _0x5627f2;}['onInit'](_0x253731,_0x324764){const _0x31d570=this['normalizeInstanceIdentifier'](_0x324764),_0x201559=this['onInitCallbacks']['get'](_0x31d570)??new Set();_0x201559['add'](_0x253731),this['onInitCallbacks']['set'](_0x31d570,_0x201559);const _0x4fa908=this['instances']['get'](_0x31d570);return _0x4fa908&&_0x253731(_0x4fa908,_0x31d570),()=>{_0x201559['delete'](_0x253731);};}['invokeOnInitCallbacks'](_0x539e3a,_0x4a7e81){const _0x5e6a9c=this['onInitCallbacks']['get'](_0x4a7e81);if(_0x5e6a9c){for(const _0x2d9006 of _0x5e6a9c)try{_0x2d9006(_0x539e3a,_0x4a7e81);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4d16a8,options:_0x354b7a={}}){let _0x5b7f66=this['instances']['get'](_0x4d16a8);if(!_0x5b7f66&&this['component']&&(_0x5b7f66=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4d16a8),'options':_0x354b7a}),this['instances']['set'](_0x4d16a8,_0x5b7f66),this['instancesOptions']['set'](_0x4d16a8,_0x354b7a),this['invokeOnInitCallbacks'](_0x5b7f66,_0x4d16a8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4d16a8,_0x5b7f66);}catch{}return _0x5b7f66||null;}['normalizeInstanceIdentifier'](_0x156191=ke){return this['component']?this['component']['multipleInstances']?_0x156191:ke:_0x156191;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x326534){return _0x326534===ke?void 0x0:_0x326534;}function Rc(_0x1c422f){return _0x1c422f['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x36aa2b){this['name']=_0x36aa2b,this['providers']=new Map();}['addComponent'](_0x417655){const _0x3be3a0=this['getProvider'](_0x417655['name']);if(_0x3be3a0['isComponentSet']())throw new Error('Component\x20'+_0x417655['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3be3a0['setComponent'](_0x417655);}['addOrOverwriteComponent'](_0xe869e3){this['getProvider'](_0xe869e3['name'])['isComponentSet']()&&this['providers']['delete'](_0xe869e3['name']),this['addComponent'](_0xe869e3);}['getProvider'](_0x18a8cb){if(this['providers']['has'](_0x18a8cb))return this['providers']['get'](_0x18a8cb);const _0x4b917a=new Sc(_0x18a8cb,this);return this['providers']['set'](_0x18a8cb,_0x4b917a),_0x4b917a;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2e46d0){_0x2e46d0[_0x2e46d0['DEBUG']=0x0]='DEBUG',_0x2e46d0[_0x2e46d0['VERBOSE']=0x1]='VERBOSE',_0x2e46d0[_0x2e46d0['INFO']=0x2]='INFO',_0x2e46d0[_0x2e46d0['WARN']=0x3]='WARN',_0x2e46d0[_0x2e46d0['ERROR']=0x4]='ERROR',_0x2e46d0[_0x2e46d0['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xf132ba,_0x28fd91,..._0x1a08ee)=>{if(_0x28fd91<_0xf132ba['logLevel'])return;const _0x16864d=new Date()['toISOString'](),_0x5c7009=Pc[_0x28fd91];if(_0x5c7009)console[_0x5c7009]('['+_0x16864d+']\x20\x20'+_0xf132ba['name']+':',..._0x1a08ee);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x28fd91+')');};class xi{constructor(_0x377a38){this['name']=_0x377a38,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x26a696){if(!(_0x26a696 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x26a696+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x26a696;}['setLogLevel'](_0x427912){this['_logLevel']=typeof _0x427912=='string'?kc[_0x427912]:_0x427912;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x136694){if(typeof _0x136694!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x136694;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x442dad){this['_userLogHandler']=_0x442dad;}['debug'](..._0x179b9f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x179b9f),this['_logHandler'](this,T['DEBUG'],..._0x179b9f);}['log'](..._0x3e62e6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3e62e6),this['_logHandler'](this,T['VERBOSE'],..._0x3e62e6);}['info'](..._0x44594e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x44594e),this['_logHandler'](this,T['INFO'],..._0x44594e);}['warn'](..._0xe8b3a6){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xe8b3a6),this['_logHandler'](this,T['WARN'],..._0xe8b3a6);}['error'](..._0x6f01fc){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x6f01fc),this['_logHandler'](this,T['ERROR'],..._0x6f01fc);}}const Dc=(_0x17a83a,_0x365235)=>_0x365235['some'](_0x205d9d=>_0x17a83a instanceof _0x205d9d);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x418914){const _0x365667=new Promise((_0x2abb80,_0x4e9d12)=>{const _0x19a321=()=>{_0x418914['removeEventListener']('success',_0x4134d7),_0x418914['removeEventListener']('error',_0x34c44e);},_0x4134d7=()=>{_0x2abb80(_e(_0x418914['result'])),_0x19a321();},_0x34c44e=()=>{_0x4e9d12(_0x418914['error']),_0x19a321();};_0x418914['addEventListener']('success',_0x4134d7),_0x418914['addEventListener']('error',_0x34c44e);});return _0x365667['then'](_0x2c410e=>{_0x2c410e instanceof IDBCursor&&Kr['set'](_0x2c410e,_0x418914);})['catch'](()=>{}),Fi['set'](_0x365667,_0x418914),_0x365667;}function Fc(_0x28ef3f){if(ui['has'](_0x28ef3f))return;const _0x3d85d4=new Promise((_0x3ff167,_0x5d004f)=>{const _0xc9282f=()=>{_0x28ef3f['removeEventListener']('complete',_0xfff9a4),_0x28ef3f['removeEventListener']('error',_0x278190),_0x28ef3f['removeEventListener']('abort',_0x278190);},_0xfff9a4=()=>{_0x3ff167(),_0xc9282f();},_0x278190=()=>{_0x5d004f(_0x28ef3f['error']||new DOMException('AbortError','AbortError')),_0xc9282f();};_0x28ef3f['addEventListener']('complete',_0xfff9a4),_0x28ef3f['addEventListener']('error',_0x278190),_0x28ef3f['addEventListener']('abort',_0x278190);});ui['set'](_0x28ef3f,_0x3d85d4);}let di={'get'(_0x2ac583,_0x407053,_0x2a12c9){if(_0x2ac583 instanceof IDBTransaction){if(_0x407053==='done')return ui['get'](_0x2ac583);if(_0x407053==='objectStoreNames')return _0x2ac583['objectStoreNames']||Yr['get'](_0x2ac583);if(_0x407053==='store')return _0x2a12c9['objectStoreNames'][0x1]?void 0x0:_0x2a12c9['objectStore'](_0x2a12c9['objectStoreNames'][0x0]);}return _e(_0x2ac583[_0x407053]);},'set'(_0x27f2f4,_0x165caa,_0x174a0e){return _0x27f2f4[_0x165caa]=_0x174a0e,!0x0;},'has'(_0x3cf558,_0x1496ce){return _0x3cf558 instanceof IDBTransaction&&(_0x1496ce==='done'||_0x1496ce==='store')?!0x0:_0x1496ce in _0x3cf558;}};function Uc(_0x36022c){di=_0x36022c(di);}function Wc(_0x439441){return _0x439441===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xba057b,..._0x3828a0){const _0x2e8f9c=_0x439441['call'](Xn(this),_0xba057b,..._0x3828a0);return Yr['set'](_0x2e8f9c,_0xba057b['sort']?_0xba057b['sort']():[_0xba057b]),_e(_0x2e8f9c);}:Lc()['includes'](_0x439441)?function(..._0x58a81a){return _0x439441['apply'](Xn(this),_0x58a81a),_e(Kr['get'](this));}:function(..._0x2da578){return _e(_0x439441['apply'](Xn(this),_0x2da578));};}function Bc(_0x27f1e9){return typeof _0x27f1e9=='function'?Wc(_0x27f1e9):(_0x27f1e9 instanceof IDBTransaction&&Fc(_0x27f1e9),Dc(_0x27f1e9,Mc())?new Proxy(_0x27f1e9,di):_0x27f1e9);}function _e(_0x27525d){if(_0x27525d instanceof IDBRequest)return xc(_0x27525d);if(Jn['has'](_0x27525d))return Jn['get'](_0x27525d);const _0x1ead0f=Bc(_0x27525d);return _0x1ead0f!==_0x27525d&&(Jn['set'](_0x27525d,_0x1ead0f),Fi['set'](_0x1ead0f,_0x27525d)),_0x1ead0f;}const Xn=_0x47c320=>Fi['get'](_0x47c320);function Vc(_0x26dcfc,_0x1ab426,{blocked:_0x25fd4e,upgrade:_0x25e00d,blocking:_0x11399c,terminated:_0x50bf9b}={}){const _0x41c12b=indexedDB['open'](_0x26dcfc,_0x1ab426),_0x56728d=_e(_0x41c12b);return _0x25e00d&&_0x41c12b['addEventListener']('upgradeneeded',_0x4b7f78=>{_0x25e00d(_e(_0x41c12b['result']),_0x4b7f78['oldVersion'],_0x4b7f78['newVersion'],_e(_0x41c12b['transaction']),_0x4b7f78);}),_0x25fd4e&&_0x41c12b['addEventListener']('blocked',_0x44cf44=>_0x25fd4e(_0x44cf44['oldVersion'],_0x44cf44['newVersion'],_0x44cf44)),_0x56728d['then'](_0x6de953=>{_0x50bf9b&&_0x6de953['addEventListener']('close',()=>_0x50bf9b()),_0x11399c&&_0x6de953['addEventListener']('versionchange',_0x2e03eb=>_0x11399c(_0x2e03eb['oldVersion'],_0x2e03eb['newVersion'],_0x2e03eb));})['catch'](()=>{}),_0x56728d;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x25268c,_0x3d9447){if(!(_0x25268c instanceof IDBDatabase&&!(_0x3d9447 in _0x25268c)&&typeof _0x3d9447=='string'))return;if(Zn['get'](_0x3d9447))return Zn['get'](_0x3d9447);const _0x116f8e=_0x3d9447['replace'](/FromIndex$/,''),_0x2a02d=_0x3d9447!==_0x116f8e,_0x4c5ea0=$c['includes'](_0x116f8e);if(!(_0x116f8e in(_0x2a02d?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4c5ea0||Hc['includes'](_0x116f8e)))return;const _0x20514b=async function(_0x2f3436,..._0x30cfcb){const _0x132376=this['transaction'](_0x2f3436,_0x4c5ea0?'readwrite':'readonly');let _0xade938=_0x132376['store'];return _0x2a02d&&(_0xade938=_0xade938['index'](_0x30cfcb['shift']())),(await Promise['all']([_0xade938[_0x116f8e](..._0x30cfcb),_0x4c5ea0&&_0x132376['done']]))[0x0];};return Zn['set'](_0x3d9447,_0x20514b),_0x20514b;}Uc(_0x30836d=>({..._0x30836d,'get':(_0x17caea,_0x583733,_0x3b8343)=>Os(_0x17caea,_0x583733)||_0x30836d['get'](_0x17caea,_0x583733,_0x3b8343),'has':(_0xc8364a,_0x201ad5)=>!!Os(_0xc8364a,_0x201ad5)||_0x30836d['has'](_0xc8364a,_0x201ad5)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x327419){this['container']=_0x327419;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1a7e70=>{if(qc(_0x1a7e70)){const _0x5b8628=_0x1a7e70['getImmediate']();return _0x5b8628['library']+'/'+_0x5b8628['version'];}else return null;})['filter'](_0x432aa4=>_0x432aa4)['join']('\x20');}}function qc(_0x2aa559){const _0x89bc3c=_0x2aa559['getComponent']();return(_0x89bc3c==null?void 0x0:_0x89bc3c['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x25fe03,_0x1315c6){try{_0x25fe03['container']['addComponent'](_0x1315c6);}catch(_0x37e67a){re['debug']('Component\x20'+_0x1315c6['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x25fe03['name'],_0x37e67a);}}function et(_0x35c745){const _0x36c4df=_0x35c745['name'];if(gi['has'](_0x36c4df))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x36c4df+'.'),!0x1;gi['set'](_0x36c4df,_0x35c745);for(const _0x5b2111 of Le['values']())Ms(_0x5b2111,_0x35c745);for(const _0x35015d of _i['values']())Ms(_0x35015d,_0x35c745);return!0x0;}function Ui(_0x33cd52,_0x355666){const _0x512d3a=_0x33cd52['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x512d3a&&_0x512d3a['triggerHeartbeat'](),_0x33cd52['container']['getProvider'](_0x355666);}function H(_0x22e782){return _0x22e782==null?!0x1:_0x22e782['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4c0013,_0x1ede37,_0x251033){this['_isDeleted']=!0x1,this['_options']={..._0x4c0013},this['_config']={..._0x1ede37},this['_name']=_0x1ede37['name'],this['_automaticDataCollectionEnabled']=_0x1ede37['automaticDataCollectionEnabled'],this['_container']=_0x251033,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5bcc99){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5bcc99;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x38fac1){this['_isDeleted']=_0x38fac1;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x2d5ddb,_0x1250d6={}){let _0x79d914=_0x2d5ddb;typeof _0x1250d6!='object'&&(_0x1250d6={'name':_0x1250d6});const _0x16a72c={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1250d6},_0x26be90=_0x16a72c['name'];if(typeof _0x26be90!='string'||!_0x26be90)throw ge['create']('bad-app-name',{'appName':String(_0x26be90)});if(_0x79d914||(_0x79d914=$r()),!_0x79d914)throw ge['create']('no-options');const _0x1b5d25=Le['get'](_0x26be90);if(_0x1b5d25){if(De(_0x79d914,_0x1b5d25['options'])&&De(_0x16a72c,_0x1b5d25['config']))return _0x1b5d25;throw ge['create']('duplicate-app',{'appName':_0x26be90});}const _0x2f63cf=new Ac(_0x26be90);for(const _0x16b57c of gi['values']())_0x2f63cf['addComponent'](_0x16b57c);const _0x16d4af=new Il(_0x79d914,_0x16a72c,_0x2f63cf);return Le['set'](_0x26be90,_0x16d4af),_0x16d4af;}function Qr(_0x377605=pi){const _0x353670=Le['get'](_0x377605);if(!_0x353670&&_0x377605===pi&&$r())return wl();if(!_0x353670)throw ge['create']('no-app',{'appName':_0x377605});return _0x353670;}function l_(){return Array['from'](Le['values']());}async function h_(_0x1103c0){let _0x12cc0a=!0x1;const _0x51b4ea=_0x1103c0['name'];Le['has'](_0x51b4ea)?(_0x12cc0a=!0x0,Le['delete'](_0x51b4ea)):_i['has'](_0x51b4ea)&&_0x1103c0['decRefCount']()<=0x0&&(_i['delete'](_0x51b4ea),_0x12cc0a=!0x0),_0x12cc0a&&(await Promise['all'](_0x1103c0['container']['getProviders']()['map'](_0x5a1d77=>_0x5a1d77['delete']())),_0x1103c0['isDeleted']=!0x0);}function me(_0x2b12b0,_0xa75c95,_0x1de37b){let _0xfc268b=vl[_0x2b12b0]??_0x2b12b0;_0x1de37b&&(_0xfc268b+='-'+_0x1de37b);const _0x2811bb=_0xfc268b['match'](/\s|\//),_0x3bb0d8=_0xa75c95['match'](/\s|\//);if(_0x2811bb||_0x3bb0d8){const _0x226ffb=['Unable\x20to\x20register\x20library\x20\x22'+_0xfc268b+'\x22\x20with\x20version\x20\x22'+_0xa75c95+'\x22:'];_0x2811bb&&_0x226ffb['push']('library\x20name\x20\x22'+_0xfc268b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2811bb&&_0x3bb0d8&&_0x226ffb['push']('and'),_0x3bb0d8&&_0x226ffb['push']('version\x20name\x20\x22'+_0xa75c95+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x226ffb['join']('\x20'));return;}et(new Me(_0xfc268b+'-version',()=>({'library':_0xfc268b,'version':_0xa75c95}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0xda0284,_0x495fef)=>{switch(_0x495fef){case 0x0:try{_0xda0284['createObjectStore'](Rt);}catch(_0x12e161){console['warn'](_0x12e161);}}}})['catch'](_0x4d32ac=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4d32ac['message']});})),ei;}async function Sl(_0x1042ba){try{const _0x112767=(await Jr())['transaction'](Rt),_0x2c7c9f=await _0x112767['objectStore'](Rt)['get'](Xr(_0x1042ba));return await _0x112767['done'],_0x2c7c9f;}catch(_0x4cc65c){if(_0x4cc65c instanceof Se)re['warn'](_0x4cc65c['message']);else{const _0x46820c=ge['create']('idb-get',{'originalErrorMessage':_0x4cc65c==null?void 0x0:_0x4cc65c['message']});re['warn'](_0x46820c['message']);}}}async function Ls(_0x659d53,_0x587083){try{const _0x7f0be2=(await Jr())['transaction'](Rt,'readwrite');await _0x7f0be2['objectStore'](Rt)['put'](_0x587083,Xr(_0x659d53)),await _0x7f0be2['done'];}catch(_0x16f9cd){if(_0x16f9cd instanceof Se)re['warn'](_0x16f9cd['message']);else{const _0xdf6306=ge['create']('idb-set',{'originalErrorMessage':_0x16f9cd==null?void 0x0:_0x16f9cd['message']});re['warn'](_0xdf6306['message']);}}}function Xr(_0x160946){return _0x160946['name']+'!'+_0x160946['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x43b67c){this['container']=_0x43b67c,this['_heartbeatsCache']=null;const _0x32b806=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x32b806),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x19ba66=>(this['_heartbeatsCache']=_0x19ba66,_0x19ba66));}async['triggerHeartbeat'](){var _0x52a508,_0x5173d7;try{const _0x31ef04=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x348f0b=xs();if(((_0x52a508=this['_heartbeatsCache'])==null?void 0x0:_0x52a508['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5173d7=this['_heartbeatsCache'])==null?void 0x0:_0x5173d7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x348f0b||this['_heartbeatsCache']['heartbeats']['some'](_0xa18390=>_0xa18390['date']===_0x348f0b))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x348f0b,'agent':_0x31ef04}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x2057df=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2057df,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3fe19b){re['warn'](_0x3fe19b);}}async['getHeartbeatsHeader'](){var _0x539bb6;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x539bb6=this['_heartbeatsCache'])==null?void 0x0:_0x539bb6['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x7496ed=xs(),{heartbeatsToSend:_0x69bb4,unsentEntries:_0x35a431}=kl(this['_heartbeatsCache']['heartbeats']),_0x29da15=an(JSON['stringify']({'version':0x2,'heartbeats':_0x69bb4}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x7496ed,_0x35a431['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x35a431,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x29da15;}catch(_0x59075a){return re['warn'](_0x59075a),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0xc62598,_0x5b45b1=bl){const _0x73757e=[];let _0x1effc7=_0xc62598['slice']();for(const _0x2fb8b9 of _0xc62598){const _0x4ff5cc=_0x73757e['find'](_0x4d0640=>_0x4d0640['agent']===_0x2fb8b9['agent']);if(_0x4ff5cc){if(_0x4ff5cc['dates']['push'](_0x2fb8b9['date']),Fs(_0x73757e)>_0x5b45b1){_0x4ff5cc['dates']['pop']();break;}}else{if(_0x73757e['push']({'agent':_0x2fb8b9['agent'],'dates':[_0x2fb8b9['date']]}),Fs(_0x73757e)>_0x5b45b1){_0x73757e['pop']();break;}}_0x1effc7=_0x1effc7['slice'](0x1);}return{'heartbeatsToSend':_0x73757e,'unsentEntries':_0x1effc7};}class Nl{constructor(_0x574418){this['app']=_0x574418,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x593df2=await Sl(this['app']);return _0x593df2!=null&&_0x593df2['heartbeats']?_0x593df2:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x295244){if(await this['_canUseIndexedDBPromise']){const _0x3af070=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x295244['lastSentHeartbeatDate']??_0x3af070['lastSentHeartbeatDate'],'heartbeats':_0x295244['heartbeats']});}else return;}async['add'](_0x7d6734){if(await this['_canUseIndexedDBPromise']){const _0x129ab9=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x7d6734['lastSentHeartbeatDate']??_0x129ab9['lastSentHeartbeatDate'],'heartbeats':[..._0x129ab9['heartbeats'],..._0x7d6734['heartbeats']]});}else return;}}function Fs(_0x4fdb69){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x4fdb69}))['length'];}function Pl(_0x48ee21){if(_0x48ee21['length']===0x0)return-0x1;let _0x1d7859=0x0,_0x4a4883=_0x48ee21[0x0]['date'];for(let _0x2cccd5=0x1;_0x2cccd5<_0x48ee21['length'];_0x2cccd5++)_0x48ee21[_0x2cccd5]['date']<_0x4a4883&&(_0x4a4883=_0x48ee21[_0x2cccd5]['date'],_0x1d7859=_0x2cccd5);return _0x1d7859;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x431aee){et(new Me('platform-logger',_0x255afc=>new Gc(_0x255afc),'PRIVATE')),et(new Me('heartbeat',_0x3b84ca=>new Al(_0x3b84ca),'PRIVATE')),me(fi,Ds,_0x431aee),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x5831b1){Zr=_0x5831b1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x343808){this['domStorage_']=_0x343808,this['prefix_']='firebase:';}['set'](_0x471fd0,_0x1b38ef){_0x1b38ef==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x471fd0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x471fd0),O(_0x1b38ef));}['get'](_0x310541){const _0x335a44=this['domStorage_']['getItem'](this['prefixedName_'](_0x310541));return _0x335a44==null?null:bt(_0x335a44);}['remove'](_0x123a07){this['domStorage_']['removeItem'](this['prefixedName_'](_0x123a07));}['prefixedName_'](_0x3ae3d7){return this['prefix_']+_0x3ae3d7;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3dd022,_0x1e2870){_0x1e2870==null?delete this['cache_'][_0x3dd022]:this['cache_'][_0x3dd022]=_0x1e2870;}['get'](_0x4581ce){return Y(this['cache_'],_0x4581ce)?this['cache_'][_0x4581ce]:null;}['remove'](_0x42640c){delete this['cache_'][_0x42640c];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x10c181){try{if(typeof window<'u'&&typeof window[_0x10c181]<'u'){const _0x1f28f7=window[_0x10c181];return _0x1f28f7['setItem']('firebase:sentinel','cache'),_0x1f28f7['removeItem']('firebase:sentinel'),new xl(_0x1f28f7);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x5ea174=0x1;return function(){return _0x5ea174++;};}()),no=function(_0x1494b3){const _0x54b79e=Tc(_0x1494b3),_0x5453cc=new Ec();_0x5453cc['update'](_0x54b79e);const _0x56d5cd=_0x5453cc['digest']();return Di['encodeByteArray'](_0x56d5cd);},Bt=function(..._0x21cd79){let _0x30ffaf='';for(let _0x42955f=0x0;_0x42955f<_0x21cd79['length'];_0x42955f++){const _0x4b37e0=_0x21cd79[_0x42955f];Array['isArray'](_0x4b37e0)||_0x4b37e0&&typeof _0x4b37e0=='object'&&typeof _0x4b37e0['length']=='number'?_0x30ffaf+=Bt['apply'](null,_0x4b37e0):typeof _0x4b37e0=='object'?_0x30ffaf+=O(_0x4b37e0):_0x30ffaf+=_0x4b37e0,_0x30ffaf+='\x20';}return _0x30ffaf;};let Et=null,Vs=!0x0;const Wl=function(_0x372fbd,_0xb9e33c){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5c1791){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x489c6e=Bt['apply'](null,_0x5c1791);Et(_0x489c6e);}},Vt=function(_0x1624fd){return function(..._0x15e69b){L(_0x1624fd,..._0x15e69b);};},mi=function(..._0x4e020e){const _0x284045='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x4e020e);Qe['error'](_0x284045);},oe=function(..._0xa15b13){const _0x464924='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0xa15b13);throw Qe['error'](_0x464924),new Error(_0x464924);},U=function(..._0x43e0db){const _0x4cc58a='FIREBASE\x20WARNING:\x20'+Bt(..._0x43e0db);Qe['warn'](_0x4cc58a);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x26f679){return typeof _0x26f679=='number'&&(_0x26f679!==_0x26f679||_0x26f679===Number['POSITIVE_INFINITY']||_0x26f679===Number['NEGATIVE_INFINITY']);},Vl=function(_0x19b40f){if(document['readyState']==='complete')_0x19b40f();else{let _0x32f68d=!0x1;const _0x55fafb=function(){if(!document['body']){setTimeout(_0x55fafb,Math['floor'](0xa));return;}_0x32f68d||(_0x32f68d=!0x0,_0x19b40f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x55fafb,!0x1),window['addEventListener']('load',_0x55fafb,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x55fafb();}),window['attachEvent']('onload',_0x55fafb));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2076a2,_0x51a725){if(_0x2076a2===_0x51a725)return 0x0;if(_0x2076a2===xe||_0x51a725===Ie)return-0x1;if(_0x51a725===xe||_0x2076a2===Ie)return 0x1;{const _0x2c1db5=Hs(_0x2076a2),_0x4e2ba7=Hs(_0x51a725);return _0x2c1db5!==null?_0x4e2ba7!==null?_0x2c1db5-_0x4e2ba7===0x0?_0x2076a2['length']-_0x51a725['length']:_0x2c1db5-_0x4e2ba7:-0x1:_0x4e2ba7!==null?0x1:_0x2076a2<_0x51a725?-0x1:0x1;}},Hl=function(_0x4f5f33,_0x2d124a){return _0x4f5f33===_0x2d124a?0x0:_0x4f5f33<_0x2d124a?-0x1:0x1;},pt=function(_0x98be90,_0x164e1c){if(_0x164e1c&&_0x98be90 in _0x164e1c)return _0x164e1c[_0x98be90];throw new Error('Missing\x20required\x20key\x20('+_0x98be90+')\x20in\x20object:\x20'+O(_0x164e1c));},Bi=function(_0x1d7dd6){if(typeof _0x1d7dd6!='object'||_0x1d7dd6===null)return O(_0x1d7dd6);const _0x11e9d0=[];for(const _0x108af7 in _0x1d7dd6)_0x11e9d0['push'](_0x108af7);_0x11e9d0['sort']();let _0x2b4116='{';for(let _0x390c05=0x0;_0x390c05<_0x11e9d0['length'];_0x390c05++)_0x390c05!==0x0&&(_0x2b4116+=','),_0x2b4116+=O(_0x11e9d0[_0x390c05]),_0x2b4116+=':',_0x2b4116+=Bi(_0x1d7dd6[_0x11e9d0[_0x390c05]]);return _0x2b4116+='}',_0x2b4116;},io=function(_0x3dedbe,_0x24b607){const _0x2ab368=_0x3dedbe['length'];if(_0x2ab368<=_0x24b607)return[_0x3dedbe];const _0x3b5f0f=[];for(let _0x1c3e6f=0x0;_0x1c3e6f<_0x2ab368;_0x1c3e6f+=_0x24b607)_0x1c3e6f+_0x24b607>_0x2ab368?_0x3b5f0f['push'](_0x3dedbe['substring'](_0x1c3e6f,_0x2ab368)):_0x3b5f0f['push'](_0x3dedbe['substring'](_0x1c3e6f,_0x1c3e6f+_0x24b607));return _0x3b5f0f;};function x(_0x5052e2,_0x7108d4){for(const _0x391c4e in _0x5052e2)_0x5052e2['hasOwnProperty'](_0x391c4e)&&_0x7108d4(_0x391c4e,_0x5052e2[_0x391c4e]);}const so=function(_0x321d2a){f(!Wi(_0x321d2a),'Invalid\x20JSON\x20number');const _0x571345=0xb,_0x4c8e73=0x34,_0x4ae9eb=(0x1<<_0x571345-0x1)-0x1;let _0x2a56bb,_0x358be5,_0x6c769d,_0x3bda50,_0x3e660a;_0x321d2a===0x0?(_0x358be5=0x0,_0x6c769d=0x0,_0x2a56bb=0x1/_0x321d2a===-0x1/0x0?0x1:0x0):(_0x2a56bb=_0x321d2a<0x0,_0x321d2a=Math['abs'](_0x321d2a),_0x321d2a>=Math['pow'](0x2,0x1-_0x4ae9eb)?(_0x3bda50=Math['min'](Math['floor'](Math['log'](_0x321d2a)/Math['LN2']),_0x4ae9eb),_0x358be5=_0x3bda50+_0x4ae9eb,_0x6c769d=Math['round'](_0x321d2a*Math['pow'](0x2,_0x4c8e73-_0x3bda50)-Math['pow'](0x2,_0x4c8e73))):(_0x358be5=0x0,_0x6c769d=Math['round'](_0x321d2a/Math['pow'](0x2,0x1-_0x4ae9eb-_0x4c8e73))));const _0x5b5a21=[];for(_0x3e660a=_0x4c8e73;_0x3e660a;_0x3e660a-=0x1)_0x5b5a21['push'](_0x6c769d%0x2?0x1:0x0),_0x6c769d=Math['floor'](_0x6c769d/0x2);for(_0x3e660a=_0x571345;_0x3e660a;_0x3e660a-=0x1)_0x5b5a21['push'](_0x358be5%0x2?0x1:0x0),_0x358be5=Math['floor'](_0x358be5/0x2);_0x5b5a21['push'](_0x2a56bb?0x1:0x0),_0x5b5a21['reverse']();const _0x2c71be=_0x5b5a21['join']('');let _0x14c823='';for(_0x3e660a=0x0;_0x3e660a<0x40;_0x3e660a+=0x8){let _0x363a9b=parseInt(_0x2c71be['substr'](_0x3e660a,0x8),0x2)['toString'](0x10);_0x363a9b['length']===0x1&&(_0x363a9b='0'+_0x363a9b),_0x14c823=_0x14c823+_0x363a9b;}return _0x14c823['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x1463ab,_0x195dd6){let _0x4e6e46='Unknown\x20Error';_0x1463ab==='too_big'?_0x4e6e46='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1463ab==='permission_denied'?_0x4e6e46='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1463ab==='unavailable'&&(_0x4e6e46='The\x20service\x20is\x20unavailable');const _0x509f9e=new Error(_0x1463ab+'\x20at\x20'+_0x195dd6['_path']['toString']()+':\x20'+_0x4e6e46);return _0x509f9e['code']=_0x1463ab['toUpperCase'](),_0x509f9e;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2de6f9){if(zl['test'](_0x2de6f9)){const _0xb507d7=Number(_0x2de6f9);if(_0xb507d7>=jl&&_0xb507d7<=Kl)return _0xb507d7;}return null;},lt=function(_0x5e0e02){try{_0x5e0e02();}catch(_0x4d43e7){setTimeout(()=>{const _0x311c78=_0x4d43e7['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x311c78),_0x4d43e7;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0xe4bed3,_0x5965ed){const _0x44a8c7=setTimeout(_0xe4bed3,_0x5965ed);return typeof _0x44a8c7=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x44a8c7):typeof _0x44a8c7=='object'&&_0x44a8c7['unref']&&_0x44a8c7['unref'](),_0x44a8c7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x216c1a,_0x31e0b8){this['appCheckProvider']=_0x31e0b8,this['appName']=_0x216c1a['name'],H(_0x216c1a)&&_0x216c1a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x216c1a['settings']['appCheckToken']),this['appCheck']=_0x31e0b8==null?void 0x0:_0x31e0b8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x31e0b8==null||_0x31e0b8['get']()['then'](_0x5ab75f=>this['appCheck']=_0x5ab75f);}['getToken'](_0x1b1f02){if(this['serverAppAppCheckToken']){if(_0x1b1f02)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1b1f02):new Promise((_0x5aba3e,_0x553a47)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1b1f02)['then'](_0x5aba3e,_0x553a47):_0x5aba3e(null);},0x0);});}['addTokenChangeListener'](_0x5c2c12){var _0x292a71;(_0x292a71=this['appCheckProvider'])==null||_0x292a71['get']()['then'](_0x56f40c=>_0x56f40c['addTokenListener'](_0x5c2c12));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x75c31c,_0x40b563,_0x30815b){this['appName_']=_0x75c31c,this['firebaseOptions_']=_0x40b563,this['authProvider_']=_0x30815b,this['auth_']=null,this['auth_']=_0x30815b['getImmediate']({'optional':!0x0}),this['auth_']||_0x30815b['onInit'](_0x153b9d=>this['auth_']=_0x153b9d);}['getToken'](_0x111081){return this['auth_']?this['auth_']['getToken'](_0x111081)['catch'](_0x345c59=>_0x345c59&&_0x345c59['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x345c59)):new Promise((_0x44146c,_0x128b9c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x111081)['then'](_0x44146c,_0x128b9c):_0x44146c(null);},0x0);});}['addTokenChangeListener'](_0x1e1d5d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1e1d5d):this['authProvider_']['get']()['then'](_0x3a7bc8=>_0x3a7bc8['addAuthTokenListener'](_0x1e1d5d));}['removeTokenChangeListener'](_0x391881){this['authProvider_']['get']()['then'](_0x1d1c8e=>_0x1d1c8e['removeAuthTokenListener'](_0x391881));}['notifyForInvalidToken'](){let _0xca0f10='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xca0f10+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xca0f10+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xca0f10+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xca0f10);}}class tn{constructor(_0x46ff9a){this['accessToken']=_0x46ff9a;}['getToken'](_0x3460cc){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x11ff43){_0x11ff43(this['accessToken']);}['removeTokenChangeListener'](_0x402048){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x68d2f3,_0x1aec5e,_0xda25fd,_0x1e78f5,_0x2f07e9=!0x1,_0x5eb53e='',_0x5bb4c5=!0x1,_0x5184e8=!0x1,_0x43eba4=null){this['secure']=_0x1aec5e,this['namespace']=_0xda25fd,this['webSocketOnly']=_0x1e78f5,this['nodeAdmin']=_0x2f07e9,this['persistenceKey']=_0x5eb53e,this['includeNamespaceInQueryParams']=_0x5bb4c5,this['isUsingEmulator']=_0x5184e8,this['emulatorOptions']=_0x43eba4,this['_host']=_0x68d2f3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x68d2f3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x32b72d){_0x32b72d!==this['internalHost']&&(this['internalHost']=_0x32b72d,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x8746af=this['toURLString']();return this['persistenceKey']&&(_0x8746af+='<'+this['persistenceKey']+'>'),_0x8746af;}['toURLString'](){const _0x21903b=this['secure']?'https://':'http://',_0x36e054=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x21903b+this['host']+'/'+_0x36e054;}}function Xl(_0x3091aa){return _0x3091aa['host']!==_0x3091aa['internalHost']||_0x3091aa['isCustomHost']()||_0x3091aa['includeNamespaceInQueryParams'];}function go(_0x7cddea,_0x242422,_0x329ecb){f(typeof _0x242422=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x329ecb=='object','typeof\x20params\x20must\x20==\x20object');let _0x1bc685;if(_0x242422===fo)_0x1bc685=(_0x7cddea['secure']?'wss://':'ws://')+_0x7cddea['internalHost']+'/.ws?';else{if(_0x242422===po)_0x1bc685=(_0x7cddea['secure']?'https://':'http://')+_0x7cddea['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x242422);}Xl(_0x7cddea)&&(_0x329ecb['ns']=_0x7cddea['namespace']);const _0x4c2bcd=[];return x(_0x329ecb,(_0x165627,_0x152f40)=>{_0x4c2bcd['push'](_0x165627+'='+_0x152f40);}),_0x1bc685+_0x4c2bcd['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5638ac,_0x2b4802=0x1){Y(this['counters_'],_0x5638ac)||(this['counters_'][_0x5638ac]=0x0),this['counters_'][_0x5638ac]+=_0x2b4802;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x1eb90e){const _0xa990e7=_0x1eb90e['toString']();return ti[_0xa990e7]||(ti[_0xa990e7]=new Zl()),ti[_0xa990e7];}function eh(_0x3214ba,_0x224e28){const _0x21f5da=_0x3214ba['toString']();return ni[_0x21f5da]||(ni[_0x21f5da]=_0x224e28()),ni[_0x21f5da];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2202e1){this['onMessage_']=_0x2202e1,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2b8f0e,_0x2aa02f){this['closeAfterResponse']=_0x2b8f0e,this['onClose']=_0x2aa02f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x432013,_0x12efe2){for(this['pendingResponses'][_0x432013]=_0x12efe2;this['pendingResponses'][this['currentResponseNum']];){const _0x498514=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x286e5c=0x0;_0x286e5c<_0x498514['length'];++_0x286e5c)_0x498514[_0x286e5c]&&lt(()=>{this['onMessage_'](_0x498514[_0x286e5c]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2f5a4f,_0x5db3ab,_0x40ae33,_0x3087ae,_0x4287bb,_0x4ecaeb,_0x5b189c){this['connId']=_0x2f5a4f,this['repoInfo']=_0x5db3ab,this['applicationId']=_0x40ae33,this['appCheckToken']=_0x3087ae,this['authToken']=_0x4287bb,this['transportSessionId']=_0x4ecaeb,this['lastSessionId']=_0x5b189c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2f5a4f),this['stats_']=Hi(_0x5db3ab),this['urlFn']=_0x792dcf=>(this['appCheckToken']&&(_0x792dcf[yi]=this['appCheckToken']),go(_0x5db3ab,po,_0x792dcf));}['open'](_0x3ea629,_0x1b92fd){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1b92fd,this['myPacketOrderer']=new th(_0x3ea629),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x1e4fed)=>{const [_0x4669bc,_0x4f2c51,_0x3c0653,_0x42629e,_0x180a0f]=_0x1e4fed;if(this['incrementIncomingBytes_'](_0x1e4fed),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4669bc===$s)this['id']=_0x4f2c51,this['password']=_0x3c0653;else{if(_0x4669bc===nh)_0x4f2c51?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4f2c51,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4669bc);}}},(..._0x13bcb5)=>{const [_0xaf626e,_0x8bb235]=_0x13bcb5;this['incrementIncomingBytes_'](_0x13bcb5),this['myPacketOrderer']['handleResponse'](_0xaf626e,_0x8bb235);},()=>{this['onClosed_']();},this['urlFn']);const _0x322e7f={};_0x322e7f[$s]='t',_0x322e7f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x322e7f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x322e7f[ro]=Vi,this['transportSessionId']&&(_0x322e7f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x322e7f[ho]=this['lastSessionId']),this['applicationId']&&(_0x322e7f[uo]=this['applicationId']),this['appCheckToken']&&(_0x322e7f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x322e7f[ao]=co);const _0x17d1e8=this['urlFn'](_0x322e7f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x17d1e8),this['scriptTagHolder']['addTag'](_0x17d1e8,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5227c5){const _0x84dbf2=O(_0x5227c5);this['bytesSent']+=_0x84dbf2['length'],this['stats_']['incrementCounter']('bytes_sent',_0x84dbf2['length']);const _0x1b0f6b=Br(_0x84dbf2),_0x5dad49=io(_0x1b0f6b,hh);for(let _0xbe58e7=0x0;_0xbe58e7<_0x5dad49['length'];_0xbe58e7++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5dad49['length'],_0x5dad49[_0xbe58e7]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4cd1a5,_0x490736){this['myDisconnFrame']=document['createElement']('iframe');const _0x29ce9b={};_0x29ce9b[lh]='t',_0x29ce9b[mo]=_0x4cd1a5,_0x29ce9b[yo]=_0x490736,this['myDisconnFrame']['src']=this['urlFn'](_0x29ce9b),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3fcf23){const _0x3d6f51=O(_0x3fcf23)['length'];this['bytesReceived']+=_0x3d6f51,this['stats_']['incrementCounter']('bytes_received',_0x3d6f51);}}class $i{constructor(_0x1e64d2,_0x32bd8d,_0x445c4f,_0x445733){this['onDisconnect']=_0x445c4f,this['urlFn']=_0x445733,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x1e64d2,window[sh+this['uniqueCallbackIdentifier']]=_0x32bd8d,this['myIFrame']=$i['createIFrame_']();let _0x282d0d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x282d0d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x28df41='<html><body>'+_0x282d0d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x28df41),this['myIFrame']['doc']['close']();}catch(_0x238e05){L('frame\x20writing\x20exception'),_0x238e05['stack']&&L(_0x238e05['stack']),L(_0x238e05);}}}static['createIFrame_'](){const _0x10db2e=document['createElement']('iframe');if(_0x10db2e['style']['display']='none',document['body']){document['body']['appendChild'](_0x10db2e);try{_0x10db2e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xef2fb1=document['domain'];_0x10db2e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xef2fb1+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x10db2e['contentDocument']?_0x10db2e['doc']=_0x10db2e['contentDocument']:_0x10db2e['contentWindow']?_0x10db2e['doc']=_0x10db2e['contentWindow']['document']:_0x10db2e['document']&&(_0x10db2e['doc']=_0x10db2e['document']),_0x10db2e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x518115=this['onDisconnect'];_0x518115&&(this['onDisconnect']=null,_0x518115());}['startLongPoll'](_0x3776ec,_0x22c2fa){for(this['myID']=_0x3776ec,this['myPW']=_0x22c2fa,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x342ad1={};_0x342ad1[mo]=this['myID'],_0x342ad1[yo]=this['myPW'],_0x342ad1[vo]=this['currentSerial'];let _0x20ebe8=this['urlFn'](_0x342ad1),_0x237854='',_0x479c91=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x237854['length']<=Eo;){const _0x5ac2b0=this['pendingSegs']['shift']();_0x237854=_0x237854+'&'+oh+_0x479c91+'='+_0x5ac2b0['seg']+'&'+ah+_0x479c91+'='+_0x5ac2b0['ts']+'&'+ch+_0x479c91+'='+_0x5ac2b0['d'],_0x479c91++;}return _0x20ebe8=_0x20ebe8+_0x237854,this['addLongPollTag_'](_0x20ebe8,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1f1730,_0x30082d,_0xe39473){this['pendingSegs']['push']({'seg':_0x1f1730,'ts':_0x30082d,'d':_0xe39473}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5b742e,_0x457ea9){this['outstandingRequests']['add'](_0x457ea9);const _0x145817=()=>{this['outstandingRequests']['delete'](_0x457ea9),this['newRequest_']();},_0x430c32=setTimeout(_0x145817,Math['floor'](uh)),_0x335770=()=>{clearTimeout(_0x430c32),_0x145817();};this['addTag'](_0x5b742e,_0x335770);}['addTag'](_0x79f636,_0x352670){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1e1d2b=this['myIFrame']['doc']['createElement']('script');_0x1e1d2b['type']='text/javascript',_0x1e1d2b['async']=!0x0,_0x1e1d2b['src']=_0x79f636,_0x1e1d2b['onload']=_0x1e1d2b['onreadystatechange']=function(){const _0x325ee7=_0x1e1d2b['readyState'];(!_0x325ee7||_0x325ee7==='loaded'||_0x325ee7==='complete')&&(_0x1e1d2b['onload']=_0x1e1d2b['onreadystatechange']=null,_0x1e1d2b['parentNode']&&_0x1e1d2b['parentNode']['removeChild'](_0x1e1d2b),_0x352670());},_0x1e1d2b['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x79f636),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1e1d2b);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1a5178,_0x44b772,_0x56a8f9,_0x569632,_0x3b2c24,_0x4012d0,_0x4013fc){this['connId']=_0x1a5178,this['applicationId']=_0x56a8f9,this['appCheckToken']=_0x569632,this['authToken']=_0x3b2c24,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x44b772),this['connURL']=G['connectionURL_'](_0x44b772,_0x4012d0,_0x4013fc,_0x569632,_0x56a8f9),this['nodeAdmin']=_0x44b772['nodeAdmin'];}static['connectionURL_'](_0x30006e,_0x144aae,_0x3d55fe,_0x7ac5dd,_0x5af762){const _0x3f22f3={};return _0x3f22f3[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3f22f3[ao]=co),_0x144aae&&(_0x3f22f3[oo]=_0x144aae),_0x3d55fe&&(_0x3f22f3[ho]=_0x3d55fe),_0x7ac5dd&&(_0x3f22f3[yi]=_0x7ac5dd),_0x5af762&&(_0x3f22f3[uo]=_0x5af762),go(_0x30006e,fo,_0x3f22f3);}['open'](_0x52cfdb,_0x4edc78){this['onDisconnect']=_0x4edc78,this['onMessage']=_0x52cfdb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5a6583;dc(),this['mySock']=new hn(this['connURL'],[],_0x5a6583);}catch(_0x3334cc){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xd44d61=_0x3334cc['message']||_0x3334cc['data'];_0xd44d61&&this['log_'](_0xd44d61),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x57eb76=>{this['handleIncomingFrame'](_0x57eb76);},this['mySock']['onerror']=_0x3e7f36=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3ec88a=_0x3e7f36['message']||_0x3e7f36['data'];_0x3ec88a&&this['log_'](_0x3ec88a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x286921=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xb60d76=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2b00ce=navigator['userAgent']['match'](_0xb60d76);_0x2b00ce&&_0x2b00ce['length']>0x1&&parseFloat(_0x2b00ce[0x1])<4.4&&(_0x286921=!0x0);}return!_0x286921&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1cc096){if(this['frames']['push'](_0x1cc096),this['frames']['length']===this['totalFrames']){const _0x1ec7f9=this['frames']['join']('');this['frames']=null;const _0x177932=bt(_0x1ec7f9);this['onMessage'](_0x177932);}}['handleNewFrameCount_'](_0xb23726){this['totalFrames']=_0xb23726,this['frames']=[];}['extractFrameCount_'](_0x2eea16){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2eea16['length']<=0x6){const _0x2f2405=Number(_0x2eea16);if(!isNaN(_0x2f2405))return this['handleNewFrameCount_'](_0x2f2405),null;}return this['handleNewFrameCount_'](0x1),_0x2eea16;}['handleIncomingFrame'](_0xc28f16){if(this['mySock']===null)return;const _0x550352=_0xc28f16['data'];if(this['bytesReceived']+=_0x550352['length'],this['stats_']['incrementCounter']('bytes_received',_0x550352['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x550352);else{const _0xdfafe8=this['extractFrameCount_'](_0x550352);_0xdfafe8!==null&&this['appendFrame_'](_0xdfafe8);}}['send'](_0x2b4700){this['resetKeepAlive']();const _0x45a53e=O(_0x2b4700);this['bytesSent']+=_0x45a53e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x45a53e['length']);const _0xa8fdb4=io(_0x45a53e,fh);_0xa8fdb4['length']>0x1&&this['sendString_'](String(_0xa8fdb4['length']));for(let _0x3ebc67=0x0;_0x3ebc67<_0xa8fdb4['length'];_0x3ebc67++)this['sendString_'](_0xa8fdb4[_0x3ebc67]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x23d8d6){try{this['mySock']['send'](_0x23d8d6);}catch(_0x12ede6){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x12ede6['message']||_0x12ede6['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x7b0a8d){this['initTransports_'](_0x7b0a8d);}['initTransports_'](_0x65118b){const _0x4ae486=G&&G['isAvailable']();let _0x437eac=_0x4ae486&&!G['previouslyFailed']();if(_0x65118b['webSocketOnly']&&(_0x4ae486||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x437eac=!0x0),_0x437eac)this['transports_']=[G];else{const _0x5b386a=this['transports_']=[];for(const _0x2e8ed1 of At['ALL_TRANSPORTS'])_0x2e8ed1&&_0x2e8ed1['isAvailable']()&&_0x5b386a['push'](_0x2e8ed1);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4ee861,_0x5baa40,_0x96a56b,_0x28f7e0,_0x54976e,_0x12e29c,_0x354edd,_0x4b7679,_0x3f166,_0x3e2662){this['id']=_0x4ee861,this['repoInfo_']=_0x5baa40,this['applicationId_']=_0x96a56b,this['appCheckToken_']=_0x28f7e0,this['authToken_']=_0x54976e,this['onMessage_']=_0x12e29c,this['onReady_']=_0x354edd,this['onDisconnect_']=_0x4b7679,this['onKill_']=_0x3f166,this['lastSessionId']=_0x3e2662,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x5baa40),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x35aeba=this['transportManager_']['initialTransport']();this['conn_']=new _0x35aeba(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x35aeba['responsesRequiredToBeHealthy']||0x0;const _0x1ea214=this['connReceiver_'](this['conn_']),_0x2e5682=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1ea214,_0x2e5682);},Math['floor'](0x0));const _0x303704=_0x35aeba['healthyTimeout']||0x0;_0x303704>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x303704)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x353431){return _0x128ac3=>{_0x353431===this['conn_']?this['onConnectionLost_'](_0x128ac3):_0x353431===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x6793a0){return _0x1112e9=>{this['state_']!==0x2&&(_0x6793a0===this['rx_']?this['onPrimaryMessageReceived_'](_0x1112e9):_0x6793a0===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1112e9):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x7477e2){const _0xcd5c3={'t':'d','d':_0x7477e2};this['sendData_'](_0xcd5c3);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x425994){if(ii in _0x425994){const _0xb6ae0d=_0x425994[ii];_0xb6ae0d===js?this['upgradeIfSecondaryHealthy_']():_0xb6ae0d===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xb6ae0d===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x18f100){const _0x513de8=pt('t',_0x18f100),_0x259b76=pt('d',_0x18f100);if(_0x513de8==='c')this['onSecondaryControl_'](_0x259b76);else{if(_0x513de8==='d')this['pendingDataMessages']['push'](_0x259b76);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x513de8);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x31aa99){const _0x1b8f7d=pt('t',_0x31aa99),_0x204b98=pt('d',_0x31aa99);_0x1b8f7d==='c'?this['onControl_'](_0x204b98):_0x1b8f7d==='d'&&this['onDataMessage_'](_0x204b98);}['onDataMessage_'](_0x2619cf){this['onPrimaryResponse_'](),this['onMessage_'](_0x2619cf);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x230365){const _0x4d8ef4=pt(ii,_0x230365);if(Gs in _0x230365){const _0x46c73e=_0x230365[Gs];if(_0x4d8ef4===Ih){const _0x441578={..._0x46c73e};this['repoInfo_']['isUsingEmulator']&&(_0x441578['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x441578);}else{if(_0x4d8ef4===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4ad7a5=0x0;_0x4ad7a5<this['pendingDataMessages']['length'];++_0x4ad7a5)this['onDataMessage_'](this['pendingDataMessages'][_0x4ad7a5]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4d8ef4===vh?this['onConnectionShutdown_'](_0x46c73e):_0x4d8ef4===qs?this['onReset_'](_0x46c73e):_0x4d8ef4===Eh?mi('Server\x20Error:\x20'+_0x46c73e):_0x4d8ef4===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x4d8ef4);}}}['onHandshake_'](_0x554c1e){const _0x3bd097=_0x554c1e['ts'],_0x436c66=_0x554c1e['v'],_0x2a2977=_0x554c1e['h'];this['sessionId']=_0x554c1e['s'],this['repoInfo_']['host']=_0x2a2977,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3bd097),Vi!==_0x436c66&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5c7607=this['transportManager_']['upgradeTransport']();_0x5c7607&&this['startUpgrade_'](_0x5c7607);}['startUpgrade_'](_0x277af8){this['secondaryConn_']=new _0x277af8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x277af8['responsesRequiredToBeHealthy']||0x0;const _0x403f00=this['connReceiver_'](this['secondaryConn_']),_0x8941a9=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x403f00,_0x8941a9),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x214254){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x214254),this['repoInfo_']['host']=_0x214254,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x586dcf,_0x267fb8){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x586dcf,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x267fb8,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x26347c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x26347c||this['rx_']===_0x26347c)&&this['close']();}['onConnectionLost_'](_0x2c584d){this['conn_']=null,!_0x2c584d&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3b53d6){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3b53d6),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xb333aa){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xb333aa);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x462396,_0x347a2d,_0xcf0e35,_0x6e0b0f){}['merge'](_0x54508b,_0x555cd3,_0x592d13,_0x30542e){}['refreshAuthToken'](_0x4057dd){}['refreshAppCheckToken'](_0x3fdc20){}['onDisconnectPut'](_0x4aa7a5,_0x1a66ba,_0x5f4680){}['onDisconnectMerge'](_0x13f261,_0x2420ff,_0x5a2f27){}['onDisconnectCancel'](_0x390c96,_0x126bd9){}['reportStats'](_0xf0bb20){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0xe9f844){this['allowedEvents_']=_0xe9f844,this['listeners_']={},f(Array['isArray'](_0xe9f844)&&_0xe9f844['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x344ffe,..._0x38fc04){if(Array['isArray'](this['listeners_'][_0x344ffe])){const _0x1b2d24=[...this['listeners_'][_0x344ffe]];for(let _0x21d3c4=0x0;_0x21d3c4<_0x1b2d24['length'];_0x21d3c4++)_0x1b2d24[_0x21d3c4]['callback']['apply'](_0x1b2d24[_0x21d3c4]['context'],_0x38fc04);}}['on'](_0x5829e1,_0x28403a,_0x2ebcfa){this['validateEventType_'](_0x5829e1),this['listeners_'][_0x5829e1]=this['listeners_'][_0x5829e1]||[],this['listeners_'][_0x5829e1]['push']({'callback':_0x28403a,'context':_0x2ebcfa});const _0x598c0b=this['getInitialEvent'](_0x5829e1);_0x598c0b&&_0x28403a['apply'](_0x2ebcfa,_0x598c0b);}['off'](_0x538c3a,_0x54d123,_0x38e063){this['validateEventType_'](_0x538c3a);const _0x5115c2=this['listeners_'][_0x538c3a]||[];for(let _0x42e144=0x0;_0x42e144<_0x5115c2['length'];_0x42e144++)if(_0x5115c2[_0x42e144]['callback']===_0x54d123&&(!_0x38e063||_0x38e063===_0x5115c2[_0x42e144]['context'])){_0x5115c2['splice'](_0x42e144,0x1);return;}}['validateEventType_'](_0xd8c4dc){f(this['allowedEvents_']['find'](_0x30a9e9=>_0x30a9e9===_0xd8c4dc),'Unknown\x20event:\x20'+_0xd8c4dc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5463be){return f(_0x5463be==='online','Unknown\x20event\x20type:\x20'+_0x5463be),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x3d7df1,_0x439aa6){if(_0x439aa6===void 0x0){this['pieces_']=_0x3d7df1['split']('/');let _0x24baaa=0x0;for(let _0x4d9894=0x0;_0x4d9894<this['pieces_']['length'];_0x4d9894++)this['pieces_'][_0x4d9894]['length']>0x0&&(this['pieces_'][_0x24baaa]=this['pieces_'][_0x4d9894],_0x24baaa++);this['pieces_']['length']=_0x24baaa,this['pieceNum_']=0x0;}else this['pieces_']=_0x3d7df1,this['pieceNum_']=_0x439aa6;}['toString'](){let _0x27f3f9='';for(let _0x319b08=this['pieceNum_'];_0x319b08<this['pieces_']['length'];_0x319b08++)this['pieces_'][_0x319b08]!==''&&(_0x27f3f9+='/'+this['pieces_'][_0x319b08]);return _0x27f3f9||'/';}}function w(){return new C('');}function y(_0x4443ed){return _0x4443ed['pieceNum_']>=_0x4443ed['pieces_']['length']?null:_0x4443ed['pieces_'][_0x4443ed['pieceNum_']];}function we(_0x693843){return _0x693843['pieces_']['length']-_0x693843['pieceNum_'];}function b(_0x317552){let _0x9e4e10=_0x317552['pieceNum_'];return _0x9e4e10<_0x317552['pieces_']['length']&&_0x9e4e10++,new C(_0x317552['pieces_'],_0x9e4e10);}function Gi(_0x436bbf){return _0x436bbf['pieceNum_']<_0x436bbf['pieces_']['length']?_0x436bbf['pieces_'][_0x436bbf['pieces_']['length']-0x1]:null;}function Ch(_0x26ba86){let _0x248d7d='';for(let _0x8a5508=_0x26ba86['pieceNum_'];_0x8a5508<_0x26ba86['pieces_']['length'];_0x8a5508++)_0x26ba86['pieces_'][_0x8a5508]!==''&&(_0x248d7d+='/'+encodeURIComponent(String(_0x26ba86['pieces_'][_0x8a5508])));return _0x248d7d||'/';}function kt(_0x4f7337,_0x53a50f=0x0){return _0x4f7337['pieces_']['slice'](_0x4f7337['pieceNum_']+_0x53a50f);}function To(_0xdc817d){if(_0xdc817d['pieceNum_']>=_0xdc817d['pieces_']['length'])return null;const _0x4e5eaf=[];for(let _0x3efb05=_0xdc817d['pieceNum_'];_0x3efb05<_0xdc817d['pieces_']['length']-0x1;_0x3efb05++)_0x4e5eaf['push'](_0xdc817d['pieces_'][_0x3efb05]);return new C(_0x4e5eaf,0x0);}function A(_0x549452,_0x321484){const _0x32b387=[];for(let _0x50de45=_0x549452['pieceNum_'];_0x50de45<_0x549452['pieces_']['length'];_0x50de45++)_0x32b387['push'](_0x549452['pieces_'][_0x50de45]);if(_0x321484 instanceof C){for(let _0x4ce80b=_0x321484['pieceNum_'];_0x4ce80b<_0x321484['pieces_']['length'];_0x4ce80b++)_0x32b387['push'](_0x321484['pieces_'][_0x4ce80b]);}else{const _0x2bf30f=_0x321484['split']('/');for(let _0x5ac035=0x0;_0x5ac035<_0x2bf30f['length'];_0x5ac035++)_0x2bf30f[_0x5ac035]['length']>0x0&&_0x32b387['push'](_0x2bf30f[_0x5ac035]);}return new C(_0x32b387,0x0);}function v(_0x530ca5){return _0x530ca5['pieceNum_']>=_0x530ca5['pieces_']['length'];}function F(_0x7db7ee,_0x185a7c){const _0x57e70a=y(_0x7db7ee),_0x53f979=y(_0x185a7c);if(_0x57e70a===null)return _0x185a7c;if(_0x57e70a===_0x53f979)return F(b(_0x7db7ee),b(_0x185a7c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x185a7c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x7db7ee+')');}function Th(_0x1c7587,_0x1d3eff){const _0x35e685=kt(_0x1c7587,0x0),_0x39ea0f=kt(_0x1d3eff,0x0);for(let _0x3b9423=0x0;_0x3b9423<_0x35e685['length']&&_0x3b9423<_0x39ea0f['length'];_0x3b9423++){const _0x78fbcd=He(_0x35e685[_0x3b9423],_0x39ea0f[_0x3b9423]);if(_0x78fbcd!==0x0)return _0x78fbcd;}return _0x35e685['length']===_0x39ea0f['length']?0x0:_0x35e685['length']<_0x39ea0f['length']?-0x1:0x1;}function qi(_0x52ec75,_0x5e6009){if(we(_0x52ec75)!==we(_0x5e6009))return!0x1;for(let _0x3e97b3=_0x52ec75['pieceNum_'],_0x213967=_0x5e6009['pieceNum_'];_0x3e97b3<=_0x52ec75['pieces_']['length'];_0x3e97b3++,_0x213967++)if(_0x52ec75['pieces_'][_0x3e97b3]!==_0x5e6009['pieces_'][_0x213967])return!0x1;return!0x0;}function $(_0x557c23,_0x219f64){let _0x374622=_0x557c23['pieceNum_'],_0x4b4849=_0x219f64['pieceNum_'];if(we(_0x557c23)>we(_0x219f64))return!0x1;for(;_0x374622<_0x557c23['pieces_']['length'];){if(_0x557c23['pieces_'][_0x374622]!==_0x219f64['pieces_'][_0x4b4849])return!0x1;++_0x374622,++_0x4b4849;}return!0x0;}class Sh{constructor(_0x418a29,_0xafabe3){this['errorPrefix_']=_0xafabe3,this['parts_']=kt(_0x418a29,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1d5f0b=0x0;_0x1d5f0b<this['parts_']['length'];_0x1d5f0b++)this['byteLength_']+=Pn(this['parts_'][_0x1d5f0b]);So(this);}}function bh(_0x595686,_0x5a50b2){_0x595686['parts_']['length']>0x0&&(_0x595686['byteLength_']+=0x1),_0x595686['parts_']['push'](_0x5a50b2),_0x595686['byteLength_']+=Pn(_0x5a50b2),So(_0x595686);}function Rh(_0x4ce58e){const _0xd7e2f8=_0x4ce58e['parts_']['pop']();_0x4ce58e['byteLength_']-=Pn(_0xd7e2f8),_0x4ce58e['parts_']['length']>0x0&&(_0x4ce58e['byteLength_']-=0x1);}function So(_0x299d12){if(_0x299d12['byteLength_']>Js)throw new Error(_0x299d12['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x299d12['byteLength_']+').');if(_0x299d12['parts_']['length']>Qs)throw new Error(_0x299d12['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x299d12));}function Ne(_0x3e6188){return _0x3e6188['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3e6188['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x39e1c9,_0x312588;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x312588='visibilitychange',_0x39e1c9='hidden'):typeof document['mozHidden']<'u'?(_0x312588='mozvisibilitychange',_0x39e1c9='mozHidden'):typeof document['msHidden']<'u'?(_0x312588='msvisibilitychange',_0x39e1c9='msHidden'):typeof document['webkitHidden']<'u'&&(_0x312588='webkitvisibilitychange',_0x39e1c9='webkitHidden')),this['visible_']=!0x0,_0x312588&&document['addEventListener'](_0x312588,()=>{const _0x5a3536=!document[_0x39e1c9];_0x5a3536!==this['visible_']&&(this['visible_']=_0x5a3536,this['trigger']('visible',_0x5a3536));},!0x1);}['getInitialEvent'](_0x93a7b){return f(_0x93a7b==='visible','Unknown\x20event\x20type:\x20'+_0x93a7b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x1e327d,_0x780fc1,_0x3141a1,_0x5e8145,_0x35d43d,_0x336058,_0x2fbd09,_0x422705){if(super(),this['repoInfo_']=_0x1e327d,this['applicationId_']=_0x780fc1,this['onDataUpdate_']=_0x3141a1,this['onConnectStatus_']=_0x5e8145,this['onServerInfoUpdate_']=_0x35d43d,this['authTokenProvider_']=_0x336058,this['appCheckTokenProvider_']=_0x2fbd09,this['authOverride_']=_0x422705,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x422705)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1e327d['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4f6f2e,_0x25b546,_0x159a3d){const _0x274087=++this['requestNumber_'],_0xcaa29={'r':_0x274087,'a':_0x4f6f2e,'b':_0x25b546};this['log_'](O(_0xcaa29)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xcaa29),_0x159a3d&&(this['requestCBHash_'][_0x274087]=_0x159a3d);}['get'](_0x1ae57b){this['initConnection_']();const _0x1feeb1=new Ve(),_0xd046bd={'action':'g','request':{'p':_0x1ae57b['_path']['toString'](),'q':_0x1ae57b['_queryObject']},'onComplete':_0x523d68=>{const _0x42650b=_0x523d68['d'];_0x523d68['s']==='ok'?_0x1feeb1['resolve'](_0x42650b):_0x1feeb1['reject'](_0x42650b);}};this['outstandingGets_']['push'](_0xd046bd),this['outstandingGetCount_']++;const _0x5589eb=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5589eb),_0x1feeb1['promise'];}['listen'](_0x1bbac8,_0x38fd67,_0x22709f,_0x13a1b7){this['initConnection_']();const _0x2deccc=_0x1bbac8['_queryIdentifier'],_0x267d22=_0x1bbac8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x267d22+'\x20'+_0x2deccc),this['listens']['has'](_0x267d22)||this['listens']['set'](_0x267d22,new Map()),f(_0x1bbac8['_queryParams']['isDefault']()||!_0x1bbac8['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x267d22)['has'](_0x2deccc),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x430d91={'onComplete':_0x13a1b7,'hashFn':_0x38fd67,'query':_0x1bbac8,'tag':_0x22709f};this['listens']['get'](_0x267d22)['set'](_0x2deccc,_0x430d91),this['connected_']&&this['sendListen_'](_0x430d91);}['sendGet_'](_0x4fb64b){const _0x268f38=this['outstandingGets_'][_0x4fb64b];this['sendRequest']('g',_0x268f38['request'],_0x4c030f=>{delete this['outstandingGets_'][_0x4fb64b],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x268f38['onComplete']&&_0x268f38['onComplete'](_0x4c030f);});}['sendListen_'](_0x2e4188){const _0x4f9a15=_0x2e4188['query'],_0x1864c1=_0x4f9a15['_path']['toString'](),_0x109e12=_0x4f9a15['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1864c1+'\x20for\x20'+_0x109e12);const _0x1971a5={'p':_0x1864c1},_0x2834c1='q';_0x2e4188['tag']&&(_0x1971a5['q']=_0x4f9a15['_queryObject'],_0x1971a5['t']=_0x2e4188['tag']),_0x1971a5['h']=_0x2e4188['hashFn'](),this['sendRequest'](_0x2834c1,_0x1971a5,_0x1d22fa=>{const _0x5a6851=_0x1d22fa['d'],_0xae8c88=_0x1d22fa['s'];ie['warnOnListenWarnings_'](_0x5a6851,_0x4f9a15),(this['listens']['get'](_0x1864c1)&&this['listens']['get'](_0x1864c1)['get'](_0x109e12))===_0x2e4188&&(this['log_']('listen\x20response',_0x1d22fa),_0xae8c88!=='ok'&&this['removeListen_'](_0x1864c1,_0x109e12),_0x2e4188['onComplete']&&_0x2e4188['onComplete'](_0xae8c88,_0x5a6851));});}static['warnOnListenWarnings_'](_0x3f7bcd,_0x301b2b){if(_0x3f7bcd&&typeof _0x3f7bcd=='object'&&Y(_0x3f7bcd,'w')){const _0x437454=Oe(_0x3f7bcd,'w');if(Array['isArray'](_0x437454)&&~_0x437454['indexOf']('no_index')){const _0xbb68e3='\x22.indexOn\x22:\x20\x22'+_0x301b2b['_queryParams']['getIndex']()['toString']()+'\x22',_0x50e596=_0x301b2b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0xbb68e3+'\x20at\x20'+_0x50e596+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x28b2fd){this['authToken_']=_0x28b2fd,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x28b2fd);}['reduceReconnectDelayIfAdminCredential_'](_0x1ffddb){(_0x1ffddb&&_0x1ffddb['length']===0x28||vc(_0x1ffddb))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x11e7d4){this['appCheckToken_']=_0x11e7d4,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2caa23=this['authToken_'],_0x3d1221=yc(_0x2caa23)?'auth':'gauth',_0x1f4f30={'cred':_0x2caa23};this['authOverride_']===null?_0x1f4f30['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1f4f30['authvar']=this['authOverride_']),this['sendRequest'](_0x3d1221,_0x1f4f30,_0x4affe5=>{const _0x29b959=_0x4affe5['s'],_0x34fcb6=_0x4affe5['d']||'error';this['authToken_']===_0x2caa23&&(_0x29b959==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x29b959,_0x34fcb6));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5ea5f5=>{const _0x516068=_0x5ea5f5['s'],_0x4ef337=_0x5ea5f5['d']||'error';_0x516068==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x516068,_0x4ef337);});}['unlisten'](_0xdd1fa9,_0x279926){const _0x41098b=_0xdd1fa9['_path']['toString'](),_0x3b2454=_0xdd1fa9['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x41098b+'\x20'+_0x3b2454),f(_0xdd1fa9['_queryParams']['isDefault']()||!_0xdd1fa9['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x41098b,_0x3b2454)&&this['connected_']&&this['sendUnlisten_'](_0x41098b,_0x3b2454,_0xdd1fa9['_queryObject'],_0x279926);}['sendUnlisten_'](_0x68a7db,_0x5b9209,_0x263e00,_0x492782){this['log_']('Unlisten\x20on\x20'+_0x68a7db+'\x20for\x20'+_0x5b9209);const _0xaaeda2={'p':_0x68a7db},_0x10ec46='n';_0x492782&&(_0xaaeda2['q']=_0x263e00,_0xaaeda2['t']=_0x492782),this['sendRequest'](_0x10ec46,_0xaaeda2);}['onDisconnectPut'](_0x45e436,_0x5d3655,_0x48a26d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x45e436,_0x5d3655,_0x48a26d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x45e436,'action':'o','data':_0x5d3655,'onComplete':_0x48a26d});}['onDisconnectMerge'](_0x46f623,_0x5aaf13,_0x40bc39){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x46f623,_0x5aaf13,_0x40bc39):this['onDisconnectRequestQueue_']['push']({'pathString':_0x46f623,'action':'om','data':_0x5aaf13,'onComplete':_0x40bc39});}['onDisconnectCancel'](_0x66c183,_0x2e8cc2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x66c183,null,_0x2e8cc2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x66c183,'action':'oc','data':null,'onComplete':_0x2e8cc2});}['sendOnDisconnect_'](_0x17dd9a,_0x1da195,_0x4839b3,_0x338e59){const _0x4cd8b1={'p':_0x1da195,'d':_0x4839b3};this['log_']('onDisconnect\x20'+_0x17dd9a,_0x4cd8b1),this['sendRequest'](_0x17dd9a,_0x4cd8b1,_0x46cd03=>{_0x338e59&&setTimeout(()=>{_0x338e59(_0x46cd03['s'],_0x46cd03['d']);},Math['floor'](0x0));});}['put'](_0x3062a7,_0x1a3aff,_0xa8ae46,_0x596fbf){this['putInternal']('p',_0x3062a7,_0x1a3aff,_0xa8ae46,_0x596fbf);}['merge'](_0x438b30,_0x5b0d5f,_0x3d6776,_0x33ebf5){this['putInternal']('m',_0x438b30,_0x5b0d5f,_0x3d6776,_0x33ebf5);}['putInternal'](_0x418a67,_0xe62f05,_0x4e37a3,_0x336dd0,_0x5f399a){this['initConnection_']();const _0x34fa24={'p':_0xe62f05,'d':_0x4e37a3};_0x5f399a!==void 0x0&&(_0x34fa24['h']=_0x5f399a),this['outstandingPuts_']['push']({'action':_0x418a67,'request':_0x34fa24,'onComplete':_0x336dd0}),this['outstandingPutCount_']++;const _0x2d9521=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2d9521):this['log_']('Buffering\x20put:\x20'+_0xe62f05);}['sendPut_'](_0x208988){const _0x294f27=this['outstandingPuts_'][_0x208988]['action'],_0x38f4ef=this['outstandingPuts_'][_0x208988]['request'],_0x1a9260=this['outstandingPuts_'][_0x208988]['onComplete'];this['outstandingPuts_'][_0x208988]['queued']=this['connected_'],this['sendRequest'](_0x294f27,_0x38f4ef,_0x379253=>{this['log_'](_0x294f27+'\x20response',_0x379253),delete this['outstandingPuts_'][_0x208988],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1a9260&&_0x1a9260(_0x379253['s'],_0x379253['d']);});}['reportStats'](_0x186552){if(this['connected_']){const _0x2b759c={'c':_0x186552};this['log_']('reportStats',_0x2b759c),this['sendRequest']('s',_0x2b759c,_0x24cf2c=>{if(_0x24cf2c['s']!=='ok'){const _0x3734c2=_0x24cf2c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3734c2);}});}}['onDataMessage_'](_0x6217df){if('r'in _0x6217df){this['log_']('from\x20server:\x20'+O(_0x6217df));const _0x2d785f=_0x6217df['r'],_0x5d4fc4=this['requestCBHash_'][_0x2d785f];_0x5d4fc4&&(delete this['requestCBHash_'][_0x2d785f],_0x5d4fc4(_0x6217df['b']));}else{if('error'in _0x6217df)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x6217df['error'];'a'in _0x6217df&&this['onDataPush_'](_0x6217df['a'],_0x6217df['b']);}}['onDataPush_'](_0x872843,_0x1107f2){this['log_']('handleServerMessage',_0x872843,_0x1107f2),_0x872843==='d'?this['onDataUpdate_'](_0x1107f2['p'],_0x1107f2['d'],!0x1,_0x1107f2['t']):_0x872843==='m'?this['onDataUpdate_'](_0x1107f2['p'],_0x1107f2['d'],!0x0,_0x1107f2['t']):_0x872843==='c'?this['onListenRevoked_'](_0x1107f2['p'],_0x1107f2['q']):_0x872843==='ac'?this['onAuthRevoked_'](_0x1107f2['s'],_0x1107f2['d']):_0x872843==='apc'?this['onAppCheckRevoked_'](_0x1107f2['s'],_0x1107f2['d']):_0x872843==='sd'?this['onSecurityDebugPacket_'](_0x1107f2):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x872843)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x42dff4,_0x4503f6){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x42dff4),this['lastSessionId']=_0x4503f6,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x55ed8b){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x55ed8b));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x31239c){_0x31239c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x31239c;}['onOnline_'](_0x265df9){_0x265df9?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1a8fbf=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x44bb72=Math['max'](0x0,this['reconnectDelay_']-_0x1a8fbf);_0x44bb72=Math['random']()*_0x44bb72,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x44bb72+'ms'),this['scheduleConnect_'](_0x44bb72),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x34b377=this['onDataMessage_']['bind'](this),_0x14ddb4=this['onReady_']['bind'](this),_0x2fad7d=this['onRealtimeDisconnect_']['bind'](this),_0x51afd0=this['id']+':'+ie['nextConnectionId_']++,_0x41ae9b=this['lastSessionId'];let _0x4bdd2c=!0x1,_0x7e4a9=null;const _0x1c128b=function(){_0x7e4a9?_0x7e4a9['close']():(_0x4bdd2c=!0x0,_0x2fad7d());},_0xb21565=function(_0x5c68d2){f(_0x7e4a9,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x7e4a9['sendRequest'](_0x5c68d2);};this['realtime_']={'close':_0x1c128b,'sendRequest':_0xb21565};const _0x4d0755=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x378fc6,_0x1a460b]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4d0755),this['appCheckTokenProvider_']['getToken'](_0x4d0755)]);_0x4bdd2c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x378fc6&&_0x378fc6['accessToken'],this['appCheckToken_']=_0x1a460b&&_0x1a460b['token'],_0x7e4a9=new wh(_0x51afd0,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x34b377,_0x14ddb4,_0x2fad7d,_0x103917=>{U(_0x103917+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x41ae9b));}catch(_0x3dd61a){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3dd61a),_0x4bdd2c||(this['repoInfo_']['nodeAdmin']&&U(_0x3dd61a),_0x1c128b());}}}['interrupt'](_0x2dc195){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2dc195),this['interruptReasons_'][_0x2dc195]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4a8fd2){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4a8fd2),delete this['interruptReasons_'][_0x4a8fd2],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xd980d3){const _0x3f9ec5=_0xd980d3-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3f9ec5});}['cancelSentTransactions_'](){for(let _0x72e56e=0x0;_0x72e56e<this['outstandingPuts_']['length'];_0x72e56e++){const _0x23e63b=this['outstandingPuts_'][_0x72e56e];_0x23e63b&&'h'in _0x23e63b['request']&&_0x23e63b['queued']&&(_0x23e63b['onComplete']&&_0x23e63b['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x72e56e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3844ac,_0x3ccb60){let _0x5f4512;_0x3ccb60?_0x5f4512=_0x3ccb60['map'](_0x3fbb9c=>Bi(_0x3fbb9c))['join']('$'):_0x5f4512='default';const _0x12ad33=this['removeListen_'](_0x3844ac,_0x5f4512);_0x12ad33&&_0x12ad33['onComplete']&&_0x12ad33['onComplete']('permission_denied');}['removeListen_'](_0x1af7d0,_0x25972f){const _0xf70df0=new C(_0x1af7d0)['toString']();let _0x294836;if(this['listens']['has'](_0xf70df0)){const _0x8feea7=this['listens']['get'](_0xf70df0);_0x294836=_0x8feea7['get'](_0x25972f),_0x8feea7['delete'](_0x25972f),_0x8feea7['size']===0x0&&this['listens']['delete'](_0xf70df0);}else _0x294836=void 0x0;return _0x294836;}['onAuthRevoked_'](_0xee4da3,_0x4c9351){L('Auth\x20token\x20revoked:\x20'+_0xee4da3+'/'+_0x4c9351),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xee4da3==='invalid_token'||_0xee4da3==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x519204,_0x20c930){L('App\x20check\x20token\x20revoked:\x20'+_0x519204+'/'+_0x20c930),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x519204==='invalid_token'||_0x519204==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4793de){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4793de):'msg'in _0x4793de&&console['log']('FIREBASE:\x20'+_0x4793de['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x206217 of this['listens']['values']())for(const _0x54113c of _0x206217['values']())this['sendListen_'](_0x54113c);for(let _0x1374ac=0x0;_0x1374ac<this['outstandingPuts_']['length'];_0x1374ac++)this['outstandingPuts_'][_0x1374ac]&&this['sendPut_'](_0x1374ac);for(;this['onDisconnectRequestQueue_']['length'];){const _0x578d65=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x578d65['action'],_0x578d65['pathString'],_0x578d65['data'],_0x578d65['onComplete']);}for(let _0xa0fa07=0x0;_0xa0fa07<this['outstandingGets_']['length'];_0xa0fa07++)this['outstandingGets_'][_0xa0fa07]&&this['sendGet_'](_0xa0fa07);}['sendConnectStats_'](){const _0x5d571f={};let _0x11e492='js';_0x5d571f['sdk.'+_0x11e492+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x5d571f['framework.cordova']=0x1:qr()&&(_0x5d571f['framework.reactnative']=0x1),this['reportStats'](_0x5d571f);}['shouldReconnect_'](){const _0x21b3bf=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x21b3bf;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3bf9fe,_0x391585){this['name']=_0x3bf9fe,this['node']=_0x391585;}static['Wrap'](_0x37e3dd,_0x31ef5c){return new E(_0x37e3dd,_0x31ef5c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5e9544,_0x2ff8dc){const _0xb316ae=new E(xe,_0x5e9544),_0x429651=new E(xe,_0x2ff8dc);return this['compare'](_0xb316ae,_0x429651)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0xa0e3fb){Xt=_0xa0e3fb;}['compare'](_0x42c288,_0x25acba){return He(_0x42c288['name'],_0x25acba['name']);}['isDefinedOn'](_0x2f94ce){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xc14f5c,_0x16119e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x4e9044,_0xe02255){return f(typeof _0x4e9044=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4e9044,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x26a978,_0x4412c1,_0x13e689,_0x4d0000,_0x4675ed=null){this['isReverse_']=_0x4d0000,this['resultGenerator_']=_0x4675ed,this['nodeStack_']=[];let _0x508075=0x1;for(;!_0x26a978['isEmpty']();)if(_0x26a978=_0x26a978,_0x508075=_0x4412c1?_0x13e689(_0x26a978['key'],_0x4412c1):0x1,_0x4d0000&&(_0x508075*=-0x1),_0x508075<0x0)this['isReverse_']?_0x26a978=_0x26a978['left']:_0x26a978=_0x26a978['right'];else{if(_0x508075===0x0){this['nodeStack_']['push'](_0x26a978);break;}else this['nodeStack_']['push'](_0x26a978),this['isReverse_']?_0x26a978=_0x26a978['right']:_0x26a978=_0x26a978['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4a671b=this['nodeStack_']['pop'](),_0x124c9d;if(this['resultGenerator_']?_0x124c9d=this['resultGenerator_'](_0x4a671b['key'],_0x4a671b['value']):_0x124c9d={'key':_0x4a671b['key'],'value':_0x4a671b['value']},this['isReverse_']){for(_0x4a671b=_0x4a671b['left'];!_0x4a671b['isEmpty']();)this['nodeStack_']['push'](_0x4a671b),_0x4a671b=_0x4a671b['right'];}else{for(_0x4a671b=_0x4a671b['right'];!_0x4a671b['isEmpty']();)this['nodeStack_']['push'](_0x4a671b),_0x4a671b=_0x4a671b['left'];}return _0x124c9d;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x56b54f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x56b54f['key'],_0x56b54f['value']):{'key':_0x56b54f['key'],'value':_0x56b54f['value']};}}class M{constructor(_0x5b5418,_0x1a27e5,_0x113863,_0x13fb58,_0x4dda83){this['key']=_0x5b5418,this['value']=_0x1a27e5,this['color']=_0x113863??M['RED'],this['left']=_0x13fb58??B['EMPTY_NODE'],this['right']=_0x4dda83??B['EMPTY_NODE'];}['copy'](_0x374aa7,_0x52e424,_0x36d8ea,_0x167185,_0x5a6cf5){return new M(_0x374aa7??this['key'],_0x52e424??this['value'],_0x36d8ea??this['color'],_0x167185??this['left'],_0x5a6cf5??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x14d3ab){return this['left']['inorderTraversal'](_0x14d3ab)||!!_0x14d3ab(this['key'],this['value'])||this['right']['inorderTraversal'](_0x14d3ab);}['reverseTraversal'](_0x25bc8d){return this['right']['reverseTraversal'](_0x25bc8d)||_0x25bc8d(this['key'],this['value'])||this['left']['reverseTraversal'](_0x25bc8d);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5310b9,_0x1964d1,_0x33202c){let _0x515214=this;const _0x678a3a=_0x33202c(_0x5310b9,_0x515214['key']);return _0x678a3a<0x0?_0x515214=_0x515214['copy'](null,null,null,_0x515214['left']['insert'](_0x5310b9,_0x1964d1,_0x33202c),null):_0x678a3a===0x0?_0x515214=_0x515214['copy'](null,_0x1964d1,null,null,null):_0x515214=_0x515214['copy'](null,null,null,null,_0x515214['right']['insert'](_0x5310b9,_0x1964d1,_0x33202c)),_0x515214['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2d27a4=this;return!_0x2d27a4['left']['isRed_']()&&!_0x2d27a4['left']['left']['isRed_']()&&(_0x2d27a4=_0x2d27a4['moveRedLeft_']()),_0x2d27a4=_0x2d27a4['copy'](null,null,null,_0x2d27a4['left']['removeMin_'](),null),_0x2d27a4['fixUp_']();}['remove'](_0x31d233,_0x1f8426){let _0x3f7bce,_0x1616f1;if(_0x3f7bce=this,_0x1f8426(_0x31d233,_0x3f7bce['key'])<0x0)!_0x3f7bce['left']['isEmpty']()&&!_0x3f7bce['left']['isRed_']()&&!_0x3f7bce['left']['left']['isRed_']()&&(_0x3f7bce=_0x3f7bce['moveRedLeft_']()),_0x3f7bce=_0x3f7bce['copy'](null,null,null,_0x3f7bce['left']['remove'](_0x31d233,_0x1f8426),null);else{if(_0x3f7bce['left']['isRed_']()&&(_0x3f7bce=_0x3f7bce['rotateRight_']()),!_0x3f7bce['right']['isEmpty']()&&!_0x3f7bce['right']['isRed_']()&&!_0x3f7bce['right']['left']['isRed_']()&&(_0x3f7bce=_0x3f7bce['moveRedRight_']()),_0x1f8426(_0x31d233,_0x3f7bce['key'])===0x0){if(_0x3f7bce['right']['isEmpty']())return B['EMPTY_NODE'];_0x1616f1=_0x3f7bce['right']['min_'](),_0x3f7bce=_0x3f7bce['copy'](_0x1616f1['key'],_0x1616f1['value'],null,null,_0x3f7bce['right']['removeMin_']());}_0x3f7bce=_0x3f7bce['copy'](null,null,null,null,_0x3f7bce['right']['remove'](_0x31d233,_0x1f8426));}return _0x3f7bce['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3c0d68=this;return _0x3c0d68['right']['isRed_']()&&!_0x3c0d68['left']['isRed_']()&&(_0x3c0d68=_0x3c0d68['rotateLeft_']()),_0x3c0d68['left']['isRed_']()&&_0x3c0d68['left']['left']['isRed_']()&&(_0x3c0d68=_0x3c0d68['rotateRight_']()),_0x3c0d68['left']['isRed_']()&&_0x3c0d68['right']['isRed_']()&&(_0x3c0d68=_0x3c0d68['colorFlip_']()),_0x3c0d68;}['moveRedLeft_'](){let _0x4a26ef=this['colorFlip_']();return _0x4a26ef['right']['left']['isRed_']()&&(_0x4a26ef=_0x4a26ef['copy'](null,null,null,null,_0x4a26ef['right']['rotateRight_']()),_0x4a26ef=_0x4a26ef['rotateLeft_'](),_0x4a26ef=_0x4a26ef['colorFlip_']()),_0x4a26ef;}['moveRedRight_'](){let _0x1121fc=this['colorFlip_']();return _0x1121fc['left']['left']['isRed_']()&&(_0x1121fc=_0x1121fc['rotateRight_'](),_0x1121fc=_0x1121fc['colorFlip_']()),_0x1121fc;}['rotateLeft_'](){const _0x1225d7=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1225d7,null);}['rotateRight_'](){const _0x1b1511=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1b1511);}['colorFlip_'](){const _0x489db2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5d9b9f=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x489db2,_0x5d9b9f);}['checkMaxDepth_'](){const _0x5a402a=this['check_']();return Math['pow'](0x2,_0x5a402a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x3f226e=this['left']['check_']();if(_0x3f226e!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x3f226e+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x24cea9,_0x36f79f,_0xbebee6,_0x433d59,_0x281dbb){return this;}['insert'](_0x371cfa,_0x145bf4,_0x122279){return new M(_0x371cfa,_0x145bf4,null);}['remove'](_0x197849,_0x36f03a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xc911c6){return!0x1;}['reverseTraversal'](_0x4f3e75){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0xc926df,_0x4558be=B['EMPTY_NODE']){this['comparator_']=_0xc926df,this['root_']=_0x4558be;}['insert'](_0x3f06c7,_0xcf39db){return new B(this['comparator_'],this['root_']['insert'](_0x3f06c7,_0xcf39db,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x28e695){return new B(this['comparator_'],this['root_']['remove'](_0x28e695,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x468c79){let _0x2d46b0,_0x13f5e5=this['root_'];for(;!_0x13f5e5['isEmpty']();){if(_0x2d46b0=this['comparator_'](_0x468c79,_0x13f5e5['key']),_0x2d46b0===0x0)return _0x13f5e5['value'];_0x2d46b0<0x0?_0x13f5e5=_0x13f5e5['left']:_0x2d46b0>0x0&&(_0x13f5e5=_0x13f5e5['right']);}return null;}['getPredecessorKey'](_0x2afcfc){let _0x186bfa,_0x24cfb1=this['root_'],_0x3daf1c=null;for(;!_0x24cfb1['isEmpty']();)if(_0x186bfa=this['comparator_'](_0x2afcfc,_0x24cfb1['key']),_0x186bfa===0x0){if(_0x24cfb1['left']['isEmpty']())return _0x3daf1c?_0x3daf1c['key']:null;for(_0x24cfb1=_0x24cfb1['left'];!_0x24cfb1['right']['isEmpty']();)_0x24cfb1=_0x24cfb1['right'];return _0x24cfb1['key'];}else _0x186bfa<0x0?_0x24cfb1=_0x24cfb1['left']:_0x186bfa>0x0&&(_0x3daf1c=_0x24cfb1,_0x24cfb1=_0x24cfb1['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1bd7cb){return this['root_']['inorderTraversal'](_0x1bd7cb);}['reverseTraversal'](_0x396455){return this['root_']['reverseTraversal'](_0x396455);}['getIterator'](_0x1d67e1){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x1d67e1);}['getIteratorFrom'](_0x67bf59,_0x378943){return new Zt(this['root_'],_0x67bf59,this['comparator_'],!0x1,_0x378943);}['getReverseIteratorFrom'](_0x3eb2fa,_0x4b9042){return new Zt(this['root_'],_0x3eb2fa,this['comparator_'],!0x0,_0x4b9042);}['getReverseIterator'](_0x37891d){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x37891d);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x3096d4,_0x52dd90){return He(_0x3096d4['name'],_0x52dd90['name']);}function ji(_0x555de6,_0x1f74f7){return He(_0x555de6,_0x1f74f7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x10d56e){vi=_0x10d56e;}const Ro=function(_0x302526){return typeof _0x302526=='number'?'number:'+so(_0x302526):'string:'+_0x302526;},Ao=function(_0x1d23be){if(_0x1d23be['isLeafNode']()){const _0x48be2e=_0x1d23be['val']();f(typeof _0x48be2e=='string'||typeof _0x48be2e=='number'||typeof _0x48be2e=='object'&&Y(_0x48be2e,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1d23be===vi||_0x1d23be['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1d23be===vi||_0x1d23be['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x391fd7){er=_0x391fd7;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4c471f,_0x50e40d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4c471f,this['priorityNode_']=_0x50e40d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x12357a){return new D(this['value_'],_0x12357a);}['getImmediateChild'](_0x2473e2){return _0x2473e2==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0xa4902f){return v(_0xa4902f)?this:y(_0xa4902f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1c10bf,_0x58db7f){return null;}['updateImmediateChild'](_0x5b5cf5,_0x46cf91){return _0x5b5cf5==='.priority'?this['updatePriority'](_0x46cf91):_0x46cf91['isEmpty']()&&_0x5b5cf5!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5b5cf5,_0x46cf91)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x23ecd9,_0x42163e){const _0x3bef0f=y(_0x23ecd9);return _0x3bef0f===null?_0x42163e:_0x42163e['isEmpty']()&&_0x3bef0f!=='.priority'?this:(f(_0x3bef0f!=='.priority'||we(_0x23ecd9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3bef0f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x23ecd9),_0x42163e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x40b6e9,_0x1870b8){return!0x1;}['val'](_0x1277f5){return _0x1277f5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4d6835='';this['priorityNode_']['isEmpty']()||(_0x4d6835+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x423373=typeof this['value_'];_0x4d6835+=_0x423373+':',_0x423373==='number'?_0x4d6835+=so(this['value_']):_0x4d6835+=this['value_'],this['lazyHash_']=no(_0x4d6835);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2c3379){return _0x2c3379===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2c3379 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2c3379['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2c3379));}['compareToLeafNode_'](_0x2b8f25){const _0x4adf77=typeof _0x2b8f25['value_'],_0x3f9fda=typeof this['value_'],_0x1f7f26=D['VALUE_TYPE_ORDER']['indexOf'](_0x4adf77),_0x4fd653=D['VALUE_TYPE_ORDER']['indexOf'](_0x3f9fda);return f(_0x1f7f26>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4adf77),f(_0x4fd653>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3f9fda),_0x1f7f26===_0x4fd653?_0x3f9fda==='object'?0x0:this['value_']<_0x2b8f25['value_']?-0x1:this['value_']===_0x2b8f25['value_']?0x0:0x1:_0x4fd653-_0x1f7f26;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4e8c68){if(_0x4e8c68===this)return!0x0;if(_0x4e8c68['isLeafNode']()){const _0x39d869=_0x4e8c68;return this['value_']===_0x39d869['value_']&&this['priorityNode_']['equals'](_0x39d869['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x28185d){ko=_0x28185d;}function xh(_0x1c089e){No=_0x1c089e;}class Fh extends On{['compare'](_0xf9e19,_0xb3fe98){const _0x424e00=_0xf9e19['node']['getPriority'](),_0xce4c3b=_0xb3fe98['node']['getPriority'](),_0x29c358=_0x424e00['compareTo'](_0xce4c3b);return _0x29c358===0x0?He(_0xf9e19['name'],_0xb3fe98['name']):_0x29c358;}['isDefinedOn'](_0x54fcb1){return!_0x54fcb1['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5a2222,_0x2712d5){return!_0x5a2222['getPriority']()['equals'](_0x2712d5['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x5f099d,_0x4240a2){const _0x495423=ko(_0x5f099d);return new E(_0x4240a2,new D('[PRIORITY-POST]',_0x495423));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x37be62){const _0x56e360=_0x1423b3=>parseInt(Math['log'](_0x1423b3)/Uh,0xa),_0x1e4a83=_0xbcf79c=>parseInt(Array(_0xbcf79c+0x1)['join']('1'),0x2);this['count']=_0x56e360(_0x37be62+0x1),this['current_']=this['count']-0x1;const _0x42f849=_0x1e4a83(this['count']);this['bits_']=_0x37be62+0x1&_0x42f849;}['nextBitIsOne'](){const _0x25be7c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x25be7c;}}const dn=function(_0x3b57e2,_0x2b8ae4,_0x5e6a04,_0x278463){_0x3b57e2['sort'](_0x2b8ae4);const _0x37d1a9=function(_0x49403,_0x195210){const _0x3b8992=_0x195210-_0x49403;let _0x4577b3,_0x406f24;if(_0x3b8992===0x0)return null;if(_0x3b8992===0x1)return _0x4577b3=_0x3b57e2[_0x49403],_0x406f24=_0x5e6a04?_0x5e6a04(_0x4577b3):_0x4577b3,new M(_0x406f24,_0x4577b3['node'],M['BLACK'],null,null);{const _0x1d46ee=parseInt(_0x3b8992/0x2,0xa)+_0x49403,_0x18727e=_0x37d1a9(_0x49403,_0x1d46ee),_0x22ae36=_0x37d1a9(_0x1d46ee+0x1,_0x195210);return _0x4577b3=_0x3b57e2[_0x1d46ee],_0x406f24=_0x5e6a04?_0x5e6a04(_0x4577b3):_0x4577b3,new M(_0x406f24,_0x4577b3['node'],M['BLACK'],_0x18727e,_0x22ae36);}},_0x56d264=function(_0x385868){let _0x4fbea6=null,_0x48e756=null,_0x3d4982=_0x3b57e2['length'];const _0x2ddc90=function(_0xbd2c7e,_0xce573c){const _0x519d01=_0x3d4982-_0xbd2c7e,_0x4f15ff=_0x3d4982;_0x3d4982-=_0xbd2c7e;const _0x3d5027=_0x37d1a9(_0x519d01+0x1,_0x4f15ff),_0x79c41c=_0x3b57e2[_0x519d01],_0xdc1a8c=_0x5e6a04?_0x5e6a04(_0x79c41c):_0x79c41c;_0xc42065(new M(_0xdc1a8c,_0x79c41c['node'],_0xce573c,null,_0x3d5027));},_0xc42065=function(_0x5778b3){_0x4fbea6?(_0x4fbea6['left']=_0x5778b3,_0x4fbea6=_0x5778b3):(_0x48e756=_0x5778b3,_0x4fbea6=_0x5778b3);};for(let _0x1d88f9=0x0;_0x1d88f9<_0x385868['count'];++_0x1d88f9){const _0x3dc1b0=_0x385868['nextBitIsOne'](),_0x343558=Math['pow'](0x2,_0x385868['count']-(_0x1d88f9+0x1));_0x3dc1b0?_0x2ddc90(_0x343558,M['BLACK']):(_0x2ddc90(_0x343558,M['BLACK']),_0x2ddc90(_0x343558,M['RED']));}return _0x48e756;},_0x145a97=new Wh(_0x3b57e2['length']),_0x50fb08=_0x56d264(_0x145a97);return new B(_0x278463||_0x2b8ae4,_0x50fb08);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x20d5cd,_0x296c6e){this['indexes_']=_0x20d5cd,this['indexSet_']=_0x296c6e;}['get'](_0x2de5cf){const _0x43a414=Oe(this['indexes_'],_0x2de5cf);if(!_0x43a414)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2de5cf);return _0x43a414 instanceof B?_0x43a414:null;}['hasIndex'](_0x588a57){return Y(this['indexSet_'],_0x588a57['toString']());}['addIndex'](_0x37a5cd,_0x445558){f(_0x37a5cd!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x57c9c6=[];let _0x2bb50d=!0x1;const _0x7236ec=_0x445558['getIterator'](E['Wrap']);let _0x57893c=_0x7236ec['getNext']();for(;_0x57893c;)_0x2bb50d=_0x2bb50d||_0x37a5cd['isDefinedOn'](_0x57893c['node']),_0x57c9c6['push'](_0x57893c),_0x57893c=_0x7236ec['getNext']();let _0x821398;_0x2bb50d?_0x821398=dn(_0x57c9c6,_0x37a5cd['getCompare']()):_0x821398=je;const _0x23302d=_0x37a5cd['toString'](),_0x11685e={...this['indexSet_']};_0x11685e[_0x23302d]=_0x37a5cd;const _0x21ba66={...this['indexes_']};return _0x21ba66[_0x23302d]=_0x821398,new ee(_0x21ba66,_0x11685e);}['addToIndexes'](_0xd43397,_0x32e710){const _0x5921e2=ln(this['indexes_'],(_0x25effe,_0x183728)=>{const _0x2d2d47=Oe(this['indexSet_'],_0x183728);if(f(_0x2d2d47,'Missing\x20index\x20implementation\x20for\x20'+_0x183728),_0x25effe===je){if(_0x2d2d47['isDefinedOn'](_0xd43397['node'])){const _0x56f828=[],_0x363649=_0x32e710['getIterator'](E['Wrap']);let _0x55ef34=_0x363649['getNext']();for(;_0x55ef34;)_0x55ef34['name']!==_0xd43397['name']&&_0x56f828['push'](_0x55ef34),_0x55ef34=_0x363649['getNext']();return _0x56f828['push'](_0xd43397),dn(_0x56f828,_0x2d2d47['getCompare']());}else return je;}else{const _0x4b1feb=_0x32e710['get'](_0xd43397['name']);let _0x2d66d9=_0x25effe;return _0x4b1feb&&(_0x2d66d9=_0x2d66d9['remove'](new E(_0xd43397['name'],_0x4b1feb))),_0x2d66d9['insert'](_0xd43397,_0xd43397['node']);}});return new ee(_0x5921e2,this['indexSet_']);}['removeFromIndexes'](_0x709ae1,_0x48efd5){const _0x390f0c=ln(this['indexes_'],_0x2d6b20=>{if(_0x2d6b20===je)return _0x2d6b20;{const _0x532d57=_0x48efd5['get'](_0x709ae1['name']);return _0x532d57?_0x2d6b20['remove'](new E(_0x709ae1['name'],_0x532d57)):_0x2d6b20;}});return new ee(_0x390f0c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x1706d2,_0x4b5aa9,_0x2bb5c9){this['children_']=_0x1706d2,this['priorityNode_']=_0x4b5aa9,this['indexMap_']=_0x2bb5c9,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x51d272){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x51d272,this['indexMap_']);}['getImmediateChild'](_0x501d63){if(_0x501d63==='.priority')return this['getPriority']();{const _0x389ab5=this['children_']['get'](_0x501d63);return _0x389ab5===null?gt:_0x389ab5;}}['getChild'](_0x5dd5b4){const _0x3a8fd1=y(_0x5dd5b4);return _0x3a8fd1===null?this:this['getImmediateChild'](_0x3a8fd1)['getChild'](b(_0x5dd5b4));}['hasChild'](_0x3bd68f){return this['children_']['get'](_0x3bd68f)!==null;}['updateImmediateChild'](_0x4bb141,_0x3878de){if(f(_0x3878de,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4bb141==='.priority')return this['updatePriority'](_0x3878de);{const _0xcf9771=new E(_0x4bb141,_0x3878de);let _0x193019,_0x48bdd9;_0x3878de['isEmpty']()?(_0x193019=this['children_']['remove'](_0x4bb141),_0x48bdd9=this['indexMap_']['removeFromIndexes'](_0xcf9771,this['children_'])):(_0x193019=this['children_']['insert'](_0x4bb141,_0x3878de),_0x48bdd9=this['indexMap_']['addToIndexes'](_0xcf9771,this['children_']));const _0x55bfdd=_0x193019['isEmpty']()?gt:this['priorityNode_'];return new g(_0x193019,_0x55bfdd,_0x48bdd9);}}['updateChild'](_0x4f9718,_0x171299){const _0x565e6e=y(_0x4f9718);if(_0x565e6e===null)return _0x171299;{f(y(_0x4f9718)!=='.priority'||we(_0x4f9718)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4669a6=this['getImmediateChild'](_0x565e6e)['updateChild'](b(_0x4f9718),_0x171299);return this['updateImmediateChild'](_0x565e6e,_0x4669a6);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xb2b7f7){if(this['isEmpty']())return null;const _0x570625={};let _0x4c9b79=0x0,_0x470575=0x0,_0x2bd6a7=!0x0;if(this['forEachChild'](R,(_0x4ee4d0,_0xdc14d4)=>{_0x570625[_0x4ee4d0]=_0xdc14d4['val'](_0xb2b7f7),_0x4c9b79++,_0x2bd6a7&&g['INTEGER_REGEXP_']['test'](_0x4ee4d0)?_0x470575=Math['max'](_0x470575,Number(_0x4ee4d0)):_0x2bd6a7=!0x1;}),!_0xb2b7f7&&_0x2bd6a7&&_0x470575<0x2*_0x4c9b79){const _0x32b14d=[];for(const _0x1634f5 in _0x570625)_0x32b14d[_0x1634f5]=_0x570625[_0x1634f5];return _0x32b14d;}else return _0xb2b7f7&&!this['getPriority']()['isEmpty']()&&(_0x570625['.priority']=this['getPriority']()['val']()),_0x570625;}['hash'](){if(this['lazyHash_']===null){let _0x228c7e='';this['getPriority']()['isEmpty']()||(_0x228c7e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2cb173,_0x5738a4)=>{const _0x483473=_0x5738a4['hash']();_0x483473!==''&&(_0x228c7e+=':'+_0x2cb173+':'+_0x483473);}),this['lazyHash_']=_0x228c7e===''?'':no(_0x228c7e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x467c07,_0x4a4379,_0x2ca26e){const _0x3144b5=this['resolveIndex_'](_0x2ca26e);if(_0x3144b5){const _0x3a2e19=_0x3144b5['getPredecessorKey'](new E(_0x467c07,_0x4a4379));return _0x3a2e19?_0x3a2e19['name']:null;}else return this['children_']['getPredecessorKey'](_0x467c07);}['getFirstChildName'](_0x14a911){const _0x2331f3=this['resolveIndex_'](_0x14a911);if(_0x2331f3){const _0x171234=_0x2331f3['minKey']();return _0x171234&&_0x171234['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x328680){const _0x10ca6f=this['getFirstChildName'](_0x328680);return _0x10ca6f?new E(_0x10ca6f,this['children_']['get'](_0x10ca6f)):null;}['getLastChildName'](_0x202fa8){const _0x3a6004=this['resolveIndex_'](_0x202fa8);if(_0x3a6004){const _0x430130=_0x3a6004['maxKey']();return _0x430130&&_0x430130['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x37d649){const _0x31b0ae=this['getLastChildName'](_0x37d649);return _0x31b0ae?new E(_0x31b0ae,this['children_']['get'](_0x31b0ae)):null;}['forEachChild'](_0xb00ca2,_0x21c1db){const _0x4b4334=this['resolveIndex_'](_0xb00ca2);return _0x4b4334?_0x4b4334['inorderTraversal'](_0xf0b516=>_0x21c1db(_0xf0b516['name'],_0xf0b516['node'])):this['children_']['inorderTraversal'](_0x21c1db);}['getIterator'](_0x572f41){return this['getIteratorFrom'](_0x572f41['minPost'](),_0x572f41);}['getIteratorFrom'](_0x22a956,_0x569540){const _0x1ef087=this['resolveIndex_'](_0x569540);if(_0x1ef087)return _0x1ef087['getIteratorFrom'](_0x22a956,_0x81f5ff=>_0x81f5ff);{const _0x1731ec=this['children_']['getIteratorFrom'](_0x22a956['name'],E['Wrap']);let _0x336833=_0x1731ec['peek']();for(;_0x336833!=null&&_0x569540['compare'](_0x336833,_0x22a956)<0x0;)_0x1731ec['getNext'](),_0x336833=_0x1731ec['peek']();return _0x1731ec;}}['getReverseIterator'](_0x289ba1){return this['getReverseIteratorFrom'](_0x289ba1['maxPost'](),_0x289ba1);}['getReverseIteratorFrom'](_0x52a355,_0x4963f5){const _0x264fa5=this['resolveIndex_'](_0x4963f5);if(_0x264fa5)return _0x264fa5['getReverseIteratorFrom'](_0x52a355,_0x52679a=>_0x52679a);{const _0x380926=this['children_']['getReverseIteratorFrom'](_0x52a355['name'],E['Wrap']);let _0x8b93e6=_0x380926['peek']();for(;_0x8b93e6!=null&&_0x4963f5['compare'](_0x8b93e6,_0x52a355)>0x0;)_0x380926['getNext'](),_0x8b93e6=_0x380926['peek']();return _0x380926;}}['compareTo'](_0x3abf95){return this['isEmpty']()?_0x3abf95['isEmpty']()?0x0:-0x1:_0x3abf95['isLeafNode']()||_0x3abf95['isEmpty']()?0x1:_0x3abf95===Ht?-0x1:0x0;}['withIndex'](_0x3cd0a5){if(_0x3cd0a5===ye||this['indexMap_']['hasIndex'](_0x3cd0a5))return this;{const _0x10221a=this['indexMap_']['addIndex'](_0x3cd0a5,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x10221a);}}['isIndexed'](_0xf50e6f){return _0xf50e6f===ye||this['indexMap_']['hasIndex'](_0xf50e6f);}['equals'](_0x2025a9){if(_0x2025a9===this)return!0x0;if(_0x2025a9['isLeafNode']())return!0x1;{const _0xd631e8=_0x2025a9;if(this['getPriority']()['equals'](_0xd631e8['getPriority']())){if(this['children_']['count']()===_0xd631e8['children_']['count']()){const _0x1bc3b7=this['getIterator'](R),_0x3458fb=_0xd631e8['getIterator'](R);let _0x34881c=_0x1bc3b7['getNext'](),_0x31bc14=_0x3458fb['getNext']();for(;_0x34881c&&_0x31bc14;){if(_0x34881c['name']!==_0x31bc14['name']||!_0x34881c['node']['equals'](_0x31bc14['node']))return!0x1;_0x34881c=_0x1bc3b7['getNext'](),_0x31bc14=_0x3458fb['getNext']();}return _0x34881c===null&&_0x31bc14===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x206fb6){return _0x206fb6===ye?null:this['indexMap_']['get'](_0x206fb6['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x273be9){return _0x273be9===this?0x0:0x1;}['equals'](_0x18c86d){return _0x18c86d===this;}['getPriority'](){return this;}['getImmediateChild'](_0x53b84e){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x1ed645,_0x2a5ef2=null){if(_0x1ed645===null)return g['EMPTY_NODE'];if(typeof _0x1ed645=='object'&&'.priority'in _0x1ed645&&(_0x2a5ef2=_0x1ed645['.priority']),f(_0x2a5ef2===null||typeof _0x2a5ef2=='string'||typeof _0x2a5ef2=='number'||typeof _0x2a5ef2=='object'&&'.sv'in _0x2a5ef2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2a5ef2),typeof _0x1ed645=='object'&&'.value'in _0x1ed645&&_0x1ed645['.value']!==null&&(_0x1ed645=_0x1ed645['.value']),typeof _0x1ed645!='object'||'.sv'in _0x1ed645){const _0xb0df32=_0x1ed645;return new D(_0xb0df32,N(_0x2a5ef2));}if(!(_0x1ed645 instanceof Array)&&Vh){const _0x296f7e=[];let _0x112359=!0x1;if(x(_0x1ed645,(_0x25f0f0,_0x5f39a2)=>{if(_0x25f0f0['substring'](0x0,0x1)!=='.'){const _0x36833d=N(_0x5f39a2);_0x36833d['isEmpty']()||(_0x112359=_0x112359||!_0x36833d['getPriority']()['isEmpty'](),_0x296f7e['push'](new E(_0x25f0f0,_0x36833d)));}}),_0x296f7e['length']===0x0)return g['EMPTY_NODE'];const _0x3008a9=dn(_0x296f7e,Dh,_0x4b0740=>_0x4b0740['name'],ji);if(_0x112359){const _0x180514=dn(_0x296f7e,R['getCompare']());return new g(_0x3008a9,N(_0x2a5ef2),new ee({'.priority':_0x180514},{'.priority':R}));}else return new g(_0x3008a9,N(_0x2a5ef2),ee['Default']);}else{let _0x48a84c=g['EMPTY_NODE'];return x(_0x1ed645,(_0x2d6916,_0x56147e)=>{if(Y(_0x1ed645,_0x2d6916)&&_0x2d6916['substring'](0x0,0x1)!=='.'){const _0x267942=N(_0x56147e);(_0x267942['isLeafNode']()||!_0x267942['isEmpty']())&&(_0x48a84c=_0x48a84c['updateImmediateChild'](_0x2d6916,_0x267942));}}),_0x48a84c['updatePriority'](N(_0x2a5ef2));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2840d8){super(),this['indexPath_']=_0x2840d8,f(!v(_0x2840d8)&&y(_0x2840d8)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5af5ba){return _0x5af5ba['getChild'](this['indexPath_']);}['isDefinedOn'](_0x331db1){return!_0x331db1['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3385ce,_0x25874f){const _0x4a0293=this['extractChild'](_0x3385ce['node']),_0x443ecf=this['extractChild'](_0x25874f['node']),_0x1125ba=_0x4a0293['compareTo'](_0x443ecf);return _0x1125ba===0x0?He(_0x3385ce['name'],_0x25874f['name']):_0x1125ba;}['makePost'](_0x534024,_0x4f4b00){const _0x100a91=N(_0x534024),_0x31ce30=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x100a91);return new E(_0x4f4b00,_0x31ce30);}['maxPost'](){const _0x427e91=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x427e91);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0xe26f67,_0x577b90){const _0x4f9f7a=_0xe26f67['node']['compareTo'](_0x577b90['node']);return _0x4f9f7a===0x0?He(_0xe26f67['name'],_0x577b90['name']):_0x4f9f7a;}['isDefinedOn'](_0x3a4cea){return!0x0;}['indexedValueChanged'](_0x7d07b3,_0x453ea7){return!_0x7d07b3['equals'](_0x453ea7);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4d7bad,_0x373b92){const _0x6f7bba=N(_0x4d7bad);return new E(_0x373b92,_0x6f7bba);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x4f29c9){return{'type':'value','snapshotNode':_0x4f29c9};}function tt(_0x24b5aa,_0x25476d){return{'type':'child_added','snapshotNode':_0x25476d,'childName':_0x24b5aa};}function Nt(_0x208845,_0x56c485){return{'type':'child_removed','snapshotNode':_0x56c485,'childName':_0x208845};}function Pt(_0x4c7638,_0x2753f6,_0x258ad0){return{'type':'child_changed','snapshotNode':_0x2753f6,'childName':_0x4c7638,'oldSnap':_0x258ad0};}function $h(_0x13a59a,_0x261ba2){return{'type':'child_moved','snapshotNode':_0x261ba2,'childName':_0x13a59a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x21c7fe){this['index_']=_0x21c7fe;}['updateChild'](_0x2f0abc,_0x2ad757,_0x30e5b8,_0x43ccba,_0x174f2f,_0xa943ac){f(_0x2f0abc['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x49865a=_0x2f0abc['getImmediateChild'](_0x2ad757);return _0x49865a['getChild'](_0x43ccba)['equals'](_0x30e5b8['getChild'](_0x43ccba))&&_0x49865a['isEmpty']()===_0x30e5b8['isEmpty']()||(_0xa943ac!=null&&(_0x30e5b8['isEmpty']()?_0x2f0abc['hasChild'](_0x2ad757)?_0xa943ac['trackChildChange'](Nt(_0x2ad757,_0x49865a)):f(_0x2f0abc['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x49865a['isEmpty']()?_0xa943ac['trackChildChange'](tt(_0x2ad757,_0x30e5b8)):_0xa943ac['trackChildChange'](Pt(_0x2ad757,_0x30e5b8,_0x49865a))),_0x2f0abc['isLeafNode']()&&_0x30e5b8['isEmpty']())?_0x2f0abc:_0x2f0abc['updateImmediateChild'](_0x2ad757,_0x30e5b8)['withIndex'](this['index_']);}['updateFullNode'](_0x2755a9,_0x2e278c,_0x4172e7){return _0x4172e7!=null&&(_0x2755a9['isLeafNode']()||_0x2755a9['forEachChild'](R,(_0x546645,_0x5e2d05)=>{_0x2e278c['hasChild'](_0x546645)||_0x4172e7['trackChildChange'](Nt(_0x546645,_0x5e2d05));}),_0x2e278c['isLeafNode']()||_0x2e278c['forEachChild'](R,(_0x48191f,_0x288251)=>{if(_0x2755a9['hasChild'](_0x48191f)){const _0xaa1339=_0x2755a9['getImmediateChild'](_0x48191f);_0xaa1339['equals'](_0x288251)||_0x4172e7['trackChildChange'](Pt(_0x48191f,_0x288251,_0xaa1339));}else _0x4172e7['trackChildChange'](tt(_0x48191f,_0x288251));})),_0x2e278c['withIndex'](this['index_']);}['updatePriority'](_0x2ef5b7,_0x4f064f){return _0x2ef5b7['isEmpty']()?g['EMPTY_NODE']:_0x2ef5b7['updatePriority'](_0x4f064f);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0xd2a912){this['indexedFilter_']=new Yi(_0xd2a912['getIndex']()),this['index_']=_0xd2a912['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0xd2a912),this['endPost_']=Ot['getEndPost_'](_0xd2a912),this['startIsInclusive_']=!_0xd2a912['startAfterSet_'],this['endIsInclusive_']=!_0xd2a912['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x984090){const _0x41bcc7=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x984090)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x984090)<0x0,_0x540b37=this['endIsInclusive_']?this['index_']['compare'](_0x984090,this['getEndPost']())<=0x0:this['index_']['compare'](_0x984090,this['getEndPost']())<0x0;return _0x41bcc7&&_0x540b37;}['updateChild'](_0x21cce0,_0x229c01,_0x19fc79,_0xcff423,_0x164177,_0x573225){return this['matches'](new E(_0x229c01,_0x19fc79))||(_0x19fc79=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x21cce0,_0x229c01,_0x19fc79,_0xcff423,_0x164177,_0x573225);}['updateFullNode'](_0x1ece4b,_0x1f1920,_0x26c888){_0x1f1920['isLeafNode']()&&(_0x1f1920=g['EMPTY_NODE']);let _0x695ffb=_0x1f1920['withIndex'](this['index_']);_0x695ffb=_0x695ffb['updatePriority'](g['EMPTY_NODE']);const _0x9473a6=this;return _0x1f1920['forEachChild'](R,(_0x175c6b,_0x227594)=>{_0x9473a6['matches'](new E(_0x175c6b,_0x227594))||(_0x695ffb=_0x695ffb['updateImmediateChild'](_0x175c6b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1ece4b,_0x695ffb,_0x26c888);}['updatePriority'](_0x336154,_0x9c7d19){return _0x336154;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2c049e){if(_0x2c049e['hasStart']()){const _0x463654=_0x2c049e['getIndexStartName']();return _0x2c049e['getIndex']()['makePost'](_0x2c049e['getIndexStartValue'](),_0x463654);}else return _0x2c049e['getIndex']()['minPost']();}static['getEndPost_'](_0x28666c){if(_0x28666c['hasEnd']()){const _0x2499f4=_0x28666c['getIndexEndName']();return _0x28666c['getIndex']()['makePost'](_0x28666c['getIndexEndValue'](),_0x2499f4);}else return _0x28666c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x3399d0){this['withinDirectionalStart']=_0x5e57ce=>this['reverse_']?this['withinEndPost'](_0x5e57ce):this['withinStartPost'](_0x5e57ce),this['withinDirectionalEnd']=_0x16e4e3=>this['reverse_']?this['withinStartPost'](_0x16e4e3):this['withinEndPost'](_0x16e4e3),this['withinStartPost']=_0x3775e6=>{const _0x3271d4=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3775e6);return this['startIsInclusive_']?_0x3271d4<=0x0:_0x3271d4<0x0;},this['withinEndPost']=_0x1730b1=>{const _0x467010=this['index_']['compare'](_0x1730b1,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x467010<=0x0:_0x467010<0x0;},this['rangedFilter_']=new Ot(_0x3399d0),this['index_']=_0x3399d0['getIndex'](),this['limit_']=_0x3399d0['getLimit'](),this['reverse_']=!_0x3399d0['isViewFromLeft'](),this['startIsInclusive_']=!_0x3399d0['startAfterSet_'],this['endIsInclusive_']=!_0x3399d0['endBeforeSet_'];}['updateChild'](_0x16e988,_0x959c1,_0x3327bc,_0x85011,_0x5e1228,_0x1c043e){return this['rangedFilter_']['matches'](new E(_0x959c1,_0x3327bc))||(_0x3327bc=g['EMPTY_NODE']),_0x16e988['getImmediateChild'](_0x959c1)['equals'](_0x3327bc)?_0x16e988:_0x16e988['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x16e988,_0x959c1,_0x3327bc,_0x85011,_0x5e1228,_0x1c043e):this['fullLimitUpdateChild_'](_0x16e988,_0x959c1,_0x3327bc,_0x5e1228,_0x1c043e);}['updateFullNode'](_0x1660e7,_0x1a1ff4,_0x31ce5d){let _0x3cfd67;if(_0x1a1ff4['isLeafNode']()||_0x1a1ff4['isEmpty']())_0x3cfd67=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1a1ff4['numChildren']()&&_0x1a1ff4['isIndexed'](this['index_'])){_0x3cfd67=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3a3605;this['reverse_']?_0x3a3605=_0x1a1ff4['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3a3605=_0x1a1ff4['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x167989=0x0;for(;_0x3a3605['hasNext']()&&_0x167989<this['limit_'];){const _0x3758c7=_0x3a3605['getNext']();if(this['withinDirectionalStart'](_0x3758c7)){if(this['withinDirectionalEnd'](_0x3758c7))_0x3cfd67=_0x3cfd67['updateImmediateChild'](_0x3758c7['name'],_0x3758c7['node']),_0x167989++;else break;}else continue;}}else{_0x3cfd67=_0x1a1ff4['withIndex'](this['index_']),_0x3cfd67=_0x3cfd67['updatePriority'](g['EMPTY_NODE']);let _0x1a3335;this['reverse_']?_0x1a3335=_0x3cfd67['getReverseIterator'](this['index_']):_0x1a3335=_0x3cfd67['getIterator'](this['index_']);let _0x1ec5a7=0x0;for(;_0x1a3335['hasNext']();){const _0x192819=_0x1a3335['getNext']();_0x1ec5a7<this['limit_']&&this['withinDirectionalStart'](_0x192819)&&this['withinDirectionalEnd'](_0x192819)?_0x1ec5a7++:_0x3cfd67=_0x3cfd67['updateImmediateChild'](_0x192819['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1660e7,_0x3cfd67,_0x31ce5d);}['updatePriority'](_0x3e44d4,_0x445f2c){return _0x3e44d4;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x56c877,_0x121dd3,_0x19407a,_0xe4a043,_0x29384b){let _0x282b70;if(this['reverse_']){const _0x47564a=this['index_']['getCompare']();_0x282b70=(_0x4b2861,_0xb6d3b8)=>_0x47564a(_0xb6d3b8,_0x4b2861);}else _0x282b70=this['index_']['getCompare']();const _0x2702d7=_0x56c877;f(_0x2702d7['numChildren']()===this['limit_'],'');const _0x5e2119=new E(_0x121dd3,_0x19407a),_0xc4c3f5=this['reverse_']?_0x2702d7['getFirstChild'](this['index_']):_0x2702d7['getLastChild'](this['index_']),_0x223c38=this['rangedFilter_']['matches'](_0x5e2119);if(_0x2702d7['hasChild'](_0x121dd3)){const _0x3e970e=_0x2702d7['getImmediateChild'](_0x121dd3);let _0x1f0a59=_0xe4a043['getChildAfterChild'](this['index_'],_0xc4c3f5,this['reverse_']);for(;_0x1f0a59!=null&&(_0x1f0a59['name']===_0x121dd3||_0x2702d7['hasChild'](_0x1f0a59['name']));)_0x1f0a59=_0xe4a043['getChildAfterChild'](this['index_'],_0x1f0a59,this['reverse_']);const _0x210a79=_0x1f0a59==null?0x1:_0x282b70(_0x1f0a59,_0x5e2119);if(_0x223c38&&!_0x19407a['isEmpty']()&&_0x210a79>=0x0)return _0x29384b!=null&&_0x29384b['trackChildChange'](Pt(_0x121dd3,_0x19407a,_0x3e970e)),_0x2702d7['updateImmediateChild'](_0x121dd3,_0x19407a);{_0x29384b!=null&&_0x29384b['trackChildChange'](Nt(_0x121dd3,_0x3e970e));const _0x95bbac=_0x2702d7['updateImmediateChild'](_0x121dd3,g['EMPTY_NODE']);return _0x1f0a59!=null&&this['rangedFilter_']['matches'](_0x1f0a59)?(_0x29384b!=null&&_0x29384b['trackChildChange'](tt(_0x1f0a59['name'],_0x1f0a59['node'])),_0x95bbac['updateImmediateChild'](_0x1f0a59['name'],_0x1f0a59['node'])):_0x95bbac;}}else return _0x19407a['isEmpty']()?_0x56c877:_0x223c38&&_0x282b70(_0xc4c3f5,_0x5e2119)>=0x0?(_0x29384b!=null&&(_0x29384b['trackChildChange'](Nt(_0xc4c3f5['name'],_0xc4c3f5['node'])),_0x29384b['trackChildChange'](tt(_0x121dd3,_0x19407a))),_0x2702d7['updateImmediateChild'](_0x121dd3,_0x19407a)['updateImmediateChild'](_0xc4c3f5['name'],g['EMPTY_NODE'])):_0x56c877;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2c7199=new Qi();return _0x2c7199['limitSet_']=this['limitSet_'],_0x2c7199['limit_']=this['limit_'],_0x2c7199['startSet_']=this['startSet_'],_0x2c7199['startAfterSet_']=this['startAfterSet_'],_0x2c7199['indexStartValue_']=this['indexStartValue_'],_0x2c7199['startNameSet_']=this['startNameSet_'],_0x2c7199['indexStartName_']=this['indexStartName_'],_0x2c7199['endSet_']=this['endSet_'],_0x2c7199['endBeforeSet_']=this['endBeforeSet_'],_0x2c7199['indexEndValue_']=this['indexEndValue_'],_0x2c7199['endNameSet_']=this['endNameSet_'],_0x2c7199['indexEndName_']=this['indexEndName_'],_0x2c7199['index_']=this['index_'],_0x2c7199['viewFrom_']=this['viewFrom_'],_0x2c7199;}}function qh(_0x1af65d){return _0x1af65d['loadsAllData']()?new Yi(_0x1af65d['getIndex']()):_0x1af65d['hasLimit']()?new Gh(_0x1af65d):new Ot(_0x1af65d);}function zh(_0x79ff1,_0x4849ef){const _0x49d657=_0x79ff1['copy']();return _0x49d657['limitSet_']=!0x0,_0x49d657['limit_']=_0x4849ef,_0x49d657['viewFrom_']='l',_0x49d657;}function jh(_0x2faa47,_0xb15008,_0x3b26fd){const _0x1b8838=_0x2faa47['copy']();return _0x1b8838['startSet_']=!0x0,_0xb15008===void 0x0&&(_0xb15008=null),_0x1b8838['indexStartValue_']=_0xb15008,_0x3b26fd!=null?(_0x1b8838['startNameSet_']=!0x0,_0x1b8838['indexStartName_']=_0x3b26fd):(_0x1b8838['startNameSet_']=!0x1,_0x1b8838['indexStartName_']=''),_0x1b8838;}function Kh(_0x1d590a,_0x515cca,_0x531199){const _0x371657=_0x1d590a['copy']();return _0x371657['endSet_']=!0x0,_0x515cca===void 0x0&&(_0x515cca=null),_0x371657['indexEndValue_']=_0x515cca,_0x531199!==void 0x0?(_0x371657['endNameSet_']=!0x0,_0x371657['indexEndName_']=_0x531199):(_0x371657['endNameSet_']=!0x1,_0x371657['indexEndName_']=''),_0x371657;}function Do(_0x47cfd5,_0x2641da){const _0xac329e=_0x47cfd5['copy']();return _0xac329e['index_']=_0x2641da,_0xac329e;}function tr(_0x2fc871){const _0x5466f9={};if(_0x2fc871['isDefault']())return _0x5466f9;let _0x4eee59;if(_0x2fc871['index_']===R?_0x4eee59='$priority':_0x2fc871['index_']===Po?_0x4eee59='$value':_0x2fc871['index_']===ye?_0x4eee59='$key':(f(_0x2fc871['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x4eee59=_0x2fc871['index_']['toString']()),_0x5466f9['orderBy']=O(_0x4eee59),_0x2fc871['startSet_']){const _0x4dff1d=_0x2fc871['startAfterSet_']?'startAfter':'startAt';_0x5466f9[_0x4dff1d]=O(_0x2fc871['indexStartValue_']),_0x2fc871['startNameSet_']&&(_0x5466f9[_0x4dff1d]+=','+O(_0x2fc871['indexStartName_']));}if(_0x2fc871['endSet_']){const _0x25ff68=_0x2fc871['endBeforeSet_']?'endBefore':'endAt';_0x5466f9[_0x25ff68]=O(_0x2fc871['indexEndValue_']),_0x2fc871['endNameSet_']&&(_0x5466f9[_0x25ff68]+=','+O(_0x2fc871['indexEndName_']));}return _0x2fc871['limitSet_']&&(_0x2fc871['isViewFromLeft']()?_0x5466f9['limitToFirst']=_0x2fc871['limit_']:_0x5466f9['limitToLast']=_0x2fc871['limit_']),_0x5466f9;}function nr(_0x3a8b6f){const _0x182322={};if(_0x3a8b6f['startSet_']&&(_0x182322['sp']=_0x3a8b6f['indexStartValue_'],_0x3a8b6f['startNameSet_']&&(_0x182322['sn']=_0x3a8b6f['indexStartName_']),_0x182322['sin']=!_0x3a8b6f['startAfterSet_']),_0x3a8b6f['endSet_']&&(_0x182322['ep']=_0x3a8b6f['indexEndValue_'],_0x3a8b6f['endNameSet_']&&(_0x182322['en']=_0x3a8b6f['indexEndName_']),_0x182322['ein']=!_0x3a8b6f['endBeforeSet_']),_0x3a8b6f['limitSet_']){_0x182322['l']=_0x3a8b6f['limit_'];let _0x3c6c20=_0x3a8b6f['viewFrom_'];_0x3c6c20===''&&(_0x3a8b6f['isViewFromLeft']()?_0x3c6c20='l':_0x3c6c20='r'),_0x182322['vf']=_0x3c6c20;}return _0x3a8b6f['index_']!==R&&(_0x182322['i']=_0x3a8b6f['index_']['toString']()),_0x182322;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1bf3b5){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x54137b,_0x2111ba){return _0x2111ba!==void 0x0?'tag$'+_0x2111ba:(f(_0x54137b['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x54137b['_path']['toString']());}constructor(_0x3007cd,_0x1aa1f4,_0x276579,_0x2be352){super(),this['repoInfo_']=_0x3007cd,this['onDataUpdate_']=_0x1aa1f4,this['authTokenProvider_']=_0x276579,this['appCheckTokenProvider_']=_0x2be352,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x17dcff,_0x18a7cf,_0x11ad8a,_0xff078d){const _0x51a64d=_0x17dcff['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x51a64d+'\x20'+_0x17dcff['_queryIdentifier']);const _0xc48b02=fn['getListenId_'](_0x17dcff,_0x11ad8a),_0x161725={};this['listens_'][_0xc48b02]=_0x161725;const _0x8380b=tr(_0x17dcff['_queryParams']);this['restRequest_'](_0x51a64d+'.json',_0x8380b,(_0x180163,_0x5c21c5)=>{let _0x4f4b7c=_0x5c21c5;if(_0x180163===0x194&&(_0x4f4b7c=null,_0x180163=null),_0x180163===null&&this['onDataUpdate_'](_0x51a64d,_0x4f4b7c,!0x1,_0x11ad8a),Oe(this['listens_'],_0xc48b02)===_0x161725){let _0x6596dd;_0x180163?_0x180163===0x191?_0x6596dd='permission_denied':_0x6596dd='rest_error:'+_0x180163:_0x6596dd='ok',_0xff078d(_0x6596dd,null);}});}['unlisten'](_0x400b97,_0x263172){const _0xed2ada=fn['getListenId_'](_0x400b97,_0x263172);delete this['listens_'][_0xed2ada];}['get'](_0x2db41d){const _0x41b247=tr(_0x2db41d['_queryParams']),_0x356134=_0x2db41d['_path']['toString'](),_0x4fbd5d=new Ve();return this['restRequest_'](_0x356134+'.json',_0x41b247,(_0x438149,_0x36e3ab)=>{let _0x612cb2=_0x36e3ab;_0x438149===0x194&&(_0x612cb2=null,_0x438149=null),_0x438149===null?(this['onDataUpdate_'](_0x356134,_0x612cb2,!0x1,null),_0x4fbd5d['resolve'](_0x612cb2)):_0x4fbd5d['reject'](new Error(_0x612cb2));}),_0x4fbd5d['promise'];}['refreshAuthToken'](_0x4f3c42){}['restRequest_'](_0x5a0b0e,_0x1fd6cf={},_0x1c2af0){return _0x1fd6cf['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x15f12c,_0x396852])=>{_0x15f12c&&_0x15f12c['accessToken']&&(_0x1fd6cf['auth']=_0x15f12c['accessToken']),_0x396852&&_0x396852['token']&&(_0x1fd6cf['ac']=_0x396852['token']);const _0x5921d7=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5a0b0e+'?ns='+this['repoInfo_']['namespace']+at(_0x1fd6cf);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5921d7);const _0x58b035=new XMLHttpRequest();_0x58b035['onreadystatechange']=()=>{if(_0x1c2af0&&_0x58b035['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5921d7+'\x20received.\x20status:',_0x58b035['status'],'response:',_0x58b035['responseText']);let _0x6c3a44=null;if(_0x58b035['status']>=0xc8&&_0x58b035['status']<0x12c){try{_0x6c3a44=bt(_0x58b035['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5921d7+':\x20'+_0x58b035['responseText']);}_0x1c2af0(null,_0x6c3a44);}else _0x58b035['status']!==0x191&&_0x58b035['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5921d7+'\x20Status:\x20'+_0x58b035['status']),_0x1c2af0(_0x58b035['status']);_0x1c2af0=null;}},_0x58b035['open']('GET',_0x5921d7,!0x0),_0x58b035['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x437ae3){return this['rootNode_']['getChild'](_0x437ae3);}['updateSnapshot'](_0x4aa4c2,_0x58857e){this['rootNode_']=this['rootNode_']['updateChild'](_0x4aa4c2,_0x58857e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x3f5714,_0x5d574c,_0x143067){if(v(_0x5d574c))_0x3f5714['value']=_0x143067,_0x3f5714['children']['clear']();else{if(_0x3f5714['value']!==null)_0x3f5714['value']=_0x3f5714['value']['updateChild'](_0x5d574c,_0x143067);else{const _0x2c1745=y(_0x5d574c);_0x3f5714['children']['has'](_0x2c1745)||_0x3f5714['children']['set'](_0x2c1745,pn());const _0x2d176a=_0x3f5714['children']['get'](_0x2c1745);_0x5d574c=b(_0x5d574c),Mo(_0x2d176a,_0x5d574c,_0x143067);}}}function Ei(_0x5b9798,_0x819102,_0x419444){_0x5b9798['value']!==null?_0x419444(_0x819102,_0x5b9798['value']):Qh(_0x5b9798,(_0x46d243,_0x1d45d1)=>{const _0x1b56d0=new C(_0x819102['toString']()+'/'+_0x46d243);Ei(_0x1d45d1,_0x1b56d0,_0x419444);});}function Qh(_0x205b86,_0x369969){_0x205b86['children']['forEach']((_0x424538,_0x1c45f7)=>{_0x369969(_0x1c45f7,_0x424538);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x1f15fe){this['collection_']=_0x1f15fe,this['last_']=null;}['get'](){const _0x4b5fc3=this['collection_']['get'](),_0x265e29={..._0x4b5fc3};return this['last_']&&x(this['last_'],(_0x23deb4,_0xfdb179)=>{_0x265e29[_0x23deb4]=_0x265e29[_0x23deb4]-_0xfdb179;}),this['last_']=_0x4b5fc3,_0x265e29;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x2da2cb,_0x3b0493){this['server_']=_0x3b0493,this['statsToReport_']={},this['statsListener_']=new Jh(_0x2da2cb);const _0x244644=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x244644));}['reportStats_'](){const _0x56e860=this['statsListener_']['get'](),_0x3187c7={};let _0x336303=!0x1;x(_0x56e860,(_0x3a692e,_0x2cbf9a)=>{_0x2cbf9a>0x0&&Y(this['statsToReport_'],_0x3a692e)&&(_0x3187c7[_0x3a692e]=_0x2cbf9a,_0x336303=!0x0);}),_0x336303&&this['server_']['reportStats'](_0x3187c7),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x558e57){_0x558e57[_0x558e57['OVERWRITE']=0x0]='OVERWRITE',_0x558e57[_0x558e57['MERGE']=0x1]='MERGE',_0x558e57[_0x558e57['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x558e57[_0x558e57['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x228c15){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x228c15,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x515946,_0x223477,_0x4d071f){this['path']=_0x515946,this['affectedTree']=_0x223477,this['revert']=_0x4d071f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x48620f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x462759=this['affectedTree']['subtree'](new C(_0x48620f));return new _n(w(),_0x462759,this['revert']);}}else return f(y(this['path'])===_0x48620f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x7b33,_0x1ef5f5){this['source']=_0x7b33,this['path']=_0x1ef5f5,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4872ef){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x1a761a,_0x156f58,_0xa34884){this['source']=_0x1a761a,this['path']=_0x156f58,this['snap']=_0xa34884,this['type']=q['OVERWRITE'];}['operationForChild'](_0x3ae334){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x3ae334)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x32f7c5,_0x468b3b,_0x4938d5){this['source']=_0x32f7c5,this['path']=_0x468b3b,this['children']=_0x4938d5,this['type']=q['MERGE'];}['operationForChild'](_0x3daa7e){if(v(this['path'])){const _0x43a328=this['children']['subtree'](new C(_0x3daa7e));return _0x43a328['isEmpty']()?null:_0x43a328['value']?new Fe(this['source'],w(),_0x43a328['value']):new nt(this['source'],w(),_0x43a328);}else return f(y(this['path'])===_0x3daa7e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x254847,_0x4b7774,_0x274525){this['node_']=_0x254847,this['fullyInitialized_']=_0x4b7774,this['filtered_']=_0x274525;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xbb2b36){if(v(_0xbb2b36))return this['isFullyInitialized']()&&!this['filtered_'];const _0x53100d=y(_0xbb2b36);return this['isCompleteForChild'](_0x53100d);}['isCompleteForChild'](_0x526e20){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x526e20);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2878c0){this['query_']=_0x2878c0,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5d57a9,_0xbbcbd4,_0x197964,_0x1788a9){const _0x2ae31d=[],_0x1eeabf=[];return _0xbbcbd4['forEach'](_0x33b717=>{_0x33b717['type']==='child_changed'&&_0x5d57a9['index_']['indexedValueChanged'](_0x33b717['oldSnap'],_0x33b717['snapshotNode'])&&_0x1eeabf['push']($h(_0x33b717['childName'],_0x33b717['snapshotNode']));}),mt(_0x5d57a9,_0x2ae31d,'child_removed',_0xbbcbd4,_0x1788a9,_0x197964),mt(_0x5d57a9,_0x2ae31d,'child_added',_0xbbcbd4,_0x1788a9,_0x197964),mt(_0x5d57a9,_0x2ae31d,'child_moved',_0x1eeabf,_0x1788a9,_0x197964),mt(_0x5d57a9,_0x2ae31d,'child_changed',_0xbbcbd4,_0x1788a9,_0x197964),mt(_0x5d57a9,_0x2ae31d,'value',_0xbbcbd4,_0x1788a9,_0x197964),_0x2ae31d;}function mt(_0x451ecb,_0x507433,_0x294214,_0x2176c3,_0x4fbf46,_0x4a45c6){const _0x4b3069=_0x2176c3['filter'](_0x5d4a27=>_0x5d4a27['type']===_0x294214);_0x4b3069['sort']((_0xba94c1,_0x310447)=>su(_0x451ecb,_0xba94c1,_0x310447)),_0x4b3069['forEach'](_0x5d137b=>{const _0x2ab541=iu(_0x451ecb,_0x5d137b,_0x4a45c6);_0x4fbf46['forEach'](_0xc68385=>{_0xc68385['respondsTo'](_0x5d137b['type'])&&_0x507433['push'](_0xc68385['createEvent'](_0x2ab541,_0x451ecb['query_']));});});}function iu(_0x161d70,_0x342989,_0x5469fc){return _0x342989['type']==='value'||_0x342989['type']==='child_removed'||(_0x342989['prevName']=_0x5469fc['getPredecessorChildName'](_0x342989['childName'],_0x342989['snapshotNode'],_0x161d70['index_'])),_0x342989;}function su(_0x1ee2db,_0x40eda8,_0x55923e){if(_0x40eda8['childName']==null||_0x55923e['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x28b23b=new E(_0x40eda8['childName'],_0x40eda8['snapshotNode']),_0x1209a9=new E(_0x55923e['childName'],_0x55923e['snapshotNode']);return _0x1ee2db['index_']['compare'](_0x28b23b,_0x1209a9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x45be09,_0xc00bc8){return{'eventCache':_0x45be09,'serverCache':_0xc00bc8};}function wt(_0x2159b3,_0x47019f,_0x49444e,_0x4558bb){return Dn(new Ce(_0x47019f,_0x49444e,_0x4558bb),_0x2159b3['serverCache']);}function Lo(_0x257fa5,_0x28db8e,_0x29b665,_0x2ebc1d){return Dn(_0x257fa5['eventCache'],new Ce(_0x28db8e,_0x29b665,_0x2ebc1d));}function gn(_0x3c9c9e){return _0x3c9c9e['eventCache']['isFullyInitialized']()?_0x3c9c9e['eventCache']['getNode']():null;}function Ue(_0x90c144){return _0x90c144['serverCache']['isFullyInitialized']()?_0x90c144['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2c8152){let _0x5ceee0=new S(null);return x(_0x2c8152,(_0x2351b3,_0x3d28b1)=>{_0x5ceee0=_0x5ceee0['set'](new C(_0x2351b3),_0x3d28b1);}),_0x5ceee0;}constructor(_0x394732,_0x3f2967=ru()){this['value']=_0x394732,this['children']=_0x3f2967;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x325167,_0x3bfd0d){if(this['value']!=null&&_0x3bfd0d(this['value']))return{'path':w(),'value':this['value']};if(v(_0x325167))return null;{const _0x40ea82=y(_0x325167),_0x40642c=this['children']['get'](_0x40ea82);if(_0x40642c!==null){const _0x58f25d=_0x40642c['findRootMostMatchingPathAndValue'](b(_0x325167),_0x3bfd0d);return _0x58f25d!=null?{'path':A(new C(_0x40ea82),_0x58f25d['path']),'value':_0x58f25d['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x41e8b2){return this['findRootMostMatchingPathAndValue'](_0x41e8b2,()=>!0x0);}['subtree'](_0x376263){if(v(_0x376263))return this;{const _0x31d923=y(_0x376263),_0x5e51cd=this['children']['get'](_0x31d923);return _0x5e51cd!==null?_0x5e51cd['subtree'](b(_0x376263)):new S(null);}}['set'](_0x4f5988,_0x1722dd){if(v(_0x4f5988))return new S(_0x1722dd,this['children']);{const _0x39a350=y(_0x4f5988),_0x1185e0=(this['children']['get'](_0x39a350)||new S(null))['set'](b(_0x4f5988),_0x1722dd),_0x2d0127=this['children']['insert'](_0x39a350,_0x1185e0);return new S(this['value'],_0x2d0127);}}['remove'](_0x3127e6){if(v(_0x3127e6))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x2bce8c=y(_0x3127e6),_0x20d189=this['children']['get'](_0x2bce8c);if(_0x20d189){const _0x1e07ad=_0x20d189['remove'](b(_0x3127e6));let _0x52af60;return _0x1e07ad['isEmpty']()?_0x52af60=this['children']['remove'](_0x2bce8c):_0x52af60=this['children']['insert'](_0x2bce8c,_0x1e07ad),this['value']===null&&_0x52af60['isEmpty']()?new S(null):new S(this['value'],_0x52af60);}else return this;}}['get'](_0x10e2d1){if(v(_0x10e2d1))return this['value'];{const _0x1427fe=y(_0x10e2d1),_0x18d4aa=this['children']['get'](_0x1427fe);return _0x18d4aa?_0x18d4aa['get'](b(_0x10e2d1)):null;}}['setTree'](_0x572205,_0xb8c9c5){if(v(_0x572205))return _0xb8c9c5;{const _0x1d3f15=y(_0x572205),_0x50e441=(this['children']['get'](_0x1d3f15)||new S(null))['setTree'](b(_0x572205),_0xb8c9c5);let _0xf9f136;return _0x50e441['isEmpty']()?_0xf9f136=this['children']['remove'](_0x1d3f15):_0xf9f136=this['children']['insert'](_0x1d3f15,_0x50e441),new S(this['value'],_0xf9f136);}}['fold'](_0x778ad4){return this['fold_'](w(),_0x778ad4);}['fold_'](_0x4eaf99,_0x3c81c4){const _0x548b74={};return this['children']['inorderTraversal']((_0x529b02,_0x5072f0)=>{_0x548b74[_0x529b02]=_0x5072f0['fold_'](A(_0x4eaf99,_0x529b02),_0x3c81c4);}),_0x3c81c4(_0x4eaf99,this['value'],_0x548b74);}['findOnPath'](_0x1accfc,_0x34f49d){return this['findOnPath_'](_0x1accfc,w(),_0x34f49d);}['findOnPath_'](_0x3873a6,_0x120ed5,_0x100a29){const _0x12fa17=this['value']?_0x100a29(_0x120ed5,this['value']):!0x1;if(_0x12fa17)return _0x12fa17;if(v(_0x3873a6))return null;{const _0x344acf=y(_0x3873a6),_0x3e9875=this['children']['get'](_0x344acf);return _0x3e9875?_0x3e9875['findOnPath_'](b(_0x3873a6),A(_0x120ed5,_0x344acf),_0x100a29):null;}}['foreachOnPath'](_0x22096c,_0x2a9373){return this['foreachOnPath_'](_0x22096c,w(),_0x2a9373);}['foreachOnPath_'](_0x4fa83c,_0x30a40c,_0x1245d8){if(v(_0x4fa83c))return this;{this['value']&&_0x1245d8(_0x30a40c,this['value']);const _0x32ef8d=y(_0x4fa83c),_0x1b7def=this['children']['get'](_0x32ef8d);return _0x1b7def?_0x1b7def['foreachOnPath_'](b(_0x4fa83c),A(_0x30a40c,_0x32ef8d),_0x1245d8):new S(null);}}['foreach'](_0x34f3b4){this['foreach_'](w(),_0x34f3b4);}['foreach_'](_0x13db65,_0x37a049){this['children']['inorderTraversal']((_0x446312,_0x285a1d)=>{_0x285a1d['foreach_'](A(_0x13db65,_0x446312),_0x37a049);}),this['value']&&_0x37a049(_0x13db65,this['value']);}['foreachChild'](_0xb69741){this['children']['inorderTraversal']((_0x44eb5a,_0x3974cf)=>{_0x3974cf['value']&&_0xb69741(_0x44eb5a,_0x3974cf['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x452930){this['writeTree_']=_0x452930;}static['empty'](){return new j(new S(null));}}function Ct(_0x39b58f,_0xa80c99,_0x3b4c99){if(v(_0xa80c99))return new j(new S(_0x3b4c99));{const _0x268926=_0x39b58f['writeTree_']['findRootMostValueAndPath'](_0xa80c99);if(_0x268926!=null){const _0xf8ff74=_0x268926['path'];let _0x364fd0=_0x268926['value'];const _0x586c7c=F(_0xf8ff74,_0xa80c99);return _0x364fd0=_0x364fd0['updateChild'](_0x586c7c,_0x3b4c99),new j(_0x39b58f['writeTree_']['set'](_0xf8ff74,_0x364fd0));}else{const _0x3c622a=new S(_0x3b4c99),_0x1efc33=_0x39b58f['writeTree_']['setTree'](_0xa80c99,_0x3c622a);return new j(_0x1efc33);}}}function Ii(_0x2a6e45,_0x13ccd1,_0x83cd2a){let _0x4e3d6b=_0x2a6e45;return x(_0x83cd2a,(_0x43a262,_0x5a3db2)=>{_0x4e3d6b=Ct(_0x4e3d6b,A(_0x13ccd1,_0x43a262),_0x5a3db2);}),_0x4e3d6b;}function sr(_0x4415a1,_0x546f4a){if(v(_0x546f4a))return j['empty']();{const _0x526c6d=_0x4415a1['writeTree_']['setTree'](_0x546f4a,new S(null));return new j(_0x526c6d);}}function wi(_0x117340,_0x5730c3){return $e(_0x117340,_0x5730c3)!=null;}function $e(_0x3451c8,_0x5c08f6){const _0x3ed3f2=_0x3451c8['writeTree_']['findRootMostValueAndPath'](_0x5c08f6);return _0x3ed3f2!=null?_0x3451c8['writeTree_']['get'](_0x3ed3f2['path'])['getChild'](F(_0x3ed3f2['path'],_0x5c08f6)):null;}function rr(_0x5a1608){const _0x4054ba=[],_0x2b1fdb=_0x5a1608['writeTree_']['value'];return _0x2b1fdb!=null?_0x2b1fdb['isLeafNode']()||_0x2b1fdb['forEachChild'](R,(_0x323049,_0x4469a7)=>{_0x4054ba['push'](new E(_0x323049,_0x4469a7));}):_0x5a1608['writeTree_']['children']['inorderTraversal']((_0x4a71c5,_0x30e8aa)=>{_0x30e8aa['value']!=null&&_0x4054ba['push'](new E(_0x4a71c5,_0x30e8aa['value']));}),_0x4054ba;}function ve(_0x17d84e,_0x739b75){if(v(_0x739b75))return _0x17d84e;{const _0x13e059=$e(_0x17d84e,_0x739b75);return _0x13e059!=null?new j(new S(_0x13e059)):new j(_0x17d84e['writeTree_']['subtree'](_0x739b75));}}function Ci(_0x151d5e){return _0x151d5e['writeTree_']['isEmpty']();}function it(_0x2519a0,_0x2679b3){return xo(w(),_0x2519a0['writeTree_'],_0x2679b3);}function xo(_0x169890,_0x382d64,_0x3a6ff0){if(_0x382d64['value']!=null)return _0x3a6ff0['updateChild'](_0x169890,_0x382d64['value']);{let _0xd43689=null;return _0x382d64['children']['inorderTraversal']((_0x333cb0,_0x5c8c70)=>{_0x333cb0==='.priority'?(f(_0x5c8c70['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xd43689=_0x5c8c70['value']):_0x3a6ff0=xo(A(_0x169890,_0x333cb0),_0x5c8c70,_0x3a6ff0);}),!_0x3a6ff0['getChild'](_0x169890)['isEmpty']()&&_0xd43689!==null&&(_0x3a6ff0=_0x3a6ff0['updateChild'](A(_0x169890,'.priority'),_0xd43689)),_0x3a6ff0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3da7ca,_0x38e2fa){return Bo(_0x38e2fa,_0x3da7ca);}function ou(_0x343235,_0x5daa49,_0x173c5d,_0x5c1a48,_0xc5ba5){f(_0x5c1a48>_0x343235['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xc5ba5===void 0x0&&(_0xc5ba5=!0x0),_0x343235['allWrites']['push']({'path':_0x5daa49,'snap':_0x173c5d,'writeId':_0x5c1a48,'visible':_0xc5ba5}),_0xc5ba5&&(_0x343235['visibleWrites']=Ct(_0x343235['visibleWrites'],_0x5daa49,_0x173c5d)),_0x343235['lastWriteId']=_0x5c1a48;}function au(_0x5cca6f,_0x3e7ec4,_0x2da139,_0x1a3130){f(_0x1a3130>_0x5cca6f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5cca6f['allWrites']['push']({'path':_0x3e7ec4,'children':_0x2da139,'writeId':_0x1a3130,'visible':!0x0}),_0x5cca6f['visibleWrites']=Ii(_0x5cca6f['visibleWrites'],_0x3e7ec4,_0x2da139),_0x5cca6f['lastWriteId']=_0x1a3130;}function cu(_0x2a70b1,_0x39d066){for(let _0x4c2aaa=0x0;_0x4c2aaa<_0x2a70b1['allWrites']['length'];_0x4c2aaa++){const _0x31b175=_0x2a70b1['allWrites'][_0x4c2aaa];if(_0x31b175['writeId']===_0x39d066)return _0x31b175;}return null;}function lu(_0x3aae7b,_0x1eb8bd){const _0x4eb130=_0x3aae7b['allWrites']['findIndex'](_0x49de17=>_0x49de17['writeId']===_0x1eb8bd);f(_0x4eb130>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x56a0d5=_0x3aae7b['allWrites'][_0x4eb130];_0x3aae7b['allWrites']['splice'](_0x4eb130,0x1);let _0x1fb132=_0x56a0d5['visible'],_0x54a93b=!0x1,_0x245008=_0x3aae7b['allWrites']['length']-0x1;for(;_0x1fb132&&_0x245008>=0x0;){const _0x595877=_0x3aae7b['allWrites'][_0x245008];_0x595877['visible']&&(_0x245008>=_0x4eb130&&hu(_0x595877,_0x56a0d5['path'])?_0x1fb132=!0x1:$(_0x56a0d5['path'],_0x595877['path'])&&(_0x54a93b=!0x0)),_0x245008--;}if(_0x1fb132){if(_0x54a93b)return uu(_0x3aae7b),!0x0;if(_0x56a0d5['snap'])_0x3aae7b['visibleWrites']=sr(_0x3aae7b['visibleWrites'],_0x56a0d5['path']);else{const _0x1ca73b=_0x56a0d5['children'];x(_0x1ca73b,_0x1c4d0e=>{_0x3aae7b['visibleWrites']=sr(_0x3aae7b['visibleWrites'],A(_0x56a0d5['path'],_0x1c4d0e));});}return!0x0;}else return!0x1;}function hu(_0x38278f,_0x26a2bf){if(_0x38278f['snap'])return $(_0x38278f['path'],_0x26a2bf);for(const _0x340b2f in _0x38278f['children'])if(_0x38278f['children']['hasOwnProperty'](_0x340b2f)&&$(A(_0x38278f['path'],_0x340b2f),_0x26a2bf))return!0x0;return!0x1;}function uu(_0xd159d8){_0xd159d8['visibleWrites']=Fo(_0xd159d8['allWrites'],du,w()),_0xd159d8['allWrites']['length']>0x0?_0xd159d8['lastWriteId']=_0xd159d8['allWrites'][_0xd159d8['allWrites']['length']-0x1]['writeId']:_0xd159d8['lastWriteId']=-0x1;}function du(_0x47bfa0){return _0x47bfa0['visible'];}function Fo(_0x4b39c4,_0xeca663,_0x41b400){let _0x3d3c38=j['empty']();for(let _0x1b1293=0x0;_0x1b1293<_0x4b39c4['length'];++_0x1b1293){const _0x2387cf=_0x4b39c4[_0x1b1293];if(_0xeca663(_0x2387cf)){const _0x495b5d=_0x2387cf['path'];let _0x2d89fa;if(_0x2387cf['snap'])$(_0x41b400,_0x495b5d)?(_0x2d89fa=F(_0x41b400,_0x495b5d),_0x3d3c38=Ct(_0x3d3c38,_0x2d89fa,_0x2387cf['snap'])):$(_0x495b5d,_0x41b400)&&(_0x2d89fa=F(_0x495b5d,_0x41b400),_0x3d3c38=Ct(_0x3d3c38,w(),_0x2387cf['snap']['getChild'](_0x2d89fa)));else{if(_0x2387cf['children']){if($(_0x41b400,_0x495b5d))_0x2d89fa=F(_0x41b400,_0x495b5d),_0x3d3c38=Ii(_0x3d3c38,_0x2d89fa,_0x2387cf['children']);else{if($(_0x495b5d,_0x41b400)){if(_0x2d89fa=F(_0x495b5d,_0x41b400),v(_0x2d89fa))_0x3d3c38=Ii(_0x3d3c38,w(),_0x2387cf['children']);else{const _0xc7b67a=Oe(_0x2387cf['children'],y(_0x2d89fa));if(_0xc7b67a){const _0x563f57=_0xc7b67a['getChild'](b(_0x2d89fa));_0x3d3c38=Ct(_0x3d3c38,w(),_0x563f57);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3d3c38;}function Uo(_0x4f6f5c,_0x4474cf,_0x297ab2,_0x2d9086,_0x299d32){if(!_0x2d9086&&!_0x299d32){const _0x163de2=$e(_0x4f6f5c['visibleWrites'],_0x4474cf);if(_0x163de2!=null)return _0x163de2;{const _0x4da155=ve(_0x4f6f5c['visibleWrites'],_0x4474cf);if(Ci(_0x4da155))return _0x297ab2;if(_0x297ab2==null&&!wi(_0x4da155,w()))return null;{const _0x575125=_0x297ab2||g['EMPTY_NODE'];return it(_0x4da155,_0x575125);}}}else{const _0x80cc2b=ve(_0x4f6f5c['visibleWrites'],_0x4474cf);if(!_0x299d32&&Ci(_0x80cc2b))return _0x297ab2;if(!_0x299d32&&_0x297ab2==null&&!wi(_0x80cc2b,w()))return null;{const _0x379c06=function(_0x520e23){return(_0x520e23['visible']||_0x299d32)&&(!_0x2d9086||!~_0x2d9086['indexOf'](_0x520e23['writeId']))&&($(_0x520e23['path'],_0x4474cf)||$(_0x4474cf,_0x520e23['path']));},_0xbfb51d=Fo(_0x4f6f5c['allWrites'],_0x379c06,_0x4474cf),_0x23b648=_0x297ab2||g['EMPTY_NODE'];return it(_0xbfb51d,_0x23b648);}}}function fu(_0x59c5e8,_0x47e1e9,_0x1becca){let _0x4cb4dc=g['EMPTY_NODE'];const _0x3b79b5=$e(_0x59c5e8['visibleWrites'],_0x47e1e9);if(_0x3b79b5)return _0x3b79b5['isLeafNode']()||_0x3b79b5['forEachChild'](R,(_0x121c98,_0x3faaf9)=>{_0x4cb4dc=_0x4cb4dc['updateImmediateChild'](_0x121c98,_0x3faaf9);}),_0x4cb4dc;if(_0x1becca){const _0x218c3b=ve(_0x59c5e8['visibleWrites'],_0x47e1e9);return _0x1becca['forEachChild'](R,(_0x37b8e7,_0x35f379)=>{const _0x4315dd=it(ve(_0x218c3b,new C(_0x37b8e7)),_0x35f379);_0x4cb4dc=_0x4cb4dc['updateImmediateChild'](_0x37b8e7,_0x4315dd);}),rr(_0x218c3b)['forEach'](_0x27b853=>{_0x4cb4dc=_0x4cb4dc['updateImmediateChild'](_0x27b853['name'],_0x27b853['node']);}),_0x4cb4dc;}else{const _0x497460=ve(_0x59c5e8['visibleWrites'],_0x47e1e9);return rr(_0x497460)['forEach'](_0x4c6024=>{_0x4cb4dc=_0x4cb4dc['updateImmediateChild'](_0x4c6024['name'],_0x4c6024['node']);}),_0x4cb4dc;}}function pu(_0x10ad52,_0x40fa10,_0x5685cf,_0x4b8f3c,_0x451ce9){f(_0x4b8f3c||_0x451ce9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x128e13=A(_0x40fa10,_0x5685cf);if(wi(_0x10ad52['visibleWrites'],_0x128e13))return null;{const _0x40acc0=ve(_0x10ad52['visibleWrites'],_0x128e13);return Ci(_0x40acc0)?_0x451ce9['getChild'](_0x5685cf):it(_0x40acc0,_0x451ce9['getChild'](_0x5685cf));}}function _u(_0x3e7f10,_0x3007ac,_0x29bb04,_0x1ae8f3){const _0x30cb53=A(_0x3007ac,_0x29bb04),_0x520b8f=$e(_0x3e7f10['visibleWrites'],_0x30cb53);if(_0x520b8f!=null)return _0x520b8f;if(_0x1ae8f3['isCompleteForChild'](_0x29bb04)){const _0x1cbf30=ve(_0x3e7f10['visibleWrites'],_0x30cb53);return it(_0x1cbf30,_0x1ae8f3['getNode']()['getImmediateChild'](_0x29bb04));}else return null;}function gu(_0x4c4088,_0x262c0c){return $e(_0x4c4088['visibleWrites'],_0x262c0c);}function mu(_0x4b3072,_0x385cc4,_0x247a81,_0xf8def9,_0x530d40,_0x58c031,_0x5cdd2d){let _0x21c728;const _0x308348=ve(_0x4b3072['visibleWrites'],_0x385cc4),_0x15b8e5=$e(_0x308348,w());if(_0x15b8e5!=null)_0x21c728=_0x15b8e5;else{if(_0x247a81!=null)_0x21c728=it(_0x308348,_0x247a81);else return[];}if(_0x21c728=_0x21c728['withIndex'](_0x5cdd2d),!_0x21c728['isEmpty']()&&!_0x21c728['isLeafNode']()){const _0x56e06b=[],_0x9675d9=_0x5cdd2d['getCompare'](),_0x5e5d46=_0x58c031?_0x21c728['getReverseIteratorFrom'](_0xf8def9,_0x5cdd2d):_0x21c728['getIteratorFrom'](_0xf8def9,_0x5cdd2d);let _0x392070=_0x5e5d46['getNext']();for(;_0x392070&&_0x56e06b['length']<_0x530d40;)_0x9675d9(_0x392070,_0xf8def9)!==0x0&&_0x56e06b['push'](_0x392070),_0x392070=_0x5e5d46['getNext']();return _0x56e06b;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xdf4954,_0x5854c9,_0x240ca1,_0x1b222e){return Uo(_0xdf4954['writeTree'],_0xdf4954['treePath'],_0x5854c9,_0x240ca1,_0x1b222e);}function es(_0x4bcc93,_0x3727ca){return fu(_0x4bcc93['writeTree'],_0x4bcc93['treePath'],_0x3727ca);}function or(_0x52938e,_0x2e6924,_0x5aa372,_0x5bfd67){return pu(_0x52938e['writeTree'],_0x52938e['treePath'],_0x2e6924,_0x5aa372,_0x5bfd67);}function yn(_0x575e3f,_0x4ba0dc){return gu(_0x575e3f['writeTree'],A(_0x575e3f['treePath'],_0x4ba0dc));}function vu(_0x5a8ea4,_0x4168ce,_0x5e5eb2,_0x503abe,_0x5b764c,_0x683f4){return mu(_0x5a8ea4['writeTree'],_0x5a8ea4['treePath'],_0x4168ce,_0x5e5eb2,_0x503abe,_0x5b764c,_0x683f4);}function ts(_0x1f3feb,_0x5811a6,_0x483e81){return _u(_0x1f3feb['writeTree'],_0x1f3feb['treePath'],_0x5811a6,_0x483e81);}function Wo(_0x4fa03d,_0x369179){return Bo(A(_0x4fa03d['treePath'],_0x369179),_0x4fa03d['writeTree']);}function Bo(_0xd16121,_0x569fef){return{'treePath':_0xd16121,'writeTree':_0x569fef};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x588d2b){const _0x574456=_0x588d2b['type'],_0x1b4538=_0x588d2b['childName'];f(_0x574456==='child_added'||_0x574456==='child_changed'||_0x574456==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1b4538!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4b37e4=this['changeMap']['get'](_0x1b4538);if(_0x4b37e4){const _0xbca17d=_0x4b37e4['type'];if(_0x574456==='child_added'&&_0xbca17d==='child_removed')this['changeMap']['set'](_0x1b4538,Pt(_0x1b4538,_0x588d2b['snapshotNode'],_0x4b37e4['snapshotNode']));else{if(_0x574456==='child_removed'&&_0xbca17d==='child_added')this['changeMap']['delete'](_0x1b4538);else{if(_0x574456==='child_removed'&&_0xbca17d==='child_changed')this['changeMap']['set'](_0x1b4538,Nt(_0x1b4538,_0x4b37e4['oldSnap']));else{if(_0x574456==='child_changed'&&_0xbca17d==='child_added')this['changeMap']['set'](_0x1b4538,tt(_0x1b4538,_0x588d2b['snapshotNode']));else{if(_0x574456==='child_changed'&&_0xbca17d==='child_changed')this['changeMap']['set'](_0x1b4538,Pt(_0x1b4538,_0x588d2b['snapshotNode'],_0x4b37e4['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x588d2b+'\x20occurred\x20after\x20'+_0x4b37e4);}}}}}else this['changeMap']['set'](_0x1b4538,_0x588d2b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x1dc27f){return null;}['getChildAfterChild'](_0x2a97be,_0xffa639,_0x10d054){return null;}}const Vo=new Iu();class ns{constructor(_0x3631b9,_0x265cdd,_0x4bbc22=null){this['writes_']=_0x3631b9,this['viewCache_']=_0x265cdd,this['optCompleteServerCache_']=_0x4bbc22;}['getCompleteChild'](_0x3f8f23){const _0x3528cd=this['viewCache_']['eventCache'];if(_0x3528cd['isCompleteForChild'](_0x3f8f23))return _0x3528cd['getNode']()['getImmediateChild'](_0x3f8f23);{const _0x2405c9=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x3f8f23,_0x2405c9);}}['getChildAfterChild'](_0x50ca5c,_0x4352da,_0x3fe634){const _0x637042=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x487ead=vu(this['writes_'],_0x637042,_0x4352da,0x1,_0x3fe634,_0x50ca5c);return _0x487ead['length']===0x0?null:_0x487ead[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x51ac40){return{'filter':_0x51ac40};}function Cu(_0x202902,_0x8a5e9b){f(_0x8a5e9b['eventCache']['getNode']()['isIndexed'](_0x202902['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x8a5e9b['serverCache']['getNode']()['isIndexed'](_0x202902['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5a86b7,_0x528f3e,_0x1e5943,_0x22c53e,_0x123e17){const _0x37d59c=new Eu();let _0x298607,_0x35d659;if(_0x1e5943['type']===q['OVERWRITE']){const _0x369205=_0x1e5943;_0x369205['source']['fromUser']?_0x298607=Ti(_0x5a86b7,_0x528f3e,_0x369205['path'],_0x369205['snap'],_0x22c53e,_0x123e17,_0x37d59c):(f(_0x369205['source']['fromServer'],'Unknown\x20source.'),_0x35d659=_0x369205['source']['tagged']||_0x528f3e['serverCache']['isFiltered']()&&!v(_0x369205['path']),_0x298607=vn(_0x5a86b7,_0x528f3e,_0x369205['path'],_0x369205['snap'],_0x22c53e,_0x123e17,_0x35d659,_0x37d59c));}else{if(_0x1e5943['type']===q['MERGE']){const _0x41e280=_0x1e5943;_0x41e280['source']['fromUser']?_0x298607=bu(_0x5a86b7,_0x528f3e,_0x41e280['path'],_0x41e280['children'],_0x22c53e,_0x123e17,_0x37d59c):(f(_0x41e280['source']['fromServer'],'Unknown\x20source.'),_0x35d659=_0x41e280['source']['tagged']||_0x528f3e['serverCache']['isFiltered'](),_0x298607=Si(_0x5a86b7,_0x528f3e,_0x41e280['path'],_0x41e280['children'],_0x22c53e,_0x123e17,_0x35d659,_0x37d59c));}else{if(_0x1e5943['type']===q['ACK_USER_WRITE']){const _0x18170b=_0x1e5943;_0x18170b['revert']?_0x298607=ku(_0x5a86b7,_0x528f3e,_0x18170b['path'],_0x22c53e,_0x123e17,_0x37d59c):_0x298607=Ru(_0x5a86b7,_0x528f3e,_0x18170b['path'],_0x18170b['affectedTree'],_0x22c53e,_0x123e17,_0x37d59c);}else{if(_0x1e5943['type']===q['LISTEN_COMPLETE'])_0x298607=Au(_0x5a86b7,_0x528f3e,_0x1e5943['path'],_0x22c53e,_0x37d59c);else throw ot('Unknown\x20operation\x20type:\x20'+_0x1e5943['type']);}}}const _0x414d75=_0x37d59c['getChanges']();return Su(_0x528f3e,_0x298607,_0x414d75),{'viewCache':_0x298607,'changes':_0x414d75};}function Su(_0x19250a,_0x4998fb,_0xde11be){const _0x15a3e4=_0x4998fb['eventCache'];if(_0x15a3e4['isFullyInitialized']()){const _0x4abac1=_0x15a3e4['getNode']()['isLeafNode']()||_0x15a3e4['getNode']()['isEmpty'](),_0x3ef0ee=gn(_0x19250a);(_0xde11be['length']>0x0||!_0x19250a['eventCache']['isFullyInitialized']()||_0x4abac1&&!_0x15a3e4['getNode']()['equals'](_0x3ef0ee)||!_0x15a3e4['getNode']()['getPriority']()['equals'](_0x3ef0ee['getPriority']()))&&_0xde11be['push'](Oo(gn(_0x4998fb)));}}function Ho(_0x107911,_0x53bb93,_0xce806b,_0x961745,_0x5506df,_0x44f06e){const _0x169ef5=_0x53bb93['eventCache'];if(yn(_0x961745,_0xce806b)!=null)return _0x53bb93;{let _0x4616c7,_0x267b13;if(v(_0xce806b)){if(f(_0x53bb93['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x53bb93['serverCache']['isFiltered']()){const _0x5474e9=Ue(_0x53bb93),_0x4a2e16=_0x5474e9 instanceof g?_0x5474e9:g['EMPTY_NODE'],_0x4adf0b=es(_0x961745,_0x4a2e16);_0x4616c7=_0x107911['filter']['updateFullNode'](_0x53bb93['eventCache']['getNode'](),_0x4adf0b,_0x44f06e);}else{const _0x555814=mn(_0x961745,Ue(_0x53bb93));_0x4616c7=_0x107911['filter']['updateFullNode'](_0x53bb93['eventCache']['getNode'](),_0x555814,_0x44f06e);}}else{const _0x3802c8=y(_0xce806b);if(_0x3802c8==='.priority'){f(we(_0xce806b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x43a8c7=_0x169ef5['getNode']();_0x267b13=_0x53bb93['serverCache']['getNode']();const _0x2c3428=or(_0x961745,_0xce806b,_0x43a8c7,_0x267b13);_0x2c3428!=null?_0x4616c7=_0x107911['filter']['updatePriority'](_0x43a8c7,_0x2c3428):_0x4616c7=_0x169ef5['getNode']();}else{const _0x5cd182=b(_0xce806b);let _0x3625f3;if(_0x169ef5['isCompleteForChild'](_0x3802c8)){_0x267b13=_0x53bb93['serverCache']['getNode']();const _0x421b3c=or(_0x961745,_0xce806b,_0x169ef5['getNode'](),_0x267b13);_0x421b3c!=null?_0x3625f3=_0x169ef5['getNode']()['getImmediateChild'](_0x3802c8)['updateChild'](_0x5cd182,_0x421b3c):_0x3625f3=_0x169ef5['getNode']()['getImmediateChild'](_0x3802c8);}else _0x3625f3=ts(_0x961745,_0x3802c8,_0x53bb93['serverCache']);_0x3625f3!=null?_0x4616c7=_0x107911['filter']['updateChild'](_0x169ef5['getNode'](),_0x3802c8,_0x3625f3,_0x5cd182,_0x5506df,_0x44f06e):_0x4616c7=_0x169ef5['getNode']();}}return wt(_0x53bb93,_0x4616c7,_0x169ef5['isFullyInitialized']()||v(_0xce806b),_0x107911['filter']['filtersNodes']());}}function vn(_0xc07bbb,_0x41bf88,_0x36335d,_0xd75177,_0x49ae63,_0x1464df,_0x5c7181,_0x3e37c0){const _0x176b95=_0x41bf88['serverCache'];let _0x2c1df0;const _0x5ac89e=_0x5c7181?_0xc07bbb['filter']:_0xc07bbb['filter']['getIndexedFilter']();if(v(_0x36335d))_0x2c1df0=_0x5ac89e['updateFullNode'](_0x176b95['getNode'](),_0xd75177,null);else{if(_0x5ac89e['filtersNodes']()&&!_0x176b95['isFiltered']()){const _0x4a68e4=_0x176b95['getNode']()['updateChild'](_0x36335d,_0xd75177);_0x2c1df0=_0x5ac89e['updateFullNode'](_0x176b95['getNode'](),_0x4a68e4,null);}else{const _0x2a8e90=y(_0x36335d);if(!_0x176b95['isCompleteForPath'](_0x36335d)&&we(_0x36335d)>0x1)return _0x41bf88;const _0x5bc1f7=b(_0x36335d),_0x3df3ec=_0x176b95['getNode']()['getImmediateChild'](_0x2a8e90)['updateChild'](_0x5bc1f7,_0xd75177);_0x2a8e90==='.priority'?_0x2c1df0=_0x5ac89e['updatePriority'](_0x176b95['getNode'](),_0x3df3ec):_0x2c1df0=_0x5ac89e['updateChild'](_0x176b95['getNode'](),_0x2a8e90,_0x3df3ec,_0x5bc1f7,Vo,null);}}const _0x385cf8=Lo(_0x41bf88,_0x2c1df0,_0x176b95['isFullyInitialized']()||v(_0x36335d),_0x5ac89e['filtersNodes']()),_0x4e9ef3=new ns(_0x49ae63,_0x385cf8,_0x1464df);return Ho(_0xc07bbb,_0x385cf8,_0x36335d,_0x49ae63,_0x4e9ef3,_0x3e37c0);}function Ti(_0x5895ee,_0x1c78a9,_0x2e72f9,_0x296ae8,_0x4388bd,_0x2cc0a4,_0x4c2305){const _0x52ba94=_0x1c78a9['eventCache'];let _0x1c836f,_0x265e2d;const _0xc0aaa5=new ns(_0x4388bd,_0x1c78a9,_0x2cc0a4);if(v(_0x2e72f9))_0x265e2d=_0x5895ee['filter']['updateFullNode'](_0x1c78a9['eventCache']['getNode'](),_0x296ae8,_0x4c2305),_0x1c836f=wt(_0x1c78a9,_0x265e2d,!0x0,_0x5895ee['filter']['filtersNodes']());else{const _0x1a55ee=y(_0x2e72f9);if(_0x1a55ee==='.priority')_0x265e2d=_0x5895ee['filter']['updatePriority'](_0x1c78a9['eventCache']['getNode'](),_0x296ae8),_0x1c836f=wt(_0x1c78a9,_0x265e2d,_0x52ba94['isFullyInitialized'](),_0x52ba94['isFiltered']());else{const _0x20ad76=b(_0x2e72f9),_0x2e94c1=_0x52ba94['getNode']()['getImmediateChild'](_0x1a55ee);let _0x37028e;if(v(_0x20ad76))_0x37028e=_0x296ae8;else{const _0x9a35e2=_0xc0aaa5['getCompleteChild'](_0x1a55ee);_0x9a35e2!=null?Gi(_0x20ad76)==='.priority'&&_0x9a35e2['getChild'](To(_0x20ad76))['isEmpty']()?_0x37028e=_0x9a35e2:_0x37028e=_0x9a35e2['updateChild'](_0x20ad76,_0x296ae8):_0x37028e=g['EMPTY_NODE'];}if(_0x2e94c1['equals'](_0x37028e))_0x1c836f=_0x1c78a9;else{const _0x2e1f70=_0x5895ee['filter']['updateChild'](_0x52ba94['getNode'](),_0x1a55ee,_0x37028e,_0x20ad76,_0xc0aaa5,_0x4c2305);_0x1c836f=wt(_0x1c78a9,_0x2e1f70,_0x52ba94['isFullyInitialized'](),_0x5895ee['filter']['filtersNodes']());}}}return _0x1c836f;}function ar(_0x591b23,_0x19a7c9){return _0x591b23['eventCache']['isCompleteForChild'](_0x19a7c9);}function bu(_0x2bc8a0,_0x514aa8,_0x93b621,_0x3ade1e,_0x24c36e,_0x86fad0,_0x503e83){let _0x1cc3ee=_0x514aa8;return _0x3ade1e['foreach']((_0x34ac6d,_0x20d2f1)=>{const _0x22111d=A(_0x93b621,_0x34ac6d);ar(_0x514aa8,y(_0x22111d))&&(_0x1cc3ee=Ti(_0x2bc8a0,_0x1cc3ee,_0x22111d,_0x20d2f1,_0x24c36e,_0x86fad0,_0x503e83));}),_0x3ade1e['foreach']((_0xa15a68,_0x24f038)=>{const _0x5993f4=A(_0x93b621,_0xa15a68);ar(_0x514aa8,y(_0x5993f4))||(_0x1cc3ee=Ti(_0x2bc8a0,_0x1cc3ee,_0x5993f4,_0x24f038,_0x24c36e,_0x86fad0,_0x503e83));}),_0x1cc3ee;}function cr(_0x1595e1,_0x39f16c,_0x3edf5d){return _0x3edf5d['foreach']((_0x2dca82,_0x572f7d)=>{_0x39f16c=_0x39f16c['updateChild'](_0x2dca82,_0x572f7d);}),_0x39f16c;}function Si(_0x3f409b,_0xb84ae5,_0x27b687,_0xa536c7,_0x3210a6,_0x1d3bca,_0x23145e,_0x4601ac){if(_0xb84ae5['serverCache']['getNode']()['isEmpty']()&&!_0xb84ae5['serverCache']['isFullyInitialized']())return _0xb84ae5;let _0x5df1b1=_0xb84ae5,_0x2d5197;v(_0x27b687)?_0x2d5197=_0xa536c7:_0x2d5197=new S(null)['setTree'](_0x27b687,_0xa536c7);const _0x9cc4be=_0xb84ae5['serverCache']['getNode']();return _0x2d5197['children']['inorderTraversal']((_0x5f35ac,_0x47b691)=>{if(_0x9cc4be['hasChild'](_0x5f35ac)){const _0x1901d9=_0xb84ae5['serverCache']['getNode']()['getImmediateChild'](_0x5f35ac),_0x2095a3=cr(_0x3f409b,_0x1901d9,_0x47b691);_0x5df1b1=vn(_0x3f409b,_0x5df1b1,new C(_0x5f35ac),_0x2095a3,_0x3210a6,_0x1d3bca,_0x23145e,_0x4601ac);}}),_0x2d5197['children']['inorderTraversal']((_0x4e6ad5,_0x4a7260)=>{const _0x12f400=!_0xb84ae5['serverCache']['isCompleteForChild'](_0x4e6ad5)&&_0x4a7260['value']===null;if(!_0x9cc4be['hasChild'](_0x4e6ad5)&&!_0x12f400){const _0x231c02=_0xb84ae5['serverCache']['getNode']()['getImmediateChild'](_0x4e6ad5),_0x54670d=cr(_0x3f409b,_0x231c02,_0x4a7260);_0x5df1b1=vn(_0x3f409b,_0x5df1b1,new C(_0x4e6ad5),_0x54670d,_0x3210a6,_0x1d3bca,_0x23145e,_0x4601ac);}}),_0x5df1b1;}function Ru(_0x488dfd,_0x331700,_0x710ee3,_0x30e45a,_0x3d4627,_0x1571a5,_0x484d64){if(yn(_0x3d4627,_0x710ee3)!=null)return _0x331700;const _0x4b5496=_0x331700['serverCache']['isFiltered'](),_0x11e90b=_0x331700['serverCache'];if(_0x30e45a['value']!=null){if(v(_0x710ee3)&&_0x11e90b['isFullyInitialized']()||_0x11e90b['isCompleteForPath'](_0x710ee3))return vn(_0x488dfd,_0x331700,_0x710ee3,_0x11e90b['getNode']()['getChild'](_0x710ee3),_0x3d4627,_0x1571a5,_0x4b5496,_0x484d64);if(v(_0x710ee3)){let _0x3b08ab=new S(null);return _0x11e90b['getNode']()['forEachChild'](ye,(_0x14e898,_0x3478a8)=>{_0x3b08ab=_0x3b08ab['set'](new C(_0x14e898),_0x3478a8);}),Si(_0x488dfd,_0x331700,_0x710ee3,_0x3b08ab,_0x3d4627,_0x1571a5,_0x4b5496,_0x484d64);}else return _0x331700;}else{let _0x234f62=new S(null);return _0x30e45a['foreach']((_0xb13e07,_0x5090aa)=>{const _0x5e7c54=A(_0x710ee3,_0xb13e07);_0x11e90b['isCompleteForPath'](_0x5e7c54)&&(_0x234f62=_0x234f62['set'](_0xb13e07,_0x11e90b['getNode']()['getChild'](_0x5e7c54)));}),Si(_0x488dfd,_0x331700,_0x710ee3,_0x234f62,_0x3d4627,_0x1571a5,_0x4b5496,_0x484d64);}}function Au(_0xfd4c82,_0x1a69fa,_0x2fc7f1,_0x134e24,_0x2a3d10){const _0x457ac6=_0x1a69fa['serverCache'],_0x1a7917=Lo(_0x1a69fa,_0x457ac6['getNode'](),_0x457ac6['isFullyInitialized']()||v(_0x2fc7f1),_0x457ac6['isFiltered']());return Ho(_0xfd4c82,_0x1a7917,_0x2fc7f1,_0x134e24,Vo,_0x2a3d10);}function ku(_0x400a83,_0x5c3119,_0x41dbe2,_0x4c4172,_0x5f1a93,_0x1cd529){let _0x35d380;if(yn(_0x4c4172,_0x41dbe2)!=null)return _0x5c3119;{const _0x37b4f7=new ns(_0x4c4172,_0x5c3119,_0x5f1a93),_0x1b32be=_0x5c3119['eventCache']['getNode']();let _0x2c5625;if(v(_0x41dbe2)||y(_0x41dbe2)==='.priority'){let _0x244434;if(_0x5c3119['serverCache']['isFullyInitialized']())_0x244434=mn(_0x4c4172,Ue(_0x5c3119));else{const _0x186efd=_0x5c3119['serverCache']['getNode']();f(_0x186efd instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x244434=es(_0x4c4172,_0x186efd);}_0x244434=_0x244434,_0x2c5625=_0x400a83['filter']['updateFullNode'](_0x1b32be,_0x244434,_0x1cd529);}else{const _0x4f7910=y(_0x41dbe2);let _0x52944d=ts(_0x4c4172,_0x4f7910,_0x5c3119['serverCache']);_0x52944d==null&&_0x5c3119['serverCache']['isCompleteForChild'](_0x4f7910)&&(_0x52944d=_0x1b32be['getImmediateChild'](_0x4f7910)),_0x52944d!=null?_0x2c5625=_0x400a83['filter']['updateChild'](_0x1b32be,_0x4f7910,_0x52944d,b(_0x41dbe2),_0x37b4f7,_0x1cd529):_0x5c3119['eventCache']['getNode']()['hasChild'](_0x4f7910)?_0x2c5625=_0x400a83['filter']['updateChild'](_0x1b32be,_0x4f7910,g['EMPTY_NODE'],b(_0x41dbe2),_0x37b4f7,_0x1cd529):_0x2c5625=_0x1b32be,_0x2c5625['isEmpty']()&&_0x5c3119['serverCache']['isFullyInitialized']()&&(_0x35d380=mn(_0x4c4172,Ue(_0x5c3119)),_0x35d380['isLeafNode']()&&(_0x2c5625=_0x400a83['filter']['updateFullNode'](_0x2c5625,_0x35d380,_0x1cd529)));}return _0x35d380=_0x5c3119['serverCache']['isFullyInitialized']()||yn(_0x4c4172,w())!=null,wt(_0x5c3119,_0x2c5625,_0x35d380,_0x400a83['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x2d8a44,_0x173795){this['query_']=_0x2d8a44,this['eventRegistrations_']=[];const _0x469701=this['query_']['_queryParams'],_0x118e65=new Yi(_0x469701['getIndex']()),_0x8f3a42=qh(_0x469701);this['processor_']=wu(_0x8f3a42);const _0x557a0f=_0x173795['serverCache'],_0x5807b2=_0x173795['eventCache'],_0x5e4391=_0x118e65['updateFullNode'](g['EMPTY_NODE'],_0x557a0f['getNode'](),null),_0x29cced=_0x8f3a42['updateFullNode'](g['EMPTY_NODE'],_0x5807b2['getNode'](),null),_0x2bb144=new Ce(_0x5e4391,_0x557a0f['isFullyInitialized'](),_0x118e65['filtersNodes']()),_0x5eaa0b=new Ce(_0x29cced,_0x5807b2['isFullyInitialized'](),_0x8f3a42['filtersNodes']());this['viewCache_']=Dn(_0x5eaa0b,_0x2bb144),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x2cdfe4){return _0x2cdfe4['viewCache_']['serverCache']['getNode']();}function Ou(_0xbe277a){return gn(_0xbe277a['viewCache_']);}function Du(_0x508f0b,_0x72b427){const _0x5773e3=Ue(_0x508f0b['viewCache_']);return _0x5773e3&&(_0x508f0b['query']['_queryParams']['loadsAllData']()||!v(_0x72b427)&&!_0x5773e3['getImmediateChild'](y(_0x72b427))['isEmpty']())?_0x5773e3['getChild'](_0x72b427):null;}function lr(_0x12c890){return _0x12c890['eventRegistrations_']['length']===0x0;}function Mu(_0x2d0c26,_0x258966){_0x2d0c26['eventRegistrations_']['push'](_0x258966);}function hr(_0x178202,_0x4d658f,_0x3ba13a){const _0x5639f2=[];if(_0x3ba13a){f(_0x4d658f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x232e43=_0x178202['query']['_path'];_0x178202['eventRegistrations_']['forEach'](_0x152405=>{const _0x4e4c98=_0x152405['createCancelEvent'](_0x3ba13a,_0x232e43);_0x4e4c98&&_0x5639f2['push'](_0x4e4c98);});}if(_0x4d658f){let _0x29fc83=[];for(let _0x1766cf=0x0;_0x1766cf<_0x178202['eventRegistrations_']['length'];++_0x1766cf){const _0x373c2e=_0x178202['eventRegistrations_'][_0x1766cf];if(!_0x373c2e['matches'](_0x4d658f))_0x29fc83['push'](_0x373c2e);else{if(_0x4d658f['hasAnyCallback']()){_0x29fc83=_0x29fc83['concat'](_0x178202['eventRegistrations_']['slice'](_0x1766cf+0x1));break;}}}_0x178202['eventRegistrations_']=_0x29fc83;}else _0x178202['eventRegistrations_']=[];return _0x5639f2;}function ur(_0x16bb64,_0x321657,_0x25d9ac,_0x54f7f4){_0x321657['type']===q['MERGE']&&_0x321657['source']['queryId']!==null&&(f(Ue(_0x16bb64['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x16bb64['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2ca861=_0x16bb64['viewCache_'],_0x56729d=Tu(_0x16bb64['processor_'],_0x2ca861,_0x321657,_0x25d9ac,_0x54f7f4);return Cu(_0x16bb64['processor_'],_0x56729d['viewCache']),f(_0x56729d['viewCache']['serverCache']['isFullyInitialized']()||!_0x2ca861['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x16bb64['viewCache_']=_0x56729d['viewCache'],$o(_0x16bb64,_0x56729d['changes'],_0x56729d['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x411f4f,_0x357799){const _0x518bd6=_0x411f4f['viewCache_']['eventCache'],_0x296160=[];return _0x518bd6['getNode']()['isLeafNode']()||_0x518bd6['getNode']()['forEachChild'](R,(_0x2f021b,_0x207c5e)=>{_0x296160['push'](tt(_0x2f021b,_0x207c5e));}),_0x518bd6['isFullyInitialized']()&&_0x296160['push'](Oo(_0x518bd6['getNode']())),$o(_0x411f4f,_0x296160,_0x518bd6['getNode'](),_0x357799);}function $o(_0x592732,_0x1d7863,_0x55fd20,_0x54ad18){const _0x301706=_0x54ad18?[_0x54ad18]:_0x592732['eventRegistrations_'];return nu(_0x592732['eventGenerator_'],_0x1d7863,_0x55fd20,_0x301706);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x2a7722){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x2a7722;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x308a96){return _0x308a96['views']['size']===0x0;}function is(_0x2020a7,_0x1a57d4,_0x3416fd,_0x3b2931){const _0x50545e=_0x1a57d4['source']['queryId'];if(_0x50545e!==null){const _0x5bf610=_0x2020a7['views']['get'](_0x50545e);return f(_0x5bf610!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x5bf610,_0x1a57d4,_0x3416fd,_0x3b2931);}else{let _0x4362e7=[];for(const _0x1d07f4 of _0x2020a7['views']['values']())_0x4362e7=_0x4362e7['concat'](ur(_0x1d07f4,_0x1a57d4,_0x3416fd,_0x3b2931));return _0x4362e7;}}function qo(_0x12b053,_0xb75426,_0x24a847,_0x35b574,_0x34e036){const _0x2b6f1d=_0xb75426['_queryIdentifier'],_0x1fa1d4=_0x12b053['views']['get'](_0x2b6f1d);if(!_0x1fa1d4){let _0x34def0=mn(_0x24a847,_0x34e036?_0x35b574:null),_0x392fc=!0x1;_0x34def0?_0x392fc=!0x0:_0x35b574 instanceof g?(_0x34def0=es(_0x24a847,_0x35b574),_0x392fc=!0x1):(_0x34def0=g['EMPTY_NODE'],_0x392fc=!0x1);const _0x5f282b=Dn(new Ce(_0x34def0,_0x392fc,!0x1),new Ce(_0x35b574,_0x34e036,!0x1));return new Nu(_0xb75426,_0x5f282b);}return _0x1fa1d4;}function Wu(_0x1d5ce3,_0x5d46ee,_0x40bb99,_0x4c8594,_0x5a3e4a,_0xe18a6d){const _0x250602=qo(_0x1d5ce3,_0x5d46ee,_0x4c8594,_0x5a3e4a,_0xe18a6d);return _0x1d5ce3['views']['has'](_0x5d46ee['_queryIdentifier'])||_0x1d5ce3['views']['set'](_0x5d46ee['_queryIdentifier'],_0x250602),Mu(_0x250602,_0x40bb99),Lu(_0x250602,_0x40bb99);}function Bu(_0x2dea3a,_0x732728,_0x55f0e1,_0x22be92){const _0x232232=_0x732728['_queryIdentifier'],_0x2f7b5e=[];let _0x373e18=[];const _0x21c148=Te(_0x2dea3a);if(_0x232232==='default'){for(const [_0x3ab560,_0x4486d7]of _0x2dea3a['views']['entries']())_0x373e18=_0x373e18['concat'](hr(_0x4486d7,_0x55f0e1,_0x22be92)),lr(_0x4486d7)&&(_0x2dea3a['views']['delete'](_0x3ab560),_0x4486d7['query']['_queryParams']['loadsAllData']()||_0x2f7b5e['push'](_0x4486d7['query']));}else{const _0x554ff5=_0x2dea3a['views']['get'](_0x232232);_0x554ff5&&(_0x373e18=_0x373e18['concat'](hr(_0x554ff5,_0x55f0e1,_0x22be92)),lr(_0x554ff5)&&(_0x2dea3a['views']['delete'](_0x232232),_0x554ff5['query']['_queryParams']['loadsAllData']()||_0x2f7b5e['push'](_0x554ff5['query'])));}return _0x21c148&&!Te(_0x2dea3a)&&_0x2f7b5e['push'](new(Fu())(_0x732728['_repo'],_0x732728['_path'])),{'removed':_0x2f7b5e,'events':_0x373e18};}function zo(_0x3735e5){const _0x178124=[];for(const _0x29c4a3 of _0x3735e5['views']['values']())_0x29c4a3['query']['_queryParams']['loadsAllData']()||_0x178124['push'](_0x29c4a3);return _0x178124;}function Ee(_0x6367db,_0x4cd897){let _0x17d85f=null;for(const _0x1fff3a of _0x6367db['views']['values']())_0x17d85f=_0x17d85f||Du(_0x1fff3a,_0x4cd897);return _0x17d85f;}function jo(_0x3aaaaa,_0x14b691){if(_0x14b691['_queryParams']['loadsAllData']())return Ln(_0x3aaaaa);{const _0xe7ae4c=_0x14b691['_queryIdentifier'];return _0x3aaaaa['views']['get'](_0xe7ae4c);}}function Ko(_0x32f74f,_0xfb1628){return jo(_0x32f74f,_0xfb1628)!=null;}function Te(_0x5f5e06){return Ln(_0x5f5e06)!=null;}function Ln(_0x576d3b){for(const _0x8f9c5c of _0x576d3b['views']['values']())if(_0x8f9c5c['query']['_queryParams']['loadsAllData']())return _0x8f9c5c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x4db11c){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x4db11c;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x15cc90){this['listenProvider_']=_0x15cc90,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x288c0e,_0x1f2069,_0x166c5b,_0x2e1bd2,_0x1f1445){return ou(_0x288c0e['pendingWriteTree_'],_0x1f2069,_0x166c5b,_0x2e1bd2,_0x1f1445),_0x1f1445?ht(_0x288c0e,new Fe(Ji(),_0x1f2069,_0x166c5b)):[];}function Gu(_0x305ade,_0x3acf00,_0x386829,_0xd844ca){au(_0x305ade['pendingWriteTree_'],_0x3acf00,_0x386829,_0xd844ca);const _0x35d742=S['fromObject'](_0x386829);return ht(_0x305ade,new nt(Ji(),_0x3acf00,_0x35d742));}function pe(_0x330914,_0x42f4d8,_0x409f48=!0x1){const _0x1c64b0=cu(_0x330914['pendingWriteTree_'],_0x42f4d8);if(lu(_0x330914['pendingWriteTree_'],_0x42f4d8)){let _0x1f2cf7=new S(null);return _0x1c64b0['snap']!=null?_0x1f2cf7=_0x1f2cf7['set'](w(),!0x0):x(_0x1c64b0['children'],_0x80a420=>{_0x1f2cf7=_0x1f2cf7['set'](new C(_0x80a420),!0x0);}),ht(_0x330914,new _n(_0x1c64b0['path'],_0x1f2cf7,_0x409f48));}else return[];}function $t(_0x4e69f6,_0x2c841d,_0x477275){return ht(_0x4e69f6,new Fe(Xi(),_0x2c841d,_0x477275));}function qu(_0x1b27a6,_0x215d1a,_0x264445){const _0x2f760f=S['fromObject'](_0x264445);return ht(_0x1b27a6,new nt(Xi(),_0x215d1a,_0x2f760f));}function zu(_0x3dcfd7,_0x5ea762){return ht(_0x3dcfd7,new Dt(Xi(),_0x5ea762));}function ju(_0x55c0,_0x3bff96,_0x1a823b){const _0x251b0d=rs(_0x55c0,_0x1a823b);if(_0x251b0d){const _0x33d2f2=os(_0x251b0d),_0x40da94=_0x33d2f2['path'],_0x3bfdef=_0x33d2f2['queryId'],_0x1ed767=F(_0x40da94,_0x3bff96),_0x1f3fe9=new Dt(Zi(_0x3bfdef),_0x1ed767);return as(_0x55c0,_0x40da94,_0x1f3fe9);}else return[];}function wn(_0x44242d,_0x3c159c,_0x43b689,_0x10028d,_0x1259ee=!0x1){const _0x297263=_0x3c159c['_path'],_0x5a6a5d=_0x44242d['syncPointTree_']['get'](_0x297263);let _0x23c54a=[];if(_0x5a6a5d&&(_0x3c159c['_queryIdentifier']==='default'||Ko(_0x5a6a5d,_0x3c159c))){const _0x42a0aa=Bu(_0x5a6a5d,_0x3c159c,_0x43b689,_0x10028d);Uu(_0x5a6a5d)&&(_0x44242d['syncPointTree_']=_0x44242d['syncPointTree_']['remove'](_0x297263));const _0x1fb187=_0x42a0aa['removed'];if(_0x23c54a=_0x42a0aa['events'],!_0x1259ee){const _0x210b99=_0x1fb187['findIndex'](_0x5069bc=>_0x5069bc['_queryParams']['loadsAllData']())!==-0x1,_0x486270=_0x44242d['syncPointTree_']['findOnPath'](_0x297263,(_0x2fc2e0,_0x5b98e0)=>Te(_0x5b98e0));if(_0x210b99&&!_0x486270){const _0x2e70de=_0x44242d['syncPointTree_']['subtree'](_0x297263);if(!_0x2e70de['isEmpty']()){const _0x2c4240=Qu(_0x2e70de);for(let _0x24c3ed=0x0;_0x24c3ed<_0x2c4240['length'];++_0x24c3ed){const _0x336766=_0x2c4240[_0x24c3ed],_0x3cdeae=_0x336766['query'],_0x4e60c1=Xo(_0x44242d,_0x336766);_0x44242d['listenProvider_']['startListening'](Tt(_0x3cdeae),Mt(_0x44242d,_0x3cdeae),_0x4e60c1['hashFn'],_0x4e60c1['onComplete']);}}}!_0x486270&&_0x1fb187['length']>0x0&&!_0x10028d&&(_0x210b99?_0x44242d['listenProvider_']['stopListening'](Tt(_0x3c159c),null):_0x1fb187['forEach'](_0x503190=>{const _0x2e43d2=_0x44242d['queryToTagMap']['get'](Fn(_0x503190));_0x44242d['listenProvider_']['stopListening'](Tt(_0x503190),_0x2e43d2);}));}Ju(_0x44242d,_0x1fb187);}return _0x23c54a;}function Yo(_0x5a37cb,_0x3bfd21,_0x395dfc,_0x3ad8d1){const _0xb906da=rs(_0x5a37cb,_0x3ad8d1);if(_0xb906da!=null){const _0x1a6f08=os(_0xb906da),_0x4e77ee=_0x1a6f08['path'],_0x396e77=_0x1a6f08['queryId'],_0x3faeb6=F(_0x4e77ee,_0x3bfd21),_0x9f336=new Fe(Zi(_0x396e77),_0x3faeb6,_0x395dfc);return as(_0x5a37cb,_0x4e77ee,_0x9f336);}else return[];}function Ku(_0x27520e,_0x2194c2,_0x1fbdf7,_0x3b933c){const _0x533d0f=rs(_0x27520e,_0x3b933c);if(_0x533d0f){const _0x457e10=os(_0x533d0f),_0x3c00ad=_0x457e10['path'],_0x54d2bb=_0x457e10['queryId'],_0x1ba2fb=F(_0x3c00ad,_0x2194c2),_0x1cd478=S['fromObject'](_0x1fbdf7),_0x2e11af=new nt(Zi(_0x54d2bb),_0x1ba2fb,_0x1cd478);return as(_0x27520e,_0x3c00ad,_0x2e11af);}else return[];}function bi(_0x439fec,_0x2d2e8d,_0xa468e1,_0xa97ffd=!0x1){const _0xe06d5c=_0x2d2e8d['_path'];let _0x5a28a5=null,_0x537514=!0x1;_0x439fec['syncPointTree_']['foreachOnPath'](_0xe06d5c,(_0x330153,_0x31ddc4)=>{const _0x3e41d9=F(_0x330153,_0xe06d5c);_0x5a28a5=_0x5a28a5||Ee(_0x31ddc4,_0x3e41d9),_0x537514=_0x537514||Te(_0x31ddc4);});let _0x23beb6=_0x439fec['syncPointTree_']['get'](_0xe06d5c);_0x23beb6?(_0x537514=_0x537514||Te(_0x23beb6),_0x5a28a5=_0x5a28a5||Ee(_0x23beb6,w())):(_0x23beb6=new Go(),_0x439fec['syncPointTree_']=_0x439fec['syncPointTree_']['set'](_0xe06d5c,_0x23beb6));let _0x50a5f1;_0x5a28a5!=null?_0x50a5f1=!0x0:(_0x50a5f1=!0x1,_0x5a28a5=g['EMPTY_NODE'],_0x439fec['syncPointTree_']['subtree'](_0xe06d5c)['foreachChild']((_0xa728a2,_0xbac38d)=>{const _0x5b4f5e=Ee(_0xbac38d,w());_0x5b4f5e&&(_0x5a28a5=_0x5a28a5['updateImmediateChild'](_0xa728a2,_0x5b4f5e));}));const _0x103add=Ko(_0x23beb6,_0x2d2e8d);if(!_0x103add&&!_0x2d2e8d['_queryParams']['loadsAllData']()){const _0x18db5d=Fn(_0x2d2e8d);f(!_0x439fec['queryToTagMap']['has'](_0x18db5d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x28bf28=Xu();_0x439fec['queryToTagMap']['set'](_0x18db5d,_0x28bf28),_0x439fec['tagToQueryMap']['set'](_0x28bf28,_0x18db5d);}const _0x3c9cba=Mn(_0x439fec['pendingWriteTree_'],_0xe06d5c);let _0x48413a=Wu(_0x23beb6,_0x2d2e8d,_0xa468e1,_0x3c9cba,_0x5a28a5,_0x50a5f1);if(!_0x103add&&!_0x537514&&!_0xa97ffd){const _0x3e83c1=jo(_0x23beb6,_0x2d2e8d);_0x48413a=_0x48413a['concat'](Zu(_0x439fec,_0x2d2e8d,_0x3e83c1));}return _0x48413a;}function xn(_0x5b0f5b,_0x93c028,_0x357164){const _0x56c4c2=_0x5b0f5b['pendingWriteTree_'],_0x42734e=_0x5b0f5b['syncPointTree_']['findOnPath'](_0x93c028,(_0x33c2b6,_0x1beb36)=>{const _0x4e6694=F(_0x33c2b6,_0x93c028),_0x4df431=Ee(_0x1beb36,_0x4e6694);if(_0x4df431)return _0x4df431;});return Uo(_0x56c4c2,_0x93c028,_0x42734e,_0x357164,!0x0);}function Yu(_0x42df5d,_0x4ddc7a){const _0x1a75a5=_0x4ddc7a['_path'];let _0x110d2b=null;_0x42df5d['syncPointTree_']['foreachOnPath'](_0x1a75a5,(_0x1eda7c,_0x535b39)=>{const _0x234d5a=F(_0x1eda7c,_0x1a75a5);_0x110d2b=_0x110d2b||Ee(_0x535b39,_0x234d5a);});let _0x2f4e85=_0x42df5d['syncPointTree_']['get'](_0x1a75a5);_0x2f4e85?_0x110d2b=_0x110d2b||Ee(_0x2f4e85,w()):(_0x2f4e85=new Go(),_0x42df5d['syncPointTree_']=_0x42df5d['syncPointTree_']['set'](_0x1a75a5,_0x2f4e85));const _0x9d842=_0x110d2b!=null,_0x19c596=_0x9d842?new Ce(_0x110d2b,!0x0,!0x1):null,_0x52ab22=Mn(_0x42df5d['pendingWriteTree_'],_0x4ddc7a['_path']),_0x19dc83=qo(_0x2f4e85,_0x4ddc7a,_0x52ab22,_0x9d842?_0x19c596['getNode']():g['EMPTY_NODE'],_0x9d842);return Ou(_0x19dc83);}function ht(_0x12dc39,_0xc2b91){return Qo(_0xc2b91,_0x12dc39['syncPointTree_'],null,Mn(_0x12dc39['pendingWriteTree_'],w()));}function Qo(_0x4501fe,_0xc8ecd3,_0x5f498a,_0x2bae7a){if(v(_0x4501fe['path']))return Jo(_0x4501fe,_0xc8ecd3,_0x5f498a,_0x2bae7a);{const _0x303f11=_0xc8ecd3['get'](w());_0x5f498a==null&&_0x303f11!=null&&(_0x5f498a=Ee(_0x303f11,w()));let _0x1c66ed=[];const _0x9033ef=y(_0x4501fe['path']),_0x6f9871=_0x4501fe['operationForChild'](_0x9033ef),_0x1df25f=_0xc8ecd3['children']['get'](_0x9033ef);if(_0x1df25f&&_0x6f9871){const _0x37fd41=_0x5f498a?_0x5f498a['getImmediateChild'](_0x9033ef):null,_0x24ab67=Wo(_0x2bae7a,_0x9033ef);_0x1c66ed=_0x1c66ed['concat'](Qo(_0x6f9871,_0x1df25f,_0x37fd41,_0x24ab67));}return _0x303f11&&(_0x1c66ed=_0x1c66ed['concat'](is(_0x303f11,_0x4501fe,_0x2bae7a,_0x5f498a))),_0x1c66ed;}}function Jo(_0x12d2f4,_0x2ba398,_0x113af0,_0x48e164){const _0x1ca4eb=_0x2ba398['get'](w());_0x113af0==null&&_0x1ca4eb!=null&&(_0x113af0=Ee(_0x1ca4eb,w()));let _0x71a786=[];return _0x2ba398['children']['inorderTraversal']((_0x387035,_0x1b82ad)=>{const _0x10277f=_0x113af0?_0x113af0['getImmediateChild'](_0x387035):null,_0x2597c1=Wo(_0x48e164,_0x387035),_0x2cc898=_0x12d2f4['operationForChild'](_0x387035);_0x2cc898&&(_0x71a786=_0x71a786['concat'](Jo(_0x2cc898,_0x1b82ad,_0x10277f,_0x2597c1)));}),_0x1ca4eb&&(_0x71a786=_0x71a786['concat'](is(_0x1ca4eb,_0x12d2f4,_0x48e164,_0x113af0))),_0x71a786;}function Xo(_0x17f921,_0x17add7){const _0x2af792=_0x17add7['query'],_0x10456c=Mt(_0x17f921,_0x2af792);return{'hashFn':()=>(Pu(_0x17add7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2746e3=>{if(_0x2746e3==='ok')return _0x10456c?ju(_0x17f921,_0x2af792['_path'],_0x10456c):zu(_0x17f921,_0x2af792['_path']);{const _0x154fea=ql(_0x2746e3,_0x2af792);return wn(_0x17f921,_0x2af792,null,_0x154fea);}}};}function Mt(_0x4a026a,_0x2cfa7d){const _0x95fd12=Fn(_0x2cfa7d);return _0x4a026a['queryToTagMap']['get'](_0x95fd12);}function Fn(_0x52bee7){return _0x52bee7['_path']['toString']()+'$'+_0x52bee7['_queryIdentifier'];}function rs(_0xe2e1a0,_0xdd2add){return _0xe2e1a0['tagToQueryMap']['get'](_0xdd2add);}function os(_0x4860d3){const _0xed1644=_0x4860d3['indexOf']('$');return f(_0xed1644!==-0x1&&_0xed1644<_0x4860d3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4860d3['substr'](_0xed1644+0x1),'path':new C(_0x4860d3['substr'](0x0,_0xed1644))};}function as(_0x174c89,_0x650295,_0x2c8711){const _0x51fff9=_0x174c89['syncPointTree_']['get'](_0x650295);f(_0x51fff9,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3d38c5=Mn(_0x174c89['pendingWriteTree_'],_0x650295);return is(_0x51fff9,_0x2c8711,_0x3d38c5,null);}function Qu(_0xb5a523){return _0xb5a523['fold']((_0x569351,_0x168cc7,_0x5c38ad)=>{if(_0x168cc7&&Te(_0x168cc7))return[Ln(_0x168cc7)];{let _0x3b35dd=[];return _0x168cc7&&(_0x3b35dd=zo(_0x168cc7)),x(_0x5c38ad,(_0x29f7a6,_0x5ea3bb)=>{_0x3b35dd=_0x3b35dd['concat'](_0x5ea3bb);}),_0x3b35dd;}});}function Tt(_0x1fa552){return _0x1fa552['_queryParams']['loadsAllData']()&&!_0x1fa552['_queryParams']['isDefault']()?new(Hu())(_0x1fa552['_repo'],_0x1fa552['_path']):_0x1fa552;}function Ju(_0x1a0c48,_0x1be1da){for(let _0xc112ea=0x0;_0xc112ea<_0x1be1da['length'];++_0xc112ea){const _0x292bcd=_0x1be1da[_0xc112ea];if(!_0x292bcd['_queryParams']['loadsAllData']()){const _0x3038a1=Fn(_0x292bcd),_0x5d4e0f=_0x1a0c48['queryToTagMap']['get'](_0x3038a1);_0x1a0c48['queryToTagMap']['delete'](_0x3038a1),_0x1a0c48['tagToQueryMap']['delete'](_0x5d4e0f);}}}function Xu(){return $u++;}function Zu(_0x538710,_0x6c330b,_0x193147){const _0xcafd26=_0x6c330b['_path'],_0x2ef12f=Mt(_0x538710,_0x6c330b),_0x3a4ae5=Xo(_0x538710,_0x193147),_0x4b90e4=_0x538710['listenProvider_']['startListening'](Tt(_0x6c330b),_0x2ef12f,_0x3a4ae5['hashFn'],_0x3a4ae5['onComplete']),_0x323833=_0x538710['syncPointTree_']['subtree'](_0xcafd26);if(_0x2ef12f)f(!Te(_0x323833['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5dc728=_0x323833['fold']((_0x187cee,_0x5a4493,_0x2ff70c)=>{if(!v(_0x187cee)&&_0x5a4493&&Te(_0x5a4493))return[Ln(_0x5a4493)['query']];{let _0x1fda03=[];return _0x5a4493&&(_0x1fda03=_0x1fda03['concat'](zo(_0x5a4493)['map'](_0x48dae5=>_0x48dae5['query']))),x(_0x2ff70c,(_0x3a85b3,_0x5053aa)=>{_0x1fda03=_0x1fda03['concat'](_0x5053aa);}),_0x1fda03;}});for(let _0x4b3e4d=0x0;_0x4b3e4d<_0x5dc728['length'];++_0x4b3e4d){const _0x1296c6=_0x5dc728[_0x4b3e4d];_0x538710['listenProvider_']['stopListening'](Tt(_0x1296c6),Mt(_0x538710,_0x1296c6));}}return _0x4b90e4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x502db3){this['node_']=_0x502db3;}['getImmediateChild'](_0x2d6cb4){const _0x22e67c=this['node_']['getImmediateChild'](_0x2d6cb4);return new cs(_0x22e67c);}['node'](){return this['node_'];}}class ls{constructor(_0x47528d,_0x24f8ec){this['syncTree_']=_0x47528d,this['path_']=_0x24f8ec;}['getImmediateChild'](_0x22c3d6){const _0x5c6bc0=A(this['path_'],_0x22c3d6);return new ls(this['syncTree_'],_0x5c6bc0);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x363ff0){return _0x363ff0=_0x363ff0||{},_0x363ff0['timestamp']=_0x363ff0['timestamp']||new Date()['getTime'](),_0x363ff0;},fr=function(_0x2017e4,_0x360196,_0x489657){if(!_0x2017e4||typeof _0x2017e4!='object')return _0x2017e4;if(f('.sv'in _0x2017e4,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2017e4['.sv']=='string')return td(_0x2017e4['.sv'],_0x360196,_0x489657);if(typeof _0x2017e4['.sv']=='object')return nd(_0x2017e4['.sv'],_0x360196);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2017e4,null,0x2));},td=function(_0x20d3e6,_0x35ed71,_0x591693){switch(_0x20d3e6){case'timestamp':return _0x591693['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x20d3e6);}},nd=function(_0x3bc58e,_0x5cf879,_0x18012f){_0x3bc58e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3bc58e,null,0x2));const _0x133076=_0x3bc58e['increment'];typeof _0x133076!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x133076);const _0x7ca0bb=_0x5cf879['node']();if(f(_0x7ca0bb!==null&&typeof _0x7ca0bb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x7ca0bb['isLeafNode']())return _0x133076;const _0x2a3ce3=_0x7ca0bb['getValue']();return typeof _0x2a3ce3!='number'?_0x133076:_0x2a3ce3+_0x133076;},Zo=function(_0x38450a,_0xef0770,_0x2dcbc8,_0x555e54){return us(_0xef0770,new ls(_0x2dcbc8,_0x38450a),_0x555e54);},hs=function(_0x5ab620,_0x4f554c,_0x38d3be){return us(_0x5ab620,new cs(_0x4f554c),_0x38d3be);};function us(_0x1efa10,_0x77a95b,_0x101d72){const _0x4eacc7=_0x1efa10['getPriority']()['val'](),_0xebeb65=fr(_0x4eacc7,_0x77a95b['getImmediateChild']('.priority'),_0x101d72);let _0x120a07;if(_0x1efa10['isLeafNode']()){const _0x14ff26=_0x1efa10,_0x5390d9=fr(_0x14ff26['getValue'](),_0x77a95b,_0x101d72);return _0x5390d9!==_0x14ff26['getValue']()||_0xebeb65!==_0x14ff26['getPriority']()['val']()?new D(_0x5390d9,N(_0xebeb65)):_0x1efa10;}else{const _0x217fe2=_0x1efa10;return _0x120a07=_0x217fe2,_0xebeb65!==_0x217fe2['getPriority']()['val']()&&(_0x120a07=_0x120a07['updatePriority'](new D(_0xebeb65))),_0x217fe2['forEachChild'](R,(_0x23aa21,_0x4fc273)=>{const _0x47ad83=us(_0x4fc273,_0x77a95b['getImmediateChild'](_0x23aa21),_0x101d72);_0x47ad83!==_0x4fc273&&(_0x120a07=_0x120a07['updateImmediateChild'](_0x23aa21,_0x47ad83));}),_0x120a07;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x54fb28='',_0x2ca458=null,_0x5421f7={'children':{},'childCount':0x0}){this['name']=_0x54fb28,this['parent']=_0x2ca458,this['node']=_0x5421f7;}}function Un(_0x462ec2,_0x6605ec){let _0x362081=_0x6605ec instanceof C?_0x6605ec:new C(_0x6605ec),_0x4aba2c=_0x462ec2,_0x2aa6ff=y(_0x362081);for(;_0x2aa6ff!==null;){const _0x1edb1d=Oe(_0x4aba2c['node']['children'],_0x2aa6ff)||{'children':{},'childCount':0x0};_0x4aba2c=new ds(_0x2aa6ff,_0x4aba2c,_0x1edb1d),_0x362081=b(_0x362081),_0x2aa6ff=y(_0x362081);}return _0x4aba2c;}function Ge(_0x9ecdb0){return _0x9ecdb0['node']['value'];}function fs(_0x3f2ce1,_0x4af1cd){_0x3f2ce1['node']['value']=_0x4af1cd,Ri(_0x3f2ce1);}function ea(_0x9ae8ad){return _0x9ae8ad['node']['childCount']>0x0;}function id(_0x21b47f){return Ge(_0x21b47f)===void 0x0&&!ea(_0x21b47f);}function Wn(_0x3c7361,_0x1f9062){x(_0x3c7361['node']['children'],(_0x210ac7,_0x280430)=>{_0x1f9062(new ds(_0x210ac7,_0x3c7361,_0x280430));});}function ta(_0x2c33f3,_0x40f3b1,_0x30a5cb,_0x43dff1){_0x30a5cb&&_0x40f3b1(_0x2c33f3),Wn(_0x2c33f3,_0x383469=>{ta(_0x383469,_0x40f3b1,!0x0);});}function sd(_0x254489,_0x57eba4,_0x2f8246){let _0x269600=_0x254489['parent'];for(;_0x269600!==null;){if(_0x57eba4(_0x269600))return!0x0;_0x269600=_0x269600['parent'];}return!0x1;}function Gt(_0x2c4ba8){return new C(_0x2c4ba8['parent']===null?_0x2c4ba8['name']:Gt(_0x2c4ba8['parent'])+'/'+_0x2c4ba8['name']);}function Ri(_0x17c8d8){_0x17c8d8['parent']!==null&&rd(_0x17c8d8['parent'],_0x17c8d8['name'],_0x17c8d8);}function rd(_0xa39b6a,_0x2b5e5f,_0xcdcdc8){const _0x502f08=id(_0xcdcdc8),_0x4956f2=Y(_0xa39b6a['node']['children'],_0x2b5e5f);_0x502f08&&_0x4956f2?(delete _0xa39b6a['node']['children'][_0x2b5e5f],_0xa39b6a['node']['childCount']--,Ri(_0xa39b6a)):!_0x502f08&&!_0x4956f2&&(_0xa39b6a['node']['children'][_0x2b5e5f]=_0xcdcdc8['node'],_0xa39b6a['node']['childCount']++,Ri(_0xa39b6a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2c7a97){return typeof _0x2c7a97=='string'&&_0x2c7a97['length']!==0x0&&!od['test'](_0x2c7a97);},na=function(_0x5911f){return typeof _0x5911f=='string'&&_0x5911f['length']!==0x0&&!ad['test'](_0x5911f);},cd=function(_0x7a7f29){return _0x7a7f29&&(_0x7a7f29=_0x7a7f29['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x7a7f29);},Cn=function(_0x491b2d){return _0x491b2d===null||typeof _0x491b2d=='string'||typeof _0x491b2d=='number'&&!Wi(_0x491b2d)||_0x491b2d&&typeof _0x491b2d=='object'&&Y(_0x491b2d,'.sv');},qt=function(_0x154411,_0x189090,_0x33a154,_0xc39602){_0xc39602&&_0x189090===void 0x0||zt(Nn(_0x154411,'value'),_0x189090,_0x33a154);},zt=function(_0x4940c8,_0x553686,_0x20ae9d){const _0x5582f7=_0x20ae9d instanceof C?new Sh(_0x20ae9d,_0x4940c8):_0x20ae9d;if(_0x553686===void 0x0)throw new Error(_0x4940c8+'contains\x20undefined\x20'+Ne(_0x5582f7));if(typeof _0x553686=='function')throw new Error(_0x4940c8+'contains\x20a\x20function\x20'+Ne(_0x5582f7)+'\x20with\x20contents\x20=\x20'+_0x553686['toString']());if(Wi(_0x553686))throw new Error(_0x4940c8+'contains\x20'+_0x553686['toString']()+'\x20'+Ne(_0x5582f7));if(typeof _0x553686=='string'&&_0x553686['length']>oi/0x3&&Pn(_0x553686)>oi)throw new Error(_0x4940c8+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x5582f7)+'\x20(\x27'+_0x553686['substring'](0x0,0x32)+'...\x27)');if(_0x553686&&typeof _0x553686=='object'){let _0x3f7632=!0x1,_0x2860c6=!0x1;if(x(_0x553686,(_0x2eab37,_0xbb0e21)=>{if(_0x2eab37==='.value')_0x3f7632=!0x0;else{if(_0x2eab37!=='.priority'&&_0x2eab37!=='.sv'&&(_0x2860c6=!0x0,!ps(_0x2eab37)))throw new Error(_0x4940c8+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2eab37+')\x20'+Ne(_0x5582f7)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x5582f7,_0x2eab37),zt(_0x4940c8,_0xbb0e21,_0x5582f7),Rh(_0x5582f7);}),_0x3f7632&&_0x2860c6)throw new Error(_0x4940c8+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x5582f7)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x58ac3f,_0xc6d1c){let _0xe25e9f,_0x3db2a0;for(_0xe25e9f=0x0;_0xe25e9f<_0xc6d1c['length'];_0xe25e9f++){_0x3db2a0=_0xc6d1c[_0xe25e9f];const _0x342478=kt(_0x3db2a0);for(let _0x3a97d8=0x0;_0x3a97d8<_0x342478['length'];_0x3a97d8++)if(!(_0x342478[_0x3a97d8]==='.priority'&&_0x3a97d8===_0x342478['length']-0x1)){if(!ps(_0x342478[_0x3a97d8]))throw new Error(_0x58ac3f+'contains\x20an\x20invalid\x20key\x20('+_0x342478[_0x3a97d8]+')\x20in\x20path\x20'+_0x3db2a0['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0xc6d1c['sort'](Th);let _0x9c61a3=null;for(_0xe25e9f=0x0;_0xe25e9f<_0xc6d1c['length'];_0xe25e9f++){if(_0x3db2a0=_0xc6d1c[_0xe25e9f],_0x9c61a3!==null&&$(_0x9c61a3,_0x3db2a0))throw new Error(_0x58ac3f+'contains\x20a\x20path\x20'+_0x9c61a3['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3db2a0['toString']());_0x9c61a3=_0x3db2a0;}},hd=function(_0x561984,_0x501b5a,_0x70c95e,_0x3a67a5){const _0x4d6bc1=Nn(_0x561984,'values');if(!(_0x501b5a&&typeof _0x501b5a=='object')||Array['isArray'](_0x501b5a))throw new Error(_0x4d6bc1+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2a9dc4=[];x(_0x501b5a,(_0x17786b,_0x12110d)=>{const _0x35d961=new C(_0x17786b);if(zt(_0x4d6bc1,_0x12110d,A(_0x70c95e,_0x35d961)),Gi(_0x35d961)==='.priority'&&!Cn(_0x12110d))throw new Error(_0x4d6bc1+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x35d961['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2a9dc4['push'](_0x35d961);}),ld(_0x4d6bc1,_0x2a9dc4);},_s=function(_0x2af668,_0x3f03a8,_0x44f297,_0x340ea0){if(!na(_0x44f297))throw new Error(Nn(_0x2af668,_0x3f03a8)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x44f297+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x4ba797,_0xf48d77,_0x49ab74,_0x85f617){_0x49ab74&&(_0x49ab74=_0x49ab74['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x4ba797,_0xf48d77,_0x49ab74);},gs=function(_0x21b8ae,_0x5e0b97){if(y(_0x5e0b97)==='.info')throw new Error(_0x21b8ae+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x2e69f2,_0x1d15a4){const _0x258355=_0x1d15a4['path']['toString']();if(typeof _0x1d15a4['repoInfo']['host']!='string'||_0x1d15a4['repoInfo']['host']['length']===0x0||!ps(_0x1d15a4['repoInfo']['namespace'])&&_0x1d15a4['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x258355['length']!==0x0&&!cd(_0x258355))throw new Error(Nn(_0x2e69f2,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5ef350,_0xfa4db){let _0x418e18=null;for(let _0x1104d3=0x0;_0x1104d3<_0xfa4db['length'];_0x1104d3++){const _0x4db84d=_0xfa4db[_0x1104d3],_0x37a9f0=_0x4db84d['getPath']();_0x418e18!==null&&!qi(_0x37a9f0,_0x418e18['path'])&&(_0x5ef350['eventLists_']['push'](_0x418e18),_0x418e18=null),_0x418e18===null&&(_0x418e18={'events':[],'path':_0x37a9f0}),_0x418e18['events']['push'](_0x4db84d);}_0x418e18&&_0x5ef350['eventLists_']['push'](_0x418e18);}function ia(_0x3272fd,_0x449c08,_0x44c06f){Bn(_0x3272fd,_0x44c06f),sa(_0x3272fd,_0x2b3358=>qi(_0x2b3358,_0x449c08));}function V(_0x374a86,_0xffc482,_0x4ec639){Bn(_0x374a86,_0x4ec639),sa(_0x374a86,_0x5a6479=>$(_0x5a6479,_0xffc482)||$(_0xffc482,_0x5a6479));}function sa(_0x10f00e,_0x4fa76d){_0x10f00e['recursionDepth_']++;let _0x639a85=!0x0;for(let _0x1c54bd=0x0;_0x1c54bd<_0x10f00e['eventLists_']['length'];_0x1c54bd++){const _0x46a567=_0x10f00e['eventLists_'][_0x1c54bd];if(_0x46a567){const _0x4c319f=_0x46a567['path'];_0x4fa76d(_0x4c319f)?(pd(_0x10f00e['eventLists_'][_0x1c54bd]),_0x10f00e['eventLists_'][_0x1c54bd]=null):_0x639a85=!0x1;}}_0x639a85&&(_0x10f00e['eventLists_']=[]),_0x10f00e['recursionDepth_']--;}function pd(_0x132872){for(let _0x3b678d=0x0;_0x3b678d<_0x132872['events']['length'];_0x3b678d++){const _0x25d41f=_0x132872['events'][_0x3b678d];if(_0x25d41f!==null){_0x132872['events'][_0x3b678d]=null;const _0x359441=_0x25d41f['getEventRunner']();Et&&L('event:\x20'+_0x25d41f['toString']()),lt(_0x359441);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x28858c,_0x668a6a,_0x3e0902,_0xa4db62){this['repoInfo_']=_0x28858c,this['forceRestClient_']=_0x668a6a,this['authTokenProvider_']=_0x3e0902,this['appCheckProvider_']=_0xa4db62,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x255f11,_0x5755cb,_0x4e450b){if(_0x255f11['stats_']=Hi(_0x255f11['repoInfo_']),_0x255f11['forceRestClient_']||Yl())_0x255f11['server_']=new fn(_0x255f11['repoInfo_'],(_0xf38cda,_0x57161b,_0x171a04,_0x3cb69a)=>{pr(_0x255f11,_0xf38cda,_0x57161b,_0x171a04,_0x3cb69a);},_0x255f11['authTokenProvider_'],_0x255f11['appCheckProvider_']),setTimeout(()=>_r(_0x255f11,!0x0),0x0);else{if(typeof _0x4e450b<'u'&&_0x4e450b!==null){if(typeof _0x4e450b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4e450b);}catch(_0x3b9271){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3b9271);}}_0x255f11['persistentConnection_']=new ie(_0x255f11['repoInfo_'],_0x5755cb,(_0x6503c0,_0x4703c7,_0x8efebe,_0x3d6bf6)=>{pr(_0x255f11,_0x6503c0,_0x4703c7,_0x8efebe,_0x3d6bf6);},_0x533023=>{_r(_0x255f11,_0x533023);},_0x31e5f4=>{yd(_0x255f11,_0x31e5f4);},_0x255f11['authTokenProvider_'],_0x255f11['appCheckProvider_'],_0x4e450b),_0x255f11['server_']=_0x255f11['persistentConnection_'];}_0x255f11['authTokenProvider_']['addTokenChangeListener'](_0x42f88e=>{_0x255f11['server_']['refreshAuthToken'](_0x42f88e);}),_0x255f11['appCheckProvider_']['addTokenChangeListener'](_0x4d5e24=>{_0x255f11['server_']['refreshAppCheckToken'](_0x4d5e24['token']);}),_0x255f11['statsReporter_']=eh(_0x255f11['repoInfo_'],()=>new eu(_0x255f11['stats_'],_0x255f11['server_'])),_0x255f11['infoData_']=new Yh(),_0x255f11['infoSyncTree_']=new dr({'startListening':(_0x20d704,_0xbe7407,_0x22a26e,_0x26fd23)=>{let _0x496650=[];const _0x1b9b3d=_0x255f11['infoData_']['getNode'](_0x20d704['_path']);return _0x1b9b3d['isEmpty']()||(_0x496650=$t(_0x255f11['infoSyncTree_'],_0x20d704['_path'],_0x1b9b3d),setTimeout(()=>{_0x26fd23('ok');},0x0)),_0x496650;},'stopListening':()=>{}}),ms(_0x255f11,'connected',!0x1),_0x255f11['serverSyncTree_']=new dr({'startListening':(_0x475126,_0x1e1f41,_0x3baee7,_0x1dda76)=>(_0x255f11['server_']['listen'](_0x475126,_0x3baee7,_0x1e1f41,(_0x25d6f2,_0x26886a)=>{const _0x5c80a4=_0x1dda76(_0x25d6f2,_0x26886a);V(_0x255f11['eventQueue_'],_0x475126['_path'],_0x5c80a4);}),[]),'stopListening':(_0x313fa1,_0x47c544)=>{_0x255f11['server_']['unlisten'](_0x313fa1,_0x47c544);}});}function oa(_0x3da206){const _0x3c8520=_0x3da206['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3c8520;}function jt(_0x5d58ba){return ed({'timestamp':oa(_0x5d58ba)});}function pr(_0x260ec8,_0x39f2c2,_0x2e1d22,_0x45bf3c,_0x4a0c16){_0x260ec8['dataUpdateCount']++;const _0x83faa6=new C(_0x39f2c2);_0x2e1d22=_0x260ec8['interceptServerDataCallback_']?_0x260ec8['interceptServerDataCallback_'](_0x39f2c2,_0x2e1d22):_0x2e1d22;let _0xcdf555=[];if(_0x4a0c16){if(_0x45bf3c){const _0x5c3825=ln(_0x2e1d22,_0x5c2f8f=>N(_0x5c2f8f));_0xcdf555=Ku(_0x260ec8['serverSyncTree_'],_0x83faa6,_0x5c3825,_0x4a0c16);}else{const _0x811973=N(_0x2e1d22);_0xcdf555=Yo(_0x260ec8['serverSyncTree_'],_0x83faa6,_0x811973,_0x4a0c16);}}else{if(_0x45bf3c){const _0x30cca3=ln(_0x2e1d22,_0x4a87f6=>N(_0x4a87f6));_0xcdf555=qu(_0x260ec8['serverSyncTree_'],_0x83faa6,_0x30cca3);}else{const _0x35db1f=N(_0x2e1d22);_0xcdf555=$t(_0x260ec8['serverSyncTree_'],_0x83faa6,_0x35db1f);}}let _0x310946=_0x83faa6;_0xcdf555['length']>0x0&&(_0x310946=st(_0x260ec8,_0x83faa6)),V(_0x260ec8['eventQueue_'],_0x310946,_0xcdf555);}function _r(_0x551e1d,_0x1579c0){ms(_0x551e1d,'connected',_0x1579c0),_0x1579c0===!0x1&&wd(_0x551e1d);}function yd(_0x52e96b,_0x72a4ae){x(_0x72a4ae,(_0x39a800,_0x2f4526)=>{ms(_0x52e96b,_0x39a800,_0x2f4526);});}function ms(_0x459fdf,_0x44a60b,_0x1a5c10){const _0x3b3b5a=new C('/.info/'+_0x44a60b),_0x2ce5bf=N(_0x1a5c10);_0x459fdf['infoData_']['updateSnapshot'](_0x3b3b5a,_0x2ce5bf);const _0x5a3b50=$t(_0x459fdf['infoSyncTree_'],_0x3b3b5a,_0x2ce5bf);V(_0x459fdf['eventQueue_'],_0x3b3b5a,_0x5a3b50);}function Vn(_0x57f3c1){return _0x57f3c1['nextWriteId_']++;}function vd(_0x79c56e,_0x38b988,_0x5d988a){const _0x2941d2=Yu(_0x79c56e['serverSyncTree_'],_0x38b988);return _0x2941d2!=null?Promise['resolve'](_0x2941d2):_0x79c56e['server_']['get'](_0x38b988)['then'](_0x588864=>{const _0x2446f4=N(_0x588864)['withIndex'](_0x38b988['_queryParams']['getIndex']());bi(_0x79c56e['serverSyncTree_'],_0x38b988,_0x5d988a,!0x0);let _0x427fbf;if(_0x38b988['_queryParams']['loadsAllData']())_0x427fbf=$t(_0x79c56e['serverSyncTree_'],_0x38b988['_path'],_0x2446f4);else{const _0x5816fa=Mt(_0x79c56e['serverSyncTree_'],_0x38b988);_0x427fbf=Yo(_0x79c56e['serverSyncTree_'],_0x38b988['_path'],_0x2446f4,_0x5816fa);}return V(_0x79c56e['eventQueue_'],_0x38b988['_path'],_0x427fbf),wn(_0x79c56e['serverSyncTree_'],_0x38b988,_0x5d988a,null,!0x0),_0x2446f4;},_0x12e1c1=>(ut(_0x79c56e,'get\x20for\x20query\x20'+O(_0x38b988)+'\x20failed:\x20'+_0x12e1c1),Promise['reject'](new Error(_0x12e1c1))));}function Ed(_0x15302d,_0x30aec2,_0x353521,_0x2ce2e9,_0xd7c2fb){ut(_0x15302d,'set',{'path':_0x30aec2['toString'](),'value':_0x353521,'priority':_0x2ce2e9});const _0x49beeb=jt(_0x15302d),_0x1fafac=N(_0x353521,_0x2ce2e9),_0x15cdd9=xn(_0x15302d['serverSyncTree_'],_0x30aec2),_0x35575c=hs(_0x1fafac,_0x15cdd9,_0x49beeb),_0x4578e7=Vn(_0x15302d),_0x3e50fe=ss(_0x15302d['serverSyncTree_'],_0x30aec2,_0x35575c,_0x4578e7,!0x0);Bn(_0x15302d['eventQueue_'],_0x3e50fe),_0x15302d['server_']['put'](_0x30aec2['toString'](),_0x1fafac['val'](!0x0),(_0x1fda27,_0x240ba9)=>{const _0x31b9d4=_0x1fda27==='ok';_0x31b9d4||U('set\x20at\x20'+_0x30aec2+'\x20failed:\x20'+_0x1fda27);const _0x1528a4=pe(_0x15302d['serverSyncTree_'],_0x4578e7,!_0x31b9d4);V(_0x15302d['eventQueue_'],_0x30aec2,_0x1528a4),Ai(_0x15302d,_0xd7c2fb,_0x1fda27,_0x240ba9);});const _0x27c742=vs(_0x15302d,_0x30aec2);st(_0x15302d,_0x27c742),V(_0x15302d['eventQueue_'],_0x27c742,[]);}function Id(_0x36a052,_0x1b4488,_0x2366bf,_0x1fa232){ut(_0x36a052,'update',{'path':_0x1b4488['toString'](),'value':_0x2366bf});let _0x45f141=!0x0;const _0x571532=jt(_0x36a052),_0x48b355={};if(x(_0x2366bf,(_0x5df2f3,_0x37b2f3)=>{_0x45f141=!0x1,_0x48b355[_0x5df2f3]=Zo(A(_0x1b4488,_0x5df2f3),N(_0x37b2f3),_0x36a052['serverSyncTree_'],_0x571532);}),_0x45f141)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x36a052,_0x1fa232,'ok',void 0x0);else{const _0x15575c=Vn(_0x36a052),_0x19819d=Gu(_0x36a052['serverSyncTree_'],_0x1b4488,_0x48b355,_0x15575c);Bn(_0x36a052['eventQueue_'],_0x19819d),_0x36a052['server_']['merge'](_0x1b4488['toString'](),_0x2366bf,(_0x5b4172,_0x1c5a42)=>{const _0x5f186f=_0x5b4172==='ok';_0x5f186f||U('update\x20at\x20'+_0x1b4488+'\x20failed:\x20'+_0x5b4172);const _0xeb93fc=pe(_0x36a052['serverSyncTree_'],_0x15575c,!_0x5f186f),_0x104062=_0xeb93fc['length']>0x0?st(_0x36a052,_0x1b4488):_0x1b4488;V(_0x36a052['eventQueue_'],_0x104062,_0xeb93fc),Ai(_0x36a052,_0x1fa232,_0x5b4172,_0x1c5a42);}),x(_0x2366bf,_0x141185=>{const _0x39f792=vs(_0x36a052,A(_0x1b4488,_0x141185));st(_0x36a052,_0x39f792);}),V(_0x36a052['eventQueue_'],_0x1b4488,[]);}}function wd(_0x40fb6d){ut(_0x40fb6d,'onDisconnectEvents');const _0x4825bd=jt(_0x40fb6d),_0x871d4a=pn();Ei(_0x40fb6d['onDisconnect_'],w(),(_0x22f41d,_0x4d103e)=>{const _0x553b07=Zo(_0x22f41d,_0x4d103e,_0x40fb6d['serverSyncTree_'],_0x4825bd);Mo(_0x871d4a,_0x22f41d,_0x553b07);});let _0x58228f=[];Ei(_0x871d4a,w(),(_0xf1c93f,_0x592bb5)=>{_0x58228f=_0x58228f['concat']($t(_0x40fb6d['serverSyncTree_'],_0xf1c93f,_0x592bb5));const _0x58568b=vs(_0x40fb6d,_0xf1c93f);st(_0x40fb6d,_0x58568b);}),_0x40fb6d['onDisconnect_']=pn(),V(_0x40fb6d['eventQueue_'],w(),_0x58228f);}function Cd(_0x1e8d45,_0x440078,_0x2a0607){let _0x4da91c;y(_0x440078['_path'])==='.info'?_0x4da91c=bi(_0x1e8d45['infoSyncTree_'],_0x440078,_0x2a0607):_0x4da91c=bi(_0x1e8d45['serverSyncTree_'],_0x440078,_0x2a0607),ia(_0x1e8d45['eventQueue_'],_0x440078['_path'],_0x4da91c);}function Td(_0x13d499,_0x357e87,_0x4fb63b){let _0x329e46;y(_0x357e87['_path'])==='.info'?_0x329e46=wn(_0x13d499['infoSyncTree_'],_0x357e87,_0x4fb63b):_0x329e46=wn(_0x13d499['serverSyncTree_'],_0x357e87,_0x4fb63b),ia(_0x13d499['eventQueue_'],_0x357e87['_path'],_0x329e46);}function aa(_0x41b63d){_0x41b63d['persistentConnection_']&&_0x41b63d['persistentConnection_']['interrupt'](ra);}function Sd(_0x46cb29){_0x46cb29['persistentConnection_']&&_0x46cb29['persistentConnection_']['resume'](ra);}function ut(_0xba249e,..._0x4abaed){let _0x4a66e0='';_0xba249e['persistentConnection_']&&(_0x4a66e0=_0xba249e['persistentConnection_']['id']+':'),L(_0x4a66e0,..._0x4abaed);}function Ai(_0x154721,_0x55186a,_0x1e91ca,_0x3702d3){_0x55186a&&lt(()=>{if(_0x1e91ca==='ok')_0x55186a(null);else{const _0x380cb4=(_0x1e91ca||'error')['toUpperCase']();let _0x2c0b8f=_0x380cb4;_0x3702d3&&(_0x2c0b8f+=':\x20'+_0x3702d3);const _0x24057b=new Error(_0x2c0b8f);_0x24057b['code']=_0x380cb4,_0x55186a(_0x24057b);}});}function bd(_0x3451e5,_0x5588c3,_0xa7426f,_0x92196d,_0x396b3b,_0x29a61d){ut(_0x3451e5,'transaction\x20on\x20'+_0x5588c3);const _0x34a37d={'path':_0x5588c3,'update':_0xa7426f,'onComplete':_0x92196d,'status':null,'order':to(),'applyLocally':_0x29a61d,'retryCount':0x0,'unwatcher':_0x396b3b,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3b30e9=ys(_0x3451e5,_0x5588c3,void 0x0);_0x34a37d['currentInputSnapshot']=_0x3b30e9;const _0x5ca3f9=_0x34a37d['update'](_0x3b30e9['val']());if(_0x5ca3f9===void 0x0)_0x34a37d['unwatcher'](),_0x34a37d['currentOutputSnapshotRaw']=null,_0x34a37d['currentOutputSnapshotResolved']=null,_0x34a37d['onComplete']&&_0x34a37d['onComplete'](null,!0x1,_0x34a37d['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5ca3f9,_0x34a37d['path']),_0x34a37d['status']=0x0;const _0x4b4ef7=Un(_0x3451e5['transactionQueueTree_'],_0x5588c3),_0x51e91c=Ge(_0x4b4ef7)||[];_0x51e91c['push'](_0x34a37d),fs(_0x4b4ef7,_0x51e91c);let _0x2da837;typeof _0x5ca3f9=='object'&&_0x5ca3f9!==null&&Y(_0x5ca3f9,'.priority')?(_0x2da837=Oe(_0x5ca3f9,'.priority'),f(Cn(_0x2da837),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2da837=(xn(_0x3451e5['serverSyncTree_'],_0x5588c3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1ef8cb=jt(_0x3451e5),_0x2204b5=N(_0x5ca3f9,_0x2da837),_0x403f29=hs(_0x2204b5,_0x3b30e9,_0x1ef8cb);_0x34a37d['currentOutputSnapshotRaw']=_0x2204b5,_0x34a37d['currentOutputSnapshotResolved']=_0x403f29,_0x34a37d['currentWriteId']=Vn(_0x3451e5);const _0x4160b7=ss(_0x3451e5['serverSyncTree_'],_0x5588c3,_0x403f29,_0x34a37d['currentWriteId'],_0x34a37d['applyLocally']);V(_0x3451e5['eventQueue_'],_0x5588c3,_0x4160b7),Hn(_0x3451e5,_0x3451e5['transactionQueueTree_']);}}function ys(_0x3c57f5,_0x1fa49f,_0x3770bc){return xn(_0x3c57f5['serverSyncTree_'],_0x1fa49f,_0x3770bc)||g['EMPTY_NODE'];}function Hn(_0x3741cc,_0x3da66d=_0x3741cc['transactionQueueTree_']){if(_0x3da66d||$n(_0x3741cc,_0x3da66d),Ge(_0x3da66d)){const _0x2c2f05=la(_0x3741cc,_0x3da66d);f(_0x2c2f05['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2c2f05['every'](_0x2c1bd1=>_0x2c1bd1['status']===0x0)&&Rd(_0x3741cc,Gt(_0x3da66d),_0x2c2f05);}else ea(_0x3da66d)&&Wn(_0x3da66d,_0x2a45d9=>{Hn(_0x3741cc,_0x2a45d9);});}function Rd(_0x139a78,_0x139d7e,_0x1d1221){const _0x3a8d15=_0x1d1221['map'](_0x3543c0=>_0x3543c0['currentWriteId']),_0x3fabc2=ys(_0x139a78,_0x139d7e,_0x3a8d15);let _0x1a5fec=_0x3fabc2;const _0x308bd6=_0x3fabc2['hash']();for(let _0x1b5a1e=0x0;_0x1b5a1e<_0x1d1221['length'];_0x1b5a1e++){const _0x4cb47b=_0x1d1221[_0x1b5a1e];f(_0x4cb47b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4cb47b['status']=0x1,_0x4cb47b['retryCount']++;const _0x372128=F(_0x139d7e,_0x4cb47b['path']);_0x1a5fec=_0x1a5fec['updateChild'](_0x372128,_0x4cb47b['currentOutputSnapshotRaw']);}const _0x1c02f5=_0x1a5fec['val'](!0x0),_0x8a8dcd=_0x139d7e;_0x139a78['server_']['put'](_0x8a8dcd['toString'](),_0x1c02f5,_0x200b37=>{ut(_0x139a78,'transaction\x20put\x20response',{'path':_0x8a8dcd['toString'](),'status':_0x200b37});let _0x2a6d34=[];if(_0x200b37==='ok'){const _0x2b5dcf=[];for(let _0x2ca6c9=0x0;_0x2ca6c9<_0x1d1221['length'];_0x2ca6c9++)_0x1d1221[_0x2ca6c9]['status']=0x2,_0x2a6d34=_0x2a6d34['concat'](pe(_0x139a78['serverSyncTree_'],_0x1d1221[_0x2ca6c9]['currentWriteId'])),_0x1d1221[_0x2ca6c9]['onComplete']&&_0x2b5dcf['push'](()=>_0x1d1221[_0x2ca6c9]['onComplete'](null,!0x0,_0x1d1221[_0x2ca6c9]['currentOutputSnapshotResolved'])),_0x1d1221[_0x2ca6c9]['unwatcher']();$n(_0x139a78,Un(_0x139a78['transactionQueueTree_'],_0x139d7e)),Hn(_0x139a78,_0x139a78['transactionQueueTree_']),V(_0x139a78['eventQueue_'],_0x139d7e,_0x2a6d34);for(let _0x8a1158=0x0;_0x8a1158<_0x2b5dcf['length'];_0x8a1158++)lt(_0x2b5dcf[_0x8a1158]);}else{if(_0x200b37==='datastale'){for(let _0xb2fc86=0x0;_0xb2fc86<_0x1d1221['length'];_0xb2fc86++)_0x1d1221[_0xb2fc86]['status']===0x3?_0x1d1221[_0xb2fc86]['status']=0x4:_0x1d1221[_0xb2fc86]['status']=0x0;}else{U('transaction\x20at\x20'+_0x8a8dcd['toString']()+'\x20failed:\x20'+_0x200b37);for(let _0x19a947=0x0;_0x19a947<_0x1d1221['length'];_0x19a947++)_0x1d1221[_0x19a947]['status']=0x4,_0x1d1221[_0x19a947]['abortReason']=_0x200b37;}st(_0x139a78,_0x139d7e);}},_0x308bd6);}function st(_0x43ce04,_0x5365a9){const _0x4403a2=ca(_0x43ce04,_0x5365a9),_0x4059cb=Gt(_0x4403a2),_0x5dfc1e=la(_0x43ce04,_0x4403a2);return Ad(_0x43ce04,_0x5dfc1e,_0x4059cb),_0x4059cb;}function Ad(_0x3d8732,_0x5c7c17,_0x3c7f03){if(_0x5c7c17['length']===0x0)return;const _0x5a1fde=[];let _0x4d283e=[];const _0x4d93b1=_0x5c7c17['filter'](_0x1b6788=>_0x1b6788['status']===0x0)['map'](_0x808047=>_0x808047['currentWriteId']);for(let _0x44a112=0x0;_0x44a112<_0x5c7c17['length'];_0x44a112++){const _0x463a51=_0x5c7c17[_0x44a112],_0x5300be=F(_0x3c7f03,_0x463a51['path']);let _0x1009bf=!0x1,_0x1bef49;if(f(_0x5300be!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x463a51['status']===0x4)_0x1009bf=!0x0,_0x1bef49=_0x463a51['abortReason'],_0x4d283e=_0x4d283e['concat'](pe(_0x3d8732['serverSyncTree_'],_0x463a51['currentWriteId'],!0x0));else{if(_0x463a51['status']===0x0){if(_0x463a51['retryCount']>=_d)_0x1009bf=!0x0,_0x1bef49='maxretry',_0x4d283e=_0x4d283e['concat'](pe(_0x3d8732['serverSyncTree_'],_0x463a51['currentWriteId'],!0x0));else{const _0x415c6c=ys(_0x3d8732,_0x463a51['path'],_0x4d93b1);_0x463a51['currentInputSnapshot']=_0x415c6c;const _0xd379c=_0x5c7c17[_0x44a112]['update'](_0x415c6c['val']());if(_0xd379c!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xd379c,_0x463a51['path']);let _0x41566c=N(_0xd379c);typeof _0xd379c=='object'&&_0xd379c!=null&&Y(_0xd379c,'.priority')||(_0x41566c=_0x41566c['updatePriority'](_0x415c6c['getPriority']()));const _0x4b2305=_0x463a51['currentWriteId'],_0x222287=jt(_0x3d8732),_0xdadab=hs(_0x41566c,_0x415c6c,_0x222287);_0x463a51['currentOutputSnapshotRaw']=_0x41566c,_0x463a51['currentOutputSnapshotResolved']=_0xdadab,_0x463a51['currentWriteId']=Vn(_0x3d8732),_0x4d93b1['splice'](_0x4d93b1['indexOf'](_0x4b2305),0x1),_0x4d283e=_0x4d283e['concat'](ss(_0x3d8732['serverSyncTree_'],_0x463a51['path'],_0xdadab,_0x463a51['currentWriteId'],_0x463a51['applyLocally'])),_0x4d283e=_0x4d283e['concat'](pe(_0x3d8732['serverSyncTree_'],_0x4b2305,!0x0));}else _0x1009bf=!0x0,_0x1bef49='nodata',_0x4d283e=_0x4d283e['concat'](pe(_0x3d8732['serverSyncTree_'],_0x463a51['currentWriteId'],!0x0));}}}V(_0x3d8732['eventQueue_'],_0x3c7f03,_0x4d283e),_0x4d283e=[],_0x1009bf&&(_0x5c7c17[_0x44a112]['status']=0x2,function(_0x1e2dee){setTimeout(_0x1e2dee,Math['floor'](0x0));}(_0x5c7c17[_0x44a112]['unwatcher']),_0x5c7c17[_0x44a112]['onComplete']&&(_0x1bef49==='nodata'?_0x5a1fde['push'](()=>_0x5c7c17[_0x44a112]['onComplete'](null,!0x1,_0x5c7c17[_0x44a112]['currentInputSnapshot'])):_0x5a1fde['push'](()=>_0x5c7c17[_0x44a112]['onComplete'](new Error(_0x1bef49),!0x1,null))));}$n(_0x3d8732,_0x3d8732['transactionQueueTree_']);for(let _0xc1f0ea=0x0;_0xc1f0ea<_0x5a1fde['length'];_0xc1f0ea++)lt(_0x5a1fde[_0xc1f0ea]);Hn(_0x3d8732,_0x3d8732['transactionQueueTree_']);}function ca(_0x22be02,_0x8f12ca){let _0x29a2c3,_0x5ea9e8=_0x22be02['transactionQueueTree_'];for(_0x29a2c3=y(_0x8f12ca);_0x29a2c3!==null&&Ge(_0x5ea9e8)===void 0x0;)_0x5ea9e8=Un(_0x5ea9e8,_0x29a2c3),_0x8f12ca=b(_0x8f12ca),_0x29a2c3=y(_0x8f12ca);return _0x5ea9e8;}function la(_0x38ee79,_0x119070){const _0x2491af=[];return ha(_0x38ee79,_0x119070,_0x2491af),_0x2491af['sort']((_0x222d91,_0x442072)=>_0x222d91['order']-_0x442072['order']),_0x2491af;}function ha(_0xd2e47c,_0x5531fb,_0x3cd377){const _0x150f0b=Ge(_0x5531fb);if(_0x150f0b){for(let _0x44eca8=0x0;_0x44eca8<_0x150f0b['length'];_0x44eca8++)_0x3cd377['push'](_0x150f0b[_0x44eca8]);}Wn(_0x5531fb,_0xdf2ca6=>{ha(_0xd2e47c,_0xdf2ca6,_0x3cd377);});}function $n(_0x535bab,_0x2eab63){const _0xa52b67=Ge(_0x2eab63);if(_0xa52b67){let _0x188ec9=0x0;for(let _0x54bd7f=0x0;_0x54bd7f<_0xa52b67['length'];_0x54bd7f++)_0xa52b67[_0x54bd7f]['status']!==0x2&&(_0xa52b67[_0x188ec9]=_0xa52b67[_0x54bd7f],_0x188ec9++);_0xa52b67['length']=_0x188ec9,fs(_0x2eab63,_0xa52b67['length']>0x0?_0xa52b67:void 0x0);}Wn(_0x2eab63,_0x34ce73=>{$n(_0x535bab,_0x34ce73);});}function vs(_0x497a9b,_0x503867){const _0x2f62d0=Gt(ca(_0x497a9b,_0x503867)),_0x3cc120=Un(_0x497a9b['transactionQueueTree_'],_0x503867);return sd(_0x3cc120,_0x12af46=>{ai(_0x497a9b,_0x12af46);}),ai(_0x497a9b,_0x3cc120),ta(_0x3cc120,_0x1627be=>{ai(_0x497a9b,_0x1627be);}),_0x2f62d0;}function ai(_0x392508,_0x837390){const _0x3e6806=Ge(_0x837390);if(_0x3e6806){const _0x7ef1bd=[];let _0x58adf0=[],_0x231efb=-0x1;for(let _0xdd91e9=0x0;_0xdd91e9<_0x3e6806['length'];_0xdd91e9++)_0x3e6806[_0xdd91e9]['status']===0x3||(_0x3e6806[_0xdd91e9]['status']===0x1?(f(_0x231efb===_0xdd91e9-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x231efb=_0xdd91e9,_0x3e6806[_0xdd91e9]['status']=0x3,_0x3e6806[_0xdd91e9]['abortReason']='set'):(f(_0x3e6806[_0xdd91e9]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3e6806[_0xdd91e9]['unwatcher'](),_0x58adf0=_0x58adf0['concat'](pe(_0x392508['serverSyncTree_'],_0x3e6806[_0xdd91e9]['currentWriteId'],!0x0)),_0x3e6806[_0xdd91e9]['onComplete']&&_0x7ef1bd['push'](_0x3e6806[_0xdd91e9]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x231efb===-0x1?fs(_0x837390,void 0x0):_0x3e6806['length']=_0x231efb+0x1,V(_0x392508['eventQueue_'],Gt(_0x837390),_0x58adf0);for(let _0x5a5dc2=0x0;_0x5a5dc2<_0x7ef1bd['length'];_0x5a5dc2++)lt(_0x7ef1bd[_0x5a5dc2]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x38a4ed){let _0x8985cf='';const _0x546893=_0x38a4ed['split']('/');for(let _0x5b27ef=0x0;_0x5b27ef<_0x546893['length'];_0x5b27ef++)if(_0x546893[_0x5b27ef]['length']>0x0){let _0x128085=_0x546893[_0x5b27ef];try{_0x128085=decodeURIComponent(_0x128085['replace'](/\+/g,'\x20'));}catch{}_0x8985cf+='/'+_0x128085;}return _0x8985cf;}function Nd(_0x2b27de){const _0x4fa45b={};_0x2b27de['charAt'](0x0)==='?'&&(_0x2b27de=_0x2b27de['substring'](0x1));for(const _0x127fca of _0x2b27de['split']('&')){if(_0x127fca['length']===0x0)continue;const _0x21eebb=_0x127fca['split']('=');_0x21eebb['length']===0x2?_0x4fa45b[decodeURIComponent(_0x21eebb[0x0])]=decodeURIComponent(_0x21eebb[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x127fca+'\x27\x20in\x20query\x20\x27'+_0x2b27de+'\x27');}return _0x4fa45b;}const gr=function(_0x4fbaa4,_0x4f63bc){const _0x3e78b7=Pd(_0x4fbaa4),_0x475af5=_0x3e78b7['namespace'];_0x3e78b7['domain']==='firebase.com'&&oe(_0x3e78b7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x475af5||_0x475af5==='undefined')&&_0x3e78b7['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3e78b7['secure']||Bl();const _0x5934d8=_0x3e78b7['scheme']==='ws'||_0x3e78b7['scheme']==='wss';return{'repoInfo':new _o(_0x3e78b7['host'],_0x3e78b7['secure'],_0x475af5,_0x5934d8,_0x4f63bc,'',_0x475af5!==_0x3e78b7['subdomain']),'path':new C(_0x3e78b7['pathString'])};},Pd=function(_0x501bad){let _0x8def33='',_0x22b284='',_0xc00c7b='',_0x3be9c1='',_0x56ed2e='',_0x2218d7=!0x0,_0x56f58a='https',_0xd68bdc=0x1bb;if(typeof _0x501bad=='string'){let _0x334468=_0x501bad['indexOf']('//');_0x334468>=0x0&&(_0x56f58a=_0x501bad['substring'](0x0,_0x334468-0x1),_0x501bad=_0x501bad['substring'](_0x334468+0x2));let _0x1424af=_0x501bad['indexOf']('/');_0x1424af===-0x1&&(_0x1424af=_0x501bad['length']);let _0x42c17b=_0x501bad['indexOf']('?');_0x42c17b===-0x1&&(_0x42c17b=_0x501bad['length']),_0x8def33=_0x501bad['substring'](0x0,Math['min'](_0x1424af,_0x42c17b)),_0x1424af<_0x42c17b&&(_0x3be9c1=kd(_0x501bad['substring'](_0x1424af,_0x42c17b)));const _0x760838=Nd(_0x501bad['substring'](Math['min'](_0x501bad['length'],_0x42c17b)));_0x334468=_0x8def33['indexOf'](':'),_0x334468>=0x0?(_0x2218d7=_0x56f58a==='https'||_0x56f58a==='wss',_0xd68bdc=parseInt(_0x8def33['substring'](_0x334468+0x1),0xa)):_0x334468=_0x8def33['length'];const _0x4c97d8=_0x8def33['slice'](0x0,_0x334468);if(_0x4c97d8['toLowerCase']()==='localhost')_0x22b284='localhost';else{if(_0x4c97d8['split']('.')['length']<=0x2)_0x22b284=_0x4c97d8;else{const _0x33dd42=_0x8def33['indexOf']('.');_0xc00c7b=_0x8def33['substring'](0x0,_0x33dd42)['toLowerCase'](),_0x22b284=_0x8def33['substring'](_0x33dd42+0x1),_0x56ed2e=_0xc00c7b;}}'ns'in _0x760838&&(_0x56ed2e=_0x760838['ns']);}return{'host':_0x8def33,'port':_0xd68bdc,'domain':_0x22b284,'subdomain':_0xc00c7b,'secure':_0x2218d7,'scheme':_0x56f58a,'pathString':_0x3be9c1,'namespace':_0x56ed2e};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x454a9a=0x0;const _0x2a8195=[];return function(_0x42cdf4){const _0x569a49=_0x42cdf4===_0x454a9a;_0x454a9a=_0x42cdf4;let _0xd274f6;const _0x4811fd=new Array(0x8);for(_0xd274f6=0x7;_0xd274f6>=0x0;_0xd274f6--)_0x4811fd[_0xd274f6]=mr['charAt'](_0x42cdf4%0x40),_0x42cdf4=Math['floor'](_0x42cdf4/0x40);f(_0x42cdf4===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x363f62=_0x4811fd['join']('');if(_0x569a49){for(_0xd274f6=0xb;_0xd274f6>=0x0&&_0x2a8195[_0xd274f6]===0x3f;_0xd274f6--)_0x2a8195[_0xd274f6]=0x0;_0x2a8195[_0xd274f6]++;}else{for(_0xd274f6=0x0;_0xd274f6<0xc;_0xd274f6++)_0x2a8195[_0xd274f6]=Math['floor'](Math['random']()*0x40);}for(_0xd274f6=0x0;_0xd274f6<0xc;_0xd274f6++)_0x363f62+=mr['charAt'](_0x2a8195[_0xd274f6]);return f(_0x363f62['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x363f62;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x31e4b0,_0x286f8b,_0x4a57e4,_0x276c40){this['eventType']=_0x31e4b0,this['eventRegistration']=_0x286f8b,this['snapshot']=_0x4a57e4,this['prevName']=_0x276c40;}['getPath'](){const _0x4669b8=this['snapshot']['ref'];return this['eventType']==='value'?_0x4669b8['_path']:_0x4669b8['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1a2d02,_0x2430de,_0x11ba70){this['eventRegistration']=_0x1a2d02,this['error']=_0x2430de,this['path']=_0x11ba70;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x349dcd,_0x460eda){this['snapshotCallback']=_0x349dcd,this['cancelCallback']=_0x460eda;}['onValue'](_0x2a3bce,_0x2a470c){this['snapshotCallback']['call'](null,_0x2a3bce,_0x2a470c);}['onCancel'](_0x13ba92){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x13ba92);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1ffcd8){return this['snapshotCallback']===_0x1ffcd8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1ffcd8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1ffcd8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3bc4e2,_0x366069,_0x321278,_0x1418a3){this['_repo']=_0x3bc4e2,this['_path']=_0x366069,this['_queryParams']=_0x321278,this['_orderByCalled']=_0x1418a3;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1f35c1=nr(this['_queryParams']),_0x157aa2=Bi(_0x1f35c1);return _0x157aa2==='{}'?'default':_0x157aa2;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4ca0d6){if(_0x4ca0d6=k(_0x4ca0d6),!(_0x4ca0d6 instanceof be))return!0x1;const _0x541ead=this['_repo']===_0x4ca0d6['_repo'],_0x3358cf=qi(this['_path'],_0x4ca0d6['_path']),_0xbf26f1=this['_queryIdentifier']===_0x4ca0d6['_queryIdentifier'];return _0x541ead&&_0x3358cf&&_0xbf26f1;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x3b0b39,_0x2a5455){if(_0x3b0b39['_orderByCalled']===!0x0)throw new Error(_0x2a5455+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x487ade){let _0xf406a6=null,_0x860877=null;if(_0x487ade['hasStart']()&&(_0xf406a6=_0x487ade['getIndexStartValue']()),_0x487ade['hasEnd']()&&(_0x860877=_0x487ade['getIndexEndValue']()),_0x487ade['getIndex']()===ye){const _0x1085ed='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x53115f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x487ade['hasStart']()){if(_0x487ade['getIndexStartName']()!==xe)throw new Error(_0x1085ed);if(typeof _0xf406a6!='string')throw new Error(_0x53115f);}if(_0x487ade['hasEnd']()){if(_0x487ade['getIndexEndName']()!==Ie)throw new Error(_0x1085ed);if(typeof _0x860877!='string')throw new Error(_0x53115f);}}else{if(_0x487ade['getIndex']()===R){if(_0xf406a6!=null&&!Cn(_0xf406a6)||_0x860877!=null&&!Cn(_0x860877))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x487ade['getIndex']()instanceof Ki||_0x487ade['getIndex']()===Po,'unknown\x20index\x20type.'),_0xf406a6!=null&&typeof _0xf406a6=='object'||_0x860877!=null&&typeof _0x860877=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x9919ac){if(_0x9919ac['hasStart']()&&_0x9919ac['hasEnd']()&&_0x9919ac['hasLimit']()&&!_0x9919ac['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x251e33,_0x4b914f){super(_0x251e33,_0x4b914f,new Qi(),!0x1);}get['parent'](){const _0x32780d=To(this['_path']);return _0x32780d===null?null:new Z(this['_repo'],_0x32780d);}get['root'](){let _0xa79d0=this;for(;_0xa79d0['parent']!==null;)_0xa79d0=_0xa79d0['parent'];return _0xa79d0;}}class rt{constructor(_0x1aea79,_0x57ae59,_0x4f9055){this['_node']=_0x1aea79,this['ref']=_0x57ae59,this['_index']=_0x4f9055;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3a9df7){const _0x2fbb83=new C(_0x3a9df7),_0x3f0c6b=Lt(this['ref'],_0x3a9df7);return new rt(this['_node']['getChild'](_0x2fbb83),_0x3f0c6b,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x3b5237){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x33bb87,_0x625173)=>_0x3b5237(new rt(_0x625173,Lt(this['ref'],_0x33bb87),R)));}['hasChild'](_0x916d53){const _0x3513ee=new C(_0x916d53);return!this['_node']['getChild'](_0x3513ee)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x2e899b,_0x1a75e0){return _0x2e899b=k(_0x2e899b),_0x2e899b['_checkNotDeleted']('ref'),_0x1a75e0!==void 0x0?Lt(_0x2e899b['_root'],_0x1a75e0):_0x2e899b['_root'];}function Lt(_0x2051db,_0x42cc37){return _0x2051db=k(_0x2051db),y(_0x2051db['_path'])===null?ud('child','path',_0x42cc37):_s('child','path',_0x42cc37),new Z(_0x2051db['_repo'],A(_0x2051db['_path'],_0x42cc37));}function d_(_0x5e7757,_0x48241a){_0x5e7757=k(_0x5e7757),gs('push',_0x5e7757['_path']),qt('push',_0x48241a,_0x5e7757['_path'],!0x0);const _0x1ce293=oa(_0x5e7757['_repo']),_0x45166b=Od(_0x1ce293),_0x577f32=Lt(_0x5e7757,_0x45166b),_0xe1ddd0=Lt(_0x5e7757,_0x45166b);let _0x5c0405;return _0x48241a!=null?_0x5c0405=Ld(_0xe1ddd0,_0x48241a)['then'](()=>_0xe1ddd0):_0x5c0405=Promise['resolve'](_0xe1ddd0),_0x577f32['then']=_0x5c0405['then']['bind'](_0x5c0405),_0x577f32['catch']=_0x5c0405['then']['bind'](_0x5c0405,void 0x0),_0x577f32;}function Ld(_0x1dbaa7,_0x4dc9df){_0x1dbaa7=k(_0x1dbaa7),gs('set',_0x1dbaa7['_path']),qt('set',_0x4dc9df,_0x1dbaa7['_path'],!0x1);const _0xab4362=new Ve();return Ed(_0x1dbaa7['_repo'],_0x1dbaa7['_path'],_0x4dc9df,null,_0xab4362['wrapCallback'](()=>{})),_0xab4362['promise'];}function f_(_0x960b65,_0x1ce25b){hd('update',_0x1ce25b,_0x960b65['_path']);const _0x167164=new Ve();return Id(_0x960b65['_repo'],_0x960b65['_path'],_0x1ce25b,_0x167164['wrapCallback'](()=>{})),_0x167164['promise'];}function p_(_0x5821a7){_0x5821a7=k(_0x5821a7);const _0x4a47ab=new ua(()=>{}),_0x36307e=new qn(_0x4a47ab);return vd(_0x5821a7['_repo'],_0x5821a7,_0x36307e)['then'](_0x4ccfda=>new rt(_0x4ccfda,new Z(_0x5821a7['_repo'],_0x5821a7['_path']),_0x5821a7['_queryParams']['getIndex']()));}class qn{constructor(_0x32758b){this['callbackContext']=_0x32758b;}['respondsTo'](_0x32ec3e){return _0x32ec3e==='value';}['createEvent'](_0x53d736,_0x100b3d){const _0x4e0898=_0x100b3d['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x53d736['snapshotNode'],new Z(_0x100b3d['_repo'],_0x100b3d['_path']),_0x4e0898));}['getEventRunner'](_0x3d27b8){return _0x3d27b8['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3d27b8['error']):()=>this['callbackContext']['onValue'](_0x3d27b8['snapshot'],null);}['createCancelEvent'](_0x54b3c3,_0x280de5){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x54b3c3,_0x280de5):null;}['matches'](_0x37484d){return _0x37484d instanceof qn?!_0x37484d['callbackContext']||!this['callbackContext']?!0x0:_0x37484d['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x1b12d4,_0x3d4fdb,_0x106b29,_0x190085,_0x5e67ad){const _0x14faa5=new ua(_0x106b29,void 0x0),_0x531707=new qn(_0x14faa5);return Cd(_0x1b12d4['_repo'],_0x1b12d4,_0x531707),()=>Td(_0x1b12d4['_repo'],_0x1b12d4,_0x531707);}function Fd(_0x3bccb8,_0x1f074a,_0x117bd5,_0xa9fe84){return xd(_0x3bccb8,'value',_0x1f074a);}class dt{}class pa extends dt{constructor(_0x1f9a9c,_0x2f8944){super(),this['_value']=_0x1f9a9c,this['_key']=_0x2f8944,this['type']='endAt';}['_apply'](_0x429a54){qt('endAt',this['_value'],_0x429a54['_path'],!0x0);const _0x17917b=Kh(_0x429a54['_queryParams'],this['_value'],this['_key']);if(fa(_0x17917b),Gn(_0x17917b),_0x429a54['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x429a54['_repo'],_0x429a54['_path'],_0x17917b,_0x429a54['_orderByCalled']);}}function __(_0x49413f,_0x2a2060){return new pa(_0x49413f,_0x2a2060);}class _a extends dt{constructor(_0xfbd862,_0x128aa1){super(),this['_value']=_0xfbd862,this['_key']=_0x128aa1,this['type']='startAt';}['_apply'](_0x46b38d){qt('startAt',this['_value'],_0x46b38d['_path'],!0x0);const _0x1ddd34=jh(_0x46b38d['_queryParams'],this['_value'],this['_key']);if(fa(_0x1ddd34),Gn(_0x1ddd34),_0x46b38d['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x46b38d['_repo'],_0x46b38d['_path'],_0x1ddd34,_0x46b38d['_orderByCalled']);}}function g_(_0x525c71=null,_0x30d14b){return new _a(_0x525c71,_0x30d14b);}class Ud extends dt{constructor(_0x461a8c){super(),this['_limit']=_0x461a8c,this['type']='limitToFirst';}['_apply'](_0x53eef8){if(_0x53eef8['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x53eef8['_repo'],_0x53eef8['_path'],zh(_0x53eef8['_queryParams'],this['_limit']),_0x53eef8['_orderByCalled']);}}function m_(_0x192219){if(Math['floor'](_0x192219)!==_0x192219||_0x192219<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x192219);}class Wd extends dt{constructor(_0x1c5da7){super(),this['_path']=_0x1c5da7,this['type']='orderByChild';}['_apply'](_0x1b04d8){da(_0x1b04d8,'orderByChild');const _0x299867=new C(this['_path']);if(v(_0x299867))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2175f1=new Ki(_0x299867),_0x58c38c=Do(_0x1b04d8['_queryParams'],_0x2175f1);return Gn(_0x58c38c),new be(_0x1b04d8['_repo'],_0x1b04d8['_path'],_0x58c38c,!0x0);}}function y_(_0x52cfda){if(_0x52cfda==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x52cfda==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x52cfda==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x52cfda),new Wd(_0x52cfda);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1a846d){da(_0x1a846d,'orderByKey');const _0x4b436b=Do(_0x1a846d['_queryParams'],ye);return Gn(_0x4b436b),new be(_0x1a846d['_repo'],_0x1a846d['_path'],_0x4b436b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x497425,_0x490d5b){super(),this['_value']=_0x497425,this['_key']=_0x490d5b,this['type']='equalTo';}['_apply'](_0x2ab143){if(qt('equalTo',this['_value'],_0x2ab143['_path'],!0x1),_0x2ab143['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2ab143['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2ab143));}}function E_(_0x334197,_0x3545b){return new Vd(_0x334197,_0x3545b);}function I_(_0x238e63,..._0x14320a){let _0x386af3=k(_0x238e63);for(const _0x3110f3 of _0x14320a)_0x386af3=_0x3110f3['_apply'](_0x386af3);return _0x386af3;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3ee74f,_0x544c33,_0x34d15a,_0x200bef){const _0x37e352=_0x544c33['lastIndexOf'](':'),_0x330f91=_0x544c33['substring'](0x0,_0x37e352),_0x4f18f2=Wt(_0x330f91);_0x3ee74f['repoInfo_']=new _o(_0x544c33,_0x4f18f2,_0x3ee74f['repoInfo_']['namespace'],_0x3ee74f['repoInfo_']['webSocketOnly'],_0x3ee74f['repoInfo_']['nodeAdmin'],_0x3ee74f['repoInfo_']['persistenceKey'],_0x3ee74f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x34d15a),_0x200bef&&(_0x3ee74f['authTokenProvider_']=_0x200bef);}function qd(_0x3d91af,_0x2a28d8,_0x47a4fc,_0x57b707,_0x148259){let _0x130396=_0x57b707||_0x3d91af['options']['databaseURL'];_0x130396===void 0x0&&(_0x3d91af['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3d91af['options']['projectId']),_0x130396=_0x3d91af['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4765f9=gr(_0x130396,_0x148259),_0x434b4b=_0x4765f9['repoInfo'],_0x398f2d;typeof process<'u'&&Us&&(_0x398f2d=Us[Hd]),_0x398f2d?(_0x130396='http://'+_0x398f2d+'?ns='+_0x434b4b['namespace'],_0x4765f9=gr(_0x130396,_0x148259),_0x434b4b=_0x4765f9['repoInfo']):_0x4765f9['repoInfo']['secure'];const _0x1447bb=new Jl(_0x3d91af['name'],_0x3d91af['options'],_0x2a28d8);dd('Invalid\x20Firebase\x20Database\x20URL',_0x4765f9),v(_0x4765f9['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x409b64=jd(_0x434b4b,_0x3d91af,_0x1447bb,new Ql(_0x3d91af,_0x47a4fc));return new Kd(_0x409b64,_0x3d91af);}function zd(_0x4bda64,_0x21de8a){const _0xe207d1=ki[_0x21de8a];(!_0xe207d1||_0xe207d1[_0x4bda64['key']]!==_0x4bda64)&&oe('Database\x20'+_0x21de8a+'('+_0x4bda64['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4bda64),delete _0xe207d1[_0x4bda64['key']];}function jd(_0x49e899,_0x17e3fa,_0x2cc564,_0x4304c8){let _0x3834fc=ki[_0x17e3fa['name']];_0x3834fc||(_0x3834fc={},ki[_0x17e3fa['name']]=_0x3834fc);let _0x5ead81=_0x3834fc[_0x49e899['toURLString']()];return _0x5ead81&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x5ead81=new gd(_0x49e899,$d,_0x2cc564,_0x4304c8),_0x3834fc[_0x49e899['toURLString']()]=_0x5ead81,_0x5ead81;}class Kd{constructor(_0xe845b9,_0x18aad9){this['_repoInternal']=_0xe845b9,this['app']=_0x18aad9,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5596e1){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5596e1+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1165a9=Qr(),_0x4c6b27){const _0x523b2c=Ui(_0x1165a9,'database')['getImmediate']({'identifier':_0x4c6b27});if(!_0x523b2c['_instanceStarted']){const _0x3a4a60=ac('database');_0x3a4a60&&Yd(_0x523b2c,..._0x3a4a60);}return _0x523b2c;}function Yd(_0x4f2b97,_0x3ba06a,_0x45c2a7,_0x53e816={}){_0x4f2b97=k(_0x4f2b97),_0x4f2b97['_checkNotDeleted']('useEmulator');const _0x2eb5f3=_0x3ba06a+':'+_0x45c2a7,_0x33e1a8=_0x4f2b97['_repoInternal'];if(_0x4f2b97['_instanceStarted']){if(_0x2eb5f3===_0x4f2b97['_repoInternal']['repoInfo_']['host']&&De(_0x53e816,_0x33e1a8['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x690c6a;if(_0x33e1a8['repoInfo_']['nodeAdmin'])_0x53e816['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x690c6a=new tn(tn['OWNER']);else{if(_0x53e816['mockUserToken']){const _0x1045df=typeof _0x53e816['mockUserToken']=='string'?_0x53e816['mockUserToken']:cc(_0x53e816['mockUserToken'],_0x4f2b97['app']['options']['projectId']);_0x690c6a=new tn(_0x1045df);}}Wt(_0x3ba06a)&&jr(_0x3ba06a),Gd(_0x33e1a8,_0x2eb5f3,_0x53e816,_0x690c6a);}function C_(_0x16607a){_0x16607a=k(_0x16607a),_0x16607a['_checkNotDeleted']('goOffline'),aa(_0x16607a['_repo']);}function T_(_0x7ca95){_0x7ca95=k(_0x7ca95),_0x7ca95['_checkNotDeleted']('goOnline'),Sd(_0x7ca95['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x30f776){Ll(ct),et(new Me('database',(_0x586229,{instanceIdentifier:_0x50061e})=>{const _0x35281b=_0x586229['getProvider']('app')['getImmediate'](),_0x409c8f=_0x586229['getProvider']('auth-internal'),_0x5993d5=_0x586229['getProvider']('app-check-internal');return qd(_0x35281b,_0x409c8f,_0x5993d5,_0x50061e);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x30f776),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x58ba12,_0x247dbd){this['committed']=_0x58ba12,this['snapshot']=_0x247dbd;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x424281,_0x2b3c81,_0xfdd1e3){if(_0x424281=k(_0x424281),gs('Reference.transaction',_0x424281['_path']),_0x424281['key']==='.length'||_0x424281['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x424281['key']+'\x20is\x20a\x20read-only\x20object.';const _0x48ca58=!0x0,_0x57ebcf=new Ve(),_0x34dd7b=(_0x5a05a3,_0x50181d,_0x2ae92f)=>{let _0x2d2cae=null;_0x5a05a3?_0x57ebcf['reject'](_0x5a05a3):(_0x2d2cae=new rt(_0x2ae92f,new Z(_0x424281['_repo'],_0x424281['_path']),R),_0x57ebcf['resolve'](new Xd(_0x50181d,_0x2d2cae)));},_0x32a729=Fd(_0x424281,()=>{});return bd(_0x424281['_repo'],_0x424281['_path'],_0x2b3c81,_0x34dd7b,_0x32a729,_0x48ca58),_0x57ebcf['promise'];}ie['prototype']['simpleListen']=function(_0x4ae3ca,_0x4c31b9){this['sendRequest']('q',{'p':_0x4ae3ca},_0x4c31b9);},ie['prototype']['echo']=function(_0x1754b0,_0x399d5b){this['sendRequest']('echo',{'d':_0x1754b0},_0x399d5b);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x31bf88,..._0x4f45f9){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x31bf88,..._0x4f45f9);}function nn(_0x4eea0c,..._0x3125af){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x4eea0c,..._0x3125af);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0xa6ad5e,..._0x6c62fd){throw Es(_0xa6ad5e,..._0x6c62fd);}function J(_0x2f82e2,..._0x31f92b){return Es(_0x2f82e2,..._0x31f92b);}function ya(_0x525cdf,_0x34f97c,_0x176920){const _0x50a6dd={...Zd(),[_0x34f97c]:_0x176920};return new Ut('auth','Firebase',_0x50a6dd)['create'](_0x34f97c,{'appName':_0x525cdf['name']});}function se(_0x22ca10){return ya(_0x22ca10,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5351cb,..._0x1f15e1){if(typeof _0x5351cb!='string'){const _0x31d1ba=_0x1f15e1[0x0],_0xfaa83b=[..._0x1f15e1['slice'](0x1)];return _0xfaa83b[0x0]&&(_0xfaa83b[0x0]['appName']=_0x5351cb['name']),_0x5351cb['_errorFactory']['create'](_0x31d1ba,..._0xfaa83b);}return ma['create'](_0x5351cb,..._0x1f15e1);}function m(_0x554c71,_0x59b089,..._0x5d5c6a){if(!_0x554c71)throw Es(_0x59b089,..._0x5d5c6a);}function te(_0x3574db){const _0xe5b36c='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3574db;throw nn(_0xe5b36c),new Error(_0xe5b36c);}function ae(_0x10b18d,_0x698004){_0x10b18d||te(_0x698004);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x5c9bf3;return typeof self<'u'&&((_0x5c9bf3=self['location'])==null?void 0x0:_0x5c9bf3['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4d4854;return typeof self<'u'&&((_0x4d4854=self['location'])==null?void 0x0:_0x4d4854['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x2a5ada=navigator;return _0x2a5ada['languages']&&_0x2a5ada['languages'][0x0]||_0x2a5ada['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x291c88,_0x12a231){this['shortDelay']=_0x291c88,this['longDelay']=_0x12a231,ae(_0x12a231>_0x291c88,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x421429,_0x2a9c57){ae(_0x421429['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x429f1d}=_0x421429['emulator'];return _0x2a9c57?''+_0x429f1d+(_0x2a9c57['startsWith']('/')?_0x2a9c57['slice'](0x1):_0x2a9c57):_0x429f1d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x245d22,_0x2e161b,_0x4fbce2){this['fetchImpl']=_0x245d22,_0x2e161b&&(this['headersImpl']=_0x2e161b),_0x4fbce2&&(this['responseImpl']=_0x4fbce2);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x5be15b,_0x221246){return _0x5be15b['tenantId']&&!_0x221246['tenantId']?{..._0x221246,'tenantId':_0x5be15b['tenantId']}:_0x221246;}async function Ae(_0x2c0458,_0x4256e4,_0x4de16c,_0x434bb3,_0xbda8bd={}){return Ea(_0x2c0458,_0xbda8bd,async()=>{let _0x821d4={},_0x1d782a={};_0x434bb3&&(_0x4256e4==='GET'?_0x1d782a=_0x434bb3:_0x821d4={'body':JSON['stringify'](_0x434bb3)});const _0x368603=at({..._0x1d782a,'key':_0x2c0458['config']['apiKey']})['slice'](0x1),_0x243d07=await _0x2c0458['_getAdditionalHeaders']();_0x243d07['Content-Type']='application/json',_0x2c0458['languageCode']&&(_0x243d07['X-Firebase-Locale']=_0x2c0458['languageCode']);const _0x13057c={'method':_0x4256e4,'headers':_0x243d07,..._0x821d4};return lc()||(_0x13057c['referrerPolicy']='strict-origin-when-cross-origin'),_0x2c0458['emulatorConfig']&&Wt(_0x2c0458['emulatorConfig']['host'])&&(_0x13057c['credentials']='include'),va['fetch']()(await Ia(_0x2c0458,_0x2c0458['config']['apiHost'],_0x4de16c,_0x368603),_0x13057c);});}async function Ea(_0x4f0e5b,_0x40fb16,_0x3886b0){_0x4f0e5b['_canInitEmulator']=!0x1;const _0x10b60c={...rf,..._0x40fb16};try{const _0x3a29d1=new lf(_0x4f0e5b),_0x3f5bb8=await Promise['race']([_0x3886b0(),_0x3a29d1['promise']]);_0x3a29d1['clearNetworkTimeout']();const _0x1f54d0=await _0x3f5bb8['json']();if('needConfirmation'in _0x1f54d0)throw en(_0x4f0e5b,'account-exists-with-different-credential',_0x1f54d0);if(_0x3f5bb8['ok']&&!('errorMessage'in _0x1f54d0))return _0x1f54d0;{const _0x41df6a=_0x3f5bb8['ok']?_0x1f54d0['errorMessage']:_0x1f54d0['error']['message'],[_0xaa2390,_0x17a857]=_0x41df6a['split']('\x20:\x20');if(_0xaa2390==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4f0e5b,'credential-already-in-use',_0x1f54d0);if(_0xaa2390==='EMAIL_EXISTS')throw en(_0x4f0e5b,'email-already-in-use',_0x1f54d0);if(_0xaa2390==='USER_DISABLED')throw en(_0x4f0e5b,'user-disabled',_0x1f54d0);const _0xf8e3c3=_0x10b60c[_0xaa2390]||_0xaa2390['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x17a857)throw ya(_0x4f0e5b,_0xf8e3c3,_0x17a857);K(_0x4f0e5b,_0xf8e3c3);}}catch(_0xeb4e8c){if(_0xeb4e8c instanceof Se)throw _0xeb4e8c;K(_0x4f0e5b,'network-request-failed',{'message':String(_0xeb4e8c)});}}async function Yt(_0x121c1c,_0x45d662,_0x5ddf79,_0x1439f2,_0x51c08f={}){const _0x3af889=await Ae(_0x121c1c,_0x45d662,_0x5ddf79,_0x1439f2,_0x51c08f);return'mfaPendingCredential'in _0x3af889&&K(_0x121c1c,'multi-factor-auth-required',{'_serverResponse':_0x3af889}),_0x3af889;}async function Ia(_0x2e7c4b,_0x3aa71b,_0x53ca44,_0x3adb1e){const _0x54a66e=''+_0x3aa71b+_0x53ca44+'?'+_0x3adb1e,_0x440655=_0x2e7c4b,_0x2fd4cc=_0x440655['config']['emulator']?Is(_0x2e7c4b['config'],_0x54a66e):_0x2e7c4b['config']['apiScheme']+'://'+_0x54a66e;return of['includes'](_0x53ca44)&&(await _0x440655['_persistenceManagerAvailable'],_0x440655['_getPersistenceType']()==='COOKIE')?_0x440655['_getPersistence']()['_getFinalTarget'](_0x2fd4cc)['toString']():_0x2fd4cc;}function cf(_0x57187c){switch(_0x57187c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0xf4e5a8){this['auth']=_0xf4e5a8,this['timer']=null,this['promise']=new Promise((_0x384141,_0x500455)=>{this['timer']=setTimeout(()=>_0x500455(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4ff717,_0x5174bb,_0x2cf17e){const _0x467ec9={'appName':_0x4ff717['name']};_0x2cf17e['email']&&(_0x467ec9['email']=_0x2cf17e['email']),_0x2cf17e['phoneNumber']&&(_0x467ec9['phoneNumber']=_0x2cf17e['phoneNumber']);const _0x3d6918=J(_0x4ff717,_0x5174bb,_0x467ec9);return _0x3d6918['customData']['_tokenResponse']=_0x2cf17e,_0x3d6918;}function vr(_0x16dee4){return _0x16dee4!==void 0x0&&_0x16dee4['enterprise']!==void 0x0;}class hf{constructor(_0x1524ac){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1524ac['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1524ac['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1524ac['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x593d4d){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x53d97a of this['recaptchaEnforcementState'])if(_0x53d97a['provider']&&_0x53d97a['provider']===_0x593d4d)return cf(_0x53d97a['enforcementState']);return null;}['isProviderEnabled'](_0x20e70c){return this['getProviderEnforcementState'](_0x20e70c)==='ENFORCE'||this['getProviderEnforcementState'](_0x20e70c)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x396dbc,_0x132d49){return Ae(_0x396dbc,'GET','/v2/recaptchaConfig',Re(_0x396dbc,_0x132d49));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x446915,_0xdcdc36){return Ae(_0x446915,'POST','/v1/accounts:delete',_0xdcdc36);}async function Sn(_0x12cd88,_0x30fe03){return Ae(_0x12cd88,'POST','/v1/accounts:lookup',_0x30fe03);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x58a9a2){if(_0x58a9a2)try{const _0x373dcd=new Date(Number(_0x58a9a2));if(!isNaN(_0x373dcd['getTime']()))return _0x373dcd['toUTCString']();}catch{}}async function ff(_0x16dd31,_0x594c34=!0x1){const _0x15e54c=k(_0x16dd31),_0x3252ed=await _0x15e54c['getIdToken'](_0x594c34),_0x4b5585=ws(_0x3252ed);m(_0x4b5585&&_0x4b5585['exp']&&_0x4b5585['auth_time']&&_0x4b5585['iat'],_0x15e54c['auth'],'internal-error');const _0x5ad263=typeof _0x4b5585['firebase']=='object'?_0x4b5585['firebase']:void 0x0,_0x35976c=_0x5ad263==null?void 0x0:_0x5ad263['sign_in_provider'];return{'claims':_0x4b5585,'token':_0x3252ed,'authTime':St(ci(_0x4b5585['auth_time'])),'issuedAtTime':St(ci(_0x4b5585['iat'])),'expirationTime':St(ci(_0x4b5585['exp'])),'signInProvider':_0x35976c||null,'signInSecondFactor':(_0x5ad263==null?void 0x0:_0x5ad263['sign_in_second_factor'])||null};}function ci(_0x187797){return Number(_0x187797)*0x3e8;}function ws(_0x4820c6){const [_0x207e86,_0x46ff7b,_0x2245f0]=_0x4820c6['split']('.');if(_0x207e86===void 0x0||_0x46ff7b===void 0x0||_0x2245f0===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1ac954=cn(_0x46ff7b);return _0x1ac954?JSON['parse'](_0x1ac954):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2208ac){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2208ac==null?void 0x0:_0x2208ac['toString']()),null;}}function Er(_0x4ee734){const _0xa13d97=ws(_0x4ee734);return m(_0xa13d97,'internal-error'),m(typeof _0xa13d97['exp']<'u','internal-error'),m(typeof _0xa13d97['iat']<'u','internal-error'),Number(_0xa13d97['exp'])-Number(_0xa13d97['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x80907e,_0x767a85,_0x2459e3=!0x1){if(_0x2459e3)return _0x767a85;try{return await _0x767a85;}catch(_0x1f489c){throw _0x1f489c instanceof Se&&pf(_0x1f489c)&&_0x80907e['auth']['currentUser']===_0x80907e&&await _0x80907e['auth']['signOut'](),_0x1f489c;}}function pf({code:_0x3993f3}){return _0x3993f3==='auth/user-disabled'||_0x3993f3==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x20d2a0){this['user']=_0x20d2a0,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x6961e){if(_0x6961e){const _0x5efd74=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5efd74;}else{this['errorBackoff']=0x7530;const _0x588f26=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x588f26);}}['schedule'](_0xbf2a3b=!0x1){if(!this['isRunning'])return;const _0x5c5530=this['getInterval'](_0xbf2a3b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5c5530);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x67f9d){(_0x67f9d==null?void 0x0:_0x67f9d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x56ee3a,_0x2e8e0d){this['createdAt']=_0x56ee3a,this['lastLoginAt']=_0x2e8e0d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x5a7c1f){this['createdAt']=_0x5a7c1f['createdAt'],this['lastLoginAt']=_0x5a7c1f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5a28e6){var _0x37d0be;const _0x9db3db=_0x5a28e6['auth'],_0x404736=await _0x5a28e6['getIdToken'](),_0x2937e3=await xt(_0x5a28e6,Sn(_0x9db3db,{'idToken':_0x404736}));m(_0x2937e3==null?void 0x0:_0x2937e3['users']['length'],_0x9db3db,'internal-error');const _0x1e285e=_0x2937e3['users'][0x0];_0x5a28e6['_notifyReloadListener'](_0x1e285e);const _0x2974c0=(_0x37d0be=_0x1e285e['providerUserInfo'])!=null&&_0x37d0be['length']?wa(_0x1e285e['providerUserInfo']):[],_0xf0a33a=mf(_0x5a28e6['providerData'],_0x2974c0),_0x3efd4c=_0x5a28e6['isAnonymous'],_0xe861a9=!(_0x5a28e6['email']&&_0x1e285e['passwordHash'])&&!(_0xf0a33a!=null&&_0xf0a33a['length']),_0x4d04b2=_0x3efd4c?_0xe861a9:!0x1,_0x22dabf={'uid':_0x1e285e['localId'],'displayName':_0x1e285e['displayName']||null,'photoURL':_0x1e285e['photoUrl']||null,'email':_0x1e285e['email']||null,'emailVerified':_0x1e285e['emailVerified']||!0x1,'phoneNumber':_0x1e285e['phoneNumber']||null,'tenantId':_0x1e285e['tenantId']||null,'providerData':_0xf0a33a,'metadata':new Pi(_0x1e285e['createdAt'],_0x1e285e['lastLoginAt']),'isAnonymous':_0x4d04b2};Object['assign'](_0x5a28e6,_0x22dabf);}async function gf(_0x545ba7){const _0x22a909=k(_0x545ba7);await bn(_0x22a909),await _0x22a909['auth']['_persistUserIfCurrent'](_0x22a909),_0x22a909['auth']['_notifyListenersIfCurrent'](_0x22a909);}function mf(_0x216b83,_0x72abf5){return[..._0x216b83['filter'](_0xecaf01=>!_0x72abf5['some'](_0x167f73=>_0x167f73['providerId']===_0xecaf01['providerId'])),..._0x72abf5];}function wa(_0x688f11){return _0x688f11['map'](({providerId:_0x48ff23,..._0x323657})=>({'providerId':_0x48ff23,'uid':_0x323657['rawId']||'','displayName':_0x323657['displayName']||null,'email':_0x323657['email']||null,'phoneNumber':_0x323657['phoneNumber']||null,'photoURL':_0x323657['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0xf7f186,_0x9c0c5a){const _0x54a947=await Ea(_0xf7f186,{},async()=>{const _0x43f915=at({'grant_type':'refresh_token','refresh_token':_0x9c0c5a})['slice'](0x1),{tokenApiHost:_0x4d3c2c,apiKey:_0x16d897}=_0xf7f186['config'],_0x45bcbf=await Ia(_0xf7f186,_0x4d3c2c,'/v1/token','key='+_0x16d897),_0x5db038=await _0xf7f186['_getAdditionalHeaders']();_0x5db038['Content-Type']='application/x-www-form-urlencoded';const _0x51d7e9={'method':'POST','headers':_0x5db038,'body':_0x43f915};return _0xf7f186['emulatorConfig']&&Wt(_0xf7f186['emulatorConfig']['host'])&&(_0x51d7e9['credentials']='include'),va['fetch']()(_0x45bcbf,_0x51d7e9);});return{'accessToken':_0x54a947['access_token'],'expiresIn':_0x54a947['expires_in'],'refreshToken':_0x54a947['refresh_token']};}async function vf(_0x5741e0,_0x581b87){return Ae(_0x5741e0,'POST','/v2/accounts:revokeToken',Re(_0x5741e0,_0x581b87));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x266e9b){m(_0x266e9b['idToken'],'internal-error'),m(typeof _0x266e9b['idToken']<'u','internal-error'),m(typeof _0x266e9b['refreshToken']<'u','internal-error');const _0x31d044='expiresIn'in _0x266e9b&&typeof _0x266e9b['expiresIn']<'u'?Number(_0x266e9b['expiresIn']):Er(_0x266e9b['idToken']);this['updateTokensAndExpiration'](_0x266e9b['idToken'],_0x266e9b['refreshToken'],_0x31d044);}['updateFromIdToken'](_0x49f8c8){m(_0x49f8c8['length']!==0x0,'internal-error');const _0x5578ef=Er(_0x49f8c8);this['updateTokensAndExpiration'](_0x49f8c8,null,_0x5578ef);}async['getToken'](_0xd98dc2,_0xf89847=!0x1){return!_0xf89847&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xd98dc2,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xd98dc2,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3fc93e,_0xca8522){const {accessToken:_0x44b71b,refreshToken:_0x3aca40,expiresIn:_0x399188}=await yf(_0x3fc93e,_0xca8522);this['updateTokensAndExpiration'](_0x44b71b,_0x3aca40,Number(_0x399188));}['updateTokensAndExpiration'](_0x673f31,_0x387e76,_0x3e57b8){this['refreshToken']=_0x387e76||null,this['accessToken']=_0x673f31||null,this['expirationTime']=Date['now']()+_0x3e57b8*0x3e8;}static['fromJSON'](_0x23c533,_0x22bf74){const {refreshToken:_0xc2ba01,accessToken:_0x8ea36,expirationTime:_0x3692b5}=_0x22bf74,_0x2fbe94=new Je();return _0xc2ba01&&(m(typeof _0xc2ba01=='string','internal-error',{'appName':_0x23c533}),_0x2fbe94['refreshToken']=_0xc2ba01),_0x8ea36&&(m(typeof _0x8ea36=='string','internal-error',{'appName':_0x23c533}),_0x2fbe94['accessToken']=_0x8ea36),_0x3692b5&&(m(typeof _0x3692b5=='number','internal-error',{'appName':_0x23c533}),_0x2fbe94['expirationTime']=_0x3692b5),_0x2fbe94;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3a7b3a){this['accessToken']=_0x3a7b3a['accessToken'],this['refreshToken']=_0x3a7b3a['refreshToken'],this['expirationTime']=_0x3a7b3a['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x271ac7,_0x1e807e){m(typeof _0x271ac7=='string'||typeof _0x271ac7>'u','internal-error',{'appName':_0x1e807e});}class z{constructor({uid:_0x1b4331,auth:_0x5d1e9f,stsTokenManager:_0x1b3e71,..._0x11c1cf}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1b4331,this['auth']=_0x5d1e9f,this['stsTokenManager']=_0x1b3e71,this['accessToken']=_0x1b3e71['accessToken'],this['displayName']=_0x11c1cf['displayName']||null,this['email']=_0x11c1cf['email']||null,this['emailVerified']=_0x11c1cf['emailVerified']||!0x1,this['phoneNumber']=_0x11c1cf['phoneNumber']||null,this['photoURL']=_0x11c1cf['photoURL']||null,this['isAnonymous']=_0x11c1cf['isAnonymous']||!0x1,this['tenantId']=_0x11c1cf['tenantId']||null,this['providerData']=_0x11c1cf['providerData']?[..._0x11c1cf['providerData']]:[],this['metadata']=new Pi(_0x11c1cf['createdAt']||void 0x0,_0x11c1cf['lastLoginAt']||void 0x0);}async['getIdToken'](_0x8cd659){const _0x2de5b7=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x8cd659));return m(_0x2de5b7,this['auth'],'internal-error'),this['accessToken']!==_0x2de5b7&&(this['accessToken']=_0x2de5b7,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2de5b7;}['getIdTokenResult'](_0x42321f){return ff(this,_0x42321f);}['reload'](){return gf(this);}['_assign'](_0x2f355d){this!==_0x2f355d&&(m(this['uid']===_0x2f355d['uid'],this['auth'],'internal-error'),this['displayName']=_0x2f355d['displayName'],this['photoURL']=_0x2f355d['photoURL'],this['email']=_0x2f355d['email'],this['emailVerified']=_0x2f355d['emailVerified'],this['phoneNumber']=_0x2f355d['phoneNumber'],this['isAnonymous']=_0x2f355d['isAnonymous'],this['tenantId']=_0x2f355d['tenantId'],this['providerData']=_0x2f355d['providerData']['map'](_0x49e950=>({..._0x49e950})),this['metadata']['_copy'](_0x2f355d['metadata']),this['stsTokenManager']['_assign'](_0x2f355d['stsTokenManager']));}['_clone'](_0xd4e44a){const _0x3b3da3=new z({...this,'auth':_0xd4e44a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3b3da3['metadata']['_copy'](this['metadata']),_0x3b3da3;}['_onReload'](_0x17d3ef){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x17d3ef,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4c9e85){this['reloadListener']?this['reloadListener'](_0x4c9e85):this['reloadUserInfo']=_0x4c9e85;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1448d6,_0x11b798=!0x1){let _0x399763=!0x1;_0x1448d6['idToken']&&_0x1448d6['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1448d6),_0x399763=!0x0),_0x11b798&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x399763&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x57fa36=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x57fa36})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x7f414d=>({..._0x7f414d})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0xde4ea3,_0x2ac10c){const _0x4dbea3=_0x2ac10c['displayName']??void 0x0,_0x1e2dcd=_0x2ac10c['email']??void 0x0,_0x230b43=_0x2ac10c['phoneNumber']??void 0x0,_0xfe16df=_0x2ac10c['photoURL']??void 0x0,_0x406052=_0x2ac10c['tenantId']??void 0x0,_0x4e8de7=_0x2ac10c['_redirectEventId']??void 0x0,_0x2df5cc=_0x2ac10c['createdAt']??void 0x0,_0x3d1363=_0x2ac10c['lastLoginAt']??void 0x0,{uid:_0x3bbef5,emailVerified:_0x371111,isAnonymous:_0xf31948,providerData:_0x7cf899,stsTokenManager:_0x2c3f9b}=_0x2ac10c;m(_0x3bbef5&&_0x2c3f9b,_0xde4ea3,'internal-error');const _0x450e68=Je['fromJSON'](this['name'],_0x2c3f9b);m(typeof _0x3bbef5=='string',_0xde4ea3,'internal-error'),ce(_0x4dbea3,_0xde4ea3['name']),ce(_0x1e2dcd,_0xde4ea3['name']),m(typeof _0x371111=='boolean',_0xde4ea3,'internal-error'),m(typeof _0xf31948=='boolean',_0xde4ea3,'internal-error'),ce(_0x230b43,_0xde4ea3['name']),ce(_0xfe16df,_0xde4ea3['name']),ce(_0x406052,_0xde4ea3['name']),ce(_0x4e8de7,_0xde4ea3['name']),ce(_0x2df5cc,_0xde4ea3['name']),ce(_0x3d1363,_0xde4ea3['name']);const _0x7b72a0=new z({'uid':_0x3bbef5,'auth':_0xde4ea3,'email':_0x1e2dcd,'emailVerified':_0x371111,'displayName':_0x4dbea3,'isAnonymous':_0xf31948,'photoURL':_0xfe16df,'phoneNumber':_0x230b43,'tenantId':_0x406052,'stsTokenManager':_0x450e68,'createdAt':_0x2df5cc,'lastLoginAt':_0x3d1363});return _0x7cf899&&Array['isArray'](_0x7cf899)&&(_0x7b72a0['providerData']=_0x7cf899['map'](_0x3b52ef=>({..._0x3b52ef}))),_0x4e8de7&&(_0x7b72a0['_redirectEventId']=_0x4e8de7),_0x7b72a0;}static async['_fromIdTokenResponse'](_0x27a298,_0x3bce00,_0x40671a=!0x1){const _0x40ed54=new Je();_0x40ed54['updateFromServerResponse'](_0x3bce00);const _0x398716=new z({'uid':_0x3bce00['localId'],'auth':_0x27a298,'stsTokenManager':_0x40ed54,'isAnonymous':_0x40671a});return await bn(_0x398716),_0x398716;}static async['_fromGetAccountInfoResponse'](_0x49df29,_0x5195dc,_0x151ca6){const _0x2b1e34=_0x5195dc['users'][0x0];m(_0x2b1e34['localId']!==void 0x0,'internal-error');const _0x38d17b=_0x2b1e34['providerUserInfo']!==void 0x0?wa(_0x2b1e34['providerUserInfo']):[],_0x1cf0ac=!(_0x2b1e34['email']&&_0x2b1e34['passwordHash'])&&!(_0x38d17b!=null&&_0x38d17b['length']),_0x4c56f1=new Je();_0x4c56f1['updateFromIdToken'](_0x151ca6);const _0x3430a7=new z({'uid':_0x2b1e34['localId'],'auth':_0x49df29,'stsTokenManager':_0x4c56f1,'isAnonymous':_0x1cf0ac}),_0xc7bec9={'uid':_0x2b1e34['localId'],'displayName':_0x2b1e34['displayName']||null,'photoURL':_0x2b1e34['photoUrl']||null,'email':_0x2b1e34['email']||null,'emailVerified':_0x2b1e34['emailVerified']||!0x1,'phoneNumber':_0x2b1e34['phoneNumber']||null,'tenantId':_0x2b1e34['tenantId']||null,'providerData':_0x38d17b,'metadata':new Pi(_0x2b1e34['createdAt'],_0x2b1e34['lastLoginAt']),'isAnonymous':!(_0x2b1e34['email']&&_0x2b1e34['passwordHash'])&&!(_0x38d17b!=null&&_0x38d17b['length'])};return Object['assign'](_0x3430a7,_0xc7bec9),_0x3430a7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x28eb2d){ae(_0x28eb2d instanceof Function,'Expected\x20a\x20class\x20definition');let _0x29b235=Ir['get'](_0x28eb2d);return _0x29b235?(ae(_0x29b235 instanceof _0x28eb2d,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x29b235):(_0x29b235=new _0x28eb2d(),Ir['set'](_0x28eb2d,_0x29b235),_0x29b235);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x58af5f,_0x1d2971){this['storage'][_0x58af5f]=_0x1d2971;}async['_get'](_0x581737){const _0x2db19f=this['storage'][_0x581737];return _0x2db19f===void 0x0?null:_0x2db19f;}async['_remove'](_0x3e77a3){delete this['storage'][_0x3e77a3];}['_addListener'](_0x4c0097,_0x26db25){}['_removeListener'](_0x46194f,_0x4f82fe){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x505d19,_0x1e0b88,_0x23b6b5){return'firebase:'+_0x505d19+':'+_0x1e0b88+':'+_0x23b6b5;}class Xe{constructor(_0x2cde87,_0x1ef6b8,_0x5c527e){this['persistence']=_0x2cde87,this['auth']=_0x1ef6b8,this['userKey']=_0x5c527e;const {config:_0x5ae94c,name:_0x1a23a3}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x5ae94c['apiKey'],_0x1a23a3),this['fullPersistenceKey']=sn('persistence',_0x5ae94c['apiKey'],_0x1a23a3),this['boundEventHandler']=_0x1ef6b8['_onStorageEvent']['bind'](_0x1ef6b8),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x44223a){return this['persistence']['_set'](this['fullUserKey'],_0x44223a['toJSON']());}async['getCurrentUser'](){const _0x2fbc8c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2fbc8c)return null;if(typeof _0x2fbc8c=='string'){const _0x44df87=await Sn(this['auth'],{'idToken':_0x2fbc8c})['catch'](()=>{});return _0x44df87?z['_fromGetAccountInfoResponse'](this['auth'],_0x44df87,_0x2fbc8c):null;}return z['_fromJSON'](this['auth'],_0x2fbc8c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2d6192){if(this['persistence']===_0x2d6192)return;const _0x599671=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2d6192,_0x599671)return this['setCurrentUser'](_0x599671);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3cde59,_0x5b41fc,_0x59f516='authUser'){if(!_0x5b41fc['length'])return new Xe(ne(wr),_0x3cde59,_0x59f516);const _0x51e4f3=(await Promise['all'](_0x5b41fc['map'](async _0x23a789=>{if(await _0x23a789['_isAvailable']())return _0x23a789;})))['filter'](_0x2e08a5=>_0x2e08a5);let _0x41148e=_0x51e4f3[0x0]||ne(wr);const _0x53d8b7=sn(_0x59f516,_0x3cde59['config']['apiKey'],_0x3cde59['name']);let _0x3fca3f=null;for(const _0x2d329e of _0x5b41fc)try{const _0x2bf059=await _0x2d329e['_get'](_0x53d8b7);if(_0x2bf059){let _0x3c834b;if(typeof _0x2bf059=='string'){const _0x3f8b3a=await Sn(_0x3cde59,{'idToken':_0x2bf059})['catch'](()=>{});if(!_0x3f8b3a)break;_0x3c834b=await z['_fromGetAccountInfoResponse'](_0x3cde59,_0x3f8b3a,_0x2bf059);}else _0x3c834b=z['_fromJSON'](_0x3cde59,_0x2bf059);_0x2d329e!==_0x41148e&&(_0x3fca3f=_0x3c834b),_0x41148e=_0x2d329e;break;}}catch{}const _0x1cee9b=_0x51e4f3['filter'](_0x4e8d77=>_0x4e8d77['_shouldAllowMigration']);return!_0x41148e['_shouldAllowMigration']||!_0x1cee9b['length']?new Xe(_0x41148e,_0x3cde59,_0x59f516):(_0x41148e=_0x1cee9b[0x0],_0x3fca3f&&await _0x41148e['_set'](_0x53d8b7,_0x3fca3f['toJSON']()),await Promise['all'](_0x5b41fc['map'](async _0x55f2c2=>{if(_0x55f2c2!==_0x41148e)try{await _0x55f2c2['_remove'](_0x53d8b7);}catch{}})),new Xe(_0x41148e,_0x3cde59,_0x59f516));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x5be739){const _0x4390d9=_0x5be739['toLowerCase']();if(_0x4390d9['includes']('opera/')||_0x4390d9['includes']('opr/')||_0x4390d9['includes']('opios/'))return'Opera';if(Ra(_0x4390d9))return'IEMobile';if(_0x4390d9['includes']('msie')||_0x4390d9['includes']('trident/'))return'IE';if(_0x4390d9['includes']('edge/'))return'Edge';if(Ta(_0x4390d9))return'Firefox';if(_0x4390d9['includes']('silk/'))return'Silk';if(ka(_0x4390d9))return'Blackberry';if(Na(_0x4390d9))return'Webos';if(Sa(_0x4390d9))return'Safari';if((_0x4390d9['includes']('chrome/')||ba(_0x4390d9))&&!_0x4390d9['includes']('edge/'))return'Chrome';if(Aa(_0x4390d9))return'Android';{const _0x459669=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4ced79=_0x5be739['match'](_0x459669);if((_0x4ced79==null?void 0x0:_0x4ced79['length'])===0x2)return _0x4ced79[0x1];}return'Other';}function Ta(_0x392ca0=W()){return/firefox\//i['test'](_0x392ca0);}function Sa(_0xb13207=W()){const _0x34ac0e=_0xb13207['toLowerCase']();return _0x34ac0e['includes']('safari/')&&!_0x34ac0e['includes']('chrome/')&&!_0x34ac0e['includes']('crios/')&&!_0x34ac0e['includes']('android');}function ba(_0x16d229=W()){return/crios\//i['test'](_0x16d229);}function Ra(_0x12e0c4=W()){return/iemobile/i['test'](_0x12e0c4);}function Aa(_0x33df9d=W()){return/android/i['test'](_0x33df9d);}function ka(_0x4839dc=W()){return/blackberry/i['test'](_0x4839dc);}function Na(_0x5008af=W()){return/webos/i['test'](_0x5008af);}function Cs(_0x1b75c7=W()){return/iphone|ipad|ipod/i['test'](_0x1b75c7)||/macintosh/i['test'](_0x1b75c7)&&/mobile/i['test'](_0x1b75c7);}function Ef(_0x21054a=W()){var _0x19db4b;return Cs(_0x21054a)&&!!((_0x19db4b=window['navigator'])!=null&&_0x19db4b['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2a4ac8=W()){return Cs(_0x2a4ac8)||Aa(_0x2a4ac8)||Na(_0x2a4ac8)||ka(_0x2a4ac8)||/windows phone/i['test'](_0x2a4ac8)||Ra(_0x2a4ac8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x44fc74,_0x3c98c0=[]){let _0x3b46bc;switch(_0x44fc74){case'Browser':_0x3b46bc=Cr(W());break;case'Worker':_0x3b46bc=Cr(W())+'-'+_0x44fc74;break;default:_0x3b46bc=_0x44fc74;}const _0x10ad20=_0x3c98c0['length']?_0x3c98c0['join'](','):'FirebaseCore-web';return _0x3b46bc+'/JsCore/'+ct+'/'+_0x10ad20;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x134c87){this['auth']=_0x134c87,this['queue']=[];}['pushCallback'](_0x4199c3,_0x5bc0f3){const _0x275448=_0x158cab=>new Promise((_0x38cb98,_0x18995c)=>{try{const _0x5c7bd5=_0x4199c3(_0x158cab);_0x38cb98(_0x5c7bd5);}catch(_0x5e5d9c){_0x18995c(_0x5e5d9c);}});_0x275448['onAbort']=_0x5bc0f3,this['queue']['push'](_0x275448);const _0x21751e=this['queue']['length']-0x1;return()=>{this['queue'][_0x21751e]=()=>Promise['resolve']();};}async['runMiddleware'](_0x334e4b){if(this['auth']['currentUser']===_0x334e4b)return;const _0xe00b26=[];try{for(const _0x2321a7 of this['queue'])await _0x2321a7(_0x334e4b),_0x2321a7['onAbort']&&_0xe00b26['push'](_0x2321a7['onAbort']);}catch(_0x35cff9){_0xe00b26['reverse']();for(const _0x5d59fa of _0xe00b26)try{_0x5d59fa();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x35cff9==null?void 0x0:_0x35cff9['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x118a06,_0x1610c9={}){return Ae(_0x118a06,'GET','/v2/passwordPolicy',Re(_0x118a06,_0x1610c9));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x413683){var _0x3136da;const _0x341315=_0x413683['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x341315['minPasswordLength']??Tf,_0x341315['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x341315['maxPasswordLength']),_0x341315['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x341315['containsLowercaseCharacter']),_0x341315['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x341315['containsUppercaseCharacter']),_0x341315['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x341315['containsNumericCharacter']),_0x341315['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x341315['containsNonAlphanumericCharacter']),this['enforcementState']=_0x413683['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3136da=_0x413683['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3136da['join'](''))??'',this['forceUpgradeOnSignin']=_0x413683['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x413683['schemaVersion'];}['validatePassword'](_0x37f774){const _0x3e0503={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x37f774,_0x3e0503),this['validatePasswordCharacterOptions'](_0x37f774,_0x3e0503),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['meetsMinPasswordLength']??!0x0),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['meetsMaxPasswordLength']??!0x0),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['containsLowercaseLetter']??!0x0),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['containsUppercaseLetter']??!0x0),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['containsNumericCharacter']??!0x0),_0x3e0503['isValid']&&(_0x3e0503['isValid']=_0x3e0503['containsNonAlphanumericCharacter']??!0x0),_0x3e0503;}['validatePasswordLengthOptions'](_0x11203b,_0x20bbb0){const _0x3b9213=this['customStrengthOptions']['minPasswordLength'],_0x309330=this['customStrengthOptions']['maxPasswordLength'];_0x3b9213&&(_0x20bbb0['meetsMinPasswordLength']=_0x11203b['length']>=_0x3b9213),_0x309330&&(_0x20bbb0['meetsMaxPasswordLength']=_0x11203b['length']<=_0x309330);}['validatePasswordCharacterOptions'](_0x4b1463,_0x2b99e0){this['updatePasswordCharacterOptionsStatuses'](_0x2b99e0,!0x1,!0x1,!0x1,!0x1);let _0x1bc5a0;for(let _0x4f1ab5=0x0;_0x4f1ab5<_0x4b1463['length'];_0x4f1ab5++)_0x1bc5a0=_0x4b1463['charAt'](_0x4f1ab5),this['updatePasswordCharacterOptionsStatuses'](_0x2b99e0,_0x1bc5a0>='a'&&_0x1bc5a0<='z',_0x1bc5a0>='A'&&_0x1bc5a0<='Z',_0x1bc5a0>='0'&&_0x1bc5a0<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1bc5a0));}['updatePasswordCharacterOptionsStatuses'](_0x17b340,_0x3c4871,_0x1fd272,_0x733646,_0x29ffb8){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x17b340['containsLowercaseLetter']||(_0x17b340['containsLowercaseLetter']=_0x3c4871)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x17b340['containsUppercaseLetter']||(_0x17b340['containsUppercaseLetter']=_0x1fd272)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x17b340['containsNumericCharacter']||(_0x17b340['containsNumericCharacter']=_0x733646)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x17b340['containsNonAlphanumericCharacter']||(_0x17b340['containsNonAlphanumericCharacter']=_0x29ffb8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x41c6a0,_0x20a8d1,_0x193e9b,_0x1e269a){this['app']=_0x41c6a0,this['heartbeatServiceProvider']=_0x20a8d1,this['appCheckServiceProvider']=_0x193e9b,this['config']=_0x1e269a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x41c6a0['name'],this['clientVersion']=_0x1e269a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x46c2ec=>this['_resolvePersistenceManagerAvailable']=_0x46c2ec);}['_initializeWithPersistence'](_0x534103,_0x19dc50){return _0x19dc50&&(this['_popupRedirectResolver']=ne(_0x19dc50)),this['_initializationPromise']=this['queue'](async()=>{var _0x46e8f4,_0x2253fe,_0x1f318d;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x534103),(_0x46e8f4=this['_resolvePersistenceManagerAvailable'])==null||_0x46e8f4['call'](this),!this['_deleted'])){if((_0x2253fe=this['_popupRedirectResolver'])!=null&&_0x2253fe['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x19dc50),this['lastNotifiedUid']=((_0x1f318d=this['currentUser'])==null?void 0x0:_0x1f318d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3f35b9=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3f35b9)){if(this['currentUser']&&_0x3f35b9&&this['currentUser']['uid']===_0x3f35b9['uid']){this['_currentUser']['_assign'](_0x3f35b9),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3f35b9,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4fc534){try{const _0x1990f2=await Sn(this,{'idToken':_0x4fc534}),_0x224135=await z['_fromGetAccountInfoResponse'](this,_0x1990f2,_0x4fc534);await this['directlySetCurrentUser'](_0x224135);}catch(_0x5b7132){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5b7132),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x343387){var _0x2b73b1;if(H(this['app'])){const _0x53ad16=this['app']['settings']['authIdToken'];return _0x53ad16?new Promise(_0x73c69e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x53ad16)['then'](_0x73c69e,_0x73c69e));}):this['directlySetCurrentUser'](null);}const _0x36ed26=await this['assertedPersistence']['getCurrentUser']();let _0x23fb41=_0x36ed26,_0x238563=!0x1;if(_0x343387&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x310131=(_0x2b73b1=this['redirectUser'])==null?void 0x0:_0x2b73b1['_redirectEventId'],_0x1f4dff=_0x23fb41==null?void 0x0:_0x23fb41['_redirectEventId'],_0x5110bc=await this['tryRedirectSignIn'](_0x343387);(!_0x310131||_0x310131===_0x1f4dff)&&(_0x5110bc!=null&&_0x5110bc['user'])&&(_0x23fb41=_0x5110bc['user'],_0x238563=!0x0);}if(!_0x23fb41)return this['directlySetCurrentUser'](null);if(!_0x23fb41['_redirectEventId']){if(_0x238563)try{await this['beforeStateQueue']['runMiddleware'](_0x23fb41);}catch(_0x156a1e){_0x23fb41=_0x36ed26,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x156a1e));}return _0x23fb41?this['reloadAndSetCurrentUserOrClear'](_0x23fb41):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x23fb41['_redirectEventId']?this['directlySetCurrentUser'](_0x23fb41):this['reloadAndSetCurrentUserOrClear'](_0x23fb41);}async['tryRedirectSignIn'](_0x572e94){let _0x3ffd4c=null;try{_0x3ffd4c=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x572e94,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3ffd4c;}async['reloadAndSetCurrentUserOrClear'](_0x1887fa){try{await bn(_0x1887fa);}catch(_0x4b6098){if((_0x4b6098==null?void 0x0:_0x4b6098['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1887fa);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1e01de){if(H(this['app']))return Promise['reject'](se(this));const _0x26173d=_0x1e01de?k(_0x1e01de):null;return _0x26173d&&m(_0x26173d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x26173d&&_0x26173d['_clone'](this));}async['_updateCurrentUser'](_0x438374,_0x158a18=!0x1){if(!this['_deleted'])return _0x438374&&m(this['tenantId']===_0x438374['tenantId'],this,'tenant-id-mismatch'),_0x158a18||await this['beforeStateQueue']['runMiddleware'](_0x438374),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x438374),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x9b3f51){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x9b3f51));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xab3cfe){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x200135=this['_getPasswordPolicyInternal']();return _0x200135['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x200135['validatePassword'](_0xab3cfe);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x44fbf5=await Cf(this),_0xf0a9df=new Sf(_0x44fbf5);this['tenantId']===null?this['_projectPasswordPolicy']=_0xf0a9df:this['_tenantPasswordPolicies'][this['tenantId']]=_0xf0a9df;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x6b9b3f){this['_errorFactory']=new Ut('auth','Firebase',_0x6b9b3f());}['onAuthStateChanged'](_0x1f1a4e,_0x15f825,_0x5e3300){return this['registerStateListener'](this['authStateSubscription'],_0x1f1a4e,_0x15f825,_0x5e3300);}['beforeAuthStateChanged'](_0x240b6a,_0x3ed810){return this['beforeStateQueue']['pushCallback'](_0x240b6a,_0x3ed810);}['onIdTokenChanged'](_0xd19360,_0x963fc0,_0x175a76){return this['registerStateListener'](this['idTokenSubscription'],_0xd19360,_0x963fc0,_0x175a76);}['authStateReady'](){return new Promise((_0x11a41d,_0x5dbb06)=>{if(this['currentUser'])_0x11a41d();else{const _0x265899=this['onAuthStateChanged'](()=>{_0x265899(),_0x11a41d();},_0x5dbb06);}});}async['revokeAccessToken'](_0x3f5a8a){if(this['currentUser']){const _0x4d4e1f=await this['currentUser']['getIdToken'](),_0x48d2e0={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3f5a8a,'idToken':_0x4d4e1f};this['tenantId']!=null&&(_0x48d2e0['tenantId']=this['tenantId']),await vf(this,_0x48d2e0);}}['toJSON'](){var _0x39d5a2;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x39d5a2=this['_currentUser'])==null?void 0x0:_0x39d5a2['toJSON']()};}async['_setRedirectUser'](_0x4cb93e,_0x47d0d3){const _0x43573d=await this['getOrInitRedirectPersistenceManager'](_0x47d0d3);return _0x4cb93e===null?_0x43573d['removeCurrentUser']():_0x43573d['setCurrentUser'](_0x4cb93e);}async['getOrInitRedirectPersistenceManager'](_0x2531a4){if(!this['redirectPersistenceManager']){const _0x4c1dfd=_0x2531a4&&ne(_0x2531a4)||this['_popupRedirectResolver'];m(_0x4c1dfd,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4c1dfd['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x207e00){var _0x285a13,_0x1648ff;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x285a13=this['_currentUser'])==null?void 0x0:_0x285a13['_redirectEventId'])===_0x207e00?this['_currentUser']:((_0x1648ff=this['redirectUser'])==null?void 0x0:_0x1648ff['_redirectEventId'])===_0x207e00?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x6ba6d6){if(_0x6ba6d6===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x6ba6d6));}['_notifyListenersIfCurrent'](_0x156371){_0x156371===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x12d62a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4ed85c=((_0x12d62a=this['currentUser'])==null?void 0x0:_0x12d62a['uid'])??null;this['lastNotifiedUid']!==_0x4ed85c&&(this['lastNotifiedUid']=_0x4ed85c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x227a34,_0x153e3a,_0x26adb5,_0x5a6c36){if(this['_deleted'])return()=>{};const _0x28da44=typeof _0x153e3a=='function'?_0x153e3a:_0x153e3a['next']['bind'](_0x153e3a);let _0x20cf6d=!0x1;const _0x222deb=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x222deb,this,'internal-error'),_0x222deb['then'](()=>{_0x20cf6d||_0x28da44(this['currentUser']);}),typeof _0x153e3a=='function'){const _0x6d6e68=_0x227a34['addObserver'](_0x153e3a,_0x26adb5,_0x5a6c36);return()=>{_0x20cf6d=!0x0,_0x6d6e68();};}else{const _0x177e13=_0x227a34['addObserver'](_0x153e3a);return()=>{_0x20cf6d=!0x0,_0x177e13();};}}async['directlySetCurrentUser'](_0x22edf3){this['currentUser']&&this['currentUser']!==_0x22edf3&&this['_currentUser']['_stopProactiveRefresh'](),_0x22edf3&&this['isProactiveRefreshEnabled']&&_0x22edf3['_startProactiveRefresh'](),this['currentUser']=_0x22edf3,_0x22edf3?await this['assertedPersistence']['setCurrentUser'](_0x22edf3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2667a3){return this['operations']=this['operations']['then'](_0x2667a3,_0x2667a3),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x7a5aeb){!_0x7a5aeb||this['frameworks']['includes'](_0x7a5aeb)||(this['frameworks']['push'](_0x7a5aeb),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1ac4d6;const _0x3efe65={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3efe65['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x760a8d=await((_0x1ac4d6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1ac4d6['getHeartbeatsHeader']());_0x760a8d&&(_0x3efe65['X-Firebase-Client']=_0x760a8d);const _0x21cbfc=await this['_getAppCheckToken']();return _0x21cbfc&&(_0x3efe65['X-Firebase-AppCheck']=_0x21cbfc),_0x3efe65;}async['_getAppCheckToken'](){var _0xb252cc;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1d2426=await((_0xb252cc=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xb252cc['getToken']());return _0x1d2426!=null&&_0x1d2426['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1d2426['error']),_0x1d2426==null?void 0x0:_0x1d2426['token'];}}function qe(_0x45f702){return k(_0x45f702);}class Tr{constructor(_0x194846){this['auth']=_0x194846,this['observer']=null,this['addObserver']=Ic(_0x525485=>this['observer']=_0x525485);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x36dd34){zn=_0x36dd34;}function Da(_0x207944){return zn['loadJS'](_0x207944);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x180d2){return'__'+_0x180d2+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x673537){_0x673537();}['execute'](_0x38f8bb,_0x38dccd){return Promise['resolve']('token');}['render'](_0x5c7c7d,_0x30632d){return'';}}class Of{['ready'](_0x2e0e34){_0x2e0e34();}['execute'](_0x2e01bd,_0x160f78){return Promise['resolve']('token');}['render'](_0x148bf6,_0x35e7f3){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x442662){this['type']=Df,this['auth']=qe(_0x442662);}async['verify'](_0x182e9c='verify',_0x132f1c=!0x1){async function _0xddfb(_0x2390cb){if(!_0x132f1c){if(_0x2390cb['tenantId']==null&&_0x2390cb['_agentRecaptchaConfig']!=null)return _0x2390cb['_agentRecaptchaConfig']['siteKey'];if(_0x2390cb['tenantId']!=null&&_0x2390cb['_tenantRecaptchaConfigs'][_0x2390cb['tenantId']]!==void 0x0)return _0x2390cb['_tenantRecaptchaConfigs'][_0x2390cb['tenantId']]['siteKey'];}return new Promise(async(_0x45d0dd,_0x1127f5)=>{uf(_0x2390cb,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4ac594=>{if(_0x4ac594['recaptchaKey']===void 0x0)_0x1127f5(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x235ad6=new hf(_0x4ac594);return _0x2390cb['tenantId']==null?_0x2390cb['_agentRecaptchaConfig']=_0x235ad6:_0x2390cb['_tenantRecaptchaConfigs'][_0x2390cb['tenantId']]=_0x235ad6,_0x45d0dd(_0x235ad6['siteKey']);}})['catch'](_0x93113=>{_0x1127f5(_0x93113);});});}function _0x3d9c3d(_0x3b0b8d,_0x4dbc5d,_0xdbc908){const _0x3cd37f=window['grecaptcha'];vr(_0x3cd37f)?_0x3cd37f['enterprise']['ready'](()=>{_0x3cd37f['enterprise']['execute'](_0x3b0b8d,{'action':_0x182e9c})['then'](_0x32adb4=>{_0x4dbc5d(_0x32adb4);})['catch'](()=>{_0x4dbc5d(Ma);});}):_0xdbc908(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x598714,_0x6cd61d)=>{_0xddfb(this['auth'])['then'](async _0x3149fc=>{if(!_0x132f1c&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3d9c3d(_0x3149fc,_0x598714,_0x6cd61d);else{if(typeof window>'u'){_0x6cd61d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4f8f05=Af();_0x4f8f05['length']!==0x0&&(_0x4f8f05+=_0x3149fc+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x41e723;(_0x41e723=le['scriptInjectionDeferred'])==null||_0x41e723['resolve']();},Da(_0x4f8f05)['then'](()=>{var _0x5212bc;return(_0x5212bc=le['scriptInjectionDeferred'])==null?void 0x0:_0x5212bc['promise'];})['then'](()=>{_0x3d9c3d(_0x3149fc,_0x598714,_0x6cd61d);})['catch'](_0x17de1e=>{_0x6cd61d(_0x17de1e);});}})['catch'](_0xec865=>{_0x6cd61d(_0xec865);});});}}le['scriptInjectionDeferred']=null;async function br(_0x550b1b,_0x49fccf,_0x1debf7,_0x3b8c85=!0x1,_0x496fa5=!0x1){const _0x4120ca=new le(_0x550b1b);let _0x2ef1de;if(_0x496fa5)_0x2ef1de=Ma;else try{_0x2ef1de=await _0x4120ca['verify'](_0x1debf7);}catch{_0x2ef1de=await _0x4120ca['verify'](_0x1debf7,!0x0);}const _0x39ba16={..._0x49fccf};if(_0x1debf7==='mfaSmsEnrollment'||_0x1debf7==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x39ba16){const _0x285380=_0x39ba16['phoneEnrollmentInfo']['phoneNumber'],_0x148601=_0x39ba16['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x39ba16,{'phoneEnrollmentInfo':{'phoneNumber':_0x285380,'recaptchaToken':_0x148601,'captchaResponse':_0x2ef1de,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x39ba16){const _0x4c44a8=_0x39ba16['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x39ba16,{'phoneSignInInfo':{'recaptchaToken':_0x4c44a8,'captchaResponse':_0x2ef1de,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x39ba16;}return _0x3b8c85?Object['assign'](_0x39ba16,{'captchaResp':_0x2ef1de}):Object['assign'](_0x39ba16,{'captchaResponse':_0x2ef1de}),Object['assign'](_0x39ba16,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x39ba16,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x39ba16;}async function Oi(_0x5ac72c,_0x4497a4,_0x167625,_0x5ed271,_0x255141){var _0x542137;if((_0x542137=_0x5ac72c['_getRecaptchaConfig']())!=null&&_0x542137['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3b6946=await br(_0x5ac72c,_0x4497a4,_0x167625,_0x167625==='getOobCode');return _0x5ed271(_0x5ac72c,_0x3b6946);}else return _0x5ed271(_0x5ac72c,_0x4497a4)['catch'](async _0x30c12b=>{if(_0x30c12b['code']==='auth/missing-recaptcha-token'){console['log'](_0x167625+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x14558d=await br(_0x5ac72c,_0x4497a4,_0x167625,_0x167625==='getOobCode');return _0x5ed271(_0x5ac72c,_0x14558d);}else return Promise['reject'](_0x30c12b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x2757ef,_0x432ff7){const _0x2bc3a1=Ui(_0x2757ef,'auth');if(_0x2bc3a1['isInitialized']()){const _0x1ae48c=_0x2bc3a1['getImmediate'](),_0x27fdf0=_0x2bc3a1['getOptions']();if(De(_0x27fdf0,_0x432ff7??{}))return _0x1ae48c;K(_0x1ae48c,'already-initialized');}return _0x2bc3a1['initialize']({'options':_0x432ff7});}function Lf(_0x22ad47,_0xcb4e92){const _0x46bff7=(_0xcb4e92==null?void 0x0:_0xcb4e92['persistence'])||[],_0x5eb8e5=(Array['isArray'](_0x46bff7)?_0x46bff7:[_0x46bff7])['map'](ne);_0xcb4e92!=null&&_0xcb4e92['errorMap']&&_0x22ad47['_updateErrorMap'](_0xcb4e92['errorMap']),_0x22ad47['_initializeWithPersistence'](_0x5eb8e5,_0xcb4e92==null?void 0x0:_0xcb4e92['popupRedirectResolver']);}function xf(_0x9006a7,_0x274fd2,_0x4e598c){const _0x47545a=qe(_0x9006a7);m(/^https?:\/\//['test'](_0x274fd2),_0x47545a,'invalid-emulator-scheme');const _0x2ffd56=!0x1,_0xca0c17=La(_0x274fd2),{host:_0xac6960,port:_0x5593c0}=Ff(_0x274fd2),_0x580a0e=_0x5593c0===null?'':':'+_0x5593c0,_0xd4933b={'url':_0xca0c17+'//'+_0xac6960+_0x580a0e+'/'},_0x54e973=Object['freeze']({'host':_0xac6960,'port':_0x5593c0,'protocol':_0xca0c17['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2ffd56})});if(!_0x47545a['_canInitEmulator']){m(_0x47545a['config']['emulator']&&_0x47545a['emulatorConfig'],_0x47545a,'emulator-config-failed'),m(De(_0xd4933b,_0x47545a['config']['emulator'])&&De(_0x54e973,_0x47545a['emulatorConfig']),_0x47545a,'emulator-config-failed');return;}_0x47545a['config']['emulator']=_0xd4933b,_0x47545a['emulatorConfig']=_0x54e973,_0x47545a['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0xac6960)?jr(_0xca0c17+'//'+_0xac6960+_0x580a0e):Uf();}function La(_0x36c28a){const _0x4105d0=_0x36c28a['indexOf'](':');return _0x4105d0<0x0?'':_0x36c28a['substr'](0x0,_0x4105d0+0x1);}function Ff(_0x2fe3a5){const _0x24dec3=La(_0x2fe3a5),_0x2ce1c6=/(\/\/)?([^?#/]+)/['exec'](_0x2fe3a5['substr'](_0x24dec3['length']));if(!_0x2ce1c6)return{'host':'','port':null};const _0xea649a=_0x2ce1c6[0x2]['split']('@')['pop']()||'',_0x303330=/^(\[[^\]]+\])(:|$)/['exec'](_0xea649a);if(_0x303330){const _0xfc997c=_0x303330[0x1];return{'host':_0xfc997c,'port':Rr(_0xea649a['substr'](_0xfc997c['length']+0x1))};}else{const [_0x27f49f,_0x427eba]=_0xea649a['split'](':');return{'host':_0x27f49f,'port':Rr(_0x427eba)};}}function Rr(_0x2283b9){if(!_0x2283b9)return null;const _0x4ea59f=Number(_0x2283b9);return isNaN(_0x4ea59f)?null:_0x4ea59f;}function Uf(){function _0x24d636(){const _0x8d8f2b=document['createElement']('p'),_0x76f55d=_0x8d8f2b['style'];_0x8d8f2b['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x76f55d['position']='fixed',_0x76f55d['width']='100%',_0x76f55d['backgroundColor']='#ffffff',_0x76f55d['border']='.1em\x20solid\x20#000000',_0x76f55d['color']='#b50000',_0x76f55d['bottom']='0px',_0x76f55d['left']='0px',_0x76f55d['margin']='0px',_0x76f55d['zIndex']='10000',_0x76f55d['textAlign']='center',_0x8d8f2b['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x8d8f2b);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x24d636):_0x24d636());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x503fb3,_0x496590){this['providerId']=_0x503fb3,this['signInMethod']=_0x496590;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x37e64a){return te('not\x20implemented');}['_linkToIdToken'](_0x48ff6c,_0xbdd10d){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x55bebe){return te('not\x20implemented');}}async function Wf(_0x1b5194,_0x1954cd){return Ae(_0x1b5194,'POST','/v1/accounts:signUp',_0x1954cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x4b3564,_0x48af70){return Yt(_0x4b3564,'POST','/v1/accounts:signInWithPassword',Re(_0x4b3564,_0x48af70));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x1b7f1e,_0x531739){return Yt(_0x1b7f1e,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1b7f1e,_0x531739));}async function Hf(_0x43589d,_0x56c365){return Yt(_0x43589d,'POST','/v1/accounts:signInWithEmailLink',Re(_0x43589d,_0x56c365));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x29c755,_0x271d6c,_0x441fbd,_0x1e6257=null){super('password',_0x441fbd),this['_email']=_0x29c755,this['_password']=_0x271d6c,this['_tenantId']=_0x1e6257;}static['_fromEmailAndPassword'](_0x365830,_0x3d1b1b){return new Ft(_0x365830,_0x3d1b1b,'password');}static['_fromEmailAndCode'](_0xd82670,_0x5a9ffc,_0x39be69=null){return new Ft(_0xd82670,_0x5a9ffc,'emailLink',_0x39be69);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1c0fcf){const _0x193b8f=typeof _0x1c0fcf=='string'?JSON['parse'](_0x1c0fcf):_0x1c0fcf;if(_0x193b8f!=null&&_0x193b8f['email']&&(_0x193b8f!=null&&_0x193b8f['password'])){if(_0x193b8f['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x193b8f['email'],_0x193b8f['password']);if(_0x193b8f['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x193b8f['email'],_0x193b8f['password'],_0x193b8f['tenantId']);}return null;}async['_getIdTokenResponse'](_0x16cd70){switch(this['signInMethod']){case'password':const _0x1aa127={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x16cd70,_0x1aa127,'signInWithPassword',Bf);case'emailLink':return Vf(_0x16cd70,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x16cd70,'internal-error');}}async['_linkToIdToken'](_0x56b793,_0x5787fe){switch(this['signInMethod']){case'password':const _0x2bf4e5={'idToken':_0x5787fe,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x56b793,_0x2bf4e5,'signUpPassword',Wf);case'emailLink':return Hf(_0x56b793,{'idToken':_0x5787fe,'email':this['_email'],'oobCode':this['_password']});default:K(_0x56b793,'internal-error');}}['_getReauthenticationResolver'](_0x1a69a3){return this['_getIdTokenResponse'](_0x1a69a3);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x22f77c,_0x41b55b){return Yt(_0x22f77c,'POST','/v1/accounts:signInWithIdp',Re(_0x22f77c,_0x41b55b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x13ec15){const _0x36c07a=new We(_0x13ec15['providerId'],_0x13ec15['signInMethod']);return _0x13ec15['idToken']||_0x13ec15['accessToken']?(_0x13ec15['idToken']&&(_0x36c07a['idToken']=_0x13ec15['idToken']),_0x13ec15['accessToken']&&(_0x36c07a['accessToken']=_0x13ec15['accessToken']),_0x13ec15['nonce']&&!_0x13ec15['pendingToken']&&(_0x36c07a['nonce']=_0x13ec15['nonce']),_0x13ec15['pendingToken']&&(_0x36c07a['pendingToken']=_0x13ec15['pendingToken'])):_0x13ec15['oauthToken']&&_0x13ec15['oauthTokenSecret']?(_0x36c07a['accessToken']=_0x13ec15['oauthToken'],_0x36c07a['secret']=_0x13ec15['oauthTokenSecret']):K('argument-error'),_0x36c07a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x51cedf){const _0x458253=typeof _0x51cedf=='string'?JSON['parse'](_0x51cedf):_0x51cedf,{providerId:_0x3d1b19,signInMethod:_0x34baeb,..._0x53ec3b}=_0x458253;if(!_0x3d1b19||!_0x34baeb)return null;const _0x3333bf=new We(_0x3d1b19,_0x34baeb);return _0x3333bf['idToken']=_0x53ec3b['idToken']||void 0x0,_0x3333bf['accessToken']=_0x53ec3b['accessToken']||void 0x0,_0x3333bf['secret']=_0x53ec3b['secret'],_0x3333bf['nonce']=_0x53ec3b['nonce'],_0x3333bf['pendingToken']=_0x53ec3b['pendingToken']||null,_0x3333bf;}['_getIdTokenResponse'](_0xc316c2){const _0x564383=this['buildRequest']();return Ze(_0xc316c2,_0x564383);}['_linkToIdToken'](_0x357ff5,_0x5a6878){const _0x41a9fc=this['buildRequest']();return _0x41a9fc['idToken']=_0x5a6878,Ze(_0x357ff5,_0x41a9fc);}['_getReauthenticationResolver'](_0x1163d2){const _0x3d0675=this['buildRequest']();return _0x3d0675['autoCreate']=!0x1,Ze(_0x1163d2,_0x3d0675);}['buildRequest'](){const _0x20bbfc={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x20bbfc['pendingToken']=this['pendingToken'];else{const _0x337b57={};this['idToken']&&(_0x337b57['id_token']=this['idToken']),this['accessToken']&&(_0x337b57['access_token']=this['accessToken']),this['secret']&&(_0x337b57['oauth_token_secret']=this['secret']),_0x337b57['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x337b57['nonce']=this['nonce']),_0x20bbfc['postBody']=at(_0x337b57);}return _0x20bbfc;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x474860){switch(_0x474860){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x13cdfd){const _0x290359=yt(vt(_0x13cdfd))['link'],_0x881c45=_0x290359?yt(vt(_0x290359))['deep_link_id']:null,_0x4bf338=yt(vt(_0x13cdfd))['deep_link_id'];return(_0x4bf338?yt(vt(_0x4bf338))['link']:null)||_0x4bf338||_0x881c45||_0x290359||_0x13cdfd;}class Ss{constructor(_0xdda8ae){const _0x26ac8a=yt(vt(_0xdda8ae)),_0xac6748=_0x26ac8a['apiKey']??null,_0x56fcc8=_0x26ac8a['oobCode']??null,_0x5c64b0=Gf(_0x26ac8a['mode']??null);m(_0xac6748&&_0x56fcc8&&_0x5c64b0,'argument-error'),this['apiKey']=_0xac6748,this['operation']=_0x5c64b0,this['code']=_0x56fcc8,this['continueUrl']=_0x26ac8a['continueUrl']??null,this['languageCode']=_0x26ac8a['lang']??null,this['tenantId']=_0x26ac8a['tenantId']??null;}static['parseLink'](_0x155bfa){const _0x2d7ffd=qf(_0x155bfa);try{return new Ss(_0x2d7ffd);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0xcd2892,_0x130175){return Ft['_fromEmailAndPassword'](_0xcd2892,_0x130175);}static['credentialWithLink'](_0x7ed2ee,_0x3ebfeb){const _0x33c340=Ss['parseLink'](_0x3ebfeb);return m(_0x33c340,'argument-error'),Ft['_fromEmailAndCode'](_0x7ed2ee,_0x33c340['code'],_0x33c340['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x1d6080){this['providerId']=_0x1d6080,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xabf8ab){this['defaultLanguageCode']=_0xabf8ab;}['setCustomParameters'](_0x20602c){return this['customParameters']=_0x20602c,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x14befb){return this['scopes']['includes'](_0x14befb)||this['scopes']['push'](_0x14befb),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x32c3b7){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x32c3b7});}static['credentialFromResult'](_0x15720f){return he['credentialFromTaggedObject'](_0x15720f);}static['credentialFromError'](_0x546752){return he['credentialFromTaggedObject'](_0x546752['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5b9a47}){if(!_0x5b9a47||!('oauthAccessToken'in _0x5b9a47)||!_0x5b9a47['oauthAccessToken'])return null;try{return he['credential'](_0x5b9a47['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xd21318,_0x1ec46c){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xd21318,'accessToken':_0x1ec46c});}static['credentialFromResult'](_0x2da4a8){return ue['credentialFromTaggedObject'](_0x2da4a8);}static['credentialFromError'](_0x594dcd){return ue['credentialFromTaggedObject'](_0x594dcd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30513c}){if(!_0x30513c)return null;const {oauthIdToken:_0x1bc107,oauthAccessToken:_0x19d335}=_0x30513c;if(!_0x1bc107&&!_0x19d335)return null;try{return ue['credential'](_0x1bc107,_0x19d335);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x2d4a02){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2d4a02});}static['credentialFromResult'](_0xba5e3a){return de['credentialFromTaggedObject'](_0xba5e3a);}static['credentialFromError'](_0x76571f){return de['credentialFromTaggedObject'](_0x76571f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x15bf5b}){if(!_0x15bf5b||!('oauthAccessToken'in _0x15bf5b)||!_0x15bf5b['oauthAccessToken'])return null;try{return de['credential'](_0x15bf5b['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x274e37,_0x377532){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x274e37,'oauthTokenSecret':_0x377532});}static['credentialFromResult'](_0x2e727f){return fe['credentialFromTaggedObject'](_0x2e727f);}static['credentialFromError'](_0x32a7ab){return fe['credentialFromTaggedObject'](_0x32a7ab['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x6439ac}){if(!_0x6439ac)return null;const {oauthAccessToken:_0x50ac44,oauthTokenSecret:_0x25593a}=_0x6439ac;if(!_0x50ac44||!_0x25593a)return null;try{return fe['credential'](_0x50ac44,_0x25593a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x9a8cde,_0x34ba92){return Yt(_0x9a8cde,'POST','/v1/accounts:signUp',Re(_0x9a8cde,_0x34ba92));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x308129){this['user']=_0x308129['user'],this['providerId']=_0x308129['providerId'],this['_tokenResponse']=_0x308129['_tokenResponse'],this['operationType']=_0x308129['operationType'];}static async['_fromIdTokenResponse'](_0x1d1419,_0x45f4dc,_0x309b42,_0x532f77=!0x1){const _0x312cfc=await z['_fromIdTokenResponse'](_0x1d1419,_0x309b42,_0x532f77),_0xf0d941=Ar(_0x309b42);return new Be({'user':_0x312cfc,'providerId':_0xf0d941,'_tokenResponse':_0x309b42,'operationType':_0x45f4dc});}static async['_forOperation'](_0xbaa5e1,_0x4c2977,_0x46aff3){await _0xbaa5e1['_updateTokensIfNecessary'](_0x46aff3,!0x0);const _0x504193=Ar(_0x46aff3);return new Be({'user':_0xbaa5e1,'providerId':_0x504193,'_tokenResponse':_0x46aff3,'operationType':_0x4c2977});}}function Ar(_0x33c989){return _0x33c989['providerId']?_0x33c989['providerId']:'phoneNumber'in _0x33c989?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x3d855e,_0x50ebe3,_0x5dd0ae,_0x36bcc9){super(_0x50ebe3['code'],_0x50ebe3['message']),this['operationType']=_0x5dd0ae,this['user']=_0x36bcc9,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x3d855e['name'],'tenantId':_0x3d855e['tenantId']??void 0x0,'_serverResponse':_0x50ebe3['customData']['_serverResponse'],'operationType':_0x5dd0ae};}static['_fromErrorAndOperation'](_0x2ecd7e,_0x365974,_0x272a82,_0xf9148e){return new Rn(_0x2ecd7e,_0x365974,_0x272a82,_0xf9148e);}}function Fa(_0x2aef24,_0x430dfb,_0x507d86,_0x41eae8){return(_0x430dfb==='reauthenticate'?_0x507d86['_getReauthenticationResolver'](_0x2aef24):_0x507d86['_getIdTokenResponse'](_0x2aef24))['catch'](_0x396cf2=>{throw _0x396cf2['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x2aef24,_0x396cf2,_0x430dfb,_0x41eae8):_0x396cf2;});}async function jf(_0x1b0c38,_0xa35db8,_0x13ecff=!0x1){const _0x416330=await xt(_0x1b0c38,_0xa35db8['_linkToIdToken'](_0x1b0c38['auth'],await _0x1b0c38['getIdToken']()),_0x13ecff);return Be['_forOperation'](_0x1b0c38,'link',_0x416330);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4fb07a,_0x1b99a9,_0x2b8482=!0x1){const {auth:_0x3cbd17}=_0x4fb07a;if(H(_0x3cbd17['app']))return Promise['reject'](se(_0x3cbd17));const _0x425c02='reauthenticate';try{const _0x5e65b8=await xt(_0x4fb07a,Fa(_0x3cbd17,_0x425c02,_0x1b99a9,_0x4fb07a),_0x2b8482);m(_0x5e65b8['idToken'],_0x3cbd17,'internal-error');const _0xf9926a=ws(_0x5e65b8['idToken']);m(_0xf9926a,_0x3cbd17,'internal-error');const {sub:_0x4ef46d}=_0xf9926a;return m(_0x4fb07a['uid']===_0x4ef46d,_0x3cbd17,'user-mismatch'),Be['_forOperation'](_0x4fb07a,_0x425c02,_0x5e65b8);}catch(_0x2954b5){throw(_0x2954b5==null?void 0x0:_0x2954b5['code'])==='auth/user-not-found'&&K(_0x3cbd17,'user-mismatch'),_0x2954b5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x332134,_0x22ddcd,_0x1c3165=!0x1){if(H(_0x332134['app']))return Promise['reject'](se(_0x332134));const _0x1fb3fb='signIn',_0x35a553=await Fa(_0x332134,_0x1fb3fb,_0x22ddcd),_0x128b28=await Be['_fromIdTokenResponse'](_0x332134,_0x1fb3fb,_0x35a553);return _0x1c3165||await _0x332134['_updateCurrentUser'](_0x128b28['user']),_0x128b28;}async function Yf(_0x502bef,_0x477558){return Ua(qe(_0x502bef),_0x477558);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x426670){const _0x340b32=qe(_0x426670);_0x340b32['_getPasswordPolicyInternal']()&&await _0x340b32['_updatePasswordPolicy']();}async function R_(_0x156eb3,_0x471b13,_0x11833f){if(H(_0x156eb3['app']))return Promise['reject'](se(_0x156eb3));const _0x3cd536=qe(_0x156eb3),_0x5e13b8=await Oi(_0x3cd536,{'returnSecureToken':!0x0,'email':_0x471b13,'password':_0x11833f,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3de968=>{throw _0x3de968['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x156eb3),_0x3de968;}),_0x21f001=await Be['_fromIdTokenResponse'](_0x3cd536,'signIn',_0x5e13b8);return await _0x3cd536['_updateCurrentUser'](_0x21f001['user']),_0x21f001;}function A_(_0x2587de,_0x226917,_0x37b61b){return H(_0x2587de['app'])?Promise['reject'](se(_0x2587de)):Yf(k(_0x2587de),ft['credential'](_0x226917,_0x37b61b))['catch'](async _0x397ffa=>{throw _0x397ffa['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2587de),_0x397ffa;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x74ab35,_0x578393){return k(_0x74ab35)['setPersistence'](_0x578393);}function Qf(_0x3ea108,_0x32c71c,_0x344ac7,_0x24174d){return k(_0x3ea108)['onIdTokenChanged'](_0x32c71c,_0x344ac7,_0x24174d);}function Jf(_0x2d8d6f,_0x2a6e20,_0x636820){return k(_0x2d8d6f)['beforeAuthStateChanged'](_0x2a6e20,_0x636820);}function N_(_0x416a65,_0x2bce78,_0x37b539,_0x54f872){return k(_0x416a65)['onAuthStateChanged'](_0x2bce78,_0x37b539,_0x54f872);}function P_(_0x196a6f){return k(_0x196a6f)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x83733,_0x3b7027){this['storageRetriever']=_0x83733,this['type']=_0x3b7027;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x270288,_0xa90b47){return this['storage']['setItem'](_0x270288,JSON['stringify'](_0xa90b47)),Promise['resolve']();}['_get'](_0x24063f){const _0x213dd7=this['storage']['getItem'](_0x24063f);return Promise['resolve'](_0x213dd7?JSON['parse'](_0x213dd7):null);}['_remove'](_0x445fe8){return this['storage']['removeItem'](_0x445fe8),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x28b4c2,_0x1ad9ae)=>this['onStorageEvent'](_0x28b4c2,_0x1ad9ae),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x98a13c){for(const _0x22bc20 of Object['keys'](this['listeners'])){const _0x936bad=this['storage']['getItem'](_0x22bc20),_0x589f44=this['localCache'][_0x22bc20];_0x936bad!==_0x589f44&&_0x98a13c(_0x22bc20,_0x589f44,_0x936bad);}}['onStorageEvent'](_0x5aad48,_0x41c0b9=!0x1){if(!_0x5aad48['key']){this['forAllChangedKeys']((_0x399000,_0x5c2e91,_0x41aef6)=>{this['notifyListeners'](_0x399000,_0x41aef6);});return;}const _0x5ba5c8=_0x5aad48['key'];_0x41c0b9?this['detachListener']():this['stopPolling']();const _0x4962e1=()=>{const _0x234428=this['storage']['getItem'](_0x5ba5c8);!_0x41c0b9&&this['localCache'][_0x5ba5c8]===_0x234428||this['notifyListeners'](_0x5ba5c8,_0x234428);},_0x2396ee=this['storage']['getItem'](_0x5ba5c8);If()&&_0x2396ee!==_0x5aad48['newValue']&&_0x5aad48['newValue']!==_0x5aad48['oldValue']?setTimeout(_0x4962e1,Zf):_0x4962e1();}['notifyListeners'](_0x3e1550,_0x109d2c){this['localCache'][_0x3e1550]=_0x109d2c;const _0x45fff4=this['listeners'][_0x3e1550];if(_0x45fff4){for(const _0x1864f6 of Array['from'](_0x45fff4))_0x1864f6(_0x109d2c&&JSON['parse'](_0x109d2c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4754f6,_0x5844af,_0xc8f3af)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4754f6,'oldValue':_0x5844af,'newValue':_0xc8f3af}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x11e685,_0x57d4ee){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x11e685]||(this['listeners'][_0x11e685]=new Set(),this['localCache'][_0x11e685]=this['storage']['getItem'](_0x11e685)),this['listeners'][_0x11e685]['add'](_0x57d4ee);}['_removeListener'](_0x3e5c00,_0x596958){this['listeners'][_0x3e5c00]&&(this['listeners'][_0x3e5c00]['delete'](_0x596958),this['listeners'][_0x3e5c00]['size']===0x0&&delete this['listeners'][_0x3e5c00]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4d320a,_0x5a9fe7){await super['_set'](_0x4d320a,_0x5a9fe7),this['localCache'][_0x4d320a]=JSON['stringify'](_0x5a9fe7);}async['_get'](_0x2c2be7){const _0x3f2aa3=await super['_get'](_0x2c2be7);return this['localCache'][_0x2c2be7]=JSON['stringify'](_0x3f2aa3),_0x3f2aa3;}async['_remove'](_0x759a1a){await super['_remove'](_0x759a1a),delete this['localCache'][_0x759a1a];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xc1fe52,_0x3c7735){}['_removeListener'](_0x1f6343,_0x2593a5){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1b4265){return Promise['all'](_0x1b4265['map'](async _0x468b0d=>{try{return{'fulfilled':!0x0,'value':await _0x468b0d};}catch(_0x489a8e){return{'fulfilled':!0x1,'reason':_0x489a8e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x560406){this['eventTarget']=_0x560406,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1d5a1f){const _0x32642c=this['receivers']['find'](_0x37600e=>_0x37600e['isListeningto'](_0x1d5a1f));if(_0x32642c)return _0x32642c;const _0x3ffd23=new jn(_0x1d5a1f);return this['receivers']['push'](_0x3ffd23),_0x3ffd23;}['isListeningto'](_0x5a1d41){return this['eventTarget']===_0x5a1d41;}async['handleEvent'](_0x738ff2){const _0x35c4b0=_0x738ff2,{eventId:_0x4b9d77,eventType:_0xc7dc1e,data:_0xa5951c}=_0x35c4b0['data'],_0x48dafa=this['handlersMap'][_0xc7dc1e];if(!(_0x48dafa!=null&&_0x48dafa['size']))return;_0x35c4b0['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4b9d77,'eventType':_0xc7dc1e});const _0x5ab47d=Array['from'](_0x48dafa)['map'](async _0x3e67f5=>_0x3e67f5(_0x35c4b0['origin'],_0xa5951c)),_0x15fb0a=await tp(_0x5ab47d);_0x35c4b0['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4b9d77,'eventType':_0xc7dc1e,'response':_0x15fb0a});}['_subscribe'](_0x449abf,_0x5cb710){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x449abf]||(this['handlersMap'][_0x449abf]=new Set()),this['handlersMap'][_0x449abf]['add'](_0x5cb710);}['_unsubscribe'](_0x98ed6,_0x263ea6){this['handlersMap'][_0x98ed6]&&_0x263ea6&&this['handlersMap'][_0x98ed6]['delete'](_0x263ea6),(!_0x263ea6||this['handlersMap'][_0x98ed6]['size']===0x0)&&delete this['handlersMap'][_0x98ed6],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x3f50e7='',_0x462e22=0xa){let _0x1eb13f='';for(let _0x2f66fd=0x0;_0x2f66fd<_0x462e22;_0x2f66fd++)_0x1eb13f+=Math['floor'](Math['random']()*0xa);return _0x3f50e7+_0x1eb13f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x406fa4){this['target']=_0x406fa4,this['handlers']=new Set();}['removeMessageHandler'](_0x4766b4){_0x4766b4['messageChannel']&&(_0x4766b4['messageChannel']['port1']['removeEventListener']('message',_0x4766b4['onMessage']),_0x4766b4['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4766b4);}async['_send'](_0x23d74a,_0x3b4d15,_0x3c2a03=0x32){const _0x40ad16=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x40ad16)throw new Error('connection_unavailable');let _0x48d570,_0x192ee9;return new Promise((_0x2a06f1,_0x5bcd55)=>{const _0x19b458=bs('',0x14);_0x40ad16['port1']['start']();const _0x4724a3=setTimeout(()=>{_0x5bcd55(new Error('unsupported_event'));},_0x3c2a03);_0x192ee9={'messageChannel':_0x40ad16,'onMessage'(_0x3860b3){const _0x57e163=_0x3860b3;if(_0x57e163['data']['eventId']===_0x19b458)switch(_0x57e163['data']['status']){case'ack':clearTimeout(_0x4724a3),_0x48d570=setTimeout(()=>{_0x5bcd55(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x48d570),_0x2a06f1(_0x57e163['data']['response']);break;default:clearTimeout(_0x4724a3),clearTimeout(_0x48d570),_0x5bcd55(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x192ee9),_0x40ad16['port1']['addEventListener']('message',_0x192ee9['onMessage']),this['target']['postMessage']({'eventType':_0x23d74a,'eventId':_0x19b458,'data':_0x3b4d15},[_0x40ad16['port2']]);})['finally'](()=>{_0x192ee9&&this['removeMessageHandler'](_0x192ee9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x143a81){X()['location']['href']=_0x143a81;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x34d099;return((_0x34d099=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x34d099['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x54706c){this['request']=_0x54706c;}['toPromise'](){return new Promise((_0x11c083,_0x47ed64)=>{this['request']['addEventListener']('success',()=>{_0x11c083(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x47ed64(this['request']['error']);});});}}function Kn(_0x1d502b,_0x53e967){return _0x1d502b['transaction']([kn],_0x53e967?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5464f5=indexedDB['deleteDatabase'](qa);return new Jt(_0x5464f5)['toPromise']();}function ja(){const _0x406d68=indexedDB['open'](qa,ap);return new Promise((_0x4eaac4,_0x39fddb)=>{_0x406d68['addEventListener']('error',()=>{_0x39fddb(_0x406d68['error']);}),_0x406d68['addEventListener']('upgradeneeded',()=>{const _0x229e01=_0x406d68['result'];try{_0x229e01['createObjectStore'](kn,{'keyPath':za});}catch(_0x20965b){_0x39fddb(_0x20965b);}}),_0x406d68['addEventListener']('success',async()=>{const _0xfaa02a=_0x406d68['result'];_0xfaa02a['objectStoreNames']['contains'](kn)?_0x4eaac4(_0xfaa02a):(_0xfaa02a['close'](),await cp(),_0x4eaac4(await ja()));});});}async function kr(_0x5d5443,_0x59dcc3,_0xe58eb){const _0x1d0e23=Kn(_0x5d5443,!0x0)['put']({[za]:_0x59dcc3,'value':_0xe58eb});return new Jt(_0x1d0e23)['toPromise']();}async function lp(_0x2e5672,_0x4a48a0){const _0x178a0a=Kn(_0x2e5672,!0x1)['get'](_0x4a48a0),_0x13910f=await new Jt(_0x178a0a)['toPromise']();return _0x13910f===void 0x0?null:_0x13910f['value'];}function Nr(_0x193fc9,_0xee8691){const _0x5783e8=Kn(_0x193fc9,!0x0)['delete'](_0xee8691);return new Jt(_0x5783e8)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x242731){let _0x175e95=0x0;for(;;)try{const _0xf99430=await this['_openDb']();return await _0x242731(_0xf99430);}catch(_0x2e6ad5){if(_0x175e95++>up)throw _0x2e6ad5;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1fa794,_0x255ee7)=>({'keyProcessed':(await this['_poll']())['includes'](_0x255ee7['key'])})),this['receiver']['_subscribe']('ping',async(_0x36e304,_0x16f5f4)=>['keyChanged']);}async['initializeSender'](){var _0x382232,_0x345249;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x3c2b82=await this['sender']['_send']('ping',{},0x320);_0x3c2b82&&(_0x382232=_0x3c2b82[0x0])!=null&&_0x382232['fulfilled']&&(_0x345249=_0x3c2b82[0x0])!=null&&_0x345249['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x201718){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x201718},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5b540d=>{await kr(_0x5b540d,An,'1'),await Nr(_0x5b540d,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4aab0b){this['pendingWrites']++;try{await _0x4aab0b();}finally{this['pendingWrites']--;}}async['_set'](_0x548fcf,_0x1bfb8f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x179c1c=>kr(_0x179c1c,_0x548fcf,_0x1bfb8f)),this['localCache'][_0x548fcf]=_0x1bfb8f,this['notifyServiceWorker'](_0x548fcf)));}async['_get'](_0x270df9){const _0x3c990e=await this['_withRetries'](_0x5ae13d=>lp(_0x5ae13d,_0x270df9));return this['localCache'][_0x270df9]=_0x3c990e,_0x3c990e;}async['_remove'](_0x555bd1){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x35e54e=>Nr(_0x35e54e,_0x555bd1)),delete this['localCache'][_0x555bd1],this['notifyServiceWorker'](_0x555bd1)));}async['_poll'](){const _0x2616f0=await this['_withRetries'](_0x128340=>{const _0x55c644=Kn(_0x128340,!0x1)['getAll']();return new Jt(_0x55c644)['toPromise']();});if(!_0x2616f0)return[];if(this['pendingWrites']!==0x0)return[];const _0x48d8e0=[],_0x1f2e85=new Set();if(_0x2616f0['length']!==0x0){for(const {fbase_key:_0x2ffb99,value:_0x26ca17}of _0x2616f0)_0x1f2e85['add'](_0x2ffb99),JSON['stringify'](this['localCache'][_0x2ffb99])!==JSON['stringify'](_0x26ca17)&&(this['notifyListeners'](_0x2ffb99,_0x26ca17),_0x48d8e0['push'](_0x2ffb99));}for(const _0x443f4b of Object['keys'](this['localCache']))this['localCache'][_0x443f4b]&&!_0x1f2e85['has'](_0x443f4b)&&(this['notifyListeners'](_0x443f4b,null),_0x48d8e0['push'](_0x443f4b));return _0x48d8e0;}['notifyListeners'](_0x55f46d,_0x5a0917){this['localCache'][_0x55f46d]=_0x5a0917;const _0xc9efa3=this['listeners'][_0x55f46d];if(_0xc9efa3){for(const _0x111c44 of Array['from'](_0xc9efa3))_0x111c44(_0x5a0917);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x59c279,_0x132ce8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x59c279]||(this['listeners'][_0x59c279]=new Set(),this['_get'](_0x59c279)),this['listeners'][_0x59c279]['add'](_0x132ce8);}['_removeListener'](_0xbd0e50,_0x1d1fdf){this['listeners'][_0xbd0e50]&&(this['listeners'][_0xbd0e50]['delete'](_0x1d1fdf),this['listeners'][_0xbd0e50]['size']===0x0&&delete this['listeners'][_0xbd0e50]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x4971d1,_0x5c0477){return _0x5c0477?ne(_0x5c0477):(m(_0x4971d1['_popupRedirectResolver'],_0x4971d1,'argument-error'),_0x4971d1['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x239548){super('custom','custom'),this['params']=_0x239548;}['_getIdTokenResponse'](_0x4d1952){return Ze(_0x4d1952,this['_buildIdpRequest']());}['_linkToIdToken'](_0x202ba2,_0x2eb423){return Ze(_0x202ba2,this['_buildIdpRequest'](_0x2eb423));}['_getReauthenticationResolver'](_0x49704e){return Ze(_0x49704e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4290fe){const _0xe4c27c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4290fe&&(_0xe4c27c['idToken']=_0x4290fe),_0xe4c27c;}}function pp(_0x1f7ff5){return Ua(_0x1f7ff5['auth'],new Rs(_0x1f7ff5),_0x1f7ff5['bypassAuthState']);}function _p(_0x48e63d){const {auth:_0x4fb92d,user:_0x5c9691}=_0x48e63d;return m(_0x5c9691,_0x4fb92d,'internal-error'),Kf(_0x5c9691,new Rs(_0x48e63d),_0x48e63d['bypassAuthState']);}async function gp(_0x3bfc95){const {auth:_0x4fe545,user:_0xdd120}=_0x3bfc95;return m(_0xdd120,_0x4fe545,'internal-error'),jf(_0xdd120,new Rs(_0x3bfc95),_0x3bfc95['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x58a700,_0x52538d,_0x4b4860,_0x1b905b,_0x32aa9f=!0x1){this['auth']=_0x58a700,this['resolver']=_0x4b4860,this['user']=_0x1b905b,this['bypassAuthState']=_0x32aa9f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x52538d)?_0x52538d:[_0x52538d];}['execute'](){return new Promise(async(_0x3d1df7,_0x3df9fd)=>{this['pendingPromise']={'resolve':_0x3d1df7,'reject':_0x3df9fd};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2eaa5d){this['reject'](_0x2eaa5d);}});}async['onAuthEvent'](_0x427d10){const {urlResponse:_0x3666ab,sessionId:_0x4d92d5,postBody:_0x30ffcb,tenantId:_0x2ec751,error:_0x52d48a,type:_0x3cf0ab}=_0x427d10;if(_0x52d48a){this['reject'](_0x52d48a);return;}const _0x1e0f3a={'auth':this['auth'],'requestUri':_0x3666ab,'sessionId':_0x4d92d5,'tenantId':_0x2ec751||void 0x0,'postBody':_0x30ffcb||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3cf0ab)(_0x1e0f3a));}catch(_0x49a212){this['reject'](_0x49a212);}}['onError'](_0x411a39){this['reject'](_0x411a39);}['getIdpTask'](_0x117b02){switch(_0x117b02){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x4a285a){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4a285a),this['unregisterAndCleanUp']();}['reject'](_0x2d1088){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2d1088),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0xdced72,_0x5074e1,_0x246a19,_0x16c1f7,_0x29b524){super(_0xdced72,_0x5074e1,_0x16c1f7,_0x29b524),this['provider']=_0x246a19,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x34a66b=await this['execute']();return m(_0x34a66b,this['auth'],'internal-error'),_0x34a66b;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x30df55=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x30df55),this['authWindow']['associatedEvent']=_0x30df55,this['resolver']['_originValidation'](this['auth'])['catch'](_0xb62fa8=>{this['reject'](_0xb62fa8);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x48df58=>{_0x48df58||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5e6fcc;return((_0x5e6fcc=this['authWindow'])==null?void 0x0:_0x5e6fcc['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x44b0d6=()=>{var _0x352d8e,_0x40c0be;if((_0x40c0be=(_0x352d8e=this['authWindow'])==null?void 0x0:_0x352d8e['window'])!=null&&_0x40c0be['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x44b0d6,mp['get']());};_0x44b0d6();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x3f0a42,_0x1c066a,_0xaaabb9=!0x1){super(_0x3f0a42,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1c066a,void 0x0,_0xaaabb9),this['eventId']=null;}async['execute'](){let _0x5dcb6b=rn['get'](this['auth']['_key']());if(!_0x5dcb6b){try{const _0x53ab46=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5dcb6b=()=>Promise['resolve'](_0x53ab46);}catch(_0xccf49d){_0x5dcb6b=()=>Promise['reject'](_0xccf49d);}rn['set'](this['auth']['_key'](),_0x5dcb6b);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5dcb6b();}async['onAuthEvent'](_0x16d552){if(_0x16d552['type']==='signInViaRedirect')return super['onAuthEvent'](_0x16d552);if(_0x16d552['type']==='unknown'){this['resolve'](null);return;}if(_0x16d552['eventId']){const _0x249b59=await this['auth']['_redirectUserForId'](_0x16d552['eventId']);if(_0x249b59)return this['user']=_0x249b59,super['onAuthEvent'](_0x16d552);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x5c8fb0,_0x303d53){const _0x1aff69=Cp(_0x303d53),_0x30d3dd=wp(_0x5c8fb0);if(!await _0x30d3dd['_isAvailable']())return!0x1;const _0x1483f1=await _0x30d3dd['_get'](_0x1aff69)==='true';return await _0x30d3dd['_remove'](_0x1aff69),_0x1483f1;}function Ip(_0x18f74f,_0x2ad581){rn['set'](_0x18f74f['_key'](),_0x2ad581);}function wp(_0x43e49b){return ne(_0x43e49b['_redirectPersistence']);}function Cp(_0x41904f){return sn(yp,_0x41904f['config']['apiKey'],_0x41904f['name']);}async function Tp(_0x35e8fd,_0x199efa,_0x20f0ec=!0x1){if(H(_0x35e8fd['app']))return Promise['reject'](se(_0x35e8fd));const _0x5d9ae8=qe(_0x35e8fd),_0x39ccfa=fp(_0x5d9ae8,_0x199efa),_0x167bdc=await new vp(_0x5d9ae8,_0x39ccfa,_0x20f0ec)['execute']();return _0x167bdc&&!_0x20f0ec&&(delete _0x167bdc['user']['_redirectEventId'],await _0x5d9ae8['_persistUserIfCurrent'](_0x167bdc['user']),await _0x5d9ae8['_setRedirectUser'](null,_0x199efa)),_0x167bdc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x151328){this['auth']=_0x151328,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xf45d8c){this['consumers']['add'](_0xf45d8c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xf45d8c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xf45d8c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3a8a30){this['consumers']['delete'](_0x3a8a30);}['onEvent'](_0x1f56a4){if(this['hasEventBeenHandled'](_0x1f56a4))return!0x1;let _0x58528a=!0x1;return this['consumers']['forEach'](_0x593537=>{this['isEventForConsumer'](_0x1f56a4,_0x593537)&&(_0x58528a=!0x0,this['sendToConsumer'](_0x1f56a4,_0x593537),this['saveEventToCache'](_0x1f56a4));}),this['hasHandledPotentialRedirect']||!Rp(_0x1f56a4)||(this['hasHandledPotentialRedirect']=!0x0,_0x58528a||(this['queuedRedirectEvent']=_0x1f56a4,_0x58528a=!0x0)),_0x58528a;}['sendToConsumer'](_0x400739,_0x5489e3){var _0x473865;if(_0x400739['error']&&!Qa(_0x400739)){const _0xb0fd57=((_0x473865=_0x400739['error']['code'])==null?void 0x0:_0x473865['split']('auth/')[0x1])||'internal-error';_0x5489e3['onError'](J(this['auth'],_0xb0fd57));}else _0x5489e3['onAuthEvent'](_0x400739);}['isEventForConsumer'](_0x25789d,_0x1c5ddb){const _0x4a7175=_0x1c5ddb['eventId']===null||!!_0x25789d['eventId']&&_0x25789d['eventId']===_0x1c5ddb['eventId'];return _0x1c5ddb['filter']['includes'](_0x25789d['type'])&&_0x4a7175;}['hasEventBeenHandled'](_0x571231){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x571231));}['saveEventToCache'](_0x7f32f8){this['cachedEventUids']['add'](Pr(_0x7f32f8)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x1066a8){return[_0x1066a8['type'],_0x1066a8['eventId'],_0x1066a8['sessionId'],_0x1066a8['tenantId']]['filter'](_0x496a29=>_0x496a29)['join']('-');}function Qa({type:_0x399520,error:_0x497e18}){return _0x399520==='unknown'&&(_0x497e18==null?void 0x0:_0x497e18['code'])==='auth/no-auth-event';}function Rp(_0x2f4a18){switch(_0x2f4a18['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x2f4a18);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4ace2e,_0x2d9808={}){return Ae(_0x4ace2e,'GET','/v1/projects',_0x2d9808);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x4e76fa){if(_0x4e76fa['config']['emulator'])return;const {authorizedDomains:_0x18e6a6}=await Ap(_0x4e76fa);for(const _0x1b5802 of _0x18e6a6)try{if(Op(_0x1b5802))return;}catch{}K(_0x4e76fa,'unauthorized-domain');}function Op(_0x52cc00){const _0x49acc2=Ni(),{protocol:_0x41dfe8,hostname:_0x3022af}=new URL(_0x49acc2);if(_0x52cc00['startsWith']('chrome-extension://')){const _0xdb6fad=new URL(_0x52cc00);return _0xdb6fad['hostname']===''&&_0x3022af===''?_0x41dfe8==='chrome-extension:'&&_0x52cc00['replace']('chrome-extension://','')===_0x49acc2['replace']('chrome-extension://',''):_0x41dfe8==='chrome-extension:'&&_0xdb6fad['hostname']===_0x3022af;}if(!Np['test'](_0x41dfe8))return!0x1;if(kp['test'](_0x52cc00))return _0x3022af===_0x52cc00;const _0x45ad0d=_0x52cc00['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x45ad0d+'|'+_0x45ad0d+')$','i')['test'](_0x3022af);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x2e5a57=X()['___jsl'];if(_0x2e5a57!=null&&_0x2e5a57['H']){for(const _0x125bfe of Object['keys'](_0x2e5a57['H']))if(_0x2e5a57['H'][_0x125bfe]['r']=_0x2e5a57['H'][_0x125bfe]['r']||[],_0x2e5a57['H'][_0x125bfe]['L']=_0x2e5a57['H'][_0x125bfe]['L']||[],_0x2e5a57['H'][_0x125bfe]['r']=[..._0x2e5a57['H'][_0x125bfe]['L']],_0x2e5a57['CP']){for(let _0xf17ca4=0x0;_0xf17ca4<_0x2e5a57['CP']['length'];_0xf17ca4++)_0x2e5a57['CP'][_0xf17ca4]=null;}}}function Mp(_0x4b294d){return new Promise((_0x3293fd,_0x3cc823)=>{var _0x1879d5,_0x4f9fb6,_0x121e62;function _0x3b8434(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3293fd(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x3cc823(J(_0x4b294d,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x4f9fb6=(_0x1879d5=X()['gapi'])==null?void 0x0:_0x1879d5['iframes'])!=null&&_0x4f9fb6['Iframe'])_0x3293fd(gapi['iframes']['getContext']());else{if((_0x121e62=X()['gapi'])!=null&&_0x121e62['load'])_0x3b8434();else{const _0x2b792f=Nf('iframefcb');return X()[_0x2b792f]=()=>{gapi['load']?_0x3b8434():_0x3cc823(J(_0x4b294d,'network-request-failed'));},Da(kf()+'?onload='+_0x2b792f)['catch'](_0x58f23d=>_0x3cc823(_0x58f23d));}}})['catch'](_0x3635cf=>{throw on=null,_0x3635cf;});}let on=null;function Lp(_0x2de258){return on=on||Mp(_0x2de258),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x4944a6){const _0x2dde59=_0x4944a6['config'];m(_0x2dde59['authDomain'],_0x4944a6,'auth-domain-config-required');const _0x43b1dd=_0x2dde59['emulator']?Is(_0x2dde59,Up):'https://'+_0x4944a6['config']['authDomain']+'/'+Fp,_0x3f240f={'apiKey':_0x2dde59['apiKey'],'appName':_0x4944a6['name'],'v':ct},_0x1f45a0=Bp['get'](_0x4944a6['config']['apiHost']);_0x1f45a0&&(_0x3f240f['eid']=_0x1f45a0);const _0x34f38c=_0x4944a6['_getFrameworks']();return _0x34f38c['length']&&(_0x3f240f['fw']=_0x34f38c['join'](',')),_0x43b1dd+'?'+at(_0x3f240f)['slice'](0x1);}async function Hp(_0x8595c6){const _0x1e405d=await Lp(_0x8595c6),_0x55d068=X()['gapi'];return m(_0x55d068,_0x8595c6,'internal-error'),_0x1e405d['open']({'where':document['body'],'url':Vp(_0x8595c6),'messageHandlersFilter':_0x55d068['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x166114=>new Promise(async(_0x21d034,_0x4489aa)=>{await _0x166114['restyle']({'setHideOnLeave':!0x1});const _0x4ee086=J(_0x8595c6,'network-request-failed'),_0x2a1d98=X()['setTimeout'](()=>{_0x4489aa(_0x4ee086);},xp['get']());function _0x20e5b2(){X()['clearTimeout'](_0x2a1d98),_0x21d034(_0x166114);}_0x166114['ping'](_0x20e5b2)['then'](_0x20e5b2,()=>{_0x4489aa(_0x4ee086);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x21b789){this['window']=_0x21b789,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x48e0d9,_0x61c68,_0x3f5a08,_0x1da01d=Gp,_0x447e2b=qp){const _0xbfd349=Math['max']((window['screen']['availHeight']-_0x447e2b)/0x2,0x0)['toString'](),_0x38bb85=Math['max']((window['screen']['availWidth']-_0x1da01d)/0x2,0x0)['toString']();let _0x325b51='';const _0x53410f={...$p,'width':_0x1da01d['toString'](),'height':_0x447e2b['toString'](),'top':_0xbfd349,'left':_0x38bb85},_0xf30330=W()['toLowerCase']();_0x3f5a08&&(_0x325b51=ba(_0xf30330)?zp:_0x3f5a08),Ta(_0xf30330)&&(_0x61c68=_0x61c68||jp,_0x53410f['scrollbars']='yes');const _0x335ad6=Object['entries'](_0x53410f)['reduce']((_0x254e10,[_0x2c6046,_0x1ef01d])=>''+_0x254e10+_0x2c6046+'='+_0x1ef01d+',','');if(Ef(_0xf30330)&&_0x325b51!=='_self')return Yp(_0x61c68||'',_0x325b51),new Dr(null);const _0x4a3421=window['open'](_0x61c68||'',_0x325b51,_0x335ad6);m(_0x4a3421,_0x48e0d9,'popup-blocked');try{_0x4a3421['focus']();}catch{}return new Dr(_0x4a3421);}function Yp(_0x4c2bc7,_0x42f9c3){const _0x38660d=document['createElement']('a');_0x38660d['href']=_0x4c2bc7,_0x38660d['target']=_0x42f9c3;const _0x539af2=document['createEvent']('MouseEvent');_0x539af2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x38660d['dispatchEvent'](_0x539af2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x310ec5,_0x37b8c7,_0x1e7996,_0x4d25c0,_0x3cf8cb,_0x3b9496){m(_0x310ec5['config']['authDomain'],_0x310ec5,'auth-domain-config-required'),m(_0x310ec5['config']['apiKey'],_0x310ec5,'invalid-api-key');const _0x532b44={'apiKey':_0x310ec5['config']['apiKey'],'appName':_0x310ec5['name'],'authType':_0x1e7996,'redirectUrl':_0x4d25c0,'v':ct,'eventId':_0x3cf8cb};if(_0x37b8c7 instanceof xa){_0x37b8c7['setDefaultLanguage'](_0x310ec5['languageCode']),_0x532b44['providerId']=_0x37b8c7['providerId']||'',hi(_0x37b8c7['getCustomParameters']())||(_0x532b44['customParameters']=JSON['stringify'](_0x37b8c7['getCustomParameters']()));for(const [_0x1ea6dd,_0x2694b2]of Object['entries']({}))_0x532b44[_0x1ea6dd]=_0x2694b2;}if(_0x37b8c7 instanceof Qt){const _0x5fff71=_0x37b8c7['getScopes']()['filter'](_0x500ca2=>_0x500ca2!=='');_0x5fff71['length']>0x0&&(_0x532b44['scopes']=_0x5fff71['join'](','));}_0x310ec5['tenantId']&&(_0x532b44['tid']=_0x310ec5['tenantId']);const _0x2870f8=_0x532b44;for(const _0x47da09 of Object['keys'](_0x2870f8))_0x2870f8[_0x47da09]===void 0x0&&delete _0x2870f8[_0x47da09];const _0x6c28d1=await _0x310ec5['_getAppCheckToken'](),_0x4ea4ed=_0x6c28d1?'#'+Xp+'='+encodeURIComponent(_0x6c28d1):'';return Zp(_0x310ec5)+'?'+at(_0x2870f8)['slice'](0x1)+_0x4ea4ed;}function Zp({config:_0x1dc4b1}){return _0x1dc4b1['emulator']?Is(_0x1dc4b1,Jp):'https://'+_0x1dc4b1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x99a44f,_0x9fc5cf,_0x23b700,_0x3143b7){var _0x521008;ae((_0x521008=this['eventManagers'][_0x99a44f['_key']()])==null?void 0x0:_0x521008['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4a717c=await Mr(_0x99a44f,_0x9fc5cf,_0x23b700,Ni(),_0x3143b7);return Kp(_0x99a44f,_0x4a717c,bs());}async['_openRedirect'](_0x38c18a,_0x3136a3,_0x19d22b,_0x39fc0c){await this['_originValidation'](_0x38c18a);const _0xdf4f0e=await Mr(_0x38c18a,_0x3136a3,_0x19d22b,Ni(),_0x39fc0c);return ip(_0xdf4f0e),new Promise(()=>{});}['_initialize'](_0x93fea5){const _0x532888=_0x93fea5['_key']();if(this['eventManagers'][_0x532888]){const {manager:_0x4fcfcf,promise:_0x136761}=this['eventManagers'][_0x532888];return _0x4fcfcf?Promise['resolve'](_0x4fcfcf):(ae(_0x136761,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x136761);}const _0x3d1eb0=this['initAndGetManager'](_0x93fea5);return this['eventManagers'][_0x532888]={'promise':_0x3d1eb0},_0x3d1eb0['catch'](()=>{delete this['eventManagers'][_0x532888];}),_0x3d1eb0;}async['initAndGetManager'](_0x24d983){const _0x419d00=await Hp(_0x24d983),_0x3318d2=new bp(_0x24d983);return _0x419d00['register']('authEvent',_0x4b3fee=>(m(_0x4b3fee==null?void 0x0:_0x4b3fee['authEvent'],_0x24d983,'invalid-auth-event'),{'status':_0x3318d2['onEvent'](_0x4b3fee['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x24d983['_key']()]={'manager':_0x3318d2},this['iframes'][_0x24d983['_key']()]=_0x419d00,_0x3318d2;}['_isIframeWebStorageSupported'](_0x5927c8,_0x20d8fc){this['iframes'][_0x5927c8['_key']()]['send'](li,{'type':li},_0x4219ab=>{var _0x5e0b6c;const _0x170a48=(_0x5e0b6c=_0x4219ab==null?void 0x0:_0x4219ab[0x0])==null?void 0x0:_0x5e0b6c[li];_0x170a48!==void 0x0&&_0x20d8fc(!!_0x170a48),K(_0x5927c8,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4d11f5){const _0x4ace39=_0x4d11f5['_key']();return this['originValidationPromises'][_0x4ace39]||(this['originValidationPromises'][_0x4ace39]=Pp(_0x4d11f5)),this['originValidationPromises'][_0x4ace39];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x51ea19){this['auth']=_0x51ea19,this['internalListeners']=new Map();}['getUid'](){var _0x59d43a;return this['assertAuthConfigured'](),((_0x59d43a=this['auth']['currentUser'])==null?void 0x0:_0x59d43a['uid'])||null;}async['getToken'](_0x4f5749){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4f5749)}:null;}['addAuthTokenListener'](_0x2db7b7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2db7b7))return;const _0x2908e7=this['auth']['onIdTokenChanged'](_0x138ee3=>{_0x2db7b7((_0x138ee3==null?void 0x0:_0x138ee3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2db7b7,_0x2908e7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xbae682){this['assertAuthConfigured']();const _0x3c32f5=this['internalListeners']['get'](_0xbae682);_0x3c32f5&&(this['internalListeners']['delete'](_0xbae682),_0x3c32f5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x21fb14){switch(_0x21fb14){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3e3b3d){et(new Me('auth',(_0x3fde28,{options:_0x5a75e1})=>{const _0x91104f=_0x3fde28['getProvider']('app')['getImmediate'](),_0x5e8d0c=_0x3fde28['getProvider']('heartbeat'),_0xaaf363=_0x3fde28['getProvider']('app-check-internal'),{apiKey:_0x697f97,authDomain:_0xc96994}=_0x91104f['options'];m(_0x697f97&&!_0x697f97['includes'](':'),'invalid-api-key',{'appName':_0x91104f['name']});const _0x1b4bd7={'apiKey':_0x697f97,'authDomain':_0xc96994,'clientPlatform':_0x3e3b3d,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3e3b3d)},_0xc9d0f5=new bf(_0x91104f,_0x5e8d0c,_0xaaf363,_0x1b4bd7);return Lf(_0xc9d0f5,_0x5a75e1),_0xc9d0f5;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x4974ba,_0x269d24,_0x3e5b61)=>{_0x4974ba['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x206468=>{const _0x5d07d0=qe(_0x206468['getProvider']('auth')['getImmediate']());return(_0x435e42=>new n_(_0x435e42))(_0x5d07d0);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3e3b3d)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x49218e=>async _0x5647b1=>{const _0x43c426=_0x5647b1&&await _0x5647b1['getIdTokenResult'](),_0x5e68ad=_0x43c426&&(new Date()['getTime']()-Date['parse'](_0x43c426['issuedAtTime']))/0x3e8;if(_0x5e68ad&&_0x5e68ad>o_)return;const _0x53aca2=_0x43c426==null?void 0x0:_0x43c426['token'];Fr!==_0x53aca2&&(Fr=_0x53aca2,await fetch(_0x49218e,{'method':_0x53aca2?'POST':'DELETE','headers':_0x53aca2?{'Authorization':'Bearer\x20'+_0x53aca2}:{}}));};function O_(_0x47910c=Qr()){const _0x4d098c=Ui(_0x47910c,'auth');if(_0x4d098c['isInitialized']())return _0x4d098c['getImmediate']();const _0xead113=Mf(_0x47910c,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4d9dde=Gr('authTokenSyncURL');if(_0x4d9dde&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5c3828=new URL(_0x4d9dde,location['origin']);if(location['origin']===_0x5c3828['origin']){const _0x52ade7=a_(_0x5c3828['toString']());Jf(_0xead113,_0x52ade7,()=>_0x52ade7(_0xead113['currentUser'])),Qf(_0xead113,_0x4471b9=>_0x52ade7(_0x4471b9));}}const _0xfca6e3=Hr('auth');return _0xfca6e3&&xf(_0xead113,'http://'+_0xfca6e3),_0xead113;}function c_(){var _0x3ca783;return((_0x3ca783=document['getElementsByTagName']('head'))==null?void 0x0:_0x3ca783[0x0])??document;}Rf({'loadJS'(_0xe3b583){return new Promise((_0x4d6abf,_0x33e801)=>{const _0x54a092=document['createElement']('script');_0x54a092['setAttribute']('src',_0xe3b583),_0x54a092['onload']=_0x4d6abf,_0x54a092['onerror']=_0x19229d=>{const _0x13b164=J('internal-error');_0x13b164['customData']=_0x19229d,_0x33e801(_0x13b164);},_0x54a092['type']='text/javascript',_0x54a092['charset']='UTF-8',c_()['appendChild'](_0x54a092);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};