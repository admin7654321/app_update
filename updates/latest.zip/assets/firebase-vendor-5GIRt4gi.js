const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5785a0,_0x35ecda){if(!_0x5785a0)throw ot(_0x35ecda);},ot=function(_0x3e7ee9){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3e7ee9);},Wr=function(_0x4521b5){const _0x19a79a=[];let _0x5beb14=0x0;for(let _0x3a2c0c=0x0;_0x3a2c0c<_0x4521b5['length'];_0x3a2c0c++){let _0x3c023a=_0x4521b5['charCodeAt'](_0x3a2c0c);_0x3c023a<0x80?_0x19a79a[_0x5beb14++]=_0x3c023a:_0x3c023a<0x800?(_0x19a79a[_0x5beb14++]=_0x3c023a>>0x6|0xc0,_0x19a79a[_0x5beb14++]=_0x3c023a&0x3f|0x80):(_0x3c023a&0xfc00)===0xd800&&_0x3a2c0c+0x1<_0x4521b5['length']&&(_0x4521b5['charCodeAt'](_0x3a2c0c+0x1)&0xfc00)===0xdc00?(_0x3c023a=0x10000+((_0x3c023a&0x3ff)<<0xa)+(_0x4521b5['charCodeAt'](++_0x3a2c0c)&0x3ff),_0x19a79a[_0x5beb14++]=_0x3c023a>>0x12|0xf0,_0x19a79a[_0x5beb14++]=_0x3c023a>>0xc&0x3f|0x80,_0x19a79a[_0x5beb14++]=_0x3c023a>>0x6&0x3f|0x80,_0x19a79a[_0x5beb14++]=_0x3c023a&0x3f|0x80):(_0x19a79a[_0x5beb14++]=_0x3c023a>>0xc|0xe0,_0x19a79a[_0x5beb14++]=_0x3c023a>>0x6&0x3f|0x80,_0x19a79a[_0x5beb14++]=_0x3c023a&0x3f|0x80);}return _0x19a79a;},Za=function(_0x43c351){const _0x5d3318=[];let _0x2e0b29=0x0,_0x44443d=0x0;for(;_0x2e0b29<_0x43c351['length'];){const _0x563990=_0x43c351[_0x2e0b29++];if(_0x563990<0x80)_0x5d3318[_0x44443d++]=String['fromCharCode'](_0x563990);else{if(_0x563990>0xbf&&_0x563990<0xe0){const _0x556470=_0x43c351[_0x2e0b29++];_0x5d3318[_0x44443d++]=String['fromCharCode']((_0x563990&0x1f)<<0x6|_0x556470&0x3f);}else{if(_0x563990>0xef&&_0x563990<0x16d){const _0x1dc3b3=_0x43c351[_0x2e0b29++],_0x31378d=_0x43c351[_0x2e0b29++],_0x7d8a24=_0x43c351[_0x2e0b29++],_0x188f4e=((_0x563990&0x7)<<0x12|(_0x1dc3b3&0x3f)<<0xc|(_0x31378d&0x3f)<<0x6|_0x7d8a24&0x3f)-0x10000;_0x5d3318[_0x44443d++]=String['fromCharCode'](0xd800+(_0x188f4e>>0xa)),_0x5d3318[_0x44443d++]=String['fromCharCode'](0xdc00+(_0x188f4e&0x3ff));}else{const _0x442a46=_0x43c351[_0x2e0b29++],_0x3fe632=_0x43c351[_0x2e0b29++];_0x5d3318[_0x44443d++]=String['fromCharCode']((_0x563990&0xf)<<0xc|(_0x442a46&0x3f)<<0x6|_0x3fe632&0x3f);}}}}return _0x5d3318['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x332bd2,_0x4678ba){if(!Array['isArray'](_0x332bd2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3f5ee4=_0x4678ba?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4983f3=[];for(let _0x5de398=0x0;_0x5de398<_0x332bd2['length'];_0x5de398+=0x3){const _0x3e8bf1=_0x332bd2[_0x5de398],_0x216664=_0x5de398+0x1<_0x332bd2['length'],_0x18e2ad=_0x216664?_0x332bd2[_0x5de398+0x1]:0x0,_0x400b1f=_0x5de398+0x2<_0x332bd2['length'],_0x220a4f=_0x400b1f?_0x332bd2[_0x5de398+0x2]:0x0,_0x194ed6=_0x3e8bf1>>0x2,_0x2a59aa=(_0x3e8bf1&0x3)<<0x4|_0x18e2ad>>0x4;let _0x3a91c4=(_0x18e2ad&0xf)<<0x2|_0x220a4f>>0x6,_0x76d498=_0x220a4f&0x3f;_0x400b1f||(_0x76d498=0x40,_0x216664||(_0x3a91c4=0x40)),_0x4983f3['push'](_0x3f5ee4[_0x194ed6],_0x3f5ee4[_0x2a59aa],_0x3f5ee4[_0x3a91c4],_0x3f5ee4[_0x76d498]);}return _0x4983f3['join']('');},'encodeString'(_0x34ae97,_0x3e29c4){return this['HAS_NATIVE_SUPPORT']&&!_0x3e29c4?btoa(_0x34ae97):this['encodeByteArray'](Wr(_0x34ae97),_0x3e29c4);},'decodeString'(_0x566ed9,_0x5df8e2){return this['HAS_NATIVE_SUPPORT']&&!_0x5df8e2?atob(_0x566ed9):Za(this['decodeStringToByteArray'](_0x566ed9,_0x5df8e2));},'decodeStringToByteArray'(_0x3c6dc0,_0x12a51b){this['init_']();const _0x44af81=_0x12a51b?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x36a74e=[];for(let _0x51e4ac=0x0;_0x51e4ac<_0x3c6dc0['length'];){const _0x11188e=_0x44af81[_0x3c6dc0['charAt'](_0x51e4ac++)],_0x535fa2=_0x51e4ac<_0x3c6dc0['length']?_0x44af81[_0x3c6dc0['charAt'](_0x51e4ac)]:0x0;++_0x51e4ac;const _0x43ba1b=_0x51e4ac<_0x3c6dc0['length']?_0x44af81[_0x3c6dc0['charAt'](_0x51e4ac)]:0x40;++_0x51e4ac;const _0x469212=_0x51e4ac<_0x3c6dc0['length']?_0x44af81[_0x3c6dc0['charAt'](_0x51e4ac)]:0x40;if(++_0x51e4ac,_0x11188e==null||_0x535fa2==null||_0x43ba1b==null||_0x469212==null)throw new ec();const _0x344c7c=_0x11188e<<0x2|_0x535fa2>>0x4;if(_0x36a74e['push'](_0x344c7c),_0x43ba1b!==0x40){const _0x529300=_0x535fa2<<0x4&0xf0|_0x43ba1b>>0x2;if(_0x36a74e['push'](_0x529300),_0x469212!==0x40){const _0x422884=_0x43ba1b<<0x6&0xc0|_0x469212;_0x36a74e['push'](_0x422884);}}}return _0x36a74e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x53604d=0x0;_0x53604d<this['ENCODED_VALS']['length'];_0x53604d++)this['byteToCharMap_'][_0x53604d]=this['ENCODED_VALS']['charAt'](_0x53604d),this['charToByteMap_'][this['byteToCharMap_'][_0x53604d]]=_0x53604d,this['byteToCharMapWebSafe_'][_0x53604d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x53604d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x53604d]]=_0x53604d,_0x53604d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x53604d)]=_0x53604d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x53604d)]=_0x53604d);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x532057){const _0x49f98d=Wr(_0x532057);return Di['encodeByteArray'](_0x49f98d,!0x0);},an=function(_0x3316ae){return Br(_0x3316ae)['replace'](/\./g,'');},cn=function(_0x5d31f4){try{return Di['decodeString'](_0x5d31f4,!0x0);}catch(_0x2b1bdd){console['error']('base64Decode\x20failed:\x20',_0x2b1bdd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3dd8fc){return Vr(void 0x0,_0x3dd8fc);}function Vr(_0x3f7df6,_0x11bf56){if(!(_0x11bf56 instanceof Object))return _0x11bf56;switch(_0x11bf56['constructor']){case Date:const _0x577351=_0x11bf56;return new Date(_0x577351['getTime']());case Object:_0x3f7df6===void 0x0&&(_0x3f7df6={});break;case Array:_0x3f7df6=[];break;default:return _0x11bf56;}for(const _0x50a425 in _0x11bf56)!_0x11bf56['hasOwnProperty'](_0x50a425)||!nc(_0x50a425)||(_0x3f7df6[_0x50a425]=Vr(_0x3f7df6[_0x50a425],_0x11bf56[_0x50a425]));return _0x3f7df6;}function nc(_0x4ad82c){return _0x4ad82c!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x27ed8f=As['__FIREBASE_DEFAULTS__'];if(_0x27ed8f)return JSON['parse'](_0x27ed8f);},oc=()=>{if(typeof document>'u')return;let _0x295ae5;try{_0x295ae5=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1d4c84=_0x295ae5&&cn(_0x295ae5[0x1]);return _0x1d4c84&&JSON['parse'](_0x1d4c84);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x268041){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x268041);return;}},Hr=_0x19e756=>{var _0x24c5da,_0x26d7a0;return(_0x26d7a0=(_0x24c5da=Mi())==null?void 0x0:_0x24c5da['emulatorHosts'])==null?void 0x0:_0x26d7a0[_0x19e756];},ac=_0x1f8e8e=>{const _0xe7793f=Hr(_0x1f8e8e);if(!_0xe7793f)return;const _0x140193=_0xe7793f['lastIndexOf'](':');if(_0x140193<=0x0||_0x140193+0x1===_0xe7793f['length'])throw new Error('Invalid\x20host\x20'+_0xe7793f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0xebb2e7=parseInt(_0xe7793f['substring'](_0x140193+0x1),0xa);return _0xe7793f[0x0]==='['?[_0xe7793f['substring'](0x1,_0x140193-0x1),_0xebb2e7]:[_0xe7793f['substring'](0x0,_0x140193),_0xebb2e7];},$r=()=>{var _0x33a908;return(_0x33a908=Mi())==null?void 0x0:_0x33a908['config'];},Gr=_0x2b3219=>{var _0x1bb606;return(_0x1bb606=Mi())==null?void 0x0:_0x1bb606['_'+_0x2b3219];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x39b3e2,_0x8b5741)=>{this['resolve']=_0x39b3e2,this['reject']=_0x8b5741;});}['wrapCallback'](_0x396e57){return(_0x3b9388,_0xa736e3)=>{_0x3b9388?this['reject'](_0x3b9388):this['resolve'](_0xa736e3),typeof _0x396e57=='function'&&(this['promise']['catch'](()=>{}),_0x396e57['length']===0x1?_0x396e57(_0x3b9388):_0x396e57(_0x3b9388,_0xa736e3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x4e46ed,_0x2bd9ba){if(_0x4e46ed['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4df91a={'alg':'none','type':'JWT'},_0x31f0ad=_0x2bd9ba||'demo-project',_0xd3b344=_0x4e46ed['iat']||0x0,_0xc081d0=_0x4e46ed['sub']||_0x4e46ed['user_id'];if(!_0xc081d0)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3c96fe={'iss':'https://securetoken.google.com/'+_0x31f0ad,'aud':_0x31f0ad,'iat':_0xd3b344,'exp':_0xd3b344+0xe10,'auth_time':_0xd3b344,'sub':_0xc081d0,'user_id':_0xc081d0,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4e46ed};return[an(JSON['stringify'](_0x4df91a)),an(JSON['stringify'](_0x3c96fe)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x543679=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x543679=='object'&&_0x543679['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x10b025=W();return _0x10b025['indexOf']('MSIE\x20')>=0x0||_0x10b025['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x440f4f,_0xbbe5b)=>{try{let _0x236337=!0x0;const _0x402de7='validate-browser-context-for-indexeddb-analytics-module',_0xcc174f=self['indexedDB']['open'](_0x402de7);_0xcc174f['onsuccess']=()=>{_0xcc174f['result']['close'](),_0x236337||self['indexedDB']['deleteDatabase'](_0x402de7),_0x440f4f(!0x0);},_0xcc174f['onupgradeneeded']=()=>{_0x236337=!0x1;},_0xcc174f['onerror']=()=>{var _0x9067fd;_0xbbe5b(((_0x9067fd=_0xcc174f['error'])==null?void 0x0:_0x9067fd['message'])||'');};}catch(_0x134af4){_0xbbe5b(_0x134af4);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x45a4c5,_0x3209ff,_0xd1b925){super(_0x3209ff),this['code']=_0x45a4c5,this['customData']=_0xd1b925,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x30b41b,_0x5ea705,_0x22d81b){this['service']=_0x30b41b,this['serviceName']=_0x5ea705,this['errors']=_0x22d81b;}['create'](_0x144ae1,..._0x1f74df){const _0x3fca2e=_0x1f74df[0x0]||{},_0x1c5387=this['service']+'/'+_0x144ae1,_0x14930d=this['errors'][_0x144ae1],_0xa7d5aa=_0x14930d?gc(_0x14930d,_0x3fca2e):'Error',_0x544169=this['serviceName']+':\x20'+_0xa7d5aa+'\x20('+_0x1c5387+').';return new Se(_0x1c5387,_0x544169,_0x3fca2e);}}function gc(_0x446f04,_0x35e22d){return _0x446f04['replace'](mc,(_0x2f7752,_0x9821b5)=>{const _0x5b8037=_0x35e22d[_0x9821b5];return _0x5b8037!=null?String(_0x5b8037):'<'+_0x9821b5+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x227153){return JSON['parse'](_0x227153);}function O(_0x511f5b){return JSON['stringify'](_0x511f5b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xb64aba){let _0x2d2b5={},_0x3a0773={},_0x52a56d={},_0x395ca6='';try{const _0x549dfc=_0xb64aba['split']('.');_0x2d2b5=bt(cn(_0x549dfc[0x0])||''),_0x3a0773=bt(cn(_0x549dfc[0x1])||''),_0x395ca6=_0x549dfc[0x2],_0x52a56d=_0x3a0773['d']||{},delete _0x3a0773['d'];}catch{}return{'header':_0x2d2b5,'claims':_0x3a0773,'data':_0x52a56d,'signature':_0x395ca6};},yc=function(_0x203121){const _0xcd625e=zr(_0x203121),_0x32dddc=_0xcd625e['claims'];return!!_0x32dddc&&typeof _0x32dddc=='object'&&_0x32dddc['hasOwnProperty']('iat');},vc=function(_0x3e3838){const _0x3fac3e=zr(_0x3e3838)['claims'];return typeof _0x3fac3e=='object'&&_0x3fac3e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xbe6ac5,_0x271490){return Object['prototype']['hasOwnProperty']['call'](_0xbe6ac5,_0x271490);}function Oe(_0x8f8abe,_0x32263c){if(Object['prototype']['hasOwnProperty']['call'](_0x8f8abe,_0x32263c))return _0x8f8abe[_0x32263c];}function hi(_0x468fe7){for(const _0x156c40 in _0x468fe7)if(Object['prototype']['hasOwnProperty']['call'](_0x468fe7,_0x156c40))return!0x1;return!0x0;}function ln(_0xab1696,_0x405af1,_0x1da83e){const _0x565534={};for(const _0x50b5df in _0xab1696)Object['prototype']['hasOwnProperty']['call'](_0xab1696,_0x50b5df)&&(_0x565534[_0x50b5df]=_0x405af1['call'](_0x1da83e,_0xab1696[_0x50b5df],_0x50b5df,_0xab1696));return _0x565534;}function De(_0x4b82e9,_0x5b835b){if(_0x4b82e9===_0x5b835b)return!0x0;const _0x5b18c2=Object['keys'](_0x4b82e9),_0x4f78b9=Object['keys'](_0x5b835b);for(const _0x478a74 of _0x5b18c2){if(!_0x4f78b9['includes'](_0x478a74))return!0x1;const _0x578e92=_0x4b82e9[_0x478a74],_0x4dbbb4=_0x5b835b[_0x478a74];if(ks(_0x578e92)&&ks(_0x4dbbb4)){if(!De(_0x578e92,_0x4dbbb4))return!0x1;}else{if(_0x578e92!==_0x4dbbb4)return!0x1;}}for(const _0x586d2b of _0x4f78b9)if(!_0x5b18c2['includes'](_0x586d2b))return!0x1;return!0x0;}function ks(_0x52932e){return _0x52932e!==null&&typeof _0x52932e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1dc1bc){const _0x4b0d2b=[];for(const [_0x3be750,_0x365d16]of Object['entries'](_0x1dc1bc))Array['isArray'](_0x365d16)?_0x365d16['forEach'](_0x39633e=>{_0x4b0d2b['push'](encodeURIComponent(_0x3be750)+'='+encodeURIComponent(_0x39633e));}):_0x4b0d2b['push'](encodeURIComponent(_0x3be750)+'='+encodeURIComponent(_0x365d16));return _0x4b0d2b['length']?'&'+_0x4b0d2b['join']('&'):'';}function yt(_0x34a77f){const _0x41ee62={};return _0x34a77f['replace'](/^\?/,'')['split']('&')['forEach'](_0x12e503=>{if(_0x12e503){const [_0x2a425f,_0x4f63db]=_0x12e503['split']('=');_0x41ee62[decodeURIComponent(_0x2a425f)]=decodeURIComponent(_0x4f63db);}}),_0x41ee62;}function vt(_0x4658be){const _0x266fa7=_0x4658be['indexOf']('?');if(!_0x266fa7)return'';const _0x1a15a6=_0x4658be['indexOf']('#',_0x266fa7);return _0x4658be['substring'](_0x266fa7,_0x1a15a6>0x0?_0x1a15a6:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4860ba=0x1;_0x4860ba<this['blockSize'];++_0x4860ba)this['pad_'][_0x4860ba]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x35e164,_0x541c97){_0x541c97||(_0x541c97=0x0);const _0x2a6a0c=this['W_'];if(typeof _0x35e164=='string'){for(let _0x526960=0x0;_0x526960<0x10;_0x526960++)_0x2a6a0c[_0x526960]=_0x35e164['charCodeAt'](_0x541c97)<<0x18|_0x35e164['charCodeAt'](_0x541c97+0x1)<<0x10|_0x35e164['charCodeAt'](_0x541c97+0x2)<<0x8|_0x35e164['charCodeAt'](_0x541c97+0x3),_0x541c97+=0x4;}else{for(let _0x340b81=0x0;_0x340b81<0x10;_0x340b81++)_0x2a6a0c[_0x340b81]=_0x35e164[_0x541c97]<<0x18|_0x35e164[_0x541c97+0x1]<<0x10|_0x35e164[_0x541c97+0x2]<<0x8|_0x35e164[_0x541c97+0x3],_0x541c97+=0x4;}for(let _0x1fb729=0x10;_0x1fb729<0x50;_0x1fb729++){const _0x1c73ce=_0x2a6a0c[_0x1fb729-0x3]^_0x2a6a0c[_0x1fb729-0x8]^_0x2a6a0c[_0x1fb729-0xe]^_0x2a6a0c[_0x1fb729-0x10];_0x2a6a0c[_0x1fb729]=(_0x1c73ce<<0x1|_0x1c73ce>>>0x1f)&0xffffffff;}let _0x2b77a4=this['chain_'][0x0],_0xb3d0ac=this['chain_'][0x1],_0x52c68e=this['chain_'][0x2],_0x4c397b=this['chain_'][0x3],_0x3dfb30=this['chain_'][0x4],_0x33b340,_0x1c47b0;for(let _0x24f353=0x0;_0x24f353<0x50;_0x24f353++){_0x24f353<0x28?_0x24f353<0x14?(_0x33b340=_0x4c397b^_0xb3d0ac&(_0x52c68e^_0x4c397b),_0x1c47b0=0x5a827999):(_0x33b340=_0xb3d0ac^_0x52c68e^_0x4c397b,_0x1c47b0=0x6ed9eba1):_0x24f353<0x3c?(_0x33b340=_0xb3d0ac&_0x52c68e|_0x4c397b&(_0xb3d0ac|_0x52c68e),_0x1c47b0=0x8f1bbcdc):(_0x33b340=_0xb3d0ac^_0x52c68e^_0x4c397b,_0x1c47b0=0xca62c1d6);const _0x1355d5=(_0x2b77a4<<0x5|_0x2b77a4>>>0x1b)+_0x33b340+_0x3dfb30+_0x1c47b0+_0x2a6a0c[_0x24f353]&0xffffffff;_0x3dfb30=_0x4c397b,_0x4c397b=_0x52c68e,_0x52c68e=(_0xb3d0ac<<0x1e|_0xb3d0ac>>>0x2)&0xffffffff,_0xb3d0ac=_0x2b77a4,_0x2b77a4=_0x1355d5;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2b77a4&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xb3d0ac&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52c68e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4c397b&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3dfb30&0xffffffff;}['update'](_0x335783,_0xc18fd6){if(_0x335783==null)return;_0xc18fd6===void 0x0&&(_0xc18fd6=_0x335783['length']);const _0x1a6e6f=_0xc18fd6-this['blockSize'];let _0x45b8c7=0x0;const _0x154ff1=this['buf_'];let _0x57c790=this['inbuf_'];for(;_0x45b8c7<_0xc18fd6;){if(_0x57c790===0x0){for(;_0x45b8c7<=_0x1a6e6f;)this['compress_'](_0x335783,_0x45b8c7),_0x45b8c7+=this['blockSize'];}if(typeof _0x335783=='string'){for(;_0x45b8c7<_0xc18fd6;)if(_0x154ff1[_0x57c790]=_0x335783['charCodeAt'](_0x45b8c7),++_0x57c790,++_0x45b8c7,_0x57c790===this['blockSize']){this['compress_'](_0x154ff1),_0x57c790=0x0;break;}}else{for(;_0x45b8c7<_0xc18fd6;)if(_0x154ff1[_0x57c790]=_0x335783[_0x45b8c7],++_0x57c790,++_0x45b8c7,_0x57c790===this['blockSize']){this['compress_'](_0x154ff1),_0x57c790=0x0;break;}}}this['inbuf_']=_0x57c790,this['total_']+=_0xc18fd6;}['digest'](){const _0x1f2b2b=[];let _0x3e12b3=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1dc69e=this['blockSize']-0x1;_0x1dc69e>=0x38;_0x1dc69e--)this['buf_'][_0x1dc69e]=_0x3e12b3&0xff,_0x3e12b3/=0x100;this['compress_'](this['buf_']);let _0xdf4f00=0x0;for(let _0xc9cb93=0x0;_0xc9cb93<0x5;_0xc9cb93++)for(let _0x976924=0x18;_0x976924>=0x0;_0x976924-=0x8)_0x1f2b2b[_0xdf4f00]=this['chain_'][_0xc9cb93]>>_0x976924&0xff,++_0xdf4f00;return _0x1f2b2b;}}function Ic(_0x26df71,_0x5205d1){const _0x5976f0=new wc(_0x26df71,_0x5205d1);return _0x5976f0['subscribe']['bind'](_0x5976f0);}class wc{constructor(_0x422516,_0x389696){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x389696,this['task']['then'](()=>{_0x422516(this);})['catch'](_0xf4e92=>{this['error'](_0xf4e92);});}['next'](_0x371d13){this['forEachObserver'](_0x483c3b=>{_0x483c3b['next'](_0x371d13);});}['error'](_0x394789){this['forEachObserver'](_0x5b97c9=>{_0x5b97c9['error'](_0x394789);}),this['close'](_0x394789);}['complete'](){this['forEachObserver'](_0x1cdde9=>{_0x1cdde9['complete']();}),this['close']();}['subscribe'](_0x1e749b,_0x2f9016,_0x23c882){let _0x57fb07;if(_0x1e749b===void 0x0&&_0x2f9016===void 0x0&&_0x23c882===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x1e749b,['next','error','complete'])?_0x57fb07=_0x1e749b:_0x57fb07={'next':_0x1e749b,'error':_0x2f9016,'complete':_0x23c882},_0x57fb07['next']===void 0x0&&(_0x57fb07['next']=Qn),_0x57fb07['error']===void 0x0&&(_0x57fb07['error']=Qn),_0x57fb07['complete']===void 0x0&&(_0x57fb07['complete']=Qn);const _0x25c967=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x57fb07['error'](this['finalError']):_0x57fb07['complete']();}catch{}}),this['observers']['push'](_0x57fb07),_0x25c967;}['unsubscribeOne'](_0x3609e5){this['observers']===void 0x0||this['observers'][_0x3609e5]===void 0x0||(delete this['observers'][_0x3609e5],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x39c17a){if(!this['finalized']){for(let _0x3c6a4e=0x0;_0x3c6a4e<this['observers']['length'];_0x3c6a4e++)this['sendOne'](_0x3c6a4e,_0x39c17a);}}['sendOne'](_0x4f2b81,_0x443986){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4f2b81]!==void 0x0)try{_0x443986(this['observers'][_0x4f2b81]);}catch(_0x58e681){typeof console<'u'&&console['error']&&console['error'](_0x58e681);}});}['close'](_0x3b8a61){this['finalized']||(this['finalized']=!0x0,_0x3b8a61!==void 0x0&&(this['finalError']=_0x3b8a61),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x47fd5c,_0x5669c0){if(typeof _0x47fd5c!='object'||_0x47fd5c===null)return!0x1;for(const _0xe3ae07 of _0x5669c0)if(_0xe3ae07 in _0x47fd5c&&typeof _0x47fd5c[_0xe3ae07]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x132e8d,_0x1ee129){return _0x132e8d+'\x20failed:\x20'+_0x1ee129+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2823f2){const _0x59dc90=[];let _0x46fbae=0x0;for(let _0x421b48=0x0;_0x421b48<_0x2823f2['length'];_0x421b48++){let _0x4bb71e=_0x2823f2['charCodeAt'](_0x421b48);if(_0x4bb71e>=0xd800&&_0x4bb71e<=0xdbff){const _0x32787b=_0x4bb71e-0xd800;_0x421b48++,f(_0x421b48<_0x2823f2['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1ea291=_0x2823f2['charCodeAt'](_0x421b48)-0xdc00;_0x4bb71e=0x10000+(_0x32787b<<0xa)+_0x1ea291;}_0x4bb71e<0x80?_0x59dc90[_0x46fbae++]=_0x4bb71e:_0x4bb71e<0x800?(_0x59dc90[_0x46fbae++]=_0x4bb71e>>0x6|0xc0,_0x59dc90[_0x46fbae++]=_0x4bb71e&0x3f|0x80):_0x4bb71e<0x10000?(_0x59dc90[_0x46fbae++]=_0x4bb71e>>0xc|0xe0,_0x59dc90[_0x46fbae++]=_0x4bb71e>>0x6&0x3f|0x80,_0x59dc90[_0x46fbae++]=_0x4bb71e&0x3f|0x80):(_0x59dc90[_0x46fbae++]=_0x4bb71e>>0x12|0xf0,_0x59dc90[_0x46fbae++]=_0x4bb71e>>0xc&0x3f|0x80,_0x59dc90[_0x46fbae++]=_0x4bb71e>>0x6&0x3f|0x80,_0x59dc90[_0x46fbae++]=_0x4bb71e&0x3f|0x80);}return _0x59dc90;},Pn=function(_0x51350b){let _0x353cb8=0x0;for(let _0x345851=0x0;_0x345851<_0x51350b['length'];_0x345851++){const _0x14133f=_0x51350b['charCodeAt'](_0x345851);_0x14133f<0x80?_0x353cb8++:_0x14133f<0x800?_0x353cb8+=0x2:_0x14133f>=0xd800&&_0x14133f<=0xdbff?(_0x353cb8+=0x4,_0x345851++):_0x353cb8+=0x3;}return _0x353cb8;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x220c99){return _0x220c99&&_0x220c99['_delegate']?_0x220c99['_delegate']:_0x220c99;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x253ed3){try{return(_0x253ed3['startsWith']('http://')||_0x253ed3['startsWith']('https://')?new URL(_0x253ed3)['hostname']:_0x253ed3)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1850ad){return(await fetch(_0x1850ad,{'credentials':'include'}))['ok'];}class Me{constructor(_0x6c55bf,_0x2ac197,_0x509022){this['name']=_0x6c55bf,this['instanceFactory']=_0x2ac197,this['type']=_0x509022,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1e5254){return this['instantiationMode']=_0x1e5254,this;}['setMultipleInstances'](_0x3d7229){return this['multipleInstances']=_0x3d7229,this;}['setServiceProps'](_0x4cad07){return this['serviceProps']=_0x4cad07,this;}['setInstanceCreatedCallback'](_0x3a8415){return this['onInstanceCreated']=_0x3a8415,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x59332c,_0xd2b111){this['name']=_0x59332c,this['container']=_0xd2b111,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4c4dbe){const _0x2f9207=this['normalizeInstanceIdentifier'](_0x4c4dbe);if(!this['instancesDeferred']['has'](_0x2f9207)){const _0x193c21=new Ve();if(this['instancesDeferred']['set'](_0x2f9207,_0x193c21),this['isInitialized'](_0x2f9207)||this['shouldAutoInitialize']())try{const _0x4e7b54=this['getOrInitializeService']({'instanceIdentifier':_0x2f9207});_0x4e7b54&&_0x193c21['resolve'](_0x4e7b54);}catch{}}return this['instancesDeferred']['get'](_0x2f9207)['promise'];}['getImmediate'](_0xada13d){const _0x42c7cb=this['normalizeInstanceIdentifier'](_0xada13d==null?void 0x0:_0xada13d['identifier']),_0x20983e=(_0xada13d==null?void 0x0:_0xada13d['optional'])??!0x1;if(this['isInitialized'](_0x42c7cb)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x42c7cb});}catch(_0x35ba53){if(_0x20983e)return null;throw _0x35ba53;}else{if(_0x20983e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x385ccc){if(_0x385ccc['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x385ccc['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x385ccc,!!this['shouldAutoInitialize']()){if(Rc(_0x385ccc))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0xc3c656,_0x5c238f]of this['instancesDeferred']['entries']()){const _0x3e9079=this['normalizeInstanceIdentifier'](_0xc3c656);try{const _0x286fd3=this['getOrInitializeService']({'instanceIdentifier':_0x3e9079});_0x5c238f['resolve'](_0x286fd3);}catch{}}}}['clearInstance'](_0x5ccf32=ke){this['instancesDeferred']['delete'](_0x5ccf32),this['instancesOptions']['delete'](_0x5ccf32),this['instances']['delete'](_0x5ccf32);}async['delete'](){const _0x54fadc=Array['from'](this['instances']['values']());await Promise['all']([..._0x54fadc['filter'](_0x3eff0a=>'INTERNAL'in _0x3eff0a)['map'](_0x4ced72=>_0x4ced72['INTERNAL']['delete']()),..._0x54fadc['filter'](_0x5b5881=>'_delete'in _0x5b5881)['map'](_0x593fa9=>_0x593fa9['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5ed3a6=ke){return this['instances']['has'](_0x5ed3a6);}['getOptions'](_0x57556a=ke){return this['instancesOptions']['get'](_0x57556a)||{};}['initialize'](_0x22993e={}){const {options:_0x5dfd1b={}}=_0x22993e,_0x5395d5=this['normalizeInstanceIdentifier'](_0x22993e['instanceIdentifier']);if(this['isInitialized'](_0x5395d5))throw Error(this['name']+'('+_0x5395d5+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x20e47d=this['getOrInitializeService']({'instanceIdentifier':_0x5395d5,'options':_0x5dfd1b});for(const [_0x5727a0,_0x4a5835]of this['instancesDeferred']['entries']()){const _0x4ff317=this['normalizeInstanceIdentifier'](_0x5727a0);_0x5395d5===_0x4ff317&&_0x4a5835['resolve'](_0x20e47d);}return _0x20e47d;}['onInit'](_0x3c7c17,_0x1de0c2){const _0x5920ee=this['normalizeInstanceIdentifier'](_0x1de0c2),_0x4f7ce4=this['onInitCallbacks']['get'](_0x5920ee)??new Set();_0x4f7ce4['add'](_0x3c7c17),this['onInitCallbacks']['set'](_0x5920ee,_0x4f7ce4);const _0xa09f51=this['instances']['get'](_0x5920ee);return _0xa09f51&&_0x3c7c17(_0xa09f51,_0x5920ee),()=>{_0x4f7ce4['delete'](_0x3c7c17);};}['invokeOnInitCallbacks'](_0x390a4c,_0x27ae16){const _0x3d0952=this['onInitCallbacks']['get'](_0x27ae16);if(_0x3d0952){for(const _0x22774d of _0x3d0952)try{_0x22774d(_0x390a4c,_0x27ae16);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xc97883,options:_0x3b20ff={}}){let _0x2e9130=this['instances']['get'](_0xc97883);if(!_0x2e9130&&this['component']&&(_0x2e9130=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xc97883),'options':_0x3b20ff}),this['instances']['set'](_0xc97883,_0x2e9130),this['instancesOptions']['set'](_0xc97883,_0x3b20ff),this['invokeOnInitCallbacks'](_0x2e9130,_0xc97883),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xc97883,_0x2e9130);}catch{}return _0x2e9130||null;}['normalizeInstanceIdentifier'](_0x4db1dc=ke){return this['component']?this['component']['multipleInstances']?_0x4db1dc:ke:_0x4db1dc;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x29aeca){return _0x29aeca===ke?void 0x0:_0x29aeca;}function Rc(_0x1928a0){return _0x1928a0['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x208d9f){this['name']=_0x208d9f,this['providers']=new Map();}['addComponent'](_0x223caf){const _0x4be9e1=this['getProvider'](_0x223caf['name']);if(_0x4be9e1['isComponentSet']())throw new Error('Component\x20'+_0x223caf['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4be9e1['setComponent'](_0x223caf);}['addOrOverwriteComponent'](_0x37b2ce){this['getProvider'](_0x37b2ce['name'])['isComponentSet']()&&this['providers']['delete'](_0x37b2ce['name']),this['addComponent'](_0x37b2ce);}['getProvider'](_0x517ce5){if(this['providers']['has'](_0x517ce5))return this['providers']['get'](_0x517ce5);const _0x41df11=new Sc(_0x517ce5,this);return this['providers']['set'](_0x517ce5,_0x41df11),_0x41df11;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x30667a){_0x30667a[_0x30667a['DEBUG']=0x0]='DEBUG',_0x30667a[_0x30667a['VERBOSE']=0x1]='VERBOSE',_0x30667a[_0x30667a['INFO']=0x2]='INFO',_0x30667a[_0x30667a['WARN']=0x3]='WARN',_0x30667a[_0x30667a['ERROR']=0x4]='ERROR',_0x30667a[_0x30667a['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xd2826c,_0x362c4f,..._0x1cbc52)=>{if(_0x362c4f<_0xd2826c['logLevel'])return;const _0x55219c=new Date()['toISOString'](),_0x245790=Pc[_0x362c4f];if(_0x245790)console[_0x245790]('['+_0x55219c+']\x20\x20'+_0xd2826c['name']+':',..._0x1cbc52);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x362c4f+')');};class xi{constructor(_0x260d41){this['name']=_0x260d41,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x38424a){if(!(_0x38424a in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x38424a+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x38424a;}['setLogLevel'](_0x5aeffe){this['_logLevel']=typeof _0x5aeffe=='string'?kc[_0x5aeffe]:_0x5aeffe;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x42bb88){if(typeof _0x42bb88!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x42bb88;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1fd709){this['_userLogHandler']=_0x1fd709;}['debug'](..._0x4043c4){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4043c4),this['_logHandler'](this,T['DEBUG'],..._0x4043c4);}['log'](..._0x31594b){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x31594b),this['_logHandler'](this,T['VERBOSE'],..._0x31594b);}['info'](..._0x284bfd){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x284bfd),this['_logHandler'](this,T['INFO'],..._0x284bfd);}['warn'](..._0x3004f1){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3004f1),this['_logHandler'](this,T['WARN'],..._0x3004f1);}['error'](..._0x25b7a7){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x25b7a7),this['_logHandler'](this,T['ERROR'],..._0x25b7a7);}}const Dc=(_0x1197e5,_0x5ac858)=>_0x5ac858['some'](_0x384234=>_0x1197e5 instanceof _0x384234);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2f8659){const _0x1836db=new Promise((_0x1b4747,_0x481c23)=>{const _0x2e876c=()=>{_0x2f8659['removeEventListener']('success',_0x5e630d),_0x2f8659['removeEventListener']('error',_0x403722);},_0x5e630d=()=>{_0x1b4747(_e(_0x2f8659['result'])),_0x2e876c();},_0x403722=()=>{_0x481c23(_0x2f8659['error']),_0x2e876c();};_0x2f8659['addEventListener']('success',_0x5e630d),_0x2f8659['addEventListener']('error',_0x403722);});return _0x1836db['then'](_0x44059d=>{_0x44059d instanceof IDBCursor&&Kr['set'](_0x44059d,_0x2f8659);})['catch'](()=>{}),Fi['set'](_0x1836db,_0x2f8659),_0x1836db;}function Fc(_0x5f18ea){if(ui['has'](_0x5f18ea))return;const _0x474ff5=new Promise((_0xa29fd1,_0x1ea8a5)=>{const _0x2fc76b=()=>{_0x5f18ea['removeEventListener']('complete',_0x56f7e7),_0x5f18ea['removeEventListener']('error',_0x3db1e7),_0x5f18ea['removeEventListener']('abort',_0x3db1e7);},_0x56f7e7=()=>{_0xa29fd1(),_0x2fc76b();},_0x3db1e7=()=>{_0x1ea8a5(_0x5f18ea['error']||new DOMException('AbortError','AbortError')),_0x2fc76b();};_0x5f18ea['addEventListener']('complete',_0x56f7e7),_0x5f18ea['addEventListener']('error',_0x3db1e7),_0x5f18ea['addEventListener']('abort',_0x3db1e7);});ui['set'](_0x5f18ea,_0x474ff5);}let di={'get'(_0x404f86,_0x133d4a,_0xa9e4c7){if(_0x404f86 instanceof IDBTransaction){if(_0x133d4a==='done')return ui['get'](_0x404f86);if(_0x133d4a==='objectStoreNames')return _0x404f86['objectStoreNames']||Yr['get'](_0x404f86);if(_0x133d4a==='store')return _0xa9e4c7['objectStoreNames'][0x1]?void 0x0:_0xa9e4c7['objectStore'](_0xa9e4c7['objectStoreNames'][0x0]);}return _e(_0x404f86[_0x133d4a]);},'set'(_0x49ed34,_0x4c250a,_0x1264ea){return _0x49ed34[_0x4c250a]=_0x1264ea,!0x0;},'has'(_0x1b12dc,_0x4f99cd){return _0x1b12dc instanceof IDBTransaction&&(_0x4f99cd==='done'||_0x4f99cd==='store')?!0x0:_0x4f99cd in _0x1b12dc;}};function Uc(_0x42d429){di=_0x42d429(di);}function Wc(_0x5a9995){return _0x5a9995===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3a8096,..._0x183550){const _0xa10462=_0x5a9995['call'](Xn(this),_0x3a8096,..._0x183550);return Yr['set'](_0xa10462,_0x3a8096['sort']?_0x3a8096['sort']():[_0x3a8096]),_e(_0xa10462);}:Lc()['includes'](_0x5a9995)?function(..._0x34c8d4){return _0x5a9995['apply'](Xn(this),_0x34c8d4),_e(Kr['get'](this));}:function(..._0x25c89f){return _e(_0x5a9995['apply'](Xn(this),_0x25c89f));};}function Bc(_0x10a4a2){return typeof _0x10a4a2=='function'?Wc(_0x10a4a2):(_0x10a4a2 instanceof IDBTransaction&&Fc(_0x10a4a2),Dc(_0x10a4a2,Mc())?new Proxy(_0x10a4a2,di):_0x10a4a2);}function _e(_0x274d9c){if(_0x274d9c instanceof IDBRequest)return xc(_0x274d9c);if(Jn['has'](_0x274d9c))return Jn['get'](_0x274d9c);const _0x8c3af2=Bc(_0x274d9c);return _0x8c3af2!==_0x274d9c&&(Jn['set'](_0x274d9c,_0x8c3af2),Fi['set'](_0x8c3af2,_0x274d9c)),_0x8c3af2;}const Xn=_0x2cf956=>Fi['get'](_0x2cf956);function Vc(_0x3c3f33,_0x402952,{blocked:_0xd0fa80,upgrade:_0x5ef362,blocking:_0x5d8b14,terminated:_0x2274a4}={}){const _0x374d80=indexedDB['open'](_0x3c3f33,_0x402952),_0x4c1d4c=_e(_0x374d80);return _0x5ef362&&_0x374d80['addEventListener']('upgradeneeded',_0x1a1dd3=>{_0x5ef362(_e(_0x374d80['result']),_0x1a1dd3['oldVersion'],_0x1a1dd3['newVersion'],_e(_0x374d80['transaction']),_0x1a1dd3);}),_0xd0fa80&&_0x374d80['addEventListener']('blocked',_0xd74331=>_0xd0fa80(_0xd74331['oldVersion'],_0xd74331['newVersion'],_0xd74331)),_0x4c1d4c['then'](_0x415d28=>{_0x2274a4&&_0x415d28['addEventListener']('close',()=>_0x2274a4()),_0x5d8b14&&_0x415d28['addEventListener']('versionchange',_0x40a322=>_0x5d8b14(_0x40a322['oldVersion'],_0x40a322['newVersion'],_0x40a322));})['catch'](()=>{}),_0x4c1d4c;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x129b62,_0x2e35bf){if(!(_0x129b62 instanceof IDBDatabase&&!(_0x2e35bf in _0x129b62)&&typeof _0x2e35bf=='string'))return;if(Zn['get'](_0x2e35bf))return Zn['get'](_0x2e35bf);const _0x3e48c5=_0x2e35bf['replace'](/FromIndex$/,''),_0x1dfee9=_0x2e35bf!==_0x3e48c5,_0x366f31=$c['includes'](_0x3e48c5);if(!(_0x3e48c5 in(_0x1dfee9?IDBIndex:IDBObjectStore)['prototype'])||!(_0x366f31||Hc['includes'](_0x3e48c5)))return;const _0x57fabd=async function(_0x3a5833,..._0x256a77){const _0x2b2796=this['transaction'](_0x3a5833,_0x366f31?'readwrite':'readonly');let _0x1f53e4=_0x2b2796['store'];return _0x1dfee9&&(_0x1f53e4=_0x1f53e4['index'](_0x256a77['shift']())),(await Promise['all']([_0x1f53e4[_0x3e48c5](..._0x256a77),_0x366f31&&_0x2b2796['done']]))[0x0];};return Zn['set'](_0x2e35bf,_0x57fabd),_0x57fabd;}Uc(_0x3e6ece=>({..._0x3e6ece,'get':(_0x497949,_0x1240bb,_0x5eb304)=>Os(_0x497949,_0x1240bb)||_0x3e6ece['get'](_0x497949,_0x1240bb,_0x5eb304),'has':(_0xb60431,_0x5dee92)=>!!Os(_0xb60431,_0x5dee92)||_0x3e6ece['has'](_0xb60431,_0x5dee92)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x1d621a){this['container']=_0x1d621a;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x231932=>{if(qc(_0x231932)){const _0x3edc5a=_0x231932['getImmediate']();return _0x3edc5a['library']+'/'+_0x3edc5a['version'];}else return null;})['filter'](_0x2e0f6b=>_0x2e0f6b)['join']('\x20');}}function qc(_0x1bafaa){const _0x3cd7a3=_0x1bafaa['getComponent']();return(_0x3cd7a3==null?void 0x0:_0x3cd7a3['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3cc0a3,_0x5b3623){try{_0x3cc0a3['container']['addComponent'](_0x5b3623);}catch(_0x44171c){re['debug']('Component\x20'+_0x5b3623['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3cc0a3['name'],_0x44171c);}}function et(_0x12a4b9){const _0x397493=_0x12a4b9['name'];if(gi['has'](_0x397493))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x397493+'.'),!0x1;gi['set'](_0x397493,_0x12a4b9);for(const _0x3fd5be of Le['values']())Ms(_0x3fd5be,_0x12a4b9);for(const _0x422d26 of _i['values']())Ms(_0x422d26,_0x12a4b9);return!0x0;}function Ui(_0x5f11d5,_0x40b355){const _0x30229d=_0x5f11d5['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x30229d&&_0x30229d['triggerHeartbeat'](),_0x5f11d5['container']['getProvider'](_0x40b355);}function H(_0x28cf10){return _0x28cf10==null?!0x1:_0x28cf10['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4969b0,_0x51a137,_0x464696){this['_isDeleted']=!0x1,this['_options']={..._0x4969b0},this['_config']={..._0x51a137},this['_name']=_0x51a137['name'],this['_automaticDataCollectionEnabled']=_0x51a137['automaticDataCollectionEnabled'],this['_container']=_0x464696,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3c9bd5){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3c9bd5;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x6b0d46){this['_isDeleted']=_0x6b0d46;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x231162,_0x3fa3c3={}){let _0x5c2591=_0x231162;typeof _0x3fa3c3!='object'&&(_0x3fa3c3={'name':_0x3fa3c3});const _0x58acf1={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x3fa3c3},_0x23591d=_0x58acf1['name'];if(typeof _0x23591d!='string'||!_0x23591d)throw ge['create']('bad-app-name',{'appName':String(_0x23591d)});if(_0x5c2591||(_0x5c2591=$r()),!_0x5c2591)throw ge['create']('no-options');const _0x5653c0=Le['get'](_0x23591d);if(_0x5653c0){if(De(_0x5c2591,_0x5653c0['options'])&&De(_0x58acf1,_0x5653c0['config']))return _0x5653c0;throw ge['create']('duplicate-app',{'appName':_0x23591d});}const _0x317b4f=new Ac(_0x23591d);for(const _0x2ca733 of gi['values']())_0x317b4f['addComponent'](_0x2ca733);const _0x17ef31=new Il(_0x5c2591,_0x58acf1,_0x317b4f);return Le['set'](_0x23591d,_0x17ef31),_0x17ef31;}function Qr(_0x2da79c=pi){const _0x1b8fb9=Le['get'](_0x2da79c);if(!_0x1b8fb9&&_0x2da79c===pi&&$r())return wl();if(!_0x1b8fb9)throw ge['create']('no-app',{'appName':_0x2da79c});return _0x1b8fb9;}function l_(){return Array['from'](Le['values']());}async function h_(_0x35aaa9){let _0x591ff4=!0x1;const _0x454759=_0x35aaa9['name'];Le['has'](_0x454759)?(_0x591ff4=!0x0,Le['delete'](_0x454759)):_i['has'](_0x454759)&&_0x35aaa9['decRefCount']()<=0x0&&(_i['delete'](_0x454759),_0x591ff4=!0x0),_0x591ff4&&(await Promise['all'](_0x35aaa9['container']['getProviders']()['map'](_0x15b1a4=>_0x15b1a4['delete']())),_0x35aaa9['isDeleted']=!0x0);}function me(_0x10a0be,_0x220961,_0x584900){let _0x3a774b=vl[_0x10a0be]??_0x10a0be;_0x584900&&(_0x3a774b+='-'+_0x584900);const _0x584a16=_0x3a774b['match'](/\s|\//),_0x418459=_0x220961['match'](/\s|\//);if(_0x584a16||_0x418459){const _0x36bc2e=['Unable\x20to\x20register\x20library\x20\x22'+_0x3a774b+'\x22\x20with\x20version\x20\x22'+_0x220961+'\x22:'];_0x584a16&&_0x36bc2e['push']('library\x20name\x20\x22'+_0x3a774b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x584a16&&_0x418459&&_0x36bc2e['push']('and'),_0x418459&&_0x36bc2e['push']('version\x20name\x20\x22'+_0x220961+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x36bc2e['join']('\x20'));return;}et(new Me(_0x3a774b+'-version',()=>({'library':_0x3a774b,'version':_0x220961}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1e0811,_0x5d987e)=>{switch(_0x5d987e){case 0x0:try{_0x1e0811['createObjectStore'](Rt);}catch(_0x2a70c6){console['warn'](_0x2a70c6);}}}})['catch'](_0x1bd3c6=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1bd3c6['message']});})),ei;}async function Sl(_0x615acf){try{const _0x427338=(await Jr())['transaction'](Rt),_0x2a1023=await _0x427338['objectStore'](Rt)['get'](Xr(_0x615acf));return await _0x427338['done'],_0x2a1023;}catch(_0x89a0f1){if(_0x89a0f1 instanceof Se)re['warn'](_0x89a0f1['message']);else{const _0x552109=ge['create']('idb-get',{'originalErrorMessage':_0x89a0f1==null?void 0x0:_0x89a0f1['message']});re['warn'](_0x552109['message']);}}}async function Ls(_0x111135,_0x596cbd){try{const _0x4ab5e3=(await Jr())['transaction'](Rt,'readwrite');await _0x4ab5e3['objectStore'](Rt)['put'](_0x596cbd,Xr(_0x111135)),await _0x4ab5e3['done'];}catch(_0x8d983d){if(_0x8d983d instanceof Se)re['warn'](_0x8d983d['message']);else{const _0x2a15f5=ge['create']('idb-set',{'originalErrorMessage':_0x8d983d==null?void 0x0:_0x8d983d['message']});re['warn'](_0x2a15f5['message']);}}}function Xr(_0x981082){return _0x981082['name']+'!'+_0x981082['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x207a76){this['container']=_0x207a76,this['_heartbeatsCache']=null;const _0x58b941=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x58b941),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x182fdd=>(this['_heartbeatsCache']=_0x182fdd,_0x182fdd));}async['triggerHeartbeat'](){var _0x495596,_0x2a31ad;try{const _0x1a6784=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1a2cc4=xs();if(((_0x495596=this['_heartbeatsCache'])==null?void 0x0:_0x495596['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2a31ad=this['_heartbeatsCache'])==null?void 0x0:_0x2a31ad['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1a2cc4||this['_heartbeatsCache']['heartbeats']['some'](_0x5385d5=>_0x5385d5['date']===_0x1a2cc4))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1a2cc4,'agent':_0x1a6784}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x44cd5a=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x44cd5a,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2894fa){re['warn'](_0x2894fa);}}async['getHeartbeatsHeader'](){var _0x4b678a;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4b678a=this['_heartbeatsCache'])==null?void 0x0:_0x4b678a['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x104a41=xs(),{heartbeatsToSend:_0x3bc777,unsentEntries:_0x23ff21}=kl(this['_heartbeatsCache']['heartbeats']),_0x191f60=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3bc777}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x104a41,_0x23ff21['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x23ff21,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x191f60;}catch(_0x273323){return re['warn'](_0x273323),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x2d777f,_0x40e881=bl){const _0x52dacb=[];let _0x4b5107=_0x2d777f['slice']();for(const _0x46297f of _0x2d777f){const _0x4bbf98=_0x52dacb['find'](_0x489ba5=>_0x489ba5['agent']===_0x46297f['agent']);if(_0x4bbf98){if(_0x4bbf98['dates']['push'](_0x46297f['date']),Fs(_0x52dacb)>_0x40e881){_0x4bbf98['dates']['pop']();break;}}else{if(_0x52dacb['push']({'agent':_0x46297f['agent'],'dates':[_0x46297f['date']]}),Fs(_0x52dacb)>_0x40e881){_0x52dacb['pop']();break;}}_0x4b5107=_0x4b5107['slice'](0x1);}return{'heartbeatsToSend':_0x52dacb,'unsentEntries':_0x4b5107};}class Nl{constructor(_0x8c5052){this['app']=_0x8c5052,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1d7c72=await Sl(this['app']);return _0x1d7c72!=null&&_0x1d7c72['heartbeats']?_0x1d7c72:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2497c7){if(await this['_canUseIndexedDBPromise']){const _0x41c1d9=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2497c7['lastSentHeartbeatDate']??_0x41c1d9['lastSentHeartbeatDate'],'heartbeats':_0x2497c7['heartbeats']});}else return;}async['add'](_0x2f743c){if(await this['_canUseIndexedDBPromise']){const _0x5a2edf=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2f743c['lastSentHeartbeatDate']??_0x5a2edf['lastSentHeartbeatDate'],'heartbeats':[..._0x5a2edf['heartbeats'],..._0x2f743c['heartbeats']]});}else return;}}function Fs(_0x3760a4){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x3760a4}))['length'];}function Pl(_0x26931e){if(_0x26931e['length']===0x0)return-0x1;let _0xd1945f=0x0,_0xc34599=_0x26931e[0x0]['date'];for(let _0x24ba57=0x1;_0x24ba57<_0x26931e['length'];_0x24ba57++)_0x26931e[_0x24ba57]['date']<_0xc34599&&(_0xc34599=_0x26931e[_0x24ba57]['date'],_0xd1945f=_0x24ba57);return _0xd1945f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0xc7f63f){et(new Me('platform-logger',_0x138bd4=>new Gc(_0x138bd4),'PRIVATE')),et(new Me('heartbeat',_0x497566=>new Al(_0x497566),'PRIVATE')),me(fi,Ds,_0xc7f63f),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x48783b){Zr=_0x48783b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x3610b1){this['domStorage_']=_0x3610b1,this['prefix_']='firebase:';}['set'](_0x128ff3,_0x5ace17){_0x5ace17==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x128ff3)):this['domStorage_']['setItem'](this['prefixedName_'](_0x128ff3),O(_0x5ace17));}['get'](_0x45a1d0){const _0x243416=this['domStorage_']['getItem'](this['prefixedName_'](_0x45a1d0));return _0x243416==null?null:bt(_0x243416);}['remove'](_0x31ed6d){this['domStorage_']['removeItem'](this['prefixedName_'](_0x31ed6d));}['prefixedName_'](_0x201fdc){return this['prefix_']+_0x201fdc;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x22716b,_0x488870){_0x488870==null?delete this['cache_'][_0x22716b]:this['cache_'][_0x22716b]=_0x488870;}['get'](_0x3a12fd){return Y(this['cache_'],_0x3a12fd)?this['cache_'][_0x3a12fd]:null;}['remove'](_0x3472c2){delete this['cache_'][_0x3472c2];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x1e65e6){try{if(typeof window<'u'&&typeof window[_0x1e65e6]<'u'){const _0x2b518f=window[_0x1e65e6];return _0x2b518f['setItem']('firebase:sentinel','cache'),_0x2b518f['removeItem']('firebase:sentinel'),new xl(_0x2b518f);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x518a59=0x1;return function(){return _0x518a59++;};}()),no=function(_0x51a4d5){const _0x4a9f4d=Tc(_0x51a4d5),_0x2bfea9=new Ec();_0x2bfea9['update'](_0x4a9f4d);const _0x3b2772=_0x2bfea9['digest']();return Di['encodeByteArray'](_0x3b2772);},Bt=function(..._0x219429){let _0x2fa100='';for(let _0x13be52=0x0;_0x13be52<_0x219429['length'];_0x13be52++){const _0x4c5a44=_0x219429[_0x13be52];Array['isArray'](_0x4c5a44)||_0x4c5a44&&typeof _0x4c5a44=='object'&&typeof _0x4c5a44['length']=='number'?_0x2fa100+=Bt['apply'](null,_0x4c5a44):typeof _0x4c5a44=='object'?_0x2fa100+=O(_0x4c5a44):_0x2fa100+=_0x4c5a44,_0x2fa100+='\x20';}return _0x2fa100;};let Et=null,Vs=!0x0;const Wl=function(_0x7bf318,_0x1e4d0d){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x2dbacd){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0xd98e1e=Bt['apply'](null,_0x2dbacd);Et(_0xd98e1e);}},Vt=function(_0x1c2a6c){return function(..._0x31beed){L(_0x1c2a6c,..._0x31beed);};},mi=function(..._0x29398e){const _0x1c7b9d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x29398e);Qe['error'](_0x1c7b9d);},oe=function(..._0xe50bb7){const _0x1e996c='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0xe50bb7);throw Qe['error'](_0x1e996c),new Error(_0x1e996c);},U=function(..._0x1ca1eb){const _0x26d7ce='FIREBASE\x20WARNING:\x20'+Bt(..._0x1ca1eb);Qe['warn'](_0x26d7ce);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x921243){return typeof _0x921243=='number'&&(_0x921243!==_0x921243||_0x921243===Number['POSITIVE_INFINITY']||_0x921243===Number['NEGATIVE_INFINITY']);},Vl=function(_0x3abdc6){if(document['readyState']==='complete')_0x3abdc6();else{let _0x59fce4=!0x1;const _0x52afe1=function(){if(!document['body']){setTimeout(_0x52afe1,Math['floor'](0xa));return;}_0x59fce4||(_0x59fce4=!0x0,_0x3abdc6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x52afe1,!0x1),window['addEventListener']('load',_0x52afe1,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x52afe1();}),window['attachEvent']('onload',_0x52afe1));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x1d0dff,_0x51cf2a){if(_0x1d0dff===_0x51cf2a)return 0x0;if(_0x1d0dff===xe||_0x51cf2a===Ie)return-0x1;if(_0x51cf2a===xe||_0x1d0dff===Ie)return 0x1;{const _0x1972e6=Hs(_0x1d0dff),_0x2ae638=Hs(_0x51cf2a);return _0x1972e6!==null?_0x2ae638!==null?_0x1972e6-_0x2ae638===0x0?_0x1d0dff['length']-_0x51cf2a['length']:_0x1972e6-_0x2ae638:-0x1:_0x2ae638!==null?0x1:_0x1d0dff<_0x51cf2a?-0x1:0x1;}},Hl=function(_0x475740,_0x463701){return _0x475740===_0x463701?0x0:_0x475740<_0x463701?-0x1:0x1;},pt=function(_0x1aec85,_0x1b3f69){if(_0x1b3f69&&_0x1aec85 in _0x1b3f69)return _0x1b3f69[_0x1aec85];throw new Error('Missing\x20required\x20key\x20('+_0x1aec85+')\x20in\x20object:\x20'+O(_0x1b3f69));},Bi=function(_0x206f89){if(typeof _0x206f89!='object'||_0x206f89===null)return O(_0x206f89);const _0x147687=[];for(const _0x2560b1 in _0x206f89)_0x147687['push'](_0x2560b1);_0x147687['sort']();let _0x15ef46='{';for(let _0x1eddc7=0x0;_0x1eddc7<_0x147687['length'];_0x1eddc7++)_0x1eddc7!==0x0&&(_0x15ef46+=','),_0x15ef46+=O(_0x147687[_0x1eddc7]),_0x15ef46+=':',_0x15ef46+=Bi(_0x206f89[_0x147687[_0x1eddc7]]);return _0x15ef46+='}',_0x15ef46;},io=function(_0x48cbe5,_0x397c9e){const _0x6f8c17=_0x48cbe5['length'];if(_0x6f8c17<=_0x397c9e)return[_0x48cbe5];const _0x7885a2=[];for(let _0x3395f5=0x0;_0x3395f5<_0x6f8c17;_0x3395f5+=_0x397c9e)_0x3395f5+_0x397c9e>_0x6f8c17?_0x7885a2['push'](_0x48cbe5['substring'](_0x3395f5,_0x6f8c17)):_0x7885a2['push'](_0x48cbe5['substring'](_0x3395f5,_0x3395f5+_0x397c9e));return _0x7885a2;};function x(_0x45d3d9,_0x47606e){for(const _0x571e1e in _0x45d3d9)_0x45d3d9['hasOwnProperty'](_0x571e1e)&&_0x47606e(_0x571e1e,_0x45d3d9[_0x571e1e]);}const so=function(_0x13f9b9){f(!Wi(_0x13f9b9),'Invalid\x20JSON\x20number');const _0x43401e=0xb,_0x518597=0x34,_0x379d65=(0x1<<_0x43401e-0x1)-0x1;let _0x44fb89,_0x17aab4,_0x34dfac,_0x1fce16,_0x35416d;_0x13f9b9===0x0?(_0x17aab4=0x0,_0x34dfac=0x0,_0x44fb89=0x1/_0x13f9b9===-0x1/0x0?0x1:0x0):(_0x44fb89=_0x13f9b9<0x0,_0x13f9b9=Math['abs'](_0x13f9b9),_0x13f9b9>=Math['pow'](0x2,0x1-_0x379d65)?(_0x1fce16=Math['min'](Math['floor'](Math['log'](_0x13f9b9)/Math['LN2']),_0x379d65),_0x17aab4=_0x1fce16+_0x379d65,_0x34dfac=Math['round'](_0x13f9b9*Math['pow'](0x2,_0x518597-_0x1fce16)-Math['pow'](0x2,_0x518597))):(_0x17aab4=0x0,_0x34dfac=Math['round'](_0x13f9b9/Math['pow'](0x2,0x1-_0x379d65-_0x518597))));const _0x22387e=[];for(_0x35416d=_0x518597;_0x35416d;_0x35416d-=0x1)_0x22387e['push'](_0x34dfac%0x2?0x1:0x0),_0x34dfac=Math['floor'](_0x34dfac/0x2);for(_0x35416d=_0x43401e;_0x35416d;_0x35416d-=0x1)_0x22387e['push'](_0x17aab4%0x2?0x1:0x0),_0x17aab4=Math['floor'](_0x17aab4/0x2);_0x22387e['push'](_0x44fb89?0x1:0x0),_0x22387e['reverse']();const _0x5b8e9a=_0x22387e['join']('');let _0x3ec7b0='';for(_0x35416d=0x0;_0x35416d<0x40;_0x35416d+=0x8){let _0x3e4415=parseInt(_0x5b8e9a['substr'](_0x35416d,0x8),0x2)['toString'](0x10);_0x3e4415['length']===0x1&&(_0x3e4415='0'+_0x3e4415),_0x3ec7b0=_0x3ec7b0+_0x3e4415;}return _0x3ec7b0['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x556e75,_0x10b9a3){let _0x3e81e4='Unknown\x20Error';_0x556e75==='too_big'?_0x3e81e4='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x556e75==='permission_denied'?_0x3e81e4='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x556e75==='unavailable'&&(_0x3e81e4='The\x20service\x20is\x20unavailable');const _0x5a4cd9=new Error(_0x556e75+'\x20at\x20'+_0x10b9a3['_path']['toString']()+':\x20'+_0x3e81e4);return _0x5a4cd9['code']=_0x556e75['toUpperCase'](),_0x5a4cd9;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0xfed0a9){if(zl['test'](_0xfed0a9)){const _0x576779=Number(_0xfed0a9);if(_0x576779>=jl&&_0x576779<=Kl)return _0x576779;}return null;},lt=function(_0x2ec7c3){try{_0x2ec7c3();}catch(_0x311b9a){setTimeout(()=>{const _0xc3ba15=_0x311b9a['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xc3ba15),_0x311b9a;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5d18d4,_0x2413ab){const _0x1c5a08=setTimeout(_0x5d18d4,_0x2413ab);return typeof _0x1c5a08=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1c5a08):typeof _0x1c5a08=='object'&&_0x1c5a08['unref']&&_0x1c5a08['unref'](),_0x1c5a08;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x1d7bac,_0x585f6f){this['appCheckProvider']=_0x585f6f,this['appName']=_0x1d7bac['name'],H(_0x1d7bac)&&_0x1d7bac['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1d7bac['settings']['appCheckToken']),this['appCheck']=_0x585f6f==null?void 0x0:_0x585f6f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x585f6f==null||_0x585f6f['get']()['then'](_0x183a53=>this['appCheck']=_0x183a53);}['getToken'](_0x11e1ba){if(this['serverAppAppCheckToken']){if(_0x11e1ba)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x11e1ba):new Promise((_0x1c2785,_0x51cf3f)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x11e1ba)['then'](_0x1c2785,_0x51cf3f):_0x1c2785(null);},0x0);});}['addTokenChangeListener'](_0x460ca9){var _0x3fa24e;(_0x3fa24e=this['appCheckProvider'])==null||_0x3fa24e['get']()['then'](_0x1210f8=>_0x1210f8['addTokenListener'](_0x460ca9));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4836e7,_0x47be36,_0x3d2357){this['appName_']=_0x4836e7,this['firebaseOptions_']=_0x47be36,this['authProvider_']=_0x3d2357,this['auth_']=null,this['auth_']=_0x3d2357['getImmediate']({'optional':!0x0}),this['auth_']||_0x3d2357['onInit'](_0x4cfa26=>this['auth_']=_0x4cfa26);}['getToken'](_0x24594e){return this['auth_']?this['auth_']['getToken'](_0x24594e)['catch'](_0x167ed4=>_0x167ed4&&_0x167ed4['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x167ed4)):new Promise((_0x4163ae,_0x2c75aa)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x24594e)['then'](_0x4163ae,_0x2c75aa):_0x4163ae(null);},0x0);});}['addTokenChangeListener'](_0x2ac452){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2ac452):this['authProvider_']['get']()['then'](_0x42d163=>_0x42d163['addAuthTokenListener'](_0x2ac452));}['removeTokenChangeListener'](_0x3a0cea){this['authProvider_']['get']()['then'](_0x312624=>_0x312624['removeAuthTokenListener'](_0x3a0cea));}['notifyForInvalidToken'](){let _0x38a6d5='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x38a6d5+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x38a6d5+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x38a6d5+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x38a6d5);}}class tn{constructor(_0x5861b8){this['accessToken']=_0x5861b8;}['getToken'](_0x23fc58){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x51ef7e){_0x51ef7e(this['accessToken']);}['removeTokenChangeListener'](_0x56cbd7){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x12f9aa,_0x3cbde2,_0x29f6c8,_0xe04ec4,_0x5b2c03=!0x1,_0x23504d='',_0x261713=!0x1,_0x5b8367=!0x1,_0x293850=null){this['secure']=_0x3cbde2,this['namespace']=_0x29f6c8,this['webSocketOnly']=_0xe04ec4,this['nodeAdmin']=_0x5b2c03,this['persistenceKey']=_0x23504d,this['includeNamespaceInQueryParams']=_0x261713,this['isUsingEmulator']=_0x5b8367,this['emulatorOptions']=_0x293850,this['_host']=_0x12f9aa['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x12f9aa)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x30d958){_0x30d958!==this['internalHost']&&(this['internalHost']=_0x30d958,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x55b00f=this['toURLString']();return this['persistenceKey']&&(_0x55b00f+='<'+this['persistenceKey']+'>'),_0x55b00f;}['toURLString'](){const _0x318bb8=this['secure']?'https://':'http://',_0x1aa004=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x318bb8+this['host']+'/'+_0x1aa004;}}function Xl(_0x532163){return _0x532163['host']!==_0x532163['internalHost']||_0x532163['isCustomHost']()||_0x532163['includeNamespaceInQueryParams'];}function go(_0x225d0a,_0x45dfef,_0x19c519){f(typeof _0x45dfef=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x19c519=='object','typeof\x20params\x20must\x20==\x20object');let _0x1d199b;if(_0x45dfef===fo)_0x1d199b=(_0x225d0a['secure']?'wss://':'ws://')+_0x225d0a['internalHost']+'/.ws?';else{if(_0x45dfef===po)_0x1d199b=(_0x225d0a['secure']?'https://':'http://')+_0x225d0a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x45dfef);}Xl(_0x225d0a)&&(_0x19c519['ns']=_0x225d0a['namespace']);const _0x4514cf=[];return x(_0x19c519,(_0x58d942,_0x5b2d2e)=>{_0x4514cf['push'](_0x58d942+'='+_0x5b2d2e);}),_0x1d199b+_0x4514cf['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x3ed0da,_0x1afb6b=0x1){Y(this['counters_'],_0x3ed0da)||(this['counters_'][_0x3ed0da]=0x0),this['counters_'][_0x3ed0da]+=_0x1afb6b;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x51af98){const _0x3eb80e=_0x51af98['toString']();return ti[_0x3eb80e]||(ti[_0x3eb80e]=new Zl()),ti[_0x3eb80e];}function eh(_0x491de5,_0x1a54a5){const _0x1c9d24=_0x491de5['toString']();return ni[_0x1c9d24]||(ni[_0x1c9d24]=_0x1a54a5()),ni[_0x1c9d24];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5e88e8){this['onMessage_']=_0x5e88e8,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xd0e640,_0x25c7e9){this['closeAfterResponse']=_0xd0e640,this['onClose']=_0x25c7e9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x439b5e,_0x49a4a6){for(this['pendingResponses'][_0x439b5e]=_0x49a4a6;this['pendingResponses'][this['currentResponseNum']];){const _0x5bf687=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1b8b9f=0x0;_0x1b8b9f<_0x5bf687['length'];++_0x1b8b9f)_0x5bf687[_0x1b8b9f]&&lt(()=>{this['onMessage_'](_0x5bf687[_0x1b8b9f]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0xc2cc10,_0x5f27f2,_0x5ddc48,_0x40f214,_0x53c367,_0x5b764,_0x264e25){this['connId']=_0xc2cc10,this['repoInfo']=_0x5f27f2,this['applicationId']=_0x5ddc48,this['appCheckToken']=_0x40f214,this['authToken']=_0x53c367,this['transportSessionId']=_0x5b764,this['lastSessionId']=_0x264e25,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0xc2cc10),this['stats_']=Hi(_0x5f27f2),this['urlFn']=_0xf3c238=>(this['appCheckToken']&&(_0xf3c238[yi]=this['appCheckToken']),go(_0x5f27f2,po,_0xf3c238));}['open'](_0x525424,_0x2059d9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2059d9,this['myPacketOrderer']=new th(_0x525424),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x408655)=>{const [_0x34bfe2,_0x39b41e,_0x5729bd,_0x579335,_0x6b3809]=_0x408655;if(this['incrementIncomingBytes_'](_0x408655),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x34bfe2===$s)this['id']=_0x39b41e,this['password']=_0x5729bd;else{if(_0x34bfe2===nh)_0x39b41e?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x39b41e,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x34bfe2);}}},(..._0x4b3704)=>{const [_0x2a222d,_0x209975]=_0x4b3704;this['incrementIncomingBytes_'](_0x4b3704),this['myPacketOrderer']['handleResponse'](_0x2a222d,_0x209975);},()=>{this['onClosed_']();},this['urlFn']);const _0x4dbcc2={};_0x4dbcc2[$s]='t',_0x4dbcc2[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4dbcc2[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4dbcc2[ro]=Vi,this['transportSessionId']&&(_0x4dbcc2[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4dbcc2[ho]=this['lastSessionId']),this['applicationId']&&(_0x4dbcc2[uo]=this['applicationId']),this['appCheckToken']&&(_0x4dbcc2[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4dbcc2[ao]=co);const _0x626abc=this['urlFn'](_0x4dbcc2);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x626abc),this['scriptTagHolder']['addTag'](_0x626abc,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2cee12){const _0x2f798b=O(_0x2cee12);this['bytesSent']+=_0x2f798b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2f798b['length']);const _0x264798=Br(_0x2f798b),_0x133c2b=io(_0x264798,hh);for(let _0x3c23e8=0x0;_0x3c23e8<_0x133c2b['length'];_0x3c23e8++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x133c2b['length'],_0x133c2b[_0x3c23e8]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1863fa,_0x45c97c){this['myDisconnFrame']=document['createElement']('iframe');const _0x1a95a9={};_0x1a95a9[lh]='t',_0x1a95a9[mo]=_0x1863fa,_0x1a95a9[yo]=_0x45c97c,this['myDisconnFrame']['src']=this['urlFn'](_0x1a95a9),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1bd60b){const _0x2f26fa=O(_0x1bd60b)['length'];this['bytesReceived']+=_0x2f26fa,this['stats_']['incrementCounter']('bytes_received',_0x2f26fa);}}class $i{constructor(_0x117dbd,_0x1b60c5,_0x4ff2a6,_0x177853){this['onDisconnect']=_0x4ff2a6,this['urlFn']=_0x177853,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x117dbd,window[sh+this['uniqueCallbackIdentifier']]=_0x1b60c5,this['myIFrame']=$i['createIFrame_']();let _0x4b931e='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4b931e='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4e642a='<html><body>'+_0x4b931e+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4e642a),this['myIFrame']['doc']['close']();}catch(_0x300626){L('frame\x20writing\x20exception'),_0x300626['stack']&&L(_0x300626['stack']),L(_0x300626);}}}static['createIFrame_'](){const _0x305bf2=document['createElement']('iframe');if(_0x305bf2['style']['display']='none',document['body']){document['body']['appendChild'](_0x305bf2);try{_0x305bf2['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5e6bfa=document['domain'];_0x305bf2['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5e6bfa+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x305bf2['contentDocument']?_0x305bf2['doc']=_0x305bf2['contentDocument']:_0x305bf2['contentWindow']?_0x305bf2['doc']=_0x305bf2['contentWindow']['document']:_0x305bf2['document']&&(_0x305bf2['doc']=_0x305bf2['document']),_0x305bf2;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x400bea=this['onDisconnect'];_0x400bea&&(this['onDisconnect']=null,_0x400bea());}['startLongPoll'](_0x42168e,_0x2fac45){for(this['myID']=_0x42168e,this['myPW']=_0x2fac45,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5ed356={};_0x5ed356[mo]=this['myID'],_0x5ed356[yo]=this['myPW'],_0x5ed356[vo]=this['currentSerial'];let _0x29a81a=this['urlFn'](_0x5ed356),_0x333bcb='',_0x4dc1f1=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x333bcb['length']<=Eo;){const _0x1de037=this['pendingSegs']['shift']();_0x333bcb=_0x333bcb+'&'+oh+_0x4dc1f1+'='+_0x1de037['seg']+'&'+ah+_0x4dc1f1+'='+_0x1de037['ts']+'&'+ch+_0x4dc1f1+'='+_0x1de037['d'],_0x4dc1f1++;}return _0x29a81a=_0x29a81a+_0x333bcb,this['addLongPollTag_'](_0x29a81a,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x166c21,_0x5966a4,_0xb22915){this['pendingSegs']['push']({'seg':_0x166c21,'ts':_0x5966a4,'d':_0xb22915}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xdae52b,_0x5cd62d){this['outstandingRequests']['add'](_0x5cd62d);const _0x555c22=()=>{this['outstandingRequests']['delete'](_0x5cd62d),this['newRequest_']();},_0x16d083=setTimeout(_0x555c22,Math['floor'](uh)),_0x1bd1c0=()=>{clearTimeout(_0x16d083),_0x555c22();};this['addTag'](_0xdae52b,_0x1bd1c0);}['addTag'](_0x3543ea,_0x369dec){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x41c9af=this['myIFrame']['doc']['createElement']('script');_0x41c9af['type']='text/javascript',_0x41c9af['async']=!0x0,_0x41c9af['src']=_0x3543ea,_0x41c9af['onload']=_0x41c9af['onreadystatechange']=function(){const _0x8ce601=_0x41c9af['readyState'];(!_0x8ce601||_0x8ce601==='loaded'||_0x8ce601==='complete')&&(_0x41c9af['onload']=_0x41c9af['onreadystatechange']=null,_0x41c9af['parentNode']&&_0x41c9af['parentNode']['removeChild'](_0x41c9af),_0x369dec());},_0x41c9af['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3543ea),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x41c9af);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x19a8a8,_0x1b33b2,_0x305b54,_0x100d6e,_0x313d7b,_0x568778,_0x49aea9){this['connId']=_0x19a8a8,this['applicationId']=_0x305b54,this['appCheckToken']=_0x100d6e,this['authToken']=_0x313d7b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x1b33b2),this['connURL']=G['connectionURL_'](_0x1b33b2,_0x568778,_0x49aea9,_0x100d6e,_0x305b54),this['nodeAdmin']=_0x1b33b2['nodeAdmin'];}static['connectionURL_'](_0x17d51d,_0x5f3e48,_0x30ba9c,_0xb8fd5e,_0x34c34b){const _0x662aa5={};return _0x662aa5[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x662aa5[ao]=co),_0x5f3e48&&(_0x662aa5[oo]=_0x5f3e48),_0x30ba9c&&(_0x662aa5[ho]=_0x30ba9c),_0xb8fd5e&&(_0x662aa5[yi]=_0xb8fd5e),_0x34c34b&&(_0x662aa5[uo]=_0x34c34b),go(_0x17d51d,fo,_0x662aa5);}['open'](_0x55666b,_0x22f7d2){this['onDisconnect']=_0x22f7d2,this['onMessage']=_0x55666b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x2b3e89;dc(),this['mySock']=new hn(this['connURL'],[],_0x2b3e89);}catch(_0x6d57c3){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2c4bea=_0x6d57c3['message']||_0x6d57c3['data'];_0x2c4bea&&this['log_'](_0x2c4bea),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2f08a9=>{this['handleIncomingFrame'](_0x2f08a9);},this['mySock']['onerror']=_0x1aab2d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4d5593=_0x1aab2d['message']||_0x1aab2d['data'];_0x4d5593&&this['log_'](_0x4d5593),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x54b1aa=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x560fc0=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2891c4=navigator['userAgent']['match'](_0x560fc0);_0x2891c4&&_0x2891c4['length']>0x1&&parseFloat(_0x2891c4[0x1])<4.4&&(_0x54b1aa=!0x0);}return!_0x54b1aa&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x384543){if(this['frames']['push'](_0x384543),this['frames']['length']===this['totalFrames']){const _0x1f58dc=this['frames']['join']('');this['frames']=null;const _0x4d70d6=bt(_0x1f58dc);this['onMessage'](_0x4d70d6);}}['handleNewFrameCount_'](_0x11978c){this['totalFrames']=_0x11978c,this['frames']=[];}['extractFrameCount_'](_0x7c2325){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x7c2325['length']<=0x6){const _0x669632=Number(_0x7c2325);if(!isNaN(_0x669632))return this['handleNewFrameCount_'](_0x669632),null;}return this['handleNewFrameCount_'](0x1),_0x7c2325;}['handleIncomingFrame'](_0x128461){if(this['mySock']===null)return;const _0xce018b=_0x128461['data'];if(this['bytesReceived']+=_0xce018b['length'],this['stats_']['incrementCounter']('bytes_received',_0xce018b['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xce018b);else{const _0x379c72=this['extractFrameCount_'](_0xce018b);_0x379c72!==null&&this['appendFrame_'](_0x379c72);}}['send'](_0x5b3156){this['resetKeepAlive']();const _0x43b36a=O(_0x5b3156);this['bytesSent']+=_0x43b36a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x43b36a['length']);const _0x62b5fe=io(_0x43b36a,fh);_0x62b5fe['length']>0x1&&this['sendString_'](String(_0x62b5fe['length']));for(let _0x147c84=0x0;_0x147c84<_0x62b5fe['length'];_0x147c84++)this['sendString_'](_0x62b5fe[_0x147c84]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0xd99ea8){try{this['mySock']['send'](_0xd99ea8);}catch(_0x5e3f0c){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5e3f0c['message']||_0x5e3f0c['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1783a4){this['initTransports_'](_0x1783a4);}['initTransports_'](_0x101d58){const _0x3a9af6=G&&G['isAvailable']();let _0x1978c7=_0x3a9af6&&!G['previouslyFailed']();if(_0x101d58['webSocketOnly']&&(_0x3a9af6||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1978c7=!0x0),_0x1978c7)this['transports_']=[G];else{const _0x144fea=this['transports_']=[];for(const _0x239c8c of At['ALL_TRANSPORTS'])_0x239c8c&&_0x239c8c['isAvailable']()&&_0x144fea['push'](_0x239c8c);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x2be5e2,_0x3813d4,_0x49a1b4,_0x38a730,_0x40ab2b,_0x57d54f,_0x1264de,_0x4a2fb9,_0xe6e0ee,_0x2ea069){this['id']=_0x2be5e2,this['repoInfo_']=_0x3813d4,this['applicationId_']=_0x49a1b4,this['appCheckToken_']=_0x38a730,this['authToken_']=_0x40ab2b,this['onMessage_']=_0x57d54f,this['onReady_']=_0x1264de,this['onDisconnect_']=_0x4a2fb9,this['onKill_']=_0xe6e0ee,this['lastSessionId']=_0x2ea069,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x3813d4),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2e0248=this['transportManager_']['initialTransport']();this['conn_']=new _0x2e0248(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2e0248['responsesRequiredToBeHealthy']||0x0;const _0x2cb427=this['connReceiver_'](this['conn_']),_0x247c2a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2cb427,_0x247c2a);},Math['floor'](0x0));const _0x51c83d=_0x2e0248['healthyTimeout']||0x0;_0x51c83d>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x51c83d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x17814e){return _0x136a80=>{_0x17814e===this['conn_']?this['onConnectionLost_'](_0x136a80):_0x17814e===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2fdc13){return _0x16dec5=>{this['state_']!==0x2&&(_0x2fdc13===this['rx_']?this['onPrimaryMessageReceived_'](_0x16dec5):_0x2fdc13===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x16dec5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x36e204){const _0x52876f={'t':'d','d':_0x36e204};this['sendData_'](_0x52876f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4d8631){if(ii in _0x4d8631){const _0x353bfa=_0x4d8631[ii];_0x353bfa===js?this['upgradeIfSecondaryHealthy_']():_0x353bfa===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x353bfa===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x590958){const _0xed40ab=pt('t',_0x590958),_0x407547=pt('d',_0x590958);if(_0xed40ab==='c')this['onSecondaryControl_'](_0x407547);else{if(_0xed40ab==='d')this['pendingDataMessages']['push'](_0x407547);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xed40ab);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x43c786){const _0x54f158=pt('t',_0x43c786),_0x4df0f0=pt('d',_0x43c786);_0x54f158==='c'?this['onControl_'](_0x4df0f0):_0x54f158==='d'&&this['onDataMessage_'](_0x4df0f0);}['onDataMessage_'](_0xf5a73c){this['onPrimaryResponse_'](),this['onMessage_'](_0xf5a73c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5c3c4b){const _0x2b8cc0=pt(ii,_0x5c3c4b);if(Gs in _0x5c3c4b){const _0x2a854f=_0x5c3c4b[Gs];if(_0x2b8cc0===Ih){const _0x1f8f4e={..._0x2a854f};this['repoInfo_']['isUsingEmulator']&&(_0x1f8f4e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1f8f4e);}else{if(_0x2b8cc0===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x43e520=0x0;_0x43e520<this['pendingDataMessages']['length'];++_0x43e520)this['onDataMessage_'](this['pendingDataMessages'][_0x43e520]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2b8cc0===vh?this['onConnectionShutdown_'](_0x2a854f):_0x2b8cc0===qs?this['onReset_'](_0x2a854f):_0x2b8cc0===Eh?mi('Server\x20Error:\x20'+_0x2a854f):_0x2b8cc0===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x2b8cc0);}}}['onHandshake_'](_0x24dc2b){const _0x18f43b=_0x24dc2b['ts'],_0x4e017f=_0x24dc2b['v'],_0x5e50c0=_0x24dc2b['h'];this['sessionId']=_0x24dc2b['s'],this['repoInfo_']['host']=_0x5e50c0,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x18f43b),Vi!==_0x4e017f&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x335765=this['transportManager_']['upgradeTransport']();_0x335765&&this['startUpgrade_'](_0x335765);}['startUpgrade_'](_0x34d245){this['secondaryConn_']=new _0x34d245(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x34d245['responsesRequiredToBeHealthy']||0x0;const _0x36ac31=this['connReceiver_'](this['secondaryConn_']),_0x164d8c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x36ac31,_0x164d8c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x4bd477){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4bd477),this['repoInfo_']['host']=_0x4bd477,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x23c94c,_0x3d8d1a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x23c94c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3d8d1a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4551cb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4551cb||this['rx_']===_0x4551cb)&&this['close']();}['onConnectionLost_'](_0x596c0c){this['conn_']=null,!_0x596c0c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4138fa){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4138fa),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3f7945){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3f7945);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x4286fc,_0x3f4851,_0x5225ff,_0x27477b){}['merge'](_0x319ac1,_0x5986b9,_0x5bb1c4,_0x35f050){}['refreshAuthToken'](_0xac8c6a){}['refreshAppCheckToken'](_0x1e3f10){}['onDisconnectPut'](_0x5f412e,_0x2102a3,_0x36545d){}['onDisconnectMerge'](_0x19541f,_0x4e875a,_0x5e32d3){}['onDisconnectCancel'](_0x4f2d31,_0x35a38e){}['reportStats'](_0x35a9fc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x573446){this['allowedEvents_']=_0x573446,this['listeners_']={},f(Array['isArray'](_0x573446)&&_0x573446['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4dc3ef,..._0x1feb47){if(Array['isArray'](this['listeners_'][_0x4dc3ef])){const _0x2bf47b=[...this['listeners_'][_0x4dc3ef]];for(let _0x6022a0=0x0;_0x6022a0<_0x2bf47b['length'];_0x6022a0++)_0x2bf47b[_0x6022a0]['callback']['apply'](_0x2bf47b[_0x6022a0]['context'],_0x1feb47);}}['on'](_0x17e7c4,_0x41f173,_0x2d9552){this['validateEventType_'](_0x17e7c4),this['listeners_'][_0x17e7c4]=this['listeners_'][_0x17e7c4]||[],this['listeners_'][_0x17e7c4]['push']({'callback':_0x41f173,'context':_0x2d9552});const _0x350cdc=this['getInitialEvent'](_0x17e7c4);_0x350cdc&&_0x41f173['apply'](_0x2d9552,_0x350cdc);}['off'](_0x1c7df8,_0x22390d,_0x46175d){this['validateEventType_'](_0x1c7df8);const _0x80514f=this['listeners_'][_0x1c7df8]||[];for(let _0x5951eb=0x0;_0x5951eb<_0x80514f['length'];_0x5951eb++)if(_0x80514f[_0x5951eb]['callback']===_0x22390d&&(!_0x46175d||_0x46175d===_0x80514f[_0x5951eb]['context'])){_0x80514f['splice'](_0x5951eb,0x1);return;}}['validateEventType_'](_0x4d33fe){f(this['allowedEvents_']['find'](_0x531008=>_0x531008===_0x4d33fe),'Unknown\x20event:\x20'+_0x4d33fe);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x590a11){return f(_0x590a11==='online','Unknown\x20event\x20type:\x20'+_0x590a11),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x2c26e1,_0x358d34){if(_0x358d34===void 0x0){this['pieces_']=_0x2c26e1['split']('/');let _0x317111=0x0;for(let _0xbc9a79=0x0;_0xbc9a79<this['pieces_']['length'];_0xbc9a79++)this['pieces_'][_0xbc9a79]['length']>0x0&&(this['pieces_'][_0x317111]=this['pieces_'][_0xbc9a79],_0x317111++);this['pieces_']['length']=_0x317111,this['pieceNum_']=0x0;}else this['pieces_']=_0x2c26e1,this['pieceNum_']=_0x358d34;}['toString'](){let _0x4390b1='';for(let _0xdaaebf=this['pieceNum_'];_0xdaaebf<this['pieces_']['length'];_0xdaaebf++)this['pieces_'][_0xdaaebf]!==''&&(_0x4390b1+='/'+this['pieces_'][_0xdaaebf]);return _0x4390b1||'/';}}function w(){return new C('');}function y(_0x425f6f){return _0x425f6f['pieceNum_']>=_0x425f6f['pieces_']['length']?null:_0x425f6f['pieces_'][_0x425f6f['pieceNum_']];}function we(_0x10c7c7){return _0x10c7c7['pieces_']['length']-_0x10c7c7['pieceNum_'];}function b(_0x239455){let _0x42765d=_0x239455['pieceNum_'];return _0x42765d<_0x239455['pieces_']['length']&&_0x42765d++,new C(_0x239455['pieces_'],_0x42765d);}function Gi(_0x439ccb){return _0x439ccb['pieceNum_']<_0x439ccb['pieces_']['length']?_0x439ccb['pieces_'][_0x439ccb['pieces_']['length']-0x1]:null;}function Ch(_0x579f9f){let _0x4fc873='';for(let _0x75c3ab=_0x579f9f['pieceNum_'];_0x75c3ab<_0x579f9f['pieces_']['length'];_0x75c3ab++)_0x579f9f['pieces_'][_0x75c3ab]!==''&&(_0x4fc873+='/'+encodeURIComponent(String(_0x579f9f['pieces_'][_0x75c3ab])));return _0x4fc873||'/';}function kt(_0x11175a,_0x3d8e47=0x0){return _0x11175a['pieces_']['slice'](_0x11175a['pieceNum_']+_0x3d8e47);}function To(_0x3a30c5){if(_0x3a30c5['pieceNum_']>=_0x3a30c5['pieces_']['length'])return null;const _0x1c5c94=[];for(let _0x536fbe=_0x3a30c5['pieceNum_'];_0x536fbe<_0x3a30c5['pieces_']['length']-0x1;_0x536fbe++)_0x1c5c94['push'](_0x3a30c5['pieces_'][_0x536fbe]);return new C(_0x1c5c94,0x0);}function A(_0x26bf55,_0x4343d9){const _0x2b402c=[];for(let _0x308ce4=_0x26bf55['pieceNum_'];_0x308ce4<_0x26bf55['pieces_']['length'];_0x308ce4++)_0x2b402c['push'](_0x26bf55['pieces_'][_0x308ce4]);if(_0x4343d9 instanceof C){for(let _0x3e9d05=_0x4343d9['pieceNum_'];_0x3e9d05<_0x4343d9['pieces_']['length'];_0x3e9d05++)_0x2b402c['push'](_0x4343d9['pieces_'][_0x3e9d05]);}else{const _0x3f3354=_0x4343d9['split']('/');for(let _0x4069a5=0x0;_0x4069a5<_0x3f3354['length'];_0x4069a5++)_0x3f3354[_0x4069a5]['length']>0x0&&_0x2b402c['push'](_0x3f3354[_0x4069a5]);}return new C(_0x2b402c,0x0);}function v(_0x2ab6af){return _0x2ab6af['pieceNum_']>=_0x2ab6af['pieces_']['length'];}function F(_0x44077c,_0xef9063){const _0x519f3a=y(_0x44077c),_0x47bf53=y(_0xef9063);if(_0x519f3a===null)return _0xef9063;if(_0x519f3a===_0x47bf53)return F(b(_0x44077c),b(_0xef9063));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xef9063+')\x20is\x20not\x20within\x20outerPath\x20('+_0x44077c+')');}function Th(_0x8d59f5,_0x13e423){const _0x411550=kt(_0x8d59f5,0x0),_0x29e7f6=kt(_0x13e423,0x0);for(let _0x364a83=0x0;_0x364a83<_0x411550['length']&&_0x364a83<_0x29e7f6['length'];_0x364a83++){const _0x43d80a=He(_0x411550[_0x364a83],_0x29e7f6[_0x364a83]);if(_0x43d80a!==0x0)return _0x43d80a;}return _0x411550['length']===_0x29e7f6['length']?0x0:_0x411550['length']<_0x29e7f6['length']?-0x1:0x1;}function qi(_0x1b05a2,_0x381f6e){if(we(_0x1b05a2)!==we(_0x381f6e))return!0x1;for(let _0x4ce560=_0x1b05a2['pieceNum_'],_0x3a8ef8=_0x381f6e['pieceNum_'];_0x4ce560<=_0x1b05a2['pieces_']['length'];_0x4ce560++,_0x3a8ef8++)if(_0x1b05a2['pieces_'][_0x4ce560]!==_0x381f6e['pieces_'][_0x3a8ef8])return!0x1;return!0x0;}function $(_0x2cc353,_0x57fb5d){let _0x27379d=_0x2cc353['pieceNum_'],_0x17a3dc=_0x57fb5d['pieceNum_'];if(we(_0x2cc353)>we(_0x57fb5d))return!0x1;for(;_0x27379d<_0x2cc353['pieces_']['length'];){if(_0x2cc353['pieces_'][_0x27379d]!==_0x57fb5d['pieces_'][_0x17a3dc])return!0x1;++_0x27379d,++_0x17a3dc;}return!0x0;}class Sh{constructor(_0x5e1908,_0x4a8caf){this['errorPrefix_']=_0x4a8caf,this['parts_']=kt(_0x5e1908,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3ffa53=0x0;_0x3ffa53<this['parts_']['length'];_0x3ffa53++)this['byteLength_']+=Pn(this['parts_'][_0x3ffa53]);So(this);}}function bh(_0x15635a,_0x486ecf){_0x15635a['parts_']['length']>0x0&&(_0x15635a['byteLength_']+=0x1),_0x15635a['parts_']['push'](_0x486ecf),_0x15635a['byteLength_']+=Pn(_0x486ecf),So(_0x15635a);}function Rh(_0x41336e){const _0x3ec1d7=_0x41336e['parts_']['pop']();_0x41336e['byteLength_']-=Pn(_0x3ec1d7),_0x41336e['parts_']['length']>0x0&&(_0x41336e['byteLength_']-=0x1);}function So(_0x56c120){if(_0x56c120['byteLength_']>Js)throw new Error(_0x56c120['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x56c120['byteLength_']+').');if(_0x56c120['parts_']['length']>Qs)throw new Error(_0x56c120['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x56c120));}function Ne(_0x21dc8d){return _0x21dc8d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x21dc8d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3fcd81,_0x13c25a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x13c25a='visibilitychange',_0x3fcd81='hidden'):typeof document['mozHidden']<'u'?(_0x13c25a='mozvisibilitychange',_0x3fcd81='mozHidden'):typeof document['msHidden']<'u'?(_0x13c25a='msvisibilitychange',_0x3fcd81='msHidden'):typeof document['webkitHidden']<'u'&&(_0x13c25a='webkitvisibilitychange',_0x3fcd81='webkitHidden')),this['visible_']=!0x0,_0x13c25a&&document['addEventListener'](_0x13c25a,()=>{const _0x3f288e=!document[_0x3fcd81];_0x3f288e!==this['visible_']&&(this['visible_']=_0x3f288e,this['trigger']('visible',_0x3f288e));},!0x1);}['getInitialEvent'](_0xf0cbcf){return f(_0xf0cbcf==='visible','Unknown\x20event\x20type:\x20'+_0xf0cbcf),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x3066e6,_0x5dd5c9,_0x2babfe,_0x24f1fa,_0x3b01cb,_0x4350e1,_0x1d89a0,_0x2a70af){if(super(),this['repoInfo_']=_0x3066e6,this['applicationId_']=_0x5dd5c9,this['onDataUpdate_']=_0x2babfe,this['onConnectStatus_']=_0x24f1fa,this['onServerInfoUpdate_']=_0x3b01cb,this['authTokenProvider_']=_0x4350e1,this['appCheckTokenProvider_']=_0x1d89a0,this['authOverride_']=_0x2a70af,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2a70af)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3066e6['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x399843,_0x15dbae,_0x123dba){const _0x51f16a=++this['requestNumber_'],_0x408214={'r':_0x51f16a,'a':_0x399843,'b':_0x15dbae};this['log_'](O(_0x408214)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x408214),_0x123dba&&(this['requestCBHash_'][_0x51f16a]=_0x123dba);}['get'](_0x5c8246){this['initConnection_']();const _0x3c4334=new Ve(),_0x468966={'action':'g','request':{'p':_0x5c8246['_path']['toString'](),'q':_0x5c8246['_queryObject']},'onComplete':_0x491d07=>{const _0x142069=_0x491d07['d'];_0x491d07['s']==='ok'?_0x3c4334['resolve'](_0x142069):_0x3c4334['reject'](_0x142069);}};this['outstandingGets_']['push'](_0x468966),this['outstandingGetCount_']++;const _0x28f215=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x28f215),_0x3c4334['promise'];}['listen'](_0x4d2ebc,_0x1516bf,_0x25207d,_0x47cdd0){this['initConnection_']();const _0x56cd66=_0x4d2ebc['_queryIdentifier'],_0xde9d7b=_0x4d2ebc['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xde9d7b+'\x20'+_0x56cd66),this['listens']['has'](_0xde9d7b)||this['listens']['set'](_0xde9d7b,new Map()),f(_0x4d2ebc['_queryParams']['isDefault']()||!_0x4d2ebc['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0xde9d7b)['has'](_0x56cd66),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x28cca4={'onComplete':_0x47cdd0,'hashFn':_0x1516bf,'query':_0x4d2ebc,'tag':_0x25207d};this['listens']['get'](_0xde9d7b)['set'](_0x56cd66,_0x28cca4),this['connected_']&&this['sendListen_'](_0x28cca4);}['sendGet_'](_0x40a5cc){const _0x2b10a5=this['outstandingGets_'][_0x40a5cc];this['sendRequest']('g',_0x2b10a5['request'],_0x2229d7=>{delete this['outstandingGets_'][_0x40a5cc],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2b10a5['onComplete']&&_0x2b10a5['onComplete'](_0x2229d7);});}['sendListen_'](_0x40ece6){const _0x11189b=_0x40ece6['query'],_0x32396f=_0x11189b['_path']['toString'](),_0x3e628a=_0x11189b['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x32396f+'\x20for\x20'+_0x3e628a);const _0x48cfe5={'p':_0x32396f},_0xf57daf='q';_0x40ece6['tag']&&(_0x48cfe5['q']=_0x11189b['_queryObject'],_0x48cfe5['t']=_0x40ece6['tag']),_0x48cfe5['h']=_0x40ece6['hashFn'](),this['sendRequest'](_0xf57daf,_0x48cfe5,_0x40cece=>{const _0x9fb8ff=_0x40cece['d'],_0x292226=_0x40cece['s'];ie['warnOnListenWarnings_'](_0x9fb8ff,_0x11189b),(this['listens']['get'](_0x32396f)&&this['listens']['get'](_0x32396f)['get'](_0x3e628a))===_0x40ece6&&(this['log_']('listen\x20response',_0x40cece),_0x292226!=='ok'&&this['removeListen_'](_0x32396f,_0x3e628a),_0x40ece6['onComplete']&&_0x40ece6['onComplete'](_0x292226,_0x9fb8ff));});}static['warnOnListenWarnings_'](_0x2448ba,_0x544e6d){if(_0x2448ba&&typeof _0x2448ba=='object'&&Y(_0x2448ba,'w')){const _0x9beb31=Oe(_0x2448ba,'w');if(Array['isArray'](_0x9beb31)&&~_0x9beb31['indexOf']('no_index')){const _0x2c14fe='\x22.indexOn\x22:\x20\x22'+_0x544e6d['_queryParams']['getIndex']()['toString']()+'\x22',_0x47009b=_0x544e6d['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2c14fe+'\x20at\x20'+_0x47009b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4e041a){this['authToken_']=_0x4e041a,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4e041a);}['reduceReconnectDelayIfAdminCredential_'](_0x22cc41){(_0x22cc41&&_0x22cc41['length']===0x28||vc(_0x22cc41))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x371736){this['appCheckToken_']=_0x371736,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1ba244=this['authToken_'],_0x5f2a37=yc(_0x1ba244)?'auth':'gauth',_0x5a83de={'cred':_0x1ba244};this['authOverride_']===null?_0x5a83de['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5a83de['authvar']=this['authOverride_']),this['sendRequest'](_0x5f2a37,_0x5a83de,_0x55b7fd=>{const _0x32d8f1=_0x55b7fd['s'],_0x338077=_0x55b7fd['d']||'error';this['authToken_']===_0x1ba244&&(_0x32d8f1==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x32d8f1,_0x338077));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xb23487=>{const _0x451d40=_0xb23487['s'],_0x33df34=_0xb23487['d']||'error';_0x451d40==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x451d40,_0x33df34);});}['unlisten'](_0x1d74a7,_0x5a3bcd){const _0x13e61d=_0x1d74a7['_path']['toString'](),_0x5c8af8=_0x1d74a7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x13e61d+'\x20'+_0x5c8af8),f(_0x1d74a7['_queryParams']['isDefault']()||!_0x1d74a7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x13e61d,_0x5c8af8)&&this['connected_']&&this['sendUnlisten_'](_0x13e61d,_0x5c8af8,_0x1d74a7['_queryObject'],_0x5a3bcd);}['sendUnlisten_'](_0x5d3f37,_0x57d489,_0x38b548,_0x315a09){this['log_']('Unlisten\x20on\x20'+_0x5d3f37+'\x20for\x20'+_0x57d489);const _0x11d9c9={'p':_0x5d3f37},_0xd117fe='n';_0x315a09&&(_0x11d9c9['q']=_0x38b548,_0x11d9c9['t']=_0x315a09),this['sendRequest'](_0xd117fe,_0x11d9c9);}['onDisconnectPut'](_0x3ee529,_0x5218d5,_0x140561){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3ee529,_0x5218d5,_0x140561):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3ee529,'action':'o','data':_0x5218d5,'onComplete':_0x140561});}['onDisconnectMerge'](_0x23f8df,_0x5be130,_0x18a079){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x23f8df,_0x5be130,_0x18a079):this['onDisconnectRequestQueue_']['push']({'pathString':_0x23f8df,'action':'om','data':_0x5be130,'onComplete':_0x18a079});}['onDisconnectCancel'](_0x2f38e1,_0xce2a2c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2f38e1,null,_0xce2a2c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2f38e1,'action':'oc','data':null,'onComplete':_0xce2a2c});}['sendOnDisconnect_'](_0x341dd3,_0x3a49f3,_0x569da4,_0x237a4f){const _0x14c991={'p':_0x3a49f3,'d':_0x569da4};this['log_']('onDisconnect\x20'+_0x341dd3,_0x14c991),this['sendRequest'](_0x341dd3,_0x14c991,_0x27614a=>{_0x237a4f&&setTimeout(()=>{_0x237a4f(_0x27614a['s'],_0x27614a['d']);},Math['floor'](0x0));});}['put'](_0x6c2eca,_0x270112,_0x6451a8,_0x48019f){this['putInternal']('p',_0x6c2eca,_0x270112,_0x6451a8,_0x48019f);}['merge'](_0x90b976,_0x3f3676,_0x4764f1,_0x421fe5){this['putInternal']('m',_0x90b976,_0x3f3676,_0x4764f1,_0x421fe5);}['putInternal'](_0x421707,_0x3c15a5,_0x4e9a3c,_0x4a5c72,_0x10bfbc){this['initConnection_']();const _0x4bb9d4={'p':_0x3c15a5,'d':_0x4e9a3c};_0x10bfbc!==void 0x0&&(_0x4bb9d4['h']=_0x10bfbc),this['outstandingPuts_']['push']({'action':_0x421707,'request':_0x4bb9d4,'onComplete':_0x4a5c72}),this['outstandingPutCount_']++;const _0x3bcc47=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3bcc47):this['log_']('Buffering\x20put:\x20'+_0x3c15a5);}['sendPut_'](_0x118663){const _0x3359e6=this['outstandingPuts_'][_0x118663]['action'],_0x1692ee=this['outstandingPuts_'][_0x118663]['request'],_0x2f4c46=this['outstandingPuts_'][_0x118663]['onComplete'];this['outstandingPuts_'][_0x118663]['queued']=this['connected_'],this['sendRequest'](_0x3359e6,_0x1692ee,_0x5f3eba=>{this['log_'](_0x3359e6+'\x20response',_0x5f3eba),delete this['outstandingPuts_'][_0x118663],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2f4c46&&_0x2f4c46(_0x5f3eba['s'],_0x5f3eba['d']);});}['reportStats'](_0x447a58){if(this['connected_']){const _0x25afe8={'c':_0x447a58};this['log_']('reportStats',_0x25afe8),this['sendRequest']('s',_0x25afe8,_0x1efcdf=>{if(_0x1efcdf['s']!=='ok'){const _0x42a451=_0x1efcdf['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x42a451);}});}}['onDataMessage_'](_0x5f0543){if('r'in _0x5f0543){this['log_']('from\x20server:\x20'+O(_0x5f0543));const _0x4c425a=_0x5f0543['r'],_0x2f2f2e=this['requestCBHash_'][_0x4c425a];_0x2f2f2e&&(delete this['requestCBHash_'][_0x4c425a],_0x2f2f2e(_0x5f0543['b']));}else{if('error'in _0x5f0543)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5f0543['error'];'a'in _0x5f0543&&this['onDataPush_'](_0x5f0543['a'],_0x5f0543['b']);}}['onDataPush_'](_0x4316d9,_0x36c872){this['log_']('handleServerMessage',_0x4316d9,_0x36c872),_0x4316d9==='d'?this['onDataUpdate_'](_0x36c872['p'],_0x36c872['d'],!0x1,_0x36c872['t']):_0x4316d9==='m'?this['onDataUpdate_'](_0x36c872['p'],_0x36c872['d'],!0x0,_0x36c872['t']):_0x4316d9==='c'?this['onListenRevoked_'](_0x36c872['p'],_0x36c872['q']):_0x4316d9==='ac'?this['onAuthRevoked_'](_0x36c872['s'],_0x36c872['d']):_0x4316d9==='apc'?this['onAppCheckRevoked_'](_0x36c872['s'],_0x36c872['d']):_0x4316d9==='sd'?this['onSecurityDebugPacket_'](_0x36c872):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4316d9)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x514723,_0xc35b2f){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x514723),this['lastSessionId']=_0xc35b2f,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5db52d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5db52d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5e1697){_0x5e1697&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5e1697;}['onOnline_'](_0x267354){_0x267354?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x50a5cb=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x325876=Math['max'](0x0,this['reconnectDelay_']-_0x50a5cb);_0x325876=Math['random']()*_0x325876,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x325876+'ms'),this['scheduleConnect_'](_0x325876),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2a2ad9=this['onDataMessage_']['bind'](this),_0x11431e=this['onReady_']['bind'](this),_0x5e8489=this['onRealtimeDisconnect_']['bind'](this),_0x512a54=this['id']+':'+ie['nextConnectionId_']++,_0x1c062e=this['lastSessionId'];let _0x5d8209=!0x1,_0x57d28c=null;const _0x599a59=function(){_0x57d28c?_0x57d28c['close']():(_0x5d8209=!0x0,_0x5e8489());},_0x103e7d=function(_0x2d83c5){f(_0x57d28c,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x57d28c['sendRequest'](_0x2d83c5);};this['realtime_']={'close':_0x599a59,'sendRequest':_0x103e7d};const _0x2d820d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5f39db,_0x4389c9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2d820d),this['appCheckTokenProvider_']['getToken'](_0x2d820d)]);_0x5d8209?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5f39db&&_0x5f39db['accessToken'],this['appCheckToken_']=_0x4389c9&&_0x4389c9['token'],_0x57d28c=new wh(_0x512a54,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2a2ad9,_0x11431e,_0x5e8489,_0x3c47a6=>{U(_0x3c47a6+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x1c062e));}catch(_0x1e3fc5){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1e3fc5),_0x5d8209||(this['repoInfo_']['nodeAdmin']&&U(_0x1e3fc5),_0x599a59());}}}['interrupt'](_0x46d564){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x46d564),this['interruptReasons_'][_0x46d564]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2c9280){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2c9280),delete this['interruptReasons_'][_0x2c9280],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x34cf9e){const _0xc8efd9=_0x34cf9e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xc8efd9});}['cancelSentTransactions_'](){for(let _0x47b2ed=0x0;_0x47b2ed<this['outstandingPuts_']['length'];_0x47b2ed++){const _0x4314cd=this['outstandingPuts_'][_0x47b2ed];_0x4314cd&&'h'in _0x4314cd['request']&&_0x4314cd['queued']&&(_0x4314cd['onComplete']&&_0x4314cd['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x47b2ed],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xcfe63d,_0x57afd1){let _0x311aa8;_0x57afd1?_0x311aa8=_0x57afd1['map'](_0x421e66=>Bi(_0x421e66))['join']('$'):_0x311aa8='default';const _0x1eb20d=this['removeListen_'](_0xcfe63d,_0x311aa8);_0x1eb20d&&_0x1eb20d['onComplete']&&_0x1eb20d['onComplete']('permission_denied');}['removeListen_'](_0x487d91,_0x323e38){const _0xdcbc46=new C(_0x487d91)['toString']();let _0x522f49;if(this['listens']['has'](_0xdcbc46)){const _0x2169c5=this['listens']['get'](_0xdcbc46);_0x522f49=_0x2169c5['get'](_0x323e38),_0x2169c5['delete'](_0x323e38),_0x2169c5['size']===0x0&&this['listens']['delete'](_0xdcbc46);}else _0x522f49=void 0x0;return _0x522f49;}['onAuthRevoked_'](_0x57713d,_0x4b9342){L('Auth\x20token\x20revoked:\x20'+_0x57713d+'/'+_0x4b9342),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x57713d==='invalid_token'||_0x57713d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x526358,_0x56615a){L('App\x20check\x20token\x20revoked:\x20'+_0x526358+'/'+_0x56615a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x526358==='invalid_token'||_0x526358==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3648fe){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3648fe):'msg'in _0x3648fe&&console['log']('FIREBASE:\x20'+_0x3648fe['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2b6866 of this['listens']['values']())for(const _0x518ca8 of _0x2b6866['values']())this['sendListen_'](_0x518ca8);for(let _0x243c09=0x0;_0x243c09<this['outstandingPuts_']['length'];_0x243c09++)this['outstandingPuts_'][_0x243c09]&&this['sendPut_'](_0x243c09);for(;this['onDisconnectRequestQueue_']['length'];){const _0xae642d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xae642d['action'],_0xae642d['pathString'],_0xae642d['data'],_0xae642d['onComplete']);}for(let _0x5e5f13=0x0;_0x5e5f13<this['outstandingGets_']['length'];_0x5e5f13++)this['outstandingGets_'][_0x5e5f13]&&this['sendGet_'](_0x5e5f13);}['sendConnectStats_'](){const _0x45cf70={};let _0x4556e7='js';_0x45cf70['sdk.'+_0x4556e7+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x45cf70['framework.cordova']=0x1:qr()&&(_0x45cf70['framework.reactnative']=0x1),this['reportStats'](_0x45cf70);}['shouldReconnect_'](){const _0x4338ec=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4338ec;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x40166d,_0x41787e){this['name']=_0x40166d,this['node']=_0x41787e;}static['Wrap'](_0x522fdd,_0x5547ac){return new E(_0x522fdd,_0x5547ac);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xd62d42,_0x54649f){const _0x335c5d=new E(xe,_0xd62d42),_0x5015d9=new E(xe,_0x54649f);return this['compare'](_0x335c5d,_0x5015d9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x4c3f51){Xt=_0x4c3f51;}['compare'](_0x520eb9,_0x114624){return He(_0x520eb9['name'],_0x114624['name']);}['isDefinedOn'](_0x4ab3dc){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x33cb27,_0x5995e7){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x6463aa,_0x1da07f){return f(typeof _0x6463aa=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x6463aa,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2d2814,_0x75463c,_0x2baba9,_0x112d78,_0x5d7fc8=null){this['isReverse_']=_0x112d78,this['resultGenerator_']=_0x5d7fc8,this['nodeStack_']=[];let _0x2162a1=0x1;for(;!_0x2d2814['isEmpty']();)if(_0x2d2814=_0x2d2814,_0x2162a1=_0x75463c?_0x2baba9(_0x2d2814['key'],_0x75463c):0x1,_0x112d78&&(_0x2162a1*=-0x1),_0x2162a1<0x0)this['isReverse_']?_0x2d2814=_0x2d2814['left']:_0x2d2814=_0x2d2814['right'];else{if(_0x2162a1===0x0){this['nodeStack_']['push'](_0x2d2814);break;}else this['nodeStack_']['push'](_0x2d2814),this['isReverse_']?_0x2d2814=_0x2d2814['right']:_0x2d2814=_0x2d2814['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2e8d32=this['nodeStack_']['pop'](),_0x2f52f9;if(this['resultGenerator_']?_0x2f52f9=this['resultGenerator_'](_0x2e8d32['key'],_0x2e8d32['value']):_0x2f52f9={'key':_0x2e8d32['key'],'value':_0x2e8d32['value']},this['isReverse_']){for(_0x2e8d32=_0x2e8d32['left'];!_0x2e8d32['isEmpty']();)this['nodeStack_']['push'](_0x2e8d32),_0x2e8d32=_0x2e8d32['right'];}else{for(_0x2e8d32=_0x2e8d32['right'];!_0x2e8d32['isEmpty']();)this['nodeStack_']['push'](_0x2e8d32),_0x2e8d32=_0x2e8d32['left'];}return _0x2f52f9;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4300bc=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4300bc['key'],_0x4300bc['value']):{'key':_0x4300bc['key'],'value':_0x4300bc['value']};}}class M{constructor(_0x5e458,_0x2bda77,_0x12deb7,_0x158fda,_0x5cc4b3){this['key']=_0x5e458,this['value']=_0x2bda77,this['color']=_0x12deb7??M['RED'],this['left']=_0x158fda??B['EMPTY_NODE'],this['right']=_0x5cc4b3??B['EMPTY_NODE'];}['copy'](_0x24d155,_0x46c77f,_0xd797df,_0x48ae7c,_0x262a49){return new M(_0x24d155??this['key'],_0x46c77f??this['value'],_0xd797df??this['color'],_0x48ae7c??this['left'],_0x262a49??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x521556){return this['left']['inorderTraversal'](_0x521556)||!!_0x521556(this['key'],this['value'])||this['right']['inorderTraversal'](_0x521556);}['reverseTraversal'](_0x41722e){return this['right']['reverseTraversal'](_0x41722e)||_0x41722e(this['key'],this['value'])||this['left']['reverseTraversal'](_0x41722e);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x37e51f,_0x29ab0c,_0x38966c){let _0x1ab42e=this;const _0x3b9e63=_0x38966c(_0x37e51f,_0x1ab42e['key']);return _0x3b9e63<0x0?_0x1ab42e=_0x1ab42e['copy'](null,null,null,_0x1ab42e['left']['insert'](_0x37e51f,_0x29ab0c,_0x38966c),null):_0x3b9e63===0x0?_0x1ab42e=_0x1ab42e['copy'](null,_0x29ab0c,null,null,null):_0x1ab42e=_0x1ab42e['copy'](null,null,null,null,_0x1ab42e['right']['insert'](_0x37e51f,_0x29ab0c,_0x38966c)),_0x1ab42e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4ff8c3=this;return!_0x4ff8c3['left']['isRed_']()&&!_0x4ff8c3['left']['left']['isRed_']()&&(_0x4ff8c3=_0x4ff8c3['moveRedLeft_']()),_0x4ff8c3=_0x4ff8c3['copy'](null,null,null,_0x4ff8c3['left']['removeMin_'](),null),_0x4ff8c3['fixUp_']();}['remove'](_0x32ad7e,_0x3a32fb){let _0x390719,_0x2dcf93;if(_0x390719=this,_0x3a32fb(_0x32ad7e,_0x390719['key'])<0x0)!_0x390719['left']['isEmpty']()&&!_0x390719['left']['isRed_']()&&!_0x390719['left']['left']['isRed_']()&&(_0x390719=_0x390719['moveRedLeft_']()),_0x390719=_0x390719['copy'](null,null,null,_0x390719['left']['remove'](_0x32ad7e,_0x3a32fb),null);else{if(_0x390719['left']['isRed_']()&&(_0x390719=_0x390719['rotateRight_']()),!_0x390719['right']['isEmpty']()&&!_0x390719['right']['isRed_']()&&!_0x390719['right']['left']['isRed_']()&&(_0x390719=_0x390719['moveRedRight_']()),_0x3a32fb(_0x32ad7e,_0x390719['key'])===0x0){if(_0x390719['right']['isEmpty']())return B['EMPTY_NODE'];_0x2dcf93=_0x390719['right']['min_'](),_0x390719=_0x390719['copy'](_0x2dcf93['key'],_0x2dcf93['value'],null,null,_0x390719['right']['removeMin_']());}_0x390719=_0x390719['copy'](null,null,null,null,_0x390719['right']['remove'](_0x32ad7e,_0x3a32fb));}return _0x390719['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5929a6=this;return _0x5929a6['right']['isRed_']()&&!_0x5929a6['left']['isRed_']()&&(_0x5929a6=_0x5929a6['rotateLeft_']()),_0x5929a6['left']['isRed_']()&&_0x5929a6['left']['left']['isRed_']()&&(_0x5929a6=_0x5929a6['rotateRight_']()),_0x5929a6['left']['isRed_']()&&_0x5929a6['right']['isRed_']()&&(_0x5929a6=_0x5929a6['colorFlip_']()),_0x5929a6;}['moveRedLeft_'](){let _0x3d0efb=this['colorFlip_']();return _0x3d0efb['right']['left']['isRed_']()&&(_0x3d0efb=_0x3d0efb['copy'](null,null,null,null,_0x3d0efb['right']['rotateRight_']()),_0x3d0efb=_0x3d0efb['rotateLeft_'](),_0x3d0efb=_0x3d0efb['colorFlip_']()),_0x3d0efb;}['moveRedRight_'](){let _0x54349a=this['colorFlip_']();return _0x54349a['left']['left']['isRed_']()&&(_0x54349a=_0x54349a['rotateRight_'](),_0x54349a=_0x54349a['colorFlip_']()),_0x54349a;}['rotateLeft_'](){const _0x301cc9=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x301cc9,null);}['rotateRight_'](){const _0x53fb5f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x53fb5f);}['colorFlip_'](){const _0x26fb9c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x42f82b=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x26fb9c,_0x42f82b);}['checkMaxDepth_'](){const _0xc5275a=this['check_']();return Math['pow'](0x2,_0xc5275a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x3255b1=this['left']['check_']();if(_0x3255b1!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x3255b1+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x78a2b2,_0x446791,_0x2e6a2,_0x1a9734,_0x333148){return this;}['insert'](_0x271fd0,_0x3f3228,_0x53495d){return new M(_0x271fd0,_0x3f3228,null);}['remove'](_0xc6d5da,_0x418820){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x466714){return!0x1;}['reverseTraversal'](_0x31788f){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x35ce45,_0x5d2e7a=B['EMPTY_NODE']){this['comparator_']=_0x35ce45,this['root_']=_0x5d2e7a;}['insert'](_0x311f3e,_0x3ba0cb){return new B(this['comparator_'],this['root_']['insert'](_0x311f3e,_0x3ba0cb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4511f3){return new B(this['comparator_'],this['root_']['remove'](_0x4511f3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2f03e4){let _0x92ff29,_0x2ab29b=this['root_'];for(;!_0x2ab29b['isEmpty']();){if(_0x92ff29=this['comparator_'](_0x2f03e4,_0x2ab29b['key']),_0x92ff29===0x0)return _0x2ab29b['value'];_0x92ff29<0x0?_0x2ab29b=_0x2ab29b['left']:_0x92ff29>0x0&&(_0x2ab29b=_0x2ab29b['right']);}return null;}['getPredecessorKey'](_0x147f31){let _0x3661fd,_0x791927=this['root_'],_0x3b957f=null;for(;!_0x791927['isEmpty']();)if(_0x3661fd=this['comparator_'](_0x147f31,_0x791927['key']),_0x3661fd===0x0){if(_0x791927['left']['isEmpty']())return _0x3b957f?_0x3b957f['key']:null;for(_0x791927=_0x791927['left'];!_0x791927['right']['isEmpty']();)_0x791927=_0x791927['right'];return _0x791927['key'];}else _0x3661fd<0x0?_0x791927=_0x791927['left']:_0x3661fd>0x0&&(_0x3b957f=_0x791927,_0x791927=_0x791927['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x33181c){return this['root_']['inorderTraversal'](_0x33181c);}['reverseTraversal'](_0x5f2cfe){return this['root_']['reverseTraversal'](_0x5f2cfe);}['getIterator'](_0x2e3f57){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x2e3f57);}['getIteratorFrom'](_0x20cc0f,_0x47daef){return new Zt(this['root_'],_0x20cc0f,this['comparator_'],!0x1,_0x47daef);}['getReverseIteratorFrom'](_0x1109f5,_0x4988fb){return new Zt(this['root_'],_0x1109f5,this['comparator_'],!0x0,_0x4988fb);}['getReverseIterator'](_0x5876e7){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x5876e7);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x656d9a,_0x3ea9bf){return He(_0x656d9a['name'],_0x3ea9bf['name']);}function ji(_0x48ef13,_0x393ebb){return He(_0x48ef13,_0x393ebb);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x2b4363){vi=_0x2b4363;}const Ro=function(_0x5e6d1a){return typeof _0x5e6d1a=='number'?'number:'+so(_0x5e6d1a):'string:'+_0x5e6d1a;},Ao=function(_0x1fa84f){if(_0x1fa84f['isLeafNode']()){const _0x28eeb4=_0x1fa84f['val']();f(typeof _0x28eeb4=='string'||typeof _0x28eeb4=='number'||typeof _0x28eeb4=='object'&&Y(_0x28eeb4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1fa84f===vi||_0x1fa84f['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1fa84f===vi||_0x1fa84f['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x9da97c){er=_0x9da97c;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xa527ae,_0x11e139=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xa527ae,this['priorityNode_']=_0x11e139,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x235651){return new D(this['value_'],_0x235651);}['getImmediateChild'](_0x4fddec){return _0x4fddec==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2e0f86){return v(_0x2e0f86)?this:y(_0x2e0f86)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1f79b6,_0x431e94){return null;}['updateImmediateChild'](_0x3a87e3,_0x21f6e3){return _0x3a87e3==='.priority'?this['updatePriority'](_0x21f6e3):_0x21f6e3['isEmpty']()&&_0x3a87e3!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x3a87e3,_0x21f6e3)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1f1b46,_0x11cf09){const _0x47821b=y(_0x1f1b46);return _0x47821b===null?_0x11cf09:_0x11cf09['isEmpty']()&&_0x47821b!=='.priority'?this:(f(_0x47821b!=='.priority'||we(_0x1f1b46)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x47821b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1f1b46),_0x11cf09)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x406108,_0x523279){return!0x1;}['val'](_0x102133){return _0x102133&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3ea6a4='';this['priorityNode_']['isEmpty']()||(_0x3ea6a4+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2aa307=typeof this['value_'];_0x3ea6a4+=_0x2aa307+':',_0x2aa307==='number'?_0x3ea6a4+=so(this['value_']):_0x3ea6a4+=this['value_'],this['lazyHash_']=no(_0x3ea6a4);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3470eb){return _0x3470eb===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3470eb instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3470eb['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3470eb));}['compareToLeafNode_'](_0x490009){const _0x3e86d0=typeof _0x490009['value_'],_0x5bb21e=typeof this['value_'],_0x433e2c=D['VALUE_TYPE_ORDER']['indexOf'](_0x3e86d0),_0x8a4e0f=D['VALUE_TYPE_ORDER']['indexOf'](_0x5bb21e);return f(_0x433e2c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3e86d0),f(_0x8a4e0f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5bb21e),_0x433e2c===_0x8a4e0f?_0x5bb21e==='object'?0x0:this['value_']<_0x490009['value_']?-0x1:this['value_']===_0x490009['value_']?0x0:0x1:_0x8a4e0f-_0x433e2c;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x58a7ab){if(_0x58a7ab===this)return!0x0;if(_0x58a7ab['isLeafNode']()){const _0x14edcd=_0x58a7ab;return this['value_']===_0x14edcd['value_']&&this['priorityNode_']['equals'](_0x14edcd['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3a8679){ko=_0x3a8679;}function xh(_0xb13c55){No=_0xb13c55;}class Fh extends On{['compare'](_0x309170,_0x4b9b5d){const _0x210033=_0x309170['node']['getPriority'](),_0x345564=_0x4b9b5d['node']['getPriority'](),_0x2a71f9=_0x210033['compareTo'](_0x345564);return _0x2a71f9===0x0?He(_0x309170['name'],_0x4b9b5d['name']):_0x2a71f9;}['isDefinedOn'](_0x2cf17a){return!_0x2cf17a['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1faf03,_0x4444cf){return!_0x1faf03['getPriority']()['equals'](_0x4444cf['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2f5cb1,_0x5a72c8){const _0x14c0fb=ko(_0x2f5cb1);return new E(_0x5a72c8,new D('[PRIORITY-POST]',_0x14c0fb));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4aa370){const _0x5eafff=_0x25c45d=>parseInt(Math['log'](_0x25c45d)/Uh,0xa),_0x10f90d=_0x2eb7c9=>parseInt(Array(_0x2eb7c9+0x1)['join']('1'),0x2);this['count']=_0x5eafff(_0x4aa370+0x1),this['current_']=this['count']-0x1;const _0x4c2459=_0x10f90d(this['count']);this['bits_']=_0x4aa370+0x1&_0x4c2459;}['nextBitIsOne'](){const _0x138da2=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x138da2;}}const dn=function(_0x215b6f,_0x517980,_0x2af692,_0x345428){_0x215b6f['sort'](_0x517980);const _0xd6beb9=function(_0x471f19,_0x32f727){const _0xa7cd43=_0x32f727-_0x471f19;let _0x29e775,_0x444339;if(_0xa7cd43===0x0)return null;if(_0xa7cd43===0x1)return _0x29e775=_0x215b6f[_0x471f19],_0x444339=_0x2af692?_0x2af692(_0x29e775):_0x29e775,new M(_0x444339,_0x29e775['node'],M['BLACK'],null,null);{const _0x55d847=parseInt(_0xa7cd43/0x2,0xa)+_0x471f19,_0x3196fc=_0xd6beb9(_0x471f19,_0x55d847),_0x4b5379=_0xd6beb9(_0x55d847+0x1,_0x32f727);return _0x29e775=_0x215b6f[_0x55d847],_0x444339=_0x2af692?_0x2af692(_0x29e775):_0x29e775,new M(_0x444339,_0x29e775['node'],M['BLACK'],_0x3196fc,_0x4b5379);}},_0x314eb1=function(_0x5e8ac0){let _0x41c72f=null,_0x30ed66=null,_0x393f40=_0x215b6f['length'];const _0x3d2171=function(_0x162918,_0x625019){const _0x924198=_0x393f40-_0x162918,_0x3d6fa4=_0x393f40;_0x393f40-=_0x162918;const _0x3caa0d=_0xd6beb9(_0x924198+0x1,_0x3d6fa4),_0x53db83=_0x215b6f[_0x924198],_0x1f43d0=_0x2af692?_0x2af692(_0x53db83):_0x53db83;_0x51f163(new M(_0x1f43d0,_0x53db83['node'],_0x625019,null,_0x3caa0d));},_0x51f163=function(_0x372985){_0x41c72f?(_0x41c72f['left']=_0x372985,_0x41c72f=_0x372985):(_0x30ed66=_0x372985,_0x41c72f=_0x372985);};for(let _0x923ddf=0x0;_0x923ddf<_0x5e8ac0['count'];++_0x923ddf){const _0x741c99=_0x5e8ac0['nextBitIsOne'](),_0x340095=Math['pow'](0x2,_0x5e8ac0['count']-(_0x923ddf+0x1));_0x741c99?_0x3d2171(_0x340095,M['BLACK']):(_0x3d2171(_0x340095,M['BLACK']),_0x3d2171(_0x340095,M['RED']));}return _0x30ed66;},_0x5df360=new Wh(_0x215b6f['length']),_0x416c47=_0x314eb1(_0x5df360);return new B(_0x345428||_0x517980,_0x416c47);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x12e60e,_0x25ba0e){this['indexes_']=_0x12e60e,this['indexSet_']=_0x25ba0e;}['get'](_0x4b957e){const _0x55bb79=Oe(this['indexes_'],_0x4b957e);if(!_0x55bb79)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4b957e);return _0x55bb79 instanceof B?_0x55bb79:null;}['hasIndex'](_0x1a78da){return Y(this['indexSet_'],_0x1a78da['toString']());}['addIndex'](_0x3959ba,_0x23ef6e){f(_0x3959ba!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4fef6e=[];let _0x1ab7ba=!0x1;const _0x157c1e=_0x23ef6e['getIterator'](E['Wrap']);let _0x1df2cc=_0x157c1e['getNext']();for(;_0x1df2cc;)_0x1ab7ba=_0x1ab7ba||_0x3959ba['isDefinedOn'](_0x1df2cc['node']),_0x4fef6e['push'](_0x1df2cc),_0x1df2cc=_0x157c1e['getNext']();let _0x170b25;_0x1ab7ba?_0x170b25=dn(_0x4fef6e,_0x3959ba['getCompare']()):_0x170b25=je;const _0x4cc6be=_0x3959ba['toString'](),_0x2b0ce8={...this['indexSet_']};_0x2b0ce8[_0x4cc6be]=_0x3959ba;const _0x15bc6a={...this['indexes_']};return _0x15bc6a[_0x4cc6be]=_0x170b25,new ee(_0x15bc6a,_0x2b0ce8);}['addToIndexes'](_0x54abb1,_0x4c5f2d){const _0x5f1f3f=ln(this['indexes_'],(_0x423fc2,_0x224268)=>{const _0x2fb5b0=Oe(this['indexSet_'],_0x224268);if(f(_0x2fb5b0,'Missing\x20index\x20implementation\x20for\x20'+_0x224268),_0x423fc2===je){if(_0x2fb5b0['isDefinedOn'](_0x54abb1['node'])){const _0x45848d=[],_0x315437=_0x4c5f2d['getIterator'](E['Wrap']);let _0x14f4be=_0x315437['getNext']();for(;_0x14f4be;)_0x14f4be['name']!==_0x54abb1['name']&&_0x45848d['push'](_0x14f4be),_0x14f4be=_0x315437['getNext']();return _0x45848d['push'](_0x54abb1),dn(_0x45848d,_0x2fb5b0['getCompare']());}else return je;}else{const _0x3bc856=_0x4c5f2d['get'](_0x54abb1['name']);let _0x13b776=_0x423fc2;return _0x3bc856&&(_0x13b776=_0x13b776['remove'](new E(_0x54abb1['name'],_0x3bc856))),_0x13b776['insert'](_0x54abb1,_0x54abb1['node']);}});return new ee(_0x5f1f3f,this['indexSet_']);}['removeFromIndexes'](_0x2ed4a0,_0x4aeeb0){const _0xef0f3d=ln(this['indexes_'],_0x5c2ab0=>{if(_0x5c2ab0===je)return _0x5c2ab0;{const _0x54ed15=_0x4aeeb0['get'](_0x2ed4a0['name']);return _0x54ed15?_0x5c2ab0['remove'](new E(_0x2ed4a0['name'],_0x54ed15)):_0x5c2ab0;}});return new ee(_0xef0f3d,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x537727,_0x38fba3,_0xb3d27d){this['children_']=_0x537727,this['priorityNode_']=_0x38fba3,this['indexMap_']=_0xb3d27d,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x38c7cd){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x38c7cd,this['indexMap_']);}['getImmediateChild'](_0xa8a4ce){if(_0xa8a4ce==='.priority')return this['getPriority']();{const _0x50575d=this['children_']['get'](_0xa8a4ce);return _0x50575d===null?gt:_0x50575d;}}['getChild'](_0x2ec635){const _0x37ddb0=y(_0x2ec635);return _0x37ddb0===null?this:this['getImmediateChild'](_0x37ddb0)['getChild'](b(_0x2ec635));}['hasChild'](_0x2dbd21){return this['children_']['get'](_0x2dbd21)!==null;}['updateImmediateChild'](_0x5eddfd,_0x2a24ad){if(f(_0x2a24ad,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5eddfd==='.priority')return this['updatePriority'](_0x2a24ad);{const _0xf7deaa=new E(_0x5eddfd,_0x2a24ad);let _0xbbd703,_0x3a7713;_0x2a24ad['isEmpty']()?(_0xbbd703=this['children_']['remove'](_0x5eddfd),_0x3a7713=this['indexMap_']['removeFromIndexes'](_0xf7deaa,this['children_'])):(_0xbbd703=this['children_']['insert'](_0x5eddfd,_0x2a24ad),_0x3a7713=this['indexMap_']['addToIndexes'](_0xf7deaa,this['children_']));const _0x25ad59=_0xbbd703['isEmpty']()?gt:this['priorityNode_'];return new g(_0xbbd703,_0x25ad59,_0x3a7713);}}['updateChild'](_0x49eb0f,_0x4068d0){const _0x1c430d=y(_0x49eb0f);if(_0x1c430d===null)return _0x4068d0;{f(y(_0x49eb0f)!=='.priority'||we(_0x49eb0f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x55fc77=this['getImmediateChild'](_0x1c430d)['updateChild'](b(_0x49eb0f),_0x4068d0);return this['updateImmediateChild'](_0x1c430d,_0x55fc77);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x54722a){if(this['isEmpty']())return null;const _0x5f22ac={};let _0x51c2b7=0x0,_0x442f28=0x0,_0x497883=!0x0;if(this['forEachChild'](R,(_0x245582,_0x109e28)=>{_0x5f22ac[_0x245582]=_0x109e28['val'](_0x54722a),_0x51c2b7++,_0x497883&&g['INTEGER_REGEXP_']['test'](_0x245582)?_0x442f28=Math['max'](_0x442f28,Number(_0x245582)):_0x497883=!0x1;}),!_0x54722a&&_0x497883&&_0x442f28<0x2*_0x51c2b7){const _0xa4afa0=[];for(const _0x53dff in _0x5f22ac)_0xa4afa0[_0x53dff]=_0x5f22ac[_0x53dff];return _0xa4afa0;}else return _0x54722a&&!this['getPriority']()['isEmpty']()&&(_0x5f22ac['.priority']=this['getPriority']()['val']()),_0x5f22ac;}['hash'](){if(this['lazyHash_']===null){let _0x4b8ae7='';this['getPriority']()['isEmpty']()||(_0x4b8ae7+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x289d2a,_0xc51531)=>{const _0x311fca=_0xc51531['hash']();_0x311fca!==''&&(_0x4b8ae7+=':'+_0x289d2a+':'+_0x311fca);}),this['lazyHash_']=_0x4b8ae7===''?'':no(_0x4b8ae7);}return this['lazyHash_'];}['getPredecessorChildName'](_0x598997,_0x4b3df1,_0x35cca7){const _0x1352bf=this['resolveIndex_'](_0x35cca7);if(_0x1352bf){const _0x56b40e=_0x1352bf['getPredecessorKey'](new E(_0x598997,_0x4b3df1));return _0x56b40e?_0x56b40e['name']:null;}else return this['children_']['getPredecessorKey'](_0x598997);}['getFirstChildName'](_0x1a51cf){const _0x5711ec=this['resolveIndex_'](_0x1a51cf);if(_0x5711ec){const _0x297ada=_0x5711ec['minKey']();return _0x297ada&&_0x297ada['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xdaa471){const _0x300656=this['getFirstChildName'](_0xdaa471);return _0x300656?new E(_0x300656,this['children_']['get'](_0x300656)):null;}['getLastChildName'](_0x2a6817){const _0x382016=this['resolveIndex_'](_0x2a6817);if(_0x382016){const _0x42d8d1=_0x382016['maxKey']();return _0x42d8d1&&_0x42d8d1['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4e4f63){const _0x3735c0=this['getLastChildName'](_0x4e4f63);return _0x3735c0?new E(_0x3735c0,this['children_']['get'](_0x3735c0)):null;}['forEachChild'](_0x6149bd,_0x86a89f){const _0x1c425f=this['resolveIndex_'](_0x6149bd);return _0x1c425f?_0x1c425f['inorderTraversal'](_0x202ca5=>_0x86a89f(_0x202ca5['name'],_0x202ca5['node'])):this['children_']['inorderTraversal'](_0x86a89f);}['getIterator'](_0x1eddc6){return this['getIteratorFrom'](_0x1eddc6['minPost'](),_0x1eddc6);}['getIteratorFrom'](_0x36559a,_0x367a79){const _0x4802d2=this['resolveIndex_'](_0x367a79);if(_0x4802d2)return _0x4802d2['getIteratorFrom'](_0x36559a,_0x143c30=>_0x143c30);{const _0x58ecc5=this['children_']['getIteratorFrom'](_0x36559a['name'],E['Wrap']);let _0x2571ae=_0x58ecc5['peek']();for(;_0x2571ae!=null&&_0x367a79['compare'](_0x2571ae,_0x36559a)<0x0;)_0x58ecc5['getNext'](),_0x2571ae=_0x58ecc5['peek']();return _0x58ecc5;}}['getReverseIterator'](_0x417730){return this['getReverseIteratorFrom'](_0x417730['maxPost'](),_0x417730);}['getReverseIteratorFrom'](_0x409dd8,_0x32245d){const _0x320387=this['resolveIndex_'](_0x32245d);if(_0x320387)return _0x320387['getReverseIteratorFrom'](_0x409dd8,_0x1fcb20=>_0x1fcb20);{const _0x3c4eeb=this['children_']['getReverseIteratorFrom'](_0x409dd8['name'],E['Wrap']);let _0x55ef0e=_0x3c4eeb['peek']();for(;_0x55ef0e!=null&&_0x32245d['compare'](_0x55ef0e,_0x409dd8)>0x0;)_0x3c4eeb['getNext'](),_0x55ef0e=_0x3c4eeb['peek']();return _0x3c4eeb;}}['compareTo'](_0xbae687){return this['isEmpty']()?_0xbae687['isEmpty']()?0x0:-0x1:_0xbae687['isLeafNode']()||_0xbae687['isEmpty']()?0x1:_0xbae687===Ht?-0x1:0x0;}['withIndex'](_0x5d57a4){if(_0x5d57a4===ye||this['indexMap_']['hasIndex'](_0x5d57a4))return this;{const _0x24214e=this['indexMap_']['addIndex'](_0x5d57a4,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x24214e);}}['isIndexed'](_0x3d5aad){return _0x3d5aad===ye||this['indexMap_']['hasIndex'](_0x3d5aad);}['equals'](_0xeec9bd){if(_0xeec9bd===this)return!0x0;if(_0xeec9bd['isLeafNode']())return!0x1;{const _0x455091=_0xeec9bd;if(this['getPriority']()['equals'](_0x455091['getPriority']())){if(this['children_']['count']()===_0x455091['children_']['count']()){const _0x46c178=this['getIterator'](R),_0x365894=_0x455091['getIterator'](R);let _0x3904c3=_0x46c178['getNext'](),_0x104dca=_0x365894['getNext']();for(;_0x3904c3&&_0x104dca;){if(_0x3904c3['name']!==_0x104dca['name']||!_0x3904c3['node']['equals'](_0x104dca['node']))return!0x1;_0x3904c3=_0x46c178['getNext'](),_0x104dca=_0x365894['getNext']();}return _0x3904c3===null&&_0x104dca===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x45e70c){return _0x45e70c===ye?null:this['indexMap_']['get'](_0x45e70c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x3a8cfd){return _0x3a8cfd===this?0x0:0x1;}['equals'](_0x2dd409){return _0x2dd409===this;}['getPriority'](){return this;}['getImmediateChild'](_0x105f39){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0xdcca40,_0x34caab=null){if(_0xdcca40===null)return g['EMPTY_NODE'];if(typeof _0xdcca40=='object'&&'.priority'in _0xdcca40&&(_0x34caab=_0xdcca40['.priority']),f(_0x34caab===null||typeof _0x34caab=='string'||typeof _0x34caab=='number'||typeof _0x34caab=='object'&&'.sv'in _0x34caab,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x34caab),typeof _0xdcca40=='object'&&'.value'in _0xdcca40&&_0xdcca40['.value']!==null&&(_0xdcca40=_0xdcca40['.value']),typeof _0xdcca40!='object'||'.sv'in _0xdcca40){const _0x4afcb6=_0xdcca40;return new D(_0x4afcb6,N(_0x34caab));}if(!(_0xdcca40 instanceof Array)&&Vh){const _0x383ca3=[];let _0x2f504e=!0x1;if(x(_0xdcca40,(_0x52e9ae,_0x158483)=>{if(_0x52e9ae['substring'](0x0,0x1)!=='.'){const _0x376fbe=N(_0x158483);_0x376fbe['isEmpty']()||(_0x2f504e=_0x2f504e||!_0x376fbe['getPriority']()['isEmpty'](),_0x383ca3['push'](new E(_0x52e9ae,_0x376fbe)));}}),_0x383ca3['length']===0x0)return g['EMPTY_NODE'];const _0x5f0ec7=dn(_0x383ca3,Dh,_0x873bd8=>_0x873bd8['name'],ji);if(_0x2f504e){const _0x2fbe0a=dn(_0x383ca3,R['getCompare']());return new g(_0x5f0ec7,N(_0x34caab),new ee({'.priority':_0x2fbe0a},{'.priority':R}));}else return new g(_0x5f0ec7,N(_0x34caab),ee['Default']);}else{let _0x291caf=g['EMPTY_NODE'];return x(_0xdcca40,(_0x597637,_0x5df9b2)=>{if(Y(_0xdcca40,_0x597637)&&_0x597637['substring'](0x0,0x1)!=='.'){const _0xb79572=N(_0x5df9b2);(_0xb79572['isLeafNode']()||!_0xb79572['isEmpty']())&&(_0x291caf=_0x291caf['updateImmediateChild'](_0x597637,_0xb79572));}}),_0x291caf['updatePriority'](N(_0x34caab));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x583c13){super(),this['indexPath_']=_0x583c13,f(!v(_0x583c13)&&y(_0x583c13)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x21a302){return _0x21a302['getChild'](this['indexPath_']);}['isDefinedOn'](_0x470afd){return!_0x470afd['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x20dfc7,_0x47e069){const _0x16d65b=this['extractChild'](_0x20dfc7['node']),_0x3c077d=this['extractChild'](_0x47e069['node']),_0x50ceba=_0x16d65b['compareTo'](_0x3c077d);return _0x50ceba===0x0?He(_0x20dfc7['name'],_0x47e069['name']):_0x50ceba;}['makePost'](_0x4eb977,_0x1877fa){const _0xf240dd=N(_0x4eb977),_0x2c3635=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xf240dd);return new E(_0x1877fa,_0x2c3635);}['maxPost'](){const _0x38dc8e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x38dc8e);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x3d3aef,_0x895ad2){const _0x292e8d=_0x3d3aef['node']['compareTo'](_0x895ad2['node']);return _0x292e8d===0x0?He(_0x3d3aef['name'],_0x895ad2['name']):_0x292e8d;}['isDefinedOn'](_0x437ed8){return!0x0;}['indexedValueChanged'](_0xb618ea,_0x22408e){return!_0xb618ea['equals'](_0x22408e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3fa421,_0x431e60){const _0x42c203=N(_0x3fa421);return new E(_0x431e60,_0x42c203);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x53ef03){return{'type':'value','snapshotNode':_0x53ef03};}function tt(_0x31586a,_0x4f9e9c){return{'type':'child_added','snapshotNode':_0x4f9e9c,'childName':_0x31586a};}function Nt(_0x49c9b7,_0x21f2ff){return{'type':'child_removed','snapshotNode':_0x21f2ff,'childName':_0x49c9b7};}function Pt(_0x1e2331,_0x36ccb0,_0x3e00c1){return{'type':'child_changed','snapshotNode':_0x36ccb0,'childName':_0x1e2331,'oldSnap':_0x3e00c1};}function $h(_0x19c7bb,_0x42761a){return{'type':'child_moved','snapshotNode':_0x42761a,'childName':_0x19c7bb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x4c6bf5){this['index_']=_0x4c6bf5;}['updateChild'](_0x43564d,_0x328a5d,_0x11e5e5,_0x41473f,_0x59fb8e,_0x5ad47f){f(_0x43564d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x21095d=_0x43564d['getImmediateChild'](_0x328a5d);return _0x21095d['getChild'](_0x41473f)['equals'](_0x11e5e5['getChild'](_0x41473f))&&_0x21095d['isEmpty']()===_0x11e5e5['isEmpty']()||(_0x5ad47f!=null&&(_0x11e5e5['isEmpty']()?_0x43564d['hasChild'](_0x328a5d)?_0x5ad47f['trackChildChange'](Nt(_0x328a5d,_0x21095d)):f(_0x43564d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x21095d['isEmpty']()?_0x5ad47f['trackChildChange'](tt(_0x328a5d,_0x11e5e5)):_0x5ad47f['trackChildChange'](Pt(_0x328a5d,_0x11e5e5,_0x21095d))),_0x43564d['isLeafNode']()&&_0x11e5e5['isEmpty']())?_0x43564d:_0x43564d['updateImmediateChild'](_0x328a5d,_0x11e5e5)['withIndex'](this['index_']);}['updateFullNode'](_0x91f4e7,_0x1d97db,_0x40da95){return _0x40da95!=null&&(_0x91f4e7['isLeafNode']()||_0x91f4e7['forEachChild'](R,(_0x466e1c,_0x430ebb)=>{_0x1d97db['hasChild'](_0x466e1c)||_0x40da95['trackChildChange'](Nt(_0x466e1c,_0x430ebb));}),_0x1d97db['isLeafNode']()||_0x1d97db['forEachChild'](R,(_0x3c3eae,_0xdbf8fc)=>{if(_0x91f4e7['hasChild'](_0x3c3eae)){const _0x2dc7a4=_0x91f4e7['getImmediateChild'](_0x3c3eae);_0x2dc7a4['equals'](_0xdbf8fc)||_0x40da95['trackChildChange'](Pt(_0x3c3eae,_0xdbf8fc,_0x2dc7a4));}else _0x40da95['trackChildChange'](tt(_0x3c3eae,_0xdbf8fc));})),_0x1d97db['withIndex'](this['index_']);}['updatePriority'](_0x57c316,_0x192ade){return _0x57c316['isEmpty']()?g['EMPTY_NODE']:_0x57c316['updatePriority'](_0x192ade);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x587a7d){this['indexedFilter_']=new Yi(_0x587a7d['getIndex']()),this['index_']=_0x587a7d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x587a7d),this['endPost_']=Ot['getEndPost_'](_0x587a7d),this['startIsInclusive_']=!_0x587a7d['startAfterSet_'],this['endIsInclusive_']=!_0x587a7d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x592dcf){const _0x27814e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x592dcf)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x592dcf)<0x0,_0x28800a=this['endIsInclusive_']?this['index_']['compare'](_0x592dcf,this['getEndPost']())<=0x0:this['index_']['compare'](_0x592dcf,this['getEndPost']())<0x0;return _0x27814e&&_0x28800a;}['updateChild'](_0x38d532,_0x4ce97b,_0x4ab1ad,_0x118791,_0x448590,_0x2cffaa){return this['matches'](new E(_0x4ce97b,_0x4ab1ad))||(_0x4ab1ad=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x38d532,_0x4ce97b,_0x4ab1ad,_0x118791,_0x448590,_0x2cffaa);}['updateFullNode'](_0x552e38,_0x13f868,_0xfa287){_0x13f868['isLeafNode']()&&(_0x13f868=g['EMPTY_NODE']);let _0x59fde5=_0x13f868['withIndex'](this['index_']);_0x59fde5=_0x59fde5['updatePriority'](g['EMPTY_NODE']);const _0x3acef0=this;return _0x13f868['forEachChild'](R,(_0x42111b,_0x312cce)=>{_0x3acef0['matches'](new E(_0x42111b,_0x312cce))||(_0x59fde5=_0x59fde5['updateImmediateChild'](_0x42111b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x552e38,_0x59fde5,_0xfa287);}['updatePriority'](_0x5a8a9f,_0x18f5f5){return _0x5a8a9f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x19d28f){if(_0x19d28f['hasStart']()){const _0x159783=_0x19d28f['getIndexStartName']();return _0x19d28f['getIndex']()['makePost'](_0x19d28f['getIndexStartValue'](),_0x159783);}else return _0x19d28f['getIndex']()['minPost']();}static['getEndPost_'](_0x3a1a63){if(_0x3a1a63['hasEnd']()){const _0x978025=_0x3a1a63['getIndexEndName']();return _0x3a1a63['getIndex']()['makePost'](_0x3a1a63['getIndexEndValue'](),_0x978025);}else return _0x3a1a63['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x13fe82){this['withinDirectionalStart']=_0x1118cc=>this['reverse_']?this['withinEndPost'](_0x1118cc):this['withinStartPost'](_0x1118cc),this['withinDirectionalEnd']=_0x1fd63a=>this['reverse_']?this['withinStartPost'](_0x1fd63a):this['withinEndPost'](_0x1fd63a),this['withinStartPost']=_0x150771=>{const _0x37e230=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x150771);return this['startIsInclusive_']?_0x37e230<=0x0:_0x37e230<0x0;},this['withinEndPost']=_0x52b3f6=>{const _0x15d176=this['index_']['compare'](_0x52b3f6,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x15d176<=0x0:_0x15d176<0x0;},this['rangedFilter_']=new Ot(_0x13fe82),this['index_']=_0x13fe82['getIndex'](),this['limit_']=_0x13fe82['getLimit'](),this['reverse_']=!_0x13fe82['isViewFromLeft'](),this['startIsInclusive_']=!_0x13fe82['startAfterSet_'],this['endIsInclusive_']=!_0x13fe82['endBeforeSet_'];}['updateChild'](_0x1f749f,_0x598c5e,_0x3efaae,_0x2ed47b,_0x43ff36,_0x14f362){return this['rangedFilter_']['matches'](new E(_0x598c5e,_0x3efaae))||(_0x3efaae=g['EMPTY_NODE']),_0x1f749f['getImmediateChild'](_0x598c5e)['equals'](_0x3efaae)?_0x1f749f:_0x1f749f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1f749f,_0x598c5e,_0x3efaae,_0x2ed47b,_0x43ff36,_0x14f362):this['fullLimitUpdateChild_'](_0x1f749f,_0x598c5e,_0x3efaae,_0x43ff36,_0x14f362);}['updateFullNode'](_0x4c4fea,_0x281fba,_0x1bedb1){let _0x1452f4;if(_0x281fba['isLeafNode']()||_0x281fba['isEmpty']())_0x1452f4=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x281fba['numChildren']()&&_0x281fba['isIndexed'](this['index_'])){_0x1452f4=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1eabe8;this['reverse_']?_0x1eabe8=_0x281fba['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1eabe8=_0x281fba['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xb0cd8=0x0;for(;_0x1eabe8['hasNext']()&&_0xb0cd8<this['limit_'];){const _0xbd10fa=_0x1eabe8['getNext']();if(this['withinDirectionalStart'](_0xbd10fa)){if(this['withinDirectionalEnd'](_0xbd10fa))_0x1452f4=_0x1452f4['updateImmediateChild'](_0xbd10fa['name'],_0xbd10fa['node']),_0xb0cd8++;else break;}else continue;}}else{_0x1452f4=_0x281fba['withIndex'](this['index_']),_0x1452f4=_0x1452f4['updatePriority'](g['EMPTY_NODE']);let _0x47b1f5;this['reverse_']?_0x47b1f5=_0x1452f4['getReverseIterator'](this['index_']):_0x47b1f5=_0x1452f4['getIterator'](this['index_']);let _0x46dcfe=0x0;for(;_0x47b1f5['hasNext']();){const _0x36c04d=_0x47b1f5['getNext']();_0x46dcfe<this['limit_']&&this['withinDirectionalStart'](_0x36c04d)&&this['withinDirectionalEnd'](_0x36c04d)?_0x46dcfe++:_0x1452f4=_0x1452f4['updateImmediateChild'](_0x36c04d['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4c4fea,_0x1452f4,_0x1bedb1);}['updatePriority'](_0x19679c,_0x6f5c5c){return _0x19679c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5eb162,_0x1169ec,_0x355fc5,_0x4db84d,_0x1047d1){let _0x3e8f1c;if(this['reverse_']){const _0x28cc55=this['index_']['getCompare']();_0x3e8f1c=(_0x1ecf85,_0x2a79e1)=>_0x28cc55(_0x2a79e1,_0x1ecf85);}else _0x3e8f1c=this['index_']['getCompare']();const _0x5b9030=_0x5eb162;f(_0x5b9030['numChildren']()===this['limit_'],'');const _0x4ae03f=new E(_0x1169ec,_0x355fc5),_0x3a4c3e=this['reverse_']?_0x5b9030['getFirstChild'](this['index_']):_0x5b9030['getLastChild'](this['index_']),_0x3962da=this['rangedFilter_']['matches'](_0x4ae03f);if(_0x5b9030['hasChild'](_0x1169ec)){const _0xdeb3ea=_0x5b9030['getImmediateChild'](_0x1169ec);let _0x289da2=_0x4db84d['getChildAfterChild'](this['index_'],_0x3a4c3e,this['reverse_']);for(;_0x289da2!=null&&(_0x289da2['name']===_0x1169ec||_0x5b9030['hasChild'](_0x289da2['name']));)_0x289da2=_0x4db84d['getChildAfterChild'](this['index_'],_0x289da2,this['reverse_']);const _0x318ee5=_0x289da2==null?0x1:_0x3e8f1c(_0x289da2,_0x4ae03f);if(_0x3962da&&!_0x355fc5['isEmpty']()&&_0x318ee5>=0x0)return _0x1047d1!=null&&_0x1047d1['trackChildChange'](Pt(_0x1169ec,_0x355fc5,_0xdeb3ea)),_0x5b9030['updateImmediateChild'](_0x1169ec,_0x355fc5);{_0x1047d1!=null&&_0x1047d1['trackChildChange'](Nt(_0x1169ec,_0xdeb3ea));const _0x3b860d=_0x5b9030['updateImmediateChild'](_0x1169ec,g['EMPTY_NODE']);return _0x289da2!=null&&this['rangedFilter_']['matches'](_0x289da2)?(_0x1047d1!=null&&_0x1047d1['trackChildChange'](tt(_0x289da2['name'],_0x289da2['node'])),_0x3b860d['updateImmediateChild'](_0x289da2['name'],_0x289da2['node'])):_0x3b860d;}}else return _0x355fc5['isEmpty']()?_0x5eb162:_0x3962da&&_0x3e8f1c(_0x3a4c3e,_0x4ae03f)>=0x0?(_0x1047d1!=null&&(_0x1047d1['trackChildChange'](Nt(_0x3a4c3e['name'],_0x3a4c3e['node'])),_0x1047d1['trackChildChange'](tt(_0x1169ec,_0x355fc5))),_0x5b9030['updateImmediateChild'](_0x1169ec,_0x355fc5)['updateImmediateChild'](_0x3a4c3e['name'],g['EMPTY_NODE'])):_0x5eb162;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x452c4f=new Qi();return _0x452c4f['limitSet_']=this['limitSet_'],_0x452c4f['limit_']=this['limit_'],_0x452c4f['startSet_']=this['startSet_'],_0x452c4f['startAfterSet_']=this['startAfterSet_'],_0x452c4f['indexStartValue_']=this['indexStartValue_'],_0x452c4f['startNameSet_']=this['startNameSet_'],_0x452c4f['indexStartName_']=this['indexStartName_'],_0x452c4f['endSet_']=this['endSet_'],_0x452c4f['endBeforeSet_']=this['endBeforeSet_'],_0x452c4f['indexEndValue_']=this['indexEndValue_'],_0x452c4f['endNameSet_']=this['endNameSet_'],_0x452c4f['indexEndName_']=this['indexEndName_'],_0x452c4f['index_']=this['index_'],_0x452c4f['viewFrom_']=this['viewFrom_'],_0x452c4f;}}function qh(_0x12fedb){return _0x12fedb['loadsAllData']()?new Yi(_0x12fedb['getIndex']()):_0x12fedb['hasLimit']()?new Gh(_0x12fedb):new Ot(_0x12fedb);}function zh(_0x1c5a86,_0x5a7ca8){const _0x346149=_0x1c5a86['copy']();return _0x346149['limitSet_']=!0x0,_0x346149['limit_']=_0x5a7ca8,_0x346149['viewFrom_']='l',_0x346149;}function jh(_0x28f4a7,_0x589c33,_0x2ffda5){const _0x1c05cb=_0x28f4a7['copy']();return _0x1c05cb['startSet_']=!0x0,_0x589c33===void 0x0&&(_0x589c33=null),_0x1c05cb['indexStartValue_']=_0x589c33,_0x2ffda5!=null?(_0x1c05cb['startNameSet_']=!0x0,_0x1c05cb['indexStartName_']=_0x2ffda5):(_0x1c05cb['startNameSet_']=!0x1,_0x1c05cb['indexStartName_']=''),_0x1c05cb;}function Kh(_0x36a397,_0x5dc6d1,_0x3951a0){const _0x44a756=_0x36a397['copy']();return _0x44a756['endSet_']=!0x0,_0x5dc6d1===void 0x0&&(_0x5dc6d1=null),_0x44a756['indexEndValue_']=_0x5dc6d1,_0x3951a0!==void 0x0?(_0x44a756['endNameSet_']=!0x0,_0x44a756['indexEndName_']=_0x3951a0):(_0x44a756['endNameSet_']=!0x1,_0x44a756['indexEndName_']=''),_0x44a756;}function Do(_0x3af100,_0x313b2a){const _0x4e0a4b=_0x3af100['copy']();return _0x4e0a4b['index_']=_0x313b2a,_0x4e0a4b;}function tr(_0x3ae5d8){const _0x171343={};if(_0x3ae5d8['isDefault']())return _0x171343;let _0x549ff8;if(_0x3ae5d8['index_']===R?_0x549ff8='$priority':_0x3ae5d8['index_']===Po?_0x549ff8='$value':_0x3ae5d8['index_']===ye?_0x549ff8='$key':(f(_0x3ae5d8['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x549ff8=_0x3ae5d8['index_']['toString']()),_0x171343['orderBy']=O(_0x549ff8),_0x3ae5d8['startSet_']){const _0x18181c=_0x3ae5d8['startAfterSet_']?'startAfter':'startAt';_0x171343[_0x18181c]=O(_0x3ae5d8['indexStartValue_']),_0x3ae5d8['startNameSet_']&&(_0x171343[_0x18181c]+=','+O(_0x3ae5d8['indexStartName_']));}if(_0x3ae5d8['endSet_']){const _0x597fb0=_0x3ae5d8['endBeforeSet_']?'endBefore':'endAt';_0x171343[_0x597fb0]=O(_0x3ae5d8['indexEndValue_']),_0x3ae5d8['endNameSet_']&&(_0x171343[_0x597fb0]+=','+O(_0x3ae5d8['indexEndName_']));}return _0x3ae5d8['limitSet_']&&(_0x3ae5d8['isViewFromLeft']()?_0x171343['limitToFirst']=_0x3ae5d8['limit_']:_0x171343['limitToLast']=_0x3ae5d8['limit_']),_0x171343;}function nr(_0x217849){const _0x1956e3={};if(_0x217849['startSet_']&&(_0x1956e3['sp']=_0x217849['indexStartValue_'],_0x217849['startNameSet_']&&(_0x1956e3['sn']=_0x217849['indexStartName_']),_0x1956e3['sin']=!_0x217849['startAfterSet_']),_0x217849['endSet_']&&(_0x1956e3['ep']=_0x217849['indexEndValue_'],_0x217849['endNameSet_']&&(_0x1956e3['en']=_0x217849['indexEndName_']),_0x1956e3['ein']=!_0x217849['endBeforeSet_']),_0x217849['limitSet_']){_0x1956e3['l']=_0x217849['limit_'];let _0x8657be=_0x217849['viewFrom_'];_0x8657be===''&&(_0x217849['isViewFromLeft']()?_0x8657be='l':_0x8657be='r'),_0x1956e3['vf']=_0x8657be;}return _0x217849['index_']!==R&&(_0x1956e3['i']=_0x217849['index_']['toString']()),_0x1956e3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x301570){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x22540e,_0xe29787){return _0xe29787!==void 0x0?'tag$'+_0xe29787:(f(_0x22540e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x22540e['_path']['toString']());}constructor(_0x2e128c,_0x220cd7,_0x4d8da1,_0x37c43a){super(),this['repoInfo_']=_0x2e128c,this['onDataUpdate_']=_0x220cd7,this['authTokenProvider_']=_0x4d8da1,this['appCheckTokenProvider_']=_0x37c43a,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4cfa88,_0x3b9fba,_0x4fc780,_0x18e72e){const _0x2b6cee=_0x4cfa88['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2b6cee+'\x20'+_0x4cfa88['_queryIdentifier']);const _0x93e22f=fn['getListenId_'](_0x4cfa88,_0x4fc780),_0x1a3da7={};this['listens_'][_0x93e22f]=_0x1a3da7;const _0x385be5=tr(_0x4cfa88['_queryParams']);this['restRequest_'](_0x2b6cee+'.json',_0x385be5,(_0x288548,_0x307c6a)=>{let _0x476618=_0x307c6a;if(_0x288548===0x194&&(_0x476618=null,_0x288548=null),_0x288548===null&&this['onDataUpdate_'](_0x2b6cee,_0x476618,!0x1,_0x4fc780),Oe(this['listens_'],_0x93e22f)===_0x1a3da7){let _0x1e52d6;_0x288548?_0x288548===0x191?_0x1e52d6='permission_denied':_0x1e52d6='rest_error:'+_0x288548:_0x1e52d6='ok',_0x18e72e(_0x1e52d6,null);}});}['unlisten'](_0x146811,_0x543705){const _0x3e2e7e=fn['getListenId_'](_0x146811,_0x543705);delete this['listens_'][_0x3e2e7e];}['get'](_0xb27637){const _0x1d3aed=tr(_0xb27637['_queryParams']),_0x574562=_0xb27637['_path']['toString'](),_0x3ab4f4=new Ve();return this['restRequest_'](_0x574562+'.json',_0x1d3aed,(_0x3b1337,_0x1c4de1)=>{let _0x5a833f=_0x1c4de1;_0x3b1337===0x194&&(_0x5a833f=null,_0x3b1337=null),_0x3b1337===null?(this['onDataUpdate_'](_0x574562,_0x5a833f,!0x1,null),_0x3ab4f4['resolve'](_0x5a833f)):_0x3ab4f4['reject'](new Error(_0x5a833f));}),_0x3ab4f4['promise'];}['refreshAuthToken'](_0x981967){}['restRequest_'](_0xf596bc,_0x443be1={},_0x5269af){return _0x443be1['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5d7468,_0x5d88b8])=>{_0x5d7468&&_0x5d7468['accessToken']&&(_0x443be1['auth']=_0x5d7468['accessToken']),_0x5d88b8&&_0x5d88b8['token']&&(_0x443be1['ac']=_0x5d88b8['token']);const _0xfbb40d=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xf596bc+'?ns='+this['repoInfo_']['namespace']+at(_0x443be1);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xfbb40d);const _0x3dffd7=new XMLHttpRequest();_0x3dffd7['onreadystatechange']=()=>{if(_0x5269af&&_0x3dffd7['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xfbb40d+'\x20received.\x20status:',_0x3dffd7['status'],'response:',_0x3dffd7['responseText']);let _0x22e4c5=null;if(_0x3dffd7['status']>=0xc8&&_0x3dffd7['status']<0x12c){try{_0x22e4c5=bt(_0x3dffd7['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xfbb40d+':\x20'+_0x3dffd7['responseText']);}_0x5269af(null,_0x22e4c5);}else _0x3dffd7['status']!==0x191&&_0x3dffd7['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xfbb40d+'\x20Status:\x20'+_0x3dffd7['status']),_0x5269af(_0x3dffd7['status']);_0x5269af=null;}},_0x3dffd7['open']('GET',_0xfbb40d,!0x0),_0x3dffd7['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2875a5){return this['rootNode_']['getChild'](_0x2875a5);}['updateSnapshot'](_0x3c6728,_0x287867){this['rootNode_']=this['rootNode_']['updateChild'](_0x3c6728,_0x287867);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0xd3ee75,_0x50776b,_0x2af851){if(v(_0x50776b))_0xd3ee75['value']=_0x2af851,_0xd3ee75['children']['clear']();else{if(_0xd3ee75['value']!==null)_0xd3ee75['value']=_0xd3ee75['value']['updateChild'](_0x50776b,_0x2af851);else{const _0x27afed=y(_0x50776b);_0xd3ee75['children']['has'](_0x27afed)||_0xd3ee75['children']['set'](_0x27afed,pn());const _0xba4f3f=_0xd3ee75['children']['get'](_0x27afed);_0x50776b=b(_0x50776b),Mo(_0xba4f3f,_0x50776b,_0x2af851);}}}function Ei(_0x55c447,_0x5e4044,_0x424564){_0x55c447['value']!==null?_0x424564(_0x5e4044,_0x55c447['value']):Qh(_0x55c447,(_0x19c7f4,_0x432d9b)=>{const _0x1800aa=new C(_0x5e4044['toString']()+'/'+_0x19c7f4);Ei(_0x432d9b,_0x1800aa,_0x424564);});}function Qh(_0xea5d99,_0x1a0716){_0xea5d99['children']['forEach']((_0x161068,_0x133ba5)=>{_0x1a0716(_0x133ba5,_0x161068);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x334a12){this['collection_']=_0x334a12,this['last_']=null;}['get'](){const _0x1a2199=this['collection_']['get'](),_0x5e495c={..._0x1a2199};return this['last_']&&x(this['last_'],(_0x24abae,_0x4caa15)=>{_0x5e495c[_0x24abae]=_0x5e495c[_0x24abae]-_0x4caa15;}),this['last_']=_0x1a2199,_0x5e495c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x456958,_0x1f2555){this['server_']=_0x1f2555,this['statsToReport_']={},this['statsListener_']=new Jh(_0x456958);const _0x90f24d=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x90f24d));}['reportStats_'](){const _0x2c4f86=this['statsListener_']['get'](),_0x5f0b24={};let _0x3e2b97=!0x1;x(_0x2c4f86,(_0x2df672,_0xd8682f)=>{_0xd8682f>0x0&&Y(this['statsToReport_'],_0x2df672)&&(_0x5f0b24[_0x2df672]=_0xd8682f,_0x3e2b97=!0x0);}),_0x3e2b97&&this['server_']['reportStats'](_0x5f0b24),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x436209){_0x436209[_0x436209['OVERWRITE']=0x0]='OVERWRITE',_0x436209[_0x436209['MERGE']=0x1]='MERGE',_0x436209[_0x436209['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x436209[_0x436209['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x51f80d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x51f80d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x2730af,_0x3facd1,_0x4b762c){this['path']=_0x2730af,this['affectedTree']=_0x3facd1,this['revert']=_0x4b762c,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0xfc3569){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2288ed=this['affectedTree']['subtree'](new C(_0xfc3569));return new _n(w(),_0x2288ed,this['revert']);}}else return f(y(this['path'])===_0xfc3569,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x480b22,_0x4df1e7){this['source']=_0x480b22,this['path']=_0x4df1e7,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x2c696b){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x78c0b1,_0x585b2e,_0x5cc829){this['source']=_0x78c0b1,this['path']=_0x585b2e,this['snap']=_0x5cc829,this['type']=q['OVERWRITE'];}['operationForChild'](_0x5a570e){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x5a570e)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x1c25b6,_0x41e79a,_0x5a242e){this['source']=_0x1c25b6,this['path']=_0x41e79a,this['children']=_0x5a242e,this['type']=q['MERGE'];}['operationForChild'](_0x267dfb){if(v(this['path'])){const _0x223f90=this['children']['subtree'](new C(_0x267dfb));return _0x223f90['isEmpty']()?null:_0x223f90['value']?new Fe(this['source'],w(),_0x223f90['value']):new nt(this['source'],w(),_0x223f90);}else return f(y(this['path'])===_0x267dfb,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x53d0c1,_0x30caa5,_0x5d7d4d){this['node_']=_0x53d0c1,this['fullyInitialized_']=_0x30caa5,this['filtered_']=_0x5d7d4d;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x58ec0f){if(v(_0x58ec0f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4643e5=y(_0x58ec0f);return this['isCompleteForChild'](_0x4643e5);}['isCompleteForChild'](_0x49d63c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x49d63c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x40ab11){this['query_']=_0x40ab11,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0xbe4fd7,_0x29b257,_0x173677,_0x495626){const _0xe86d5f=[],_0x4b72d8=[];return _0x29b257['forEach'](_0x229ebc=>{_0x229ebc['type']==='child_changed'&&_0xbe4fd7['index_']['indexedValueChanged'](_0x229ebc['oldSnap'],_0x229ebc['snapshotNode'])&&_0x4b72d8['push']($h(_0x229ebc['childName'],_0x229ebc['snapshotNode']));}),mt(_0xbe4fd7,_0xe86d5f,'child_removed',_0x29b257,_0x495626,_0x173677),mt(_0xbe4fd7,_0xe86d5f,'child_added',_0x29b257,_0x495626,_0x173677),mt(_0xbe4fd7,_0xe86d5f,'child_moved',_0x4b72d8,_0x495626,_0x173677),mt(_0xbe4fd7,_0xe86d5f,'child_changed',_0x29b257,_0x495626,_0x173677),mt(_0xbe4fd7,_0xe86d5f,'value',_0x29b257,_0x495626,_0x173677),_0xe86d5f;}function mt(_0x214fea,_0x48ef78,_0x40447b,_0x3d0827,_0x284db7,_0x1ffb58){const _0x9df3cd=_0x3d0827['filter'](_0x4ef362=>_0x4ef362['type']===_0x40447b);_0x9df3cd['sort']((_0x438d06,_0x5fb578)=>su(_0x214fea,_0x438d06,_0x5fb578)),_0x9df3cd['forEach'](_0x4730ee=>{const _0x10278a=iu(_0x214fea,_0x4730ee,_0x1ffb58);_0x284db7['forEach'](_0x51057a=>{_0x51057a['respondsTo'](_0x4730ee['type'])&&_0x48ef78['push'](_0x51057a['createEvent'](_0x10278a,_0x214fea['query_']));});});}function iu(_0xc5a404,_0x40e928,_0x6927c8){return _0x40e928['type']==='value'||_0x40e928['type']==='child_removed'||(_0x40e928['prevName']=_0x6927c8['getPredecessorChildName'](_0x40e928['childName'],_0x40e928['snapshotNode'],_0xc5a404['index_'])),_0x40e928;}function su(_0x73ded5,_0x565bfd,_0x4ecf0b){if(_0x565bfd['childName']==null||_0x4ecf0b['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x5dce9b=new E(_0x565bfd['childName'],_0x565bfd['snapshotNode']),_0x32cf22=new E(_0x4ecf0b['childName'],_0x4ecf0b['snapshotNode']);return _0x73ded5['index_']['compare'](_0x5dce9b,_0x32cf22);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x295782,_0x594887){return{'eventCache':_0x295782,'serverCache':_0x594887};}function wt(_0x270391,_0x534a35,_0x2d4b70,_0x5b9f51){return Dn(new Ce(_0x534a35,_0x2d4b70,_0x5b9f51),_0x270391['serverCache']);}function Lo(_0xce130e,_0x41176c,_0x638282,_0x13453c){return Dn(_0xce130e['eventCache'],new Ce(_0x41176c,_0x638282,_0x13453c));}function gn(_0x1db2b2){return _0x1db2b2['eventCache']['isFullyInitialized']()?_0x1db2b2['eventCache']['getNode']():null;}function Ue(_0x5023c9){return _0x5023c9['serverCache']['isFullyInitialized']()?_0x5023c9['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2692ca){let _0x271796=new S(null);return x(_0x2692ca,(_0x2758ac,_0x3e4564)=>{_0x271796=_0x271796['set'](new C(_0x2758ac),_0x3e4564);}),_0x271796;}constructor(_0x4beb64,_0x19a8c3=ru()){this['value']=_0x4beb64,this['children']=_0x19a8c3;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2f6961,_0x5687cb){if(this['value']!=null&&_0x5687cb(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2f6961))return null;{const _0x34ebfa=y(_0x2f6961),_0x317784=this['children']['get'](_0x34ebfa);if(_0x317784!==null){const _0x1a2226=_0x317784['findRootMostMatchingPathAndValue'](b(_0x2f6961),_0x5687cb);return _0x1a2226!=null?{'path':A(new C(_0x34ebfa),_0x1a2226['path']),'value':_0x1a2226['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3ae35d){return this['findRootMostMatchingPathAndValue'](_0x3ae35d,()=>!0x0);}['subtree'](_0x10f8c8){if(v(_0x10f8c8))return this;{const _0x5ee264=y(_0x10f8c8),_0x67cee6=this['children']['get'](_0x5ee264);return _0x67cee6!==null?_0x67cee6['subtree'](b(_0x10f8c8)):new S(null);}}['set'](_0x515057,_0x3b40f1){if(v(_0x515057))return new S(_0x3b40f1,this['children']);{const _0x972bfa=y(_0x515057),_0x20d6ee=(this['children']['get'](_0x972bfa)||new S(null))['set'](b(_0x515057),_0x3b40f1),_0x4870c4=this['children']['insert'](_0x972bfa,_0x20d6ee);return new S(this['value'],_0x4870c4);}}['remove'](_0x514081){if(v(_0x514081))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x28f28a=y(_0x514081),_0x5eb552=this['children']['get'](_0x28f28a);if(_0x5eb552){const _0x344b8d=_0x5eb552['remove'](b(_0x514081));let _0x5b11a7;return _0x344b8d['isEmpty']()?_0x5b11a7=this['children']['remove'](_0x28f28a):_0x5b11a7=this['children']['insert'](_0x28f28a,_0x344b8d),this['value']===null&&_0x5b11a7['isEmpty']()?new S(null):new S(this['value'],_0x5b11a7);}else return this;}}['get'](_0xdc3c93){if(v(_0xdc3c93))return this['value'];{const _0x691e7a=y(_0xdc3c93),_0x346752=this['children']['get'](_0x691e7a);return _0x346752?_0x346752['get'](b(_0xdc3c93)):null;}}['setTree'](_0x212a91,_0x24e205){if(v(_0x212a91))return _0x24e205;{const _0x1966d9=y(_0x212a91),_0x54ae1b=(this['children']['get'](_0x1966d9)||new S(null))['setTree'](b(_0x212a91),_0x24e205);let _0x3d0ebb;return _0x54ae1b['isEmpty']()?_0x3d0ebb=this['children']['remove'](_0x1966d9):_0x3d0ebb=this['children']['insert'](_0x1966d9,_0x54ae1b),new S(this['value'],_0x3d0ebb);}}['fold'](_0x770285){return this['fold_'](w(),_0x770285);}['fold_'](_0x145dff,_0x10b236){const _0x5e23c1={};return this['children']['inorderTraversal']((_0x1d0772,_0x42fe8d)=>{_0x5e23c1[_0x1d0772]=_0x42fe8d['fold_'](A(_0x145dff,_0x1d0772),_0x10b236);}),_0x10b236(_0x145dff,this['value'],_0x5e23c1);}['findOnPath'](_0xe5ec21,_0x2e62d0){return this['findOnPath_'](_0xe5ec21,w(),_0x2e62d0);}['findOnPath_'](_0x60cd4,_0x3914f9,_0x155b04){const _0x5e5551=this['value']?_0x155b04(_0x3914f9,this['value']):!0x1;if(_0x5e5551)return _0x5e5551;if(v(_0x60cd4))return null;{const _0x448da6=y(_0x60cd4),_0x466313=this['children']['get'](_0x448da6);return _0x466313?_0x466313['findOnPath_'](b(_0x60cd4),A(_0x3914f9,_0x448da6),_0x155b04):null;}}['foreachOnPath'](_0xffba26,_0x3e13cb){return this['foreachOnPath_'](_0xffba26,w(),_0x3e13cb);}['foreachOnPath_'](_0x1a3761,_0x5b6715,_0x2e1348){if(v(_0x1a3761))return this;{this['value']&&_0x2e1348(_0x5b6715,this['value']);const _0x378b48=y(_0x1a3761),_0x27a211=this['children']['get'](_0x378b48);return _0x27a211?_0x27a211['foreachOnPath_'](b(_0x1a3761),A(_0x5b6715,_0x378b48),_0x2e1348):new S(null);}}['foreach'](_0x27bb98){this['foreach_'](w(),_0x27bb98);}['foreach_'](_0x5b7b66,_0x3350ae){this['children']['inorderTraversal']((_0x437d4d,_0x11a86b)=>{_0x11a86b['foreach_'](A(_0x5b7b66,_0x437d4d),_0x3350ae);}),this['value']&&_0x3350ae(_0x5b7b66,this['value']);}['foreachChild'](_0x3f25aa){this['children']['inorderTraversal']((_0x409787,_0x141b7d)=>{_0x141b7d['value']&&_0x3f25aa(_0x409787,_0x141b7d['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2deaac){this['writeTree_']=_0x2deaac;}static['empty'](){return new j(new S(null));}}function Ct(_0x30cb32,_0x7e67b5,_0x18cd8e){if(v(_0x7e67b5))return new j(new S(_0x18cd8e));{const _0x3055ba=_0x30cb32['writeTree_']['findRootMostValueAndPath'](_0x7e67b5);if(_0x3055ba!=null){const _0x152e70=_0x3055ba['path'];let _0x384063=_0x3055ba['value'];const _0x2cf538=F(_0x152e70,_0x7e67b5);return _0x384063=_0x384063['updateChild'](_0x2cf538,_0x18cd8e),new j(_0x30cb32['writeTree_']['set'](_0x152e70,_0x384063));}else{const _0x274b95=new S(_0x18cd8e),_0x18b66d=_0x30cb32['writeTree_']['setTree'](_0x7e67b5,_0x274b95);return new j(_0x18b66d);}}}function Ii(_0x2774c7,_0x5b84c7,_0x4af512){let _0x5b36c0=_0x2774c7;return x(_0x4af512,(_0x4af340,_0x1a5025)=>{_0x5b36c0=Ct(_0x5b36c0,A(_0x5b84c7,_0x4af340),_0x1a5025);}),_0x5b36c0;}function sr(_0x154611,_0x75bc1f){if(v(_0x75bc1f))return j['empty']();{const _0x4ff2df=_0x154611['writeTree_']['setTree'](_0x75bc1f,new S(null));return new j(_0x4ff2df);}}function wi(_0x362af8,_0x10072d){return $e(_0x362af8,_0x10072d)!=null;}function $e(_0x58aadf,_0x5766f3){const _0x37a1c7=_0x58aadf['writeTree_']['findRootMostValueAndPath'](_0x5766f3);return _0x37a1c7!=null?_0x58aadf['writeTree_']['get'](_0x37a1c7['path'])['getChild'](F(_0x37a1c7['path'],_0x5766f3)):null;}function rr(_0x1343dd){const _0x1cf7c1=[],_0x7f3a3d=_0x1343dd['writeTree_']['value'];return _0x7f3a3d!=null?_0x7f3a3d['isLeafNode']()||_0x7f3a3d['forEachChild'](R,(_0xf5b0bb,_0x44da55)=>{_0x1cf7c1['push'](new E(_0xf5b0bb,_0x44da55));}):_0x1343dd['writeTree_']['children']['inorderTraversal']((_0x4a8e00,_0x20a258)=>{_0x20a258['value']!=null&&_0x1cf7c1['push'](new E(_0x4a8e00,_0x20a258['value']));}),_0x1cf7c1;}function ve(_0x86579c,_0x1685bd){if(v(_0x1685bd))return _0x86579c;{const _0x3dd0f8=$e(_0x86579c,_0x1685bd);return _0x3dd0f8!=null?new j(new S(_0x3dd0f8)):new j(_0x86579c['writeTree_']['subtree'](_0x1685bd));}}function Ci(_0x5afd5c){return _0x5afd5c['writeTree_']['isEmpty']();}function it(_0x3ffd3a,_0x4407a0){return xo(w(),_0x3ffd3a['writeTree_'],_0x4407a0);}function xo(_0x2d56a6,_0x511819,_0x2386ec){if(_0x511819['value']!=null)return _0x2386ec['updateChild'](_0x2d56a6,_0x511819['value']);{let _0x3638d5=null;return _0x511819['children']['inorderTraversal']((_0x27da2b,_0x5562c8)=>{_0x27da2b==='.priority'?(f(_0x5562c8['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3638d5=_0x5562c8['value']):_0x2386ec=xo(A(_0x2d56a6,_0x27da2b),_0x5562c8,_0x2386ec);}),!_0x2386ec['getChild'](_0x2d56a6)['isEmpty']()&&_0x3638d5!==null&&(_0x2386ec=_0x2386ec['updateChild'](A(_0x2d56a6,'.priority'),_0x3638d5)),_0x2386ec;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x42231b,_0x578b90){return Bo(_0x578b90,_0x42231b);}function ou(_0x5b70e6,_0xbd930a,_0x378fb8,_0x196e8c,_0x2fe41c){f(_0x196e8c>_0x5b70e6['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2fe41c===void 0x0&&(_0x2fe41c=!0x0),_0x5b70e6['allWrites']['push']({'path':_0xbd930a,'snap':_0x378fb8,'writeId':_0x196e8c,'visible':_0x2fe41c}),_0x2fe41c&&(_0x5b70e6['visibleWrites']=Ct(_0x5b70e6['visibleWrites'],_0xbd930a,_0x378fb8)),_0x5b70e6['lastWriteId']=_0x196e8c;}function au(_0xf4b788,_0x5a0857,_0x4c7f9b,_0x621c5e){f(_0x621c5e>_0xf4b788['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xf4b788['allWrites']['push']({'path':_0x5a0857,'children':_0x4c7f9b,'writeId':_0x621c5e,'visible':!0x0}),_0xf4b788['visibleWrites']=Ii(_0xf4b788['visibleWrites'],_0x5a0857,_0x4c7f9b),_0xf4b788['lastWriteId']=_0x621c5e;}function cu(_0x2b0ff1,_0x1e7b0e){for(let _0x287d2b=0x0;_0x287d2b<_0x2b0ff1['allWrites']['length'];_0x287d2b++){const _0x3b39bc=_0x2b0ff1['allWrites'][_0x287d2b];if(_0x3b39bc['writeId']===_0x1e7b0e)return _0x3b39bc;}return null;}function lu(_0x235f8d,_0x1cdc26){const _0x5b4472=_0x235f8d['allWrites']['findIndex'](_0x342588=>_0x342588['writeId']===_0x1cdc26);f(_0x5b4472>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x455be6=_0x235f8d['allWrites'][_0x5b4472];_0x235f8d['allWrites']['splice'](_0x5b4472,0x1);let _0x3c0ea9=_0x455be6['visible'],_0x43e0b2=!0x1,_0x264a2c=_0x235f8d['allWrites']['length']-0x1;for(;_0x3c0ea9&&_0x264a2c>=0x0;){const _0x4e2a8a=_0x235f8d['allWrites'][_0x264a2c];_0x4e2a8a['visible']&&(_0x264a2c>=_0x5b4472&&hu(_0x4e2a8a,_0x455be6['path'])?_0x3c0ea9=!0x1:$(_0x455be6['path'],_0x4e2a8a['path'])&&(_0x43e0b2=!0x0)),_0x264a2c--;}if(_0x3c0ea9){if(_0x43e0b2)return uu(_0x235f8d),!0x0;if(_0x455be6['snap'])_0x235f8d['visibleWrites']=sr(_0x235f8d['visibleWrites'],_0x455be6['path']);else{const _0x24b50f=_0x455be6['children'];x(_0x24b50f,_0x54ce80=>{_0x235f8d['visibleWrites']=sr(_0x235f8d['visibleWrites'],A(_0x455be6['path'],_0x54ce80));});}return!0x0;}else return!0x1;}function hu(_0x436b40,_0x463c71){if(_0x436b40['snap'])return $(_0x436b40['path'],_0x463c71);for(const _0x1e1788 in _0x436b40['children'])if(_0x436b40['children']['hasOwnProperty'](_0x1e1788)&&$(A(_0x436b40['path'],_0x1e1788),_0x463c71))return!0x0;return!0x1;}function uu(_0x56b59f){_0x56b59f['visibleWrites']=Fo(_0x56b59f['allWrites'],du,w()),_0x56b59f['allWrites']['length']>0x0?_0x56b59f['lastWriteId']=_0x56b59f['allWrites'][_0x56b59f['allWrites']['length']-0x1]['writeId']:_0x56b59f['lastWriteId']=-0x1;}function du(_0x5e2e9e){return _0x5e2e9e['visible'];}function Fo(_0x550de0,_0x4bad5f,_0x36f333){let _0x1a78c7=j['empty']();for(let _0x3a3866=0x0;_0x3a3866<_0x550de0['length'];++_0x3a3866){const _0x1bd714=_0x550de0[_0x3a3866];if(_0x4bad5f(_0x1bd714)){const _0xbd4336=_0x1bd714['path'];let _0x1aa1d0;if(_0x1bd714['snap'])$(_0x36f333,_0xbd4336)?(_0x1aa1d0=F(_0x36f333,_0xbd4336),_0x1a78c7=Ct(_0x1a78c7,_0x1aa1d0,_0x1bd714['snap'])):$(_0xbd4336,_0x36f333)&&(_0x1aa1d0=F(_0xbd4336,_0x36f333),_0x1a78c7=Ct(_0x1a78c7,w(),_0x1bd714['snap']['getChild'](_0x1aa1d0)));else{if(_0x1bd714['children']){if($(_0x36f333,_0xbd4336))_0x1aa1d0=F(_0x36f333,_0xbd4336),_0x1a78c7=Ii(_0x1a78c7,_0x1aa1d0,_0x1bd714['children']);else{if($(_0xbd4336,_0x36f333)){if(_0x1aa1d0=F(_0xbd4336,_0x36f333),v(_0x1aa1d0))_0x1a78c7=Ii(_0x1a78c7,w(),_0x1bd714['children']);else{const _0x4f3066=Oe(_0x1bd714['children'],y(_0x1aa1d0));if(_0x4f3066){const _0x449c0d=_0x4f3066['getChild'](b(_0x1aa1d0));_0x1a78c7=Ct(_0x1a78c7,w(),_0x449c0d);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1a78c7;}function Uo(_0x3a5b7f,_0x284aa4,_0x2a86ac,_0x28e398,_0x5d165b){if(!_0x28e398&&!_0x5d165b){const _0xfe2e1=$e(_0x3a5b7f['visibleWrites'],_0x284aa4);if(_0xfe2e1!=null)return _0xfe2e1;{const _0x5010c7=ve(_0x3a5b7f['visibleWrites'],_0x284aa4);if(Ci(_0x5010c7))return _0x2a86ac;if(_0x2a86ac==null&&!wi(_0x5010c7,w()))return null;{const _0x30d3d4=_0x2a86ac||g['EMPTY_NODE'];return it(_0x5010c7,_0x30d3d4);}}}else{const _0x74d8a8=ve(_0x3a5b7f['visibleWrites'],_0x284aa4);if(!_0x5d165b&&Ci(_0x74d8a8))return _0x2a86ac;if(!_0x5d165b&&_0x2a86ac==null&&!wi(_0x74d8a8,w()))return null;{const _0x257c5c=function(_0x521a57){return(_0x521a57['visible']||_0x5d165b)&&(!_0x28e398||!~_0x28e398['indexOf'](_0x521a57['writeId']))&&($(_0x521a57['path'],_0x284aa4)||$(_0x284aa4,_0x521a57['path']));},_0x291ab8=Fo(_0x3a5b7f['allWrites'],_0x257c5c,_0x284aa4),_0x5204f1=_0x2a86ac||g['EMPTY_NODE'];return it(_0x291ab8,_0x5204f1);}}}function fu(_0x18bae7,_0x200e28,_0xfea539){let _0x18d723=g['EMPTY_NODE'];const _0x387c24=$e(_0x18bae7['visibleWrites'],_0x200e28);if(_0x387c24)return _0x387c24['isLeafNode']()||_0x387c24['forEachChild'](R,(_0x4cfd1f,_0x2a6486)=>{_0x18d723=_0x18d723['updateImmediateChild'](_0x4cfd1f,_0x2a6486);}),_0x18d723;if(_0xfea539){const _0x579356=ve(_0x18bae7['visibleWrites'],_0x200e28);return _0xfea539['forEachChild'](R,(_0x317ad0,_0x243979)=>{const _0x173ca5=it(ve(_0x579356,new C(_0x317ad0)),_0x243979);_0x18d723=_0x18d723['updateImmediateChild'](_0x317ad0,_0x173ca5);}),rr(_0x579356)['forEach'](_0x5e2059=>{_0x18d723=_0x18d723['updateImmediateChild'](_0x5e2059['name'],_0x5e2059['node']);}),_0x18d723;}else{const _0x7f18ae=ve(_0x18bae7['visibleWrites'],_0x200e28);return rr(_0x7f18ae)['forEach'](_0x4d7bc7=>{_0x18d723=_0x18d723['updateImmediateChild'](_0x4d7bc7['name'],_0x4d7bc7['node']);}),_0x18d723;}}function pu(_0x30b7d4,_0x3344b,_0x211c20,_0x30752f,_0x5909b9){f(_0x30752f||_0x5909b9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3b0a19=A(_0x3344b,_0x211c20);if(wi(_0x30b7d4['visibleWrites'],_0x3b0a19))return null;{const _0x51b776=ve(_0x30b7d4['visibleWrites'],_0x3b0a19);return Ci(_0x51b776)?_0x5909b9['getChild'](_0x211c20):it(_0x51b776,_0x5909b9['getChild'](_0x211c20));}}function _u(_0x4c3d78,_0x434955,_0x5db7ba,_0x5d00ab){const _0x5e60cc=A(_0x434955,_0x5db7ba),_0x5b078a=$e(_0x4c3d78['visibleWrites'],_0x5e60cc);if(_0x5b078a!=null)return _0x5b078a;if(_0x5d00ab['isCompleteForChild'](_0x5db7ba)){const _0x3f2596=ve(_0x4c3d78['visibleWrites'],_0x5e60cc);return it(_0x3f2596,_0x5d00ab['getNode']()['getImmediateChild'](_0x5db7ba));}else return null;}function gu(_0x7ad3dc,_0x25897f){return $e(_0x7ad3dc['visibleWrites'],_0x25897f);}function mu(_0x4d5325,_0x246b98,_0x45e7db,_0x4d3fd2,_0x2d64df,_0x552d82,_0x23fa06){let _0x1ad9b0;const _0x118b0e=ve(_0x4d5325['visibleWrites'],_0x246b98),_0x1311ba=$e(_0x118b0e,w());if(_0x1311ba!=null)_0x1ad9b0=_0x1311ba;else{if(_0x45e7db!=null)_0x1ad9b0=it(_0x118b0e,_0x45e7db);else return[];}if(_0x1ad9b0=_0x1ad9b0['withIndex'](_0x23fa06),!_0x1ad9b0['isEmpty']()&&!_0x1ad9b0['isLeafNode']()){const _0x7225df=[],_0x5d0b80=_0x23fa06['getCompare'](),_0x3f8143=_0x552d82?_0x1ad9b0['getReverseIteratorFrom'](_0x4d3fd2,_0x23fa06):_0x1ad9b0['getIteratorFrom'](_0x4d3fd2,_0x23fa06);let _0xd07159=_0x3f8143['getNext']();for(;_0xd07159&&_0x7225df['length']<_0x2d64df;)_0x5d0b80(_0xd07159,_0x4d3fd2)!==0x0&&_0x7225df['push'](_0xd07159),_0xd07159=_0x3f8143['getNext']();return _0x7225df;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x42877c,_0x463d9b,_0x392d6c,_0x53c6f2){return Uo(_0x42877c['writeTree'],_0x42877c['treePath'],_0x463d9b,_0x392d6c,_0x53c6f2);}function es(_0x4f8ce4,_0x137fbe){return fu(_0x4f8ce4['writeTree'],_0x4f8ce4['treePath'],_0x137fbe);}function or(_0x42906b,_0x4573f3,_0x2f85a6,_0x287532){return pu(_0x42906b['writeTree'],_0x42906b['treePath'],_0x4573f3,_0x2f85a6,_0x287532);}function yn(_0x30f135,_0x194b3e){return gu(_0x30f135['writeTree'],A(_0x30f135['treePath'],_0x194b3e));}function vu(_0x1c53b9,_0x13db51,_0x5a30c8,_0x95716,_0x3cbd7a,_0x11dbe0){return mu(_0x1c53b9['writeTree'],_0x1c53b9['treePath'],_0x13db51,_0x5a30c8,_0x95716,_0x3cbd7a,_0x11dbe0);}function ts(_0x5cb117,_0x2d509d,_0xb0c9e4){return _u(_0x5cb117['writeTree'],_0x5cb117['treePath'],_0x2d509d,_0xb0c9e4);}function Wo(_0x8cbe41,_0x167904){return Bo(A(_0x8cbe41['treePath'],_0x167904),_0x8cbe41['writeTree']);}function Bo(_0x2864dd,_0x49f425){return{'treePath':_0x2864dd,'writeTree':_0x49f425};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1cdb00){const _0x2a7480=_0x1cdb00['type'],_0x4c6142=_0x1cdb00['childName'];f(_0x2a7480==='child_added'||_0x2a7480==='child_changed'||_0x2a7480==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4c6142!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x175490=this['changeMap']['get'](_0x4c6142);if(_0x175490){const _0x12f441=_0x175490['type'];if(_0x2a7480==='child_added'&&_0x12f441==='child_removed')this['changeMap']['set'](_0x4c6142,Pt(_0x4c6142,_0x1cdb00['snapshotNode'],_0x175490['snapshotNode']));else{if(_0x2a7480==='child_removed'&&_0x12f441==='child_added')this['changeMap']['delete'](_0x4c6142);else{if(_0x2a7480==='child_removed'&&_0x12f441==='child_changed')this['changeMap']['set'](_0x4c6142,Nt(_0x4c6142,_0x175490['oldSnap']));else{if(_0x2a7480==='child_changed'&&_0x12f441==='child_added')this['changeMap']['set'](_0x4c6142,tt(_0x4c6142,_0x1cdb00['snapshotNode']));else{if(_0x2a7480==='child_changed'&&_0x12f441==='child_changed')this['changeMap']['set'](_0x4c6142,Pt(_0x4c6142,_0x1cdb00['snapshotNode'],_0x175490['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x1cdb00+'\x20occurred\x20after\x20'+_0x175490);}}}}}else this['changeMap']['set'](_0x4c6142,_0x1cdb00);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x164812){return null;}['getChildAfterChild'](_0x34b257,_0xd4c90a,_0x45737c){return null;}}const Vo=new Iu();class ns{constructor(_0x97f22c,_0x1f6d50,_0x14eb5a=null){this['writes_']=_0x97f22c,this['viewCache_']=_0x1f6d50,this['optCompleteServerCache_']=_0x14eb5a;}['getCompleteChild'](_0x486566){const _0x11c4cd=this['viewCache_']['eventCache'];if(_0x11c4cd['isCompleteForChild'](_0x486566))return _0x11c4cd['getNode']()['getImmediateChild'](_0x486566);{const _0x21a1f0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x486566,_0x21a1f0);}}['getChildAfterChild'](_0x5e63d4,_0x323838,_0x4b334d){const _0x3a5de3=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x365937=vu(this['writes_'],_0x3a5de3,_0x323838,0x1,_0x4b334d,_0x5e63d4);return _0x365937['length']===0x0?null:_0x365937[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x18ed60){return{'filter':_0x18ed60};}function Cu(_0x2cc5a9,_0x4bbad1){f(_0x4bbad1['eventCache']['getNode']()['isIndexed'](_0x2cc5a9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4bbad1['serverCache']['getNode']()['isIndexed'](_0x2cc5a9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1ac70f,_0x1c5cd3,_0x3199a2,_0x4c3ee4,_0x55d250){const _0x3a69c7=new Eu();let _0x16e83a,_0xb749f5;if(_0x3199a2['type']===q['OVERWRITE']){const _0x4cb60c=_0x3199a2;_0x4cb60c['source']['fromUser']?_0x16e83a=Ti(_0x1ac70f,_0x1c5cd3,_0x4cb60c['path'],_0x4cb60c['snap'],_0x4c3ee4,_0x55d250,_0x3a69c7):(f(_0x4cb60c['source']['fromServer'],'Unknown\x20source.'),_0xb749f5=_0x4cb60c['source']['tagged']||_0x1c5cd3['serverCache']['isFiltered']()&&!v(_0x4cb60c['path']),_0x16e83a=vn(_0x1ac70f,_0x1c5cd3,_0x4cb60c['path'],_0x4cb60c['snap'],_0x4c3ee4,_0x55d250,_0xb749f5,_0x3a69c7));}else{if(_0x3199a2['type']===q['MERGE']){const _0x399c44=_0x3199a2;_0x399c44['source']['fromUser']?_0x16e83a=bu(_0x1ac70f,_0x1c5cd3,_0x399c44['path'],_0x399c44['children'],_0x4c3ee4,_0x55d250,_0x3a69c7):(f(_0x399c44['source']['fromServer'],'Unknown\x20source.'),_0xb749f5=_0x399c44['source']['tagged']||_0x1c5cd3['serverCache']['isFiltered'](),_0x16e83a=Si(_0x1ac70f,_0x1c5cd3,_0x399c44['path'],_0x399c44['children'],_0x4c3ee4,_0x55d250,_0xb749f5,_0x3a69c7));}else{if(_0x3199a2['type']===q['ACK_USER_WRITE']){const _0x281c8a=_0x3199a2;_0x281c8a['revert']?_0x16e83a=ku(_0x1ac70f,_0x1c5cd3,_0x281c8a['path'],_0x4c3ee4,_0x55d250,_0x3a69c7):_0x16e83a=Ru(_0x1ac70f,_0x1c5cd3,_0x281c8a['path'],_0x281c8a['affectedTree'],_0x4c3ee4,_0x55d250,_0x3a69c7);}else{if(_0x3199a2['type']===q['LISTEN_COMPLETE'])_0x16e83a=Au(_0x1ac70f,_0x1c5cd3,_0x3199a2['path'],_0x4c3ee4,_0x3a69c7);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3199a2['type']);}}}const _0x5331e8=_0x3a69c7['getChanges']();return Su(_0x1c5cd3,_0x16e83a,_0x5331e8),{'viewCache':_0x16e83a,'changes':_0x5331e8};}function Su(_0x27d5af,_0x4f7be4,_0x5da926){const _0x25fd43=_0x4f7be4['eventCache'];if(_0x25fd43['isFullyInitialized']()){const _0x180040=_0x25fd43['getNode']()['isLeafNode']()||_0x25fd43['getNode']()['isEmpty'](),_0x5d69a0=gn(_0x27d5af);(_0x5da926['length']>0x0||!_0x27d5af['eventCache']['isFullyInitialized']()||_0x180040&&!_0x25fd43['getNode']()['equals'](_0x5d69a0)||!_0x25fd43['getNode']()['getPriority']()['equals'](_0x5d69a0['getPriority']()))&&_0x5da926['push'](Oo(gn(_0x4f7be4)));}}function Ho(_0x3a8f4b,_0x42cfd1,_0x4fbe09,_0x291536,_0x3d2ff4,_0x243c39){const _0x8b5cb0=_0x42cfd1['eventCache'];if(yn(_0x291536,_0x4fbe09)!=null)return _0x42cfd1;{let _0x243eda,_0x498db4;if(v(_0x4fbe09)){if(f(_0x42cfd1['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x42cfd1['serverCache']['isFiltered']()){const _0x4b340f=Ue(_0x42cfd1),_0xca3fcb=_0x4b340f instanceof g?_0x4b340f:g['EMPTY_NODE'],_0x44587e=es(_0x291536,_0xca3fcb);_0x243eda=_0x3a8f4b['filter']['updateFullNode'](_0x42cfd1['eventCache']['getNode'](),_0x44587e,_0x243c39);}else{const _0x2ffa3f=mn(_0x291536,Ue(_0x42cfd1));_0x243eda=_0x3a8f4b['filter']['updateFullNode'](_0x42cfd1['eventCache']['getNode'](),_0x2ffa3f,_0x243c39);}}else{const _0xdd687d=y(_0x4fbe09);if(_0xdd687d==='.priority'){f(we(_0x4fbe09)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x9d31fd=_0x8b5cb0['getNode']();_0x498db4=_0x42cfd1['serverCache']['getNode']();const _0x2b11ef=or(_0x291536,_0x4fbe09,_0x9d31fd,_0x498db4);_0x2b11ef!=null?_0x243eda=_0x3a8f4b['filter']['updatePriority'](_0x9d31fd,_0x2b11ef):_0x243eda=_0x8b5cb0['getNode']();}else{const _0x1cbb7d=b(_0x4fbe09);let _0x6a975;if(_0x8b5cb0['isCompleteForChild'](_0xdd687d)){_0x498db4=_0x42cfd1['serverCache']['getNode']();const _0xa6f05b=or(_0x291536,_0x4fbe09,_0x8b5cb0['getNode'](),_0x498db4);_0xa6f05b!=null?_0x6a975=_0x8b5cb0['getNode']()['getImmediateChild'](_0xdd687d)['updateChild'](_0x1cbb7d,_0xa6f05b):_0x6a975=_0x8b5cb0['getNode']()['getImmediateChild'](_0xdd687d);}else _0x6a975=ts(_0x291536,_0xdd687d,_0x42cfd1['serverCache']);_0x6a975!=null?_0x243eda=_0x3a8f4b['filter']['updateChild'](_0x8b5cb0['getNode'](),_0xdd687d,_0x6a975,_0x1cbb7d,_0x3d2ff4,_0x243c39):_0x243eda=_0x8b5cb0['getNode']();}}return wt(_0x42cfd1,_0x243eda,_0x8b5cb0['isFullyInitialized']()||v(_0x4fbe09),_0x3a8f4b['filter']['filtersNodes']());}}function vn(_0x286b41,_0x1f8ce1,_0x4dd832,_0x574913,_0x974c0c,_0x51ff8f,_0x41403b,_0x2b13c6){const _0x4b3f48=_0x1f8ce1['serverCache'];let _0x20bff8;const _0x254853=_0x41403b?_0x286b41['filter']:_0x286b41['filter']['getIndexedFilter']();if(v(_0x4dd832))_0x20bff8=_0x254853['updateFullNode'](_0x4b3f48['getNode'](),_0x574913,null);else{if(_0x254853['filtersNodes']()&&!_0x4b3f48['isFiltered']()){const _0x45f09d=_0x4b3f48['getNode']()['updateChild'](_0x4dd832,_0x574913);_0x20bff8=_0x254853['updateFullNode'](_0x4b3f48['getNode'](),_0x45f09d,null);}else{const _0x4d9a36=y(_0x4dd832);if(!_0x4b3f48['isCompleteForPath'](_0x4dd832)&&we(_0x4dd832)>0x1)return _0x1f8ce1;const _0x2b44bd=b(_0x4dd832),_0x5a9474=_0x4b3f48['getNode']()['getImmediateChild'](_0x4d9a36)['updateChild'](_0x2b44bd,_0x574913);_0x4d9a36==='.priority'?_0x20bff8=_0x254853['updatePriority'](_0x4b3f48['getNode'](),_0x5a9474):_0x20bff8=_0x254853['updateChild'](_0x4b3f48['getNode'](),_0x4d9a36,_0x5a9474,_0x2b44bd,Vo,null);}}const _0x1382dd=Lo(_0x1f8ce1,_0x20bff8,_0x4b3f48['isFullyInitialized']()||v(_0x4dd832),_0x254853['filtersNodes']()),_0x1e707d=new ns(_0x974c0c,_0x1382dd,_0x51ff8f);return Ho(_0x286b41,_0x1382dd,_0x4dd832,_0x974c0c,_0x1e707d,_0x2b13c6);}function Ti(_0x1fd75c,_0x77e6cf,_0x4431c9,_0xeced9f,_0x106553,_0x51c979,_0x19e7ad){const _0x248ca3=_0x77e6cf['eventCache'];let _0x34ddd5,_0x1887f7;const _0x402c77=new ns(_0x106553,_0x77e6cf,_0x51c979);if(v(_0x4431c9))_0x1887f7=_0x1fd75c['filter']['updateFullNode'](_0x77e6cf['eventCache']['getNode'](),_0xeced9f,_0x19e7ad),_0x34ddd5=wt(_0x77e6cf,_0x1887f7,!0x0,_0x1fd75c['filter']['filtersNodes']());else{const _0x3774ce=y(_0x4431c9);if(_0x3774ce==='.priority')_0x1887f7=_0x1fd75c['filter']['updatePriority'](_0x77e6cf['eventCache']['getNode'](),_0xeced9f),_0x34ddd5=wt(_0x77e6cf,_0x1887f7,_0x248ca3['isFullyInitialized'](),_0x248ca3['isFiltered']());else{const _0x43bbb6=b(_0x4431c9),_0x13deb8=_0x248ca3['getNode']()['getImmediateChild'](_0x3774ce);let _0x4bb978;if(v(_0x43bbb6))_0x4bb978=_0xeced9f;else{const _0x2269c8=_0x402c77['getCompleteChild'](_0x3774ce);_0x2269c8!=null?Gi(_0x43bbb6)==='.priority'&&_0x2269c8['getChild'](To(_0x43bbb6))['isEmpty']()?_0x4bb978=_0x2269c8:_0x4bb978=_0x2269c8['updateChild'](_0x43bbb6,_0xeced9f):_0x4bb978=g['EMPTY_NODE'];}if(_0x13deb8['equals'](_0x4bb978))_0x34ddd5=_0x77e6cf;else{const _0xd1e3b1=_0x1fd75c['filter']['updateChild'](_0x248ca3['getNode'](),_0x3774ce,_0x4bb978,_0x43bbb6,_0x402c77,_0x19e7ad);_0x34ddd5=wt(_0x77e6cf,_0xd1e3b1,_0x248ca3['isFullyInitialized'](),_0x1fd75c['filter']['filtersNodes']());}}}return _0x34ddd5;}function ar(_0x2773de,_0xc67b52){return _0x2773de['eventCache']['isCompleteForChild'](_0xc67b52);}function bu(_0x1325ca,_0x599c25,_0x3927b3,_0x2788d3,_0xbe5fc8,_0x31277c,_0x311a6f){let _0x70a3c7=_0x599c25;return _0x2788d3['foreach']((_0xfb8e12,_0x3ac33d)=>{const _0x2e151c=A(_0x3927b3,_0xfb8e12);ar(_0x599c25,y(_0x2e151c))&&(_0x70a3c7=Ti(_0x1325ca,_0x70a3c7,_0x2e151c,_0x3ac33d,_0xbe5fc8,_0x31277c,_0x311a6f));}),_0x2788d3['foreach']((_0x809d81,_0xa20994)=>{const _0x4a1b63=A(_0x3927b3,_0x809d81);ar(_0x599c25,y(_0x4a1b63))||(_0x70a3c7=Ti(_0x1325ca,_0x70a3c7,_0x4a1b63,_0xa20994,_0xbe5fc8,_0x31277c,_0x311a6f));}),_0x70a3c7;}function cr(_0x40ba58,_0x198af8,_0x435fa9){return _0x435fa9['foreach']((_0x4bc464,_0x88252d)=>{_0x198af8=_0x198af8['updateChild'](_0x4bc464,_0x88252d);}),_0x198af8;}function Si(_0x544f52,_0x520aa8,_0x341000,_0x23a40f,_0x4b48d6,_0x5d9358,_0x2aa65e,_0x2bf021){if(_0x520aa8['serverCache']['getNode']()['isEmpty']()&&!_0x520aa8['serverCache']['isFullyInitialized']())return _0x520aa8;let _0x155e78=_0x520aa8,_0x4dc959;v(_0x341000)?_0x4dc959=_0x23a40f:_0x4dc959=new S(null)['setTree'](_0x341000,_0x23a40f);const _0x1c2a04=_0x520aa8['serverCache']['getNode']();return _0x4dc959['children']['inorderTraversal']((_0x5d06d2,_0xf6d0b)=>{if(_0x1c2a04['hasChild'](_0x5d06d2)){const _0x25bd2d=_0x520aa8['serverCache']['getNode']()['getImmediateChild'](_0x5d06d2),_0x3454e0=cr(_0x544f52,_0x25bd2d,_0xf6d0b);_0x155e78=vn(_0x544f52,_0x155e78,new C(_0x5d06d2),_0x3454e0,_0x4b48d6,_0x5d9358,_0x2aa65e,_0x2bf021);}}),_0x4dc959['children']['inorderTraversal']((_0x302e12,_0x13768e)=>{const _0x207b2f=!_0x520aa8['serverCache']['isCompleteForChild'](_0x302e12)&&_0x13768e['value']===null;if(!_0x1c2a04['hasChild'](_0x302e12)&&!_0x207b2f){const _0x3072d5=_0x520aa8['serverCache']['getNode']()['getImmediateChild'](_0x302e12),_0x3c2eaf=cr(_0x544f52,_0x3072d5,_0x13768e);_0x155e78=vn(_0x544f52,_0x155e78,new C(_0x302e12),_0x3c2eaf,_0x4b48d6,_0x5d9358,_0x2aa65e,_0x2bf021);}}),_0x155e78;}function Ru(_0x35d9c0,_0x20f393,_0x65711b,_0x15752f,_0x145061,_0x5870cc,_0x2b4081){if(yn(_0x145061,_0x65711b)!=null)return _0x20f393;const _0xe2645=_0x20f393['serverCache']['isFiltered'](),_0x5c9953=_0x20f393['serverCache'];if(_0x15752f['value']!=null){if(v(_0x65711b)&&_0x5c9953['isFullyInitialized']()||_0x5c9953['isCompleteForPath'](_0x65711b))return vn(_0x35d9c0,_0x20f393,_0x65711b,_0x5c9953['getNode']()['getChild'](_0x65711b),_0x145061,_0x5870cc,_0xe2645,_0x2b4081);if(v(_0x65711b)){let _0x22cf4e=new S(null);return _0x5c9953['getNode']()['forEachChild'](ye,(_0x52ef34,_0x59bfe4)=>{_0x22cf4e=_0x22cf4e['set'](new C(_0x52ef34),_0x59bfe4);}),Si(_0x35d9c0,_0x20f393,_0x65711b,_0x22cf4e,_0x145061,_0x5870cc,_0xe2645,_0x2b4081);}else return _0x20f393;}else{let _0x3e8efa=new S(null);return _0x15752f['foreach']((_0x2f7967,_0x14180d)=>{const _0xd99828=A(_0x65711b,_0x2f7967);_0x5c9953['isCompleteForPath'](_0xd99828)&&(_0x3e8efa=_0x3e8efa['set'](_0x2f7967,_0x5c9953['getNode']()['getChild'](_0xd99828)));}),Si(_0x35d9c0,_0x20f393,_0x65711b,_0x3e8efa,_0x145061,_0x5870cc,_0xe2645,_0x2b4081);}}function Au(_0x2af40d,_0x523457,_0x3d6336,_0x3d2466,_0x307df4){const _0x2a371b=_0x523457['serverCache'],_0x1ffc99=Lo(_0x523457,_0x2a371b['getNode'](),_0x2a371b['isFullyInitialized']()||v(_0x3d6336),_0x2a371b['isFiltered']());return Ho(_0x2af40d,_0x1ffc99,_0x3d6336,_0x3d2466,Vo,_0x307df4);}function ku(_0x2251e4,_0xdd647,_0x5c88db,_0x10e9d2,_0x4b8a5d,_0x5540dd){let _0x5d1fb2;if(yn(_0x10e9d2,_0x5c88db)!=null)return _0xdd647;{const _0x203210=new ns(_0x10e9d2,_0xdd647,_0x4b8a5d),_0x5c527e=_0xdd647['eventCache']['getNode']();let _0x454ea1;if(v(_0x5c88db)||y(_0x5c88db)==='.priority'){let _0xde0ad3;if(_0xdd647['serverCache']['isFullyInitialized']())_0xde0ad3=mn(_0x10e9d2,Ue(_0xdd647));else{const _0x4ce3fb=_0xdd647['serverCache']['getNode']();f(_0x4ce3fb instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xde0ad3=es(_0x10e9d2,_0x4ce3fb);}_0xde0ad3=_0xde0ad3,_0x454ea1=_0x2251e4['filter']['updateFullNode'](_0x5c527e,_0xde0ad3,_0x5540dd);}else{const _0xadb4b3=y(_0x5c88db);let _0x398db8=ts(_0x10e9d2,_0xadb4b3,_0xdd647['serverCache']);_0x398db8==null&&_0xdd647['serverCache']['isCompleteForChild'](_0xadb4b3)&&(_0x398db8=_0x5c527e['getImmediateChild'](_0xadb4b3)),_0x398db8!=null?_0x454ea1=_0x2251e4['filter']['updateChild'](_0x5c527e,_0xadb4b3,_0x398db8,b(_0x5c88db),_0x203210,_0x5540dd):_0xdd647['eventCache']['getNode']()['hasChild'](_0xadb4b3)?_0x454ea1=_0x2251e4['filter']['updateChild'](_0x5c527e,_0xadb4b3,g['EMPTY_NODE'],b(_0x5c88db),_0x203210,_0x5540dd):_0x454ea1=_0x5c527e,_0x454ea1['isEmpty']()&&_0xdd647['serverCache']['isFullyInitialized']()&&(_0x5d1fb2=mn(_0x10e9d2,Ue(_0xdd647)),_0x5d1fb2['isLeafNode']()&&(_0x454ea1=_0x2251e4['filter']['updateFullNode'](_0x454ea1,_0x5d1fb2,_0x5540dd)));}return _0x5d1fb2=_0xdd647['serverCache']['isFullyInitialized']()||yn(_0x10e9d2,w())!=null,wt(_0xdd647,_0x454ea1,_0x5d1fb2,_0x2251e4['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x56284a,_0x2790fc){this['query_']=_0x56284a,this['eventRegistrations_']=[];const _0x292f80=this['query_']['_queryParams'],_0x552384=new Yi(_0x292f80['getIndex']()),_0x32347c=qh(_0x292f80);this['processor_']=wu(_0x32347c);const _0x240ee9=_0x2790fc['serverCache'],_0x31a1cd=_0x2790fc['eventCache'],_0x392d8b=_0x552384['updateFullNode'](g['EMPTY_NODE'],_0x240ee9['getNode'](),null),_0x466a9d=_0x32347c['updateFullNode'](g['EMPTY_NODE'],_0x31a1cd['getNode'](),null),_0x3eff46=new Ce(_0x392d8b,_0x240ee9['isFullyInitialized'](),_0x552384['filtersNodes']()),_0x54c2de=new Ce(_0x466a9d,_0x31a1cd['isFullyInitialized'](),_0x32347c['filtersNodes']());this['viewCache_']=Dn(_0x54c2de,_0x3eff46),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x230f1b){return _0x230f1b['viewCache_']['serverCache']['getNode']();}function Ou(_0x2efec4){return gn(_0x2efec4['viewCache_']);}function Du(_0x5863ea,_0x8e723b){const _0x4bfedb=Ue(_0x5863ea['viewCache_']);return _0x4bfedb&&(_0x5863ea['query']['_queryParams']['loadsAllData']()||!v(_0x8e723b)&&!_0x4bfedb['getImmediateChild'](y(_0x8e723b))['isEmpty']())?_0x4bfedb['getChild'](_0x8e723b):null;}function lr(_0x24b7cc){return _0x24b7cc['eventRegistrations_']['length']===0x0;}function Mu(_0x5965f4,_0x45a9f0){_0x5965f4['eventRegistrations_']['push'](_0x45a9f0);}function hr(_0x567436,_0x5cb191,_0x5255f4){const _0x159537=[];if(_0x5255f4){f(_0x5cb191==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x172a55=_0x567436['query']['_path'];_0x567436['eventRegistrations_']['forEach'](_0x178d6e=>{const _0x424464=_0x178d6e['createCancelEvent'](_0x5255f4,_0x172a55);_0x424464&&_0x159537['push'](_0x424464);});}if(_0x5cb191){let _0x49bdc8=[];for(let _0x16e7ac=0x0;_0x16e7ac<_0x567436['eventRegistrations_']['length'];++_0x16e7ac){const _0x5c5d0e=_0x567436['eventRegistrations_'][_0x16e7ac];if(!_0x5c5d0e['matches'](_0x5cb191))_0x49bdc8['push'](_0x5c5d0e);else{if(_0x5cb191['hasAnyCallback']()){_0x49bdc8=_0x49bdc8['concat'](_0x567436['eventRegistrations_']['slice'](_0x16e7ac+0x1));break;}}}_0x567436['eventRegistrations_']=_0x49bdc8;}else _0x567436['eventRegistrations_']=[];return _0x159537;}function ur(_0x44b8c7,_0x3b8ea8,_0x4ded79,_0x3a7887){_0x3b8ea8['type']===q['MERGE']&&_0x3b8ea8['source']['queryId']!==null&&(f(Ue(_0x44b8c7['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x44b8c7['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2d07d5=_0x44b8c7['viewCache_'],_0x2b56c4=Tu(_0x44b8c7['processor_'],_0x2d07d5,_0x3b8ea8,_0x4ded79,_0x3a7887);return Cu(_0x44b8c7['processor_'],_0x2b56c4['viewCache']),f(_0x2b56c4['viewCache']['serverCache']['isFullyInitialized']()||!_0x2d07d5['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x44b8c7['viewCache_']=_0x2b56c4['viewCache'],$o(_0x44b8c7,_0x2b56c4['changes'],_0x2b56c4['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x1e9025,_0x83ce61){const _0x9deb18=_0x1e9025['viewCache_']['eventCache'],_0x464267=[];return _0x9deb18['getNode']()['isLeafNode']()||_0x9deb18['getNode']()['forEachChild'](R,(_0x59e4d6,_0xeb4030)=>{_0x464267['push'](tt(_0x59e4d6,_0xeb4030));}),_0x9deb18['isFullyInitialized']()&&_0x464267['push'](Oo(_0x9deb18['getNode']())),$o(_0x1e9025,_0x464267,_0x9deb18['getNode'](),_0x83ce61);}function $o(_0x4853a5,_0x1314f6,_0x368422,_0x40f6c4){const _0x2bdd6d=_0x40f6c4?[_0x40f6c4]:_0x4853a5['eventRegistrations_'];return nu(_0x4853a5['eventGenerator_'],_0x1314f6,_0x368422,_0x2bdd6d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x484aa4){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x484aa4;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x5e2deb){return _0x5e2deb['views']['size']===0x0;}function is(_0x46b6cb,_0x1212ec,_0x5a0789,_0x56873c){const _0x21772e=_0x1212ec['source']['queryId'];if(_0x21772e!==null){const _0x28fd49=_0x46b6cb['views']['get'](_0x21772e);return f(_0x28fd49!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x28fd49,_0x1212ec,_0x5a0789,_0x56873c);}else{let _0x12653a=[];for(const _0x525adc of _0x46b6cb['views']['values']())_0x12653a=_0x12653a['concat'](ur(_0x525adc,_0x1212ec,_0x5a0789,_0x56873c));return _0x12653a;}}function qo(_0x5e849b,_0x13642a,_0x2a5e07,_0x1d5615,_0x5aae85){const _0x114629=_0x13642a['_queryIdentifier'],_0x2c7150=_0x5e849b['views']['get'](_0x114629);if(!_0x2c7150){let _0x3fef3e=mn(_0x2a5e07,_0x5aae85?_0x1d5615:null),_0x1e2d44=!0x1;_0x3fef3e?_0x1e2d44=!0x0:_0x1d5615 instanceof g?(_0x3fef3e=es(_0x2a5e07,_0x1d5615),_0x1e2d44=!0x1):(_0x3fef3e=g['EMPTY_NODE'],_0x1e2d44=!0x1);const _0x49d6cc=Dn(new Ce(_0x3fef3e,_0x1e2d44,!0x1),new Ce(_0x1d5615,_0x5aae85,!0x1));return new Nu(_0x13642a,_0x49d6cc);}return _0x2c7150;}function Wu(_0x307d10,_0x4a95d5,_0x2df5aa,_0x56a7c7,_0x753214,_0x1f5bf3){const _0x378d6c=qo(_0x307d10,_0x4a95d5,_0x56a7c7,_0x753214,_0x1f5bf3);return _0x307d10['views']['has'](_0x4a95d5['_queryIdentifier'])||_0x307d10['views']['set'](_0x4a95d5['_queryIdentifier'],_0x378d6c),Mu(_0x378d6c,_0x2df5aa),Lu(_0x378d6c,_0x2df5aa);}function Bu(_0x5c601b,_0x4ccbda,_0x382378,_0x55d27c){const _0x37c38e=_0x4ccbda['_queryIdentifier'],_0x3ceddb=[];let _0x83098a=[];const _0x5f6530=Te(_0x5c601b);if(_0x37c38e==='default'){for(const [_0x1efab0,_0x17f336]of _0x5c601b['views']['entries']())_0x83098a=_0x83098a['concat'](hr(_0x17f336,_0x382378,_0x55d27c)),lr(_0x17f336)&&(_0x5c601b['views']['delete'](_0x1efab0),_0x17f336['query']['_queryParams']['loadsAllData']()||_0x3ceddb['push'](_0x17f336['query']));}else{const _0x47635c=_0x5c601b['views']['get'](_0x37c38e);_0x47635c&&(_0x83098a=_0x83098a['concat'](hr(_0x47635c,_0x382378,_0x55d27c)),lr(_0x47635c)&&(_0x5c601b['views']['delete'](_0x37c38e),_0x47635c['query']['_queryParams']['loadsAllData']()||_0x3ceddb['push'](_0x47635c['query'])));}return _0x5f6530&&!Te(_0x5c601b)&&_0x3ceddb['push'](new(Fu())(_0x4ccbda['_repo'],_0x4ccbda['_path'])),{'removed':_0x3ceddb,'events':_0x83098a};}function zo(_0x3b4326){const _0x40cd7f=[];for(const _0xa3e3f4 of _0x3b4326['views']['values']())_0xa3e3f4['query']['_queryParams']['loadsAllData']()||_0x40cd7f['push'](_0xa3e3f4);return _0x40cd7f;}function Ee(_0x36c93c,_0x520563){let _0x4d978f=null;for(const _0x1e5450 of _0x36c93c['views']['values']())_0x4d978f=_0x4d978f||Du(_0x1e5450,_0x520563);return _0x4d978f;}function jo(_0x288ca1,_0x1bb7c7){if(_0x1bb7c7['_queryParams']['loadsAllData']())return Ln(_0x288ca1);{const _0x4642b8=_0x1bb7c7['_queryIdentifier'];return _0x288ca1['views']['get'](_0x4642b8);}}function Ko(_0x1126ae,_0x2f917c){return jo(_0x1126ae,_0x2f917c)!=null;}function Te(_0x5d3f1a){return Ln(_0x5d3f1a)!=null;}function Ln(_0x5bcb5d){for(const _0x2c2375 of _0x5bcb5d['views']['values']())if(_0x2c2375['query']['_queryParams']['loadsAllData']())return _0x2c2375;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x3faf3a){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3faf3a;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x3db65b){this['listenProvider_']=_0x3db65b,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x44122d,_0x35f509,_0x190f73,_0x3767c5,_0x43f601){return ou(_0x44122d['pendingWriteTree_'],_0x35f509,_0x190f73,_0x3767c5,_0x43f601),_0x43f601?ht(_0x44122d,new Fe(Ji(),_0x35f509,_0x190f73)):[];}function Gu(_0x295709,_0x11fce9,_0x2526e0,_0x17a932){au(_0x295709['pendingWriteTree_'],_0x11fce9,_0x2526e0,_0x17a932);const _0x1ac81f=S['fromObject'](_0x2526e0);return ht(_0x295709,new nt(Ji(),_0x11fce9,_0x1ac81f));}function pe(_0x2bcd03,_0x22edbf,_0x254153=!0x1){const _0x3fc044=cu(_0x2bcd03['pendingWriteTree_'],_0x22edbf);if(lu(_0x2bcd03['pendingWriteTree_'],_0x22edbf)){let _0x3e8abf=new S(null);return _0x3fc044['snap']!=null?_0x3e8abf=_0x3e8abf['set'](w(),!0x0):x(_0x3fc044['children'],_0xdc5bb3=>{_0x3e8abf=_0x3e8abf['set'](new C(_0xdc5bb3),!0x0);}),ht(_0x2bcd03,new _n(_0x3fc044['path'],_0x3e8abf,_0x254153));}else return[];}function $t(_0x1495a9,_0x53cfd1,_0x2b9baf){return ht(_0x1495a9,new Fe(Xi(),_0x53cfd1,_0x2b9baf));}function qu(_0x5558c3,_0x1c4150,_0x486b5c){const _0x315eb3=S['fromObject'](_0x486b5c);return ht(_0x5558c3,new nt(Xi(),_0x1c4150,_0x315eb3));}function zu(_0x3efc80,_0x4f9874){return ht(_0x3efc80,new Dt(Xi(),_0x4f9874));}function ju(_0x487711,_0x431a6c,_0x515e02){const _0x3ddad6=rs(_0x487711,_0x515e02);if(_0x3ddad6){const _0x2ea15b=os(_0x3ddad6),_0x2c5ba2=_0x2ea15b['path'],_0x2ffaa4=_0x2ea15b['queryId'],_0xae1c77=F(_0x2c5ba2,_0x431a6c),_0x4fa7e1=new Dt(Zi(_0x2ffaa4),_0xae1c77);return as(_0x487711,_0x2c5ba2,_0x4fa7e1);}else return[];}function wn(_0x52522d,_0xdeeb9a,_0xc4e481,_0x30cc1d,_0x47f4e2=!0x1){const _0x54c59f=_0xdeeb9a['_path'],_0x213247=_0x52522d['syncPointTree_']['get'](_0x54c59f);let _0x249126=[];if(_0x213247&&(_0xdeeb9a['_queryIdentifier']==='default'||Ko(_0x213247,_0xdeeb9a))){const _0x396ce5=Bu(_0x213247,_0xdeeb9a,_0xc4e481,_0x30cc1d);Uu(_0x213247)&&(_0x52522d['syncPointTree_']=_0x52522d['syncPointTree_']['remove'](_0x54c59f));const _0x1523e5=_0x396ce5['removed'];if(_0x249126=_0x396ce5['events'],!_0x47f4e2){const _0x3875f6=_0x1523e5['findIndex'](_0x241f4c=>_0x241f4c['_queryParams']['loadsAllData']())!==-0x1,_0x4cfefa=_0x52522d['syncPointTree_']['findOnPath'](_0x54c59f,(_0x956eeb,_0x555010)=>Te(_0x555010));if(_0x3875f6&&!_0x4cfefa){const _0xb067d7=_0x52522d['syncPointTree_']['subtree'](_0x54c59f);if(!_0xb067d7['isEmpty']()){const _0xf6999c=Qu(_0xb067d7);for(let _0x14c033=0x0;_0x14c033<_0xf6999c['length'];++_0x14c033){const _0x44c6d3=_0xf6999c[_0x14c033],_0x361f18=_0x44c6d3['query'],_0x3ae081=Xo(_0x52522d,_0x44c6d3);_0x52522d['listenProvider_']['startListening'](Tt(_0x361f18),Mt(_0x52522d,_0x361f18),_0x3ae081['hashFn'],_0x3ae081['onComplete']);}}}!_0x4cfefa&&_0x1523e5['length']>0x0&&!_0x30cc1d&&(_0x3875f6?_0x52522d['listenProvider_']['stopListening'](Tt(_0xdeeb9a),null):_0x1523e5['forEach'](_0x49ae16=>{const _0x4e8822=_0x52522d['queryToTagMap']['get'](Fn(_0x49ae16));_0x52522d['listenProvider_']['stopListening'](Tt(_0x49ae16),_0x4e8822);}));}Ju(_0x52522d,_0x1523e5);}return _0x249126;}function Yo(_0x1a13fa,_0x481a80,_0x4f99d2,_0x59bdc0){const _0x2aaa22=rs(_0x1a13fa,_0x59bdc0);if(_0x2aaa22!=null){const _0x5281f9=os(_0x2aaa22),_0x22fdf3=_0x5281f9['path'],_0x50c75c=_0x5281f9['queryId'],_0x14ea0c=F(_0x22fdf3,_0x481a80),_0x3f494a=new Fe(Zi(_0x50c75c),_0x14ea0c,_0x4f99d2);return as(_0x1a13fa,_0x22fdf3,_0x3f494a);}else return[];}function Ku(_0x3aa819,_0x2b0717,_0xbfba0e,_0x2ba9c9){const _0x583b7c=rs(_0x3aa819,_0x2ba9c9);if(_0x583b7c){const _0x430266=os(_0x583b7c),_0x8b9c5a=_0x430266['path'],_0x44752d=_0x430266['queryId'],_0x1befac=F(_0x8b9c5a,_0x2b0717),_0x2c7a45=S['fromObject'](_0xbfba0e),_0x17d52a=new nt(Zi(_0x44752d),_0x1befac,_0x2c7a45);return as(_0x3aa819,_0x8b9c5a,_0x17d52a);}else return[];}function bi(_0x48c976,_0x42c4ea,_0x30c8ee,_0x2c1ca9=!0x1){const _0xf13773=_0x42c4ea['_path'];let _0xe2635d=null,_0x14e793=!0x1;_0x48c976['syncPointTree_']['foreachOnPath'](_0xf13773,(_0x550fd3,_0x7d3a12)=>{const _0x247706=F(_0x550fd3,_0xf13773);_0xe2635d=_0xe2635d||Ee(_0x7d3a12,_0x247706),_0x14e793=_0x14e793||Te(_0x7d3a12);});let _0x25b8b4=_0x48c976['syncPointTree_']['get'](_0xf13773);_0x25b8b4?(_0x14e793=_0x14e793||Te(_0x25b8b4),_0xe2635d=_0xe2635d||Ee(_0x25b8b4,w())):(_0x25b8b4=new Go(),_0x48c976['syncPointTree_']=_0x48c976['syncPointTree_']['set'](_0xf13773,_0x25b8b4));let _0x125378;_0xe2635d!=null?_0x125378=!0x0:(_0x125378=!0x1,_0xe2635d=g['EMPTY_NODE'],_0x48c976['syncPointTree_']['subtree'](_0xf13773)['foreachChild']((_0x21ed45,_0x5bf832)=>{const _0x4d77ce=Ee(_0x5bf832,w());_0x4d77ce&&(_0xe2635d=_0xe2635d['updateImmediateChild'](_0x21ed45,_0x4d77ce));}));const _0x3064af=Ko(_0x25b8b4,_0x42c4ea);if(!_0x3064af&&!_0x42c4ea['_queryParams']['loadsAllData']()){const _0x2b6d1d=Fn(_0x42c4ea);f(!_0x48c976['queryToTagMap']['has'](_0x2b6d1d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x140d6f=Xu();_0x48c976['queryToTagMap']['set'](_0x2b6d1d,_0x140d6f),_0x48c976['tagToQueryMap']['set'](_0x140d6f,_0x2b6d1d);}const _0xb3a567=Mn(_0x48c976['pendingWriteTree_'],_0xf13773);let _0x894b44=Wu(_0x25b8b4,_0x42c4ea,_0x30c8ee,_0xb3a567,_0xe2635d,_0x125378);if(!_0x3064af&&!_0x14e793&&!_0x2c1ca9){const _0x3da164=jo(_0x25b8b4,_0x42c4ea);_0x894b44=_0x894b44['concat'](Zu(_0x48c976,_0x42c4ea,_0x3da164));}return _0x894b44;}function xn(_0x53a6a8,_0x4bfd7e,_0x4a7aff){const _0x2e16f0=_0x53a6a8['pendingWriteTree_'],_0x50ba7c=_0x53a6a8['syncPointTree_']['findOnPath'](_0x4bfd7e,(_0x5e1847,_0x243008)=>{const _0x512ae9=F(_0x5e1847,_0x4bfd7e),_0x5b651c=Ee(_0x243008,_0x512ae9);if(_0x5b651c)return _0x5b651c;});return Uo(_0x2e16f0,_0x4bfd7e,_0x50ba7c,_0x4a7aff,!0x0);}function Yu(_0x3cef5d,_0x359ca0){const _0x249db5=_0x359ca0['_path'];let _0x2c07f1=null;_0x3cef5d['syncPointTree_']['foreachOnPath'](_0x249db5,(_0x5a3f05,_0x4c773d)=>{const _0x569c6a=F(_0x5a3f05,_0x249db5);_0x2c07f1=_0x2c07f1||Ee(_0x4c773d,_0x569c6a);});let _0x168acb=_0x3cef5d['syncPointTree_']['get'](_0x249db5);_0x168acb?_0x2c07f1=_0x2c07f1||Ee(_0x168acb,w()):(_0x168acb=new Go(),_0x3cef5d['syncPointTree_']=_0x3cef5d['syncPointTree_']['set'](_0x249db5,_0x168acb));const _0x973b2d=_0x2c07f1!=null,_0x4ab67f=_0x973b2d?new Ce(_0x2c07f1,!0x0,!0x1):null,_0x4867e8=Mn(_0x3cef5d['pendingWriteTree_'],_0x359ca0['_path']),_0x253c05=qo(_0x168acb,_0x359ca0,_0x4867e8,_0x973b2d?_0x4ab67f['getNode']():g['EMPTY_NODE'],_0x973b2d);return Ou(_0x253c05);}function ht(_0x350538,_0x4ac958){return Qo(_0x4ac958,_0x350538['syncPointTree_'],null,Mn(_0x350538['pendingWriteTree_'],w()));}function Qo(_0x280923,_0x43976f,_0x5dcf86,_0x1c88e3){if(v(_0x280923['path']))return Jo(_0x280923,_0x43976f,_0x5dcf86,_0x1c88e3);{const _0x11cae5=_0x43976f['get'](w());_0x5dcf86==null&&_0x11cae5!=null&&(_0x5dcf86=Ee(_0x11cae5,w()));let _0x75e57=[];const _0x387075=y(_0x280923['path']),_0x59057e=_0x280923['operationForChild'](_0x387075),_0x4e6631=_0x43976f['children']['get'](_0x387075);if(_0x4e6631&&_0x59057e){const _0x10c261=_0x5dcf86?_0x5dcf86['getImmediateChild'](_0x387075):null,_0x3f4172=Wo(_0x1c88e3,_0x387075);_0x75e57=_0x75e57['concat'](Qo(_0x59057e,_0x4e6631,_0x10c261,_0x3f4172));}return _0x11cae5&&(_0x75e57=_0x75e57['concat'](is(_0x11cae5,_0x280923,_0x1c88e3,_0x5dcf86))),_0x75e57;}}function Jo(_0x17f6d7,_0x2a0904,_0x4e748d,_0x540216){const _0x4b38be=_0x2a0904['get'](w());_0x4e748d==null&&_0x4b38be!=null&&(_0x4e748d=Ee(_0x4b38be,w()));let _0x4bfd27=[];return _0x2a0904['children']['inorderTraversal']((_0x4f0c8e,_0x30c65f)=>{const _0x347432=_0x4e748d?_0x4e748d['getImmediateChild'](_0x4f0c8e):null,_0x5c9007=Wo(_0x540216,_0x4f0c8e),_0x1b0df8=_0x17f6d7['operationForChild'](_0x4f0c8e);_0x1b0df8&&(_0x4bfd27=_0x4bfd27['concat'](Jo(_0x1b0df8,_0x30c65f,_0x347432,_0x5c9007)));}),_0x4b38be&&(_0x4bfd27=_0x4bfd27['concat'](is(_0x4b38be,_0x17f6d7,_0x540216,_0x4e748d))),_0x4bfd27;}function Xo(_0x250f1c,_0x4c4a87){const _0x159b4f=_0x4c4a87['query'],_0x410cb7=Mt(_0x250f1c,_0x159b4f);return{'hashFn':()=>(Pu(_0x4c4a87)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1406f2=>{if(_0x1406f2==='ok')return _0x410cb7?ju(_0x250f1c,_0x159b4f['_path'],_0x410cb7):zu(_0x250f1c,_0x159b4f['_path']);{const _0x27f3e5=ql(_0x1406f2,_0x159b4f);return wn(_0x250f1c,_0x159b4f,null,_0x27f3e5);}}};}function Mt(_0x3f2d94,_0x5ce2bb){const _0x1d1cf7=Fn(_0x5ce2bb);return _0x3f2d94['queryToTagMap']['get'](_0x1d1cf7);}function Fn(_0x265142){return _0x265142['_path']['toString']()+'$'+_0x265142['_queryIdentifier'];}function rs(_0x1539c3,_0x54d1d9){return _0x1539c3['tagToQueryMap']['get'](_0x54d1d9);}function os(_0x2600c3){const _0x440098=_0x2600c3['indexOf']('$');return f(_0x440098!==-0x1&&_0x440098<_0x2600c3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2600c3['substr'](_0x440098+0x1),'path':new C(_0x2600c3['substr'](0x0,_0x440098))};}function as(_0x2bc63c,_0x2eb18d,_0x1d023b){const _0x45ce10=_0x2bc63c['syncPointTree_']['get'](_0x2eb18d);f(_0x45ce10,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x57a984=Mn(_0x2bc63c['pendingWriteTree_'],_0x2eb18d);return is(_0x45ce10,_0x1d023b,_0x57a984,null);}function Qu(_0x2accf7){return _0x2accf7['fold']((_0x7b113f,_0x25ef43,_0xb58a2d)=>{if(_0x25ef43&&Te(_0x25ef43))return[Ln(_0x25ef43)];{let _0x25cf95=[];return _0x25ef43&&(_0x25cf95=zo(_0x25ef43)),x(_0xb58a2d,(_0x2ddb56,_0x49bf47)=>{_0x25cf95=_0x25cf95['concat'](_0x49bf47);}),_0x25cf95;}});}function Tt(_0x13850a){return _0x13850a['_queryParams']['loadsAllData']()&&!_0x13850a['_queryParams']['isDefault']()?new(Hu())(_0x13850a['_repo'],_0x13850a['_path']):_0x13850a;}function Ju(_0x29789d,_0x3ccf28){for(let _0x2c90bb=0x0;_0x2c90bb<_0x3ccf28['length'];++_0x2c90bb){const _0x3252d8=_0x3ccf28[_0x2c90bb];if(!_0x3252d8['_queryParams']['loadsAllData']()){const _0x19d30d=Fn(_0x3252d8),_0x5efe68=_0x29789d['queryToTagMap']['get'](_0x19d30d);_0x29789d['queryToTagMap']['delete'](_0x19d30d),_0x29789d['tagToQueryMap']['delete'](_0x5efe68);}}}function Xu(){return $u++;}function Zu(_0x1ef4b1,_0x5db3df,_0x1b0535){const _0x18e120=_0x5db3df['_path'],_0x3708f3=Mt(_0x1ef4b1,_0x5db3df),_0x48bbe3=Xo(_0x1ef4b1,_0x1b0535),_0x2aa3fb=_0x1ef4b1['listenProvider_']['startListening'](Tt(_0x5db3df),_0x3708f3,_0x48bbe3['hashFn'],_0x48bbe3['onComplete']),_0x46cd57=_0x1ef4b1['syncPointTree_']['subtree'](_0x18e120);if(_0x3708f3)f(!Te(_0x46cd57['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x57e3e5=_0x46cd57['fold']((_0x56a9b5,_0x1a083a,_0x590fa8)=>{if(!v(_0x56a9b5)&&_0x1a083a&&Te(_0x1a083a))return[Ln(_0x1a083a)['query']];{let _0x52803d=[];return _0x1a083a&&(_0x52803d=_0x52803d['concat'](zo(_0x1a083a)['map'](_0x10b28f=>_0x10b28f['query']))),x(_0x590fa8,(_0x4b63c6,_0x3ce6e3)=>{_0x52803d=_0x52803d['concat'](_0x3ce6e3);}),_0x52803d;}});for(let _0x3bfd3d=0x0;_0x3bfd3d<_0x57e3e5['length'];++_0x3bfd3d){const _0x43b5dc=_0x57e3e5[_0x3bfd3d];_0x1ef4b1['listenProvider_']['stopListening'](Tt(_0x43b5dc),Mt(_0x1ef4b1,_0x43b5dc));}}return _0x2aa3fb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0xdaae88){this['node_']=_0xdaae88;}['getImmediateChild'](_0x597fd2){const _0x900af5=this['node_']['getImmediateChild'](_0x597fd2);return new cs(_0x900af5);}['node'](){return this['node_'];}}class ls{constructor(_0x476774,_0x1f1656){this['syncTree_']=_0x476774,this['path_']=_0x1f1656;}['getImmediateChild'](_0x41a815){const _0x427a8f=A(this['path_'],_0x41a815);return new ls(this['syncTree_'],_0x427a8f);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x7a8074){return _0x7a8074=_0x7a8074||{},_0x7a8074['timestamp']=_0x7a8074['timestamp']||new Date()['getTime'](),_0x7a8074;},fr=function(_0x344978,_0x378bab,_0x100386){if(!_0x344978||typeof _0x344978!='object')return _0x344978;if(f('.sv'in _0x344978,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x344978['.sv']=='string')return td(_0x344978['.sv'],_0x378bab,_0x100386);if(typeof _0x344978['.sv']=='object')return nd(_0x344978['.sv'],_0x378bab);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x344978,null,0x2));},td=function(_0x54fd92,_0x5b82f8,_0xf34492){switch(_0x54fd92){case'timestamp':return _0xf34492['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x54fd92);}},nd=function(_0x595ae8,_0xe0920e,_0x4eff49){_0x595ae8['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x595ae8,null,0x2));const _0x1902f0=_0x595ae8['increment'];typeof _0x1902f0!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1902f0);const _0x1c2377=_0xe0920e['node']();if(f(_0x1c2377!==null&&typeof _0x1c2377<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1c2377['isLeafNode']())return _0x1902f0;const _0x4a0787=_0x1c2377['getValue']();return typeof _0x4a0787!='number'?_0x1902f0:_0x4a0787+_0x1902f0;},Zo=function(_0x15e641,_0x43e4a0,_0x19b928,_0x43dd97){return us(_0x43e4a0,new ls(_0x19b928,_0x15e641),_0x43dd97);},hs=function(_0x93621c,_0x4c5843,_0x292ff4){return us(_0x93621c,new cs(_0x4c5843),_0x292ff4);};function us(_0x4bf9d5,_0x30a1dc,_0x4ae723){const _0x325bef=_0x4bf9d5['getPriority']()['val'](),_0x36fab3=fr(_0x325bef,_0x30a1dc['getImmediateChild']('.priority'),_0x4ae723);let _0x47ff41;if(_0x4bf9d5['isLeafNode']()){const _0x5eb5c9=_0x4bf9d5,_0x50bcb4=fr(_0x5eb5c9['getValue'](),_0x30a1dc,_0x4ae723);return _0x50bcb4!==_0x5eb5c9['getValue']()||_0x36fab3!==_0x5eb5c9['getPriority']()['val']()?new D(_0x50bcb4,N(_0x36fab3)):_0x4bf9d5;}else{const _0x1bc4ea=_0x4bf9d5;return _0x47ff41=_0x1bc4ea,_0x36fab3!==_0x1bc4ea['getPriority']()['val']()&&(_0x47ff41=_0x47ff41['updatePriority'](new D(_0x36fab3))),_0x1bc4ea['forEachChild'](R,(_0x1a1a8a,_0x77c52c)=>{const _0x8e4829=us(_0x77c52c,_0x30a1dc['getImmediateChild'](_0x1a1a8a),_0x4ae723);_0x8e4829!==_0x77c52c&&(_0x47ff41=_0x47ff41['updateImmediateChild'](_0x1a1a8a,_0x8e4829));}),_0x47ff41;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x142d3a='',_0x37295c=null,_0xd29fad={'children':{},'childCount':0x0}){this['name']=_0x142d3a,this['parent']=_0x37295c,this['node']=_0xd29fad;}}function Un(_0xa9ffda,_0x429828){let _0x5ee89c=_0x429828 instanceof C?_0x429828:new C(_0x429828),_0x294cec=_0xa9ffda,_0x4da449=y(_0x5ee89c);for(;_0x4da449!==null;){const _0x29e46c=Oe(_0x294cec['node']['children'],_0x4da449)||{'children':{},'childCount':0x0};_0x294cec=new ds(_0x4da449,_0x294cec,_0x29e46c),_0x5ee89c=b(_0x5ee89c),_0x4da449=y(_0x5ee89c);}return _0x294cec;}function Ge(_0x22d5d1){return _0x22d5d1['node']['value'];}function fs(_0xf666fa,_0x5200dc){_0xf666fa['node']['value']=_0x5200dc,Ri(_0xf666fa);}function ea(_0x3bbae2){return _0x3bbae2['node']['childCount']>0x0;}function id(_0x5a71af){return Ge(_0x5a71af)===void 0x0&&!ea(_0x5a71af);}function Wn(_0xb0e141,_0x30f562){x(_0xb0e141['node']['children'],(_0x1f38ca,_0x201e2e)=>{_0x30f562(new ds(_0x1f38ca,_0xb0e141,_0x201e2e));});}function ta(_0x358012,_0x12afd4,_0x13da9e,_0x592ab6){_0x13da9e&&_0x12afd4(_0x358012),Wn(_0x358012,_0x34419b=>{ta(_0x34419b,_0x12afd4,!0x0);});}function sd(_0x477cda,_0x47758b,_0x580f54){let _0x554159=_0x477cda['parent'];for(;_0x554159!==null;){if(_0x47758b(_0x554159))return!0x0;_0x554159=_0x554159['parent'];}return!0x1;}function Gt(_0x45343c){return new C(_0x45343c['parent']===null?_0x45343c['name']:Gt(_0x45343c['parent'])+'/'+_0x45343c['name']);}function Ri(_0x55575f){_0x55575f['parent']!==null&&rd(_0x55575f['parent'],_0x55575f['name'],_0x55575f);}function rd(_0x13557a,_0x1c3355,_0x53d92d){const _0x1501f0=id(_0x53d92d),_0x428abb=Y(_0x13557a['node']['children'],_0x1c3355);_0x1501f0&&_0x428abb?(delete _0x13557a['node']['children'][_0x1c3355],_0x13557a['node']['childCount']--,Ri(_0x13557a)):!_0x1501f0&&!_0x428abb&&(_0x13557a['node']['children'][_0x1c3355]=_0x53d92d['node'],_0x13557a['node']['childCount']++,Ri(_0x13557a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0xee51ca){return typeof _0xee51ca=='string'&&_0xee51ca['length']!==0x0&&!od['test'](_0xee51ca);},na=function(_0x1a903b){return typeof _0x1a903b=='string'&&_0x1a903b['length']!==0x0&&!ad['test'](_0x1a903b);},cd=function(_0x1c0b9b){return _0x1c0b9b&&(_0x1c0b9b=_0x1c0b9b['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1c0b9b);},Cn=function(_0x223f80){return _0x223f80===null||typeof _0x223f80=='string'||typeof _0x223f80=='number'&&!Wi(_0x223f80)||_0x223f80&&typeof _0x223f80=='object'&&Y(_0x223f80,'.sv');},qt=function(_0x156b21,_0x3105bf,_0x43052c,_0x25a026){_0x25a026&&_0x3105bf===void 0x0||zt(Nn(_0x156b21,'value'),_0x3105bf,_0x43052c);},zt=function(_0x25a536,_0x1d0315,_0xa64a85){const _0x3f7337=_0xa64a85 instanceof C?new Sh(_0xa64a85,_0x25a536):_0xa64a85;if(_0x1d0315===void 0x0)throw new Error(_0x25a536+'contains\x20undefined\x20'+Ne(_0x3f7337));if(typeof _0x1d0315=='function')throw new Error(_0x25a536+'contains\x20a\x20function\x20'+Ne(_0x3f7337)+'\x20with\x20contents\x20=\x20'+_0x1d0315['toString']());if(Wi(_0x1d0315))throw new Error(_0x25a536+'contains\x20'+_0x1d0315['toString']()+'\x20'+Ne(_0x3f7337));if(typeof _0x1d0315=='string'&&_0x1d0315['length']>oi/0x3&&Pn(_0x1d0315)>oi)throw new Error(_0x25a536+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x3f7337)+'\x20(\x27'+_0x1d0315['substring'](0x0,0x32)+'...\x27)');if(_0x1d0315&&typeof _0x1d0315=='object'){let _0x3df6e5=!0x1,_0x5d6bad=!0x1;if(x(_0x1d0315,(_0x23e5e3,_0x4d4313)=>{if(_0x23e5e3==='.value')_0x3df6e5=!0x0;else{if(_0x23e5e3!=='.priority'&&_0x23e5e3!=='.sv'&&(_0x5d6bad=!0x0,!ps(_0x23e5e3)))throw new Error(_0x25a536+'\x20contains\x20an\x20invalid\x20key\x20('+_0x23e5e3+')\x20'+Ne(_0x3f7337)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x3f7337,_0x23e5e3),zt(_0x25a536,_0x4d4313,_0x3f7337),Rh(_0x3f7337);}),_0x3df6e5&&_0x5d6bad)throw new Error(_0x25a536+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x3f7337)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x3a1c17,_0x5c6fb3){let _0x216e1e,_0x561661;for(_0x216e1e=0x0;_0x216e1e<_0x5c6fb3['length'];_0x216e1e++){_0x561661=_0x5c6fb3[_0x216e1e];const _0x37fab4=kt(_0x561661);for(let _0x10b82c=0x0;_0x10b82c<_0x37fab4['length'];_0x10b82c++)if(!(_0x37fab4[_0x10b82c]==='.priority'&&_0x10b82c===_0x37fab4['length']-0x1)){if(!ps(_0x37fab4[_0x10b82c]))throw new Error(_0x3a1c17+'contains\x20an\x20invalid\x20key\x20('+_0x37fab4[_0x10b82c]+')\x20in\x20path\x20'+_0x561661['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5c6fb3['sort'](Th);let _0x5417f7=null;for(_0x216e1e=0x0;_0x216e1e<_0x5c6fb3['length'];_0x216e1e++){if(_0x561661=_0x5c6fb3[_0x216e1e],_0x5417f7!==null&&$(_0x5417f7,_0x561661))throw new Error(_0x3a1c17+'contains\x20a\x20path\x20'+_0x5417f7['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x561661['toString']());_0x5417f7=_0x561661;}},hd=function(_0x40dede,_0x5ef858,_0x55629e,_0x589596){const _0xe0cff6=Nn(_0x40dede,'values');if(!(_0x5ef858&&typeof _0x5ef858=='object')||Array['isArray'](_0x5ef858))throw new Error(_0xe0cff6+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x456fd0=[];x(_0x5ef858,(_0x4f5f2d,_0x16aaf3)=>{const _0x4f52dc=new C(_0x4f5f2d);if(zt(_0xe0cff6,_0x16aaf3,A(_0x55629e,_0x4f52dc)),Gi(_0x4f52dc)==='.priority'&&!Cn(_0x16aaf3))throw new Error(_0xe0cff6+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4f52dc['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x456fd0['push'](_0x4f52dc);}),ld(_0xe0cff6,_0x456fd0);},_s=function(_0x42eac5,_0x1303fd,_0x31903f,_0x269627){if(!na(_0x31903f))throw new Error(Nn(_0x42eac5,_0x1303fd)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x31903f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0xecb88e,_0x55fe5d,_0x2d4f9a,_0x1cbf02){_0x2d4f9a&&(_0x2d4f9a=_0x2d4f9a['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0xecb88e,_0x55fe5d,_0x2d4f9a);},gs=function(_0x125ad5,_0x65426){if(y(_0x65426)==='.info')throw new Error(_0x125ad5+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x31c233,_0x29be89){const _0x4d18db=_0x29be89['path']['toString']();if(typeof _0x29be89['repoInfo']['host']!='string'||_0x29be89['repoInfo']['host']['length']===0x0||!ps(_0x29be89['repoInfo']['namespace'])&&_0x29be89['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4d18db['length']!==0x0&&!cd(_0x4d18db))throw new Error(Nn(_0x31c233,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x604dca,_0x54da46){let _0x3a52a0=null;for(let _0x4f1340=0x0;_0x4f1340<_0x54da46['length'];_0x4f1340++){const _0x1584c9=_0x54da46[_0x4f1340],_0x59e942=_0x1584c9['getPath']();_0x3a52a0!==null&&!qi(_0x59e942,_0x3a52a0['path'])&&(_0x604dca['eventLists_']['push'](_0x3a52a0),_0x3a52a0=null),_0x3a52a0===null&&(_0x3a52a0={'events':[],'path':_0x59e942}),_0x3a52a0['events']['push'](_0x1584c9);}_0x3a52a0&&_0x604dca['eventLists_']['push'](_0x3a52a0);}function ia(_0x92b427,_0x2b8885,_0x4fba56){Bn(_0x92b427,_0x4fba56),sa(_0x92b427,_0x947279=>qi(_0x947279,_0x2b8885));}function V(_0x1eb1f2,_0x44d4a5,_0x3d129f){Bn(_0x1eb1f2,_0x3d129f),sa(_0x1eb1f2,_0x108102=>$(_0x108102,_0x44d4a5)||$(_0x44d4a5,_0x108102));}function sa(_0x809b56,_0xf1578d){_0x809b56['recursionDepth_']++;let _0x5f2013=!0x0;for(let _0x2116e5=0x0;_0x2116e5<_0x809b56['eventLists_']['length'];_0x2116e5++){const _0x172ba3=_0x809b56['eventLists_'][_0x2116e5];if(_0x172ba3){const _0x8794f=_0x172ba3['path'];_0xf1578d(_0x8794f)?(pd(_0x809b56['eventLists_'][_0x2116e5]),_0x809b56['eventLists_'][_0x2116e5]=null):_0x5f2013=!0x1;}}_0x5f2013&&(_0x809b56['eventLists_']=[]),_0x809b56['recursionDepth_']--;}function pd(_0x20dc56){for(let _0x37ade4=0x0;_0x37ade4<_0x20dc56['events']['length'];_0x37ade4++){const _0x1acb29=_0x20dc56['events'][_0x37ade4];if(_0x1acb29!==null){_0x20dc56['events'][_0x37ade4]=null;const _0x4d4c28=_0x1acb29['getEventRunner']();Et&&L('event:\x20'+_0x1acb29['toString']()),lt(_0x4d4c28);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x593419,_0x475922,_0x2a4d2a,_0x1fe976){this['repoInfo_']=_0x593419,this['forceRestClient_']=_0x475922,this['authTokenProvider_']=_0x2a4d2a,this['appCheckProvider_']=_0x1fe976,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x4fb418,_0x4b4ed0,_0x131fe8){if(_0x4fb418['stats_']=Hi(_0x4fb418['repoInfo_']),_0x4fb418['forceRestClient_']||Yl())_0x4fb418['server_']=new fn(_0x4fb418['repoInfo_'],(_0x1f86aa,_0xdcbe54,_0x6c2256,_0xa3d6d6)=>{pr(_0x4fb418,_0x1f86aa,_0xdcbe54,_0x6c2256,_0xa3d6d6);},_0x4fb418['authTokenProvider_'],_0x4fb418['appCheckProvider_']),setTimeout(()=>_r(_0x4fb418,!0x0),0x0);else{if(typeof _0x131fe8<'u'&&_0x131fe8!==null){if(typeof _0x131fe8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x131fe8);}catch(_0x24e945){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x24e945);}}_0x4fb418['persistentConnection_']=new ie(_0x4fb418['repoInfo_'],_0x4b4ed0,(_0x571301,_0x388718,_0x4d624f,_0x324a14)=>{pr(_0x4fb418,_0x571301,_0x388718,_0x4d624f,_0x324a14);},_0x59a916=>{_r(_0x4fb418,_0x59a916);},_0x3f6a20=>{yd(_0x4fb418,_0x3f6a20);},_0x4fb418['authTokenProvider_'],_0x4fb418['appCheckProvider_'],_0x131fe8),_0x4fb418['server_']=_0x4fb418['persistentConnection_'];}_0x4fb418['authTokenProvider_']['addTokenChangeListener'](_0xd6c729=>{_0x4fb418['server_']['refreshAuthToken'](_0xd6c729);}),_0x4fb418['appCheckProvider_']['addTokenChangeListener'](_0x403fb2=>{_0x4fb418['server_']['refreshAppCheckToken'](_0x403fb2['token']);}),_0x4fb418['statsReporter_']=eh(_0x4fb418['repoInfo_'],()=>new eu(_0x4fb418['stats_'],_0x4fb418['server_'])),_0x4fb418['infoData_']=new Yh(),_0x4fb418['infoSyncTree_']=new dr({'startListening':(_0x36e789,_0x982071,_0x367378,_0x29dae6)=>{let _0x21ce71=[];const _0x7d98c8=_0x4fb418['infoData_']['getNode'](_0x36e789['_path']);return _0x7d98c8['isEmpty']()||(_0x21ce71=$t(_0x4fb418['infoSyncTree_'],_0x36e789['_path'],_0x7d98c8),setTimeout(()=>{_0x29dae6('ok');},0x0)),_0x21ce71;},'stopListening':()=>{}}),ms(_0x4fb418,'connected',!0x1),_0x4fb418['serverSyncTree_']=new dr({'startListening':(_0x4f0e63,_0x139d55,_0x2be616,_0x127b53)=>(_0x4fb418['server_']['listen'](_0x4f0e63,_0x2be616,_0x139d55,(_0x168e55,_0x5e4601)=>{const _0xbe4d7b=_0x127b53(_0x168e55,_0x5e4601);V(_0x4fb418['eventQueue_'],_0x4f0e63['_path'],_0xbe4d7b);}),[]),'stopListening':(_0x5d1761,_0x4171f1)=>{_0x4fb418['server_']['unlisten'](_0x5d1761,_0x4171f1);}});}function oa(_0x51a3e3){const _0x1fa595=_0x51a3e3['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1fa595;}function jt(_0x58bef7){return ed({'timestamp':oa(_0x58bef7)});}function pr(_0x18b567,_0x1d9a2b,_0xae08ec,_0x1e622d,_0x11f5a6){_0x18b567['dataUpdateCount']++;const _0x1e498c=new C(_0x1d9a2b);_0xae08ec=_0x18b567['interceptServerDataCallback_']?_0x18b567['interceptServerDataCallback_'](_0x1d9a2b,_0xae08ec):_0xae08ec;let _0x48fb4f=[];if(_0x11f5a6){if(_0x1e622d){const _0x3edef6=ln(_0xae08ec,_0x51e5a8=>N(_0x51e5a8));_0x48fb4f=Ku(_0x18b567['serverSyncTree_'],_0x1e498c,_0x3edef6,_0x11f5a6);}else{const _0x268d74=N(_0xae08ec);_0x48fb4f=Yo(_0x18b567['serverSyncTree_'],_0x1e498c,_0x268d74,_0x11f5a6);}}else{if(_0x1e622d){const _0x3adff2=ln(_0xae08ec,_0x98aff8=>N(_0x98aff8));_0x48fb4f=qu(_0x18b567['serverSyncTree_'],_0x1e498c,_0x3adff2);}else{const _0x37f5d3=N(_0xae08ec);_0x48fb4f=$t(_0x18b567['serverSyncTree_'],_0x1e498c,_0x37f5d3);}}let _0x18b183=_0x1e498c;_0x48fb4f['length']>0x0&&(_0x18b183=st(_0x18b567,_0x1e498c)),V(_0x18b567['eventQueue_'],_0x18b183,_0x48fb4f);}function _r(_0x10af11,_0x25ae0f){ms(_0x10af11,'connected',_0x25ae0f),_0x25ae0f===!0x1&&wd(_0x10af11);}function yd(_0x577497,_0x3e8ccc){x(_0x3e8ccc,(_0x571b35,_0x234d07)=>{ms(_0x577497,_0x571b35,_0x234d07);});}function ms(_0x34f4f9,_0xd3cb0c,_0x25c931){const _0x13fb86=new C('/.info/'+_0xd3cb0c),_0x2e03e8=N(_0x25c931);_0x34f4f9['infoData_']['updateSnapshot'](_0x13fb86,_0x2e03e8);const _0x3c7075=$t(_0x34f4f9['infoSyncTree_'],_0x13fb86,_0x2e03e8);V(_0x34f4f9['eventQueue_'],_0x13fb86,_0x3c7075);}function Vn(_0x8ff41b){return _0x8ff41b['nextWriteId_']++;}function vd(_0x5efe74,_0x264b5a,_0x463005){const _0x3de524=Yu(_0x5efe74['serverSyncTree_'],_0x264b5a);return _0x3de524!=null?Promise['resolve'](_0x3de524):_0x5efe74['server_']['get'](_0x264b5a)['then'](_0x1da592=>{const _0x5e6ea2=N(_0x1da592)['withIndex'](_0x264b5a['_queryParams']['getIndex']());bi(_0x5efe74['serverSyncTree_'],_0x264b5a,_0x463005,!0x0);let _0x387130;if(_0x264b5a['_queryParams']['loadsAllData']())_0x387130=$t(_0x5efe74['serverSyncTree_'],_0x264b5a['_path'],_0x5e6ea2);else{const _0x3056bf=Mt(_0x5efe74['serverSyncTree_'],_0x264b5a);_0x387130=Yo(_0x5efe74['serverSyncTree_'],_0x264b5a['_path'],_0x5e6ea2,_0x3056bf);}return V(_0x5efe74['eventQueue_'],_0x264b5a['_path'],_0x387130),wn(_0x5efe74['serverSyncTree_'],_0x264b5a,_0x463005,null,!0x0),_0x5e6ea2;},_0xbf173c=>(ut(_0x5efe74,'get\x20for\x20query\x20'+O(_0x264b5a)+'\x20failed:\x20'+_0xbf173c),Promise['reject'](new Error(_0xbf173c))));}function Ed(_0x216a06,_0x4417fe,_0x2aa4a4,_0xfd2652,_0x5f3a6d){ut(_0x216a06,'set',{'path':_0x4417fe['toString'](),'value':_0x2aa4a4,'priority':_0xfd2652});const _0x34c18f=jt(_0x216a06),_0x290374=N(_0x2aa4a4,_0xfd2652),_0x1cfcc9=xn(_0x216a06['serverSyncTree_'],_0x4417fe),_0x3e4479=hs(_0x290374,_0x1cfcc9,_0x34c18f),_0x156b1c=Vn(_0x216a06),_0x1cb5e4=ss(_0x216a06['serverSyncTree_'],_0x4417fe,_0x3e4479,_0x156b1c,!0x0);Bn(_0x216a06['eventQueue_'],_0x1cb5e4),_0x216a06['server_']['put'](_0x4417fe['toString'](),_0x290374['val'](!0x0),(_0x1ba9e5,_0x1f944b)=>{const _0x59f20a=_0x1ba9e5==='ok';_0x59f20a||U('set\x20at\x20'+_0x4417fe+'\x20failed:\x20'+_0x1ba9e5);const _0x5421ad=pe(_0x216a06['serverSyncTree_'],_0x156b1c,!_0x59f20a);V(_0x216a06['eventQueue_'],_0x4417fe,_0x5421ad),Ai(_0x216a06,_0x5f3a6d,_0x1ba9e5,_0x1f944b);});const _0x21b748=vs(_0x216a06,_0x4417fe);st(_0x216a06,_0x21b748),V(_0x216a06['eventQueue_'],_0x21b748,[]);}function Id(_0x331523,_0x40134c,_0x59df65,_0x2bb231){ut(_0x331523,'update',{'path':_0x40134c['toString'](),'value':_0x59df65});let _0x5a38b9=!0x0;const _0x16c645=jt(_0x331523),_0x248db5={};if(x(_0x59df65,(_0x25348a,_0x179fff)=>{_0x5a38b9=!0x1,_0x248db5[_0x25348a]=Zo(A(_0x40134c,_0x25348a),N(_0x179fff),_0x331523['serverSyncTree_'],_0x16c645);}),_0x5a38b9)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x331523,_0x2bb231,'ok',void 0x0);else{const _0x46fd20=Vn(_0x331523),_0x58095b=Gu(_0x331523['serverSyncTree_'],_0x40134c,_0x248db5,_0x46fd20);Bn(_0x331523['eventQueue_'],_0x58095b),_0x331523['server_']['merge'](_0x40134c['toString'](),_0x59df65,(_0xf95b2b,_0x47e02e)=>{const _0x193ad8=_0xf95b2b==='ok';_0x193ad8||U('update\x20at\x20'+_0x40134c+'\x20failed:\x20'+_0xf95b2b);const _0x42a793=pe(_0x331523['serverSyncTree_'],_0x46fd20,!_0x193ad8),_0x4cd4f6=_0x42a793['length']>0x0?st(_0x331523,_0x40134c):_0x40134c;V(_0x331523['eventQueue_'],_0x4cd4f6,_0x42a793),Ai(_0x331523,_0x2bb231,_0xf95b2b,_0x47e02e);}),x(_0x59df65,_0x1495d6=>{const _0x5bc77a=vs(_0x331523,A(_0x40134c,_0x1495d6));st(_0x331523,_0x5bc77a);}),V(_0x331523['eventQueue_'],_0x40134c,[]);}}function wd(_0x26a370){ut(_0x26a370,'onDisconnectEvents');const _0x3b4153=jt(_0x26a370),_0x5049ef=pn();Ei(_0x26a370['onDisconnect_'],w(),(_0x25b81a,_0x2182ff)=>{const _0x240dd4=Zo(_0x25b81a,_0x2182ff,_0x26a370['serverSyncTree_'],_0x3b4153);Mo(_0x5049ef,_0x25b81a,_0x240dd4);});let _0x1dc069=[];Ei(_0x5049ef,w(),(_0x4b50ac,_0x51dd44)=>{_0x1dc069=_0x1dc069['concat']($t(_0x26a370['serverSyncTree_'],_0x4b50ac,_0x51dd44));const _0x26d71e=vs(_0x26a370,_0x4b50ac);st(_0x26a370,_0x26d71e);}),_0x26a370['onDisconnect_']=pn(),V(_0x26a370['eventQueue_'],w(),_0x1dc069);}function Cd(_0x727c52,_0x3fd9f3,_0x39e3b9){let _0x1a0dd9;y(_0x3fd9f3['_path'])==='.info'?_0x1a0dd9=bi(_0x727c52['infoSyncTree_'],_0x3fd9f3,_0x39e3b9):_0x1a0dd9=bi(_0x727c52['serverSyncTree_'],_0x3fd9f3,_0x39e3b9),ia(_0x727c52['eventQueue_'],_0x3fd9f3['_path'],_0x1a0dd9);}function Td(_0x4b0005,_0x482cae,_0x1ada8c){let _0x3e72eb;y(_0x482cae['_path'])==='.info'?_0x3e72eb=wn(_0x4b0005['infoSyncTree_'],_0x482cae,_0x1ada8c):_0x3e72eb=wn(_0x4b0005['serverSyncTree_'],_0x482cae,_0x1ada8c),ia(_0x4b0005['eventQueue_'],_0x482cae['_path'],_0x3e72eb);}function aa(_0x23df95){_0x23df95['persistentConnection_']&&_0x23df95['persistentConnection_']['interrupt'](ra);}function Sd(_0x21c9b1){_0x21c9b1['persistentConnection_']&&_0x21c9b1['persistentConnection_']['resume'](ra);}function ut(_0x4e6f65,..._0x5eb7cd){let _0x2071b3='';_0x4e6f65['persistentConnection_']&&(_0x2071b3=_0x4e6f65['persistentConnection_']['id']+':'),L(_0x2071b3,..._0x5eb7cd);}function Ai(_0x415acd,_0x4a006b,_0x1829e7,_0x5b4674){_0x4a006b&&lt(()=>{if(_0x1829e7==='ok')_0x4a006b(null);else{const _0x1298f2=(_0x1829e7||'error')['toUpperCase']();let _0x53743b=_0x1298f2;_0x5b4674&&(_0x53743b+=':\x20'+_0x5b4674);const _0x15218f=new Error(_0x53743b);_0x15218f['code']=_0x1298f2,_0x4a006b(_0x15218f);}});}function bd(_0x12a5af,_0x383e00,_0x1e597f,_0x282f0e,_0x3ef55d,_0x1ce80b){ut(_0x12a5af,'transaction\x20on\x20'+_0x383e00);const _0x414971={'path':_0x383e00,'update':_0x1e597f,'onComplete':_0x282f0e,'status':null,'order':to(),'applyLocally':_0x1ce80b,'retryCount':0x0,'unwatcher':_0x3ef55d,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4f8fee=ys(_0x12a5af,_0x383e00,void 0x0);_0x414971['currentInputSnapshot']=_0x4f8fee;const _0x59f19d=_0x414971['update'](_0x4f8fee['val']());if(_0x59f19d===void 0x0)_0x414971['unwatcher'](),_0x414971['currentOutputSnapshotRaw']=null,_0x414971['currentOutputSnapshotResolved']=null,_0x414971['onComplete']&&_0x414971['onComplete'](null,!0x1,_0x414971['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x59f19d,_0x414971['path']),_0x414971['status']=0x0;const _0x59e614=Un(_0x12a5af['transactionQueueTree_'],_0x383e00),_0x340303=Ge(_0x59e614)||[];_0x340303['push'](_0x414971),fs(_0x59e614,_0x340303);let _0x2e41b3;typeof _0x59f19d=='object'&&_0x59f19d!==null&&Y(_0x59f19d,'.priority')?(_0x2e41b3=Oe(_0x59f19d,'.priority'),f(Cn(_0x2e41b3),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2e41b3=(xn(_0x12a5af['serverSyncTree_'],_0x383e00)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x987fad=jt(_0x12a5af),_0x1e3deb=N(_0x59f19d,_0x2e41b3),_0x4aebd9=hs(_0x1e3deb,_0x4f8fee,_0x987fad);_0x414971['currentOutputSnapshotRaw']=_0x1e3deb,_0x414971['currentOutputSnapshotResolved']=_0x4aebd9,_0x414971['currentWriteId']=Vn(_0x12a5af);const _0x2805d5=ss(_0x12a5af['serverSyncTree_'],_0x383e00,_0x4aebd9,_0x414971['currentWriteId'],_0x414971['applyLocally']);V(_0x12a5af['eventQueue_'],_0x383e00,_0x2805d5),Hn(_0x12a5af,_0x12a5af['transactionQueueTree_']);}}function ys(_0x509689,_0x2be786,_0x220422){return xn(_0x509689['serverSyncTree_'],_0x2be786,_0x220422)||g['EMPTY_NODE'];}function Hn(_0x3e487a,_0x12a4dc=_0x3e487a['transactionQueueTree_']){if(_0x12a4dc||$n(_0x3e487a,_0x12a4dc),Ge(_0x12a4dc)){const _0x10be8d=la(_0x3e487a,_0x12a4dc);f(_0x10be8d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x10be8d['every'](_0x5eb1ba=>_0x5eb1ba['status']===0x0)&&Rd(_0x3e487a,Gt(_0x12a4dc),_0x10be8d);}else ea(_0x12a4dc)&&Wn(_0x12a4dc,_0x2bd476=>{Hn(_0x3e487a,_0x2bd476);});}function Rd(_0x283e9c,_0x1fa562,_0x359f1d){const _0x4c241c=_0x359f1d['map'](_0xb145d6=>_0xb145d6['currentWriteId']),_0x12077a=ys(_0x283e9c,_0x1fa562,_0x4c241c);let _0x5a6aa1=_0x12077a;const _0x20020f=_0x12077a['hash']();for(let _0x1073d2=0x0;_0x1073d2<_0x359f1d['length'];_0x1073d2++){const _0x3bb7ce=_0x359f1d[_0x1073d2];f(_0x3bb7ce['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3bb7ce['status']=0x1,_0x3bb7ce['retryCount']++;const _0x8e24f1=F(_0x1fa562,_0x3bb7ce['path']);_0x5a6aa1=_0x5a6aa1['updateChild'](_0x8e24f1,_0x3bb7ce['currentOutputSnapshotRaw']);}const _0x4ae2a3=_0x5a6aa1['val'](!0x0),_0x20b9a3=_0x1fa562;_0x283e9c['server_']['put'](_0x20b9a3['toString'](),_0x4ae2a3,_0x488e81=>{ut(_0x283e9c,'transaction\x20put\x20response',{'path':_0x20b9a3['toString'](),'status':_0x488e81});let _0x1834e9=[];if(_0x488e81==='ok'){const _0x3d5102=[];for(let _0x2c51d4=0x0;_0x2c51d4<_0x359f1d['length'];_0x2c51d4++)_0x359f1d[_0x2c51d4]['status']=0x2,_0x1834e9=_0x1834e9['concat'](pe(_0x283e9c['serverSyncTree_'],_0x359f1d[_0x2c51d4]['currentWriteId'])),_0x359f1d[_0x2c51d4]['onComplete']&&_0x3d5102['push'](()=>_0x359f1d[_0x2c51d4]['onComplete'](null,!0x0,_0x359f1d[_0x2c51d4]['currentOutputSnapshotResolved'])),_0x359f1d[_0x2c51d4]['unwatcher']();$n(_0x283e9c,Un(_0x283e9c['transactionQueueTree_'],_0x1fa562)),Hn(_0x283e9c,_0x283e9c['transactionQueueTree_']),V(_0x283e9c['eventQueue_'],_0x1fa562,_0x1834e9);for(let _0x185e4f=0x0;_0x185e4f<_0x3d5102['length'];_0x185e4f++)lt(_0x3d5102[_0x185e4f]);}else{if(_0x488e81==='datastale'){for(let _0xa920e7=0x0;_0xa920e7<_0x359f1d['length'];_0xa920e7++)_0x359f1d[_0xa920e7]['status']===0x3?_0x359f1d[_0xa920e7]['status']=0x4:_0x359f1d[_0xa920e7]['status']=0x0;}else{U('transaction\x20at\x20'+_0x20b9a3['toString']()+'\x20failed:\x20'+_0x488e81);for(let _0x5b7067=0x0;_0x5b7067<_0x359f1d['length'];_0x5b7067++)_0x359f1d[_0x5b7067]['status']=0x4,_0x359f1d[_0x5b7067]['abortReason']=_0x488e81;}st(_0x283e9c,_0x1fa562);}},_0x20020f);}function st(_0x119f03,_0x14e9ff){const _0x581de=ca(_0x119f03,_0x14e9ff),_0x49bb82=Gt(_0x581de),_0x419c00=la(_0x119f03,_0x581de);return Ad(_0x119f03,_0x419c00,_0x49bb82),_0x49bb82;}function Ad(_0x4e1c9c,_0x30e75f,_0x369f46){if(_0x30e75f['length']===0x0)return;const _0x36f40b=[];let _0x50bfa6=[];const _0x37b02e=_0x30e75f['filter'](_0x42d02b=>_0x42d02b['status']===0x0)['map'](_0xc33c8a=>_0xc33c8a['currentWriteId']);for(let _0x5aeda0=0x0;_0x5aeda0<_0x30e75f['length'];_0x5aeda0++){const _0x46e590=_0x30e75f[_0x5aeda0],_0x486154=F(_0x369f46,_0x46e590['path']);let _0x373e85=!0x1,_0x409997;if(f(_0x486154!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x46e590['status']===0x4)_0x373e85=!0x0,_0x409997=_0x46e590['abortReason'],_0x50bfa6=_0x50bfa6['concat'](pe(_0x4e1c9c['serverSyncTree_'],_0x46e590['currentWriteId'],!0x0));else{if(_0x46e590['status']===0x0){if(_0x46e590['retryCount']>=_d)_0x373e85=!0x0,_0x409997='maxretry',_0x50bfa6=_0x50bfa6['concat'](pe(_0x4e1c9c['serverSyncTree_'],_0x46e590['currentWriteId'],!0x0));else{const _0x12362b=ys(_0x4e1c9c,_0x46e590['path'],_0x37b02e);_0x46e590['currentInputSnapshot']=_0x12362b;const _0xddcd41=_0x30e75f[_0x5aeda0]['update'](_0x12362b['val']());if(_0xddcd41!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xddcd41,_0x46e590['path']);let _0x20ae18=N(_0xddcd41);typeof _0xddcd41=='object'&&_0xddcd41!=null&&Y(_0xddcd41,'.priority')||(_0x20ae18=_0x20ae18['updatePriority'](_0x12362b['getPriority']()));const _0x3b76ff=_0x46e590['currentWriteId'],_0x307655=jt(_0x4e1c9c),_0x5e4a4c=hs(_0x20ae18,_0x12362b,_0x307655);_0x46e590['currentOutputSnapshotRaw']=_0x20ae18,_0x46e590['currentOutputSnapshotResolved']=_0x5e4a4c,_0x46e590['currentWriteId']=Vn(_0x4e1c9c),_0x37b02e['splice'](_0x37b02e['indexOf'](_0x3b76ff),0x1),_0x50bfa6=_0x50bfa6['concat'](ss(_0x4e1c9c['serverSyncTree_'],_0x46e590['path'],_0x5e4a4c,_0x46e590['currentWriteId'],_0x46e590['applyLocally'])),_0x50bfa6=_0x50bfa6['concat'](pe(_0x4e1c9c['serverSyncTree_'],_0x3b76ff,!0x0));}else _0x373e85=!0x0,_0x409997='nodata',_0x50bfa6=_0x50bfa6['concat'](pe(_0x4e1c9c['serverSyncTree_'],_0x46e590['currentWriteId'],!0x0));}}}V(_0x4e1c9c['eventQueue_'],_0x369f46,_0x50bfa6),_0x50bfa6=[],_0x373e85&&(_0x30e75f[_0x5aeda0]['status']=0x2,function(_0x2631fc){setTimeout(_0x2631fc,Math['floor'](0x0));}(_0x30e75f[_0x5aeda0]['unwatcher']),_0x30e75f[_0x5aeda0]['onComplete']&&(_0x409997==='nodata'?_0x36f40b['push'](()=>_0x30e75f[_0x5aeda0]['onComplete'](null,!0x1,_0x30e75f[_0x5aeda0]['currentInputSnapshot'])):_0x36f40b['push'](()=>_0x30e75f[_0x5aeda0]['onComplete'](new Error(_0x409997),!0x1,null))));}$n(_0x4e1c9c,_0x4e1c9c['transactionQueueTree_']);for(let _0xa8e2fc=0x0;_0xa8e2fc<_0x36f40b['length'];_0xa8e2fc++)lt(_0x36f40b[_0xa8e2fc]);Hn(_0x4e1c9c,_0x4e1c9c['transactionQueueTree_']);}function ca(_0x10fe2b,_0x7e962d){let _0x94d048,_0x15557f=_0x10fe2b['transactionQueueTree_'];for(_0x94d048=y(_0x7e962d);_0x94d048!==null&&Ge(_0x15557f)===void 0x0;)_0x15557f=Un(_0x15557f,_0x94d048),_0x7e962d=b(_0x7e962d),_0x94d048=y(_0x7e962d);return _0x15557f;}function la(_0x1c148a,_0x238a7c){const _0x3ecff1=[];return ha(_0x1c148a,_0x238a7c,_0x3ecff1),_0x3ecff1['sort']((_0x5339aa,_0x34f86f)=>_0x5339aa['order']-_0x34f86f['order']),_0x3ecff1;}function ha(_0x1c6ad7,_0x42a7d4,_0x1d7f87){const _0x15779f=Ge(_0x42a7d4);if(_0x15779f){for(let _0xa34dc8=0x0;_0xa34dc8<_0x15779f['length'];_0xa34dc8++)_0x1d7f87['push'](_0x15779f[_0xa34dc8]);}Wn(_0x42a7d4,_0x441e64=>{ha(_0x1c6ad7,_0x441e64,_0x1d7f87);});}function $n(_0x39a58a,_0x5dd4fa){const _0xa77547=Ge(_0x5dd4fa);if(_0xa77547){let _0x4b2b5c=0x0;for(let _0xdbeed1=0x0;_0xdbeed1<_0xa77547['length'];_0xdbeed1++)_0xa77547[_0xdbeed1]['status']!==0x2&&(_0xa77547[_0x4b2b5c]=_0xa77547[_0xdbeed1],_0x4b2b5c++);_0xa77547['length']=_0x4b2b5c,fs(_0x5dd4fa,_0xa77547['length']>0x0?_0xa77547:void 0x0);}Wn(_0x5dd4fa,_0x4709cc=>{$n(_0x39a58a,_0x4709cc);});}function vs(_0xc15eec,_0xdbff19){const _0x3742b3=Gt(ca(_0xc15eec,_0xdbff19)),_0x4a17df=Un(_0xc15eec['transactionQueueTree_'],_0xdbff19);return sd(_0x4a17df,_0x25e580=>{ai(_0xc15eec,_0x25e580);}),ai(_0xc15eec,_0x4a17df),ta(_0x4a17df,_0xce8685=>{ai(_0xc15eec,_0xce8685);}),_0x3742b3;}function ai(_0x3c7b77,_0x111cc4){const _0x5ba01e=Ge(_0x111cc4);if(_0x5ba01e){const _0x4f327b=[];let _0x288b2c=[],_0x1cd275=-0x1;for(let _0x48fca9=0x0;_0x48fca9<_0x5ba01e['length'];_0x48fca9++)_0x5ba01e[_0x48fca9]['status']===0x3||(_0x5ba01e[_0x48fca9]['status']===0x1?(f(_0x1cd275===_0x48fca9-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1cd275=_0x48fca9,_0x5ba01e[_0x48fca9]['status']=0x3,_0x5ba01e[_0x48fca9]['abortReason']='set'):(f(_0x5ba01e[_0x48fca9]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5ba01e[_0x48fca9]['unwatcher'](),_0x288b2c=_0x288b2c['concat'](pe(_0x3c7b77['serverSyncTree_'],_0x5ba01e[_0x48fca9]['currentWriteId'],!0x0)),_0x5ba01e[_0x48fca9]['onComplete']&&_0x4f327b['push'](_0x5ba01e[_0x48fca9]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1cd275===-0x1?fs(_0x111cc4,void 0x0):_0x5ba01e['length']=_0x1cd275+0x1,V(_0x3c7b77['eventQueue_'],Gt(_0x111cc4),_0x288b2c);for(let _0x4d13f4=0x0;_0x4d13f4<_0x4f327b['length'];_0x4d13f4++)lt(_0x4f327b[_0x4d13f4]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5907d0){let _0x209b81='';const _0x471b23=_0x5907d0['split']('/');for(let _0x466f0a=0x0;_0x466f0a<_0x471b23['length'];_0x466f0a++)if(_0x471b23[_0x466f0a]['length']>0x0){let _0x1698e9=_0x471b23[_0x466f0a];try{_0x1698e9=decodeURIComponent(_0x1698e9['replace'](/\+/g,'\x20'));}catch{}_0x209b81+='/'+_0x1698e9;}return _0x209b81;}function Nd(_0x4d4978){const _0x2bc898={};_0x4d4978['charAt'](0x0)==='?'&&(_0x4d4978=_0x4d4978['substring'](0x1));for(const _0x19f894 of _0x4d4978['split']('&')){if(_0x19f894['length']===0x0)continue;const _0x3c20cd=_0x19f894['split']('=');_0x3c20cd['length']===0x2?_0x2bc898[decodeURIComponent(_0x3c20cd[0x0])]=decodeURIComponent(_0x3c20cd[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x19f894+'\x27\x20in\x20query\x20\x27'+_0x4d4978+'\x27');}return _0x2bc898;}const gr=function(_0x43d801,_0x5be3b4){const _0x232923=Pd(_0x43d801),_0x5ba471=_0x232923['namespace'];_0x232923['domain']==='firebase.com'&&oe(_0x232923['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5ba471||_0x5ba471==='undefined')&&_0x232923['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x232923['secure']||Bl();const _0x43b538=_0x232923['scheme']==='ws'||_0x232923['scheme']==='wss';return{'repoInfo':new _o(_0x232923['host'],_0x232923['secure'],_0x5ba471,_0x43b538,_0x5be3b4,'',_0x5ba471!==_0x232923['subdomain']),'path':new C(_0x232923['pathString'])};},Pd=function(_0x9a1a62){let _0x5254e8='',_0x10bb0d='',_0x5ddc5b='',_0x2f40b0='',_0x8ef6c3='',_0x349270=!0x0,_0x410903='https',_0x5a6277=0x1bb;if(typeof _0x9a1a62=='string'){let _0x411aea=_0x9a1a62['indexOf']('//');_0x411aea>=0x0&&(_0x410903=_0x9a1a62['substring'](0x0,_0x411aea-0x1),_0x9a1a62=_0x9a1a62['substring'](_0x411aea+0x2));let _0x21e0c7=_0x9a1a62['indexOf']('/');_0x21e0c7===-0x1&&(_0x21e0c7=_0x9a1a62['length']);let _0x4910c6=_0x9a1a62['indexOf']('?');_0x4910c6===-0x1&&(_0x4910c6=_0x9a1a62['length']),_0x5254e8=_0x9a1a62['substring'](0x0,Math['min'](_0x21e0c7,_0x4910c6)),_0x21e0c7<_0x4910c6&&(_0x2f40b0=kd(_0x9a1a62['substring'](_0x21e0c7,_0x4910c6)));const _0x1e6dfe=Nd(_0x9a1a62['substring'](Math['min'](_0x9a1a62['length'],_0x4910c6)));_0x411aea=_0x5254e8['indexOf'](':'),_0x411aea>=0x0?(_0x349270=_0x410903==='https'||_0x410903==='wss',_0x5a6277=parseInt(_0x5254e8['substring'](_0x411aea+0x1),0xa)):_0x411aea=_0x5254e8['length'];const _0x2067fe=_0x5254e8['slice'](0x0,_0x411aea);if(_0x2067fe['toLowerCase']()==='localhost')_0x10bb0d='localhost';else{if(_0x2067fe['split']('.')['length']<=0x2)_0x10bb0d=_0x2067fe;else{const _0x37871f=_0x5254e8['indexOf']('.');_0x5ddc5b=_0x5254e8['substring'](0x0,_0x37871f)['toLowerCase'](),_0x10bb0d=_0x5254e8['substring'](_0x37871f+0x1),_0x8ef6c3=_0x5ddc5b;}}'ns'in _0x1e6dfe&&(_0x8ef6c3=_0x1e6dfe['ns']);}return{'host':_0x5254e8,'port':_0x5a6277,'domain':_0x10bb0d,'subdomain':_0x5ddc5b,'secure':_0x349270,'scheme':_0x410903,'pathString':_0x2f40b0,'namespace':_0x8ef6c3};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x3ce343=0x0;const _0x1eafeb=[];return function(_0x66c59f){const _0x3e645c=_0x66c59f===_0x3ce343;_0x3ce343=_0x66c59f;let _0x18691f;const _0x46e680=new Array(0x8);for(_0x18691f=0x7;_0x18691f>=0x0;_0x18691f--)_0x46e680[_0x18691f]=mr['charAt'](_0x66c59f%0x40),_0x66c59f=Math['floor'](_0x66c59f/0x40);f(_0x66c59f===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4f98f7=_0x46e680['join']('');if(_0x3e645c){for(_0x18691f=0xb;_0x18691f>=0x0&&_0x1eafeb[_0x18691f]===0x3f;_0x18691f--)_0x1eafeb[_0x18691f]=0x0;_0x1eafeb[_0x18691f]++;}else{for(_0x18691f=0x0;_0x18691f<0xc;_0x18691f++)_0x1eafeb[_0x18691f]=Math['floor'](Math['random']()*0x40);}for(_0x18691f=0x0;_0x18691f<0xc;_0x18691f++)_0x4f98f7+=mr['charAt'](_0x1eafeb[_0x18691f]);return f(_0x4f98f7['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4f98f7;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x42699,_0x461fc0,_0x239aff,_0xa38008){this['eventType']=_0x42699,this['eventRegistration']=_0x461fc0,this['snapshot']=_0x239aff,this['prevName']=_0xa38008;}['getPath'](){const _0x84afcb=this['snapshot']['ref'];return this['eventType']==='value'?_0x84afcb['_path']:_0x84afcb['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x28d6c8,_0x3bb426,_0x362f76){this['eventRegistration']=_0x28d6c8,this['error']=_0x3bb426,this['path']=_0x362f76;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x1a3e7b,_0x2171e5){this['snapshotCallback']=_0x1a3e7b,this['cancelCallback']=_0x2171e5;}['onValue'](_0x2c20ad,_0x459280){this['snapshotCallback']['call'](null,_0x2c20ad,_0x459280);}['onCancel'](_0x37424b){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x37424b);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4b8af8){return this['snapshotCallback']===_0x4b8af8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4b8af8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4b8af8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xba7e1d,_0xe20693,_0x5e2bb4,_0x30f9dd){this['_repo']=_0xba7e1d,this['_path']=_0xe20693,this['_queryParams']=_0x5e2bb4,this['_orderByCalled']=_0x30f9dd;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x54844b=nr(this['_queryParams']),_0xcdb26c=Bi(_0x54844b);return _0xcdb26c==='{}'?'default':_0xcdb26c;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x2262dd){if(_0x2262dd=k(_0x2262dd),!(_0x2262dd instanceof be))return!0x1;const _0x5d3b4a=this['_repo']===_0x2262dd['_repo'],_0x3ab3ac=qi(this['_path'],_0x2262dd['_path']),_0xf34cbe=this['_queryIdentifier']===_0x2262dd['_queryIdentifier'];return _0x5d3b4a&&_0x3ab3ac&&_0xf34cbe;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x219cce,_0x26ed61){if(_0x219cce['_orderByCalled']===!0x0)throw new Error(_0x26ed61+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x4cade6){let _0x2aa704=null,_0xfbc391=null;if(_0x4cade6['hasStart']()&&(_0x2aa704=_0x4cade6['getIndexStartValue']()),_0x4cade6['hasEnd']()&&(_0xfbc391=_0x4cade6['getIndexEndValue']()),_0x4cade6['getIndex']()===ye){const _0x1d7fa0='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x271be8='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4cade6['hasStart']()){if(_0x4cade6['getIndexStartName']()!==xe)throw new Error(_0x1d7fa0);if(typeof _0x2aa704!='string')throw new Error(_0x271be8);}if(_0x4cade6['hasEnd']()){if(_0x4cade6['getIndexEndName']()!==Ie)throw new Error(_0x1d7fa0);if(typeof _0xfbc391!='string')throw new Error(_0x271be8);}}else{if(_0x4cade6['getIndex']()===R){if(_0x2aa704!=null&&!Cn(_0x2aa704)||_0xfbc391!=null&&!Cn(_0xfbc391))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4cade6['getIndex']()instanceof Ki||_0x4cade6['getIndex']()===Po,'unknown\x20index\x20type.'),_0x2aa704!=null&&typeof _0x2aa704=='object'||_0xfbc391!=null&&typeof _0xfbc391=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2ce217){if(_0x2ce217['hasStart']()&&_0x2ce217['hasEnd']()&&_0x2ce217['hasLimit']()&&!_0x2ce217['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x421a28,_0x80d1a9){super(_0x421a28,_0x80d1a9,new Qi(),!0x1);}get['parent'](){const _0x4a8707=To(this['_path']);return _0x4a8707===null?null:new Z(this['_repo'],_0x4a8707);}get['root'](){let _0x3a78ad=this;for(;_0x3a78ad['parent']!==null;)_0x3a78ad=_0x3a78ad['parent'];return _0x3a78ad;}}class rt{constructor(_0x1cfd4f,_0x424213,_0x1b244a){this['_node']=_0x1cfd4f,this['ref']=_0x424213,this['_index']=_0x1b244a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x356b39){const _0x56c174=new C(_0x356b39),_0x3dcb91=Lt(this['ref'],_0x356b39);return new rt(this['_node']['getChild'](_0x56c174),_0x3dcb91,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2ae57a){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5ef16c,_0x23d846)=>_0x2ae57a(new rt(_0x23d846,Lt(this['ref'],_0x5ef16c),R)));}['hasChild'](_0x6891a3){const _0xdd0376=new C(_0x6891a3);return!this['_node']['getChild'](_0xdd0376)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x523bed,_0x34eb32){return _0x523bed=k(_0x523bed),_0x523bed['_checkNotDeleted']('ref'),_0x34eb32!==void 0x0?Lt(_0x523bed['_root'],_0x34eb32):_0x523bed['_root'];}function Lt(_0x1d711d,_0x2dca8c){return _0x1d711d=k(_0x1d711d),y(_0x1d711d['_path'])===null?ud('child','path',_0x2dca8c):_s('child','path',_0x2dca8c),new Z(_0x1d711d['_repo'],A(_0x1d711d['_path'],_0x2dca8c));}function d_(_0x3592f8,_0x1525a3){_0x3592f8=k(_0x3592f8),gs('push',_0x3592f8['_path']),qt('push',_0x1525a3,_0x3592f8['_path'],!0x0);const _0x27956c=oa(_0x3592f8['_repo']),_0x54c761=Od(_0x27956c),_0x4143f3=Lt(_0x3592f8,_0x54c761),_0x3bbf7a=Lt(_0x3592f8,_0x54c761);let _0x50f961;return _0x1525a3!=null?_0x50f961=Ld(_0x3bbf7a,_0x1525a3)['then'](()=>_0x3bbf7a):_0x50f961=Promise['resolve'](_0x3bbf7a),_0x4143f3['then']=_0x50f961['then']['bind'](_0x50f961),_0x4143f3['catch']=_0x50f961['then']['bind'](_0x50f961,void 0x0),_0x4143f3;}function Ld(_0x5b56dc,_0x4c9ef3){_0x5b56dc=k(_0x5b56dc),gs('set',_0x5b56dc['_path']),qt('set',_0x4c9ef3,_0x5b56dc['_path'],!0x1);const _0x2d81b2=new Ve();return Ed(_0x5b56dc['_repo'],_0x5b56dc['_path'],_0x4c9ef3,null,_0x2d81b2['wrapCallback'](()=>{})),_0x2d81b2['promise'];}function f_(_0x2e07a9,_0x4f5f48){hd('update',_0x4f5f48,_0x2e07a9['_path']);const _0x42dd1e=new Ve();return Id(_0x2e07a9['_repo'],_0x2e07a9['_path'],_0x4f5f48,_0x42dd1e['wrapCallback'](()=>{})),_0x42dd1e['promise'];}function p_(_0x4de7bd){_0x4de7bd=k(_0x4de7bd);const _0x253e0c=new ua(()=>{}),_0x20159f=new qn(_0x253e0c);return vd(_0x4de7bd['_repo'],_0x4de7bd,_0x20159f)['then'](_0x52d2af=>new rt(_0x52d2af,new Z(_0x4de7bd['_repo'],_0x4de7bd['_path']),_0x4de7bd['_queryParams']['getIndex']()));}class qn{constructor(_0x5442cb){this['callbackContext']=_0x5442cb;}['respondsTo'](_0x44308d){return _0x44308d==='value';}['createEvent'](_0x596081,_0x854d84){const _0x8a89f2=_0x854d84['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x596081['snapshotNode'],new Z(_0x854d84['_repo'],_0x854d84['_path']),_0x8a89f2));}['getEventRunner'](_0x2af1f4){return _0x2af1f4['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2af1f4['error']):()=>this['callbackContext']['onValue'](_0x2af1f4['snapshot'],null);}['createCancelEvent'](_0x4c9c48,_0x303925){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x4c9c48,_0x303925):null;}['matches'](_0x29f7fd){return _0x29f7fd instanceof qn?!_0x29f7fd['callbackContext']||!this['callbackContext']?!0x0:_0x29f7fd['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x961958,_0x5369a3,_0x277923,_0x14782a,_0x6cfb40){const _0x11310d=new ua(_0x277923,void 0x0),_0x1c4f07=new qn(_0x11310d);return Cd(_0x961958['_repo'],_0x961958,_0x1c4f07),()=>Td(_0x961958['_repo'],_0x961958,_0x1c4f07);}function Fd(_0x47c7c2,_0x4ae971,_0x6c8a4b,_0x215827){return xd(_0x47c7c2,'value',_0x4ae971);}class dt{}class pa extends dt{constructor(_0x313b8d,_0xe4ba42){super(),this['_value']=_0x313b8d,this['_key']=_0xe4ba42,this['type']='endAt';}['_apply'](_0x11ad75){qt('endAt',this['_value'],_0x11ad75['_path'],!0x0);const _0x39c404=Kh(_0x11ad75['_queryParams'],this['_value'],this['_key']);if(fa(_0x39c404),Gn(_0x39c404),_0x11ad75['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x11ad75['_repo'],_0x11ad75['_path'],_0x39c404,_0x11ad75['_orderByCalled']);}}function __(_0x5b19a9,_0x2fa9b2){return new pa(_0x5b19a9,_0x2fa9b2);}class _a extends dt{constructor(_0x33e18d,_0x46cc50){super(),this['_value']=_0x33e18d,this['_key']=_0x46cc50,this['type']='startAt';}['_apply'](_0x30205b){qt('startAt',this['_value'],_0x30205b['_path'],!0x0);const _0x48805d=jh(_0x30205b['_queryParams'],this['_value'],this['_key']);if(fa(_0x48805d),Gn(_0x48805d),_0x30205b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x30205b['_repo'],_0x30205b['_path'],_0x48805d,_0x30205b['_orderByCalled']);}}function g_(_0x365cd0=null,_0x880d2e){return new _a(_0x365cd0,_0x880d2e);}class Ud extends dt{constructor(_0x2d8ba3){super(),this['_limit']=_0x2d8ba3,this['type']='limitToFirst';}['_apply'](_0x482e85){if(_0x482e85['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x482e85['_repo'],_0x482e85['_path'],zh(_0x482e85['_queryParams'],this['_limit']),_0x482e85['_orderByCalled']);}}function m_(_0x5b1130){if(Math['floor'](_0x5b1130)!==_0x5b1130||_0x5b1130<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x5b1130);}class Wd extends dt{constructor(_0x21ec2e){super(),this['_path']=_0x21ec2e,this['type']='orderByChild';}['_apply'](_0x21b851){da(_0x21b851,'orderByChild');const _0x303d3c=new C(this['_path']);if(v(_0x303d3c))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x145049=new Ki(_0x303d3c),_0x25318e=Do(_0x21b851['_queryParams'],_0x145049);return Gn(_0x25318e),new be(_0x21b851['_repo'],_0x21b851['_path'],_0x25318e,!0x0);}}function y_(_0x360ec6){if(_0x360ec6==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x360ec6==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x360ec6==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x360ec6),new Wd(_0x360ec6);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3d9f92){da(_0x3d9f92,'orderByKey');const _0x3b58ba=Do(_0x3d9f92['_queryParams'],ye);return Gn(_0x3b58ba),new be(_0x3d9f92['_repo'],_0x3d9f92['_path'],_0x3b58ba,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x34adce,_0x37bebd){super(),this['_value']=_0x34adce,this['_key']=_0x37bebd,this['type']='equalTo';}['_apply'](_0x5b8fa0){if(qt('equalTo',this['_value'],_0x5b8fa0['_path'],!0x1),_0x5b8fa0['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5b8fa0['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x5b8fa0));}}function E_(_0x322ade,_0x2ec45b){return new Vd(_0x322ade,_0x2ec45b);}function I_(_0x4f5534,..._0x2b34c9){let _0x585e74=k(_0x4f5534);for(const _0x35b37d of _0x2b34c9)_0x585e74=_0x35b37d['_apply'](_0x585e74);return _0x585e74;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x5ac91a,_0x2ee236,_0x2ce934,_0x30fec5){const _0x59fdaa=_0x2ee236['lastIndexOf'](':'),_0x322fee=_0x2ee236['substring'](0x0,_0x59fdaa),_0x2ff895=Wt(_0x322fee);_0x5ac91a['repoInfo_']=new _o(_0x2ee236,_0x2ff895,_0x5ac91a['repoInfo_']['namespace'],_0x5ac91a['repoInfo_']['webSocketOnly'],_0x5ac91a['repoInfo_']['nodeAdmin'],_0x5ac91a['repoInfo_']['persistenceKey'],_0x5ac91a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2ce934),_0x30fec5&&(_0x5ac91a['authTokenProvider_']=_0x30fec5);}function qd(_0x49ac0d,_0x3dab02,_0x5ae9af,_0x579402,_0x3a0f2f){let _0x22ca0a=_0x579402||_0x49ac0d['options']['databaseURL'];_0x22ca0a===void 0x0&&(_0x49ac0d['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x49ac0d['options']['projectId']),_0x22ca0a=_0x49ac0d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3f6533=gr(_0x22ca0a,_0x3a0f2f),_0x3cda99=_0x3f6533['repoInfo'],_0x3c28ee;typeof process<'u'&&Us&&(_0x3c28ee=Us[Hd]),_0x3c28ee?(_0x22ca0a='http://'+_0x3c28ee+'?ns='+_0x3cda99['namespace'],_0x3f6533=gr(_0x22ca0a,_0x3a0f2f),_0x3cda99=_0x3f6533['repoInfo']):_0x3f6533['repoInfo']['secure'];const _0x389d92=new Jl(_0x49ac0d['name'],_0x49ac0d['options'],_0x3dab02);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3f6533),v(_0x3f6533['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4be092=jd(_0x3cda99,_0x49ac0d,_0x389d92,new Ql(_0x49ac0d,_0x5ae9af));return new Kd(_0x4be092,_0x49ac0d);}function zd(_0x47b21b,_0x52b0b0){const _0x56e13e=ki[_0x52b0b0];(!_0x56e13e||_0x56e13e[_0x47b21b['key']]!==_0x47b21b)&&oe('Database\x20'+_0x52b0b0+'('+_0x47b21b['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x47b21b),delete _0x56e13e[_0x47b21b['key']];}function jd(_0x2e1786,_0x380660,_0x445018,_0x40913a){let _0xc9c552=ki[_0x380660['name']];_0xc9c552||(_0xc9c552={},ki[_0x380660['name']]=_0xc9c552);let _0x2792c4=_0xc9c552[_0x2e1786['toURLString']()];return _0x2792c4&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2792c4=new gd(_0x2e1786,$d,_0x445018,_0x40913a),_0xc9c552[_0x2e1786['toURLString']()]=_0x2792c4,_0x2792c4;}class Kd{constructor(_0x4f97b6,_0x19a3cf){this['_repoInternal']=_0x4f97b6,this['app']=_0x19a3cf,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0xefa8){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0xefa8+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1318bc=Qr(),_0x316666){const _0x1d5f41=Ui(_0x1318bc,'database')['getImmediate']({'identifier':_0x316666});if(!_0x1d5f41['_instanceStarted']){const _0x48ab0d=ac('database');_0x48ab0d&&Yd(_0x1d5f41,..._0x48ab0d);}return _0x1d5f41;}function Yd(_0x144e76,_0x2a0db0,_0x1f4e19,_0x5462e3={}){_0x144e76=k(_0x144e76),_0x144e76['_checkNotDeleted']('useEmulator');const _0x4100ec=_0x2a0db0+':'+_0x1f4e19,_0x86699e=_0x144e76['_repoInternal'];if(_0x144e76['_instanceStarted']){if(_0x4100ec===_0x144e76['_repoInternal']['repoInfo_']['host']&&De(_0x5462e3,_0x86699e['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x41f33e;if(_0x86699e['repoInfo_']['nodeAdmin'])_0x5462e3['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x41f33e=new tn(tn['OWNER']);else{if(_0x5462e3['mockUserToken']){const _0x135ac5=typeof _0x5462e3['mockUserToken']=='string'?_0x5462e3['mockUserToken']:cc(_0x5462e3['mockUserToken'],_0x144e76['app']['options']['projectId']);_0x41f33e=new tn(_0x135ac5);}}Wt(_0x2a0db0)&&jr(_0x2a0db0),Gd(_0x86699e,_0x4100ec,_0x5462e3,_0x41f33e);}function C_(_0x113cee){_0x113cee=k(_0x113cee),_0x113cee['_checkNotDeleted']('goOffline'),aa(_0x113cee['_repo']);}function T_(_0x302ec6){_0x302ec6=k(_0x302ec6),_0x302ec6['_checkNotDeleted']('goOnline'),Sd(_0x302ec6['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x1f126e){Ll(ct),et(new Me('database',(_0x2773b4,{instanceIdentifier:_0x177855})=>{const _0x2c53c1=_0x2773b4['getProvider']('app')['getImmediate'](),_0x4ff8ee=_0x2773b4['getProvider']('auth-internal'),_0x87f61c=_0x2773b4['getProvider']('app-check-internal');return qd(_0x2c53c1,_0x4ff8ee,_0x87f61c,_0x177855);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x1f126e),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x583cc8,_0x5b82f2){this['committed']=_0x583cc8,this['snapshot']=_0x5b82f2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x4ae2dd,_0x3f4766,_0x195d14){if(_0x4ae2dd=k(_0x4ae2dd),gs('Reference.transaction',_0x4ae2dd['_path']),_0x4ae2dd['key']==='.length'||_0x4ae2dd['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4ae2dd['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3c1a9e=!0x0,_0x1dada4=new Ve(),_0x249098=(_0xdae1c,_0x4006b7,_0x4ad724)=>{let _0x4b3cfb=null;_0xdae1c?_0x1dada4['reject'](_0xdae1c):(_0x4b3cfb=new rt(_0x4ad724,new Z(_0x4ae2dd['_repo'],_0x4ae2dd['_path']),R),_0x1dada4['resolve'](new Xd(_0x4006b7,_0x4b3cfb)));},_0x2b1c54=Fd(_0x4ae2dd,()=>{});return bd(_0x4ae2dd['_repo'],_0x4ae2dd['_path'],_0x3f4766,_0x249098,_0x2b1c54,_0x3c1a9e),_0x1dada4['promise'];}ie['prototype']['simpleListen']=function(_0x5d521e,_0x33d294){this['sendRequest']('q',{'p':_0x5d521e},_0x33d294);},ie['prototype']['echo']=function(_0x594b36,_0x49b86a){this['sendRequest']('echo',{'d':_0x594b36},_0x49b86a);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x134390,..._0x51b943){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x134390,..._0x51b943);}function nn(_0x32dd1c,..._0x4a52fe){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x32dd1c,..._0x4a52fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x540cf4,..._0x3b7264){throw Es(_0x540cf4,..._0x3b7264);}function J(_0x100113,..._0x33e8e){return Es(_0x100113,..._0x33e8e);}function ya(_0x5ba1d7,_0x5f5602,_0x2cd64e){const _0x2cade4={...Zd(),[_0x5f5602]:_0x2cd64e};return new Ut('auth','Firebase',_0x2cade4)['create'](_0x5f5602,{'appName':_0x5ba1d7['name']});}function se(_0x45c787){return ya(_0x45c787,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x14bdcb,..._0x3d9435){if(typeof _0x14bdcb!='string'){const _0x26bcbb=_0x3d9435[0x0],_0x20ce84=[..._0x3d9435['slice'](0x1)];return _0x20ce84[0x0]&&(_0x20ce84[0x0]['appName']=_0x14bdcb['name']),_0x14bdcb['_errorFactory']['create'](_0x26bcbb,..._0x20ce84);}return ma['create'](_0x14bdcb,..._0x3d9435);}function m(_0x41b615,_0x350f88,..._0x423d37){if(!_0x41b615)throw Es(_0x350f88,..._0x423d37);}function te(_0x1aa836){const _0x1105c4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1aa836;throw nn(_0x1105c4),new Error(_0x1105c4);}function ae(_0x444108,_0x54f691){_0x444108||te(_0x54f691);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x4dfea0;return typeof self<'u'&&((_0x4dfea0=self['location'])==null?void 0x0:_0x4dfea0['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4d1737;return typeof self<'u'&&((_0x4d1737=self['location'])==null?void 0x0:_0x4d1737['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x34646e=navigator;return _0x34646e['languages']&&_0x34646e['languages'][0x0]||_0x34646e['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x4fcaa5,_0x33a474){this['shortDelay']=_0x4fcaa5,this['longDelay']=_0x33a474,ae(_0x33a474>_0x4fcaa5,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x584501,_0x9b56d1){ae(_0x584501['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5a3d11}=_0x584501['emulator'];return _0x9b56d1?''+_0x5a3d11+(_0x9b56d1['startsWith']('/')?_0x9b56d1['slice'](0x1):_0x9b56d1):_0x5a3d11;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x58b9fe,_0x58eefb,_0x55f475){this['fetchImpl']=_0x58b9fe,_0x58eefb&&(this['headersImpl']=_0x58eefb),_0x55f475&&(this['responseImpl']=_0x55f475);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x2dc337,_0x4be4a7){return _0x2dc337['tenantId']&&!_0x4be4a7['tenantId']?{..._0x4be4a7,'tenantId':_0x2dc337['tenantId']}:_0x4be4a7;}async function Ae(_0x1f57c4,_0x40889e,_0x859233,_0x521c75,_0x4ccc3d={}){return Ea(_0x1f57c4,_0x4ccc3d,async()=>{let _0x48da5c={},_0x228d53={};_0x521c75&&(_0x40889e==='GET'?_0x228d53=_0x521c75:_0x48da5c={'body':JSON['stringify'](_0x521c75)});const _0x40148f=at({..._0x228d53,'key':_0x1f57c4['config']['apiKey']})['slice'](0x1),_0x5bfbc1=await _0x1f57c4['_getAdditionalHeaders']();_0x5bfbc1['Content-Type']='application/json',_0x1f57c4['languageCode']&&(_0x5bfbc1['X-Firebase-Locale']=_0x1f57c4['languageCode']);const _0x3f1dd9={'method':_0x40889e,'headers':_0x5bfbc1,..._0x48da5c};return lc()||(_0x3f1dd9['referrerPolicy']='strict-origin-when-cross-origin'),_0x1f57c4['emulatorConfig']&&Wt(_0x1f57c4['emulatorConfig']['host'])&&(_0x3f1dd9['credentials']='include'),va['fetch']()(await Ia(_0x1f57c4,_0x1f57c4['config']['apiHost'],_0x859233,_0x40148f),_0x3f1dd9);});}async function Ea(_0x1492e1,_0x5cb487,_0x42335d){_0x1492e1['_canInitEmulator']=!0x1;const _0x215cc8={...rf,..._0x5cb487};try{const _0x39f359=new lf(_0x1492e1),_0x5363d9=await Promise['race']([_0x42335d(),_0x39f359['promise']]);_0x39f359['clearNetworkTimeout']();const _0x4c9ce4=await _0x5363d9['json']();if('needConfirmation'in _0x4c9ce4)throw en(_0x1492e1,'account-exists-with-different-credential',_0x4c9ce4);if(_0x5363d9['ok']&&!('errorMessage'in _0x4c9ce4))return _0x4c9ce4;{const _0x4fb1a1=_0x5363d9['ok']?_0x4c9ce4['errorMessage']:_0x4c9ce4['error']['message'],[_0x8d2a44,_0x1e4a3d]=_0x4fb1a1['split']('\x20:\x20');if(_0x8d2a44==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1492e1,'credential-already-in-use',_0x4c9ce4);if(_0x8d2a44==='EMAIL_EXISTS')throw en(_0x1492e1,'email-already-in-use',_0x4c9ce4);if(_0x8d2a44==='USER_DISABLED')throw en(_0x1492e1,'user-disabled',_0x4c9ce4);const _0x288986=_0x215cc8[_0x8d2a44]||_0x8d2a44['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1e4a3d)throw ya(_0x1492e1,_0x288986,_0x1e4a3d);K(_0x1492e1,_0x288986);}}catch(_0x523ae4){if(_0x523ae4 instanceof Se)throw _0x523ae4;K(_0x1492e1,'network-request-failed',{'message':String(_0x523ae4)});}}async function Yt(_0x1d5535,_0x5bc219,_0xa80c4d,_0xe06621,_0xd7b759={}){const _0x41ef05=await Ae(_0x1d5535,_0x5bc219,_0xa80c4d,_0xe06621,_0xd7b759);return'mfaPendingCredential'in _0x41ef05&&K(_0x1d5535,'multi-factor-auth-required',{'_serverResponse':_0x41ef05}),_0x41ef05;}async function Ia(_0x31f3b1,_0x10e931,_0x5d9dfe,_0x5d0d51){const _0x2ce7cb=''+_0x10e931+_0x5d9dfe+'?'+_0x5d0d51,_0x4f7a0d=_0x31f3b1,_0x44ba8f=_0x4f7a0d['config']['emulator']?Is(_0x31f3b1['config'],_0x2ce7cb):_0x31f3b1['config']['apiScheme']+'://'+_0x2ce7cb;return of['includes'](_0x5d9dfe)&&(await _0x4f7a0d['_persistenceManagerAvailable'],_0x4f7a0d['_getPersistenceType']()==='COOKIE')?_0x4f7a0d['_getPersistence']()['_getFinalTarget'](_0x44ba8f)['toString']():_0x44ba8f;}function cf(_0x4c32ac){switch(_0x4c32ac){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1cf169){this['auth']=_0x1cf169,this['timer']=null,this['promise']=new Promise((_0x270eed,_0x69797e)=>{this['timer']=setTimeout(()=>_0x69797e(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x52f628,_0x4faf2e,_0x17c958){const _0x282642={'appName':_0x52f628['name']};_0x17c958['email']&&(_0x282642['email']=_0x17c958['email']),_0x17c958['phoneNumber']&&(_0x282642['phoneNumber']=_0x17c958['phoneNumber']);const _0x52a4a9=J(_0x52f628,_0x4faf2e,_0x282642);return _0x52a4a9['customData']['_tokenResponse']=_0x17c958,_0x52a4a9;}function vr(_0x1ee55a){return _0x1ee55a!==void 0x0&&_0x1ee55a['enterprise']!==void 0x0;}class hf{constructor(_0x3cbea4){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3cbea4['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3cbea4['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3cbea4['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4c78f7){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x18ffb7 of this['recaptchaEnforcementState'])if(_0x18ffb7['provider']&&_0x18ffb7['provider']===_0x4c78f7)return cf(_0x18ffb7['enforcementState']);return null;}['isProviderEnabled'](_0x1e42c2){return this['getProviderEnforcementState'](_0x1e42c2)==='ENFORCE'||this['getProviderEnforcementState'](_0x1e42c2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x15f6f9,_0x298952){return Ae(_0x15f6f9,'GET','/v2/recaptchaConfig',Re(_0x15f6f9,_0x298952));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x120f06,_0x3d2b79){return Ae(_0x120f06,'POST','/v1/accounts:delete',_0x3d2b79);}async function Sn(_0x3e881d,_0x51c7be){return Ae(_0x3e881d,'POST','/v1/accounts:lookup',_0x51c7be);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x2961f3){if(_0x2961f3)try{const _0x22ffb3=new Date(Number(_0x2961f3));if(!isNaN(_0x22ffb3['getTime']()))return _0x22ffb3['toUTCString']();}catch{}}async function ff(_0x708fc8,_0x2f1968=!0x1){const _0x2569fd=k(_0x708fc8),_0x5cf6f9=await _0x2569fd['getIdToken'](_0x2f1968),_0x1431a2=ws(_0x5cf6f9);m(_0x1431a2&&_0x1431a2['exp']&&_0x1431a2['auth_time']&&_0x1431a2['iat'],_0x2569fd['auth'],'internal-error');const _0x3c322c=typeof _0x1431a2['firebase']=='object'?_0x1431a2['firebase']:void 0x0,_0x4a2726=_0x3c322c==null?void 0x0:_0x3c322c['sign_in_provider'];return{'claims':_0x1431a2,'token':_0x5cf6f9,'authTime':St(ci(_0x1431a2['auth_time'])),'issuedAtTime':St(ci(_0x1431a2['iat'])),'expirationTime':St(ci(_0x1431a2['exp'])),'signInProvider':_0x4a2726||null,'signInSecondFactor':(_0x3c322c==null?void 0x0:_0x3c322c['sign_in_second_factor'])||null};}function ci(_0x4c4673){return Number(_0x4c4673)*0x3e8;}function ws(_0x3b3721){const [_0x409a6f,_0x3cae63,_0x175616]=_0x3b3721['split']('.');if(_0x409a6f===void 0x0||_0x3cae63===void 0x0||_0x175616===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1d36b8=cn(_0x3cae63);return _0x1d36b8?JSON['parse'](_0x1d36b8):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x36f5df){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x36f5df==null?void 0x0:_0x36f5df['toString']()),null;}}function Er(_0x505055){const _0x1fee07=ws(_0x505055);return m(_0x1fee07,'internal-error'),m(typeof _0x1fee07['exp']<'u','internal-error'),m(typeof _0x1fee07['iat']<'u','internal-error'),Number(_0x1fee07['exp'])-Number(_0x1fee07['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x2696fb,_0x2f1772,_0x56994b=!0x1){if(_0x56994b)return _0x2f1772;try{return await _0x2f1772;}catch(_0x492d30){throw _0x492d30 instanceof Se&&pf(_0x492d30)&&_0x2696fb['auth']['currentUser']===_0x2696fb&&await _0x2696fb['auth']['signOut'](),_0x492d30;}}function pf({code:_0x5886b6}){return _0x5886b6==='auth/user-disabled'||_0x5886b6==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x34c1d9){this['user']=_0x34c1d9,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1376e8){if(_0x1376e8){const _0x369b06=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x369b06;}else{this['errorBackoff']=0x7530;const _0x5c9076=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5c9076);}}['schedule'](_0x29e34f=!0x1){if(!this['isRunning'])return;const _0x33be70=this['getInterval'](_0x29e34f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x33be70);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xfde36a){(_0xfde36a==null?void 0x0:_0xfde36a['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x298cc8,_0x2d761e){this['createdAt']=_0x298cc8,this['lastLoginAt']=_0x2d761e,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x276c79){this['createdAt']=_0x276c79['createdAt'],this['lastLoginAt']=_0x276c79['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x14c240){var _0x23b311;const _0x335c76=_0x14c240['auth'],_0x2f08ab=await _0x14c240['getIdToken'](),_0x2196a2=await xt(_0x14c240,Sn(_0x335c76,{'idToken':_0x2f08ab}));m(_0x2196a2==null?void 0x0:_0x2196a2['users']['length'],_0x335c76,'internal-error');const _0x278ef3=_0x2196a2['users'][0x0];_0x14c240['_notifyReloadListener'](_0x278ef3);const _0x36d758=(_0x23b311=_0x278ef3['providerUserInfo'])!=null&&_0x23b311['length']?wa(_0x278ef3['providerUserInfo']):[],_0x4171c3=mf(_0x14c240['providerData'],_0x36d758),_0x41f9f2=_0x14c240['isAnonymous'],_0x3aa9b4=!(_0x14c240['email']&&_0x278ef3['passwordHash'])&&!(_0x4171c3!=null&&_0x4171c3['length']),_0x865c4c=_0x41f9f2?_0x3aa9b4:!0x1,_0x50319a={'uid':_0x278ef3['localId'],'displayName':_0x278ef3['displayName']||null,'photoURL':_0x278ef3['photoUrl']||null,'email':_0x278ef3['email']||null,'emailVerified':_0x278ef3['emailVerified']||!0x1,'phoneNumber':_0x278ef3['phoneNumber']||null,'tenantId':_0x278ef3['tenantId']||null,'providerData':_0x4171c3,'metadata':new Pi(_0x278ef3['createdAt'],_0x278ef3['lastLoginAt']),'isAnonymous':_0x865c4c};Object['assign'](_0x14c240,_0x50319a);}async function gf(_0x242f24){const _0x5e2281=k(_0x242f24);await bn(_0x5e2281),await _0x5e2281['auth']['_persistUserIfCurrent'](_0x5e2281),_0x5e2281['auth']['_notifyListenersIfCurrent'](_0x5e2281);}function mf(_0x303307,_0x1c3da4){return[..._0x303307['filter'](_0x9d76a4=>!_0x1c3da4['some'](_0x20aabf=>_0x20aabf['providerId']===_0x9d76a4['providerId'])),..._0x1c3da4];}function wa(_0x12c805){return _0x12c805['map'](({providerId:_0x651cb2,..._0x1b1bc0})=>({'providerId':_0x651cb2,'uid':_0x1b1bc0['rawId']||'','displayName':_0x1b1bc0['displayName']||null,'email':_0x1b1bc0['email']||null,'phoneNumber':_0x1b1bc0['phoneNumber']||null,'photoURL':_0x1b1bc0['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x17d26e,_0x2b2890){const _0x2b81d1=await Ea(_0x17d26e,{},async()=>{const _0x18225f=at({'grant_type':'refresh_token','refresh_token':_0x2b2890})['slice'](0x1),{tokenApiHost:_0x503a53,apiKey:_0x492b96}=_0x17d26e['config'],_0x29d527=await Ia(_0x17d26e,_0x503a53,'/v1/token','key='+_0x492b96),_0x1202b9=await _0x17d26e['_getAdditionalHeaders']();_0x1202b9['Content-Type']='application/x-www-form-urlencoded';const _0x1f93fa={'method':'POST','headers':_0x1202b9,'body':_0x18225f};return _0x17d26e['emulatorConfig']&&Wt(_0x17d26e['emulatorConfig']['host'])&&(_0x1f93fa['credentials']='include'),va['fetch']()(_0x29d527,_0x1f93fa);});return{'accessToken':_0x2b81d1['access_token'],'expiresIn':_0x2b81d1['expires_in'],'refreshToken':_0x2b81d1['refresh_token']};}async function vf(_0x5dd221,_0x556ff1){return Ae(_0x5dd221,'POST','/v2/accounts:revokeToken',Re(_0x5dd221,_0x556ff1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x58be26){m(_0x58be26['idToken'],'internal-error'),m(typeof _0x58be26['idToken']<'u','internal-error'),m(typeof _0x58be26['refreshToken']<'u','internal-error');const _0x303c75='expiresIn'in _0x58be26&&typeof _0x58be26['expiresIn']<'u'?Number(_0x58be26['expiresIn']):Er(_0x58be26['idToken']);this['updateTokensAndExpiration'](_0x58be26['idToken'],_0x58be26['refreshToken'],_0x303c75);}['updateFromIdToken'](_0x516a8e){m(_0x516a8e['length']!==0x0,'internal-error');const _0x30d056=Er(_0x516a8e);this['updateTokensAndExpiration'](_0x516a8e,null,_0x30d056);}async['getToken'](_0x458380,_0x48d052=!0x1){return!_0x48d052&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x458380,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x458380,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4ae8f1,_0x5d1924){const {accessToken:_0x559328,refreshToken:_0x38425c,expiresIn:_0x111053}=await yf(_0x4ae8f1,_0x5d1924);this['updateTokensAndExpiration'](_0x559328,_0x38425c,Number(_0x111053));}['updateTokensAndExpiration'](_0x49244e,_0xe95479,_0x17f7b0){this['refreshToken']=_0xe95479||null,this['accessToken']=_0x49244e||null,this['expirationTime']=Date['now']()+_0x17f7b0*0x3e8;}static['fromJSON'](_0x32f91a,_0x4e09d8){const {refreshToken:_0x20779f,accessToken:_0x1d7df9,expirationTime:_0x5d7fb7}=_0x4e09d8,_0x32e1e7=new Je();return _0x20779f&&(m(typeof _0x20779f=='string','internal-error',{'appName':_0x32f91a}),_0x32e1e7['refreshToken']=_0x20779f),_0x1d7df9&&(m(typeof _0x1d7df9=='string','internal-error',{'appName':_0x32f91a}),_0x32e1e7['accessToken']=_0x1d7df9),_0x5d7fb7&&(m(typeof _0x5d7fb7=='number','internal-error',{'appName':_0x32f91a}),_0x32e1e7['expirationTime']=_0x5d7fb7),_0x32e1e7;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x17571b){this['accessToken']=_0x17571b['accessToken'],this['refreshToken']=_0x17571b['refreshToken'],this['expirationTime']=_0x17571b['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x4930bd,_0x4a4f0e){m(typeof _0x4930bd=='string'||typeof _0x4930bd>'u','internal-error',{'appName':_0x4a4f0e});}class z{constructor({uid:_0x1ea912,auth:_0x1fe5b9,stsTokenManager:_0x58744c,..._0x4589af}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1ea912,this['auth']=_0x1fe5b9,this['stsTokenManager']=_0x58744c,this['accessToken']=_0x58744c['accessToken'],this['displayName']=_0x4589af['displayName']||null,this['email']=_0x4589af['email']||null,this['emailVerified']=_0x4589af['emailVerified']||!0x1,this['phoneNumber']=_0x4589af['phoneNumber']||null,this['photoURL']=_0x4589af['photoURL']||null,this['isAnonymous']=_0x4589af['isAnonymous']||!0x1,this['tenantId']=_0x4589af['tenantId']||null,this['providerData']=_0x4589af['providerData']?[..._0x4589af['providerData']]:[],this['metadata']=new Pi(_0x4589af['createdAt']||void 0x0,_0x4589af['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3c356f){const _0x51d993=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x3c356f));return m(_0x51d993,this['auth'],'internal-error'),this['accessToken']!==_0x51d993&&(this['accessToken']=_0x51d993,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x51d993;}['getIdTokenResult'](_0x3d1611){return ff(this,_0x3d1611);}['reload'](){return gf(this);}['_assign'](_0x5776cb){this!==_0x5776cb&&(m(this['uid']===_0x5776cb['uid'],this['auth'],'internal-error'),this['displayName']=_0x5776cb['displayName'],this['photoURL']=_0x5776cb['photoURL'],this['email']=_0x5776cb['email'],this['emailVerified']=_0x5776cb['emailVerified'],this['phoneNumber']=_0x5776cb['phoneNumber'],this['isAnonymous']=_0x5776cb['isAnonymous'],this['tenantId']=_0x5776cb['tenantId'],this['providerData']=_0x5776cb['providerData']['map'](_0x46fb4b=>({..._0x46fb4b})),this['metadata']['_copy'](_0x5776cb['metadata']),this['stsTokenManager']['_assign'](_0x5776cb['stsTokenManager']));}['_clone'](_0xa747c){const _0x7366f8=new z({...this,'auth':_0xa747c,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x7366f8['metadata']['_copy'](this['metadata']),_0x7366f8;}['_onReload'](_0x5991cc){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5991cc,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x6f59b9){this['reloadListener']?this['reloadListener'](_0x6f59b9):this['reloadUserInfo']=_0x6f59b9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5d59de,_0x5cdca7=!0x1){let _0x160fa7=!0x1;_0x5d59de['idToken']&&_0x5d59de['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5d59de),_0x160fa7=!0x0),_0x5cdca7&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x160fa7&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2ee3ab=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2ee3ab})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4c7369=>({..._0x4c7369})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5ac11a,_0x1d1a92){const _0x290a7c=_0x1d1a92['displayName']??void 0x0,_0x12f5f1=_0x1d1a92['email']??void 0x0,_0x366c88=_0x1d1a92['phoneNumber']??void 0x0,_0x23eca7=_0x1d1a92['photoURL']??void 0x0,_0x465af0=_0x1d1a92['tenantId']??void 0x0,_0x249d66=_0x1d1a92['_redirectEventId']??void 0x0,_0x2229b8=_0x1d1a92['createdAt']??void 0x0,_0x5d5dc4=_0x1d1a92['lastLoginAt']??void 0x0,{uid:_0x290e1b,emailVerified:_0x52eb51,isAnonymous:_0x2c66a5,providerData:_0x3004d5,stsTokenManager:_0x415d6b}=_0x1d1a92;m(_0x290e1b&&_0x415d6b,_0x5ac11a,'internal-error');const _0x51aab1=Je['fromJSON'](this['name'],_0x415d6b);m(typeof _0x290e1b=='string',_0x5ac11a,'internal-error'),ce(_0x290a7c,_0x5ac11a['name']),ce(_0x12f5f1,_0x5ac11a['name']),m(typeof _0x52eb51=='boolean',_0x5ac11a,'internal-error'),m(typeof _0x2c66a5=='boolean',_0x5ac11a,'internal-error'),ce(_0x366c88,_0x5ac11a['name']),ce(_0x23eca7,_0x5ac11a['name']),ce(_0x465af0,_0x5ac11a['name']),ce(_0x249d66,_0x5ac11a['name']),ce(_0x2229b8,_0x5ac11a['name']),ce(_0x5d5dc4,_0x5ac11a['name']);const _0x37f6d6=new z({'uid':_0x290e1b,'auth':_0x5ac11a,'email':_0x12f5f1,'emailVerified':_0x52eb51,'displayName':_0x290a7c,'isAnonymous':_0x2c66a5,'photoURL':_0x23eca7,'phoneNumber':_0x366c88,'tenantId':_0x465af0,'stsTokenManager':_0x51aab1,'createdAt':_0x2229b8,'lastLoginAt':_0x5d5dc4});return _0x3004d5&&Array['isArray'](_0x3004d5)&&(_0x37f6d6['providerData']=_0x3004d5['map'](_0x453170=>({..._0x453170}))),_0x249d66&&(_0x37f6d6['_redirectEventId']=_0x249d66),_0x37f6d6;}static async['_fromIdTokenResponse'](_0x315e59,_0x51b627,_0x17cfe5=!0x1){const _0x2632fa=new Je();_0x2632fa['updateFromServerResponse'](_0x51b627);const _0x54356f=new z({'uid':_0x51b627['localId'],'auth':_0x315e59,'stsTokenManager':_0x2632fa,'isAnonymous':_0x17cfe5});return await bn(_0x54356f),_0x54356f;}static async['_fromGetAccountInfoResponse'](_0x21e483,_0x6e5b23,_0x48e21b){const _0x11ccbe=_0x6e5b23['users'][0x0];m(_0x11ccbe['localId']!==void 0x0,'internal-error');const _0x252351=_0x11ccbe['providerUserInfo']!==void 0x0?wa(_0x11ccbe['providerUserInfo']):[],_0xb52c00=!(_0x11ccbe['email']&&_0x11ccbe['passwordHash'])&&!(_0x252351!=null&&_0x252351['length']),_0x5328b2=new Je();_0x5328b2['updateFromIdToken'](_0x48e21b);const _0x345f1b=new z({'uid':_0x11ccbe['localId'],'auth':_0x21e483,'stsTokenManager':_0x5328b2,'isAnonymous':_0xb52c00}),_0xd2e3f={'uid':_0x11ccbe['localId'],'displayName':_0x11ccbe['displayName']||null,'photoURL':_0x11ccbe['photoUrl']||null,'email':_0x11ccbe['email']||null,'emailVerified':_0x11ccbe['emailVerified']||!0x1,'phoneNumber':_0x11ccbe['phoneNumber']||null,'tenantId':_0x11ccbe['tenantId']||null,'providerData':_0x252351,'metadata':new Pi(_0x11ccbe['createdAt'],_0x11ccbe['lastLoginAt']),'isAnonymous':!(_0x11ccbe['email']&&_0x11ccbe['passwordHash'])&&!(_0x252351!=null&&_0x252351['length'])};return Object['assign'](_0x345f1b,_0xd2e3f),_0x345f1b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x40f551){ae(_0x40f551 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1efb39=Ir['get'](_0x40f551);return _0x1efb39?(ae(_0x1efb39 instanceof _0x40f551,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1efb39):(_0x1efb39=new _0x40f551(),Ir['set'](_0x40f551,_0x1efb39),_0x1efb39);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2ce83e,_0x2e11df){this['storage'][_0x2ce83e]=_0x2e11df;}async['_get'](_0x4ad5f0){const _0x1aa35d=this['storage'][_0x4ad5f0];return _0x1aa35d===void 0x0?null:_0x1aa35d;}async['_remove'](_0x38a435){delete this['storage'][_0x38a435];}['_addListener'](_0x1044b7,_0x4fb106){}['_removeListener'](_0x29c8a1,_0x1134fd){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0xd27fff,_0x2b45ff,_0x39c0d5){return'firebase:'+_0xd27fff+':'+_0x2b45ff+':'+_0x39c0d5;}class Xe{constructor(_0x1f6160,_0x526600,_0x5754e9){this['persistence']=_0x1f6160,this['auth']=_0x526600,this['userKey']=_0x5754e9;const {config:_0x3c2d87,name:_0x8a77b6}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3c2d87['apiKey'],_0x8a77b6),this['fullPersistenceKey']=sn('persistence',_0x3c2d87['apiKey'],_0x8a77b6),this['boundEventHandler']=_0x526600['_onStorageEvent']['bind'](_0x526600),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5ba812){return this['persistence']['_set'](this['fullUserKey'],_0x5ba812['toJSON']());}async['getCurrentUser'](){const _0x458d5e=await this['persistence']['_get'](this['fullUserKey']);if(!_0x458d5e)return null;if(typeof _0x458d5e=='string'){const _0x329902=await Sn(this['auth'],{'idToken':_0x458d5e})['catch'](()=>{});return _0x329902?z['_fromGetAccountInfoResponse'](this['auth'],_0x329902,_0x458d5e):null;}return z['_fromJSON'](this['auth'],_0x458d5e);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3a4f52){if(this['persistence']===_0x3a4f52)return;const _0x346f53=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3a4f52,_0x346f53)return this['setCurrentUser'](_0x346f53);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4405d5,_0x25fac3,_0x184163='authUser'){if(!_0x25fac3['length'])return new Xe(ne(wr),_0x4405d5,_0x184163);const _0x56db2f=(await Promise['all'](_0x25fac3['map'](async _0x7c36eb=>{if(await _0x7c36eb['_isAvailable']())return _0x7c36eb;})))['filter'](_0xf19186=>_0xf19186);let _0x2cde1d=_0x56db2f[0x0]||ne(wr);const _0x11722a=sn(_0x184163,_0x4405d5['config']['apiKey'],_0x4405d5['name']);let _0x5b65a9=null;for(const _0x530940 of _0x25fac3)try{const _0x4ede4b=await _0x530940['_get'](_0x11722a);if(_0x4ede4b){let _0x474529;if(typeof _0x4ede4b=='string'){const _0x1010b9=await Sn(_0x4405d5,{'idToken':_0x4ede4b})['catch'](()=>{});if(!_0x1010b9)break;_0x474529=await z['_fromGetAccountInfoResponse'](_0x4405d5,_0x1010b9,_0x4ede4b);}else _0x474529=z['_fromJSON'](_0x4405d5,_0x4ede4b);_0x530940!==_0x2cde1d&&(_0x5b65a9=_0x474529),_0x2cde1d=_0x530940;break;}}catch{}const _0x4c8fe0=_0x56db2f['filter'](_0xf51ef1=>_0xf51ef1['_shouldAllowMigration']);return!_0x2cde1d['_shouldAllowMigration']||!_0x4c8fe0['length']?new Xe(_0x2cde1d,_0x4405d5,_0x184163):(_0x2cde1d=_0x4c8fe0[0x0],_0x5b65a9&&await _0x2cde1d['_set'](_0x11722a,_0x5b65a9['toJSON']()),await Promise['all'](_0x25fac3['map'](async _0x325610=>{if(_0x325610!==_0x2cde1d)try{await _0x325610['_remove'](_0x11722a);}catch{}})),new Xe(_0x2cde1d,_0x4405d5,_0x184163));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x54988f){const _0x1c6405=_0x54988f['toLowerCase']();if(_0x1c6405['includes']('opera/')||_0x1c6405['includes']('opr/')||_0x1c6405['includes']('opios/'))return'Opera';if(Ra(_0x1c6405))return'IEMobile';if(_0x1c6405['includes']('msie')||_0x1c6405['includes']('trident/'))return'IE';if(_0x1c6405['includes']('edge/'))return'Edge';if(Ta(_0x1c6405))return'Firefox';if(_0x1c6405['includes']('silk/'))return'Silk';if(ka(_0x1c6405))return'Blackberry';if(Na(_0x1c6405))return'Webos';if(Sa(_0x1c6405))return'Safari';if((_0x1c6405['includes']('chrome/')||ba(_0x1c6405))&&!_0x1c6405['includes']('edge/'))return'Chrome';if(Aa(_0x1c6405))return'Android';{const _0x28784b=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x379c15=_0x54988f['match'](_0x28784b);if((_0x379c15==null?void 0x0:_0x379c15['length'])===0x2)return _0x379c15[0x1];}return'Other';}function Ta(_0x5d50b3=W()){return/firefox\//i['test'](_0x5d50b3);}function Sa(_0x59076f=W()){const _0x33166a=_0x59076f['toLowerCase']();return _0x33166a['includes']('safari/')&&!_0x33166a['includes']('chrome/')&&!_0x33166a['includes']('crios/')&&!_0x33166a['includes']('android');}function ba(_0x2a9361=W()){return/crios\//i['test'](_0x2a9361);}function Ra(_0x21a4a2=W()){return/iemobile/i['test'](_0x21a4a2);}function Aa(_0x3e909a=W()){return/android/i['test'](_0x3e909a);}function ka(_0x3ed4d8=W()){return/blackberry/i['test'](_0x3ed4d8);}function Na(_0x4b7ed5=W()){return/webos/i['test'](_0x4b7ed5);}function Cs(_0x37a59d=W()){return/iphone|ipad|ipod/i['test'](_0x37a59d)||/macintosh/i['test'](_0x37a59d)&&/mobile/i['test'](_0x37a59d);}function Ef(_0x2db418=W()){var _0x23539f;return Cs(_0x2db418)&&!!((_0x23539f=window['navigator'])!=null&&_0x23539f['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x3648a6=W()){return Cs(_0x3648a6)||Aa(_0x3648a6)||Na(_0x3648a6)||ka(_0x3648a6)||/windows phone/i['test'](_0x3648a6)||Ra(_0x3648a6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x348b25,_0x5c1835=[]){let _0x9c6cd9;switch(_0x348b25){case'Browser':_0x9c6cd9=Cr(W());break;case'Worker':_0x9c6cd9=Cr(W())+'-'+_0x348b25;break;default:_0x9c6cd9=_0x348b25;}const _0x2bd76b=_0x5c1835['length']?_0x5c1835['join'](','):'FirebaseCore-web';return _0x9c6cd9+'/JsCore/'+ct+'/'+_0x2bd76b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4e21f8){this['auth']=_0x4e21f8,this['queue']=[];}['pushCallback'](_0x44d553,_0x2e5b48){const _0x5505e4=_0x1a2fd3=>new Promise((_0x509945,_0xaaccf7)=>{try{const _0x2c6825=_0x44d553(_0x1a2fd3);_0x509945(_0x2c6825);}catch(_0x386e3d){_0xaaccf7(_0x386e3d);}});_0x5505e4['onAbort']=_0x2e5b48,this['queue']['push'](_0x5505e4);const _0x2f64bf=this['queue']['length']-0x1;return()=>{this['queue'][_0x2f64bf]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4bd4f5){if(this['auth']['currentUser']===_0x4bd4f5)return;const _0x59857d=[];try{for(const _0x5d31cf of this['queue'])await _0x5d31cf(_0x4bd4f5),_0x5d31cf['onAbort']&&_0x59857d['push'](_0x5d31cf['onAbort']);}catch(_0xfa39f8){_0x59857d['reverse']();for(const _0x2cfb2c of _0x59857d)try{_0x2cfb2c();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xfa39f8==null?void 0x0:_0xfa39f8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0xa36acd,_0xaace26={}){return Ae(_0xa36acd,'GET','/v2/passwordPolicy',Re(_0xa36acd,_0xaace26));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3b6173){var _0x1573b2;const _0x3d9918=_0x3b6173['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3d9918['minPasswordLength']??Tf,_0x3d9918['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3d9918['maxPasswordLength']),_0x3d9918['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3d9918['containsLowercaseCharacter']),_0x3d9918['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3d9918['containsUppercaseCharacter']),_0x3d9918['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3d9918['containsNumericCharacter']),_0x3d9918['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3d9918['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3b6173['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1573b2=_0x3b6173['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1573b2['join'](''))??'',this['forceUpgradeOnSignin']=_0x3b6173['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3b6173['schemaVersion'];}['validatePassword'](_0x477159){const _0x48e5c1={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x477159,_0x48e5c1),this['validatePasswordCharacterOptions'](_0x477159,_0x48e5c1),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['meetsMinPasswordLength']??!0x0),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['meetsMaxPasswordLength']??!0x0),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['containsLowercaseLetter']??!0x0),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['containsUppercaseLetter']??!0x0),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['containsNumericCharacter']??!0x0),_0x48e5c1['isValid']&&(_0x48e5c1['isValid']=_0x48e5c1['containsNonAlphanumericCharacter']??!0x0),_0x48e5c1;}['validatePasswordLengthOptions'](_0x4ab259,_0x351dbd){const _0x1c61d4=this['customStrengthOptions']['minPasswordLength'],_0x299579=this['customStrengthOptions']['maxPasswordLength'];_0x1c61d4&&(_0x351dbd['meetsMinPasswordLength']=_0x4ab259['length']>=_0x1c61d4),_0x299579&&(_0x351dbd['meetsMaxPasswordLength']=_0x4ab259['length']<=_0x299579);}['validatePasswordCharacterOptions'](_0x46105f,_0x38a703){this['updatePasswordCharacterOptionsStatuses'](_0x38a703,!0x1,!0x1,!0x1,!0x1);let _0x2c9d34;for(let _0x399019=0x0;_0x399019<_0x46105f['length'];_0x399019++)_0x2c9d34=_0x46105f['charAt'](_0x399019),this['updatePasswordCharacterOptionsStatuses'](_0x38a703,_0x2c9d34>='a'&&_0x2c9d34<='z',_0x2c9d34>='A'&&_0x2c9d34<='Z',_0x2c9d34>='0'&&_0x2c9d34<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x2c9d34));}['updatePasswordCharacterOptionsStatuses'](_0x383b0c,_0x181e26,_0x4520ca,_0x142460,_0x1e84eb){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x383b0c['containsLowercaseLetter']||(_0x383b0c['containsLowercaseLetter']=_0x181e26)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x383b0c['containsUppercaseLetter']||(_0x383b0c['containsUppercaseLetter']=_0x4520ca)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x383b0c['containsNumericCharacter']||(_0x383b0c['containsNumericCharacter']=_0x142460)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x383b0c['containsNonAlphanumericCharacter']||(_0x383b0c['containsNonAlphanumericCharacter']=_0x1e84eb));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x31c775,_0x6aa94,_0x263a1b,_0x1fbd78){this['app']=_0x31c775,this['heartbeatServiceProvider']=_0x6aa94,this['appCheckServiceProvider']=_0x263a1b,this['config']=_0x1fbd78,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x31c775['name'],this['clientVersion']=_0x1fbd78['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x184ee1=>this['_resolvePersistenceManagerAvailable']=_0x184ee1);}['_initializeWithPersistence'](_0x210c94,_0x19cd4d){return _0x19cd4d&&(this['_popupRedirectResolver']=ne(_0x19cd4d)),this['_initializationPromise']=this['queue'](async()=>{var _0x5a10c8,_0x444ddc,_0x170de6;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x210c94),(_0x5a10c8=this['_resolvePersistenceManagerAvailable'])==null||_0x5a10c8['call'](this),!this['_deleted'])){if((_0x444ddc=this['_popupRedirectResolver'])!=null&&_0x444ddc['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x19cd4d),this['lastNotifiedUid']=((_0x170de6=this['currentUser'])==null?void 0x0:_0x170de6['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x567e03=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x567e03)){if(this['currentUser']&&_0x567e03&&this['currentUser']['uid']===_0x567e03['uid']){this['_currentUser']['_assign'](_0x567e03),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x567e03,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5104c0){try{const _0x2d5712=await Sn(this,{'idToken':_0x5104c0}),_0x59c499=await z['_fromGetAccountInfoResponse'](this,_0x2d5712,_0x5104c0);await this['directlySetCurrentUser'](_0x59c499);}catch(_0x24cf76){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x24cf76),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x50e7a5){var _0x44b014;if(H(this['app'])){const _0x5e454a=this['app']['settings']['authIdToken'];return _0x5e454a?new Promise(_0x10f95f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5e454a)['then'](_0x10f95f,_0x10f95f));}):this['directlySetCurrentUser'](null);}const _0x1cc0b8=await this['assertedPersistence']['getCurrentUser']();let _0x42ef6a=_0x1cc0b8,_0x56758d=!0x1;if(_0x50e7a5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2ac2d5=(_0x44b014=this['redirectUser'])==null?void 0x0:_0x44b014['_redirectEventId'],_0x2a5081=_0x42ef6a==null?void 0x0:_0x42ef6a['_redirectEventId'],_0xa652dd=await this['tryRedirectSignIn'](_0x50e7a5);(!_0x2ac2d5||_0x2ac2d5===_0x2a5081)&&(_0xa652dd!=null&&_0xa652dd['user'])&&(_0x42ef6a=_0xa652dd['user'],_0x56758d=!0x0);}if(!_0x42ef6a)return this['directlySetCurrentUser'](null);if(!_0x42ef6a['_redirectEventId']){if(_0x56758d)try{await this['beforeStateQueue']['runMiddleware'](_0x42ef6a);}catch(_0x1431b2){_0x42ef6a=_0x1cc0b8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1431b2));}return _0x42ef6a?this['reloadAndSetCurrentUserOrClear'](_0x42ef6a):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x42ef6a['_redirectEventId']?this['directlySetCurrentUser'](_0x42ef6a):this['reloadAndSetCurrentUserOrClear'](_0x42ef6a);}async['tryRedirectSignIn'](_0x2577e0){let _0x3e765e=null;try{_0x3e765e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2577e0,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3e765e;}async['reloadAndSetCurrentUserOrClear'](_0x5873a0){try{await bn(_0x5873a0);}catch(_0xf6f17b){if((_0xf6f17b==null?void 0x0:_0xf6f17b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5873a0);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x47133c){if(H(this['app']))return Promise['reject'](se(this));const _0x1f9f1c=_0x47133c?k(_0x47133c):null;return _0x1f9f1c&&m(_0x1f9f1c['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1f9f1c&&_0x1f9f1c['_clone'](this));}async['_updateCurrentUser'](_0x4f2f5b,_0x247da7=!0x1){if(!this['_deleted'])return _0x4f2f5b&&m(this['tenantId']===_0x4f2f5b['tenantId'],this,'tenant-id-mismatch'),_0x247da7||await this['beforeStateQueue']['runMiddleware'](_0x4f2f5b),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x4f2f5b),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4ecf5d){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x4ecf5d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2901c1){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5727ca=this['_getPasswordPolicyInternal']();return _0x5727ca['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5727ca['validatePassword'](_0x2901c1);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3d4e3c=await Cf(this),_0x4aeb0c=new Sf(_0x3d4e3c);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4aeb0c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4aeb0c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x238e47){this['_errorFactory']=new Ut('auth','Firebase',_0x238e47());}['onAuthStateChanged'](_0x1b6395,_0x59aa4d,_0x5402b1){return this['registerStateListener'](this['authStateSubscription'],_0x1b6395,_0x59aa4d,_0x5402b1);}['beforeAuthStateChanged'](_0x301152,_0x1b312a){return this['beforeStateQueue']['pushCallback'](_0x301152,_0x1b312a);}['onIdTokenChanged'](_0x1527ef,_0x2650c0,_0x7be6c0){return this['registerStateListener'](this['idTokenSubscription'],_0x1527ef,_0x2650c0,_0x7be6c0);}['authStateReady'](){return new Promise((_0x10edbc,_0x5e3f70)=>{if(this['currentUser'])_0x10edbc();else{const _0x25c888=this['onAuthStateChanged'](()=>{_0x25c888(),_0x10edbc();},_0x5e3f70);}});}async['revokeAccessToken'](_0x5d5546){if(this['currentUser']){const _0x1536d0=await this['currentUser']['getIdToken'](),_0x536145={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5d5546,'idToken':_0x1536d0};this['tenantId']!=null&&(_0x536145['tenantId']=this['tenantId']),await vf(this,_0x536145);}}['toJSON'](){var _0xaf5955;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xaf5955=this['_currentUser'])==null?void 0x0:_0xaf5955['toJSON']()};}async['_setRedirectUser'](_0x50e8dd,_0xb4f32a){const _0x372ef2=await this['getOrInitRedirectPersistenceManager'](_0xb4f32a);return _0x50e8dd===null?_0x372ef2['removeCurrentUser']():_0x372ef2['setCurrentUser'](_0x50e8dd);}async['getOrInitRedirectPersistenceManager'](_0x3eaf49){if(!this['redirectPersistenceManager']){const _0x255a78=_0x3eaf49&&ne(_0x3eaf49)||this['_popupRedirectResolver'];m(_0x255a78,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x255a78['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2f9b96){var _0x62b30f,_0x2d711e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x62b30f=this['_currentUser'])==null?void 0x0:_0x62b30f['_redirectEventId'])===_0x2f9b96?this['_currentUser']:((_0x2d711e=this['redirectUser'])==null?void 0x0:_0x2d711e['_redirectEventId'])===_0x2f9b96?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xd18655){if(_0xd18655===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xd18655));}['_notifyListenersIfCurrent'](_0x296989){_0x296989===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x7e5688;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x59585a=((_0x7e5688=this['currentUser'])==null?void 0x0:_0x7e5688['uid'])??null;this['lastNotifiedUid']!==_0x59585a&&(this['lastNotifiedUid']=_0x59585a,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x22fb7e,_0x2e0c3d,_0x3aa328,_0xc9e7de){if(this['_deleted'])return()=>{};const _0x3b20d1=typeof _0x2e0c3d=='function'?_0x2e0c3d:_0x2e0c3d['next']['bind'](_0x2e0c3d);let _0x9b9afd=!0x1;const _0x2b3f86=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2b3f86,this,'internal-error'),_0x2b3f86['then'](()=>{_0x9b9afd||_0x3b20d1(this['currentUser']);}),typeof _0x2e0c3d=='function'){const _0x87165d=_0x22fb7e['addObserver'](_0x2e0c3d,_0x3aa328,_0xc9e7de);return()=>{_0x9b9afd=!0x0,_0x87165d();};}else{const _0x352fa9=_0x22fb7e['addObserver'](_0x2e0c3d);return()=>{_0x9b9afd=!0x0,_0x352fa9();};}}async['directlySetCurrentUser'](_0x55753a){this['currentUser']&&this['currentUser']!==_0x55753a&&this['_currentUser']['_stopProactiveRefresh'](),_0x55753a&&this['isProactiveRefreshEnabled']&&_0x55753a['_startProactiveRefresh'](),this['currentUser']=_0x55753a,_0x55753a?await this['assertedPersistence']['setCurrentUser'](_0x55753a):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4ee77e){return this['operations']=this['operations']['then'](_0x4ee77e,_0x4ee77e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x46829c){!_0x46829c||this['frameworks']['includes'](_0x46829c)||(this['frameworks']['push'](_0x46829c),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x36d0ea;const _0x2fb299={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2fb299['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2ea4e5=await((_0x36d0ea=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x36d0ea['getHeartbeatsHeader']());_0x2ea4e5&&(_0x2fb299['X-Firebase-Client']=_0x2ea4e5);const _0xfecef=await this['_getAppCheckToken']();return _0xfecef&&(_0x2fb299['X-Firebase-AppCheck']=_0xfecef),_0x2fb299;}async['_getAppCheckToken'](){var _0x12186c;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3cc8ca=await((_0x12186c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x12186c['getToken']());return _0x3cc8ca!=null&&_0x3cc8ca['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3cc8ca['error']),_0x3cc8ca==null?void 0x0:_0x3cc8ca['token'];}}function qe(_0x51a653){return k(_0x51a653);}class Tr{constructor(_0x307782){this['auth']=_0x307782,this['observer']=null,this['addObserver']=Ic(_0x3c82c5=>this['observer']=_0x3c82c5);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2a1b31){zn=_0x2a1b31;}function Da(_0x56d22a){return zn['loadJS'](_0x56d22a);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1f5c29){return'__'+_0x1f5c29+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x32d15c){_0x32d15c();}['execute'](_0x10d97f,_0x4ab827){return Promise['resolve']('token');}['render'](_0xda1974,_0x159bb5){return'';}}class Of{['ready'](_0x4ca2f4){_0x4ca2f4();}['execute'](_0x5e973a,_0x3ecdfd){return Promise['resolve']('token');}['render'](_0x3ed26c,_0x4ef38a){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3a4f20){this['type']=Df,this['auth']=qe(_0x3a4f20);}async['verify'](_0x49655a='verify',_0xe19475=!0x1){async function _0x3553aa(_0x1e3a20){if(!_0xe19475){if(_0x1e3a20['tenantId']==null&&_0x1e3a20['_agentRecaptchaConfig']!=null)return _0x1e3a20['_agentRecaptchaConfig']['siteKey'];if(_0x1e3a20['tenantId']!=null&&_0x1e3a20['_tenantRecaptchaConfigs'][_0x1e3a20['tenantId']]!==void 0x0)return _0x1e3a20['_tenantRecaptchaConfigs'][_0x1e3a20['tenantId']]['siteKey'];}return new Promise(async(_0x4b8993,_0x13595d)=>{uf(_0x1e3a20,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x248244=>{if(_0x248244['recaptchaKey']===void 0x0)_0x13595d(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x327758=new hf(_0x248244);return _0x1e3a20['tenantId']==null?_0x1e3a20['_agentRecaptchaConfig']=_0x327758:_0x1e3a20['_tenantRecaptchaConfigs'][_0x1e3a20['tenantId']]=_0x327758,_0x4b8993(_0x327758['siteKey']);}})['catch'](_0x1a58de=>{_0x13595d(_0x1a58de);});});}function _0x5297f6(_0x2dfbb9,_0x17f195,_0x4d0a23){const _0xf5b5=window['grecaptcha'];vr(_0xf5b5)?_0xf5b5['enterprise']['ready'](()=>{_0xf5b5['enterprise']['execute'](_0x2dfbb9,{'action':_0x49655a})['then'](_0x3a10d1=>{_0x17f195(_0x3a10d1);})['catch'](()=>{_0x17f195(Ma);});}):_0x4d0a23(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x98187c,_0x53298e)=>{_0x3553aa(this['auth'])['then'](async _0x44d745=>{if(!_0xe19475&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5297f6(_0x44d745,_0x98187c,_0x53298e);else{if(typeof window>'u'){_0x53298e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x302b47=Af();_0x302b47['length']!==0x0&&(_0x302b47+=_0x44d745+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x3f9f17;(_0x3f9f17=le['scriptInjectionDeferred'])==null||_0x3f9f17['resolve']();},Da(_0x302b47)['then'](()=>{var _0x5f583e;return(_0x5f583e=le['scriptInjectionDeferred'])==null?void 0x0:_0x5f583e['promise'];})['then'](()=>{_0x5297f6(_0x44d745,_0x98187c,_0x53298e);})['catch'](_0x5bf558=>{_0x53298e(_0x5bf558);});}})['catch'](_0x5236f4=>{_0x53298e(_0x5236f4);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1265e3,_0x155f30,_0x134814,_0xae034a=!0x1,_0xe05fe7=!0x1){const _0x50bc47=new le(_0x1265e3);let _0x1dabd4;if(_0xe05fe7)_0x1dabd4=Ma;else try{_0x1dabd4=await _0x50bc47['verify'](_0x134814);}catch{_0x1dabd4=await _0x50bc47['verify'](_0x134814,!0x0);}const _0x164316={..._0x155f30};if(_0x134814==='mfaSmsEnrollment'||_0x134814==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x164316){const _0x16bd55=_0x164316['phoneEnrollmentInfo']['phoneNumber'],_0x3ffe8a=_0x164316['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x164316,{'phoneEnrollmentInfo':{'phoneNumber':_0x16bd55,'recaptchaToken':_0x3ffe8a,'captchaResponse':_0x1dabd4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x164316){const _0x5731fa=_0x164316['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x164316,{'phoneSignInInfo':{'recaptchaToken':_0x5731fa,'captchaResponse':_0x1dabd4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x164316;}return _0xae034a?Object['assign'](_0x164316,{'captchaResp':_0x1dabd4}):Object['assign'](_0x164316,{'captchaResponse':_0x1dabd4}),Object['assign'](_0x164316,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x164316,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x164316;}async function Oi(_0x203e7b,_0x38479d,_0x2c0367,_0x28522f,_0x5dd396){var _0x1d82a6;if((_0x1d82a6=_0x203e7b['_getRecaptchaConfig']())!=null&&_0x1d82a6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x36e9a8=await br(_0x203e7b,_0x38479d,_0x2c0367,_0x2c0367==='getOobCode');return _0x28522f(_0x203e7b,_0x36e9a8);}else return _0x28522f(_0x203e7b,_0x38479d)['catch'](async _0x2ddd3a=>{if(_0x2ddd3a['code']==='auth/missing-recaptcha-token'){console['log'](_0x2c0367+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4a36d8=await br(_0x203e7b,_0x38479d,_0x2c0367,_0x2c0367==='getOobCode');return _0x28522f(_0x203e7b,_0x4a36d8);}else return Promise['reject'](_0x2ddd3a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x350f1a,_0x557440){const _0x3cab55=Ui(_0x350f1a,'auth');if(_0x3cab55['isInitialized']()){const _0x176cad=_0x3cab55['getImmediate'](),_0x2bf5dd=_0x3cab55['getOptions']();if(De(_0x2bf5dd,_0x557440??{}))return _0x176cad;K(_0x176cad,'already-initialized');}return _0x3cab55['initialize']({'options':_0x557440});}function Lf(_0x25fb0e,_0x580451){const _0x395d39=(_0x580451==null?void 0x0:_0x580451['persistence'])||[],_0x4b6b19=(Array['isArray'](_0x395d39)?_0x395d39:[_0x395d39])['map'](ne);_0x580451!=null&&_0x580451['errorMap']&&_0x25fb0e['_updateErrorMap'](_0x580451['errorMap']),_0x25fb0e['_initializeWithPersistence'](_0x4b6b19,_0x580451==null?void 0x0:_0x580451['popupRedirectResolver']);}function xf(_0x4ad7a1,_0x1861e3,_0x2a1b00){const _0x21fd40=qe(_0x4ad7a1);m(/^https?:\/\//['test'](_0x1861e3),_0x21fd40,'invalid-emulator-scheme');const _0x176bf0=!0x1,_0x55d9ac=La(_0x1861e3),{host:_0x48ddb7,port:_0x233c13}=Ff(_0x1861e3),_0x444e35=_0x233c13===null?'':':'+_0x233c13,_0x516b07={'url':_0x55d9ac+'//'+_0x48ddb7+_0x444e35+'/'},_0x5767a5=Object['freeze']({'host':_0x48ddb7,'port':_0x233c13,'protocol':_0x55d9ac['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x176bf0})});if(!_0x21fd40['_canInitEmulator']){m(_0x21fd40['config']['emulator']&&_0x21fd40['emulatorConfig'],_0x21fd40,'emulator-config-failed'),m(De(_0x516b07,_0x21fd40['config']['emulator'])&&De(_0x5767a5,_0x21fd40['emulatorConfig']),_0x21fd40,'emulator-config-failed');return;}_0x21fd40['config']['emulator']=_0x516b07,_0x21fd40['emulatorConfig']=_0x5767a5,_0x21fd40['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x48ddb7)?jr(_0x55d9ac+'//'+_0x48ddb7+_0x444e35):Uf();}function La(_0x91bed5){const _0x283e1e=_0x91bed5['indexOf'](':');return _0x283e1e<0x0?'':_0x91bed5['substr'](0x0,_0x283e1e+0x1);}function Ff(_0x4a877c){const _0xd7f3dd=La(_0x4a877c),_0x2ace76=/(\/\/)?([^?#/]+)/['exec'](_0x4a877c['substr'](_0xd7f3dd['length']));if(!_0x2ace76)return{'host':'','port':null};const _0x314b9c=_0x2ace76[0x2]['split']('@')['pop']()||'',_0x260273=/^(\[[^\]]+\])(:|$)/['exec'](_0x314b9c);if(_0x260273){const _0x59b127=_0x260273[0x1];return{'host':_0x59b127,'port':Rr(_0x314b9c['substr'](_0x59b127['length']+0x1))};}else{const [_0x130ceb,_0x2323ea]=_0x314b9c['split'](':');return{'host':_0x130ceb,'port':Rr(_0x2323ea)};}}function Rr(_0x115711){if(!_0x115711)return null;const _0x2fda50=Number(_0x115711);return isNaN(_0x2fda50)?null:_0x2fda50;}function Uf(){function _0x1919f3(){const _0x107afd=document['createElement']('p'),_0x1ad350=_0x107afd['style'];_0x107afd['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1ad350['position']='fixed',_0x1ad350['width']='100%',_0x1ad350['backgroundColor']='#ffffff',_0x1ad350['border']='.1em\x20solid\x20#000000',_0x1ad350['color']='#b50000',_0x1ad350['bottom']='0px',_0x1ad350['left']='0px',_0x1ad350['margin']='0px',_0x1ad350['zIndex']='10000',_0x1ad350['textAlign']='center',_0x107afd['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x107afd);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1919f3):_0x1919f3());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x306b14,_0x6654fe){this['providerId']=_0x306b14,this['signInMethod']=_0x6654fe;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x10d15e){return te('not\x20implemented');}['_linkToIdToken'](_0x11019b,_0x3148d9){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1683fd){return te('not\x20implemented');}}async function Wf(_0x460402,_0x22d68e){return Ae(_0x460402,'POST','/v1/accounts:signUp',_0x22d68e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x11c146,_0x3df7dd){return Yt(_0x11c146,'POST','/v1/accounts:signInWithPassword',Re(_0x11c146,_0x3df7dd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4ed671,_0x2fda62){return Yt(_0x4ed671,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4ed671,_0x2fda62));}async function Hf(_0x53f7cf,_0x18c813){return Yt(_0x53f7cf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x53f7cf,_0x18c813));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x472de9,_0xb5abb2,_0x5129bf,_0xad48b2=null){super('password',_0x5129bf),this['_email']=_0x472de9,this['_password']=_0xb5abb2,this['_tenantId']=_0xad48b2;}static['_fromEmailAndPassword'](_0x346014,_0x24719a){return new Ft(_0x346014,_0x24719a,'password');}static['_fromEmailAndCode'](_0xbca94a,_0x3372df,_0x5d2c62=null){return new Ft(_0xbca94a,_0x3372df,'emailLink',_0x5d2c62);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x569266){const _0x520494=typeof _0x569266=='string'?JSON['parse'](_0x569266):_0x569266;if(_0x520494!=null&&_0x520494['email']&&(_0x520494!=null&&_0x520494['password'])){if(_0x520494['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x520494['email'],_0x520494['password']);if(_0x520494['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x520494['email'],_0x520494['password'],_0x520494['tenantId']);}return null;}async['_getIdTokenResponse'](_0xa93d8e){switch(this['signInMethod']){case'password':const _0x29b707={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0xa93d8e,_0x29b707,'signInWithPassword',Bf);case'emailLink':return Vf(_0xa93d8e,{'email':this['_email'],'oobCode':this['_password']});default:K(_0xa93d8e,'internal-error');}}async['_linkToIdToken'](_0x9a1353,_0x1d2239){switch(this['signInMethod']){case'password':const _0x21e9f5={'idToken':_0x1d2239,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x9a1353,_0x21e9f5,'signUpPassword',Wf);case'emailLink':return Hf(_0x9a1353,{'idToken':_0x1d2239,'email':this['_email'],'oobCode':this['_password']});default:K(_0x9a1353,'internal-error');}}['_getReauthenticationResolver'](_0x36ea23){return this['_getIdTokenResponse'](_0x36ea23);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x1160ff,_0xe0e3a6){return Yt(_0x1160ff,'POST','/v1/accounts:signInWithIdp',Re(_0x1160ff,_0xe0e3a6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2a8771){const _0x2296f1=new We(_0x2a8771['providerId'],_0x2a8771['signInMethod']);return _0x2a8771['idToken']||_0x2a8771['accessToken']?(_0x2a8771['idToken']&&(_0x2296f1['idToken']=_0x2a8771['idToken']),_0x2a8771['accessToken']&&(_0x2296f1['accessToken']=_0x2a8771['accessToken']),_0x2a8771['nonce']&&!_0x2a8771['pendingToken']&&(_0x2296f1['nonce']=_0x2a8771['nonce']),_0x2a8771['pendingToken']&&(_0x2296f1['pendingToken']=_0x2a8771['pendingToken'])):_0x2a8771['oauthToken']&&_0x2a8771['oauthTokenSecret']?(_0x2296f1['accessToken']=_0x2a8771['oauthToken'],_0x2296f1['secret']=_0x2a8771['oauthTokenSecret']):K('argument-error'),_0x2296f1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x59dddd){const _0x10217f=typeof _0x59dddd=='string'?JSON['parse'](_0x59dddd):_0x59dddd,{providerId:_0x58ea29,signInMethod:_0xac6e56,..._0xf79eef}=_0x10217f;if(!_0x58ea29||!_0xac6e56)return null;const _0x4d20a4=new We(_0x58ea29,_0xac6e56);return _0x4d20a4['idToken']=_0xf79eef['idToken']||void 0x0,_0x4d20a4['accessToken']=_0xf79eef['accessToken']||void 0x0,_0x4d20a4['secret']=_0xf79eef['secret'],_0x4d20a4['nonce']=_0xf79eef['nonce'],_0x4d20a4['pendingToken']=_0xf79eef['pendingToken']||null,_0x4d20a4;}['_getIdTokenResponse'](_0x49f1b4){const _0x11c7ae=this['buildRequest']();return Ze(_0x49f1b4,_0x11c7ae);}['_linkToIdToken'](_0xdad49b,_0x16af4f){const _0x5077a5=this['buildRequest']();return _0x5077a5['idToken']=_0x16af4f,Ze(_0xdad49b,_0x5077a5);}['_getReauthenticationResolver'](_0x284b24){const _0x5d0259=this['buildRequest']();return _0x5d0259['autoCreate']=!0x1,Ze(_0x284b24,_0x5d0259);}['buildRequest'](){const _0x57c62d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x57c62d['pendingToken']=this['pendingToken'];else{const _0x4889b9={};this['idToken']&&(_0x4889b9['id_token']=this['idToken']),this['accessToken']&&(_0x4889b9['access_token']=this['accessToken']),this['secret']&&(_0x4889b9['oauth_token_secret']=this['secret']),_0x4889b9['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4889b9['nonce']=this['nonce']),_0x57c62d['postBody']=at(_0x4889b9);}return _0x57c62d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x26f751){switch(_0x26f751){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x491303){const _0x274d00=yt(vt(_0x491303))['link'],_0x5eff3c=_0x274d00?yt(vt(_0x274d00))['deep_link_id']:null,_0x5924fd=yt(vt(_0x491303))['deep_link_id'];return(_0x5924fd?yt(vt(_0x5924fd))['link']:null)||_0x5924fd||_0x5eff3c||_0x274d00||_0x491303;}class Ss{constructor(_0xd3e097){const _0x89d8ed=yt(vt(_0xd3e097)),_0x939517=_0x89d8ed['apiKey']??null,_0x1e5851=_0x89d8ed['oobCode']??null,_0x120a6f=Gf(_0x89d8ed['mode']??null);m(_0x939517&&_0x1e5851&&_0x120a6f,'argument-error'),this['apiKey']=_0x939517,this['operation']=_0x120a6f,this['code']=_0x1e5851,this['continueUrl']=_0x89d8ed['continueUrl']??null,this['languageCode']=_0x89d8ed['lang']??null,this['tenantId']=_0x89d8ed['tenantId']??null;}static['parseLink'](_0x1d3b59){const _0x12336d=qf(_0x1d3b59);try{return new Ss(_0x12336d);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x336670,_0x22ada3){return Ft['_fromEmailAndPassword'](_0x336670,_0x22ada3);}static['credentialWithLink'](_0x22a18b,_0x36fe47){const _0x2fb0c7=Ss['parseLink'](_0x36fe47);return m(_0x2fb0c7,'argument-error'),Ft['_fromEmailAndCode'](_0x22a18b,_0x2fb0c7['code'],_0x2fb0c7['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x307021){this['providerId']=_0x307021,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x476915){this['defaultLanguageCode']=_0x476915;}['setCustomParameters'](_0x2d7acc){return this['customParameters']=_0x2d7acc,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1d3cdd){return this['scopes']['includes'](_0x1d3cdd)||this['scopes']['push'](_0x1d3cdd),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x2abf3e){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2abf3e});}static['credentialFromResult'](_0x284a82){return he['credentialFromTaggedObject'](_0x284a82);}static['credentialFromError'](_0x1628c5){return he['credentialFromTaggedObject'](_0x1628c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd35e2b}){if(!_0xd35e2b||!('oauthAccessToken'in _0xd35e2b)||!_0xd35e2b['oauthAccessToken'])return null;try{return he['credential'](_0xd35e2b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3cd712,_0x11a38e){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3cd712,'accessToken':_0x11a38e});}static['credentialFromResult'](_0x266f03){return ue['credentialFromTaggedObject'](_0x266f03);}static['credentialFromError'](_0x10aff1){return ue['credentialFromTaggedObject'](_0x10aff1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x20c31b}){if(!_0x20c31b)return null;const {oauthIdToken:_0x12b70e,oauthAccessToken:_0x2f0831}=_0x20c31b;if(!_0x12b70e&&!_0x2f0831)return null;try{return ue['credential'](_0x12b70e,_0x2f0831);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x4e2256){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4e2256});}static['credentialFromResult'](_0x446fe0){return de['credentialFromTaggedObject'](_0x446fe0);}static['credentialFromError'](_0x54079f){return de['credentialFromTaggedObject'](_0x54079f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2a86c3}){if(!_0x2a86c3||!('oauthAccessToken'in _0x2a86c3)||!_0x2a86c3['oauthAccessToken'])return null;try{return de['credential'](_0x2a86c3['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x3bf419,_0x50ad04){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3bf419,'oauthTokenSecret':_0x50ad04});}static['credentialFromResult'](_0x1af553){return fe['credentialFromTaggedObject'](_0x1af553);}static['credentialFromError'](_0x5df256){return fe['credentialFromTaggedObject'](_0x5df256['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1672d9}){if(!_0x1672d9)return null;const {oauthAccessToken:_0x56dfd6,oauthTokenSecret:_0x95e88b}=_0x1672d9;if(!_0x56dfd6||!_0x95e88b)return null;try{return fe['credential'](_0x56dfd6,_0x95e88b);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x2f86dc,_0x11ede8){return Yt(_0x2f86dc,'POST','/v1/accounts:signUp',Re(_0x2f86dc,_0x11ede8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x281574){this['user']=_0x281574['user'],this['providerId']=_0x281574['providerId'],this['_tokenResponse']=_0x281574['_tokenResponse'],this['operationType']=_0x281574['operationType'];}static async['_fromIdTokenResponse'](_0x4b82e1,_0x47ddf1,_0x4078ae,_0x5eb6ea=!0x1){const _0x4549a=await z['_fromIdTokenResponse'](_0x4b82e1,_0x4078ae,_0x5eb6ea),_0x2dffcf=Ar(_0x4078ae);return new Be({'user':_0x4549a,'providerId':_0x2dffcf,'_tokenResponse':_0x4078ae,'operationType':_0x47ddf1});}static async['_forOperation'](_0x4e030e,_0x464634,_0x11b18b){await _0x4e030e['_updateTokensIfNecessary'](_0x11b18b,!0x0);const _0x2fe5a0=Ar(_0x11b18b);return new Be({'user':_0x4e030e,'providerId':_0x2fe5a0,'_tokenResponse':_0x11b18b,'operationType':_0x464634});}}function Ar(_0x190726){return _0x190726['providerId']?_0x190726['providerId']:'phoneNumber'in _0x190726?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x354676,_0x41545f,_0x510ea6,_0x363dfe){super(_0x41545f['code'],_0x41545f['message']),this['operationType']=_0x510ea6,this['user']=_0x363dfe,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x354676['name'],'tenantId':_0x354676['tenantId']??void 0x0,'_serverResponse':_0x41545f['customData']['_serverResponse'],'operationType':_0x510ea6};}static['_fromErrorAndOperation'](_0x4cfda8,_0x7b2e51,_0x3b46de,_0x45b8ad){return new Rn(_0x4cfda8,_0x7b2e51,_0x3b46de,_0x45b8ad);}}function Fa(_0x4f0cd4,_0x53d1ba,_0x10ee44,_0x395458){return(_0x53d1ba==='reauthenticate'?_0x10ee44['_getReauthenticationResolver'](_0x4f0cd4):_0x10ee44['_getIdTokenResponse'](_0x4f0cd4))['catch'](_0xcf06c0=>{throw _0xcf06c0['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x4f0cd4,_0xcf06c0,_0x53d1ba,_0x395458):_0xcf06c0;});}async function jf(_0x21365a,_0x1d0091,_0x3c7cf4=!0x1){const _0x346e9=await xt(_0x21365a,_0x1d0091['_linkToIdToken'](_0x21365a['auth'],await _0x21365a['getIdToken']()),_0x3c7cf4);return Be['_forOperation'](_0x21365a,'link',_0x346e9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x18b444,_0x44340f,_0x336ba9=!0x1){const {auth:_0x67dfc1}=_0x18b444;if(H(_0x67dfc1['app']))return Promise['reject'](se(_0x67dfc1));const _0x55c5bf='reauthenticate';try{const _0x3b631b=await xt(_0x18b444,Fa(_0x67dfc1,_0x55c5bf,_0x44340f,_0x18b444),_0x336ba9);m(_0x3b631b['idToken'],_0x67dfc1,'internal-error');const _0x588e57=ws(_0x3b631b['idToken']);m(_0x588e57,_0x67dfc1,'internal-error');const {sub:_0x97276e}=_0x588e57;return m(_0x18b444['uid']===_0x97276e,_0x67dfc1,'user-mismatch'),Be['_forOperation'](_0x18b444,_0x55c5bf,_0x3b631b);}catch(_0x213b5d){throw(_0x213b5d==null?void 0x0:_0x213b5d['code'])==='auth/user-not-found'&&K(_0x67dfc1,'user-mismatch'),_0x213b5d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4a6e2d,_0x1de019,_0x5cc989=!0x1){if(H(_0x4a6e2d['app']))return Promise['reject'](se(_0x4a6e2d));const _0x4e8c55='signIn',_0x355d06=await Fa(_0x4a6e2d,_0x4e8c55,_0x1de019),_0x7480f8=await Be['_fromIdTokenResponse'](_0x4a6e2d,_0x4e8c55,_0x355d06);return _0x5cc989||await _0x4a6e2d['_updateCurrentUser'](_0x7480f8['user']),_0x7480f8;}async function Yf(_0x581197,_0x15333a){return Ua(qe(_0x581197),_0x15333a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x5c3411){const _0x10aaeb=qe(_0x5c3411);_0x10aaeb['_getPasswordPolicyInternal']()&&await _0x10aaeb['_updatePasswordPolicy']();}async function R_(_0x31750d,_0x2bbb03,_0x1669ab){if(H(_0x31750d['app']))return Promise['reject'](se(_0x31750d));const _0x4af0fc=qe(_0x31750d),_0x4b7b49=await Oi(_0x4af0fc,{'returnSecureToken':!0x0,'email':_0x2bbb03,'password':_0x1669ab,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x1f1adf=>{throw _0x1f1adf['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x31750d),_0x1f1adf;}),_0x33ad04=await Be['_fromIdTokenResponse'](_0x4af0fc,'signIn',_0x4b7b49);return await _0x4af0fc['_updateCurrentUser'](_0x33ad04['user']),_0x33ad04;}function A_(_0x4783d0,_0x44f0e0,_0x55367f){return H(_0x4783d0['app'])?Promise['reject'](se(_0x4783d0)):Yf(k(_0x4783d0),ft['credential'](_0x44f0e0,_0x55367f))['catch'](async _0x2e9661=>{throw _0x2e9661['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4783d0),_0x2e9661;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x300961,_0xea678d){return k(_0x300961)['setPersistence'](_0xea678d);}function Qf(_0x4d9123,_0x50a227,_0x20cae3,_0x1d0ea8){return k(_0x4d9123)['onIdTokenChanged'](_0x50a227,_0x20cae3,_0x1d0ea8);}function Jf(_0x41ac06,_0x1d3d82,_0x4cf9ae){return k(_0x41ac06)['beforeAuthStateChanged'](_0x1d3d82,_0x4cf9ae);}function N_(_0x513be9,_0x28c776,_0x2cffec,_0x5ef2b2){return k(_0x513be9)['onAuthStateChanged'](_0x28c776,_0x2cffec,_0x5ef2b2);}function P_(_0x2096f6){return k(_0x2096f6)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5130e4,_0x490868){this['storageRetriever']=_0x5130e4,this['type']=_0x490868;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x46c308,_0x392da7){return this['storage']['setItem'](_0x46c308,JSON['stringify'](_0x392da7)),Promise['resolve']();}['_get'](_0x161317){const _0x5dfc1a=this['storage']['getItem'](_0x161317);return Promise['resolve'](_0x5dfc1a?JSON['parse'](_0x5dfc1a):null);}['_remove'](_0x2e6e65){return this['storage']['removeItem'](_0x2e6e65),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2e3418,_0x158a51)=>this['onStorageEvent'](_0x2e3418,_0x158a51),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x124280){for(const _0x480d89 of Object['keys'](this['listeners'])){const _0x24df86=this['storage']['getItem'](_0x480d89),_0x176a8d=this['localCache'][_0x480d89];_0x24df86!==_0x176a8d&&_0x124280(_0x480d89,_0x176a8d,_0x24df86);}}['onStorageEvent'](_0x4ba94f,_0x2fa7b6=!0x1){if(!_0x4ba94f['key']){this['forAllChangedKeys']((_0x59b9cf,_0x4abc0a,_0x2494ed)=>{this['notifyListeners'](_0x59b9cf,_0x2494ed);});return;}const _0x19b6a3=_0x4ba94f['key'];_0x2fa7b6?this['detachListener']():this['stopPolling']();const _0x273491=()=>{const _0x493c98=this['storage']['getItem'](_0x19b6a3);!_0x2fa7b6&&this['localCache'][_0x19b6a3]===_0x493c98||this['notifyListeners'](_0x19b6a3,_0x493c98);},_0x13f1d7=this['storage']['getItem'](_0x19b6a3);If()&&_0x13f1d7!==_0x4ba94f['newValue']&&_0x4ba94f['newValue']!==_0x4ba94f['oldValue']?setTimeout(_0x273491,Zf):_0x273491();}['notifyListeners'](_0x7ab5da,_0x531f5c){this['localCache'][_0x7ab5da]=_0x531f5c;const _0x5a73d1=this['listeners'][_0x7ab5da];if(_0x5a73d1){for(const _0x4f1cc5 of Array['from'](_0x5a73d1))_0x4f1cc5(_0x531f5c&&JSON['parse'](_0x531f5c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1baa7f,_0x574936,_0x5f25be)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1baa7f,'oldValue':_0x574936,'newValue':_0x5f25be}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x57ea2a,_0x2f3b71){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x57ea2a]||(this['listeners'][_0x57ea2a]=new Set(),this['localCache'][_0x57ea2a]=this['storage']['getItem'](_0x57ea2a)),this['listeners'][_0x57ea2a]['add'](_0x2f3b71);}['_removeListener'](_0x53da1f,_0x43ef09){this['listeners'][_0x53da1f]&&(this['listeners'][_0x53da1f]['delete'](_0x43ef09),this['listeners'][_0x53da1f]['size']===0x0&&delete this['listeners'][_0x53da1f]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4f8661,_0x5a3c82){await super['_set'](_0x4f8661,_0x5a3c82),this['localCache'][_0x4f8661]=JSON['stringify'](_0x5a3c82);}async['_get'](_0x4e526f){const _0x3ffc46=await super['_get'](_0x4e526f);return this['localCache'][_0x4e526f]=JSON['stringify'](_0x3ffc46),_0x3ffc46;}async['_remove'](_0x2cbf34){await super['_remove'](_0x2cbf34),delete this['localCache'][_0x2cbf34];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x38a382,_0x347c1e){}['_removeListener'](_0x4a43f5,_0x1c9fc7){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x2fc74c){return Promise['all'](_0x2fc74c['map'](async _0x2ed4ad=>{try{return{'fulfilled':!0x0,'value':await _0x2ed4ad};}catch(_0x15f7be){return{'fulfilled':!0x1,'reason':_0x15f7be};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x300968){this['eventTarget']=_0x300968,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x586754){const _0x31ec09=this['receivers']['find'](_0x200723=>_0x200723['isListeningto'](_0x586754));if(_0x31ec09)return _0x31ec09;const _0x1aa20a=new jn(_0x586754);return this['receivers']['push'](_0x1aa20a),_0x1aa20a;}['isListeningto'](_0x408aca){return this['eventTarget']===_0x408aca;}async['handleEvent'](_0x2c1b5b){const _0x2d3ebe=_0x2c1b5b,{eventId:_0x43f3b2,eventType:_0x30a57c,data:_0x9296a7}=_0x2d3ebe['data'],_0x15ab16=this['handlersMap'][_0x30a57c];if(!(_0x15ab16!=null&&_0x15ab16['size']))return;_0x2d3ebe['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x43f3b2,'eventType':_0x30a57c});const _0xe362da=Array['from'](_0x15ab16)['map'](async _0x6eadca=>_0x6eadca(_0x2d3ebe['origin'],_0x9296a7)),_0x42fcc3=await tp(_0xe362da);_0x2d3ebe['ports'][0x0]['postMessage']({'status':'done','eventId':_0x43f3b2,'eventType':_0x30a57c,'response':_0x42fcc3});}['_subscribe'](_0x1fb366,_0x5b8dce){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1fb366]||(this['handlersMap'][_0x1fb366]=new Set()),this['handlersMap'][_0x1fb366]['add'](_0x5b8dce);}['_unsubscribe'](_0x5dabc0,_0xc68537){this['handlersMap'][_0x5dabc0]&&_0xc68537&&this['handlersMap'][_0x5dabc0]['delete'](_0xc68537),(!_0xc68537||this['handlersMap'][_0x5dabc0]['size']===0x0)&&delete this['handlersMap'][_0x5dabc0],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x553048='',_0xbb9c8=0xa){let _0xd38d57='';for(let _0x2522f9=0x0;_0x2522f9<_0xbb9c8;_0x2522f9++)_0xd38d57+=Math['floor'](Math['random']()*0xa);return _0x553048+_0xd38d57;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x58a0f7){this['target']=_0x58a0f7,this['handlers']=new Set();}['removeMessageHandler'](_0x341ea1){_0x341ea1['messageChannel']&&(_0x341ea1['messageChannel']['port1']['removeEventListener']('message',_0x341ea1['onMessage']),_0x341ea1['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x341ea1);}async['_send'](_0x187bf2,_0x23bb5c,_0x1091df=0x32){const _0xacf526=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xacf526)throw new Error('connection_unavailable');let _0x1c664c,_0xcb4a08;return new Promise((_0x4d9720,_0x54523c)=>{const _0xdbb6bc=bs('',0x14);_0xacf526['port1']['start']();const _0x55a4ac=setTimeout(()=>{_0x54523c(new Error('unsupported_event'));},_0x1091df);_0xcb4a08={'messageChannel':_0xacf526,'onMessage'(_0x577286){const _0x47f4e5=_0x577286;if(_0x47f4e5['data']['eventId']===_0xdbb6bc)switch(_0x47f4e5['data']['status']){case'ack':clearTimeout(_0x55a4ac),_0x1c664c=setTimeout(()=>{_0x54523c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1c664c),_0x4d9720(_0x47f4e5['data']['response']);break;default:clearTimeout(_0x55a4ac),clearTimeout(_0x1c664c),_0x54523c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xcb4a08),_0xacf526['port1']['addEventListener']('message',_0xcb4a08['onMessage']),this['target']['postMessage']({'eventType':_0x187bf2,'eventId':_0xdbb6bc,'data':_0x23bb5c},[_0xacf526['port2']]);})['finally'](()=>{_0xcb4a08&&this['removeMessageHandler'](_0xcb4a08);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x4160e3){X()['location']['href']=_0x4160e3;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x2def27;return((_0x2def27=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2def27['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0xc45767){this['request']=_0xc45767;}['toPromise'](){return new Promise((_0x42e2d6,_0x42b2d5)=>{this['request']['addEventListener']('success',()=>{_0x42e2d6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x42b2d5(this['request']['error']);});});}}function Kn(_0x4562c6,_0x9c0b08){return _0x4562c6['transaction']([kn],_0x9c0b08?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0xe1015a=indexedDB['deleteDatabase'](qa);return new Jt(_0xe1015a)['toPromise']();}function ja(){const _0x366afe=indexedDB['open'](qa,ap);return new Promise((_0xe0f2fc,_0x313318)=>{_0x366afe['addEventListener']('error',()=>{_0x313318(_0x366afe['error']);}),_0x366afe['addEventListener']('upgradeneeded',()=>{const _0x4c3ac2=_0x366afe['result'];try{_0x4c3ac2['createObjectStore'](kn,{'keyPath':za});}catch(_0x48d799){_0x313318(_0x48d799);}}),_0x366afe['addEventListener']('success',async()=>{const _0x36957e=_0x366afe['result'];_0x36957e['objectStoreNames']['contains'](kn)?_0xe0f2fc(_0x36957e):(_0x36957e['close'](),await cp(),_0xe0f2fc(await ja()));});});}async function kr(_0x2d97db,_0x41ed2c,_0x3a09d9){const _0x2cc5f1=Kn(_0x2d97db,!0x0)['put']({[za]:_0x41ed2c,'value':_0x3a09d9});return new Jt(_0x2cc5f1)['toPromise']();}async function lp(_0x2f9723,_0x4c9eb4){const _0x424bc9=Kn(_0x2f9723,!0x1)['get'](_0x4c9eb4),_0x553de1=await new Jt(_0x424bc9)['toPromise']();return _0x553de1===void 0x0?null:_0x553de1['value'];}function Nr(_0x2897ef,_0x55f8a0){const _0x6d4692=Kn(_0x2897ef,!0x0)['delete'](_0x55f8a0);return new Jt(_0x6d4692)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x296986){let _0x1766f7=0x0;for(;;)try{const _0x21d982=await this['_openDb']();return await _0x296986(_0x21d982);}catch(_0x38cf11){if(_0x1766f7++>up)throw _0x38cf11;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x5268cb,_0x2ecc72)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2ecc72['key'])})),this['receiver']['_subscribe']('ping',async(_0x24d82c,_0x25b9d1)=>['keyChanged']);}async['initializeSender'](){var _0x585d98,_0x553719;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x462e29=await this['sender']['_send']('ping',{},0x320);_0x462e29&&(_0x585d98=_0x462e29[0x0])!=null&&_0x585d98['fulfilled']&&(_0x553719=_0x462e29[0x0])!=null&&_0x553719['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x25aa71){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x25aa71},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xd8a927=>{await kr(_0xd8a927,An,'1'),await Nr(_0xd8a927,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1c2955){this['pendingWrites']++;try{await _0x1c2955();}finally{this['pendingWrites']--;}}async['_set'](_0x3e24fa,_0x3f54f9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x37d74b=>kr(_0x37d74b,_0x3e24fa,_0x3f54f9)),this['localCache'][_0x3e24fa]=_0x3f54f9,this['notifyServiceWorker'](_0x3e24fa)));}async['_get'](_0x186486){const _0x4cbeb4=await this['_withRetries'](_0x56dd63=>lp(_0x56dd63,_0x186486));return this['localCache'][_0x186486]=_0x4cbeb4,_0x4cbeb4;}async['_remove'](_0x3bd2e4){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x57400e=>Nr(_0x57400e,_0x3bd2e4)),delete this['localCache'][_0x3bd2e4],this['notifyServiceWorker'](_0x3bd2e4)));}async['_poll'](){const _0x168725=await this['_withRetries'](_0x123096=>{const _0x4b0998=Kn(_0x123096,!0x1)['getAll']();return new Jt(_0x4b0998)['toPromise']();});if(!_0x168725)return[];if(this['pendingWrites']!==0x0)return[];const _0x42f174=[],_0x2a5358=new Set();if(_0x168725['length']!==0x0){for(const {fbase_key:_0x2873d0,value:_0xf9b750}of _0x168725)_0x2a5358['add'](_0x2873d0),JSON['stringify'](this['localCache'][_0x2873d0])!==JSON['stringify'](_0xf9b750)&&(this['notifyListeners'](_0x2873d0,_0xf9b750),_0x42f174['push'](_0x2873d0));}for(const _0x31ca9c of Object['keys'](this['localCache']))this['localCache'][_0x31ca9c]&&!_0x2a5358['has'](_0x31ca9c)&&(this['notifyListeners'](_0x31ca9c,null),_0x42f174['push'](_0x31ca9c));return _0x42f174;}['notifyListeners'](_0x18c8df,_0x4088a0){this['localCache'][_0x18c8df]=_0x4088a0;const _0x486af8=this['listeners'][_0x18c8df];if(_0x486af8){for(const _0x3a6965 of Array['from'](_0x486af8))_0x3a6965(_0x4088a0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2e434c,_0x4cc8bd){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2e434c]||(this['listeners'][_0x2e434c]=new Set(),this['_get'](_0x2e434c)),this['listeners'][_0x2e434c]['add'](_0x4cc8bd);}['_removeListener'](_0x35319b,_0x5afec2){this['listeners'][_0x35319b]&&(this['listeners'][_0x35319b]['delete'](_0x5afec2),this['listeners'][_0x35319b]['size']===0x0&&delete this['listeners'][_0x35319b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x1a36a7,_0x2636ae){return _0x2636ae?ne(_0x2636ae):(m(_0x1a36a7['_popupRedirectResolver'],_0x1a36a7,'argument-error'),_0x1a36a7['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x587f80){super('custom','custom'),this['params']=_0x587f80;}['_getIdTokenResponse'](_0x25ce85){return Ze(_0x25ce85,this['_buildIdpRequest']());}['_linkToIdToken'](_0x528c75,_0x3ea13c){return Ze(_0x528c75,this['_buildIdpRequest'](_0x3ea13c));}['_getReauthenticationResolver'](_0x39873c){return Ze(_0x39873c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5ab00c){const _0x6afd82={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5ab00c&&(_0x6afd82['idToken']=_0x5ab00c),_0x6afd82;}}function pp(_0x5ddaae){return Ua(_0x5ddaae['auth'],new Rs(_0x5ddaae),_0x5ddaae['bypassAuthState']);}function _p(_0x350745){const {auth:_0xb20b71,user:_0x7ff7b6}=_0x350745;return m(_0x7ff7b6,_0xb20b71,'internal-error'),Kf(_0x7ff7b6,new Rs(_0x350745),_0x350745['bypassAuthState']);}async function gp(_0x5ce397){const {auth:_0x132e99,user:_0x2af742}=_0x5ce397;return m(_0x2af742,_0x132e99,'internal-error'),jf(_0x2af742,new Rs(_0x5ce397),_0x5ce397['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2b8c22,_0x183f1e,_0x3de26d,_0x101546,_0x2825cc=!0x1){this['auth']=_0x2b8c22,this['resolver']=_0x3de26d,this['user']=_0x101546,this['bypassAuthState']=_0x2825cc,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x183f1e)?_0x183f1e:[_0x183f1e];}['execute'](){return new Promise(async(_0x17c7e2,_0xe2a164)=>{this['pendingPromise']={'resolve':_0x17c7e2,'reject':_0xe2a164};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x57d6cb){this['reject'](_0x57d6cb);}});}async['onAuthEvent'](_0x30a616){const {urlResponse:_0x523e98,sessionId:_0x565f6a,postBody:_0x4c7a5f,tenantId:_0x44eaea,error:_0x12ce7c,type:_0x4242c2}=_0x30a616;if(_0x12ce7c){this['reject'](_0x12ce7c);return;}const _0x1d3dd5={'auth':this['auth'],'requestUri':_0x523e98,'sessionId':_0x565f6a,'tenantId':_0x44eaea||void 0x0,'postBody':_0x4c7a5f||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4242c2)(_0x1d3dd5));}catch(_0x4ad263){this['reject'](_0x4ad263);}}['onError'](_0x1001e4){this['reject'](_0x1001e4);}['getIdpTask'](_0x3c9755){switch(_0x3c9755){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x13b191){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x13b191),this['unregisterAndCleanUp']();}['reject'](_0xe71f40){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xe71f40),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x31df6a,_0x44652a,_0x227154,_0x3156d6,_0x3d9b76){super(_0x31df6a,_0x44652a,_0x3156d6,_0x3d9b76),this['provider']=_0x227154,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xfaf2f0=await this['execute']();return m(_0xfaf2f0,this['auth'],'internal-error'),_0xfaf2f0;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2bfb45=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2bfb45),this['authWindow']['associatedEvent']=_0x2bfb45,this['resolver']['_originValidation'](this['auth'])['catch'](_0x13453f=>{this['reject'](_0x13453f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5e8650=>{_0x5e8650||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x150800;return((_0x150800=this['authWindow'])==null?void 0x0:_0x150800['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xd3872d=()=>{var _0x4e3f2f,_0x202c43;if((_0x202c43=(_0x4e3f2f=this['authWindow'])==null?void 0x0:_0x4e3f2f['window'])!=null&&_0x202c43['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xd3872d,mp['get']());};_0xd3872d();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0xf4e8d2,_0x16651b,_0x52a7ae=!0x1){super(_0xf4e8d2,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x16651b,void 0x0,_0x52a7ae),this['eventId']=null;}async['execute'](){let _0xfc3052=rn['get'](this['auth']['_key']());if(!_0xfc3052){try{const _0x56baf9=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0xfc3052=()=>Promise['resolve'](_0x56baf9);}catch(_0x1df877){_0xfc3052=()=>Promise['reject'](_0x1df877);}rn['set'](this['auth']['_key'](),_0xfc3052);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xfc3052();}async['onAuthEvent'](_0x5c4462){if(_0x5c4462['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5c4462);if(_0x5c4462['type']==='unknown'){this['resolve'](null);return;}if(_0x5c4462['eventId']){const _0x5a108b=await this['auth']['_redirectUserForId'](_0x5c4462['eventId']);if(_0x5a108b)return this['user']=_0x5a108b,super['onAuthEvent'](_0x5c4462);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x1ed585,_0x1f19bc){const _0x446b1b=Cp(_0x1f19bc),_0x4a7f66=wp(_0x1ed585);if(!await _0x4a7f66['_isAvailable']())return!0x1;const _0x2ba552=await _0x4a7f66['_get'](_0x446b1b)==='true';return await _0x4a7f66['_remove'](_0x446b1b),_0x2ba552;}function Ip(_0x98840b,_0x1f786c){rn['set'](_0x98840b['_key'](),_0x1f786c);}function wp(_0x3908a7){return ne(_0x3908a7['_redirectPersistence']);}function Cp(_0x317b18){return sn(yp,_0x317b18['config']['apiKey'],_0x317b18['name']);}async function Tp(_0x5457c3,_0x23d66e,_0x3df89c=!0x1){if(H(_0x5457c3['app']))return Promise['reject'](se(_0x5457c3));const _0x5bfe4c=qe(_0x5457c3),_0x3b7a35=fp(_0x5bfe4c,_0x23d66e),_0x8f88e0=await new vp(_0x5bfe4c,_0x3b7a35,_0x3df89c)['execute']();return _0x8f88e0&&!_0x3df89c&&(delete _0x8f88e0['user']['_redirectEventId'],await _0x5bfe4c['_persistUserIfCurrent'](_0x8f88e0['user']),await _0x5bfe4c['_setRedirectUser'](null,_0x23d66e)),_0x8f88e0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x32441d){this['auth']=_0x32441d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4b0152){this['consumers']['add'](_0x4b0152),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4b0152)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4b0152),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x500fca){this['consumers']['delete'](_0x500fca);}['onEvent'](_0x2ae710){if(this['hasEventBeenHandled'](_0x2ae710))return!0x1;let _0x2f9742=!0x1;return this['consumers']['forEach'](_0x1ab0d2=>{this['isEventForConsumer'](_0x2ae710,_0x1ab0d2)&&(_0x2f9742=!0x0,this['sendToConsumer'](_0x2ae710,_0x1ab0d2),this['saveEventToCache'](_0x2ae710));}),this['hasHandledPotentialRedirect']||!Rp(_0x2ae710)||(this['hasHandledPotentialRedirect']=!0x0,_0x2f9742||(this['queuedRedirectEvent']=_0x2ae710,_0x2f9742=!0x0)),_0x2f9742;}['sendToConsumer'](_0x17f448,_0xe8f240){var _0xc5cd92;if(_0x17f448['error']&&!Qa(_0x17f448)){const _0x5d8393=((_0xc5cd92=_0x17f448['error']['code'])==null?void 0x0:_0xc5cd92['split']('auth/')[0x1])||'internal-error';_0xe8f240['onError'](J(this['auth'],_0x5d8393));}else _0xe8f240['onAuthEvent'](_0x17f448);}['isEventForConsumer'](_0x41aeff,_0x57a540){const _0x26e27c=_0x57a540['eventId']===null||!!_0x41aeff['eventId']&&_0x41aeff['eventId']===_0x57a540['eventId'];return _0x57a540['filter']['includes'](_0x41aeff['type'])&&_0x26e27c;}['hasEventBeenHandled'](_0x48841a){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x48841a));}['saveEventToCache'](_0x539350){this['cachedEventUids']['add'](Pr(_0x539350)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x492332){return[_0x492332['type'],_0x492332['eventId'],_0x492332['sessionId'],_0x492332['tenantId']]['filter'](_0x1cd84b=>_0x1cd84b)['join']('-');}function Qa({type:_0x4b0016,error:_0x395a05}){return _0x4b0016==='unknown'&&(_0x395a05==null?void 0x0:_0x395a05['code'])==='auth/no-auth-event';}function Rp(_0x22af3f){switch(_0x22af3f['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x22af3f);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4f51f1,_0x1184f3={}){return Ae(_0x4f51f1,'GET','/v1/projects',_0x1184f3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x49431e){if(_0x49431e['config']['emulator'])return;const {authorizedDomains:_0x467e37}=await Ap(_0x49431e);for(const _0x529f63 of _0x467e37)try{if(Op(_0x529f63))return;}catch{}K(_0x49431e,'unauthorized-domain');}function Op(_0x24da9b){const _0x3648c1=Ni(),{protocol:_0x2a856e,hostname:_0xdc0cc0}=new URL(_0x3648c1);if(_0x24da9b['startsWith']('chrome-extension://')){const _0x58ffa1=new URL(_0x24da9b);return _0x58ffa1['hostname']===''&&_0xdc0cc0===''?_0x2a856e==='chrome-extension:'&&_0x24da9b['replace']('chrome-extension://','')===_0x3648c1['replace']('chrome-extension://',''):_0x2a856e==='chrome-extension:'&&_0x58ffa1['hostname']===_0xdc0cc0;}if(!Np['test'](_0x2a856e))return!0x1;if(kp['test'](_0x24da9b))return _0xdc0cc0===_0x24da9b;const _0x4f8688=_0x24da9b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4f8688+'|'+_0x4f8688+')$','i')['test'](_0xdc0cc0);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x397d79=X()['___jsl'];if(_0x397d79!=null&&_0x397d79['H']){for(const _0x5bccbf of Object['keys'](_0x397d79['H']))if(_0x397d79['H'][_0x5bccbf]['r']=_0x397d79['H'][_0x5bccbf]['r']||[],_0x397d79['H'][_0x5bccbf]['L']=_0x397d79['H'][_0x5bccbf]['L']||[],_0x397d79['H'][_0x5bccbf]['r']=[..._0x397d79['H'][_0x5bccbf]['L']],_0x397d79['CP']){for(let _0x9c2a8=0x0;_0x9c2a8<_0x397d79['CP']['length'];_0x9c2a8++)_0x397d79['CP'][_0x9c2a8]=null;}}}function Mp(_0x2152a1){return new Promise((_0x4d63c0,_0xd7a12a)=>{var _0x12de29,_0x345a0e,_0x3e1112;function _0x55240c(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4d63c0(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0xd7a12a(J(_0x2152a1,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x345a0e=(_0x12de29=X()['gapi'])==null?void 0x0:_0x12de29['iframes'])!=null&&_0x345a0e['Iframe'])_0x4d63c0(gapi['iframes']['getContext']());else{if((_0x3e1112=X()['gapi'])!=null&&_0x3e1112['load'])_0x55240c();else{const _0x26729d=Nf('iframefcb');return X()[_0x26729d]=()=>{gapi['load']?_0x55240c():_0xd7a12a(J(_0x2152a1,'network-request-failed'));},Da(kf()+'?onload='+_0x26729d)['catch'](_0x21c471=>_0xd7a12a(_0x21c471));}}})['catch'](_0x290eca=>{throw on=null,_0x290eca;});}let on=null;function Lp(_0x5a8aa6){return on=on||Mp(_0x5a8aa6),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x437931){const _0x5b4316=_0x437931['config'];m(_0x5b4316['authDomain'],_0x437931,'auth-domain-config-required');const _0x21b415=_0x5b4316['emulator']?Is(_0x5b4316,Up):'https://'+_0x437931['config']['authDomain']+'/'+Fp,_0x56da69={'apiKey':_0x5b4316['apiKey'],'appName':_0x437931['name'],'v':ct},_0x53adc8=Bp['get'](_0x437931['config']['apiHost']);_0x53adc8&&(_0x56da69['eid']=_0x53adc8);const _0x5ed699=_0x437931['_getFrameworks']();return _0x5ed699['length']&&(_0x56da69['fw']=_0x5ed699['join'](',')),_0x21b415+'?'+at(_0x56da69)['slice'](0x1);}async function Hp(_0x38deab){const _0x1f6549=await Lp(_0x38deab),_0x44d7fe=X()['gapi'];return m(_0x44d7fe,_0x38deab,'internal-error'),_0x1f6549['open']({'where':document['body'],'url':Vp(_0x38deab),'messageHandlersFilter':_0x44d7fe['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x13b283=>new Promise(async(_0xa56390,_0x5a851f)=>{await _0x13b283['restyle']({'setHideOnLeave':!0x1});const _0x261978=J(_0x38deab,'network-request-failed'),_0x24998c=X()['setTimeout'](()=>{_0x5a851f(_0x261978);},xp['get']());function _0x22afc8(){X()['clearTimeout'](_0x24998c),_0xa56390(_0x13b283);}_0x13b283['ping'](_0x22afc8)['then'](_0x22afc8,()=>{_0x5a851f(_0x261978);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1ce612){this['window']=_0x1ce612,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x56f7cb,_0xb95753,_0xf6ec81,_0x139b65=Gp,_0x85c37b=qp){const _0xe02575=Math['max']((window['screen']['availHeight']-_0x85c37b)/0x2,0x0)['toString'](),_0x422a37=Math['max']((window['screen']['availWidth']-_0x139b65)/0x2,0x0)['toString']();let _0x47fb03='';const _0x50c536={...$p,'width':_0x139b65['toString'](),'height':_0x85c37b['toString'](),'top':_0xe02575,'left':_0x422a37},_0x19caf6=W()['toLowerCase']();_0xf6ec81&&(_0x47fb03=ba(_0x19caf6)?zp:_0xf6ec81),Ta(_0x19caf6)&&(_0xb95753=_0xb95753||jp,_0x50c536['scrollbars']='yes');const _0x59d946=Object['entries'](_0x50c536)['reduce']((_0xfa913,[_0x346925,_0x29c1d5])=>''+_0xfa913+_0x346925+'='+_0x29c1d5+',','');if(Ef(_0x19caf6)&&_0x47fb03!=='_self')return Yp(_0xb95753||'',_0x47fb03),new Dr(null);const _0x21b503=window['open'](_0xb95753||'',_0x47fb03,_0x59d946);m(_0x21b503,_0x56f7cb,'popup-blocked');try{_0x21b503['focus']();}catch{}return new Dr(_0x21b503);}function Yp(_0x29e504,_0x38a458){const _0x5a863b=document['createElement']('a');_0x5a863b['href']=_0x29e504,_0x5a863b['target']=_0x38a458;const _0x2bc3a4=document['createEvent']('MouseEvent');_0x2bc3a4['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5a863b['dispatchEvent'](_0x2bc3a4);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x1daa6b,_0x2c7915,_0x986b17,_0x3f56b1,_0x2ee5ac,_0x4cb605){m(_0x1daa6b['config']['authDomain'],_0x1daa6b,'auth-domain-config-required'),m(_0x1daa6b['config']['apiKey'],_0x1daa6b,'invalid-api-key');const _0xe98df6={'apiKey':_0x1daa6b['config']['apiKey'],'appName':_0x1daa6b['name'],'authType':_0x986b17,'redirectUrl':_0x3f56b1,'v':ct,'eventId':_0x2ee5ac};if(_0x2c7915 instanceof xa){_0x2c7915['setDefaultLanguage'](_0x1daa6b['languageCode']),_0xe98df6['providerId']=_0x2c7915['providerId']||'',hi(_0x2c7915['getCustomParameters']())||(_0xe98df6['customParameters']=JSON['stringify'](_0x2c7915['getCustomParameters']()));for(const [_0x18f9d3,_0x55333f]of Object['entries']({}))_0xe98df6[_0x18f9d3]=_0x55333f;}if(_0x2c7915 instanceof Qt){const _0x3236c8=_0x2c7915['getScopes']()['filter'](_0x4262f4=>_0x4262f4!=='');_0x3236c8['length']>0x0&&(_0xe98df6['scopes']=_0x3236c8['join'](','));}_0x1daa6b['tenantId']&&(_0xe98df6['tid']=_0x1daa6b['tenantId']);const _0x2a53b7=_0xe98df6;for(const _0x35108b of Object['keys'](_0x2a53b7))_0x2a53b7[_0x35108b]===void 0x0&&delete _0x2a53b7[_0x35108b];const _0x49457c=await _0x1daa6b['_getAppCheckToken'](),_0xbb6b55=_0x49457c?'#'+Xp+'='+encodeURIComponent(_0x49457c):'';return Zp(_0x1daa6b)+'?'+at(_0x2a53b7)['slice'](0x1)+_0xbb6b55;}function Zp({config:_0x40d037}){return _0x40d037['emulator']?Is(_0x40d037,Jp):'https://'+_0x40d037['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x9ddf94,_0x153447,_0x56bfff,_0x67d1f9){var _0x352477;ae((_0x352477=this['eventManagers'][_0x9ddf94['_key']()])==null?void 0x0:_0x352477['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x58c072=await Mr(_0x9ddf94,_0x153447,_0x56bfff,Ni(),_0x67d1f9);return Kp(_0x9ddf94,_0x58c072,bs());}async['_openRedirect'](_0x44583f,_0x421075,_0x3cc3b9,_0x1374d6){await this['_originValidation'](_0x44583f);const _0x4a77d3=await Mr(_0x44583f,_0x421075,_0x3cc3b9,Ni(),_0x1374d6);return ip(_0x4a77d3),new Promise(()=>{});}['_initialize'](_0x4a068b){const _0x1a81c9=_0x4a068b['_key']();if(this['eventManagers'][_0x1a81c9]){const {manager:_0x7f7bc1,promise:_0x45ad45}=this['eventManagers'][_0x1a81c9];return _0x7f7bc1?Promise['resolve'](_0x7f7bc1):(ae(_0x45ad45,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x45ad45);}const _0x3ed6b8=this['initAndGetManager'](_0x4a068b);return this['eventManagers'][_0x1a81c9]={'promise':_0x3ed6b8},_0x3ed6b8['catch'](()=>{delete this['eventManagers'][_0x1a81c9];}),_0x3ed6b8;}async['initAndGetManager'](_0x502fb8){const _0x259d27=await Hp(_0x502fb8),_0x22d6b5=new bp(_0x502fb8);return _0x259d27['register']('authEvent',_0x4801a4=>(m(_0x4801a4==null?void 0x0:_0x4801a4['authEvent'],_0x502fb8,'invalid-auth-event'),{'status':_0x22d6b5['onEvent'](_0x4801a4['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x502fb8['_key']()]={'manager':_0x22d6b5},this['iframes'][_0x502fb8['_key']()]=_0x259d27,_0x22d6b5;}['_isIframeWebStorageSupported'](_0x57eceb,_0x370134){this['iframes'][_0x57eceb['_key']()]['send'](li,{'type':li},_0xded337=>{var _0x18e292;const _0x595a61=(_0x18e292=_0xded337==null?void 0x0:_0xded337[0x0])==null?void 0x0:_0x18e292[li];_0x595a61!==void 0x0&&_0x370134(!!_0x595a61),K(_0x57eceb,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2823e0){const _0x1a9aee=_0x2823e0['_key']();return this['originValidationPromises'][_0x1a9aee]||(this['originValidationPromises'][_0x1a9aee]=Pp(_0x2823e0)),this['originValidationPromises'][_0x1a9aee];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x2172e2){this['auth']=_0x2172e2,this['internalListeners']=new Map();}['getUid'](){var _0x44da1c;return this['assertAuthConfigured'](),((_0x44da1c=this['auth']['currentUser'])==null?void 0x0:_0x44da1c['uid'])||null;}async['getToken'](_0x4ca84d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4ca84d)}:null;}['addAuthTokenListener'](_0x25016b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x25016b))return;const _0x12e2ea=this['auth']['onIdTokenChanged'](_0x4d9764=>{_0x25016b((_0x4d9764==null?void 0x0:_0x4d9764['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x25016b,_0x12e2ea),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x927b4f){this['assertAuthConfigured']();const _0x360acc=this['internalListeners']['get'](_0x927b4f);_0x360acc&&(this['internalListeners']['delete'](_0x927b4f),_0x360acc(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x33579d){switch(_0x33579d){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x4005ec){et(new Me('auth',(_0x5b8571,{options:_0x37d3cd})=>{const _0x2b64de=_0x5b8571['getProvider']('app')['getImmediate'](),_0x56b77e=_0x5b8571['getProvider']('heartbeat'),_0xc9cc50=_0x5b8571['getProvider']('app-check-internal'),{apiKey:_0x1c7261,authDomain:_0x2ca081}=_0x2b64de['options'];m(_0x1c7261&&!_0x1c7261['includes'](':'),'invalid-api-key',{'appName':_0x2b64de['name']});const _0x456ade={'apiKey':_0x1c7261,'authDomain':_0x2ca081,'clientPlatform':_0x4005ec,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x4005ec)},_0x4743fe=new bf(_0x2b64de,_0x56b77e,_0xc9cc50,_0x456ade);return Lf(_0x4743fe,_0x37d3cd),_0x4743fe;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x442811,_0x1e7c35,_0x208a6a)=>{_0x442811['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x211b73=>{const _0x4c0d2f=qe(_0x211b73['getProvider']('auth')['getImmediate']());return(_0x36b47d=>new n_(_0x36b47d))(_0x4c0d2f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x4005ec)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x587885=>async _0x27a3b6=>{const _0x43d446=_0x27a3b6&&await _0x27a3b6['getIdTokenResult'](),_0x53dba2=_0x43d446&&(new Date()['getTime']()-Date['parse'](_0x43d446['issuedAtTime']))/0x3e8;if(_0x53dba2&&_0x53dba2>o_)return;const _0x5c6035=_0x43d446==null?void 0x0:_0x43d446['token'];Fr!==_0x5c6035&&(Fr=_0x5c6035,await fetch(_0x587885,{'method':_0x5c6035?'POST':'DELETE','headers':_0x5c6035?{'Authorization':'Bearer\x20'+_0x5c6035}:{}}));};function O_(_0x24b8af=Qr()){const _0xf57ce1=Ui(_0x24b8af,'auth');if(_0xf57ce1['isInitialized']())return _0xf57ce1['getImmediate']();const _0x1c54ed=Mf(_0x24b8af,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x41923a=Gr('authTokenSyncURL');if(_0x41923a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x198735=new URL(_0x41923a,location['origin']);if(location['origin']===_0x198735['origin']){const _0x297493=a_(_0x198735['toString']());Jf(_0x1c54ed,_0x297493,()=>_0x297493(_0x1c54ed['currentUser'])),Qf(_0x1c54ed,_0x547dc1=>_0x297493(_0x547dc1));}}const _0x5c55dc=Hr('auth');return _0x5c55dc&&xf(_0x1c54ed,'http://'+_0x5c55dc),_0x1c54ed;}function c_(){var _0x528ad2;return((_0x528ad2=document['getElementsByTagName']('head'))==null?void 0x0:_0x528ad2[0x0])??document;}Rf({'loadJS'(_0x4242c0){return new Promise((_0x7bff3d,_0x28f99b)=>{const _0x39e61f=document['createElement']('script');_0x39e61f['setAttribute']('src',_0x4242c0),_0x39e61f['onload']=_0x7bff3d,_0x39e61f['onerror']=_0xfd060a=>{const _0x4a8b4c=J('internal-error');_0x4a8b4c['customData']=_0xfd060a,_0x28f99b(_0x4a8b4c);},_0x39e61f['type']='text/javascript',_0x39e61f['charset']='UTF-8',c_()['appendChild'](_0x39e61f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};