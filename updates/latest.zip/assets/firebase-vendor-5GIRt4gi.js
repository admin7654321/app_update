const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3cd7a1,_0x522ab6){if(!_0x3cd7a1)throw ot(_0x522ab6);},ot=function(_0x3ad8af){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3ad8af);},Wr=function(_0x293d45){const _0x3d40ae=[];let _0x39739a=0x0;for(let _0x4d87e9=0x0;_0x4d87e9<_0x293d45['length'];_0x4d87e9++){let _0x2eafd6=_0x293d45['charCodeAt'](_0x4d87e9);_0x2eafd6<0x80?_0x3d40ae[_0x39739a++]=_0x2eafd6:_0x2eafd6<0x800?(_0x3d40ae[_0x39739a++]=_0x2eafd6>>0x6|0xc0,_0x3d40ae[_0x39739a++]=_0x2eafd6&0x3f|0x80):(_0x2eafd6&0xfc00)===0xd800&&_0x4d87e9+0x1<_0x293d45['length']&&(_0x293d45['charCodeAt'](_0x4d87e9+0x1)&0xfc00)===0xdc00?(_0x2eafd6=0x10000+((_0x2eafd6&0x3ff)<<0xa)+(_0x293d45['charCodeAt'](++_0x4d87e9)&0x3ff),_0x3d40ae[_0x39739a++]=_0x2eafd6>>0x12|0xf0,_0x3d40ae[_0x39739a++]=_0x2eafd6>>0xc&0x3f|0x80,_0x3d40ae[_0x39739a++]=_0x2eafd6>>0x6&0x3f|0x80,_0x3d40ae[_0x39739a++]=_0x2eafd6&0x3f|0x80):(_0x3d40ae[_0x39739a++]=_0x2eafd6>>0xc|0xe0,_0x3d40ae[_0x39739a++]=_0x2eafd6>>0x6&0x3f|0x80,_0x3d40ae[_0x39739a++]=_0x2eafd6&0x3f|0x80);}return _0x3d40ae;},Za=function(_0x164c8d){const _0x5acdc0=[];let _0xa172ef=0x0,_0x5420cb=0x0;for(;_0xa172ef<_0x164c8d['length'];){const _0x1177f9=_0x164c8d[_0xa172ef++];if(_0x1177f9<0x80)_0x5acdc0[_0x5420cb++]=String['fromCharCode'](_0x1177f9);else{if(_0x1177f9>0xbf&&_0x1177f9<0xe0){const _0x1c0f7a=_0x164c8d[_0xa172ef++];_0x5acdc0[_0x5420cb++]=String['fromCharCode']((_0x1177f9&0x1f)<<0x6|_0x1c0f7a&0x3f);}else{if(_0x1177f9>0xef&&_0x1177f9<0x16d){const _0x7888ac=_0x164c8d[_0xa172ef++],_0x244f63=_0x164c8d[_0xa172ef++],_0x4a8634=_0x164c8d[_0xa172ef++],_0x132c11=((_0x1177f9&0x7)<<0x12|(_0x7888ac&0x3f)<<0xc|(_0x244f63&0x3f)<<0x6|_0x4a8634&0x3f)-0x10000;_0x5acdc0[_0x5420cb++]=String['fromCharCode'](0xd800+(_0x132c11>>0xa)),_0x5acdc0[_0x5420cb++]=String['fromCharCode'](0xdc00+(_0x132c11&0x3ff));}else{const _0x2a2a3c=_0x164c8d[_0xa172ef++],_0x3c95d5=_0x164c8d[_0xa172ef++];_0x5acdc0[_0x5420cb++]=String['fromCharCode']((_0x1177f9&0xf)<<0xc|(_0x2a2a3c&0x3f)<<0x6|_0x3c95d5&0x3f);}}}}return _0x5acdc0['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2458d9,_0x467668){if(!Array['isArray'](_0x2458d9))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x70c54e=_0x467668?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2a4ed4=[];for(let _0x18879b=0x0;_0x18879b<_0x2458d9['length'];_0x18879b+=0x3){const _0x26d61f=_0x2458d9[_0x18879b],_0x1ab3a9=_0x18879b+0x1<_0x2458d9['length'],_0x19fd1e=_0x1ab3a9?_0x2458d9[_0x18879b+0x1]:0x0,_0x57edc7=_0x18879b+0x2<_0x2458d9['length'],_0x3193a8=_0x57edc7?_0x2458d9[_0x18879b+0x2]:0x0,_0x2d98c4=_0x26d61f>>0x2,_0x50fab2=(_0x26d61f&0x3)<<0x4|_0x19fd1e>>0x4;let _0x224249=(_0x19fd1e&0xf)<<0x2|_0x3193a8>>0x6,_0x5c256f=_0x3193a8&0x3f;_0x57edc7||(_0x5c256f=0x40,_0x1ab3a9||(_0x224249=0x40)),_0x2a4ed4['push'](_0x70c54e[_0x2d98c4],_0x70c54e[_0x50fab2],_0x70c54e[_0x224249],_0x70c54e[_0x5c256f]);}return _0x2a4ed4['join']('');},'encodeString'(_0x37842f,_0x4500b1){return this['HAS_NATIVE_SUPPORT']&&!_0x4500b1?btoa(_0x37842f):this['encodeByteArray'](Wr(_0x37842f),_0x4500b1);},'decodeString'(_0x1fd1f6,_0x4e6ebb){return this['HAS_NATIVE_SUPPORT']&&!_0x4e6ebb?atob(_0x1fd1f6):Za(this['decodeStringToByteArray'](_0x1fd1f6,_0x4e6ebb));},'decodeStringToByteArray'(_0x495005,_0x45aae6){this['init_']();const _0x4a8f83=_0x45aae6?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x15124f=[];for(let _0x37bf97=0x0;_0x37bf97<_0x495005['length'];){const _0x2b2d04=_0x4a8f83[_0x495005['charAt'](_0x37bf97++)],_0x1d3d87=_0x37bf97<_0x495005['length']?_0x4a8f83[_0x495005['charAt'](_0x37bf97)]:0x0;++_0x37bf97;const _0x1b625d=_0x37bf97<_0x495005['length']?_0x4a8f83[_0x495005['charAt'](_0x37bf97)]:0x40;++_0x37bf97;const _0x3d37ca=_0x37bf97<_0x495005['length']?_0x4a8f83[_0x495005['charAt'](_0x37bf97)]:0x40;if(++_0x37bf97,_0x2b2d04==null||_0x1d3d87==null||_0x1b625d==null||_0x3d37ca==null)throw new ec();const _0x20acc7=_0x2b2d04<<0x2|_0x1d3d87>>0x4;if(_0x15124f['push'](_0x20acc7),_0x1b625d!==0x40){const _0x2a27eb=_0x1d3d87<<0x4&0xf0|_0x1b625d>>0x2;if(_0x15124f['push'](_0x2a27eb),_0x3d37ca!==0x40){const _0xfb3be8=_0x1b625d<<0x6&0xc0|_0x3d37ca;_0x15124f['push'](_0xfb3be8);}}}return _0x15124f;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4da836=0x0;_0x4da836<this['ENCODED_VALS']['length'];_0x4da836++)this['byteToCharMap_'][_0x4da836]=this['ENCODED_VALS']['charAt'](_0x4da836),this['charToByteMap_'][this['byteToCharMap_'][_0x4da836]]=_0x4da836,this['byteToCharMapWebSafe_'][_0x4da836]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4da836),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4da836]]=_0x4da836,_0x4da836>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4da836)]=_0x4da836,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4da836)]=_0x4da836);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x5083c7){const _0x483fb3=Wr(_0x5083c7);return Di['encodeByteArray'](_0x483fb3,!0x0);},an=function(_0x34e1f5){return Br(_0x34e1f5)['replace'](/\./g,'');},cn=function(_0x861a33){try{return Di['decodeString'](_0x861a33,!0x0);}catch(_0x4f9ed6){console['error']('base64Decode\x20failed:\x20',_0x4f9ed6);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0xf44fe2){return Vr(void 0x0,_0xf44fe2);}function Vr(_0xe0ad2e,_0x51b68f){if(!(_0x51b68f instanceof Object))return _0x51b68f;switch(_0x51b68f['constructor']){case Date:const _0x19044f=_0x51b68f;return new Date(_0x19044f['getTime']());case Object:_0xe0ad2e===void 0x0&&(_0xe0ad2e={});break;case Array:_0xe0ad2e=[];break;default:return _0x51b68f;}for(const _0x5e15d7 in _0x51b68f)!_0x51b68f['hasOwnProperty'](_0x5e15d7)||!nc(_0x5e15d7)||(_0xe0ad2e[_0x5e15d7]=Vr(_0xe0ad2e[_0x5e15d7],_0x51b68f[_0x5e15d7]));return _0xe0ad2e;}function nc(_0x44a911){return _0x44a911!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x96f27e=As['__FIREBASE_DEFAULTS__'];if(_0x96f27e)return JSON['parse'](_0x96f27e);},oc=()=>{if(typeof document>'u')return;let _0x7ffdad;try{_0x7ffdad=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x105b9d=_0x7ffdad&&cn(_0x7ffdad[0x1]);return _0x105b9d&&JSON['parse'](_0x105b9d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x27c1c4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x27c1c4);return;}},Hr=_0x42ef8c=>{var _0x389920,_0xf2d2a2;return(_0xf2d2a2=(_0x389920=Mi())==null?void 0x0:_0x389920['emulatorHosts'])==null?void 0x0:_0xf2d2a2[_0x42ef8c];},ac=_0x5d94f5=>{const _0x2af2da=Hr(_0x5d94f5);if(!_0x2af2da)return;const _0x15662e=_0x2af2da['lastIndexOf'](':');if(_0x15662e<=0x0||_0x15662e+0x1===_0x2af2da['length'])throw new Error('Invalid\x20host\x20'+_0x2af2da+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x14e723=parseInt(_0x2af2da['substring'](_0x15662e+0x1),0xa);return _0x2af2da[0x0]==='['?[_0x2af2da['substring'](0x1,_0x15662e-0x1),_0x14e723]:[_0x2af2da['substring'](0x0,_0x15662e),_0x14e723];},$r=()=>{var _0xcfe352;return(_0xcfe352=Mi())==null?void 0x0:_0xcfe352['config'];},Gr=_0x4c7552=>{var _0x3dbb1f;return(_0x3dbb1f=Mi())==null?void 0x0:_0x3dbb1f['_'+_0x4c7552];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5a24eb,_0x57ec0c)=>{this['resolve']=_0x5a24eb,this['reject']=_0x57ec0c;});}['wrapCallback'](_0x4247f1){return(_0x4220b7,_0x17c302)=>{_0x4220b7?this['reject'](_0x4220b7):this['resolve'](_0x17c302),typeof _0x4247f1=='function'&&(this['promise']['catch'](()=>{}),_0x4247f1['length']===0x1?_0x4247f1(_0x4220b7):_0x4247f1(_0x4220b7,_0x17c302));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3c2b7c,_0x5d2591){if(_0x3c2b7c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x325e86={'alg':'none','type':'JWT'},_0x7b0951=_0x5d2591||'demo-project',_0x26784e=_0x3c2b7c['iat']||0x0,_0x5ac3f1=_0x3c2b7c['sub']||_0x3c2b7c['user_id'];if(!_0x5ac3f1)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2d5294={'iss':'https://securetoken.google.com/'+_0x7b0951,'aud':_0x7b0951,'iat':_0x26784e,'exp':_0x26784e+0xe10,'auth_time':_0x26784e,'sub':_0x5ac3f1,'user_id':_0x5ac3f1,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3c2b7c};return[an(JSON['stringify'](_0x325e86)),an(JSON['stringify'](_0x2d5294)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x10e673=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x10e673=='object'&&_0x10e673['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x55d362=W();return _0x55d362['indexOf']('MSIE\x20')>=0x0||_0x55d362['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x26370a,_0x155fce)=>{try{let _0x27fa96=!0x0;const _0x4c6ddb='validate-browser-context-for-indexeddb-analytics-module',_0x52d8d0=self['indexedDB']['open'](_0x4c6ddb);_0x52d8d0['onsuccess']=()=>{_0x52d8d0['result']['close'](),_0x27fa96||self['indexedDB']['deleteDatabase'](_0x4c6ddb),_0x26370a(!0x0);},_0x52d8d0['onupgradeneeded']=()=>{_0x27fa96=!0x1;},_0x52d8d0['onerror']=()=>{var _0x2e71ab;_0x155fce(((_0x2e71ab=_0x52d8d0['error'])==null?void 0x0:_0x2e71ab['message'])||'');};}catch(_0x3cb632){_0x155fce(_0x3cb632);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x352c01,_0x47224b,_0x3036c6){super(_0x47224b),this['code']=_0x352c01,this['customData']=_0x3036c6,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2597c2,_0x305fd0,_0xddcd0){this['service']=_0x2597c2,this['serviceName']=_0x305fd0,this['errors']=_0xddcd0;}['create'](_0x20e4fd,..._0x42528d){const _0x3615f2=_0x42528d[0x0]||{},_0x4f25c9=this['service']+'/'+_0x20e4fd,_0x3a2226=this['errors'][_0x20e4fd],_0x538a60=_0x3a2226?gc(_0x3a2226,_0x3615f2):'Error',_0x16d0c3=this['serviceName']+':\x20'+_0x538a60+'\x20('+_0x4f25c9+').';return new Se(_0x4f25c9,_0x16d0c3,_0x3615f2);}}function gc(_0x4698b7,_0x4c4096){return _0x4698b7['replace'](mc,(_0x3c6bdf,_0x363930)=>{const _0x8753b6=_0x4c4096[_0x363930];return _0x8753b6!=null?String(_0x8753b6):'<'+_0x363930+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x1ebb43){return JSON['parse'](_0x1ebb43);}function O(_0x1aa7b4){return JSON['stringify'](_0x1aa7b4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x24ff22){let _0x5d654f={},_0x46fbe5={},_0x164cb4={},_0xd9ca21='';try{const _0xa5e8cd=_0x24ff22['split']('.');_0x5d654f=bt(cn(_0xa5e8cd[0x0])||''),_0x46fbe5=bt(cn(_0xa5e8cd[0x1])||''),_0xd9ca21=_0xa5e8cd[0x2],_0x164cb4=_0x46fbe5['d']||{},delete _0x46fbe5['d'];}catch{}return{'header':_0x5d654f,'claims':_0x46fbe5,'data':_0x164cb4,'signature':_0xd9ca21};},yc=function(_0x4da110){const _0x567269=zr(_0x4da110),_0xa9cd6e=_0x567269['claims'];return!!_0xa9cd6e&&typeof _0xa9cd6e=='object'&&_0xa9cd6e['hasOwnProperty']('iat');},vc=function(_0x163e69){const _0x4b7f7d=zr(_0x163e69)['claims'];return typeof _0x4b7f7d=='object'&&_0x4b7f7d['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xbaccd0,_0x4571c5){return Object['prototype']['hasOwnProperty']['call'](_0xbaccd0,_0x4571c5);}function Oe(_0x3ff1e5,_0x462fd6){if(Object['prototype']['hasOwnProperty']['call'](_0x3ff1e5,_0x462fd6))return _0x3ff1e5[_0x462fd6];}function hi(_0x51eb99){for(const _0xe6bd68 in _0x51eb99)if(Object['prototype']['hasOwnProperty']['call'](_0x51eb99,_0xe6bd68))return!0x1;return!0x0;}function ln(_0x159823,_0x244cf8,_0x3daa4d){const _0x201287={};for(const _0x569dff in _0x159823)Object['prototype']['hasOwnProperty']['call'](_0x159823,_0x569dff)&&(_0x201287[_0x569dff]=_0x244cf8['call'](_0x3daa4d,_0x159823[_0x569dff],_0x569dff,_0x159823));return _0x201287;}function De(_0x1b7caf,_0x1c9349){if(_0x1b7caf===_0x1c9349)return!0x0;const _0x1fb045=Object['keys'](_0x1b7caf),_0x4c06b3=Object['keys'](_0x1c9349);for(const _0x12ced2 of _0x1fb045){if(!_0x4c06b3['includes'](_0x12ced2))return!0x1;const _0x47c372=_0x1b7caf[_0x12ced2],_0x586d00=_0x1c9349[_0x12ced2];if(ks(_0x47c372)&&ks(_0x586d00)){if(!De(_0x47c372,_0x586d00))return!0x1;}else{if(_0x47c372!==_0x586d00)return!0x1;}}for(const _0x4ccce1 of _0x4c06b3)if(!_0x1fb045['includes'](_0x4ccce1))return!0x1;return!0x0;}function ks(_0x2d3e83){return _0x2d3e83!==null&&typeof _0x2d3e83=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x31c9c5){const _0x3a0a4c=[];for(const [_0x4c8603,_0x31b77f]of Object['entries'](_0x31c9c5))Array['isArray'](_0x31b77f)?_0x31b77f['forEach'](_0x406a13=>{_0x3a0a4c['push'](encodeURIComponent(_0x4c8603)+'='+encodeURIComponent(_0x406a13));}):_0x3a0a4c['push'](encodeURIComponent(_0x4c8603)+'='+encodeURIComponent(_0x31b77f));return _0x3a0a4c['length']?'&'+_0x3a0a4c['join']('&'):'';}function yt(_0x2a45b9){const _0x1e0727={};return _0x2a45b9['replace'](/^\?/,'')['split']('&')['forEach'](_0x19fb0d=>{if(_0x19fb0d){const [_0x308678,_0x5e876d]=_0x19fb0d['split']('=');_0x1e0727[decodeURIComponent(_0x308678)]=decodeURIComponent(_0x5e876d);}}),_0x1e0727;}function vt(_0x18826a){const _0x25d876=_0x18826a['indexOf']('?');if(!_0x25d876)return'';const _0x594ddd=_0x18826a['indexOf']('#',_0x25d876);return _0x18826a['substring'](_0x25d876,_0x594ddd>0x0?_0x594ddd:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x133568=0x1;_0x133568<this['blockSize'];++_0x133568)this['pad_'][_0x133568]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5b896e,_0x580515){_0x580515||(_0x580515=0x0);const _0x591bbf=this['W_'];if(typeof _0x5b896e=='string'){for(let _0x3ef592=0x0;_0x3ef592<0x10;_0x3ef592++)_0x591bbf[_0x3ef592]=_0x5b896e['charCodeAt'](_0x580515)<<0x18|_0x5b896e['charCodeAt'](_0x580515+0x1)<<0x10|_0x5b896e['charCodeAt'](_0x580515+0x2)<<0x8|_0x5b896e['charCodeAt'](_0x580515+0x3),_0x580515+=0x4;}else{for(let _0x3b15ed=0x0;_0x3b15ed<0x10;_0x3b15ed++)_0x591bbf[_0x3b15ed]=_0x5b896e[_0x580515]<<0x18|_0x5b896e[_0x580515+0x1]<<0x10|_0x5b896e[_0x580515+0x2]<<0x8|_0x5b896e[_0x580515+0x3],_0x580515+=0x4;}for(let _0xde7d72=0x10;_0xde7d72<0x50;_0xde7d72++){const _0x3a4104=_0x591bbf[_0xde7d72-0x3]^_0x591bbf[_0xde7d72-0x8]^_0x591bbf[_0xde7d72-0xe]^_0x591bbf[_0xde7d72-0x10];_0x591bbf[_0xde7d72]=(_0x3a4104<<0x1|_0x3a4104>>>0x1f)&0xffffffff;}let _0x50c9c2=this['chain_'][0x0],_0x1e4c8b=this['chain_'][0x1],_0x165579=this['chain_'][0x2],_0x19c57e=this['chain_'][0x3],_0x420263=this['chain_'][0x4],_0x4406f9,_0x252acd;for(let _0x2acf96=0x0;_0x2acf96<0x50;_0x2acf96++){_0x2acf96<0x28?_0x2acf96<0x14?(_0x4406f9=_0x19c57e^_0x1e4c8b&(_0x165579^_0x19c57e),_0x252acd=0x5a827999):(_0x4406f9=_0x1e4c8b^_0x165579^_0x19c57e,_0x252acd=0x6ed9eba1):_0x2acf96<0x3c?(_0x4406f9=_0x1e4c8b&_0x165579|_0x19c57e&(_0x1e4c8b|_0x165579),_0x252acd=0x8f1bbcdc):(_0x4406f9=_0x1e4c8b^_0x165579^_0x19c57e,_0x252acd=0xca62c1d6);const _0x3cceaa=(_0x50c9c2<<0x5|_0x50c9c2>>>0x1b)+_0x4406f9+_0x420263+_0x252acd+_0x591bbf[_0x2acf96]&0xffffffff;_0x420263=_0x19c57e,_0x19c57e=_0x165579,_0x165579=(_0x1e4c8b<<0x1e|_0x1e4c8b>>>0x2)&0xffffffff,_0x1e4c8b=_0x50c9c2,_0x50c9c2=_0x3cceaa;}this['chain_'][0x0]=this['chain_'][0x0]+_0x50c9c2&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1e4c8b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x165579&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x19c57e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x420263&0xffffffff;}['update'](_0x117789,_0x306c98){if(_0x117789==null)return;_0x306c98===void 0x0&&(_0x306c98=_0x117789['length']);const _0x24ae43=_0x306c98-this['blockSize'];let _0x36b79a=0x0;const _0x2ddbbb=this['buf_'];let _0x5d2a4c=this['inbuf_'];for(;_0x36b79a<_0x306c98;){if(_0x5d2a4c===0x0){for(;_0x36b79a<=_0x24ae43;)this['compress_'](_0x117789,_0x36b79a),_0x36b79a+=this['blockSize'];}if(typeof _0x117789=='string'){for(;_0x36b79a<_0x306c98;)if(_0x2ddbbb[_0x5d2a4c]=_0x117789['charCodeAt'](_0x36b79a),++_0x5d2a4c,++_0x36b79a,_0x5d2a4c===this['blockSize']){this['compress_'](_0x2ddbbb),_0x5d2a4c=0x0;break;}}else{for(;_0x36b79a<_0x306c98;)if(_0x2ddbbb[_0x5d2a4c]=_0x117789[_0x36b79a],++_0x5d2a4c,++_0x36b79a,_0x5d2a4c===this['blockSize']){this['compress_'](_0x2ddbbb),_0x5d2a4c=0x0;break;}}}this['inbuf_']=_0x5d2a4c,this['total_']+=_0x306c98;}['digest'](){const _0x36a05b=[];let _0x195f09=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x32673a=this['blockSize']-0x1;_0x32673a>=0x38;_0x32673a--)this['buf_'][_0x32673a]=_0x195f09&0xff,_0x195f09/=0x100;this['compress_'](this['buf_']);let _0xb5ed7=0x0;for(let _0x3f9358=0x0;_0x3f9358<0x5;_0x3f9358++)for(let _0x3e2e1e=0x18;_0x3e2e1e>=0x0;_0x3e2e1e-=0x8)_0x36a05b[_0xb5ed7]=this['chain_'][_0x3f9358]>>_0x3e2e1e&0xff,++_0xb5ed7;return _0x36a05b;}}function Ic(_0x8199e9,_0x440d49){const _0x3bd380=new wc(_0x8199e9,_0x440d49);return _0x3bd380['subscribe']['bind'](_0x3bd380);}class wc{constructor(_0x304293,_0xda47e1){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xda47e1,this['task']['then'](()=>{_0x304293(this);})['catch'](_0x57b07d=>{this['error'](_0x57b07d);});}['next'](_0x5235cf){this['forEachObserver'](_0x25b15b=>{_0x25b15b['next'](_0x5235cf);});}['error'](_0xfd94a8){this['forEachObserver'](_0x219c4a=>{_0x219c4a['error'](_0xfd94a8);}),this['close'](_0xfd94a8);}['complete'](){this['forEachObserver'](_0x184582=>{_0x184582['complete']();}),this['close']();}['subscribe'](_0x4f9ad3,_0x5d3c27,_0x3c1b04){let _0x239a81;if(_0x4f9ad3===void 0x0&&_0x5d3c27===void 0x0&&_0x3c1b04===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4f9ad3,['next','error','complete'])?_0x239a81=_0x4f9ad3:_0x239a81={'next':_0x4f9ad3,'error':_0x5d3c27,'complete':_0x3c1b04},_0x239a81['next']===void 0x0&&(_0x239a81['next']=Qn),_0x239a81['error']===void 0x0&&(_0x239a81['error']=Qn),_0x239a81['complete']===void 0x0&&(_0x239a81['complete']=Qn);const _0x3a0664=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x239a81['error'](this['finalError']):_0x239a81['complete']();}catch{}}),this['observers']['push'](_0x239a81),_0x3a0664;}['unsubscribeOne'](_0x3c8731){this['observers']===void 0x0||this['observers'][_0x3c8731]===void 0x0||(delete this['observers'][_0x3c8731],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x776ddb){if(!this['finalized']){for(let _0x453e79=0x0;_0x453e79<this['observers']['length'];_0x453e79++)this['sendOne'](_0x453e79,_0x776ddb);}}['sendOne'](_0xa99da,_0x16d095){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xa99da]!==void 0x0)try{_0x16d095(this['observers'][_0xa99da]);}catch(_0xc48648){typeof console<'u'&&console['error']&&console['error'](_0xc48648);}});}['close'](_0x137ae7){this['finalized']||(this['finalized']=!0x0,_0x137ae7!==void 0x0&&(this['finalError']=_0x137ae7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3fdf38,_0x550fe4){if(typeof _0x3fdf38!='object'||_0x3fdf38===null)return!0x1;for(const _0x12874f of _0x550fe4)if(_0x12874f in _0x3fdf38&&typeof _0x3fdf38[_0x12874f]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x38a952,_0x5a6faa){return _0x38a952+'\x20failed:\x20'+_0x5a6faa+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x56d117){const _0x42ae05=[];let _0x181f75=0x0;for(let _0x5a729c=0x0;_0x5a729c<_0x56d117['length'];_0x5a729c++){let _0x22e90a=_0x56d117['charCodeAt'](_0x5a729c);if(_0x22e90a>=0xd800&&_0x22e90a<=0xdbff){const _0x52ff71=_0x22e90a-0xd800;_0x5a729c++,f(_0x5a729c<_0x56d117['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x44f41e=_0x56d117['charCodeAt'](_0x5a729c)-0xdc00;_0x22e90a=0x10000+(_0x52ff71<<0xa)+_0x44f41e;}_0x22e90a<0x80?_0x42ae05[_0x181f75++]=_0x22e90a:_0x22e90a<0x800?(_0x42ae05[_0x181f75++]=_0x22e90a>>0x6|0xc0,_0x42ae05[_0x181f75++]=_0x22e90a&0x3f|0x80):_0x22e90a<0x10000?(_0x42ae05[_0x181f75++]=_0x22e90a>>0xc|0xe0,_0x42ae05[_0x181f75++]=_0x22e90a>>0x6&0x3f|0x80,_0x42ae05[_0x181f75++]=_0x22e90a&0x3f|0x80):(_0x42ae05[_0x181f75++]=_0x22e90a>>0x12|0xf0,_0x42ae05[_0x181f75++]=_0x22e90a>>0xc&0x3f|0x80,_0x42ae05[_0x181f75++]=_0x22e90a>>0x6&0x3f|0x80,_0x42ae05[_0x181f75++]=_0x22e90a&0x3f|0x80);}return _0x42ae05;},Pn=function(_0x46dd7d){let _0x2fa5a9=0x0;for(let _0x4af5db=0x0;_0x4af5db<_0x46dd7d['length'];_0x4af5db++){const _0x331b96=_0x46dd7d['charCodeAt'](_0x4af5db);_0x331b96<0x80?_0x2fa5a9++:_0x331b96<0x800?_0x2fa5a9+=0x2:_0x331b96>=0xd800&&_0x331b96<=0xdbff?(_0x2fa5a9+=0x4,_0x4af5db++):_0x2fa5a9+=0x3;}return _0x2fa5a9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4d5ca1){return _0x4d5ca1&&_0x4d5ca1['_delegate']?_0x4d5ca1['_delegate']:_0x4d5ca1;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x5bdf86){try{return(_0x5bdf86['startsWith']('http://')||_0x5bdf86['startsWith']('https://')?new URL(_0x5bdf86)['hostname']:_0x5bdf86)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x24d680){return(await fetch(_0x24d680,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4b013f,_0x40b993,_0x34cc73){this['name']=_0x4b013f,this['instanceFactory']=_0x40b993,this['type']=_0x34cc73,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x8a2b4d){return this['instantiationMode']=_0x8a2b4d,this;}['setMultipleInstances'](_0x1aedab){return this['multipleInstances']=_0x1aedab,this;}['setServiceProps'](_0x102825){return this['serviceProps']=_0x102825,this;}['setInstanceCreatedCallback'](_0x58de71){return this['onInstanceCreated']=_0x58de71,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x176936,_0x3b69ca){this['name']=_0x176936,this['container']=_0x3b69ca,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x211ebb){const _0x53aac7=this['normalizeInstanceIdentifier'](_0x211ebb);if(!this['instancesDeferred']['has'](_0x53aac7)){const _0x1cf50e=new Ve();if(this['instancesDeferred']['set'](_0x53aac7,_0x1cf50e),this['isInitialized'](_0x53aac7)||this['shouldAutoInitialize']())try{const _0x2e67db=this['getOrInitializeService']({'instanceIdentifier':_0x53aac7});_0x2e67db&&_0x1cf50e['resolve'](_0x2e67db);}catch{}}return this['instancesDeferred']['get'](_0x53aac7)['promise'];}['getImmediate'](_0xfef34d){const _0x368c7f=this['normalizeInstanceIdentifier'](_0xfef34d==null?void 0x0:_0xfef34d['identifier']),_0x4cba1a=(_0xfef34d==null?void 0x0:_0xfef34d['optional'])??!0x1;if(this['isInitialized'](_0x368c7f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x368c7f});}catch(_0x5ab78e){if(_0x4cba1a)return null;throw _0x5ab78e;}else{if(_0x4cba1a)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x230606){if(_0x230606['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x230606['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x230606,!!this['shouldAutoInitialize']()){if(Rc(_0x230606))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x9960bf,_0x40860e]of this['instancesDeferred']['entries']()){const _0x3e7ed2=this['normalizeInstanceIdentifier'](_0x9960bf);try{const _0x2dc1e0=this['getOrInitializeService']({'instanceIdentifier':_0x3e7ed2});_0x40860e['resolve'](_0x2dc1e0);}catch{}}}}['clearInstance'](_0x1344a4=ke){this['instancesDeferred']['delete'](_0x1344a4),this['instancesOptions']['delete'](_0x1344a4),this['instances']['delete'](_0x1344a4);}async['delete'](){const _0x281d01=Array['from'](this['instances']['values']());await Promise['all']([..._0x281d01['filter'](_0xd520bb=>'INTERNAL'in _0xd520bb)['map'](_0xb5f41f=>_0xb5f41f['INTERNAL']['delete']()),..._0x281d01['filter'](_0x1f7aad=>'_delete'in _0x1f7aad)['map'](_0x588873=>_0x588873['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xa40213=ke){return this['instances']['has'](_0xa40213);}['getOptions'](_0xb66623=ke){return this['instancesOptions']['get'](_0xb66623)||{};}['initialize'](_0xda615e={}){const {options:_0x3edae8={}}=_0xda615e,_0x18909b=this['normalizeInstanceIdentifier'](_0xda615e['instanceIdentifier']);if(this['isInitialized'](_0x18909b))throw Error(this['name']+'('+_0x18909b+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xa953d5=this['getOrInitializeService']({'instanceIdentifier':_0x18909b,'options':_0x3edae8});for(const [_0x3fa0b4,_0x57a602]of this['instancesDeferred']['entries']()){const _0x1724ee=this['normalizeInstanceIdentifier'](_0x3fa0b4);_0x18909b===_0x1724ee&&_0x57a602['resolve'](_0xa953d5);}return _0xa953d5;}['onInit'](_0x4ac62d,_0x345741){const _0x512095=this['normalizeInstanceIdentifier'](_0x345741),_0x921e99=this['onInitCallbacks']['get'](_0x512095)??new Set();_0x921e99['add'](_0x4ac62d),this['onInitCallbacks']['set'](_0x512095,_0x921e99);const _0x188e11=this['instances']['get'](_0x512095);return _0x188e11&&_0x4ac62d(_0x188e11,_0x512095),()=>{_0x921e99['delete'](_0x4ac62d);};}['invokeOnInitCallbacks'](_0x297376,_0x101a90){const _0x27e00d=this['onInitCallbacks']['get'](_0x101a90);if(_0x27e00d){for(const _0x3cd279 of _0x27e00d)try{_0x3cd279(_0x297376,_0x101a90);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5733a6,options:_0x40f1d6={}}){let _0x4dbb04=this['instances']['get'](_0x5733a6);if(!_0x4dbb04&&this['component']&&(_0x4dbb04=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5733a6),'options':_0x40f1d6}),this['instances']['set'](_0x5733a6,_0x4dbb04),this['instancesOptions']['set'](_0x5733a6,_0x40f1d6),this['invokeOnInitCallbacks'](_0x4dbb04,_0x5733a6),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5733a6,_0x4dbb04);}catch{}return _0x4dbb04||null;}['normalizeInstanceIdentifier'](_0x5c49eb=ke){return this['component']?this['component']['multipleInstances']?_0x5c49eb:ke:_0x5c49eb;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x5ad5cf){return _0x5ad5cf===ke?void 0x0:_0x5ad5cf;}function Rc(_0x459d6f){return _0x459d6f['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4c258b){this['name']=_0x4c258b,this['providers']=new Map();}['addComponent'](_0x518f5f){const _0x3eb7d9=this['getProvider'](_0x518f5f['name']);if(_0x3eb7d9['isComponentSet']())throw new Error('Component\x20'+_0x518f5f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3eb7d9['setComponent'](_0x518f5f);}['addOrOverwriteComponent'](_0x310ecd){this['getProvider'](_0x310ecd['name'])['isComponentSet']()&&this['providers']['delete'](_0x310ecd['name']),this['addComponent'](_0x310ecd);}['getProvider'](_0x144f06){if(this['providers']['has'](_0x144f06))return this['providers']['get'](_0x144f06);const _0x1a2d70=new Sc(_0x144f06,this);return this['providers']['set'](_0x144f06,_0x1a2d70),_0x1a2d70;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x56c9b9){_0x56c9b9[_0x56c9b9['DEBUG']=0x0]='DEBUG',_0x56c9b9[_0x56c9b9['VERBOSE']=0x1]='VERBOSE',_0x56c9b9[_0x56c9b9['INFO']=0x2]='INFO',_0x56c9b9[_0x56c9b9['WARN']=0x3]='WARN',_0x56c9b9[_0x56c9b9['ERROR']=0x4]='ERROR',_0x56c9b9[_0x56c9b9['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x1e2aa0,_0x1a9510,..._0x305579)=>{if(_0x1a9510<_0x1e2aa0['logLevel'])return;const _0x11ab7e=new Date()['toISOString'](),_0x50bb52=Pc[_0x1a9510];if(_0x50bb52)console[_0x50bb52]('['+_0x11ab7e+']\x20\x20'+_0x1e2aa0['name']+':',..._0x305579);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1a9510+')');};class xi{constructor(_0x214a90){this['name']=_0x214a90,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x8ee61e){if(!(_0x8ee61e in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x8ee61e+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x8ee61e;}['setLogLevel'](_0x840133){this['_logLevel']=typeof _0x840133=='string'?kc[_0x840133]:_0x840133;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2ead8d){if(typeof _0x2ead8d!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2ead8d;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x300153){this['_userLogHandler']=_0x300153;}['debug'](..._0x3e1dfb){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3e1dfb),this['_logHandler'](this,T['DEBUG'],..._0x3e1dfb);}['log'](..._0x4007eb){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4007eb),this['_logHandler'](this,T['VERBOSE'],..._0x4007eb);}['info'](..._0x4fd8d1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4fd8d1),this['_logHandler'](this,T['INFO'],..._0x4fd8d1);}['warn'](..._0x125684){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x125684),this['_logHandler'](this,T['WARN'],..._0x125684);}['error'](..._0x3eaa6e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3eaa6e),this['_logHandler'](this,T['ERROR'],..._0x3eaa6e);}}const Dc=(_0x21cc80,_0x8801ad)=>_0x8801ad['some'](_0x2f86e5=>_0x21cc80 instanceof _0x2f86e5);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x459493){const _0x360144=new Promise((_0x3d4091,_0x395710)=>{const _0x4d87c1=()=>{_0x459493['removeEventListener']('success',_0x4eda14),_0x459493['removeEventListener']('error',_0x2e8f06);},_0x4eda14=()=>{_0x3d4091(_e(_0x459493['result'])),_0x4d87c1();},_0x2e8f06=()=>{_0x395710(_0x459493['error']),_0x4d87c1();};_0x459493['addEventListener']('success',_0x4eda14),_0x459493['addEventListener']('error',_0x2e8f06);});return _0x360144['then'](_0x2fc411=>{_0x2fc411 instanceof IDBCursor&&Kr['set'](_0x2fc411,_0x459493);})['catch'](()=>{}),Fi['set'](_0x360144,_0x459493),_0x360144;}function Fc(_0x3d806e){if(ui['has'](_0x3d806e))return;const _0x426b04=new Promise((_0x412eeb,_0x41f169)=>{const _0x5e4180=()=>{_0x3d806e['removeEventListener']('complete',_0x502f70),_0x3d806e['removeEventListener']('error',_0x1eb140),_0x3d806e['removeEventListener']('abort',_0x1eb140);},_0x502f70=()=>{_0x412eeb(),_0x5e4180();},_0x1eb140=()=>{_0x41f169(_0x3d806e['error']||new DOMException('AbortError','AbortError')),_0x5e4180();};_0x3d806e['addEventListener']('complete',_0x502f70),_0x3d806e['addEventListener']('error',_0x1eb140),_0x3d806e['addEventListener']('abort',_0x1eb140);});ui['set'](_0x3d806e,_0x426b04);}let di={'get'(_0x7a9a53,_0x28af8e,_0x2ecf55){if(_0x7a9a53 instanceof IDBTransaction){if(_0x28af8e==='done')return ui['get'](_0x7a9a53);if(_0x28af8e==='objectStoreNames')return _0x7a9a53['objectStoreNames']||Yr['get'](_0x7a9a53);if(_0x28af8e==='store')return _0x2ecf55['objectStoreNames'][0x1]?void 0x0:_0x2ecf55['objectStore'](_0x2ecf55['objectStoreNames'][0x0]);}return _e(_0x7a9a53[_0x28af8e]);},'set'(_0x240f28,_0x5e29e0,_0x43b38f){return _0x240f28[_0x5e29e0]=_0x43b38f,!0x0;},'has'(_0x11d252,_0x4a583c){return _0x11d252 instanceof IDBTransaction&&(_0x4a583c==='done'||_0x4a583c==='store')?!0x0:_0x4a583c in _0x11d252;}};function Uc(_0x420aa5){di=_0x420aa5(di);}function Wc(_0x904cc4){return _0x904cc4===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x349232,..._0x4d343c){const _0x375183=_0x904cc4['call'](Xn(this),_0x349232,..._0x4d343c);return Yr['set'](_0x375183,_0x349232['sort']?_0x349232['sort']():[_0x349232]),_e(_0x375183);}:Lc()['includes'](_0x904cc4)?function(..._0x1c020d){return _0x904cc4['apply'](Xn(this),_0x1c020d),_e(Kr['get'](this));}:function(..._0x4f517a){return _e(_0x904cc4['apply'](Xn(this),_0x4f517a));};}function Bc(_0x43bc15){return typeof _0x43bc15=='function'?Wc(_0x43bc15):(_0x43bc15 instanceof IDBTransaction&&Fc(_0x43bc15),Dc(_0x43bc15,Mc())?new Proxy(_0x43bc15,di):_0x43bc15);}function _e(_0x2c6e56){if(_0x2c6e56 instanceof IDBRequest)return xc(_0x2c6e56);if(Jn['has'](_0x2c6e56))return Jn['get'](_0x2c6e56);const _0x342aa8=Bc(_0x2c6e56);return _0x342aa8!==_0x2c6e56&&(Jn['set'](_0x2c6e56,_0x342aa8),Fi['set'](_0x342aa8,_0x2c6e56)),_0x342aa8;}const Xn=_0x46a09e=>Fi['get'](_0x46a09e);function Vc(_0x9ba16,_0x1e8114,{blocked:_0x12d46e,upgrade:_0x451ba3,blocking:_0x39abbc,terminated:_0x4d8b9d}={}){const _0x46570f=indexedDB['open'](_0x9ba16,_0x1e8114),_0x5a55b0=_e(_0x46570f);return _0x451ba3&&_0x46570f['addEventListener']('upgradeneeded',_0xe21bef=>{_0x451ba3(_e(_0x46570f['result']),_0xe21bef['oldVersion'],_0xe21bef['newVersion'],_e(_0x46570f['transaction']),_0xe21bef);}),_0x12d46e&&_0x46570f['addEventListener']('blocked',_0x42e8d6=>_0x12d46e(_0x42e8d6['oldVersion'],_0x42e8d6['newVersion'],_0x42e8d6)),_0x5a55b0['then'](_0xfa7599=>{_0x4d8b9d&&_0xfa7599['addEventListener']('close',()=>_0x4d8b9d()),_0x39abbc&&_0xfa7599['addEventListener']('versionchange',_0x3a4731=>_0x39abbc(_0x3a4731['oldVersion'],_0x3a4731['newVersion'],_0x3a4731));})['catch'](()=>{}),_0x5a55b0;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x236bac,_0x260905){if(!(_0x236bac instanceof IDBDatabase&&!(_0x260905 in _0x236bac)&&typeof _0x260905=='string'))return;if(Zn['get'](_0x260905))return Zn['get'](_0x260905);const _0x417546=_0x260905['replace'](/FromIndex$/,''),_0x1e7b49=_0x260905!==_0x417546,_0xf57d91=$c['includes'](_0x417546);if(!(_0x417546 in(_0x1e7b49?IDBIndex:IDBObjectStore)['prototype'])||!(_0xf57d91||Hc['includes'](_0x417546)))return;const _0x3da119=async function(_0x4083da,..._0x13c227){const _0x36ac44=this['transaction'](_0x4083da,_0xf57d91?'readwrite':'readonly');let _0x143ef9=_0x36ac44['store'];return _0x1e7b49&&(_0x143ef9=_0x143ef9['index'](_0x13c227['shift']())),(await Promise['all']([_0x143ef9[_0x417546](..._0x13c227),_0xf57d91&&_0x36ac44['done']]))[0x0];};return Zn['set'](_0x260905,_0x3da119),_0x3da119;}Uc(_0x33c851=>({..._0x33c851,'get':(_0x455d81,_0x3069e6,_0x3c81fb)=>Os(_0x455d81,_0x3069e6)||_0x33c851['get'](_0x455d81,_0x3069e6,_0x3c81fb),'has':(_0x202736,_0x3c2a91)=>!!Os(_0x202736,_0x3c2a91)||_0x33c851['has'](_0x202736,_0x3c2a91)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x43c57e){this['container']=_0x43c57e;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x511a03=>{if(qc(_0x511a03)){const _0x139e97=_0x511a03['getImmediate']();return _0x139e97['library']+'/'+_0x139e97['version'];}else return null;})['filter'](_0x2540ef=>_0x2540ef)['join']('\x20');}}function qc(_0x4d72db){const _0x31ef4d=_0x4d72db['getComponent']();return(_0x31ef4d==null?void 0x0:_0x31ef4d['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x24e3a8,_0x5d40a8){try{_0x24e3a8['container']['addComponent'](_0x5d40a8);}catch(_0x3b4f32){re['debug']('Component\x20'+_0x5d40a8['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x24e3a8['name'],_0x3b4f32);}}function et(_0x154930){const _0x4fb3d6=_0x154930['name'];if(gi['has'](_0x4fb3d6))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4fb3d6+'.'),!0x1;gi['set'](_0x4fb3d6,_0x154930);for(const _0x202f1c of Le['values']())Ms(_0x202f1c,_0x154930);for(const _0x3697d3 of _i['values']())Ms(_0x3697d3,_0x154930);return!0x0;}function Ui(_0x10f1ee,_0x2739ac){const _0x43a897=_0x10f1ee['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x43a897&&_0x43a897['triggerHeartbeat'](),_0x10f1ee['container']['getProvider'](_0x2739ac);}function H(_0x1ab3a5){return _0x1ab3a5==null?!0x1:_0x1ab3a5['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x1bcd2a,_0x32f4b8,_0x2860ac){this['_isDeleted']=!0x1,this['_options']={..._0x1bcd2a},this['_config']={..._0x32f4b8},this['_name']=_0x32f4b8['name'],this['_automaticDataCollectionEnabled']=_0x32f4b8['automaticDataCollectionEnabled'],this['_container']=_0x2860ac,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x52e3dc){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x52e3dc;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2a3acb){this['_isDeleted']=_0x2a3acb;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5df1c4,_0x1bfe97={}){let _0x2655c6=_0x5df1c4;typeof _0x1bfe97!='object'&&(_0x1bfe97={'name':_0x1bfe97});const _0x3d46a8={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1bfe97},_0x629c0f=_0x3d46a8['name'];if(typeof _0x629c0f!='string'||!_0x629c0f)throw ge['create']('bad-app-name',{'appName':String(_0x629c0f)});if(_0x2655c6||(_0x2655c6=$r()),!_0x2655c6)throw ge['create']('no-options');const _0x53bb32=Le['get'](_0x629c0f);if(_0x53bb32){if(De(_0x2655c6,_0x53bb32['options'])&&De(_0x3d46a8,_0x53bb32['config']))return _0x53bb32;throw ge['create']('duplicate-app',{'appName':_0x629c0f});}const _0x324617=new Ac(_0x629c0f);for(const _0x35c619 of gi['values']())_0x324617['addComponent'](_0x35c619);const _0x417d70=new Il(_0x2655c6,_0x3d46a8,_0x324617);return Le['set'](_0x629c0f,_0x417d70),_0x417d70;}function Qr(_0x3601f2=pi){const _0x4b463c=Le['get'](_0x3601f2);if(!_0x4b463c&&_0x3601f2===pi&&$r())return wl();if(!_0x4b463c)throw ge['create']('no-app',{'appName':_0x3601f2});return _0x4b463c;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3587d4){let _0x10ea85=!0x1;const _0x1fe03b=_0x3587d4['name'];Le['has'](_0x1fe03b)?(_0x10ea85=!0x0,Le['delete'](_0x1fe03b)):_i['has'](_0x1fe03b)&&_0x3587d4['decRefCount']()<=0x0&&(_i['delete'](_0x1fe03b),_0x10ea85=!0x0),_0x10ea85&&(await Promise['all'](_0x3587d4['container']['getProviders']()['map'](_0x262813=>_0x262813['delete']())),_0x3587d4['isDeleted']=!0x0);}function me(_0x1980a8,_0x1fca50,_0x6bbcc9){let _0x5221bb=vl[_0x1980a8]??_0x1980a8;_0x6bbcc9&&(_0x5221bb+='-'+_0x6bbcc9);const _0x346afc=_0x5221bb['match'](/\s|\//),_0x301090=_0x1fca50['match'](/\s|\//);if(_0x346afc||_0x301090){const _0x22d601=['Unable\x20to\x20register\x20library\x20\x22'+_0x5221bb+'\x22\x20with\x20version\x20\x22'+_0x1fca50+'\x22:'];_0x346afc&&_0x22d601['push']('library\x20name\x20\x22'+_0x5221bb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x346afc&&_0x301090&&_0x22d601['push']('and'),_0x301090&&_0x22d601['push']('version\x20name\x20\x22'+_0x1fca50+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x22d601['join']('\x20'));return;}et(new Me(_0x5221bb+'-version',()=>({'library':_0x5221bb,'version':_0x1fca50}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x24aaa4,_0x2769b9)=>{switch(_0x2769b9){case 0x0:try{_0x24aaa4['createObjectStore'](Rt);}catch(_0x47fde6){console['warn'](_0x47fde6);}}}})['catch'](_0x4f74eb=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4f74eb['message']});})),ei;}async function Sl(_0x59c9f4){try{const _0x117523=(await Jr())['transaction'](Rt),_0x12eb26=await _0x117523['objectStore'](Rt)['get'](Xr(_0x59c9f4));return await _0x117523['done'],_0x12eb26;}catch(_0x42440c){if(_0x42440c instanceof Se)re['warn'](_0x42440c['message']);else{const _0x424482=ge['create']('idb-get',{'originalErrorMessage':_0x42440c==null?void 0x0:_0x42440c['message']});re['warn'](_0x424482['message']);}}}async function Ls(_0x28bef4,_0x50b110){try{const _0xa7ddf1=(await Jr())['transaction'](Rt,'readwrite');await _0xa7ddf1['objectStore'](Rt)['put'](_0x50b110,Xr(_0x28bef4)),await _0xa7ddf1['done'];}catch(_0x580f9f){if(_0x580f9f instanceof Se)re['warn'](_0x580f9f['message']);else{const _0x66781b=ge['create']('idb-set',{'originalErrorMessage':_0x580f9f==null?void 0x0:_0x580f9f['message']});re['warn'](_0x66781b['message']);}}}function Xr(_0x285f6f){return _0x285f6f['name']+'!'+_0x285f6f['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x270b8b){this['container']=_0x270b8b,this['_heartbeatsCache']=null;const _0x5aad61=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5aad61),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3db88a=>(this['_heartbeatsCache']=_0x3db88a,_0x3db88a));}async['triggerHeartbeat'](){var _0x4be9fa,_0x13ba5f;try{const _0x573b6d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2b3b66=xs();if(((_0x4be9fa=this['_heartbeatsCache'])==null?void 0x0:_0x4be9fa['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x13ba5f=this['_heartbeatsCache'])==null?void 0x0:_0x13ba5f['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2b3b66||this['_heartbeatsCache']['heartbeats']['some'](_0x243866=>_0x243866['date']===_0x2b3b66))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2b3b66,'agent':_0x573b6d}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x442cf9=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x442cf9,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x25b8c2){re['warn'](_0x25b8c2);}}async['getHeartbeatsHeader'](){var _0x1db0d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1db0d=this['_heartbeatsCache'])==null?void 0x0:_0x1db0d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5e86dc=xs(),{heartbeatsToSend:_0x1f9762,unsentEntries:_0x20e928}=kl(this['_heartbeatsCache']['heartbeats']),_0x425780=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1f9762}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5e86dc,_0x20e928['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x20e928,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x425780;}catch(_0x4f3740){return re['warn'](_0x4f3740),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0xaddff1,_0x295cab=bl){const _0x170eec=[];let _0x36f545=_0xaddff1['slice']();for(const _0x5b40c7 of _0xaddff1){const _0xf03b9c=_0x170eec['find'](_0x2c9367=>_0x2c9367['agent']===_0x5b40c7['agent']);if(_0xf03b9c){if(_0xf03b9c['dates']['push'](_0x5b40c7['date']),Fs(_0x170eec)>_0x295cab){_0xf03b9c['dates']['pop']();break;}}else{if(_0x170eec['push']({'agent':_0x5b40c7['agent'],'dates':[_0x5b40c7['date']]}),Fs(_0x170eec)>_0x295cab){_0x170eec['pop']();break;}}_0x36f545=_0x36f545['slice'](0x1);}return{'heartbeatsToSend':_0x170eec,'unsentEntries':_0x36f545};}class Nl{constructor(_0x254bec){this['app']=_0x254bec,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5cfa00=await Sl(this['app']);return _0x5cfa00!=null&&_0x5cfa00['heartbeats']?_0x5cfa00:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4edb0a){if(await this['_canUseIndexedDBPromise']){const _0x5d407a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4edb0a['lastSentHeartbeatDate']??_0x5d407a['lastSentHeartbeatDate'],'heartbeats':_0x4edb0a['heartbeats']});}else return;}async['add'](_0x565fbd){if(await this['_canUseIndexedDBPromise']){const _0x290ecb=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x565fbd['lastSentHeartbeatDate']??_0x290ecb['lastSentHeartbeatDate'],'heartbeats':[..._0x290ecb['heartbeats'],..._0x565fbd['heartbeats']]});}else return;}}function Fs(_0x1176cf){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1176cf}))['length'];}function Pl(_0x42e3dc){if(_0x42e3dc['length']===0x0)return-0x1;let _0x12e550=0x0,_0x4c0955=_0x42e3dc[0x0]['date'];for(let _0x47fc0d=0x1;_0x47fc0d<_0x42e3dc['length'];_0x47fc0d++)_0x42e3dc[_0x47fc0d]['date']<_0x4c0955&&(_0x4c0955=_0x42e3dc[_0x47fc0d]['date'],_0x12e550=_0x47fc0d);return _0x12e550;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x447d0a){et(new Me('platform-logger',_0xbe5daa=>new Gc(_0xbe5daa),'PRIVATE')),et(new Me('heartbeat',_0x5ae988=>new Al(_0x5ae988),'PRIVATE')),me(fi,Ds,_0x447d0a),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x4f76e8){Zr=_0x4f76e8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x3473c4){this['domStorage_']=_0x3473c4,this['prefix_']='firebase:';}['set'](_0x593cd5,_0x59c1cf){_0x59c1cf==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x593cd5)):this['domStorage_']['setItem'](this['prefixedName_'](_0x593cd5),O(_0x59c1cf));}['get'](_0x5f59b2){const _0x220fb0=this['domStorage_']['getItem'](this['prefixedName_'](_0x5f59b2));return _0x220fb0==null?null:bt(_0x220fb0);}['remove'](_0x4a91af){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4a91af));}['prefixedName_'](_0x4fb8bd){return this['prefix_']+_0x4fb8bd;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x59cd7a,_0x4798e3){_0x4798e3==null?delete this['cache_'][_0x59cd7a]:this['cache_'][_0x59cd7a]=_0x4798e3;}['get'](_0x47364d){return Y(this['cache_'],_0x47364d)?this['cache_'][_0x47364d]:null;}['remove'](_0x5694b7){delete this['cache_'][_0x5694b7];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x50ab64){try{if(typeof window<'u'&&typeof window[_0x50ab64]<'u'){const _0x454dee=window[_0x50ab64];return _0x454dee['setItem']('firebase:sentinel','cache'),_0x454dee['removeItem']('firebase:sentinel'),new xl(_0x454dee);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x2438d0=0x1;return function(){return _0x2438d0++;};}()),no=function(_0x21c467){const _0x329b76=Tc(_0x21c467),_0x30ad85=new Ec();_0x30ad85['update'](_0x329b76);const _0x27aa77=_0x30ad85['digest']();return Di['encodeByteArray'](_0x27aa77);},Bt=function(..._0x33334d){let _0x54884e='';for(let _0x16d8e0=0x0;_0x16d8e0<_0x33334d['length'];_0x16d8e0++){const _0x2a1570=_0x33334d[_0x16d8e0];Array['isArray'](_0x2a1570)||_0x2a1570&&typeof _0x2a1570=='object'&&typeof _0x2a1570['length']=='number'?_0x54884e+=Bt['apply'](null,_0x2a1570):typeof _0x2a1570=='object'?_0x54884e+=O(_0x2a1570):_0x54884e+=_0x2a1570,_0x54884e+='\x20';}return _0x54884e;};let Et=null,Vs=!0x0;const Wl=function(_0x31fa96,_0x8e0b50){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1902bc){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x2819a8=Bt['apply'](null,_0x1902bc);Et(_0x2819a8);}},Vt=function(_0x17be8d){return function(..._0x1dd968){L(_0x17be8d,..._0x1dd968);};},mi=function(..._0x5cbef1){const _0xa1eb4e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x5cbef1);Qe['error'](_0xa1eb4e);},oe=function(..._0x221a00){const _0x2ceb32='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x221a00);throw Qe['error'](_0x2ceb32),new Error(_0x2ceb32);},U=function(..._0x1fdca9){const _0x5de870='FIREBASE\x20WARNING:\x20'+Bt(..._0x1fdca9);Qe['warn'](_0x5de870);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x193311){return typeof _0x193311=='number'&&(_0x193311!==_0x193311||_0x193311===Number['POSITIVE_INFINITY']||_0x193311===Number['NEGATIVE_INFINITY']);},Vl=function(_0xbb1979){if(document['readyState']==='complete')_0xbb1979();else{let _0x2adca9=!0x1;const _0x5c3b25=function(){if(!document['body']){setTimeout(_0x5c3b25,Math['floor'](0xa));return;}_0x2adca9||(_0x2adca9=!0x0,_0xbb1979());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5c3b25,!0x1),window['addEventListener']('load',_0x5c3b25,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5c3b25();}),window['attachEvent']('onload',_0x5c3b25));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4ff476,_0x2ec262){if(_0x4ff476===_0x2ec262)return 0x0;if(_0x4ff476===xe||_0x2ec262===Ie)return-0x1;if(_0x2ec262===xe||_0x4ff476===Ie)return 0x1;{const _0x2c3a33=Hs(_0x4ff476),_0x46aad7=Hs(_0x2ec262);return _0x2c3a33!==null?_0x46aad7!==null?_0x2c3a33-_0x46aad7===0x0?_0x4ff476['length']-_0x2ec262['length']:_0x2c3a33-_0x46aad7:-0x1:_0x46aad7!==null?0x1:_0x4ff476<_0x2ec262?-0x1:0x1;}},Hl=function(_0x597a18,_0x436096){return _0x597a18===_0x436096?0x0:_0x597a18<_0x436096?-0x1:0x1;},pt=function(_0x595279,_0x44639a){if(_0x44639a&&_0x595279 in _0x44639a)return _0x44639a[_0x595279];throw new Error('Missing\x20required\x20key\x20('+_0x595279+')\x20in\x20object:\x20'+O(_0x44639a));},Bi=function(_0x575bdf){if(typeof _0x575bdf!='object'||_0x575bdf===null)return O(_0x575bdf);const _0x18104e=[];for(const _0x44fd63 in _0x575bdf)_0x18104e['push'](_0x44fd63);_0x18104e['sort']();let _0x114e65='{';for(let _0x4cf613=0x0;_0x4cf613<_0x18104e['length'];_0x4cf613++)_0x4cf613!==0x0&&(_0x114e65+=','),_0x114e65+=O(_0x18104e[_0x4cf613]),_0x114e65+=':',_0x114e65+=Bi(_0x575bdf[_0x18104e[_0x4cf613]]);return _0x114e65+='}',_0x114e65;},io=function(_0x40f420,_0x2c5423){const _0xfdaf19=_0x40f420['length'];if(_0xfdaf19<=_0x2c5423)return[_0x40f420];const _0x5d1813=[];for(let _0x432f2a=0x0;_0x432f2a<_0xfdaf19;_0x432f2a+=_0x2c5423)_0x432f2a+_0x2c5423>_0xfdaf19?_0x5d1813['push'](_0x40f420['substring'](_0x432f2a,_0xfdaf19)):_0x5d1813['push'](_0x40f420['substring'](_0x432f2a,_0x432f2a+_0x2c5423));return _0x5d1813;};function x(_0x129b30,_0x4f01cf){for(const _0x3fa76a in _0x129b30)_0x129b30['hasOwnProperty'](_0x3fa76a)&&_0x4f01cf(_0x3fa76a,_0x129b30[_0x3fa76a]);}const so=function(_0x1a6f57){f(!Wi(_0x1a6f57),'Invalid\x20JSON\x20number');const _0x51ed92=0xb,_0x3bc6a4=0x34,_0x2950c8=(0x1<<_0x51ed92-0x1)-0x1;let _0x3390fa,_0x30b394,_0x306b49,_0x405a5a,_0x492a0e;_0x1a6f57===0x0?(_0x30b394=0x0,_0x306b49=0x0,_0x3390fa=0x1/_0x1a6f57===-0x1/0x0?0x1:0x0):(_0x3390fa=_0x1a6f57<0x0,_0x1a6f57=Math['abs'](_0x1a6f57),_0x1a6f57>=Math['pow'](0x2,0x1-_0x2950c8)?(_0x405a5a=Math['min'](Math['floor'](Math['log'](_0x1a6f57)/Math['LN2']),_0x2950c8),_0x30b394=_0x405a5a+_0x2950c8,_0x306b49=Math['round'](_0x1a6f57*Math['pow'](0x2,_0x3bc6a4-_0x405a5a)-Math['pow'](0x2,_0x3bc6a4))):(_0x30b394=0x0,_0x306b49=Math['round'](_0x1a6f57/Math['pow'](0x2,0x1-_0x2950c8-_0x3bc6a4))));const _0x102065=[];for(_0x492a0e=_0x3bc6a4;_0x492a0e;_0x492a0e-=0x1)_0x102065['push'](_0x306b49%0x2?0x1:0x0),_0x306b49=Math['floor'](_0x306b49/0x2);for(_0x492a0e=_0x51ed92;_0x492a0e;_0x492a0e-=0x1)_0x102065['push'](_0x30b394%0x2?0x1:0x0),_0x30b394=Math['floor'](_0x30b394/0x2);_0x102065['push'](_0x3390fa?0x1:0x0),_0x102065['reverse']();const _0x50f947=_0x102065['join']('');let _0x571a4f='';for(_0x492a0e=0x0;_0x492a0e<0x40;_0x492a0e+=0x8){let _0x5e7a41=parseInt(_0x50f947['substr'](_0x492a0e,0x8),0x2)['toString'](0x10);_0x5e7a41['length']===0x1&&(_0x5e7a41='0'+_0x5e7a41),_0x571a4f=_0x571a4f+_0x5e7a41;}return _0x571a4f['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x476aae,_0x25a35b){let _0xb7b38='Unknown\x20Error';_0x476aae==='too_big'?_0xb7b38='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x476aae==='permission_denied'?_0xb7b38='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x476aae==='unavailable'&&(_0xb7b38='The\x20service\x20is\x20unavailable');const _0x34f72d=new Error(_0x476aae+'\x20at\x20'+_0x25a35b['_path']['toString']()+':\x20'+_0xb7b38);return _0x34f72d['code']=_0x476aae['toUpperCase'](),_0x34f72d;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0xdb463b){if(zl['test'](_0xdb463b)){const _0x31b2d9=Number(_0xdb463b);if(_0x31b2d9>=jl&&_0x31b2d9<=Kl)return _0x31b2d9;}return null;},lt=function(_0x1ee04a){try{_0x1ee04a();}catch(_0x2b5eb8){setTimeout(()=>{const _0x382e69=_0x2b5eb8['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x382e69),_0x2b5eb8;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0xabd6b4,_0x370dc5){const _0x4d7422=setTimeout(_0xabd6b4,_0x370dc5);return typeof _0x4d7422=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4d7422):typeof _0x4d7422=='object'&&_0x4d7422['unref']&&_0x4d7422['unref'](),_0x4d7422;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xaed3c7,_0x44e637){this['appCheckProvider']=_0x44e637,this['appName']=_0xaed3c7['name'],H(_0xaed3c7)&&_0xaed3c7['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xaed3c7['settings']['appCheckToken']),this['appCheck']=_0x44e637==null?void 0x0:_0x44e637['getImmediate']({'optional':!0x0}),this['appCheck']||_0x44e637==null||_0x44e637['get']()['then'](_0x3ce6df=>this['appCheck']=_0x3ce6df);}['getToken'](_0x2022a4){if(this['serverAppAppCheckToken']){if(_0x2022a4)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2022a4):new Promise((_0x28c355,_0x1bd5f1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2022a4)['then'](_0x28c355,_0x1bd5f1):_0x28c355(null);},0x0);});}['addTokenChangeListener'](_0xb6b55c){var _0x57ce8e;(_0x57ce8e=this['appCheckProvider'])==null||_0x57ce8e['get']()['then'](_0x50d6c3=>_0x50d6c3['addTokenListener'](_0xb6b55c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x28f458,_0x439f30,_0x4c8bba){this['appName_']=_0x28f458,this['firebaseOptions_']=_0x439f30,this['authProvider_']=_0x4c8bba,this['auth_']=null,this['auth_']=_0x4c8bba['getImmediate']({'optional':!0x0}),this['auth_']||_0x4c8bba['onInit'](_0x5ea66f=>this['auth_']=_0x5ea66f);}['getToken'](_0x34002a){return this['auth_']?this['auth_']['getToken'](_0x34002a)['catch'](_0x5ba920=>_0x5ba920&&_0x5ba920['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5ba920)):new Promise((_0x38a03e,_0x987211)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x34002a)['then'](_0x38a03e,_0x987211):_0x38a03e(null);},0x0);});}['addTokenChangeListener'](_0x3c2316){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3c2316):this['authProvider_']['get']()['then'](_0x13a942=>_0x13a942['addAuthTokenListener'](_0x3c2316));}['removeTokenChangeListener'](_0x10aba3){this['authProvider_']['get']()['then'](_0x4290f5=>_0x4290f5['removeAuthTokenListener'](_0x10aba3));}['notifyForInvalidToken'](){let _0x2477cd='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2477cd+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2477cd+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2477cd+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2477cd);}}class tn{constructor(_0x45a093){this['accessToken']=_0x45a093;}['getToken'](_0x24257c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x59f15b){_0x59f15b(this['accessToken']);}['removeTokenChangeListener'](_0x261e05){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x415eae,_0x2d2486,_0x27389c,_0x4bbf56,_0xcb06e6=!0x1,_0x569d4b='',_0x304275=!0x1,_0x4852fa=!0x1,_0x14c2d5=null){this['secure']=_0x2d2486,this['namespace']=_0x27389c,this['webSocketOnly']=_0x4bbf56,this['nodeAdmin']=_0xcb06e6,this['persistenceKey']=_0x569d4b,this['includeNamespaceInQueryParams']=_0x304275,this['isUsingEmulator']=_0x4852fa,this['emulatorOptions']=_0x14c2d5,this['_host']=_0x415eae['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x415eae)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x34b6ee){_0x34b6ee!==this['internalHost']&&(this['internalHost']=_0x34b6ee,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x21d8b2=this['toURLString']();return this['persistenceKey']&&(_0x21d8b2+='<'+this['persistenceKey']+'>'),_0x21d8b2;}['toURLString'](){const _0x37ed79=this['secure']?'https://':'http://',_0x525ab4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x37ed79+this['host']+'/'+_0x525ab4;}}function Xl(_0x122eac){return _0x122eac['host']!==_0x122eac['internalHost']||_0x122eac['isCustomHost']()||_0x122eac['includeNamespaceInQueryParams'];}function go(_0x314ffc,_0x5685d8,_0x198260){f(typeof _0x5685d8=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x198260=='object','typeof\x20params\x20must\x20==\x20object');let _0x43d605;if(_0x5685d8===fo)_0x43d605=(_0x314ffc['secure']?'wss://':'ws://')+_0x314ffc['internalHost']+'/.ws?';else{if(_0x5685d8===po)_0x43d605=(_0x314ffc['secure']?'https://':'http://')+_0x314ffc['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5685d8);}Xl(_0x314ffc)&&(_0x198260['ns']=_0x314ffc['namespace']);const _0x464e01=[];return x(_0x198260,(_0x2fb9eb,_0x141a0e)=>{_0x464e01['push'](_0x2fb9eb+'='+_0x141a0e);}),_0x43d605+_0x464e01['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x208a02,_0x528d99=0x1){Y(this['counters_'],_0x208a02)||(this['counters_'][_0x208a02]=0x0),this['counters_'][_0x208a02]+=_0x528d99;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5ebbd9){const _0x350e75=_0x5ebbd9['toString']();return ti[_0x350e75]||(ti[_0x350e75]=new Zl()),ti[_0x350e75];}function eh(_0x513c23,_0x50097f){const _0x39cf85=_0x513c23['toString']();return ni[_0x39cf85]||(ni[_0x39cf85]=_0x50097f()),ni[_0x39cf85];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4cf911){this['onMessage_']=_0x4cf911,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x48c7a5,_0xbaaff5){this['closeAfterResponse']=_0x48c7a5,this['onClose']=_0xbaaff5,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4b0fa4,_0x234790){for(this['pendingResponses'][_0x4b0fa4]=_0x234790;this['pendingResponses'][this['currentResponseNum']];){const _0x22a517=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3ac20a=0x0;_0x3ac20a<_0x22a517['length'];++_0x3ac20a)_0x22a517[_0x3ac20a]&&lt(()=>{this['onMessage_'](_0x22a517[_0x3ac20a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x3f1263,_0x109d00,_0x2111cd,_0x1ce2bf,_0x18dbd3,_0x357ea1,_0x29ea28){this['connId']=_0x3f1263,this['repoInfo']=_0x109d00,this['applicationId']=_0x2111cd,this['appCheckToken']=_0x1ce2bf,this['authToken']=_0x18dbd3,this['transportSessionId']=_0x357ea1,this['lastSessionId']=_0x29ea28,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x3f1263),this['stats_']=Hi(_0x109d00),this['urlFn']=_0x485f50=>(this['appCheckToken']&&(_0x485f50[yi]=this['appCheckToken']),go(_0x109d00,po,_0x485f50));}['open'](_0x5118f4,_0x88d9a7){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x88d9a7,this['myPacketOrderer']=new th(_0x5118f4),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x13097f)=>{const [_0x3576a7,_0x3c8edb,_0x9bce7d,_0x1ff8c0,_0x59f2f6]=_0x13097f;if(this['incrementIncomingBytes_'](_0x13097f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3576a7===$s)this['id']=_0x3c8edb,this['password']=_0x9bce7d;else{if(_0x3576a7===nh)_0x3c8edb?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3c8edb,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3576a7);}}},(..._0x55f9f8)=>{const [_0x4d66f9,_0x4db6ad]=_0x55f9f8;this['incrementIncomingBytes_'](_0x55f9f8),this['myPacketOrderer']['handleResponse'](_0x4d66f9,_0x4db6ad);},()=>{this['onClosed_']();},this['urlFn']);const _0x41d490={};_0x41d490[$s]='t',_0x41d490[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x41d490[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x41d490[ro]=Vi,this['transportSessionId']&&(_0x41d490[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x41d490[ho]=this['lastSessionId']),this['applicationId']&&(_0x41d490[uo]=this['applicationId']),this['appCheckToken']&&(_0x41d490[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x41d490[ao]=co);const _0x9e4db2=this['urlFn'](_0x41d490);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x9e4db2),this['scriptTagHolder']['addTag'](_0x9e4db2,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x33d62f){const _0x4b2942=O(_0x33d62f);this['bytesSent']+=_0x4b2942['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4b2942['length']);const _0x24c4cf=Br(_0x4b2942),_0x1a95f0=io(_0x24c4cf,hh);for(let _0x1e448c=0x0;_0x1e448c<_0x1a95f0['length'];_0x1e448c++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1a95f0['length'],_0x1a95f0[_0x1e448c]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5b2299,_0x2ba792){this['myDisconnFrame']=document['createElement']('iframe');const _0x4ce56a={};_0x4ce56a[lh]='t',_0x4ce56a[mo]=_0x5b2299,_0x4ce56a[yo]=_0x2ba792,this['myDisconnFrame']['src']=this['urlFn'](_0x4ce56a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2d8665){const _0x5e8d02=O(_0x2d8665)['length'];this['bytesReceived']+=_0x5e8d02,this['stats_']['incrementCounter']('bytes_received',_0x5e8d02);}}class $i{constructor(_0x3999aa,_0x86ed83,_0x4fcd31,_0x557dbf){this['onDisconnect']=_0x4fcd31,this['urlFn']=_0x557dbf,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x3999aa,window[sh+this['uniqueCallbackIdentifier']]=_0x86ed83,this['myIFrame']=$i['createIFrame_']();let _0x2f21a1='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2f21a1='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3091f3='<html><body>'+_0x2f21a1+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3091f3),this['myIFrame']['doc']['close']();}catch(_0x2619b3){L('frame\x20writing\x20exception'),_0x2619b3['stack']&&L(_0x2619b3['stack']),L(_0x2619b3);}}}static['createIFrame_'](){const _0x35ab79=document['createElement']('iframe');if(_0x35ab79['style']['display']='none',document['body']){document['body']['appendChild'](_0x35ab79);try{_0x35ab79['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2dd698=document['domain'];_0x35ab79['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2dd698+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x35ab79['contentDocument']?_0x35ab79['doc']=_0x35ab79['contentDocument']:_0x35ab79['contentWindow']?_0x35ab79['doc']=_0x35ab79['contentWindow']['document']:_0x35ab79['document']&&(_0x35ab79['doc']=_0x35ab79['document']),_0x35ab79;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x32c069=this['onDisconnect'];_0x32c069&&(this['onDisconnect']=null,_0x32c069());}['startLongPoll'](_0x249c8d,_0x1e8e5c){for(this['myID']=_0x249c8d,this['myPW']=_0x1e8e5c,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xe52be7={};_0xe52be7[mo]=this['myID'],_0xe52be7[yo]=this['myPW'],_0xe52be7[vo]=this['currentSerial'];let _0x11e9a9=this['urlFn'](_0xe52be7),_0x2a3284='',_0x4742b0=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2a3284['length']<=Eo;){const _0x34f09a=this['pendingSegs']['shift']();_0x2a3284=_0x2a3284+'&'+oh+_0x4742b0+'='+_0x34f09a['seg']+'&'+ah+_0x4742b0+'='+_0x34f09a['ts']+'&'+ch+_0x4742b0+'='+_0x34f09a['d'],_0x4742b0++;}return _0x11e9a9=_0x11e9a9+_0x2a3284,this['addLongPollTag_'](_0x11e9a9,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x94e55a,_0x34aa0b,_0x173478){this['pendingSegs']['push']({'seg':_0x94e55a,'ts':_0x34aa0b,'d':_0x173478}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xab746,_0x55916a){this['outstandingRequests']['add'](_0x55916a);const _0x2552ac=()=>{this['outstandingRequests']['delete'](_0x55916a),this['newRequest_']();},_0x20657d=setTimeout(_0x2552ac,Math['floor'](uh)),_0x2a0bfe=()=>{clearTimeout(_0x20657d),_0x2552ac();};this['addTag'](_0xab746,_0x2a0bfe);}['addTag'](_0x107234,_0x3bd453){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4c1a2f=this['myIFrame']['doc']['createElement']('script');_0x4c1a2f['type']='text/javascript',_0x4c1a2f['async']=!0x0,_0x4c1a2f['src']=_0x107234,_0x4c1a2f['onload']=_0x4c1a2f['onreadystatechange']=function(){const _0x5d14b2=_0x4c1a2f['readyState'];(!_0x5d14b2||_0x5d14b2==='loaded'||_0x5d14b2==='complete')&&(_0x4c1a2f['onload']=_0x4c1a2f['onreadystatechange']=null,_0x4c1a2f['parentNode']&&_0x4c1a2f['parentNode']['removeChild'](_0x4c1a2f),_0x3bd453());},_0x4c1a2f['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x107234),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4c1a2f);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x5e9962,_0x1a446f,_0x5c4b7d,_0x2a3846,_0x2600f6,_0x2fb220,_0x4d5c75){this['connId']=_0x5e9962,this['applicationId']=_0x5c4b7d,this['appCheckToken']=_0x2a3846,this['authToken']=_0x2600f6,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x1a446f),this['connURL']=G['connectionURL_'](_0x1a446f,_0x2fb220,_0x4d5c75,_0x2a3846,_0x5c4b7d),this['nodeAdmin']=_0x1a446f['nodeAdmin'];}static['connectionURL_'](_0x2e0e68,_0x1c3624,_0x4750b0,_0x29312a,_0x490526){const _0x1d315b={};return _0x1d315b[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1d315b[ao]=co),_0x1c3624&&(_0x1d315b[oo]=_0x1c3624),_0x4750b0&&(_0x1d315b[ho]=_0x4750b0),_0x29312a&&(_0x1d315b[yi]=_0x29312a),_0x490526&&(_0x1d315b[uo]=_0x490526),go(_0x2e0e68,fo,_0x1d315b);}['open'](_0x503496,_0x5def13){this['onDisconnect']=_0x5def13,this['onMessage']=_0x503496,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x40132d;dc(),this['mySock']=new hn(this['connURL'],[],_0x40132d);}catch(_0x46da93){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x25016d=_0x46da93['message']||_0x46da93['data'];_0x25016d&&this['log_'](_0x25016d),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x296141=>{this['handleIncomingFrame'](_0x296141);},this['mySock']['onerror']=_0x45ebc8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x13c0f7=_0x45ebc8['message']||_0x45ebc8['data'];_0x13c0f7&&this['log_'](_0x13c0f7),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x19bd2b=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5f0401=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x577e99=navigator['userAgent']['match'](_0x5f0401);_0x577e99&&_0x577e99['length']>0x1&&parseFloat(_0x577e99[0x1])<4.4&&(_0x19bd2b=!0x0);}return!_0x19bd2b&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4a5a4c){if(this['frames']['push'](_0x4a5a4c),this['frames']['length']===this['totalFrames']){const _0x2dc60e=this['frames']['join']('');this['frames']=null;const _0x50b1fb=bt(_0x2dc60e);this['onMessage'](_0x50b1fb);}}['handleNewFrameCount_'](_0x397e3d){this['totalFrames']=_0x397e3d,this['frames']=[];}['extractFrameCount_'](_0x39fa9e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x39fa9e['length']<=0x6){const _0x1d652b=Number(_0x39fa9e);if(!isNaN(_0x1d652b))return this['handleNewFrameCount_'](_0x1d652b),null;}return this['handleNewFrameCount_'](0x1),_0x39fa9e;}['handleIncomingFrame'](_0x2d7afc){if(this['mySock']===null)return;const _0xeaa659=_0x2d7afc['data'];if(this['bytesReceived']+=_0xeaa659['length'],this['stats_']['incrementCounter']('bytes_received',_0xeaa659['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xeaa659);else{const _0x5bb6b7=this['extractFrameCount_'](_0xeaa659);_0x5bb6b7!==null&&this['appendFrame_'](_0x5bb6b7);}}['send'](_0x58cde7){this['resetKeepAlive']();const _0xd7ab6e=O(_0x58cde7);this['bytesSent']+=_0xd7ab6e['length'],this['stats_']['incrementCounter']('bytes_sent',_0xd7ab6e['length']);const _0x47e7f3=io(_0xd7ab6e,fh);_0x47e7f3['length']>0x1&&this['sendString_'](String(_0x47e7f3['length']));for(let _0x43140e=0x0;_0x43140e<_0x47e7f3['length'];_0x43140e++)this['sendString_'](_0x47e7f3[_0x43140e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x33dc4f){try{this['mySock']['send'](_0x33dc4f);}catch(_0x14ded5){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x14ded5['message']||_0x14ded5['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1fe322){this['initTransports_'](_0x1fe322);}['initTransports_'](_0x3a58df){const _0x51efc0=G&&G['isAvailable']();let _0x3857f0=_0x51efc0&&!G['previouslyFailed']();if(_0x3a58df['webSocketOnly']&&(_0x51efc0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3857f0=!0x0),_0x3857f0)this['transports_']=[G];else{const _0x50bd47=this['transports_']=[];for(const _0x836b1 of At['ALL_TRANSPORTS'])_0x836b1&&_0x836b1['isAvailable']()&&_0x50bd47['push'](_0x836b1);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x1ea1ab,_0x2712c2,_0x4eb5ee,_0x4a67dc,_0x25091,_0x10dccf,_0x513c20,_0x4477d6,_0x75236a,_0x5ea516){this['id']=_0x1ea1ab,this['repoInfo_']=_0x2712c2,this['applicationId_']=_0x4eb5ee,this['appCheckToken_']=_0x4a67dc,this['authToken_']=_0x25091,this['onMessage_']=_0x10dccf,this['onReady_']=_0x513c20,this['onDisconnect_']=_0x4477d6,this['onKill_']=_0x75236a,this['lastSessionId']=_0x5ea516,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x2712c2),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1f5715=this['transportManager_']['initialTransport']();this['conn_']=new _0x1f5715(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1f5715['responsesRequiredToBeHealthy']||0x0;const _0x33fa11=this['connReceiver_'](this['conn_']),_0x3bedd1=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x33fa11,_0x3bedd1);},Math['floor'](0x0));const _0x226390=_0x1f5715['healthyTimeout']||0x0;_0x226390>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x226390)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5a80e3){return _0x63c72f=>{_0x5a80e3===this['conn_']?this['onConnectionLost_'](_0x63c72f):_0x5a80e3===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4bb555){return _0x4793c5=>{this['state_']!==0x2&&(_0x4bb555===this['rx_']?this['onPrimaryMessageReceived_'](_0x4793c5):_0x4bb555===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4793c5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x27ac03){const _0x5d0d42={'t':'d','d':_0x27ac03};this['sendData_'](_0x5d0d42);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xfba895){if(ii in _0xfba895){const _0x2f6bdd=_0xfba895[ii];_0x2f6bdd===js?this['upgradeIfSecondaryHealthy_']():_0x2f6bdd===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2f6bdd===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3b1d81){const _0x17aa6c=pt('t',_0x3b1d81),_0x87227c=pt('d',_0x3b1d81);if(_0x17aa6c==='c')this['onSecondaryControl_'](_0x87227c);else{if(_0x17aa6c==='d')this['pendingDataMessages']['push'](_0x87227c);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x17aa6c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1f1837){const _0x1c3992=pt('t',_0x1f1837),_0x509429=pt('d',_0x1f1837);_0x1c3992==='c'?this['onControl_'](_0x509429):_0x1c3992==='d'&&this['onDataMessage_'](_0x509429);}['onDataMessage_'](_0x5a525e){this['onPrimaryResponse_'](),this['onMessage_'](_0x5a525e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x30860e){const _0x4c787b=pt(ii,_0x30860e);if(Gs in _0x30860e){const _0x3b3ff8=_0x30860e[Gs];if(_0x4c787b===Ih){const _0xeddc1f={..._0x3b3ff8};this['repoInfo_']['isUsingEmulator']&&(_0xeddc1f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xeddc1f);}else{if(_0x4c787b===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3d7962=0x0;_0x3d7962<this['pendingDataMessages']['length'];++_0x3d7962)this['onDataMessage_'](this['pendingDataMessages'][_0x3d7962]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4c787b===vh?this['onConnectionShutdown_'](_0x3b3ff8):_0x4c787b===qs?this['onReset_'](_0x3b3ff8):_0x4c787b===Eh?mi('Server\x20Error:\x20'+_0x3b3ff8):_0x4c787b===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x4c787b);}}}['onHandshake_'](_0x3c3f8a){const _0x57a864=_0x3c3f8a['ts'],_0x95cd4d=_0x3c3f8a['v'],_0x15d250=_0x3c3f8a['h'];this['sessionId']=_0x3c3f8a['s'],this['repoInfo_']['host']=_0x15d250,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x57a864),Vi!==_0x95cd4d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x173bd0=this['transportManager_']['upgradeTransport']();_0x173bd0&&this['startUpgrade_'](_0x173bd0);}['startUpgrade_'](_0xf8a155){this['secondaryConn_']=new _0xf8a155(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xf8a155['responsesRequiredToBeHealthy']||0x0;const _0x1f1c1f=this['connReceiver_'](this['secondaryConn_']),_0x309667=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1f1c1f,_0x309667),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x3132c3){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3132c3),this['repoInfo_']['host']=_0x3132c3,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x591c2e,_0xec4123){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x591c2e,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xec4123,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x1c4a45=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x1c4a45||this['rx_']===_0x1c4a45)&&this['close']();}['onConnectionLost_'](_0x381fd3){this['conn_']=null,!_0x381fd3&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2db392){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2db392),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x275358){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x275358);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x40b661,_0x26af51,_0x2528de,_0x4bdaed){}['merge'](_0x47ae68,_0x34688e,_0x1c82d2,_0x294762){}['refreshAuthToken'](_0x58b561){}['refreshAppCheckToken'](_0x4f18e8){}['onDisconnectPut'](_0x10c4d1,_0xeaeff8,_0x4801a4){}['onDisconnectMerge'](_0x225c9f,_0x299dbb,_0x1f2835){}['onDisconnectCancel'](_0x4a511d,_0x3513a4){}['reportStats'](_0x298dc4){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4b16fe){this['allowedEvents_']=_0x4b16fe,this['listeners_']={},f(Array['isArray'](_0x4b16fe)&&_0x4b16fe['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x34f5bf,..._0x2951b7){if(Array['isArray'](this['listeners_'][_0x34f5bf])){const _0x5b4043=[...this['listeners_'][_0x34f5bf]];for(let _0x137d99=0x0;_0x137d99<_0x5b4043['length'];_0x137d99++)_0x5b4043[_0x137d99]['callback']['apply'](_0x5b4043[_0x137d99]['context'],_0x2951b7);}}['on'](_0x33c6db,_0x264aa0,_0x40ee98){this['validateEventType_'](_0x33c6db),this['listeners_'][_0x33c6db]=this['listeners_'][_0x33c6db]||[],this['listeners_'][_0x33c6db]['push']({'callback':_0x264aa0,'context':_0x40ee98});const _0x40822f=this['getInitialEvent'](_0x33c6db);_0x40822f&&_0x264aa0['apply'](_0x40ee98,_0x40822f);}['off'](_0xe21630,_0x2885fc,_0x22969a){this['validateEventType_'](_0xe21630);const _0x27959a=this['listeners_'][_0xe21630]||[];for(let _0x57043d=0x0;_0x57043d<_0x27959a['length'];_0x57043d++)if(_0x27959a[_0x57043d]['callback']===_0x2885fc&&(!_0x22969a||_0x22969a===_0x27959a[_0x57043d]['context'])){_0x27959a['splice'](_0x57043d,0x1);return;}}['validateEventType_'](_0x341e41){f(this['allowedEvents_']['find'](_0x18b402=>_0x18b402===_0x341e41),'Unknown\x20event:\x20'+_0x341e41);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3aca65){return f(_0x3aca65==='online','Unknown\x20event\x20type:\x20'+_0x3aca65),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x53ae90,_0x1b18cd){if(_0x1b18cd===void 0x0){this['pieces_']=_0x53ae90['split']('/');let _0x34a434=0x0;for(let _0x2bb869=0x0;_0x2bb869<this['pieces_']['length'];_0x2bb869++)this['pieces_'][_0x2bb869]['length']>0x0&&(this['pieces_'][_0x34a434]=this['pieces_'][_0x2bb869],_0x34a434++);this['pieces_']['length']=_0x34a434,this['pieceNum_']=0x0;}else this['pieces_']=_0x53ae90,this['pieceNum_']=_0x1b18cd;}['toString'](){let _0x5406a1='';for(let _0x4e3f09=this['pieceNum_'];_0x4e3f09<this['pieces_']['length'];_0x4e3f09++)this['pieces_'][_0x4e3f09]!==''&&(_0x5406a1+='/'+this['pieces_'][_0x4e3f09]);return _0x5406a1||'/';}}function w(){return new C('');}function y(_0xa2ccc7){return _0xa2ccc7['pieceNum_']>=_0xa2ccc7['pieces_']['length']?null:_0xa2ccc7['pieces_'][_0xa2ccc7['pieceNum_']];}function we(_0xefa7b2){return _0xefa7b2['pieces_']['length']-_0xefa7b2['pieceNum_'];}function b(_0x5afbf9){let _0x309d57=_0x5afbf9['pieceNum_'];return _0x309d57<_0x5afbf9['pieces_']['length']&&_0x309d57++,new C(_0x5afbf9['pieces_'],_0x309d57);}function Gi(_0xa53cd4){return _0xa53cd4['pieceNum_']<_0xa53cd4['pieces_']['length']?_0xa53cd4['pieces_'][_0xa53cd4['pieces_']['length']-0x1]:null;}function Ch(_0x182550){let _0x5988ea='';for(let _0x4433dc=_0x182550['pieceNum_'];_0x4433dc<_0x182550['pieces_']['length'];_0x4433dc++)_0x182550['pieces_'][_0x4433dc]!==''&&(_0x5988ea+='/'+encodeURIComponent(String(_0x182550['pieces_'][_0x4433dc])));return _0x5988ea||'/';}function kt(_0x51747e,_0x2a1f62=0x0){return _0x51747e['pieces_']['slice'](_0x51747e['pieceNum_']+_0x2a1f62);}function To(_0x298b51){if(_0x298b51['pieceNum_']>=_0x298b51['pieces_']['length'])return null;const _0x49006f=[];for(let _0x1aea7f=_0x298b51['pieceNum_'];_0x1aea7f<_0x298b51['pieces_']['length']-0x1;_0x1aea7f++)_0x49006f['push'](_0x298b51['pieces_'][_0x1aea7f]);return new C(_0x49006f,0x0);}function A(_0x5c16a7,_0x1e0590){const _0x18ee4a=[];for(let _0x2ba684=_0x5c16a7['pieceNum_'];_0x2ba684<_0x5c16a7['pieces_']['length'];_0x2ba684++)_0x18ee4a['push'](_0x5c16a7['pieces_'][_0x2ba684]);if(_0x1e0590 instanceof C){for(let _0x47b5c9=_0x1e0590['pieceNum_'];_0x47b5c9<_0x1e0590['pieces_']['length'];_0x47b5c9++)_0x18ee4a['push'](_0x1e0590['pieces_'][_0x47b5c9]);}else{const _0x55d740=_0x1e0590['split']('/');for(let _0x518a7c=0x0;_0x518a7c<_0x55d740['length'];_0x518a7c++)_0x55d740[_0x518a7c]['length']>0x0&&_0x18ee4a['push'](_0x55d740[_0x518a7c]);}return new C(_0x18ee4a,0x0);}function v(_0x18dd3d){return _0x18dd3d['pieceNum_']>=_0x18dd3d['pieces_']['length'];}function F(_0x1f418c,_0x572a6d){const _0x34db57=y(_0x1f418c),_0x396a31=y(_0x572a6d);if(_0x34db57===null)return _0x572a6d;if(_0x34db57===_0x396a31)return F(b(_0x1f418c),b(_0x572a6d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x572a6d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1f418c+')');}function Th(_0x204621,_0x3b7999){const _0x18a45d=kt(_0x204621,0x0),_0x37fbbe=kt(_0x3b7999,0x0);for(let _0x480f53=0x0;_0x480f53<_0x18a45d['length']&&_0x480f53<_0x37fbbe['length'];_0x480f53++){const _0xcc9274=He(_0x18a45d[_0x480f53],_0x37fbbe[_0x480f53]);if(_0xcc9274!==0x0)return _0xcc9274;}return _0x18a45d['length']===_0x37fbbe['length']?0x0:_0x18a45d['length']<_0x37fbbe['length']?-0x1:0x1;}function qi(_0x3cd7ea,_0x372550){if(we(_0x3cd7ea)!==we(_0x372550))return!0x1;for(let _0x5003bf=_0x3cd7ea['pieceNum_'],_0x5983fe=_0x372550['pieceNum_'];_0x5003bf<=_0x3cd7ea['pieces_']['length'];_0x5003bf++,_0x5983fe++)if(_0x3cd7ea['pieces_'][_0x5003bf]!==_0x372550['pieces_'][_0x5983fe])return!0x1;return!0x0;}function $(_0x4cc763,_0x25b608){let _0x7d4d3e=_0x4cc763['pieceNum_'],_0x1a3122=_0x25b608['pieceNum_'];if(we(_0x4cc763)>we(_0x25b608))return!0x1;for(;_0x7d4d3e<_0x4cc763['pieces_']['length'];){if(_0x4cc763['pieces_'][_0x7d4d3e]!==_0x25b608['pieces_'][_0x1a3122])return!0x1;++_0x7d4d3e,++_0x1a3122;}return!0x0;}class Sh{constructor(_0x39c4e2,_0x3c8539){this['errorPrefix_']=_0x3c8539,this['parts_']=kt(_0x39c4e2,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xe95f5=0x0;_0xe95f5<this['parts_']['length'];_0xe95f5++)this['byteLength_']+=Pn(this['parts_'][_0xe95f5]);So(this);}}function bh(_0xcbcd5c,_0x277f7b){_0xcbcd5c['parts_']['length']>0x0&&(_0xcbcd5c['byteLength_']+=0x1),_0xcbcd5c['parts_']['push'](_0x277f7b),_0xcbcd5c['byteLength_']+=Pn(_0x277f7b),So(_0xcbcd5c);}function Rh(_0x158def){const _0x17e7c3=_0x158def['parts_']['pop']();_0x158def['byteLength_']-=Pn(_0x17e7c3),_0x158def['parts_']['length']>0x0&&(_0x158def['byteLength_']-=0x1);}function So(_0xe1838c){if(_0xe1838c['byteLength_']>Js)throw new Error(_0xe1838c['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0xe1838c['byteLength_']+').');if(_0xe1838c['parts_']['length']>Qs)throw new Error(_0xe1838c['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0xe1838c));}function Ne(_0x2ef565){return _0x2ef565['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2ef565['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x2d0bd7,_0x14e87d;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x14e87d='visibilitychange',_0x2d0bd7='hidden'):typeof document['mozHidden']<'u'?(_0x14e87d='mozvisibilitychange',_0x2d0bd7='mozHidden'):typeof document['msHidden']<'u'?(_0x14e87d='msvisibilitychange',_0x2d0bd7='msHidden'):typeof document['webkitHidden']<'u'&&(_0x14e87d='webkitvisibilitychange',_0x2d0bd7='webkitHidden')),this['visible_']=!0x0,_0x14e87d&&document['addEventListener'](_0x14e87d,()=>{const _0x11dae8=!document[_0x2d0bd7];_0x11dae8!==this['visible_']&&(this['visible_']=_0x11dae8,this['trigger']('visible',_0x11dae8));},!0x1);}['getInitialEvent'](_0x1734ab){return f(_0x1734ab==='visible','Unknown\x20event\x20type:\x20'+_0x1734ab),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x4ac929,_0x1b9fc8,_0x40c7a9,_0x3bf581,_0x40d6a3,_0x393198,_0x35e2e4,_0xd192bc){if(super(),this['repoInfo_']=_0x4ac929,this['applicationId_']=_0x1b9fc8,this['onDataUpdate_']=_0x40c7a9,this['onConnectStatus_']=_0x3bf581,this['onServerInfoUpdate_']=_0x40d6a3,this['authTokenProvider_']=_0x393198,this['appCheckTokenProvider_']=_0x35e2e4,this['authOverride_']=_0xd192bc,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xd192bc)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4ac929['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x410141,_0x1f8c30,_0x4743a8){const _0x5c7acb=++this['requestNumber_'],_0x5dedaf={'r':_0x5c7acb,'a':_0x410141,'b':_0x1f8c30};this['log_'](O(_0x5dedaf)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5dedaf),_0x4743a8&&(this['requestCBHash_'][_0x5c7acb]=_0x4743a8);}['get'](_0x28014d){this['initConnection_']();const _0x89f04c=new Ve(),_0x3ed8af={'action':'g','request':{'p':_0x28014d['_path']['toString'](),'q':_0x28014d['_queryObject']},'onComplete':_0xdd8571=>{const _0x49eb02=_0xdd8571['d'];_0xdd8571['s']==='ok'?_0x89f04c['resolve'](_0x49eb02):_0x89f04c['reject'](_0x49eb02);}};this['outstandingGets_']['push'](_0x3ed8af),this['outstandingGetCount_']++;const _0x14d11e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x14d11e),_0x89f04c['promise'];}['listen'](_0x275889,_0x3eaae2,_0x24a324,_0x1737b6){this['initConnection_']();const _0x4e156=_0x275889['_queryIdentifier'],_0x4ff3dc=_0x275889['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4ff3dc+'\x20'+_0x4e156),this['listens']['has'](_0x4ff3dc)||this['listens']['set'](_0x4ff3dc,new Map()),f(_0x275889['_queryParams']['isDefault']()||!_0x275889['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4ff3dc)['has'](_0x4e156),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2ac747={'onComplete':_0x1737b6,'hashFn':_0x3eaae2,'query':_0x275889,'tag':_0x24a324};this['listens']['get'](_0x4ff3dc)['set'](_0x4e156,_0x2ac747),this['connected_']&&this['sendListen_'](_0x2ac747);}['sendGet_'](_0x238121){const _0x3b5ba3=this['outstandingGets_'][_0x238121];this['sendRequest']('g',_0x3b5ba3['request'],_0x15d2dd=>{delete this['outstandingGets_'][_0x238121],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3b5ba3['onComplete']&&_0x3b5ba3['onComplete'](_0x15d2dd);});}['sendListen_'](_0x4a6962){const _0x272c6e=_0x4a6962['query'],_0x4580b5=_0x272c6e['_path']['toString'](),_0x513846=_0x272c6e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4580b5+'\x20for\x20'+_0x513846);const _0x2dad9a={'p':_0x4580b5},_0x4ed5c9='q';_0x4a6962['tag']&&(_0x2dad9a['q']=_0x272c6e['_queryObject'],_0x2dad9a['t']=_0x4a6962['tag']),_0x2dad9a['h']=_0x4a6962['hashFn'](),this['sendRequest'](_0x4ed5c9,_0x2dad9a,_0x2c5657=>{const _0x52e3d0=_0x2c5657['d'],_0x3f67b4=_0x2c5657['s'];ie['warnOnListenWarnings_'](_0x52e3d0,_0x272c6e),(this['listens']['get'](_0x4580b5)&&this['listens']['get'](_0x4580b5)['get'](_0x513846))===_0x4a6962&&(this['log_']('listen\x20response',_0x2c5657),_0x3f67b4!=='ok'&&this['removeListen_'](_0x4580b5,_0x513846),_0x4a6962['onComplete']&&_0x4a6962['onComplete'](_0x3f67b4,_0x52e3d0));});}static['warnOnListenWarnings_'](_0x5dc155,_0x43daa4){if(_0x5dc155&&typeof _0x5dc155=='object'&&Y(_0x5dc155,'w')){const _0x5efaff=Oe(_0x5dc155,'w');if(Array['isArray'](_0x5efaff)&&~_0x5efaff['indexOf']('no_index')){const _0x2c8648='\x22.indexOn\x22:\x20\x22'+_0x43daa4['_queryParams']['getIndex']()['toString']()+'\x22',_0x5e08d3=_0x43daa4['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2c8648+'\x20at\x20'+_0x5e08d3+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x47799c){this['authToken_']=_0x47799c,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x47799c);}['reduceReconnectDelayIfAdminCredential_'](_0x39cb23){(_0x39cb23&&_0x39cb23['length']===0x28||vc(_0x39cb23))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x35f358){this['appCheckToken_']=_0x35f358,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x57144b=this['authToken_'],_0x39343a=yc(_0x57144b)?'auth':'gauth',_0x303231={'cred':_0x57144b};this['authOverride_']===null?_0x303231['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x303231['authvar']=this['authOverride_']),this['sendRequest'](_0x39343a,_0x303231,_0x36b62e=>{const _0x3d9d38=_0x36b62e['s'],_0x5c89e9=_0x36b62e['d']||'error';this['authToken_']===_0x57144b&&(_0x3d9d38==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3d9d38,_0x5c89e9));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x421a4d=>{const _0x14606b=_0x421a4d['s'],_0x2c46dd=_0x421a4d['d']||'error';_0x14606b==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x14606b,_0x2c46dd);});}['unlisten'](_0x2faf68,_0x55df38){const _0x46863c=_0x2faf68['_path']['toString'](),_0x2e3eef=_0x2faf68['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x46863c+'\x20'+_0x2e3eef),f(_0x2faf68['_queryParams']['isDefault']()||!_0x2faf68['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x46863c,_0x2e3eef)&&this['connected_']&&this['sendUnlisten_'](_0x46863c,_0x2e3eef,_0x2faf68['_queryObject'],_0x55df38);}['sendUnlisten_'](_0x1ea97b,_0x5722d8,_0x59cedb,_0x611305){this['log_']('Unlisten\x20on\x20'+_0x1ea97b+'\x20for\x20'+_0x5722d8);const _0x5b7135={'p':_0x1ea97b},_0x55ff28='n';_0x611305&&(_0x5b7135['q']=_0x59cedb,_0x5b7135['t']=_0x611305),this['sendRequest'](_0x55ff28,_0x5b7135);}['onDisconnectPut'](_0xc422b6,_0x59ab93,_0x585e37){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0xc422b6,_0x59ab93,_0x585e37):this['onDisconnectRequestQueue_']['push']({'pathString':_0xc422b6,'action':'o','data':_0x59ab93,'onComplete':_0x585e37});}['onDisconnectMerge'](_0x192603,_0x435b6e,_0x4add81){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x192603,_0x435b6e,_0x4add81):this['onDisconnectRequestQueue_']['push']({'pathString':_0x192603,'action':'om','data':_0x435b6e,'onComplete':_0x4add81});}['onDisconnectCancel'](_0xfd0c7d,_0x1ffd35){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xfd0c7d,null,_0x1ffd35):this['onDisconnectRequestQueue_']['push']({'pathString':_0xfd0c7d,'action':'oc','data':null,'onComplete':_0x1ffd35});}['sendOnDisconnect_'](_0x4fd421,_0x130a5d,_0xd6761,_0x2d8ab7){const _0x158658={'p':_0x130a5d,'d':_0xd6761};this['log_']('onDisconnect\x20'+_0x4fd421,_0x158658),this['sendRequest'](_0x4fd421,_0x158658,_0x373f4f=>{_0x2d8ab7&&setTimeout(()=>{_0x2d8ab7(_0x373f4f['s'],_0x373f4f['d']);},Math['floor'](0x0));});}['put'](_0x40730a,_0x18d027,_0x2c22a2,_0x12d81c){this['putInternal']('p',_0x40730a,_0x18d027,_0x2c22a2,_0x12d81c);}['merge'](_0x1c7edf,_0x3b48dc,_0x3ce581,_0x3b6bd9){this['putInternal']('m',_0x1c7edf,_0x3b48dc,_0x3ce581,_0x3b6bd9);}['putInternal'](_0x18f77e,_0x846364,_0x56de20,_0x5b4736,_0x29e95a){this['initConnection_']();const _0x3c5bca={'p':_0x846364,'d':_0x56de20};_0x29e95a!==void 0x0&&(_0x3c5bca['h']=_0x29e95a),this['outstandingPuts_']['push']({'action':_0x18f77e,'request':_0x3c5bca,'onComplete':_0x5b4736}),this['outstandingPutCount_']++;const _0x306d62=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x306d62):this['log_']('Buffering\x20put:\x20'+_0x846364);}['sendPut_'](_0x22675a){const _0x1adfed=this['outstandingPuts_'][_0x22675a]['action'],_0x4d1be2=this['outstandingPuts_'][_0x22675a]['request'],_0x382c42=this['outstandingPuts_'][_0x22675a]['onComplete'];this['outstandingPuts_'][_0x22675a]['queued']=this['connected_'],this['sendRequest'](_0x1adfed,_0x4d1be2,_0x4a1d7c=>{this['log_'](_0x1adfed+'\x20response',_0x4a1d7c),delete this['outstandingPuts_'][_0x22675a],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x382c42&&_0x382c42(_0x4a1d7c['s'],_0x4a1d7c['d']);});}['reportStats'](_0x50820f){if(this['connected_']){const _0x26e3ef={'c':_0x50820f};this['log_']('reportStats',_0x26e3ef),this['sendRequest']('s',_0x26e3ef,_0x1efa00=>{if(_0x1efa00['s']!=='ok'){const _0x3d473d=_0x1efa00['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3d473d);}});}}['onDataMessage_'](_0x12208b){if('r'in _0x12208b){this['log_']('from\x20server:\x20'+O(_0x12208b));const _0x4a2941=_0x12208b['r'],_0x17a222=this['requestCBHash_'][_0x4a2941];_0x17a222&&(delete this['requestCBHash_'][_0x4a2941],_0x17a222(_0x12208b['b']));}else{if('error'in _0x12208b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x12208b['error'];'a'in _0x12208b&&this['onDataPush_'](_0x12208b['a'],_0x12208b['b']);}}['onDataPush_'](_0x323df0,_0x94749){this['log_']('handleServerMessage',_0x323df0,_0x94749),_0x323df0==='d'?this['onDataUpdate_'](_0x94749['p'],_0x94749['d'],!0x1,_0x94749['t']):_0x323df0==='m'?this['onDataUpdate_'](_0x94749['p'],_0x94749['d'],!0x0,_0x94749['t']):_0x323df0==='c'?this['onListenRevoked_'](_0x94749['p'],_0x94749['q']):_0x323df0==='ac'?this['onAuthRevoked_'](_0x94749['s'],_0x94749['d']):_0x323df0==='apc'?this['onAppCheckRevoked_'](_0x94749['s'],_0x94749['d']):_0x323df0==='sd'?this['onSecurityDebugPacket_'](_0x94749):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x323df0)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3c2bdc,_0xc8ee59){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3c2bdc),this['lastSessionId']=_0xc8ee59,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xa2367a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xa2367a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x53f94e){_0x53f94e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x53f94e;}['onOnline_'](_0x1858f0){_0x1858f0?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5bf38f=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x596df3=Math['max'](0x0,this['reconnectDelay_']-_0x5bf38f);_0x596df3=Math['random']()*_0x596df3,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x596df3+'ms'),this['scheduleConnect_'](_0x596df3),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x31ef7d=this['onDataMessage_']['bind'](this),_0x2b6613=this['onReady_']['bind'](this),_0x2da05d=this['onRealtimeDisconnect_']['bind'](this),_0x14bbfe=this['id']+':'+ie['nextConnectionId_']++,_0x504307=this['lastSessionId'];let _0x18aa7b=!0x1,_0x5bf9ac=null;const _0x5502fb=function(){_0x5bf9ac?_0x5bf9ac['close']():(_0x18aa7b=!0x0,_0x2da05d());},_0xa32f86=function(_0x23131d){f(_0x5bf9ac,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x5bf9ac['sendRequest'](_0x23131d);};this['realtime_']={'close':_0x5502fb,'sendRequest':_0xa32f86};const _0x286a5e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3bda9e,_0xd3da09]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x286a5e),this['appCheckTokenProvider_']['getToken'](_0x286a5e)]);_0x18aa7b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3bda9e&&_0x3bda9e['accessToken'],this['appCheckToken_']=_0xd3da09&&_0xd3da09['token'],_0x5bf9ac=new wh(_0x14bbfe,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x31ef7d,_0x2b6613,_0x2da05d,_0x2c7837=>{U(_0x2c7837+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x504307));}catch(_0x3686d6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3686d6),_0x18aa7b||(this['repoInfo_']['nodeAdmin']&&U(_0x3686d6),_0x5502fb());}}}['interrupt'](_0x1ea111){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1ea111),this['interruptReasons_'][_0x1ea111]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x325b26){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x325b26),delete this['interruptReasons_'][_0x325b26],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2bcc85){const _0x4daa9c=_0x2bcc85-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4daa9c});}['cancelSentTransactions_'](){for(let _0x1f337e=0x0;_0x1f337e<this['outstandingPuts_']['length'];_0x1f337e++){const _0x3aa217=this['outstandingPuts_'][_0x1f337e];_0x3aa217&&'h'in _0x3aa217['request']&&_0x3aa217['queued']&&(_0x3aa217['onComplete']&&_0x3aa217['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1f337e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x401482,_0x130471){let _0x4419a2;_0x130471?_0x4419a2=_0x130471['map'](_0x326c3e=>Bi(_0x326c3e))['join']('$'):_0x4419a2='default';const _0xc81ecb=this['removeListen_'](_0x401482,_0x4419a2);_0xc81ecb&&_0xc81ecb['onComplete']&&_0xc81ecb['onComplete']('permission_denied');}['removeListen_'](_0xc9fe6c,_0x325189){const _0x4de9a3=new C(_0xc9fe6c)['toString']();let _0x1aa323;if(this['listens']['has'](_0x4de9a3)){const _0x3f252c=this['listens']['get'](_0x4de9a3);_0x1aa323=_0x3f252c['get'](_0x325189),_0x3f252c['delete'](_0x325189),_0x3f252c['size']===0x0&&this['listens']['delete'](_0x4de9a3);}else _0x1aa323=void 0x0;return _0x1aa323;}['onAuthRevoked_'](_0x509f8a,_0x5e807b){L('Auth\x20token\x20revoked:\x20'+_0x509f8a+'/'+_0x5e807b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x509f8a==='invalid_token'||_0x509f8a==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5d75b0,_0x3c9db3){L('App\x20check\x20token\x20revoked:\x20'+_0x5d75b0+'/'+_0x3c9db3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5d75b0==='invalid_token'||_0x5d75b0==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x21ad22){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x21ad22):'msg'in _0x21ad22&&console['log']('FIREBASE:\x20'+_0x21ad22['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x59d4ce of this['listens']['values']())for(const _0x36a845 of _0x59d4ce['values']())this['sendListen_'](_0x36a845);for(let _0x2a9403=0x0;_0x2a9403<this['outstandingPuts_']['length'];_0x2a9403++)this['outstandingPuts_'][_0x2a9403]&&this['sendPut_'](_0x2a9403);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4abcad=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4abcad['action'],_0x4abcad['pathString'],_0x4abcad['data'],_0x4abcad['onComplete']);}for(let _0x5c2cc2=0x0;_0x5c2cc2<this['outstandingGets_']['length'];_0x5c2cc2++)this['outstandingGets_'][_0x5c2cc2]&&this['sendGet_'](_0x5c2cc2);}['sendConnectStats_'](){const _0x1c889a={};let _0xb4deb7='js';_0x1c889a['sdk.'+_0xb4deb7+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1c889a['framework.cordova']=0x1:qr()&&(_0x1c889a['framework.reactnative']=0x1),this['reportStats'](_0x1c889a);}['shouldReconnect_'](){const _0x29cd9e=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x29cd9e;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x49b0e7,_0x2a4c6f){this['name']=_0x49b0e7,this['node']=_0x2a4c6f;}static['Wrap'](_0x142b5f,_0x997b7f){return new E(_0x142b5f,_0x997b7f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x36190c,_0x5c7508){const _0xd26706=new E(xe,_0x36190c),_0x599f73=new E(xe,_0x5c7508);return this['compare'](_0xd26706,_0x599f73)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x113d41){Xt=_0x113d41;}['compare'](_0xc14153,_0x1c1e36){return He(_0xc14153['name'],_0x1c1e36['name']);}['isDefinedOn'](_0x547e20){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x383f1b,_0x37434e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x7b84ba,_0x40dbc6){return f(typeof _0x7b84ba=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x7b84ba,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5d3f2e,_0x3d2b8,_0x576834,_0x1e3206,_0xa4019=null){this['isReverse_']=_0x1e3206,this['resultGenerator_']=_0xa4019,this['nodeStack_']=[];let _0x5909c0=0x1;for(;!_0x5d3f2e['isEmpty']();)if(_0x5d3f2e=_0x5d3f2e,_0x5909c0=_0x3d2b8?_0x576834(_0x5d3f2e['key'],_0x3d2b8):0x1,_0x1e3206&&(_0x5909c0*=-0x1),_0x5909c0<0x0)this['isReverse_']?_0x5d3f2e=_0x5d3f2e['left']:_0x5d3f2e=_0x5d3f2e['right'];else{if(_0x5909c0===0x0){this['nodeStack_']['push'](_0x5d3f2e);break;}else this['nodeStack_']['push'](_0x5d3f2e),this['isReverse_']?_0x5d3f2e=_0x5d3f2e['right']:_0x5d3f2e=_0x5d3f2e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x28b4ee=this['nodeStack_']['pop'](),_0x3b8598;if(this['resultGenerator_']?_0x3b8598=this['resultGenerator_'](_0x28b4ee['key'],_0x28b4ee['value']):_0x3b8598={'key':_0x28b4ee['key'],'value':_0x28b4ee['value']},this['isReverse_']){for(_0x28b4ee=_0x28b4ee['left'];!_0x28b4ee['isEmpty']();)this['nodeStack_']['push'](_0x28b4ee),_0x28b4ee=_0x28b4ee['right'];}else{for(_0x28b4ee=_0x28b4ee['right'];!_0x28b4ee['isEmpty']();)this['nodeStack_']['push'](_0x28b4ee),_0x28b4ee=_0x28b4ee['left'];}return _0x3b8598;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x23a45c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x23a45c['key'],_0x23a45c['value']):{'key':_0x23a45c['key'],'value':_0x23a45c['value']};}}class M{constructor(_0x7cad81,_0x396a4c,_0x59529c,_0x1340cd,_0x23670d){this['key']=_0x7cad81,this['value']=_0x396a4c,this['color']=_0x59529c??M['RED'],this['left']=_0x1340cd??B['EMPTY_NODE'],this['right']=_0x23670d??B['EMPTY_NODE'];}['copy'](_0x1912d9,_0x49357e,_0x86fc08,_0x324380,_0x34c6a0){return new M(_0x1912d9??this['key'],_0x49357e??this['value'],_0x86fc08??this['color'],_0x324380??this['left'],_0x34c6a0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x15da84){return this['left']['inorderTraversal'](_0x15da84)||!!_0x15da84(this['key'],this['value'])||this['right']['inorderTraversal'](_0x15da84);}['reverseTraversal'](_0x2129d8){return this['right']['reverseTraversal'](_0x2129d8)||_0x2129d8(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2129d8);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x55976a,_0x4f0fbf,_0x56ff35){let _0x118314=this;const _0x59d1f1=_0x56ff35(_0x55976a,_0x118314['key']);return _0x59d1f1<0x0?_0x118314=_0x118314['copy'](null,null,null,_0x118314['left']['insert'](_0x55976a,_0x4f0fbf,_0x56ff35),null):_0x59d1f1===0x0?_0x118314=_0x118314['copy'](null,_0x4f0fbf,null,null,null):_0x118314=_0x118314['copy'](null,null,null,null,_0x118314['right']['insert'](_0x55976a,_0x4f0fbf,_0x56ff35)),_0x118314['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3ead96=this;return!_0x3ead96['left']['isRed_']()&&!_0x3ead96['left']['left']['isRed_']()&&(_0x3ead96=_0x3ead96['moveRedLeft_']()),_0x3ead96=_0x3ead96['copy'](null,null,null,_0x3ead96['left']['removeMin_'](),null),_0x3ead96['fixUp_']();}['remove'](_0x51910c,_0x2125ef){let _0x3307ec,_0x25305d;if(_0x3307ec=this,_0x2125ef(_0x51910c,_0x3307ec['key'])<0x0)!_0x3307ec['left']['isEmpty']()&&!_0x3307ec['left']['isRed_']()&&!_0x3307ec['left']['left']['isRed_']()&&(_0x3307ec=_0x3307ec['moveRedLeft_']()),_0x3307ec=_0x3307ec['copy'](null,null,null,_0x3307ec['left']['remove'](_0x51910c,_0x2125ef),null);else{if(_0x3307ec['left']['isRed_']()&&(_0x3307ec=_0x3307ec['rotateRight_']()),!_0x3307ec['right']['isEmpty']()&&!_0x3307ec['right']['isRed_']()&&!_0x3307ec['right']['left']['isRed_']()&&(_0x3307ec=_0x3307ec['moveRedRight_']()),_0x2125ef(_0x51910c,_0x3307ec['key'])===0x0){if(_0x3307ec['right']['isEmpty']())return B['EMPTY_NODE'];_0x25305d=_0x3307ec['right']['min_'](),_0x3307ec=_0x3307ec['copy'](_0x25305d['key'],_0x25305d['value'],null,null,_0x3307ec['right']['removeMin_']());}_0x3307ec=_0x3307ec['copy'](null,null,null,null,_0x3307ec['right']['remove'](_0x51910c,_0x2125ef));}return _0x3307ec['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1ef85d=this;return _0x1ef85d['right']['isRed_']()&&!_0x1ef85d['left']['isRed_']()&&(_0x1ef85d=_0x1ef85d['rotateLeft_']()),_0x1ef85d['left']['isRed_']()&&_0x1ef85d['left']['left']['isRed_']()&&(_0x1ef85d=_0x1ef85d['rotateRight_']()),_0x1ef85d['left']['isRed_']()&&_0x1ef85d['right']['isRed_']()&&(_0x1ef85d=_0x1ef85d['colorFlip_']()),_0x1ef85d;}['moveRedLeft_'](){let _0xd483f6=this['colorFlip_']();return _0xd483f6['right']['left']['isRed_']()&&(_0xd483f6=_0xd483f6['copy'](null,null,null,null,_0xd483f6['right']['rotateRight_']()),_0xd483f6=_0xd483f6['rotateLeft_'](),_0xd483f6=_0xd483f6['colorFlip_']()),_0xd483f6;}['moveRedRight_'](){let _0x4d4d9f=this['colorFlip_']();return _0x4d4d9f['left']['left']['isRed_']()&&(_0x4d4d9f=_0x4d4d9f['rotateRight_'](),_0x4d4d9f=_0x4d4d9f['colorFlip_']()),_0x4d4d9f;}['rotateLeft_'](){const _0x38d533=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x38d533,null);}['rotateRight_'](){const _0x5b94c7=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5b94c7);}['colorFlip_'](){const _0x3604f4=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xf8b256=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3604f4,_0xf8b256);}['checkMaxDepth_'](){const _0xc38ec8=this['check_']();return Math['pow'](0x2,_0xc38ec8)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xc15644=this['left']['check_']();if(_0xc15644!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xc15644+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x4087e2,_0x3d6f1f,_0x473c4d,_0x5c6be7,_0x3ebe2f){return this;}['insert'](_0x2e4c11,_0x299728,_0x31a045){return new M(_0x2e4c11,_0x299728,null);}['remove'](_0x23f08e,_0x390b5a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x25210a){return!0x1;}['reverseTraversal'](_0x2b5878){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2a7acb,_0x525f48=B['EMPTY_NODE']){this['comparator_']=_0x2a7acb,this['root_']=_0x525f48;}['insert'](_0x5eced5,_0x486fa6){return new B(this['comparator_'],this['root_']['insert'](_0x5eced5,_0x486fa6,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x124bf5){return new B(this['comparator_'],this['root_']['remove'](_0x124bf5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x16471a){let _0x24fb95,_0x287fa3=this['root_'];for(;!_0x287fa3['isEmpty']();){if(_0x24fb95=this['comparator_'](_0x16471a,_0x287fa3['key']),_0x24fb95===0x0)return _0x287fa3['value'];_0x24fb95<0x0?_0x287fa3=_0x287fa3['left']:_0x24fb95>0x0&&(_0x287fa3=_0x287fa3['right']);}return null;}['getPredecessorKey'](_0x1b6ee0){let _0x5a2def,_0x5ab216=this['root_'],_0xaf2bc=null;for(;!_0x5ab216['isEmpty']();)if(_0x5a2def=this['comparator_'](_0x1b6ee0,_0x5ab216['key']),_0x5a2def===0x0){if(_0x5ab216['left']['isEmpty']())return _0xaf2bc?_0xaf2bc['key']:null;for(_0x5ab216=_0x5ab216['left'];!_0x5ab216['right']['isEmpty']();)_0x5ab216=_0x5ab216['right'];return _0x5ab216['key'];}else _0x5a2def<0x0?_0x5ab216=_0x5ab216['left']:_0x5a2def>0x0&&(_0xaf2bc=_0x5ab216,_0x5ab216=_0x5ab216['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x370d39){return this['root_']['inorderTraversal'](_0x370d39);}['reverseTraversal'](_0x47da5c){return this['root_']['reverseTraversal'](_0x47da5c);}['getIterator'](_0x3d9622){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x3d9622);}['getIteratorFrom'](_0x3d6ecb,_0x45d9f4){return new Zt(this['root_'],_0x3d6ecb,this['comparator_'],!0x1,_0x45d9f4);}['getReverseIteratorFrom'](_0x324711,_0x58ea20){return new Zt(this['root_'],_0x324711,this['comparator_'],!0x0,_0x58ea20);}['getReverseIterator'](_0x32e961){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x32e961);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x456b82,_0x184592){return He(_0x456b82['name'],_0x184592['name']);}function ji(_0x3beeda,_0x5bdfcc){return He(_0x3beeda,_0x5bdfcc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x26166a){vi=_0x26166a;}const Ro=function(_0xb0118b){return typeof _0xb0118b=='number'?'number:'+so(_0xb0118b):'string:'+_0xb0118b;},Ao=function(_0x4a8006){if(_0x4a8006['isLeafNode']()){const _0x449647=_0x4a8006['val']();f(typeof _0x449647=='string'||typeof _0x449647=='number'||typeof _0x449647=='object'&&Y(_0x449647,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4a8006===vi||_0x4a8006['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4a8006===vi||_0x4a8006['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5a1a45){er=_0x5a1a45;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x171f7b,_0x44c451=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x171f7b,this['priorityNode_']=_0x44c451,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x56e5ef){return new D(this['value_'],_0x56e5ef);}['getImmediateChild'](_0x1ab012){return _0x1ab012==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0xa4b58e){return v(_0xa4b58e)?this:y(_0xa4b58e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5e32ba,_0x3aa678){return null;}['updateImmediateChild'](_0x14854a,_0x25334a){return _0x14854a==='.priority'?this['updatePriority'](_0x25334a):_0x25334a['isEmpty']()&&_0x14854a!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x14854a,_0x25334a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x41c170,_0x293603){const _0x2a7ea7=y(_0x41c170);return _0x2a7ea7===null?_0x293603:_0x293603['isEmpty']()&&_0x2a7ea7!=='.priority'?this:(f(_0x2a7ea7!=='.priority'||we(_0x41c170)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2a7ea7,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x41c170),_0x293603)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3e74dd,_0x57dbc7){return!0x1;}['val'](_0xe19771){return _0xe19771&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x37a0f0='';this['priorityNode_']['isEmpty']()||(_0x37a0f0+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x476c56=typeof this['value_'];_0x37a0f0+=_0x476c56+':',_0x476c56==='number'?_0x37a0f0+=so(this['value_']):_0x37a0f0+=this['value_'],this['lazyHash_']=no(_0x37a0f0);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x119631){return _0x119631===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x119631 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x119631['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x119631));}['compareToLeafNode_'](_0x10bf3f){const _0x149b47=typeof _0x10bf3f['value_'],_0x49419e=typeof this['value_'],_0x55b1f0=D['VALUE_TYPE_ORDER']['indexOf'](_0x149b47),_0x152e71=D['VALUE_TYPE_ORDER']['indexOf'](_0x49419e);return f(_0x55b1f0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x149b47),f(_0x152e71>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x49419e),_0x55b1f0===_0x152e71?_0x49419e==='object'?0x0:this['value_']<_0x10bf3f['value_']?-0x1:this['value_']===_0x10bf3f['value_']?0x0:0x1:_0x152e71-_0x55b1f0;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5858e2){if(_0x5858e2===this)return!0x0;if(_0x5858e2['isLeafNode']()){const _0x415978=_0x5858e2;return this['value_']===_0x415978['value_']&&this['priorityNode_']['equals'](_0x415978['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x22d9a1){ko=_0x22d9a1;}function xh(_0x41d6cc){No=_0x41d6cc;}class Fh extends On{['compare'](_0x19182b,_0x45f9c7){const _0x489c7a=_0x19182b['node']['getPriority'](),_0x29c771=_0x45f9c7['node']['getPriority'](),_0x16691f=_0x489c7a['compareTo'](_0x29c771);return _0x16691f===0x0?He(_0x19182b['name'],_0x45f9c7['name']):_0x16691f;}['isDefinedOn'](_0x29b07d){return!_0x29b07d['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x68a447,_0x4a5083){return!_0x68a447['getPriority']()['equals'](_0x4a5083['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x285eab,_0x46f10f){const _0x1ec9ba=ko(_0x285eab);return new E(_0x46f10f,new D('[PRIORITY-POST]',_0x1ec9ba));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4e6b65){const _0x59faf8=_0x574482=>parseInt(Math['log'](_0x574482)/Uh,0xa),_0x12f715=_0x2aed9b=>parseInt(Array(_0x2aed9b+0x1)['join']('1'),0x2);this['count']=_0x59faf8(_0x4e6b65+0x1),this['current_']=this['count']-0x1;const _0x15fab3=_0x12f715(this['count']);this['bits_']=_0x4e6b65+0x1&_0x15fab3;}['nextBitIsOne'](){const _0xa9d9d3=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xa9d9d3;}}const dn=function(_0x161ce1,_0x3a0377,_0x1c19a8,_0x2cead1){_0x161ce1['sort'](_0x3a0377);const _0x2f4830=function(_0x68ab41,_0xcd8e15){const _0x7ba429=_0xcd8e15-_0x68ab41;let _0x10c8a8,_0x5eac41;if(_0x7ba429===0x0)return null;if(_0x7ba429===0x1)return _0x10c8a8=_0x161ce1[_0x68ab41],_0x5eac41=_0x1c19a8?_0x1c19a8(_0x10c8a8):_0x10c8a8,new M(_0x5eac41,_0x10c8a8['node'],M['BLACK'],null,null);{const _0x2f64fd=parseInt(_0x7ba429/0x2,0xa)+_0x68ab41,_0x433437=_0x2f4830(_0x68ab41,_0x2f64fd),_0x978f63=_0x2f4830(_0x2f64fd+0x1,_0xcd8e15);return _0x10c8a8=_0x161ce1[_0x2f64fd],_0x5eac41=_0x1c19a8?_0x1c19a8(_0x10c8a8):_0x10c8a8,new M(_0x5eac41,_0x10c8a8['node'],M['BLACK'],_0x433437,_0x978f63);}},_0x2b6783=function(_0x11618d){let _0x52553d=null,_0x13245f=null,_0x580be1=_0x161ce1['length'];const _0x2a2c75=function(_0x3c57eb,_0x5b34d1){const _0x3c65d0=_0x580be1-_0x3c57eb,_0x1445c1=_0x580be1;_0x580be1-=_0x3c57eb;const _0x18c743=_0x2f4830(_0x3c65d0+0x1,_0x1445c1),_0x187406=_0x161ce1[_0x3c65d0],_0x1d9bfe=_0x1c19a8?_0x1c19a8(_0x187406):_0x187406;_0x3b447f(new M(_0x1d9bfe,_0x187406['node'],_0x5b34d1,null,_0x18c743));},_0x3b447f=function(_0x2accc2){_0x52553d?(_0x52553d['left']=_0x2accc2,_0x52553d=_0x2accc2):(_0x13245f=_0x2accc2,_0x52553d=_0x2accc2);};for(let _0x1aaeed=0x0;_0x1aaeed<_0x11618d['count'];++_0x1aaeed){const _0xcdc15e=_0x11618d['nextBitIsOne'](),_0x5e6fa7=Math['pow'](0x2,_0x11618d['count']-(_0x1aaeed+0x1));_0xcdc15e?_0x2a2c75(_0x5e6fa7,M['BLACK']):(_0x2a2c75(_0x5e6fa7,M['BLACK']),_0x2a2c75(_0x5e6fa7,M['RED']));}return _0x13245f;},_0x18542d=new Wh(_0x161ce1['length']),_0x42ca77=_0x2b6783(_0x18542d);return new B(_0x2cead1||_0x3a0377,_0x42ca77);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5100d1,_0x3a244b){this['indexes_']=_0x5100d1,this['indexSet_']=_0x3a244b;}['get'](_0x3d9534){const _0x2a706d=Oe(this['indexes_'],_0x3d9534);if(!_0x2a706d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3d9534);return _0x2a706d instanceof B?_0x2a706d:null;}['hasIndex'](_0x40039b){return Y(this['indexSet_'],_0x40039b['toString']());}['addIndex'](_0x228c9a,_0x74dd85){f(_0x228c9a!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2c050b=[];let _0x1a5374=!0x1;const _0xf95e2e=_0x74dd85['getIterator'](E['Wrap']);let _0x453d3b=_0xf95e2e['getNext']();for(;_0x453d3b;)_0x1a5374=_0x1a5374||_0x228c9a['isDefinedOn'](_0x453d3b['node']),_0x2c050b['push'](_0x453d3b),_0x453d3b=_0xf95e2e['getNext']();let _0x491161;_0x1a5374?_0x491161=dn(_0x2c050b,_0x228c9a['getCompare']()):_0x491161=je;const _0x4281ee=_0x228c9a['toString'](),_0x1fec2f={...this['indexSet_']};_0x1fec2f[_0x4281ee]=_0x228c9a;const _0x2bc2f9={...this['indexes_']};return _0x2bc2f9[_0x4281ee]=_0x491161,new ee(_0x2bc2f9,_0x1fec2f);}['addToIndexes'](_0x5d31ab,_0x54b834){const _0xac48e=ln(this['indexes_'],(_0x1a3fe2,_0x3015fd)=>{const _0x46cc8c=Oe(this['indexSet_'],_0x3015fd);if(f(_0x46cc8c,'Missing\x20index\x20implementation\x20for\x20'+_0x3015fd),_0x1a3fe2===je){if(_0x46cc8c['isDefinedOn'](_0x5d31ab['node'])){const _0x1ba311=[],_0x3dd406=_0x54b834['getIterator'](E['Wrap']);let _0x459114=_0x3dd406['getNext']();for(;_0x459114;)_0x459114['name']!==_0x5d31ab['name']&&_0x1ba311['push'](_0x459114),_0x459114=_0x3dd406['getNext']();return _0x1ba311['push'](_0x5d31ab),dn(_0x1ba311,_0x46cc8c['getCompare']());}else return je;}else{const _0x1383a5=_0x54b834['get'](_0x5d31ab['name']);let _0x3b3390=_0x1a3fe2;return _0x1383a5&&(_0x3b3390=_0x3b3390['remove'](new E(_0x5d31ab['name'],_0x1383a5))),_0x3b3390['insert'](_0x5d31ab,_0x5d31ab['node']);}});return new ee(_0xac48e,this['indexSet_']);}['removeFromIndexes'](_0x1f9a9f,_0x5bd407){const _0x5e097b=ln(this['indexes_'],_0x34ee2f=>{if(_0x34ee2f===je)return _0x34ee2f;{const _0x347007=_0x5bd407['get'](_0x1f9a9f['name']);return _0x347007?_0x34ee2f['remove'](new E(_0x1f9a9f['name'],_0x347007)):_0x34ee2f;}});return new ee(_0x5e097b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x471667,_0x1aa270,_0x5877ec){this['children_']=_0x471667,this['priorityNode_']=_0x1aa270,this['indexMap_']=_0x5877ec,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x5d6387){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5d6387,this['indexMap_']);}['getImmediateChild'](_0x133cda){if(_0x133cda==='.priority')return this['getPriority']();{const _0x31d69f=this['children_']['get'](_0x133cda);return _0x31d69f===null?gt:_0x31d69f;}}['getChild'](_0x31864a){const _0x45c647=y(_0x31864a);return _0x45c647===null?this:this['getImmediateChild'](_0x45c647)['getChild'](b(_0x31864a));}['hasChild'](_0x1983ef){return this['children_']['get'](_0x1983ef)!==null;}['updateImmediateChild'](_0x503d73,_0x1af9d8){if(f(_0x1af9d8,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x503d73==='.priority')return this['updatePriority'](_0x1af9d8);{const _0x437d22=new E(_0x503d73,_0x1af9d8);let _0x5962d1,_0x31e988;_0x1af9d8['isEmpty']()?(_0x5962d1=this['children_']['remove'](_0x503d73),_0x31e988=this['indexMap_']['removeFromIndexes'](_0x437d22,this['children_'])):(_0x5962d1=this['children_']['insert'](_0x503d73,_0x1af9d8),_0x31e988=this['indexMap_']['addToIndexes'](_0x437d22,this['children_']));const _0x579451=_0x5962d1['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5962d1,_0x579451,_0x31e988);}}['updateChild'](_0x21eb3a,_0x5d9325){const _0x2e880d=y(_0x21eb3a);if(_0x2e880d===null)return _0x5d9325;{f(y(_0x21eb3a)!=='.priority'||we(_0x21eb3a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2e3a57=this['getImmediateChild'](_0x2e880d)['updateChild'](b(_0x21eb3a),_0x5d9325);return this['updateImmediateChild'](_0x2e880d,_0x2e3a57);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3efac3){if(this['isEmpty']())return null;const _0x363367={};let _0x22c12a=0x0,_0x49b177=0x0,_0x4d3d93=!0x0;if(this['forEachChild'](R,(_0x17e67f,_0x2ae9cd)=>{_0x363367[_0x17e67f]=_0x2ae9cd['val'](_0x3efac3),_0x22c12a++,_0x4d3d93&&g['INTEGER_REGEXP_']['test'](_0x17e67f)?_0x49b177=Math['max'](_0x49b177,Number(_0x17e67f)):_0x4d3d93=!0x1;}),!_0x3efac3&&_0x4d3d93&&_0x49b177<0x2*_0x22c12a){const _0x4511b2=[];for(const _0x52b9d5 in _0x363367)_0x4511b2[_0x52b9d5]=_0x363367[_0x52b9d5];return _0x4511b2;}else return _0x3efac3&&!this['getPriority']()['isEmpty']()&&(_0x363367['.priority']=this['getPriority']()['val']()),_0x363367;}['hash'](){if(this['lazyHash_']===null){let _0x1172a6='';this['getPriority']()['isEmpty']()||(_0x1172a6+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2a971e,_0xefa3fb)=>{const _0x563c6e=_0xefa3fb['hash']();_0x563c6e!==''&&(_0x1172a6+=':'+_0x2a971e+':'+_0x563c6e);}),this['lazyHash_']=_0x1172a6===''?'':no(_0x1172a6);}return this['lazyHash_'];}['getPredecessorChildName'](_0x510af4,_0x301926,_0x53d179){const _0x1fcfe7=this['resolveIndex_'](_0x53d179);if(_0x1fcfe7){const _0x23b659=_0x1fcfe7['getPredecessorKey'](new E(_0x510af4,_0x301926));return _0x23b659?_0x23b659['name']:null;}else return this['children_']['getPredecessorKey'](_0x510af4);}['getFirstChildName'](_0x24c50c){const _0x304fcf=this['resolveIndex_'](_0x24c50c);if(_0x304fcf){const _0x4b76e8=_0x304fcf['minKey']();return _0x4b76e8&&_0x4b76e8['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x469a72){const _0x223b1f=this['getFirstChildName'](_0x469a72);return _0x223b1f?new E(_0x223b1f,this['children_']['get'](_0x223b1f)):null;}['getLastChildName'](_0x27f401){const _0x25b393=this['resolveIndex_'](_0x27f401);if(_0x25b393){const _0x14801e=_0x25b393['maxKey']();return _0x14801e&&_0x14801e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4b0d89){const _0xd2ddd1=this['getLastChildName'](_0x4b0d89);return _0xd2ddd1?new E(_0xd2ddd1,this['children_']['get'](_0xd2ddd1)):null;}['forEachChild'](_0x7c10f8,_0x467d1d){const _0x1306ad=this['resolveIndex_'](_0x7c10f8);return _0x1306ad?_0x1306ad['inorderTraversal'](_0x55884f=>_0x467d1d(_0x55884f['name'],_0x55884f['node'])):this['children_']['inorderTraversal'](_0x467d1d);}['getIterator'](_0xb8dafb){return this['getIteratorFrom'](_0xb8dafb['minPost'](),_0xb8dafb);}['getIteratorFrom'](_0x1ce4b5,_0x1cd8dd){const _0x4af1d2=this['resolveIndex_'](_0x1cd8dd);if(_0x4af1d2)return _0x4af1d2['getIteratorFrom'](_0x1ce4b5,_0x1916e3=>_0x1916e3);{const _0x90c5c1=this['children_']['getIteratorFrom'](_0x1ce4b5['name'],E['Wrap']);let _0x42b5aa=_0x90c5c1['peek']();for(;_0x42b5aa!=null&&_0x1cd8dd['compare'](_0x42b5aa,_0x1ce4b5)<0x0;)_0x90c5c1['getNext'](),_0x42b5aa=_0x90c5c1['peek']();return _0x90c5c1;}}['getReverseIterator'](_0x7fff09){return this['getReverseIteratorFrom'](_0x7fff09['maxPost'](),_0x7fff09);}['getReverseIteratorFrom'](_0x1befe2,_0x512f0b){const _0x3b6ef2=this['resolveIndex_'](_0x512f0b);if(_0x3b6ef2)return _0x3b6ef2['getReverseIteratorFrom'](_0x1befe2,_0x31b3b5=>_0x31b3b5);{const _0x551917=this['children_']['getReverseIteratorFrom'](_0x1befe2['name'],E['Wrap']);let _0xfc9dc5=_0x551917['peek']();for(;_0xfc9dc5!=null&&_0x512f0b['compare'](_0xfc9dc5,_0x1befe2)>0x0;)_0x551917['getNext'](),_0xfc9dc5=_0x551917['peek']();return _0x551917;}}['compareTo'](_0x1b073d){return this['isEmpty']()?_0x1b073d['isEmpty']()?0x0:-0x1:_0x1b073d['isLeafNode']()||_0x1b073d['isEmpty']()?0x1:_0x1b073d===Ht?-0x1:0x0;}['withIndex'](_0x2d64df){if(_0x2d64df===ye||this['indexMap_']['hasIndex'](_0x2d64df))return this;{const _0x4c441b=this['indexMap_']['addIndex'](_0x2d64df,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4c441b);}}['isIndexed'](_0x247fe5){return _0x247fe5===ye||this['indexMap_']['hasIndex'](_0x247fe5);}['equals'](_0x238854){if(_0x238854===this)return!0x0;if(_0x238854['isLeafNode']())return!0x1;{const _0x13aa41=_0x238854;if(this['getPriority']()['equals'](_0x13aa41['getPriority']())){if(this['children_']['count']()===_0x13aa41['children_']['count']()){const _0x2c7ace=this['getIterator'](R),_0x4a5d62=_0x13aa41['getIterator'](R);let _0x8e27c2=_0x2c7ace['getNext'](),_0x42fc62=_0x4a5d62['getNext']();for(;_0x8e27c2&&_0x42fc62;){if(_0x8e27c2['name']!==_0x42fc62['name']||!_0x8e27c2['node']['equals'](_0x42fc62['node']))return!0x1;_0x8e27c2=_0x2c7ace['getNext'](),_0x42fc62=_0x4a5d62['getNext']();}return _0x8e27c2===null&&_0x42fc62===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5ead45){return _0x5ead45===ye?null:this['indexMap_']['get'](_0x5ead45['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x318e9d){return _0x318e9d===this?0x0:0x1;}['equals'](_0x5c6ee6){return _0x5c6ee6===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1bd4d4){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x12ca81,_0x46dbb8=null){if(_0x12ca81===null)return g['EMPTY_NODE'];if(typeof _0x12ca81=='object'&&'.priority'in _0x12ca81&&(_0x46dbb8=_0x12ca81['.priority']),f(_0x46dbb8===null||typeof _0x46dbb8=='string'||typeof _0x46dbb8=='number'||typeof _0x46dbb8=='object'&&'.sv'in _0x46dbb8,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x46dbb8),typeof _0x12ca81=='object'&&'.value'in _0x12ca81&&_0x12ca81['.value']!==null&&(_0x12ca81=_0x12ca81['.value']),typeof _0x12ca81!='object'||'.sv'in _0x12ca81){const _0x1517d5=_0x12ca81;return new D(_0x1517d5,N(_0x46dbb8));}if(!(_0x12ca81 instanceof Array)&&Vh){const _0x3de328=[];let _0x5ef0c4=!0x1;if(x(_0x12ca81,(_0x5a76ca,_0x1141f1)=>{if(_0x5a76ca['substring'](0x0,0x1)!=='.'){const _0x10dd35=N(_0x1141f1);_0x10dd35['isEmpty']()||(_0x5ef0c4=_0x5ef0c4||!_0x10dd35['getPriority']()['isEmpty'](),_0x3de328['push'](new E(_0x5a76ca,_0x10dd35)));}}),_0x3de328['length']===0x0)return g['EMPTY_NODE'];const _0x26886c=dn(_0x3de328,Dh,_0x22e621=>_0x22e621['name'],ji);if(_0x5ef0c4){const _0x44c58b=dn(_0x3de328,R['getCompare']());return new g(_0x26886c,N(_0x46dbb8),new ee({'.priority':_0x44c58b},{'.priority':R}));}else return new g(_0x26886c,N(_0x46dbb8),ee['Default']);}else{let _0x13417a=g['EMPTY_NODE'];return x(_0x12ca81,(_0xb16f37,_0xd71301)=>{if(Y(_0x12ca81,_0xb16f37)&&_0xb16f37['substring'](0x0,0x1)!=='.'){const _0x4ed2c0=N(_0xd71301);(_0x4ed2c0['isLeafNode']()||!_0x4ed2c0['isEmpty']())&&(_0x13417a=_0x13417a['updateImmediateChild'](_0xb16f37,_0x4ed2c0));}}),_0x13417a['updatePriority'](N(_0x46dbb8));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x5423b5){super(),this['indexPath_']=_0x5423b5,f(!v(_0x5423b5)&&y(_0x5423b5)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x303e4f){return _0x303e4f['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2eb687){return!_0x2eb687['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x39a0a1,_0x1a4740){const _0x40e470=this['extractChild'](_0x39a0a1['node']),_0x306871=this['extractChild'](_0x1a4740['node']),_0xce4dc3=_0x40e470['compareTo'](_0x306871);return _0xce4dc3===0x0?He(_0x39a0a1['name'],_0x1a4740['name']):_0xce4dc3;}['makePost'](_0x5e1d43,_0x46a30d){const _0x2c880f=N(_0x5e1d43),_0x19302f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2c880f);return new E(_0x46a30d,_0x19302f);}['maxPost'](){const _0x42b5e3=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x42b5e3);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x46e5d2,_0x484107){const _0x53d500=_0x46e5d2['node']['compareTo'](_0x484107['node']);return _0x53d500===0x0?He(_0x46e5d2['name'],_0x484107['name']):_0x53d500;}['isDefinedOn'](_0x2fe184){return!0x0;}['indexedValueChanged'](_0x5693e3,_0x98de96){return!_0x5693e3['equals'](_0x98de96);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2c306a,_0x6b85fa){const _0x3550d3=N(_0x2c306a);return new E(_0x6b85fa,_0x3550d3);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x25ecae){return{'type':'value','snapshotNode':_0x25ecae};}function tt(_0x430a48,_0x899b48){return{'type':'child_added','snapshotNode':_0x899b48,'childName':_0x430a48};}function Nt(_0x5431ff,_0xc2123f){return{'type':'child_removed','snapshotNode':_0xc2123f,'childName':_0x5431ff};}function Pt(_0x17d7de,_0x26ad16,_0x35e4bd){return{'type':'child_changed','snapshotNode':_0x26ad16,'childName':_0x17d7de,'oldSnap':_0x35e4bd};}function $h(_0x4421c3,_0x4c84e5){return{'type':'child_moved','snapshotNode':_0x4c84e5,'childName':_0x4421c3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x18ca8d){this['index_']=_0x18ca8d;}['updateChild'](_0x403248,_0x555629,_0x27511c,_0x5412a0,_0xe4f141,_0x564ca9){f(_0x403248['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x229115=_0x403248['getImmediateChild'](_0x555629);return _0x229115['getChild'](_0x5412a0)['equals'](_0x27511c['getChild'](_0x5412a0))&&_0x229115['isEmpty']()===_0x27511c['isEmpty']()||(_0x564ca9!=null&&(_0x27511c['isEmpty']()?_0x403248['hasChild'](_0x555629)?_0x564ca9['trackChildChange'](Nt(_0x555629,_0x229115)):f(_0x403248['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x229115['isEmpty']()?_0x564ca9['trackChildChange'](tt(_0x555629,_0x27511c)):_0x564ca9['trackChildChange'](Pt(_0x555629,_0x27511c,_0x229115))),_0x403248['isLeafNode']()&&_0x27511c['isEmpty']())?_0x403248:_0x403248['updateImmediateChild'](_0x555629,_0x27511c)['withIndex'](this['index_']);}['updateFullNode'](_0x480b78,_0x52ca1d,_0x3fc9b4){return _0x3fc9b4!=null&&(_0x480b78['isLeafNode']()||_0x480b78['forEachChild'](R,(_0x2e23a6,_0x101c4c)=>{_0x52ca1d['hasChild'](_0x2e23a6)||_0x3fc9b4['trackChildChange'](Nt(_0x2e23a6,_0x101c4c));}),_0x52ca1d['isLeafNode']()||_0x52ca1d['forEachChild'](R,(_0x5461f8,_0xbe9d10)=>{if(_0x480b78['hasChild'](_0x5461f8)){const _0x293f60=_0x480b78['getImmediateChild'](_0x5461f8);_0x293f60['equals'](_0xbe9d10)||_0x3fc9b4['trackChildChange'](Pt(_0x5461f8,_0xbe9d10,_0x293f60));}else _0x3fc9b4['trackChildChange'](tt(_0x5461f8,_0xbe9d10));})),_0x52ca1d['withIndex'](this['index_']);}['updatePriority'](_0x4784a0,_0x14f2d4){return _0x4784a0['isEmpty']()?g['EMPTY_NODE']:_0x4784a0['updatePriority'](_0x14f2d4);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x1fd3e1){this['indexedFilter_']=new Yi(_0x1fd3e1['getIndex']()),this['index_']=_0x1fd3e1['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x1fd3e1),this['endPost_']=Ot['getEndPost_'](_0x1fd3e1),this['startIsInclusive_']=!_0x1fd3e1['startAfterSet_'],this['endIsInclusive_']=!_0x1fd3e1['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x22345f){const _0x56e59d=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x22345f)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x22345f)<0x0,_0x1d2cb0=this['endIsInclusive_']?this['index_']['compare'](_0x22345f,this['getEndPost']())<=0x0:this['index_']['compare'](_0x22345f,this['getEndPost']())<0x0;return _0x56e59d&&_0x1d2cb0;}['updateChild'](_0x44e607,_0x178cd2,_0x3afa9d,_0x2245d6,_0x21da43,_0x483e60){return this['matches'](new E(_0x178cd2,_0x3afa9d))||(_0x3afa9d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x44e607,_0x178cd2,_0x3afa9d,_0x2245d6,_0x21da43,_0x483e60);}['updateFullNode'](_0x47e60b,_0x2bd83a,_0x5543d0){_0x2bd83a['isLeafNode']()&&(_0x2bd83a=g['EMPTY_NODE']);let _0x54705a=_0x2bd83a['withIndex'](this['index_']);_0x54705a=_0x54705a['updatePriority'](g['EMPTY_NODE']);const _0x2f1f21=this;return _0x2bd83a['forEachChild'](R,(_0x43c996,_0x140262)=>{_0x2f1f21['matches'](new E(_0x43c996,_0x140262))||(_0x54705a=_0x54705a['updateImmediateChild'](_0x43c996,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x47e60b,_0x54705a,_0x5543d0);}['updatePriority'](_0x32f500,_0x3ebd89){return _0x32f500;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4a8a58){if(_0x4a8a58['hasStart']()){const _0x4b6c75=_0x4a8a58['getIndexStartName']();return _0x4a8a58['getIndex']()['makePost'](_0x4a8a58['getIndexStartValue'](),_0x4b6c75);}else return _0x4a8a58['getIndex']()['minPost']();}static['getEndPost_'](_0xd8348e){if(_0xd8348e['hasEnd']()){const _0x3a78ca=_0xd8348e['getIndexEndName']();return _0xd8348e['getIndex']()['makePost'](_0xd8348e['getIndexEndValue'](),_0x3a78ca);}else return _0xd8348e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x38368b){this['withinDirectionalStart']=_0x2933d1=>this['reverse_']?this['withinEndPost'](_0x2933d1):this['withinStartPost'](_0x2933d1),this['withinDirectionalEnd']=_0x2b6ecf=>this['reverse_']?this['withinStartPost'](_0x2b6ecf):this['withinEndPost'](_0x2b6ecf),this['withinStartPost']=_0x98407=>{const _0x3b313e=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x98407);return this['startIsInclusive_']?_0x3b313e<=0x0:_0x3b313e<0x0;},this['withinEndPost']=_0x2371d3=>{const _0x2ebbc2=this['index_']['compare'](_0x2371d3,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2ebbc2<=0x0:_0x2ebbc2<0x0;},this['rangedFilter_']=new Ot(_0x38368b),this['index_']=_0x38368b['getIndex'](),this['limit_']=_0x38368b['getLimit'](),this['reverse_']=!_0x38368b['isViewFromLeft'](),this['startIsInclusive_']=!_0x38368b['startAfterSet_'],this['endIsInclusive_']=!_0x38368b['endBeforeSet_'];}['updateChild'](_0x15abf1,_0x5c1bba,_0x2be73d,_0x174da8,_0x1be367,_0x295194){return this['rangedFilter_']['matches'](new E(_0x5c1bba,_0x2be73d))||(_0x2be73d=g['EMPTY_NODE']),_0x15abf1['getImmediateChild'](_0x5c1bba)['equals'](_0x2be73d)?_0x15abf1:_0x15abf1['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x15abf1,_0x5c1bba,_0x2be73d,_0x174da8,_0x1be367,_0x295194):this['fullLimitUpdateChild_'](_0x15abf1,_0x5c1bba,_0x2be73d,_0x1be367,_0x295194);}['updateFullNode'](_0x3b9dd1,_0x4922bc,_0x26e1fd){let _0x244fc8;if(_0x4922bc['isLeafNode']()||_0x4922bc['isEmpty']())_0x244fc8=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4922bc['numChildren']()&&_0x4922bc['isIndexed'](this['index_'])){_0x244fc8=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x257b7e;this['reverse_']?_0x257b7e=_0x4922bc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x257b7e=_0x4922bc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x31f388=0x0;for(;_0x257b7e['hasNext']()&&_0x31f388<this['limit_'];){const _0x26c24d=_0x257b7e['getNext']();if(this['withinDirectionalStart'](_0x26c24d)){if(this['withinDirectionalEnd'](_0x26c24d))_0x244fc8=_0x244fc8['updateImmediateChild'](_0x26c24d['name'],_0x26c24d['node']),_0x31f388++;else break;}else continue;}}else{_0x244fc8=_0x4922bc['withIndex'](this['index_']),_0x244fc8=_0x244fc8['updatePriority'](g['EMPTY_NODE']);let _0x5d2508;this['reverse_']?_0x5d2508=_0x244fc8['getReverseIterator'](this['index_']):_0x5d2508=_0x244fc8['getIterator'](this['index_']);let _0x2886ca=0x0;for(;_0x5d2508['hasNext']();){const _0x3c3321=_0x5d2508['getNext']();_0x2886ca<this['limit_']&&this['withinDirectionalStart'](_0x3c3321)&&this['withinDirectionalEnd'](_0x3c3321)?_0x2886ca++:_0x244fc8=_0x244fc8['updateImmediateChild'](_0x3c3321['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3b9dd1,_0x244fc8,_0x26e1fd);}['updatePriority'](_0xa1d83f,_0x351d7a){return _0xa1d83f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x9eba74,_0x3d5974,_0x59b937,_0x3af3b7,_0x439a32){let _0x10ed9c;if(this['reverse_']){const _0x2f1b4c=this['index_']['getCompare']();_0x10ed9c=(_0x4d984c,_0x594e32)=>_0x2f1b4c(_0x594e32,_0x4d984c);}else _0x10ed9c=this['index_']['getCompare']();const _0x47ef41=_0x9eba74;f(_0x47ef41['numChildren']()===this['limit_'],'');const _0x383361=new E(_0x3d5974,_0x59b937),_0x5adf52=this['reverse_']?_0x47ef41['getFirstChild'](this['index_']):_0x47ef41['getLastChild'](this['index_']),_0x29bb32=this['rangedFilter_']['matches'](_0x383361);if(_0x47ef41['hasChild'](_0x3d5974)){const _0x38d654=_0x47ef41['getImmediateChild'](_0x3d5974);let _0x1dc21e=_0x3af3b7['getChildAfterChild'](this['index_'],_0x5adf52,this['reverse_']);for(;_0x1dc21e!=null&&(_0x1dc21e['name']===_0x3d5974||_0x47ef41['hasChild'](_0x1dc21e['name']));)_0x1dc21e=_0x3af3b7['getChildAfterChild'](this['index_'],_0x1dc21e,this['reverse_']);const _0x4459b4=_0x1dc21e==null?0x1:_0x10ed9c(_0x1dc21e,_0x383361);if(_0x29bb32&&!_0x59b937['isEmpty']()&&_0x4459b4>=0x0)return _0x439a32!=null&&_0x439a32['trackChildChange'](Pt(_0x3d5974,_0x59b937,_0x38d654)),_0x47ef41['updateImmediateChild'](_0x3d5974,_0x59b937);{_0x439a32!=null&&_0x439a32['trackChildChange'](Nt(_0x3d5974,_0x38d654));const _0x377a7e=_0x47ef41['updateImmediateChild'](_0x3d5974,g['EMPTY_NODE']);return _0x1dc21e!=null&&this['rangedFilter_']['matches'](_0x1dc21e)?(_0x439a32!=null&&_0x439a32['trackChildChange'](tt(_0x1dc21e['name'],_0x1dc21e['node'])),_0x377a7e['updateImmediateChild'](_0x1dc21e['name'],_0x1dc21e['node'])):_0x377a7e;}}else return _0x59b937['isEmpty']()?_0x9eba74:_0x29bb32&&_0x10ed9c(_0x5adf52,_0x383361)>=0x0?(_0x439a32!=null&&(_0x439a32['trackChildChange'](Nt(_0x5adf52['name'],_0x5adf52['node'])),_0x439a32['trackChildChange'](tt(_0x3d5974,_0x59b937))),_0x47ef41['updateImmediateChild'](_0x3d5974,_0x59b937)['updateImmediateChild'](_0x5adf52['name'],g['EMPTY_NODE'])):_0x9eba74;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x297fa0=new Qi();return _0x297fa0['limitSet_']=this['limitSet_'],_0x297fa0['limit_']=this['limit_'],_0x297fa0['startSet_']=this['startSet_'],_0x297fa0['startAfterSet_']=this['startAfterSet_'],_0x297fa0['indexStartValue_']=this['indexStartValue_'],_0x297fa0['startNameSet_']=this['startNameSet_'],_0x297fa0['indexStartName_']=this['indexStartName_'],_0x297fa0['endSet_']=this['endSet_'],_0x297fa0['endBeforeSet_']=this['endBeforeSet_'],_0x297fa0['indexEndValue_']=this['indexEndValue_'],_0x297fa0['endNameSet_']=this['endNameSet_'],_0x297fa0['indexEndName_']=this['indexEndName_'],_0x297fa0['index_']=this['index_'],_0x297fa0['viewFrom_']=this['viewFrom_'],_0x297fa0;}}function qh(_0x48b984){return _0x48b984['loadsAllData']()?new Yi(_0x48b984['getIndex']()):_0x48b984['hasLimit']()?new Gh(_0x48b984):new Ot(_0x48b984);}function zh(_0x4b7779,_0x21e311){const _0x1e8a2f=_0x4b7779['copy']();return _0x1e8a2f['limitSet_']=!0x0,_0x1e8a2f['limit_']=_0x21e311,_0x1e8a2f['viewFrom_']='l',_0x1e8a2f;}function jh(_0x5eed92,_0x1c1da5,_0x50a9d3){const _0x13ab12=_0x5eed92['copy']();return _0x13ab12['startSet_']=!0x0,_0x1c1da5===void 0x0&&(_0x1c1da5=null),_0x13ab12['indexStartValue_']=_0x1c1da5,_0x50a9d3!=null?(_0x13ab12['startNameSet_']=!0x0,_0x13ab12['indexStartName_']=_0x50a9d3):(_0x13ab12['startNameSet_']=!0x1,_0x13ab12['indexStartName_']=''),_0x13ab12;}function Kh(_0x312a9f,_0x1e74a8,_0x581600){const _0xbcb8e3=_0x312a9f['copy']();return _0xbcb8e3['endSet_']=!0x0,_0x1e74a8===void 0x0&&(_0x1e74a8=null),_0xbcb8e3['indexEndValue_']=_0x1e74a8,_0x581600!==void 0x0?(_0xbcb8e3['endNameSet_']=!0x0,_0xbcb8e3['indexEndName_']=_0x581600):(_0xbcb8e3['endNameSet_']=!0x1,_0xbcb8e3['indexEndName_']=''),_0xbcb8e3;}function Do(_0x47a4f0,_0x15cfe9){const _0x46814c=_0x47a4f0['copy']();return _0x46814c['index_']=_0x15cfe9,_0x46814c;}function tr(_0x510c11){const _0x4e3443={};if(_0x510c11['isDefault']())return _0x4e3443;let _0x766a48;if(_0x510c11['index_']===R?_0x766a48='$priority':_0x510c11['index_']===Po?_0x766a48='$value':_0x510c11['index_']===ye?_0x766a48='$key':(f(_0x510c11['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x766a48=_0x510c11['index_']['toString']()),_0x4e3443['orderBy']=O(_0x766a48),_0x510c11['startSet_']){const _0x1848e9=_0x510c11['startAfterSet_']?'startAfter':'startAt';_0x4e3443[_0x1848e9]=O(_0x510c11['indexStartValue_']),_0x510c11['startNameSet_']&&(_0x4e3443[_0x1848e9]+=','+O(_0x510c11['indexStartName_']));}if(_0x510c11['endSet_']){const _0x1e3e4d=_0x510c11['endBeforeSet_']?'endBefore':'endAt';_0x4e3443[_0x1e3e4d]=O(_0x510c11['indexEndValue_']),_0x510c11['endNameSet_']&&(_0x4e3443[_0x1e3e4d]+=','+O(_0x510c11['indexEndName_']));}return _0x510c11['limitSet_']&&(_0x510c11['isViewFromLeft']()?_0x4e3443['limitToFirst']=_0x510c11['limit_']:_0x4e3443['limitToLast']=_0x510c11['limit_']),_0x4e3443;}function nr(_0x5cef10){const _0x84ae67={};if(_0x5cef10['startSet_']&&(_0x84ae67['sp']=_0x5cef10['indexStartValue_'],_0x5cef10['startNameSet_']&&(_0x84ae67['sn']=_0x5cef10['indexStartName_']),_0x84ae67['sin']=!_0x5cef10['startAfterSet_']),_0x5cef10['endSet_']&&(_0x84ae67['ep']=_0x5cef10['indexEndValue_'],_0x5cef10['endNameSet_']&&(_0x84ae67['en']=_0x5cef10['indexEndName_']),_0x84ae67['ein']=!_0x5cef10['endBeforeSet_']),_0x5cef10['limitSet_']){_0x84ae67['l']=_0x5cef10['limit_'];let _0xe3cdc5=_0x5cef10['viewFrom_'];_0xe3cdc5===''&&(_0x5cef10['isViewFromLeft']()?_0xe3cdc5='l':_0xe3cdc5='r'),_0x84ae67['vf']=_0xe3cdc5;}return _0x5cef10['index_']!==R&&(_0x84ae67['i']=_0x5cef10['index_']['toString']()),_0x84ae67;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x5bb4fb){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x9320b4,_0xf954b){return _0xf954b!==void 0x0?'tag$'+_0xf954b:(f(_0x9320b4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x9320b4['_path']['toString']());}constructor(_0x43de43,_0x576736,_0x36e3e4,_0x566df5){super(),this['repoInfo_']=_0x43de43,this['onDataUpdate_']=_0x576736,this['authTokenProvider_']=_0x36e3e4,this['appCheckTokenProvider_']=_0x566df5,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2eb9ea,_0x11cecc,_0x5a8025,_0x312155){const _0x238b40=_0x2eb9ea['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x238b40+'\x20'+_0x2eb9ea['_queryIdentifier']);const _0x292d88=fn['getListenId_'](_0x2eb9ea,_0x5a8025),_0x52735f={};this['listens_'][_0x292d88]=_0x52735f;const _0x1b57ac=tr(_0x2eb9ea['_queryParams']);this['restRequest_'](_0x238b40+'.json',_0x1b57ac,(_0x4e3055,_0x12cec8)=>{let _0x148df0=_0x12cec8;if(_0x4e3055===0x194&&(_0x148df0=null,_0x4e3055=null),_0x4e3055===null&&this['onDataUpdate_'](_0x238b40,_0x148df0,!0x1,_0x5a8025),Oe(this['listens_'],_0x292d88)===_0x52735f){let _0x33a4c7;_0x4e3055?_0x4e3055===0x191?_0x33a4c7='permission_denied':_0x33a4c7='rest_error:'+_0x4e3055:_0x33a4c7='ok',_0x312155(_0x33a4c7,null);}});}['unlisten'](_0x5d50de,_0x1cf8b6){const _0x450e77=fn['getListenId_'](_0x5d50de,_0x1cf8b6);delete this['listens_'][_0x450e77];}['get'](_0xa35be9){const _0x4280b3=tr(_0xa35be9['_queryParams']),_0x8e2853=_0xa35be9['_path']['toString'](),_0x39048e=new Ve();return this['restRequest_'](_0x8e2853+'.json',_0x4280b3,(_0xd265a0,_0x9ede91)=>{let _0x3d2560=_0x9ede91;_0xd265a0===0x194&&(_0x3d2560=null,_0xd265a0=null),_0xd265a0===null?(this['onDataUpdate_'](_0x8e2853,_0x3d2560,!0x1,null),_0x39048e['resolve'](_0x3d2560)):_0x39048e['reject'](new Error(_0x3d2560));}),_0x39048e['promise'];}['refreshAuthToken'](_0x492811){}['restRequest_'](_0x5d3105,_0x1af772={},_0x4aca00){return _0x1af772['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4c54af,_0x212a6e])=>{_0x4c54af&&_0x4c54af['accessToken']&&(_0x1af772['auth']=_0x4c54af['accessToken']),_0x212a6e&&_0x212a6e['token']&&(_0x1af772['ac']=_0x212a6e['token']);const _0x244e14=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5d3105+'?ns='+this['repoInfo_']['namespace']+at(_0x1af772);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x244e14);const _0x46479b=new XMLHttpRequest();_0x46479b['onreadystatechange']=()=>{if(_0x4aca00&&_0x46479b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x244e14+'\x20received.\x20status:',_0x46479b['status'],'response:',_0x46479b['responseText']);let _0x270f13=null;if(_0x46479b['status']>=0xc8&&_0x46479b['status']<0x12c){try{_0x270f13=bt(_0x46479b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x244e14+':\x20'+_0x46479b['responseText']);}_0x4aca00(null,_0x270f13);}else _0x46479b['status']!==0x191&&_0x46479b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x244e14+'\x20Status:\x20'+_0x46479b['status']),_0x4aca00(_0x46479b['status']);_0x4aca00=null;}},_0x46479b['open']('GET',_0x244e14,!0x0),_0x46479b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x10e566){return this['rootNode_']['getChild'](_0x10e566);}['updateSnapshot'](_0x3da4f7,_0x3a8bd2){this['rootNode_']=this['rootNode_']['updateChild'](_0x3da4f7,_0x3a8bd2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x4f7b2b,_0xaa7c73,_0x3ee502){if(v(_0xaa7c73))_0x4f7b2b['value']=_0x3ee502,_0x4f7b2b['children']['clear']();else{if(_0x4f7b2b['value']!==null)_0x4f7b2b['value']=_0x4f7b2b['value']['updateChild'](_0xaa7c73,_0x3ee502);else{const _0x32e7d7=y(_0xaa7c73);_0x4f7b2b['children']['has'](_0x32e7d7)||_0x4f7b2b['children']['set'](_0x32e7d7,pn());const _0x560efe=_0x4f7b2b['children']['get'](_0x32e7d7);_0xaa7c73=b(_0xaa7c73),Mo(_0x560efe,_0xaa7c73,_0x3ee502);}}}function Ei(_0x5a95c8,_0x589fd1,_0xd73ff9){_0x5a95c8['value']!==null?_0xd73ff9(_0x589fd1,_0x5a95c8['value']):Qh(_0x5a95c8,(_0x5306c1,_0x1b5c9f)=>{const _0x365402=new C(_0x589fd1['toString']()+'/'+_0x5306c1);Ei(_0x1b5c9f,_0x365402,_0xd73ff9);});}function Qh(_0x5a62c7,_0x422eee){_0x5a62c7['children']['forEach']((_0x51ac63,_0x15f277)=>{_0x422eee(_0x15f277,_0x51ac63);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x4abfaa){this['collection_']=_0x4abfaa,this['last_']=null;}['get'](){const _0x38c040=this['collection_']['get'](),_0xd53f1c={..._0x38c040};return this['last_']&&x(this['last_'],(_0x13e913,_0x217ad4)=>{_0xd53f1c[_0x13e913]=_0xd53f1c[_0x13e913]-_0x217ad4;}),this['last_']=_0x38c040,_0xd53f1c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x27102b,_0x316ce8){this['server_']=_0x316ce8,this['statsToReport_']={},this['statsListener_']=new Jh(_0x27102b);const _0x7a4316=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x7a4316));}['reportStats_'](){const _0x700360=this['statsListener_']['get'](),_0x21b6ae={};let _0x267e3b=!0x1;x(_0x700360,(_0x20313f,_0x3a475c)=>{_0x3a475c>0x0&&Y(this['statsToReport_'],_0x20313f)&&(_0x21b6ae[_0x20313f]=_0x3a475c,_0x267e3b=!0x0);}),_0x267e3b&&this['server_']['reportStats'](_0x21b6ae),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x3f424d){_0x3f424d[_0x3f424d['OVERWRITE']=0x0]='OVERWRITE',_0x3f424d[_0x3f424d['MERGE']=0x1]='MERGE',_0x3f424d[_0x3f424d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3f424d[_0x3f424d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2ea76e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2ea76e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x2d03b5,_0x4931da,_0x4f1b3e){this['path']=_0x2d03b5,this['affectedTree']=_0x4931da,this['revert']=_0x4f1b3e,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x598994){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3632e1=this['affectedTree']['subtree'](new C(_0x598994));return new _n(w(),_0x3632e1,this['revert']);}}else return f(y(this['path'])===_0x598994,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x2be28d,_0x25bfa8){this['source']=_0x2be28d,this['path']=_0x25bfa8,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x5df961){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x188bca,_0x51745f,_0x95d3d0){this['source']=_0x188bca,this['path']=_0x51745f,this['snap']=_0x95d3d0,this['type']=q['OVERWRITE'];}['operationForChild'](_0x59ac4c){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x59ac4c)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x579670,_0x5a3887,_0x38ae0d){this['source']=_0x579670,this['path']=_0x5a3887,this['children']=_0x38ae0d,this['type']=q['MERGE'];}['operationForChild'](_0x146ea1){if(v(this['path'])){const _0x170006=this['children']['subtree'](new C(_0x146ea1));return _0x170006['isEmpty']()?null:_0x170006['value']?new Fe(this['source'],w(),_0x170006['value']):new nt(this['source'],w(),_0x170006);}else return f(y(this['path'])===_0x146ea1,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x5398cc,_0x337ed4,_0x2350f0){this['node_']=_0x5398cc,this['fullyInitialized_']=_0x337ed4,this['filtered_']=_0x2350f0;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x339c4e){if(v(_0x339c4e))return this['isFullyInitialized']()&&!this['filtered_'];const _0x11058e=y(_0x339c4e);return this['isCompleteForChild'](_0x11058e);}['isCompleteForChild'](_0x3be863){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3be863);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0xde9b34){this['query_']=_0xde9b34,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x58277b,_0x3f2a1e,_0x328263,_0x32a05c){const _0x53eb84=[],_0x22aa5c=[];return _0x3f2a1e['forEach'](_0x35fdee=>{_0x35fdee['type']==='child_changed'&&_0x58277b['index_']['indexedValueChanged'](_0x35fdee['oldSnap'],_0x35fdee['snapshotNode'])&&_0x22aa5c['push']($h(_0x35fdee['childName'],_0x35fdee['snapshotNode']));}),mt(_0x58277b,_0x53eb84,'child_removed',_0x3f2a1e,_0x32a05c,_0x328263),mt(_0x58277b,_0x53eb84,'child_added',_0x3f2a1e,_0x32a05c,_0x328263),mt(_0x58277b,_0x53eb84,'child_moved',_0x22aa5c,_0x32a05c,_0x328263),mt(_0x58277b,_0x53eb84,'child_changed',_0x3f2a1e,_0x32a05c,_0x328263),mt(_0x58277b,_0x53eb84,'value',_0x3f2a1e,_0x32a05c,_0x328263),_0x53eb84;}function mt(_0x3c3cf9,_0x163bfe,_0x3cf096,_0x2af171,_0x4ee5dc,_0x312772){const _0x285ac5=_0x2af171['filter'](_0x562d31=>_0x562d31['type']===_0x3cf096);_0x285ac5['sort']((_0xee2409,_0x3491dd)=>su(_0x3c3cf9,_0xee2409,_0x3491dd)),_0x285ac5['forEach'](_0x40f5f7=>{const _0x215d81=iu(_0x3c3cf9,_0x40f5f7,_0x312772);_0x4ee5dc['forEach'](_0x1eceda=>{_0x1eceda['respondsTo'](_0x40f5f7['type'])&&_0x163bfe['push'](_0x1eceda['createEvent'](_0x215d81,_0x3c3cf9['query_']));});});}function iu(_0x3fbe98,_0x366024,_0x1f96ad){return _0x366024['type']==='value'||_0x366024['type']==='child_removed'||(_0x366024['prevName']=_0x1f96ad['getPredecessorChildName'](_0x366024['childName'],_0x366024['snapshotNode'],_0x3fbe98['index_'])),_0x366024;}function su(_0x3a3c26,_0x4edf9c,_0x49b45d){if(_0x4edf9c['childName']==null||_0x49b45d['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x15c94c=new E(_0x4edf9c['childName'],_0x4edf9c['snapshotNode']),_0x1508a6=new E(_0x49b45d['childName'],_0x49b45d['snapshotNode']);return _0x3a3c26['index_']['compare'](_0x15c94c,_0x1508a6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x2b48d8,_0x4dc874){return{'eventCache':_0x2b48d8,'serverCache':_0x4dc874};}function wt(_0x184109,_0x285396,_0x4c3e99,_0x548f10){return Dn(new Ce(_0x285396,_0x4c3e99,_0x548f10),_0x184109['serverCache']);}function Lo(_0x57f2a4,_0x44c59c,_0x4603ac,_0x1baf36){return Dn(_0x57f2a4['eventCache'],new Ce(_0x44c59c,_0x4603ac,_0x1baf36));}function gn(_0x239b8c){return _0x239b8c['eventCache']['isFullyInitialized']()?_0x239b8c['eventCache']['getNode']():null;}function Ue(_0xdd898f){return _0xdd898f['serverCache']['isFullyInitialized']()?_0xdd898f['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x360590){let _0x2de88e=new S(null);return x(_0x360590,(_0x531c29,_0x48be96)=>{_0x2de88e=_0x2de88e['set'](new C(_0x531c29),_0x48be96);}),_0x2de88e;}constructor(_0x3f3ba5,_0x2c7299=ru()){this['value']=_0x3f3ba5,this['children']=_0x2c7299;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x158d20,_0x2b37b6){if(this['value']!=null&&_0x2b37b6(this['value']))return{'path':w(),'value':this['value']};if(v(_0x158d20))return null;{const _0x52c702=y(_0x158d20),_0x38578d=this['children']['get'](_0x52c702);if(_0x38578d!==null){const _0x502c5c=_0x38578d['findRootMostMatchingPathAndValue'](b(_0x158d20),_0x2b37b6);return _0x502c5c!=null?{'path':A(new C(_0x52c702),_0x502c5c['path']),'value':_0x502c5c['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1a3273){return this['findRootMostMatchingPathAndValue'](_0x1a3273,()=>!0x0);}['subtree'](_0x443eb3){if(v(_0x443eb3))return this;{const _0x5a3544=y(_0x443eb3),_0x12e3e0=this['children']['get'](_0x5a3544);return _0x12e3e0!==null?_0x12e3e0['subtree'](b(_0x443eb3)):new S(null);}}['set'](_0x3a9df0,_0x4c4f39){if(v(_0x3a9df0))return new S(_0x4c4f39,this['children']);{const _0x4895d1=y(_0x3a9df0),_0x244a77=(this['children']['get'](_0x4895d1)||new S(null))['set'](b(_0x3a9df0),_0x4c4f39),_0x353643=this['children']['insert'](_0x4895d1,_0x244a77);return new S(this['value'],_0x353643);}}['remove'](_0x5e8a88){if(v(_0x5e8a88))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3a73bd=y(_0x5e8a88),_0x55d541=this['children']['get'](_0x3a73bd);if(_0x55d541){const _0x134e1c=_0x55d541['remove'](b(_0x5e8a88));let _0x1f367d;return _0x134e1c['isEmpty']()?_0x1f367d=this['children']['remove'](_0x3a73bd):_0x1f367d=this['children']['insert'](_0x3a73bd,_0x134e1c),this['value']===null&&_0x1f367d['isEmpty']()?new S(null):new S(this['value'],_0x1f367d);}else return this;}}['get'](_0x382e45){if(v(_0x382e45))return this['value'];{const _0x93568f=y(_0x382e45),_0x436b33=this['children']['get'](_0x93568f);return _0x436b33?_0x436b33['get'](b(_0x382e45)):null;}}['setTree'](_0x2d18c5,_0x18b49a){if(v(_0x2d18c5))return _0x18b49a;{const _0x391ed1=y(_0x2d18c5),_0x3508dd=(this['children']['get'](_0x391ed1)||new S(null))['setTree'](b(_0x2d18c5),_0x18b49a);let _0x4f9377;return _0x3508dd['isEmpty']()?_0x4f9377=this['children']['remove'](_0x391ed1):_0x4f9377=this['children']['insert'](_0x391ed1,_0x3508dd),new S(this['value'],_0x4f9377);}}['fold'](_0x1707d6){return this['fold_'](w(),_0x1707d6);}['fold_'](_0x55c15e,_0xd23394){const _0x275018={};return this['children']['inorderTraversal']((_0x4c8dad,_0x2af839)=>{_0x275018[_0x4c8dad]=_0x2af839['fold_'](A(_0x55c15e,_0x4c8dad),_0xd23394);}),_0xd23394(_0x55c15e,this['value'],_0x275018);}['findOnPath'](_0x1eb9f7,_0x353bc1){return this['findOnPath_'](_0x1eb9f7,w(),_0x353bc1);}['findOnPath_'](_0x8c7ce,_0xffc18f,_0x5476e0){const _0xab407d=this['value']?_0x5476e0(_0xffc18f,this['value']):!0x1;if(_0xab407d)return _0xab407d;if(v(_0x8c7ce))return null;{const _0x424003=y(_0x8c7ce),_0x222d84=this['children']['get'](_0x424003);return _0x222d84?_0x222d84['findOnPath_'](b(_0x8c7ce),A(_0xffc18f,_0x424003),_0x5476e0):null;}}['foreachOnPath'](_0x2c5dc2,_0x1729ac){return this['foreachOnPath_'](_0x2c5dc2,w(),_0x1729ac);}['foreachOnPath_'](_0x54b8ff,_0x2c5b9d,_0x22d812){if(v(_0x54b8ff))return this;{this['value']&&_0x22d812(_0x2c5b9d,this['value']);const _0xaa3141=y(_0x54b8ff),_0x26e860=this['children']['get'](_0xaa3141);return _0x26e860?_0x26e860['foreachOnPath_'](b(_0x54b8ff),A(_0x2c5b9d,_0xaa3141),_0x22d812):new S(null);}}['foreach'](_0x35d5da){this['foreach_'](w(),_0x35d5da);}['foreach_'](_0x3299ca,_0x4c2f46){this['children']['inorderTraversal']((_0x18ecc1,_0x26e5ad)=>{_0x26e5ad['foreach_'](A(_0x3299ca,_0x18ecc1),_0x4c2f46);}),this['value']&&_0x4c2f46(_0x3299ca,this['value']);}['foreachChild'](_0x5649fd){this['children']['inorderTraversal']((_0xf213d3,_0x5d3c54)=>{_0x5d3c54['value']&&_0x5649fd(_0xf213d3,_0x5d3c54['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0xa48f0a){this['writeTree_']=_0xa48f0a;}static['empty'](){return new j(new S(null));}}function Ct(_0x2ddebd,_0xe06fb9,_0x277b52){if(v(_0xe06fb9))return new j(new S(_0x277b52));{const _0x15a264=_0x2ddebd['writeTree_']['findRootMostValueAndPath'](_0xe06fb9);if(_0x15a264!=null){const _0x3d5e26=_0x15a264['path'];let _0x1ea6f3=_0x15a264['value'];const _0x2b1eff=F(_0x3d5e26,_0xe06fb9);return _0x1ea6f3=_0x1ea6f3['updateChild'](_0x2b1eff,_0x277b52),new j(_0x2ddebd['writeTree_']['set'](_0x3d5e26,_0x1ea6f3));}else{const _0x5c342c=new S(_0x277b52),_0x29d167=_0x2ddebd['writeTree_']['setTree'](_0xe06fb9,_0x5c342c);return new j(_0x29d167);}}}function Ii(_0x161964,_0x201039,_0x109d49){let _0x38cbf2=_0x161964;return x(_0x109d49,(_0x63f4e2,_0x55275c)=>{_0x38cbf2=Ct(_0x38cbf2,A(_0x201039,_0x63f4e2),_0x55275c);}),_0x38cbf2;}function sr(_0x3458c6,_0x4b71a8){if(v(_0x4b71a8))return j['empty']();{const _0x17e72c=_0x3458c6['writeTree_']['setTree'](_0x4b71a8,new S(null));return new j(_0x17e72c);}}function wi(_0x247aae,_0x56c90c){return $e(_0x247aae,_0x56c90c)!=null;}function $e(_0x486c86,_0x387ee4){const _0x114a21=_0x486c86['writeTree_']['findRootMostValueAndPath'](_0x387ee4);return _0x114a21!=null?_0x486c86['writeTree_']['get'](_0x114a21['path'])['getChild'](F(_0x114a21['path'],_0x387ee4)):null;}function rr(_0x3b92a1){const _0x2c1d97=[],_0xb29345=_0x3b92a1['writeTree_']['value'];return _0xb29345!=null?_0xb29345['isLeafNode']()||_0xb29345['forEachChild'](R,(_0x2476ab,_0x5ee65c)=>{_0x2c1d97['push'](new E(_0x2476ab,_0x5ee65c));}):_0x3b92a1['writeTree_']['children']['inorderTraversal']((_0x3fd70b,_0xa66b6d)=>{_0xa66b6d['value']!=null&&_0x2c1d97['push'](new E(_0x3fd70b,_0xa66b6d['value']));}),_0x2c1d97;}function ve(_0xa1e8cb,_0x42e6ae){if(v(_0x42e6ae))return _0xa1e8cb;{const _0x244445=$e(_0xa1e8cb,_0x42e6ae);return _0x244445!=null?new j(new S(_0x244445)):new j(_0xa1e8cb['writeTree_']['subtree'](_0x42e6ae));}}function Ci(_0x29901d){return _0x29901d['writeTree_']['isEmpty']();}function it(_0x29bf27,_0x4b66e2){return xo(w(),_0x29bf27['writeTree_'],_0x4b66e2);}function xo(_0xf139a,_0x4af3f1,_0x3bb5df){if(_0x4af3f1['value']!=null)return _0x3bb5df['updateChild'](_0xf139a,_0x4af3f1['value']);{let _0x4861ab=null;return _0x4af3f1['children']['inorderTraversal']((_0x370ce2,_0x44c8ee)=>{_0x370ce2==='.priority'?(f(_0x44c8ee['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4861ab=_0x44c8ee['value']):_0x3bb5df=xo(A(_0xf139a,_0x370ce2),_0x44c8ee,_0x3bb5df);}),!_0x3bb5df['getChild'](_0xf139a)['isEmpty']()&&_0x4861ab!==null&&(_0x3bb5df=_0x3bb5df['updateChild'](A(_0xf139a,'.priority'),_0x4861ab)),_0x3bb5df;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x12c806,_0x20bf0e){return Bo(_0x20bf0e,_0x12c806);}function ou(_0x14f831,_0x5b856a,_0x32d838,_0x518ac0,_0x4cc133){f(_0x518ac0>_0x14f831['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4cc133===void 0x0&&(_0x4cc133=!0x0),_0x14f831['allWrites']['push']({'path':_0x5b856a,'snap':_0x32d838,'writeId':_0x518ac0,'visible':_0x4cc133}),_0x4cc133&&(_0x14f831['visibleWrites']=Ct(_0x14f831['visibleWrites'],_0x5b856a,_0x32d838)),_0x14f831['lastWriteId']=_0x518ac0;}function au(_0x1d7b3a,_0x16548e,_0x167af1,_0x5b447d){f(_0x5b447d>_0x1d7b3a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1d7b3a['allWrites']['push']({'path':_0x16548e,'children':_0x167af1,'writeId':_0x5b447d,'visible':!0x0}),_0x1d7b3a['visibleWrites']=Ii(_0x1d7b3a['visibleWrites'],_0x16548e,_0x167af1),_0x1d7b3a['lastWriteId']=_0x5b447d;}function cu(_0x56ece5,_0x1175e2){for(let _0x2944b9=0x0;_0x2944b9<_0x56ece5['allWrites']['length'];_0x2944b9++){const _0xbf4fdb=_0x56ece5['allWrites'][_0x2944b9];if(_0xbf4fdb['writeId']===_0x1175e2)return _0xbf4fdb;}return null;}function lu(_0xe380cb,_0x7c8563){const _0x4ebc0b=_0xe380cb['allWrites']['findIndex'](_0xf079e6=>_0xf079e6['writeId']===_0x7c8563);f(_0x4ebc0b>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x2a4d4f=_0xe380cb['allWrites'][_0x4ebc0b];_0xe380cb['allWrites']['splice'](_0x4ebc0b,0x1);let _0x324e06=_0x2a4d4f['visible'],_0x282441=!0x1,_0x49ab00=_0xe380cb['allWrites']['length']-0x1;for(;_0x324e06&&_0x49ab00>=0x0;){const _0x129548=_0xe380cb['allWrites'][_0x49ab00];_0x129548['visible']&&(_0x49ab00>=_0x4ebc0b&&hu(_0x129548,_0x2a4d4f['path'])?_0x324e06=!0x1:$(_0x2a4d4f['path'],_0x129548['path'])&&(_0x282441=!0x0)),_0x49ab00--;}if(_0x324e06){if(_0x282441)return uu(_0xe380cb),!0x0;if(_0x2a4d4f['snap'])_0xe380cb['visibleWrites']=sr(_0xe380cb['visibleWrites'],_0x2a4d4f['path']);else{const _0x1d5ffb=_0x2a4d4f['children'];x(_0x1d5ffb,_0x18b54f=>{_0xe380cb['visibleWrites']=sr(_0xe380cb['visibleWrites'],A(_0x2a4d4f['path'],_0x18b54f));});}return!0x0;}else return!0x1;}function hu(_0x1eaca4,_0x49abf9){if(_0x1eaca4['snap'])return $(_0x1eaca4['path'],_0x49abf9);for(const _0x15152d in _0x1eaca4['children'])if(_0x1eaca4['children']['hasOwnProperty'](_0x15152d)&&$(A(_0x1eaca4['path'],_0x15152d),_0x49abf9))return!0x0;return!0x1;}function uu(_0x340eca){_0x340eca['visibleWrites']=Fo(_0x340eca['allWrites'],du,w()),_0x340eca['allWrites']['length']>0x0?_0x340eca['lastWriteId']=_0x340eca['allWrites'][_0x340eca['allWrites']['length']-0x1]['writeId']:_0x340eca['lastWriteId']=-0x1;}function du(_0x249de9){return _0x249de9['visible'];}function Fo(_0x2c9640,_0x2ab9cf,_0x13ff5a){let _0x5e16e1=j['empty']();for(let _0x38d730=0x0;_0x38d730<_0x2c9640['length'];++_0x38d730){const _0xc0050=_0x2c9640[_0x38d730];if(_0x2ab9cf(_0xc0050)){const _0x45c28e=_0xc0050['path'];let _0x4e961e;if(_0xc0050['snap'])$(_0x13ff5a,_0x45c28e)?(_0x4e961e=F(_0x13ff5a,_0x45c28e),_0x5e16e1=Ct(_0x5e16e1,_0x4e961e,_0xc0050['snap'])):$(_0x45c28e,_0x13ff5a)&&(_0x4e961e=F(_0x45c28e,_0x13ff5a),_0x5e16e1=Ct(_0x5e16e1,w(),_0xc0050['snap']['getChild'](_0x4e961e)));else{if(_0xc0050['children']){if($(_0x13ff5a,_0x45c28e))_0x4e961e=F(_0x13ff5a,_0x45c28e),_0x5e16e1=Ii(_0x5e16e1,_0x4e961e,_0xc0050['children']);else{if($(_0x45c28e,_0x13ff5a)){if(_0x4e961e=F(_0x45c28e,_0x13ff5a),v(_0x4e961e))_0x5e16e1=Ii(_0x5e16e1,w(),_0xc0050['children']);else{const _0x109d41=Oe(_0xc0050['children'],y(_0x4e961e));if(_0x109d41){const _0x54b321=_0x109d41['getChild'](b(_0x4e961e));_0x5e16e1=Ct(_0x5e16e1,w(),_0x54b321);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5e16e1;}function Uo(_0x3977d8,_0x59cca3,_0x2e00a7,_0x1182b6,_0x9a85d8){if(!_0x1182b6&&!_0x9a85d8){const _0x5ac00e=$e(_0x3977d8['visibleWrites'],_0x59cca3);if(_0x5ac00e!=null)return _0x5ac00e;{const _0x37bb3b=ve(_0x3977d8['visibleWrites'],_0x59cca3);if(Ci(_0x37bb3b))return _0x2e00a7;if(_0x2e00a7==null&&!wi(_0x37bb3b,w()))return null;{const _0x4aa159=_0x2e00a7||g['EMPTY_NODE'];return it(_0x37bb3b,_0x4aa159);}}}else{const _0x3c6ee3=ve(_0x3977d8['visibleWrites'],_0x59cca3);if(!_0x9a85d8&&Ci(_0x3c6ee3))return _0x2e00a7;if(!_0x9a85d8&&_0x2e00a7==null&&!wi(_0x3c6ee3,w()))return null;{const _0x4870df=function(_0x2e0e39){return(_0x2e0e39['visible']||_0x9a85d8)&&(!_0x1182b6||!~_0x1182b6['indexOf'](_0x2e0e39['writeId']))&&($(_0x2e0e39['path'],_0x59cca3)||$(_0x59cca3,_0x2e0e39['path']));},_0x3a6787=Fo(_0x3977d8['allWrites'],_0x4870df,_0x59cca3),_0x10552e=_0x2e00a7||g['EMPTY_NODE'];return it(_0x3a6787,_0x10552e);}}}function fu(_0x19fc4c,_0x4dec8d,_0x4b2380){let _0x20af20=g['EMPTY_NODE'];const _0x24c61f=$e(_0x19fc4c['visibleWrites'],_0x4dec8d);if(_0x24c61f)return _0x24c61f['isLeafNode']()||_0x24c61f['forEachChild'](R,(_0x3901a5,_0x3d75e1)=>{_0x20af20=_0x20af20['updateImmediateChild'](_0x3901a5,_0x3d75e1);}),_0x20af20;if(_0x4b2380){const _0x429908=ve(_0x19fc4c['visibleWrites'],_0x4dec8d);return _0x4b2380['forEachChild'](R,(_0x4324d7,_0x3f0c28)=>{const _0x2c9277=it(ve(_0x429908,new C(_0x4324d7)),_0x3f0c28);_0x20af20=_0x20af20['updateImmediateChild'](_0x4324d7,_0x2c9277);}),rr(_0x429908)['forEach'](_0x38bceb=>{_0x20af20=_0x20af20['updateImmediateChild'](_0x38bceb['name'],_0x38bceb['node']);}),_0x20af20;}else{const _0x5b8232=ve(_0x19fc4c['visibleWrites'],_0x4dec8d);return rr(_0x5b8232)['forEach'](_0x51789a=>{_0x20af20=_0x20af20['updateImmediateChild'](_0x51789a['name'],_0x51789a['node']);}),_0x20af20;}}function pu(_0x399ee2,_0x339785,_0x4eb8dc,_0x3f0c65,_0x4f7d2b){f(_0x3f0c65||_0x4f7d2b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xbf3495=A(_0x339785,_0x4eb8dc);if(wi(_0x399ee2['visibleWrites'],_0xbf3495))return null;{const _0x582694=ve(_0x399ee2['visibleWrites'],_0xbf3495);return Ci(_0x582694)?_0x4f7d2b['getChild'](_0x4eb8dc):it(_0x582694,_0x4f7d2b['getChild'](_0x4eb8dc));}}function _u(_0x136545,_0x414918,_0x4d4e7b,_0xcc3d0c){const _0x2470ba=A(_0x414918,_0x4d4e7b),_0xaee945=$e(_0x136545['visibleWrites'],_0x2470ba);if(_0xaee945!=null)return _0xaee945;if(_0xcc3d0c['isCompleteForChild'](_0x4d4e7b)){const _0x438855=ve(_0x136545['visibleWrites'],_0x2470ba);return it(_0x438855,_0xcc3d0c['getNode']()['getImmediateChild'](_0x4d4e7b));}else return null;}function gu(_0x2839a1,_0x1c614c){return $e(_0x2839a1['visibleWrites'],_0x1c614c);}function mu(_0x451304,_0x289e10,_0x8faaf9,_0x488284,_0x391848,_0x1f93a1,_0x296deb){let _0x45d4aa;const _0x3bc56f=ve(_0x451304['visibleWrites'],_0x289e10),_0x3203f4=$e(_0x3bc56f,w());if(_0x3203f4!=null)_0x45d4aa=_0x3203f4;else{if(_0x8faaf9!=null)_0x45d4aa=it(_0x3bc56f,_0x8faaf9);else return[];}if(_0x45d4aa=_0x45d4aa['withIndex'](_0x296deb),!_0x45d4aa['isEmpty']()&&!_0x45d4aa['isLeafNode']()){const _0x2a0b0d=[],_0x52a297=_0x296deb['getCompare'](),_0x213191=_0x1f93a1?_0x45d4aa['getReverseIteratorFrom'](_0x488284,_0x296deb):_0x45d4aa['getIteratorFrom'](_0x488284,_0x296deb);let _0x38e2f4=_0x213191['getNext']();for(;_0x38e2f4&&_0x2a0b0d['length']<_0x391848;)_0x52a297(_0x38e2f4,_0x488284)!==0x0&&_0x2a0b0d['push'](_0x38e2f4),_0x38e2f4=_0x213191['getNext']();return _0x2a0b0d;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5c7b2b,_0x4e6422,_0x5808a6,_0x471b89){return Uo(_0x5c7b2b['writeTree'],_0x5c7b2b['treePath'],_0x4e6422,_0x5808a6,_0x471b89);}function es(_0x465672,_0x544a56){return fu(_0x465672['writeTree'],_0x465672['treePath'],_0x544a56);}function or(_0x14f587,_0x4d56b4,_0x365f95,_0x5ec512){return pu(_0x14f587['writeTree'],_0x14f587['treePath'],_0x4d56b4,_0x365f95,_0x5ec512);}function yn(_0x5f3bbe,_0x5d1ada){return gu(_0x5f3bbe['writeTree'],A(_0x5f3bbe['treePath'],_0x5d1ada));}function vu(_0x4a967a,_0x20d25f,_0x34ec0b,_0x5ba7b9,_0xf3f7ad,_0x288547){return mu(_0x4a967a['writeTree'],_0x4a967a['treePath'],_0x20d25f,_0x34ec0b,_0x5ba7b9,_0xf3f7ad,_0x288547);}function ts(_0x3798c3,_0x18d32f,_0x40b194){return _u(_0x3798c3['writeTree'],_0x3798c3['treePath'],_0x18d32f,_0x40b194);}function Wo(_0x268daf,_0x2d9b0f){return Bo(A(_0x268daf['treePath'],_0x2d9b0f),_0x268daf['writeTree']);}function Bo(_0x1c7993,_0x51c813){return{'treePath':_0x1c7993,'writeTree':_0x51c813};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x31dd5f){const _0x3f13fd=_0x31dd5f['type'],_0x41c01b=_0x31dd5f['childName'];f(_0x3f13fd==='child_added'||_0x3f13fd==='child_changed'||_0x3f13fd==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x41c01b!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x14c43c=this['changeMap']['get'](_0x41c01b);if(_0x14c43c){const _0x4afdcb=_0x14c43c['type'];if(_0x3f13fd==='child_added'&&_0x4afdcb==='child_removed')this['changeMap']['set'](_0x41c01b,Pt(_0x41c01b,_0x31dd5f['snapshotNode'],_0x14c43c['snapshotNode']));else{if(_0x3f13fd==='child_removed'&&_0x4afdcb==='child_added')this['changeMap']['delete'](_0x41c01b);else{if(_0x3f13fd==='child_removed'&&_0x4afdcb==='child_changed')this['changeMap']['set'](_0x41c01b,Nt(_0x41c01b,_0x14c43c['oldSnap']));else{if(_0x3f13fd==='child_changed'&&_0x4afdcb==='child_added')this['changeMap']['set'](_0x41c01b,tt(_0x41c01b,_0x31dd5f['snapshotNode']));else{if(_0x3f13fd==='child_changed'&&_0x4afdcb==='child_changed')this['changeMap']['set'](_0x41c01b,Pt(_0x41c01b,_0x31dd5f['snapshotNode'],_0x14c43c['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x31dd5f+'\x20occurred\x20after\x20'+_0x14c43c);}}}}}else this['changeMap']['set'](_0x41c01b,_0x31dd5f);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x1bf886){return null;}['getChildAfterChild'](_0x31d0bd,_0x322cdf,_0x53b2c0){return null;}}const Vo=new Iu();class ns{constructor(_0x2fc068,_0x114404,_0x43505a=null){this['writes_']=_0x2fc068,this['viewCache_']=_0x114404,this['optCompleteServerCache_']=_0x43505a;}['getCompleteChild'](_0x29481d){const _0x365ac1=this['viewCache_']['eventCache'];if(_0x365ac1['isCompleteForChild'](_0x29481d))return _0x365ac1['getNode']()['getImmediateChild'](_0x29481d);{const _0x5ef9d4=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x29481d,_0x5ef9d4);}}['getChildAfterChild'](_0x1089e1,_0x3c2722,_0x2b8f33){const _0x1632a9=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x3b2442=vu(this['writes_'],_0x1632a9,_0x3c2722,0x1,_0x2b8f33,_0x1089e1);return _0x3b2442['length']===0x0?null:_0x3b2442[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x576d8d){return{'filter':_0x576d8d};}function Cu(_0xabd1d4,_0x1a01b5){f(_0x1a01b5['eventCache']['getNode']()['isIndexed'](_0xabd1d4['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1a01b5['serverCache']['getNode']()['isIndexed'](_0xabd1d4['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x4cf542,_0x2dfa9b,_0x9f696d,_0x11c729,_0x2143c4){const _0x24f9d2=new Eu();let _0x44ec2f,_0x18725d;if(_0x9f696d['type']===q['OVERWRITE']){const _0x580762=_0x9f696d;_0x580762['source']['fromUser']?_0x44ec2f=Ti(_0x4cf542,_0x2dfa9b,_0x580762['path'],_0x580762['snap'],_0x11c729,_0x2143c4,_0x24f9d2):(f(_0x580762['source']['fromServer'],'Unknown\x20source.'),_0x18725d=_0x580762['source']['tagged']||_0x2dfa9b['serverCache']['isFiltered']()&&!v(_0x580762['path']),_0x44ec2f=vn(_0x4cf542,_0x2dfa9b,_0x580762['path'],_0x580762['snap'],_0x11c729,_0x2143c4,_0x18725d,_0x24f9d2));}else{if(_0x9f696d['type']===q['MERGE']){const _0x561e38=_0x9f696d;_0x561e38['source']['fromUser']?_0x44ec2f=bu(_0x4cf542,_0x2dfa9b,_0x561e38['path'],_0x561e38['children'],_0x11c729,_0x2143c4,_0x24f9d2):(f(_0x561e38['source']['fromServer'],'Unknown\x20source.'),_0x18725d=_0x561e38['source']['tagged']||_0x2dfa9b['serverCache']['isFiltered'](),_0x44ec2f=Si(_0x4cf542,_0x2dfa9b,_0x561e38['path'],_0x561e38['children'],_0x11c729,_0x2143c4,_0x18725d,_0x24f9d2));}else{if(_0x9f696d['type']===q['ACK_USER_WRITE']){const _0x369244=_0x9f696d;_0x369244['revert']?_0x44ec2f=ku(_0x4cf542,_0x2dfa9b,_0x369244['path'],_0x11c729,_0x2143c4,_0x24f9d2):_0x44ec2f=Ru(_0x4cf542,_0x2dfa9b,_0x369244['path'],_0x369244['affectedTree'],_0x11c729,_0x2143c4,_0x24f9d2);}else{if(_0x9f696d['type']===q['LISTEN_COMPLETE'])_0x44ec2f=Au(_0x4cf542,_0x2dfa9b,_0x9f696d['path'],_0x11c729,_0x24f9d2);else throw ot('Unknown\x20operation\x20type:\x20'+_0x9f696d['type']);}}}const _0x366479=_0x24f9d2['getChanges']();return Su(_0x2dfa9b,_0x44ec2f,_0x366479),{'viewCache':_0x44ec2f,'changes':_0x366479};}function Su(_0x4b14c4,_0x597f99,_0xf1e30){const _0x4963f4=_0x597f99['eventCache'];if(_0x4963f4['isFullyInitialized']()){const _0x19c0a7=_0x4963f4['getNode']()['isLeafNode']()||_0x4963f4['getNode']()['isEmpty'](),_0x2cbc9a=gn(_0x4b14c4);(_0xf1e30['length']>0x0||!_0x4b14c4['eventCache']['isFullyInitialized']()||_0x19c0a7&&!_0x4963f4['getNode']()['equals'](_0x2cbc9a)||!_0x4963f4['getNode']()['getPriority']()['equals'](_0x2cbc9a['getPriority']()))&&_0xf1e30['push'](Oo(gn(_0x597f99)));}}function Ho(_0x904452,_0x35bad2,_0x176aed,_0x198cbe,_0x527875,_0x48f23a){const _0xcc0f94=_0x35bad2['eventCache'];if(yn(_0x198cbe,_0x176aed)!=null)return _0x35bad2;{let _0x386892,_0x195983;if(v(_0x176aed)){if(f(_0x35bad2['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x35bad2['serverCache']['isFiltered']()){const _0x10218e=Ue(_0x35bad2),_0x4c817a=_0x10218e instanceof g?_0x10218e:g['EMPTY_NODE'],_0x513907=es(_0x198cbe,_0x4c817a);_0x386892=_0x904452['filter']['updateFullNode'](_0x35bad2['eventCache']['getNode'](),_0x513907,_0x48f23a);}else{const _0x47bedb=mn(_0x198cbe,Ue(_0x35bad2));_0x386892=_0x904452['filter']['updateFullNode'](_0x35bad2['eventCache']['getNode'](),_0x47bedb,_0x48f23a);}}else{const _0x247a9a=y(_0x176aed);if(_0x247a9a==='.priority'){f(we(_0x176aed)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x294902=_0xcc0f94['getNode']();_0x195983=_0x35bad2['serverCache']['getNode']();const _0x3a769c=or(_0x198cbe,_0x176aed,_0x294902,_0x195983);_0x3a769c!=null?_0x386892=_0x904452['filter']['updatePriority'](_0x294902,_0x3a769c):_0x386892=_0xcc0f94['getNode']();}else{const _0x43d6d1=b(_0x176aed);let _0x573a42;if(_0xcc0f94['isCompleteForChild'](_0x247a9a)){_0x195983=_0x35bad2['serverCache']['getNode']();const _0x5bc5fe=or(_0x198cbe,_0x176aed,_0xcc0f94['getNode'](),_0x195983);_0x5bc5fe!=null?_0x573a42=_0xcc0f94['getNode']()['getImmediateChild'](_0x247a9a)['updateChild'](_0x43d6d1,_0x5bc5fe):_0x573a42=_0xcc0f94['getNode']()['getImmediateChild'](_0x247a9a);}else _0x573a42=ts(_0x198cbe,_0x247a9a,_0x35bad2['serverCache']);_0x573a42!=null?_0x386892=_0x904452['filter']['updateChild'](_0xcc0f94['getNode'](),_0x247a9a,_0x573a42,_0x43d6d1,_0x527875,_0x48f23a):_0x386892=_0xcc0f94['getNode']();}}return wt(_0x35bad2,_0x386892,_0xcc0f94['isFullyInitialized']()||v(_0x176aed),_0x904452['filter']['filtersNodes']());}}function vn(_0xf21753,_0x4603c5,_0x1081b9,_0x568149,_0x3fbf31,_0x27369b,_0x29c4fd,_0x31501a){const _0x464af5=_0x4603c5['serverCache'];let _0x37dac2;const _0x368509=_0x29c4fd?_0xf21753['filter']:_0xf21753['filter']['getIndexedFilter']();if(v(_0x1081b9))_0x37dac2=_0x368509['updateFullNode'](_0x464af5['getNode'](),_0x568149,null);else{if(_0x368509['filtersNodes']()&&!_0x464af5['isFiltered']()){const _0x1a13f7=_0x464af5['getNode']()['updateChild'](_0x1081b9,_0x568149);_0x37dac2=_0x368509['updateFullNode'](_0x464af5['getNode'](),_0x1a13f7,null);}else{const _0x3b0e15=y(_0x1081b9);if(!_0x464af5['isCompleteForPath'](_0x1081b9)&&we(_0x1081b9)>0x1)return _0x4603c5;const _0x1b404b=b(_0x1081b9),_0x25c44d=_0x464af5['getNode']()['getImmediateChild'](_0x3b0e15)['updateChild'](_0x1b404b,_0x568149);_0x3b0e15==='.priority'?_0x37dac2=_0x368509['updatePriority'](_0x464af5['getNode'](),_0x25c44d):_0x37dac2=_0x368509['updateChild'](_0x464af5['getNode'](),_0x3b0e15,_0x25c44d,_0x1b404b,Vo,null);}}const _0x2bef11=Lo(_0x4603c5,_0x37dac2,_0x464af5['isFullyInitialized']()||v(_0x1081b9),_0x368509['filtersNodes']()),_0x295987=new ns(_0x3fbf31,_0x2bef11,_0x27369b);return Ho(_0xf21753,_0x2bef11,_0x1081b9,_0x3fbf31,_0x295987,_0x31501a);}function Ti(_0x3ecd99,_0x277983,_0x4caec1,_0x409078,_0x325a3b,_0x52bcdf,_0xb7eca4){const _0x59fcc6=_0x277983['eventCache'];let _0x126b7d,_0x2577fd;const _0x2a4ad3=new ns(_0x325a3b,_0x277983,_0x52bcdf);if(v(_0x4caec1))_0x2577fd=_0x3ecd99['filter']['updateFullNode'](_0x277983['eventCache']['getNode'](),_0x409078,_0xb7eca4),_0x126b7d=wt(_0x277983,_0x2577fd,!0x0,_0x3ecd99['filter']['filtersNodes']());else{const _0x58cf91=y(_0x4caec1);if(_0x58cf91==='.priority')_0x2577fd=_0x3ecd99['filter']['updatePriority'](_0x277983['eventCache']['getNode'](),_0x409078),_0x126b7d=wt(_0x277983,_0x2577fd,_0x59fcc6['isFullyInitialized'](),_0x59fcc6['isFiltered']());else{const _0x3f3146=b(_0x4caec1),_0x3b6490=_0x59fcc6['getNode']()['getImmediateChild'](_0x58cf91);let _0x380132;if(v(_0x3f3146))_0x380132=_0x409078;else{const _0x494069=_0x2a4ad3['getCompleteChild'](_0x58cf91);_0x494069!=null?Gi(_0x3f3146)==='.priority'&&_0x494069['getChild'](To(_0x3f3146))['isEmpty']()?_0x380132=_0x494069:_0x380132=_0x494069['updateChild'](_0x3f3146,_0x409078):_0x380132=g['EMPTY_NODE'];}if(_0x3b6490['equals'](_0x380132))_0x126b7d=_0x277983;else{const _0x5a2736=_0x3ecd99['filter']['updateChild'](_0x59fcc6['getNode'](),_0x58cf91,_0x380132,_0x3f3146,_0x2a4ad3,_0xb7eca4);_0x126b7d=wt(_0x277983,_0x5a2736,_0x59fcc6['isFullyInitialized'](),_0x3ecd99['filter']['filtersNodes']());}}}return _0x126b7d;}function ar(_0x531d5b,_0x8ed20c){return _0x531d5b['eventCache']['isCompleteForChild'](_0x8ed20c);}function bu(_0x54662a,_0x5950cc,_0x55e006,_0x3945f7,_0x4fc06f,_0x35bda1,_0x30b4be){let _0x1d6bb5=_0x5950cc;return _0x3945f7['foreach']((_0x3b4726,_0x319c78)=>{const _0x39b750=A(_0x55e006,_0x3b4726);ar(_0x5950cc,y(_0x39b750))&&(_0x1d6bb5=Ti(_0x54662a,_0x1d6bb5,_0x39b750,_0x319c78,_0x4fc06f,_0x35bda1,_0x30b4be));}),_0x3945f7['foreach']((_0xe568bc,_0xf6866d)=>{const _0x28a26e=A(_0x55e006,_0xe568bc);ar(_0x5950cc,y(_0x28a26e))||(_0x1d6bb5=Ti(_0x54662a,_0x1d6bb5,_0x28a26e,_0xf6866d,_0x4fc06f,_0x35bda1,_0x30b4be));}),_0x1d6bb5;}function cr(_0x4d4fe2,_0x4e4981,_0x55d47e){return _0x55d47e['foreach']((_0x3c36be,_0xddca51)=>{_0x4e4981=_0x4e4981['updateChild'](_0x3c36be,_0xddca51);}),_0x4e4981;}function Si(_0x49b077,_0x1c340b,_0x4396e4,_0x1d57bb,_0x2f18a5,_0x35ad4b,_0x47d35c,_0x2feefe){if(_0x1c340b['serverCache']['getNode']()['isEmpty']()&&!_0x1c340b['serverCache']['isFullyInitialized']())return _0x1c340b;let _0x5bab5e=_0x1c340b,_0x50c405;v(_0x4396e4)?_0x50c405=_0x1d57bb:_0x50c405=new S(null)['setTree'](_0x4396e4,_0x1d57bb);const _0x48f47d=_0x1c340b['serverCache']['getNode']();return _0x50c405['children']['inorderTraversal']((_0x5ce277,_0x1c67b2)=>{if(_0x48f47d['hasChild'](_0x5ce277)){const _0x57bc94=_0x1c340b['serverCache']['getNode']()['getImmediateChild'](_0x5ce277),_0x3054c5=cr(_0x49b077,_0x57bc94,_0x1c67b2);_0x5bab5e=vn(_0x49b077,_0x5bab5e,new C(_0x5ce277),_0x3054c5,_0x2f18a5,_0x35ad4b,_0x47d35c,_0x2feefe);}}),_0x50c405['children']['inorderTraversal']((_0x18e55a,_0x5acd57)=>{const _0x40f4ba=!_0x1c340b['serverCache']['isCompleteForChild'](_0x18e55a)&&_0x5acd57['value']===null;if(!_0x48f47d['hasChild'](_0x18e55a)&&!_0x40f4ba){const _0x41dca6=_0x1c340b['serverCache']['getNode']()['getImmediateChild'](_0x18e55a),_0x55a492=cr(_0x49b077,_0x41dca6,_0x5acd57);_0x5bab5e=vn(_0x49b077,_0x5bab5e,new C(_0x18e55a),_0x55a492,_0x2f18a5,_0x35ad4b,_0x47d35c,_0x2feefe);}}),_0x5bab5e;}function Ru(_0x278c86,_0x489212,_0x338b00,_0x44fb18,_0x2c6bfd,_0x3bfdcf,_0xbe6df8){if(yn(_0x2c6bfd,_0x338b00)!=null)return _0x489212;const _0x316da3=_0x489212['serverCache']['isFiltered'](),_0x1b9596=_0x489212['serverCache'];if(_0x44fb18['value']!=null){if(v(_0x338b00)&&_0x1b9596['isFullyInitialized']()||_0x1b9596['isCompleteForPath'](_0x338b00))return vn(_0x278c86,_0x489212,_0x338b00,_0x1b9596['getNode']()['getChild'](_0x338b00),_0x2c6bfd,_0x3bfdcf,_0x316da3,_0xbe6df8);if(v(_0x338b00)){let _0x25a788=new S(null);return _0x1b9596['getNode']()['forEachChild'](ye,(_0x4fa19d,_0xc31dae)=>{_0x25a788=_0x25a788['set'](new C(_0x4fa19d),_0xc31dae);}),Si(_0x278c86,_0x489212,_0x338b00,_0x25a788,_0x2c6bfd,_0x3bfdcf,_0x316da3,_0xbe6df8);}else return _0x489212;}else{let _0x1045c9=new S(null);return _0x44fb18['foreach']((_0x4e062a,_0x8a3038)=>{const _0x32f459=A(_0x338b00,_0x4e062a);_0x1b9596['isCompleteForPath'](_0x32f459)&&(_0x1045c9=_0x1045c9['set'](_0x4e062a,_0x1b9596['getNode']()['getChild'](_0x32f459)));}),Si(_0x278c86,_0x489212,_0x338b00,_0x1045c9,_0x2c6bfd,_0x3bfdcf,_0x316da3,_0xbe6df8);}}function Au(_0x2fb0d0,_0x2aca85,_0x5a9676,_0x1229b2,_0x192437){const _0x263151=_0x2aca85['serverCache'],_0x715b2b=Lo(_0x2aca85,_0x263151['getNode'](),_0x263151['isFullyInitialized']()||v(_0x5a9676),_0x263151['isFiltered']());return Ho(_0x2fb0d0,_0x715b2b,_0x5a9676,_0x1229b2,Vo,_0x192437);}function ku(_0x1f447b,_0x4d97d7,_0x5b84c2,_0x4799ef,_0x5803a9,_0x17fc0e){let _0x267919;if(yn(_0x4799ef,_0x5b84c2)!=null)return _0x4d97d7;{const _0x4d6902=new ns(_0x4799ef,_0x4d97d7,_0x5803a9),_0x19ca2e=_0x4d97d7['eventCache']['getNode']();let _0x308b93;if(v(_0x5b84c2)||y(_0x5b84c2)==='.priority'){let _0x53ab29;if(_0x4d97d7['serverCache']['isFullyInitialized']())_0x53ab29=mn(_0x4799ef,Ue(_0x4d97d7));else{const _0x153b71=_0x4d97d7['serverCache']['getNode']();f(_0x153b71 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x53ab29=es(_0x4799ef,_0x153b71);}_0x53ab29=_0x53ab29,_0x308b93=_0x1f447b['filter']['updateFullNode'](_0x19ca2e,_0x53ab29,_0x17fc0e);}else{const _0x14d06a=y(_0x5b84c2);let _0x4f70ac=ts(_0x4799ef,_0x14d06a,_0x4d97d7['serverCache']);_0x4f70ac==null&&_0x4d97d7['serverCache']['isCompleteForChild'](_0x14d06a)&&(_0x4f70ac=_0x19ca2e['getImmediateChild'](_0x14d06a)),_0x4f70ac!=null?_0x308b93=_0x1f447b['filter']['updateChild'](_0x19ca2e,_0x14d06a,_0x4f70ac,b(_0x5b84c2),_0x4d6902,_0x17fc0e):_0x4d97d7['eventCache']['getNode']()['hasChild'](_0x14d06a)?_0x308b93=_0x1f447b['filter']['updateChild'](_0x19ca2e,_0x14d06a,g['EMPTY_NODE'],b(_0x5b84c2),_0x4d6902,_0x17fc0e):_0x308b93=_0x19ca2e,_0x308b93['isEmpty']()&&_0x4d97d7['serverCache']['isFullyInitialized']()&&(_0x267919=mn(_0x4799ef,Ue(_0x4d97d7)),_0x267919['isLeafNode']()&&(_0x308b93=_0x1f447b['filter']['updateFullNode'](_0x308b93,_0x267919,_0x17fc0e)));}return _0x267919=_0x4d97d7['serverCache']['isFullyInitialized']()||yn(_0x4799ef,w())!=null,wt(_0x4d97d7,_0x308b93,_0x267919,_0x1f447b['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x215822,_0x24b6a4){this['query_']=_0x215822,this['eventRegistrations_']=[];const _0xba8a04=this['query_']['_queryParams'],_0x2f19da=new Yi(_0xba8a04['getIndex']()),_0x1111e1=qh(_0xba8a04);this['processor_']=wu(_0x1111e1);const _0xbb56bc=_0x24b6a4['serverCache'],_0x320b0a=_0x24b6a4['eventCache'],_0x58c535=_0x2f19da['updateFullNode'](g['EMPTY_NODE'],_0xbb56bc['getNode'](),null),_0x59722e=_0x1111e1['updateFullNode'](g['EMPTY_NODE'],_0x320b0a['getNode'](),null),_0x1ac312=new Ce(_0x58c535,_0xbb56bc['isFullyInitialized'](),_0x2f19da['filtersNodes']()),_0xa71527=new Ce(_0x59722e,_0x320b0a['isFullyInitialized'](),_0x1111e1['filtersNodes']());this['viewCache_']=Dn(_0xa71527,_0x1ac312),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x105e43){return _0x105e43['viewCache_']['serverCache']['getNode']();}function Ou(_0x28e06f){return gn(_0x28e06f['viewCache_']);}function Du(_0x2ee564,_0x253446){const _0x24ba2f=Ue(_0x2ee564['viewCache_']);return _0x24ba2f&&(_0x2ee564['query']['_queryParams']['loadsAllData']()||!v(_0x253446)&&!_0x24ba2f['getImmediateChild'](y(_0x253446))['isEmpty']())?_0x24ba2f['getChild'](_0x253446):null;}function lr(_0xba31fc){return _0xba31fc['eventRegistrations_']['length']===0x0;}function Mu(_0x50c05d,_0x43528b){_0x50c05d['eventRegistrations_']['push'](_0x43528b);}function hr(_0x15453d,_0x6b2d12,_0x3c54af){const _0xd8061e=[];if(_0x3c54af){f(_0x6b2d12==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0xa2d769=_0x15453d['query']['_path'];_0x15453d['eventRegistrations_']['forEach'](_0x47ac98=>{const _0x23bbb7=_0x47ac98['createCancelEvent'](_0x3c54af,_0xa2d769);_0x23bbb7&&_0xd8061e['push'](_0x23bbb7);});}if(_0x6b2d12){let _0x349d50=[];for(let _0x121bc0=0x0;_0x121bc0<_0x15453d['eventRegistrations_']['length'];++_0x121bc0){const _0x2ebc1e=_0x15453d['eventRegistrations_'][_0x121bc0];if(!_0x2ebc1e['matches'](_0x6b2d12))_0x349d50['push'](_0x2ebc1e);else{if(_0x6b2d12['hasAnyCallback']()){_0x349d50=_0x349d50['concat'](_0x15453d['eventRegistrations_']['slice'](_0x121bc0+0x1));break;}}}_0x15453d['eventRegistrations_']=_0x349d50;}else _0x15453d['eventRegistrations_']=[];return _0xd8061e;}function ur(_0x59f62e,_0x2867cc,_0x50114d,_0xa30589){_0x2867cc['type']===q['MERGE']&&_0x2867cc['source']['queryId']!==null&&(f(Ue(_0x59f62e['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x59f62e['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x172d93=_0x59f62e['viewCache_'],_0x492ba4=Tu(_0x59f62e['processor_'],_0x172d93,_0x2867cc,_0x50114d,_0xa30589);return Cu(_0x59f62e['processor_'],_0x492ba4['viewCache']),f(_0x492ba4['viewCache']['serverCache']['isFullyInitialized']()||!_0x172d93['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x59f62e['viewCache_']=_0x492ba4['viewCache'],$o(_0x59f62e,_0x492ba4['changes'],_0x492ba4['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x47178c,_0xabafe4){const _0x142bc0=_0x47178c['viewCache_']['eventCache'],_0x3e4b4b=[];return _0x142bc0['getNode']()['isLeafNode']()||_0x142bc0['getNode']()['forEachChild'](R,(_0x8db6ea,_0x4771e2)=>{_0x3e4b4b['push'](tt(_0x8db6ea,_0x4771e2));}),_0x142bc0['isFullyInitialized']()&&_0x3e4b4b['push'](Oo(_0x142bc0['getNode']())),$o(_0x47178c,_0x3e4b4b,_0x142bc0['getNode'](),_0xabafe4);}function $o(_0xd1e857,_0x307c3a,_0x445a1a,_0x4623a3){const _0x46240a=_0x4623a3?[_0x4623a3]:_0xd1e857['eventRegistrations_'];return nu(_0xd1e857['eventGenerator_'],_0x307c3a,_0x445a1a,_0x46240a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xb99a64){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xb99a64;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x4f0808){return _0x4f0808['views']['size']===0x0;}function is(_0x324562,_0x1a5910,_0x476281,_0x4c048e){const _0x3869c0=_0x1a5910['source']['queryId'];if(_0x3869c0!==null){const _0x16e9a8=_0x324562['views']['get'](_0x3869c0);return f(_0x16e9a8!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x16e9a8,_0x1a5910,_0x476281,_0x4c048e);}else{let _0x505d15=[];for(const _0x2c3452 of _0x324562['views']['values']())_0x505d15=_0x505d15['concat'](ur(_0x2c3452,_0x1a5910,_0x476281,_0x4c048e));return _0x505d15;}}function qo(_0x1ccf21,_0x43ee6b,_0x3e7e6e,_0x99557c,_0x1269a8){const _0x17d63a=_0x43ee6b['_queryIdentifier'],_0x204113=_0x1ccf21['views']['get'](_0x17d63a);if(!_0x204113){let _0x272220=mn(_0x3e7e6e,_0x1269a8?_0x99557c:null),_0xcb48e=!0x1;_0x272220?_0xcb48e=!0x0:_0x99557c instanceof g?(_0x272220=es(_0x3e7e6e,_0x99557c),_0xcb48e=!0x1):(_0x272220=g['EMPTY_NODE'],_0xcb48e=!0x1);const _0x4d53ff=Dn(new Ce(_0x272220,_0xcb48e,!0x1),new Ce(_0x99557c,_0x1269a8,!0x1));return new Nu(_0x43ee6b,_0x4d53ff);}return _0x204113;}function Wu(_0x25a8f5,_0x541ff2,_0x5d506e,_0x1d19d0,_0x3750a1,_0x5d166d){const _0x2f8c7c=qo(_0x25a8f5,_0x541ff2,_0x1d19d0,_0x3750a1,_0x5d166d);return _0x25a8f5['views']['has'](_0x541ff2['_queryIdentifier'])||_0x25a8f5['views']['set'](_0x541ff2['_queryIdentifier'],_0x2f8c7c),Mu(_0x2f8c7c,_0x5d506e),Lu(_0x2f8c7c,_0x5d506e);}function Bu(_0x10c904,_0x83391d,_0x437667,_0x2a0296){const _0x19d11a=_0x83391d['_queryIdentifier'],_0x5ead94=[];let _0x2a4233=[];const _0x2a2cc3=Te(_0x10c904);if(_0x19d11a==='default'){for(const [_0xd06834,_0x595af9]of _0x10c904['views']['entries']())_0x2a4233=_0x2a4233['concat'](hr(_0x595af9,_0x437667,_0x2a0296)),lr(_0x595af9)&&(_0x10c904['views']['delete'](_0xd06834),_0x595af9['query']['_queryParams']['loadsAllData']()||_0x5ead94['push'](_0x595af9['query']));}else{const _0x2b8552=_0x10c904['views']['get'](_0x19d11a);_0x2b8552&&(_0x2a4233=_0x2a4233['concat'](hr(_0x2b8552,_0x437667,_0x2a0296)),lr(_0x2b8552)&&(_0x10c904['views']['delete'](_0x19d11a),_0x2b8552['query']['_queryParams']['loadsAllData']()||_0x5ead94['push'](_0x2b8552['query'])));}return _0x2a2cc3&&!Te(_0x10c904)&&_0x5ead94['push'](new(Fu())(_0x83391d['_repo'],_0x83391d['_path'])),{'removed':_0x5ead94,'events':_0x2a4233};}function zo(_0x1208a9){const _0x3102ea=[];for(const _0x517e6c of _0x1208a9['views']['values']())_0x517e6c['query']['_queryParams']['loadsAllData']()||_0x3102ea['push'](_0x517e6c);return _0x3102ea;}function Ee(_0x3ca196,_0x2deed1){let _0x3078a0=null;for(const _0x4357a2 of _0x3ca196['views']['values']())_0x3078a0=_0x3078a0||Du(_0x4357a2,_0x2deed1);return _0x3078a0;}function jo(_0xdba234,_0x52e874){if(_0x52e874['_queryParams']['loadsAllData']())return Ln(_0xdba234);{const _0x266c09=_0x52e874['_queryIdentifier'];return _0xdba234['views']['get'](_0x266c09);}}function Ko(_0x5b8d6e,_0x1923d4){return jo(_0x5b8d6e,_0x1923d4)!=null;}function Te(_0x32c93e){return Ln(_0x32c93e)!=null;}function Ln(_0x1ffcc7){for(const _0x182dcc of _0x1ffcc7['views']['values']())if(_0x182dcc['query']['_queryParams']['loadsAllData']())return _0x182dcc;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x244ea6){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x244ea6;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x504315){this['listenProvider_']=_0x504315,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x4379f3,_0x45fc96,_0x2ce5ad,_0x2e72c6,_0x13203f){return ou(_0x4379f3['pendingWriteTree_'],_0x45fc96,_0x2ce5ad,_0x2e72c6,_0x13203f),_0x13203f?ht(_0x4379f3,new Fe(Ji(),_0x45fc96,_0x2ce5ad)):[];}function Gu(_0x597786,_0x1a3cff,_0x464629,_0xf17330){au(_0x597786['pendingWriteTree_'],_0x1a3cff,_0x464629,_0xf17330);const _0x272193=S['fromObject'](_0x464629);return ht(_0x597786,new nt(Ji(),_0x1a3cff,_0x272193));}function pe(_0x3d9b3c,_0xc984f,_0x27db64=!0x1){const _0x57ecf4=cu(_0x3d9b3c['pendingWriteTree_'],_0xc984f);if(lu(_0x3d9b3c['pendingWriteTree_'],_0xc984f)){let _0x1a2ff3=new S(null);return _0x57ecf4['snap']!=null?_0x1a2ff3=_0x1a2ff3['set'](w(),!0x0):x(_0x57ecf4['children'],_0x440839=>{_0x1a2ff3=_0x1a2ff3['set'](new C(_0x440839),!0x0);}),ht(_0x3d9b3c,new _n(_0x57ecf4['path'],_0x1a2ff3,_0x27db64));}else return[];}function $t(_0x4ff995,_0x361d52,_0x5ab439){return ht(_0x4ff995,new Fe(Xi(),_0x361d52,_0x5ab439));}function qu(_0x2d35c1,_0x33ee3e,_0x45d3a0){const _0x4a3e55=S['fromObject'](_0x45d3a0);return ht(_0x2d35c1,new nt(Xi(),_0x33ee3e,_0x4a3e55));}function zu(_0x16d7c4,_0x21a032){return ht(_0x16d7c4,new Dt(Xi(),_0x21a032));}function ju(_0x16a547,_0x53ce3f,_0x25bf75){const _0x5c5e96=rs(_0x16a547,_0x25bf75);if(_0x5c5e96){const _0x412593=os(_0x5c5e96),_0x335448=_0x412593['path'],_0x59219e=_0x412593['queryId'],_0x140a5f=F(_0x335448,_0x53ce3f),_0x48e6b6=new Dt(Zi(_0x59219e),_0x140a5f);return as(_0x16a547,_0x335448,_0x48e6b6);}else return[];}function wn(_0x280f2d,_0x4d248c,_0x14ff7b,_0xc1039d,_0x380d9d=!0x1){const _0x4323c8=_0x4d248c['_path'],_0x5f0b97=_0x280f2d['syncPointTree_']['get'](_0x4323c8);let _0x74e523=[];if(_0x5f0b97&&(_0x4d248c['_queryIdentifier']==='default'||Ko(_0x5f0b97,_0x4d248c))){const _0x42740f=Bu(_0x5f0b97,_0x4d248c,_0x14ff7b,_0xc1039d);Uu(_0x5f0b97)&&(_0x280f2d['syncPointTree_']=_0x280f2d['syncPointTree_']['remove'](_0x4323c8));const _0x4a822b=_0x42740f['removed'];if(_0x74e523=_0x42740f['events'],!_0x380d9d){const _0x48d742=_0x4a822b['findIndex'](_0x5887a8=>_0x5887a8['_queryParams']['loadsAllData']())!==-0x1,_0x266e20=_0x280f2d['syncPointTree_']['findOnPath'](_0x4323c8,(_0x563edc,_0x36936a)=>Te(_0x36936a));if(_0x48d742&&!_0x266e20){const _0x568d24=_0x280f2d['syncPointTree_']['subtree'](_0x4323c8);if(!_0x568d24['isEmpty']()){const _0x23b9a8=Qu(_0x568d24);for(let _0xb2e626=0x0;_0xb2e626<_0x23b9a8['length'];++_0xb2e626){const _0x5a2246=_0x23b9a8[_0xb2e626],_0x252698=_0x5a2246['query'],_0x301ad8=Xo(_0x280f2d,_0x5a2246);_0x280f2d['listenProvider_']['startListening'](Tt(_0x252698),Mt(_0x280f2d,_0x252698),_0x301ad8['hashFn'],_0x301ad8['onComplete']);}}}!_0x266e20&&_0x4a822b['length']>0x0&&!_0xc1039d&&(_0x48d742?_0x280f2d['listenProvider_']['stopListening'](Tt(_0x4d248c),null):_0x4a822b['forEach'](_0x11fa22=>{const _0x19b847=_0x280f2d['queryToTagMap']['get'](Fn(_0x11fa22));_0x280f2d['listenProvider_']['stopListening'](Tt(_0x11fa22),_0x19b847);}));}Ju(_0x280f2d,_0x4a822b);}return _0x74e523;}function Yo(_0x22919b,_0x229019,_0xbb3082,_0x105fb9){const _0x30718a=rs(_0x22919b,_0x105fb9);if(_0x30718a!=null){const _0x29a728=os(_0x30718a),_0x1b774c=_0x29a728['path'],_0x40cd76=_0x29a728['queryId'],_0x5660f5=F(_0x1b774c,_0x229019),_0x1967e2=new Fe(Zi(_0x40cd76),_0x5660f5,_0xbb3082);return as(_0x22919b,_0x1b774c,_0x1967e2);}else return[];}function Ku(_0xc3bb59,_0x17cd54,_0x35a2d6,_0x31513a){const _0x1859ee=rs(_0xc3bb59,_0x31513a);if(_0x1859ee){const _0x445f82=os(_0x1859ee),_0x1e4b6f=_0x445f82['path'],_0x4a2b04=_0x445f82['queryId'],_0x45d7c3=F(_0x1e4b6f,_0x17cd54),_0xb23673=S['fromObject'](_0x35a2d6),_0x3e855e=new nt(Zi(_0x4a2b04),_0x45d7c3,_0xb23673);return as(_0xc3bb59,_0x1e4b6f,_0x3e855e);}else return[];}function bi(_0x238a00,_0x1d4fc1,_0x3271cf,_0x249136=!0x1){const _0x663c86=_0x1d4fc1['_path'];let _0x36b22e=null,_0x2b6568=!0x1;_0x238a00['syncPointTree_']['foreachOnPath'](_0x663c86,(_0x2bfa8b,_0x1c9abd)=>{const _0x37cf58=F(_0x2bfa8b,_0x663c86);_0x36b22e=_0x36b22e||Ee(_0x1c9abd,_0x37cf58),_0x2b6568=_0x2b6568||Te(_0x1c9abd);});let _0x5d286d=_0x238a00['syncPointTree_']['get'](_0x663c86);_0x5d286d?(_0x2b6568=_0x2b6568||Te(_0x5d286d),_0x36b22e=_0x36b22e||Ee(_0x5d286d,w())):(_0x5d286d=new Go(),_0x238a00['syncPointTree_']=_0x238a00['syncPointTree_']['set'](_0x663c86,_0x5d286d));let _0xb38b71;_0x36b22e!=null?_0xb38b71=!0x0:(_0xb38b71=!0x1,_0x36b22e=g['EMPTY_NODE'],_0x238a00['syncPointTree_']['subtree'](_0x663c86)['foreachChild']((_0x46479d,_0xacb0ea)=>{const _0x42089f=Ee(_0xacb0ea,w());_0x42089f&&(_0x36b22e=_0x36b22e['updateImmediateChild'](_0x46479d,_0x42089f));}));const _0x476d6c=Ko(_0x5d286d,_0x1d4fc1);if(!_0x476d6c&&!_0x1d4fc1['_queryParams']['loadsAllData']()){const _0x4442cf=Fn(_0x1d4fc1);f(!_0x238a00['queryToTagMap']['has'](_0x4442cf),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x39cb5e=Xu();_0x238a00['queryToTagMap']['set'](_0x4442cf,_0x39cb5e),_0x238a00['tagToQueryMap']['set'](_0x39cb5e,_0x4442cf);}const _0x202c24=Mn(_0x238a00['pendingWriteTree_'],_0x663c86);let _0x303b01=Wu(_0x5d286d,_0x1d4fc1,_0x3271cf,_0x202c24,_0x36b22e,_0xb38b71);if(!_0x476d6c&&!_0x2b6568&&!_0x249136){const _0x5c24eb=jo(_0x5d286d,_0x1d4fc1);_0x303b01=_0x303b01['concat'](Zu(_0x238a00,_0x1d4fc1,_0x5c24eb));}return _0x303b01;}function xn(_0x5d8456,_0x5ade8c,_0x4cb82c){const _0x37f7aa=_0x5d8456['pendingWriteTree_'],_0x2b0b4e=_0x5d8456['syncPointTree_']['findOnPath'](_0x5ade8c,(_0x9df493,_0x2c20b0)=>{const _0x2f135b=F(_0x9df493,_0x5ade8c),_0x10d728=Ee(_0x2c20b0,_0x2f135b);if(_0x10d728)return _0x10d728;});return Uo(_0x37f7aa,_0x5ade8c,_0x2b0b4e,_0x4cb82c,!0x0);}function Yu(_0x1f25b9,_0x2fb18d){const _0x45f077=_0x2fb18d['_path'];let _0x5f59e0=null;_0x1f25b9['syncPointTree_']['foreachOnPath'](_0x45f077,(_0x370081,_0x494804)=>{const _0x5877e9=F(_0x370081,_0x45f077);_0x5f59e0=_0x5f59e0||Ee(_0x494804,_0x5877e9);});let _0x330252=_0x1f25b9['syncPointTree_']['get'](_0x45f077);_0x330252?_0x5f59e0=_0x5f59e0||Ee(_0x330252,w()):(_0x330252=new Go(),_0x1f25b9['syncPointTree_']=_0x1f25b9['syncPointTree_']['set'](_0x45f077,_0x330252));const _0x5ccd2b=_0x5f59e0!=null,_0x2247c6=_0x5ccd2b?new Ce(_0x5f59e0,!0x0,!0x1):null,_0x2a2350=Mn(_0x1f25b9['pendingWriteTree_'],_0x2fb18d['_path']),_0x4cefed=qo(_0x330252,_0x2fb18d,_0x2a2350,_0x5ccd2b?_0x2247c6['getNode']():g['EMPTY_NODE'],_0x5ccd2b);return Ou(_0x4cefed);}function ht(_0x18c9a7,_0x5d1848){return Qo(_0x5d1848,_0x18c9a7['syncPointTree_'],null,Mn(_0x18c9a7['pendingWriteTree_'],w()));}function Qo(_0x59a986,_0x28bba2,_0x57112f,_0x3229b5){if(v(_0x59a986['path']))return Jo(_0x59a986,_0x28bba2,_0x57112f,_0x3229b5);{const _0x4939ca=_0x28bba2['get'](w());_0x57112f==null&&_0x4939ca!=null&&(_0x57112f=Ee(_0x4939ca,w()));let _0x37a810=[];const _0x2bee23=y(_0x59a986['path']),_0x12f169=_0x59a986['operationForChild'](_0x2bee23),_0x5cc02c=_0x28bba2['children']['get'](_0x2bee23);if(_0x5cc02c&&_0x12f169){const _0x40104=_0x57112f?_0x57112f['getImmediateChild'](_0x2bee23):null,_0x54165e=Wo(_0x3229b5,_0x2bee23);_0x37a810=_0x37a810['concat'](Qo(_0x12f169,_0x5cc02c,_0x40104,_0x54165e));}return _0x4939ca&&(_0x37a810=_0x37a810['concat'](is(_0x4939ca,_0x59a986,_0x3229b5,_0x57112f))),_0x37a810;}}function Jo(_0x455073,_0x5859c6,_0x32d14f,_0x26ee02){const _0x252d56=_0x5859c6['get'](w());_0x32d14f==null&&_0x252d56!=null&&(_0x32d14f=Ee(_0x252d56,w()));let _0x19f053=[];return _0x5859c6['children']['inorderTraversal']((_0x137435,_0x21d1fa)=>{const _0x45a219=_0x32d14f?_0x32d14f['getImmediateChild'](_0x137435):null,_0x16a7b3=Wo(_0x26ee02,_0x137435),_0xf6e3f=_0x455073['operationForChild'](_0x137435);_0xf6e3f&&(_0x19f053=_0x19f053['concat'](Jo(_0xf6e3f,_0x21d1fa,_0x45a219,_0x16a7b3)));}),_0x252d56&&(_0x19f053=_0x19f053['concat'](is(_0x252d56,_0x455073,_0x26ee02,_0x32d14f))),_0x19f053;}function Xo(_0x27f842,_0x53e259){const _0x4467b4=_0x53e259['query'],_0x1c819c=Mt(_0x27f842,_0x4467b4);return{'hashFn':()=>(Pu(_0x53e259)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x21bbfd=>{if(_0x21bbfd==='ok')return _0x1c819c?ju(_0x27f842,_0x4467b4['_path'],_0x1c819c):zu(_0x27f842,_0x4467b4['_path']);{const _0x22023e=ql(_0x21bbfd,_0x4467b4);return wn(_0x27f842,_0x4467b4,null,_0x22023e);}}};}function Mt(_0x44b7dd,_0x58b2b){const _0x27ee93=Fn(_0x58b2b);return _0x44b7dd['queryToTagMap']['get'](_0x27ee93);}function Fn(_0x14fa3c){return _0x14fa3c['_path']['toString']()+'$'+_0x14fa3c['_queryIdentifier'];}function rs(_0xba4ec5,_0x5459c8){return _0xba4ec5['tagToQueryMap']['get'](_0x5459c8);}function os(_0x91875c){const _0x51b249=_0x91875c['indexOf']('$');return f(_0x51b249!==-0x1&&_0x51b249<_0x91875c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x91875c['substr'](_0x51b249+0x1),'path':new C(_0x91875c['substr'](0x0,_0x51b249))};}function as(_0x5c5257,_0x10eede,_0x5e0115){const _0xe32c46=_0x5c5257['syncPointTree_']['get'](_0x10eede);f(_0xe32c46,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x39a28b=Mn(_0x5c5257['pendingWriteTree_'],_0x10eede);return is(_0xe32c46,_0x5e0115,_0x39a28b,null);}function Qu(_0x53a20e){return _0x53a20e['fold']((_0x383ee6,_0x10a00d,_0xf79d42)=>{if(_0x10a00d&&Te(_0x10a00d))return[Ln(_0x10a00d)];{let _0x42d7d0=[];return _0x10a00d&&(_0x42d7d0=zo(_0x10a00d)),x(_0xf79d42,(_0xec5e36,_0x2df1f4)=>{_0x42d7d0=_0x42d7d0['concat'](_0x2df1f4);}),_0x42d7d0;}});}function Tt(_0x209a4f){return _0x209a4f['_queryParams']['loadsAllData']()&&!_0x209a4f['_queryParams']['isDefault']()?new(Hu())(_0x209a4f['_repo'],_0x209a4f['_path']):_0x209a4f;}function Ju(_0x5b845f,_0x386b26){for(let _0x4f1df9=0x0;_0x4f1df9<_0x386b26['length'];++_0x4f1df9){const _0x249a01=_0x386b26[_0x4f1df9];if(!_0x249a01['_queryParams']['loadsAllData']()){const _0x33e2f0=Fn(_0x249a01),_0x10f319=_0x5b845f['queryToTagMap']['get'](_0x33e2f0);_0x5b845f['queryToTagMap']['delete'](_0x33e2f0),_0x5b845f['tagToQueryMap']['delete'](_0x10f319);}}}function Xu(){return $u++;}function Zu(_0x20f6d9,_0x3b1f96,_0x2dc6f9){const _0x568214=_0x3b1f96['_path'],_0x2c30ed=Mt(_0x20f6d9,_0x3b1f96),_0x4fbbda=Xo(_0x20f6d9,_0x2dc6f9),_0x371e5d=_0x20f6d9['listenProvider_']['startListening'](Tt(_0x3b1f96),_0x2c30ed,_0x4fbbda['hashFn'],_0x4fbbda['onComplete']),_0x95602b=_0x20f6d9['syncPointTree_']['subtree'](_0x568214);if(_0x2c30ed)f(!Te(_0x95602b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x856b66=_0x95602b['fold']((_0xc3156c,_0x53ae36,_0x3151d0)=>{if(!v(_0xc3156c)&&_0x53ae36&&Te(_0x53ae36))return[Ln(_0x53ae36)['query']];{let _0x35b8dc=[];return _0x53ae36&&(_0x35b8dc=_0x35b8dc['concat'](zo(_0x53ae36)['map'](_0x381aef=>_0x381aef['query']))),x(_0x3151d0,(_0x3cf77b,_0x379a0e)=>{_0x35b8dc=_0x35b8dc['concat'](_0x379a0e);}),_0x35b8dc;}});for(let _0x32d968=0x0;_0x32d968<_0x856b66['length'];++_0x32d968){const _0x94f0bf=_0x856b66[_0x32d968];_0x20f6d9['listenProvider_']['stopListening'](Tt(_0x94f0bf),Mt(_0x20f6d9,_0x94f0bf));}}return _0x371e5d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x2e267c){this['node_']=_0x2e267c;}['getImmediateChild'](_0x8643c9){const _0x31a468=this['node_']['getImmediateChild'](_0x8643c9);return new cs(_0x31a468);}['node'](){return this['node_'];}}class ls{constructor(_0xa4e4fb,_0x1de166){this['syncTree_']=_0xa4e4fb,this['path_']=_0x1de166;}['getImmediateChild'](_0x2dac6c){const _0x104fe4=A(this['path_'],_0x2dac6c);return new ls(this['syncTree_'],_0x104fe4);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0xf40e3a){return _0xf40e3a=_0xf40e3a||{},_0xf40e3a['timestamp']=_0xf40e3a['timestamp']||new Date()['getTime'](),_0xf40e3a;},fr=function(_0x58013f,_0x400756,_0x53866f){if(!_0x58013f||typeof _0x58013f!='object')return _0x58013f;if(f('.sv'in _0x58013f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x58013f['.sv']=='string')return td(_0x58013f['.sv'],_0x400756,_0x53866f);if(typeof _0x58013f['.sv']=='object')return nd(_0x58013f['.sv'],_0x400756);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x58013f,null,0x2));},td=function(_0x4de812,_0x227ea1,_0x2e44d4){switch(_0x4de812){case'timestamp':return _0x2e44d4['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4de812);}},nd=function(_0x4302e2,_0x10a8e7,_0x54d083){_0x4302e2['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4302e2,null,0x2));const _0x1d7d8b=_0x4302e2['increment'];typeof _0x1d7d8b!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1d7d8b);const _0x1389bd=_0x10a8e7['node']();if(f(_0x1389bd!==null&&typeof _0x1389bd<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1389bd['isLeafNode']())return _0x1d7d8b;const _0x22d08a=_0x1389bd['getValue']();return typeof _0x22d08a!='number'?_0x1d7d8b:_0x22d08a+_0x1d7d8b;},Zo=function(_0xddd58e,_0x35bd83,_0x10c519,_0x3b9aba){return us(_0x35bd83,new ls(_0x10c519,_0xddd58e),_0x3b9aba);},hs=function(_0x5d903e,_0x22196b,_0x1b4d22){return us(_0x5d903e,new cs(_0x22196b),_0x1b4d22);};function us(_0x511aa7,_0x3f42fa,_0x4f9254){const _0x21c216=_0x511aa7['getPriority']()['val'](),_0x570fc7=fr(_0x21c216,_0x3f42fa['getImmediateChild']('.priority'),_0x4f9254);let _0x2b2bca;if(_0x511aa7['isLeafNode']()){const _0x1b6e84=_0x511aa7,_0x563f4a=fr(_0x1b6e84['getValue'](),_0x3f42fa,_0x4f9254);return _0x563f4a!==_0x1b6e84['getValue']()||_0x570fc7!==_0x1b6e84['getPriority']()['val']()?new D(_0x563f4a,N(_0x570fc7)):_0x511aa7;}else{const _0x4e8a61=_0x511aa7;return _0x2b2bca=_0x4e8a61,_0x570fc7!==_0x4e8a61['getPriority']()['val']()&&(_0x2b2bca=_0x2b2bca['updatePriority'](new D(_0x570fc7))),_0x4e8a61['forEachChild'](R,(_0x3da156,_0x2be188)=>{const _0x4e5633=us(_0x2be188,_0x3f42fa['getImmediateChild'](_0x3da156),_0x4f9254);_0x4e5633!==_0x2be188&&(_0x2b2bca=_0x2b2bca['updateImmediateChild'](_0x3da156,_0x4e5633));}),_0x2b2bca;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x114a72='',_0x2b1ff6=null,_0x237f61={'children':{},'childCount':0x0}){this['name']=_0x114a72,this['parent']=_0x2b1ff6,this['node']=_0x237f61;}}function Un(_0x4f9a96,_0x4bc45a){let _0x3b4df4=_0x4bc45a instanceof C?_0x4bc45a:new C(_0x4bc45a),_0x800de4=_0x4f9a96,_0x3a2a93=y(_0x3b4df4);for(;_0x3a2a93!==null;){const _0x31ef82=Oe(_0x800de4['node']['children'],_0x3a2a93)||{'children':{},'childCount':0x0};_0x800de4=new ds(_0x3a2a93,_0x800de4,_0x31ef82),_0x3b4df4=b(_0x3b4df4),_0x3a2a93=y(_0x3b4df4);}return _0x800de4;}function Ge(_0x54ad66){return _0x54ad66['node']['value'];}function fs(_0x18eef7,_0xcfd886){_0x18eef7['node']['value']=_0xcfd886,Ri(_0x18eef7);}function ea(_0x4489ba){return _0x4489ba['node']['childCount']>0x0;}function id(_0x81061c){return Ge(_0x81061c)===void 0x0&&!ea(_0x81061c);}function Wn(_0x1a0f15,_0x79e6c8){x(_0x1a0f15['node']['children'],(_0xfba594,_0x2464fd)=>{_0x79e6c8(new ds(_0xfba594,_0x1a0f15,_0x2464fd));});}function ta(_0x14f2e7,_0x56389c,_0x19345e,_0x453442){_0x19345e&&_0x56389c(_0x14f2e7),Wn(_0x14f2e7,_0x947a4d=>{ta(_0x947a4d,_0x56389c,!0x0);});}function sd(_0x33986d,_0x53f6cd,_0x39ed4f){let _0x188e18=_0x33986d['parent'];for(;_0x188e18!==null;){if(_0x53f6cd(_0x188e18))return!0x0;_0x188e18=_0x188e18['parent'];}return!0x1;}function Gt(_0x4beff6){return new C(_0x4beff6['parent']===null?_0x4beff6['name']:Gt(_0x4beff6['parent'])+'/'+_0x4beff6['name']);}function Ri(_0x287dde){_0x287dde['parent']!==null&&rd(_0x287dde['parent'],_0x287dde['name'],_0x287dde);}function rd(_0x46f99a,_0x431a,_0x1b85ed){const _0x33ae46=id(_0x1b85ed),_0x37d6ce=Y(_0x46f99a['node']['children'],_0x431a);_0x33ae46&&_0x37d6ce?(delete _0x46f99a['node']['children'][_0x431a],_0x46f99a['node']['childCount']--,Ri(_0x46f99a)):!_0x33ae46&&!_0x37d6ce&&(_0x46f99a['node']['children'][_0x431a]=_0x1b85ed['node'],_0x46f99a['node']['childCount']++,Ri(_0x46f99a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x271404){return typeof _0x271404=='string'&&_0x271404['length']!==0x0&&!od['test'](_0x271404);},na=function(_0x5b80f5){return typeof _0x5b80f5=='string'&&_0x5b80f5['length']!==0x0&&!ad['test'](_0x5b80f5);},cd=function(_0x524c8d){return _0x524c8d&&(_0x524c8d=_0x524c8d['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x524c8d);},Cn=function(_0x157db3){return _0x157db3===null||typeof _0x157db3=='string'||typeof _0x157db3=='number'&&!Wi(_0x157db3)||_0x157db3&&typeof _0x157db3=='object'&&Y(_0x157db3,'.sv');},qt=function(_0x137fb9,_0x460357,_0x3e72d6,_0x195231){_0x195231&&_0x460357===void 0x0||zt(Nn(_0x137fb9,'value'),_0x460357,_0x3e72d6);},zt=function(_0x598d34,_0xd1f306,_0xf66cd3){const _0xa2b77b=_0xf66cd3 instanceof C?new Sh(_0xf66cd3,_0x598d34):_0xf66cd3;if(_0xd1f306===void 0x0)throw new Error(_0x598d34+'contains\x20undefined\x20'+Ne(_0xa2b77b));if(typeof _0xd1f306=='function')throw new Error(_0x598d34+'contains\x20a\x20function\x20'+Ne(_0xa2b77b)+'\x20with\x20contents\x20=\x20'+_0xd1f306['toString']());if(Wi(_0xd1f306))throw new Error(_0x598d34+'contains\x20'+_0xd1f306['toString']()+'\x20'+Ne(_0xa2b77b));if(typeof _0xd1f306=='string'&&_0xd1f306['length']>oi/0x3&&Pn(_0xd1f306)>oi)throw new Error(_0x598d34+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0xa2b77b)+'\x20(\x27'+_0xd1f306['substring'](0x0,0x32)+'...\x27)');if(_0xd1f306&&typeof _0xd1f306=='object'){let _0xf481a1=!0x1,_0x495c4f=!0x1;if(x(_0xd1f306,(_0x2b46d6,_0x7c6307)=>{if(_0x2b46d6==='.value')_0xf481a1=!0x0;else{if(_0x2b46d6!=='.priority'&&_0x2b46d6!=='.sv'&&(_0x495c4f=!0x0,!ps(_0x2b46d6)))throw new Error(_0x598d34+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2b46d6+')\x20'+Ne(_0xa2b77b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0xa2b77b,_0x2b46d6),zt(_0x598d34,_0x7c6307,_0xa2b77b),Rh(_0xa2b77b);}),_0xf481a1&&_0x495c4f)throw new Error(_0x598d34+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0xa2b77b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x126325,_0x649b47){let _0xb65cef,_0x5b4b3d;for(_0xb65cef=0x0;_0xb65cef<_0x649b47['length'];_0xb65cef++){_0x5b4b3d=_0x649b47[_0xb65cef];const _0x587b81=kt(_0x5b4b3d);for(let _0x45b92f=0x0;_0x45b92f<_0x587b81['length'];_0x45b92f++)if(!(_0x587b81[_0x45b92f]==='.priority'&&_0x45b92f===_0x587b81['length']-0x1)){if(!ps(_0x587b81[_0x45b92f]))throw new Error(_0x126325+'contains\x20an\x20invalid\x20key\x20('+_0x587b81[_0x45b92f]+')\x20in\x20path\x20'+_0x5b4b3d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x649b47['sort'](Th);let _0x3624e5=null;for(_0xb65cef=0x0;_0xb65cef<_0x649b47['length'];_0xb65cef++){if(_0x5b4b3d=_0x649b47[_0xb65cef],_0x3624e5!==null&&$(_0x3624e5,_0x5b4b3d))throw new Error(_0x126325+'contains\x20a\x20path\x20'+_0x3624e5['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5b4b3d['toString']());_0x3624e5=_0x5b4b3d;}},hd=function(_0x45e639,_0x479be6,_0x2f8a16,_0x5b94fe){const _0x50b67f=Nn(_0x45e639,'values');if(!(_0x479be6&&typeof _0x479be6=='object')||Array['isArray'](_0x479be6))throw new Error(_0x50b67f+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x34668f=[];x(_0x479be6,(_0x44796f,_0x33f0f0)=>{const _0x49fcd3=new C(_0x44796f);if(zt(_0x50b67f,_0x33f0f0,A(_0x2f8a16,_0x49fcd3)),Gi(_0x49fcd3)==='.priority'&&!Cn(_0x33f0f0))throw new Error(_0x50b67f+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x49fcd3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x34668f['push'](_0x49fcd3);}),ld(_0x50b67f,_0x34668f);},_s=function(_0x3b2ffd,_0x424baa,_0x1c43f1,_0x28c5bf){if(!na(_0x1c43f1))throw new Error(Nn(_0x3b2ffd,_0x424baa)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1c43f1+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x20f3f9,_0x930265,_0x2f8ca1,_0x45265f){_0x2f8ca1&&(_0x2f8ca1=_0x2f8ca1['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x20f3f9,_0x930265,_0x2f8ca1);},gs=function(_0x4a7c25,_0x528cec){if(y(_0x528cec)==='.info')throw new Error(_0x4a7c25+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x166481,_0x1fccad){const _0x19b045=_0x1fccad['path']['toString']();if(typeof _0x1fccad['repoInfo']['host']!='string'||_0x1fccad['repoInfo']['host']['length']===0x0||!ps(_0x1fccad['repoInfo']['namespace'])&&_0x1fccad['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x19b045['length']!==0x0&&!cd(_0x19b045))throw new Error(Nn(_0x166481,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x1d4d34,_0x445289){let _0x4eab8d=null;for(let _0x11674d=0x0;_0x11674d<_0x445289['length'];_0x11674d++){const _0x1c66ae=_0x445289[_0x11674d],_0x4cd7d5=_0x1c66ae['getPath']();_0x4eab8d!==null&&!qi(_0x4cd7d5,_0x4eab8d['path'])&&(_0x1d4d34['eventLists_']['push'](_0x4eab8d),_0x4eab8d=null),_0x4eab8d===null&&(_0x4eab8d={'events':[],'path':_0x4cd7d5}),_0x4eab8d['events']['push'](_0x1c66ae);}_0x4eab8d&&_0x1d4d34['eventLists_']['push'](_0x4eab8d);}function ia(_0x5eead1,_0x445326,_0x328848){Bn(_0x5eead1,_0x328848),sa(_0x5eead1,_0x5cb42e=>qi(_0x5cb42e,_0x445326));}function V(_0x3aa91a,_0x2f9403,_0x5b67fe){Bn(_0x3aa91a,_0x5b67fe),sa(_0x3aa91a,_0x4ffae6=>$(_0x4ffae6,_0x2f9403)||$(_0x2f9403,_0x4ffae6));}function sa(_0x1f07c5,_0x3f3512){_0x1f07c5['recursionDepth_']++;let _0x1304c5=!0x0;for(let _0x644323=0x0;_0x644323<_0x1f07c5['eventLists_']['length'];_0x644323++){const _0x472fec=_0x1f07c5['eventLists_'][_0x644323];if(_0x472fec){const _0x19b08e=_0x472fec['path'];_0x3f3512(_0x19b08e)?(pd(_0x1f07c5['eventLists_'][_0x644323]),_0x1f07c5['eventLists_'][_0x644323]=null):_0x1304c5=!0x1;}}_0x1304c5&&(_0x1f07c5['eventLists_']=[]),_0x1f07c5['recursionDepth_']--;}function pd(_0x39e408){for(let _0x652d83=0x0;_0x652d83<_0x39e408['events']['length'];_0x652d83++){const _0x58bc14=_0x39e408['events'][_0x652d83];if(_0x58bc14!==null){_0x39e408['events'][_0x652d83]=null;const _0x4a7ff4=_0x58bc14['getEventRunner']();Et&&L('event:\x20'+_0x58bc14['toString']()),lt(_0x4a7ff4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x595ee2,_0xf0ad40,_0x943fc5,_0x2b75bb){this['repoInfo_']=_0x595ee2,this['forceRestClient_']=_0xf0ad40,this['authTokenProvider_']=_0x943fc5,this['appCheckProvider_']=_0x2b75bb,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x261cee,_0x1e0e1f,_0xa2934e){if(_0x261cee['stats_']=Hi(_0x261cee['repoInfo_']),_0x261cee['forceRestClient_']||Yl())_0x261cee['server_']=new fn(_0x261cee['repoInfo_'],(_0x4d7e80,_0x3849e8,_0x1aa18a,_0x6d7dd3)=>{pr(_0x261cee,_0x4d7e80,_0x3849e8,_0x1aa18a,_0x6d7dd3);},_0x261cee['authTokenProvider_'],_0x261cee['appCheckProvider_']),setTimeout(()=>_r(_0x261cee,!0x0),0x0);else{if(typeof _0xa2934e<'u'&&_0xa2934e!==null){if(typeof _0xa2934e!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xa2934e);}catch(_0x1bf4c3){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1bf4c3);}}_0x261cee['persistentConnection_']=new ie(_0x261cee['repoInfo_'],_0x1e0e1f,(_0x26494a,_0x1e5061,_0x119377,_0x593afe)=>{pr(_0x261cee,_0x26494a,_0x1e5061,_0x119377,_0x593afe);},_0x49e4d7=>{_r(_0x261cee,_0x49e4d7);},_0x2d2c07=>{yd(_0x261cee,_0x2d2c07);},_0x261cee['authTokenProvider_'],_0x261cee['appCheckProvider_'],_0xa2934e),_0x261cee['server_']=_0x261cee['persistentConnection_'];}_0x261cee['authTokenProvider_']['addTokenChangeListener'](_0x541150=>{_0x261cee['server_']['refreshAuthToken'](_0x541150);}),_0x261cee['appCheckProvider_']['addTokenChangeListener'](_0x366582=>{_0x261cee['server_']['refreshAppCheckToken'](_0x366582['token']);}),_0x261cee['statsReporter_']=eh(_0x261cee['repoInfo_'],()=>new eu(_0x261cee['stats_'],_0x261cee['server_'])),_0x261cee['infoData_']=new Yh(),_0x261cee['infoSyncTree_']=new dr({'startListening':(_0x5cbc43,_0x3161e6,_0x1f9b1e,_0x257fe0)=>{let _0x3b80f2=[];const _0x5a3818=_0x261cee['infoData_']['getNode'](_0x5cbc43['_path']);return _0x5a3818['isEmpty']()||(_0x3b80f2=$t(_0x261cee['infoSyncTree_'],_0x5cbc43['_path'],_0x5a3818),setTimeout(()=>{_0x257fe0('ok');},0x0)),_0x3b80f2;},'stopListening':()=>{}}),ms(_0x261cee,'connected',!0x1),_0x261cee['serverSyncTree_']=new dr({'startListening':(_0x45a279,_0x565d40,_0x319e26,_0x42418b)=>(_0x261cee['server_']['listen'](_0x45a279,_0x319e26,_0x565d40,(_0x244304,_0x2fc0a6)=>{const _0x45ced3=_0x42418b(_0x244304,_0x2fc0a6);V(_0x261cee['eventQueue_'],_0x45a279['_path'],_0x45ced3);}),[]),'stopListening':(_0x52de8c,_0x200f17)=>{_0x261cee['server_']['unlisten'](_0x52de8c,_0x200f17);}});}function oa(_0x252a92){const _0x2c3659=_0x252a92['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2c3659;}function jt(_0x3967cf){return ed({'timestamp':oa(_0x3967cf)});}function pr(_0x4c9a9b,_0x55ff63,_0x4c03ae,_0x303e3f,_0x570b3d){_0x4c9a9b['dataUpdateCount']++;const _0x18cb9d=new C(_0x55ff63);_0x4c03ae=_0x4c9a9b['interceptServerDataCallback_']?_0x4c9a9b['interceptServerDataCallback_'](_0x55ff63,_0x4c03ae):_0x4c03ae;let _0x89d3fc=[];if(_0x570b3d){if(_0x303e3f){const _0x39be43=ln(_0x4c03ae,_0x56edfb=>N(_0x56edfb));_0x89d3fc=Ku(_0x4c9a9b['serverSyncTree_'],_0x18cb9d,_0x39be43,_0x570b3d);}else{const _0x3101b0=N(_0x4c03ae);_0x89d3fc=Yo(_0x4c9a9b['serverSyncTree_'],_0x18cb9d,_0x3101b0,_0x570b3d);}}else{if(_0x303e3f){const _0x4baab1=ln(_0x4c03ae,_0x4a3ab2=>N(_0x4a3ab2));_0x89d3fc=qu(_0x4c9a9b['serverSyncTree_'],_0x18cb9d,_0x4baab1);}else{const _0x5ee20a=N(_0x4c03ae);_0x89d3fc=$t(_0x4c9a9b['serverSyncTree_'],_0x18cb9d,_0x5ee20a);}}let _0x24b204=_0x18cb9d;_0x89d3fc['length']>0x0&&(_0x24b204=st(_0x4c9a9b,_0x18cb9d)),V(_0x4c9a9b['eventQueue_'],_0x24b204,_0x89d3fc);}function _r(_0x143191,_0x37f186){ms(_0x143191,'connected',_0x37f186),_0x37f186===!0x1&&wd(_0x143191);}function yd(_0x1b0d17,_0x158f6c){x(_0x158f6c,(_0x607ce2,_0x1bfd3f)=>{ms(_0x1b0d17,_0x607ce2,_0x1bfd3f);});}function ms(_0x162eb5,_0x1dff25,_0x1c4071){const _0x4ab21b=new C('/.info/'+_0x1dff25),_0x2704b4=N(_0x1c4071);_0x162eb5['infoData_']['updateSnapshot'](_0x4ab21b,_0x2704b4);const _0x4e4a2b=$t(_0x162eb5['infoSyncTree_'],_0x4ab21b,_0x2704b4);V(_0x162eb5['eventQueue_'],_0x4ab21b,_0x4e4a2b);}function Vn(_0x489f3b){return _0x489f3b['nextWriteId_']++;}function vd(_0x425b4a,_0x2783f4,_0x457220){const _0x21377b=Yu(_0x425b4a['serverSyncTree_'],_0x2783f4);return _0x21377b!=null?Promise['resolve'](_0x21377b):_0x425b4a['server_']['get'](_0x2783f4)['then'](_0x5689f1=>{const _0x328924=N(_0x5689f1)['withIndex'](_0x2783f4['_queryParams']['getIndex']());bi(_0x425b4a['serverSyncTree_'],_0x2783f4,_0x457220,!0x0);let _0x5532d3;if(_0x2783f4['_queryParams']['loadsAllData']())_0x5532d3=$t(_0x425b4a['serverSyncTree_'],_0x2783f4['_path'],_0x328924);else{const _0x5e0342=Mt(_0x425b4a['serverSyncTree_'],_0x2783f4);_0x5532d3=Yo(_0x425b4a['serverSyncTree_'],_0x2783f4['_path'],_0x328924,_0x5e0342);}return V(_0x425b4a['eventQueue_'],_0x2783f4['_path'],_0x5532d3),wn(_0x425b4a['serverSyncTree_'],_0x2783f4,_0x457220,null,!0x0),_0x328924;},_0x12b657=>(ut(_0x425b4a,'get\x20for\x20query\x20'+O(_0x2783f4)+'\x20failed:\x20'+_0x12b657),Promise['reject'](new Error(_0x12b657))));}function Ed(_0x1d00f9,_0x4d253b,_0x4554d8,_0x109ba9,_0x20dd1a){ut(_0x1d00f9,'set',{'path':_0x4d253b['toString'](),'value':_0x4554d8,'priority':_0x109ba9});const _0x256c2c=jt(_0x1d00f9),_0x574017=N(_0x4554d8,_0x109ba9),_0x517b44=xn(_0x1d00f9['serverSyncTree_'],_0x4d253b),_0x4edc56=hs(_0x574017,_0x517b44,_0x256c2c),_0x2e8609=Vn(_0x1d00f9),_0x26ce55=ss(_0x1d00f9['serverSyncTree_'],_0x4d253b,_0x4edc56,_0x2e8609,!0x0);Bn(_0x1d00f9['eventQueue_'],_0x26ce55),_0x1d00f9['server_']['put'](_0x4d253b['toString'](),_0x574017['val'](!0x0),(_0x2f870c,_0xd2ac3b)=>{const _0x4d418a=_0x2f870c==='ok';_0x4d418a||U('set\x20at\x20'+_0x4d253b+'\x20failed:\x20'+_0x2f870c);const _0x4560b2=pe(_0x1d00f9['serverSyncTree_'],_0x2e8609,!_0x4d418a);V(_0x1d00f9['eventQueue_'],_0x4d253b,_0x4560b2),Ai(_0x1d00f9,_0x20dd1a,_0x2f870c,_0xd2ac3b);});const _0x5b4efc=vs(_0x1d00f9,_0x4d253b);st(_0x1d00f9,_0x5b4efc),V(_0x1d00f9['eventQueue_'],_0x5b4efc,[]);}function Id(_0x58836b,_0xca7184,_0x226542,_0x25458b){ut(_0x58836b,'update',{'path':_0xca7184['toString'](),'value':_0x226542});let _0x272d1c=!0x0;const _0x4d98d2=jt(_0x58836b),_0x2f7cff={};if(x(_0x226542,(_0x54e722,_0x1c4bd2)=>{_0x272d1c=!0x1,_0x2f7cff[_0x54e722]=Zo(A(_0xca7184,_0x54e722),N(_0x1c4bd2),_0x58836b['serverSyncTree_'],_0x4d98d2);}),_0x272d1c)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x58836b,_0x25458b,'ok',void 0x0);else{const _0x23947e=Vn(_0x58836b),_0x58b073=Gu(_0x58836b['serverSyncTree_'],_0xca7184,_0x2f7cff,_0x23947e);Bn(_0x58836b['eventQueue_'],_0x58b073),_0x58836b['server_']['merge'](_0xca7184['toString'](),_0x226542,(_0x5aff39,_0x1c164b)=>{const _0x1c50e5=_0x5aff39==='ok';_0x1c50e5||U('update\x20at\x20'+_0xca7184+'\x20failed:\x20'+_0x5aff39);const _0x5a1205=pe(_0x58836b['serverSyncTree_'],_0x23947e,!_0x1c50e5),_0x246379=_0x5a1205['length']>0x0?st(_0x58836b,_0xca7184):_0xca7184;V(_0x58836b['eventQueue_'],_0x246379,_0x5a1205),Ai(_0x58836b,_0x25458b,_0x5aff39,_0x1c164b);}),x(_0x226542,_0x22b86a=>{const _0x3dbb3c=vs(_0x58836b,A(_0xca7184,_0x22b86a));st(_0x58836b,_0x3dbb3c);}),V(_0x58836b['eventQueue_'],_0xca7184,[]);}}function wd(_0x22d0f9){ut(_0x22d0f9,'onDisconnectEvents');const _0x540c81=jt(_0x22d0f9),_0x2be8f7=pn();Ei(_0x22d0f9['onDisconnect_'],w(),(_0x30ad76,_0x1fdb30)=>{const _0x1bad5e=Zo(_0x30ad76,_0x1fdb30,_0x22d0f9['serverSyncTree_'],_0x540c81);Mo(_0x2be8f7,_0x30ad76,_0x1bad5e);});let _0x2685c7=[];Ei(_0x2be8f7,w(),(_0x9210e7,_0x2738b6)=>{_0x2685c7=_0x2685c7['concat']($t(_0x22d0f9['serverSyncTree_'],_0x9210e7,_0x2738b6));const _0x337bf5=vs(_0x22d0f9,_0x9210e7);st(_0x22d0f9,_0x337bf5);}),_0x22d0f9['onDisconnect_']=pn(),V(_0x22d0f9['eventQueue_'],w(),_0x2685c7);}function Cd(_0x6f65ca,_0x3f68a8,_0x5a9e86){let _0x1c0703;y(_0x3f68a8['_path'])==='.info'?_0x1c0703=bi(_0x6f65ca['infoSyncTree_'],_0x3f68a8,_0x5a9e86):_0x1c0703=bi(_0x6f65ca['serverSyncTree_'],_0x3f68a8,_0x5a9e86),ia(_0x6f65ca['eventQueue_'],_0x3f68a8['_path'],_0x1c0703);}function Td(_0x55b982,_0x216911,_0x53b177){let _0x10780c;y(_0x216911['_path'])==='.info'?_0x10780c=wn(_0x55b982['infoSyncTree_'],_0x216911,_0x53b177):_0x10780c=wn(_0x55b982['serverSyncTree_'],_0x216911,_0x53b177),ia(_0x55b982['eventQueue_'],_0x216911['_path'],_0x10780c);}function aa(_0x327162){_0x327162['persistentConnection_']&&_0x327162['persistentConnection_']['interrupt'](ra);}function Sd(_0x3b2359){_0x3b2359['persistentConnection_']&&_0x3b2359['persistentConnection_']['resume'](ra);}function ut(_0x2b5883,..._0x11637c){let _0x282536='';_0x2b5883['persistentConnection_']&&(_0x282536=_0x2b5883['persistentConnection_']['id']+':'),L(_0x282536,..._0x11637c);}function Ai(_0xd0ce48,_0x56f6ee,_0x324e6f,_0x25b587){_0x56f6ee&&lt(()=>{if(_0x324e6f==='ok')_0x56f6ee(null);else{const _0x1a5a80=(_0x324e6f||'error')['toUpperCase']();let _0x45af88=_0x1a5a80;_0x25b587&&(_0x45af88+=':\x20'+_0x25b587);const _0x5bb915=new Error(_0x45af88);_0x5bb915['code']=_0x1a5a80,_0x56f6ee(_0x5bb915);}});}function bd(_0x20ca3d,_0x55071f,_0x2f9cae,_0x2e055a,_0x57f1db,_0x37d6e9){ut(_0x20ca3d,'transaction\x20on\x20'+_0x55071f);const _0x49bc87={'path':_0x55071f,'update':_0x2f9cae,'onComplete':_0x2e055a,'status':null,'order':to(),'applyLocally':_0x37d6e9,'retryCount':0x0,'unwatcher':_0x57f1db,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4cc160=ys(_0x20ca3d,_0x55071f,void 0x0);_0x49bc87['currentInputSnapshot']=_0x4cc160;const _0x5a9266=_0x49bc87['update'](_0x4cc160['val']());if(_0x5a9266===void 0x0)_0x49bc87['unwatcher'](),_0x49bc87['currentOutputSnapshotRaw']=null,_0x49bc87['currentOutputSnapshotResolved']=null,_0x49bc87['onComplete']&&_0x49bc87['onComplete'](null,!0x1,_0x49bc87['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5a9266,_0x49bc87['path']),_0x49bc87['status']=0x0;const _0x2c302c=Un(_0x20ca3d['transactionQueueTree_'],_0x55071f),_0x57a6de=Ge(_0x2c302c)||[];_0x57a6de['push'](_0x49bc87),fs(_0x2c302c,_0x57a6de);let _0x555fbf;typeof _0x5a9266=='object'&&_0x5a9266!==null&&Y(_0x5a9266,'.priority')?(_0x555fbf=Oe(_0x5a9266,'.priority'),f(Cn(_0x555fbf),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x555fbf=(xn(_0x20ca3d['serverSyncTree_'],_0x55071f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3dce75=jt(_0x20ca3d),_0x5ab6da=N(_0x5a9266,_0x555fbf),_0x3cde79=hs(_0x5ab6da,_0x4cc160,_0x3dce75);_0x49bc87['currentOutputSnapshotRaw']=_0x5ab6da,_0x49bc87['currentOutputSnapshotResolved']=_0x3cde79,_0x49bc87['currentWriteId']=Vn(_0x20ca3d);const _0x3991ee=ss(_0x20ca3d['serverSyncTree_'],_0x55071f,_0x3cde79,_0x49bc87['currentWriteId'],_0x49bc87['applyLocally']);V(_0x20ca3d['eventQueue_'],_0x55071f,_0x3991ee),Hn(_0x20ca3d,_0x20ca3d['transactionQueueTree_']);}}function ys(_0x4c6f67,_0x345d88,_0x5ddef9){return xn(_0x4c6f67['serverSyncTree_'],_0x345d88,_0x5ddef9)||g['EMPTY_NODE'];}function Hn(_0x568f44,_0x41b038=_0x568f44['transactionQueueTree_']){if(_0x41b038||$n(_0x568f44,_0x41b038),Ge(_0x41b038)){const _0x3bdf8b=la(_0x568f44,_0x41b038);f(_0x3bdf8b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3bdf8b['every'](_0x54c460=>_0x54c460['status']===0x0)&&Rd(_0x568f44,Gt(_0x41b038),_0x3bdf8b);}else ea(_0x41b038)&&Wn(_0x41b038,_0x7dcd89=>{Hn(_0x568f44,_0x7dcd89);});}function Rd(_0x4f0e82,_0x110404,_0x53520e){const _0x526c9c=_0x53520e['map'](_0x511c7a=>_0x511c7a['currentWriteId']),_0x538c05=ys(_0x4f0e82,_0x110404,_0x526c9c);let _0xf8e309=_0x538c05;const _0x578c32=_0x538c05['hash']();for(let _0x54c3c5=0x0;_0x54c3c5<_0x53520e['length'];_0x54c3c5++){const _0x1b8e57=_0x53520e[_0x54c3c5];f(_0x1b8e57['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1b8e57['status']=0x1,_0x1b8e57['retryCount']++;const _0x32dccb=F(_0x110404,_0x1b8e57['path']);_0xf8e309=_0xf8e309['updateChild'](_0x32dccb,_0x1b8e57['currentOutputSnapshotRaw']);}const _0x2c30fa=_0xf8e309['val'](!0x0),_0x431bc2=_0x110404;_0x4f0e82['server_']['put'](_0x431bc2['toString'](),_0x2c30fa,_0x405de1=>{ut(_0x4f0e82,'transaction\x20put\x20response',{'path':_0x431bc2['toString'](),'status':_0x405de1});let _0x45bf77=[];if(_0x405de1==='ok'){const _0x57c1e0=[];for(let _0x584c11=0x0;_0x584c11<_0x53520e['length'];_0x584c11++)_0x53520e[_0x584c11]['status']=0x2,_0x45bf77=_0x45bf77['concat'](pe(_0x4f0e82['serverSyncTree_'],_0x53520e[_0x584c11]['currentWriteId'])),_0x53520e[_0x584c11]['onComplete']&&_0x57c1e0['push'](()=>_0x53520e[_0x584c11]['onComplete'](null,!0x0,_0x53520e[_0x584c11]['currentOutputSnapshotResolved'])),_0x53520e[_0x584c11]['unwatcher']();$n(_0x4f0e82,Un(_0x4f0e82['transactionQueueTree_'],_0x110404)),Hn(_0x4f0e82,_0x4f0e82['transactionQueueTree_']),V(_0x4f0e82['eventQueue_'],_0x110404,_0x45bf77);for(let _0x4da1ae=0x0;_0x4da1ae<_0x57c1e0['length'];_0x4da1ae++)lt(_0x57c1e0[_0x4da1ae]);}else{if(_0x405de1==='datastale'){for(let _0x413ae0=0x0;_0x413ae0<_0x53520e['length'];_0x413ae0++)_0x53520e[_0x413ae0]['status']===0x3?_0x53520e[_0x413ae0]['status']=0x4:_0x53520e[_0x413ae0]['status']=0x0;}else{U('transaction\x20at\x20'+_0x431bc2['toString']()+'\x20failed:\x20'+_0x405de1);for(let _0x16bbaf=0x0;_0x16bbaf<_0x53520e['length'];_0x16bbaf++)_0x53520e[_0x16bbaf]['status']=0x4,_0x53520e[_0x16bbaf]['abortReason']=_0x405de1;}st(_0x4f0e82,_0x110404);}},_0x578c32);}function st(_0x190550,_0xf0d472){const _0x2b9f1e=ca(_0x190550,_0xf0d472),_0x34e1cc=Gt(_0x2b9f1e),_0x4187bc=la(_0x190550,_0x2b9f1e);return Ad(_0x190550,_0x4187bc,_0x34e1cc),_0x34e1cc;}function Ad(_0x468e51,_0x1a0be8,_0x2a8486){if(_0x1a0be8['length']===0x0)return;const _0xdcbb0e=[];let _0x4a1543=[];const _0x493490=_0x1a0be8['filter'](_0x250230=>_0x250230['status']===0x0)['map'](_0xa8b91d=>_0xa8b91d['currentWriteId']);for(let _0x47b765=0x0;_0x47b765<_0x1a0be8['length'];_0x47b765++){const _0x3dfca1=_0x1a0be8[_0x47b765],_0x14ac9d=F(_0x2a8486,_0x3dfca1['path']);let _0x2914cd=!0x1,_0x2b22cd;if(f(_0x14ac9d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3dfca1['status']===0x4)_0x2914cd=!0x0,_0x2b22cd=_0x3dfca1['abortReason'],_0x4a1543=_0x4a1543['concat'](pe(_0x468e51['serverSyncTree_'],_0x3dfca1['currentWriteId'],!0x0));else{if(_0x3dfca1['status']===0x0){if(_0x3dfca1['retryCount']>=_d)_0x2914cd=!0x0,_0x2b22cd='maxretry',_0x4a1543=_0x4a1543['concat'](pe(_0x468e51['serverSyncTree_'],_0x3dfca1['currentWriteId'],!0x0));else{const _0x355b69=ys(_0x468e51,_0x3dfca1['path'],_0x493490);_0x3dfca1['currentInputSnapshot']=_0x355b69;const _0x253fb9=_0x1a0be8[_0x47b765]['update'](_0x355b69['val']());if(_0x253fb9!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x253fb9,_0x3dfca1['path']);let _0x204f5d=N(_0x253fb9);typeof _0x253fb9=='object'&&_0x253fb9!=null&&Y(_0x253fb9,'.priority')||(_0x204f5d=_0x204f5d['updatePriority'](_0x355b69['getPriority']()));const _0x3204aa=_0x3dfca1['currentWriteId'],_0x34e1eb=jt(_0x468e51),_0x4f5cdf=hs(_0x204f5d,_0x355b69,_0x34e1eb);_0x3dfca1['currentOutputSnapshotRaw']=_0x204f5d,_0x3dfca1['currentOutputSnapshotResolved']=_0x4f5cdf,_0x3dfca1['currentWriteId']=Vn(_0x468e51),_0x493490['splice'](_0x493490['indexOf'](_0x3204aa),0x1),_0x4a1543=_0x4a1543['concat'](ss(_0x468e51['serverSyncTree_'],_0x3dfca1['path'],_0x4f5cdf,_0x3dfca1['currentWriteId'],_0x3dfca1['applyLocally'])),_0x4a1543=_0x4a1543['concat'](pe(_0x468e51['serverSyncTree_'],_0x3204aa,!0x0));}else _0x2914cd=!0x0,_0x2b22cd='nodata',_0x4a1543=_0x4a1543['concat'](pe(_0x468e51['serverSyncTree_'],_0x3dfca1['currentWriteId'],!0x0));}}}V(_0x468e51['eventQueue_'],_0x2a8486,_0x4a1543),_0x4a1543=[],_0x2914cd&&(_0x1a0be8[_0x47b765]['status']=0x2,function(_0x2bb5f9){setTimeout(_0x2bb5f9,Math['floor'](0x0));}(_0x1a0be8[_0x47b765]['unwatcher']),_0x1a0be8[_0x47b765]['onComplete']&&(_0x2b22cd==='nodata'?_0xdcbb0e['push'](()=>_0x1a0be8[_0x47b765]['onComplete'](null,!0x1,_0x1a0be8[_0x47b765]['currentInputSnapshot'])):_0xdcbb0e['push'](()=>_0x1a0be8[_0x47b765]['onComplete'](new Error(_0x2b22cd),!0x1,null))));}$n(_0x468e51,_0x468e51['transactionQueueTree_']);for(let _0x5b047f=0x0;_0x5b047f<_0xdcbb0e['length'];_0x5b047f++)lt(_0xdcbb0e[_0x5b047f]);Hn(_0x468e51,_0x468e51['transactionQueueTree_']);}function ca(_0x5ca8b4,_0xf6d0a0){let _0x3bee44,_0x5710aa=_0x5ca8b4['transactionQueueTree_'];for(_0x3bee44=y(_0xf6d0a0);_0x3bee44!==null&&Ge(_0x5710aa)===void 0x0;)_0x5710aa=Un(_0x5710aa,_0x3bee44),_0xf6d0a0=b(_0xf6d0a0),_0x3bee44=y(_0xf6d0a0);return _0x5710aa;}function la(_0xf7a995,_0x2a751b){const _0x26258a=[];return ha(_0xf7a995,_0x2a751b,_0x26258a),_0x26258a['sort']((_0x4a046c,_0x2ad335)=>_0x4a046c['order']-_0x2ad335['order']),_0x26258a;}function ha(_0xd955aa,_0x5d9202,_0x1200d6){const _0x4b4548=Ge(_0x5d9202);if(_0x4b4548){for(let _0x2ab5ba=0x0;_0x2ab5ba<_0x4b4548['length'];_0x2ab5ba++)_0x1200d6['push'](_0x4b4548[_0x2ab5ba]);}Wn(_0x5d9202,_0x50570a=>{ha(_0xd955aa,_0x50570a,_0x1200d6);});}function $n(_0x3b6606,_0x5c1ca8){const _0x46f9ee=Ge(_0x5c1ca8);if(_0x46f9ee){let _0x4adcf4=0x0;for(let _0x5b3a69=0x0;_0x5b3a69<_0x46f9ee['length'];_0x5b3a69++)_0x46f9ee[_0x5b3a69]['status']!==0x2&&(_0x46f9ee[_0x4adcf4]=_0x46f9ee[_0x5b3a69],_0x4adcf4++);_0x46f9ee['length']=_0x4adcf4,fs(_0x5c1ca8,_0x46f9ee['length']>0x0?_0x46f9ee:void 0x0);}Wn(_0x5c1ca8,_0x5b8a01=>{$n(_0x3b6606,_0x5b8a01);});}function vs(_0x14532c,_0x1f73ea){const _0x309cca=Gt(ca(_0x14532c,_0x1f73ea)),_0x5b68e4=Un(_0x14532c['transactionQueueTree_'],_0x1f73ea);return sd(_0x5b68e4,_0x17a715=>{ai(_0x14532c,_0x17a715);}),ai(_0x14532c,_0x5b68e4),ta(_0x5b68e4,_0x235280=>{ai(_0x14532c,_0x235280);}),_0x309cca;}function ai(_0x318a28,_0xc54c25){const _0x17c526=Ge(_0xc54c25);if(_0x17c526){const _0x1f6be8=[];let _0x5f0825=[],_0x4f49b4=-0x1;for(let _0x32ebd2=0x0;_0x32ebd2<_0x17c526['length'];_0x32ebd2++)_0x17c526[_0x32ebd2]['status']===0x3||(_0x17c526[_0x32ebd2]['status']===0x1?(f(_0x4f49b4===_0x32ebd2-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4f49b4=_0x32ebd2,_0x17c526[_0x32ebd2]['status']=0x3,_0x17c526[_0x32ebd2]['abortReason']='set'):(f(_0x17c526[_0x32ebd2]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x17c526[_0x32ebd2]['unwatcher'](),_0x5f0825=_0x5f0825['concat'](pe(_0x318a28['serverSyncTree_'],_0x17c526[_0x32ebd2]['currentWriteId'],!0x0)),_0x17c526[_0x32ebd2]['onComplete']&&_0x1f6be8['push'](_0x17c526[_0x32ebd2]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4f49b4===-0x1?fs(_0xc54c25,void 0x0):_0x17c526['length']=_0x4f49b4+0x1,V(_0x318a28['eventQueue_'],Gt(_0xc54c25),_0x5f0825);for(let _0x3e9d33=0x0;_0x3e9d33<_0x1f6be8['length'];_0x3e9d33++)lt(_0x1f6be8[_0x3e9d33]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x225148){let _0x856aa5='';const _0x4e9d63=_0x225148['split']('/');for(let _0x168ffd=0x0;_0x168ffd<_0x4e9d63['length'];_0x168ffd++)if(_0x4e9d63[_0x168ffd]['length']>0x0){let _0x283552=_0x4e9d63[_0x168ffd];try{_0x283552=decodeURIComponent(_0x283552['replace'](/\+/g,'\x20'));}catch{}_0x856aa5+='/'+_0x283552;}return _0x856aa5;}function Nd(_0x4f6860){const _0x5dc356={};_0x4f6860['charAt'](0x0)==='?'&&(_0x4f6860=_0x4f6860['substring'](0x1));for(const _0x31f2a8 of _0x4f6860['split']('&')){if(_0x31f2a8['length']===0x0)continue;const _0xf2510c=_0x31f2a8['split']('=');_0xf2510c['length']===0x2?_0x5dc356[decodeURIComponent(_0xf2510c[0x0])]=decodeURIComponent(_0xf2510c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x31f2a8+'\x27\x20in\x20query\x20\x27'+_0x4f6860+'\x27');}return _0x5dc356;}const gr=function(_0x119598,_0x19b208){const _0x205270=Pd(_0x119598),_0x4e8d75=_0x205270['namespace'];_0x205270['domain']==='firebase.com'&&oe(_0x205270['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4e8d75||_0x4e8d75==='undefined')&&_0x205270['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x205270['secure']||Bl();const _0x3e966a=_0x205270['scheme']==='ws'||_0x205270['scheme']==='wss';return{'repoInfo':new _o(_0x205270['host'],_0x205270['secure'],_0x4e8d75,_0x3e966a,_0x19b208,'',_0x4e8d75!==_0x205270['subdomain']),'path':new C(_0x205270['pathString'])};},Pd=function(_0xcea6b){let _0x3aed74='',_0x957e9f='',_0xc4e466='',_0x3ff494='',_0x31fce4='',_0x1a0129=!0x0,_0x343e84='https',_0x1ba181=0x1bb;if(typeof _0xcea6b=='string'){let _0x171b8a=_0xcea6b['indexOf']('//');_0x171b8a>=0x0&&(_0x343e84=_0xcea6b['substring'](0x0,_0x171b8a-0x1),_0xcea6b=_0xcea6b['substring'](_0x171b8a+0x2));let _0x429b83=_0xcea6b['indexOf']('/');_0x429b83===-0x1&&(_0x429b83=_0xcea6b['length']);let _0x45bd1e=_0xcea6b['indexOf']('?');_0x45bd1e===-0x1&&(_0x45bd1e=_0xcea6b['length']),_0x3aed74=_0xcea6b['substring'](0x0,Math['min'](_0x429b83,_0x45bd1e)),_0x429b83<_0x45bd1e&&(_0x3ff494=kd(_0xcea6b['substring'](_0x429b83,_0x45bd1e)));const _0x45675d=Nd(_0xcea6b['substring'](Math['min'](_0xcea6b['length'],_0x45bd1e)));_0x171b8a=_0x3aed74['indexOf'](':'),_0x171b8a>=0x0?(_0x1a0129=_0x343e84==='https'||_0x343e84==='wss',_0x1ba181=parseInt(_0x3aed74['substring'](_0x171b8a+0x1),0xa)):_0x171b8a=_0x3aed74['length'];const _0x33e9f0=_0x3aed74['slice'](0x0,_0x171b8a);if(_0x33e9f0['toLowerCase']()==='localhost')_0x957e9f='localhost';else{if(_0x33e9f0['split']('.')['length']<=0x2)_0x957e9f=_0x33e9f0;else{const _0x1ecadd=_0x3aed74['indexOf']('.');_0xc4e466=_0x3aed74['substring'](0x0,_0x1ecadd)['toLowerCase'](),_0x957e9f=_0x3aed74['substring'](_0x1ecadd+0x1),_0x31fce4=_0xc4e466;}}'ns'in _0x45675d&&(_0x31fce4=_0x45675d['ns']);}return{'host':_0x3aed74,'port':_0x1ba181,'domain':_0x957e9f,'subdomain':_0xc4e466,'secure':_0x1a0129,'scheme':_0x343e84,'pathString':_0x3ff494,'namespace':_0x31fce4};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x390060=0x0;const _0x3c727d=[];return function(_0x230739){const _0x529efc=_0x230739===_0x390060;_0x390060=_0x230739;let _0x5ee6d7;const _0x29f604=new Array(0x8);for(_0x5ee6d7=0x7;_0x5ee6d7>=0x0;_0x5ee6d7--)_0x29f604[_0x5ee6d7]=mr['charAt'](_0x230739%0x40),_0x230739=Math['floor'](_0x230739/0x40);f(_0x230739===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x21ebcc=_0x29f604['join']('');if(_0x529efc){for(_0x5ee6d7=0xb;_0x5ee6d7>=0x0&&_0x3c727d[_0x5ee6d7]===0x3f;_0x5ee6d7--)_0x3c727d[_0x5ee6d7]=0x0;_0x3c727d[_0x5ee6d7]++;}else{for(_0x5ee6d7=0x0;_0x5ee6d7<0xc;_0x5ee6d7++)_0x3c727d[_0x5ee6d7]=Math['floor'](Math['random']()*0x40);}for(_0x5ee6d7=0x0;_0x5ee6d7<0xc;_0x5ee6d7++)_0x21ebcc+=mr['charAt'](_0x3c727d[_0x5ee6d7]);return f(_0x21ebcc['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x21ebcc;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x59d311,_0x358d74,_0x28181c,_0x3c6f9c){this['eventType']=_0x59d311,this['eventRegistration']=_0x358d74,this['snapshot']=_0x28181c,this['prevName']=_0x3c6f9c;}['getPath'](){const _0xc551e5=this['snapshot']['ref'];return this['eventType']==='value'?_0xc551e5['_path']:_0xc551e5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3725af,_0x55e61e,_0x2e81c1){this['eventRegistration']=_0x3725af,this['error']=_0x55e61e,this['path']=_0x2e81c1;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0xe1e96a,_0x5dc448){this['snapshotCallback']=_0xe1e96a,this['cancelCallback']=_0x5dc448;}['onValue'](_0xc18b06,_0x50d89f){this['snapshotCallback']['call'](null,_0xc18b06,_0x50d89f);}['onCancel'](_0x180876){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x180876);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xb7c16){return this['snapshotCallback']===_0xb7c16['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xb7c16['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xb7c16['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x46aff6,_0x4cc07a,_0x26d68f,_0x53c243){this['_repo']=_0x46aff6,this['_path']=_0x4cc07a,this['_queryParams']=_0x26d68f,this['_orderByCalled']=_0x53c243;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4034af=nr(this['_queryParams']),_0x58ade2=Bi(_0x4034af);return _0x58ade2==='{}'?'default':_0x58ade2;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x99b08c){if(_0x99b08c=k(_0x99b08c),!(_0x99b08c instanceof be))return!0x1;const _0x5de569=this['_repo']===_0x99b08c['_repo'],_0x533621=qi(this['_path'],_0x99b08c['_path']),_0x10ec51=this['_queryIdentifier']===_0x99b08c['_queryIdentifier'];return _0x5de569&&_0x533621&&_0x10ec51;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x27ad49,_0xb65de5){if(_0x27ad49['_orderByCalled']===!0x0)throw new Error(_0xb65de5+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x19ba75){let _0x2622ec=null,_0x5bd2af=null;if(_0x19ba75['hasStart']()&&(_0x2622ec=_0x19ba75['getIndexStartValue']()),_0x19ba75['hasEnd']()&&(_0x5bd2af=_0x19ba75['getIndexEndValue']()),_0x19ba75['getIndex']()===ye){const _0x178a65='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x6c30af='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x19ba75['hasStart']()){if(_0x19ba75['getIndexStartName']()!==xe)throw new Error(_0x178a65);if(typeof _0x2622ec!='string')throw new Error(_0x6c30af);}if(_0x19ba75['hasEnd']()){if(_0x19ba75['getIndexEndName']()!==Ie)throw new Error(_0x178a65);if(typeof _0x5bd2af!='string')throw new Error(_0x6c30af);}}else{if(_0x19ba75['getIndex']()===R){if(_0x2622ec!=null&&!Cn(_0x2622ec)||_0x5bd2af!=null&&!Cn(_0x5bd2af))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x19ba75['getIndex']()instanceof Ki||_0x19ba75['getIndex']()===Po,'unknown\x20index\x20type.'),_0x2622ec!=null&&typeof _0x2622ec=='object'||_0x5bd2af!=null&&typeof _0x5bd2af=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2e3614){if(_0x2e3614['hasStart']()&&_0x2e3614['hasEnd']()&&_0x2e3614['hasLimit']()&&!_0x2e3614['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2a089d,_0x102e34){super(_0x2a089d,_0x102e34,new Qi(),!0x1);}get['parent'](){const _0x2ea9b5=To(this['_path']);return _0x2ea9b5===null?null:new Z(this['_repo'],_0x2ea9b5);}get['root'](){let _0x5c5303=this;for(;_0x5c5303['parent']!==null;)_0x5c5303=_0x5c5303['parent'];return _0x5c5303;}}class rt{constructor(_0xd2cfc5,_0x23ebc0,_0x49bd8f){this['_node']=_0xd2cfc5,this['ref']=_0x23ebc0,this['_index']=_0x49bd8f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4de860){const _0x2c3da3=new C(_0x4de860),_0x4673cc=Lt(this['ref'],_0x4de860);return new rt(this['_node']['getChild'](_0x2c3da3),_0x4673cc,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x45440b){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x292f67,_0x404818)=>_0x45440b(new rt(_0x404818,Lt(this['ref'],_0x292f67),R)));}['hasChild'](_0x20f8b6){const _0x185df2=new C(_0x20f8b6);return!this['_node']['getChild'](_0x185df2)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1fb8a9,_0x41cd9b){return _0x1fb8a9=k(_0x1fb8a9),_0x1fb8a9['_checkNotDeleted']('ref'),_0x41cd9b!==void 0x0?Lt(_0x1fb8a9['_root'],_0x41cd9b):_0x1fb8a9['_root'];}function Lt(_0x3a8693,_0x3e3201){return _0x3a8693=k(_0x3a8693),y(_0x3a8693['_path'])===null?ud('child','path',_0x3e3201):_s('child','path',_0x3e3201),new Z(_0x3a8693['_repo'],A(_0x3a8693['_path'],_0x3e3201));}function d_(_0xf5a440,_0x5a623e){_0xf5a440=k(_0xf5a440),gs('push',_0xf5a440['_path']),qt('push',_0x5a623e,_0xf5a440['_path'],!0x0);const _0x3808d8=oa(_0xf5a440['_repo']),_0x430a9c=Od(_0x3808d8),_0x3098de=Lt(_0xf5a440,_0x430a9c),_0x5ea775=Lt(_0xf5a440,_0x430a9c);let _0x23f2ec;return _0x5a623e!=null?_0x23f2ec=Ld(_0x5ea775,_0x5a623e)['then'](()=>_0x5ea775):_0x23f2ec=Promise['resolve'](_0x5ea775),_0x3098de['then']=_0x23f2ec['then']['bind'](_0x23f2ec),_0x3098de['catch']=_0x23f2ec['then']['bind'](_0x23f2ec,void 0x0),_0x3098de;}function Ld(_0x4d9b04,_0x2b6a29){_0x4d9b04=k(_0x4d9b04),gs('set',_0x4d9b04['_path']),qt('set',_0x2b6a29,_0x4d9b04['_path'],!0x1);const _0x1b8b0f=new Ve();return Ed(_0x4d9b04['_repo'],_0x4d9b04['_path'],_0x2b6a29,null,_0x1b8b0f['wrapCallback'](()=>{})),_0x1b8b0f['promise'];}function f_(_0x154f7e,_0x2b0829){hd('update',_0x2b0829,_0x154f7e['_path']);const _0x346c12=new Ve();return Id(_0x154f7e['_repo'],_0x154f7e['_path'],_0x2b0829,_0x346c12['wrapCallback'](()=>{})),_0x346c12['promise'];}function p_(_0x312b3b){_0x312b3b=k(_0x312b3b);const _0x40b1f5=new ua(()=>{}),_0x209c8d=new qn(_0x40b1f5);return vd(_0x312b3b['_repo'],_0x312b3b,_0x209c8d)['then'](_0x11fcd0=>new rt(_0x11fcd0,new Z(_0x312b3b['_repo'],_0x312b3b['_path']),_0x312b3b['_queryParams']['getIndex']()));}class qn{constructor(_0x5d94c9){this['callbackContext']=_0x5d94c9;}['respondsTo'](_0x4a946d){return _0x4a946d==='value';}['createEvent'](_0x9d445a,_0x286d99){const _0xae7523=_0x286d99['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x9d445a['snapshotNode'],new Z(_0x286d99['_repo'],_0x286d99['_path']),_0xae7523));}['getEventRunner'](_0x59c570){return _0x59c570['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x59c570['error']):()=>this['callbackContext']['onValue'](_0x59c570['snapshot'],null);}['createCancelEvent'](_0x4e2e81,_0x3e6999){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x4e2e81,_0x3e6999):null;}['matches'](_0x1d0e4e){return _0x1d0e4e instanceof qn?!_0x1d0e4e['callbackContext']||!this['callbackContext']?!0x0:_0x1d0e4e['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0xa23b0d,_0x29bea7,_0x32b995,_0x3eea9e,_0x4a253e){const _0x27ef35=new ua(_0x32b995,void 0x0),_0x2edab2=new qn(_0x27ef35);return Cd(_0xa23b0d['_repo'],_0xa23b0d,_0x2edab2),()=>Td(_0xa23b0d['_repo'],_0xa23b0d,_0x2edab2);}function Fd(_0x1316f1,_0x204196,_0x35b8a5,_0x18cd6a){return xd(_0x1316f1,'value',_0x204196);}class dt{}class pa extends dt{constructor(_0x435447,_0x230336){super(),this['_value']=_0x435447,this['_key']=_0x230336,this['type']='endAt';}['_apply'](_0x2f809a){qt('endAt',this['_value'],_0x2f809a['_path'],!0x0);const _0x245363=Kh(_0x2f809a['_queryParams'],this['_value'],this['_key']);if(fa(_0x245363),Gn(_0x245363),_0x2f809a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2f809a['_repo'],_0x2f809a['_path'],_0x245363,_0x2f809a['_orderByCalled']);}}function __(_0x1db2c6,_0x31ddcb){return new pa(_0x1db2c6,_0x31ddcb);}class _a extends dt{constructor(_0x15f681,_0x4af75d){super(),this['_value']=_0x15f681,this['_key']=_0x4af75d,this['type']='startAt';}['_apply'](_0x15648d){qt('startAt',this['_value'],_0x15648d['_path'],!0x0);const _0x178b94=jh(_0x15648d['_queryParams'],this['_value'],this['_key']);if(fa(_0x178b94),Gn(_0x178b94),_0x15648d['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x15648d['_repo'],_0x15648d['_path'],_0x178b94,_0x15648d['_orderByCalled']);}}function g_(_0x59015d=null,_0x44070a){return new _a(_0x59015d,_0x44070a);}class Ud extends dt{constructor(_0x1a6488){super(),this['_limit']=_0x1a6488,this['type']='limitToFirst';}['_apply'](_0x524c0c){if(_0x524c0c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x524c0c['_repo'],_0x524c0c['_path'],zh(_0x524c0c['_queryParams'],this['_limit']),_0x524c0c['_orderByCalled']);}}function m_(_0x461b47){if(Math['floor'](_0x461b47)!==_0x461b47||_0x461b47<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x461b47);}class Wd extends dt{constructor(_0x309d65){super(),this['_path']=_0x309d65,this['type']='orderByChild';}['_apply'](_0x4a724d){da(_0x4a724d,'orderByChild');const _0xb0685d=new C(this['_path']);if(v(_0xb0685d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xf214a0=new Ki(_0xb0685d),_0x3ec0bc=Do(_0x4a724d['_queryParams'],_0xf214a0);return Gn(_0x3ec0bc),new be(_0x4a724d['_repo'],_0x4a724d['_path'],_0x3ec0bc,!0x0);}}function y_(_0x294790){if(_0x294790==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x294790==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x294790==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x294790),new Wd(_0x294790);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x48ec3a){da(_0x48ec3a,'orderByKey');const _0x3eee7c=Do(_0x48ec3a['_queryParams'],ye);return Gn(_0x3eee7c),new be(_0x48ec3a['_repo'],_0x48ec3a['_path'],_0x3eee7c,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x4a4181,_0x2dc368){super(),this['_value']=_0x4a4181,this['_key']=_0x2dc368,this['type']='equalTo';}['_apply'](_0x155b0c){if(qt('equalTo',this['_value'],_0x155b0c['_path'],!0x1),_0x155b0c['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x155b0c['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x155b0c));}}function E_(_0x29b9d6,_0x54ab8f){return new Vd(_0x29b9d6,_0x54ab8f);}function I_(_0x2463dd,..._0x2fb5cd){let _0x2b7929=k(_0x2463dd);for(const _0xcae392 of _0x2fb5cd)_0x2b7929=_0xcae392['_apply'](_0x2b7929);return _0x2b7929;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3858f3,_0x3dbc4f,_0x27c38c,_0xbef1f4){const _0x2e506f=_0x3dbc4f['lastIndexOf'](':'),_0x452db1=_0x3dbc4f['substring'](0x0,_0x2e506f),_0x5e8a3c=Wt(_0x452db1);_0x3858f3['repoInfo_']=new _o(_0x3dbc4f,_0x5e8a3c,_0x3858f3['repoInfo_']['namespace'],_0x3858f3['repoInfo_']['webSocketOnly'],_0x3858f3['repoInfo_']['nodeAdmin'],_0x3858f3['repoInfo_']['persistenceKey'],_0x3858f3['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x27c38c),_0xbef1f4&&(_0x3858f3['authTokenProvider_']=_0xbef1f4);}function qd(_0x353d8e,_0x1fa361,_0x45fe77,_0x252a70,_0x5b496c){let _0xc7863e=_0x252a70||_0x353d8e['options']['databaseURL'];_0xc7863e===void 0x0&&(_0x353d8e['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x353d8e['options']['projectId']),_0xc7863e=_0x353d8e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3ccb57=gr(_0xc7863e,_0x5b496c),_0x3c0c83=_0x3ccb57['repoInfo'],_0x13b18d;typeof process<'u'&&Us&&(_0x13b18d=Us[Hd]),_0x13b18d?(_0xc7863e='http://'+_0x13b18d+'?ns='+_0x3c0c83['namespace'],_0x3ccb57=gr(_0xc7863e,_0x5b496c),_0x3c0c83=_0x3ccb57['repoInfo']):_0x3ccb57['repoInfo']['secure'];const _0x5a572f=new Jl(_0x353d8e['name'],_0x353d8e['options'],_0x1fa361);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3ccb57),v(_0x3ccb57['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x7d3dc6=jd(_0x3c0c83,_0x353d8e,_0x5a572f,new Ql(_0x353d8e,_0x45fe77));return new Kd(_0x7d3dc6,_0x353d8e);}function zd(_0x10f368,_0x149fb2){const _0x2c414e=ki[_0x149fb2];(!_0x2c414e||_0x2c414e[_0x10f368['key']]!==_0x10f368)&&oe('Database\x20'+_0x149fb2+'('+_0x10f368['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x10f368),delete _0x2c414e[_0x10f368['key']];}function jd(_0x29ab80,_0x54ca02,_0x1d4bef,_0x1daf65){let _0x234c84=ki[_0x54ca02['name']];_0x234c84||(_0x234c84={},ki[_0x54ca02['name']]=_0x234c84);let _0x21e201=_0x234c84[_0x29ab80['toURLString']()];return _0x21e201&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x21e201=new gd(_0x29ab80,$d,_0x1d4bef,_0x1daf65),_0x234c84[_0x29ab80['toURLString']()]=_0x21e201,_0x21e201;}class Kd{constructor(_0xe2a88,_0x5425bf){this['_repoInternal']=_0xe2a88,this['app']=_0x5425bf,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x204a31){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x204a31+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x531efb=Qr(),_0x3fc42f){const _0x5a3173=Ui(_0x531efb,'database')['getImmediate']({'identifier':_0x3fc42f});if(!_0x5a3173['_instanceStarted']){const _0x2af45a=ac('database');_0x2af45a&&Yd(_0x5a3173,..._0x2af45a);}return _0x5a3173;}function Yd(_0x44d246,_0x3d3def,_0xea45d3,_0x16f377={}){_0x44d246=k(_0x44d246),_0x44d246['_checkNotDeleted']('useEmulator');const _0x1172af=_0x3d3def+':'+_0xea45d3,_0x285c51=_0x44d246['_repoInternal'];if(_0x44d246['_instanceStarted']){if(_0x1172af===_0x44d246['_repoInternal']['repoInfo_']['host']&&De(_0x16f377,_0x285c51['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3268ae;if(_0x285c51['repoInfo_']['nodeAdmin'])_0x16f377['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3268ae=new tn(tn['OWNER']);else{if(_0x16f377['mockUserToken']){const _0x15af64=typeof _0x16f377['mockUserToken']=='string'?_0x16f377['mockUserToken']:cc(_0x16f377['mockUserToken'],_0x44d246['app']['options']['projectId']);_0x3268ae=new tn(_0x15af64);}}Wt(_0x3d3def)&&jr(_0x3d3def),Gd(_0x285c51,_0x1172af,_0x16f377,_0x3268ae);}function C_(_0x1b58eb){_0x1b58eb=k(_0x1b58eb),_0x1b58eb['_checkNotDeleted']('goOffline'),aa(_0x1b58eb['_repo']);}function T_(_0x135a92){_0x135a92=k(_0x135a92),_0x135a92['_checkNotDeleted']('goOnline'),Sd(_0x135a92['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x480dd7){Ll(ct),et(new Me('database',(_0x4eff03,{instanceIdentifier:_0x5d77a5})=>{const _0x4e42c9=_0x4eff03['getProvider']('app')['getImmediate'](),_0x10b818=_0x4eff03['getProvider']('auth-internal'),_0x3809f3=_0x4eff03['getProvider']('app-check-internal');return qd(_0x4e42c9,_0x10b818,_0x3809f3,_0x5d77a5);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x480dd7),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xe25a36,_0x4b632a){this['committed']=_0xe25a36,this['snapshot']=_0x4b632a;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x4ecddb,_0x31b342,_0x35f1d1){if(_0x4ecddb=k(_0x4ecddb),gs('Reference.transaction',_0x4ecddb['_path']),_0x4ecddb['key']==='.length'||_0x4ecddb['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4ecddb['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1a35eb=!0x0,_0x2672ad=new Ve(),_0x23828a=(_0x3bb1f5,_0x72798b,_0x457249)=>{let _0x19301d=null;_0x3bb1f5?_0x2672ad['reject'](_0x3bb1f5):(_0x19301d=new rt(_0x457249,new Z(_0x4ecddb['_repo'],_0x4ecddb['_path']),R),_0x2672ad['resolve'](new Xd(_0x72798b,_0x19301d)));},_0x573027=Fd(_0x4ecddb,()=>{});return bd(_0x4ecddb['_repo'],_0x4ecddb['_path'],_0x31b342,_0x23828a,_0x573027,_0x1a35eb),_0x2672ad['promise'];}ie['prototype']['simpleListen']=function(_0x5e0859,_0x38a067){this['sendRequest']('q',{'p':_0x5e0859},_0x38a067);},ie['prototype']['echo']=function(_0x4f1936,_0x149156){this['sendRequest']('echo',{'d':_0x4f1936},_0x149156);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x469c4f,..._0x27019c){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x469c4f,..._0x27019c);}function nn(_0xdc3f65,..._0x31c1fe){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0xdc3f65,..._0x31c1fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x331bf6,..._0x407860){throw Es(_0x331bf6,..._0x407860);}function J(_0x1d88b4,..._0x567bb3){return Es(_0x1d88b4,..._0x567bb3);}function ya(_0x4ee5e7,_0x1a5ca6,_0x4fef2e){const _0x1d6742={...Zd(),[_0x1a5ca6]:_0x4fef2e};return new Ut('auth','Firebase',_0x1d6742)['create'](_0x1a5ca6,{'appName':_0x4ee5e7['name']});}function se(_0x505dfe){return ya(_0x505dfe,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0xfc4c56,..._0x203731){if(typeof _0xfc4c56!='string'){const _0x26fc82=_0x203731[0x0],_0x442c7e=[..._0x203731['slice'](0x1)];return _0x442c7e[0x0]&&(_0x442c7e[0x0]['appName']=_0xfc4c56['name']),_0xfc4c56['_errorFactory']['create'](_0x26fc82,..._0x442c7e);}return ma['create'](_0xfc4c56,..._0x203731);}function m(_0xf821f,_0x224c14,..._0xdd25a0){if(!_0xf821f)throw Es(_0x224c14,..._0xdd25a0);}function te(_0x1201bb){const _0x203bfd='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1201bb;throw nn(_0x203bfd),new Error(_0x203bfd);}function ae(_0x283df8,_0x286500){_0x283df8||te(_0x286500);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x112a50;return typeof self<'u'&&((_0x112a50=self['location'])==null?void 0x0:_0x112a50['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x701438;return typeof self<'u'&&((_0x701438=self['location'])==null?void 0x0:_0x701438['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x41b112=navigator;return _0x41b112['languages']&&_0x41b112['languages'][0x0]||_0x41b112['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3074b1,_0xb7a8be){this['shortDelay']=_0x3074b1,this['longDelay']=_0xb7a8be,ae(_0xb7a8be>_0x3074b1,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x732217,_0x4ef928){ae(_0x732217['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5a7658}=_0x732217['emulator'];return _0x4ef928?''+_0x5a7658+(_0x4ef928['startsWith']('/')?_0x4ef928['slice'](0x1):_0x4ef928):_0x5a7658;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5edae9,_0x422561,_0x943c03){this['fetchImpl']=_0x5edae9,_0x422561&&(this['headersImpl']=_0x422561),_0x943c03&&(this['responseImpl']=_0x943c03);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x317271,_0x46e2fa){return _0x317271['tenantId']&&!_0x46e2fa['tenantId']?{..._0x46e2fa,'tenantId':_0x317271['tenantId']}:_0x46e2fa;}async function Ae(_0x4024a0,_0x59ad57,_0x3af63d,_0x1c0683,_0x15f7ad={}){return Ea(_0x4024a0,_0x15f7ad,async()=>{let _0x3e6af0={},_0x4f11c5={};_0x1c0683&&(_0x59ad57==='GET'?_0x4f11c5=_0x1c0683:_0x3e6af0={'body':JSON['stringify'](_0x1c0683)});const _0x2b97a2=at({..._0x4f11c5,'key':_0x4024a0['config']['apiKey']})['slice'](0x1),_0x1e52de=await _0x4024a0['_getAdditionalHeaders']();_0x1e52de['Content-Type']='application/json',_0x4024a0['languageCode']&&(_0x1e52de['X-Firebase-Locale']=_0x4024a0['languageCode']);const _0x2af345={'method':_0x59ad57,'headers':_0x1e52de,..._0x3e6af0};return lc()||(_0x2af345['referrerPolicy']='strict-origin-when-cross-origin'),_0x4024a0['emulatorConfig']&&Wt(_0x4024a0['emulatorConfig']['host'])&&(_0x2af345['credentials']='include'),va['fetch']()(await Ia(_0x4024a0,_0x4024a0['config']['apiHost'],_0x3af63d,_0x2b97a2),_0x2af345);});}async function Ea(_0x56aeba,_0x349a27,_0x48cd06){_0x56aeba['_canInitEmulator']=!0x1;const _0xb4876b={...rf,..._0x349a27};try{const _0x51861b=new lf(_0x56aeba),_0x3e503c=await Promise['race']([_0x48cd06(),_0x51861b['promise']]);_0x51861b['clearNetworkTimeout']();const _0x48ff3c=await _0x3e503c['json']();if('needConfirmation'in _0x48ff3c)throw en(_0x56aeba,'account-exists-with-different-credential',_0x48ff3c);if(_0x3e503c['ok']&&!('errorMessage'in _0x48ff3c))return _0x48ff3c;{const _0x39277b=_0x3e503c['ok']?_0x48ff3c['errorMessage']:_0x48ff3c['error']['message'],[_0x3d94ba,_0x7cbd9a]=_0x39277b['split']('\x20:\x20');if(_0x3d94ba==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x56aeba,'credential-already-in-use',_0x48ff3c);if(_0x3d94ba==='EMAIL_EXISTS')throw en(_0x56aeba,'email-already-in-use',_0x48ff3c);if(_0x3d94ba==='USER_DISABLED')throw en(_0x56aeba,'user-disabled',_0x48ff3c);const _0x2942cb=_0xb4876b[_0x3d94ba]||_0x3d94ba['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x7cbd9a)throw ya(_0x56aeba,_0x2942cb,_0x7cbd9a);K(_0x56aeba,_0x2942cb);}}catch(_0x144558){if(_0x144558 instanceof Se)throw _0x144558;K(_0x56aeba,'network-request-failed',{'message':String(_0x144558)});}}async function Yt(_0x519784,_0xd81e24,_0xa1a7da,_0xe92411,_0x5d8a5e={}){const _0x4b2632=await Ae(_0x519784,_0xd81e24,_0xa1a7da,_0xe92411,_0x5d8a5e);return'mfaPendingCredential'in _0x4b2632&&K(_0x519784,'multi-factor-auth-required',{'_serverResponse':_0x4b2632}),_0x4b2632;}async function Ia(_0x898707,_0x3a42a3,_0x35a8da,_0x110876){const _0x50740f=''+_0x3a42a3+_0x35a8da+'?'+_0x110876,_0x2af730=_0x898707,_0x5cd4ca=_0x2af730['config']['emulator']?Is(_0x898707['config'],_0x50740f):_0x898707['config']['apiScheme']+'://'+_0x50740f;return of['includes'](_0x35a8da)&&(await _0x2af730['_persistenceManagerAvailable'],_0x2af730['_getPersistenceType']()==='COOKIE')?_0x2af730['_getPersistence']()['_getFinalTarget'](_0x5cd4ca)['toString']():_0x5cd4ca;}function cf(_0x2159bb){switch(_0x2159bb){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x78d4f3){this['auth']=_0x78d4f3,this['timer']=null,this['promise']=new Promise((_0x5822ca,_0x629a71)=>{this['timer']=setTimeout(()=>_0x629a71(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0xcd7566,_0xa8dafa,_0x7351c5){const _0x11800b={'appName':_0xcd7566['name']};_0x7351c5['email']&&(_0x11800b['email']=_0x7351c5['email']),_0x7351c5['phoneNumber']&&(_0x11800b['phoneNumber']=_0x7351c5['phoneNumber']);const _0x201f97=J(_0xcd7566,_0xa8dafa,_0x11800b);return _0x201f97['customData']['_tokenResponse']=_0x7351c5,_0x201f97;}function vr(_0x43a4df){return _0x43a4df!==void 0x0&&_0x43a4df['enterprise']!==void 0x0;}class hf{constructor(_0x5a7651){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5a7651['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5a7651['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5a7651['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x51f456){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4ae3c4 of this['recaptchaEnforcementState'])if(_0x4ae3c4['provider']&&_0x4ae3c4['provider']===_0x51f456)return cf(_0x4ae3c4['enforcementState']);return null;}['isProviderEnabled'](_0x22b242){return this['getProviderEnforcementState'](_0x22b242)==='ENFORCE'||this['getProviderEnforcementState'](_0x22b242)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x45ac2b,_0x3d7640){return Ae(_0x45ac2b,'GET','/v2/recaptchaConfig',Re(_0x45ac2b,_0x3d7640));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4e0d74,_0xd12450){return Ae(_0x4e0d74,'POST','/v1/accounts:delete',_0xd12450);}async function Sn(_0x58f03d,_0xce3420){return Ae(_0x58f03d,'POST','/v1/accounts:lookup',_0xce3420);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x345522){if(_0x345522)try{const _0x5da0e8=new Date(Number(_0x345522));if(!isNaN(_0x5da0e8['getTime']()))return _0x5da0e8['toUTCString']();}catch{}}async function ff(_0x2fde0c,_0x41c845=!0x1){const _0x3436bf=k(_0x2fde0c),_0x3f1dda=await _0x3436bf['getIdToken'](_0x41c845),_0x177cd8=ws(_0x3f1dda);m(_0x177cd8&&_0x177cd8['exp']&&_0x177cd8['auth_time']&&_0x177cd8['iat'],_0x3436bf['auth'],'internal-error');const _0x10beae=typeof _0x177cd8['firebase']=='object'?_0x177cd8['firebase']:void 0x0,_0x4f7903=_0x10beae==null?void 0x0:_0x10beae['sign_in_provider'];return{'claims':_0x177cd8,'token':_0x3f1dda,'authTime':St(ci(_0x177cd8['auth_time'])),'issuedAtTime':St(ci(_0x177cd8['iat'])),'expirationTime':St(ci(_0x177cd8['exp'])),'signInProvider':_0x4f7903||null,'signInSecondFactor':(_0x10beae==null?void 0x0:_0x10beae['sign_in_second_factor'])||null};}function ci(_0x1beb27){return Number(_0x1beb27)*0x3e8;}function ws(_0x4c7a5b){const [_0x33e792,_0x1e5bd6,_0x324a1d]=_0x4c7a5b['split']('.');if(_0x33e792===void 0x0||_0x1e5bd6===void 0x0||_0x324a1d===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4cc621=cn(_0x1e5bd6);return _0x4cc621?JSON['parse'](_0x4cc621):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2bac54){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2bac54==null?void 0x0:_0x2bac54['toString']()),null;}}function Er(_0x3cdd61){const _0x4bd1a3=ws(_0x3cdd61);return m(_0x4bd1a3,'internal-error'),m(typeof _0x4bd1a3['exp']<'u','internal-error'),m(typeof _0x4bd1a3['iat']<'u','internal-error'),Number(_0x4bd1a3['exp'])-Number(_0x4bd1a3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x134d85,_0x2581e8,_0x542a3c=!0x1){if(_0x542a3c)return _0x2581e8;try{return await _0x2581e8;}catch(_0x2f1ce0){throw _0x2f1ce0 instanceof Se&&pf(_0x2f1ce0)&&_0x134d85['auth']['currentUser']===_0x134d85&&await _0x134d85['auth']['signOut'](),_0x2f1ce0;}}function pf({code:_0x574c05}){return _0x574c05==='auth/user-disabled'||_0x574c05==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x554626){this['user']=_0x554626,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x215948){if(_0x215948){const _0x32184f=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x32184f;}else{this['errorBackoff']=0x7530;const _0x47ca0e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x47ca0e);}}['schedule'](_0x13a054=!0x1){if(!this['isRunning'])return;const _0x5173ed=this['getInterval'](_0x13a054);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5173ed);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5b72ed){(_0x5b72ed==null?void 0x0:_0x5b72ed['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x816720,_0xb29f3b){this['createdAt']=_0x816720,this['lastLoginAt']=_0xb29f3b,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x597fd0){this['createdAt']=_0x597fd0['createdAt'],this['lastLoginAt']=_0x597fd0['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x49fff0){var _0x2148eb;const _0x5b7c46=_0x49fff0['auth'],_0x42bd50=await _0x49fff0['getIdToken'](),_0x2483fd=await xt(_0x49fff0,Sn(_0x5b7c46,{'idToken':_0x42bd50}));m(_0x2483fd==null?void 0x0:_0x2483fd['users']['length'],_0x5b7c46,'internal-error');const _0x51e430=_0x2483fd['users'][0x0];_0x49fff0['_notifyReloadListener'](_0x51e430);const _0x5afce4=(_0x2148eb=_0x51e430['providerUserInfo'])!=null&&_0x2148eb['length']?wa(_0x51e430['providerUserInfo']):[],_0x49f9b3=mf(_0x49fff0['providerData'],_0x5afce4),_0x4b7580=_0x49fff0['isAnonymous'],_0x491190=!(_0x49fff0['email']&&_0x51e430['passwordHash'])&&!(_0x49f9b3!=null&&_0x49f9b3['length']),_0x11eec7=_0x4b7580?_0x491190:!0x1,_0x3751b1={'uid':_0x51e430['localId'],'displayName':_0x51e430['displayName']||null,'photoURL':_0x51e430['photoUrl']||null,'email':_0x51e430['email']||null,'emailVerified':_0x51e430['emailVerified']||!0x1,'phoneNumber':_0x51e430['phoneNumber']||null,'tenantId':_0x51e430['tenantId']||null,'providerData':_0x49f9b3,'metadata':new Pi(_0x51e430['createdAt'],_0x51e430['lastLoginAt']),'isAnonymous':_0x11eec7};Object['assign'](_0x49fff0,_0x3751b1);}async function gf(_0x1fa6df){const _0x1bf797=k(_0x1fa6df);await bn(_0x1bf797),await _0x1bf797['auth']['_persistUserIfCurrent'](_0x1bf797),_0x1bf797['auth']['_notifyListenersIfCurrent'](_0x1bf797);}function mf(_0x49e83b,_0x200f9a){return[..._0x49e83b['filter'](_0x47768c=>!_0x200f9a['some'](_0x1ccd22=>_0x1ccd22['providerId']===_0x47768c['providerId'])),..._0x200f9a];}function wa(_0x194ad4){return _0x194ad4['map'](({providerId:_0x115b75,..._0x990e2f})=>({'providerId':_0x115b75,'uid':_0x990e2f['rawId']||'','displayName':_0x990e2f['displayName']||null,'email':_0x990e2f['email']||null,'phoneNumber':_0x990e2f['phoneNumber']||null,'photoURL':_0x990e2f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x3062de,_0x4f45ff){const _0x2d84c1=await Ea(_0x3062de,{},async()=>{const _0x4190f3=at({'grant_type':'refresh_token','refresh_token':_0x4f45ff})['slice'](0x1),{tokenApiHost:_0xd0e643,apiKey:_0x2213ca}=_0x3062de['config'],_0x167035=await Ia(_0x3062de,_0xd0e643,'/v1/token','key='+_0x2213ca),_0x56e8a1=await _0x3062de['_getAdditionalHeaders']();_0x56e8a1['Content-Type']='application/x-www-form-urlencoded';const _0x138dfb={'method':'POST','headers':_0x56e8a1,'body':_0x4190f3};return _0x3062de['emulatorConfig']&&Wt(_0x3062de['emulatorConfig']['host'])&&(_0x138dfb['credentials']='include'),va['fetch']()(_0x167035,_0x138dfb);});return{'accessToken':_0x2d84c1['access_token'],'expiresIn':_0x2d84c1['expires_in'],'refreshToken':_0x2d84c1['refresh_token']};}async function vf(_0x26bf5b,_0x2dcec0){return Ae(_0x26bf5b,'POST','/v2/accounts:revokeToken',Re(_0x26bf5b,_0x2dcec0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x15ae3b){m(_0x15ae3b['idToken'],'internal-error'),m(typeof _0x15ae3b['idToken']<'u','internal-error'),m(typeof _0x15ae3b['refreshToken']<'u','internal-error');const _0x116bae='expiresIn'in _0x15ae3b&&typeof _0x15ae3b['expiresIn']<'u'?Number(_0x15ae3b['expiresIn']):Er(_0x15ae3b['idToken']);this['updateTokensAndExpiration'](_0x15ae3b['idToken'],_0x15ae3b['refreshToken'],_0x116bae);}['updateFromIdToken'](_0x2a72b8){m(_0x2a72b8['length']!==0x0,'internal-error');const _0x11ac18=Er(_0x2a72b8);this['updateTokensAndExpiration'](_0x2a72b8,null,_0x11ac18);}async['getToken'](_0x183384,_0x585ea8=!0x1){return!_0x585ea8&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x183384,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x183384,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x55a9ee,_0x3e74cc){const {accessToken:_0x1b98dc,refreshToken:_0x2404c8,expiresIn:_0x345a70}=await yf(_0x55a9ee,_0x3e74cc);this['updateTokensAndExpiration'](_0x1b98dc,_0x2404c8,Number(_0x345a70));}['updateTokensAndExpiration'](_0x45cf83,_0x2d751e,_0x5c83b5){this['refreshToken']=_0x2d751e||null,this['accessToken']=_0x45cf83||null,this['expirationTime']=Date['now']()+_0x5c83b5*0x3e8;}static['fromJSON'](_0x1a4d3e,_0xf21d25){const {refreshToken:_0x4cfb4f,accessToken:_0x51eb24,expirationTime:_0x26301d}=_0xf21d25,_0x541e16=new Je();return _0x4cfb4f&&(m(typeof _0x4cfb4f=='string','internal-error',{'appName':_0x1a4d3e}),_0x541e16['refreshToken']=_0x4cfb4f),_0x51eb24&&(m(typeof _0x51eb24=='string','internal-error',{'appName':_0x1a4d3e}),_0x541e16['accessToken']=_0x51eb24),_0x26301d&&(m(typeof _0x26301d=='number','internal-error',{'appName':_0x1a4d3e}),_0x541e16['expirationTime']=_0x26301d),_0x541e16;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x56442c){this['accessToken']=_0x56442c['accessToken'],this['refreshToken']=_0x56442c['refreshToken'],this['expirationTime']=_0x56442c['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x33b4fe,_0x19bd56){m(typeof _0x33b4fe=='string'||typeof _0x33b4fe>'u','internal-error',{'appName':_0x19bd56});}class z{constructor({uid:_0x2d3d59,auth:_0x28e3ae,stsTokenManager:_0x6080c0,..._0x59e56c}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2d3d59,this['auth']=_0x28e3ae,this['stsTokenManager']=_0x6080c0,this['accessToken']=_0x6080c0['accessToken'],this['displayName']=_0x59e56c['displayName']||null,this['email']=_0x59e56c['email']||null,this['emailVerified']=_0x59e56c['emailVerified']||!0x1,this['phoneNumber']=_0x59e56c['phoneNumber']||null,this['photoURL']=_0x59e56c['photoURL']||null,this['isAnonymous']=_0x59e56c['isAnonymous']||!0x1,this['tenantId']=_0x59e56c['tenantId']||null,this['providerData']=_0x59e56c['providerData']?[..._0x59e56c['providerData']]:[],this['metadata']=new Pi(_0x59e56c['createdAt']||void 0x0,_0x59e56c['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4edf83){const _0x4f8c10=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4edf83));return m(_0x4f8c10,this['auth'],'internal-error'),this['accessToken']!==_0x4f8c10&&(this['accessToken']=_0x4f8c10,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4f8c10;}['getIdTokenResult'](_0x1a617b){return ff(this,_0x1a617b);}['reload'](){return gf(this);}['_assign'](_0x180543){this!==_0x180543&&(m(this['uid']===_0x180543['uid'],this['auth'],'internal-error'),this['displayName']=_0x180543['displayName'],this['photoURL']=_0x180543['photoURL'],this['email']=_0x180543['email'],this['emailVerified']=_0x180543['emailVerified'],this['phoneNumber']=_0x180543['phoneNumber'],this['isAnonymous']=_0x180543['isAnonymous'],this['tenantId']=_0x180543['tenantId'],this['providerData']=_0x180543['providerData']['map'](_0x26070d=>({..._0x26070d})),this['metadata']['_copy'](_0x180543['metadata']),this['stsTokenManager']['_assign'](_0x180543['stsTokenManager']));}['_clone'](_0x223bf1){const _0x19bc0f=new z({...this,'auth':_0x223bf1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x19bc0f['metadata']['_copy'](this['metadata']),_0x19bc0f;}['_onReload'](_0x5cd51a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5cd51a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x215331){this['reloadListener']?this['reloadListener'](_0x215331):this['reloadUserInfo']=_0x215331;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xbe83ca,_0x2426ac=!0x1){let _0x43290d=!0x1;_0xbe83ca['idToken']&&_0xbe83ca['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xbe83ca),_0x43290d=!0x0),_0x2426ac&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x43290d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x25ebbe=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x25ebbe})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x36b691=>({..._0x36b691})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x58528e,_0x15884f){const _0x11c5f1=_0x15884f['displayName']??void 0x0,_0x801a5f=_0x15884f['email']??void 0x0,_0x1c6b1e=_0x15884f['phoneNumber']??void 0x0,_0xc49363=_0x15884f['photoURL']??void 0x0,_0x33d61c=_0x15884f['tenantId']??void 0x0,_0x421b76=_0x15884f['_redirectEventId']??void 0x0,_0x38e6c6=_0x15884f['createdAt']??void 0x0,_0x2514c9=_0x15884f['lastLoginAt']??void 0x0,{uid:_0x524ad1,emailVerified:_0x55a470,isAnonymous:_0x3d5380,providerData:_0xd8031b,stsTokenManager:_0x39dbd1}=_0x15884f;m(_0x524ad1&&_0x39dbd1,_0x58528e,'internal-error');const _0x34db55=Je['fromJSON'](this['name'],_0x39dbd1);m(typeof _0x524ad1=='string',_0x58528e,'internal-error'),ce(_0x11c5f1,_0x58528e['name']),ce(_0x801a5f,_0x58528e['name']),m(typeof _0x55a470=='boolean',_0x58528e,'internal-error'),m(typeof _0x3d5380=='boolean',_0x58528e,'internal-error'),ce(_0x1c6b1e,_0x58528e['name']),ce(_0xc49363,_0x58528e['name']),ce(_0x33d61c,_0x58528e['name']),ce(_0x421b76,_0x58528e['name']),ce(_0x38e6c6,_0x58528e['name']),ce(_0x2514c9,_0x58528e['name']);const _0x3b7483=new z({'uid':_0x524ad1,'auth':_0x58528e,'email':_0x801a5f,'emailVerified':_0x55a470,'displayName':_0x11c5f1,'isAnonymous':_0x3d5380,'photoURL':_0xc49363,'phoneNumber':_0x1c6b1e,'tenantId':_0x33d61c,'stsTokenManager':_0x34db55,'createdAt':_0x38e6c6,'lastLoginAt':_0x2514c9});return _0xd8031b&&Array['isArray'](_0xd8031b)&&(_0x3b7483['providerData']=_0xd8031b['map'](_0x2996f9=>({..._0x2996f9}))),_0x421b76&&(_0x3b7483['_redirectEventId']=_0x421b76),_0x3b7483;}static async['_fromIdTokenResponse'](_0x90dd1c,_0x5748fc,_0x24875c=!0x1){const _0x2c16dc=new Je();_0x2c16dc['updateFromServerResponse'](_0x5748fc);const _0x153fea=new z({'uid':_0x5748fc['localId'],'auth':_0x90dd1c,'stsTokenManager':_0x2c16dc,'isAnonymous':_0x24875c});return await bn(_0x153fea),_0x153fea;}static async['_fromGetAccountInfoResponse'](_0x57def5,_0xb7b138,_0x562e9a){const _0x3e17ef=_0xb7b138['users'][0x0];m(_0x3e17ef['localId']!==void 0x0,'internal-error');const _0x17fdaa=_0x3e17ef['providerUserInfo']!==void 0x0?wa(_0x3e17ef['providerUserInfo']):[],_0x2acb9b=!(_0x3e17ef['email']&&_0x3e17ef['passwordHash'])&&!(_0x17fdaa!=null&&_0x17fdaa['length']),_0x448920=new Je();_0x448920['updateFromIdToken'](_0x562e9a);const _0x75d66a=new z({'uid':_0x3e17ef['localId'],'auth':_0x57def5,'stsTokenManager':_0x448920,'isAnonymous':_0x2acb9b}),_0xe3b705={'uid':_0x3e17ef['localId'],'displayName':_0x3e17ef['displayName']||null,'photoURL':_0x3e17ef['photoUrl']||null,'email':_0x3e17ef['email']||null,'emailVerified':_0x3e17ef['emailVerified']||!0x1,'phoneNumber':_0x3e17ef['phoneNumber']||null,'tenantId':_0x3e17ef['tenantId']||null,'providerData':_0x17fdaa,'metadata':new Pi(_0x3e17ef['createdAt'],_0x3e17ef['lastLoginAt']),'isAnonymous':!(_0x3e17ef['email']&&_0x3e17ef['passwordHash'])&&!(_0x17fdaa!=null&&_0x17fdaa['length'])};return Object['assign'](_0x75d66a,_0xe3b705),_0x75d66a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x1d5d73){ae(_0x1d5d73 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5417b4=Ir['get'](_0x1d5d73);return _0x5417b4?(ae(_0x5417b4 instanceof _0x1d5d73,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5417b4):(_0x5417b4=new _0x1d5d73(),Ir['set'](_0x1d5d73,_0x5417b4),_0x5417b4);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5b7ac,_0x2264aa){this['storage'][_0x5b7ac]=_0x2264aa;}async['_get'](_0x2aa938){const _0x268824=this['storage'][_0x2aa938];return _0x268824===void 0x0?null:_0x268824;}async['_remove'](_0x373591){delete this['storage'][_0x373591];}['_addListener'](_0x58c7e3,_0x2e9aa2){}['_removeListener'](_0x5e152f,_0x738bea){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x2fb89c,_0x58554f,_0x2ac983){return'firebase:'+_0x2fb89c+':'+_0x58554f+':'+_0x2ac983;}class Xe{constructor(_0x51b0ce,_0x5e74d2,_0x3753ca){this['persistence']=_0x51b0ce,this['auth']=_0x5e74d2,this['userKey']=_0x3753ca;const {config:_0x1c5976,name:_0x4ff020}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1c5976['apiKey'],_0x4ff020),this['fullPersistenceKey']=sn('persistence',_0x1c5976['apiKey'],_0x4ff020),this['boundEventHandler']=_0x5e74d2['_onStorageEvent']['bind'](_0x5e74d2),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3413fd){return this['persistence']['_set'](this['fullUserKey'],_0x3413fd['toJSON']());}async['getCurrentUser'](){const _0x52c1c7=await this['persistence']['_get'](this['fullUserKey']);if(!_0x52c1c7)return null;if(typeof _0x52c1c7=='string'){const _0x5303ca=await Sn(this['auth'],{'idToken':_0x52c1c7})['catch'](()=>{});return _0x5303ca?z['_fromGetAccountInfoResponse'](this['auth'],_0x5303ca,_0x52c1c7):null;}return z['_fromJSON'](this['auth'],_0x52c1c7);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1196e6){if(this['persistence']===_0x1196e6)return;const _0x45c4b3=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1196e6,_0x45c4b3)return this['setCurrentUser'](_0x45c4b3);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2ce1a9,_0x547163,_0x146e24='authUser'){if(!_0x547163['length'])return new Xe(ne(wr),_0x2ce1a9,_0x146e24);const _0xb5bb64=(await Promise['all'](_0x547163['map'](async _0x435416=>{if(await _0x435416['_isAvailable']())return _0x435416;})))['filter'](_0x5f3c2c=>_0x5f3c2c);let _0x2e0541=_0xb5bb64[0x0]||ne(wr);const _0x576bfc=sn(_0x146e24,_0x2ce1a9['config']['apiKey'],_0x2ce1a9['name']);let _0x39339b=null;for(const _0x39d5cb of _0x547163)try{const _0xa94aae=await _0x39d5cb['_get'](_0x576bfc);if(_0xa94aae){let _0x2d73db;if(typeof _0xa94aae=='string'){const _0x106eaf=await Sn(_0x2ce1a9,{'idToken':_0xa94aae})['catch'](()=>{});if(!_0x106eaf)break;_0x2d73db=await z['_fromGetAccountInfoResponse'](_0x2ce1a9,_0x106eaf,_0xa94aae);}else _0x2d73db=z['_fromJSON'](_0x2ce1a9,_0xa94aae);_0x39d5cb!==_0x2e0541&&(_0x39339b=_0x2d73db),_0x2e0541=_0x39d5cb;break;}}catch{}const _0x55b386=_0xb5bb64['filter'](_0x490dc6=>_0x490dc6['_shouldAllowMigration']);return!_0x2e0541['_shouldAllowMigration']||!_0x55b386['length']?new Xe(_0x2e0541,_0x2ce1a9,_0x146e24):(_0x2e0541=_0x55b386[0x0],_0x39339b&&await _0x2e0541['_set'](_0x576bfc,_0x39339b['toJSON']()),await Promise['all'](_0x547163['map'](async _0x538ef3=>{if(_0x538ef3!==_0x2e0541)try{await _0x538ef3['_remove'](_0x576bfc);}catch{}})),new Xe(_0x2e0541,_0x2ce1a9,_0x146e24));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x45f6a4){const _0x55961b=_0x45f6a4['toLowerCase']();if(_0x55961b['includes']('opera/')||_0x55961b['includes']('opr/')||_0x55961b['includes']('opios/'))return'Opera';if(Ra(_0x55961b))return'IEMobile';if(_0x55961b['includes']('msie')||_0x55961b['includes']('trident/'))return'IE';if(_0x55961b['includes']('edge/'))return'Edge';if(Ta(_0x55961b))return'Firefox';if(_0x55961b['includes']('silk/'))return'Silk';if(ka(_0x55961b))return'Blackberry';if(Na(_0x55961b))return'Webos';if(Sa(_0x55961b))return'Safari';if((_0x55961b['includes']('chrome/')||ba(_0x55961b))&&!_0x55961b['includes']('edge/'))return'Chrome';if(Aa(_0x55961b))return'Android';{const _0x1c152f=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3f7e4c=_0x45f6a4['match'](_0x1c152f);if((_0x3f7e4c==null?void 0x0:_0x3f7e4c['length'])===0x2)return _0x3f7e4c[0x1];}return'Other';}function Ta(_0x188521=W()){return/firefox\//i['test'](_0x188521);}function Sa(_0x48799c=W()){const _0x33b97d=_0x48799c['toLowerCase']();return _0x33b97d['includes']('safari/')&&!_0x33b97d['includes']('chrome/')&&!_0x33b97d['includes']('crios/')&&!_0x33b97d['includes']('android');}function ba(_0xa2325c=W()){return/crios\//i['test'](_0xa2325c);}function Ra(_0x30f2d2=W()){return/iemobile/i['test'](_0x30f2d2);}function Aa(_0x2733f1=W()){return/android/i['test'](_0x2733f1);}function ka(_0x1275a3=W()){return/blackberry/i['test'](_0x1275a3);}function Na(_0x2f405d=W()){return/webos/i['test'](_0x2f405d);}function Cs(_0x2726ac=W()){return/iphone|ipad|ipod/i['test'](_0x2726ac)||/macintosh/i['test'](_0x2726ac)&&/mobile/i['test'](_0x2726ac);}function Ef(_0x10812e=W()){var _0xa4763c;return Cs(_0x10812e)&&!!((_0xa4763c=window['navigator'])!=null&&_0xa4763c['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5d18a2=W()){return Cs(_0x5d18a2)||Aa(_0x5d18a2)||Na(_0x5d18a2)||ka(_0x5d18a2)||/windows phone/i['test'](_0x5d18a2)||Ra(_0x5d18a2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x51a3f6,_0x281c2e=[]){let _0x46239c;switch(_0x51a3f6){case'Browser':_0x46239c=Cr(W());break;case'Worker':_0x46239c=Cr(W())+'-'+_0x51a3f6;break;default:_0x46239c=_0x51a3f6;}const _0x1189bc=_0x281c2e['length']?_0x281c2e['join'](','):'FirebaseCore-web';return _0x46239c+'/JsCore/'+ct+'/'+_0x1189bc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x430dda){this['auth']=_0x430dda,this['queue']=[];}['pushCallback'](_0x2e5221,_0x5ab8b2){const _0xff3d89=_0x57c9fe=>new Promise((_0x2be465,_0x551594)=>{try{const _0xb69b1f=_0x2e5221(_0x57c9fe);_0x2be465(_0xb69b1f);}catch(_0x5c6478){_0x551594(_0x5c6478);}});_0xff3d89['onAbort']=_0x5ab8b2,this['queue']['push'](_0xff3d89);const _0x5f2371=this['queue']['length']-0x1;return()=>{this['queue'][_0x5f2371]=()=>Promise['resolve']();};}async['runMiddleware'](_0x26cda7){if(this['auth']['currentUser']===_0x26cda7)return;const _0x195278=[];try{for(const _0x21e4a5 of this['queue'])await _0x21e4a5(_0x26cda7),_0x21e4a5['onAbort']&&_0x195278['push'](_0x21e4a5['onAbort']);}catch(_0x44d192){_0x195278['reverse']();for(const _0xe294d of _0x195278)try{_0xe294d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x44d192==null?void 0x0:_0x44d192['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x1ec48f,_0x2af21d={}){return Ae(_0x1ec48f,'GET','/v2/passwordPolicy',Re(_0x1ec48f,_0x2af21d));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x48e0e3){var _0x5d8930;const _0x29e21d=_0x48e0e3['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x29e21d['minPasswordLength']??Tf,_0x29e21d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x29e21d['maxPasswordLength']),_0x29e21d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x29e21d['containsLowercaseCharacter']),_0x29e21d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x29e21d['containsUppercaseCharacter']),_0x29e21d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x29e21d['containsNumericCharacter']),_0x29e21d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x29e21d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x48e0e3['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5d8930=_0x48e0e3['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5d8930['join'](''))??'',this['forceUpgradeOnSignin']=_0x48e0e3['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x48e0e3['schemaVersion'];}['validatePassword'](_0x760329){const _0x2cff95={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x760329,_0x2cff95),this['validatePasswordCharacterOptions'](_0x760329,_0x2cff95),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['meetsMinPasswordLength']??!0x0),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['meetsMaxPasswordLength']??!0x0),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['containsLowercaseLetter']??!0x0),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['containsUppercaseLetter']??!0x0),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['containsNumericCharacter']??!0x0),_0x2cff95['isValid']&&(_0x2cff95['isValid']=_0x2cff95['containsNonAlphanumericCharacter']??!0x0),_0x2cff95;}['validatePasswordLengthOptions'](_0x491634,_0xcf9b31){const _0x1e4afc=this['customStrengthOptions']['minPasswordLength'],_0x40c229=this['customStrengthOptions']['maxPasswordLength'];_0x1e4afc&&(_0xcf9b31['meetsMinPasswordLength']=_0x491634['length']>=_0x1e4afc),_0x40c229&&(_0xcf9b31['meetsMaxPasswordLength']=_0x491634['length']<=_0x40c229);}['validatePasswordCharacterOptions'](_0x1c9017,_0x11bae4){this['updatePasswordCharacterOptionsStatuses'](_0x11bae4,!0x1,!0x1,!0x1,!0x1);let _0x41b65c;for(let _0x2e1cb1=0x0;_0x2e1cb1<_0x1c9017['length'];_0x2e1cb1++)_0x41b65c=_0x1c9017['charAt'](_0x2e1cb1),this['updatePasswordCharacterOptionsStatuses'](_0x11bae4,_0x41b65c>='a'&&_0x41b65c<='z',_0x41b65c>='A'&&_0x41b65c<='Z',_0x41b65c>='0'&&_0x41b65c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x41b65c));}['updatePasswordCharacterOptionsStatuses'](_0x461312,_0x245086,_0x5f4aee,_0x9a2c32,_0x4cf86e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x461312['containsLowercaseLetter']||(_0x461312['containsLowercaseLetter']=_0x245086)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x461312['containsUppercaseLetter']||(_0x461312['containsUppercaseLetter']=_0x5f4aee)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x461312['containsNumericCharacter']||(_0x461312['containsNumericCharacter']=_0x9a2c32)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x461312['containsNonAlphanumericCharacter']||(_0x461312['containsNonAlphanumericCharacter']=_0x4cf86e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1563a8,_0x364021,_0x251c9f,_0x4ac06a){this['app']=_0x1563a8,this['heartbeatServiceProvider']=_0x364021,this['appCheckServiceProvider']=_0x251c9f,this['config']=_0x4ac06a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1563a8['name'],this['clientVersion']=_0x4ac06a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x6a8cd2=>this['_resolvePersistenceManagerAvailable']=_0x6a8cd2);}['_initializeWithPersistence'](_0x4ebc30,_0x1c026e){return _0x1c026e&&(this['_popupRedirectResolver']=ne(_0x1c026e)),this['_initializationPromise']=this['queue'](async()=>{var _0x3bea7b,_0x16a2d6,_0x4bf843;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4ebc30),(_0x3bea7b=this['_resolvePersistenceManagerAvailable'])==null||_0x3bea7b['call'](this),!this['_deleted'])){if((_0x16a2d6=this['_popupRedirectResolver'])!=null&&_0x16a2d6['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1c026e),this['lastNotifiedUid']=((_0x4bf843=this['currentUser'])==null?void 0x0:_0x4bf843['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x31aa99=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x31aa99)){if(this['currentUser']&&_0x31aa99&&this['currentUser']['uid']===_0x31aa99['uid']){this['_currentUser']['_assign'](_0x31aa99),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x31aa99,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x13adc4){try{const _0x356983=await Sn(this,{'idToken':_0x13adc4}),_0xd01dcb=await z['_fromGetAccountInfoResponse'](this,_0x356983,_0x13adc4);await this['directlySetCurrentUser'](_0xd01dcb);}catch(_0x4a0648){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4a0648),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x580ea6){var _0x5a00dd;if(H(this['app'])){const _0x414229=this['app']['settings']['authIdToken'];return _0x414229?new Promise(_0x2aeec8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x414229)['then'](_0x2aeec8,_0x2aeec8));}):this['directlySetCurrentUser'](null);}const _0x1b9ec7=await this['assertedPersistence']['getCurrentUser']();let _0x47c8eb=_0x1b9ec7,_0x22140b=!0x1;if(_0x580ea6&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x558a55=(_0x5a00dd=this['redirectUser'])==null?void 0x0:_0x5a00dd['_redirectEventId'],_0x543ba3=_0x47c8eb==null?void 0x0:_0x47c8eb['_redirectEventId'],_0x59e22d=await this['tryRedirectSignIn'](_0x580ea6);(!_0x558a55||_0x558a55===_0x543ba3)&&(_0x59e22d!=null&&_0x59e22d['user'])&&(_0x47c8eb=_0x59e22d['user'],_0x22140b=!0x0);}if(!_0x47c8eb)return this['directlySetCurrentUser'](null);if(!_0x47c8eb['_redirectEventId']){if(_0x22140b)try{await this['beforeStateQueue']['runMiddleware'](_0x47c8eb);}catch(_0x410196){_0x47c8eb=_0x1b9ec7,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x410196));}return _0x47c8eb?this['reloadAndSetCurrentUserOrClear'](_0x47c8eb):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x47c8eb['_redirectEventId']?this['directlySetCurrentUser'](_0x47c8eb):this['reloadAndSetCurrentUserOrClear'](_0x47c8eb);}async['tryRedirectSignIn'](_0x5391a9){let _0x58362d=null;try{_0x58362d=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5391a9,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x58362d;}async['reloadAndSetCurrentUserOrClear'](_0xb1d877){try{await bn(_0xb1d877);}catch(_0x2fe962){if((_0x2fe962==null?void 0x0:_0x2fe962['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0xb1d877);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x231aa4){if(H(this['app']))return Promise['reject'](se(this));const _0x3f861a=_0x231aa4?k(_0x231aa4):null;return _0x3f861a&&m(_0x3f861a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3f861a&&_0x3f861a['_clone'](this));}async['_updateCurrentUser'](_0x45eb01,_0x147cce=!0x1){if(!this['_deleted'])return _0x45eb01&&m(this['tenantId']===_0x45eb01['tenantId'],this,'tenant-id-mismatch'),_0x147cce||await this['beforeStateQueue']['runMiddleware'](_0x45eb01),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x45eb01),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x37350c){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x37350c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x52d608){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4d9d2c=this['_getPasswordPolicyInternal']();return _0x4d9d2c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4d9d2c['validatePassword'](_0x52d608);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xe972f=await Cf(this),_0x2b09fa=new Sf(_0xe972f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2b09fa:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2b09fa;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x12f7bf){this['_errorFactory']=new Ut('auth','Firebase',_0x12f7bf());}['onAuthStateChanged'](_0x4f0509,_0x1eb934,_0x441644){return this['registerStateListener'](this['authStateSubscription'],_0x4f0509,_0x1eb934,_0x441644);}['beforeAuthStateChanged'](_0x157c6c,_0x5792a0){return this['beforeStateQueue']['pushCallback'](_0x157c6c,_0x5792a0);}['onIdTokenChanged'](_0x1701c3,_0x3fcab5,_0x5549ad){return this['registerStateListener'](this['idTokenSubscription'],_0x1701c3,_0x3fcab5,_0x5549ad);}['authStateReady'](){return new Promise((_0x4f50bf,_0x4302f8)=>{if(this['currentUser'])_0x4f50bf();else{const _0x1958d0=this['onAuthStateChanged'](()=>{_0x1958d0(),_0x4f50bf();},_0x4302f8);}});}async['revokeAccessToken'](_0x299677){if(this['currentUser']){const _0x575ddf=await this['currentUser']['getIdToken'](),_0x4c0ff6={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x299677,'idToken':_0x575ddf};this['tenantId']!=null&&(_0x4c0ff6['tenantId']=this['tenantId']),await vf(this,_0x4c0ff6);}}['toJSON'](){var _0x38f315;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x38f315=this['_currentUser'])==null?void 0x0:_0x38f315['toJSON']()};}async['_setRedirectUser'](_0x45bc64,_0x46b6fc){const _0x2dbeac=await this['getOrInitRedirectPersistenceManager'](_0x46b6fc);return _0x45bc64===null?_0x2dbeac['removeCurrentUser']():_0x2dbeac['setCurrentUser'](_0x45bc64);}async['getOrInitRedirectPersistenceManager'](_0x323e7a){if(!this['redirectPersistenceManager']){const _0x186cd8=_0x323e7a&&ne(_0x323e7a)||this['_popupRedirectResolver'];m(_0x186cd8,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x186cd8['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1455f9){var _0x95b548,_0x41f44b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x95b548=this['_currentUser'])==null?void 0x0:_0x95b548['_redirectEventId'])===_0x1455f9?this['_currentUser']:((_0x41f44b=this['redirectUser'])==null?void 0x0:_0x41f44b['_redirectEventId'])===_0x1455f9?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x129df7){if(_0x129df7===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x129df7));}['_notifyListenersIfCurrent'](_0x1b4c0b){_0x1b4c0b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x47a2ac;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5324ea=((_0x47a2ac=this['currentUser'])==null?void 0x0:_0x47a2ac['uid'])??null;this['lastNotifiedUid']!==_0x5324ea&&(this['lastNotifiedUid']=_0x5324ea,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1faae1,_0x2465d0,_0x5ebc34,_0x113344){if(this['_deleted'])return()=>{};const _0x209492=typeof _0x2465d0=='function'?_0x2465d0:_0x2465d0['next']['bind'](_0x2465d0);let _0x4a562b=!0x1;const _0x561333=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x561333,this,'internal-error'),_0x561333['then'](()=>{_0x4a562b||_0x209492(this['currentUser']);}),typeof _0x2465d0=='function'){const _0x2fec78=_0x1faae1['addObserver'](_0x2465d0,_0x5ebc34,_0x113344);return()=>{_0x4a562b=!0x0,_0x2fec78();};}else{const _0x17efcb=_0x1faae1['addObserver'](_0x2465d0);return()=>{_0x4a562b=!0x0,_0x17efcb();};}}async['directlySetCurrentUser'](_0x4d6bd5){this['currentUser']&&this['currentUser']!==_0x4d6bd5&&this['_currentUser']['_stopProactiveRefresh'](),_0x4d6bd5&&this['isProactiveRefreshEnabled']&&_0x4d6bd5['_startProactiveRefresh'](),this['currentUser']=_0x4d6bd5,_0x4d6bd5?await this['assertedPersistence']['setCurrentUser'](_0x4d6bd5):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3bd92f){return this['operations']=this['operations']['then'](_0x3bd92f,_0x3bd92f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5ae50a){!_0x5ae50a||this['frameworks']['includes'](_0x5ae50a)||(this['frameworks']['push'](_0x5ae50a),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2f15d7;const _0x6490fc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x6490fc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x264fe0=await((_0x2f15d7=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2f15d7['getHeartbeatsHeader']());_0x264fe0&&(_0x6490fc['X-Firebase-Client']=_0x264fe0);const _0x79a7d2=await this['_getAppCheckToken']();return _0x79a7d2&&(_0x6490fc['X-Firebase-AppCheck']=_0x79a7d2),_0x6490fc;}async['_getAppCheckToken'](){var _0x26e8c6;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1efe9a=await((_0x26e8c6=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x26e8c6['getToken']());return _0x1efe9a!=null&&_0x1efe9a['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1efe9a['error']),_0x1efe9a==null?void 0x0:_0x1efe9a['token'];}}function qe(_0xf93aa5){return k(_0xf93aa5);}class Tr{constructor(_0x102010){this['auth']=_0x102010,this['observer']=null,this['addObserver']=Ic(_0x31c039=>this['observer']=_0x31c039);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xed6c4b){zn=_0xed6c4b;}function Da(_0x531b72){return zn['loadJS'](_0x531b72);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x51c79b){return'__'+_0x51c79b+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x11be2e){_0x11be2e();}['execute'](_0x5bb34b,_0xbba9d2){return Promise['resolve']('token');}['render'](_0x5b6595,_0x1bc448){return'';}}class Of{['ready'](_0x12c451){_0x12c451();}['execute'](_0x5f4fbb,_0x4ebba7){return Promise['resolve']('token');}['render'](_0x5919a5,_0x4d1def){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4a8f7a){this['type']=Df,this['auth']=qe(_0x4a8f7a);}async['verify'](_0x2ca285='verify',_0x1bc96a=!0x1){async function _0x4126eb(_0x37cfad){if(!_0x1bc96a){if(_0x37cfad['tenantId']==null&&_0x37cfad['_agentRecaptchaConfig']!=null)return _0x37cfad['_agentRecaptchaConfig']['siteKey'];if(_0x37cfad['tenantId']!=null&&_0x37cfad['_tenantRecaptchaConfigs'][_0x37cfad['tenantId']]!==void 0x0)return _0x37cfad['_tenantRecaptchaConfigs'][_0x37cfad['tenantId']]['siteKey'];}return new Promise(async(_0x9236bf,_0x558435)=>{uf(_0x37cfad,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xc6c094=>{if(_0xc6c094['recaptchaKey']===void 0x0)_0x558435(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x59c4a0=new hf(_0xc6c094);return _0x37cfad['tenantId']==null?_0x37cfad['_agentRecaptchaConfig']=_0x59c4a0:_0x37cfad['_tenantRecaptchaConfigs'][_0x37cfad['tenantId']]=_0x59c4a0,_0x9236bf(_0x59c4a0['siteKey']);}})['catch'](_0x2eb7b9=>{_0x558435(_0x2eb7b9);});});}function _0x5f3183(_0x5a8400,_0x5cec77,_0x3f3ae8){const _0x232758=window['grecaptcha'];vr(_0x232758)?_0x232758['enterprise']['ready'](()=>{_0x232758['enterprise']['execute'](_0x5a8400,{'action':_0x2ca285})['then'](_0xb85c6b=>{_0x5cec77(_0xb85c6b);})['catch'](()=>{_0x5cec77(Ma);});}):_0x3f3ae8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5e4f45,_0x2c37f2)=>{_0x4126eb(this['auth'])['then'](async _0x2a7dde=>{if(!_0x1bc96a&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5f3183(_0x2a7dde,_0x5e4f45,_0x2c37f2);else{if(typeof window>'u'){_0x2c37f2(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x576433=Af();_0x576433['length']!==0x0&&(_0x576433+=_0x2a7dde+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x167c30;(_0x167c30=le['scriptInjectionDeferred'])==null||_0x167c30['resolve']();},Da(_0x576433)['then'](()=>{var _0x340a9e;return(_0x340a9e=le['scriptInjectionDeferred'])==null?void 0x0:_0x340a9e['promise'];})['then'](()=>{_0x5f3183(_0x2a7dde,_0x5e4f45,_0x2c37f2);})['catch'](_0x5d882b=>{_0x2c37f2(_0x5d882b);});}})['catch'](_0xc70d13=>{_0x2c37f2(_0xc70d13);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1b778d,_0x20f7d0,_0x143a4d,_0x3e68f4=!0x1,_0x469185=!0x1){const _0x4f9388=new le(_0x1b778d);let _0xc19ddb;if(_0x469185)_0xc19ddb=Ma;else try{_0xc19ddb=await _0x4f9388['verify'](_0x143a4d);}catch{_0xc19ddb=await _0x4f9388['verify'](_0x143a4d,!0x0);}const _0x3c75ab={..._0x20f7d0};if(_0x143a4d==='mfaSmsEnrollment'||_0x143a4d==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3c75ab){const _0xd61ab4=_0x3c75ab['phoneEnrollmentInfo']['phoneNumber'],_0x17e254=_0x3c75ab['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3c75ab,{'phoneEnrollmentInfo':{'phoneNumber':_0xd61ab4,'recaptchaToken':_0x17e254,'captchaResponse':_0xc19ddb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3c75ab){const _0x706ccc=_0x3c75ab['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3c75ab,{'phoneSignInInfo':{'recaptchaToken':_0x706ccc,'captchaResponse':_0xc19ddb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3c75ab;}return _0x3e68f4?Object['assign'](_0x3c75ab,{'captchaResp':_0xc19ddb}):Object['assign'](_0x3c75ab,{'captchaResponse':_0xc19ddb}),Object['assign'](_0x3c75ab,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3c75ab,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3c75ab;}async function Oi(_0x4b5348,_0x3c4100,_0x145b08,_0x51a00a,_0x1c0386){var _0x2cf779;if((_0x2cf779=_0x4b5348['_getRecaptchaConfig']())!=null&&_0x2cf779['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1368de=await br(_0x4b5348,_0x3c4100,_0x145b08,_0x145b08==='getOobCode');return _0x51a00a(_0x4b5348,_0x1368de);}else return _0x51a00a(_0x4b5348,_0x3c4100)['catch'](async _0x185732=>{if(_0x185732['code']==='auth/missing-recaptcha-token'){console['log'](_0x145b08+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x7cba7d=await br(_0x4b5348,_0x3c4100,_0x145b08,_0x145b08==='getOobCode');return _0x51a00a(_0x4b5348,_0x7cba7d);}else return Promise['reject'](_0x185732);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x2b3a8c,_0x1d6f1d){const _0x553743=Ui(_0x2b3a8c,'auth');if(_0x553743['isInitialized']()){const _0x49ab74=_0x553743['getImmediate'](),_0xbe01ce=_0x553743['getOptions']();if(De(_0xbe01ce,_0x1d6f1d??{}))return _0x49ab74;K(_0x49ab74,'already-initialized');}return _0x553743['initialize']({'options':_0x1d6f1d});}function Lf(_0xf4c11f,_0x3677b6){const _0x456e03=(_0x3677b6==null?void 0x0:_0x3677b6['persistence'])||[],_0x22fe6c=(Array['isArray'](_0x456e03)?_0x456e03:[_0x456e03])['map'](ne);_0x3677b6!=null&&_0x3677b6['errorMap']&&_0xf4c11f['_updateErrorMap'](_0x3677b6['errorMap']),_0xf4c11f['_initializeWithPersistence'](_0x22fe6c,_0x3677b6==null?void 0x0:_0x3677b6['popupRedirectResolver']);}function xf(_0x5264e9,_0x5debc5,_0x16b958){const _0x313206=qe(_0x5264e9);m(/^https?:\/\//['test'](_0x5debc5),_0x313206,'invalid-emulator-scheme');const _0xa5150f=!0x1,_0x2234b7=La(_0x5debc5),{host:_0x4fae64,port:_0x522f2a}=Ff(_0x5debc5),_0x472213=_0x522f2a===null?'':':'+_0x522f2a,_0x201f07={'url':_0x2234b7+'//'+_0x4fae64+_0x472213+'/'},_0x187796=Object['freeze']({'host':_0x4fae64,'port':_0x522f2a,'protocol':_0x2234b7['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0xa5150f})});if(!_0x313206['_canInitEmulator']){m(_0x313206['config']['emulator']&&_0x313206['emulatorConfig'],_0x313206,'emulator-config-failed'),m(De(_0x201f07,_0x313206['config']['emulator'])&&De(_0x187796,_0x313206['emulatorConfig']),_0x313206,'emulator-config-failed');return;}_0x313206['config']['emulator']=_0x201f07,_0x313206['emulatorConfig']=_0x187796,_0x313206['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x4fae64)?jr(_0x2234b7+'//'+_0x4fae64+_0x472213):Uf();}function La(_0x53fa3d){const _0x1e8c94=_0x53fa3d['indexOf'](':');return _0x1e8c94<0x0?'':_0x53fa3d['substr'](0x0,_0x1e8c94+0x1);}function Ff(_0x2fc13b){const _0x35af20=La(_0x2fc13b),_0x40560a=/(\/\/)?([^?#/]+)/['exec'](_0x2fc13b['substr'](_0x35af20['length']));if(!_0x40560a)return{'host':'','port':null};const _0x24733e=_0x40560a[0x2]['split']('@')['pop']()||'',_0x60d8b5=/^(\[[^\]]+\])(:|$)/['exec'](_0x24733e);if(_0x60d8b5){const _0x30ee9c=_0x60d8b5[0x1];return{'host':_0x30ee9c,'port':Rr(_0x24733e['substr'](_0x30ee9c['length']+0x1))};}else{const [_0x2cdeac,_0x178d82]=_0x24733e['split'](':');return{'host':_0x2cdeac,'port':Rr(_0x178d82)};}}function Rr(_0x1928e7){if(!_0x1928e7)return null;const _0x204439=Number(_0x1928e7);return isNaN(_0x204439)?null:_0x204439;}function Uf(){function _0x11d631(){const _0x3055e7=document['createElement']('p'),_0x51b385=_0x3055e7['style'];_0x3055e7['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x51b385['position']='fixed',_0x51b385['width']='100%',_0x51b385['backgroundColor']='#ffffff',_0x51b385['border']='.1em\x20solid\x20#000000',_0x51b385['color']='#b50000',_0x51b385['bottom']='0px',_0x51b385['left']='0px',_0x51b385['margin']='0px',_0x51b385['zIndex']='10000',_0x51b385['textAlign']='center',_0x3055e7['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3055e7);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x11d631):_0x11d631());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x13fae0,_0x37b48a){this['providerId']=_0x13fae0,this['signInMethod']=_0x37b48a;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x1d2f55){return te('not\x20implemented');}['_linkToIdToken'](_0x3206d8,_0x4c51c2){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1dd961){return te('not\x20implemented');}}async function Wf(_0x4e7143,_0x344994){return Ae(_0x4e7143,'POST','/v1/accounts:signUp',_0x344994);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1cfe48,_0x5b129d){return Yt(_0x1cfe48,'POST','/v1/accounts:signInWithPassword',Re(_0x1cfe48,_0x5b129d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x312cb9,_0x256091){return Yt(_0x312cb9,'POST','/v1/accounts:signInWithEmailLink',Re(_0x312cb9,_0x256091));}async function Hf(_0x591f1b,_0x20418a){return Yt(_0x591f1b,'POST','/v1/accounts:signInWithEmailLink',Re(_0x591f1b,_0x20418a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x3e9fa7,_0x3597f4,_0x15ee3b,_0x561c16=null){super('password',_0x15ee3b),this['_email']=_0x3e9fa7,this['_password']=_0x3597f4,this['_tenantId']=_0x561c16;}static['_fromEmailAndPassword'](_0x198d24,_0x3613de){return new Ft(_0x198d24,_0x3613de,'password');}static['_fromEmailAndCode'](_0x32b6c7,_0x47fc76,_0x419055=null){return new Ft(_0x32b6c7,_0x47fc76,'emailLink',_0x419055);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2f0a46){const _0x4883b6=typeof _0x2f0a46=='string'?JSON['parse'](_0x2f0a46):_0x2f0a46;if(_0x4883b6!=null&&_0x4883b6['email']&&(_0x4883b6!=null&&_0x4883b6['password'])){if(_0x4883b6['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4883b6['email'],_0x4883b6['password']);if(_0x4883b6['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4883b6['email'],_0x4883b6['password'],_0x4883b6['tenantId']);}return null;}async['_getIdTokenResponse'](_0x28eae6){switch(this['signInMethod']){case'password':const _0x5685ba={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x28eae6,_0x5685ba,'signInWithPassword',Bf);case'emailLink':return Vf(_0x28eae6,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x28eae6,'internal-error');}}async['_linkToIdToken'](_0x1c81fa,_0x2b2ad3){switch(this['signInMethod']){case'password':const _0x19b5f1={'idToken':_0x2b2ad3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1c81fa,_0x19b5f1,'signUpPassword',Wf);case'emailLink':return Hf(_0x1c81fa,{'idToken':_0x2b2ad3,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1c81fa,'internal-error');}}['_getReauthenticationResolver'](_0x4ee992){return this['_getIdTokenResponse'](_0x4ee992);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x233057,_0x1f1133){return Yt(_0x233057,'POST','/v1/accounts:signInWithIdp',Re(_0x233057,_0x1f1133));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x13924d){const _0x408d32=new We(_0x13924d['providerId'],_0x13924d['signInMethod']);return _0x13924d['idToken']||_0x13924d['accessToken']?(_0x13924d['idToken']&&(_0x408d32['idToken']=_0x13924d['idToken']),_0x13924d['accessToken']&&(_0x408d32['accessToken']=_0x13924d['accessToken']),_0x13924d['nonce']&&!_0x13924d['pendingToken']&&(_0x408d32['nonce']=_0x13924d['nonce']),_0x13924d['pendingToken']&&(_0x408d32['pendingToken']=_0x13924d['pendingToken'])):_0x13924d['oauthToken']&&_0x13924d['oauthTokenSecret']?(_0x408d32['accessToken']=_0x13924d['oauthToken'],_0x408d32['secret']=_0x13924d['oauthTokenSecret']):K('argument-error'),_0x408d32;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1e1cca){const _0x18a6f4=typeof _0x1e1cca=='string'?JSON['parse'](_0x1e1cca):_0x1e1cca,{providerId:_0x53e62f,signInMethod:_0x16c543,..._0x5d5847}=_0x18a6f4;if(!_0x53e62f||!_0x16c543)return null;const _0x293d1b=new We(_0x53e62f,_0x16c543);return _0x293d1b['idToken']=_0x5d5847['idToken']||void 0x0,_0x293d1b['accessToken']=_0x5d5847['accessToken']||void 0x0,_0x293d1b['secret']=_0x5d5847['secret'],_0x293d1b['nonce']=_0x5d5847['nonce'],_0x293d1b['pendingToken']=_0x5d5847['pendingToken']||null,_0x293d1b;}['_getIdTokenResponse'](_0x51965e){const _0x3e48c7=this['buildRequest']();return Ze(_0x51965e,_0x3e48c7);}['_linkToIdToken'](_0x598eb8,_0x318d8b){const _0x2d92c5=this['buildRequest']();return _0x2d92c5['idToken']=_0x318d8b,Ze(_0x598eb8,_0x2d92c5);}['_getReauthenticationResolver'](_0x5ea14e){const _0x2a7637=this['buildRequest']();return _0x2a7637['autoCreate']=!0x1,Ze(_0x5ea14e,_0x2a7637);}['buildRequest'](){const _0x4973d6={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4973d6['pendingToken']=this['pendingToken'];else{const _0x508fd1={};this['idToken']&&(_0x508fd1['id_token']=this['idToken']),this['accessToken']&&(_0x508fd1['access_token']=this['accessToken']),this['secret']&&(_0x508fd1['oauth_token_secret']=this['secret']),_0x508fd1['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x508fd1['nonce']=this['nonce']),_0x4973d6['postBody']=at(_0x508fd1);}return _0x4973d6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x15c118){switch(_0x15c118){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2a1ad2){const _0x3cf72a=yt(vt(_0x2a1ad2))['link'],_0x1c6267=_0x3cf72a?yt(vt(_0x3cf72a))['deep_link_id']:null,_0x20fcfe=yt(vt(_0x2a1ad2))['deep_link_id'];return(_0x20fcfe?yt(vt(_0x20fcfe))['link']:null)||_0x20fcfe||_0x1c6267||_0x3cf72a||_0x2a1ad2;}class Ss{constructor(_0x40b516){const _0x218bb0=yt(vt(_0x40b516)),_0x1568fd=_0x218bb0['apiKey']??null,_0x7a3f66=_0x218bb0['oobCode']??null,_0xb406e1=Gf(_0x218bb0['mode']??null);m(_0x1568fd&&_0x7a3f66&&_0xb406e1,'argument-error'),this['apiKey']=_0x1568fd,this['operation']=_0xb406e1,this['code']=_0x7a3f66,this['continueUrl']=_0x218bb0['continueUrl']??null,this['languageCode']=_0x218bb0['lang']??null,this['tenantId']=_0x218bb0['tenantId']??null;}static['parseLink'](_0x2960d0){const _0x48c63a=qf(_0x2960d0);try{return new Ss(_0x48c63a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2c465f,_0x2128cc){return Ft['_fromEmailAndPassword'](_0x2c465f,_0x2128cc);}static['credentialWithLink'](_0x2d353b,_0x18d216){const _0x1eaae0=Ss['parseLink'](_0x18d216);return m(_0x1eaae0,'argument-error'),Ft['_fromEmailAndCode'](_0x2d353b,_0x1eaae0['code'],_0x1eaae0['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3e8b24){this['providerId']=_0x3e8b24,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x527aaf){this['defaultLanguageCode']=_0x527aaf;}['setCustomParameters'](_0x462fc0){return this['customParameters']=_0x462fc0,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x8b8588){return this['scopes']['includes'](_0x8b8588)||this['scopes']['push'](_0x8b8588),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x460c10){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x460c10});}static['credentialFromResult'](_0x4404ac){return he['credentialFromTaggedObject'](_0x4404ac);}static['credentialFromError'](_0x53932e){return he['credentialFromTaggedObject'](_0x53932e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x375ec4}){if(!_0x375ec4||!('oauthAccessToken'in _0x375ec4)||!_0x375ec4['oauthAccessToken'])return null;try{return he['credential'](_0x375ec4['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xd12c66,_0x3ea591){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xd12c66,'accessToken':_0x3ea591});}static['credentialFromResult'](_0x535384){return ue['credentialFromTaggedObject'](_0x535384);}static['credentialFromError'](_0x13403f){return ue['credentialFromTaggedObject'](_0x13403f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22b2e2}){if(!_0x22b2e2)return null;const {oauthIdToken:_0x1f4df6,oauthAccessToken:_0x5559be}=_0x22b2e2;if(!_0x1f4df6&&!_0x5559be)return null;try{return ue['credential'](_0x1f4df6,_0x5559be);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3cb31f){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3cb31f});}static['credentialFromResult'](_0x526fa0){return de['credentialFromTaggedObject'](_0x526fa0);}static['credentialFromError'](_0x5bfa1d){return de['credentialFromTaggedObject'](_0x5bfa1d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x526259}){if(!_0x526259||!('oauthAccessToken'in _0x526259)||!_0x526259['oauthAccessToken'])return null;try{return de['credential'](_0x526259['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x63e29c,_0x5f0419){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x63e29c,'oauthTokenSecret':_0x5f0419});}static['credentialFromResult'](_0x4d2a7e){return fe['credentialFromTaggedObject'](_0x4d2a7e);}static['credentialFromError'](_0x4bc102){return fe['credentialFromTaggedObject'](_0x4bc102['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x48f2dc}){if(!_0x48f2dc)return null;const {oauthAccessToken:_0x138a2f,oauthTokenSecret:_0x1a1e4f}=_0x48f2dc;if(!_0x138a2f||!_0x1a1e4f)return null;try{return fe['credential'](_0x138a2f,_0x1a1e4f);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3f881f,_0x100adf){return Yt(_0x3f881f,'POST','/v1/accounts:signUp',Re(_0x3f881f,_0x100adf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4ab6f2){this['user']=_0x4ab6f2['user'],this['providerId']=_0x4ab6f2['providerId'],this['_tokenResponse']=_0x4ab6f2['_tokenResponse'],this['operationType']=_0x4ab6f2['operationType'];}static async['_fromIdTokenResponse'](_0x78beac,_0x2e5d96,_0x158c85,_0x2682ce=!0x1){const _0x54ad4f=await z['_fromIdTokenResponse'](_0x78beac,_0x158c85,_0x2682ce),_0x4e9d0e=Ar(_0x158c85);return new Be({'user':_0x54ad4f,'providerId':_0x4e9d0e,'_tokenResponse':_0x158c85,'operationType':_0x2e5d96});}static async['_forOperation'](_0xf7c187,_0x22152f,_0x5ca83b){await _0xf7c187['_updateTokensIfNecessary'](_0x5ca83b,!0x0);const _0x2a1705=Ar(_0x5ca83b);return new Be({'user':_0xf7c187,'providerId':_0x2a1705,'_tokenResponse':_0x5ca83b,'operationType':_0x22152f});}}function Ar(_0xcb0daf){return _0xcb0daf['providerId']?_0xcb0daf['providerId']:'phoneNumber'in _0xcb0daf?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x21c957,_0x5d465d,_0x1567e0,_0x4b91f9){super(_0x5d465d['code'],_0x5d465d['message']),this['operationType']=_0x1567e0,this['user']=_0x4b91f9,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x21c957['name'],'tenantId':_0x21c957['tenantId']??void 0x0,'_serverResponse':_0x5d465d['customData']['_serverResponse'],'operationType':_0x1567e0};}static['_fromErrorAndOperation'](_0x398e35,_0x7c0760,_0x5ae614,_0xe80bc6){return new Rn(_0x398e35,_0x7c0760,_0x5ae614,_0xe80bc6);}}function Fa(_0x41ffe3,_0x1d8a0b,_0x499b55,_0x12a415){return(_0x1d8a0b==='reauthenticate'?_0x499b55['_getReauthenticationResolver'](_0x41ffe3):_0x499b55['_getIdTokenResponse'](_0x41ffe3))['catch'](_0x23b7ee=>{throw _0x23b7ee['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x41ffe3,_0x23b7ee,_0x1d8a0b,_0x12a415):_0x23b7ee;});}async function jf(_0x2f8dec,_0xa4b788,_0x5bf642=!0x1){const _0x2722bb=await xt(_0x2f8dec,_0xa4b788['_linkToIdToken'](_0x2f8dec['auth'],await _0x2f8dec['getIdToken']()),_0x5bf642);return Be['_forOperation'](_0x2f8dec,'link',_0x2722bb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xae4047,_0x1b6264,_0xd4508=!0x1){const {auth:_0x27c646}=_0xae4047;if(H(_0x27c646['app']))return Promise['reject'](se(_0x27c646));const _0x5c3b5e='reauthenticate';try{const _0x5dbdaa=await xt(_0xae4047,Fa(_0x27c646,_0x5c3b5e,_0x1b6264,_0xae4047),_0xd4508);m(_0x5dbdaa['idToken'],_0x27c646,'internal-error');const _0xadaa93=ws(_0x5dbdaa['idToken']);m(_0xadaa93,_0x27c646,'internal-error');const {sub:_0x1904e9}=_0xadaa93;return m(_0xae4047['uid']===_0x1904e9,_0x27c646,'user-mismatch'),Be['_forOperation'](_0xae4047,_0x5c3b5e,_0x5dbdaa);}catch(_0x52a352){throw(_0x52a352==null?void 0x0:_0x52a352['code'])==='auth/user-not-found'&&K(_0x27c646,'user-mismatch'),_0x52a352;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0xed226b,_0x2206f7,_0x25b046=!0x1){if(H(_0xed226b['app']))return Promise['reject'](se(_0xed226b));const _0x121dc7='signIn',_0x55c259=await Fa(_0xed226b,_0x121dc7,_0x2206f7),_0x489974=await Be['_fromIdTokenResponse'](_0xed226b,_0x121dc7,_0x55c259);return _0x25b046||await _0xed226b['_updateCurrentUser'](_0x489974['user']),_0x489974;}async function Yf(_0x5e0fa8,_0x2e4deb){return Ua(qe(_0x5e0fa8),_0x2e4deb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x286ef5){const _0x3e94c5=qe(_0x286ef5);_0x3e94c5['_getPasswordPolicyInternal']()&&await _0x3e94c5['_updatePasswordPolicy']();}async function R_(_0x4fd747,_0x371c3a,_0x18aa3d){if(H(_0x4fd747['app']))return Promise['reject'](se(_0x4fd747));const _0x1e4730=qe(_0x4fd747),_0x2c2308=await Oi(_0x1e4730,{'returnSecureToken':!0x0,'email':_0x371c3a,'password':_0x18aa3d,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x23c3c2=>{throw _0x23c3c2['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4fd747),_0x23c3c2;}),_0x44bac6=await Be['_fromIdTokenResponse'](_0x1e4730,'signIn',_0x2c2308);return await _0x1e4730['_updateCurrentUser'](_0x44bac6['user']),_0x44bac6;}function A_(_0x5f00c9,_0x17afb5,_0x4e1fc6){return H(_0x5f00c9['app'])?Promise['reject'](se(_0x5f00c9)):Yf(k(_0x5f00c9),ft['credential'](_0x17afb5,_0x4e1fc6))['catch'](async _0x50bd7c=>{throw _0x50bd7c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5f00c9),_0x50bd7c;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x48a170,_0x5090d6){return k(_0x48a170)['setPersistence'](_0x5090d6);}function Qf(_0x392f1f,_0xd26ce5,_0x5e4b0a,_0x4f60a7){return k(_0x392f1f)['onIdTokenChanged'](_0xd26ce5,_0x5e4b0a,_0x4f60a7);}function Jf(_0x542475,_0x442e83,_0x11ffc4){return k(_0x542475)['beforeAuthStateChanged'](_0x442e83,_0x11ffc4);}function N_(_0x4c8165,_0x2e092c,_0x434dea,_0x2600a2){return k(_0x4c8165)['onAuthStateChanged'](_0x2e092c,_0x434dea,_0x2600a2);}function P_(_0x27ebd5){return k(_0x27ebd5)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5bdcda,_0x4ea839){this['storageRetriever']=_0x5bdcda,this['type']=_0x4ea839;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x126c56,_0x13fa14){return this['storage']['setItem'](_0x126c56,JSON['stringify'](_0x13fa14)),Promise['resolve']();}['_get'](_0x2c9de4){const _0x1bd377=this['storage']['getItem'](_0x2c9de4);return Promise['resolve'](_0x1bd377?JSON['parse'](_0x1bd377):null);}['_remove'](_0x57c3b5){return this['storage']['removeItem'](_0x57c3b5),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3d60c4,_0x1b5add)=>this['onStorageEvent'](_0x3d60c4,_0x1b5add),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5147c5){for(const _0x254ea9 of Object['keys'](this['listeners'])){const _0x3a1f7f=this['storage']['getItem'](_0x254ea9),_0x3fe8bf=this['localCache'][_0x254ea9];_0x3a1f7f!==_0x3fe8bf&&_0x5147c5(_0x254ea9,_0x3fe8bf,_0x3a1f7f);}}['onStorageEvent'](_0x4bb199,_0x142b47=!0x1){if(!_0x4bb199['key']){this['forAllChangedKeys']((_0x27705a,_0x2ddbc9,_0x1c0122)=>{this['notifyListeners'](_0x27705a,_0x1c0122);});return;}const _0x260abd=_0x4bb199['key'];_0x142b47?this['detachListener']():this['stopPolling']();const _0x78e40=()=>{const _0xb48ea6=this['storage']['getItem'](_0x260abd);!_0x142b47&&this['localCache'][_0x260abd]===_0xb48ea6||this['notifyListeners'](_0x260abd,_0xb48ea6);},_0x12962f=this['storage']['getItem'](_0x260abd);If()&&_0x12962f!==_0x4bb199['newValue']&&_0x4bb199['newValue']!==_0x4bb199['oldValue']?setTimeout(_0x78e40,Zf):_0x78e40();}['notifyListeners'](_0x1f743c,_0x8b5266){this['localCache'][_0x1f743c]=_0x8b5266;const _0x5e391e=this['listeners'][_0x1f743c];if(_0x5e391e){for(const _0x183f3a of Array['from'](_0x5e391e))_0x183f3a(_0x8b5266&&JSON['parse'](_0x8b5266));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xe17bf6,_0x284344,_0x521d61)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xe17bf6,'oldValue':_0x284344,'newValue':_0x521d61}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x52db31,_0x1dc33a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x52db31]||(this['listeners'][_0x52db31]=new Set(),this['localCache'][_0x52db31]=this['storage']['getItem'](_0x52db31)),this['listeners'][_0x52db31]['add'](_0x1dc33a);}['_removeListener'](_0x2d7819,_0x293a79){this['listeners'][_0x2d7819]&&(this['listeners'][_0x2d7819]['delete'](_0x293a79),this['listeners'][_0x2d7819]['size']===0x0&&delete this['listeners'][_0x2d7819]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x244415,_0xcf1f09){await super['_set'](_0x244415,_0xcf1f09),this['localCache'][_0x244415]=JSON['stringify'](_0xcf1f09);}async['_get'](_0x2bb476){const _0x1a91af=await super['_get'](_0x2bb476);return this['localCache'][_0x2bb476]=JSON['stringify'](_0x1a91af),_0x1a91af;}async['_remove'](_0x4f8433){await super['_remove'](_0x4f8433),delete this['localCache'][_0x4f8433];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4437b7,_0x39bab0){}['_removeListener'](_0x2bc5ce,_0x1ea35){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1fd73c){return Promise['all'](_0x1fd73c['map'](async _0x36125b=>{try{return{'fulfilled':!0x0,'value':await _0x36125b};}catch(_0x3112de){return{'fulfilled':!0x1,'reason':_0x3112de};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x22e9be){this['eventTarget']=_0x22e9be,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5d3457){const _0x59cf97=this['receivers']['find'](_0x4c037a=>_0x4c037a['isListeningto'](_0x5d3457));if(_0x59cf97)return _0x59cf97;const _0x2a2dab=new jn(_0x5d3457);return this['receivers']['push'](_0x2a2dab),_0x2a2dab;}['isListeningto'](_0x5a5de4){return this['eventTarget']===_0x5a5de4;}async['handleEvent'](_0x1e62e5){const _0x152d8b=_0x1e62e5,{eventId:_0x4fdda6,eventType:_0x116772,data:_0xf8acb3}=_0x152d8b['data'],_0x362a83=this['handlersMap'][_0x116772];if(!(_0x362a83!=null&&_0x362a83['size']))return;_0x152d8b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4fdda6,'eventType':_0x116772});const _0xd376c0=Array['from'](_0x362a83)['map'](async _0x4fa00b=>_0x4fa00b(_0x152d8b['origin'],_0xf8acb3)),_0x561f4d=await tp(_0xd376c0);_0x152d8b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4fdda6,'eventType':_0x116772,'response':_0x561f4d});}['_subscribe'](_0x455911,_0x4bf683){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x455911]||(this['handlersMap'][_0x455911]=new Set()),this['handlersMap'][_0x455911]['add'](_0x4bf683);}['_unsubscribe'](_0x4115ff,_0x48719b){this['handlersMap'][_0x4115ff]&&_0x48719b&&this['handlersMap'][_0x4115ff]['delete'](_0x48719b),(!_0x48719b||this['handlersMap'][_0x4115ff]['size']===0x0)&&delete this['handlersMap'][_0x4115ff],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4ef1a9='',_0xb655e7=0xa){let _0xd79f52='';for(let _0xb8a520=0x0;_0xb8a520<_0xb655e7;_0xb8a520++)_0xd79f52+=Math['floor'](Math['random']()*0xa);return _0x4ef1a9+_0xd79f52;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x4863ba){this['target']=_0x4863ba,this['handlers']=new Set();}['removeMessageHandler'](_0x45eb85){_0x45eb85['messageChannel']&&(_0x45eb85['messageChannel']['port1']['removeEventListener']('message',_0x45eb85['onMessage']),_0x45eb85['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x45eb85);}async['_send'](_0x20fd1a,_0x3b77ce,_0x20b3f6=0x32){const _0x3106db=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3106db)throw new Error('connection_unavailable');let _0x56f148,_0x3c35fd;return new Promise((_0x4cbd03,_0x5b40cf)=>{const _0x2a9ea2=bs('',0x14);_0x3106db['port1']['start']();const _0xb092f2=setTimeout(()=>{_0x5b40cf(new Error('unsupported_event'));},_0x20b3f6);_0x3c35fd={'messageChannel':_0x3106db,'onMessage'(_0x1d7b78){const _0x4926f0=_0x1d7b78;if(_0x4926f0['data']['eventId']===_0x2a9ea2)switch(_0x4926f0['data']['status']){case'ack':clearTimeout(_0xb092f2),_0x56f148=setTimeout(()=>{_0x5b40cf(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x56f148),_0x4cbd03(_0x4926f0['data']['response']);break;default:clearTimeout(_0xb092f2),clearTimeout(_0x56f148),_0x5b40cf(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3c35fd),_0x3106db['port1']['addEventListener']('message',_0x3c35fd['onMessage']),this['target']['postMessage']({'eventType':_0x20fd1a,'eventId':_0x2a9ea2,'data':_0x3b77ce},[_0x3106db['port2']]);})['finally'](()=>{_0x3c35fd&&this['removeMessageHandler'](_0x3c35fd);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x51bafe){X()['location']['href']=_0x51bafe;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x30a059;return((_0x30a059=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x30a059['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x260b40){this['request']=_0x260b40;}['toPromise'](){return new Promise((_0x4c31cd,_0x4bef6c)=>{this['request']['addEventListener']('success',()=>{_0x4c31cd(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4bef6c(this['request']['error']);});});}}function Kn(_0x1ebf10,_0x492ca9){return _0x1ebf10['transaction']([kn],_0x492ca9?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x557e95=indexedDB['deleteDatabase'](qa);return new Jt(_0x557e95)['toPromise']();}function ja(){const _0x58d002=indexedDB['open'](qa,ap);return new Promise((_0x3b9c21,_0x5e00b4)=>{_0x58d002['addEventListener']('error',()=>{_0x5e00b4(_0x58d002['error']);}),_0x58d002['addEventListener']('upgradeneeded',()=>{const _0x4d604b=_0x58d002['result'];try{_0x4d604b['createObjectStore'](kn,{'keyPath':za});}catch(_0xd9623d){_0x5e00b4(_0xd9623d);}}),_0x58d002['addEventListener']('success',async()=>{const _0xc3bace=_0x58d002['result'];_0xc3bace['objectStoreNames']['contains'](kn)?_0x3b9c21(_0xc3bace):(_0xc3bace['close'](),await cp(),_0x3b9c21(await ja()));});});}async function kr(_0x5a4b6a,_0x4923cb,_0x31954b){const _0x3713eb=Kn(_0x5a4b6a,!0x0)['put']({[za]:_0x4923cb,'value':_0x31954b});return new Jt(_0x3713eb)['toPromise']();}async function lp(_0x50136d,_0x41d5da){const _0x58e57e=Kn(_0x50136d,!0x1)['get'](_0x41d5da),_0x1728d6=await new Jt(_0x58e57e)['toPromise']();return _0x1728d6===void 0x0?null:_0x1728d6['value'];}function Nr(_0xff9a22,_0x523eac){const _0x1dabfa=Kn(_0xff9a22,!0x0)['delete'](_0x523eac);return new Jt(_0x1dabfa)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x4cd1b0){let _0x539c22=0x0;for(;;)try{const _0x3054d8=await this['_openDb']();return await _0x4cd1b0(_0x3054d8);}catch(_0x5f0a52){if(_0x539c22++>up)throw _0x5f0a52;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0xc15346,_0x827c64)=>({'keyProcessed':(await this['_poll']())['includes'](_0x827c64['key'])})),this['receiver']['_subscribe']('ping',async(_0x3304f4,_0x5d2c40)=>['keyChanged']);}async['initializeSender'](){var _0x3aade5,_0x5c370e;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x13c4fe=await this['sender']['_send']('ping',{},0x320);_0x13c4fe&&(_0x3aade5=_0x13c4fe[0x0])!=null&&_0x3aade5['fulfilled']&&(_0x5c370e=_0x13c4fe[0x0])!=null&&_0x5c370e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x11b2ba){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x11b2ba},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x36abda=>{await kr(_0x36abda,An,'1'),await Nr(_0x36abda,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x573914){this['pendingWrites']++;try{await _0x573914();}finally{this['pendingWrites']--;}}async['_set'](_0x3fc4f6,_0xf0a23c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x32366b=>kr(_0x32366b,_0x3fc4f6,_0xf0a23c)),this['localCache'][_0x3fc4f6]=_0xf0a23c,this['notifyServiceWorker'](_0x3fc4f6)));}async['_get'](_0x379453){const _0x2ebf93=await this['_withRetries'](_0x212bb6=>lp(_0x212bb6,_0x379453));return this['localCache'][_0x379453]=_0x2ebf93,_0x2ebf93;}async['_remove'](_0x21fd9d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5614cd=>Nr(_0x5614cd,_0x21fd9d)),delete this['localCache'][_0x21fd9d],this['notifyServiceWorker'](_0x21fd9d)));}async['_poll'](){const _0x41987f=await this['_withRetries'](_0x15ed87=>{const _0x25ed6d=Kn(_0x15ed87,!0x1)['getAll']();return new Jt(_0x25ed6d)['toPromise']();});if(!_0x41987f)return[];if(this['pendingWrites']!==0x0)return[];const _0x4e1f39=[],_0x38dbd1=new Set();if(_0x41987f['length']!==0x0){for(const {fbase_key:_0x43d60d,value:_0x25a08b}of _0x41987f)_0x38dbd1['add'](_0x43d60d),JSON['stringify'](this['localCache'][_0x43d60d])!==JSON['stringify'](_0x25a08b)&&(this['notifyListeners'](_0x43d60d,_0x25a08b),_0x4e1f39['push'](_0x43d60d));}for(const _0x1873de of Object['keys'](this['localCache']))this['localCache'][_0x1873de]&&!_0x38dbd1['has'](_0x1873de)&&(this['notifyListeners'](_0x1873de,null),_0x4e1f39['push'](_0x1873de));return _0x4e1f39;}['notifyListeners'](_0x4490dc,_0x8444bf){this['localCache'][_0x4490dc]=_0x8444bf;const _0x3f8f27=this['listeners'][_0x4490dc];if(_0x3f8f27){for(const _0x478a2f of Array['from'](_0x3f8f27))_0x478a2f(_0x8444bf);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x490a75,_0x3d3ed2){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x490a75]||(this['listeners'][_0x490a75]=new Set(),this['_get'](_0x490a75)),this['listeners'][_0x490a75]['add'](_0x3d3ed2);}['_removeListener'](_0x2382c,_0x47d00a){this['listeners'][_0x2382c]&&(this['listeners'][_0x2382c]['delete'](_0x47d00a),this['listeners'][_0x2382c]['size']===0x0&&delete this['listeners'][_0x2382c]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x2d8b1a,_0x160f6a){return _0x160f6a?ne(_0x160f6a):(m(_0x2d8b1a['_popupRedirectResolver'],_0x2d8b1a,'argument-error'),_0x2d8b1a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x80c20c){super('custom','custom'),this['params']=_0x80c20c;}['_getIdTokenResponse'](_0x36fc32){return Ze(_0x36fc32,this['_buildIdpRequest']());}['_linkToIdToken'](_0x40f0a2,_0x40364e){return Ze(_0x40f0a2,this['_buildIdpRequest'](_0x40364e));}['_getReauthenticationResolver'](_0x44a25c){return Ze(_0x44a25c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xfac36b){const _0x43b00f={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xfac36b&&(_0x43b00f['idToken']=_0xfac36b),_0x43b00f;}}function pp(_0x32ede5){return Ua(_0x32ede5['auth'],new Rs(_0x32ede5),_0x32ede5['bypassAuthState']);}function _p(_0x3f0170){const {auth:_0x1754d0,user:_0x4a2364}=_0x3f0170;return m(_0x4a2364,_0x1754d0,'internal-error'),Kf(_0x4a2364,new Rs(_0x3f0170),_0x3f0170['bypassAuthState']);}async function gp(_0x46dd50){const {auth:_0x4f0908,user:_0x3c1082}=_0x46dd50;return m(_0x3c1082,_0x4f0908,'internal-error'),jf(_0x3c1082,new Rs(_0x46dd50),_0x46dd50['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x4e0e12,_0x4e2b72,_0x5f3deb,_0x38015e,_0x5feb3f=!0x1){this['auth']=_0x4e0e12,this['resolver']=_0x5f3deb,this['user']=_0x38015e,this['bypassAuthState']=_0x5feb3f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4e2b72)?_0x4e2b72:[_0x4e2b72];}['execute'](){return new Promise(async(_0x301919,_0x4ddfd1)=>{this['pendingPromise']={'resolve':_0x301919,'reject':_0x4ddfd1};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xb13f00){this['reject'](_0xb13f00);}});}async['onAuthEvent'](_0x5405b2){const {urlResponse:_0x42a3d0,sessionId:_0x315529,postBody:_0x5beefb,tenantId:_0x493921,error:_0x175c3b,type:_0x1d34dd}=_0x5405b2;if(_0x175c3b){this['reject'](_0x175c3b);return;}const _0x308909={'auth':this['auth'],'requestUri':_0x42a3d0,'sessionId':_0x315529,'tenantId':_0x493921||void 0x0,'postBody':_0x5beefb||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1d34dd)(_0x308909));}catch(_0x3281bb){this['reject'](_0x3281bb);}}['onError'](_0x1900fe){this['reject'](_0x1900fe);}['getIdpTask'](_0x3013a7){switch(_0x3013a7){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x4fc052){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4fc052),this['unregisterAndCleanUp']();}['reject'](_0x1dbc89){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1dbc89),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3f8f7d,_0x2e57ad,_0x5486fd,_0x3d76d4,_0x4e47c0){super(_0x3f8f7d,_0x2e57ad,_0x3d76d4,_0x4e47c0),this['provider']=_0x5486fd,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x4f1e1a=await this['execute']();return m(_0x4f1e1a,this['auth'],'internal-error'),_0x4f1e1a;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4b779c=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4b779c),this['authWindow']['associatedEvent']=_0x4b779c,this['resolver']['_originValidation'](this['auth'])['catch'](_0x5e0797=>{this['reject'](_0x5e0797);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x37c89c=>{_0x37c89c||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4909b3;return((_0x4909b3=this['authWindow'])==null?void 0x0:_0x4909b3['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3e1746=()=>{var _0x46d0c,_0x2ded5c;if((_0x2ded5c=(_0x46d0c=this['authWindow'])==null?void 0x0:_0x46d0c['window'])!=null&&_0x2ded5c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3e1746,mp['get']());};_0x3e1746();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x536ee7,_0x3e5ffa,_0x568b1c=!0x1){super(_0x536ee7,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3e5ffa,void 0x0,_0x568b1c),this['eventId']=null;}async['execute'](){let _0x5201e2=rn['get'](this['auth']['_key']());if(!_0x5201e2){try{const _0xc44e04=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5201e2=()=>Promise['resolve'](_0xc44e04);}catch(_0x435a7f){_0x5201e2=()=>Promise['reject'](_0x435a7f);}rn['set'](this['auth']['_key'](),_0x5201e2);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5201e2();}async['onAuthEvent'](_0x14494a){if(_0x14494a['type']==='signInViaRedirect')return super['onAuthEvent'](_0x14494a);if(_0x14494a['type']==='unknown'){this['resolve'](null);return;}if(_0x14494a['eventId']){const _0x4b8043=await this['auth']['_redirectUserForId'](_0x14494a['eventId']);if(_0x4b8043)return this['user']=_0x4b8043,super['onAuthEvent'](_0x14494a);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x32b7ea,_0x267555){const _0x34bc0b=Cp(_0x267555),_0x2a39cb=wp(_0x32b7ea);if(!await _0x2a39cb['_isAvailable']())return!0x1;const _0x24416c=await _0x2a39cb['_get'](_0x34bc0b)==='true';return await _0x2a39cb['_remove'](_0x34bc0b),_0x24416c;}function Ip(_0x47cda4,_0x1d0e35){rn['set'](_0x47cda4['_key'](),_0x1d0e35);}function wp(_0x5b34c0){return ne(_0x5b34c0['_redirectPersistence']);}function Cp(_0x2fcb63){return sn(yp,_0x2fcb63['config']['apiKey'],_0x2fcb63['name']);}async function Tp(_0x322a30,_0x3437c2,_0x7bb9a0=!0x1){if(H(_0x322a30['app']))return Promise['reject'](se(_0x322a30));const _0x266b28=qe(_0x322a30),_0x143083=fp(_0x266b28,_0x3437c2),_0x3baed0=await new vp(_0x266b28,_0x143083,_0x7bb9a0)['execute']();return _0x3baed0&&!_0x7bb9a0&&(delete _0x3baed0['user']['_redirectEventId'],await _0x266b28['_persistUserIfCurrent'](_0x3baed0['user']),await _0x266b28['_setRedirectUser'](null,_0x3437c2)),_0x3baed0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x21bf2b){this['auth']=_0x21bf2b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1005c2){this['consumers']['add'](_0x1005c2),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1005c2)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1005c2),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5ce172){this['consumers']['delete'](_0x5ce172);}['onEvent'](_0x585c5f){if(this['hasEventBeenHandled'](_0x585c5f))return!0x1;let _0x459532=!0x1;return this['consumers']['forEach'](_0xf4ed4e=>{this['isEventForConsumer'](_0x585c5f,_0xf4ed4e)&&(_0x459532=!0x0,this['sendToConsumer'](_0x585c5f,_0xf4ed4e),this['saveEventToCache'](_0x585c5f));}),this['hasHandledPotentialRedirect']||!Rp(_0x585c5f)||(this['hasHandledPotentialRedirect']=!0x0,_0x459532||(this['queuedRedirectEvent']=_0x585c5f,_0x459532=!0x0)),_0x459532;}['sendToConsumer'](_0x48bee1,_0x13fca6){var _0x2266d5;if(_0x48bee1['error']&&!Qa(_0x48bee1)){const _0x433e5a=((_0x2266d5=_0x48bee1['error']['code'])==null?void 0x0:_0x2266d5['split']('auth/')[0x1])||'internal-error';_0x13fca6['onError'](J(this['auth'],_0x433e5a));}else _0x13fca6['onAuthEvent'](_0x48bee1);}['isEventForConsumer'](_0x4b69fe,_0x248346){const _0x279868=_0x248346['eventId']===null||!!_0x4b69fe['eventId']&&_0x4b69fe['eventId']===_0x248346['eventId'];return _0x248346['filter']['includes'](_0x4b69fe['type'])&&_0x279868;}['hasEventBeenHandled'](_0x46cca8){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x46cca8));}['saveEventToCache'](_0x50cd57){this['cachedEventUids']['add'](Pr(_0x50cd57)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x4d975e){return[_0x4d975e['type'],_0x4d975e['eventId'],_0x4d975e['sessionId'],_0x4d975e['tenantId']]['filter'](_0x1088c0=>_0x1088c0)['join']('-');}function Qa({type:_0x4df71a,error:_0x2c944a}){return _0x4df71a==='unknown'&&(_0x2c944a==null?void 0x0:_0x2c944a['code'])==='auth/no-auth-event';}function Rp(_0x66ffa4){switch(_0x66ffa4['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x66ffa4);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x5dbe09,_0x3c27d4={}){return Ae(_0x5dbe09,'GET','/v1/projects',_0x3c27d4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x103307){if(_0x103307['config']['emulator'])return;const {authorizedDomains:_0xfdaf4}=await Ap(_0x103307);for(const _0x3de6dc of _0xfdaf4)try{if(Op(_0x3de6dc))return;}catch{}K(_0x103307,'unauthorized-domain');}function Op(_0xaf8e8a){const _0x41bac6=Ni(),{protocol:_0x2f35b3,hostname:_0x53d2d5}=new URL(_0x41bac6);if(_0xaf8e8a['startsWith']('chrome-extension://')){const _0x4d53fe=new URL(_0xaf8e8a);return _0x4d53fe['hostname']===''&&_0x53d2d5===''?_0x2f35b3==='chrome-extension:'&&_0xaf8e8a['replace']('chrome-extension://','')===_0x41bac6['replace']('chrome-extension://',''):_0x2f35b3==='chrome-extension:'&&_0x4d53fe['hostname']===_0x53d2d5;}if(!Np['test'](_0x2f35b3))return!0x1;if(kp['test'](_0xaf8e8a))return _0x53d2d5===_0xaf8e8a;const _0x1c3bd8=_0xaf8e8a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1c3bd8+'|'+_0x1c3bd8+')$','i')['test'](_0x53d2d5);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x230e40=X()['___jsl'];if(_0x230e40!=null&&_0x230e40['H']){for(const _0x44f616 of Object['keys'](_0x230e40['H']))if(_0x230e40['H'][_0x44f616]['r']=_0x230e40['H'][_0x44f616]['r']||[],_0x230e40['H'][_0x44f616]['L']=_0x230e40['H'][_0x44f616]['L']||[],_0x230e40['H'][_0x44f616]['r']=[..._0x230e40['H'][_0x44f616]['L']],_0x230e40['CP']){for(let _0x27cdd0=0x0;_0x27cdd0<_0x230e40['CP']['length'];_0x27cdd0++)_0x230e40['CP'][_0x27cdd0]=null;}}}function Mp(_0xa90e9f){return new Promise((_0x5bd556,_0x3e9d76)=>{var _0x432e21,_0xa995f,_0x5820a2;function _0x4f69fd(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5bd556(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x3e9d76(J(_0xa90e9f,'network-request-failed'));},'timeout':Dp['get']()});}if((_0xa995f=(_0x432e21=X()['gapi'])==null?void 0x0:_0x432e21['iframes'])!=null&&_0xa995f['Iframe'])_0x5bd556(gapi['iframes']['getContext']());else{if((_0x5820a2=X()['gapi'])!=null&&_0x5820a2['load'])_0x4f69fd();else{const _0x310d7=Nf('iframefcb');return X()[_0x310d7]=()=>{gapi['load']?_0x4f69fd():_0x3e9d76(J(_0xa90e9f,'network-request-failed'));},Da(kf()+'?onload='+_0x310d7)['catch'](_0x2cb0a4=>_0x3e9d76(_0x2cb0a4));}}})['catch'](_0x204029=>{throw on=null,_0x204029;});}let on=null;function Lp(_0x10a01c){return on=on||Mp(_0x10a01c),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x4e09e3){const _0x1b8f34=_0x4e09e3['config'];m(_0x1b8f34['authDomain'],_0x4e09e3,'auth-domain-config-required');const _0x4e7d1d=_0x1b8f34['emulator']?Is(_0x1b8f34,Up):'https://'+_0x4e09e3['config']['authDomain']+'/'+Fp,_0x3ea3c2={'apiKey':_0x1b8f34['apiKey'],'appName':_0x4e09e3['name'],'v':ct},_0x121ee7=Bp['get'](_0x4e09e3['config']['apiHost']);_0x121ee7&&(_0x3ea3c2['eid']=_0x121ee7);const _0x10278d=_0x4e09e3['_getFrameworks']();return _0x10278d['length']&&(_0x3ea3c2['fw']=_0x10278d['join'](',')),_0x4e7d1d+'?'+at(_0x3ea3c2)['slice'](0x1);}async function Hp(_0x2d75da){const _0x2b1d8e=await Lp(_0x2d75da),_0x3fa427=X()['gapi'];return m(_0x3fa427,_0x2d75da,'internal-error'),_0x2b1d8e['open']({'where':document['body'],'url':Vp(_0x2d75da),'messageHandlersFilter':_0x3fa427['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x31adc6=>new Promise(async(_0x435e34,_0x37291e)=>{await _0x31adc6['restyle']({'setHideOnLeave':!0x1});const _0x50cb75=J(_0x2d75da,'network-request-failed'),_0x2e795a=X()['setTimeout'](()=>{_0x37291e(_0x50cb75);},xp['get']());function _0x4cf64b(){X()['clearTimeout'](_0x2e795a),_0x435e34(_0x31adc6);}_0x31adc6['ping'](_0x4cf64b)['then'](_0x4cf64b,()=>{_0x37291e(_0x50cb75);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x32c753){this['window']=_0x32c753,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x2387eb,_0x589da7,_0x59c8c7,_0x473395=Gp,_0xe56c3a=qp){const _0x5758e4=Math['max']((window['screen']['availHeight']-_0xe56c3a)/0x2,0x0)['toString'](),_0x57f64c=Math['max']((window['screen']['availWidth']-_0x473395)/0x2,0x0)['toString']();let _0x272308='';const _0x17c49d={...$p,'width':_0x473395['toString'](),'height':_0xe56c3a['toString'](),'top':_0x5758e4,'left':_0x57f64c},_0x376a47=W()['toLowerCase']();_0x59c8c7&&(_0x272308=ba(_0x376a47)?zp:_0x59c8c7),Ta(_0x376a47)&&(_0x589da7=_0x589da7||jp,_0x17c49d['scrollbars']='yes');const _0x2eec8b=Object['entries'](_0x17c49d)['reduce']((_0x5c8ef0,[_0x2fa75e,_0x56ce6f])=>''+_0x5c8ef0+_0x2fa75e+'='+_0x56ce6f+',','');if(Ef(_0x376a47)&&_0x272308!=='_self')return Yp(_0x589da7||'',_0x272308),new Dr(null);const _0xda439d=window['open'](_0x589da7||'',_0x272308,_0x2eec8b);m(_0xda439d,_0x2387eb,'popup-blocked');try{_0xda439d['focus']();}catch{}return new Dr(_0xda439d);}function Yp(_0x2fd843,_0x19ebc9){const _0x4ad22a=document['createElement']('a');_0x4ad22a['href']=_0x2fd843,_0x4ad22a['target']=_0x19ebc9;const _0x20c0a2=document['createEvent']('MouseEvent');_0x20c0a2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4ad22a['dispatchEvent'](_0x20c0a2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x6b0c69,_0x2b1ca9,_0x20ba55,_0x1a31ba,_0x353a87,_0x5c19c5){m(_0x6b0c69['config']['authDomain'],_0x6b0c69,'auth-domain-config-required'),m(_0x6b0c69['config']['apiKey'],_0x6b0c69,'invalid-api-key');const _0x558fc2={'apiKey':_0x6b0c69['config']['apiKey'],'appName':_0x6b0c69['name'],'authType':_0x20ba55,'redirectUrl':_0x1a31ba,'v':ct,'eventId':_0x353a87};if(_0x2b1ca9 instanceof xa){_0x2b1ca9['setDefaultLanguage'](_0x6b0c69['languageCode']),_0x558fc2['providerId']=_0x2b1ca9['providerId']||'',hi(_0x2b1ca9['getCustomParameters']())||(_0x558fc2['customParameters']=JSON['stringify'](_0x2b1ca9['getCustomParameters']()));for(const [_0x2bb61d,_0x3d23d7]of Object['entries']({}))_0x558fc2[_0x2bb61d]=_0x3d23d7;}if(_0x2b1ca9 instanceof Qt){const _0x4abbf5=_0x2b1ca9['getScopes']()['filter'](_0x26629d=>_0x26629d!=='');_0x4abbf5['length']>0x0&&(_0x558fc2['scopes']=_0x4abbf5['join'](','));}_0x6b0c69['tenantId']&&(_0x558fc2['tid']=_0x6b0c69['tenantId']);const _0x493d28=_0x558fc2;for(const _0xcffc85 of Object['keys'](_0x493d28))_0x493d28[_0xcffc85]===void 0x0&&delete _0x493d28[_0xcffc85];const _0x398385=await _0x6b0c69['_getAppCheckToken'](),_0x1d8b6c=_0x398385?'#'+Xp+'='+encodeURIComponent(_0x398385):'';return Zp(_0x6b0c69)+'?'+at(_0x493d28)['slice'](0x1)+_0x1d8b6c;}function Zp({config:_0x5a1303}){return _0x5a1303['emulator']?Is(_0x5a1303,Jp):'https://'+_0x5a1303['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x1a36d0,_0x1fffb0,_0x2922c7,_0x13a2d0){var _0x2d3d93;ae((_0x2d3d93=this['eventManagers'][_0x1a36d0['_key']()])==null?void 0x0:_0x2d3d93['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5c87ae=await Mr(_0x1a36d0,_0x1fffb0,_0x2922c7,Ni(),_0x13a2d0);return Kp(_0x1a36d0,_0x5c87ae,bs());}async['_openRedirect'](_0x2ded31,_0x2a26b0,_0x2d7159,_0x350a8b){await this['_originValidation'](_0x2ded31);const _0x3529a7=await Mr(_0x2ded31,_0x2a26b0,_0x2d7159,Ni(),_0x350a8b);return ip(_0x3529a7),new Promise(()=>{});}['_initialize'](_0x2dd6b0){const _0x31b138=_0x2dd6b0['_key']();if(this['eventManagers'][_0x31b138]){const {manager:_0x5b7497,promise:_0x260eb1}=this['eventManagers'][_0x31b138];return _0x5b7497?Promise['resolve'](_0x5b7497):(ae(_0x260eb1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x260eb1);}const _0x4ba472=this['initAndGetManager'](_0x2dd6b0);return this['eventManagers'][_0x31b138]={'promise':_0x4ba472},_0x4ba472['catch'](()=>{delete this['eventManagers'][_0x31b138];}),_0x4ba472;}async['initAndGetManager'](_0x3f2106){const _0x5ec272=await Hp(_0x3f2106),_0x163a8d=new bp(_0x3f2106);return _0x5ec272['register']('authEvent',_0x263b52=>(m(_0x263b52==null?void 0x0:_0x263b52['authEvent'],_0x3f2106,'invalid-auth-event'),{'status':_0x163a8d['onEvent'](_0x263b52['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3f2106['_key']()]={'manager':_0x163a8d},this['iframes'][_0x3f2106['_key']()]=_0x5ec272,_0x163a8d;}['_isIframeWebStorageSupported'](_0x5ec29a,_0x5ce509){this['iframes'][_0x5ec29a['_key']()]['send'](li,{'type':li},_0x22459b=>{var _0x4ee4fe;const _0xe09e91=(_0x4ee4fe=_0x22459b==null?void 0x0:_0x22459b[0x0])==null?void 0x0:_0x4ee4fe[li];_0xe09e91!==void 0x0&&_0x5ce509(!!_0xe09e91),K(_0x5ec29a,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3e779a){const _0x288d37=_0x3e779a['_key']();return this['originValidationPromises'][_0x288d37]||(this['originValidationPromises'][_0x288d37]=Pp(_0x3e779a)),this['originValidationPromises'][_0x288d37];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x1874fa){this['auth']=_0x1874fa,this['internalListeners']=new Map();}['getUid'](){var _0x1d21db;return this['assertAuthConfigured'](),((_0x1d21db=this['auth']['currentUser'])==null?void 0x0:_0x1d21db['uid'])||null;}async['getToken'](_0x3ce922){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3ce922)}:null;}['addAuthTokenListener'](_0x49c3d7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x49c3d7))return;const _0x14ed81=this['auth']['onIdTokenChanged'](_0x1030a2=>{_0x49c3d7((_0x1030a2==null?void 0x0:_0x1030a2['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x49c3d7,_0x14ed81),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x59feed){this['assertAuthConfigured']();const _0x1acf04=this['internalListeners']['get'](_0x59feed);_0x1acf04&&(this['internalListeners']['delete'](_0x59feed),_0x1acf04(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x42b64e){switch(_0x42b64e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x579e42){et(new Me('auth',(_0x4c784b,{options:_0x492df5})=>{const _0x22cd79=_0x4c784b['getProvider']('app')['getImmediate'](),_0x175164=_0x4c784b['getProvider']('heartbeat'),_0xd4e422=_0x4c784b['getProvider']('app-check-internal'),{apiKey:_0x3b7c6d,authDomain:_0x1c9029}=_0x22cd79['options'];m(_0x3b7c6d&&!_0x3b7c6d['includes'](':'),'invalid-api-key',{'appName':_0x22cd79['name']});const _0x130f89={'apiKey':_0x3b7c6d,'authDomain':_0x1c9029,'clientPlatform':_0x579e42,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x579e42)},_0x1b3b5d=new bf(_0x22cd79,_0x175164,_0xd4e422,_0x130f89);return Lf(_0x1b3b5d,_0x492df5),_0x1b3b5d;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x543024,_0x110dbc,_0x369ef7)=>{_0x543024['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x28d768=>{const _0xba5821=qe(_0x28d768['getProvider']('auth')['getImmediate']());return(_0x1977e6=>new n_(_0x1977e6))(_0xba5821);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x579e42)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4484ce=>async _0x572b09=>{const _0x1def1a=_0x572b09&&await _0x572b09['getIdTokenResult'](),_0x5ead1f=_0x1def1a&&(new Date()['getTime']()-Date['parse'](_0x1def1a['issuedAtTime']))/0x3e8;if(_0x5ead1f&&_0x5ead1f>o_)return;const _0x2ddaba=_0x1def1a==null?void 0x0:_0x1def1a['token'];Fr!==_0x2ddaba&&(Fr=_0x2ddaba,await fetch(_0x4484ce,{'method':_0x2ddaba?'POST':'DELETE','headers':_0x2ddaba?{'Authorization':'Bearer\x20'+_0x2ddaba}:{}}));};function O_(_0x4dd6ed=Qr()){const _0x4c8811=Ui(_0x4dd6ed,'auth');if(_0x4c8811['isInitialized']())return _0x4c8811['getImmediate']();const _0x3f9c53=Mf(_0x4dd6ed,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x37db43=Gr('authTokenSyncURL');if(_0x37db43&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xda77f3=new URL(_0x37db43,location['origin']);if(location['origin']===_0xda77f3['origin']){const _0x292786=a_(_0xda77f3['toString']());Jf(_0x3f9c53,_0x292786,()=>_0x292786(_0x3f9c53['currentUser'])),Qf(_0x3f9c53,_0x2fc305=>_0x292786(_0x2fc305));}}const _0x1c7592=Hr('auth');return _0x1c7592&&xf(_0x3f9c53,'http://'+_0x1c7592),_0x3f9c53;}function c_(){var _0x4bf737;return((_0x4bf737=document['getElementsByTagName']('head'))==null?void 0x0:_0x4bf737[0x0])??document;}Rf({'loadJS'(_0x3eba24){return new Promise((_0x448f81,_0x502f49)=>{const _0x7ff604=document['createElement']('script');_0x7ff604['setAttribute']('src',_0x3eba24),_0x7ff604['onload']=_0x448f81,_0x7ff604['onerror']=_0x25e236=>{const _0x4f33ad=J('internal-error');_0x4f33ad['customData']=_0x25e236,_0x502f49(_0x4f33ad);},_0x7ff604['type']='text/javascript',_0x7ff604['charset']='UTF-8',c_()['appendChild'](_0x7ff604);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};