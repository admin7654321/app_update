const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x48e984,_0x8ebc1a){if(!_0x48e984)throw ot(_0x8ebc1a);},ot=function(_0x15929c){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x15929c);},Wr=function(_0x1dc1d1){const _0x3c4ffb=[];let _0x58c1e9=0x0;for(let _0x14fa03=0x0;_0x14fa03<_0x1dc1d1['length'];_0x14fa03++){let _0x294f18=_0x1dc1d1['charCodeAt'](_0x14fa03);_0x294f18<0x80?_0x3c4ffb[_0x58c1e9++]=_0x294f18:_0x294f18<0x800?(_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0x6|0xc0,_0x3c4ffb[_0x58c1e9++]=_0x294f18&0x3f|0x80):(_0x294f18&0xfc00)===0xd800&&_0x14fa03+0x1<_0x1dc1d1['length']&&(_0x1dc1d1['charCodeAt'](_0x14fa03+0x1)&0xfc00)===0xdc00?(_0x294f18=0x10000+((_0x294f18&0x3ff)<<0xa)+(_0x1dc1d1['charCodeAt'](++_0x14fa03)&0x3ff),_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0x12|0xf0,_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0xc&0x3f|0x80,_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0x6&0x3f|0x80,_0x3c4ffb[_0x58c1e9++]=_0x294f18&0x3f|0x80):(_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0xc|0xe0,_0x3c4ffb[_0x58c1e9++]=_0x294f18>>0x6&0x3f|0x80,_0x3c4ffb[_0x58c1e9++]=_0x294f18&0x3f|0x80);}return _0x3c4ffb;},Za=function(_0x2c8de3){const _0x53b0c4=[];let _0x1e89a6=0x0,_0x4799e9=0x0;for(;_0x1e89a6<_0x2c8de3['length'];){const _0x243384=_0x2c8de3[_0x1e89a6++];if(_0x243384<0x80)_0x53b0c4[_0x4799e9++]=String['fromCharCode'](_0x243384);else{if(_0x243384>0xbf&&_0x243384<0xe0){const _0x460bf9=_0x2c8de3[_0x1e89a6++];_0x53b0c4[_0x4799e9++]=String['fromCharCode']((_0x243384&0x1f)<<0x6|_0x460bf9&0x3f);}else{if(_0x243384>0xef&&_0x243384<0x16d){const _0x5be4ad=_0x2c8de3[_0x1e89a6++],_0x411385=_0x2c8de3[_0x1e89a6++],_0x32a4fd=_0x2c8de3[_0x1e89a6++],_0x39d8fd=((_0x243384&0x7)<<0x12|(_0x5be4ad&0x3f)<<0xc|(_0x411385&0x3f)<<0x6|_0x32a4fd&0x3f)-0x10000;_0x53b0c4[_0x4799e9++]=String['fromCharCode'](0xd800+(_0x39d8fd>>0xa)),_0x53b0c4[_0x4799e9++]=String['fromCharCode'](0xdc00+(_0x39d8fd&0x3ff));}else{const _0x3f56d9=_0x2c8de3[_0x1e89a6++],_0x92d5e9=_0x2c8de3[_0x1e89a6++];_0x53b0c4[_0x4799e9++]=String['fromCharCode']((_0x243384&0xf)<<0xc|(_0x3f56d9&0x3f)<<0x6|_0x92d5e9&0x3f);}}}}return _0x53b0c4['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x515de2,_0x5002bf){if(!Array['isArray'](_0x515de2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x43b3a4=_0x5002bf?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5baa0b=[];for(let _0x4ac5b7=0x0;_0x4ac5b7<_0x515de2['length'];_0x4ac5b7+=0x3){const _0x15b1c9=_0x515de2[_0x4ac5b7],_0x25eac8=_0x4ac5b7+0x1<_0x515de2['length'],_0x55df0f=_0x25eac8?_0x515de2[_0x4ac5b7+0x1]:0x0,_0x718b08=_0x4ac5b7+0x2<_0x515de2['length'],_0x2ffc2d=_0x718b08?_0x515de2[_0x4ac5b7+0x2]:0x0,_0x100612=_0x15b1c9>>0x2,_0x36fce8=(_0x15b1c9&0x3)<<0x4|_0x55df0f>>0x4;let _0x5a2312=(_0x55df0f&0xf)<<0x2|_0x2ffc2d>>0x6,_0x3c5cdc=_0x2ffc2d&0x3f;_0x718b08||(_0x3c5cdc=0x40,_0x25eac8||(_0x5a2312=0x40)),_0x5baa0b['push'](_0x43b3a4[_0x100612],_0x43b3a4[_0x36fce8],_0x43b3a4[_0x5a2312],_0x43b3a4[_0x3c5cdc]);}return _0x5baa0b['join']('');},'encodeString'(_0x50c58b,_0x1610ef){return this['HAS_NATIVE_SUPPORT']&&!_0x1610ef?btoa(_0x50c58b):this['encodeByteArray'](Wr(_0x50c58b),_0x1610ef);},'decodeString'(_0x4ed61f,_0x5b303b){return this['HAS_NATIVE_SUPPORT']&&!_0x5b303b?atob(_0x4ed61f):Za(this['decodeStringToByteArray'](_0x4ed61f,_0x5b303b));},'decodeStringToByteArray'(_0x3edb6d,_0x118d01){this['init_']();const _0x28cf7b=_0x118d01?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x29aab9=[];for(let _0x1a4405=0x0;_0x1a4405<_0x3edb6d['length'];){const _0x172676=_0x28cf7b[_0x3edb6d['charAt'](_0x1a4405++)],_0x2c7edc=_0x1a4405<_0x3edb6d['length']?_0x28cf7b[_0x3edb6d['charAt'](_0x1a4405)]:0x0;++_0x1a4405;const _0x2f8060=_0x1a4405<_0x3edb6d['length']?_0x28cf7b[_0x3edb6d['charAt'](_0x1a4405)]:0x40;++_0x1a4405;const _0x386ee3=_0x1a4405<_0x3edb6d['length']?_0x28cf7b[_0x3edb6d['charAt'](_0x1a4405)]:0x40;if(++_0x1a4405,_0x172676==null||_0x2c7edc==null||_0x2f8060==null||_0x386ee3==null)throw new ec();const _0x508c3e=_0x172676<<0x2|_0x2c7edc>>0x4;if(_0x29aab9['push'](_0x508c3e),_0x2f8060!==0x40){const _0x19e45e=_0x2c7edc<<0x4&0xf0|_0x2f8060>>0x2;if(_0x29aab9['push'](_0x19e45e),_0x386ee3!==0x40){const _0x1a50cb=_0x2f8060<<0x6&0xc0|_0x386ee3;_0x29aab9['push'](_0x1a50cb);}}}return _0x29aab9;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xee12ef=0x0;_0xee12ef<this['ENCODED_VALS']['length'];_0xee12ef++)this['byteToCharMap_'][_0xee12ef]=this['ENCODED_VALS']['charAt'](_0xee12ef),this['charToByteMap_'][this['byteToCharMap_'][_0xee12ef]]=_0xee12ef,this['byteToCharMapWebSafe_'][_0xee12ef]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xee12ef),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xee12ef]]=_0xee12ef,_0xee12ef>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xee12ef)]=_0xee12ef,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xee12ef)]=_0xee12ef);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x459901){const _0x403fed=Wr(_0x459901);return Di['encodeByteArray'](_0x403fed,!0x0);},an=function(_0x39d168){return Br(_0x39d168)['replace'](/\./g,'');},cn=function(_0x556c01){try{return Di['decodeString'](_0x556c01,!0x0);}catch(_0x2167a8){console['error']('base64Decode\x20failed:\x20',_0x2167a8);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x4fd357){return Vr(void 0x0,_0x4fd357);}function Vr(_0xbaaa28,_0x3a3421){if(!(_0x3a3421 instanceof Object))return _0x3a3421;switch(_0x3a3421['constructor']){case Date:const _0x226337=_0x3a3421;return new Date(_0x226337['getTime']());case Object:_0xbaaa28===void 0x0&&(_0xbaaa28={});break;case Array:_0xbaaa28=[];break;default:return _0x3a3421;}for(const _0x122568 in _0x3a3421)!_0x3a3421['hasOwnProperty'](_0x122568)||!nc(_0x122568)||(_0xbaaa28[_0x122568]=Vr(_0xbaaa28[_0x122568],_0x3a3421[_0x122568]));return _0xbaaa28;}function nc(_0xd97b30){return _0xd97b30!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2068ae=As['__FIREBASE_DEFAULTS__'];if(_0x2068ae)return JSON['parse'](_0x2068ae);},oc=()=>{if(typeof document>'u')return;let _0x1cf384;try{_0x1cf384=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4e68f9=_0x1cf384&&cn(_0x1cf384[0x1]);return _0x4e68f9&&JSON['parse'](_0x4e68f9);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4ffb25){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4ffb25);return;}},Hr=_0x180bd4=>{var _0x5b2b5a,_0x19e739;return(_0x19e739=(_0x5b2b5a=Mi())==null?void 0x0:_0x5b2b5a['emulatorHosts'])==null?void 0x0:_0x19e739[_0x180bd4];},ac=_0x1ccdd7=>{const _0x2c5cf9=Hr(_0x1ccdd7);if(!_0x2c5cf9)return;const _0x22367f=_0x2c5cf9['lastIndexOf'](':');if(_0x22367f<=0x0||_0x22367f+0x1===_0x2c5cf9['length'])throw new Error('Invalid\x20host\x20'+_0x2c5cf9+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x33e55e=parseInt(_0x2c5cf9['substring'](_0x22367f+0x1),0xa);return _0x2c5cf9[0x0]==='['?[_0x2c5cf9['substring'](0x1,_0x22367f-0x1),_0x33e55e]:[_0x2c5cf9['substring'](0x0,_0x22367f),_0x33e55e];},$r=()=>{var _0x14eb37;return(_0x14eb37=Mi())==null?void 0x0:_0x14eb37['config'];},Gr=_0x3a70c7=>{var _0x49f9aa;return(_0x49f9aa=Mi())==null?void 0x0:_0x49f9aa['_'+_0x3a70c7];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4a8629,_0x1f330a)=>{this['resolve']=_0x4a8629,this['reject']=_0x1f330a;});}['wrapCallback'](_0x2a2b0a){return(_0x499f9f,_0x39a1aa)=>{_0x499f9f?this['reject'](_0x499f9f):this['resolve'](_0x39a1aa),typeof _0x2a2b0a=='function'&&(this['promise']['catch'](()=>{}),_0x2a2b0a['length']===0x1?_0x2a2b0a(_0x499f9f):_0x2a2b0a(_0x499f9f,_0x39a1aa));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3de196,_0x4c47fd){if(_0x3de196['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x30f0fb={'alg':'none','type':'JWT'},_0x55f77d=_0x4c47fd||'demo-project',_0x2f45a9=_0x3de196['iat']||0x0,_0x4c4155=_0x3de196['sub']||_0x3de196['user_id'];if(!_0x4c4155)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x513acf={'iss':'https://securetoken.google.com/'+_0x55f77d,'aud':_0x55f77d,'iat':_0x2f45a9,'exp':_0x2f45a9+0xe10,'auth_time':_0x2f45a9,'sub':_0x4c4155,'user_id':_0x4c4155,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3de196};return[an(JSON['stringify'](_0x30f0fb)),an(JSON['stringify'](_0x513acf)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x53d86d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x53d86d=='object'&&_0x53d86d['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x4d5c1d=W();return _0x4d5c1d['indexOf']('MSIE\x20')>=0x0||_0x4d5c1d['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x39e667,_0x7cc21f)=>{try{let _0x595e49=!0x0;const _0x14c5ee='validate-browser-context-for-indexeddb-analytics-module',_0x30e542=self['indexedDB']['open'](_0x14c5ee);_0x30e542['onsuccess']=()=>{_0x30e542['result']['close'](),_0x595e49||self['indexedDB']['deleteDatabase'](_0x14c5ee),_0x39e667(!0x0);},_0x30e542['onupgradeneeded']=()=>{_0x595e49=!0x1;},_0x30e542['onerror']=()=>{var _0x723ea9;_0x7cc21f(((_0x723ea9=_0x30e542['error'])==null?void 0x0:_0x723ea9['message'])||'');};}catch(_0x361f94){_0x7cc21f(_0x361f94);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xcd11ee,_0x11b34e,_0x3de298){super(_0x11b34e),this['code']=_0xcd11ee,this['customData']=_0x3de298,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2614db,_0x8baabf,_0x3257e3){this['service']=_0x2614db,this['serviceName']=_0x8baabf,this['errors']=_0x3257e3;}['create'](_0x27ac31,..._0x560f4e){const _0x32c01c=_0x560f4e[0x0]||{},_0x91f7f1=this['service']+'/'+_0x27ac31,_0x1277ad=this['errors'][_0x27ac31],_0x20bd05=_0x1277ad?gc(_0x1277ad,_0x32c01c):'Error',_0x145caf=this['serviceName']+':\x20'+_0x20bd05+'\x20('+_0x91f7f1+').';return new Se(_0x91f7f1,_0x145caf,_0x32c01c);}}function gc(_0x32cf9a,_0x3d1a4c){return _0x32cf9a['replace'](mc,(_0x31b5ce,_0x190127)=>{const _0x26ac83=_0x3d1a4c[_0x190127];return _0x26ac83!=null?String(_0x26ac83):'<'+_0x190127+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x432e52){return JSON['parse'](_0x432e52);}function O(_0x12b625){return JSON['stringify'](_0x12b625);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xab22a1){let _0x21353b={},_0x2c67d9={},_0x6421c={},_0x25f43b='';try{const _0x49e0b2=_0xab22a1['split']('.');_0x21353b=bt(cn(_0x49e0b2[0x0])||''),_0x2c67d9=bt(cn(_0x49e0b2[0x1])||''),_0x25f43b=_0x49e0b2[0x2],_0x6421c=_0x2c67d9['d']||{},delete _0x2c67d9['d'];}catch{}return{'header':_0x21353b,'claims':_0x2c67d9,'data':_0x6421c,'signature':_0x25f43b};},yc=function(_0x4c06d8){const _0x17b8c5=zr(_0x4c06d8),_0x16c1df=_0x17b8c5['claims'];return!!_0x16c1df&&typeof _0x16c1df=='object'&&_0x16c1df['hasOwnProperty']('iat');},vc=function(_0x3231b3){const _0x1d8004=zr(_0x3231b3)['claims'];return typeof _0x1d8004=='object'&&_0x1d8004['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x445943,_0x19689a){return Object['prototype']['hasOwnProperty']['call'](_0x445943,_0x19689a);}function Oe(_0x21c1f0,_0x56735b){if(Object['prototype']['hasOwnProperty']['call'](_0x21c1f0,_0x56735b))return _0x21c1f0[_0x56735b];}function hi(_0x24f5fd){for(const _0x499c0b in _0x24f5fd)if(Object['prototype']['hasOwnProperty']['call'](_0x24f5fd,_0x499c0b))return!0x1;return!0x0;}function ln(_0x148758,_0x4cc640,_0x45420b){const _0x309619={};for(const _0x2831c2 in _0x148758)Object['prototype']['hasOwnProperty']['call'](_0x148758,_0x2831c2)&&(_0x309619[_0x2831c2]=_0x4cc640['call'](_0x45420b,_0x148758[_0x2831c2],_0x2831c2,_0x148758));return _0x309619;}function De(_0x388c08,_0x17c706){if(_0x388c08===_0x17c706)return!0x0;const _0x3953c3=Object['keys'](_0x388c08),_0x5a8bd3=Object['keys'](_0x17c706);for(const _0x226c70 of _0x3953c3){if(!_0x5a8bd3['includes'](_0x226c70))return!0x1;const _0x5d1037=_0x388c08[_0x226c70],_0x11f06f=_0x17c706[_0x226c70];if(ks(_0x5d1037)&&ks(_0x11f06f)){if(!De(_0x5d1037,_0x11f06f))return!0x1;}else{if(_0x5d1037!==_0x11f06f)return!0x1;}}for(const _0x3741e6 of _0x5a8bd3)if(!_0x3953c3['includes'](_0x3741e6))return!0x1;return!0x0;}function ks(_0x1cafc9){return _0x1cafc9!==null&&typeof _0x1cafc9=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5a09dc){const _0x49f2b2=[];for(const [_0x195f24,_0x4829e6]of Object['entries'](_0x5a09dc))Array['isArray'](_0x4829e6)?_0x4829e6['forEach'](_0x594bb3=>{_0x49f2b2['push'](encodeURIComponent(_0x195f24)+'='+encodeURIComponent(_0x594bb3));}):_0x49f2b2['push'](encodeURIComponent(_0x195f24)+'='+encodeURIComponent(_0x4829e6));return _0x49f2b2['length']?'&'+_0x49f2b2['join']('&'):'';}function yt(_0x4f595c){const _0x48077f={};return _0x4f595c['replace'](/^\?/,'')['split']('&')['forEach'](_0x4a6b34=>{if(_0x4a6b34){const [_0x5a36b3,_0x4b4e93]=_0x4a6b34['split']('=');_0x48077f[decodeURIComponent(_0x5a36b3)]=decodeURIComponent(_0x4b4e93);}}),_0x48077f;}function vt(_0x1ceb72){const _0x135a10=_0x1ceb72['indexOf']('?');if(!_0x135a10)return'';const _0x5c1c96=_0x1ceb72['indexOf']('#',_0x135a10);return _0x1ceb72['substring'](_0x135a10,_0x5c1c96>0x0?_0x5c1c96:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3970dd=0x1;_0x3970dd<this['blockSize'];++_0x3970dd)this['pad_'][_0x3970dd]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x856d15,_0x176280){_0x176280||(_0x176280=0x0);const _0x3ad42e=this['W_'];if(typeof _0x856d15=='string'){for(let _0x452aa3=0x0;_0x452aa3<0x10;_0x452aa3++)_0x3ad42e[_0x452aa3]=_0x856d15['charCodeAt'](_0x176280)<<0x18|_0x856d15['charCodeAt'](_0x176280+0x1)<<0x10|_0x856d15['charCodeAt'](_0x176280+0x2)<<0x8|_0x856d15['charCodeAt'](_0x176280+0x3),_0x176280+=0x4;}else{for(let _0x5efd27=0x0;_0x5efd27<0x10;_0x5efd27++)_0x3ad42e[_0x5efd27]=_0x856d15[_0x176280]<<0x18|_0x856d15[_0x176280+0x1]<<0x10|_0x856d15[_0x176280+0x2]<<0x8|_0x856d15[_0x176280+0x3],_0x176280+=0x4;}for(let _0x10af5c=0x10;_0x10af5c<0x50;_0x10af5c++){const _0x45a4cf=_0x3ad42e[_0x10af5c-0x3]^_0x3ad42e[_0x10af5c-0x8]^_0x3ad42e[_0x10af5c-0xe]^_0x3ad42e[_0x10af5c-0x10];_0x3ad42e[_0x10af5c]=(_0x45a4cf<<0x1|_0x45a4cf>>>0x1f)&0xffffffff;}let _0x815097=this['chain_'][0x0],_0x3051c7=this['chain_'][0x1],_0x3fc6c0=this['chain_'][0x2],_0x11cb72=this['chain_'][0x3],_0x103e09=this['chain_'][0x4],_0x575bb9,_0x101868;for(let _0x4b2072=0x0;_0x4b2072<0x50;_0x4b2072++){_0x4b2072<0x28?_0x4b2072<0x14?(_0x575bb9=_0x11cb72^_0x3051c7&(_0x3fc6c0^_0x11cb72),_0x101868=0x5a827999):(_0x575bb9=_0x3051c7^_0x3fc6c0^_0x11cb72,_0x101868=0x6ed9eba1):_0x4b2072<0x3c?(_0x575bb9=_0x3051c7&_0x3fc6c0|_0x11cb72&(_0x3051c7|_0x3fc6c0),_0x101868=0x8f1bbcdc):(_0x575bb9=_0x3051c7^_0x3fc6c0^_0x11cb72,_0x101868=0xca62c1d6);const _0x45b22a=(_0x815097<<0x5|_0x815097>>>0x1b)+_0x575bb9+_0x103e09+_0x101868+_0x3ad42e[_0x4b2072]&0xffffffff;_0x103e09=_0x11cb72,_0x11cb72=_0x3fc6c0,_0x3fc6c0=(_0x3051c7<<0x1e|_0x3051c7>>>0x2)&0xffffffff,_0x3051c7=_0x815097,_0x815097=_0x45b22a;}this['chain_'][0x0]=this['chain_'][0x0]+_0x815097&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3051c7&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3fc6c0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x11cb72&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x103e09&0xffffffff;}['update'](_0x37271c,_0x11a659){if(_0x37271c==null)return;_0x11a659===void 0x0&&(_0x11a659=_0x37271c['length']);const _0x543e79=_0x11a659-this['blockSize'];let _0x59c17f=0x0;const _0x5e5c07=this['buf_'];let _0x24a41b=this['inbuf_'];for(;_0x59c17f<_0x11a659;){if(_0x24a41b===0x0){for(;_0x59c17f<=_0x543e79;)this['compress_'](_0x37271c,_0x59c17f),_0x59c17f+=this['blockSize'];}if(typeof _0x37271c=='string'){for(;_0x59c17f<_0x11a659;)if(_0x5e5c07[_0x24a41b]=_0x37271c['charCodeAt'](_0x59c17f),++_0x24a41b,++_0x59c17f,_0x24a41b===this['blockSize']){this['compress_'](_0x5e5c07),_0x24a41b=0x0;break;}}else{for(;_0x59c17f<_0x11a659;)if(_0x5e5c07[_0x24a41b]=_0x37271c[_0x59c17f],++_0x24a41b,++_0x59c17f,_0x24a41b===this['blockSize']){this['compress_'](_0x5e5c07),_0x24a41b=0x0;break;}}}this['inbuf_']=_0x24a41b,this['total_']+=_0x11a659;}['digest'](){const _0xbdf143=[];let _0x3acc1c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x164608=this['blockSize']-0x1;_0x164608>=0x38;_0x164608--)this['buf_'][_0x164608]=_0x3acc1c&0xff,_0x3acc1c/=0x100;this['compress_'](this['buf_']);let _0x2c7f45=0x0;for(let _0x4c6662=0x0;_0x4c6662<0x5;_0x4c6662++)for(let _0x10cb61=0x18;_0x10cb61>=0x0;_0x10cb61-=0x8)_0xbdf143[_0x2c7f45]=this['chain_'][_0x4c6662]>>_0x10cb61&0xff,++_0x2c7f45;return _0xbdf143;}}function Ic(_0x429d4c,_0x121d64){const _0x38cdc1=new wc(_0x429d4c,_0x121d64);return _0x38cdc1['subscribe']['bind'](_0x38cdc1);}class wc{constructor(_0x30dfcf,_0x5e01e2){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5e01e2,this['task']['then'](()=>{_0x30dfcf(this);})['catch'](_0x1d2583=>{this['error'](_0x1d2583);});}['next'](_0x641076){this['forEachObserver'](_0x5dd48e=>{_0x5dd48e['next'](_0x641076);});}['error'](_0x28cab3){this['forEachObserver'](_0x4b937b=>{_0x4b937b['error'](_0x28cab3);}),this['close'](_0x28cab3);}['complete'](){this['forEachObserver'](_0x3ce729=>{_0x3ce729['complete']();}),this['close']();}['subscribe'](_0x397e52,_0x8166d5,_0x96a00b){let _0x16373f;if(_0x397e52===void 0x0&&_0x8166d5===void 0x0&&_0x96a00b===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x397e52,['next','error','complete'])?_0x16373f=_0x397e52:_0x16373f={'next':_0x397e52,'error':_0x8166d5,'complete':_0x96a00b},_0x16373f['next']===void 0x0&&(_0x16373f['next']=Qn),_0x16373f['error']===void 0x0&&(_0x16373f['error']=Qn),_0x16373f['complete']===void 0x0&&(_0x16373f['complete']=Qn);const _0x33d015=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x16373f['error'](this['finalError']):_0x16373f['complete']();}catch{}}),this['observers']['push'](_0x16373f),_0x33d015;}['unsubscribeOne'](_0x90a5bb){this['observers']===void 0x0||this['observers'][_0x90a5bb]===void 0x0||(delete this['observers'][_0x90a5bb],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x16270a){if(!this['finalized']){for(let _0x156b9d=0x0;_0x156b9d<this['observers']['length'];_0x156b9d++)this['sendOne'](_0x156b9d,_0x16270a);}}['sendOne'](_0x2f6832,_0x4e9391){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2f6832]!==void 0x0)try{_0x4e9391(this['observers'][_0x2f6832]);}catch(_0x3033c6){typeof console<'u'&&console['error']&&console['error'](_0x3033c6);}});}['close'](_0x3f4d60){this['finalized']||(this['finalized']=!0x0,_0x3f4d60!==void 0x0&&(this['finalError']=_0x3f4d60),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x5181a2,_0xf14222){if(typeof _0x5181a2!='object'||_0x5181a2===null)return!0x1;for(const _0x2018b6 of _0xf14222)if(_0x2018b6 in _0x5181a2&&typeof _0x5181a2[_0x2018b6]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x54d6c0,_0x2c7369){return _0x54d6c0+'\x20failed:\x20'+_0x2c7369+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x5102bf){const _0x1db5c5=[];let _0xcb5b8f=0x0;for(let _0x3a6130=0x0;_0x3a6130<_0x5102bf['length'];_0x3a6130++){let _0x5a11b4=_0x5102bf['charCodeAt'](_0x3a6130);if(_0x5a11b4>=0xd800&&_0x5a11b4<=0xdbff){const _0x49e680=_0x5a11b4-0xd800;_0x3a6130++,f(_0x3a6130<_0x5102bf['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3d77ae=_0x5102bf['charCodeAt'](_0x3a6130)-0xdc00;_0x5a11b4=0x10000+(_0x49e680<<0xa)+_0x3d77ae;}_0x5a11b4<0x80?_0x1db5c5[_0xcb5b8f++]=_0x5a11b4:_0x5a11b4<0x800?(_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0x6|0xc0,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4&0x3f|0x80):_0x5a11b4<0x10000?(_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0xc|0xe0,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0x6&0x3f|0x80,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4&0x3f|0x80):(_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0x12|0xf0,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0xc&0x3f|0x80,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4>>0x6&0x3f|0x80,_0x1db5c5[_0xcb5b8f++]=_0x5a11b4&0x3f|0x80);}return _0x1db5c5;},Pn=function(_0x438729){let _0x29e0c9=0x0;for(let _0x4f57f6=0x0;_0x4f57f6<_0x438729['length'];_0x4f57f6++){const _0xc8e85f=_0x438729['charCodeAt'](_0x4f57f6);_0xc8e85f<0x80?_0x29e0c9++:_0xc8e85f<0x800?_0x29e0c9+=0x2:_0xc8e85f>=0xd800&&_0xc8e85f<=0xdbff?(_0x29e0c9+=0x4,_0x4f57f6++):_0x29e0c9+=0x3;}return _0x29e0c9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x121679){return _0x121679&&_0x121679['_delegate']?_0x121679['_delegate']:_0x121679;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x50d114){try{return(_0x50d114['startsWith']('http://')||_0x50d114['startsWith']('https://')?new URL(_0x50d114)['hostname']:_0x50d114)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x12aa71){return(await fetch(_0x12aa71,{'credentials':'include'}))['ok'];}class Me{constructor(_0x49a0fc,_0x4ce486,_0x20d493){this['name']=_0x49a0fc,this['instanceFactory']=_0x4ce486,this['type']=_0x20d493,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x59639a){return this['instantiationMode']=_0x59639a,this;}['setMultipleInstances'](_0x8aaf2b){return this['multipleInstances']=_0x8aaf2b,this;}['setServiceProps'](_0x467b26){return this['serviceProps']=_0x467b26,this;}['setInstanceCreatedCallback'](_0x810b6b){return this['onInstanceCreated']=_0x810b6b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x1b7bb5,_0x8cf9ce){this['name']=_0x1b7bb5,this['container']=_0x8cf9ce,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1d5a6d){const _0x14a9bd=this['normalizeInstanceIdentifier'](_0x1d5a6d);if(!this['instancesDeferred']['has'](_0x14a9bd)){const _0x2e6938=new Ve();if(this['instancesDeferred']['set'](_0x14a9bd,_0x2e6938),this['isInitialized'](_0x14a9bd)||this['shouldAutoInitialize']())try{const _0x40d19f=this['getOrInitializeService']({'instanceIdentifier':_0x14a9bd});_0x40d19f&&_0x2e6938['resolve'](_0x40d19f);}catch{}}return this['instancesDeferred']['get'](_0x14a9bd)['promise'];}['getImmediate'](_0x2fc62a){const _0x2d2b78=this['normalizeInstanceIdentifier'](_0x2fc62a==null?void 0x0:_0x2fc62a['identifier']),_0x452e51=(_0x2fc62a==null?void 0x0:_0x2fc62a['optional'])??!0x1;if(this['isInitialized'](_0x2d2b78)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2d2b78});}catch(_0xb210b5){if(_0x452e51)return null;throw _0xb210b5;}else{if(_0x452e51)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x5d0734){if(_0x5d0734['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x5d0734['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x5d0734,!!this['shouldAutoInitialize']()){if(Rc(_0x5d0734))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x39b6a0,_0x2b6467]of this['instancesDeferred']['entries']()){const _0x578b29=this['normalizeInstanceIdentifier'](_0x39b6a0);try{const _0x37aaf8=this['getOrInitializeService']({'instanceIdentifier':_0x578b29});_0x2b6467['resolve'](_0x37aaf8);}catch{}}}}['clearInstance'](_0x5f3174=ke){this['instancesDeferred']['delete'](_0x5f3174),this['instancesOptions']['delete'](_0x5f3174),this['instances']['delete'](_0x5f3174);}async['delete'](){const _0x1094c7=Array['from'](this['instances']['values']());await Promise['all']([..._0x1094c7['filter'](_0xeb2da0=>'INTERNAL'in _0xeb2da0)['map'](_0x252f86=>_0x252f86['INTERNAL']['delete']()),..._0x1094c7['filter'](_0x4e2d9b=>'_delete'in _0x4e2d9b)['map'](_0x560a4e=>_0x560a4e['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xea413=ke){return this['instances']['has'](_0xea413);}['getOptions'](_0x113a7c=ke){return this['instancesOptions']['get'](_0x113a7c)||{};}['initialize'](_0x3300c3={}){const {options:_0x17dfcf={}}=_0x3300c3,_0x2f225f=this['normalizeInstanceIdentifier'](_0x3300c3['instanceIdentifier']);if(this['isInitialized'](_0x2f225f))throw Error(this['name']+'('+_0x2f225f+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x511f6c=this['getOrInitializeService']({'instanceIdentifier':_0x2f225f,'options':_0x17dfcf});for(const [_0x4eff27,_0x3273ab]of this['instancesDeferred']['entries']()){const _0x2f8e77=this['normalizeInstanceIdentifier'](_0x4eff27);_0x2f225f===_0x2f8e77&&_0x3273ab['resolve'](_0x511f6c);}return _0x511f6c;}['onInit'](_0x330d4e,_0x34b40d){const _0x595bc0=this['normalizeInstanceIdentifier'](_0x34b40d),_0x818bb9=this['onInitCallbacks']['get'](_0x595bc0)??new Set();_0x818bb9['add'](_0x330d4e),this['onInitCallbacks']['set'](_0x595bc0,_0x818bb9);const _0x45d369=this['instances']['get'](_0x595bc0);return _0x45d369&&_0x330d4e(_0x45d369,_0x595bc0),()=>{_0x818bb9['delete'](_0x330d4e);};}['invokeOnInitCallbacks'](_0x135af8,_0xac997d){const _0x31b7d2=this['onInitCallbacks']['get'](_0xac997d);if(_0x31b7d2){for(const _0x236e78 of _0x31b7d2)try{_0x236e78(_0x135af8,_0xac997d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5b2a68,options:_0x3ad150={}}){let _0xfeb98c=this['instances']['get'](_0x5b2a68);if(!_0xfeb98c&&this['component']&&(_0xfeb98c=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5b2a68),'options':_0x3ad150}),this['instances']['set'](_0x5b2a68,_0xfeb98c),this['instancesOptions']['set'](_0x5b2a68,_0x3ad150),this['invokeOnInitCallbacks'](_0xfeb98c,_0x5b2a68),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5b2a68,_0xfeb98c);}catch{}return _0xfeb98c||null;}['normalizeInstanceIdentifier'](_0x6676fd=ke){return this['component']?this['component']['multipleInstances']?_0x6676fd:ke:_0x6676fd;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x28e006){return _0x28e006===ke?void 0x0:_0x28e006;}function Rc(_0x34c7cd){return _0x34c7cd['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3d6b5b){this['name']=_0x3d6b5b,this['providers']=new Map();}['addComponent'](_0x597f8c){const _0x5a6dda=this['getProvider'](_0x597f8c['name']);if(_0x5a6dda['isComponentSet']())throw new Error('Component\x20'+_0x597f8c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5a6dda['setComponent'](_0x597f8c);}['addOrOverwriteComponent'](_0x33e668){this['getProvider'](_0x33e668['name'])['isComponentSet']()&&this['providers']['delete'](_0x33e668['name']),this['addComponent'](_0x33e668);}['getProvider'](_0x3c7441){if(this['providers']['has'](_0x3c7441))return this['providers']['get'](_0x3c7441);const _0x7635e6=new Sc(_0x3c7441,this);return this['providers']['set'](_0x3c7441,_0x7635e6),_0x7635e6;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xfeb45e){_0xfeb45e[_0xfeb45e['DEBUG']=0x0]='DEBUG',_0xfeb45e[_0xfeb45e['VERBOSE']=0x1]='VERBOSE',_0xfeb45e[_0xfeb45e['INFO']=0x2]='INFO',_0xfeb45e[_0xfeb45e['WARN']=0x3]='WARN',_0xfeb45e[_0xfeb45e['ERROR']=0x4]='ERROR',_0xfeb45e[_0xfeb45e['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x4ab15f,_0x29da23,..._0x2f5a04)=>{if(_0x29da23<_0x4ab15f['logLevel'])return;const _0x567b43=new Date()['toISOString'](),_0xfb1f50=Pc[_0x29da23];if(_0xfb1f50)console[_0xfb1f50]('['+_0x567b43+']\x20\x20'+_0x4ab15f['name']+':',..._0x2f5a04);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x29da23+')');};class xi{constructor(_0xf00a34){this['name']=_0xf00a34,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x10c60b){if(!(_0x10c60b in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x10c60b+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x10c60b;}['setLogLevel'](_0x55afb7){this['_logLevel']=typeof _0x55afb7=='string'?kc[_0x55afb7]:_0x55afb7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x54bb6b){if(typeof _0x54bb6b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x54bb6b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x491b49){this['_userLogHandler']=_0x491b49;}['debug'](..._0x33471f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x33471f),this['_logHandler'](this,T['DEBUG'],..._0x33471f);}['log'](..._0xe63f92){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xe63f92),this['_logHandler'](this,T['VERBOSE'],..._0xe63f92);}['info'](..._0x16a23a){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x16a23a),this['_logHandler'](this,T['INFO'],..._0x16a23a);}['warn'](..._0x4f9908){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4f9908),this['_logHandler'](this,T['WARN'],..._0x4f9908);}['error'](..._0x47adbc){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x47adbc),this['_logHandler'](this,T['ERROR'],..._0x47adbc);}}const Dc=(_0x5a4628,_0x2ec80c)=>_0x2ec80c['some'](_0x55e964=>_0x5a4628 instanceof _0x55e964);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x497e7c){const _0x5f5515=new Promise((_0x4700e8,_0x459515)=>{const _0x3430bd=()=>{_0x497e7c['removeEventListener']('success',_0x2126bb),_0x497e7c['removeEventListener']('error',_0x386293);},_0x2126bb=()=>{_0x4700e8(_e(_0x497e7c['result'])),_0x3430bd();},_0x386293=()=>{_0x459515(_0x497e7c['error']),_0x3430bd();};_0x497e7c['addEventListener']('success',_0x2126bb),_0x497e7c['addEventListener']('error',_0x386293);});return _0x5f5515['then'](_0x26d767=>{_0x26d767 instanceof IDBCursor&&Kr['set'](_0x26d767,_0x497e7c);})['catch'](()=>{}),Fi['set'](_0x5f5515,_0x497e7c),_0x5f5515;}function Fc(_0x4c98cb){if(ui['has'](_0x4c98cb))return;const _0x1227a5=new Promise((_0x292d34,_0x1c3327)=>{const _0x19b63b=()=>{_0x4c98cb['removeEventListener']('complete',_0xd763c2),_0x4c98cb['removeEventListener']('error',_0x1a647e),_0x4c98cb['removeEventListener']('abort',_0x1a647e);},_0xd763c2=()=>{_0x292d34(),_0x19b63b();},_0x1a647e=()=>{_0x1c3327(_0x4c98cb['error']||new DOMException('AbortError','AbortError')),_0x19b63b();};_0x4c98cb['addEventListener']('complete',_0xd763c2),_0x4c98cb['addEventListener']('error',_0x1a647e),_0x4c98cb['addEventListener']('abort',_0x1a647e);});ui['set'](_0x4c98cb,_0x1227a5);}let di={'get'(_0x232b52,_0x5eb7ed,_0x440e09){if(_0x232b52 instanceof IDBTransaction){if(_0x5eb7ed==='done')return ui['get'](_0x232b52);if(_0x5eb7ed==='objectStoreNames')return _0x232b52['objectStoreNames']||Yr['get'](_0x232b52);if(_0x5eb7ed==='store')return _0x440e09['objectStoreNames'][0x1]?void 0x0:_0x440e09['objectStore'](_0x440e09['objectStoreNames'][0x0]);}return _e(_0x232b52[_0x5eb7ed]);},'set'(_0x2101ff,_0x34b465,_0x925092){return _0x2101ff[_0x34b465]=_0x925092,!0x0;},'has'(_0x3ee875,_0x5d5e3d){return _0x3ee875 instanceof IDBTransaction&&(_0x5d5e3d==='done'||_0x5d5e3d==='store')?!0x0:_0x5d5e3d in _0x3ee875;}};function Uc(_0x2709d3){di=_0x2709d3(di);}function Wc(_0x405d7e){return _0x405d7e===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x284540,..._0x17152d){const _0x179992=_0x405d7e['call'](Xn(this),_0x284540,..._0x17152d);return Yr['set'](_0x179992,_0x284540['sort']?_0x284540['sort']():[_0x284540]),_e(_0x179992);}:Lc()['includes'](_0x405d7e)?function(..._0x4ae180){return _0x405d7e['apply'](Xn(this),_0x4ae180),_e(Kr['get'](this));}:function(..._0x42e960){return _e(_0x405d7e['apply'](Xn(this),_0x42e960));};}function Bc(_0x41c408){return typeof _0x41c408=='function'?Wc(_0x41c408):(_0x41c408 instanceof IDBTransaction&&Fc(_0x41c408),Dc(_0x41c408,Mc())?new Proxy(_0x41c408,di):_0x41c408);}function _e(_0x29bb45){if(_0x29bb45 instanceof IDBRequest)return xc(_0x29bb45);if(Jn['has'](_0x29bb45))return Jn['get'](_0x29bb45);const _0x117eea=Bc(_0x29bb45);return _0x117eea!==_0x29bb45&&(Jn['set'](_0x29bb45,_0x117eea),Fi['set'](_0x117eea,_0x29bb45)),_0x117eea;}const Xn=_0x1aae44=>Fi['get'](_0x1aae44);function Vc(_0x3d5980,_0x1e948c,{blocked:_0x273cf3,upgrade:_0x2ab2ed,blocking:_0x48dea2,terminated:_0x2357b0}={}){const _0x124c94=indexedDB['open'](_0x3d5980,_0x1e948c),_0xeff33d=_e(_0x124c94);return _0x2ab2ed&&_0x124c94['addEventListener']('upgradeneeded',_0xa136e0=>{_0x2ab2ed(_e(_0x124c94['result']),_0xa136e0['oldVersion'],_0xa136e0['newVersion'],_e(_0x124c94['transaction']),_0xa136e0);}),_0x273cf3&&_0x124c94['addEventListener']('blocked',_0x525a55=>_0x273cf3(_0x525a55['oldVersion'],_0x525a55['newVersion'],_0x525a55)),_0xeff33d['then'](_0x4e56d1=>{_0x2357b0&&_0x4e56d1['addEventListener']('close',()=>_0x2357b0()),_0x48dea2&&_0x4e56d1['addEventListener']('versionchange',_0x186c6e=>_0x48dea2(_0x186c6e['oldVersion'],_0x186c6e['newVersion'],_0x186c6e));})['catch'](()=>{}),_0xeff33d;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x148737,_0x87ee19){if(!(_0x148737 instanceof IDBDatabase&&!(_0x87ee19 in _0x148737)&&typeof _0x87ee19=='string'))return;if(Zn['get'](_0x87ee19))return Zn['get'](_0x87ee19);const _0xa4d067=_0x87ee19['replace'](/FromIndex$/,''),_0x166705=_0x87ee19!==_0xa4d067,_0x1d0d52=$c['includes'](_0xa4d067);if(!(_0xa4d067 in(_0x166705?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1d0d52||Hc['includes'](_0xa4d067)))return;const _0x9b542b=async function(_0x5eecae,..._0x52a2ff){const _0x51a69a=this['transaction'](_0x5eecae,_0x1d0d52?'readwrite':'readonly');let _0x50965c=_0x51a69a['store'];return _0x166705&&(_0x50965c=_0x50965c['index'](_0x52a2ff['shift']())),(await Promise['all']([_0x50965c[_0xa4d067](..._0x52a2ff),_0x1d0d52&&_0x51a69a['done']]))[0x0];};return Zn['set'](_0x87ee19,_0x9b542b),_0x9b542b;}Uc(_0x12cd3d=>({..._0x12cd3d,'get':(_0x330028,_0x2a6cf8,_0x4a1174)=>Os(_0x330028,_0x2a6cf8)||_0x12cd3d['get'](_0x330028,_0x2a6cf8,_0x4a1174),'has':(_0x159fea,_0x21f778)=>!!Os(_0x159fea,_0x21f778)||_0x12cd3d['has'](_0x159fea,_0x21f778)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x49cfe9){this['container']=_0x49cfe9;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5aa607=>{if(qc(_0x5aa607)){const _0x69c3b=_0x5aa607['getImmediate']();return _0x69c3b['library']+'/'+_0x69c3b['version'];}else return null;})['filter'](_0x338100=>_0x338100)['join']('\x20');}}function qc(_0x8821e7){const _0x584dc4=_0x8821e7['getComponent']();return(_0x584dc4==null?void 0x0:_0x584dc4['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4e117a,_0x3af04f){try{_0x4e117a['container']['addComponent'](_0x3af04f);}catch(_0x5f2faf){re['debug']('Component\x20'+_0x3af04f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4e117a['name'],_0x5f2faf);}}function et(_0x1add43){const _0x41f96a=_0x1add43['name'];if(gi['has'](_0x41f96a))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x41f96a+'.'),!0x1;gi['set'](_0x41f96a,_0x1add43);for(const _0x475ecc of Le['values']())Ms(_0x475ecc,_0x1add43);for(const _0x3288e7 of _i['values']())Ms(_0x3288e7,_0x1add43);return!0x0;}function Ui(_0x447ecd,_0x3a732c){const _0xb5931d=_0x447ecd['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xb5931d&&_0xb5931d['triggerHeartbeat'](),_0x447ecd['container']['getProvider'](_0x3a732c);}function H(_0x5be70a){return _0x5be70a==null?!0x1:_0x5be70a['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x1874d9,_0x12b301,_0x5f4346){this['_isDeleted']=!0x1,this['_options']={..._0x1874d9},this['_config']={..._0x12b301},this['_name']=_0x12b301['name'],this['_automaticDataCollectionEnabled']=_0x12b301['automaticDataCollectionEnabled'],this['_container']=_0x5f4346,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x308411){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x308411;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x442ee9){this['_isDeleted']=_0x442ee9;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5e0f8f,_0x117165={}){let _0x2fab75=_0x5e0f8f;typeof _0x117165!='object'&&(_0x117165={'name':_0x117165});const _0xd524b5={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x117165},_0x854b3e=_0xd524b5['name'];if(typeof _0x854b3e!='string'||!_0x854b3e)throw ge['create']('bad-app-name',{'appName':String(_0x854b3e)});if(_0x2fab75||(_0x2fab75=$r()),!_0x2fab75)throw ge['create']('no-options');const _0x392e0f=Le['get'](_0x854b3e);if(_0x392e0f){if(De(_0x2fab75,_0x392e0f['options'])&&De(_0xd524b5,_0x392e0f['config']))return _0x392e0f;throw ge['create']('duplicate-app',{'appName':_0x854b3e});}const _0x9d3031=new Ac(_0x854b3e);for(const _0x153720 of gi['values']())_0x9d3031['addComponent'](_0x153720);const _0x570a4b=new Il(_0x2fab75,_0xd524b5,_0x9d3031);return Le['set'](_0x854b3e,_0x570a4b),_0x570a4b;}function Qr(_0x316fbd=pi){const _0x458e3f=Le['get'](_0x316fbd);if(!_0x458e3f&&_0x316fbd===pi&&$r())return wl();if(!_0x458e3f)throw ge['create']('no-app',{'appName':_0x316fbd});return _0x458e3f;}function l_(){return Array['from'](Le['values']());}async function h_(_0x1d8149){let _0x4097b4=!0x1;const _0x2d6a47=_0x1d8149['name'];Le['has'](_0x2d6a47)?(_0x4097b4=!0x0,Le['delete'](_0x2d6a47)):_i['has'](_0x2d6a47)&&_0x1d8149['decRefCount']()<=0x0&&(_i['delete'](_0x2d6a47),_0x4097b4=!0x0),_0x4097b4&&(await Promise['all'](_0x1d8149['container']['getProviders']()['map'](_0x1ab34f=>_0x1ab34f['delete']())),_0x1d8149['isDeleted']=!0x0);}function me(_0x9c2bc,_0x1f8209,_0x45c780){let _0x353c5a=vl[_0x9c2bc]??_0x9c2bc;_0x45c780&&(_0x353c5a+='-'+_0x45c780);const _0x41dde5=_0x353c5a['match'](/\s|\//),_0x1c7f5c=_0x1f8209['match'](/\s|\//);if(_0x41dde5||_0x1c7f5c){const _0x5d4e49=['Unable\x20to\x20register\x20library\x20\x22'+_0x353c5a+'\x22\x20with\x20version\x20\x22'+_0x1f8209+'\x22:'];_0x41dde5&&_0x5d4e49['push']('library\x20name\x20\x22'+_0x353c5a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x41dde5&&_0x1c7f5c&&_0x5d4e49['push']('and'),_0x1c7f5c&&_0x5d4e49['push']('version\x20name\x20\x22'+_0x1f8209+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5d4e49['join']('\x20'));return;}et(new Me(_0x353c5a+'-version',()=>({'library':_0x353c5a,'version':_0x1f8209}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1b8012,_0x1075e3)=>{switch(_0x1075e3){case 0x0:try{_0x1b8012['createObjectStore'](Rt);}catch(_0x1b615f){console['warn'](_0x1b615f);}}}})['catch'](_0x5e5892=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5e5892['message']});})),ei;}async function Sl(_0x347f9e){try{const _0x30bea6=(await Jr())['transaction'](Rt),_0x3c291b=await _0x30bea6['objectStore'](Rt)['get'](Xr(_0x347f9e));return await _0x30bea6['done'],_0x3c291b;}catch(_0x1f9df2){if(_0x1f9df2 instanceof Se)re['warn'](_0x1f9df2['message']);else{const _0x14082b=ge['create']('idb-get',{'originalErrorMessage':_0x1f9df2==null?void 0x0:_0x1f9df2['message']});re['warn'](_0x14082b['message']);}}}async function Ls(_0x1d499f,_0x108b3b){try{const _0x57fba0=(await Jr())['transaction'](Rt,'readwrite');await _0x57fba0['objectStore'](Rt)['put'](_0x108b3b,Xr(_0x1d499f)),await _0x57fba0['done'];}catch(_0x219423){if(_0x219423 instanceof Se)re['warn'](_0x219423['message']);else{const _0x9d8a2=ge['create']('idb-set',{'originalErrorMessage':_0x219423==null?void 0x0:_0x219423['message']});re['warn'](_0x9d8a2['message']);}}}function Xr(_0x4aa8cc){return _0x4aa8cc['name']+'!'+_0x4aa8cc['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x292c77){this['container']=_0x292c77,this['_heartbeatsCache']=null;const _0x4f9e74=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x4f9e74),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x498f1c=>(this['_heartbeatsCache']=_0x498f1c,_0x498f1c));}async['triggerHeartbeat'](){var _0x3d1eac,_0x3039bc;try{const _0x2e59b2=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x42a387=xs();if(((_0x3d1eac=this['_heartbeatsCache'])==null?void 0x0:_0x3d1eac['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3039bc=this['_heartbeatsCache'])==null?void 0x0:_0x3039bc['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x42a387||this['_heartbeatsCache']['heartbeats']['some'](_0x335d2b=>_0x335d2b['date']===_0x42a387))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x42a387,'agent':_0x2e59b2}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1bda15=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1bda15,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xba3565){re['warn'](_0xba3565);}}async['getHeartbeatsHeader'](){var _0x5237f4;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5237f4=this['_heartbeatsCache'])==null?void 0x0:_0x5237f4['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x39cdc4=xs(),{heartbeatsToSend:_0x384f28,unsentEntries:_0x5c5403}=kl(this['_heartbeatsCache']['heartbeats']),_0x393848=an(JSON['stringify']({'version':0x2,'heartbeats':_0x384f28}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x39cdc4,_0x5c5403['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5c5403,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x393848;}catch(_0x2da661){return re['warn'](_0x2da661),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x39d59b,_0x2a5783=bl){const _0x578ba7=[];let _0x19e750=_0x39d59b['slice']();for(const _0x44d271 of _0x39d59b){const _0x13d429=_0x578ba7['find'](_0x10340a=>_0x10340a['agent']===_0x44d271['agent']);if(_0x13d429){if(_0x13d429['dates']['push'](_0x44d271['date']),Fs(_0x578ba7)>_0x2a5783){_0x13d429['dates']['pop']();break;}}else{if(_0x578ba7['push']({'agent':_0x44d271['agent'],'dates':[_0x44d271['date']]}),Fs(_0x578ba7)>_0x2a5783){_0x578ba7['pop']();break;}}_0x19e750=_0x19e750['slice'](0x1);}return{'heartbeatsToSend':_0x578ba7,'unsentEntries':_0x19e750};}class Nl{constructor(_0x48d80e){this['app']=_0x48d80e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x25591c=await Sl(this['app']);return _0x25591c!=null&&_0x25591c['heartbeats']?_0x25591c:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x14492d){if(await this['_canUseIndexedDBPromise']){const _0x2c3b26=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x14492d['lastSentHeartbeatDate']??_0x2c3b26['lastSentHeartbeatDate'],'heartbeats':_0x14492d['heartbeats']});}else return;}async['add'](_0x3c4028){if(await this['_canUseIndexedDBPromise']){const _0x2430f3=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3c4028['lastSentHeartbeatDate']??_0x2430f3['lastSentHeartbeatDate'],'heartbeats':[..._0x2430f3['heartbeats'],..._0x3c4028['heartbeats']]});}else return;}}function Fs(_0x1f7b81){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1f7b81}))['length'];}function Pl(_0x570c7c){if(_0x570c7c['length']===0x0)return-0x1;let _0x5b5271=0x0,_0x27481f=_0x570c7c[0x0]['date'];for(let _0x341112=0x1;_0x341112<_0x570c7c['length'];_0x341112++)_0x570c7c[_0x341112]['date']<_0x27481f&&(_0x27481f=_0x570c7c[_0x341112]['date'],_0x5b5271=_0x341112);return _0x5b5271;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x2039a9){et(new Me('platform-logger',_0x3fed80=>new Gc(_0x3fed80),'PRIVATE')),et(new Me('heartbeat',_0x5225dc=>new Al(_0x5225dc),'PRIVATE')),me(fi,Ds,_0x2039a9),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x5e7aee){Zr=_0x5e7aee;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x30d938){this['domStorage_']=_0x30d938,this['prefix_']='firebase:';}['set'](_0x5e4d9c,_0x311ef4){_0x311ef4==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5e4d9c)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5e4d9c),O(_0x311ef4));}['get'](_0x87203c){const _0x4216c9=this['domStorage_']['getItem'](this['prefixedName_'](_0x87203c));return _0x4216c9==null?null:bt(_0x4216c9);}['remove'](_0x178c25){this['domStorage_']['removeItem'](this['prefixedName_'](_0x178c25));}['prefixedName_'](_0x5dcd5b){return this['prefix_']+_0x5dcd5b;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x40d995,_0x4d6efb){_0x4d6efb==null?delete this['cache_'][_0x40d995]:this['cache_'][_0x40d995]=_0x4d6efb;}['get'](_0x5eafd1){return Y(this['cache_'],_0x5eafd1)?this['cache_'][_0x5eafd1]:null;}['remove'](_0x4683a1){delete this['cache_'][_0x4683a1];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5d322f){try{if(typeof window<'u'&&typeof window[_0x5d322f]<'u'){const _0x1ae271=window[_0x5d322f];return _0x1ae271['setItem']('firebase:sentinel','cache'),_0x1ae271['removeItem']('firebase:sentinel'),new xl(_0x1ae271);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x54ef53=0x1;return function(){return _0x54ef53++;};}()),no=function(_0x3b2924){const _0x21efa5=Tc(_0x3b2924),_0x427869=new Ec();_0x427869['update'](_0x21efa5);const _0x5aeca5=_0x427869['digest']();return Di['encodeByteArray'](_0x5aeca5);},Bt=function(..._0x16ea45){let _0x1361de='';for(let _0x2ad7b3=0x0;_0x2ad7b3<_0x16ea45['length'];_0x2ad7b3++){const _0x2abe84=_0x16ea45[_0x2ad7b3];Array['isArray'](_0x2abe84)||_0x2abe84&&typeof _0x2abe84=='object'&&typeof _0x2abe84['length']=='number'?_0x1361de+=Bt['apply'](null,_0x2abe84):typeof _0x2abe84=='object'?_0x1361de+=O(_0x2abe84):_0x1361de+=_0x2abe84,_0x1361de+='\x20';}return _0x1361de;};let Et=null,Vs=!0x0;const Wl=function(_0x1e6e10,_0x5c7b69){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x15f1d5){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3b628e=Bt['apply'](null,_0x15f1d5);Et(_0x3b628e);}},Vt=function(_0x59226a){return function(..._0x1224d5){L(_0x59226a,..._0x1224d5);};},mi=function(..._0x2f6930){const _0x2b65cd='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x2f6930);Qe['error'](_0x2b65cd);},oe=function(..._0x4a465c){const _0x56b8fe='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4a465c);throw Qe['error'](_0x56b8fe),new Error(_0x56b8fe);},U=function(..._0x47f978){const _0x221055='FIREBASE\x20WARNING:\x20'+Bt(..._0x47f978);Qe['warn'](_0x221055);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x3a4fb0){return typeof _0x3a4fb0=='number'&&(_0x3a4fb0!==_0x3a4fb0||_0x3a4fb0===Number['POSITIVE_INFINITY']||_0x3a4fb0===Number['NEGATIVE_INFINITY']);},Vl=function(_0x474246){if(document['readyState']==='complete')_0x474246();else{let _0x5298be=!0x1;const _0x3311e0=function(){if(!document['body']){setTimeout(_0x3311e0,Math['floor'](0xa));return;}_0x5298be||(_0x5298be=!0x0,_0x474246());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3311e0,!0x1),window['addEventListener']('load',_0x3311e0,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3311e0();}),window['attachEvent']('onload',_0x3311e0));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2b8521,_0x11bc39){if(_0x2b8521===_0x11bc39)return 0x0;if(_0x2b8521===xe||_0x11bc39===Ie)return-0x1;if(_0x11bc39===xe||_0x2b8521===Ie)return 0x1;{const _0x5c241c=Hs(_0x2b8521),_0x254c8b=Hs(_0x11bc39);return _0x5c241c!==null?_0x254c8b!==null?_0x5c241c-_0x254c8b===0x0?_0x2b8521['length']-_0x11bc39['length']:_0x5c241c-_0x254c8b:-0x1:_0x254c8b!==null?0x1:_0x2b8521<_0x11bc39?-0x1:0x1;}},Hl=function(_0x1a898c,_0x469af1){return _0x1a898c===_0x469af1?0x0:_0x1a898c<_0x469af1?-0x1:0x1;},pt=function(_0x55ddfe,_0x497544){if(_0x497544&&_0x55ddfe in _0x497544)return _0x497544[_0x55ddfe];throw new Error('Missing\x20required\x20key\x20('+_0x55ddfe+')\x20in\x20object:\x20'+O(_0x497544));},Bi=function(_0x43dbf8){if(typeof _0x43dbf8!='object'||_0x43dbf8===null)return O(_0x43dbf8);const _0x1be23b=[];for(const _0x35ad0d in _0x43dbf8)_0x1be23b['push'](_0x35ad0d);_0x1be23b['sort']();let _0x25f3af='{';for(let _0x50a328=0x0;_0x50a328<_0x1be23b['length'];_0x50a328++)_0x50a328!==0x0&&(_0x25f3af+=','),_0x25f3af+=O(_0x1be23b[_0x50a328]),_0x25f3af+=':',_0x25f3af+=Bi(_0x43dbf8[_0x1be23b[_0x50a328]]);return _0x25f3af+='}',_0x25f3af;},io=function(_0x39549f,_0x4fa4fe){const _0x3c78fe=_0x39549f['length'];if(_0x3c78fe<=_0x4fa4fe)return[_0x39549f];const _0x1e1d97=[];for(let _0x5165e9=0x0;_0x5165e9<_0x3c78fe;_0x5165e9+=_0x4fa4fe)_0x5165e9+_0x4fa4fe>_0x3c78fe?_0x1e1d97['push'](_0x39549f['substring'](_0x5165e9,_0x3c78fe)):_0x1e1d97['push'](_0x39549f['substring'](_0x5165e9,_0x5165e9+_0x4fa4fe));return _0x1e1d97;};function x(_0x151a47,_0x59c58a){for(const _0x5e83f5 in _0x151a47)_0x151a47['hasOwnProperty'](_0x5e83f5)&&_0x59c58a(_0x5e83f5,_0x151a47[_0x5e83f5]);}const so=function(_0x3bfaf6){f(!Wi(_0x3bfaf6),'Invalid\x20JSON\x20number');const _0xb5e8bf=0xb,_0x295e62=0x34,_0x4f751d=(0x1<<_0xb5e8bf-0x1)-0x1;let _0x4a5713,_0x191c44,_0x5a84cc,_0x1fe05d,_0x52a207;_0x3bfaf6===0x0?(_0x191c44=0x0,_0x5a84cc=0x0,_0x4a5713=0x1/_0x3bfaf6===-0x1/0x0?0x1:0x0):(_0x4a5713=_0x3bfaf6<0x0,_0x3bfaf6=Math['abs'](_0x3bfaf6),_0x3bfaf6>=Math['pow'](0x2,0x1-_0x4f751d)?(_0x1fe05d=Math['min'](Math['floor'](Math['log'](_0x3bfaf6)/Math['LN2']),_0x4f751d),_0x191c44=_0x1fe05d+_0x4f751d,_0x5a84cc=Math['round'](_0x3bfaf6*Math['pow'](0x2,_0x295e62-_0x1fe05d)-Math['pow'](0x2,_0x295e62))):(_0x191c44=0x0,_0x5a84cc=Math['round'](_0x3bfaf6/Math['pow'](0x2,0x1-_0x4f751d-_0x295e62))));const _0x562111=[];for(_0x52a207=_0x295e62;_0x52a207;_0x52a207-=0x1)_0x562111['push'](_0x5a84cc%0x2?0x1:0x0),_0x5a84cc=Math['floor'](_0x5a84cc/0x2);for(_0x52a207=_0xb5e8bf;_0x52a207;_0x52a207-=0x1)_0x562111['push'](_0x191c44%0x2?0x1:0x0),_0x191c44=Math['floor'](_0x191c44/0x2);_0x562111['push'](_0x4a5713?0x1:0x0),_0x562111['reverse']();const _0xb13707=_0x562111['join']('');let _0x210f24='';for(_0x52a207=0x0;_0x52a207<0x40;_0x52a207+=0x8){let _0x27d03a=parseInt(_0xb13707['substr'](_0x52a207,0x8),0x2)['toString'](0x10);_0x27d03a['length']===0x1&&(_0x27d03a='0'+_0x27d03a),_0x210f24=_0x210f24+_0x27d03a;}return _0x210f24['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2d55f9,_0x424b24){let _0x129195='Unknown\x20Error';_0x2d55f9==='too_big'?_0x129195='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2d55f9==='permission_denied'?_0x129195='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2d55f9==='unavailable'&&(_0x129195='The\x20service\x20is\x20unavailable');const _0x2ed8db=new Error(_0x2d55f9+'\x20at\x20'+_0x424b24['_path']['toString']()+':\x20'+_0x129195);return _0x2ed8db['code']=_0x2d55f9['toUpperCase'](),_0x2ed8db;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x478b53){if(zl['test'](_0x478b53)){const _0x36adcd=Number(_0x478b53);if(_0x36adcd>=jl&&_0x36adcd<=Kl)return _0x36adcd;}return null;},lt=function(_0x1af901){try{_0x1af901();}catch(_0x3c18a0){setTimeout(()=>{const _0x4e2ef6=_0x3c18a0['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4e2ef6),_0x3c18a0;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x1f0217,_0x359297){const _0x521ec7=setTimeout(_0x1f0217,_0x359297);return typeof _0x521ec7=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x521ec7):typeof _0x521ec7=='object'&&_0x521ec7['unref']&&_0x521ec7['unref'](),_0x521ec7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x33f1df,_0x36f8c0){this['appCheckProvider']=_0x36f8c0,this['appName']=_0x33f1df['name'],H(_0x33f1df)&&_0x33f1df['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x33f1df['settings']['appCheckToken']),this['appCheck']=_0x36f8c0==null?void 0x0:_0x36f8c0['getImmediate']({'optional':!0x0}),this['appCheck']||_0x36f8c0==null||_0x36f8c0['get']()['then'](_0x1962fe=>this['appCheck']=_0x1962fe);}['getToken'](_0x594a73){if(this['serverAppAppCheckToken']){if(_0x594a73)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x594a73):new Promise((_0x4638b1,_0x4402a5)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x594a73)['then'](_0x4638b1,_0x4402a5):_0x4638b1(null);},0x0);});}['addTokenChangeListener'](_0x12357){var _0x3722aa;(_0x3722aa=this['appCheckProvider'])==null||_0x3722aa['get']()['then'](_0x35bb44=>_0x35bb44['addTokenListener'](_0x12357));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x404534,_0x38101e,_0x3b1f3a){this['appName_']=_0x404534,this['firebaseOptions_']=_0x38101e,this['authProvider_']=_0x3b1f3a,this['auth_']=null,this['auth_']=_0x3b1f3a['getImmediate']({'optional':!0x0}),this['auth_']||_0x3b1f3a['onInit'](_0x11abcf=>this['auth_']=_0x11abcf);}['getToken'](_0x2b673a){return this['auth_']?this['auth_']['getToken'](_0x2b673a)['catch'](_0x2413e3=>_0x2413e3&&_0x2413e3['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2413e3)):new Promise((_0x5a30e5,_0x21e6b0)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2b673a)['then'](_0x5a30e5,_0x21e6b0):_0x5a30e5(null);},0x0);});}['addTokenChangeListener'](_0x148c3d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x148c3d):this['authProvider_']['get']()['then'](_0x35691a=>_0x35691a['addAuthTokenListener'](_0x148c3d));}['removeTokenChangeListener'](_0x54cef8){this['authProvider_']['get']()['then'](_0x119bdc=>_0x119bdc['removeAuthTokenListener'](_0x54cef8));}['notifyForInvalidToken'](){let _0x1b3440='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1b3440+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1b3440+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1b3440+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1b3440);}}class tn{constructor(_0x3139bb){this['accessToken']=_0x3139bb;}['getToken'](_0x28d24f){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x45de3c){_0x45de3c(this['accessToken']);}['removeTokenChangeListener'](_0x1a0498){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x5467c0,_0x452d17,_0xc9c4ec,_0x453706,_0x9912a2=!0x1,_0x5c673e='',_0x4802f0=!0x1,_0x3490cb=!0x1,_0x3ff39a=null){this['secure']=_0x452d17,this['namespace']=_0xc9c4ec,this['webSocketOnly']=_0x453706,this['nodeAdmin']=_0x9912a2,this['persistenceKey']=_0x5c673e,this['includeNamespaceInQueryParams']=_0x4802f0,this['isUsingEmulator']=_0x3490cb,this['emulatorOptions']=_0x3ff39a,this['_host']=_0x5467c0['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x5467c0)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x364c22){_0x364c22!==this['internalHost']&&(this['internalHost']=_0x364c22,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4917e6=this['toURLString']();return this['persistenceKey']&&(_0x4917e6+='<'+this['persistenceKey']+'>'),_0x4917e6;}['toURLString'](){const _0x41c91f=this['secure']?'https://':'http://',_0x4016e5=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x41c91f+this['host']+'/'+_0x4016e5;}}function Xl(_0x463cd5){return _0x463cd5['host']!==_0x463cd5['internalHost']||_0x463cd5['isCustomHost']()||_0x463cd5['includeNamespaceInQueryParams'];}function go(_0x4fe2f8,_0x182590,_0x475595){f(typeof _0x182590=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x475595=='object','typeof\x20params\x20must\x20==\x20object');let _0x412dc7;if(_0x182590===fo)_0x412dc7=(_0x4fe2f8['secure']?'wss://':'ws://')+_0x4fe2f8['internalHost']+'/.ws?';else{if(_0x182590===po)_0x412dc7=(_0x4fe2f8['secure']?'https://':'http://')+_0x4fe2f8['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x182590);}Xl(_0x4fe2f8)&&(_0x475595['ns']=_0x4fe2f8['namespace']);const _0x31a5f7=[];return x(_0x475595,(_0x23bc3b,_0x1e4d30)=>{_0x31a5f7['push'](_0x23bc3b+'='+_0x1e4d30);}),_0x412dc7+_0x31a5f7['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x3ca49a,_0x147505=0x1){Y(this['counters_'],_0x3ca49a)||(this['counters_'][_0x3ca49a]=0x0),this['counters_'][_0x3ca49a]+=_0x147505;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x200e8b){const _0x2076a7=_0x200e8b['toString']();return ti[_0x2076a7]||(ti[_0x2076a7]=new Zl()),ti[_0x2076a7];}function eh(_0x3e1005,_0x3db890){const _0x51ab1f=_0x3e1005['toString']();return ni[_0x51ab1f]||(ni[_0x51ab1f]=_0x3db890()),ni[_0x51ab1f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2247dd){this['onMessage_']=_0x2247dd,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2b5809,_0x1349e4){this['closeAfterResponse']=_0x2b5809,this['onClose']=_0x1349e4,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x55b6eb,_0x4e2e9d){for(this['pendingResponses'][_0x55b6eb]=_0x4e2e9d;this['pendingResponses'][this['currentResponseNum']];){const _0x1e274b=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x25f52b=0x0;_0x25f52b<_0x1e274b['length'];++_0x25f52b)_0x1e274b[_0x25f52b]&&lt(()=>{this['onMessage_'](_0x1e274b[_0x25f52b]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x337307,_0x56c7eb,_0x5f2ed6,_0x228879,_0x3fbe62,_0x3ae387,_0x5ab2bf){this['connId']=_0x337307,this['repoInfo']=_0x56c7eb,this['applicationId']=_0x5f2ed6,this['appCheckToken']=_0x228879,this['authToken']=_0x3fbe62,this['transportSessionId']=_0x3ae387,this['lastSessionId']=_0x5ab2bf,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x337307),this['stats_']=Hi(_0x56c7eb),this['urlFn']=_0x3d20db=>(this['appCheckToken']&&(_0x3d20db[yi]=this['appCheckToken']),go(_0x56c7eb,po,_0x3d20db));}['open'](_0x2c7033,_0x577b99){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x577b99,this['myPacketOrderer']=new th(_0x2c7033),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x50e4d3)=>{const [_0x4e7c0d,_0x1ff0a9,_0x28f8d7,_0x558091,_0x4b2408]=_0x50e4d3;if(this['incrementIncomingBytes_'](_0x50e4d3),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4e7c0d===$s)this['id']=_0x1ff0a9,this['password']=_0x28f8d7;else{if(_0x4e7c0d===nh)_0x1ff0a9?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1ff0a9,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4e7c0d);}}},(..._0xa52289)=>{const [_0x46a731,_0x5963de]=_0xa52289;this['incrementIncomingBytes_'](_0xa52289),this['myPacketOrderer']['handleResponse'](_0x46a731,_0x5963de);},()=>{this['onClosed_']();},this['urlFn']);const _0x14657a={};_0x14657a[$s]='t',_0x14657a[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x14657a[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x14657a[ro]=Vi,this['transportSessionId']&&(_0x14657a[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x14657a[ho]=this['lastSessionId']),this['applicationId']&&(_0x14657a[uo]=this['applicationId']),this['appCheckToken']&&(_0x14657a[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x14657a[ao]=co);const _0x5408fb=this['urlFn'](_0x14657a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5408fb),this['scriptTagHolder']['addTag'](_0x5408fb,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x34aa74){const _0x9a73ca=O(_0x34aa74);this['bytesSent']+=_0x9a73ca['length'],this['stats_']['incrementCounter']('bytes_sent',_0x9a73ca['length']);const _0x134a14=Br(_0x9a73ca),_0x3afd73=io(_0x134a14,hh);for(let _0x47d47b=0x0;_0x47d47b<_0x3afd73['length'];_0x47d47b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3afd73['length'],_0x3afd73[_0x47d47b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x22c9d8,_0x4f6a5e){this['myDisconnFrame']=document['createElement']('iframe');const _0x39b81e={};_0x39b81e[lh]='t',_0x39b81e[mo]=_0x22c9d8,_0x39b81e[yo]=_0x4f6a5e,this['myDisconnFrame']['src']=this['urlFn'](_0x39b81e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x17c96e){const _0x12c47c=O(_0x17c96e)['length'];this['bytesReceived']+=_0x12c47c,this['stats_']['incrementCounter']('bytes_received',_0x12c47c);}}class $i{constructor(_0x368296,_0x5ae16b,_0x47cbd5,_0xb4577d){this['onDisconnect']=_0x47cbd5,this['urlFn']=_0xb4577d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x368296,window[sh+this['uniqueCallbackIdentifier']]=_0x5ae16b,this['myIFrame']=$i['createIFrame_']();let _0x5e706f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5e706f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x581657='<html><body>'+_0x5e706f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x581657),this['myIFrame']['doc']['close']();}catch(_0x3b49c0){L('frame\x20writing\x20exception'),_0x3b49c0['stack']&&L(_0x3b49c0['stack']),L(_0x3b49c0);}}}static['createIFrame_'](){const _0x42c5eb=document['createElement']('iframe');if(_0x42c5eb['style']['display']='none',document['body']){document['body']['appendChild'](_0x42c5eb);try{_0x42c5eb['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x67fdbf=document['domain'];_0x42c5eb['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x67fdbf+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x42c5eb['contentDocument']?_0x42c5eb['doc']=_0x42c5eb['contentDocument']:_0x42c5eb['contentWindow']?_0x42c5eb['doc']=_0x42c5eb['contentWindow']['document']:_0x42c5eb['document']&&(_0x42c5eb['doc']=_0x42c5eb['document']),_0x42c5eb;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3e508e=this['onDisconnect'];_0x3e508e&&(this['onDisconnect']=null,_0x3e508e());}['startLongPoll'](_0x1a89cb,_0x4f155f){for(this['myID']=_0x1a89cb,this['myPW']=_0x4f155f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x22b357={};_0x22b357[mo]=this['myID'],_0x22b357[yo]=this['myPW'],_0x22b357[vo]=this['currentSerial'];let _0x586048=this['urlFn'](_0x22b357),_0x3c89c9='',_0x14bbd8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x3c89c9['length']<=Eo;){const _0x11f096=this['pendingSegs']['shift']();_0x3c89c9=_0x3c89c9+'&'+oh+_0x14bbd8+'='+_0x11f096['seg']+'&'+ah+_0x14bbd8+'='+_0x11f096['ts']+'&'+ch+_0x14bbd8+'='+_0x11f096['d'],_0x14bbd8++;}return _0x586048=_0x586048+_0x3c89c9,this['addLongPollTag_'](_0x586048,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2d8900,_0x9211a2,_0x2b7ffd){this['pendingSegs']['push']({'seg':_0x2d8900,'ts':_0x9211a2,'d':_0x2b7ffd}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x242d0f,_0x590032){this['outstandingRequests']['add'](_0x590032);const _0x10892b=()=>{this['outstandingRequests']['delete'](_0x590032),this['newRequest_']();},_0xcb4a5b=setTimeout(_0x10892b,Math['floor'](uh)),_0x827e09=()=>{clearTimeout(_0xcb4a5b),_0x10892b();};this['addTag'](_0x242d0f,_0x827e09);}['addTag'](_0x13beee,_0x12f9ac){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x25158e=this['myIFrame']['doc']['createElement']('script');_0x25158e['type']='text/javascript',_0x25158e['async']=!0x0,_0x25158e['src']=_0x13beee,_0x25158e['onload']=_0x25158e['onreadystatechange']=function(){const _0xe50de5=_0x25158e['readyState'];(!_0xe50de5||_0xe50de5==='loaded'||_0xe50de5==='complete')&&(_0x25158e['onload']=_0x25158e['onreadystatechange']=null,_0x25158e['parentNode']&&_0x25158e['parentNode']['removeChild'](_0x25158e),_0x12f9ac());},_0x25158e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x13beee),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x25158e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1bf047,_0x261358,_0x323be3,_0x4a1326,_0x1a4304,_0x2d2eb3,_0x35770f){this['connId']=_0x1bf047,this['applicationId']=_0x323be3,this['appCheckToken']=_0x4a1326,this['authToken']=_0x1a4304,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x261358),this['connURL']=G['connectionURL_'](_0x261358,_0x2d2eb3,_0x35770f,_0x4a1326,_0x323be3),this['nodeAdmin']=_0x261358['nodeAdmin'];}static['connectionURL_'](_0x4154c7,_0x276da1,_0x2e3603,_0x3b5447,_0x546e26){const _0x162b74={};return _0x162b74[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x162b74[ao]=co),_0x276da1&&(_0x162b74[oo]=_0x276da1),_0x2e3603&&(_0x162b74[ho]=_0x2e3603),_0x3b5447&&(_0x162b74[yi]=_0x3b5447),_0x546e26&&(_0x162b74[uo]=_0x546e26),go(_0x4154c7,fo,_0x162b74);}['open'](_0x16d581,_0x144a39){this['onDisconnect']=_0x144a39,this['onMessage']=_0x16d581,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x52f68b;dc(),this['mySock']=new hn(this['connURL'],[],_0x52f68b);}catch(_0xe4f19a){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xfb878c=_0xe4f19a['message']||_0xe4f19a['data'];_0xfb878c&&this['log_'](_0xfb878c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1d92b6=>{this['handleIncomingFrame'](_0x1d92b6);},this['mySock']['onerror']=_0x24f0f9=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x42203f=_0x24f0f9['message']||_0x24f0f9['data'];_0x42203f&&this['log_'](_0x42203f),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2e08ae=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x543f7a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x365319=navigator['userAgent']['match'](_0x543f7a);_0x365319&&_0x365319['length']>0x1&&parseFloat(_0x365319[0x1])<4.4&&(_0x2e08ae=!0x0);}return!_0x2e08ae&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2b6d92){if(this['frames']['push'](_0x2b6d92),this['frames']['length']===this['totalFrames']){const _0x51588d=this['frames']['join']('');this['frames']=null;const _0x211bef=bt(_0x51588d);this['onMessage'](_0x211bef);}}['handleNewFrameCount_'](_0x4f981a){this['totalFrames']=_0x4f981a,this['frames']=[];}['extractFrameCount_'](_0x289354){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x289354['length']<=0x6){const _0x4371c4=Number(_0x289354);if(!isNaN(_0x4371c4))return this['handleNewFrameCount_'](_0x4371c4),null;}return this['handleNewFrameCount_'](0x1),_0x289354;}['handleIncomingFrame'](_0x3182b3){if(this['mySock']===null)return;const _0x583294=_0x3182b3['data'];if(this['bytesReceived']+=_0x583294['length'],this['stats_']['incrementCounter']('bytes_received',_0x583294['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x583294);else{const _0x127f1e=this['extractFrameCount_'](_0x583294);_0x127f1e!==null&&this['appendFrame_'](_0x127f1e);}}['send'](_0x56dbeb){this['resetKeepAlive']();const _0x343ff6=O(_0x56dbeb);this['bytesSent']+=_0x343ff6['length'],this['stats_']['incrementCounter']('bytes_sent',_0x343ff6['length']);const _0x13ab80=io(_0x343ff6,fh);_0x13ab80['length']>0x1&&this['sendString_'](String(_0x13ab80['length']));for(let _0x2f9f21=0x0;_0x2f9f21<_0x13ab80['length'];_0x2f9f21++)this['sendString_'](_0x13ab80[_0x2f9f21]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x323978){try{this['mySock']['send'](_0x323978);}catch(_0x2d5aae){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2d5aae['message']||_0x2d5aae['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x851d2){this['initTransports_'](_0x851d2);}['initTransports_'](_0x5b3557){const _0x188ebe=G&&G['isAvailable']();let _0x1cfb61=_0x188ebe&&!G['previouslyFailed']();if(_0x5b3557['webSocketOnly']&&(_0x188ebe||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1cfb61=!0x0),_0x1cfb61)this['transports_']=[G];else{const _0x1e7f14=this['transports_']=[];for(const _0x173d2b of At['ALL_TRANSPORTS'])_0x173d2b&&_0x173d2b['isAvailable']()&&_0x1e7f14['push'](_0x173d2b);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x10b61f,_0xe27743,_0x233dd2,_0x969ee1,_0x112ee3,_0x19e075,_0x28bc6b,_0x5eafe0,_0x316b2d,_0x2d23d1){this['id']=_0x10b61f,this['repoInfo_']=_0xe27743,this['applicationId_']=_0x233dd2,this['appCheckToken_']=_0x969ee1,this['authToken_']=_0x112ee3,this['onMessage_']=_0x19e075,this['onReady_']=_0x28bc6b,this['onDisconnect_']=_0x5eafe0,this['onKill_']=_0x316b2d,this['lastSessionId']=_0x2d23d1,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0xe27743),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1aa2cc=this['transportManager_']['initialTransport']();this['conn_']=new _0x1aa2cc(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1aa2cc['responsesRequiredToBeHealthy']||0x0;const _0x24e7e4=this['connReceiver_'](this['conn_']),_0x49c225=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x24e7e4,_0x49c225);},Math['floor'](0x0));const _0x41afcb=_0x1aa2cc['healthyTimeout']||0x0;_0x41afcb>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x41afcb)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2b51a5){return _0x1db426=>{_0x2b51a5===this['conn_']?this['onConnectionLost_'](_0x1db426):_0x2b51a5===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x6fd644){return _0x290d95=>{this['state_']!==0x2&&(_0x6fd644===this['rx_']?this['onPrimaryMessageReceived_'](_0x290d95):_0x6fd644===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x290d95):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2ab07e){const _0x21d1e8={'t':'d','d':_0x2ab07e};this['sendData_'](_0x21d1e8);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x13fad4){if(ii in _0x13fad4){const _0x1f7d25=_0x13fad4[ii];_0x1f7d25===js?this['upgradeIfSecondaryHealthy_']():_0x1f7d25===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1f7d25===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x16c7fe){const _0x42a3e7=pt('t',_0x16c7fe),_0x7a5d18=pt('d',_0x16c7fe);if(_0x42a3e7==='c')this['onSecondaryControl_'](_0x7a5d18);else{if(_0x42a3e7==='d')this['pendingDataMessages']['push'](_0x7a5d18);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x42a3e7);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xcae788){const _0x47fb4b=pt('t',_0xcae788),_0x384715=pt('d',_0xcae788);_0x47fb4b==='c'?this['onControl_'](_0x384715):_0x47fb4b==='d'&&this['onDataMessage_'](_0x384715);}['onDataMessage_'](_0x102a21){this['onPrimaryResponse_'](),this['onMessage_'](_0x102a21);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x71e927){const _0x14e145=pt(ii,_0x71e927);if(Gs in _0x71e927){const _0x19ccd2=_0x71e927[Gs];if(_0x14e145===Ih){const _0x579570={..._0x19ccd2};this['repoInfo_']['isUsingEmulator']&&(_0x579570['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x579570);}else{if(_0x14e145===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x258538=0x0;_0x258538<this['pendingDataMessages']['length'];++_0x258538)this['onDataMessage_'](this['pendingDataMessages'][_0x258538]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x14e145===vh?this['onConnectionShutdown_'](_0x19ccd2):_0x14e145===qs?this['onReset_'](_0x19ccd2):_0x14e145===Eh?mi('Server\x20Error:\x20'+_0x19ccd2):_0x14e145===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x14e145);}}}['onHandshake_'](_0x3749bd){const _0x507ff1=_0x3749bd['ts'],_0xa5139d=_0x3749bd['v'],_0x117d90=_0x3749bd['h'];this['sessionId']=_0x3749bd['s'],this['repoInfo_']['host']=_0x117d90,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x507ff1),Vi!==_0xa5139d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xeb7c65=this['transportManager_']['upgradeTransport']();_0xeb7c65&&this['startUpgrade_'](_0xeb7c65);}['startUpgrade_'](_0x3f8b96){this['secondaryConn_']=new _0x3f8b96(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3f8b96['responsesRequiredToBeHealthy']||0x0;const _0x3d343c=this['connReceiver_'](this['secondaryConn_']),_0x1f831b=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3d343c,_0x1f831b),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x4dc51d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4dc51d),this['repoInfo_']['host']=_0x4dc51d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x43188d,_0x480ed0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x43188d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x480ed0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2232fb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2232fb||this['rx_']===_0x2232fb)&&this['close']();}['onConnectionLost_'](_0x1a0362){this['conn_']=null,!_0x1a0362&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x400793){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x400793),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x78142a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x78142a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x36990c,_0x2d987d,_0x9e71bb,_0x3fa949){}['merge'](_0x21ec24,_0x4e82d5,_0x3cad0b,_0x551ef0){}['refreshAuthToken'](_0x3ec46d){}['refreshAppCheckToken'](_0x42eb53){}['onDisconnectPut'](_0xef95ee,_0x35e5b1,_0x2bf6df){}['onDisconnectMerge'](_0x57cbeb,_0x239570,_0x55ecdf){}['onDisconnectCancel'](_0x576ffa,_0x15ea42){}['reportStats'](_0x7514be){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x265640){this['allowedEvents_']=_0x265640,this['listeners_']={},f(Array['isArray'](_0x265640)&&_0x265640['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2502ef,..._0x5cd833){if(Array['isArray'](this['listeners_'][_0x2502ef])){const _0x4453cb=[...this['listeners_'][_0x2502ef]];for(let _0x56729b=0x0;_0x56729b<_0x4453cb['length'];_0x56729b++)_0x4453cb[_0x56729b]['callback']['apply'](_0x4453cb[_0x56729b]['context'],_0x5cd833);}}['on'](_0x346c7f,_0x342be7,_0x304455){this['validateEventType_'](_0x346c7f),this['listeners_'][_0x346c7f]=this['listeners_'][_0x346c7f]||[],this['listeners_'][_0x346c7f]['push']({'callback':_0x342be7,'context':_0x304455});const _0x39850e=this['getInitialEvent'](_0x346c7f);_0x39850e&&_0x342be7['apply'](_0x304455,_0x39850e);}['off'](_0x1aac26,_0x3f5ae7,_0x43a338){this['validateEventType_'](_0x1aac26);const _0x2adf5c=this['listeners_'][_0x1aac26]||[];for(let _0x39d97c=0x0;_0x39d97c<_0x2adf5c['length'];_0x39d97c++)if(_0x2adf5c[_0x39d97c]['callback']===_0x3f5ae7&&(!_0x43a338||_0x43a338===_0x2adf5c[_0x39d97c]['context'])){_0x2adf5c['splice'](_0x39d97c,0x1);return;}}['validateEventType_'](_0xba36f7){f(this['allowedEvents_']['find'](_0x5d8c68=>_0x5d8c68===_0xba36f7),'Unknown\x20event:\x20'+_0xba36f7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x288ec9){return f(_0x288ec9==='online','Unknown\x20event\x20type:\x20'+_0x288ec9),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x474529,_0x281a45){if(_0x281a45===void 0x0){this['pieces_']=_0x474529['split']('/');let _0x2fa685=0x0;for(let _0x4ae24d=0x0;_0x4ae24d<this['pieces_']['length'];_0x4ae24d++)this['pieces_'][_0x4ae24d]['length']>0x0&&(this['pieces_'][_0x2fa685]=this['pieces_'][_0x4ae24d],_0x2fa685++);this['pieces_']['length']=_0x2fa685,this['pieceNum_']=0x0;}else this['pieces_']=_0x474529,this['pieceNum_']=_0x281a45;}['toString'](){let _0x34ee77='';for(let _0x19e1ac=this['pieceNum_'];_0x19e1ac<this['pieces_']['length'];_0x19e1ac++)this['pieces_'][_0x19e1ac]!==''&&(_0x34ee77+='/'+this['pieces_'][_0x19e1ac]);return _0x34ee77||'/';}}function w(){return new C('');}function y(_0x45a93b){return _0x45a93b['pieceNum_']>=_0x45a93b['pieces_']['length']?null:_0x45a93b['pieces_'][_0x45a93b['pieceNum_']];}function we(_0x6c9642){return _0x6c9642['pieces_']['length']-_0x6c9642['pieceNum_'];}function b(_0x2d4b42){let _0x3a3506=_0x2d4b42['pieceNum_'];return _0x3a3506<_0x2d4b42['pieces_']['length']&&_0x3a3506++,new C(_0x2d4b42['pieces_'],_0x3a3506);}function Gi(_0x2bd278){return _0x2bd278['pieceNum_']<_0x2bd278['pieces_']['length']?_0x2bd278['pieces_'][_0x2bd278['pieces_']['length']-0x1]:null;}function Ch(_0x4ee77f){let _0x5360c1='';for(let _0x24675f=_0x4ee77f['pieceNum_'];_0x24675f<_0x4ee77f['pieces_']['length'];_0x24675f++)_0x4ee77f['pieces_'][_0x24675f]!==''&&(_0x5360c1+='/'+encodeURIComponent(String(_0x4ee77f['pieces_'][_0x24675f])));return _0x5360c1||'/';}function kt(_0x57708c,_0x29b9cd=0x0){return _0x57708c['pieces_']['slice'](_0x57708c['pieceNum_']+_0x29b9cd);}function To(_0x37173c){if(_0x37173c['pieceNum_']>=_0x37173c['pieces_']['length'])return null;const _0x2e86c4=[];for(let _0x1a4c59=_0x37173c['pieceNum_'];_0x1a4c59<_0x37173c['pieces_']['length']-0x1;_0x1a4c59++)_0x2e86c4['push'](_0x37173c['pieces_'][_0x1a4c59]);return new C(_0x2e86c4,0x0);}function A(_0xdb36a9,_0x3c5ff8){const _0x1aa275=[];for(let _0x5cbd9b=_0xdb36a9['pieceNum_'];_0x5cbd9b<_0xdb36a9['pieces_']['length'];_0x5cbd9b++)_0x1aa275['push'](_0xdb36a9['pieces_'][_0x5cbd9b]);if(_0x3c5ff8 instanceof C){for(let _0x3c1419=_0x3c5ff8['pieceNum_'];_0x3c1419<_0x3c5ff8['pieces_']['length'];_0x3c1419++)_0x1aa275['push'](_0x3c5ff8['pieces_'][_0x3c1419]);}else{const _0x3cc0ba=_0x3c5ff8['split']('/');for(let _0x12312e=0x0;_0x12312e<_0x3cc0ba['length'];_0x12312e++)_0x3cc0ba[_0x12312e]['length']>0x0&&_0x1aa275['push'](_0x3cc0ba[_0x12312e]);}return new C(_0x1aa275,0x0);}function v(_0x2725a5){return _0x2725a5['pieceNum_']>=_0x2725a5['pieces_']['length'];}function F(_0x5c9bcd,_0x2f5439){const _0x17c3b4=y(_0x5c9bcd),_0x2868c6=y(_0x2f5439);if(_0x17c3b4===null)return _0x2f5439;if(_0x17c3b4===_0x2868c6)return F(b(_0x5c9bcd),b(_0x2f5439));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2f5439+')\x20is\x20not\x20within\x20outerPath\x20('+_0x5c9bcd+')');}function Th(_0xca801a,_0x13c1ee){const _0x29ec60=kt(_0xca801a,0x0),_0x36b412=kt(_0x13c1ee,0x0);for(let _0x33d649=0x0;_0x33d649<_0x29ec60['length']&&_0x33d649<_0x36b412['length'];_0x33d649++){const _0x5b5c3d=He(_0x29ec60[_0x33d649],_0x36b412[_0x33d649]);if(_0x5b5c3d!==0x0)return _0x5b5c3d;}return _0x29ec60['length']===_0x36b412['length']?0x0:_0x29ec60['length']<_0x36b412['length']?-0x1:0x1;}function qi(_0x17116a,_0x411f56){if(we(_0x17116a)!==we(_0x411f56))return!0x1;for(let _0x26e607=_0x17116a['pieceNum_'],_0x2105d1=_0x411f56['pieceNum_'];_0x26e607<=_0x17116a['pieces_']['length'];_0x26e607++,_0x2105d1++)if(_0x17116a['pieces_'][_0x26e607]!==_0x411f56['pieces_'][_0x2105d1])return!0x1;return!0x0;}function $(_0x117cbe,_0x1aad20){let _0x4fe9e1=_0x117cbe['pieceNum_'],_0x4612c5=_0x1aad20['pieceNum_'];if(we(_0x117cbe)>we(_0x1aad20))return!0x1;for(;_0x4fe9e1<_0x117cbe['pieces_']['length'];){if(_0x117cbe['pieces_'][_0x4fe9e1]!==_0x1aad20['pieces_'][_0x4612c5])return!0x1;++_0x4fe9e1,++_0x4612c5;}return!0x0;}class Sh{constructor(_0x34258c,_0x1a1898){this['errorPrefix_']=_0x1a1898,this['parts_']=kt(_0x34258c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xcfb035=0x0;_0xcfb035<this['parts_']['length'];_0xcfb035++)this['byteLength_']+=Pn(this['parts_'][_0xcfb035]);So(this);}}function bh(_0xceb355,_0x4b0327){_0xceb355['parts_']['length']>0x0&&(_0xceb355['byteLength_']+=0x1),_0xceb355['parts_']['push'](_0x4b0327),_0xceb355['byteLength_']+=Pn(_0x4b0327),So(_0xceb355);}function Rh(_0x197a6c){const _0x272a69=_0x197a6c['parts_']['pop']();_0x197a6c['byteLength_']-=Pn(_0x272a69),_0x197a6c['parts_']['length']>0x0&&(_0x197a6c['byteLength_']-=0x1);}function So(_0x961d6d){if(_0x961d6d['byteLength_']>Js)throw new Error(_0x961d6d['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x961d6d['byteLength_']+').');if(_0x961d6d['parts_']['length']>Qs)throw new Error(_0x961d6d['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x961d6d));}function Ne(_0x291815){return _0x291815['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x291815['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x30a6cb,_0x4ab8ea;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4ab8ea='visibilitychange',_0x30a6cb='hidden'):typeof document['mozHidden']<'u'?(_0x4ab8ea='mozvisibilitychange',_0x30a6cb='mozHidden'):typeof document['msHidden']<'u'?(_0x4ab8ea='msvisibilitychange',_0x30a6cb='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4ab8ea='webkitvisibilitychange',_0x30a6cb='webkitHidden')),this['visible_']=!0x0,_0x4ab8ea&&document['addEventListener'](_0x4ab8ea,()=>{const _0x401a5a=!document[_0x30a6cb];_0x401a5a!==this['visible_']&&(this['visible_']=_0x401a5a,this['trigger']('visible',_0x401a5a));},!0x1);}['getInitialEvent'](_0x315d14){return f(_0x315d14==='visible','Unknown\x20event\x20type:\x20'+_0x315d14),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x174d30,_0x404797,_0x50868f,_0x1d482d,_0x5646a8,_0x3adc4b,_0x498754,_0x3d5e99){if(super(),this['repoInfo_']=_0x174d30,this['applicationId_']=_0x404797,this['onDataUpdate_']=_0x50868f,this['onConnectStatus_']=_0x1d482d,this['onServerInfoUpdate_']=_0x5646a8,this['authTokenProvider_']=_0x3adc4b,this['appCheckTokenProvider_']=_0x498754,this['authOverride_']=_0x3d5e99,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3d5e99)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x174d30['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x34a7de,_0x1a571a,_0x1e12ca){const _0x3076f7=++this['requestNumber_'],_0x3af53f={'r':_0x3076f7,'a':_0x34a7de,'b':_0x1a571a};this['log_'](O(_0x3af53f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3af53f),_0x1e12ca&&(this['requestCBHash_'][_0x3076f7]=_0x1e12ca);}['get'](_0x53d030){this['initConnection_']();const _0x453efc=new Ve(),_0x293225={'action':'g','request':{'p':_0x53d030['_path']['toString'](),'q':_0x53d030['_queryObject']},'onComplete':_0x2d2ea8=>{const _0x6f0096=_0x2d2ea8['d'];_0x2d2ea8['s']==='ok'?_0x453efc['resolve'](_0x6f0096):_0x453efc['reject'](_0x6f0096);}};this['outstandingGets_']['push'](_0x293225),this['outstandingGetCount_']++;const _0xceb1fb=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xceb1fb),_0x453efc['promise'];}['listen'](_0x2bcf08,_0x4ff0b5,_0x46d479,_0x7afa7b){this['initConnection_']();const _0x275bdb=_0x2bcf08['_queryIdentifier'],_0x228dc9=_0x2bcf08['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x228dc9+'\x20'+_0x275bdb),this['listens']['has'](_0x228dc9)||this['listens']['set'](_0x228dc9,new Map()),f(_0x2bcf08['_queryParams']['isDefault']()||!_0x2bcf08['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x228dc9)['has'](_0x275bdb),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x23e265={'onComplete':_0x7afa7b,'hashFn':_0x4ff0b5,'query':_0x2bcf08,'tag':_0x46d479};this['listens']['get'](_0x228dc9)['set'](_0x275bdb,_0x23e265),this['connected_']&&this['sendListen_'](_0x23e265);}['sendGet_'](_0x56e6c4){const _0x2aae72=this['outstandingGets_'][_0x56e6c4];this['sendRequest']('g',_0x2aae72['request'],_0x45d594=>{delete this['outstandingGets_'][_0x56e6c4],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2aae72['onComplete']&&_0x2aae72['onComplete'](_0x45d594);});}['sendListen_'](_0x3bf3f9){const _0x46151f=_0x3bf3f9['query'],_0x184ed0=_0x46151f['_path']['toString'](),_0x52784a=_0x46151f['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x184ed0+'\x20for\x20'+_0x52784a);const _0x112d21={'p':_0x184ed0},_0x28d661='q';_0x3bf3f9['tag']&&(_0x112d21['q']=_0x46151f['_queryObject'],_0x112d21['t']=_0x3bf3f9['tag']),_0x112d21['h']=_0x3bf3f9['hashFn'](),this['sendRequest'](_0x28d661,_0x112d21,_0x48f92f=>{const _0x161717=_0x48f92f['d'],_0x263133=_0x48f92f['s'];ie['warnOnListenWarnings_'](_0x161717,_0x46151f),(this['listens']['get'](_0x184ed0)&&this['listens']['get'](_0x184ed0)['get'](_0x52784a))===_0x3bf3f9&&(this['log_']('listen\x20response',_0x48f92f),_0x263133!=='ok'&&this['removeListen_'](_0x184ed0,_0x52784a),_0x3bf3f9['onComplete']&&_0x3bf3f9['onComplete'](_0x263133,_0x161717));});}static['warnOnListenWarnings_'](_0x268669,_0x19dd9d){if(_0x268669&&typeof _0x268669=='object'&&Y(_0x268669,'w')){const _0x5753af=Oe(_0x268669,'w');if(Array['isArray'](_0x5753af)&&~_0x5753af['indexOf']('no_index')){const _0x123c45='\x22.indexOn\x22:\x20\x22'+_0x19dd9d['_queryParams']['getIndex']()['toString']()+'\x22',_0x309f42=_0x19dd9d['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x123c45+'\x20at\x20'+_0x309f42+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xabb427){this['authToken_']=_0xabb427,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xabb427);}['reduceReconnectDelayIfAdminCredential_'](_0x120d1b){(_0x120d1b&&_0x120d1b['length']===0x28||vc(_0x120d1b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x51ca56){this['appCheckToken_']=_0x51ca56,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2278c0=this['authToken_'],_0x1bf48c=yc(_0x2278c0)?'auth':'gauth',_0x154036={'cred':_0x2278c0};this['authOverride_']===null?_0x154036['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x154036['authvar']=this['authOverride_']),this['sendRequest'](_0x1bf48c,_0x154036,_0x13ad43=>{const _0x3db941=_0x13ad43['s'],_0x39998d=_0x13ad43['d']||'error';this['authToken_']===_0x2278c0&&(_0x3db941==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3db941,_0x39998d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x410821=>{const _0x5a7ae2=_0x410821['s'],_0x3f7557=_0x410821['d']||'error';_0x5a7ae2==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5a7ae2,_0x3f7557);});}['unlisten'](_0xa82b37,_0x2bdfea){const _0x5408b2=_0xa82b37['_path']['toString'](),_0x5b981e=_0xa82b37['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5408b2+'\x20'+_0x5b981e),f(_0xa82b37['_queryParams']['isDefault']()||!_0xa82b37['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5408b2,_0x5b981e)&&this['connected_']&&this['sendUnlisten_'](_0x5408b2,_0x5b981e,_0xa82b37['_queryObject'],_0x2bdfea);}['sendUnlisten_'](_0x29339a,_0x455617,_0x10b1ee,_0x3b26af){this['log_']('Unlisten\x20on\x20'+_0x29339a+'\x20for\x20'+_0x455617);const _0x4babae={'p':_0x29339a},_0x429996='n';_0x3b26af&&(_0x4babae['q']=_0x10b1ee,_0x4babae['t']=_0x3b26af),this['sendRequest'](_0x429996,_0x4babae);}['onDisconnectPut'](_0x5832d5,_0x65a4d1,_0x29a434){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5832d5,_0x65a4d1,_0x29a434):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5832d5,'action':'o','data':_0x65a4d1,'onComplete':_0x29a434});}['onDisconnectMerge'](_0x3eeca0,_0x27c8d7,_0x53c16c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x3eeca0,_0x27c8d7,_0x53c16c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3eeca0,'action':'om','data':_0x27c8d7,'onComplete':_0x53c16c});}['onDisconnectCancel'](_0x426c28,_0x5d47a0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x426c28,null,_0x5d47a0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x426c28,'action':'oc','data':null,'onComplete':_0x5d47a0});}['sendOnDisconnect_'](_0x591ebe,_0xa7d11e,_0x5eede8,_0x2abcc3){const _0x19b415={'p':_0xa7d11e,'d':_0x5eede8};this['log_']('onDisconnect\x20'+_0x591ebe,_0x19b415),this['sendRequest'](_0x591ebe,_0x19b415,_0x1281f1=>{_0x2abcc3&&setTimeout(()=>{_0x2abcc3(_0x1281f1['s'],_0x1281f1['d']);},Math['floor'](0x0));});}['put'](_0x4250b5,_0x435333,_0x47f51e,_0x16ed60){this['putInternal']('p',_0x4250b5,_0x435333,_0x47f51e,_0x16ed60);}['merge'](_0x2f0c2b,_0x2fa465,_0x1a0dc3,_0x525343){this['putInternal']('m',_0x2f0c2b,_0x2fa465,_0x1a0dc3,_0x525343);}['putInternal'](_0x46681c,_0x452cc5,_0xca5239,_0x12608b,_0x5adfea){this['initConnection_']();const _0x23cc10={'p':_0x452cc5,'d':_0xca5239};_0x5adfea!==void 0x0&&(_0x23cc10['h']=_0x5adfea),this['outstandingPuts_']['push']({'action':_0x46681c,'request':_0x23cc10,'onComplete':_0x12608b}),this['outstandingPutCount_']++;const _0x44f308=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x44f308):this['log_']('Buffering\x20put:\x20'+_0x452cc5);}['sendPut_'](_0x494f4c){const _0x1f72c3=this['outstandingPuts_'][_0x494f4c]['action'],_0x5e3d79=this['outstandingPuts_'][_0x494f4c]['request'],_0x14097f=this['outstandingPuts_'][_0x494f4c]['onComplete'];this['outstandingPuts_'][_0x494f4c]['queued']=this['connected_'],this['sendRequest'](_0x1f72c3,_0x5e3d79,_0x2db52f=>{this['log_'](_0x1f72c3+'\x20response',_0x2db52f),delete this['outstandingPuts_'][_0x494f4c],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x14097f&&_0x14097f(_0x2db52f['s'],_0x2db52f['d']);});}['reportStats'](_0x213942){if(this['connected_']){const _0x10caf2={'c':_0x213942};this['log_']('reportStats',_0x10caf2),this['sendRequest']('s',_0x10caf2,_0x2d6e41=>{if(_0x2d6e41['s']!=='ok'){const _0x30dcef=_0x2d6e41['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x30dcef);}});}}['onDataMessage_'](_0x20dd9a){if('r'in _0x20dd9a){this['log_']('from\x20server:\x20'+O(_0x20dd9a));const _0x59f22a=_0x20dd9a['r'],_0x8721f5=this['requestCBHash_'][_0x59f22a];_0x8721f5&&(delete this['requestCBHash_'][_0x59f22a],_0x8721f5(_0x20dd9a['b']));}else{if('error'in _0x20dd9a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x20dd9a['error'];'a'in _0x20dd9a&&this['onDataPush_'](_0x20dd9a['a'],_0x20dd9a['b']);}}['onDataPush_'](_0x25ca82,_0x592284){this['log_']('handleServerMessage',_0x25ca82,_0x592284),_0x25ca82==='d'?this['onDataUpdate_'](_0x592284['p'],_0x592284['d'],!0x1,_0x592284['t']):_0x25ca82==='m'?this['onDataUpdate_'](_0x592284['p'],_0x592284['d'],!0x0,_0x592284['t']):_0x25ca82==='c'?this['onListenRevoked_'](_0x592284['p'],_0x592284['q']):_0x25ca82==='ac'?this['onAuthRevoked_'](_0x592284['s'],_0x592284['d']):_0x25ca82==='apc'?this['onAppCheckRevoked_'](_0x592284['s'],_0x592284['d']):_0x25ca82==='sd'?this['onSecurityDebugPacket_'](_0x592284):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x25ca82)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x183559,_0x1b9ced){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x183559),this['lastSessionId']=_0x1b9ced,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4710e3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4710e3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4de1f7){_0x4de1f7&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4de1f7;}['onOnline_'](_0x3671ff){_0x3671ff?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5a1fde=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x122eff=Math['max'](0x0,this['reconnectDelay_']-_0x5a1fde);_0x122eff=Math['random']()*_0x122eff,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x122eff+'ms'),this['scheduleConnect_'](_0x122eff),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x78ef19=this['onDataMessage_']['bind'](this),_0x28bbfd=this['onReady_']['bind'](this),_0x31675b=this['onRealtimeDisconnect_']['bind'](this),_0x50aa2b=this['id']+':'+ie['nextConnectionId_']++,_0x54ce25=this['lastSessionId'];let _0x4f4225=!0x1,_0x39247a=null;const _0x469ee9=function(){_0x39247a?_0x39247a['close']():(_0x4f4225=!0x0,_0x31675b());},_0x382b54=function(_0x294cda){f(_0x39247a,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x39247a['sendRequest'](_0x294cda);};this['realtime_']={'close':_0x469ee9,'sendRequest':_0x382b54};const _0x2d9590=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xed994d,_0x16ff44]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2d9590),this['appCheckTokenProvider_']['getToken'](_0x2d9590)]);_0x4f4225?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xed994d&&_0xed994d['accessToken'],this['appCheckToken_']=_0x16ff44&&_0x16ff44['token'],_0x39247a=new wh(_0x50aa2b,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x78ef19,_0x28bbfd,_0x31675b,_0x6a181d=>{U(_0x6a181d+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x54ce25));}catch(_0x360058){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x360058),_0x4f4225||(this['repoInfo_']['nodeAdmin']&&U(_0x360058),_0x469ee9());}}}['interrupt'](_0x339fcf){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x339fcf),this['interruptReasons_'][_0x339fcf]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x10209d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x10209d),delete this['interruptReasons_'][_0x10209d],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1eeab0){const _0x59ba0d=_0x1eeab0-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x59ba0d});}['cancelSentTransactions_'](){for(let _0x2aed24=0x0;_0x2aed24<this['outstandingPuts_']['length'];_0x2aed24++){const _0x446366=this['outstandingPuts_'][_0x2aed24];_0x446366&&'h'in _0x446366['request']&&_0x446366['queued']&&(_0x446366['onComplete']&&_0x446366['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2aed24],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x412338,_0x97359d){let _0x54ccba;_0x97359d?_0x54ccba=_0x97359d['map'](_0x5da1f8=>Bi(_0x5da1f8))['join']('$'):_0x54ccba='default';const _0xddd707=this['removeListen_'](_0x412338,_0x54ccba);_0xddd707&&_0xddd707['onComplete']&&_0xddd707['onComplete']('permission_denied');}['removeListen_'](_0x9150e8,_0x25f916){const _0x32c555=new C(_0x9150e8)['toString']();let _0x249b0b;if(this['listens']['has'](_0x32c555)){const _0x44fcd6=this['listens']['get'](_0x32c555);_0x249b0b=_0x44fcd6['get'](_0x25f916),_0x44fcd6['delete'](_0x25f916),_0x44fcd6['size']===0x0&&this['listens']['delete'](_0x32c555);}else _0x249b0b=void 0x0;return _0x249b0b;}['onAuthRevoked_'](_0x2c3900,_0x1ec99a){L('Auth\x20token\x20revoked:\x20'+_0x2c3900+'/'+_0x1ec99a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2c3900==='invalid_token'||_0x2c3900==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x407482,_0x2b77d3){L('App\x20check\x20token\x20revoked:\x20'+_0x407482+'/'+_0x2b77d3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x407482==='invalid_token'||_0x407482==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3f0e8d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3f0e8d):'msg'in _0x3f0e8d&&console['log']('FIREBASE:\x20'+_0x3f0e8d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4039a4 of this['listens']['values']())for(const _0x4c77c6 of _0x4039a4['values']())this['sendListen_'](_0x4c77c6);for(let _0x3533d8=0x0;_0x3533d8<this['outstandingPuts_']['length'];_0x3533d8++)this['outstandingPuts_'][_0x3533d8]&&this['sendPut_'](_0x3533d8);for(;this['onDisconnectRequestQueue_']['length'];){const _0x57b1eb=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x57b1eb['action'],_0x57b1eb['pathString'],_0x57b1eb['data'],_0x57b1eb['onComplete']);}for(let _0x255716=0x0;_0x255716<this['outstandingGets_']['length'];_0x255716++)this['outstandingGets_'][_0x255716]&&this['sendGet_'](_0x255716);}['sendConnectStats_'](){const _0x3386ea={};let _0x1927af='js';_0x3386ea['sdk.'+_0x1927af+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x3386ea['framework.cordova']=0x1:qr()&&(_0x3386ea['framework.reactnative']=0x1),this['reportStats'](_0x3386ea);}['shouldReconnect_'](){const _0x5aac3d=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x5aac3d;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3be9c4,_0x28be72){this['name']=_0x3be9c4,this['node']=_0x28be72;}static['Wrap'](_0x3e4f15,_0x3073d3){return new E(_0x3e4f15,_0x3073d3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x53a07b,_0x174725){const _0x4255e9=new E(xe,_0x53a07b),_0x2e24ad=new E(xe,_0x174725);return this['compare'](_0x4255e9,_0x2e24ad)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x417179){Xt=_0x417179;}['compare'](_0x53f30d,_0x1788a6){return He(_0x53f30d['name'],_0x1788a6['name']);}['isDefinedOn'](_0x16cade){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2d6d5e,_0x54b89f){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3ad529,_0x251c17){return f(typeof _0x3ad529=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3ad529,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x46cce5,_0x5b35e7,_0x3193be,_0x5b7d2b,_0x44c0da=null){this['isReverse_']=_0x5b7d2b,this['resultGenerator_']=_0x44c0da,this['nodeStack_']=[];let _0x155d6b=0x1;for(;!_0x46cce5['isEmpty']();)if(_0x46cce5=_0x46cce5,_0x155d6b=_0x5b35e7?_0x3193be(_0x46cce5['key'],_0x5b35e7):0x1,_0x5b7d2b&&(_0x155d6b*=-0x1),_0x155d6b<0x0)this['isReverse_']?_0x46cce5=_0x46cce5['left']:_0x46cce5=_0x46cce5['right'];else{if(_0x155d6b===0x0){this['nodeStack_']['push'](_0x46cce5);break;}else this['nodeStack_']['push'](_0x46cce5),this['isReverse_']?_0x46cce5=_0x46cce5['right']:_0x46cce5=_0x46cce5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5865e8=this['nodeStack_']['pop'](),_0x310f9d;if(this['resultGenerator_']?_0x310f9d=this['resultGenerator_'](_0x5865e8['key'],_0x5865e8['value']):_0x310f9d={'key':_0x5865e8['key'],'value':_0x5865e8['value']},this['isReverse_']){for(_0x5865e8=_0x5865e8['left'];!_0x5865e8['isEmpty']();)this['nodeStack_']['push'](_0x5865e8),_0x5865e8=_0x5865e8['right'];}else{for(_0x5865e8=_0x5865e8['right'];!_0x5865e8['isEmpty']();)this['nodeStack_']['push'](_0x5865e8),_0x5865e8=_0x5865e8['left'];}return _0x310f9d;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1f1901=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1f1901['key'],_0x1f1901['value']):{'key':_0x1f1901['key'],'value':_0x1f1901['value']};}}class M{constructor(_0x38ec0d,_0x853ac2,_0x1c1376,_0x3427f3,_0x518741){this['key']=_0x38ec0d,this['value']=_0x853ac2,this['color']=_0x1c1376??M['RED'],this['left']=_0x3427f3??B['EMPTY_NODE'],this['right']=_0x518741??B['EMPTY_NODE'];}['copy'](_0x21f040,_0x47b333,_0x185f21,_0x190f2c,_0x220c52){return new M(_0x21f040??this['key'],_0x47b333??this['value'],_0x185f21??this['color'],_0x190f2c??this['left'],_0x220c52??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x33c3ac){return this['left']['inorderTraversal'](_0x33c3ac)||!!_0x33c3ac(this['key'],this['value'])||this['right']['inorderTraversal'](_0x33c3ac);}['reverseTraversal'](_0x4ec0c3){return this['right']['reverseTraversal'](_0x4ec0c3)||_0x4ec0c3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4ec0c3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5ef5b4,_0x3f4914,_0x3a6a9c){let _0xe9990b=this;const _0x37617b=_0x3a6a9c(_0x5ef5b4,_0xe9990b['key']);return _0x37617b<0x0?_0xe9990b=_0xe9990b['copy'](null,null,null,_0xe9990b['left']['insert'](_0x5ef5b4,_0x3f4914,_0x3a6a9c),null):_0x37617b===0x0?_0xe9990b=_0xe9990b['copy'](null,_0x3f4914,null,null,null):_0xe9990b=_0xe9990b['copy'](null,null,null,null,_0xe9990b['right']['insert'](_0x5ef5b4,_0x3f4914,_0x3a6a9c)),_0xe9990b['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x11adf6=this;return!_0x11adf6['left']['isRed_']()&&!_0x11adf6['left']['left']['isRed_']()&&(_0x11adf6=_0x11adf6['moveRedLeft_']()),_0x11adf6=_0x11adf6['copy'](null,null,null,_0x11adf6['left']['removeMin_'](),null),_0x11adf6['fixUp_']();}['remove'](_0x53ee4a,_0x6c6ff0){let _0x5cc975,_0x1f8acd;if(_0x5cc975=this,_0x6c6ff0(_0x53ee4a,_0x5cc975['key'])<0x0)!_0x5cc975['left']['isEmpty']()&&!_0x5cc975['left']['isRed_']()&&!_0x5cc975['left']['left']['isRed_']()&&(_0x5cc975=_0x5cc975['moveRedLeft_']()),_0x5cc975=_0x5cc975['copy'](null,null,null,_0x5cc975['left']['remove'](_0x53ee4a,_0x6c6ff0),null);else{if(_0x5cc975['left']['isRed_']()&&(_0x5cc975=_0x5cc975['rotateRight_']()),!_0x5cc975['right']['isEmpty']()&&!_0x5cc975['right']['isRed_']()&&!_0x5cc975['right']['left']['isRed_']()&&(_0x5cc975=_0x5cc975['moveRedRight_']()),_0x6c6ff0(_0x53ee4a,_0x5cc975['key'])===0x0){if(_0x5cc975['right']['isEmpty']())return B['EMPTY_NODE'];_0x1f8acd=_0x5cc975['right']['min_'](),_0x5cc975=_0x5cc975['copy'](_0x1f8acd['key'],_0x1f8acd['value'],null,null,_0x5cc975['right']['removeMin_']());}_0x5cc975=_0x5cc975['copy'](null,null,null,null,_0x5cc975['right']['remove'](_0x53ee4a,_0x6c6ff0));}return _0x5cc975['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x55b198=this;return _0x55b198['right']['isRed_']()&&!_0x55b198['left']['isRed_']()&&(_0x55b198=_0x55b198['rotateLeft_']()),_0x55b198['left']['isRed_']()&&_0x55b198['left']['left']['isRed_']()&&(_0x55b198=_0x55b198['rotateRight_']()),_0x55b198['left']['isRed_']()&&_0x55b198['right']['isRed_']()&&(_0x55b198=_0x55b198['colorFlip_']()),_0x55b198;}['moveRedLeft_'](){let _0x565d81=this['colorFlip_']();return _0x565d81['right']['left']['isRed_']()&&(_0x565d81=_0x565d81['copy'](null,null,null,null,_0x565d81['right']['rotateRight_']()),_0x565d81=_0x565d81['rotateLeft_'](),_0x565d81=_0x565d81['colorFlip_']()),_0x565d81;}['moveRedRight_'](){let _0x265e57=this['colorFlip_']();return _0x265e57['left']['left']['isRed_']()&&(_0x265e57=_0x265e57['rotateRight_'](),_0x265e57=_0x265e57['colorFlip_']()),_0x265e57;}['rotateLeft_'](){const _0x13182e=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x13182e,null);}['rotateRight_'](){const _0x199106=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x199106);}['colorFlip_'](){const _0x11f87b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4dcb31=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x11f87b,_0x4dcb31);}['checkMaxDepth_'](){const _0x721da3=this['check_']();return Math['pow'](0x2,_0x721da3)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x58de59=this['left']['check_']();if(_0x58de59!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x58de59+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x5df516,_0x45533a,_0x473631,_0x52fe17,_0x5370ce){return this;}['insert'](_0x826f0c,_0x54a523,_0x2ed790){return new M(_0x826f0c,_0x54a523,null);}['remove'](_0x260191,_0x3c6acc){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1be010){return!0x1;}['reverseTraversal'](_0x203b89){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x442c4d,_0x17b89a=B['EMPTY_NODE']){this['comparator_']=_0x442c4d,this['root_']=_0x17b89a;}['insert'](_0x1b18cd,_0x849630){return new B(this['comparator_'],this['root_']['insert'](_0x1b18cd,_0x849630,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3dd678){return new B(this['comparator_'],this['root_']['remove'](_0x3dd678,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x58df94){let _0x36bf36,_0x35e8a9=this['root_'];for(;!_0x35e8a9['isEmpty']();){if(_0x36bf36=this['comparator_'](_0x58df94,_0x35e8a9['key']),_0x36bf36===0x0)return _0x35e8a9['value'];_0x36bf36<0x0?_0x35e8a9=_0x35e8a9['left']:_0x36bf36>0x0&&(_0x35e8a9=_0x35e8a9['right']);}return null;}['getPredecessorKey'](_0x48befc){let _0x34f6b3,_0xd8e916=this['root_'],_0x5c6ed2=null;for(;!_0xd8e916['isEmpty']();)if(_0x34f6b3=this['comparator_'](_0x48befc,_0xd8e916['key']),_0x34f6b3===0x0){if(_0xd8e916['left']['isEmpty']())return _0x5c6ed2?_0x5c6ed2['key']:null;for(_0xd8e916=_0xd8e916['left'];!_0xd8e916['right']['isEmpty']();)_0xd8e916=_0xd8e916['right'];return _0xd8e916['key'];}else _0x34f6b3<0x0?_0xd8e916=_0xd8e916['left']:_0x34f6b3>0x0&&(_0x5c6ed2=_0xd8e916,_0xd8e916=_0xd8e916['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5d1aea){return this['root_']['inorderTraversal'](_0x5d1aea);}['reverseTraversal'](_0x5783f4){return this['root_']['reverseTraversal'](_0x5783f4);}['getIterator'](_0x5eff87){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x5eff87);}['getIteratorFrom'](_0x1327ef,_0xcbcd7c){return new Zt(this['root_'],_0x1327ef,this['comparator_'],!0x1,_0xcbcd7c);}['getReverseIteratorFrom'](_0x2aadd3,_0x5cfe23){return new Zt(this['root_'],_0x2aadd3,this['comparator_'],!0x0,_0x5cfe23);}['getReverseIterator'](_0x95a516){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x95a516);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x8f464,_0x35583){return He(_0x8f464['name'],_0x35583['name']);}function ji(_0x44fb27,_0x1e2080){return He(_0x44fb27,_0x1e2080);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x443fba){vi=_0x443fba;}const Ro=function(_0x370c2b){return typeof _0x370c2b=='number'?'number:'+so(_0x370c2b):'string:'+_0x370c2b;},Ao=function(_0x10ec8b){if(_0x10ec8b['isLeafNode']()){const _0x5bf47a=_0x10ec8b['val']();f(typeof _0x5bf47a=='string'||typeof _0x5bf47a=='number'||typeof _0x5bf47a=='object'&&Y(_0x5bf47a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x10ec8b===vi||_0x10ec8b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x10ec8b===vi||_0x10ec8b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5ce578){er=_0x5ce578;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x3a9867,_0x2b35be=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3a9867,this['priorityNode_']=_0x2b35be,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5e5c76){return new D(this['value_'],_0x5e5c76);}['getImmediateChild'](_0x4f4e35){return _0x4f4e35==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1cdeda){return v(_0x1cdeda)?this:y(_0x1cdeda)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x46ef06,_0x79c456){return null;}['updateImmediateChild'](_0x269af1,_0x3aef83){return _0x269af1==='.priority'?this['updatePriority'](_0x3aef83):_0x3aef83['isEmpty']()&&_0x269af1!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x269af1,_0x3aef83)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x13e532,_0x2d2cb8){const _0x372bd7=y(_0x13e532);return _0x372bd7===null?_0x2d2cb8:_0x2d2cb8['isEmpty']()&&_0x372bd7!=='.priority'?this:(f(_0x372bd7!=='.priority'||we(_0x13e532)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x372bd7,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x13e532),_0x2d2cb8)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2b9e6f,_0x17af34){return!0x1;}['val'](_0x85d700){return _0x85d700&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xefc530='';this['priorityNode_']['isEmpty']()||(_0xefc530+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x3ac4ef=typeof this['value_'];_0xefc530+=_0x3ac4ef+':',_0x3ac4ef==='number'?_0xefc530+=so(this['value_']):_0xefc530+=this['value_'],this['lazyHash_']=no(_0xefc530);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x399590){return _0x399590===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x399590 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x399590['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x399590));}['compareToLeafNode_'](_0x2d6258){const _0x54153a=typeof _0x2d6258['value_'],_0x5ac7c6=typeof this['value_'],_0x1060e6=D['VALUE_TYPE_ORDER']['indexOf'](_0x54153a),_0x567ecb=D['VALUE_TYPE_ORDER']['indexOf'](_0x5ac7c6);return f(_0x1060e6>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x54153a),f(_0x567ecb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5ac7c6),_0x1060e6===_0x567ecb?_0x5ac7c6==='object'?0x0:this['value_']<_0x2d6258['value_']?-0x1:this['value_']===_0x2d6258['value_']?0x0:0x1:_0x567ecb-_0x1060e6;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x59792f){if(_0x59792f===this)return!0x0;if(_0x59792f['isLeafNode']()){const _0x54d249=_0x59792f;return this['value_']===_0x54d249['value_']&&this['priorityNode_']['equals'](_0x54d249['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x359553){ko=_0x359553;}function xh(_0x46f9de){No=_0x46f9de;}class Fh extends On{['compare'](_0x3791e4,_0x17f172){const _0x3b701c=_0x3791e4['node']['getPriority'](),_0x4eb616=_0x17f172['node']['getPriority'](),_0x39c5bd=_0x3b701c['compareTo'](_0x4eb616);return _0x39c5bd===0x0?He(_0x3791e4['name'],_0x17f172['name']):_0x39c5bd;}['isDefinedOn'](_0x2c94ac){return!_0x2c94ac['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3be7fc,_0x5ec26d){return!_0x3be7fc['getPriority']()['equals'](_0x5ec26d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xf73067,_0x5798c9){const _0x4e76bb=ko(_0xf73067);return new E(_0x5798c9,new D('[PRIORITY-POST]',_0x4e76bb));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4ce6c2){const _0x18853c=_0x1961ae=>parseInt(Math['log'](_0x1961ae)/Uh,0xa),_0x47cc72=_0x3e7d35=>parseInt(Array(_0x3e7d35+0x1)['join']('1'),0x2);this['count']=_0x18853c(_0x4ce6c2+0x1),this['current_']=this['count']-0x1;const _0x199af7=_0x47cc72(this['count']);this['bits_']=_0x4ce6c2+0x1&_0x199af7;}['nextBitIsOne'](){const _0x2670ad=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2670ad;}}const dn=function(_0x359438,_0x1aa7fe,_0x2c2097,_0x4c6066){_0x359438['sort'](_0x1aa7fe);const _0x28c011=function(_0x21bbd0,_0x3e85fc){const _0x2601ce=_0x3e85fc-_0x21bbd0;let _0x4187fa,_0xbe4cc0;if(_0x2601ce===0x0)return null;if(_0x2601ce===0x1)return _0x4187fa=_0x359438[_0x21bbd0],_0xbe4cc0=_0x2c2097?_0x2c2097(_0x4187fa):_0x4187fa,new M(_0xbe4cc0,_0x4187fa['node'],M['BLACK'],null,null);{const _0x1646d6=parseInt(_0x2601ce/0x2,0xa)+_0x21bbd0,_0x38baee=_0x28c011(_0x21bbd0,_0x1646d6),_0x324901=_0x28c011(_0x1646d6+0x1,_0x3e85fc);return _0x4187fa=_0x359438[_0x1646d6],_0xbe4cc0=_0x2c2097?_0x2c2097(_0x4187fa):_0x4187fa,new M(_0xbe4cc0,_0x4187fa['node'],M['BLACK'],_0x38baee,_0x324901);}},_0x3c5ed8=function(_0x1517a1){let _0x282b8b=null,_0x357b13=null,_0x2310f2=_0x359438['length'];const _0x3cec0e=function(_0xfadae8,_0x17f3b9){const _0x3ccaff=_0x2310f2-_0xfadae8,_0x356b6b=_0x2310f2;_0x2310f2-=_0xfadae8;const _0x188fde=_0x28c011(_0x3ccaff+0x1,_0x356b6b),_0x5cc862=_0x359438[_0x3ccaff],_0x47c996=_0x2c2097?_0x2c2097(_0x5cc862):_0x5cc862;_0x1db7d8(new M(_0x47c996,_0x5cc862['node'],_0x17f3b9,null,_0x188fde));},_0x1db7d8=function(_0x5c213c){_0x282b8b?(_0x282b8b['left']=_0x5c213c,_0x282b8b=_0x5c213c):(_0x357b13=_0x5c213c,_0x282b8b=_0x5c213c);};for(let _0x514199=0x0;_0x514199<_0x1517a1['count'];++_0x514199){const _0x1c0817=_0x1517a1['nextBitIsOne'](),_0x5b962c=Math['pow'](0x2,_0x1517a1['count']-(_0x514199+0x1));_0x1c0817?_0x3cec0e(_0x5b962c,M['BLACK']):(_0x3cec0e(_0x5b962c,M['BLACK']),_0x3cec0e(_0x5b962c,M['RED']));}return _0x357b13;},_0x4dcbf1=new Wh(_0x359438['length']),_0x39cdb8=_0x3c5ed8(_0x4dcbf1);return new B(_0x4c6066||_0x1aa7fe,_0x39cdb8);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2772ba,_0x1f4f3e){this['indexes_']=_0x2772ba,this['indexSet_']=_0x1f4f3e;}['get'](_0x5c4578){const _0x267070=Oe(this['indexes_'],_0x5c4578);if(!_0x267070)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5c4578);return _0x267070 instanceof B?_0x267070:null;}['hasIndex'](_0x924bef){return Y(this['indexSet_'],_0x924bef['toString']());}['addIndex'](_0x40ff56,_0x477f18){f(_0x40ff56!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xa285f0=[];let _0x56df0d=!0x1;const _0x26e112=_0x477f18['getIterator'](E['Wrap']);let _0x149b65=_0x26e112['getNext']();for(;_0x149b65;)_0x56df0d=_0x56df0d||_0x40ff56['isDefinedOn'](_0x149b65['node']),_0xa285f0['push'](_0x149b65),_0x149b65=_0x26e112['getNext']();let _0x692594;_0x56df0d?_0x692594=dn(_0xa285f0,_0x40ff56['getCompare']()):_0x692594=je;const _0x471870=_0x40ff56['toString'](),_0x5dcac2={...this['indexSet_']};_0x5dcac2[_0x471870]=_0x40ff56;const _0x3ab694={...this['indexes_']};return _0x3ab694[_0x471870]=_0x692594,new ee(_0x3ab694,_0x5dcac2);}['addToIndexes'](_0x2f2236,_0x53c1f2){const _0x5d2545=ln(this['indexes_'],(_0x5da29a,_0x259106)=>{const _0x4fcaaa=Oe(this['indexSet_'],_0x259106);if(f(_0x4fcaaa,'Missing\x20index\x20implementation\x20for\x20'+_0x259106),_0x5da29a===je){if(_0x4fcaaa['isDefinedOn'](_0x2f2236['node'])){const _0xad1bfe=[],_0x1e0d30=_0x53c1f2['getIterator'](E['Wrap']);let _0x1f65fa=_0x1e0d30['getNext']();for(;_0x1f65fa;)_0x1f65fa['name']!==_0x2f2236['name']&&_0xad1bfe['push'](_0x1f65fa),_0x1f65fa=_0x1e0d30['getNext']();return _0xad1bfe['push'](_0x2f2236),dn(_0xad1bfe,_0x4fcaaa['getCompare']());}else return je;}else{const _0x358869=_0x53c1f2['get'](_0x2f2236['name']);let _0x5ab74b=_0x5da29a;return _0x358869&&(_0x5ab74b=_0x5ab74b['remove'](new E(_0x2f2236['name'],_0x358869))),_0x5ab74b['insert'](_0x2f2236,_0x2f2236['node']);}});return new ee(_0x5d2545,this['indexSet_']);}['removeFromIndexes'](_0x45a252,_0x3bde38){const _0x25b8a0=ln(this['indexes_'],_0x35ed44=>{if(_0x35ed44===je)return _0x35ed44;{const _0x3903ca=_0x3bde38['get'](_0x45a252['name']);return _0x3903ca?_0x35ed44['remove'](new E(_0x45a252['name'],_0x3903ca)):_0x35ed44;}});return new ee(_0x25b8a0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2330f9,_0x404ad9,_0x2bd53e){this['children_']=_0x2330f9,this['priorityNode_']=_0x404ad9,this['indexMap_']=_0x2bd53e,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x9db552){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x9db552,this['indexMap_']);}['getImmediateChild'](_0x2fa225){if(_0x2fa225==='.priority')return this['getPriority']();{const _0x4db735=this['children_']['get'](_0x2fa225);return _0x4db735===null?gt:_0x4db735;}}['getChild'](_0x15d225){const _0x4bf0c2=y(_0x15d225);return _0x4bf0c2===null?this:this['getImmediateChild'](_0x4bf0c2)['getChild'](b(_0x15d225));}['hasChild'](_0x509282){return this['children_']['get'](_0x509282)!==null;}['updateImmediateChild'](_0x24791e,_0x286d71){if(f(_0x286d71,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x24791e==='.priority')return this['updatePriority'](_0x286d71);{const _0x20ac0b=new E(_0x24791e,_0x286d71);let _0x29d6a2,_0x452450;_0x286d71['isEmpty']()?(_0x29d6a2=this['children_']['remove'](_0x24791e),_0x452450=this['indexMap_']['removeFromIndexes'](_0x20ac0b,this['children_'])):(_0x29d6a2=this['children_']['insert'](_0x24791e,_0x286d71),_0x452450=this['indexMap_']['addToIndexes'](_0x20ac0b,this['children_']));const _0x1e6a9e=_0x29d6a2['isEmpty']()?gt:this['priorityNode_'];return new g(_0x29d6a2,_0x1e6a9e,_0x452450);}}['updateChild'](_0x2acad3,_0x32c68e){const _0x34570f=y(_0x2acad3);if(_0x34570f===null)return _0x32c68e;{f(y(_0x2acad3)!=='.priority'||we(_0x2acad3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x244494=this['getImmediateChild'](_0x34570f)['updateChild'](b(_0x2acad3),_0x32c68e);return this['updateImmediateChild'](_0x34570f,_0x244494);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x56ea74){if(this['isEmpty']())return null;const _0x2de17c={};let _0x4431ff=0x0,_0x5e9c7c=0x0,_0x2dbce2=!0x0;if(this['forEachChild'](R,(_0x2de6c4,_0x3c4cc4)=>{_0x2de17c[_0x2de6c4]=_0x3c4cc4['val'](_0x56ea74),_0x4431ff++,_0x2dbce2&&g['INTEGER_REGEXP_']['test'](_0x2de6c4)?_0x5e9c7c=Math['max'](_0x5e9c7c,Number(_0x2de6c4)):_0x2dbce2=!0x1;}),!_0x56ea74&&_0x2dbce2&&_0x5e9c7c<0x2*_0x4431ff){const _0xe5b713=[];for(const _0x5539c1 in _0x2de17c)_0xe5b713[_0x5539c1]=_0x2de17c[_0x5539c1];return _0xe5b713;}else return _0x56ea74&&!this['getPriority']()['isEmpty']()&&(_0x2de17c['.priority']=this['getPriority']()['val']()),_0x2de17c;}['hash'](){if(this['lazyHash_']===null){let _0x14e16e='';this['getPriority']()['isEmpty']()||(_0x14e16e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5392f0,_0x87c2d2)=>{const _0x27edff=_0x87c2d2['hash']();_0x27edff!==''&&(_0x14e16e+=':'+_0x5392f0+':'+_0x27edff);}),this['lazyHash_']=_0x14e16e===''?'':no(_0x14e16e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x24646a,_0x358039,_0xa3d87a){const _0x19a84d=this['resolveIndex_'](_0xa3d87a);if(_0x19a84d){const _0x332676=_0x19a84d['getPredecessorKey'](new E(_0x24646a,_0x358039));return _0x332676?_0x332676['name']:null;}else return this['children_']['getPredecessorKey'](_0x24646a);}['getFirstChildName'](_0x2a4bc4){const _0xcb1fa1=this['resolveIndex_'](_0x2a4bc4);if(_0xcb1fa1){const _0x3bcfdc=_0xcb1fa1['minKey']();return _0x3bcfdc&&_0x3bcfdc['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x424629){const _0x2e87d5=this['getFirstChildName'](_0x424629);return _0x2e87d5?new E(_0x2e87d5,this['children_']['get'](_0x2e87d5)):null;}['getLastChildName'](_0x139b65){const _0x3c11f4=this['resolveIndex_'](_0x139b65);if(_0x3c11f4){const _0x4e7560=_0x3c11f4['maxKey']();return _0x4e7560&&_0x4e7560['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1380fb){const _0x4ba341=this['getLastChildName'](_0x1380fb);return _0x4ba341?new E(_0x4ba341,this['children_']['get'](_0x4ba341)):null;}['forEachChild'](_0x316204,_0x28b79b){const _0x1d69b6=this['resolveIndex_'](_0x316204);return _0x1d69b6?_0x1d69b6['inorderTraversal'](_0x4c798e=>_0x28b79b(_0x4c798e['name'],_0x4c798e['node'])):this['children_']['inorderTraversal'](_0x28b79b);}['getIterator'](_0x578a18){return this['getIteratorFrom'](_0x578a18['minPost'](),_0x578a18);}['getIteratorFrom'](_0x2aaab2,_0x4887a9){const _0x43a18e=this['resolveIndex_'](_0x4887a9);if(_0x43a18e)return _0x43a18e['getIteratorFrom'](_0x2aaab2,_0x43db65=>_0x43db65);{const _0x23a659=this['children_']['getIteratorFrom'](_0x2aaab2['name'],E['Wrap']);let _0x594989=_0x23a659['peek']();for(;_0x594989!=null&&_0x4887a9['compare'](_0x594989,_0x2aaab2)<0x0;)_0x23a659['getNext'](),_0x594989=_0x23a659['peek']();return _0x23a659;}}['getReverseIterator'](_0x3891da){return this['getReverseIteratorFrom'](_0x3891da['maxPost'](),_0x3891da);}['getReverseIteratorFrom'](_0x3c8e54,_0x304f52){const _0x215283=this['resolveIndex_'](_0x304f52);if(_0x215283)return _0x215283['getReverseIteratorFrom'](_0x3c8e54,_0x63e1ab=>_0x63e1ab);{const _0x35d33c=this['children_']['getReverseIteratorFrom'](_0x3c8e54['name'],E['Wrap']);let _0x566a38=_0x35d33c['peek']();for(;_0x566a38!=null&&_0x304f52['compare'](_0x566a38,_0x3c8e54)>0x0;)_0x35d33c['getNext'](),_0x566a38=_0x35d33c['peek']();return _0x35d33c;}}['compareTo'](_0x547c7c){return this['isEmpty']()?_0x547c7c['isEmpty']()?0x0:-0x1:_0x547c7c['isLeafNode']()||_0x547c7c['isEmpty']()?0x1:_0x547c7c===Ht?-0x1:0x0;}['withIndex'](_0x4842a0){if(_0x4842a0===ye||this['indexMap_']['hasIndex'](_0x4842a0))return this;{const _0x4cf291=this['indexMap_']['addIndex'](_0x4842a0,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4cf291);}}['isIndexed'](_0xdad8d0){return _0xdad8d0===ye||this['indexMap_']['hasIndex'](_0xdad8d0);}['equals'](_0x2bc1fb){if(_0x2bc1fb===this)return!0x0;if(_0x2bc1fb['isLeafNode']())return!0x1;{const _0xd4b4e1=_0x2bc1fb;if(this['getPriority']()['equals'](_0xd4b4e1['getPriority']())){if(this['children_']['count']()===_0xd4b4e1['children_']['count']()){const _0x667dde=this['getIterator'](R),_0x456049=_0xd4b4e1['getIterator'](R);let _0x11d7dd=_0x667dde['getNext'](),_0x14a112=_0x456049['getNext']();for(;_0x11d7dd&&_0x14a112;){if(_0x11d7dd['name']!==_0x14a112['name']||!_0x11d7dd['node']['equals'](_0x14a112['node']))return!0x1;_0x11d7dd=_0x667dde['getNext'](),_0x14a112=_0x456049['getNext']();}return _0x11d7dd===null&&_0x14a112===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x38a6d4){return _0x38a6d4===ye?null:this['indexMap_']['get'](_0x38a6d4['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0xfbc6cd){return _0xfbc6cd===this?0x0:0x1;}['equals'](_0x3d7c8f){return _0x3d7c8f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x34a0bb){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x45fd16,_0x3a5301=null){if(_0x45fd16===null)return g['EMPTY_NODE'];if(typeof _0x45fd16=='object'&&'.priority'in _0x45fd16&&(_0x3a5301=_0x45fd16['.priority']),f(_0x3a5301===null||typeof _0x3a5301=='string'||typeof _0x3a5301=='number'||typeof _0x3a5301=='object'&&'.sv'in _0x3a5301,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3a5301),typeof _0x45fd16=='object'&&'.value'in _0x45fd16&&_0x45fd16['.value']!==null&&(_0x45fd16=_0x45fd16['.value']),typeof _0x45fd16!='object'||'.sv'in _0x45fd16){const _0xbbcb68=_0x45fd16;return new D(_0xbbcb68,N(_0x3a5301));}if(!(_0x45fd16 instanceof Array)&&Vh){const _0x320510=[];let _0x12c543=!0x1;if(x(_0x45fd16,(_0x676ee1,_0x10658e)=>{if(_0x676ee1['substring'](0x0,0x1)!=='.'){const _0x586ff6=N(_0x10658e);_0x586ff6['isEmpty']()||(_0x12c543=_0x12c543||!_0x586ff6['getPriority']()['isEmpty'](),_0x320510['push'](new E(_0x676ee1,_0x586ff6)));}}),_0x320510['length']===0x0)return g['EMPTY_NODE'];const _0x221a9a=dn(_0x320510,Dh,_0xd2ead7=>_0xd2ead7['name'],ji);if(_0x12c543){const _0x25cea4=dn(_0x320510,R['getCompare']());return new g(_0x221a9a,N(_0x3a5301),new ee({'.priority':_0x25cea4},{'.priority':R}));}else return new g(_0x221a9a,N(_0x3a5301),ee['Default']);}else{let _0x3ed1a7=g['EMPTY_NODE'];return x(_0x45fd16,(_0x11fdad,_0x2d569c)=>{if(Y(_0x45fd16,_0x11fdad)&&_0x11fdad['substring'](0x0,0x1)!=='.'){const _0x338049=N(_0x2d569c);(_0x338049['isLeafNode']()||!_0x338049['isEmpty']())&&(_0x3ed1a7=_0x3ed1a7['updateImmediateChild'](_0x11fdad,_0x338049));}}),_0x3ed1a7['updatePriority'](N(_0x3a5301));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x24cebc){super(),this['indexPath_']=_0x24cebc,f(!v(_0x24cebc)&&y(_0x24cebc)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2cb2c5){return _0x2cb2c5['getChild'](this['indexPath_']);}['isDefinedOn'](_0x58cfd6){return!_0x58cfd6['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1ac080,_0x53c705){const _0x1d810b=this['extractChild'](_0x1ac080['node']),_0x2dd618=this['extractChild'](_0x53c705['node']),_0x8286e5=_0x1d810b['compareTo'](_0x2dd618);return _0x8286e5===0x0?He(_0x1ac080['name'],_0x53c705['name']):_0x8286e5;}['makePost'](_0x3e01f5,_0x621d44){const _0x2c8523=N(_0x3e01f5),_0x48c809=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2c8523);return new E(_0x621d44,_0x48c809);}['maxPost'](){const _0x3c25ce=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x3c25ce);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x10f896,_0x2ed6a9){const _0x17d0f7=_0x10f896['node']['compareTo'](_0x2ed6a9['node']);return _0x17d0f7===0x0?He(_0x10f896['name'],_0x2ed6a9['name']):_0x17d0f7;}['isDefinedOn'](_0x302390){return!0x0;}['indexedValueChanged'](_0x4c627f,_0x45a553){return!_0x4c627f['equals'](_0x45a553);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5eaef4,_0x2125b3){const _0x1b940f=N(_0x5eaef4);return new E(_0x2125b3,_0x1b940f);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x11a5e3){return{'type':'value','snapshotNode':_0x11a5e3};}function tt(_0x804005,_0x29d8b8){return{'type':'child_added','snapshotNode':_0x29d8b8,'childName':_0x804005};}function Nt(_0x40be93,_0x36687f){return{'type':'child_removed','snapshotNode':_0x36687f,'childName':_0x40be93};}function Pt(_0x2e3a99,_0x1cda75,_0x510568){return{'type':'child_changed','snapshotNode':_0x1cda75,'childName':_0x2e3a99,'oldSnap':_0x510568};}function $h(_0xda3202,_0xc56434){return{'type':'child_moved','snapshotNode':_0xc56434,'childName':_0xda3202};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x5a67e7){this['index_']=_0x5a67e7;}['updateChild'](_0x28c450,_0x434ef0,_0x34edd7,_0x330985,_0x4a72cb,_0x3bcab4){f(_0x28c450['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1d86a1=_0x28c450['getImmediateChild'](_0x434ef0);return _0x1d86a1['getChild'](_0x330985)['equals'](_0x34edd7['getChild'](_0x330985))&&_0x1d86a1['isEmpty']()===_0x34edd7['isEmpty']()||(_0x3bcab4!=null&&(_0x34edd7['isEmpty']()?_0x28c450['hasChild'](_0x434ef0)?_0x3bcab4['trackChildChange'](Nt(_0x434ef0,_0x1d86a1)):f(_0x28c450['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1d86a1['isEmpty']()?_0x3bcab4['trackChildChange'](tt(_0x434ef0,_0x34edd7)):_0x3bcab4['trackChildChange'](Pt(_0x434ef0,_0x34edd7,_0x1d86a1))),_0x28c450['isLeafNode']()&&_0x34edd7['isEmpty']())?_0x28c450:_0x28c450['updateImmediateChild'](_0x434ef0,_0x34edd7)['withIndex'](this['index_']);}['updateFullNode'](_0x33129e,_0x1cd0e0,_0x26c8b7){return _0x26c8b7!=null&&(_0x33129e['isLeafNode']()||_0x33129e['forEachChild'](R,(_0xd446e1,_0x588d06)=>{_0x1cd0e0['hasChild'](_0xd446e1)||_0x26c8b7['trackChildChange'](Nt(_0xd446e1,_0x588d06));}),_0x1cd0e0['isLeafNode']()||_0x1cd0e0['forEachChild'](R,(_0x34f60b,_0xfc8eff)=>{if(_0x33129e['hasChild'](_0x34f60b)){const _0x1db229=_0x33129e['getImmediateChild'](_0x34f60b);_0x1db229['equals'](_0xfc8eff)||_0x26c8b7['trackChildChange'](Pt(_0x34f60b,_0xfc8eff,_0x1db229));}else _0x26c8b7['trackChildChange'](tt(_0x34f60b,_0xfc8eff));})),_0x1cd0e0['withIndex'](this['index_']);}['updatePriority'](_0x4fec08,_0x24dac7){return _0x4fec08['isEmpty']()?g['EMPTY_NODE']:_0x4fec08['updatePriority'](_0x24dac7);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0xa2c842){this['indexedFilter_']=new Yi(_0xa2c842['getIndex']()),this['index_']=_0xa2c842['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0xa2c842),this['endPost_']=Ot['getEndPost_'](_0xa2c842),this['startIsInclusive_']=!_0xa2c842['startAfterSet_'],this['endIsInclusive_']=!_0xa2c842['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x82f7cb){const _0x550334=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x82f7cb)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x82f7cb)<0x0,_0x1b2a89=this['endIsInclusive_']?this['index_']['compare'](_0x82f7cb,this['getEndPost']())<=0x0:this['index_']['compare'](_0x82f7cb,this['getEndPost']())<0x0;return _0x550334&&_0x1b2a89;}['updateChild'](_0x1aae2b,_0x130f09,_0x53ae07,_0x102bd7,_0x3c8e43,_0x4db22f){return this['matches'](new E(_0x130f09,_0x53ae07))||(_0x53ae07=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1aae2b,_0x130f09,_0x53ae07,_0x102bd7,_0x3c8e43,_0x4db22f);}['updateFullNode'](_0x8cce7b,_0x4ca42f,_0x37839c){_0x4ca42f['isLeafNode']()&&(_0x4ca42f=g['EMPTY_NODE']);let _0x5a46b8=_0x4ca42f['withIndex'](this['index_']);_0x5a46b8=_0x5a46b8['updatePriority'](g['EMPTY_NODE']);const _0x3e3bd1=this;return _0x4ca42f['forEachChild'](R,(_0x22e42d,_0xcce4bc)=>{_0x3e3bd1['matches'](new E(_0x22e42d,_0xcce4bc))||(_0x5a46b8=_0x5a46b8['updateImmediateChild'](_0x22e42d,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x8cce7b,_0x5a46b8,_0x37839c);}['updatePriority'](_0x255996,_0x5116ee){return _0x255996;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x12abe9){if(_0x12abe9['hasStart']()){const _0x5b10f7=_0x12abe9['getIndexStartName']();return _0x12abe9['getIndex']()['makePost'](_0x12abe9['getIndexStartValue'](),_0x5b10f7);}else return _0x12abe9['getIndex']()['minPost']();}static['getEndPost_'](_0x2830c){if(_0x2830c['hasEnd']()){const _0x1294c3=_0x2830c['getIndexEndName']();return _0x2830c['getIndex']()['makePost'](_0x2830c['getIndexEndValue'](),_0x1294c3);}else return _0x2830c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xe6b94c){this['withinDirectionalStart']=_0x318b87=>this['reverse_']?this['withinEndPost'](_0x318b87):this['withinStartPost'](_0x318b87),this['withinDirectionalEnd']=_0x1fa6be=>this['reverse_']?this['withinStartPost'](_0x1fa6be):this['withinEndPost'](_0x1fa6be),this['withinStartPost']=_0xdf16d6=>{const _0x2a3c96=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xdf16d6);return this['startIsInclusive_']?_0x2a3c96<=0x0:_0x2a3c96<0x0;},this['withinEndPost']=_0x5779d7=>{const _0x48cfa1=this['index_']['compare'](_0x5779d7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x48cfa1<=0x0:_0x48cfa1<0x0;},this['rangedFilter_']=new Ot(_0xe6b94c),this['index_']=_0xe6b94c['getIndex'](),this['limit_']=_0xe6b94c['getLimit'](),this['reverse_']=!_0xe6b94c['isViewFromLeft'](),this['startIsInclusive_']=!_0xe6b94c['startAfterSet_'],this['endIsInclusive_']=!_0xe6b94c['endBeforeSet_'];}['updateChild'](_0x2ec01a,_0x55312f,_0x449b8c,_0x329d5e,_0x5dc658,_0x2113e7){return this['rangedFilter_']['matches'](new E(_0x55312f,_0x449b8c))||(_0x449b8c=g['EMPTY_NODE']),_0x2ec01a['getImmediateChild'](_0x55312f)['equals'](_0x449b8c)?_0x2ec01a:_0x2ec01a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2ec01a,_0x55312f,_0x449b8c,_0x329d5e,_0x5dc658,_0x2113e7):this['fullLimitUpdateChild_'](_0x2ec01a,_0x55312f,_0x449b8c,_0x5dc658,_0x2113e7);}['updateFullNode'](_0x279f7c,_0x1ce0b3,_0x5ecc){let _0x1f2521;if(_0x1ce0b3['isLeafNode']()||_0x1ce0b3['isEmpty']())_0x1f2521=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1ce0b3['numChildren']()&&_0x1ce0b3['isIndexed'](this['index_'])){_0x1f2521=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x53c93d;this['reverse_']?_0x53c93d=_0x1ce0b3['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x53c93d=_0x1ce0b3['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x245633=0x0;for(;_0x53c93d['hasNext']()&&_0x245633<this['limit_'];){const _0x3c2302=_0x53c93d['getNext']();if(this['withinDirectionalStart'](_0x3c2302)){if(this['withinDirectionalEnd'](_0x3c2302))_0x1f2521=_0x1f2521['updateImmediateChild'](_0x3c2302['name'],_0x3c2302['node']),_0x245633++;else break;}else continue;}}else{_0x1f2521=_0x1ce0b3['withIndex'](this['index_']),_0x1f2521=_0x1f2521['updatePriority'](g['EMPTY_NODE']);let _0x28be14;this['reverse_']?_0x28be14=_0x1f2521['getReverseIterator'](this['index_']):_0x28be14=_0x1f2521['getIterator'](this['index_']);let _0x46e64d=0x0;for(;_0x28be14['hasNext']();){const _0x5431cf=_0x28be14['getNext']();_0x46e64d<this['limit_']&&this['withinDirectionalStart'](_0x5431cf)&&this['withinDirectionalEnd'](_0x5431cf)?_0x46e64d++:_0x1f2521=_0x1f2521['updateImmediateChild'](_0x5431cf['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x279f7c,_0x1f2521,_0x5ecc);}['updatePriority'](_0x450579,_0x57b307){return _0x450579;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3da662,_0x2a920a,_0x585978,_0x47081b,_0x4b7144){let _0x1447db;if(this['reverse_']){const _0x5bff26=this['index_']['getCompare']();_0x1447db=(_0xddfb20,_0x3417dd)=>_0x5bff26(_0x3417dd,_0xddfb20);}else _0x1447db=this['index_']['getCompare']();const _0x1c4287=_0x3da662;f(_0x1c4287['numChildren']()===this['limit_'],'');const _0x590338=new E(_0x2a920a,_0x585978),_0x18e5ef=this['reverse_']?_0x1c4287['getFirstChild'](this['index_']):_0x1c4287['getLastChild'](this['index_']),_0xd22a1f=this['rangedFilter_']['matches'](_0x590338);if(_0x1c4287['hasChild'](_0x2a920a)){const _0x442d04=_0x1c4287['getImmediateChild'](_0x2a920a);let _0x53ef43=_0x47081b['getChildAfterChild'](this['index_'],_0x18e5ef,this['reverse_']);for(;_0x53ef43!=null&&(_0x53ef43['name']===_0x2a920a||_0x1c4287['hasChild'](_0x53ef43['name']));)_0x53ef43=_0x47081b['getChildAfterChild'](this['index_'],_0x53ef43,this['reverse_']);const _0x34fb31=_0x53ef43==null?0x1:_0x1447db(_0x53ef43,_0x590338);if(_0xd22a1f&&!_0x585978['isEmpty']()&&_0x34fb31>=0x0)return _0x4b7144!=null&&_0x4b7144['trackChildChange'](Pt(_0x2a920a,_0x585978,_0x442d04)),_0x1c4287['updateImmediateChild'](_0x2a920a,_0x585978);{_0x4b7144!=null&&_0x4b7144['trackChildChange'](Nt(_0x2a920a,_0x442d04));const _0x58a855=_0x1c4287['updateImmediateChild'](_0x2a920a,g['EMPTY_NODE']);return _0x53ef43!=null&&this['rangedFilter_']['matches'](_0x53ef43)?(_0x4b7144!=null&&_0x4b7144['trackChildChange'](tt(_0x53ef43['name'],_0x53ef43['node'])),_0x58a855['updateImmediateChild'](_0x53ef43['name'],_0x53ef43['node'])):_0x58a855;}}else return _0x585978['isEmpty']()?_0x3da662:_0xd22a1f&&_0x1447db(_0x18e5ef,_0x590338)>=0x0?(_0x4b7144!=null&&(_0x4b7144['trackChildChange'](Nt(_0x18e5ef['name'],_0x18e5ef['node'])),_0x4b7144['trackChildChange'](tt(_0x2a920a,_0x585978))),_0x1c4287['updateImmediateChild'](_0x2a920a,_0x585978)['updateImmediateChild'](_0x18e5ef['name'],g['EMPTY_NODE'])):_0x3da662;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x13748f=new Qi();return _0x13748f['limitSet_']=this['limitSet_'],_0x13748f['limit_']=this['limit_'],_0x13748f['startSet_']=this['startSet_'],_0x13748f['startAfterSet_']=this['startAfterSet_'],_0x13748f['indexStartValue_']=this['indexStartValue_'],_0x13748f['startNameSet_']=this['startNameSet_'],_0x13748f['indexStartName_']=this['indexStartName_'],_0x13748f['endSet_']=this['endSet_'],_0x13748f['endBeforeSet_']=this['endBeforeSet_'],_0x13748f['indexEndValue_']=this['indexEndValue_'],_0x13748f['endNameSet_']=this['endNameSet_'],_0x13748f['indexEndName_']=this['indexEndName_'],_0x13748f['index_']=this['index_'],_0x13748f['viewFrom_']=this['viewFrom_'],_0x13748f;}}function qh(_0x38ee60){return _0x38ee60['loadsAllData']()?new Yi(_0x38ee60['getIndex']()):_0x38ee60['hasLimit']()?new Gh(_0x38ee60):new Ot(_0x38ee60);}function zh(_0xf70b2,_0x5c38cb){const _0x2ae4c2=_0xf70b2['copy']();return _0x2ae4c2['limitSet_']=!0x0,_0x2ae4c2['limit_']=_0x5c38cb,_0x2ae4c2['viewFrom_']='l',_0x2ae4c2;}function jh(_0x550f1a,_0x57f6da,_0x26431a){const _0x444af0=_0x550f1a['copy']();return _0x444af0['startSet_']=!0x0,_0x57f6da===void 0x0&&(_0x57f6da=null),_0x444af0['indexStartValue_']=_0x57f6da,_0x26431a!=null?(_0x444af0['startNameSet_']=!0x0,_0x444af0['indexStartName_']=_0x26431a):(_0x444af0['startNameSet_']=!0x1,_0x444af0['indexStartName_']=''),_0x444af0;}function Kh(_0x135b66,_0x3a3caf,_0x510f23){const _0x1a98a5=_0x135b66['copy']();return _0x1a98a5['endSet_']=!0x0,_0x3a3caf===void 0x0&&(_0x3a3caf=null),_0x1a98a5['indexEndValue_']=_0x3a3caf,_0x510f23!==void 0x0?(_0x1a98a5['endNameSet_']=!0x0,_0x1a98a5['indexEndName_']=_0x510f23):(_0x1a98a5['endNameSet_']=!0x1,_0x1a98a5['indexEndName_']=''),_0x1a98a5;}function Do(_0x2b4bd2,_0x3e8694){const _0x553eaa=_0x2b4bd2['copy']();return _0x553eaa['index_']=_0x3e8694,_0x553eaa;}function tr(_0x8bc975){const _0x568250={};if(_0x8bc975['isDefault']())return _0x568250;let _0x13d2c7;if(_0x8bc975['index_']===R?_0x13d2c7='$priority':_0x8bc975['index_']===Po?_0x13d2c7='$value':_0x8bc975['index_']===ye?_0x13d2c7='$key':(f(_0x8bc975['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x13d2c7=_0x8bc975['index_']['toString']()),_0x568250['orderBy']=O(_0x13d2c7),_0x8bc975['startSet_']){const _0x40a08f=_0x8bc975['startAfterSet_']?'startAfter':'startAt';_0x568250[_0x40a08f]=O(_0x8bc975['indexStartValue_']),_0x8bc975['startNameSet_']&&(_0x568250[_0x40a08f]+=','+O(_0x8bc975['indexStartName_']));}if(_0x8bc975['endSet_']){const _0x3ec43b=_0x8bc975['endBeforeSet_']?'endBefore':'endAt';_0x568250[_0x3ec43b]=O(_0x8bc975['indexEndValue_']),_0x8bc975['endNameSet_']&&(_0x568250[_0x3ec43b]+=','+O(_0x8bc975['indexEndName_']));}return _0x8bc975['limitSet_']&&(_0x8bc975['isViewFromLeft']()?_0x568250['limitToFirst']=_0x8bc975['limit_']:_0x568250['limitToLast']=_0x8bc975['limit_']),_0x568250;}function nr(_0x29e204){const _0x5bedce={};if(_0x29e204['startSet_']&&(_0x5bedce['sp']=_0x29e204['indexStartValue_'],_0x29e204['startNameSet_']&&(_0x5bedce['sn']=_0x29e204['indexStartName_']),_0x5bedce['sin']=!_0x29e204['startAfterSet_']),_0x29e204['endSet_']&&(_0x5bedce['ep']=_0x29e204['indexEndValue_'],_0x29e204['endNameSet_']&&(_0x5bedce['en']=_0x29e204['indexEndName_']),_0x5bedce['ein']=!_0x29e204['endBeforeSet_']),_0x29e204['limitSet_']){_0x5bedce['l']=_0x29e204['limit_'];let _0x3bf301=_0x29e204['viewFrom_'];_0x3bf301===''&&(_0x29e204['isViewFromLeft']()?_0x3bf301='l':_0x3bf301='r'),_0x5bedce['vf']=_0x3bf301;}return _0x29e204['index_']!==R&&(_0x5bedce['i']=_0x29e204['index_']['toString']()),_0x5bedce;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x466b07){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x414983,_0x50943d){return _0x50943d!==void 0x0?'tag$'+_0x50943d:(f(_0x414983['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x414983['_path']['toString']());}constructor(_0x2066e0,_0x2b3a7c,_0x370557,_0x4e9567){super(),this['repoInfo_']=_0x2066e0,this['onDataUpdate_']=_0x2b3a7c,this['authTokenProvider_']=_0x370557,this['appCheckTokenProvider_']=_0x4e9567,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2e5f67,_0xf1d22b,_0x45e3b4,_0x5753dd){const _0x54a1ae=_0x2e5f67['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x54a1ae+'\x20'+_0x2e5f67['_queryIdentifier']);const _0x5c2cc6=fn['getListenId_'](_0x2e5f67,_0x45e3b4),_0x264ef6={};this['listens_'][_0x5c2cc6]=_0x264ef6;const _0x48da12=tr(_0x2e5f67['_queryParams']);this['restRequest_'](_0x54a1ae+'.json',_0x48da12,(_0x4d3c01,_0x484407)=>{let _0x2da17a=_0x484407;if(_0x4d3c01===0x194&&(_0x2da17a=null,_0x4d3c01=null),_0x4d3c01===null&&this['onDataUpdate_'](_0x54a1ae,_0x2da17a,!0x1,_0x45e3b4),Oe(this['listens_'],_0x5c2cc6)===_0x264ef6){let _0x469c46;_0x4d3c01?_0x4d3c01===0x191?_0x469c46='permission_denied':_0x469c46='rest_error:'+_0x4d3c01:_0x469c46='ok',_0x5753dd(_0x469c46,null);}});}['unlisten'](_0x56f558,_0x1881b0){const _0x153c0c=fn['getListenId_'](_0x56f558,_0x1881b0);delete this['listens_'][_0x153c0c];}['get'](_0x11aa72){const _0x5b2985=tr(_0x11aa72['_queryParams']),_0x45a867=_0x11aa72['_path']['toString'](),_0x52c3d1=new Ve();return this['restRequest_'](_0x45a867+'.json',_0x5b2985,(_0xde2249,_0x4eab13)=>{let _0x480f95=_0x4eab13;_0xde2249===0x194&&(_0x480f95=null,_0xde2249=null),_0xde2249===null?(this['onDataUpdate_'](_0x45a867,_0x480f95,!0x1,null),_0x52c3d1['resolve'](_0x480f95)):_0x52c3d1['reject'](new Error(_0x480f95));}),_0x52c3d1['promise'];}['refreshAuthToken'](_0xe2c7ae){}['restRequest_'](_0x2c2ac4,_0x15eaf5={},_0x2ee2c1){return _0x15eaf5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5606d6,_0x95e2c5])=>{_0x5606d6&&_0x5606d6['accessToken']&&(_0x15eaf5['auth']=_0x5606d6['accessToken']),_0x95e2c5&&_0x95e2c5['token']&&(_0x15eaf5['ac']=_0x95e2c5['token']);const _0x6996cf=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2c2ac4+'?ns='+this['repoInfo_']['namespace']+at(_0x15eaf5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x6996cf);const _0x48722d=new XMLHttpRequest();_0x48722d['onreadystatechange']=()=>{if(_0x2ee2c1&&_0x48722d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x6996cf+'\x20received.\x20status:',_0x48722d['status'],'response:',_0x48722d['responseText']);let _0x159f0a=null;if(_0x48722d['status']>=0xc8&&_0x48722d['status']<0x12c){try{_0x159f0a=bt(_0x48722d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x6996cf+':\x20'+_0x48722d['responseText']);}_0x2ee2c1(null,_0x159f0a);}else _0x48722d['status']!==0x191&&_0x48722d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x6996cf+'\x20Status:\x20'+_0x48722d['status']),_0x2ee2c1(_0x48722d['status']);_0x2ee2c1=null;}},_0x48722d['open']('GET',_0x6996cf,!0x0),_0x48722d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5bf8af){return this['rootNode_']['getChild'](_0x5bf8af);}['updateSnapshot'](_0x5e859c,_0x1595cf){this['rootNode_']=this['rootNode_']['updateChild'](_0x5e859c,_0x1595cf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x22ed96,_0x2bdb38,_0x514fc8){if(v(_0x2bdb38))_0x22ed96['value']=_0x514fc8,_0x22ed96['children']['clear']();else{if(_0x22ed96['value']!==null)_0x22ed96['value']=_0x22ed96['value']['updateChild'](_0x2bdb38,_0x514fc8);else{const _0x8d5be=y(_0x2bdb38);_0x22ed96['children']['has'](_0x8d5be)||_0x22ed96['children']['set'](_0x8d5be,pn());const _0x3a00b0=_0x22ed96['children']['get'](_0x8d5be);_0x2bdb38=b(_0x2bdb38),Mo(_0x3a00b0,_0x2bdb38,_0x514fc8);}}}function Ei(_0x55a329,_0x4ab172,_0x39382b){_0x55a329['value']!==null?_0x39382b(_0x4ab172,_0x55a329['value']):Qh(_0x55a329,(_0x1c0aaf,_0x502cb7)=>{const _0x59d336=new C(_0x4ab172['toString']()+'/'+_0x1c0aaf);Ei(_0x502cb7,_0x59d336,_0x39382b);});}function Qh(_0x379a2e,_0x2478dd){_0x379a2e['children']['forEach']((_0x6b5247,_0x569edd)=>{_0x2478dd(_0x569edd,_0x6b5247);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x29cae7){this['collection_']=_0x29cae7,this['last_']=null;}['get'](){const _0x49cc92=this['collection_']['get'](),_0x3deee3={..._0x49cc92};return this['last_']&&x(this['last_'],(_0x1666b0,_0xade995)=>{_0x3deee3[_0x1666b0]=_0x3deee3[_0x1666b0]-_0xade995;}),this['last_']=_0x49cc92,_0x3deee3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x2abe45,_0x3689db){this['server_']=_0x3689db,this['statsToReport_']={},this['statsListener_']=new Jh(_0x2abe45);const _0x2d49d0=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2d49d0));}['reportStats_'](){const _0x2cd24d=this['statsListener_']['get'](),_0x386732={};let _0xaea233=!0x1;x(_0x2cd24d,(_0xae21f,_0x4bd23b)=>{_0x4bd23b>0x0&&Y(this['statsToReport_'],_0xae21f)&&(_0x386732[_0xae21f]=_0x4bd23b,_0xaea233=!0x0);}),_0xaea233&&this['server_']['reportStats'](_0x386732),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x13e823){_0x13e823[_0x13e823['OVERWRITE']=0x0]='OVERWRITE',_0x13e823[_0x13e823['MERGE']=0x1]='MERGE',_0x13e823[_0x13e823['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x13e823[_0x13e823['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x1857eb){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1857eb,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3b32ad,_0x21d176,_0xca2982){this['path']=_0x3b32ad,this['affectedTree']=_0x21d176,this['revert']=_0xca2982,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x2646cb){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x441b92=this['affectedTree']['subtree'](new C(_0x2646cb));return new _n(w(),_0x441b92,this['revert']);}}else return f(y(this['path'])===_0x2646cb,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5c1b48,_0x536246){this['source']=_0x5c1b48,this['path']=_0x536246,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x31fa6c){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x212b15,_0x29ce1e,_0x5cfd4b){this['source']=_0x212b15,this['path']=_0x29ce1e,this['snap']=_0x5cfd4b,this['type']=q['OVERWRITE'];}['operationForChild'](_0x94c0c4){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x94c0c4)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x4b62dc,_0x258fb6,_0x46b613){this['source']=_0x4b62dc,this['path']=_0x258fb6,this['children']=_0x46b613,this['type']=q['MERGE'];}['operationForChild'](_0x170b50){if(v(this['path'])){const _0x15a25b=this['children']['subtree'](new C(_0x170b50));return _0x15a25b['isEmpty']()?null:_0x15a25b['value']?new Fe(this['source'],w(),_0x15a25b['value']):new nt(this['source'],w(),_0x15a25b);}else return f(y(this['path'])===_0x170b50,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2d6566,_0x490826,_0x45d7f7){this['node_']=_0x2d6566,this['fullyInitialized_']=_0x490826,this['filtered_']=_0x45d7f7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1bfc00){if(v(_0x1bfc00))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3efb76=y(_0x1bfc00);return this['isCompleteForChild'](_0x3efb76);}['isCompleteForChild'](_0x3dc1f9){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3dc1f9);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x43b539){this['query_']=_0x43b539,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5610af,_0x5acdbe,_0x30daa1,_0x24eb18){const _0x5624db=[],_0x37c1fa=[];return _0x5acdbe['forEach'](_0x1be219=>{_0x1be219['type']==='child_changed'&&_0x5610af['index_']['indexedValueChanged'](_0x1be219['oldSnap'],_0x1be219['snapshotNode'])&&_0x37c1fa['push']($h(_0x1be219['childName'],_0x1be219['snapshotNode']));}),mt(_0x5610af,_0x5624db,'child_removed',_0x5acdbe,_0x24eb18,_0x30daa1),mt(_0x5610af,_0x5624db,'child_added',_0x5acdbe,_0x24eb18,_0x30daa1),mt(_0x5610af,_0x5624db,'child_moved',_0x37c1fa,_0x24eb18,_0x30daa1),mt(_0x5610af,_0x5624db,'child_changed',_0x5acdbe,_0x24eb18,_0x30daa1),mt(_0x5610af,_0x5624db,'value',_0x5acdbe,_0x24eb18,_0x30daa1),_0x5624db;}function mt(_0x2d7a54,_0xf833c7,_0x26894f,_0x4608a8,_0x59e0b2,_0x2be76c){const _0x5e16a4=_0x4608a8['filter'](_0x59b394=>_0x59b394['type']===_0x26894f);_0x5e16a4['sort']((_0x400a51,_0x3965fb)=>su(_0x2d7a54,_0x400a51,_0x3965fb)),_0x5e16a4['forEach'](_0x2928c5=>{const _0x4adebb=iu(_0x2d7a54,_0x2928c5,_0x2be76c);_0x59e0b2['forEach'](_0x33b9d5=>{_0x33b9d5['respondsTo'](_0x2928c5['type'])&&_0xf833c7['push'](_0x33b9d5['createEvent'](_0x4adebb,_0x2d7a54['query_']));});});}function iu(_0x1da596,_0x5ef236,_0xcf6f0c){return _0x5ef236['type']==='value'||_0x5ef236['type']==='child_removed'||(_0x5ef236['prevName']=_0xcf6f0c['getPredecessorChildName'](_0x5ef236['childName'],_0x5ef236['snapshotNode'],_0x1da596['index_'])),_0x5ef236;}function su(_0x3d242a,_0x82c789,_0x5cdbf8){if(_0x82c789['childName']==null||_0x5cdbf8['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x59ff37=new E(_0x82c789['childName'],_0x82c789['snapshotNode']),_0xe1804c=new E(_0x5cdbf8['childName'],_0x5cdbf8['snapshotNode']);return _0x3d242a['index_']['compare'](_0x59ff37,_0xe1804c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x2083fd,_0x4c3bfa){return{'eventCache':_0x2083fd,'serverCache':_0x4c3bfa};}function wt(_0x1da158,_0x28d8e9,_0x1dee71,_0x15ac56){return Dn(new Ce(_0x28d8e9,_0x1dee71,_0x15ac56),_0x1da158['serverCache']);}function Lo(_0x59e385,_0x5764fa,_0x4c49e5,_0x43ec36){return Dn(_0x59e385['eventCache'],new Ce(_0x5764fa,_0x4c49e5,_0x43ec36));}function gn(_0x3405c1){return _0x3405c1['eventCache']['isFullyInitialized']()?_0x3405c1['eventCache']['getNode']():null;}function Ue(_0x1f6a60){return _0x1f6a60['serverCache']['isFullyInitialized']()?_0x1f6a60['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x17183b){let _0x9cfc75=new S(null);return x(_0x17183b,(_0x25e514,_0x5f2fd1)=>{_0x9cfc75=_0x9cfc75['set'](new C(_0x25e514),_0x5f2fd1);}),_0x9cfc75;}constructor(_0x15b1c7,_0x40c596=ru()){this['value']=_0x15b1c7,this['children']=_0x40c596;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x444f69,_0x201a52){if(this['value']!=null&&_0x201a52(this['value']))return{'path':w(),'value':this['value']};if(v(_0x444f69))return null;{const _0x44555c=y(_0x444f69),_0x10941e=this['children']['get'](_0x44555c);if(_0x10941e!==null){const _0x16e2b3=_0x10941e['findRootMostMatchingPathAndValue'](b(_0x444f69),_0x201a52);return _0x16e2b3!=null?{'path':A(new C(_0x44555c),_0x16e2b3['path']),'value':_0x16e2b3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4ad002){return this['findRootMostMatchingPathAndValue'](_0x4ad002,()=>!0x0);}['subtree'](_0x335bf9){if(v(_0x335bf9))return this;{const _0x12fb35=y(_0x335bf9),_0x2db306=this['children']['get'](_0x12fb35);return _0x2db306!==null?_0x2db306['subtree'](b(_0x335bf9)):new S(null);}}['set'](_0x5227e5,_0xc38189){if(v(_0x5227e5))return new S(_0xc38189,this['children']);{const _0x5cfd41=y(_0x5227e5),_0x278235=(this['children']['get'](_0x5cfd41)||new S(null))['set'](b(_0x5227e5),_0xc38189),_0x502562=this['children']['insert'](_0x5cfd41,_0x278235);return new S(this['value'],_0x502562);}}['remove'](_0x386276){if(v(_0x386276))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4ab53a=y(_0x386276),_0xf811e0=this['children']['get'](_0x4ab53a);if(_0xf811e0){const _0x1d9e43=_0xf811e0['remove'](b(_0x386276));let _0x233804;return _0x1d9e43['isEmpty']()?_0x233804=this['children']['remove'](_0x4ab53a):_0x233804=this['children']['insert'](_0x4ab53a,_0x1d9e43),this['value']===null&&_0x233804['isEmpty']()?new S(null):new S(this['value'],_0x233804);}else return this;}}['get'](_0x1d44d7){if(v(_0x1d44d7))return this['value'];{const _0x596e13=y(_0x1d44d7),_0x5c2830=this['children']['get'](_0x596e13);return _0x5c2830?_0x5c2830['get'](b(_0x1d44d7)):null;}}['setTree'](_0x5dc53e,_0x33da13){if(v(_0x5dc53e))return _0x33da13;{const _0x8ce530=y(_0x5dc53e),_0x56c23b=(this['children']['get'](_0x8ce530)||new S(null))['setTree'](b(_0x5dc53e),_0x33da13);let _0x965b06;return _0x56c23b['isEmpty']()?_0x965b06=this['children']['remove'](_0x8ce530):_0x965b06=this['children']['insert'](_0x8ce530,_0x56c23b),new S(this['value'],_0x965b06);}}['fold'](_0x391309){return this['fold_'](w(),_0x391309);}['fold_'](_0x39f5f8,_0x3f0280){const _0x236e79={};return this['children']['inorderTraversal']((_0x595cf7,_0x55fa83)=>{_0x236e79[_0x595cf7]=_0x55fa83['fold_'](A(_0x39f5f8,_0x595cf7),_0x3f0280);}),_0x3f0280(_0x39f5f8,this['value'],_0x236e79);}['findOnPath'](_0x15575f,_0x300e29){return this['findOnPath_'](_0x15575f,w(),_0x300e29);}['findOnPath_'](_0x52a885,_0x918aac,_0x4b5100){const _0x1434b2=this['value']?_0x4b5100(_0x918aac,this['value']):!0x1;if(_0x1434b2)return _0x1434b2;if(v(_0x52a885))return null;{const _0x357696=y(_0x52a885),_0x47d210=this['children']['get'](_0x357696);return _0x47d210?_0x47d210['findOnPath_'](b(_0x52a885),A(_0x918aac,_0x357696),_0x4b5100):null;}}['foreachOnPath'](_0x238722,_0x27eba9){return this['foreachOnPath_'](_0x238722,w(),_0x27eba9);}['foreachOnPath_'](_0x3ebbad,_0x55c5dd,_0x40c5ba){if(v(_0x3ebbad))return this;{this['value']&&_0x40c5ba(_0x55c5dd,this['value']);const _0x3bec6a=y(_0x3ebbad),_0x2bf47c=this['children']['get'](_0x3bec6a);return _0x2bf47c?_0x2bf47c['foreachOnPath_'](b(_0x3ebbad),A(_0x55c5dd,_0x3bec6a),_0x40c5ba):new S(null);}}['foreach'](_0x127c39){this['foreach_'](w(),_0x127c39);}['foreach_'](_0x5cf103,_0x2dd272){this['children']['inorderTraversal']((_0x4c674d,_0x2f827c)=>{_0x2f827c['foreach_'](A(_0x5cf103,_0x4c674d),_0x2dd272);}),this['value']&&_0x2dd272(_0x5cf103,this['value']);}['foreachChild'](_0x3cd0a4){this['children']['inorderTraversal']((_0xbaee3c,_0x5cddb8)=>{_0x5cddb8['value']&&_0x3cd0a4(_0xbaee3c,_0x5cddb8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x5bdc66){this['writeTree_']=_0x5bdc66;}static['empty'](){return new j(new S(null));}}function Ct(_0x226ab4,_0x2255b4,_0x322b66){if(v(_0x2255b4))return new j(new S(_0x322b66));{const _0x2f3389=_0x226ab4['writeTree_']['findRootMostValueAndPath'](_0x2255b4);if(_0x2f3389!=null){const _0x2d3372=_0x2f3389['path'];let _0x5213c4=_0x2f3389['value'];const _0x53316f=F(_0x2d3372,_0x2255b4);return _0x5213c4=_0x5213c4['updateChild'](_0x53316f,_0x322b66),new j(_0x226ab4['writeTree_']['set'](_0x2d3372,_0x5213c4));}else{const _0x3da15b=new S(_0x322b66),_0x5b4183=_0x226ab4['writeTree_']['setTree'](_0x2255b4,_0x3da15b);return new j(_0x5b4183);}}}function Ii(_0x342a34,_0x302382,_0x23aa08){let _0x50b072=_0x342a34;return x(_0x23aa08,(_0x156da4,_0x3a6724)=>{_0x50b072=Ct(_0x50b072,A(_0x302382,_0x156da4),_0x3a6724);}),_0x50b072;}function sr(_0x4e4350,_0x425e4b){if(v(_0x425e4b))return j['empty']();{const _0x4bcca3=_0x4e4350['writeTree_']['setTree'](_0x425e4b,new S(null));return new j(_0x4bcca3);}}function wi(_0x4a0866,_0x1bce1a){return $e(_0x4a0866,_0x1bce1a)!=null;}function $e(_0x1aafc6,_0x5c54c9){const _0x21cff0=_0x1aafc6['writeTree_']['findRootMostValueAndPath'](_0x5c54c9);return _0x21cff0!=null?_0x1aafc6['writeTree_']['get'](_0x21cff0['path'])['getChild'](F(_0x21cff0['path'],_0x5c54c9)):null;}function rr(_0x312db1){const _0x1b876e=[],_0x4e5cf5=_0x312db1['writeTree_']['value'];return _0x4e5cf5!=null?_0x4e5cf5['isLeafNode']()||_0x4e5cf5['forEachChild'](R,(_0x434722,_0x413959)=>{_0x1b876e['push'](new E(_0x434722,_0x413959));}):_0x312db1['writeTree_']['children']['inorderTraversal']((_0x17b983,_0x141c34)=>{_0x141c34['value']!=null&&_0x1b876e['push'](new E(_0x17b983,_0x141c34['value']));}),_0x1b876e;}function ve(_0x56812c,_0x448812){if(v(_0x448812))return _0x56812c;{const _0xdc7b84=$e(_0x56812c,_0x448812);return _0xdc7b84!=null?new j(new S(_0xdc7b84)):new j(_0x56812c['writeTree_']['subtree'](_0x448812));}}function Ci(_0x38c8e4){return _0x38c8e4['writeTree_']['isEmpty']();}function it(_0x23a2ea,_0x3ea129){return xo(w(),_0x23a2ea['writeTree_'],_0x3ea129);}function xo(_0x35c67f,_0x4abdda,_0x2c8bb){if(_0x4abdda['value']!=null)return _0x2c8bb['updateChild'](_0x35c67f,_0x4abdda['value']);{let _0x2a2706=null;return _0x4abdda['children']['inorderTraversal']((_0x18c1f3,_0x182274)=>{_0x18c1f3==='.priority'?(f(_0x182274['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2a2706=_0x182274['value']):_0x2c8bb=xo(A(_0x35c67f,_0x18c1f3),_0x182274,_0x2c8bb);}),!_0x2c8bb['getChild'](_0x35c67f)['isEmpty']()&&_0x2a2706!==null&&(_0x2c8bb=_0x2c8bb['updateChild'](A(_0x35c67f,'.priority'),_0x2a2706)),_0x2c8bb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x8172a3,_0x3ba896){return Bo(_0x3ba896,_0x8172a3);}function ou(_0x2da943,_0x2368b6,_0x1aded1,_0x502b9c,_0x50aac9){f(_0x502b9c>_0x2da943['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x50aac9===void 0x0&&(_0x50aac9=!0x0),_0x2da943['allWrites']['push']({'path':_0x2368b6,'snap':_0x1aded1,'writeId':_0x502b9c,'visible':_0x50aac9}),_0x50aac9&&(_0x2da943['visibleWrites']=Ct(_0x2da943['visibleWrites'],_0x2368b6,_0x1aded1)),_0x2da943['lastWriteId']=_0x502b9c;}function au(_0x2696ac,_0x122630,_0xc960d8,_0x3b7132){f(_0x3b7132>_0x2696ac['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2696ac['allWrites']['push']({'path':_0x122630,'children':_0xc960d8,'writeId':_0x3b7132,'visible':!0x0}),_0x2696ac['visibleWrites']=Ii(_0x2696ac['visibleWrites'],_0x122630,_0xc960d8),_0x2696ac['lastWriteId']=_0x3b7132;}function cu(_0x4bfdc5,_0x32e107){for(let _0x1c64b1=0x0;_0x1c64b1<_0x4bfdc5['allWrites']['length'];_0x1c64b1++){const _0x3f442b=_0x4bfdc5['allWrites'][_0x1c64b1];if(_0x3f442b['writeId']===_0x32e107)return _0x3f442b;}return null;}function lu(_0x44de97,_0x357315){const _0x501e6e=_0x44de97['allWrites']['findIndex'](_0x4ecc26=>_0x4ecc26['writeId']===_0x357315);f(_0x501e6e>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4002d3=_0x44de97['allWrites'][_0x501e6e];_0x44de97['allWrites']['splice'](_0x501e6e,0x1);let _0x4c77b5=_0x4002d3['visible'],_0x542401=!0x1,_0x4daabf=_0x44de97['allWrites']['length']-0x1;for(;_0x4c77b5&&_0x4daabf>=0x0;){const _0x4a3897=_0x44de97['allWrites'][_0x4daabf];_0x4a3897['visible']&&(_0x4daabf>=_0x501e6e&&hu(_0x4a3897,_0x4002d3['path'])?_0x4c77b5=!0x1:$(_0x4002d3['path'],_0x4a3897['path'])&&(_0x542401=!0x0)),_0x4daabf--;}if(_0x4c77b5){if(_0x542401)return uu(_0x44de97),!0x0;if(_0x4002d3['snap'])_0x44de97['visibleWrites']=sr(_0x44de97['visibleWrites'],_0x4002d3['path']);else{const _0x3602dd=_0x4002d3['children'];x(_0x3602dd,_0x257dae=>{_0x44de97['visibleWrites']=sr(_0x44de97['visibleWrites'],A(_0x4002d3['path'],_0x257dae));});}return!0x0;}else return!0x1;}function hu(_0x189d64,_0x2dc867){if(_0x189d64['snap'])return $(_0x189d64['path'],_0x2dc867);for(const _0xf8bf55 in _0x189d64['children'])if(_0x189d64['children']['hasOwnProperty'](_0xf8bf55)&&$(A(_0x189d64['path'],_0xf8bf55),_0x2dc867))return!0x0;return!0x1;}function uu(_0x1e5a8d){_0x1e5a8d['visibleWrites']=Fo(_0x1e5a8d['allWrites'],du,w()),_0x1e5a8d['allWrites']['length']>0x0?_0x1e5a8d['lastWriteId']=_0x1e5a8d['allWrites'][_0x1e5a8d['allWrites']['length']-0x1]['writeId']:_0x1e5a8d['lastWriteId']=-0x1;}function du(_0x104431){return _0x104431['visible'];}function Fo(_0x5efa3c,_0x83b117,_0x108f31){let _0x387573=j['empty']();for(let _0x7c41ec=0x0;_0x7c41ec<_0x5efa3c['length'];++_0x7c41ec){const _0x4f27fe=_0x5efa3c[_0x7c41ec];if(_0x83b117(_0x4f27fe)){const _0x447d6b=_0x4f27fe['path'];let _0x2b8188;if(_0x4f27fe['snap'])$(_0x108f31,_0x447d6b)?(_0x2b8188=F(_0x108f31,_0x447d6b),_0x387573=Ct(_0x387573,_0x2b8188,_0x4f27fe['snap'])):$(_0x447d6b,_0x108f31)&&(_0x2b8188=F(_0x447d6b,_0x108f31),_0x387573=Ct(_0x387573,w(),_0x4f27fe['snap']['getChild'](_0x2b8188)));else{if(_0x4f27fe['children']){if($(_0x108f31,_0x447d6b))_0x2b8188=F(_0x108f31,_0x447d6b),_0x387573=Ii(_0x387573,_0x2b8188,_0x4f27fe['children']);else{if($(_0x447d6b,_0x108f31)){if(_0x2b8188=F(_0x447d6b,_0x108f31),v(_0x2b8188))_0x387573=Ii(_0x387573,w(),_0x4f27fe['children']);else{const _0x48c02b=Oe(_0x4f27fe['children'],y(_0x2b8188));if(_0x48c02b){const _0xfd47d5=_0x48c02b['getChild'](b(_0x2b8188));_0x387573=Ct(_0x387573,w(),_0xfd47d5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x387573;}function Uo(_0x558a3d,_0x73c4c7,_0x10a13d,_0x3753a7,_0x476402){if(!_0x3753a7&&!_0x476402){const _0x3442fd=$e(_0x558a3d['visibleWrites'],_0x73c4c7);if(_0x3442fd!=null)return _0x3442fd;{const _0x136c6e=ve(_0x558a3d['visibleWrites'],_0x73c4c7);if(Ci(_0x136c6e))return _0x10a13d;if(_0x10a13d==null&&!wi(_0x136c6e,w()))return null;{const _0x1d7129=_0x10a13d||g['EMPTY_NODE'];return it(_0x136c6e,_0x1d7129);}}}else{const _0x33fbaa=ve(_0x558a3d['visibleWrites'],_0x73c4c7);if(!_0x476402&&Ci(_0x33fbaa))return _0x10a13d;if(!_0x476402&&_0x10a13d==null&&!wi(_0x33fbaa,w()))return null;{const _0x3040ee=function(_0x41f49e){return(_0x41f49e['visible']||_0x476402)&&(!_0x3753a7||!~_0x3753a7['indexOf'](_0x41f49e['writeId']))&&($(_0x41f49e['path'],_0x73c4c7)||$(_0x73c4c7,_0x41f49e['path']));},_0x7842a6=Fo(_0x558a3d['allWrites'],_0x3040ee,_0x73c4c7),_0x120c76=_0x10a13d||g['EMPTY_NODE'];return it(_0x7842a6,_0x120c76);}}}function fu(_0x16e704,_0x45317d,_0xae00df){let _0x54a1e6=g['EMPTY_NODE'];const _0x5718d5=$e(_0x16e704['visibleWrites'],_0x45317d);if(_0x5718d5)return _0x5718d5['isLeafNode']()||_0x5718d5['forEachChild'](R,(_0x4d0cf7,_0x12cfa0)=>{_0x54a1e6=_0x54a1e6['updateImmediateChild'](_0x4d0cf7,_0x12cfa0);}),_0x54a1e6;if(_0xae00df){const _0x57adc6=ve(_0x16e704['visibleWrites'],_0x45317d);return _0xae00df['forEachChild'](R,(_0x2c1aa4,_0x3662ac)=>{const _0x5d3cc3=it(ve(_0x57adc6,new C(_0x2c1aa4)),_0x3662ac);_0x54a1e6=_0x54a1e6['updateImmediateChild'](_0x2c1aa4,_0x5d3cc3);}),rr(_0x57adc6)['forEach'](_0xd39767=>{_0x54a1e6=_0x54a1e6['updateImmediateChild'](_0xd39767['name'],_0xd39767['node']);}),_0x54a1e6;}else{const _0x4e2a76=ve(_0x16e704['visibleWrites'],_0x45317d);return rr(_0x4e2a76)['forEach'](_0x5dfb89=>{_0x54a1e6=_0x54a1e6['updateImmediateChild'](_0x5dfb89['name'],_0x5dfb89['node']);}),_0x54a1e6;}}function pu(_0x3b8e59,_0x490492,_0x17c1f8,_0x11345c,_0x4f3ce8){f(_0x11345c||_0x4f3ce8,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x26fba3=A(_0x490492,_0x17c1f8);if(wi(_0x3b8e59['visibleWrites'],_0x26fba3))return null;{const _0x1b4cd0=ve(_0x3b8e59['visibleWrites'],_0x26fba3);return Ci(_0x1b4cd0)?_0x4f3ce8['getChild'](_0x17c1f8):it(_0x1b4cd0,_0x4f3ce8['getChild'](_0x17c1f8));}}function _u(_0xc51b80,_0x26f896,_0x5d2f51,_0x3ea1ee){const _0x419ed1=A(_0x26f896,_0x5d2f51),_0x191b8b=$e(_0xc51b80['visibleWrites'],_0x419ed1);if(_0x191b8b!=null)return _0x191b8b;if(_0x3ea1ee['isCompleteForChild'](_0x5d2f51)){const _0x23177d=ve(_0xc51b80['visibleWrites'],_0x419ed1);return it(_0x23177d,_0x3ea1ee['getNode']()['getImmediateChild'](_0x5d2f51));}else return null;}function gu(_0x148251,_0x53ae5d){return $e(_0x148251['visibleWrites'],_0x53ae5d);}function mu(_0x488436,_0x1c18a6,_0x3b5fb2,_0x123a4c,_0x41c359,_0x3ca782,_0x1e923d){let _0x1d1ef3;const _0x188639=ve(_0x488436['visibleWrites'],_0x1c18a6),_0x6431cb=$e(_0x188639,w());if(_0x6431cb!=null)_0x1d1ef3=_0x6431cb;else{if(_0x3b5fb2!=null)_0x1d1ef3=it(_0x188639,_0x3b5fb2);else return[];}if(_0x1d1ef3=_0x1d1ef3['withIndex'](_0x1e923d),!_0x1d1ef3['isEmpty']()&&!_0x1d1ef3['isLeafNode']()){const _0x15223a=[],_0x2d86bc=_0x1e923d['getCompare'](),_0xdf5a8d=_0x3ca782?_0x1d1ef3['getReverseIteratorFrom'](_0x123a4c,_0x1e923d):_0x1d1ef3['getIteratorFrom'](_0x123a4c,_0x1e923d);let _0x2b61a4=_0xdf5a8d['getNext']();for(;_0x2b61a4&&_0x15223a['length']<_0x41c359;)_0x2d86bc(_0x2b61a4,_0x123a4c)!==0x0&&_0x15223a['push'](_0x2b61a4),_0x2b61a4=_0xdf5a8d['getNext']();return _0x15223a;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x221382,_0x5a09e5,_0x49172a,_0x2208ac){return Uo(_0x221382['writeTree'],_0x221382['treePath'],_0x5a09e5,_0x49172a,_0x2208ac);}function es(_0x2805df,_0x5665fc){return fu(_0x2805df['writeTree'],_0x2805df['treePath'],_0x5665fc);}function or(_0x29ccc1,_0x219791,_0x56313c,_0x472387){return pu(_0x29ccc1['writeTree'],_0x29ccc1['treePath'],_0x219791,_0x56313c,_0x472387);}function yn(_0x51ad30,_0x4a043b){return gu(_0x51ad30['writeTree'],A(_0x51ad30['treePath'],_0x4a043b));}function vu(_0x3e7719,_0x461b90,_0x368212,_0x3a9294,_0xa2abf8,_0x3bad6b){return mu(_0x3e7719['writeTree'],_0x3e7719['treePath'],_0x461b90,_0x368212,_0x3a9294,_0xa2abf8,_0x3bad6b);}function ts(_0x2535c0,_0x7d90cc,_0x30c6d6){return _u(_0x2535c0['writeTree'],_0x2535c0['treePath'],_0x7d90cc,_0x30c6d6);}function Wo(_0x55ce4a,_0x449dd1){return Bo(A(_0x55ce4a['treePath'],_0x449dd1),_0x55ce4a['writeTree']);}function Bo(_0x2c4a15,_0xab1479){return{'treePath':_0x2c4a15,'writeTree':_0xab1479};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x51223d){const _0x1a16e0=_0x51223d['type'],_0x574e9d=_0x51223d['childName'];f(_0x1a16e0==='child_added'||_0x1a16e0==='child_changed'||_0x1a16e0==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x574e9d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5f0524=this['changeMap']['get'](_0x574e9d);if(_0x5f0524){const _0x56fb5f=_0x5f0524['type'];if(_0x1a16e0==='child_added'&&_0x56fb5f==='child_removed')this['changeMap']['set'](_0x574e9d,Pt(_0x574e9d,_0x51223d['snapshotNode'],_0x5f0524['snapshotNode']));else{if(_0x1a16e0==='child_removed'&&_0x56fb5f==='child_added')this['changeMap']['delete'](_0x574e9d);else{if(_0x1a16e0==='child_removed'&&_0x56fb5f==='child_changed')this['changeMap']['set'](_0x574e9d,Nt(_0x574e9d,_0x5f0524['oldSnap']));else{if(_0x1a16e0==='child_changed'&&_0x56fb5f==='child_added')this['changeMap']['set'](_0x574e9d,tt(_0x574e9d,_0x51223d['snapshotNode']));else{if(_0x1a16e0==='child_changed'&&_0x56fb5f==='child_changed')this['changeMap']['set'](_0x574e9d,Pt(_0x574e9d,_0x51223d['snapshotNode'],_0x5f0524['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x51223d+'\x20occurred\x20after\x20'+_0x5f0524);}}}}}else this['changeMap']['set'](_0x574e9d,_0x51223d);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x34ff0a){return null;}['getChildAfterChild'](_0x1a4bd1,_0x1d401e,_0x5113ef){return null;}}const Vo=new Iu();class ns{constructor(_0xfb6fc9,_0x41bc9b,_0x3aa8c5=null){this['writes_']=_0xfb6fc9,this['viewCache_']=_0x41bc9b,this['optCompleteServerCache_']=_0x3aa8c5;}['getCompleteChild'](_0x32e70a){const _0x4f6db4=this['viewCache_']['eventCache'];if(_0x4f6db4['isCompleteForChild'](_0x32e70a))return _0x4f6db4['getNode']()['getImmediateChild'](_0x32e70a);{const _0x225443=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x32e70a,_0x225443);}}['getChildAfterChild'](_0x4c5b95,_0x152fab,_0x47b5c5){const _0x2f561b=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0xef42d9=vu(this['writes_'],_0x2f561b,_0x152fab,0x1,_0x47b5c5,_0x4c5b95);return _0xef42d9['length']===0x0?null:_0xef42d9[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x28cc74){return{'filter':_0x28cc74};}function Cu(_0x19b4db,_0xe0f79){f(_0xe0f79['eventCache']['getNode']()['isIndexed'](_0x19b4db['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xe0f79['serverCache']['getNode']()['isIndexed'](_0x19b4db['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5115a3,_0x8d11b1,_0x30f45f,_0x3fcf0d,_0x5cf091){const _0x119c25=new Eu();let _0x1be7eb,_0x3be7c6;if(_0x30f45f['type']===q['OVERWRITE']){const _0x48b92b=_0x30f45f;_0x48b92b['source']['fromUser']?_0x1be7eb=Ti(_0x5115a3,_0x8d11b1,_0x48b92b['path'],_0x48b92b['snap'],_0x3fcf0d,_0x5cf091,_0x119c25):(f(_0x48b92b['source']['fromServer'],'Unknown\x20source.'),_0x3be7c6=_0x48b92b['source']['tagged']||_0x8d11b1['serverCache']['isFiltered']()&&!v(_0x48b92b['path']),_0x1be7eb=vn(_0x5115a3,_0x8d11b1,_0x48b92b['path'],_0x48b92b['snap'],_0x3fcf0d,_0x5cf091,_0x3be7c6,_0x119c25));}else{if(_0x30f45f['type']===q['MERGE']){const _0x418a06=_0x30f45f;_0x418a06['source']['fromUser']?_0x1be7eb=bu(_0x5115a3,_0x8d11b1,_0x418a06['path'],_0x418a06['children'],_0x3fcf0d,_0x5cf091,_0x119c25):(f(_0x418a06['source']['fromServer'],'Unknown\x20source.'),_0x3be7c6=_0x418a06['source']['tagged']||_0x8d11b1['serverCache']['isFiltered'](),_0x1be7eb=Si(_0x5115a3,_0x8d11b1,_0x418a06['path'],_0x418a06['children'],_0x3fcf0d,_0x5cf091,_0x3be7c6,_0x119c25));}else{if(_0x30f45f['type']===q['ACK_USER_WRITE']){const _0x403845=_0x30f45f;_0x403845['revert']?_0x1be7eb=ku(_0x5115a3,_0x8d11b1,_0x403845['path'],_0x3fcf0d,_0x5cf091,_0x119c25):_0x1be7eb=Ru(_0x5115a3,_0x8d11b1,_0x403845['path'],_0x403845['affectedTree'],_0x3fcf0d,_0x5cf091,_0x119c25);}else{if(_0x30f45f['type']===q['LISTEN_COMPLETE'])_0x1be7eb=Au(_0x5115a3,_0x8d11b1,_0x30f45f['path'],_0x3fcf0d,_0x119c25);else throw ot('Unknown\x20operation\x20type:\x20'+_0x30f45f['type']);}}}const _0xff7b3a=_0x119c25['getChanges']();return Su(_0x8d11b1,_0x1be7eb,_0xff7b3a),{'viewCache':_0x1be7eb,'changes':_0xff7b3a};}function Su(_0x16c9d1,_0xd2d296,_0x826cf5){const _0x400c10=_0xd2d296['eventCache'];if(_0x400c10['isFullyInitialized']()){const _0x3f867f=_0x400c10['getNode']()['isLeafNode']()||_0x400c10['getNode']()['isEmpty'](),_0x16c1a4=gn(_0x16c9d1);(_0x826cf5['length']>0x0||!_0x16c9d1['eventCache']['isFullyInitialized']()||_0x3f867f&&!_0x400c10['getNode']()['equals'](_0x16c1a4)||!_0x400c10['getNode']()['getPriority']()['equals'](_0x16c1a4['getPriority']()))&&_0x826cf5['push'](Oo(gn(_0xd2d296)));}}function Ho(_0x16aa16,_0x5a7c09,_0x2ad73a,_0x165fcb,_0x649abe,_0x5cdb09){const _0x342b29=_0x5a7c09['eventCache'];if(yn(_0x165fcb,_0x2ad73a)!=null)return _0x5a7c09;{let _0x1d560c,_0xd2f4ed;if(v(_0x2ad73a)){if(f(_0x5a7c09['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5a7c09['serverCache']['isFiltered']()){const _0x398fb2=Ue(_0x5a7c09),_0x13ce14=_0x398fb2 instanceof g?_0x398fb2:g['EMPTY_NODE'],_0x454958=es(_0x165fcb,_0x13ce14);_0x1d560c=_0x16aa16['filter']['updateFullNode'](_0x5a7c09['eventCache']['getNode'](),_0x454958,_0x5cdb09);}else{const _0x452554=mn(_0x165fcb,Ue(_0x5a7c09));_0x1d560c=_0x16aa16['filter']['updateFullNode'](_0x5a7c09['eventCache']['getNode'](),_0x452554,_0x5cdb09);}}else{const _0x1b1e46=y(_0x2ad73a);if(_0x1b1e46==='.priority'){f(we(_0x2ad73a)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4fd540=_0x342b29['getNode']();_0xd2f4ed=_0x5a7c09['serverCache']['getNode']();const _0x66aa05=or(_0x165fcb,_0x2ad73a,_0x4fd540,_0xd2f4ed);_0x66aa05!=null?_0x1d560c=_0x16aa16['filter']['updatePriority'](_0x4fd540,_0x66aa05):_0x1d560c=_0x342b29['getNode']();}else{const _0x3251f2=b(_0x2ad73a);let _0x593afd;if(_0x342b29['isCompleteForChild'](_0x1b1e46)){_0xd2f4ed=_0x5a7c09['serverCache']['getNode']();const _0x1a5ca2=or(_0x165fcb,_0x2ad73a,_0x342b29['getNode'](),_0xd2f4ed);_0x1a5ca2!=null?_0x593afd=_0x342b29['getNode']()['getImmediateChild'](_0x1b1e46)['updateChild'](_0x3251f2,_0x1a5ca2):_0x593afd=_0x342b29['getNode']()['getImmediateChild'](_0x1b1e46);}else _0x593afd=ts(_0x165fcb,_0x1b1e46,_0x5a7c09['serverCache']);_0x593afd!=null?_0x1d560c=_0x16aa16['filter']['updateChild'](_0x342b29['getNode'](),_0x1b1e46,_0x593afd,_0x3251f2,_0x649abe,_0x5cdb09):_0x1d560c=_0x342b29['getNode']();}}return wt(_0x5a7c09,_0x1d560c,_0x342b29['isFullyInitialized']()||v(_0x2ad73a),_0x16aa16['filter']['filtersNodes']());}}function vn(_0x5c2c54,_0x23a4c1,_0x3185e6,_0xf69d68,_0x46217c,_0x5b6e8f,_0x16464e,_0xc664bf){const _0x56773d=_0x23a4c1['serverCache'];let _0x44aee3;const _0x5c4d5f=_0x16464e?_0x5c2c54['filter']:_0x5c2c54['filter']['getIndexedFilter']();if(v(_0x3185e6))_0x44aee3=_0x5c4d5f['updateFullNode'](_0x56773d['getNode'](),_0xf69d68,null);else{if(_0x5c4d5f['filtersNodes']()&&!_0x56773d['isFiltered']()){const _0x3ad709=_0x56773d['getNode']()['updateChild'](_0x3185e6,_0xf69d68);_0x44aee3=_0x5c4d5f['updateFullNode'](_0x56773d['getNode'](),_0x3ad709,null);}else{const _0x42e059=y(_0x3185e6);if(!_0x56773d['isCompleteForPath'](_0x3185e6)&&we(_0x3185e6)>0x1)return _0x23a4c1;const _0x3a4a44=b(_0x3185e6),_0x3098c2=_0x56773d['getNode']()['getImmediateChild'](_0x42e059)['updateChild'](_0x3a4a44,_0xf69d68);_0x42e059==='.priority'?_0x44aee3=_0x5c4d5f['updatePriority'](_0x56773d['getNode'](),_0x3098c2):_0x44aee3=_0x5c4d5f['updateChild'](_0x56773d['getNode'](),_0x42e059,_0x3098c2,_0x3a4a44,Vo,null);}}const _0x4934b7=Lo(_0x23a4c1,_0x44aee3,_0x56773d['isFullyInitialized']()||v(_0x3185e6),_0x5c4d5f['filtersNodes']()),_0x564c04=new ns(_0x46217c,_0x4934b7,_0x5b6e8f);return Ho(_0x5c2c54,_0x4934b7,_0x3185e6,_0x46217c,_0x564c04,_0xc664bf);}function Ti(_0x27cb66,_0x4a6ecb,_0x504e27,_0x41d599,_0x2e7a4b,_0x5b2dfa,_0x1289c2){const _0x57ef48=_0x4a6ecb['eventCache'];let _0x2fef63,_0x2df30b;const _0xa59853=new ns(_0x2e7a4b,_0x4a6ecb,_0x5b2dfa);if(v(_0x504e27))_0x2df30b=_0x27cb66['filter']['updateFullNode'](_0x4a6ecb['eventCache']['getNode'](),_0x41d599,_0x1289c2),_0x2fef63=wt(_0x4a6ecb,_0x2df30b,!0x0,_0x27cb66['filter']['filtersNodes']());else{const _0x522e5f=y(_0x504e27);if(_0x522e5f==='.priority')_0x2df30b=_0x27cb66['filter']['updatePriority'](_0x4a6ecb['eventCache']['getNode'](),_0x41d599),_0x2fef63=wt(_0x4a6ecb,_0x2df30b,_0x57ef48['isFullyInitialized'](),_0x57ef48['isFiltered']());else{const _0x4ea41b=b(_0x504e27),_0x5ae4e4=_0x57ef48['getNode']()['getImmediateChild'](_0x522e5f);let _0x3880e6;if(v(_0x4ea41b))_0x3880e6=_0x41d599;else{const _0x42d41b=_0xa59853['getCompleteChild'](_0x522e5f);_0x42d41b!=null?Gi(_0x4ea41b)==='.priority'&&_0x42d41b['getChild'](To(_0x4ea41b))['isEmpty']()?_0x3880e6=_0x42d41b:_0x3880e6=_0x42d41b['updateChild'](_0x4ea41b,_0x41d599):_0x3880e6=g['EMPTY_NODE'];}if(_0x5ae4e4['equals'](_0x3880e6))_0x2fef63=_0x4a6ecb;else{const _0x27e993=_0x27cb66['filter']['updateChild'](_0x57ef48['getNode'](),_0x522e5f,_0x3880e6,_0x4ea41b,_0xa59853,_0x1289c2);_0x2fef63=wt(_0x4a6ecb,_0x27e993,_0x57ef48['isFullyInitialized'](),_0x27cb66['filter']['filtersNodes']());}}}return _0x2fef63;}function ar(_0x516e95,_0x2f0d24){return _0x516e95['eventCache']['isCompleteForChild'](_0x2f0d24);}function bu(_0x38f449,_0x5bc9b1,_0x38a166,_0x2ad5b6,_0x4a8a17,_0x4647b1,_0x4abd39){let _0x450f30=_0x5bc9b1;return _0x2ad5b6['foreach']((_0x42c0af,_0x4dcc3e)=>{const _0x1791de=A(_0x38a166,_0x42c0af);ar(_0x5bc9b1,y(_0x1791de))&&(_0x450f30=Ti(_0x38f449,_0x450f30,_0x1791de,_0x4dcc3e,_0x4a8a17,_0x4647b1,_0x4abd39));}),_0x2ad5b6['foreach']((_0x4052dc,_0x2e7e8a)=>{const _0x4c11ff=A(_0x38a166,_0x4052dc);ar(_0x5bc9b1,y(_0x4c11ff))||(_0x450f30=Ti(_0x38f449,_0x450f30,_0x4c11ff,_0x2e7e8a,_0x4a8a17,_0x4647b1,_0x4abd39));}),_0x450f30;}function cr(_0xfd6d8a,_0x3fe9b0,_0x1f4d90){return _0x1f4d90['foreach']((_0x213214,_0x57d2a0)=>{_0x3fe9b0=_0x3fe9b0['updateChild'](_0x213214,_0x57d2a0);}),_0x3fe9b0;}function Si(_0x48c0b7,_0x37c5e2,_0x267d42,_0x24e786,_0x27f99c,_0x320991,_0x5c8b59,_0x446cbe){if(_0x37c5e2['serverCache']['getNode']()['isEmpty']()&&!_0x37c5e2['serverCache']['isFullyInitialized']())return _0x37c5e2;let _0x3f0477=_0x37c5e2,_0x55247e;v(_0x267d42)?_0x55247e=_0x24e786:_0x55247e=new S(null)['setTree'](_0x267d42,_0x24e786);const _0x1115c5=_0x37c5e2['serverCache']['getNode']();return _0x55247e['children']['inorderTraversal']((_0x58774b,_0x8e40a4)=>{if(_0x1115c5['hasChild'](_0x58774b)){const _0x598e5c=_0x37c5e2['serverCache']['getNode']()['getImmediateChild'](_0x58774b),_0x1d202f=cr(_0x48c0b7,_0x598e5c,_0x8e40a4);_0x3f0477=vn(_0x48c0b7,_0x3f0477,new C(_0x58774b),_0x1d202f,_0x27f99c,_0x320991,_0x5c8b59,_0x446cbe);}}),_0x55247e['children']['inorderTraversal']((_0x22e52b,_0x2b9459)=>{const _0x5cf800=!_0x37c5e2['serverCache']['isCompleteForChild'](_0x22e52b)&&_0x2b9459['value']===null;if(!_0x1115c5['hasChild'](_0x22e52b)&&!_0x5cf800){const _0x431c35=_0x37c5e2['serverCache']['getNode']()['getImmediateChild'](_0x22e52b),_0x2fb086=cr(_0x48c0b7,_0x431c35,_0x2b9459);_0x3f0477=vn(_0x48c0b7,_0x3f0477,new C(_0x22e52b),_0x2fb086,_0x27f99c,_0x320991,_0x5c8b59,_0x446cbe);}}),_0x3f0477;}function Ru(_0x4ff495,_0x537544,_0x31c644,_0x14ea27,_0x353721,_0x1bdced,_0x1fc23f){if(yn(_0x353721,_0x31c644)!=null)return _0x537544;const _0x38c3de=_0x537544['serverCache']['isFiltered'](),_0x27db5d=_0x537544['serverCache'];if(_0x14ea27['value']!=null){if(v(_0x31c644)&&_0x27db5d['isFullyInitialized']()||_0x27db5d['isCompleteForPath'](_0x31c644))return vn(_0x4ff495,_0x537544,_0x31c644,_0x27db5d['getNode']()['getChild'](_0x31c644),_0x353721,_0x1bdced,_0x38c3de,_0x1fc23f);if(v(_0x31c644)){let _0x1d548d=new S(null);return _0x27db5d['getNode']()['forEachChild'](ye,(_0x305217,_0x3bb515)=>{_0x1d548d=_0x1d548d['set'](new C(_0x305217),_0x3bb515);}),Si(_0x4ff495,_0x537544,_0x31c644,_0x1d548d,_0x353721,_0x1bdced,_0x38c3de,_0x1fc23f);}else return _0x537544;}else{let _0x3de38a=new S(null);return _0x14ea27['foreach']((_0x139ee0,_0x2c87b6)=>{const _0x3e8bb2=A(_0x31c644,_0x139ee0);_0x27db5d['isCompleteForPath'](_0x3e8bb2)&&(_0x3de38a=_0x3de38a['set'](_0x139ee0,_0x27db5d['getNode']()['getChild'](_0x3e8bb2)));}),Si(_0x4ff495,_0x537544,_0x31c644,_0x3de38a,_0x353721,_0x1bdced,_0x38c3de,_0x1fc23f);}}function Au(_0x598f35,_0xa581d,_0x4f1d46,_0x4bf4b3,_0x2b312f){const _0x3cf30f=_0xa581d['serverCache'],_0x1aafd4=Lo(_0xa581d,_0x3cf30f['getNode'](),_0x3cf30f['isFullyInitialized']()||v(_0x4f1d46),_0x3cf30f['isFiltered']());return Ho(_0x598f35,_0x1aafd4,_0x4f1d46,_0x4bf4b3,Vo,_0x2b312f);}function ku(_0x30ae0e,_0x529b90,_0x47ef4b,_0x10df0b,_0xaf3876,_0xf9273b){let _0x18c6d5;if(yn(_0x10df0b,_0x47ef4b)!=null)return _0x529b90;{const _0x4a52a5=new ns(_0x10df0b,_0x529b90,_0xaf3876),_0x29a9bb=_0x529b90['eventCache']['getNode']();let _0x41b7a4;if(v(_0x47ef4b)||y(_0x47ef4b)==='.priority'){let _0x5b5c7;if(_0x529b90['serverCache']['isFullyInitialized']())_0x5b5c7=mn(_0x10df0b,Ue(_0x529b90));else{const _0x5d8129=_0x529b90['serverCache']['getNode']();f(_0x5d8129 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5b5c7=es(_0x10df0b,_0x5d8129);}_0x5b5c7=_0x5b5c7,_0x41b7a4=_0x30ae0e['filter']['updateFullNode'](_0x29a9bb,_0x5b5c7,_0xf9273b);}else{const _0x58be65=y(_0x47ef4b);let _0x410ff2=ts(_0x10df0b,_0x58be65,_0x529b90['serverCache']);_0x410ff2==null&&_0x529b90['serverCache']['isCompleteForChild'](_0x58be65)&&(_0x410ff2=_0x29a9bb['getImmediateChild'](_0x58be65)),_0x410ff2!=null?_0x41b7a4=_0x30ae0e['filter']['updateChild'](_0x29a9bb,_0x58be65,_0x410ff2,b(_0x47ef4b),_0x4a52a5,_0xf9273b):_0x529b90['eventCache']['getNode']()['hasChild'](_0x58be65)?_0x41b7a4=_0x30ae0e['filter']['updateChild'](_0x29a9bb,_0x58be65,g['EMPTY_NODE'],b(_0x47ef4b),_0x4a52a5,_0xf9273b):_0x41b7a4=_0x29a9bb,_0x41b7a4['isEmpty']()&&_0x529b90['serverCache']['isFullyInitialized']()&&(_0x18c6d5=mn(_0x10df0b,Ue(_0x529b90)),_0x18c6d5['isLeafNode']()&&(_0x41b7a4=_0x30ae0e['filter']['updateFullNode'](_0x41b7a4,_0x18c6d5,_0xf9273b)));}return _0x18c6d5=_0x529b90['serverCache']['isFullyInitialized']()||yn(_0x10df0b,w())!=null,wt(_0x529b90,_0x41b7a4,_0x18c6d5,_0x30ae0e['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0xf9c9b4,_0x58cf62){this['query_']=_0xf9c9b4,this['eventRegistrations_']=[];const _0x1ee7af=this['query_']['_queryParams'],_0x4c3ee7=new Yi(_0x1ee7af['getIndex']()),_0x26fbcb=qh(_0x1ee7af);this['processor_']=wu(_0x26fbcb);const _0x1bbcfb=_0x58cf62['serverCache'],_0x2fcf80=_0x58cf62['eventCache'],_0x449d03=_0x4c3ee7['updateFullNode'](g['EMPTY_NODE'],_0x1bbcfb['getNode'](),null),_0x29b168=_0x26fbcb['updateFullNode'](g['EMPTY_NODE'],_0x2fcf80['getNode'](),null),_0x1b4f17=new Ce(_0x449d03,_0x1bbcfb['isFullyInitialized'](),_0x4c3ee7['filtersNodes']()),_0x824bf9=new Ce(_0x29b168,_0x2fcf80['isFullyInitialized'](),_0x26fbcb['filtersNodes']());this['viewCache_']=Dn(_0x824bf9,_0x1b4f17),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0xe00cfd){return _0xe00cfd['viewCache_']['serverCache']['getNode']();}function Ou(_0x762718){return gn(_0x762718['viewCache_']);}function Du(_0x24b4a3,_0x1b1ae6){const _0x4765ec=Ue(_0x24b4a3['viewCache_']);return _0x4765ec&&(_0x24b4a3['query']['_queryParams']['loadsAllData']()||!v(_0x1b1ae6)&&!_0x4765ec['getImmediateChild'](y(_0x1b1ae6))['isEmpty']())?_0x4765ec['getChild'](_0x1b1ae6):null;}function lr(_0xcdfe18){return _0xcdfe18['eventRegistrations_']['length']===0x0;}function Mu(_0x3a2188,_0x3fd8e6){_0x3a2188['eventRegistrations_']['push'](_0x3fd8e6);}function hr(_0x1ba9ca,_0x31061c,_0x18be6d){const _0x443399=[];if(_0x18be6d){f(_0x31061c==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x401a0d=_0x1ba9ca['query']['_path'];_0x1ba9ca['eventRegistrations_']['forEach'](_0x1e49b8=>{const _0x54d70a=_0x1e49b8['createCancelEvent'](_0x18be6d,_0x401a0d);_0x54d70a&&_0x443399['push'](_0x54d70a);});}if(_0x31061c){let _0x55d81d=[];for(let _0x25fd32=0x0;_0x25fd32<_0x1ba9ca['eventRegistrations_']['length'];++_0x25fd32){const _0x2294b4=_0x1ba9ca['eventRegistrations_'][_0x25fd32];if(!_0x2294b4['matches'](_0x31061c))_0x55d81d['push'](_0x2294b4);else{if(_0x31061c['hasAnyCallback']()){_0x55d81d=_0x55d81d['concat'](_0x1ba9ca['eventRegistrations_']['slice'](_0x25fd32+0x1));break;}}}_0x1ba9ca['eventRegistrations_']=_0x55d81d;}else _0x1ba9ca['eventRegistrations_']=[];return _0x443399;}function ur(_0x34cbaf,_0x59ed14,_0x150f34,_0x13be10){_0x59ed14['type']===q['MERGE']&&_0x59ed14['source']['queryId']!==null&&(f(Ue(_0x34cbaf['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x34cbaf['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x266688=_0x34cbaf['viewCache_'],_0x424c5a=Tu(_0x34cbaf['processor_'],_0x266688,_0x59ed14,_0x150f34,_0x13be10);return Cu(_0x34cbaf['processor_'],_0x424c5a['viewCache']),f(_0x424c5a['viewCache']['serverCache']['isFullyInitialized']()||!_0x266688['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x34cbaf['viewCache_']=_0x424c5a['viewCache'],$o(_0x34cbaf,_0x424c5a['changes'],_0x424c5a['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x5b43ed,_0x59c6ca){const _0x1d368b=_0x5b43ed['viewCache_']['eventCache'],_0x545d52=[];return _0x1d368b['getNode']()['isLeafNode']()||_0x1d368b['getNode']()['forEachChild'](R,(_0x1fc42d,_0x4453e6)=>{_0x545d52['push'](tt(_0x1fc42d,_0x4453e6));}),_0x1d368b['isFullyInitialized']()&&_0x545d52['push'](Oo(_0x1d368b['getNode']())),$o(_0x5b43ed,_0x545d52,_0x1d368b['getNode'](),_0x59c6ca);}function $o(_0x530bc7,_0x54eee7,_0x2bdd7a,_0x25f2c0){const _0x22285a=_0x25f2c0?[_0x25f2c0]:_0x530bc7['eventRegistrations_'];return nu(_0x530bc7['eventGenerator_'],_0x54eee7,_0x2bdd7a,_0x22285a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x13a2a1){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x13a2a1;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x60bb18){return _0x60bb18['views']['size']===0x0;}function is(_0x3193b7,_0x4667c8,_0x29df5f,_0x4e7419){const _0x20e52e=_0x4667c8['source']['queryId'];if(_0x20e52e!==null){const _0x5847a2=_0x3193b7['views']['get'](_0x20e52e);return f(_0x5847a2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x5847a2,_0x4667c8,_0x29df5f,_0x4e7419);}else{let _0x2f5313=[];for(const _0x330b21 of _0x3193b7['views']['values']())_0x2f5313=_0x2f5313['concat'](ur(_0x330b21,_0x4667c8,_0x29df5f,_0x4e7419));return _0x2f5313;}}function qo(_0x328c8b,_0xefda00,_0x4cbd1d,_0x29be08,_0x2d0a5a){const _0x4fdc8d=_0xefda00['_queryIdentifier'],_0x57a96d=_0x328c8b['views']['get'](_0x4fdc8d);if(!_0x57a96d){let _0x5dec9c=mn(_0x4cbd1d,_0x2d0a5a?_0x29be08:null),_0x45ab62=!0x1;_0x5dec9c?_0x45ab62=!0x0:_0x29be08 instanceof g?(_0x5dec9c=es(_0x4cbd1d,_0x29be08),_0x45ab62=!0x1):(_0x5dec9c=g['EMPTY_NODE'],_0x45ab62=!0x1);const _0x385195=Dn(new Ce(_0x5dec9c,_0x45ab62,!0x1),new Ce(_0x29be08,_0x2d0a5a,!0x1));return new Nu(_0xefda00,_0x385195);}return _0x57a96d;}function Wu(_0x3139d7,_0x756201,_0xc91672,_0x4549e7,_0x20b73e,_0x1f80a2){const _0xd85987=qo(_0x3139d7,_0x756201,_0x4549e7,_0x20b73e,_0x1f80a2);return _0x3139d7['views']['has'](_0x756201['_queryIdentifier'])||_0x3139d7['views']['set'](_0x756201['_queryIdentifier'],_0xd85987),Mu(_0xd85987,_0xc91672),Lu(_0xd85987,_0xc91672);}function Bu(_0x19c361,_0x717004,_0x478b5f,_0x240fc0){const _0x4cfd92=_0x717004['_queryIdentifier'],_0x47f4d9=[];let _0x25ee43=[];const _0x172869=Te(_0x19c361);if(_0x4cfd92==='default'){for(const [_0x5b1f4a,_0x39fd9a]of _0x19c361['views']['entries']())_0x25ee43=_0x25ee43['concat'](hr(_0x39fd9a,_0x478b5f,_0x240fc0)),lr(_0x39fd9a)&&(_0x19c361['views']['delete'](_0x5b1f4a),_0x39fd9a['query']['_queryParams']['loadsAllData']()||_0x47f4d9['push'](_0x39fd9a['query']));}else{const _0x4692bb=_0x19c361['views']['get'](_0x4cfd92);_0x4692bb&&(_0x25ee43=_0x25ee43['concat'](hr(_0x4692bb,_0x478b5f,_0x240fc0)),lr(_0x4692bb)&&(_0x19c361['views']['delete'](_0x4cfd92),_0x4692bb['query']['_queryParams']['loadsAllData']()||_0x47f4d9['push'](_0x4692bb['query'])));}return _0x172869&&!Te(_0x19c361)&&_0x47f4d9['push'](new(Fu())(_0x717004['_repo'],_0x717004['_path'])),{'removed':_0x47f4d9,'events':_0x25ee43};}function zo(_0x4bf263){const _0x329a89=[];for(const _0x1837ac of _0x4bf263['views']['values']())_0x1837ac['query']['_queryParams']['loadsAllData']()||_0x329a89['push'](_0x1837ac);return _0x329a89;}function Ee(_0x1704fd,_0x400b7e){let _0xeee062=null;for(const _0x216fe2 of _0x1704fd['views']['values']())_0xeee062=_0xeee062||Du(_0x216fe2,_0x400b7e);return _0xeee062;}function jo(_0x1febf7,_0xf00ea5){if(_0xf00ea5['_queryParams']['loadsAllData']())return Ln(_0x1febf7);{const _0xc97d7c=_0xf00ea5['_queryIdentifier'];return _0x1febf7['views']['get'](_0xc97d7c);}}function Ko(_0x4dd0ef,_0x4f1009){return jo(_0x4dd0ef,_0x4f1009)!=null;}function Te(_0x56d32e){return Ln(_0x56d32e)!=null;}function Ln(_0x1945af){for(const _0x57e3be of _0x1945af['views']['values']())if(_0x57e3be['query']['_queryParams']['loadsAllData']())return _0x57e3be;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1328f8){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1328f8;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0xb657cc){this['listenProvider_']=_0xb657cc,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2929cc,_0x20aa83,_0x5efdb9,_0x4171ab,_0x16201a){return ou(_0x2929cc['pendingWriteTree_'],_0x20aa83,_0x5efdb9,_0x4171ab,_0x16201a),_0x16201a?ht(_0x2929cc,new Fe(Ji(),_0x20aa83,_0x5efdb9)):[];}function Gu(_0x3f0c1e,_0x231b99,_0x265780,_0x23e961){au(_0x3f0c1e['pendingWriteTree_'],_0x231b99,_0x265780,_0x23e961);const _0x4abc37=S['fromObject'](_0x265780);return ht(_0x3f0c1e,new nt(Ji(),_0x231b99,_0x4abc37));}function pe(_0x2e89ae,_0x41f782,_0xdb5706=!0x1){const _0x30fda2=cu(_0x2e89ae['pendingWriteTree_'],_0x41f782);if(lu(_0x2e89ae['pendingWriteTree_'],_0x41f782)){let _0x34e9f3=new S(null);return _0x30fda2['snap']!=null?_0x34e9f3=_0x34e9f3['set'](w(),!0x0):x(_0x30fda2['children'],_0x76991a=>{_0x34e9f3=_0x34e9f3['set'](new C(_0x76991a),!0x0);}),ht(_0x2e89ae,new _n(_0x30fda2['path'],_0x34e9f3,_0xdb5706));}else return[];}function $t(_0xb302b6,_0x4d093b,_0x563ef4){return ht(_0xb302b6,new Fe(Xi(),_0x4d093b,_0x563ef4));}function qu(_0x315345,_0x4a023d,_0x2bfa03){const _0xdb2f4d=S['fromObject'](_0x2bfa03);return ht(_0x315345,new nt(Xi(),_0x4a023d,_0xdb2f4d));}function zu(_0x2a423f,_0x2f54df){return ht(_0x2a423f,new Dt(Xi(),_0x2f54df));}function ju(_0x26ac20,_0x5ae960,_0x388335){const _0x2a4bf5=rs(_0x26ac20,_0x388335);if(_0x2a4bf5){const _0xac2630=os(_0x2a4bf5),_0x4a9b66=_0xac2630['path'],_0x4b2724=_0xac2630['queryId'],_0x113b62=F(_0x4a9b66,_0x5ae960),_0x54a543=new Dt(Zi(_0x4b2724),_0x113b62);return as(_0x26ac20,_0x4a9b66,_0x54a543);}else return[];}function wn(_0x3f1ed5,_0x534394,_0x375b7b,_0xd87283,_0x3d2eb9=!0x1){const _0x14ce35=_0x534394['_path'],_0x53e916=_0x3f1ed5['syncPointTree_']['get'](_0x14ce35);let _0x1d272e=[];if(_0x53e916&&(_0x534394['_queryIdentifier']==='default'||Ko(_0x53e916,_0x534394))){const _0xe3bc0f=Bu(_0x53e916,_0x534394,_0x375b7b,_0xd87283);Uu(_0x53e916)&&(_0x3f1ed5['syncPointTree_']=_0x3f1ed5['syncPointTree_']['remove'](_0x14ce35));const _0x4a86d6=_0xe3bc0f['removed'];if(_0x1d272e=_0xe3bc0f['events'],!_0x3d2eb9){const _0x5cfe62=_0x4a86d6['findIndex'](_0x5644b3=>_0x5644b3['_queryParams']['loadsAllData']())!==-0x1,_0x521983=_0x3f1ed5['syncPointTree_']['findOnPath'](_0x14ce35,(_0x251916,_0x3006d9)=>Te(_0x3006d9));if(_0x5cfe62&&!_0x521983){const _0xe26fdc=_0x3f1ed5['syncPointTree_']['subtree'](_0x14ce35);if(!_0xe26fdc['isEmpty']()){const _0x4004cf=Qu(_0xe26fdc);for(let _0x4a5790=0x0;_0x4a5790<_0x4004cf['length'];++_0x4a5790){const _0x597c7b=_0x4004cf[_0x4a5790],_0x4f4314=_0x597c7b['query'],_0x29a34c=Xo(_0x3f1ed5,_0x597c7b);_0x3f1ed5['listenProvider_']['startListening'](Tt(_0x4f4314),Mt(_0x3f1ed5,_0x4f4314),_0x29a34c['hashFn'],_0x29a34c['onComplete']);}}}!_0x521983&&_0x4a86d6['length']>0x0&&!_0xd87283&&(_0x5cfe62?_0x3f1ed5['listenProvider_']['stopListening'](Tt(_0x534394),null):_0x4a86d6['forEach'](_0xb5aa7e=>{const _0x37eb80=_0x3f1ed5['queryToTagMap']['get'](Fn(_0xb5aa7e));_0x3f1ed5['listenProvider_']['stopListening'](Tt(_0xb5aa7e),_0x37eb80);}));}Ju(_0x3f1ed5,_0x4a86d6);}return _0x1d272e;}function Yo(_0xe9a888,_0x2c5f92,_0x44021d,_0xe5c908){const _0x4878bb=rs(_0xe9a888,_0xe5c908);if(_0x4878bb!=null){const _0x1f7758=os(_0x4878bb),_0x86d7b6=_0x1f7758['path'],_0x5bc9af=_0x1f7758['queryId'],_0x96884f=F(_0x86d7b6,_0x2c5f92),_0x37f304=new Fe(Zi(_0x5bc9af),_0x96884f,_0x44021d);return as(_0xe9a888,_0x86d7b6,_0x37f304);}else return[];}function Ku(_0x12bbf3,_0x167bc1,_0x45c493,_0x146653){const _0x134506=rs(_0x12bbf3,_0x146653);if(_0x134506){const _0x10a794=os(_0x134506),_0x3c4a19=_0x10a794['path'],_0x38ab83=_0x10a794['queryId'],_0x111064=F(_0x3c4a19,_0x167bc1),_0x25e6d1=S['fromObject'](_0x45c493),_0x1b6129=new nt(Zi(_0x38ab83),_0x111064,_0x25e6d1);return as(_0x12bbf3,_0x3c4a19,_0x1b6129);}else return[];}function bi(_0x593204,_0x322a07,_0x57e26f,_0x543529=!0x1){const _0x5a1fe0=_0x322a07['_path'];let _0x3f7beb=null,_0x1cb105=!0x1;_0x593204['syncPointTree_']['foreachOnPath'](_0x5a1fe0,(_0x3433bc,_0x2c036d)=>{const _0x4d2af6=F(_0x3433bc,_0x5a1fe0);_0x3f7beb=_0x3f7beb||Ee(_0x2c036d,_0x4d2af6),_0x1cb105=_0x1cb105||Te(_0x2c036d);});let _0x3d1d39=_0x593204['syncPointTree_']['get'](_0x5a1fe0);_0x3d1d39?(_0x1cb105=_0x1cb105||Te(_0x3d1d39),_0x3f7beb=_0x3f7beb||Ee(_0x3d1d39,w())):(_0x3d1d39=new Go(),_0x593204['syncPointTree_']=_0x593204['syncPointTree_']['set'](_0x5a1fe0,_0x3d1d39));let _0x20e09b;_0x3f7beb!=null?_0x20e09b=!0x0:(_0x20e09b=!0x1,_0x3f7beb=g['EMPTY_NODE'],_0x593204['syncPointTree_']['subtree'](_0x5a1fe0)['foreachChild']((_0x58075e,_0x112bda)=>{const _0x2b1495=Ee(_0x112bda,w());_0x2b1495&&(_0x3f7beb=_0x3f7beb['updateImmediateChild'](_0x58075e,_0x2b1495));}));const _0x1b03a2=Ko(_0x3d1d39,_0x322a07);if(!_0x1b03a2&&!_0x322a07['_queryParams']['loadsAllData']()){const _0x3da393=Fn(_0x322a07);f(!_0x593204['queryToTagMap']['has'](_0x3da393),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x121f77=Xu();_0x593204['queryToTagMap']['set'](_0x3da393,_0x121f77),_0x593204['tagToQueryMap']['set'](_0x121f77,_0x3da393);}const _0xa0edb3=Mn(_0x593204['pendingWriteTree_'],_0x5a1fe0);let _0xa1155=Wu(_0x3d1d39,_0x322a07,_0x57e26f,_0xa0edb3,_0x3f7beb,_0x20e09b);if(!_0x1b03a2&&!_0x1cb105&&!_0x543529){const _0x4e1d47=jo(_0x3d1d39,_0x322a07);_0xa1155=_0xa1155['concat'](Zu(_0x593204,_0x322a07,_0x4e1d47));}return _0xa1155;}function xn(_0x69f89e,_0x144df9,_0x599fdf){const _0x3cab01=_0x69f89e['pendingWriteTree_'],_0x4a542f=_0x69f89e['syncPointTree_']['findOnPath'](_0x144df9,(_0x38e4ee,_0x138aa5)=>{const _0x5d910a=F(_0x38e4ee,_0x144df9),_0x5edc0c=Ee(_0x138aa5,_0x5d910a);if(_0x5edc0c)return _0x5edc0c;});return Uo(_0x3cab01,_0x144df9,_0x4a542f,_0x599fdf,!0x0);}function Yu(_0x4c1b02,_0x4f61dd){const _0x20dbc3=_0x4f61dd['_path'];let _0x1d807d=null;_0x4c1b02['syncPointTree_']['foreachOnPath'](_0x20dbc3,(_0x2a58ad,_0x3324ca)=>{const _0x4dd780=F(_0x2a58ad,_0x20dbc3);_0x1d807d=_0x1d807d||Ee(_0x3324ca,_0x4dd780);});let _0x370841=_0x4c1b02['syncPointTree_']['get'](_0x20dbc3);_0x370841?_0x1d807d=_0x1d807d||Ee(_0x370841,w()):(_0x370841=new Go(),_0x4c1b02['syncPointTree_']=_0x4c1b02['syncPointTree_']['set'](_0x20dbc3,_0x370841));const _0x2dc81f=_0x1d807d!=null,_0x1fe375=_0x2dc81f?new Ce(_0x1d807d,!0x0,!0x1):null,_0x3e2d61=Mn(_0x4c1b02['pendingWriteTree_'],_0x4f61dd['_path']),_0x1ca1e6=qo(_0x370841,_0x4f61dd,_0x3e2d61,_0x2dc81f?_0x1fe375['getNode']():g['EMPTY_NODE'],_0x2dc81f);return Ou(_0x1ca1e6);}function ht(_0x3946b8,_0x37f9d8){return Qo(_0x37f9d8,_0x3946b8['syncPointTree_'],null,Mn(_0x3946b8['pendingWriteTree_'],w()));}function Qo(_0x1868be,_0x2a8c6a,_0x32006c,_0x55027){if(v(_0x1868be['path']))return Jo(_0x1868be,_0x2a8c6a,_0x32006c,_0x55027);{const _0x42d194=_0x2a8c6a['get'](w());_0x32006c==null&&_0x42d194!=null&&(_0x32006c=Ee(_0x42d194,w()));let _0x18501d=[];const _0x146a92=y(_0x1868be['path']),_0x4589ab=_0x1868be['operationForChild'](_0x146a92),_0x571611=_0x2a8c6a['children']['get'](_0x146a92);if(_0x571611&&_0x4589ab){const _0x267afb=_0x32006c?_0x32006c['getImmediateChild'](_0x146a92):null,_0x52c007=Wo(_0x55027,_0x146a92);_0x18501d=_0x18501d['concat'](Qo(_0x4589ab,_0x571611,_0x267afb,_0x52c007));}return _0x42d194&&(_0x18501d=_0x18501d['concat'](is(_0x42d194,_0x1868be,_0x55027,_0x32006c))),_0x18501d;}}function Jo(_0x468c7b,_0x30b298,_0x292317,_0x5acdb9){const _0x2f221f=_0x30b298['get'](w());_0x292317==null&&_0x2f221f!=null&&(_0x292317=Ee(_0x2f221f,w()));let _0x283425=[];return _0x30b298['children']['inorderTraversal']((_0x2966d4,_0xf38483)=>{const _0x24a8f2=_0x292317?_0x292317['getImmediateChild'](_0x2966d4):null,_0x8d4291=Wo(_0x5acdb9,_0x2966d4),_0x22ad74=_0x468c7b['operationForChild'](_0x2966d4);_0x22ad74&&(_0x283425=_0x283425['concat'](Jo(_0x22ad74,_0xf38483,_0x24a8f2,_0x8d4291)));}),_0x2f221f&&(_0x283425=_0x283425['concat'](is(_0x2f221f,_0x468c7b,_0x5acdb9,_0x292317))),_0x283425;}function Xo(_0x23ab4b,_0x4b81a9){const _0x20fad1=_0x4b81a9['query'],_0x4fd790=Mt(_0x23ab4b,_0x20fad1);return{'hashFn':()=>(Pu(_0x4b81a9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4e51df=>{if(_0x4e51df==='ok')return _0x4fd790?ju(_0x23ab4b,_0x20fad1['_path'],_0x4fd790):zu(_0x23ab4b,_0x20fad1['_path']);{const _0xa2c12c=ql(_0x4e51df,_0x20fad1);return wn(_0x23ab4b,_0x20fad1,null,_0xa2c12c);}}};}function Mt(_0x3e0c57,_0x4dabd1){const _0xff8854=Fn(_0x4dabd1);return _0x3e0c57['queryToTagMap']['get'](_0xff8854);}function Fn(_0x39d4f9){return _0x39d4f9['_path']['toString']()+'$'+_0x39d4f9['_queryIdentifier'];}function rs(_0x49a249,_0x37e5e2){return _0x49a249['tagToQueryMap']['get'](_0x37e5e2);}function os(_0x2b6e26){const _0x2d8783=_0x2b6e26['indexOf']('$');return f(_0x2d8783!==-0x1&&_0x2d8783<_0x2b6e26['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2b6e26['substr'](_0x2d8783+0x1),'path':new C(_0x2b6e26['substr'](0x0,_0x2d8783))};}function as(_0x25c906,_0x5c1fc5,_0x7fe6be){const _0x4cd779=_0x25c906['syncPointTree_']['get'](_0x5c1fc5);f(_0x4cd779,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x76edb7=Mn(_0x25c906['pendingWriteTree_'],_0x5c1fc5);return is(_0x4cd779,_0x7fe6be,_0x76edb7,null);}function Qu(_0x28d2de){return _0x28d2de['fold']((_0x2e4bad,_0x136413,_0x20687b)=>{if(_0x136413&&Te(_0x136413))return[Ln(_0x136413)];{let _0x430201=[];return _0x136413&&(_0x430201=zo(_0x136413)),x(_0x20687b,(_0x40f3b9,_0x138ec3)=>{_0x430201=_0x430201['concat'](_0x138ec3);}),_0x430201;}});}function Tt(_0x5f343b){return _0x5f343b['_queryParams']['loadsAllData']()&&!_0x5f343b['_queryParams']['isDefault']()?new(Hu())(_0x5f343b['_repo'],_0x5f343b['_path']):_0x5f343b;}function Ju(_0x32e93b,_0x2a9254){for(let _0x1dc978=0x0;_0x1dc978<_0x2a9254['length'];++_0x1dc978){const _0xf406b4=_0x2a9254[_0x1dc978];if(!_0xf406b4['_queryParams']['loadsAllData']()){const _0x2da954=Fn(_0xf406b4),_0x1da04c=_0x32e93b['queryToTagMap']['get'](_0x2da954);_0x32e93b['queryToTagMap']['delete'](_0x2da954),_0x32e93b['tagToQueryMap']['delete'](_0x1da04c);}}}function Xu(){return $u++;}function Zu(_0x85193e,_0x377c91,_0x20b9bd){const _0x26f739=_0x377c91['_path'],_0x45b449=Mt(_0x85193e,_0x377c91),_0x545063=Xo(_0x85193e,_0x20b9bd),_0x19e450=_0x85193e['listenProvider_']['startListening'](Tt(_0x377c91),_0x45b449,_0x545063['hashFn'],_0x545063['onComplete']),_0x6a8b9f=_0x85193e['syncPointTree_']['subtree'](_0x26f739);if(_0x45b449)f(!Te(_0x6a8b9f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x49e613=_0x6a8b9f['fold']((_0x1a4da1,_0x42ccc1,_0x23f6e3)=>{if(!v(_0x1a4da1)&&_0x42ccc1&&Te(_0x42ccc1))return[Ln(_0x42ccc1)['query']];{let _0x4bb865=[];return _0x42ccc1&&(_0x4bb865=_0x4bb865['concat'](zo(_0x42ccc1)['map'](_0x282fd6=>_0x282fd6['query']))),x(_0x23f6e3,(_0x5d443d,_0x4360df)=>{_0x4bb865=_0x4bb865['concat'](_0x4360df);}),_0x4bb865;}});for(let _0x3dbf71=0x0;_0x3dbf71<_0x49e613['length'];++_0x3dbf71){const _0xf5845f=_0x49e613[_0x3dbf71];_0x85193e['listenProvider_']['stopListening'](Tt(_0xf5845f),Mt(_0x85193e,_0xf5845f));}}return _0x19e450;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x1ac664){this['node_']=_0x1ac664;}['getImmediateChild'](_0x2babd4){const _0xe5b42d=this['node_']['getImmediateChild'](_0x2babd4);return new cs(_0xe5b42d);}['node'](){return this['node_'];}}class ls{constructor(_0x5dbf02,_0x1425ea){this['syncTree_']=_0x5dbf02,this['path_']=_0x1425ea;}['getImmediateChild'](_0x255d89){const _0x2f5134=A(this['path_'],_0x255d89);return new ls(this['syncTree_'],_0x2f5134);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0xaa4ea6){return _0xaa4ea6=_0xaa4ea6||{},_0xaa4ea6['timestamp']=_0xaa4ea6['timestamp']||new Date()['getTime'](),_0xaa4ea6;},fr=function(_0x3262f8,_0x3e96cc,_0x33a443){if(!_0x3262f8||typeof _0x3262f8!='object')return _0x3262f8;if(f('.sv'in _0x3262f8,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3262f8['.sv']=='string')return td(_0x3262f8['.sv'],_0x3e96cc,_0x33a443);if(typeof _0x3262f8['.sv']=='object')return nd(_0x3262f8['.sv'],_0x3e96cc);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3262f8,null,0x2));},td=function(_0x53f6fb,_0x3dbadd,_0x57f834){switch(_0x53f6fb){case'timestamp':return _0x57f834['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x53f6fb);}},nd=function(_0x405b21,_0x3233b9,_0x33eedd){_0x405b21['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x405b21,null,0x2));const _0x520854=_0x405b21['increment'];typeof _0x520854!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x520854);const _0x33ec62=_0x3233b9['node']();if(f(_0x33ec62!==null&&typeof _0x33ec62<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x33ec62['isLeafNode']())return _0x520854;const _0x1bb40c=_0x33ec62['getValue']();return typeof _0x1bb40c!='number'?_0x520854:_0x1bb40c+_0x520854;},Zo=function(_0x4a7551,_0x3b6b8f,_0x3f13b7,_0x2ae573){return us(_0x3b6b8f,new ls(_0x3f13b7,_0x4a7551),_0x2ae573);},hs=function(_0x25440a,_0x424670,_0x2d8075){return us(_0x25440a,new cs(_0x424670),_0x2d8075);};function us(_0x5adfb6,_0x341454,_0x352360){const _0x2b3fd5=_0x5adfb6['getPriority']()['val'](),_0x35ab21=fr(_0x2b3fd5,_0x341454['getImmediateChild']('.priority'),_0x352360);let _0x456c94;if(_0x5adfb6['isLeafNode']()){const _0x1acda8=_0x5adfb6,_0x5a34a4=fr(_0x1acda8['getValue'](),_0x341454,_0x352360);return _0x5a34a4!==_0x1acda8['getValue']()||_0x35ab21!==_0x1acda8['getPriority']()['val']()?new D(_0x5a34a4,N(_0x35ab21)):_0x5adfb6;}else{const _0x2e7415=_0x5adfb6;return _0x456c94=_0x2e7415,_0x35ab21!==_0x2e7415['getPriority']()['val']()&&(_0x456c94=_0x456c94['updatePriority'](new D(_0x35ab21))),_0x2e7415['forEachChild'](R,(_0x505159,_0x4575b1)=>{const _0x545bf9=us(_0x4575b1,_0x341454['getImmediateChild'](_0x505159),_0x352360);_0x545bf9!==_0x4575b1&&(_0x456c94=_0x456c94['updateImmediateChild'](_0x505159,_0x545bf9));}),_0x456c94;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4188fb='',_0x24e571=null,_0x34f4b8={'children':{},'childCount':0x0}){this['name']=_0x4188fb,this['parent']=_0x24e571,this['node']=_0x34f4b8;}}function Un(_0x2b4cbf,_0x197825){let _0x22bcde=_0x197825 instanceof C?_0x197825:new C(_0x197825),_0x564ab0=_0x2b4cbf,_0x5e9dd0=y(_0x22bcde);for(;_0x5e9dd0!==null;){const _0x10f92d=Oe(_0x564ab0['node']['children'],_0x5e9dd0)||{'children':{},'childCount':0x0};_0x564ab0=new ds(_0x5e9dd0,_0x564ab0,_0x10f92d),_0x22bcde=b(_0x22bcde),_0x5e9dd0=y(_0x22bcde);}return _0x564ab0;}function Ge(_0x56c614){return _0x56c614['node']['value'];}function fs(_0x204f40,_0x340475){_0x204f40['node']['value']=_0x340475,Ri(_0x204f40);}function ea(_0x544259){return _0x544259['node']['childCount']>0x0;}function id(_0xd147fd){return Ge(_0xd147fd)===void 0x0&&!ea(_0xd147fd);}function Wn(_0x41b628,_0xb0450c){x(_0x41b628['node']['children'],(_0x3c334f,_0x10202b)=>{_0xb0450c(new ds(_0x3c334f,_0x41b628,_0x10202b));});}function ta(_0x45f525,_0x17cf39,_0x227c80,_0x224c18){_0x227c80&&_0x17cf39(_0x45f525),Wn(_0x45f525,_0x3b94d9=>{ta(_0x3b94d9,_0x17cf39,!0x0);});}function sd(_0x3ea934,_0x454bb5,_0x2e6894){let _0x400706=_0x3ea934['parent'];for(;_0x400706!==null;){if(_0x454bb5(_0x400706))return!0x0;_0x400706=_0x400706['parent'];}return!0x1;}function Gt(_0x122df8){return new C(_0x122df8['parent']===null?_0x122df8['name']:Gt(_0x122df8['parent'])+'/'+_0x122df8['name']);}function Ri(_0xab69e6){_0xab69e6['parent']!==null&&rd(_0xab69e6['parent'],_0xab69e6['name'],_0xab69e6);}function rd(_0x50663e,_0x235268,_0x9b9399){const _0x553708=id(_0x9b9399),_0x5749bb=Y(_0x50663e['node']['children'],_0x235268);_0x553708&&_0x5749bb?(delete _0x50663e['node']['children'][_0x235268],_0x50663e['node']['childCount']--,Ri(_0x50663e)):!_0x553708&&!_0x5749bb&&(_0x50663e['node']['children'][_0x235268]=_0x9b9399['node'],_0x50663e['node']['childCount']++,Ri(_0x50663e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x466928){return typeof _0x466928=='string'&&_0x466928['length']!==0x0&&!od['test'](_0x466928);},na=function(_0x458f8c){return typeof _0x458f8c=='string'&&_0x458f8c['length']!==0x0&&!ad['test'](_0x458f8c);},cd=function(_0x411655){return _0x411655&&(_0x411655=_0x411655['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x411655);},Cn=function(_0x4a84de){return _0x4a84de===null||typeof _0x4a84de=='string'||typeof _0x4a84de=='number'&&!Wi(_0x4a84de)||_0x4a84de&&typeof _0x4a84de=='object'&&Y(_0x4a84de,'.sv');},qt=function(_0xcbaa9f,_0x3984ae,_0x2dc513,_0x55d236){_0x55d236&&_0x3984ae===void 0x0||zt(Nn(_0xcbaa9f,'value'),_0x3984ae,_0x2dc513);},zt=function(_0x1aaade,_0x2d1b79,_0x2c6303){const _0x4678c8=_0x2c6303 instanceof C?new Sh(_0x2c6303,_0x1aaade):_0x2c6303;if(_0x2d1b79===void 0x0)throw new Error(_0x1aaade+'contains\x20undefined\x20'+Ne(_0x4678c8));if(typeof _0x2d1b79=='function')throw new Error(_0x1aaade+'contains\x20a\x20function\x20'+Ne(_0x4678c8)+'\x20with\x20contents\x20=\x20'+_0x2d1b79['toString']());if(Wi(_0x2d1b79))throw new Error(_0x1aaade+'contains\x20'+_0x2d1b79['toString']()+'\x20'+Ne(_0x4678c8));if(typeof _0x2d1b79=='string'&&_0x2d1b79['length']>oi/0x3&&Pn(_0x2d1b79)>oi)throw new Error(_0x1aaade+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4678c8)+'\x20(\x27'+_0x2d1b79['substring'](0x0,0x32)+'...\x27)');if(_0x2d1b79&&typeof _0x2d1b79=='object'){let _0x49d232=!0x1,_0xe3135b=!0x1;if(x(_0x2d1b79,(_0x6a7816,_0x2895d5)=>{if(_0x6a7816==='.value')_0x49d232=!0x0;else{if(_0x6a7816!=='.priority'&&_0x6a7816!=='.sv'&&(_0xe3135b=!0x0,!ps(_0x6a7816)))throw new Error(_0x1aaade+'\x20contains\x20an\x20invalid\x20key\x20('+_0x6a7816+')\x20'+Ne(_0x4678c8)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4678c8,_0x6a7816),zt(_0x1aaade,_0x2895d5,_0x4678c8),Rh(_0x4678c8);}),_0x49d232&&_0xe3135b)throw new Error(_0x1aaade+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4678c8)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x1000e0,_0x325ab5){let _0xcadfb2,_0x6f4b0c;for(_0xcadfb2=0x0;_0xcadfb2<_0x325ab5['length'];_0xcadfb2++){_0x6f4b0c=_0x325ab5[_0xcadfb2];const _0x59b3e3=kt(_0x6f4b0c);for(let _0x7ba261=0x0;_0x7ba261<_0x59b3e3['length'];_0x7ba261++)if(!(_0x59b3e3[_0x7ba261]==='.priority'&&_0x7ba261===_0x59b3e3['length']-0x1)){if(!ps(_0x59b3e3[_0x7ba261]))throw new Error(_0x1000e0+'contains\x20an\x20invalid\x20key\x20('+_0x59b3e3[_0x7ba261]+')\x20in\x20path\x20'+_0x6f4b0c['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x325ab5['sort'](Th);let _0x3328d4=null;for(_0xcadfb2=0x0;_0xcadfb2<_0x325ab5['length'];_0xcadfb2++){if(_0x6f4b0c=_0x325ab5[_0xcadfb2],_0x3328d4!==null&&$(_0x3328d4,_0x6f4b0c))throw new Error(_0x1000e0+'contains\x20a\x20path\x20'+_0x3328d4['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x6f4b0c['toString']());_0x3328d4=_0x6f4b0c;}},hd=function(_0x508fe8,_0x35e786,_0x33a56b,_0x43ae0a){const _0x504c39=Nn(_0x508fe8,'values');if(!(_0x35e786&&typeof _0x35e786=='object')||Array['isArray'](_0x35e786))throw new Error(_0x504c39+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5dc539=[];x(_0x35e786,(_0x3a1379,_0x1bfba6)=>{const _0x180015=new C(_0x3a1379);if(zt(_0x504c39,_0x1bfba6,A(_0x33a56b,_0x180015)),Gi(_0x180015)==='.priority'&&!Cn(_0x1bfba6))throw new Error(_0x504c39+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x180015['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5dc539['push'](_0x180015);}),ld(_0x504c39,_0x5dc539);},_s=function(_0x3f751c,_0x5bc2cf,_0x278a33,_0x1f188e){if(!na(_0x278a33))throw new Error(Nn(_0x3f751c,_0x5bc2cf)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x278a33+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x3a036c,_0x291a43,_0x4345e,_0x175ff5){_0x4345e&&(_0x4345e=_0x4345e['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x3a036c,_0x291a43,_0x4345e);},gs=function(_0x295371,_0x4035d1){if(y(_0x4035d1)==='.info')throw new Error(_0x295371+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1b5a2f,_0x4d1c62){const _0x53e117=_0x4d1c62['path']['toString']();if(typeof _0x4d1c62['repoInfo']['host']!='string'||_0x4d1c62['repoInfo']['host']['length']===0x0||!ps(_0x4d1c62['repoInfo']['namespace'])&&_0x4d1c62['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x53e117['length']!==0x0&&!cd(_0x53e117))throw new Error(Nn(_0x1b5a2f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x21bc0f,_0x476c54){let _0x52b799=null;for(let _0x7a1637=0x0;_0x7a1637<_0x476c54['length'];_0x7a1637++){const _0x591680=_0x476c54[_0x7a1637],_0x11fd18=_0x591680['getPath']();_0x52b799!==null&&!qi(_0x11fd18,_0x52b799['path'])&&(_0x21bc0f['eventLists_']['push'](_0x52b799),_0x52b799=null),_0x52b799===null&&(_0x52b799={'events':[],'path':_0x11fd18}),_0x52b799['events']['push'](_0x591680);}_0x52b799&&_0x21bc0f['eventLists_']['push'](_0x52b799);}function ia(_0x36e88e,_0x29051c,_0x6b663d){Bn(_0x36e88e,_0x6b663d),sa(_0x36e88e,_0x3820f2=>qi(_0x3820f2,_0x29051c));}function V(_0x3ab98d,_0xae7c4c,_0xafa5f9){Bn(_0x3ab98d,_0xafa5f9),sa(_0x3ab98d,_0x355c37=>$(_0x355c37,_0xae7c4c)||$(_0xae7c4c,_0x355c37));}function sa(_0x50b31d,_0x486a1a){_0x50b31d['recursionDepth_']++;let _0x82a8d=!0x0;for(let _0x4cc2fa=0x0;_0x4cc2fa<_0x50b31d['eventLists_']['length'];_0x4cc2fa++){const _0x3149c5=_0x50b31d['eventLists_'][_0x4cc2fa];if(_0x3149c5){const _0x504d4b=_0x3149c5['path'];_0x486a1a(_0x504d4b)?(pd(_0x50b31d['eventLists_'][_0x4cc2fa]),_0x50b31d['eventLists_'][_0x4cc2fa]=null):_0x82a8d=!0x1;}}_0x82a8d&&(_0x50b31d['eventLists_']=[]),_0x50b31d['recursionDepth_']--;}function pd(_0x4fde63){for(let _0x56db0d=0x0;_0x56db0d<_0x4fde63['events']['length'];_0x56db0d++){const _0x147fbf=_0x4fde63['events'][_0x56db0d];if(_0x147fbf!==null){_0x4fde63['events'][_0x56db0d]=null;const _0x4a2fbb=_0x147fbf['getEventRunner']();Et&&L('event:\x20'+_0x147fbf['toString']()),lt(_0x4a2fbb);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x4d74f2,_0x30e5e9,_0xec8997,_0x5543c5){this['repoInfo_']=_0x4d74f2,this['forceRestClient_']=_0x30e5e9,this['authTokenProvider_']=_0xec8997,this['appCheckProvider_']=_0x5543c5,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x310486,_0xacee84,_0x29adf1){if(_0x310486['stats_']=Hi(_0x310486['repoInfo_']),_0x310486['forceRestClient_']||Yl())_0x310486['server_']=new fn(_0x310486['repoInfo_'],(_0x108a1b,_0x4670b9,_0x37436d,_0x56a095)=>{pr(_0x310486,_0x108a1b,_0x4670b9,_0x37436d,_0x56a095);},_0x310486['authTokenProvider_'],_0x310486['appCheckProvider_']),setTimeout(()=>_r(_0x310486,!0x0),0x0);else{if(typeof _0x29adf1<'u'&&_0x29adf1!==null){if(typeof _0x29adf1!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x29adf1);}catch(_0x203ab1){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x203ab1);}}_0x310486['persistentConnection_']=new ie(_0x310486['repoInfo_'],_0xacee84,(_0x250504,_0x4a045e,_0x3deb1a,_0x45b363)=>{pr(_0x310486,_0x250504,_0x4a045e,_0x3deb1a,_0x45b363);},_0x39ccde=>{_r(_0x310486,_0x39ccde);},_0xf23df4=>{yd(_0x310486,_0xf23df4);},_0x310486['authTokenProvider_'],_0x310486['appCheckProvider_'],_0x29adf1),_0x310486['server_']=_0x310486['persistentConnection_'];}_0x310486['authTokenProvider_']['addTokenChangeListener'](_0x2d4a78=>{_0x310486['server_']['refreshAuthToken'](_0x2d4a78);}),_0x310486['appCheckProvider_']['addTokenChangeListener'](_0x172338=>{_0x310486['server_']['refreshAppCheckToken'](_0x172338['token']);}),_0x310486['statsReporter_']=eh(_0x310486['repoInfo_'],()=>new eu(_0x310486['stats_'],_0x310486['server_'])),_0x310486['infoData_']=new Yh(),_0x310486['infoSyncTree_']=new dr({'startListening':(_0x47da78,_0x20ad9e,_0x1f5b20,_0x40eb4d)=>{let _0x316966=[];const _0x315498=_0x310486['infoData_']['getNode'](_0x47da78['_path']);return _0x315498['isEmpty']()||(_0x316966=$t(_0x310486['infoSyncTree_'],_0x47da78['_path'],_0x315498),setTimeout(()=>{_0x40eb4d('ok');},0x0)),_0x316966;},'stopListening':()=>{}}),ms(_0x310486,'connected',!0x1),_0x310486['serverSyncTree_']=new dr({'startListening':(_0x5f12c3,_0x491fdd,_0x15f015,_0x3841cd)=>(_0x310486['server_']['listen'](_0x5f12c3,_0x15f015,_0x491fdd,(_0x44d0bc,_0xa070)=>{const _0x4fe8ff=_0x3841cd(_0x44d0bc,_0xa070);V(_0x310486['eventQueue_'],_0x5f12c3['_path'],_0x4fe8ff);}),[]),'stopListening':(_0x25504f,_0x41a855)=>{_0x310486['server_']['unlisten'](_0x25504f,_0x41a855);}});}function oa(_0x40bb17){const _0x26b410=_0x40bb17['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x26b410;}function jt(_0x40516f){return ed({'timestamp':oa(_0x40516f)});}function pr(_0x1eb948,_0x4d8c8b,_0x1040ab,_0x8df554,_0xf71a25){_0x1eb948['dataUpdateCount']++;const _0x5f5810=new C(_0x4d8c8b);_0x1040ab=_0x1eb948['interceptServerDataCallback_']?_0x1eb948['interceptServerDataCallback_'](_0x4d8c8b,_0x1040ab):_0x1040ab;let _0x331ef4=[];if(_0xf71a25){if(_0x8df554){const _0x5e4d10=ln(_0x1040ab,_0x53f58e=>N(_0x53f58e));_0x331ef4=Ku(_0x1eb948['serverSyncTree_'],_0x5f5810,_0x5e4d10,_0xf71a25);}else{const _0xd14481=N(_0x1040ab);_0x331ef4=Yo(_0x1eb948['serverSyncTree_'],_0x5f5810,_0xd14481,_0xf71a25);}}else{if(_0x8df554){const _0x1cffa8=ln(_0x1040ab,_0x3c7e81=>N(_0x3c7e81));_0x331ef4=qu(_0x1eb948['serverSyncTree_'],_0x5f5810,_0x1cffa8);}else{const _0x555732=N(_0x1040ab);_0x331ef4=$t(_0x1eb948['serverSyncTree_'],_0x5f5810,_0x555732);}}let _0x52b125=_0x5f5810;_0x331ef4['length']>0x0&&(_0x52b125=st(_0x1eb948,_0x5f5810)),V(_0x1eb948['eventQueue_'],_0x52b125,_0x331ef4);}function _r(_0x37ccd1,_0x7f23af){ms(_0x37ccd1,'connected',_0x7f23af),_0x7f23af===!0x1&&wd(_0x37ccd1);}function yd(_0x588810,_0x162e0b){x(_0x162e0b,(_0x3aa085,_0x5c7f9d)=>{ms(_0x588810,_0x3aa085,_0x5c7f9d);});}function ms(_0x13580d,_0x582565,_0x6fb83){const _0xbe9fc5=new C('/.info/'+_0x582565),_0x4b9dd2=N(_0x6fb83);_0x13580d['infoData_']['updateSnapshot'](_0xbe9fc5,_0x4b9dd2);const _0x36148d=$t(_0x13580d['infoSyncTree_'],_0xbe9fc5,_0x4b9dd2);V(_0x13580d['eventQueue_'],_0xbe9fc5,_0x36148d);}function Vn(_0x426aa2){return _0x426aa2['nextWriteId_']++;}function vd(_0x2f7828,_0x1d722a,_0x3d7ad5){const _0x388b05=Yu(_0x2f7828['serverSyncTree_'],_0x1d722a);return _0x388b05!=null?Promise['resolve'](_0x388b05):_0x2f7828['server_']['get'](_0x1d722a)['then'](_0x3cf2de=>{const _0x40be2c=N(_0x3cf2de)['withIndex'](_0x1d722a['_queryParams']['getIndex']());bi(_0x2f7828['serverSyncTree_'],_0x1d722a,_0x3d7ad5,!0x0);let _0x5de930;if(_0x1d722a['_queryParams']['loadsAllData']())_0x5de930=$t(_0x2f7828['serverSyncTree_'],_0x1d722a['_path'],_0x40be2c);else{const _0x1bbb6c=Mt(_0x2f7828['serverSyncTree_'],_0x1d722a);_0x5de930=Yo(_0x2f7828['serverSyncTree_'],_0x1d722a['_path'],_0x40be2c,_0x1bbb6c);}return V(_0x2f7828['eventQueue_'],_0x1d722a['_path'],_0x5de930),wn(_0x2f7828['serverSyncTree_'],_0x1d722a,_0x3d7ad5,null,!0x0),_0x40be2c;},_0x5063ef=>(ut(_0x2f7828,'get\x20for\x20query\x20'+O(_0x1d722a)+'\x20failed:\x20'+_0x5063ef),Promise['reject'](new Error(_0x5063ef))));}function Ed(_0x64dc30,_0x2aae8b,_0xaad1db,_0x4a55bf,_0x4533c7){ut(_0x64dc30,'set',{'path':_0x2aae8b['toString'](),'value':_0xaad1db,'priority':_0x4a55bf});const _0x122c74=jt(_0x64dc30),_0x257e86=N(_0xaad1db,_0x4a55bf),_0xcfa90f=xn(_0x64dc30['serverSyncTree_'],_0x2aae8b),_0x41af89=hs(_0x257e86,_0xcfa90f,_0x122c74),_0xb31a3b=Vn(_0x64dc30),_0x4163ae=ss(_0x64dc30['serverSyncTree_'],_0x2aae8b,_0x41af89,_0xb31a3b,!0x0);Bn(_0x64dc30['eventQueue_'],_0x4163ae),_0x64dc30['server_']['put'](_0x2aae8b['toString'](),_0x257e86['val'](!0x0),(_0xda6b59,_0x1d167b)=>{const _0x4f91a9=_0xda6b59==='ok';_0x4f91a9||U('set\x20at\x20'+_0x2aae8b+'\x20failed:\x20'+_0xda6b59);const _0x2eb393=pe(_0x64dc30['serverSyncTree_'],_0xb31a3b,!_0x4f91a9);V(_0x64dc30['eventQueue_'],_0x2aae8b,_0x2eb393),Ai(_0x64dc30,_0x4533c7,_0xda6b59,_0x1d167b);});const _0x2cc22d=vs(_0x64dc30,_0x2aae8b);st(_0x64dc30,_0x2cc22d),V(_0x64dc30['eventQueue_'],_0x2cc22d,[]);}function Id(_0x10c197,_0x11ab70,_0x29f1f6,_0x378dac){ut(_0x10c197,'update',{'path':_0x11ab70['toString'](),'value':_0x29f1f6});let _0x20a1de=!0x0;const _0x3e42a8=jt(_0x10c197),_0x3b4c6c={};if(x(_0x29f1f6,(_0x40916b,_0x143684)=>{_0x20a1de=!0x1,_0x3b4c6c[_0x40916b]=Zo(A(_0x11ab70,_0x40916b),N(_0x143684),_0x10c197['serverSyncTree_'],_0x3e42a8);}),_0x20a1de)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x10c197,_0x378dac,'ok',void 0x0);else{const _0x4f6ec6=Vn(_0x10c197),_0x15352e=Gu(_0x10c197['serverSyncTree_'],_0x11ab70,_0x3b4c6c,_0x4f6ec6);Bn(_0x10c197['eventQueue_'],_0x15352e),_0x10c197['server_']['merge'](_0x11ab70['toString'](),_0x29f1f6,(_0x263eee,_0x4e14a0)=>{const _0x114d2f=_0x263eee==='ok';_0x114d2f||U('update\x20at\x20'+_0x11ab70+'\x20failed:\x20'+_0x263eee);const _0x411903=pe(_0x10c197['serverSyncTree_'],_0x4f6ec6,!_0x114d2f),_0x26d18f=_0x411903['length']>0x0?st(_0x10c197,_0x11ab70):_0x11ab70;V(_0x10c197['eventQueue_'],_0x26d18f,_0x411903),Ai(_0x10c197,_0x378dac,_0x263eee,_0x4e14a0);}),x(_0x29f1f6,_0x8954a1=>{const _0x1b791e=vs(_0x10c197,A(_0x11ab70,_0x8954a1));st(_0x10c197,_0x1b791e);}),V(_0x10c197['eventQueue_'],_0x11ab70,[]);}}function wd(_0x276388){ut(_0x276388,'onDisconnectEvents');const _0xf9de76=jt(_0x276388),_0x29d24a=pn();Ei(_0x276388['onDisconnect_'],w(),(_0x351a80,_0x45c0b2)=>{const _0x5b003d=Zo(_0x351a80,_0x45c0b2,_0x276388['serverSyncTree_'],_0xf9de76);Mo(_0x29d24a,_0x351a80,_0x5b003d);});let _0x1b1c85=[];Ei(_0x29d24a,w(),(_0x61e269,_0x3e615e)=>{_0x1b1c85=_0x1b1c85['concat']($t(_0x276388['serverSyncTree_'],_0x61e269,_0x3e615e));const _0x17c56f=vs(_0x276388,_0x61e269);st(_0x276388,_0x17c56f);}),_0x276388['onDisconnect_']=pn(),V(_0x276388['eventQueue_'],w(),_0x1b1c85);}function Cd(_0x242447,_0x4285eb,_0x8c9c11){let _0xe7536b;y(_0x4285eb['_path'])==='.info'?_0xe7536b=bi(_0x242447['infoSyncTree_'],_0x4285eb,_0x8c9c11):_0xe7536b=bi(_0x242447['serverSyncTree_'],_0x4285eb,_0x8c9c11),ia(_0x242447['eventQueue_'],_0x4285eb['_path'],_0xe7536b);}function Td(_0x4e0e83,_0x162010,_0x1ccf6a){let _0x343ad;y(_0x162010['_path'])==='.info'?_0x343ad=wn(_0x4e0e83['infoSyncTree_'],_0x162010,_0x1ccf6a):_0x343ad=wn(_0x4e0e83['serverSyncTree_'],_0x162010,_0x1ccf6a),ia(_0x4e0e83['eventQueue_'],_0x162010['_path'],_0x343ad);}function aa(_0x5541c3){_0x5541c3['persistentConnection_']&&_0x5541c3['persistentConnection_']['interrupt'](ra);}function Sd(_0x31d7e9){_0x31d7e9['persistentConnection_']&&_0x31d7e9['persistentConnection_']['resume'](ra);}function ut(_0x4e932e,..._0x2bdd00){let _0x4d47c5='';_0x4e932e['persistentConnection_']&&(_0x4d47c5=_0x4e932e['persistentConnection_']['id']+':'),L(_0x4d47c5,..._0x2bdd00);}function Ai(_0x13d0ac,_0x401e23,_0x1f3fe3,_0x4e199b){_0x401e23&&lt(()=>{if(_0x1f3fe3==='ok')_0x401e23(null);else{const _0x312147=(_0x1f3fe3||'error')['toUpperCase']();let _0x47c969=_0x312147;_0x4e199b&&(_0x47c969+=':\x20'+_0x4e199b);const _0x5838e8=new Error(_0x47c969);_0x5838e8['code']=_0x312147,_0x401e23(_0x5838e8);}});}function bd(_0x37970b,_0x3875c4,_0x30e2e5,_0x301b58,_0x3bdd57,_0x238fcd){ut(_0x37970b,'transaction\x20on\x20'+_0x3875c4);const _0x48f0cf={'path':_0x3875c4,'update':_0x30e2e5,'onComplete':_0x301b58,'status':null,'order':to(),'applyLocally':_0x238fcd,'retryCount':0x0,'unwatcher':_0x3bdd57,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x56fbd4=ys(_0x37970b,_0x3875c4,void 0x0);_0x48f0cf['currentInputSnapshot']=_0x56fbd4;const _0x1d13e5=_0x48f0cf['update'](_0x56fbd4['val']());if(_0x1d13e5===void 0x0)_0x48f0cf['unwatcher'](),_0x48f0cf['currentOutputSnapshotRaw']=null,_0x48f0cf['currentOutputSnapshotResolved']=null,_0x48f0cf['onComplete']&&_0x48f0cf['onComplete'](null,!0x1,_0x48f0cf['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1d13e5,_0x48f0cf['path']),_0x48f0cf['status']=0x0;const _0x36e92f=Un(_0x37970b['transactionQueueTree_'],_0x3875c4),_0x4d9263=Ge(_0x36e92f)||[];_0x4d9263['push'](_0x48f0cf),fs(_0x36e92f,_0x4d9263);let _0x1b33ee;typeof _0x1d13e5=='object'&&_0x1d13e5!==null&&Y(_0x1d13e5,'.priority')?(_0x1b33ee=Oe(_0x1d13e5,'.priority'),f(Cn(_0x1b33ee),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1b33ee=(xn(_0x37970b['serverSyncTree_'],_0x3875c4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5acc2c=jt(_0x37970b),_0x224b94=N(_0x1d13e5,_0x1b33ee),_0x2abaa6=hs(_0x224b94,_0x56fbd4,_0x5acc2c);_0x48f0cf['currentOutputSnapshotRaw']=_0x224b94,_0x48f0cf['currentOutputSnapshotResolved']=_0x2abaa6,_0x48f0cf['currentWriteId']=Vn(_0x37970b);const _0x5349e5=ss(_0x37970b['serverSyncTree_'],_0x3875c4,_0x2abaa6,_0x48f0cf['currentWriteId'],_0x48f0cf['applyLocally']);V(_0x37970b['eventQueue_'],_0x3875c4,_0x5349e5),Hn(_0x37970b,_0x37970b['transactionQueueTree_']);}}function ys(_0x76f5b8,_0x5bf517,_0x503da3){return xn(_0x76f5b8['serverSyncTree_'],_0x5bf517,_0x503da3)||g['EMPTY_NODE'];}function Hn(_0x546a8b,_0x3cd861=_0x546a8b['transactionQueueTree_']){if(_0x3cd861||$n(_0x546a8b,_0x3cd861),Ge(_0x3cd861)){const _0x4e8c2b=la(_0x546a8b,_0x3cd861);f(_0x4e8c2b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4e8c2b['every'](_0xa78580=>_0xa78580['status']===0x0)&&Rd(_0x546a8b,Gt(_0x3cd861),_0x4e8c2b);}else ea(_0x3cd861)&&Wn(_0x3cd861,_0x5a05c4=>{Hn(_0x546a8b,_0x5a05c4);});}function Rd(_0x3f34a0,_0x2f6dd6,_0x14b060){const _0x3def20=_0x14b060['map'](_0x3904f5=>_0x3904f5['currentWriteId']),_0x486d82=ys(_0x3f34a0,_0x2f6dd6,_0x3def20);let _0x4af431=_0x486d82;const _0x2f817f=_0x486d82['hash']();for(let _0x4197df=0x0;_0x4197df<_0x14b060['length'];_0x4197df++){const _0x52669c=_0x14b060[_0x4197df];f(_0x52669c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x52669c['status']=0x1,_0x52669c['retryCount']++;const _0x4a6b40=F(_0x2f6dd6,_0x52669c['path']);_0x4af431=_0x4af431['updateChild'](_0x4a6b40,_0x52669c['currentOutputSnapshotRaw']);}const _0x1bb0c1=_0x4af431['val'](!0x0),_0x58c995=_0x2f6dd6;_0x3f34a0['server_']['put'](_0x58c995['toString'](),_0x1bb0c1,_0x313fdf=>{ut(_0x3f34a0,'transaction\x20put\x20response',{'path':_0x58c995['toString'](),'status':_0x313fdf});let _0x34eb02=[];if(_0x313fdf==='ok'){const _0xde9cc1=[];for(let _0x15fdd5=0x0;_0x15fdd5<_0x14b060['length'];_0x15fdd5++)_0x14b060[_0x15fdd5]['status']=0x2,_0x34eb02=_0x34eb02['concat'](pe(_0x3f34a0['serverSyncTree_'],_0x14b060[_0x15fdd5]['currentWriteId'])),_0x14b060[_0x15fdd5]['onComplete']&&_0xde9cc1['push'](()=>_0x14b060[_0x15fdd5]['onComplete'](null,!0x0,_0x14b060[_0x15fdd5]['currentOutputSnapshotResolved'])),_0x14b060[_0x15fdd5]['unwatcher']();$n(_0x3f34a0,Un(_0x3f34a0['transactionQueueTree_'],_0x2f6dd6)),Hn(_0x3f34a0,_0x3f34a0['transactionQueueTree_']),V(_0x3f34a0['eventQueue_'],_0x2f6dd6,_0x34eb02);for(let _0x3d2c3e=0x0;_0x3d2c3e<_0xde9cc1['length'];_0x3d2c3e++)lt(_0xde9cc1[_0x3d2c3e]);}else{if(_0x313fdf==='datastale'){for(let _0x2432da=0x0;_0x2432da<_0x14b060['length'];_0x2432da++)_0x14b060[_0x2432da]['status']===0x3?_0x14b060[_0x2432da]['status']=0x4:_0x14b060[_0x2432da]['status']=0x0;}else{U('transaction\x20at\x20'+_0x58c995['toString']()+'\x20failed:\x20'+_0x313fdf);for(let _0x1dd09d=0x0;_0x1dd09d<_0x14b060['length'];_0x1dd09d++)_0x14b060[_0x1dd09d]['status']=0x4,_0x14b060[_0x1dd09d]['abortReason']=_0x313fdf;}st(_0x3f34a0,_0x2f6dd6);}},_0x2f817f);}function st(_0x52dee0,_0x4af412){const _0x4ecb6a=ca(_0x52dee0,_0x4af412),_0x5be1f5=Gt(_0x4ecb6a),_0x23638a=la(_0x52dee0,_0x4ecb6a);return Ad(_0x52dee0,_0x23638a,_0x5be1f5),_0x5be1f5;}function Ad(_0x787f55,_0x176651,_0x4e7c3f){if(_0x176651['length']===0x0)return;const _0x2c28f2=[];let _0x3f9718=[];const _0x71a37f=_0x176651['filter'](_0x276941=>_0x276941['status']===0x0)['map'](_0x354f58=>_0x354f58['currentWriteId']);for(let _0x39f31f=0x0;_0x39f31f<_0x176651['length'];_0x39f31f++){const _0xdf334d=_0x176651[_0x39f31f],_0x3cc7ae=F(_0x4e7c3f,_0xdf334d['path']);let _0xf84a2d=!0x1,_0x22f6b7;if(f(_0x3cc7ae!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xdf334d['status']===0x4)_0xf84a2d=!0x0,_0x22f6b7=_0xdf334d['abortReason'],_0x3f9718=_0x3f9718['concat'](pe(_0x787f55['serverSyncTree_'],_0xdf334d['currentWriteId'],!0x0));else{if(_0xdf334d['status']===0x0){if(_0xdf334d['retryCount']>=_d)_0xf84a2d=!0x0,_0x22f6b7='maxretry',_0x3f9718=_0x3f9718['concat'](pe(_0x787f55['serverSyncTree_'],_0xdf334d['currentWriteId'],!0x0));else{const _0x374904=ys(_0x787f55,_0xdf334d['path'],_0x71a37f);_0xdf334d['currentInputSnapshot']=_0x374904;const _0x866a9d=_0x176651[_0x39f31f]['update'](_0x374904['val']());if(_0x866a9d!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x866a9d,_0xdf334d['path']);let _0xd2098=N(_0x866a9d);typeof _0x866a9d=='object'&&_0x866a9d!=null&&Y(_0x866a9d,'.priority')||(_0xd2098=_0xd2098['updatePriority'](_0x374904['getPriority']()));const _0x2c509e=_0xdf334d['currentWriteId'],_0x24e1d7=jt(_0x787f55),_0x1bd54f=hs(_0xd2098,_0x374904,_0x24e1d7);_0xdf334d['currentOutputSnapshotRaw']=_0xd2098,_0xdf334d['currentOutputSnapshotResolved']=_0x1bd54f,_0xdf334d['currentWriteId']=Vn(_0x787f55),_0x71a37f['splice'](_0x71a37f['indexOf'](_0x2c509e),0x1),_0x3f9718=_0x3f9718['concat'](ss(_0x787f55['serverSyncTree_'],_0xdf334d['path'],_0x1bd54f,_0xdf334d['currentWriteId'],_0xdf334d['applyLocally'])),_0x3f9718=_0x3f9718['concat'](pe(_0x787f55['serverSyncTree_'],_0x2c509e,!0x0));}else _0xf84a2d=!0x0,_0x22f6b7='nodata',_0x3f9718=_0x3f9718['concat'](pe(_0x787f55['serverSyncTree_'],_0xdf334d['currentWriteId'],!0x0));}}}V(_0x787f55['eventQueue_'],_0x4e7c3f,_0x3f9718),_0x3f9718=[],_0xf84a2d&&(_0x176651[_0x39f31f]['status']=0x2,function(_0x29de07){setTimeout(_0x29de07,Math['floor'](0x0));}(_0x176651[_0x39f31f]['unwatcher']),_0x176651[_0x39f31f]['onComplete']&&(_0x22f6b7==='nodata'?_0x2c28f2['push'](()=>_0x176651[_0x39f31f]['onComplete'](null,!0x1,_0x176651[_0x39f31f]['currentInputSnapshot'])):_0x2c28f2['push'](()=>_0x176651[_0x39f31f]['onComplete'](new Error(_0x22f6b7),!0x1,null))));}$n(_0x787f55,_0x787f55['transactionQueueTree_']);for(let _0x284c66=0x0;_0x284c66<_0x2c28f2['length'];_0x284c66++)lt(_0x2c28f2[_0x284c66]);Hn(_0x787f55,_0x787f55['transactionQueueTree_']);}function ca(_0x1e774a,_0x5e056e){let _0x2aff10,_0x3b5866=_0x1e774a['transactionQueueTree_'];for(_0x2aff10=y(_0x5e056e);_0x2aff10!==null&&Ge(_0x3b5866)===void 0x0;)_0x3b5866=Un(_0x3b5866,_0x2aff10),_0x5e056e=b(_0x5e056e),_0x2aff10=y(_0x5e056e);return _0x3b5866;}function la(_0x459f8b,_0x448dc9){const _0x4656be=[];return ha(_0x459f8b,_0x448dc9,_0x4656be),_0x4656be['sort']((_0x4568ab,_0x58de18)=>_0x4568ab['order']-_0x58de18['order']),_0x4656be;}function ha(_0x52e8ab,_0x4a8a29,_0x8e1d2b){const _0x28c255=Ge(_0x4a8a29);if(_0x28c255){for(let _0x1bd4aa=0x0;_0x1bd4aa<_0x28c255['length'];_0x1bd4aa++)_0x8e1d2b['push'](_0x28c255[_0x1bd4aa]);}Wn(_0x4a8a29,_0x376f3e=>{ha(_0x52e8ab,_0x376f3e,_0x8e1d2b);});}function $n(_0x29b2d5,_0x426b17){const _0x9f7c2=Ge(_0x426b17);if(_0x9f7c2){let _0x467ff2=0x0;for(let _0x4223fe=0x0;_0x4223fe<_0x9f7c2['length'];_0x4223fe++)_0x9f7c2[_0x4223fe]['status']!==0x2&&(_0x9f7c2[_0x467ff2]=_0x9f7c2[_0x4223fe],_0x467ff2++);_0x9f7c2['length']=_0x467ff2,fs(_0x426b17,_0x9f7c2['length']>0x0?_0x9f7c2:void 0x0);}Wn(_0x426b17,_0x289b72=>{$n(_0x29b2d5,_0x289b72);});}function vs(_0xa0293c,_0x37b85f){const _0xca4080=Gt(ca(_0xa0293c,_0x37b85f)),_0x521d0b=Un(_0xa0293c['transactionQueueTree_'],_0x37b85f);return sd(_0x521d0b,_0x5c3c3b=>{ai(_0xa0293c,_0x5c3c3b);}),ai(_0xa0293c,_0x521d0b),ta(_0x521d0b,_0x3bc6ed=>{ai(_0xa0293c,_0x3bc6ed);}),_0xca4080;}function ai(_0x30440e,_0x1b046a){const _0x3d2c46=Ge(_0x1b046a);if(_0x3d2c46){const _0x3e4aa2=[];let _0x1b281d=[],_0x4318f4=-0x1;for(let _0x294438=0x0;_0x294438<_0x3d2c46['length'];_0x294438++)_0x3d2c46[_0x294438]['status']===0x3||(_0x3d2c46[_0x294438]['status']===0x1?(f(_0x4318f4===_0x294438-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4318f4=_0x294438,_0x3d2c46[_0x294438]['status']=0x3,_0x3d2c46[_0x294438]['abortReason']='set'):(f(_0x3d2c46[_0x294438]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3d2c46[_0x294438]['unwatcher'](),_0x1b281d=_0x1b281d['concat'](pe(_0x30440e['serverSyncTree_'],_0x3d2c46[_0x294438]['currentWriteId'],!0x0)),_0x3d2c46[_0x294438]['onComplete']&&_0x3e4aa2['push'](_0x3d2c46[_0x294438]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4318f4===-0x1?fs(_0x1b046a,void 0x0):_0x3d2c46['length']=_0x4318f4+0x1,V(_0x30440e['eventQueue_'],Gt(_0x1b046a),_0x1b281d);for(let _0x20f48c=0x0;_0x20f48c<_0x3e4aa2['length'];_0x20f48c++)lt(_0x3e4aa2[_0x20f48c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x3b234a){let _0x38e1b6='';const _0x4ef9a5=_0x3b234a['split']('/');for(let _0x4af72=0x0;_0x4af72<_0x4ef9a5['length'];_0x4af72++)if(_0x4ef9a5[_0x4af72]['length']>0x0){let _0x58f2b6=_0x4ef9a5[_0x4af72];try{_0x58f2b6=decodeURIComponent(_0x58f2b6['replace'](/\+/g,'\x20'));}catch{}_0x38e1b6+='/'+_0x58f2b6;}return _0x38e1b6;}function Nd(_0x335f5a){const _0x5664d9={};_0x335f5a['charAt'](0x0)==='?'&&(_0x335f5a=_0x335f5a['substring'](0x1));for(const _0xb97d9 of _0x335f5a['split']('&')){if(_0xb97d9['length']===0x0)continue;const _0x426f0f=_0xb97d9['split']('=');_0x426f0f['length']===0x2?_0x5664d9[decodeURIComponent(_0x426f0f[0x0])]=decodeURIComponent(_0x426f0f[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xb97d9+'\x27\x20in\x20query\x20\x27'+_0x335f5a+'\x27');}return _0x5664d9;}const gr=function(_0x4c5e15,_0x5a5731){const _0xb5e2bf=Pd(_0x4c5e15),_0x43125a=_0xb5e2bf['namespace'];_0xb5e2bf['domain']==='firebase.com'&&oe(_0xb5e2bf['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x43125a||_0x43125a==='undefined')&&_0xb5e2bf['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xb5e2bf['secure']||Bl();const _0x2ccb9a=_0xb5e2bf['scheme']==='ws'||_0xb5e2bf['scheme']==='wss';return{'repoInfo':new _o(_0xb5e2bf['host'],_0xb5e2bf['secure'],_0x43125a,_0x2ccb9a,_0x5a5731,'',_0x43125a!==_0xb5e2bf['subdomain']),'path':new C(_0xb5e2bf['pathString'])};},Pd=function(_0x1f19ae){let _0x1f30ae='',_0x5f1215='',_0x3f08c8='',_0x2b1794='',_0x20f73d='',_0x4674aa=!0x0,_0x534a48='https',_0x376ae2=0x1bb;if(typeof _0x1f19ae=='string'){let _0x1d6385=_0x1f19ae['indexOf']('//');_0x1d6385>=0x0&&(_0x534a48=_0x1f19ae['substring'](0x0,_0x1d6385-0x1),_0x1f19ae=_0x1f19ae['substring'](_0x1d6385+0x2));let _0x5cc2b5=_0x1f19ae['indexOf']('/');_0x5cc2b5===-0x1&&(_0x5cc2b5=_0x1f19ae['length']);let _0x1c652f=_0x1f19ae['indexOf']('?');_0x1c652f===-0x1&&(_0x1c652f=_0x1f19ae['length']),_0x1f30ae=_0x1f19ae['substring'](0x0,Math['min'](_0x5cc2b5,_0x1c652f)),_0x5cc2b5<_0x1c652f&&(_0x2b1794=kd(_0x1f19ae['substring'](_0x5cc2b5,_0x1c652f)));const _0x2bc5e5=Nd(_0x1f19ae['substring'](Math['min'](_0x1f19ae['length'],_0x1c652f)));_0x1d6385=_0x1f30ae['indexOf'](':'),_0x1d6385>=0x0?(_0x4674aa=_0x534a48==='https'||_0x534a48==='wss',_0x376ae2=parseInt(_0x1f30ae['substring'](_0x1d6385+0x1),0xa)):_0x1d6385=_0x1f30ae['length'];const _0x33c1a1=_0x1f30ae['slice'](0x0,_0x1d6385);if(_0x33c1a1['toLowerCase']()==='localhost')_0x5f1215='localhost';else{if(_0x33c1a1['split']('.')['length']<=0x2)_0x5f1215=_0x33c1a1;else{const _0x5de188=_0x1f30ae['indexOf']('.');_0x3f08c8=_0x1f30ae['substring'](0x0,_0x5de188)['toLowerCase'](),_0x5f1215=_0x1f30ae['substring'](_0x5de188+0x1),_0x20f73d=_0x3f08c8;}}'ns'in _0x2bc5e5&&(_0x20f73d=_0x2bc5e5['ns']);}return{'host':_0x1f30ae,'port':_0x376ae2,'domain':_0x5f1215,'subdomain':_0x3f08c8,'secure':_0x4674aa,'scheme':_0x534a48,'pathString':_0x2b1794,'namespace':_0x20f73d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x1ce3a0=0x0;const _0x214f18=[];return function(_0x154b52){const _0x548997=_0x154b52===_0x1ce3a0;_0x1ce3a0=_0x154b52;let _0x5e560e;const _0x11662e=new Array(0x8);for(_0x5e560e=0x7;_0x5e560e>=0x0;_0x5e560e--)_0x11662e[_0x5e560e]=mr['charAt'](_0x154b52%0x40),_0x154b52=Math['floor'](_0x154b52/0x40);f(_0x154b52===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3efa33=_0x11662e['join']('');if(_0x548997){for(_0x5e560e=0xb;_0x5e560e>=0x0&&_0x214f18[_0x5e560e]===0x3f;_0x5e560e--)_0x214f18[_0x5e560e]=0x0;_0x214f18[_0x5e560e]++;}else{for(_0x5e560e=0x0;_0x5e560e<0xc;_0x5e560e++)_0x214f18[_0x5e560e]=Math['floor'](Math['random']()*0x40);}for(_0x5e560e=0x0;_0x5e560e<0xc;_0x5e560e++)_0x3efa33+=mr['charAt'](_0x214f18[_0x5e560e]);return f(_0x3efa33['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3efa33;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x24b402,_0x4f047e,_0x67bc41,_0x521ae9){this['eventType']=_0x24b402,this['eventRegistration']=_0x4f047e,this['snapshot']=_0x67bc41,this['prevName']=_0x521ae9;}['getPath'](){const _0x1c4302=this['snapshot']['ref'];return this['eventType']==='value'?_0x1c4302['_path']:_0x1c4302['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x17f499,_0x584143,_0x4539a0){this['eventRegistration']=_0x17f499,this['error']=_0x584143,this['path']=_0x4539a0;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x23dfd3,_0x5774e3){this['snapshotCallback']=_0x23dfd3,this['cancelCallback']=_0x5774e3;}['onValue'](_0x55ec96,_0x4f4707){this['snapshotCallback']['call'](null,_0x55ec96,_0x4f4707);}['onCancel'](_0x30f3d6){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x30f3d6);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5eefe0){return this['snapshotCallback']===_0x5eefe0['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5eefe0['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5eefe0['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x1e5da6,_0x144a70,_0x203645,_0x435756){this['_repo']=_0x1e5da6,this['_path']=_0x144a70,this['_queryParams']=_0x203645,this['_orderByCalled']=_0x435756;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x35f4aa=nr(this['_queryParams']),_0x5a0797=Bi(_0x35f4aa);return _0x5a0797==='{}'?'default':_0x5a0797;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x240d04){if(_0x240d04=k(_0x240d04),!(_0x240d04 instanceof be))return!0x1;const _0x40c058=this['_repo']===_0x240d04['_repo'],_0x3e7e1d=qi(this['_path'],_0x240d04['_path']),_0x37765d=this['_queryIdentifier']===_0x240d04['_queryIdentifier'];return _0x40c058&&_0x3e7e1d&&_0x37765d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x21ee41,_0x4129bf){if(_0x21ee41['_orderByCalled']===!0x0)throw new Error(_0x4129bf+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x1937bb){let _0x5af4bf=null,_0x36bdfe=null;if(_0x1937bb['hasStart']()&&(_0x5af4bf=_0x1937bb['getIndexStartValue']()),_0x1937bb['hasEnd']()&&(_0x36bdfe=_0x1937bb['getIndexEndValue']()),_0x1937bb['getIndex']()===ye){const _0x34fbf7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x56c1d8='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1937bb['hasStart']()){if(_0x1937bb['getIndexStartName']()!==xe)throw new Error(_0x34fbf7);if(typeof _0x5af4bf!='string')throw new Error(_0x56c1d8);}if(_0x1937bb['hasEnd']()){if(_0x1937bb['getIndexEndName']()!==Ie)throw new Error(_0x34fbf7);if(typeof _0x36bdfe!='string')throw new Error(_0x56c1d8);}}else{if(_0x1937bb['getIndex']()===R){if(_0x5af4bf!=null&&!Cn(_0x5af4bf)||_0x36bdfe!=null&&!Cn(_0x36bdfe))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1937bb['getIndex']()instanceof Ki||_0x1937bb['getIndex']()===Po,'unknown\x20index\x20type.'),_0x5af4bf!=null&&typeof _0x5af4bf=='object'||_0x36bdfe!=null&&typeof _0x36bdfe=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x50d2eb){if(_0x50d2eb['hasStart']()&&_0x50d2eb['hasEnd']()&&_0x50d2eb['hasLimit']()&&!_0x50d2eb['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x33a49a,_0x5ef231){super(_0x33a49a,_0x5ef231,new Qi(),!0x1);}get['parent'](){const _0x5389da=To(this['_path']);return _0x5389da===null?null:new Z(this['_repo'],_0x5389da);}get['root'](){let _0x1331b7=this;for(;_0x1331b7['parent']!==null;)_0x1331b7=_0x1331b7['parent'];return _0x1331b7;}}class rt{constructor(_0x1906e4,_0x44ff99,_0x20c3ef){this['_node']=_0x1906e4,this['ref']=_0x44ff99,this['_index']=_0x20c3ef;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x105017){const _0x43cefe=new C(_0x105017),_0x55c4d9=Lt(this['ref'],_0x105017);return new rt(this['_node']['getChild'](_0x43cefe),_0x55c4d9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x535ae1){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2a2a69,_0x327b9b)=>_0x535ae1(new rt(_0x327b9b,Lt(this['ref'],_0x2a2a69),R)));}['hasChild'](_0x2ffb51){const _0x4de5db=new C(_0x2ffb51);return!this['_node']['getChild'](_0x4de5db)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1a65ae,_0x4abef9){return _0x1a65ae=k(_0x1a65ae),_0x1a65ae['_checkNotDeleted']('ref'),_0x4abef9!==void 0x0?Lt(_0x1a65ae['_root'],_0x4abef9):_0x1a65ae['_root'];}function Lt(_0xb51c86,_0x2997dd){return _0xb51c86=k(_0xb51c86),y(_0xb51c86['_path'])===null?ud('child','path',_0x2997dd):_s('child','path',_0x2997dd),new Z(_0xb51c86['_repo'],A(_0xb51c86['_path'],_0x2997dd));}function d_(_0x1bd621,_0x46a6fa){_0x1bd621=k(_0x1bd621),gs('push',_0x1bd621['_path']),qt('push',_0x46a6fa,_0x1bd621['_path'],!0x0);const _0x4d6f03=oa(_0x1bd621['_repo']),_0x1e61bf=Od(_0x4d6f03),_0x2e3029=Lt(_0x1bd621,_0x1e61bf),_0xcf8aac=Lt(_0x1bd621,_0x1e61bf);let _0x2531de;return _0x46a6fa!=null?_0x2531de=Ld(_0xcf8aac,_0x46a6fa)['then'](()=>_0xcf8aac):_0x2531de=Promise['resolve'](_0xcf8aac),_0x2e3029['then']=_0x2531de['then']['bind'](_0x2531de),_0x2e3029['catch']=_0x2531de['then']['bind'](_0x2531de,void 0x0),_0x2e3029;}function Ld(_0x1a124d,_0x6d6408){_0x1a124d=k(_0x1a124d),gs('set',_0x1a124d['_path']),qt('set',_0x6d6408,_0x1a124d['_path'],!0x1);const _0x4d106a=new Ve();return Ed(_0x1a124d['_repo'],_0x1a124d['_path'],_0x6d6408,null,_0x4d106a['wrapCallback'](()=>{})),_0x4d106a['promise'];}function f_(_0x89d9a1,_0x2fd0af){hd('update',_0x2fd0af,_0x89d9a1['_path']);const _0x413ab8=new Ve();return Id(_0x89d9a1['_repo'],_0x89d9a1['_path'],_0x2fd0af,_0x413ab8['wrapCallback'](()=>{})),_0x413ab8['promise'];}function p_(_0x910dc2){_0x910dc2=k(_0x910dc2);const _0x4db8ca=new ua(()=>{}),_0x129813=new qn(_0x4db8ca);return vd(_0x910dc2['_repo'],_0x910dc2,_0x129813)['then'](_0x4d2baa=>new rt(_0x4d2baa,new Z(_0x910dc2['_repo'],_0x910dc2['_path']),_0x910dc2['_queryParams']['getIndex']()));}class qn{constructor(_0x5be15a){this['callbackContext']=_0x5be15a;}['respondsTo'](_0xda7e5a){return _0xda7e5a==='value';}['createEvent'](_0x115675,_0x5236a2){const _0x39ff98=_0x5236a2['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x115675['snapshotNode'],new Z(_0x5236a2['_repo'],_0x5236a2['_path']),_0x39ff98));}['getEventRunner'](_0x3af2d4){return _0x3af2d4['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3af2d4['error']):()=>this['callbackContext']['onValue'](_0x3af2d4['snapshot'],null);}['createCancelEvent'](_0x403f09,_0x1aa764){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x403f09,_0x1aa764):null;}['matches'](_0x11563b){return _0x11563b instanceof qn?!_0x11563b['callbackContext']||!this['callbackContext']?!0x0:_0x11563b['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x39801d,_0x5a7f7d,_0x5a2610,_0x3e8c27,_0x161cd1){const _0x25af3a=new ua(_0x5a2610,void 0x0),_0x57074e=new qn(_0x25af3a);return Cd(_0x39801d['_repo'],_0x39801d,_0x57074e),()=>Td(_0x39801d['_repo'],_0x39801d,_0x57074e);}function Fd(_0x53a9b9,_0x259df2,_0x31c814,_0x23f91a){return xd(_0x53a9b9,'value',_0x259df2);}class dt{}class pa extends dt{constructor(_0x543668,_0x2911f6){super(),this['_value']=_0x543668,this['_key']=_0x2911f6,this['type']='endAt';}['_apply'](_0x40c5d5){qt('endAt',this['_value'],_0x40c5d5['_path'],!0x0);const _0x10b320=Kh(_0x40c5d5['_queryParams'],this['_value'],this['_key']);if(fa(_0x10b320),Gn(_0x10b320),_0x40c5d5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x40c5d5['_repo'],_0x40c5d5['_path'],_0x10b320,_0x40c5d5['_orderByCalled']);}}function __(_0x58d8dc,_0x1222d4){return new pa(_0x58d8dc,_0x1222d4);}class _a extends dt{constructor(_0x1dc2da,_0x2276cf){super(),this['_value']=_0x1dc2da,this['_key']=_0x2276cf,this['type']='startAt';}['_apply'](_0x5297af){qt('startAt',this['_value'],_0x5297af['_path'],!0x0);const _0x5c0c6c=jh(_0x5297af['_queryParams'],this['_value'],this['_key']);if(fa(_0x5c0c6c),Gn(_0x5c0c6c),_0x5297af['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5297af['_repo'],_0x5297af['_path'],_0x5c0c6c,_0x5297af['_orderByCalled']);}}function g_(_0x4be7f5=null,_0xca83d2){return new _a(_0x4be7f5,_0xca83d2);}class Ud extends dt{constructor(_0x352f0b){super(),this['_limit']=_0x352f0b,this['type']='limitToFirst';}['_apply'](_0x1ef0d6){if(_0x1ef0d6['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1ef0d6['_repo'],_0x1ef0d6['_path'],zh(_0x1ef0d6['_queryParams'],this['_limit']),_0x1ef0d6['_orderByCalled']);}}function m_(_0x461227){if(Math['floor'](_0x461227)!==_0x461227||_0x461227<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x461227);}class Wd extends dt{constructor(_0x29e9d9){super(),this['_path']=_0x29e9d9,this['type']='orderByChild';}['_apply'](_0x2340a3){da(_0x2340a3,'orderByChild');const _0x4f1007=new C(this['_path']);if(v(_0x4f1007))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3b6926=new Ki(_0x4f1007),_0x3a02e5=Do(_0x2340a3['_queryParams'],_0x3b6926);return Gn(_0x3a02e5),new be(_0x2340a3['_repo'],_0x2340a3['_path'],_0x3a02e5,!0x0);}}function y_(_0x407da3){if(_0x407da3==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x407da3==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x407da3==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x407da3),new Wd(_0x407da3);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x49f93c){da(_0x49f93c,'orderByKey');const _0x259489=Do(_0x49f93c['_queryParams'],ye);return Gn(_0x259489),new be(_0x49f93c['_repo'],_0x49f93c['_path'],_0x259489,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x2fa1b0,_0x1b4248){super(),this['_value']=_0x2fa1b0,this['_key']=_0x1b4248,this['type']='equalTo';}['_apply'](_0x40f945){if(qt('equalTo',this['_value'],_0x40f945['_path'],!0x1),_0x40f945['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x40f945['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x40f945));}}function E_(_0x34b310,_0x1c17ed){return new Vd(_0x34b310,_0x1c17ed);}function I_(_0x532c6a,..._0xbe28fb){let _0xb2cb55=k(_0x532c6a);for(const _0x2f4657 of _0xbe28fb)_0xb2cb55=_0x2f4657['_apply'](_0xb2cb55);return _0xb2cb55;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x17d626,_0x3000e7,_0x5dbcff,_0x14f7c6){const _0x2c0f9a=_0x3000e7['lastIndexOf'](':'),_0x5f220b=_0x3000e7['substring'](0x0,_0x2c0f9a),_0x1990e1=Wt(_0x5f220b);_0x17d626['repoInfo_']=new _o(_0x3000e7,_0x1990e1,_0x17d626['repoInfo_']['namespace'],_0x17d626['repoInfo_']['webSocketOnly'],_0x17d626['repoInfo_']['nodeAdmin'],_0x17d626['repoInfo_']['persistenceKey'],_0x17d626['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5dbcff),_0x14f7c6&&(_0x17d626['authTokenProvider_']=_0x14f7c6);}function qd(_0x39a5d1,_0x97a47f,_0xa4a18c,_0x511a01,_0x5e5f50){let _0x4b8dc4=_0x511a01||_0x39a5d1['options']['databaseURL'];_0x4b8dc4===void 0x0&&(_0x39a5d1['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x39a5d1['options']['projectId']),_0x4b8dc4=_0x39a5d1['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4c8554=gr(_0x4b8dc4,_0x5e5f50),_0xbcb3c2=_0x4c8554['repoInfo'],_0xe15e0f;typeof process<'u'&&Us&&(_0xe15e0f=Us[Hd]),_0xe15e0f?(_0x4b8dc4='http://'+_0xe15e0f+'?ns='+_0xbcb3c2['namespace'],_0x4c8554=gr(_0x4b8dc4,_0x5e5f50),_0xbcb3c2=_0x4c8554['repoInfo']):_0x4c8554['repoInfo']['secure'];const _0x154c88=new Jl(_0x39a5d1['name'],_0x39a5d1['options'],_0x97a47f);dd('Invalid\x20Firebase\x20Database\x20URL',_0x4c8554),v(_0x4c8554['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2098a0=jd(_0xbcb3c2,_0x39a5d1,_0x154c88,new Ql(_0x39a5d1,_0xa4a18c));return new Kd(_0x2098a0,_0x39a5d1);}function zd(_0x1e6418,_0x3c7f4d){const _0x1eb3d7=ki[_0x3c7f4d];(!_0x1eb3d7||_0x1eb3d7[_0x1e6418['key']]!==_0x1e6418)&&oe('Database\x20'+_0x3c7f4d+'('+_0x1e6418['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x1e6418),delete _0x1eb3d7[_0x1e6418['key']];}function jd(_0x44b021,_0x14367d,_0x59dbd8,_0x4ecf14){let _0x4360ff=ki[_0x14367d['name']];_0x4360ff||(_0x4360ff={},ki[_0x14367d['name']]=_0x4360ff);let _0x3c2e5d=_0x4360ff[_0x44b021['toURLString']()];return _0x3c2e5d&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3c2e5d=new gd(_0x44b021,$d,_0x59dbd8,_0x4ecf14),_0x4360ff[_0x44b021['toURLString']()]=_0x3c2e5d,_0x3c2e5d;}class Kd{constructor(_0x1e80d1,_0x125515){this['_repoInternal']=_0x1e80d1,this['app']=_0x125515,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x269020){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x269020+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x17b82d=Qr(),_0x14a540){const _0x48a840=Ui(_0x17b82d,'database')['getImmediate']({'identifier':_0x14a540});if(!_0x48a840['_instanceStarted']){const _0x5c666b=ac('database');_0x5c666b&&Yd(_0x48a840,..._0x5c666b);}return _0x48a840;}function Yd(_0x1b4496,_0x4b484a,_0xa1f752,_0x5b05b3={}){_0x1b4496=k(_0x1b4496),_0x1b4496['_checkNotDeleted']('useEmulator');const _0x54dd11=_0x4b484a+':'+_0xa1f752,_0x3f64e0=_0x1b4496['_repoInternal'];if(_0x1b4496['_instanceStarted']){if(_0x54dd11===_0x1b4496['_repoInternal']['repoInfo_']['host']&&De(_0x5b05b3,_0x3f64e0['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x51db91;if(_0x3f64e0['repoInfo_']['nodeAdmin'])_0x5b05b3['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x51db91=new tn(tn['OWNER']);else{if(_0x5b05b3['mockUserToken']){const _0x42ff64=typeof _0x5b05b3['mockUserToken']=='string'?_0x5b05b3['mockUserToken']:cc(_0x5b05b3['mockUserToken'],_0x1b4496['app']['options']['projectId']);_0x51db91=new tn(_0x42ff64);}}Wt(_0x4b484a)&&jr(_0x4b484a),Gd(_0x3f64e0,_0x54dd11,_0x5b05b3,_0x51db91);}function C_(_0x22632e){_0x22632e=k(_0x22632e),_0x22632e['_checkNotDeleted']('goOffline'),aa(_0x22632e['_repo']);}function T_(_0x37e799){_0x37e799=k(_0x37e799),_0x37e799['_checkNotDeleted']('goOnline'),Sd(_0x37e799['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x123278){Ll(ct),et(new Me('database',(_0x2275f6,{instanceIdentifier:_0x89e721})=>{const _0x72e6ef=_0x2275f6['getProvider']('app')['getImmediate'](),_0x2f67df=_0x2275f6['getProvider']('auth-internal'),_0x3d0171=_0x2275f6['getProvider']('app-check-internal');return qd(_0x72e6ef,_0x2f67df,_0x3d0171,_0x89e721);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x123278),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x214863,_0x214c5e){this['committed']=_0x214863,this['snapshot']=_0x214c5e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x5805d2,_0x2d2327,_0x224731){if(_0x5805d2=k(_0x5805d2),gs('Reference.transaction',_0x5805d2['_path']),_0x5805d2['key']==='.length'||_0x5805d2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5805d2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2be489=!0x0,_0x202aa8=new Ve(),_0x5e0a32=(_0x87357,_0x2de3da,_0x4955d9)=>{let _0x5d64fe=null;_0x87357?_0x202aa8['reject'](_0x87357):(_0x5d64fe=new rt(_0x4955d9,new Z(_0x5805d2['_repo'],_0x5805d2['_path']),R),_0x202aa8['resolve'](new Xd(_0x2de3da,_0x5d64fe)));},_0x12f81d=Fd(_0x5805d2,()=>{});return bd(_0x5805d2['_repo'],_0x5805d2['_path'],_0x2d2327,_0x5e0a32,_0x12f81d,_0x2be489),_0x202aa8['promise'];}ie['prototype']['simpleListen']=function(_0x5c889b,_0x480da1){this['sendRequest']('q',{'p':_0x5c889b},_0x480da1);},ie['prototype']['echo']=function(_0x1c63eb,_0x567b84){this['sendRequest']('echo',{'d':_0x1c63eb},_0x567b84);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x31fb50,..._0x4e7897){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x31fb50,..._0x4e7897);}function nn(_0x2c17b7,..._0x4fefe9){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2c17b7,..._0x4fefe9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3cf8a2,..._0x357d26){throw Es(_0x3cf8a2,..._0x357d26);}function J(_0x1b0c52,..._0x39b9b1){return Es(_0x1b0c52,..._0x39b9b1);}function ya(_0x43f1e1,_0x6b05ec,_0x385db3){const _0x229e9e={...Zd(),[_0x6b05ec]:_0x385db3};return new Ut('auth','Firebase',_0x229e9e)['create'](_0x6b05ec,{'appName':_0x43f1e1['name']});}function se(_0x277350){return ya(_0x277350,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x43f878,..._0x409f50){if(typeof _0x43f878!='string'){const _0x2fb053=_0x409f50[0x0],_0x3476a5=[..._0x409f50['slice'](0x1)];return _0x3476a5[0x0]&&(_0x3476a5[0x0]['appName']=_0x43f878['name']),_0x43f878['_errorFactory']['create'](_0x2fb053,..._0x3476a5);}return ma['create'](_0x43f878,..._0x409f50);}function m(_0x128318,_0x1d418f,..._0x159294){if(!_0x128318)throw Es(_0x1d418f,..._0x159294);}function te(_0x2e8422){const _0x3bc98a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2e8422;throw nn(_0x3bc98a),new Error(_0x3bc98a);}function ae(_0x576314,_0x1e2d04){_0x576314||te(_0x1e2d04);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x527614;return typeof self<'u'&&((_0x527614=self['location'])==null?void 0x0:_0x527614['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4db873;return typeof self<'u'&&((_0x4db873=self['location'])==null?void 0x0:_0x4db873['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x3e67c9=navigator;return _0x3e67c9['languages']&&_0x3e67c9['languages'][0x0]||_0x3e67c9['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x24e79a,_0x2b5bd7){this['shortDelay']=_0x24e79a,this['longDelay']=_0x2b5bd7,ae(_0x2b5bd7>_0x24e79a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x366a2e,_0xb3c6f3){ae(_0x366a2e['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5b3da7}=_0x366a2e['emulator'];return _0xb3c6f3?''+_0x5b3da7+(_0xb3c6f3['startsWith']('/')?_0xb3c6f3['slice'](0x1):_0xb3c6f3):_0x5b3da7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x44505a,_0xbf95b,_0x576fd7){this['fetchImpl']=_0x44505a,_0xbf95b&&(this['headersImpl']=_0xbf95b),_0x576fd7&&(this['responseImpl']=_0x576fd7);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x5b4a04,_0x5eb140){return _0x5b4a04['tenantId']&&!_0x5eb140['tenantId']?{..._0x5eb140,'tenantId':_0x5b4a04['tenantId']}:_0x5eb140;}async function Ae(_0x482043,_0x497e51,_0x4488e5,_0x34ae80,_0x5c3885={}){return Ea(_0x482043,_0x5c3885,async()=>{let _0x15ab96={},_0x468d04={};_0x34ae80&&(_0x497e51==='GET'?_0x468d04=_0x34ae80:_0x15ab96={'body':JSON['stringify'](_0x34ae80)});const _0x53cc26=at({..._0x468d04,'key':_0x482043['config']['apiKey']})['slice'](0x1),_0x5072a9=await _0x482043['_getAdditionalHeaders']();_0x5072a9['Content-Type']='application/json',_0x482043['languageCode']&&(_0x5072a9['X-Firebase-Locale']=_0x482043['languageCode']);const _0x1cdc3e={'method':_0x497e51,'headers':_0x5072a9,..._0x15ab96};return lc()||(_0x1cdc3e['referrerPolicy']='strict-origin-when-cross-origin'),_0x482043['emulatorConfig']&&Wt(_0x482043['emulatorConfig']['host'])&&(_0x1cdc3e['credentials']='include'),va['fetch']()(await Ia(_0x482043,_0x482043['config']['apiHost'],_0x4488e5,_0x53cc26),_0x1cdc3e);});}async function Ea(_0x2424a1,_0x3bc732,_0x44caf7){_0x2424a1['_canInitEmulator']=!0x1;const _0xde592f={...rf,..._0x3bc732};try{const _0x365ac3=new lf(_0x2424a1),_0x21b287=await Promise['race']([_0x44caf7(),_0x365ac3['promise']]);_0x365ac3['clearNetworkTimeout']();const _0x452b45=await _0x21b287['json']();if('needConfirmation'in _0x452b45)throw en(_0x2424a1,'account-exists-with-different-credential',_0x452b45);if(_0x21b287['ok']&&!('errorMessage'in _0x452b45))return _0x452b45;{const _0x2e77d2=_0x21b287['ok']?_0x452b45['errorMessage']:_0x452b45['error']['message'],[_0x3d2dde,_0x3efb1e]=_0x2e77d2['split']('\x20:\x20');if(_0x3d2dde==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x2424a1,'credential-already-in-use',_0x452b45);if(_0x3d2dde==='EMAIL_EXISTS')throw en(_0x2424a1,'email-already-in-use',_0x452b45);if(_0x3d2dde==='USER_DISABLED')throw en(_0x2424a1,'user-disabled',_0x452b45);const _0x441bab=_0xde592f[_0x3d2dde]||_0x3d2dde['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3efb1e)throw ya(_0x2424a1,_0x441bab,_0x3efb1e);K(_0x2424a1,_0x441bab);}}catch(_0x12c19d){if(_0x12c19d instanceof Se)throw _0x12c19d;K(_0x2424a1,'network-request-failed',{'message':String(_0x12c19d)});}}async function Yt(_0x24fcee,_0xda4ae0,_0x21c840,_0x48466,_0x180a86={}){const _0x29a69f=await Ae(_0x24fcee,_0xda4ae0,_0x21c840,_0x48466,_0x180a86);return'mfaPendingCredential'in _0x29a69f&&K(_0x24fcee,'multi-factor-auth-required',{'_serverResponse':_0x29a69f}),_0x29a69f;}async function Ia(_0x30c8e0,_0x5806c8,_0x1c5f6d,_0x21e4c2){const _0x2c6ae9=''+_0x5806c8+_0x1c5f6d+'?'+_0x21e4c2,_0x877165=_0x30c8e0,_0x4ab2b3=_0x877165['config']['emulator']?Is(_0x30c8e0['config'],_0x2c6ae9):_0x30c8e0['config']['apiScheme']+'://'+_0x2c6ae9;return of['includes'](_0x1c5f6d)&&(await _0x877165['_persistenceManagerAvailable'],_0x877165['_getPersistenceType']()==='COOKIE')?_0x877165['_getPersistence']()['_getFinalTarget'](_0x4ab2b3)['toString']():_0x4ab2b3;}function cf(_0x153216){switch(_0x153216){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2b889a){this['auth']=_0x2b889a,this['timer']=null,this['promise']=new Promise((_0x22ae0c,_0x1b1d1c)=>{this['timer']=setTimeout(()=>_0x1b1d1c(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x551ab8,_0x16f6e9,_0x5d0ba8){const _0xbe4dbc={'appName':_0x551ab8['name']};_0x5d0ba8['email']&&(_0xbe4dbc['email']=_0x5d0ba8['email']),_0x5d0ba8['phoneNumber']&&(_0xbe4dbc['phoneNumber']=_0x5d0ba8['phoneNumber']);const _0x16a092=J(_0x551ab8,_0x16f6e9,_0xbe4dbc);return _0x16a092['customData']['_tokenResponse']=_0x5d0ba8,_0x16a092;}function vr(_0x223333){return _0x223333!==void 0x0&&_0x223333['enterprise']!==void 0x0;}class hf{constructor(_0xa68bbb){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0xa68bbb['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0xa68bbb['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0xa68bbb['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5a83fd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1e2361 of this['recaptchaEnforcementState'])if(_0x1e2361['provider']&&_0x1e2361['provider']===_0x5a83fd)return cf(_0x1e2361['enforcementState']);return null;}['isProviderEnabled'](_0x416329){return this['getProviderEnforcementState'](_0x416329)==='ENFORCE'||this['getProviderEnforcementState'](_0x416329)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x1ffd03,_0x56cabb){return Ae(_0x1ffd03,'GET','/v2/recaptchaConfig',Re(_0x1ffd03,_0x56cabb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x145b1e,_0x40b6cd){return Ae(_0x145b1e,'POST','/v1/accounts:delete',_0x40b6cd);}async function Sn(_0x39b01e,_0x631452){return Ae(_0x39b01e,'POST','/v1/accounts:lookup',_0x631452);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x36881e){if(_0x36881e)try{const _0x3621ab=new Date(Number(_0x36881e));if(!isNaN(_0x3621ab['getTime']()))return _0x3621ab['toUTCString']();}catch{}}async function ff(_0x4228c3,_0x31bef2=!0x1){const _0x248761=k(_0x4228c3),_0x18ba13=await _0x248761['getIdToken'](_0x31bef2),_0x36a724=ws(_0x18ba13);m(_0x36a724&&_0x36a724['exp']&&_0x36a724['auth_time']&&_0x36a724['iat'],_0x248761['auth'],'internal-error');const _0x151773=typeof _0x36a724['firebase']=='object'?_0x36a724['firebase']:void 0x0,_0x3d40a7=_0x151773==null?void 0x0:_0x151773['sign_in_provider'];return{'claims':_0x36a724,'token':_0x18ba13,'authTime':St(ci(_0x36a724['auth_time'])),'issuedAtTime':St(ci(_0x36a724['iat'])),'expirationTime':St(ci(_0x36a724['exp'])),'signInProvider':_0x3d40a7||null,'signInSecondFactor':(_0x151773==null?void 0x0:_0x151773['sign_in_second_factor'])||null};}function ci(_0x202db3){return Number(_0x202db3)*0x3e8;}function ws(_0x5cc91e){const [_0x5e6b2a,_0x497e7a,_0x4d6dbc]=_0x5cc91e['split']('.');if(_0x5e6b2a===void 0x0||_0x497e7a===void 0x0||_0x4d6dbc===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2c66ad=cn(_0x497e7a);return _0x2c66ad?JSON['parse'](_0x2c66ad):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x182b2f){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x182b2f==null?void 0x0:_0x182b2f['toString']()),null;}}function Er(_0x4c38a0){const _0x242ed7=ws(_0x4c38a0);return m(_0x242ed7,'internal-error'),m(typeof _0x242ed7['exp']<'u','internal-error'),m(typeof _0x242ed7['iat']<'u','internal-error'),Number(_0x242ed7['exp'])-Number(_0x242ed7['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x310aa2,_0x37edba,_0x40777d=!0x1){if(_0x40777d)return _0x37edba;try{return await _0x37edba;}catch(_0xacdb0c){throw _0xacdb0c instanceof Se&&pf(_0xacdb0c)&&_0x310aa2['auth']['currentUser']===_0x310aa2&&await _0x310aa2['auth']['signOut'](),_0xacdb0c;}}function pf({code:_0x1159b9}){return _0x1159b9==='auth/user-disabled'||_0x1159b9==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x5eaab9){this['user']=_0x5eaab9,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x18699e){if(_0x18699e){const _0x468fe0=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x468fe0;}else{this['errorBackoff']=0x7530;const _0x5b561f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5b561f);}}['schedule'](_0x1b9ded=!0x1){if(!this['isRunning'])return;const _0x5608ca=this['getInterval'](_0x1b9ded);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5608ca);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3099e1){(_0x3099e1==null?void 0x0:_0x3099e1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4ba240,_0x1a6a4c){this['createdAt']=_0x4ba240,this['lastLoginAt']=_0x1a6a4c,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x2b2e46){this['createdAt']=_0x2b2e46['createdAt'],this['lastLoginAt']=_0x2b2e46['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5ea199){var _0x1c1101;const _0x3b99bf=_0x5ea199['auth'],_0x57d5ce=await _0x5ea199['getIdToken'](),_0x167d44=await xt(_0x5ea199,Sn(_0x3b99bf,{'idToken':_0x57d5ce}));m(_0x167d44==null?void 0x0:_0x167d44['users']['length'],_0x3b99bf,'internal-error');const _0x2c2b1a=_0x167d44['users'][0x0];_0x5ea199['_notifyReloadListener'](_0x2c2b1a);const _0x489344=(_0x1c1101=_0x2c2b1a['providerUserInfo'])!=null&&_0x1c1101['length']?wa(_0x2c2b1a['providerUserInfo']):[],_0x1ddd0e=mf(_0x5ea199['providerData'],_0x489344),_0x6c7e4a=_0x5ea199['isAnonymous'],_0x1c8ab7=!(_0x5ea199['email']&&_0x2c2b1a['passwordHash'])&&!(_0x1ddd0e!=null&&_0x1ddd0e['length']),_0x529daf=_0x6c7e4a?_0x1c8ab7:!0x1,_0x29ef60={'uid':_0x2c2b1a['localId'],'displayName':_0x2c2b1a['displayName']||null,'photoURL':_0x2c2b1a['photoUrl']||null,'email':_0x2c2b1a['email']||null,'emailVerified':_0x2c2b1a['emailVerified']||!0x1,'phoneNumber':_0x2c2b1a['phoneNumber']||null,'tenantId':_0x2c2b1a['tenantId']||null,'providerData':_0x1ddd0e,'metadata':new Pi(_0x2c2b1a['createdAt'],_0x2c2b1a['lastLoginAt']),'isAnonymous':_0x529daf};Object['assign'](_0x5ea199,_0x29ef60);}async function gf(_0x281aec){const _0x505eb3=k(_0x281aec);await bn(_0x505eb3),await _0x505eb3['auth']['_persistUserIfCurrent'](_0x505eb3),_0x505eb3['auth']['_notifyListenersIfCurrent'](_0x505eb3);}function mf(_0xe00bca,_0x2cc999){return[..._0xe00bca['filter'](_0x4e50ae=>!_0x2cc999['some'](_0x160e08=>_0x160e08['providerId']===_0x4e50ae['providerId'])),..._0x2cc999];}function wa(_0x3e835a){return _0x3e835a['map'](({providerId:_0xa58e16,..._0x3381cf})=>({'providerId':_0xa58e16,'uid':_0x3381cf['rawId']||'','displayName':_0x3381cf['displayName']||null,'email':_0x3381cf['email']||null,'phoneNumber':_0x3381cf['phoneNumber']||null,'photoURL':_0x3381cf['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x4edc54,_0x2f8d5f){const _0x4483af=await Ea(_0x4edc54,{},async()=>{const _0x21125d=at({'grant_type':'refresh_token','refresh_token':_0x2f8d5f})['slice'](0x1),{tokenApiHost:_0x2eb5ac,apiKey:_0x116add}=_0x4edc54['config'],_0x167c90=await Ia(_0x4edc54,_0x2eb5ac,'/v1/token','key='+_0x116add),_0xdb6d6=await _0x4edc54['_getAdditionalHeaders']();_0xdb6d6['Content-Type']='application/x-www-form-urlencoded';const _0x4a9d0b={'method':'POST','headers':_0xdb6d6,'body':_0x21125d};return _0x4edc54['emulatorConfig']&&Wt(_0x4edc54['emulatorConfig']['host'])&&(_0x4a9d0b['credentials']='include'),va['fetch']()(_0x167c90,_0x4a9d0b);});return{'accessToken':_0x4483af['access_token'],'expiresIn':_0x4483af['expires_in'],'refreshToken':_0x4483af['refresh_token']};}async function vf(_0xc418de,_0x1e97a5){return Ae(_0xc418de,'POST','/v2/accounts:revokeToken',Re(_0xc418de,_0x1e97a5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x51df64){m(_0x51df64['idToken'],'internal-error'),m(typeof _0x51df64['idToken']<'u','internal-error'),m(typeof _0x51df64['refreshToken']<'u','internal-error');const _0x4e675c='expiresIn'in _0x51df64&&typeof _0x51df64['expiresIn']<'u'?Number(_0x51df64['expiresIn']):Er(_0x51df64['idToken']);this['updateTokensAndExpiration'](_0x51df64['idToken'],_0x51df64['refreshToken'],_0x4e675c);}['updateFromIdToken'](_0x19f7e9){m(_0x19f7e9['length']!==0x0,'internal-error');const _0x4456e0=Er(_0x19f7e9);this['updateTokensAndExpiration'](_0x19f7e9,null,_0x4456e0);}async['getToken'](_0xce62b2,_0x882803=!0x1){return!_0x882803&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xce62b2,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xce62b2,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5853da,_0x323e6d){const {accessToken:_0x56c242,refreshToken:_0x33df09,expiresIn:_0x48842e}=await yf(_0x5853da,_0x323e6d);this['updateTokensAndExpiration'](_0x56c242,_0x33df09,Number(_0x48842e));}['updateTokensAndExpiration'](_0x22177b,_0x87f14a,_0x23610c){this['refreshToken']=_0x87f14a||null,this['accessToken']=_0x22177b||null,this['expirationTime']=Date['now']()+_0x23610c*0x3e8;}static['fromJSON'](_0x35bd69,_0xc9e87a){const {refreshToken:_0x5835a1,accessToken:_0x42c5d4,expirationTime:_0xb0dd68}=_0xc9e87a,_0x6fc444=new Je();return _0x5835a1&&(m(typeof _0x5835a1=='string','internal-error',{'appName':_0x35bd69}),_0x6fc444['refreshToken']=_0x5835a1),_0x42c5d4&&(m(typeof _0x42c5d4=='string','internal-error',{'appName':_0x35bd69}),_0x6fc444['accessToken']=_0x42c5d4),_0xb0dd68&&(m(typeof _0xb0dd68=='number','internal-error',{'appName':_0x35bd69}),_0x6fc444['expirationTime']=_0xb0dd68),_0x6fc444;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x41502d){this['accessToken']=_0x41502d['accessToken'],this['refreshToken']=_0x41502d['refreshToken'],this['expirationTime']=_0x41502d['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x30ba96,_0x226363){m(typeof _0x30ba96=='string'||typeof _0x30ba96>'u','internal-error',{'appName':_0x226363});}class z{constructor({uid:_0x181859,auth:_0x3fd86c,stsTokenManager:_0x2bb2d7,..._0x3bba49}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x181859,this['auth']=_0x3fd86c,this['stsTokenManager']=_0x2bb2d7,this['accessToken']=_0x2bb2d7['accessToken'],this['displayName']=_0x3bba49['displayName']||null,this['email']=_0x3bba49['email']||null,this['emailVerified']=_0x3bba49['emailVerified']||!0x1,this['phoneNumber']=_0x3bba49['phoneNumber']||null,this['photoURL']=_0x3bba49['photoURL']||null,this['isAnonymous']=_0x3bba49['isAnonymous']||!0x1,this['tenantId']=_0x3bba49['tenantId']||null,this['providerData']=_0x3bba49['providerData']?[..._0x3bba49['providerData']]:[],this['metadata']=new Pi(_0x3bba49['createdAt']||void 0x0,_0x3bba49['lastLoginAt']||void 0x0);}async['getIdToken'](_0x373226){const _0x4d1186=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x373226));return m(_0x4d1186,this['auth'],'internal-error'),this['accessToken']!==_0x4d1186&&(this['accessToken']=_0x4d1186,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4d1186;}['getIdTokenResult'](_0x3aa0e4){return ff(this,_0x3aa0e4);}['reload'](){return gf(this);}['_assign'](_0x4fd4e9){this!==_0x4fd4e9&&(m(this['uid']===_0x4fd4e9['uid'],this['auth'],'internal-error'),this['displayName']=_0x4fd4e9['displayName'],this['photoURL']=_0x4fd4e9['photoURL'],this['email']=_0x4fd4e9['email'],this['emailVerified']=_0x4fd4e9['emailVerified'],this['phoneNumber']=_0x4fd4e9['phoneNumber'],this['isAnonymous']=_0x4fd4e9['isAnonymous'],this['tenantId']=_0x4fd4e9['tenantId'],this['providerData']=_0x4fd4e9['providerData']['map'](_0x71e5df=>({..._0x71e5df})),this['metadata']['_copy'](_0x4fd4e9['metadata']),this['stsTokenManager']['_assign'](_0x4fd4e9['stsTokenManager']));}['_clone'](_0x3d66c2){const _0x4016e8=new z({...this,'auth':_0x3d66c2,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4016e8['metadata']['_copy'](this['metadata']),_0x4016e8;}['_onReload'](_0x395486){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x395486,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x22fe6c){this['reloadListener']?this['reloadListener'](_0x22fe6c):this['reloadUserInfo']=_0x22fe6c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x16a10e,_0x52fd66=!0x1){let _0x110156=!0x1;_0x16a10e['idToken']&&_0x16a10e['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x16a10e),_0x110156=!0x0),_0x52fd66&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x110156&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x57bd47=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x57bd47})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x345689=>({..._0x345689})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x592cd1,_0x1d593b){const _0x44baa9=_0x1d593b['displayName']??void 0x0,_0x2fcd3e=_0x1d593b['email']??void 0x0,_0x4f0173=_0x1d593b['phoneNumber']??void 0x0,_0x4c1e86=_0x1d593b['photoURL']??void 0x0,_0x386abf=_0x1d593b['tenantId']??void 0x0,_0x44a031=_0x1d593b['_redirectEventId']??void 0x0,_0x13088b=_0x1d593b['createdAt']??void 0x0,_0x583ff8=_0x1d593b['lastLoginAt']??void 0x0,{uid:_0xbbc755,emailVerified:_0x489374,isAnonymous:_0x55b369,providerData:_0xf5ae7b,stsTokenManager:_0x31af9d}=_0x1d593b;m(_0xbbc755&&_0x31af9d,_0x592cd1,'internal-error');const _0x22cb12=Je['fromJSON'](this['name'],_0x31af9d);m(typeof _0xbbc755=='string',_0x592cd1,'internal-error'),ce(_0x44baa9,_0x592cd1['name']),ce(_0x2fcd3e,_0x592cd1['name']),m(typeof _0x489374=='boolean',_0x592cd1,'internal-error'),m(typeof _0x55b369=='boolean',_0x592cd1,'internal-error'),ce(_0x4f0173,_0x592cd1['name']),ce(_0x4c1e86,_0x592cd1['name']),ce(_0x386abf,_0x592cd1['name']),ce(_0x44a031,_0x592cd1['name']),ce(_0x13088b,_0x592cd1['name']),ce(_0x583ff8,_0x592cd1['name']);const _0x135cce=new z({'uid':_0xbbc755,'auth':_0x592cd1,'email':_0x2fcd3e,'emailVerified':_0x489374,'displayName':_0x44baa9,'isAnonymous':_0x55b369,'photoURL':_0x4c1e86,'phoneNumber':_0x4f0173,'tenantId':_0x386abf,'stsTokenManager':_0x22cb12,'createdAt':_0x13088b,'lastLoginAt':_0x583ff8});return _0xf5ae7b&&Array['isArray'](_0xf5ae7b)&&(_0x135cce['providerData']=_0xf5ae7b['map'](_0xf77981=>({..._0xf77981}))),_0x44a031&&(_0x135cce['_redirectEventId']=_0x44a031),_0x135cce;}static async['_fromIdTokenResponse'](_0x4cb77c,_0x2e251f,_0x2001a2=!0x1){const _0x3d4ff5=new Je();_0x3d4ff5['updateFromServerResponse'](_0x2e251f);const _0x1803af=new z({'uid':_0x2e251f['localId'],'auth':_0x4cb77c,'stsTokenManager':_0x3d4ff5,'isAnonymous':_0x2001a2});return await bn(_0x1803af),_0x1803af;}static async['_fromGetAccountInfoResponse'](_0x5b5ec5,_0x1a4933,_0x1d9737){const _0x320272=_0x1a4933['users'][0x0];m(_0x320272['localId']!==void 0x0,'internal-error');const _0x3b1da8=_0x320272['providerUserInfo']!==void 0x0?wa(_0x320272['providerUserInfo']):[],_0x4b7da1=!(_0x320272['email']&&_0x320272['passwordHash'])&&!(_0x3b1da8!=null&&_0x3b1da8['length']),_0x211f62=new Je();_0x211f62['updateFromIdToken'](_0x1d9737);const _0x1d6084=new z({'uid':_0x320272['localId'],'auth':_0x5b5ec5,'stsTokenManager':_0x211f62,'isAnonymous':_0x4b7da1}),_0x47e9cd={'uid':_0x320272['localId'],'displayName':_0x320272['displayName']||null,'photoURL':_0x320272['photoUrl']||null,'email':_0x320272['email']||null,'emailVerified':_0x320272['emailVerified']||!0x1,'phoneNumber':_0x320272['phoneNumber']||null,'tenantId':_0x320272['tenantId']||null,'providerData':_0x3b1da8,'metadata':new Pi(_0x320272['createdAt'],_0x320272['lastLoginAt']),'isAnonymous':!(_0x320272['email']&&_0x320272['passwordHash'])&&!(_0x3b1da8!=null&&_0x3b1da8['length'])};return Object['assign'](_0x1d6084,_0x47e9cd),_0x1d6084;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x471182){ae(_0x471182 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1f363c=Ir['get'](_0x471182);return _0x1f363c?(ae(_0x1f363c instanceof _0x471182,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1f363c):(_0x1f363c=new _0x471182(),Ir['set'](_0x471182,_0x1f363c),_0x1f363c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1e14d1,_0x11c75f){this['storage'][_0x1e14d1]=_0x11c75f;}async['_get'](_0x1841af){const _0x16de7e=this['storage'][_0x1841af];return _0x16de7e===void 0x0?null:_0x16de7e;}async['_remove'](_0xa47681){delete this['storage'][_0xa47681];}['_addListener'](_0x524177,_0x1b679c){}['_removeListener'](_0x4c4d0c,_0x45f31c){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x48de23,_0x43775c,_0x8dd45e){return'firebase:'+_0x48de23+':'+_0x43775c+':'+_0x8dd45e;}class Xe{constructor(_0x19d9c9,_0xbf5ec6,_0x5b704a){this['persistence']=_0x19d9c9,this['auth']=_0xbf5ec6,this['userKey']=_0x5b704a;const {config:_0x5b578b,name:_0x476ac0}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x5b578b['apiKey'],_0x476ac0),this['fullPersistenceKey']=sn('persistence',_0x5b578b['apiKey'],_0x476ac0),this['boundEventHandler']=_0xbf5ec6['_onStorageEvent']['bind'](_0xbf5ec6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xa0366d){return this['persistence']['_set'](this['fullUserKey'],_0xa0366d['toJSON']());}async['getCurrentUser'](){const _0x2554d2=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2554d2)return null;if(typeof _0x2554d2=='string'){const _0x43d725=await Sn(this['auth'],{'idToken':_0x2554d2})['catch'](()=>{});return _0x43d725?z['_fromGetAccountInfoResponse'](this['auth'],_0x43d725,_0x2554d2):null;}return z['_fromJSON'](this['auth'],_0x2554d2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0xbf4c5d){if(this['persistence']===_0xbf4c5d)return;const _0x3c22b9=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0xbf4c5d,_0x3c22b9)return this['setCurrentUser'](_0x3c22b9);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3532bb,_0x570069,_0x14d9ed='authUser'){if(!_0x570069['length'])return new Xe(ne(wr),_0x3532bb,_0x14d9ed);const _0x30c94e=(await Promise['all'](_0x570069['map'](async _0x2103f0=>{if(await _0x2103f0['_isAvailable']())return _0x2103f0;})))['filter'](_0x4735cc=>_0x4735cc);let _0x143d08=_0x30c94e[0x0]||ne(wr);const _0x3fae0d=sn(_0x14d9ed,_0x3532bb['config']['apiKey'],_0x3532bb['name']);let _0x547cd8=null;for(const _0x31f118 of _0x570069)try{const _0x188447=await _0x31f118['_get'](_0x3fae0d);if(_0x188447){let _0x22e400;if(typeof _0x188447=='string'){const _0x480d15=await Sn(_0x3532bb,{'idToken':_0x188447})['catch'](()=>{});if(!_0x480d15)break;_0x22e400=await z['_fromGetAccountInfoResponse'](_0x3532bb,_0x480d15,_0x188447);}else _0x22e400=z['_fromJSON'](_0x3532bb,_0x188447);_0x31f118!==_0x143d08&&(_0x547cd8=_0x22e400),_0x143d08=_0x31f118;break;}}catch{}const _0x52e488=_0x30c94e['filter'](_0x2cd15e=>_0x2cd15e['_shouldAllowMigration']);return!_0x143d08['_shouldAllowMigration']||!_0x52e488['length']?new Xe(_0x143d08,_0x3532bb,_0x14d9ed):(_0x143d08=_0x52e488[0x0],_0x547cd8&&await _0x143d08['_set'](_0x3fae0d,_0x547cd8['toJSON']()),await Promise['all'](_0x570069['map'](async _0x5aa4ba=>{if(_0x5aa4ba!==_0x143d08)try{await _0x5aa4ba['_remove'](_0x3fae0d);}catch{}})),new Xe(_0x143d08,_0x3532bb,_0x14d9ed));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x12c2f8){const _0x4eee25=_0x12c2f8['toLowerCase']();if(_0x4eee25['includes']('opera/')||_0x4eee25['includes']('opr/')||_0x4eee25['includes']('opios/'))return'Opera';if(Ra(_0x4eee25))return'IEMobile';if(_0x4eee25['includes']('msie')||_0x4eee25['includes']('trident/'))return'IE';if(_0x4eee25['includes']('edge/'))return'Edge';if(Ta(_0x4eee25))return'Firefox';if(_0x4eee25['includes']('silk/'))return'Silk';if(ka(_0x4eee25))return'Blackberry';if(Na(_0x4eee25))return'Webos';if(Sa(_0x4eee25))return'Safari';if((_0x4eee25['includes']('chrome/')||ba(_0x4eee25))&&!_0x4eee25['includes']('edge/'))return'Chrome';if(Aa(_0x4eee25))return'Android';{const _0x3b9b91=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5ea816=_0x12c2f8['match'](_0x3b9b91);if((_0x5ea816==null?void 0x0:_0x5ea816['length'])===0x2)return _0x5ea816[0x1];}return'Other';}function Ta(_0x3ba624=W()){return/firefox\//i['test'](_0x3ba624);}function Sa(_0x3d737b=W()){const _0x32e54c=_0x3d737b['toLowerCase']();return _0x32e54c['includes']('safari/')&&!_0x32e54c['includes']('chrome/')&&!_0x32e54c['includes']('crios/')&&!_0x32e54c['includes']('android');}function ba(_0x2169b3=W()){return/crios\//i['test'](_0x2169b3);}function Ra(_0x3f5b03=W()){return/iemobile/i['test'](_0x3f5b03);}function Aa(_0x2b21db=W()){return/android/i['test'](_0x2b21db);}function ka(_0x35ecd1=W()){return/blackberry/i['test'](_0x35ecd1);}function Na(_0x24c519=W()){return/webos/i['test'](_0x24c519);}function Cs(_0x3b4c65=W()){return/iphone|ipad|ipod/i['test'](_0x3b4c65)||/macintosh/i['test'](_0x3b4c65)&&/mobile/i['test'](_0x3b4c65);}function Ef(_0xd07315=W()){var _0x44cc40;return Cs(_0xd07315)&&!!((_0x44cc40=window['navigator'])!=null&&_0x44cc40['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2d0171=W()){return Cs(_0x2d0171)||Aa(_0x2d0171)||Na(_0x2d0171)||ka(_0x2d0171)||/windows phone/i['test'](_0x2d0171)||Ra(_0x2d0171);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x2060d9,_0xd97512=[]){let _0x14e801;switch(_0x2060d9){case'Browser':_0x14e801=Cr(W());break;case'Worker':_0x14e801=Cr(W())+'-'+_0x2060d9;break;default:_0x14e801=_0x2060d9;}const _0x399854=_0xd97512['length']?_0xd97512['join'](','):'FirebaseCore-web';return _0x14e801+'/JsCore/'+ct+'/'+_0x399854;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x18aa40){this['auth']=_0x18aa40,this['queue']=[];}['pushCallback'](_0x165cee,_0x42a8fa){const _0x6e22b6=_0x218a74=>new Promise((_0x1e2186,_0x5b5003)=>{try{const _0x302b7c=_0x165cee(_0x218a74);_0x1e2186(_0x302b7c);}catch(_0x59778c){_0x5b5003(_0x59778c);}});_0x6e22b6['onAbort']=_0x42a8fa,this['queue']['push'](_0x6e22b6);const _0xa65d6b=this['queue']['length']-0x1;return()=>{this['queue'][_0xa65d6b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4dc811){if(this['auth']['currentUser']===_0x4dc811)return;const _0x25b0cd=[];try{for(const _0x57464e of this['queue'])await _0x57464e(_0x4dc811),_0x57464e['onAbort']&&_0x25b0cd['push'](_0x57464e['onAbort']);}catch(_0x4bfa35){_0x25b0cd['reverse']();for(const _0x4f30f0 of _0x25b0cd)try{_0x4f30f0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4bfa35==null?void 0x0:_0x4bfa35['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x82b3a3,_0x2c7d82={}){return Ae(_0x82b3a3,'GET','/v2/passwordPolicy',Re(_0x82b3a3,_0x2c7d82));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x5da1c0){var _0x53ae83;const _0x1e077c=_0x5da1c0['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1e077c['minPasswordLength']??Tf,_0x1e077c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1e077c['maxPasswordLength']),_0x1e077c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1e077c['containsLowercaseCharacter']),_0x1e077c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1e077c['containsUppercaseCharacter']),_0x1e077c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1e077c['containsNumericCharacter']),_0x1e077c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1e077c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5da1c0['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x53ae83=_0x5da1c0['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x53ae83['join'](''))??'',this['forceUpgradeOnSignin']=_0x5da1c0['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5da1c0['schemaVersion'];}['validatePassword'](_0x57e527){const _0x3ac1c4={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x57e527,_0x3ac1c4),this['validatePasswordCharacterOptions'](_0x57e527,_0x3ac1c4),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['meetsMinPasswordLength']??!0x0),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['meetsMaxPasswordLength']??!0x0),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['containsLowercaseLetter']??!0x0),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['containsUppercaseLetter']??!0x0),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['containsNumericCharacter']??!0x0),_0x3ac1c4['isValid']&&(_0x3ac1c4['isValid']=_0x3ac1c4['containsNonAlphanumericCharacter']??!0x0),_0x3ac1c4;}['validatePasswordLengthOptions'](_0x3395ea,_0x4bc01c){const _0x6e21e5=this['customStrengthOptions']['minPasswordLength'],_0x5151e9=this['customStrengthOptions']['maxPasswordLength'];_0x6e21e5&&(_0x4bc01c['meetsMinPasswordLength']=_0x3395ea['length']>=_0x6e21e5),_0x5151e9&&(_0x4bc01c['meetsMaxPasswordLength']=_0x3395ea['length']<=_0x5151e9);}['validatePasswordCharacterOptions'](_0x40fb3c,_0x58e5d5){this['updatePasswordCharacterOptionsStatuses'](_0x58e5d5,!0x1,!0x1,!0x1,!0x1);let _0xd2f323;for(let _0x65c01=0x0;_0x65c01<_0x40fb3c['length'];_0x65c01++)_0xd2f323=_0x40fb3c['charAt'](_0x65c01),this['updatePasswordCharacterOptionsStatuses'](_0x58e5d5,_0xd2f323>='a'&&_0xd2f323<='z',_0xd2f323>='A'&&_0xd2f323<='Z',_0xd2f323>='0'&&_0xd2f323<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xd2f323));}['updatePasswordCharacterOptionsStatuses'](_0x4dcbe1,_0x1ad10f,_0x2090ea,_0xdbe6a,_0x403b8e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4dcbe1['containsLowercaseLetter']||(_0x4dcbe1['containsLowercaseLetter']=_0x1ad10f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4dcbe1['containsUppercaseLetter']||(_0x4dcbe1['containsUppercaseLetter']=_0x2090ea)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4dcbe1['containsNumericCharacter']||(_0x4dcbe1['containsNumericCharacter']=_0xdbe6a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4dcbe1['containsNonAlphanumericCharacter']||(_0x4dcbe1['containsNonAlphanumericCharacter']=_0x403b8e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x837e64,_0x193354,_0x3ba8ef,_0x34de3e){this['app']=_0x837e64,this['heartbeatServiceProvider']=_0x193354,this['appCheckServiceProvider']=_0x3ba8ef,this['config']=_0x34de3e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x837e64['name'],this['clientVersion']=_0x34de3e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x430e31=>this['_resolvePersistenceManagerAvailable']=_0x430e31);}['_initializeWithPersistence'](_0x1ce015,_0x3b4916){return _0x3b4916&&(this['_popupRedirectResolver']=ne(_0x3b4916)),this['_initializationPromise']=this['queue'](async()=>{var _0x32cc88,_0x16d43c,_0x3108eb;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x1ce015),(_0x32cc88=this['_resolvePersistenceManagerAvailable'])==null||_0x32cc88['call'](this),!this['_deleted'])){if((_0x16d43c=this['_popupRedirectResolver'])!=null&&_0x16d43c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3b4916),this['lastNotifiedUid']=((_0x3108eb=this['currentUser'])==null?void 0x0:_0x3108eb['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x541e2d=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x541e2d)){if(this['currentUser']&&_0x541e2d&&this['currentUser']['uid']===_0x541e2d['uid']){this['_currentUser']['_assign'](_0x541e2d),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x541e2d,!0x0);}}async['initializeCurrentUserFromIdToken'](_0xa6afe0){try{const _0x38755e=await Sn(this,{'idToken':_0xa6afe0}),_0x18118f=await z['_fromGetAccountInfoResponse'](this,_0x38755e,_0xa6afe0);await this['directlySetCurrentUser'](_0x18118f);}catch(_0x2221a3){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2221a3),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xdf5248){var _0x16760f;if(H(this['app'])){const _0x64385d=this['app']['settings']['authIdToken'];return _0x64385d?new Promise(_0xab723=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x64385d)['then'](_0xab723,_0xab723));}):this['directlySetCurrentUser'](null);}const _0x44d4e4=await this['assertedPersistence']['getCurrentUser']();let _0x4b85f5=_0x44d4e4,_0x18f162=!0x1;if(_0xdf5248&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x413848=(_0x16760f=this['redirectUser'])==null?void 0x0:_0x16760f['_redirectEventId'],_0x5ac590=_0x4b85f5==null?void 0x0:_0x4b85f5['_redirectEventId'],_0x1716c7=await this['tryRedirectSignIn'](_0xdf5248);(!_0x413848||_0x413848===_0x5ac590)&&(_0x1716c7!=null&&_0x1716c7['user'])&&(_0x4b85f5=_0x1716c7['user'],_0x18f162=!0x0);}if(!_0x4b85f5)return this['directlySetCurrentUser'](null);if(!_0x4b85f5['_redirectEventId']){if(_0x18f162)try{await this['beforeStateQueue']['runMiddleware'](_0x4b85f5);}catch(_0xb195a5){_0x4b85f5=_0x44d4e4,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xb195a5));}return _0x4b85f5?this['reloadAndSetCurrentUserOrClear'](_0x4b85f5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4b85f5['_redirectEventId']?this['directlySetCurrentUser'](_0x4b85f5):this['reloadAndSetCurrentUserOrClear'](_0x4b85f5);}async['tryRedirectSignIn'](_0x4c79c1){let _0x380da4=null;try{_0x380da4=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4c79c1,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x380da4;}async['reloadAndSetCurrentUserOrClear'](_0x1385dc){try{await bn(_0x1385dc);}catch(_0x4e4d2e){if((_0x4e4d2e==null?void 0x0:_0x4e4d2e['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1385dc);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x569662){if(H(this['app']))return Promise['reject'](se(this));const _0x520a62=_0x569662?k(_0x569662):null;return _0x520a62&&m(_0x520a62['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x520a62&&_0x520a62['_clone'](this));}async['_updateCurrentUser'](_0x1f7ade,_0xbc9039=!0x1){if(!this['_deleted'])return _0x1f7ade&&m(this['tenantId']===_0x1f7ade['tenantId'],this,'tenant-id-mismatch'),_0xbc9039||await this['beforeStateQueue']['runMiddleware'](_0x1f7ade),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1f7ade),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x131bf4){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x131bf4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2c08fa){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x55aba6=this['_getPasswordPolicyInternal']();return _0x55aba6['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x55aba6['validatePassword'](_0x2c08fa);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x45a874=await Cf(this),_0x2733e5=new Sf(_0x45a874);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2733e5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2733e5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x430b84){this['_errorFactory']=new Ut('auth','Firebase',_0x430b84());}['onAuthStateChanged'](_0x450127,_0x5eba98,_0x291a9e){return this['registerStateListener'](this['authStateSubscription'],_0x450127,_0x5eba98,_0x291a9e);}['beforeAuthStateChanged'](_0x5a47f2,_0x45f700){return this['beforeStateQueue']['pushCallback'](_0x5a47f2,_0x45f700);}['onIdTokenChanged'](_0x17b7a9,_0x44b6a1,_0x37c016){return this['registerStateListener'](this['idTokenSubscription'],_0x17b7a9,_0x44b6a1,_0x37c016);}['authStateReady'](){return new Promise((_0x3d5cec,_0x9621b4)=>{if(this['currentUser'])_0x3d5cec();else{const _0x5e968f=this['onAuthStateChanged'](()=>{_0x5e968f(),_0x3d5cec();},_0x9621b4);}});}async['revokeAccessToken'](_0xb35ba5){if(this['currentUser']){const _0x47c3c3=await this['currentUser']['getIdToken'](),_0x5173e2={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0xb35ba5,'idToken':_0x47c3c3};this['tenantId']!=null&&(_0x5173e2['tenantId']=this['tenantId']),await vf(this,_0x5173e2);}}['toJSON'](){var _0x96ae14;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x96ae14=this['_currentUser'])==null?void 0x0:_0x96ae14['toJSON']()};}async['_setRedirectUser'](_0x57cd4f,_0x299ce8){const _0xe2bb4e=await this['getOrInitRedirectPersistenceManager'](_0x299ce8);return _0x57cd4f===null?_0xe2bb4e['removeCurrentUser']():_0xe2bb4e['setCurrentUser'](_0x57cd4f);}async['getOrInitRedirectPersistenceManager'](_0x3503b9){if(!this['redirectPersistenceManager']){const _0x41abff=_0x3503b9&&ne(_0x3503b9)||this['_popupRedirectResolver'];m(_0x41abff,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x41abff['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xf4e035){var _0x61c6b6,_0x116784;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x61c6b6=this['_currentUser'])==null?void 0x0:_0x61c6b6['_redirectEventId'])===_0xf4e035?this['_currentUser']:((_0x116784=this['redirectUser'])==null?void 0x0:_0x116784['_redirectEventId'])===_0xf4e035?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1aa61a){if(_0x1aa61a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1aa61a));}['_notifyListenersIfCurrent'](_0x3827a2){_0x3827a2===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x14abf0;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x36ee0c=((_0x14abf0=this['currentUser'])==null?void 0x0:_0x14abf0['uid'])??null;this['lastNotifiedUid']!==_0x36ee0c&&(this['lastNotifiedUid']=_0x36ee0c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x532d8b,_0x7ebd10,_0x2f9637,_0x407c7d){if(this['_deleted'])return()=>{};const _0x3781c5=typeof _0x7ebd10=='function'?_0x7ebd10:_0x7ebd10['next']['bind'](_0x7ebd10);let _0x17e7b6=!0x1;const _0x206678=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x206678,this,'internal-error'),_0x206678['then'](()=>{_0x17e7b6||_0x3781c5(this['currentUser']);}),typeof _0x7ebd10=='function'){const _0xdef54c=_0x532d8b['addObserver'](_0x7ebd10,_0x2f9637,_0x407c7d);return()=>{_0x17e7b6=!0x0,_0xdef54c();};}else{const _0xb1a8a9=_0x532d8b['addObserver'](_0x7ebd10);return()=>{_0x17e7b6=!0x0,_0xb1a8a9();};}}async['directlySetCurrentUser'](_0x410ae1){this['currentUser']&&this['currentUser']!==_0x410ae1&&this['_currentUser']['_stopProactiveRefresh'](),_0x410ae1&&this['isProactiveRefreshEnabled']&&_0x410ae1['_startProactiveRefresh'](),this['currentUser']=_0x410ae1,_0x410ae1?await this['assertedPersistence']['setCurrentUser'](_0x410ae1):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5e3441){return this['operations']=this['operations']['then'](_0x5e3441,_0x5e3441),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4dd3f3){!_0x4dd3f3||this['frameworks']['includes'](_0x4dd3f3)||(this['frameworks']['push'](_0x4dd3f3),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x244d5c;const _0x4f95a2={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4f95a2['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x126415=await((_0x244d5c=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x244d5c['getHeartbeatsHeader']());_0x126415&&(_0x4f95a2['X-Firebase-Client']=_0x126415);const _0x3d3d07=await this['_getAppCheckToken']();return _0x3d3d07&&(_0x4f95a2['X-Firebase-AppCheck']=_0x3d3d07),_0x4f95a2;}async['_getAppCheckToken'](){var _0x4ca6b9;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x35d576=await((_0x4ca6b9=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4ca6b9['getToken']());return _0x35d576!=null&&_0x35d576['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x35d576['error']),_0x35d576==null?void 0x0:_0x35d576['token'];}}function qe(_0x3c8094){return k(_0x3c8094);}class Tr{constructor(_0x71c389){this['auth']=_0x71c389,this['observer']=null,this['addObserver']=Ic(_0x46e552=>this['observer']=_0x46e552);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x11483d){zn=_0x11483d;}function Da(_0x433430){return zn['loadJS'](_0x433430);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x34f782){return'__'+_0x34f782+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x410149){_0x410149();}['execute'](_0x5f0262,_0x536ad9){return Promise['resolve']('token');}['render'](_0x503e20,_0x3c3f50){return'';}}class Of{['ready'](_0x39a3b7){_0x39a3b7();}['execute'](_0x5bf41c,_0x20623c){return Promise['resolve']('token');}['render'](_0x2150a3,_0x5e0d80){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3fa128){this['type']=Df,this['auth']=qe(_0x3fa128);}async['verify'](_0xb45462='verify',_0x2ed1ba=!0x1){async function _0x20ebae(_0x2ecb70){if(!_0x2ed1ba){if(_0x2ecb70['tenantId']==null&&_0x2ecb70['_agentRecaptchaConfig']!=null)return _0x2ecb70['_agentRecaptchaConfig']['siteKey'];if(_0x2ecb70['tenantId']!=null&&_0x2ecb70['_tenantRecaptchaConfigs'][_0x2ecb70['tenantId']]!==void 0x0)return _0x2ecb70['_tenantRecaptchaConfigs'][_0x2ecb70['tenantId']]['siteKey'];}return new Promise(async(_0x16c5da,_0xa37704)=>{uf(_0x2ecb70,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x29f220=>{if(_0x29f220['recaptchaKey']===void 0x0)_0xa37704(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xf4af67=new hf(_0x29f220);return _0x2ecb70['tenantId']==null?_0x2ecb70['_agentRecaptchaConfig']=_0xf4af67:_0x2ecb70['_tenantRecaptchaConfigs'][_0x2ecb70['tenantId']]=_0xf4af67,_0x16c5da(_0xf4af67['siteKey']);}})['catch'](_0x36a2bc=>{_0xa37704(_0x36a2bc);});});}function _0x144e74(_0x4d01e8,_0x2fc464,_0x89388b){const _0xe08d25=window['grecaptcha'];vr(_0xe08d25)?_0xe08d25['enterprise']['ready'](()=>{_0xe08d25['enterprise']['execute'](_0x4d01e8,{'action':_0xb45462})['then'](_0x372021=>{_0x2fc464(_0x372021);})['catch'](()=>{_0x2fc464(Ma);});}):_0x89388b(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x570e51,_0x1c43e8)=>{_0x20ebae(this['auth'])['then'](async _0x3afa5f=>{if(!_0x2ed1ba&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x144e74(_0x3afa5f,_0x570e51,_0x1c43e8);else{if(typeof window>'u'){_0x1c43e8(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x20c57a=Af();_0x20c57a['length']!==0x0&&(_0x20c57a+=_0x3afa5f+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x367c52;(_0x367c52=le['scriptInjectionDeferred'])==null||_0x367c52['resolve']();},Da(_0x20c57a)['then'](()=>{var _0x3fedfe;return(_0x3fedfe=le['scriptInjectionDeferred'])==null?void 0x0:_0x3fedfe['promise'];})['then'](()=>{_0x144e74(_0x3afa5f,_0x570e51,_0x1c43e8);})['catch'](_0x36def9=>{_0x1c43e8(_0x36def9);});}})['catch'](_0x255afc=>{_0x1c43e8(_0x255afc);});});}}le['scriptInjectionDeferred']=null;async function br(_0x4a4d51,_0x1f9b45,_0x2fc118,_0x5bbc80=!0x1,_0x130cea=!0x1){const _0x3dc5e1=new le(_0x4a4d51);let _0x1a63b7;if(_0x130cea)_0x1a63b7=Ma;else try{_0x1a63b7=await _0x3dc5e1['verify'](_0x2fc118);}catch{_0x1a63b7=await _0x3dc5e1['verify'](_0x2fc118,!0x0);}const _0x35dfc0={..._0x1f9b45};if(_0x2fc118==='mfaSmsEnrollment'||_0x2fc118==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x35dfc0){const _0x24843e=_0x35dfc0['phoneEnrollmentInfo']['phoneNumber'],_0x4f4ec7=_0x35dfc0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x35dfc0,{'phoneEnrollmentInfo':{'phoneNumber':_0x24843e,'recaptchaToken':_0x4f4ec7,'captchaResponse':_0x1a63b7,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x35dfc0){const _0x7534b9=_0x35dfc0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x35dfc0,{'phoneSignInInfo':{'recaptchaToken':_0x7534b9,'captchaResponse':_0x1a63b7,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x35dfc0;}return _0x5bbc80?Object['assign'](_0x35dfc0,{'captchaResp':_0x1a63b7}):Object['assign'](_0x35dfc0,{'captchaResponse':_0x1a63b7}),Object['assign'](_0x35dfc0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x35dfc0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x35dfc0;}async function Oi(_0x3b4b3a,_0x32e61b,_0x17bd06,_0x1edc36,_0x1c7ee1){var _0x2c286b;if((_0x2c286b=_0x3b4b3a['_getRecaptchaConfig']())!=null&&_0x2c286b['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5b5f7b=await br(_0x3b4b3a,_0x32e61b,_0x17bd06,_0x17bd06==='getOobCode');return _0x1edc36(_0x3b4b3a,_0x5b5f7b);}else return _0x1edc36(_0x3b4b3a,_0x32e61b)['catch'](async _0x3e4f08=>{if(_0x3e4f08['code']==='auth/missing-recaptcha-token'){console['log'](_0x17bd06+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5abe90=await br(_0x3b4b3a,_0x32e61b,_0x17bd06,_0x17bd06==='getOobCode');return _0x1edc36(_0x3b4b3a,_0x5abe90);}else return Promise['reject'](_0x3e4f08);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x4b0d53,_0x377a39){const _0x43bfce=Ui(_0x4b0d53,'auth');if(_0x43bfce['isInitialized']()){const _0x256d65=_0x43bfce['getImmediate'](),_0x48a934=_0x43bfce['getOptions']();if(De(_0x48a934,_0x377a39??{}))return _0x256d65;K(_0x256d65,'already-initialized');}return _0x43bfce['initialize']({'options':_0x377a39});}function Lf(_0x59d44c,_0x17420f){const _0x4f0b67=(_0x17420f==null?void 0x0:_0x17420f['persistence'])||[],_0x3257b9=(Array['isArray'](_0x4f0b67)?_0x4f0b67:[_0x4f0b67])['map'](ne);_0x17420f!=null&&_0x17420f['errorMap']&&_0x59d44c['_updateErrorMap'](_0x17420f['errorMap']),_0x59d44c['_initializeWithPersistence'](_0x3257b9,_0x17420f==null?void 0x0:_0x17420f['popupRedirectResolver']);}function xf(_0x2b268f,_0x2475df,_0x6a5d89){const _0x3e1e68=qe(_0x2b268f);m(/^https?:\/\//['test'](_0x2475df),_0x3e1e68,'invalid-emulator-scheme');const _0x2fc544=!0x1,_0x58402c=La(_0x2475df),{host:_0x11d3f1,port:_0x18aae9}=Ff(_0x2475df),_0x3efefb=_0x18aae9===null?'':':'+_0x18aae9,_0x414838={'url':_0x58402c+'//'+_0x11d3f1+_0x3efefb+'/'},_0x1dda53=Object['freeze']({'host':_0x11d3f1,'port':_0x18aae9,'protocol':_0x58402c['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2fc544})});if(!_0x3e1e68['_canInitEmulator']){m(_0x3e1e68['config']['emulator']&&_0x3e1e68['emulatorConfig'],_0x3e1e68,'emulator-config-failed'),m(De(_0x414838,_0x3e1e68['config']['emulator'])&&De(_0x1dda53,_0x3e1e68['emulatorConfig']),_0x3e1e68,'emulator-config-failed');return;}_0x3e1e68['config']['emulator']=_0x414838,_0x3e1e68['emulatorConfig']=_0x1dda53,_0x3e1e68['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x11d3f1)?jr(_0x58402c+'//'+_0x11d3f1+_0x3efefb):Uf();}function La(_0x3e7165){const _0x3b0f1d=_0x3e7165['indexOf'](':');return _0x3b0f1d<0x0?'':_0x3e7165['substr'](0x0,_0x3b0f1d+0x1);}function Ff(_0x2a0caa){const _0x69ff9f=La(_0x2a0caa),_0x5e72de=/(\/\/)?([^?#/]+)/['exec'](_0x2a0caa['substr'](_0x69ff9f['length']));if(!_0x5e72de)return{'host':'','port':null};const _0x1b0dda=_0x5e72de[0x2]['split']('@')['pop']()||'',_0x3af9af=/^(\[[^\]]+\])(:|$)/['exec'](_0x1b0dda);if(_0x3af9af){const _0x4ae045=_0x3af9af[0x1];return{'host':_0x4ae045,'port':Rr(_0x1b0dda['substr'](_0x4ae045['length']+0x1))};}else{const [_0x40bc0a,_0x1b87d7]=_0x1b0dda['split'](':');return{'host':_0x40bc0a,'port':Rr(_0x1b87d7)};}}function Rr(_0x298449){if(!_0x298449)return null;const _0x25ff54=Number(_0x298449);return isNaN(_0x25ff54)?null:_0x25ff54;}function Uf(){function _0xa6e01b(){const _0x23556e=document['createElement']('p'),_0x120bfa=_0x23556e['style'];_0x23556e['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x120bfa['position']='fixed',_0x120bfa['width']='100%',_0x120bfa['backgroundColor']='#ffffff',_0x120bfa['border']='.1em\x20solid\x20#000000',_0x120bfa['color']='#b50000',_0x120bfa['bottom']='0px',_0x120bfa['left']='0px',_0x120bfa['margin']='0px',_0x120bfa['zIndex']='10000',_0x120bfa['textAlign']='center',_0x23556e['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x23556e);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xa6e01b):_0xa6e01b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x58c032,_0xce0796){this['providerId']=_0x58c032,this['signInMethod']=_0xce0796;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x58e14a){return te('not\x20implemented');}['_linkToIdToken'](_0x15bbbc,_0x267fcc){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xb71316){return te('not\x20implemented');}}async function Wf(_0x3b08eb,_0x475219){return Ae(_0x3b08eb,'POST','/v1/accounts:signUp',_0x475219);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x40fa99,_0x2085fc){return Yt(_0x40fa99,'POST','/v1/accounts:signInWithPassword',Re(_0x40fa99,_0x2085fc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x328a0d,_0x10cfa9){return Yt(_0x328a0d,'POST','/v1/accounts:signInWithEmailLink',Re(_0x328a0d,_0x10cfa9));}async function Hf(_0x30dcb4,_0x46a071){return Yt(_0x30dcb4,'POST','/v1/accounts:signInWithEmailLink',Re(_0x30dcb4,_0x46a071));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x5ee6dc,_0x43a961,_0x1e334e,_0x5a3338=null){super('password',_0x1e334e),this['_email']=_0x5ee6dc,this['_password']=_0x43a961,this['_tenantId']=_0x5a3338;}static['_fromEmailAndPassword'](_0x5a4fa6,_0x20aa06){return new Ft(_0x5a4fa6,_0x20aa06,'password');}static['_fromEmailAndCode'](_0x2678e,_0x895bb5,_0x374233=null){return new Ft(_0x2678e,_0x895bb5,'emailLink',_0x374233);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xfb4a23){const _0x2197c2=typeof _0xfb4a23=='string'?JSON['parse'](_0xfb4a23):_0xfb4a23;if(_0x2197c2!=null&&_0x2197c2['email']&&(_0x2197c2!=null&&_0x2197c2['password'])){if(_0x2197c2['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2197c2['email'],_0x2197c2['password']);if(_0x2197c2['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2197c2['email'],_0x2197c2['password'],_0x2197c2['tenantId']);}return null;}async['_getIdTokenResponse'](_0x657574){switch(this['signInMethod']){case'password':const _0x4def00={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x657574,_0x4def00,'signInWithPassword',Bf);case'emailLink':return Vf(_0x657574,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x657574,'internal-error');}}async['_linkToIdToken'](_0x57d6d9,_0x513758){switch(this['signInMethod']){case'password':const _0x97a2a3={'idToken':_0x513758,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x57d6d9,_0x97a2a3,'signUpPassword',Wf);case'emailLink':return Hf(_0x57d6d9,{'idToken':_0x513758,'email':this['_email'],'oobCode':this['_password']});default:K(_0x57d6d9,'internal-error');}}['_getReauthenticationResolver'](_0x179520){return this['_getIdTokenResponse'](_0x179520);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x440e8c,_0x217001){return Yt(_0x440e8c,'POST','/v1/accounts:signInWithIdp',Re(_0x440e8c,_0x217001));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3751d5){const _0x3a0410=new We(_0x3751d5['providerId'],_0x3751d5['signInMethod']);return _0x3751d5['idToken']||_0x3751d5['accessToken']?(_0x3751d5['idToken']&&(_0x3a0410['idToken']=_0x3751d5['idToken']),_0x3751d5['accessToken']&&(_0x3a0410['accessToken']=_0x3751d5['accessToken']),_0x3751d5['nonce']&&!_0x3751d5['pendingToken']&&(_0x3a0410['nonce']=_0x3751d5['nonce']),_0x3751d5['pendingToken']&&(_0x3a0410['pendingToken']=_0x3751d5['pendingToken'])):_0x3751d5['oauthToken']&&_0x3751d5['oauthTokenSecret']?(_0x3a0410['accessToken']=_0x3751d5['oauthToken'],_0x3a0410['secret']=_0x3751d5['oauthTokenSecret']):K('argument-error'),_0x3a0410;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x330818){const _0x761958=typeof _0x330818=='string'?JSON['parse'](_0x330818):_0x330818,{providerId:_0x652223,signInMethod:_0x60bc90,..._0x29788e}=_0x761958;if(!_0x652223||!_0x60bc90)return null;const _0x4a8b4f=new We(_0x652223,_0x60bc90);return _0x4a8b4f['idToken']=_0x29788e['idToken']||void 0x0,_0x4a8b4f['accessToken']=_0x29788e['accessToken']||void 0x0,_0x4a8b4f['secret']=_0x29788e['secret'],_0x4a8b4f['nonce']=_0x29788e['nonce'],_0x4a8b4f['pendingToken']=_0x29788e['pendingToken']||null,_0x4a8b4f;}['_getIdTokenResponse'](_0x30a927){const _0x24c4cb=this['buildRequest']();return Ze(_0x30a927,_0x24c4cb);}['_linkToIdToken'](_0x2e8da3,_0x23acaa){const _0x119f3f=this['buildRequest']();return _0x119f3f['idToken']=_0x23acaa,Ze(_0x2e8da3,_0x119f3f);}['_getReauthenticationResolver'](_0x30d44b){const _0x2ec3b1=this['buildRequest']();return _0x2ec3b1['autoCreate']=!0x1,Ze(_0x30d44b,_0x2ec3b1);}['buildRequest'](){const _0x128d0b={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x128d0b['pendingToken']=this['pendingToken'];else{const _0x591937={};this['idToken']&&(_0x591937['id_token']=this['idToken']),this['accessToken']&&(_0x591937['access_token']=this['accessToken']),this['secret']&&(_0x591937['oauth_token_secret']=this['secret']),_0x591937['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x591937['nonce']=this['nonce']),_0x128d0b['postBody']=at(_0x591937);}return _0x128d0b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x500948){switch(_0x500948){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x4f3b1f){const _0x47ea55=yt(vt(_0x4f3b1f))['link'],_0x545c5c=_0x47ea55?yt(vt(_0x47ea55))['deep_link_id']:null,_0x2a2602=yt(vt(_0x4f3b1f))['deep_link_id'];return(_0x2a2602?yt(vt(_0x2a2602))['link']:null)||_0x2a2602||_0x545c5c||_0x47ea55||_0x4f3b1f;}class Ss{constructor(_0x1b210e){const _0x535ccc=yt(vt(_0x1b210e)),_0x628803=_0x535ccc['apiKey']??null,_0x2f5d8e=_0x535ccc['oobCode']??null,_0x592c13=Gf(_0x535ccc['mode']??null);m(_0x628803&&_0x2f5d8e&&_0x592c13,'argument-error'),this['apiKey']=_0x628803,this['operation']=_0x592c13,this['code']=_0x2f5d8e,this['continueUrl']=_0x535ccc['continueUrl']??null,this['languageCode']=_0x535ccc['lang']??null,this['tenantId']=_0x535ccc['tenantId']??null;}static['parseLink'](_0x47ef38){const _0x5cc98a=qf(_0x47ef38);try{return new Ss(_0x5cc98a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0xad7b1f,_0xd36f){return Ft['_fromEmailAndPassword'](_0xad7b1f,_0xd36f);}static['credentialWithLink'](_0x3591f9,_0x3b08f9){const _0x217111=Ss['parseLink'](_0x3b08f9);return m(_0x217111,'argument-error'),Ft['_fromEmailAndCode'](_0x3591f9,_0x217111['code'],_0x217111['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3c586c){this['providerId']=_0x3c586c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x37171f){this['defaultLanguageCode']=_0x37171f;}['setCustomParameters'](_0x8f9d32){return this['customParameters']=_0x8f9d32,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1488e6){return this['scopes']['includes'](_0x1488e6)||this['scopes']['push'](_0x1488e6),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x29e336){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x29e336});}static['credentialFromResult'](_0x1d853f){return he['credentialFromTaggedObject'](_0x1d853f);}static['credentialFromError'](_0x3b3d8b){return he['credentialFromTaggedObject'](_0x3b3d8b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x444928}){if(!_0x444928||!('oauthAccessToken'in _0x444928)||!_0x444928['oauthAccessToken'])return null;try{return he['credential'](_0x444928['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1cf26b,_0x17c412){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1cf26b,'accessToken':_0x17c412});}static['credentialFromResult'](_0x5ae79e){return ue['credentialFromTaggedObject'](_0x5ae79e);}static['credentialFromError'](_0x1b5ec6){return ue['credentialFromTaggedObject'](_0x1b5ec6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x485444}){if(!_0x485444)return null;const {oauthIdToken:_0x1b6025,oauthAccessToken:_0x4176e1}=_0x485444;if(!_0x1b6025&&!_0x4176e1)return null;try{return ue['credential'](_0x1b6025,_0x4176e1);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x1fe0b0){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1fe0b0});}static['credentialFromResult'](_0x55d62b){return de['credentialFromTaggedObject'](_0x55d62b);}static['credentialFromError'](_0x3a4c07){return de['credentialFromTaggedObject'](_0x3a4c07['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5c43cb}){if(!_0x5c43cb||!('oauthAccessToken'in _0x5c43cb)||!_0x5c43cb['oauthAccessToken'])return null;try{return de['credential'](_0x5c43cb['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2b8afb,_0xe9ba1e){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2b8afb,'oauthTokenSecret':_0xe9ba1e});}static['credentialFromResult'](_0x4c2a3a){return fe['credentialFromTaggedObject'](_0x4c2a3a);}static['credentialFromError'](_0x10cf28){return fe['credentialFromTaggedObject'](_0x10cf28['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x57963c}){if(!_0x57963c)return null;const {oauthAccessToken:_0x4cfc06,oauthTokenSecret:_0x3c97a9}=_0x57963c;if(!_0x4cfc06||!_0x3c97a9)return null;try{return fe['credential'](_0x4cfc06,_0x3c97a9);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x62505e,_0x39554b){return Yt(_0x62505e,'POST','/v1/accounts:signUp',Re(_0x62505e,_0x39554b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xb472e7){this['user']=_0xb472e7['user'],this['providerId']=_0xb472e7['providerId'],this['_tokenResponse']=_0xb472e7['_tokenResponse'],this['operationType']=_0xb472e7['operationType'];}static async['_fromIdTokenResponse'](_0x1acc28,_0xb1bc61,_0x5a55fc,_0x6d16bc=!0x1){const _0x27ff7e=await z['_fromIdTokenResponse'](_0x1acc28,_0x5a55fc,_0x6d16bc),_0x5a0262=Ar(_0x5a55fc);return new Be({'user':_0x27ff7e,'providerId':_0x5a0262,'_tokenResponse':_0x5a55fc,'operationType':_0xb1bc61});}static async['_forOperation'](_0x5a61d1,_0x492130,_0x92bdd2){await _0x5a61d1['_updateTokensIfNecessary'](_0x92bdd2,!0x0);const _0x149d16=Ar(_0x92bdd2);return new Be({'user':_0x5a61d1,'providerId':_0x149d16,'_tokenResponse':_0x92bdd2,'operationType':_0x492130});}}function Ar(_0x59a66a){return _0x59a66a['providerId']?_0x59a66a['providerId']:'phoneNumber'in _0x59a66a?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xcdd1e8,_0x4f375a,_0x4bae22,_0x319a82){super(_0x4f375a['code'],_0x4f375a['message']),this['operationType']=_0x4bae22,this['user']=_0x319a82,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xcdd1e8['name'],'tenantId':_0xcdd1e8['tenantId']??void 0x0,'_serverResponse':_0x4f375a['customData']['_serverResponse'],'operationType':_0x4bae22};}static['_fromErrorAndOperation'](_0x14895f,_0x448781,_0x17980b,_0x5c0b85){return new Rn(_0x14895f,_0x448781,_0x17980b,_0x5c0b85);}}function Fa(_0x51d79b,_0x2a7dde,_0x46f413,_0x479951){return(_0x2a7dde==='reauthenticate'?_0x46f413['_getReauthenticationResolver'](_0x51d79b):_0x46f413['_getIdTokenResponse'](_0x51d79b))['catch'](_0x5bf6cd=>{throw _0x5bf6cd['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x51d79b,_0x5bf6cd,_0x2a7dde,_0x479951):_0x5bf6cd;});}async function jf(_0x5e4a7e,_0x26af17,_0xd3519=!0x1){const _0x34288c=await xt(_0x5e4a7e,_0x26af17['_linkToIdToken'](_0x5e4a7e['auth'],await _0x5e4a7e['getIdToken']()),_0xd3519);return Be['_forOperation'](_0x5e4a7e,'link',_0x34288c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1d206a,_0x2a5646,_0x5d2372=!0x1){const {auth:_0x5a1398}=_0x1d206a;if(H(_0x5a1398['app']))return Promise['reject'](se(_0x5a1398));const _0x2eee10='reauthenticate';try{const _0x5ad7a6=await xt(_0x1d206a,Fa(_0x5a1398,_0x2eee10,_0x2a5646,_0x1d206a),_0x5d2372);m(_0x5ad7a6['idToken'],_0x5a1398,'internal-error');const _0x40c0da=ws(_0x5ad7a6['idToken']);m(_0x40c0da,_0x5a1398,'internal-error');const {sub:_0x381222}=_0x40c0da;return m(_0x1d206a['uid']===_0x381222,_0x5a1398,'user-mismatch'),Be['_forOperation'](_0x1d206a,_0x2eee10,_0x5ad7a6);}catch(_0x39ad3e){throw(_0x39ad3e==null?void 0x0:_0x39ad3e['code'])==='auth/user-not-found'&&K(_0x5a1398,'user-mismatch'),_0x39ad3e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4c8a75,_0x3b9fed,_0x2a30b2=!0x1){if(H(_0x4c8a75['app']))return Promise['reject'](se(_0x4c8a75));const _0x521cbf='signIn',_0x4bb49b=await Fa(_0x4c8a75,_0x521cbf,_0x3b9fed),_0x57aacd=await Be['_fromIdTokenResponse'](_0x4c8a75,_0x521cbf,_0x4bb49b);return _0x2a30b2||await _0x4c8a75['_updateCurrentUser'](_0x57aacd['user']),_0x57aacd;}async function Yf(_0x1e3ec0,_0x201178){return Ua(qe(_0x1e3ec0),_0x201178);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0xffd220){const _0x185902=qe(_0xffd220);_0x185902['_getPasswordPolicyInternal']()&&await _0x185902['_updatePasswordPolicy']();}async function R_(_0x4e6814,_0x508358,_0x1d1b05){if(H(_0x4e6814['app']))return Promise['reject'](se(_0x4e6814));const _0x4690ca=qe(_0x4e6814),_0x42f76a=await Oi(_0x4690ca,{'returnSecureToken':!0x0,'email':_0x508358,'password':_0x1d1b05,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x2f072a=>{throw _0x2f072a['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4e6814),_0x2f072a;}),_0x3be97d=await Be['_fromIdTokenResponse'](_0x4690ca,'signIn',_0x42f76a);return await _0x4690ca['_updateCurrentUser'](_0x3be97d['user']),_0x3be97d;}function A_(_0x58b51b,_0x44a969,_0x4e23c5){return H(_0x58b51b['app'])?Promise['reject'](se(_0x58b51b)):Yf(k(_0x58b51b),ft['credential'](_0x44a969,_0x4e23c5))['catch'](async _0x79a84=>{throw _0x79a84['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x58b51b),_0x79a84;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x4769eb,_0x429b02){return k(_0x4769eb)['setPersistence'](_0x429b02);}function Qf(_0x1f7196,_0x1ce297,_0x5850db,_0x36cb55){return k(_0x1f7196)['onIdTokenChanged'](_0x1ce297,_0x5850db,_0x36cb55);}function Jf(_0x26a481,_0x4d75e5,_0x2855b7){return k(_0x26a481)['beforeAuthStateChanged'](_0x4d75e5,_0x2855b7);}function N_(_0x46dbb5,_0x4cae4e,_0x2f1cfd,_0x664d22){return k(_0x46dbb5)['onAuthStateChanged'](_0x4cae4e,_0x2f1cfd,_0x664d22);}function P_(_0x3fe53e){return k(_0x3fe53e)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x3f543c,_0x4ffd10){this['storageRetriever']=_0x3f543c,this['type']=_0x4ffd10;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4cd6d3,_0x4ccdfa){return this['storage']['setItem'](_0x4cd6d3,JSON['stringify'](_0x4ccdfa)),Promise['resolve']();}['_get'](_0x550c9f){const _0x5a8b2e=this['storage']['getItem'](_0x550c9f);return Promise['resolve'](_0x5a8b2e?JSON['parse'](_0x5a8b2e):null);}['_remove'](_0x2d74ec){return this['storage']['removeItem'](_0x2d74ec),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5adeb4,_0x14a00a)=>this['onStorageEvent'](_0x5adeb4,_0x14a00a),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3343ad){for(const _0x52fff0 of Object['keys'](this['listeners'])){const _0x48290b=this['storage']['getItem'](_0x52fff0),_0x1979a4=this['localCache'][_0x52fff0];_0x48290b!==_0x1979a4&&_0x3343ad(_0x52fff0,_0x1979a4,_0x48290b);}}['onStorageEvent'](_0x5c069c,_0x431301=!0x1){if(!_0x5c069c['key']){this['forAllChangedKeys']((_0x13a41a,_0x8f4002,_0x91a513)=>{this['notifyListeners'](_0x13a41a,_0x91a513);});return;}const _0x15f614=_0x5c069c['key'];_0x431301?this['detachListener']():this['stopPolling']();const _0x19e127=()=>{const _0x541c01=this['storage']['getItem'](_0x15f614);!_0x431301&&this['localCache'][_0x15f614]===_0x541c01||this['notifyListeners'](_0x15f614,_0x541c01);},_0x44cae8=this['storage']['getItem'](_0x15f614);If()&&_0x44cae8!==_0x5c069c['newValue']&&_0x5c069c['newValue']!==_0x5c069c['oldValue']?setTimeout(_0x19e127,Zf):_0x19e127();}['notifyListeners'](_0x4c96bd,_0x451b1f){this['localCache'][_0x4c96bd]=_0x451b1f;const _0x11f530=this['listeners'][_0x4c96bd];if(_0x11f530){for(const _0x80b4b0 of Array['from'](_0x11f530))_0x80b4b0(_0x451b1f&&JSON['parse'](_0x451b1f));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x278ed4,_0x3fe740,_0x1656f5)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x278ed4,'oldValue':_0x3fe740,'newValue':_0x1656f5}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3d67a3,_0x141389){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3d67a3]||(this['listeners'][_0x3d67a3]=new Set(),this['localCache'][_0x3d67a3]=this['storage']['getItem'](_0x3d67a3)),this['listeners'][_0x3d67a3]['add'](_0x141389);}['_removeListener'](_0x507f87,_0x374d66){this['listeners'][_0x507f87]&&(this['listeners'][_0x507f87]['delete'](_0x374d66),this['listeners'][_0x507f87]['size']===0x0&&delete this['listeners'][_0x507f87]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x34366e,_0x30f769){await super['_set'](_0x34366e,_0x30f769),this['localCache'][_0x34366e]=JSON['stringify'](_0x30f769);}async['_get'](_0x551df9){const _0x658e95=await super['_get'](_0x551df9);return this['localCache'][_0x551df9]=JSON['stringify'](_0x658e95),_0x658e95;}async['_remove'](_0x59f7e9){await super['_remove'](_0x59f7e9),delete this['localCache'][_0x59f7e9];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x53a828,_0x567786){}['_removeListener'](_0x4fc2f8,_0x5f0a2f){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x152d00){return Promise['all'](_0x152d00['map'](async _0x12f99f=>{try{return{'fulfilled':!0x0,'value':await _0x12f99f};}catch(_0xf74b64){return{'fulfilled':!0x1,'reason':_0xf74b64};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x4bb155){this['eventTarget']=_0x4bb155,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x49b11c){const _0xe4481f=this['receivers']['find'](_0x3a04a8=>_0x3a04a8['isListeningto'](_0x49b11c));if(_0xe4481f)return _0xe4481f;const _0x27fa3e=new jn(_0x49b11c);return this['receivers']['push'](_0x27fa3e),_0x27fa3e;}['isListeningto'](_0x5a15d3){return this['eventTarget']===_0x5a15d3;}async['handleEvent'](_0x5a7d42){const _0x711098=_0x5a7d42,{eventId:_0xcdb47a,eventType:_0x17103a,data:_0x599535}=_0x711098['data'],_0x4f458e=this['handlersMap'][_0x17103a];if(!(_0x4f458e!=null&&_0x4f458e['size']))return;_0x711098['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xcdb47a,'eventType':_0x17103a});const _0x266229=Array['from'](_0x4f458e)['map'](async _0x55b101=>_0x55b101(_0x711098['origin'],_0x599535)),_0xf6eacf=await tp(_0x266229);_0x711098['ports'][0x0]['postMessage']({'status':'done','eventId':_0xcdb47a,'eventType':_0x17103a,'response':_0xf6eacf});}['_subscribe'](_0x1c7310,_0x204151){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1c7310]||(this['handlersMap'][_0x1c7310]=new Set()),this['handlersMap'][_0x1c7310]['add'](_0x204151);}['_unsubscribe'](_0xef0c0b,_0x43e27f){this['handlersMap'][_0xef0c0b]&&_0x43e27f&&this['handlersMap'][_0xef0c0b]['delete'](_0x43e27f),(!_0x43e27f||this['handlersMap'][_0xef0c0b]['size']===0x0)&&delete this['handlersMap'][_0xef0c0b],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x28dadd='',_0x36aab3=0xa){let _0x2a7169='';for(let _0x57bb0d=0x0;_0x57bb0d<_0x36aab3;_0x57bb0d++)_0x2a7169+=Math['floor'](Math['random']()*0xa);return _0x28dadd+_0x2a7169;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x45bab7){this['target']=_0x45bab7,this['handlers']=new Set();}['removeMessageHandler'](_0x464dd0){_0x464dd0['messageChannel']&&(_0x464dd0['messageChannel']['port1']['removeEventListener']('message',_0x464dd0['onMessage']),_0x464dd0['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x464dd0);}async['_send'](_0x111e94,_0x376d3e,_0x478296=0x32){const _0x1a3c9b=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1a3c9b)throw new Error('connection_unavailable');let _0x28c09b,_0x12f86d;return new Promise((_0x59abe9,_0x45c987)=>{const _0x1fec25=bs('',0x14);_0x1a3c9b['port1']['start']();const _0x5aa8c4=setTimeout(()=>{_0x45c987(new Error('unsupported_event'));},_0x478296);_0x12f86d={'messageChannel':_0x1a3c9b,'onMessage'(_0x431f9f){const _0x32ee3d=_0x431f9f;if(_0x32ee3d['data']['eventId']===_0x1fec25)switch(_0x32ee3d['data']['status']){case'ack':clearTimeout(_0x5aa8c4),_0x28c09b=setTimeout(()=>{_0x45c987(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x28c09b),_0x59abe9(_0x32ee3d['data']['response']);break;default:clearTimeout(_0x5aa8c4),clearTimeout(_0x28c09b),_0x45c987(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x12f86d),_0x1a3c9b['port1']['addEventListener']('message',_0x12f86d['onMessage']),this['target']['postMessage']({'eventType':_0x111e94,'eventId':_0x1fec25,'data':_0x376d3e},[_0x1a3c9b['port2']]);})['finally'](()=>{_0x12f86d&&this['removeMessageHandler'](_0x12f86d);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x42fc0a){X()['location']['href']=_0x42fc0a;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x4c23b3;return((_0x4c23b3=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4c23b3['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x993027){this['request']=_0x993027;}['toPromise'](){return new Promise((_0x36b297,_0x841e6c)=>{this['request']['addEventListener']('success',()=>{_0x36b297(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x841e6c(this['request']['error']);});});}}function Kn(_0x5ef47e,_0x5d3c6c){return _0x5ef47e['transaction']([kn],_0x5d3c6c?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3dab50=indexedDB['deleteDatabase'](qa);return new Jt(_0x3dab50)['toPromise']();}function ja(){const _0x3314ad=indexedDB['open'](qa,ap);return new Promise((_0x285b46,_0x390a2c)=>{_0x3314ad['addEventListener']('error',()=>{_0x390a2c(_0x3314ad['error']);}),_0x3314ad['addEventListener']('upgradeneeded',()=>{const _0x27413c=_0x3314ad['result'];try{_0x27413c['createObjectStore'](kn,{'keyPath':za});}catch(_0x24fc64){_0x390a2c(_0x24fc64);}}),_0x3314ad['addEventListener']('success',async()=>{const _0x3022f4=_0x3314ad['result'];_0x3022f4['objectStoreNames']['contains'](kn)?_0x285b46(_0x3022f4):(_0x3022f4['close'](),await cp(),_0x285b46(await ja()));});});}async function kr(_0x22cb1e,_0x554d2b,_0x330063){const _0x4db4a7=Kn(_0x22cb1e,!0x0)['put']({[za]:_0x554d2b,'value':_0x330063});return new Jt(_0x4db4a7)['toPromise']();}async function lp(_0x415c34,_0x3632c2){const _0x42087f=Kn(_0x415c34,!0x1)['get'](_0x3632c2),_0x59a7dc=await new Jt(_0x42087f)['toPromise']();return _0x59a7dc===void 0x0?null:_0x59a7dc['value'];}function Nr(_0x1771ba,_0x5849b7){const _0x348fb0=Kn(_0x1771ba,!0x0)['delete'](_0x5849b7);return new Jt(_0x348fb0)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0xb5d723){let _0x44185d=0x0;for(;;)try{const _0x529ef7=await this['_openDb']();return await _0xb5d723(_0x529ef7);}catch(_0x3ef814){if(_0x44185d++>up)throw _0x3ef814;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x16c70d,_0x4dfad0)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4dfad0['key'])})),this['receiver']['_subscribe']('ping',async(_0x4b750f,_0x4c8cf9)=>['keyChanged']);}async['initializeSender'](){var _0x186998,_0xe390ac;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x5d5568=await this['sender']['_send']('ping',{},0x320);_0x5d5568&&(_0x186998=_0x5d5568[0x0])!=null&&_0x186998['fulfilled']&&(_0xe390ac=_0x5d5568[0x0])!=null&&_0xe390ac['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xd9dc2c){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xd9dc2c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4e9ebb=>{await kr(_0x4e9ebb,An,'1'),await Nr(_0x4e9ebb,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2e5253){this['pendingWrites']++;try{await _0x2e5253();}finally{this['pendingWrites']--;}}async['_set'](_0x2544af,_0x29102e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1705ce=>kr(_0x1705ce,_0x2544af,_0x29102e)),this['localCache'][_0x2544af]=_0x29102e,this['notifyServiceWorker'](_0x2544af)));}async['_get'](_0x245349){const _0x73945a=await this['_withRetries'](_0x47e290=>lp(_0x47e290,_0x245349));return this['localCache'][_0x245349]=_0x73945a,_0x73945a;}async['_remove'](_0x31f106){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x263f75=>Nr(_0x263f75,_0x31f106)),delete this['localCache'][_0x31f106],this['notifyServiceWorker'](_0x31f106)));}async['_poll'](){const _0x4583ef=await this['_withRetries'](_0x3d4f76=>{const _0x3b2464=Kn(_0x3d4f76,!0x1)['getAll']();return new Jt(_0x3b2464)['toPromise']();});if(!_0x4583ef)return[];if(this['pendingWrites']!==0x0)return[];const _0x362e68=[],_0x324350=new Set();if(_0x4583ef['length']!==0x0){for(const {fbase_key:_0x277c5f,value:_0x1f472b}of _0x4583ef)_0x324350['add'](_0x277c5f),JSON['stringify'](this['localCache'][_0x277c5f])!==JSON['stringify'](_0x1f472b)&&(this['notifyListeners'](_0x277c5f,_0x1f472b),_0x362e68['push'](_0x277c5f));}for(const _0x3d5aee of Object['keys'](this['localCache']))this['localCache'][_0x3d5aee]&&!_0x324350['has'](_0x3d5aee)&&(this['notifyListeners'](_0x3d5aee,null),_0x362e68['push'](_0x3d5aee));return _0x362e68;}['notifyListeners'](_0x2ebbab,_0x1e6916){this['localCache'][_0x2ebbab]=_0x1e6916;const _0x37e557=this['listeners'][_0x2ebbab];if(_0x37e557){for(const _0x18ab11 of Array['from'](_0x37e557))_0x18ab11(_0x1e6916);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x180f47,_0x122fd9){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x180f47]||(this['listeners'][_0x180f47]=new Set(),this['_get'](_0x180f47)),this['listeners'][_0x180f47]['add'](_0x122fd9);}['_removeListener'](_0x1f4888,_0x47c1b7){this['listeners'][_0x1f4888]&&(this['listeners'][_0x1f4888]['delete'](_0x47c1b7),this['listeners'][_0x1f4888]['size']===0x0&&delete this['listeners'][_0x1f4888]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x5caa02,_0x31860b){return _0x31860b?ne(_0x31860b):(m(_0x5caa02['_popupRedirectResolver'],_0x5caa02,'argument-error'),_0x5caa02['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x5ee3f8){super('custom','custom'),this['params']=_0x5ee3f8;}['_getIdTokenResponse'](_0x30e648){return Ze(_0x30e648,this['_buildIdpRequest']());}['_linkToIdToken'](_0x127618,_0x945109){return Ze(_0x127618,this['_buildIdpRequest'](_0x945109));}['_getReauthenticationResolver'](_0x17c278){return Ze(_0x17c278,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5d7d7f){const _0x19c965={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5d7d7f&&(_0x19c965['idToken']=_0x5d7d7f),_0x19c965;}}function pp(_0x2d7cd8){return Ua(_0x2d7cd8['auth'],new Rs(_0x2d7cd8),_0x2d7cd8['bypassAuthState']);}function _p(_0x1a8df9){const {auth:_0x50e6e8,user:_0x50e7e6}=_0x1a8df9;return m(_0x50e7e6,_0x50e6e8,'internal-error'),Kf(_0x50e7e6,new Rs(_0x1a8df9),_0x1a8df9['bypassAuthState']);}async function gp(_0x4adab0){const {auth:_0x3279c6,user:_0x33bea2}=_0x4adab0;return m(_0x33bea2,_0x3279c6,'internal-error'),jf(_0x33bea2,new Rs(_0x4adab0),_0x4adab0['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x17a250,_0x4a1dd0,_0xbc9f7f,_0x127475,_0x1c78b2=!0x1){this['auth']=_0x17a250,this['resolver']=_0xbc9f7f,this['user']=_0x127475,this['bypassAuthState']=_0x1c78b2,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4a1dd0)?_0x4a1dd0:[_0x4a1dd0];}['execute'](){return new Promise(async(_0x1f2bbd,_0x2eca30)=>{this['pendingPromise']={'resolve':_0x1f2bbd,'reject':_0x2eca30};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x52a695){this['reject'](_0x52a695);}});}async['onAuthEvent'](_0x48eee2){const {urlResponse:_0x336cfd,sessionId:_0x57577a,postBody:_0x5a9d35,tenantId:_0x1da2c1,error:_0x5606a4,type:_0x4396b3}=_0x48eee2;if(_0x5606a4){this['reject'](_0x5606a4);return;}const _0x527ccc={'auth':this['auth'],'requestUri':_0x336cfd,'sessionId':_0x57577a,'tenantId':_0x1da2c1||void 0x0,'postBody':_0x5a9d35||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4396b3)(_0x527ccc));}catch(_0x1f383f){this['reject'](_0x1f383f);}}['onError'](_0x16d5cf){this['reject'](_0x16d5cf);}['getIdpTask'](_0x5cea50){switch(_0x5cea50){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x3087b1){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3087b1),this['unregisterAndCleanUp']();}['reject'](_0x4fe561){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4fe561),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x28036c,_0x53fd15,_0x58093f,_0x52b9b1,_0x5bfe1b){super(_0x28036c,_0x53fd15,_0x52b9b1,_0x5bfe1b),this['provider']=_0x58093f,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xddb249=await this['execute']();return m(_0xddb249,this['auth'],'internal-error'),_0xddb249;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x284eaa=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x284eaa),this['authWindow']['associatedEvent']=_0x284eaa,this['resolver']['_originValidation'](this['auth'])['catch'](_0x97d6f3=>{this['reject'](_0x97d6f3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x50fee8=>{_0x50fee8||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5e9fb2;return((_0x5e9fb2=this['authWindow'])==null?void 0x0:_0x5e9fb2['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3ab7e2=()=>{var _0x3fd4b6,_0xeb937b;if((_0xeb937b=(_0x3fd4b6=this['authWindow'])==null?void 0x0:_0x3fd4b6['window'])!=null&&_0xeb937b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3ab7e2,mp['get']());};_0x3ab7e2();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x30eb5f,_0x2d9e7e,_0x1c0129=!0x1){super(_0x30eb5f,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2d9e7e,void 0x0,_0x1c0129),this['eventId']=null;}async['execute'](){let _0x39f818=rn['get'](this['auth']['_key']());if(!_0x39f818){try{const _0x4447f9=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x39f818=()=>Promise['resolve'](_0x4447f9);}catch(_0xd908ac){_0x39f818=()=>Promise['reject'](_0xd908ac);}rn['set'](this['auth']['_key'](),_0x39f818);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x39f818();}async['onAuthEvent'](_0x4015ec){if(_0x4015ec['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4015ec);if(_0x4015ec['type']==='unknown'){this['resolve'](null);return;}if(_0x4015ec['eventId']){const _0x1ef787=await this['auth']['_redirectUserForId'](_0x4015ec['eventId']);if(_0x1ef787)return this['user']=_0x1ef787,super['onAuthEvent'](_0x4015ec);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x10385a,_0x428837){const _0x4d3dcd=Cp(_0x428837),_0x3037e0=wp(_0x10385a);if(!await _0x3037e0['_isAvailable']())return!0x1;const _0x90abe=await _0x3037e0['_get'](_0x4d3dcd)==='true';return await _0x3037e0['_remove'](_0x4d3dcd),_0x90abe;}function Ip(_0xd8abe1,_0x44894a){rn['set'](_0xd8abe1['_key'](),_0x44894a);}function wp(_0x78ca26){return ne(_0x78ca26['_redirectPersistence']);}function Cp(_0x665603){return sn(yp,_0x665603['config']['apiKey'],_0x665603['name']);}async function Tp(_0xfa9dbe,_0x51119b,_0x11cede=!0x1){if(H(_0xfa9dbe['app']))return Promise['reject'](se(_0xfa9dbe));const _0xb5541=qe(_0xfa9dbe),_0x9727cc=fp(_0xb5541,_0x51119b),_0x27ee27=await new vp(_0xb5541,_0x9727cc,_0x11cede)['execute']();return _0x27ee27&&!_0x11cede&&(delete _0x27ee27['user']['_redirectEventId'],await _0xb5541['_persistUserIfCurrent'](_0x27ee27['user']),await _0xb5541['_setRedirectUser'](null,_0x51119b)),_0x27ee27;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x45329f){this['auth']=_0x45329f,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x454059){this['consumers']['add'](_0x454059),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x454059)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x454059),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1be0df){this['consumers']['delete'](_0x1be0df);}['onEvent'](_0xa298ad){if(this['hasEventBeenHandled'](_0xa298ad))return!0x1;let _0x29c21e=!0x1;return this['consumers']['forEach'](_0x33ada5=>{this['isEventForConsumer'](_0xa298ad,_0x33ada5)&&(_0x29c21e=!0x0,this['sendToConsumer'](_0xa298ad,_0x33ada5),this['saveEventToCache'](_0xa298ad));}),this['hasHandledPotentialRedirect']||!Rp(_0xa298ad)||(this['hasHandledPotentialRedirect']=!0x0,_0x29c21e||(this['queuedRedirectEvent']=_0xa298ad,_0x29c21e=!0x0)),_0x29c21e;}['sendToConsumer'](_0x26e57b,_0x446c87){var _0x2b8d65;if(_0x26e57b['error']&&!Qa(_0x26e57b)){const _0x44a72d=((_0x2b8d65=_0x26e57b['error']['code'])==null?void 0x0:_0x2b8d65['split']('auth/')[0x1])||'internal-error';_0x446c87['onError'](J(this['auth'],_0x44a72d));}else _0x446c87['onAuthEvent'](_0x26e57b);}['isEventForConsumer'](_0x166cf0,_0x343bd1){const _0x3a51d0=_0x343bd1['eventId']===null||!!_0x166cf0['eventId']&&_0x166cf0['eventId']===_0x343bd1['eventId'];return _0x343bd1['filter']['includes'](_0x166cf0['type'])&&_0x3a51d0;}['hasEventBeenHandled'](_0x4716ca){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x4716ca));}['saveEventToCache'](_0x4487cd){this['cachedEventUids']['add'](Pr(_0x4487cd)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x36682e){return[_0x36682e['type'],_0x36682e['eventId'],_0x36682e['sessionId'],_0x36682e['tenantId']]['filter'](_0x312ea9=>_0x312ea9)['join']('-');}function Qa({type:_0x21526a,error:_0x28ce8d}){return _0x21526a==='unknown'&&(_0x28ce8d==null?void 0x0:_0x28ce8d['code'])==='auth/no-auth-event';}function Rp(_0x4b5955){switch(_0x4b5955['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4b5955);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3813da,_0x5016e8={}){return Ae(_0x3813da,'GET','/v1/projects',_0x5016e8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x55002b){if(_0x55002b['config']['emulator'])return;const {authorizedDomains:_0x235511}=await Ap(_0x55002b);for(const _0x25e3f4 of _0x235511)try{if(Op(_0x25e3f4))return;}catch{}K(_0x55002b,'unauthorized-domain');}function Op(_0xb9497b){const _0x4ae2fc=Ni(),{protocol:_0x383036,hostname:_0x3b6869}=new URL(_0x4ae2fc);if(_0xb9497b['startsWith']('chrome-extension://')){const _0x479813=new URL(_0xb9497b);return _0x479813['hostname']===''&&_0x3b6869===''?_0x383036==='chrome-extension:'&&_0xb9497b['replace']('chrome-extension://','')===_0x4ae2fc['replace']('chrome-extension://',''):_0x383036==='chrome-extension:'&&_0x479813['hostname']===_0x3b6869;}if(!Np['test'](_0x383036))return!0x1;if(kp['test'](_0xb9497b))return _0x3b6869===_0xb9497b;const _0x3cd522=_0xb9497b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3cd522+'|'+_0x3cd522+')$','i')['test'](_0x3b6869);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x14b24a=X()['___jsl'];if(_0x14b24a!=null&&_0x14b24a['H']){for(const _0x41a647 of Object['keys'](_0x14b24a['H']))if(_0x14b24a['H'][_0x41a647]['r']=_0x14b24a['H'][_0x41a647]['r']||[],_0x14b24a['H'][_0x41a647]['L']=_0x14b24a['H'][_0x41a647]['L']||[],_0x14b24a['H'][_0x41a647]['r']=[..._0x14b24a['H'][_0x41a647]['L']],_0x14b24a['CP']){for(let _0x229978=0x0;_0x229978<_0x14b24a['CP']['length'];_0x229978++)_0x14b24a['CP'][_0x229978]=null;}}}function Mp(_0x185363){return new Promise((_0x1044e5,_0x2db150)=>{var _0x3181e8,_0xc13e8e,_0x188a88;function _0x3bb487(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1044e5(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x2db150(J(_0x185363,'network-request-failed'));},'timeout':Dp['get']()});}if((_0xc13e8e=(_0x3181e8=X()['gapi'])==null?void 0x0:_0x3181e8['iframes'])!=null&&_0xc13e8e['Iframe'])_0x1044e5(gapi['iframes']['getContext']());else{if((_0x188a88=X()['gapi'])!=null&&_0x188a88['load'])_0x3bb487();else{const _0x5345a7=Nf('iframefcb');return X()[_0x5345a7]=()=>{gapi['load']?_0x3bb487():_0x2db150(J(_0x185363,'network-request-failed'));},Da(kf()+'?onload='+_0x5345a7)['catch'](_0x1164fb=>_0x2db150(_0x1164fb));}}})['catch'](_0x4de352=>{throw on=null,_0x4de352;});}let on=null;function Lp(_0x44cec3){return on=on||Mp(_0x44cec3),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x295441){const _0x18d5f5=_0x295441['config'];m(_0x18d5f5['authDomain'],_0x295441,'auth-domain-config-required');const _0x528fd3=_0x18d5f5['emulator']?Is(_0x18d5f5,Up):'https://'+_0x295441['config']['authDomain']+'/'+Fp,_0x5dc27e={'apiKey':_0x18d5f5['apiKey'],'appName':_0x295441['name'],'v':ct},_0xc1006=Bp['get'](_0x295441['config']['apiHost']);_0xc1006&&(_0x5dc27e['eid']=_0xc1006);const _0x42922b=_0x295441['_getFrameworks']();return _0x42922b['length']&&(_0x5dc27e['fw']=_0x42922b['join'](',')),_0x528fd3+'?'+at(_0x5dc27e)['slice'](0x1);}async function Hp(_0x2dd737){const _0x525110=await Lp(_0x2dd737),_0x12d235=X()['gapi'];return m(_0x12d235,_0x2dd737,'internal-error'),_0x525110['open']({'where':document['body'],'url':Vp(_0x2dd737),'messageHandlersFilter':_0x12d235['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x4a0c99=>new Promise(async(_0x35dbc9,_0x1d9077)=>{await _0x4a0c99['restyle']({'setHideOnLeave':!0x1});const _0x46d23a=J(_0x2dd737,'network-request-failed'),_0x27b6c2=X()['setTimeout'](()=>{_0x1d9077(_0x46d23a);},xp['get']());function _0x4f1a91(){X()['clearTimeout'](_0x27b6c2),_0x35dbc9(_0x4a0c99);}_0x4a0c99['ping'](_0x4f1a91)['then'](_0x4f1a91,()=>{_0x1d9077(_0x46d23a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x557690){this['window']=_0x557690,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x538abb,_0x20ee8d,_0x1419d7,_0x250ce4=Gp,_0x2fbe5a=qp){const _0xf27835=Math['max']((window['screen']['availHeight']-_0x2fbe5a)/0x2,0x0)['toString'](),_0x13efbf=Math['max']((window['screen']['availWidth']-_0x250ce4)/0x2,0x0)['toString']();let _0x265bba='';const _0x396948={...$p,'width':_0x250ce4['toString'](),'height':_0x2fbe5a['toString'](),'top':_0xf27835,'left':_0x13efbf},_0x5d7f5e=W()['toLowerCase']();_0x1419d7&&(_0x265bba=ba(_0x5d7f5e)?zp:_0x1419d7),Ta(_0x5d7f5e)&&(_0x20ee8d=_0x20ee8d||jp,_0x396948['scrollbars']='yes');const _0x42ecc9=Object['entries'](_0x396948)['reduce']((_0x199700,[_0x4c4858,_0x37d8df])=>''+_0x199700+_0x4c4858+'='+_0x37d8df+',','');if(Ef(_0x5d7f5e)&&_0x265bba!=='_self')return Yp(_0x20ee8d||'',_0x265bba),new Dr(null);const _0xf490a8=window['open'](_0x20ee8d||'',_0x265bba,_0x42ecc9);m(_0xf490a8,_0x538abb,'popup-blocked');try{_0xf490a8['focus']();}catch{}return new Dr(_0xf490a8);}function Yp(_0xd75fda,_0x373af0){const _0x47bb3a=document['createElement']('a');_0x47bb3a['href']=_0xd75fda,_0x47bb3a['target']=_0x373af0;const _0x231eb2=document['createEvent']('MouseEvent');_0x231eb2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x47bb3a['dispatchEvent'](_0x231eb2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0xd223c7,_0x2a6619,_0x5038e0,_0xaed21b,_0x40b66a,_0x29db02){m(_0xd223c7['config']['authDomain'],_0xd223c7,'auth-domain-config-required'),m(_0xd223c7['config']['apiKey'],_0xd223c7,'invalid-api-key');const _0x51e1dd={'apiKey':_0xd223c7['config']['apiKey'],'appName':_0xd223c7['name'],'authType':_0x5038e0,'redirectUrl':_0xaed21b,'v':ct,'eventId':_0x40b66a};if(_0x2a6619 instanceof xa){_0x2a6619['setDefaultLanguage'](_0xd223c7['languageCode']),_0x51e1dd['providerId']=_0x2a6619['providerId']||'',hi(_0x2a6619['getCustomParameters']())||(_0x51e1dd['customParameters']=JSON['stringify'](_0x2a6619['getCustomParameters']()));for(const [_0x361051,_0x4b371e]of Object['entries']({}))_0x51e1dd[_0x361051]=_0x4b371e;}if(_0x2a6619 instanceof Qt){const _0x29c960=_0x2a6619['getScopes']()['filter'](_0x147600=>_0x147600!=='');_0x29c960['length']>0x0&&(_0x51e1dd['scopes']=_0x29c960['join'](','));}_0xd223c7['tenantId']&&(_0x51e1dd['tid']=_0xd223c7['tenantId']);const _0x119d89=_0x51e1dd;for(const _0x1c56a2 of Object['keys'](_0x119d89))_0x119d89[_0x1c56a2]===void 0x0&&delete _0x119d89[_0x1c56a2];const _0x379ffe=await _0xd223c7['_getAppCheckToken'](),_0xcbbc09=_0x379ffe?'#'+Xp+'='+encodeURIComponent(_0x379ffe):'';return Zp(_0xd223c7)+'?'+at(_0x119d89)['slice'](0x1)+_0xcbbc09;}function Zp({config:_0x56d5c3}){return _0x56d5c3['emulator']?Is(_0x56d5c3,Jp):'https://'+_0x56d5c3['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x533544,_0x622554,_0x271cac,_0x43095d){var _0x46964e;ae((_0x46964e=this['eventManagers'][_0x533544['_key']()])==null?void 0x0:_0x46964e['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xd6de85=await Mr(_0x533544,_0x622554,_0x271cac,Ni(),_0x43095d);return Kp(_0x533544,_0xd6de85,bs());}async['_openRedirect'](_0x502221,_0x4bc232,_0x5ae5b0,_0xe73ae5){await this['_originValidation'](_0x502221);const _0xb3b67a=await Mr(_0x502221,_0x4bc232,_0x5ae5b0,Ni(),_0xe73ae5);return ip(_0xb3b67a),new Promise(()=>{});}['_initialize'](_0x8b1a92){const _0x5ccdf5=_0x8b1a92['_key']();if(this['eventManagers'][_0x5ccdf5]){const {manager:_0x2d629c,promise:_0x4da3d0}=this['eventManagers'][_0x5ccdf5];return _0x2d629c?Promise['resolve'](_0x2d629c):(ae(_0x4da3d0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4da3d0);}const _0x36a1e5=this['initAndGetManager'](_0x8b1a92);return this['eventManagers'][_0x5ccdf5]={'promise':_0x36a1e5},_0x36a1e5['catch'](()=>{delete this['eventManagers'][_0x5ccdf5];}),_0x36a1e5;}async['initAndGetManager'](_0x2c24b9){const _0x4332d0=await Hp(_0x2c24b9),_0x38e915=new bp(_0x2c24b9);return _0x4332d0['register']('authEvent',_0x4724d2=>(m(_0x4724d2==null?void 0x0:_0x4724d2['authEvent'],_0x2c24b9,'invalid-auth-event'),{'status':_0x38e915['onEvent'](_0x4724d2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2c24b9['_key']()]={'manager':_0x38e915},this['iframes'][_0x2c24b9['_key']()]=_0x4332d0,_0x38e915;}['_isIframeWebStorageSupported'](_0x2cf622,_0x3642e8){this['iframes'][_0x2cf622['_key']()]['send'](li,{'type':li},_0xfa965f=>{var _0x406eb7;const _0x3c1e2c=(_0x406eb7=_0xfa965f==null?void 0x0:_0xfa965f[0x0])==null?void 0x0:_0x406eb7[li];_0x3c1e2c!==void 0x0&&_0x3642e8(!!_0x3c1e2c),K(_0x2cf622,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xd4824){const _0x543c38=_0xd4824['_key']();return this['originValidationPromises'][_0x543c38]||(this['originValidationPromises'][_0x543c38]=Pp(_0xd4824)),this['originValidationPromises'][_0x543c38];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0xc95725){this['auth']=_0xc95725,this['internalListeners']=new Map();}['getUid'](){var _0x365647;return this['assertAuthConfigured'](),((_0x365647=this['auth']['currentUser'])==null?void 0x0:_0x365647['uid'])||null;}async['getToken'](_0x9abfd8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x9abfd8)}:null;}['addAuthTokenListener'](_0x4bccff){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4bccff))return;const _0x445b8b=this['auth']['onIdTokenChanged'](_0xc49ac4=>{_0x4bccff((_0xc49ac4==null?void 0x0:_0xc49ac4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4bccff,_0x445b8b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x34944c){this['assertAuthConfigured']();const _0x5a38c2=this['internalListeners']['get'](_0x34944c);_0x5a38c2&&(this['internalListeners']['delete'](_0x34944c),_0x5a38c2(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5be731){switch(_0x5be731){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x36e1eb){et(new Me('auth',(_0xb382a9,{options:_0x23a5db})=>{const _0x5e4359=_0xb382a9['getProvider']('app')['getImmediate'](),_0x19d061=_0xb382a9['getProvider']('heartbeat'),_0x5eaa83=_0xb382a9['getProvider']('app-check-internal'),{apiKey:_0x40b5b9,authDomain:_0x53ed1c}=_0x5e4359['options'];m(_0x40b5b9&&!_0x40b5b9['includes'](':'),'invalid-api-key',{'appName':_0x5e4359['name']});const _0x25c04c={'apiKey':_0x40b5b9,'authDomain':_0x53ed1c,'clientPlatform':_0x36e1eb,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x36e1eb)},_0xd7e3e=new bf(_0x5e4359,_0x19d061,_0x5eaa83,_0x25c04c);return Lf(_0xd7e3e,_0x23a5db),_0xd7e3e;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x340dd1,_0x56268e,_0x2af58b)=>{_0x340dd1['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x18b9e7=>{const _0x4a4ea1=qe(_0x18b9e7['getProvider']('auth')['getImmediate']());return(_0x28bea1=>new n_(_0x28bea1))(_0x4a4ea1);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x36e1eb)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x28b530=>async _0x201381=>{const _0x52366c=_0x201381&&await _0x201381['getIdTokenResult'](),_0x2b60ab=_0x52366c&&(new Date()['getTime']()-Date['parse'](_0x52366c['issuedAtTime']))/0x3e8;if(_0x2b60ab&&_0x2b60ab>o_)return;const _0x494445=_0x52366c==null?void 0x0:_0x52366c['token'];Fr!==_0x494445&&(Fr=_0x494445,await fetch(_0x28b530,{'method':_0x494445?'POST':'DELETE','headers':_0x494445?{'Authorization':'Bearer\x20'+_0x494445}:{}}));};function O_(_0x1c8bb7=Qr()){const _0x2bdaec=Ui(_0x1c8bb7,'auth');if(_0x2bdaec['isInitialized']())return _0x2bdaec['getImmediate']();const _0x23d859=Mf(_0x1c8bb7,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x26f2c0=Gr('authTokenSyncURL');if(_0x26f2c0&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2b5558=new URL(_0x26f2c0,location['origin']);if(location['origin']===_0x2b5558['origin']){const _0x17f75a=a_(_0x2b5558['toString']());Jf(_0x23d859,_0x17f75a,()=>_0x17f75a(_0x23d859['currentUser'])),Qf(_0x23d859,_0x2ca75e=>_0x17f75a(_0x2ca75e));}}const _0x12b274=Hr('auth');return _0x12b274&&xf(_0x23d859,'http://'+_0x12b274),_0x23d859;}function c_(){var _0xc9e318;return((_0xc9e318=document['getElementsByTagName']('head'))==null?void 0x0:_0xc9e318[0x0])??document;}Rf({'loadJS'(_0x425a61){return new Promise((_0x3b7154,_0x59aa53)=>{const _0x5bb2bd=document['createElement']('script');_0x5bb2bd['setAttribute']('src',_0x425a61),_0x5bb2bd['onload']=_0x3b7154,_0x5bb2bd['onerror']=_0x136eb4=>{const _0x490f87=J('internal-error');_0x490f87['customData']=_0x136eb4,_0x59aa53(_0x490f87);},_0x5bb2bd['type']='text/javascript',_0x5bb2bd['charset']='UTF-8',c_()['appendChild'](_0x5bb2bd);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};