const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x49311a,_0x54fbf6){if(!_0x49311a)throw ot(_0x54fbf6);},ot=function(_0x51f6b5){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x51f6b5);},Wr=function(_0x49d21f){const _0xe92cc=[];let _0x16bc6f=0x0;for(let _0x51b4df=0x0;_0x51b4df<_0x49d21f['length'];_0x51b4df++){let _0x2360ae=_0x49d21f['charCodeAt'](_0x51b4df);_0x2360ae<0x80?_0xe92cc[_0x16bc6f++]=_0x2360ae:_0x2360ae<0x800?(_0xe92cc[_0x16bc6f++]=_0x2360ae>>0x6|0xc0,_0xe92cc[_0x16bc6f++]=_0x2360ae&0x3f|0x80):(_0x2360ae&0xfc00)===0xd800&&_0x51b4df+0x1<_0x49d21f['length']&&(_0x49d21f['charCodeAt'](_0x51b4df+0x1)&0xfc00)===0xdc00?(_0x2360ae=0x10000+((_0x2360ae&0x3ff)<<0xa)+(_0x49d21f['charCodeAt'](++_0x51b4df)&0x3ff),_0xe92cc[_0x16bc6f++]=_0x2360ae>>0x12|0xf0,_0xe92cc[_0x16bc6f++]=_0x2360ae>>0xc&0x3f|0x80,_0xe92cc[_0x16bc6f++]=_0x2360ae>>0x6&0x3f|0x80,_0xe92cc[_0x16bc6f++]=_0x2360ae&0x3f|0x80):(_0xe92cc[_0x16bc6f++]=_0x2360ae>>0xc|0xe0,_0xe92cc[_0x16bc6f++]=_0x2360ae>>0x6&0x3f|0x80,_0xe92cc[_0x16bc6f++]=_0x2360ae&0x3f|0x80);}return _0xe92cc;},Za=function(_0x1dc22c){const _0xa5867f=[];let _0x43171f=0x0,_0x11e1c8=0x0;for(;_0x43171f<_0x1dc22c['length'];){const _0x4770df=_0x1dc22c[_0x43171f++];if(_0x4770df<0x80)_0xa5867f[_0x11e1c8++]=String['fromCharCode'](_0x4770df);else{if(_0x4770df>0xbf&&_0x4770df<0xe0){const _0x7c154a=_0x1dc22c[_0x43171f++];_0xa5867f[_0x11e1c8++]=String['fromCharCode']((_0x4770df&0x1f)<<0x6|_0x7c154a&0x3f);}else{if(_0x4770df>0xef&&_0x4770df<0x16d){const _0x17b29e=_0x1dc22c[_0x43171f++],_0x3ec30e=_0x1dc22c[_0x43171f++],_0x56ab8b=_0x1dc22c[_0x43171f++],_0x188a6f=((_0x4770df&0x7)<<0x12|(_0x17b29e&0x3f)<<0xc|(_0x3ec30e&0x3f)<<0x6|_0x56ab8b&0x3f)-0x10000;_0xa5867f[_0x11e1c8++]=String['fromCharCode'](0xd800+(_0x188a6f>>0xa)),_0xa5867f[_0x11e1c8++]=String['fromCharCode'](0xdc00+(_0x188a6f&0x3ff));}else{const _0x5c7b9d=_0x1dc22c[_0x43171f++],_0xeb271e=_0x1dc22c[_0x43171f++];_0xa5867f[_0x11e1c8++]=String['fromCharCode']((_0x4770df&0xf)<<0xc|(_0x5c7b9d&0x3f)<<0x6|_0xeb271e&0x3f);}}}}return _0xa5867f['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x100a08,_0x329092){if(!Array['isArray'](_0x100a08))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x45fb7d=_0x329092?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4ff441=[];for(let _0x46d4e1=0x0;_0x46d4e1<_0x100a08['length'];_0x46d4e1+=0x3){const _0x543bbd=_0x100a08[_0x46d4e1],_0x50a294=_0x46d4e1+0x1<_0x100a08['length'],_0x48736d=_0x50a294?_0x100a08[_0x46d4e1+0x1]:0x0,_0x4dbcea=_0x46d4e1+0x2<_0x100a08['length'],_0x23ab5d=_0x4dbcea?_0x100a08[_0x46d4e1+0x2]:0x0,_0x2392e3=_0x543bbd>>0x2,_0x1594fa=(_0x543bbd&0x3)<<0x4|_0x48736d>>0x4;let _0x557641=(_0x48736d&0xf)<<0x2|_0x23ab5d>>0x6,_0x1ecea4=_0x23ab5d&0x3f;_0x4dbcea||(_0x1ecea4=0x40,_0x50a294||(_0x557641=0x40)),_0x4ff441['push'](_0x45fb7d[_0x2392e3],_0x45fb7d[_0x1594fa],_0x45fb7d[_0x557641],_0x45fb7d[_0x1ecea4]);}return _0x4ff441['join']('');},'encodeString'(_0x268514,_0x3ae268){return this['HAS_NATIVE_SUPPORT']&&!_0x3ae268?btoa(_0x268514):this['encodeByteArray'](Wr(_0x268514),_0x3ae268);},'decodeString'(_0x335455,_0x4637fe){return this['HAS_NATIVE_SUPPORT']&&!_0x4637fe?atob(_0x335455):Za(this['decodeStringToByteArray'](_0x335455,_0x4637fe));},'decodeStringToByteArray'(_0x44cd05,_0x186085){this['init_']();const _0x4a8da2=_0x186085?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2c7233=[];for(let _0x464e2c=0x0;_0x464e2c<_0x44cd05['length'];){const _0x15cb17=_0x4a8da2[_0x44cd05['charAt'](_0x464e2c++)],_0x2b9dab=_0x464e2c<_0x44cd05['length']?_0x4a8da2[_0x44cd05['charAt'](_0x464e2c)]:0x0;++_0x464e2c;const _0x18da54=_0x464e2c<_0x44cd05['length']?_0x4a8da2[_0x44cd05['charAt'](_0x464e2c)]:0x40;++_0x464e2c;const _0x45859f=_0x464e2c<_0x44cd05['length']?_0x4a8da2[_0x44cd05['charAt'](_0x464e2c)]:0x40;if(++_0x464e2c,_0x15cb17==null||_0x2b9dab==null||_0x18da54==null||_0x45859f==null)throw new ec();const _0xf152a7=_0x15cb17<<0x2|_0x2b9dab>>0x4;if(_0x2c7233['push'](_0xf152a7),_0x18da54!==0x40){const _0x2cf3b1=_0x2b9dab<<0x4&0xf0|_0x18da54>>0x2;if(_0x2c7233['push'](_0x2cf3b1),_0x45859f!==0x40){const _0x50bd6f=_0x18da54<<0x6&0xc0|_0x45859f;_0x2c7233['push'](_0x50bd6f);}}}return _0x2c7233;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xd63dd2=0x0;_0xd63dd2<this['ENCODED_VALS']['length'];_0xd63dd2++)this['byteToCharMap_'][_0xd63dd2]=this['ENCODED_VALS']['charAt'](_0xd63dd2),this['charToByteMap_'][this['byteToCharMap_'][_0xd63dd2]]=_0xd63dd2,this['byteToCharMapWebSafe_'][_0xd63dd2]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xd63dd2),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xd63dd2]]=_0xd63dd2,_0xd63dd2>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xd63dd2)]=_0xd63dd2,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xd63dd2)]=_0xd63dd2);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x30e05d){const _0x38e979=Wr(_0x30e05d);return Di['encodeByteArray'](_0x38e979,!0x0);},an=function(_0x448a3b){return Br(_0x448a3b)['replace'](/\./g,'');},cn=function(_0x2da2f9){try{return Di['decodeString'](_0x2da2f9,!0x0);}catch(_0x19d52f){console['error']('base64Decode\x20failed:\x20',_0x19d52f);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x16d3b2){return Vr(void 0x0,_0x16d3b2);}function Vr(_0x31749c,_0x1b1dec){if(!(_0x1b1dec instanceof Object))return _0x1b1dec;switch(_0x1b1dec['constructor']){case Date:const _0xe0ba28=_0x1b1dec;return new Date(_0xe0ba28['getTime']());case Object:_0x31749c===void 0x0&&(_0x31749c={});break;case Array:_0x31749c=[];break;default:return _0x1b1dec;}for(const _0x532864 in _0x1b1dec)!_0x1b1dec['hasOwnProperty'](_0x532864)||!nc(_0x532864)||(_0x31749c[_0x532864]=Vr(_0x31749c[_0x532864],_0x1b1dec[_0x532864]));return _0x31749c;}function nc(_0xe35767){return _0xe35767!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x30646b=As['__FIREBASE_DEFAULTS__'];if(_0x30646b)return JSON['parse'](_0x30646b);},oc=()=>{if(typeof document>'u')return;let _0x155083;try{_0x155083=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xd3047d=_0x155083&&cn(_0x155083[0x1]);return _0xd3047d&&JSON['parse'](_0xd3047d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x5a0b9e){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5a0b9e);return;}},Hr=_0x5ecc75=>{var _0x3b74e2,_0x2dde4c;return(_0x2dde4c=(_0x3b74e2=Mi())==null?void 0x0:_0x3b74e2['emulatorHosts'])==null?void 0x0:_0x2dde4c[_0x5ecc75];},ac=_0x1a3e8a=>{const _0x566772=Hr(_0x1a3e8a);if(!_0x566772)return;const _0x2e32c7=_0x566772['lastIndexOf'](':');if(_0x2e32c7<=0x0||_0x2e32c7+0x1===_0x566772['length'])throw new Error('Invalid\x20host\x20'+_0x566772+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2589e7=parseInt(_0x566772['substring'](_0x2e32c7+0x1),0xa);return _0x566772[0x0]==='['?[_0x566772['substring'](0x1,_0x2e32c7-0x1),_0x2589e7]:[_0x566772['substring'](0x0,_0x2e32c7),_0x2589e7];},$r=()=>{var _0x217f9c;return(_0x217f9c=Mi())==null?void 0x0:_0x217f9c['config'];},Gr=_0x4b779f=>{var _0x2f869e;return(_0x2f869e=Mi())==null?void 0x0:_0x2f869e['_'+_0x4b779f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x44663c,_0x29e441)=>{this['resolve']=_0x44663c,this['reject']=_0x29e441;});}['wrapCallback'](_0x165fbf){return(_0x554ab0,_0x1fdc17)=>{_0x554ab0?this['reject'](_0x554ab0):this['resolve'](_0x1fdc17),typeof _0x165fbf=='function'&&(this['promise']['catch'](()=>{}),_0x165fbf['length']===0x1?_0x165fbf(_0x554ab0):_0x165fbf(_0x554ab0,_0x1fdc17));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x39665a,_0x270ef1){if(_0x39665a['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xe288af={'alg':'none','type':'JWT'},_0x105ce9=_0x270ef1||'demo-project',_0xcf30dc=_0x39665a['iat']||0x0,_0x392147=_0x39665a['sub']||_0x39665a['user_id'];if(!_0x392147)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2eff7d={'iss':'https://securetoken.google.com/'+_0x105ce9,'aud':_0x105ce9,'iat':_0xcf30dc,'exp':_0xcf30dc+0xe10,'auth_time':_0xcf30dc,'sub':_0x392147,'user_id':_0x392147,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x39665a};return[an(JSON['stringify'](_0xe288af)),an(JSON['stringify'](_0x2eff7d)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x3e4afa=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3e4afa=='object'&&_0x3e4afa['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x581856=W();return _0x581856['indexOf']('MSIE\x20')>=0x0||_0x581856['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4ae7a8,_0x5efacd)=>{try{let _0x2bf327=!0x0;const _0x1c6b4a='validate-browser-context-for-indexeddb-analytics-module',_0x48bb37=self['indexedDB']['open'](_0x1c6b4a);_0x48bb37['onsuccess']=()=>{_0x48bb37['result']['close'](),_0x2bf327||self['indexedDB']['deleteDatabase'](_0x1c6b4a),_0x4ae7a8(!0x0);},_0x48bb37['onupgradeneeded']=()=>{_0x2bf327=!0x1;},_0x48bb37['onerror']=()=>{var _0x331dbc;_0x5efacd(((_0x331dbc=_0x48bb37['error'])==null?void 0x0:_0x331dbc['message'])||'');};}catch(_0x35906b){_0x5efacd(_0x35906b);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x5bed8e,_0x3723d5,_0x377b32){super(_0x3723d5),this['code']=_0x5bed8e,this['customData']=_0x377b32,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0xea27ab,_0x2f8d37,_0x504ae6){this['service']=_0xea27ab,this['serviceName']=_0x2f8d37,this['errors']=_0x504ae6;}['create'](_0x199b13,..._0x442010){const _0x34b36e=_0x442010[0x0]||{},_0x404291=this['service']+'/'+_0x199b13,_0x1ef167=this['errors'][_0x199b13],_0x32691a=_0x1ef167?gc(_0x1ef167,_0x34b36e):'Error',_0x465a0d=this['serviceName']+':\x20'+_0x32691a+'\x20('+_0x404291+').';return new Se(_0x404291,_0x465a0d,_0x34b36e);}}function gc(_0x1bd7d4,_0x5c91a5){return _0x1bd7d4['replace'](mc,(_0x35fbb3,_0x147c97)=>{const _0x554472=_0x5c91a5[_0x147c97];return _0x554472!=null?String(_0x554472):'<'+_0x147c97+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x1404bb){return JSON['parse'](_0x1404bb);}function O(_0x56c8d2){return JSON['stringify'](_0x56c8d2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x1abeeb){let _0x2c7af6={},_0x1fa403={},_0x404d19={},_0x5f598a='';try{const _0x5dc527=_0x1abeeb['split']('.');_0x2c7af6=bt(cn(_0x5dc527[0x0])||''),_0x1fa403=bt(cn(_0x5dc527[0x1])||''),_0x5f598a=_0x5dc527[0x2],_0x404d19=_0x1fa403['d']||{},delete _0x1fa403['d'];}catch{}return{'header':_0x2c7af6,'claims':_0x1fa403,'data':_0x404d19,'signature':_0x5f598a};},yc=function(_0x1978d4){const _0x556466=zr(_0x1978d4),_0x4d45b1=_0x556466['claims'];return!!_0x4d45b1&&typeof _0x4d45b1=='object'&&_0x4d45b1['hasOwnProperty']('iat');},vc=function(_0x57b41e){const _0xf6da55=zr(_0x57b41e)['claims'];return typeof _0xf6da55=='object'&&_0xf6da55['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x35ae0f,_0x40b126){return Object['prototype']['hasOwnProperty']['call'](_0x35ae0f,_0x40b126);}function Oe(_0x5c0bce,_0x16fc7c){if(Object['prototype']['hasOwnProperty']['call'](_0x5c0bce,_0x16fc7c))return _0x5c0bce[_0x16fc7c];}function hi(_0x55232f){for(const _0x49c14b in _0x55232f)if(Object['prototype']['hasOwnProperty']['call'](_0x55232f,_0x49c14b))return!0x1;return!0x0;}function ln(_0x2c8592,_0x1bf2b9,_0xfe5d7b){const _0x24a70a={};for(const _0x2468be in _0x2c8592)Object['prototype']['hasOwnProperty']['call'](_0x2c8592,_0x2468be)&&(_0x24a70a[_0x2468be]=_0x1bf2b9['call'](_0xfe5d7b,_0x2c8592[_0x2468be],_0x2468be,_0x2c8592));return _0x24a70a;}function De(_0x46051f,_0xc0773f){if(_0x46051f===_0xc0773f)return!0x0;const _0xcef2af=Object['keys'](_0x46051f),_0x4d259b=Object['keys'](_0xc0773f);for(const _0x1663c1 of _0xcef2af){if(!_0x4d259b['includes'](_0x1663c1))return!0x1;const _0x2a627d=_0x46051f[_0x1663c1],_0x17f637=_0xc0773f[_0x1663c1];if(ks(_0x2a627d)&&ks(_0x17f637)){if(!De(_0x2a627d,_0x17f637))return!0x1;}else{if(_0x2a627d!==_0x17f637)return!0x1;}}for(const _0x4f3148 of _0x4d259b)if(!_0xcef2af['includes'](_0x4f3148))return!0x1;return!0x0;}function ks(_0x332673){return _0x332673!==null&&typeof _0x332673=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3ff43f){const _0xff2030=[];for(const [_0x23a20d,_0x1c47ea]of Object['entries'](_0x3ff43f))Array['isArray'](_0x1c47ea)?_0x1c47ea['forEach'](_0x43ea62=>{_0xff2030['push'](encodeURIComponent(_0x23a20d)+'='+encodeURIComponent(_0x43ea62));}):_0xff2030['push'](encodeURIComponent(_0x23a20d)+'='+encodeURIComponent(_0x1c47ea));return _0xff2030['length']?'&'+_0xff2030['join']('&'):'';}function yt(_0xcec725){const _0x11f44b={};return _0xcec725['replace'](/^\?/,'')['split']('&')['forEach'](_0x159f58=>{if(_0x159f58){const [_0x4970e6,_0x542400]=_0x159f58['split']('=');_0x11f44b[decodeURIComponent(_0x4970e6)]=decodeURIComponent(_0x542400);}}),_0x11f44b;}function vt(_0x41b365){const _0x1b7bf4=_0x41b365['indexOf']('?');if(!_0x1b7bf4)return'';const _0x3be512=_0x41b365['indexOf']('#',_0x1b7bf4);return _0x41b365['substring'](_0x1b7bf4,_0x3be512>0x0?_0x3be512:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1b2204=0x1;_0x1b2204<this['blockSize'];++_0x1b2204)this['pad_'][_0x1b2204]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1ec008,_0x269eb7){_0x269eb7||(_0x269eb7=0x0);const _0x91db6e=this['W_'];if(typeof _0x1ec008=='string'){for(let _0x5cd0df=0x0;_0x5cd0df<0x10;_0x5cd0df++)_0x91db6e[_0x5cd0df]=_0x1ec008['charCodeAt'](_0x269eb7)<<0x18|_0x1ec008['charCodeAt'](_0x269eb7+0x1)<<0x10|_0x1ec008['charCodeAt'](_0x269eb7+0x2)<<0x8|_0x1ec008['charCodeAt'](_0x269eb7+0x3),_0x269eb7+=0x4;}else{for(let _0x5314b0=0x0;_0x5314b0<0x10;_0x5314b0++)_0x91db6e[_0x5314b0]=_0x1ec008[_0x269eb7]<<0x18|_0x1ec008[_0x269eb7+0x1]<<0x10|_0x1ec008[_0x269eb7+0x2]<<0x8|_0x1ec008[_0x269eb7+0x3],_0x269eb7+=0x4;}for(let _0x1c7d66=0x10;_0x1c7d66<0x50;_0x1c7d66++){const _0x143796=_0x91db6e[_0x1c7d66-0x3]^_0x91db6e[_0x1c7d66-0x8]^_0x91db6e[_0x1c7d66-0xe]^_0x91db6e[_0x1c7d66-0x10];_0x91db6e[_0x1c7d66]=(_0x143796<<0x1|_0x143796>>>0x1f)&0xffffffff;}let _0x552f81=this['chain_'][0x0],_0x44040b=this['chain_'][0x1],_0x45c0c1=this['chain_'][0x2],_0x83e128=this['chain_'][0x3],_0x14494a=this['chain_'][0x4],_0x4d0ec1,_0x7ae2bb;for(let _0x2480f1=0x0;_0x2480f1<0x50;_0x2480f1++){_0x2480f1<0x28?_0x2480f1<0x14?(_0x4d0ec1=_0x83e128^_0x44040b&(_0x45c0c1^_0x83e128),_0x7ae2bb=0x5a827999):(_0x4d0ec1=_0x44040b^_0x45c0c1^_0x83e128,_0x7ae2bb=0x6ed9eba1):_0x2480f1<0x3c?(_0x4d0ec1=_0x44040b&_0x45c0c1|_0x83e128&(_0x44040b|_0x45c0c1),_0x7ae2bb=0x8f1bbcdc):(_0x4d0ec1=_0x44040b^_0x45c0c1^_0x83e128,_0x7ae2bb=0xca62c1d6);const _0x1a0c93=(_0x552f81<<0x5|_0x552f81>>>0x1b)+_0x4d0ec1+_0x14494a+_0x7ae2bb+_0x91db6e[_0x2480f1]&0xffffffff;_0x14494a=_0x83e128,_0x83e128=_0x45c0c1,_0x45c0c1=(_0x44040b<<0x1e|_0x44040b>>>0x2)&0xffffffff,_0x44040b=_0x552f81,_0x552f81=_0x1a0c93;}this['chain_'][0x0]=this['chain_'][0x0]+_0x552f81&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x44040b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x45c0c1&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x83e128&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x14494a&0xffffffff;}['update'](_0x4413a4,_0x2f9b36){if(_0x4413a4==null)return;_0x2f9b36===void 0x0&&(_0x2f9b36=_0x4413a4['length']);const _0x2c2872=_0x2f9b36-this['blockSize'];let _0x307d47=0x0;const _0x2a0c0d=this['buf_'];let _0x590b2e=this['inbuf_'];for(;_0x307d47<_0x2f9b36;){if(_0x590b2e===0x0){for(;_0x307d47<=_0x2c2872;)this['compress_'](_0x4413a4,_0x307d47),_0x307d47+=this['blockSize'];}if(typeof _0x4413a4=='string'){for(;_0x307d47<_0x2f9b36;)if(_0x2a0c0d[_0x590b2e]=_0x4413a4['charCodeAt'](_0x307d47),++_0x590b2e,++_0x307d47,_0x590b2e===this['blockSize']){this['compress_'](_0x2a0c0d),_0x590b2e=0x0;break;}}else{for(;_0x307d47<_0x2f9b36;)if(_0x2a0c0d[_0x590b2e]=_0x4413a4[_0x307d47],++_0x590b2e,++_0x307d47,_0x590b2e===this['blockSize']){this['compress_'](_0x2a0c0d),_0x590b2e=0x0;break;}}}this['inbuf_']=_0x590b2e,this['total_']+=_0x2f9b36;}['digest'](){const _0x5b4e00=[];let _0x4cebd=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x238d11=this['blockSize']-0x1;_0x238d11>=0x38;_0x238d11--)this['buf_'][_0x238d11]=_0x4cebd&0xff,_0x4cebd/=0x100;this['compress_'](this['buf_']);let _0x55c973=0x0;for(let _0x340d2b=0x0;_0x340d2b<0x5;_0x340d2b++)for(let _0x3920ae=0x18;_0x3920ae>=0x0;_0x3920ae-=0x8)_0x5b4e00[_0x55c973]=this['chain_'][_0x340d2b]>>_0x3920ae&0xff,++_0x55c973;return _0x5b4e00;}}function Ic(_0x2f234b,_0x9b13d5){const _0x5f226c=new wc(_0x2f234b,_0x9b13d5);return _0x5f226c['subscribe']['bind'](_0x5f226c);}class wc{constructor(_0x4a8b0a,_0x45b3bd){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x45b3bd,this['task']['then'](()=>{_0x4a8b0a(this);})['catch'](_0x335594=>{this['error'](_0x335594);});}['next'](_0x46d0dd){this['forEachObserver'](_0x2edc18=>{_0x2edc18['next'](_0x46d0dd);});}['error'](_0x1bc3d4){this['forEachObserver'](_0x159e7c=>{_0x159e7c['error'](_0x1bc3d4);}),this['close'](_0x1bc3d4);}['complete'](){this['forEachObserver'](_0x30de72=>{_0x30de72['complete']();}),this['close']();}['subscribe'](_0x6d2ef7,_0x49d447,_0x5d6148){let _0x3abbc5;if(_0x6d2ef7===void 0x0&&_0x49d447===void 0x0&&_0x5d6148===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x6d2ef7,['next','error','complete'])?_0x3abbc5=_0x6d2ef7:_0x3abbc5={'next':_0x6d2ef7,'error':_0x49d447,'complete':_0x5d6148},_0x3abbc5['next']===void 0x0&&(_0x3abbc5['next']=Qn),_0x3abbc5['error']===void 0x0&&(_0x3abbc5['error']=Qn),_0x3abbc5['complete']===void 0x0&&(_0x3abbc5['complete']=Qn);const _0x2c7541=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3abbc5['error'](this['finalError']):_0x3abbc5['complete']();}catch{}}),this['observers']['push'](_0x3abbc5),_0x2c7541;}['unsubscribeOne'](_0x323ec7){this['observers']===void 0x0||this['observers'][_0x323ec7]===void 0x0||(delete this['observers'][_0x323ec7],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4f6a78){if(!this['finalized']){for(let _0x242fea=0x0;_0x242fea<this['observers']['length'];_0x242fea++)this['sendOne'](_0x242fea,_0x4f6a78);}}['sendOne'](_0x16560a,_0x3b56fa){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x16560a]!==void 0x0)try{_0x3b56fa(this['observers'][_0x16560a]);}catch(_0x5f21db){typeof console<'u'&&console['error']&&console['error'](_0x5f21db);}});}['close'](_0x4e197d){this['finalized']||(this['finalized']=!0x0,_0x4e197d!==void 0x0&&(this['finalError']=_0x4e197d),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x13ec94,_0x456013){if(typeof _0x13ec94!='object'||_0x13ec94===null)return!0x1;for(const _0x18a73f of _0x456013)if(_0x18a73f in _0x13ec94&&typeof _0x13ec94[_0x18a73f]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x55d910,_0x3f5cfa){return _0x55d910+'\x20failed:\x20'+_0x3f5cfa+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0xf914a){const _0x42e834=[];let _0x75198f=0x0;for(let _0x598c88=0x0;_0x598c88<_0xf914a['length'];_0x598c88++){let _0x2a3d41=_0xf914a['charCodeAt'](_0x598c88);if(_0x2a3d41>=0xd800&&_0x2a3d41<=0xdbff){const _0x2e4130=_0x2a3d41-0xd800;_0x598c88++,f(_0x598c88<_0xf914a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x449ce4=_0xf914a['charCodeAt'](_0x598c88)-0xdc00;_0x2a3d41=0x10000+(_0x2e4130<<0xa)+_0x449ce4;}_0x2a3d41<0x80?_0x42e834[_0x75198f++]=_0x2a3d41:_0x2a3d41<0x800?(_0x42e834[_0x75198f++]=_0x2a3d41>>0x6|0xc0,_0x42e834[_0x75198f++]=_0x2a3d41&0x3f|0x80):_0x2a3d41<0x10000?(_0x42e834[_0x75198f++]=_0x2a3d41>>0xc|0xe0,_0x42e834[_0x75198f++]=_0x2a3d41>>0x6&0x3f|0x80,_0x42e834[_0x75198f++]=_0x2a3d41&0x3f|0x80):(_0x42e834[_0x75198f++]=_0x2a3d41>>0x12|0xf0,_0x42e834[_0x75198f++]=_0x2a3d41>>0xc&0x3f|0x80,_0x42e834[_0x75198f++]=_0x2a3d41>>0x6&0x3f|0x80,_0x42e834[_0x75198f++]=_0x2a3d41&0x3f|0x80);}return _0x42e834;},Pn=function(_0x532d21){let _0x5b96e8=0x0;for(let _0x2bda97=0x0;_0x2bda97<_0x532d21['length'];_0x2bda97++){const _0x1ffeda=_0x532d21['charCodeAt'](_0x2bda97);_0x1ffeda<0x80?_0x5b96e8++:_0x1ffeda<0x800?_0x5b96e8+=0x2:_0x1ffeda>=0xd800&&_0x1ffeda<=0xdbff?(_0x5b96e8+=0x4,_0x2bda97++):_0x5b96e8+=0x3;}return _0x5b96e8;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x28f1a9){return _0x28f1a9&&_0x28f1a9['_delegate']?_0x28f1a9['_delegate']:_0x28f1a9;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x55fc81){try{return(_0x55fc81['startsWith']('http://')||_0x55fc81['startsWith']('https://')?new URL(_0x55fc81)['hostname']:_0x55fc81)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4fb2b0){return(await fetch(_0x4fb2b0,{'credentials':'include'}))['ok'];}class Me{constructor(_0x3e321b,_0x12073a,_0x351b87){this['name']=_0x3e321b,this['instanceFactory']=_0x12073a,this['type']=_0x351b87,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x202779){return this['instantiationMode']=_0x202779,this;}['setMultipleInstances'](_0xbe61ad){return this['multipleInstances']=_0xbe61ad,this;}['setServiceProps'](_0x1be360){return this['serviceProps']=_0x1be360,this;}['setInstanceCreatedCallback'](_0x5cd4f9){return this['onInstanceCreated']=_0x5cd4f9,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x24ebcf,_0x5a1c78){this['name']=_0x24ebcf,this['container']=_0x5a1c78,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x41f8c5){const _0x5b3052=this['normalizeInstanceIdentifier'](_0x41f8c5);if(!this['instancesDeferred']['has'](_0x5b3052)){const _0x4830ce=new Ve();if(this['instancesDeferred']['set'](_0x5b3052,_0x4830ce),this['isInitialized'](_0x5b3052)||this['shouldAutoInitialize']())try{const _0x57279c=this['getOrInitializeService']({'instanceIdentifier':_0x5b3052});_0x57279c&&_0x4830ce['resolve'](_0x57279c);}catch{}}return this['instancesDeferred']['get'](_0x5b3052)['promise'];}['getImmediate'](_0x254b59){const _0x44a1b5=this['normalizeInstanceIdentifier'](_0x254b59==null?void 0x0:_0x254b59['identifier']),_0x54d219=(_0x254b59==null?void 0x0:_0x254b59['optional'])??!0x1;if(this['isInitialized'](_0x44a1b5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x44a1b5});}catch(_0x49bbe5){if(_0x54d219)return null;throw _0x49bbe5;}else{if(_0x54d219)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x978d0f){if(_0x978d0f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x978d0f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x978d0f,!!this['shouldAutoInitialize']()){if(Rc(_0x978d0f))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1d20d1,_0x19d2fb]of this['instancesDeferred']['entries']()){const _0xcb4ed7=this['normalizeInstanceIdentifier'](_0x1d20d1);try{const _0x1d1c96=this['getOrInitializeService']({'instanceIdentifier':_0xcb4ed7});_0x19d2fb['resolve'](_0x1d1c96);}catch{}}}}['clearInstance'](_0x38d349=ke){this['instancesDeferred']['delete'](_0x38d349),this['instancesOptions']['delete'](_0x38d349),this['instances']['delete'](_0x38d349);}async['delete'](){const _0x20e2ce=Array['from'](this['instances']['values']());await Promise['all']([..._0x20e2ce['filter'](_0x388a5e=>'INTERNAL'in _0x388a5e)['map'](_0x8b15df=>_0x8b15df['INTERNAL']['delete']()),..._0x20e2ce['filter'](_0x18dfa0=>'_delete'in _0x18dfa0)['map'](_0xba7e02=>_0xba7e02['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x19bd31=ke){return this['instances']['has'](_0x19bd31);}['getOptions'](_0x268696=ke){return this['instancesOptions']['get'](_0x268696)||{};}['initialize'](_0x45f5e1={}){const {options:_0x24daf7={}}=_0x45f5e1,_0x54e98d=this['normalizeInstanceIdentifier'](_0x45f5e1['instanceIdentifier']);if(this['isInitialized'](_0x54e98d))throw Error(this['name']+'('+_0x54e98d+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2c89cb=this['getOrInitializeService']({'instanceIdentifier':_0x54e98d,'options':_0x24daf7});for(const [_0x2f99ad,_0x31aa83]of this['instancesDeferred']['entries']()){const _0x21c665=this['normalizeInstanceIdentifier'](_0x2f99ad);_0x54e98d===_0x21c665&&_0x31aa83['resolve'](_0x2c89cb);}return _0x2c89cb;}['onInit'](_0x38e208,_0x5c195c){const _0x4209c6=this['normalizeInstanceIdentifier'](_0x5c195c),_0x55ebbc=this['onInitCallbacks']['get'](_0x4209c6)??new Set();_0x55ebbc['add'](_0x38e208),this['onInitCallbacks']['set'](_0x4209c6,_0x55ebbc);const _0x217a1e=this['instances']['get'](_0x4209c6);return _0x217a1e&&_0x38e208(_0x217a1e,_0x4209c6),()=>{_0x55ebbc['delete'](_0x38e208);};}['invokeOnInitCallbacks'](_0x5cf3da,_0x5a7a1c){const _0x5eed48=this['onInitCallbacks']['get'](_0x5a7a1c);if(_0x5eed48){for(const _0x1898bb of _0x5eed48)try{_0x1898bb(_0x5cf3da,_0x5a7a1c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xf89a36,options:_0x3985c7={}}){let _0x47e9fd=this['instances']['get'](_0xf89a36);if(!_0x47e9fd&&this['component']&&(_0x47e9fd=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xf89a36),'options':_0x3985c7}),this['instances']['set'](_0xf89a36,_0x47e9fd),this['instancesOptions']['set'](_0xf89a36,_0x3985c7),this['invokeOnInitCallbacks'](_0x47e9fd,_0xf89a36),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xf89a36,_0x47e9fd);}catch{}return _0x47e9fd||null;}['normalizeInstanceIdentifier'](_0x2a367f=ke){return this['component']?this['component']['multipleInstances']?_0x2a367f:ke:_0x2a367f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x27136f){return _0x27136f===ke?void 0x0:_0x27136f;}function Rc(_0x406f61){return _0x406f61['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2033e8){this['name']=_0x2033e8,this['providers']=new Map();}['addComponent'](_0x12321f){const _0x3b0c5f=this['getProvider'](_0x12321f['name']);if(_0x3b0c5f['isComponentSet']())throw new Error('Component\x20'+_0x12321f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3b0c5f['setComponent'](_0x12321f);}['addOrOverwriteComponent'](_0x5db2a3){this['getProvider'](_0x5db2a3['name'])['isComponentSet']()&&this['providers']['delete'](_0x5db2a3['name']),this['addComponent'](_0x5db2a3);}['getProvider'](_0x5b7a4b){if(this['providers']['has'](_0x5b7a4b))return this['providers']['get'](_0x5b7a4b);const _0x150079=new Sc(_0x5b7a4b,this);return this['providers']['set'](_0x5b7a4b,_0x150079),_0x150079;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x423e73){_0x423e73[_0x423e73['DEBUG']=0x0]='DEBUG',_0x423e73[_0x423e73['VERBOSE']=0x1]='VERBOSE',_0x423e73[_0x423e73['INFO']=0x2]='INFO',_0x423e73[_0x423e73['WARN']=0x3]='WARN',_0x423e73[_0x423e73['ERROR']=0x4]='ERROR',_0x423e73[_0x423e73['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x67f3d7,_0x3594a7,..._0x13752b)=>{if(_0x3594a7<_0x67f3d7['logLevel'])return;const _0x36499b=new Date()['toISOString'](),_0x393e7d=Pc[_0x3594a7];if(_0x393e7d)console[_0x393e7d]('['+_0x36499b+']\x20\x20'+_0x67f3d7['name']+':',..._0x13752b);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3594a7+')');};class xi{constructor(_0xae2818){this['name']=_0xae2818,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5a7421){if(!(_0x5a7421 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5a7421+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5a7421;}['setLogLevel'](_0x8c6927){this['_logLevel']=typeof _0x8c6927=='string'?kc[_0x8c6927]:_0x8c6927;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x766af5){if(typeof _0x766af5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x766af5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1ee7b1){this['_userLogHandler']=_0x1ee7b1;}['debug'](..._0xb26646){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xb26646),this['_logHandler'](this,T['DEBUG'],..._0xb26646);}['log'](..._0x126b79){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x126b79),this['_logHandler'](this,T['VERBOSE'],..._0x126b79);}['info'](..._0x31e441){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x31e441),this['_logHandler'](this,T['INFO'],..._0x31e441);}['warn'](..._0x4a5631){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4a5631),this['_logHandler'](this,T['WARN'],..._0x4a5631);}['error'](..._0x479c07){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x479c07),this['_logHandler'](this,T['ERROR'],..._0x479c07);}}const Dc=(_0x37662f,_0x5c56ca)=>_0x5c56ca['some'](_0x57f9e6=>_0x37662f instanceof _0x57f9e6);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x37d013){const _0x22a44c=new Promise((_0x5f1546,_0x13e44a)=>{const _0x2aa62c=()=>{_0x37d013['removeEventListener']('success',_0x58fefa),_0x37d013['removeEventListener']('error',_0x1708d0);},_0x58fefa=()=>{_0x5f1546(_e(_0x37d013['result'])),_0x2aa62c();},_0x1708d0=()=>{_0x13e44a(_0x37d013['error']),_0x2aa62c();};_0x37d013['addEventListener']('success',_0x58fefa),_0x37d013['addEventListener']('error',_0x1708d0);});return _0x22a44c['then'](_0x41c245=>{_0x41c245 instanceof IDBCursor&&Kr['set'](_0x41c245,_0x37d013);})['catch'](()=>{}),Fi['set'](_0x22a44c,_0x37d013),_0x22a44c;}function Fc(_0x1f69a4){if(ui['has'](_0x1f69a4))return;const _0x48399a=new Promise((_0x3509ac,_0x43b635)=>{const _0x3dc4f4=()=>{_0x1f69a4['removeEventListener']('complete',_0x1adfe9),_0x1f69a4['removeEventListener']('error',_0x42a19e),_0x1f69a4['removeEventListener']('abort',_0x42a19e);},_0x1adfe9=()=>{_0x3509ac(),_0x3dc4f4();},_0x42a19e=()=>{_0x43b635(_0x1f69a4['error']||new DOMException('AbortError','AbortError')),_0x3dc4f4();};_0x1f69a4['addEventListener']('complete',_0x1adfe9),_0x1f69a4['addEventListener']('error',_0x42a19e),_0x1f69a4['addEventListener']('abort',_0x42a19e);});ui['set'](_0x1f69a4,_0x48399a);}let di={'get'(_0x453bd,_0xcd303a,_0x3e4d15){if(_0x453bd instanceof IDBTransaction){if(_0xcd303a==='done')return ui['get'](_0x453bd);if(_0xcd303a==='objectStoreNames')return _0x453bd['objectStoreNames']||Yr['get'](_0x453bd);if(_0xcd303a==='store')return _0x3e4d15['objectStoreNames'][0x1]?void 0x0:_0x3e4d15['objectStore'](_0x3e4d15['objectStoreNames'][0x0]);}return _e(_0x453bd[_0xcd303a]);},'set'(_0x3edc05,_0x38bcd1,_0x395d3f){return _0x3edc05[_0x38bcd1]=_0x395d3f,!0x0;},'has'(_0x58ea70,_0x10ee09){return _0x58ea70 instanceof IDBTransaction&&(_0x10ee09==='done'||_0x10ee09==='store')?!0x0:_0x10ee09 in _0x58ea70;}};function Uc(_0xe01a34){di=_0xe01a34(di);}function Wc(_0x185214){return _0x185214===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2302da,..._0x4bf01f){const _0xfb48=_0x185214['call'](Xn(this),_0x2302da,..._0x4bf01f);return Yr['set'](_0xfb48,_0x2302da['sort']?_0x2302da['sort']():[_0x2302da]),_e(_0xfb48);}:Lc()['includes'](_0x185214)?function(..._0x5e4cc5){return _0x185214['apply'](Xn(this),_0x5e4cc5),_e(Kr['get'](this));}:function(..._0x269dd8){return _e(_0x185214['apply'](Xn(this),_0x269dd8));};}function Bc(_0x2d8f37){return typeof _0x2d8f37=='function'?Wc(_0x2d8f37):(_0x2d8f37 instanceof IDBTransaction&&Fc(_0x2d8f37),Dc(_0x2d8f37,Mc())?new Proxy(_0x2d8f37,di):_0x2d8f37);}function _e(_0xc9acc6){if(_0xc9acc6 instanceof IDBRequest)return xc(_0xc9acc6);if(Jn['has'](_0xc9acc6))return Jn['get'](_0xc9acc6);const _0xd85b51=Bc(_0xc9acc6);return _0xd85b51!==_0xc9acc6&&(Jn['set'](_0xc9acc6,_0xd85b51),Fi['set'](_0xd85b51,_0xc9acc6)),_0xd85b51;}const Xn=_0x24cace=>Fi['get'](_0x24cace);function Vc(_0x309dda,_0x279d05,{blocked:_0x57ba0a,upgrade:_0x37dbe9,blocking:_0x8f2fe0,terminated:_0x11c66f}={}){const _0x14886a=indexedDB['open'](_0x309dda,_0x279d05),_0x16327a=_e(_0x14886a);return _0x37dbe9&&_0x14886a['addEventListener']('upgradeneeded',_0x44cacb=>{_0x37dbe9(_e(_0x14886a['result']),_0x44cacb['oldVersion'],_0x44cacb['newVersion'],_e(_0x14886a['transaction']),_0x44cacb);}),_0x57ba0a&&_0x14886a['addEventListener']('blocked',_0xc95dbc=>_0x57ba0a(_0xc95dbc['oldVersion'],_0xc95dbc['newVersion'],_0xc95dbc)),_0x16327a['then'](_0x27df56=>{_0x11c66f&&_0x27df56['addEventListener']('close',()=>_0x11c66f()),_0x8f2fe0&&_0x27df56['addEventListener']('versionchange',_0x1ba997=>_0x8f2fe0(_0x1ba997['oldVersion'],_0x1ba997['newVersion'],_0x1ba997));})['catch'](()=>{}),_0x16327a;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1544f7,_0x28e0f4){if(!(_0x1544f7 instanceof IDBDatabase&&!(_0x28e0f4 in _0x1544f7)&&typeof _0x28e0f4=='string'))return;if(Zn['get'](_0x28e0f4))return Zn['get'](_0x28e0f4);const _0x5dedb8=_0x28e0f4['replace'](/FromIndex$/,''),_0x5d8650=_0x28e0f4!==_0x5dedb8,_0x2dc043=$c['includes'](_0x5dedb8);if(!(_0x5dedb8 in(_0x5d8650?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2dc043||Hc['includes'](_0x5dedb8)))return;const _0x4de0bb=async function(_0x38be19,..._0x5c8463){const _0x4fcd02=this['transaction'](_0x38be19,_0x2dc043?'readwrite':'readonly');let _0x2ff593=_0x4fcd02['store'];return _0x5d8650&&(_0x2ff593=_0x2ff593['index'](_0x5c8463['shift']())),(await Promise['all']([_0x2ff593[_0x5dedb8](..._0x5c8463),_0x2dc043&&_0x4fcd02['done']]))[0x0];};return Zn['set'](_0x28e0f4,_0x4de0bb),_0x4de0bb;}Uc(_0x1ddd1f=>({..._0x1ddd1f,'get':(_0x20816e,_0x2a9b05,_0x3efb7c)=>Os(_0x20816e,_0x2a9b05)||_0x1ddd1f['get'](_0x20816e,_0x2a9b05,_0x3efb7c),'has':(_0x71fd60,_0x2bbda3)=>!!Os(_0x71fd60,_0x2bbda3)||_0x1ddd1f['has'](_0x71fd60,_0x2bbda3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x58ea6e){this['container']=_0x58ea6e;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x21c980=>{if(qc(_0x21c980)){const _0x5b0b6f=_0x21c980['getImmediate']();return _0x5b0b6f['library']+'/'+_0x5b0b6f['version'];}else return null;})['filter'](_0x3decf7=>_0x3decf7)['join']('\x20');}}function qc(_0xa532f2){const _0xf13b9=_0xa532f2['getComponent']();return(_0xf13b9==null?void 0x0:_0xf13b9['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x48ad29,_0x2a7567){try{_0x48ad29['container']['addComponent'](_0x2a7567);}catch(_0x118ab5){re['debug']('Component\x20'+_0x2a7567['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x48ad29['name'],_0x118ab5);}}function et(_0x51c793){const _0x270303=_0x51c793['name'];if(gi['has'](_0x270303))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x270303+'.'),!0x1;gi['set'](_0x270303,_0x51c793);for(const _0x13593f of Le['values']())Ms(_0x13593f,_0x51c793);for(const _0x293039 of _i['values']())Ms(_0x293039,_0x51c793);return!0x0;}function Ui(_0x3e4b42,_0x400c4d){const _0x462522=_0x3e4b42['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x462522&&_0x462522['triggerHeartbeat'](),_0x3e4b42['container']['getProvider'](_0x400c4d);}function H(_0x41346c){return _0x41346c==null?!0x1:_0x41346c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x534752,_0x4a9aeb,_0xa31871){this['_isDeleted']=!0x1,this['_options']={..._0x534752},this['_config']={..._0x4a9aeb},this['_name']=_0x4a9aeb['name'],this['_automaticDataCollectionEnabled']=_0x4a9aeb['automaticDataCollectionEnabled'],this['_container']=_0xa31871,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x54470f){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x54470f;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3fe66e){this['_isDeleted']=_0x3fe66e;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x564a77,_0x54a51b={}){let _0x4b1b4c=_0x564a77;typeof _0x54a51b!='object'&&(_0x54a51b={'name':_0x54a51b});const _0x32162d={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x54a51b},_0x4dd87e=_0x32162d['name'];if(typeof _0x4dd87e!='string'||!_0x4dd87e)throw ge['create']('bad-app-name',{'appName':String(_0x4dd87e)});if(_0x4b1b4c||(_0x4b1b4c=$r()),!_0x4b1b4c)throw ge['create']('no-options');const _0xfff6a1=Le['get'](_0x4dd87e);if(_0xfff6a1){if(De(_0x4b1b4c,_0xfff6a1['options'])&&De(_0x32162d,_0xfff6a1['config']))return _0xfff6a1;throw ge['create']('duplicate-app',{'appName':_0x4dd87e});}const _0x14d9dd=new Ac(_0x4dd87e);for(const _0x4ee96c of gi['values']())_0x14d9dd['addComponent'](_0x4ee96c);const _0x2a65b6=new Il(_0x4b1b4c,_0x32162d,_0x14d9dd);return Le['set'](_0x4dd87e,_0x2a65b6),_0x2a65b6;}function Qr(_0x945742=pi){const _0x32858d=Le['get'](_0x945742);if(!_0x32858d&&_0x945742===pi&&$r())return wl();if(!_0x32858d)throw ge['create']('no-app',{'appName':_0x945742});return _0x32858d;}function l_(){return Array['from'](Le['values']());}async function h_(_0x2cf0f0){let _0x4f740a=!0x1;const _0x428c94=_0x2cf0f0['name'];Le['has'](_0x428c94)?(_0x4f740a=!0x0,Le['delete'](_0x428c94)):_i['has'](_0x428c94)&&_0x2cf0f0['decRefCount']()<=0x0&&(_i['delete'](_0x428c94),_0x4f740a=!0x0),_0x4f740a&&(await Promise['all'](_0x2cf0f0['container']['getProviders']()['map'](_0x1b7ed0=>_0x1b7ed0['delete']())),_0x2cf0f0['isDeleted']=!0x0);}function me(_0x2781d9,_0x4487fd,_0xce7cf7){let _0x8ebb3f=vl[_0x2781d9]??_0x2781d9;_0xce7cf7&&(_0x8ebb3f+='-'+_0xce7cf7);const _0x11a6f8=_0x8ebb3f['match'](/\s|\//),_0xce0484=_0x4487fd['match'](/\s|\//);if(_0x11a6f8||_0xce0484){const _0x29ce4c=['Unable\x20to\x20register\x20library\x20\x22'+_0x8ebb3f+'\x22\x20with\x20version\x20\x22'+_0x4487fd+'\x22:'];_0x11a6f8&&_0x29ce4c['push']('library\x20name\x20\x22'+_0x8ebb3f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x11a6f8&&_0xce0484&&_0x29ce4c['push']('and'),_0xce0484&&_0x29ce4c['push']('version\x20name\x20\x22'+_0x4487fd+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x29ce4c['join']('\x20'));return;}et(new Me(_0x8ebb3f+'-version',()=>({'library':_0x8ebb3f,'version':_0x4487fd}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x34637b,_0x3167f5)=>{switch(_0x3167f5){case 0x0:try{_0x34637b['createObjectStore'](Rt);}catch(_0x4dafd4){console['warn'](_0x4dafd4);}}}})['catch'](_0x15f6ec=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x15f6ec['message']});})),ei;}async function Sl(_0x12f7c1){try{const _0x488594=(await Jr())['transaction'](Rt),_0xb02c06=await _0x488594['objectStore'](Rt)['get'](Xr(_0x12f7c1));return await _0x488594['done'],_0xb02c06;}catch(_0x51e761){if(_0x51e761 instanceof Se)re['warn'](_0x51e761['message']);else{const _0x4ffff6=ge['create']('idb-get',{'originalErrorMessage':_0x51e761==null?void 0x0:_0x51e761['message']});re['warn'](_0x4ffff6['message']);}}}async function Ls(_0x4852d6,_0x5c8770){try{const _0x17acdf=(await Jr())['transaction'](Rt,'readwrite');await _0x17acdf['objectStore'](Rt)['put'](_0x5c8770,Xr(_0x4852d6)),await _0x17acdf['done'];}catch(_0x48a6a7){if(_0x48a6a7 instanceof Se)re['warn'](_0x48a6a7['message']);else{const _0x587c6d=ge['create']('idb-set',{'originalErrorMessage':_0x48a6a7==null?void 0x0:_0x48a6a7['message']});re['warn'](_0x587c6d['message']);}}}function Xr(_0x177d0f){return _0x177d0f['name']+'!'+_0x177d0f['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x22f697){this['container']=_0x22f697,this['_heartbeatsCache']=null;const _0x5d6464=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5d6464),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x333c24=>(this['_heartbeatsCache']=_0x333c24,_0x333c24));}async['triggerHeartbeat'](){var _0x542b5f,_0x55f15f;try{const _0x5a59de=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x347b82=xs();if(((_0x542b5f=this['_heartbeatsCache'])==null?void 0x0:_0x542b5f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x55f15f=this['_heartbeatsCache'])==null?void 0x0:_0x55f15f['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x347b82||this['_heartbeatsCache']['heartbeats']['some'](_0x54b668=>_0x54b668['date']===_0x347b82))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x347b82,'agent':_0x5a59de}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x17d210=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x17d210,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5f573f){re['warn'](_0x5f573f);}}async['getHeartbeatsHeader'](){var _0xdc8e6f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xdc8e6f=this['_heartbeatsCache'])==null?void 0x0:_0xdc8e6f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5d28f7=xs(),{heartbeatsToSend:_0x5c29fd,unsentEntries:_0x836c8c}=kl(this['_heartbeatsCache']['heartbeats']),_0xdce8cf=an(JSON['stringify']({'version':0x2,'heartbeats':_0x5c29fd}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5d28f7,_0x836c8c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x836c8c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xdce8cf;}catch(_0x258893){return re['warn'](_0x258893),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x343c69,_0x3da1ec=bl){const _0x524956=[];let _0x13b0f5=_0x343c69['slice']();for(const _0x23986b of _0x343c69){const _0x262552=_0x524956['find'](_0x322325=>_0x322325['agent']===_0x23986b['agent']);if(_0x262552){if(_0x262552['dates']['push'](_0x23986b['date']),Fs(_0x524956)>_0x3da1ec){_0x262552['dates']['pop']();break;}}else{if(_0x524956['push']({'agent':_0x23986b['agent'],'dates':[_0x23986b['date']]}),Fs(_0x524956)>_0x3da1ec){_0x524956['pop']();break;}}_0x13b0f5=_0x13b0f5['slice'](0x1);}return{'heartbeatsToSend':_0x524956,'unsentEntries':_0x13b0f5};}class Nl{constructor(_0x37a6c7){this['app']=_0x37a6c7,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4d7628=await Sl(this['app']);return _0x4d7628!=null&&_0x4d7628['heartbeats']?_0x4d7628:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5413b9){if(await this['_canUseIndexedDBPromise']){const _0x35a1fb=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5413b9['lastSentHeartbeatDate']??_0x35a1fb['lastSentHeartbeatDate'],'heartbeats':_0x5413b9['heartbeats']});}else return;}async['add'](_0x878f8){if(await this['_canUseIndexedDBPromise']){const _0x3b7005=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x878f8['lastSentHeartbeatDate']??_0x3b7005['lastSentHeartbeatDate'],'heartbeats':[..._0x3b7005['heartbeats'],..._0x878f8['heartbeats']]});}else return;}}function Fs(_0x54f108){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x54f108}))['length'];}function Pl(_0x530888){if(_0x530888['length']===0x0)return-0x1;let _0xdf02f7=0x0,_0x4edee1=_0x530888[0x0]['date'];for(let _0x2e1062=0x1;_0x2e1062<_0x530888['length'];_0x2e1062++)_0x530888[_0x2e1062]['date']<_0x4edee1&&(_0x4edee1=_0x530888[_0x2e1062]['date'],_0xdf02f7=_0x2e1062);return _0xdf02f7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x1325b8){et(new Me('platform-logger',_0x3eae28=>new Gc(_0x3eae28),'PRIVATE')),et(new Me('heartbeat',_0x1ee245=>new Al(_0x1ee245),'PRIVATE')),me(fi,Ds,_0x1325b8),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x4ae331){Zr=_0x4ae331;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x434a69){this['domStorage_']=_0x434a69,this['prefix_']='firebase:';}['set'](_0x181ab5,_0x543467){_0x543467==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x181ab5)):this['domStorage_']['setItem'](this['prefixedName_'](_0x181ab5),O(_0x543467));}['get'](_0x35927b){const _0x73dd22=this['domStorage_']['getItem'](this['prefixedName_'](_0x35927b));return _0x73dd22==null?null:bt(_0x73dd22);}['remove'](_0xfce539){this['domStorage_']['removeItem'](this['prefixedName_'](_0xfce539));}['prefixedName_'](_0xb310c9){return this['prefix_']+_0xb310c9;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x202e7a,_0x4da249){_0x4da249==null?delete this['cache_'][_0x202e7a]:this['cache_'][_0x202e7a]=_0x4da249;}['get'](_0x54fc84){return Y(this['cache_'],_0x54fc84)?this['cache_'][_0x54fc84]:null;}['remove'](_0x587f59){delete this['cache_'][_0x587f59];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x1834d7){try{if(typeof window<'u'&&typeof window[_0x1834d7]<'u'){const _0xa3235a=window[_0x1834d7];return _0xa3235a['setItem']('firebase:sentinel','cache'),_0xa3235a['removeItem']('firebase:sentinel'),new xl(_0xa3235a);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x22eea5=0x1;return function(){return _0x22eea5++;};}()),no=function(_0x1211c4){const _0x798bb0=Tc(_0x1211c4),_0x1f755e=new Ec();_0x1f755e['update'](_0x798bb0);const _0x5dd445=_0x1f755e['digest']();return Di['encodeByteArray'](_0x5dd445);},Bt=function(..._0x4508ff){let _0x236a57='';for(let _0x1f21af=0x0;_0x1f21af<_0x4508ff['length'];_0x1f21af++){const _0xc15344=_0x4508ff[_0x1f21af];Array['isArray'](_0xc15344)||_0xc15344&&typeof _0xc15344=='object'&&typeof _0xc15344['length']=='number'?_0x236a57+=Bt['apply'](null,_0xc15344):typeof _0xc15344=='object'?_0x236a57+=O(_0xc15344):_0x236a57+=_0xc15344,_0x236a57+='\x20';}return _0x236a57;};let Et=null,Vs=!0x0;const Wl=function(_0x4d6401,_0x1dba53){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x4c1c2d){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x5d4f03=Bt['apply'](null,_0x4c1c2d);Et(_0x5d4f03);}},Vt=function(_0x2826e3){return function(..._0x2d59eb){L(_0x2826e3,..._0x2d59eb);};},mi=function(..._0x485ba2){const _0x1a910c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x485ba2);Qe['error'](_0x1a910c);},oe=function(..._0xc2cf42){const _0x26a67d='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0xc2cf42);throw Qe['error'](_0x26a67d),new Error(_0x26a67d);},U=function(..._0x4970e0){const _0x4d7df1='FIREBASE\x20WARNING:\x20'+Bt(..._0x4970e0);Qe['warn'](_0x4d7df1);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0xeedf1e){return typeof _0xeedf1e=='number'&&(_0xeedf1e!==_0xeedf1e||_0xeedf1e===Number['POSITIVE_INFINITY']||_0xeedf1e===Number['NEGATIVE_INFINITY']);},Vl=function(_0x3ed4a1){if(document['readyState']==='complete')_0x3ed4a1();else{let _0xb07e24=!0x1;const _0x7d9c09=function(){if(!document['body']){setTimeout(_0x7d9c09,Math['floor'](0xa));return;}_0xb07e24||(_0xb07e24=!0x0,_0x3ed4a1());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x7d9c09,!0x1),window['addEventListener']('load',_0x7d9c09,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x7d9c09();}),window['attachEvent']('onload',_0x7d9c09));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x73464a,_0x5767c9){if(_0x73464a===_0x5767c9)return 0x0;if(_0x73464a===xe||_0x5767c9===Ie)return-0x1;if(_0x5767c9===xe||_0x73464a===Ie)return 0x1;{const _0xeeb0c0=Hs(_0x73464a),_0x212fd6=Hs(_0x5767c9);return _0xeeb0c0!==null?_0x212fd6!==null?_0xeeb0c0-_0x212fd6===0x0?_0x73464a['length']-_0x5767c9['length']:_0xeeb0c0-_0x212fd6:-0x1:_0x212fd6!==null?0x1:_0x73464a<_0x5767c9?-0x1:0x1;}},Hl=function(_0xa22462,_0x10186b){return _0xa22462===_0x10186b?0x0:_0xa22462<_0x10186b?-0x1:0x1;},pt=function(_0x22ac0d,_0x638dcc){if(_0x638dcc&&_0x22ac0d in _0x638dcc)return _0x638dcc[_0x22ac0d];throw new Error('Missing\x20required\x20key\x20('+_0x22ac0d+')\x20in\x20object:\x20'+O(_0x638dcc));},Bi=function(_0x3b83bc){if(typeof _0x3b83bc!='object'||_0x3b83bc===null)return O(_0x3b83bc);const _0x1cd20f=[];for(const _0x24cb1a in _0x3b83bc)_0x1cd20f['push'](_0x24cb1a);_0x1cd20f['sort']();let _0x11f544='{';for(let _0xe3d00c=0x0;_0xe3d00c<_0x1cd20f['length'];_0xe3d00c++)_0xe3d00c!==0x0&&(_0x11f544+=','),_0x11f544+=O(_0x1cd20f[_0xe3d00c]),_0x11f544+=':',_0x11f544+=Bi(_0x3b83bc[_0x1cd20f[_0xe3d00c]]);return _0x11f544+='}',_0x11f544;},io=function(_0x19cc22,_0x45333b){const _0x48b18e=_0x19cc22['length'];if(_0x48b18e<=_0x45333b)return[_0x19cc22];const _0x4aabc1=[];for(let _0x4a7de4=0x0;_0x4a7de4<_0x48b18e;_0x4a7de4+=_0x45333b)_0x4a7de4+_0x45333b>_0x48b18e?_0x4aabc1['push'](_0x19cc22['substring'](_0x4a7de4,_0x48b18e)):_0x4aabc1['push'](_0x19cc22['substring'](_0x4a7de4,_0x4a7de4+_0x45333b));return _0x4aabc1;};function x(_0x52dbb0,_0x23ff99){for(const _0x3d6b94 in _0x52dbb0)_0x52dbb0['hasOwnProperty'](_0x3d6b94)&&_0x23ff99(_0x3d6b94,_0x52dbb0[_0x3d6b94]);}const so=function(_0xe6a853){f(!Wi(_0xe6a853),'Invalid\x20JSON\x20number');const _0x32f6ad=0xb,_0x568b8f=0x34,_0x24d45f=(0x1<<_0x32f6ad-0x1)-0x1;let _0x279611,_0x1d6fee,_0x51cdbe,_0x15fe3a,_0x50302e;_0xe6a853===0x0?(_0x1d6fee=0x0,_0x51cdbe=0x0,_0x279611=0x1/_0xe6a853===-0x1/0x0?0x1:0x0):(_0x279611=_0xe6a853<0x0,_0xe6a853=Math['abs'](_0xe6a853),_0xe6a853>=Math['pow'](0x2,0x1-_0x24d45f)?(_0x15fe3a=Math['min'](Math['floor'](Math['log'](_0xe6a853)/Math['LN2']),_0x24d45f),_0x1d6fee=_0x15fe3a+_0x24d45f,_0x51cdbe=Math['round'](_0xe6a853*Math['pow'](0x2,_0x568b8f-_0x15fe3a)-Math['pow'](0x2,_0x568b8f))):(_0x1d6fee=0x0,_0x51cdbe=Math['round'](_0xe6a853/Math['pow'](0x2,0x1-_0x24d45f-_0x568b8f))));const _0x189cb8=[];for(_0x50302e=_0x568b8f;_0x50302e;_0x50302e-=0x1)_0x189cb8['push'](_0x51cdbe%0x2?0x1:0x0),_0x51cdbe=Math['floor'](_0x51cdbe/0x2);for(_0x50302e=_0x32f6ad;_0x50302e;_0x50302e-=0x1)_0x189cb8['push'](_0x1d6fee%0x2?0x1:0x0),_0x1d6fee=Math['floor'](_0x1d6fee/0x2);_0x189cb8['push'](_0x279611?0x1:0x0),_0x189cb8['reverse']();const _0x2d1697=_0x189cb8['join']('');let _0xc4bb3c='';for(_0x50302e=0x0;_0x50302e<0x40;_0x50302e+=0x8){let _0x3c366a=parseInt(_0x2d1697['substr'](_0x50302e,0x8),0x2)['toString'](0x10);_0x3c366a['length']===0x1&&(_0x3c366a='0'+_0x3c366a),_0xc4bb3c=_0xc4bb3c+_0x3c366a;}return _0xc4bb3c['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x490ab3,_0x49db5f){let _0x5c87ef='Unknown\x20Error';_0x490ab3==='too_big'?_0x5c87ef='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x490ab3==='permission_denied'?_0x5c87ef='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x490ab3==='unavailable'&&(_0x5c87ef='The\x20service\x20is\x20unavailable');const _0x3f975e=new Error(_0x490ab3+'\x20at\x20'+_0x49db5f['_path']['toString']()+':\x20'+_0x5c87ef);return _0x3f975e['code']=_0x490ab3['toUpperCase'](),_0x3f975e;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2efb4a){if(zl['test'](_0x2efb4a)){const _0x4e4a49=Number(_0x2efb4a);if(_0x4e4a49>=jl&&_0x4e4a49<=Kl)return _0x4e4a49;}return null;},lt=function(_0x297c6e){try{_0x297c6e();}catch(_0x31a00f){setTimeout(()=>{const _0x254efd=_0x31a00f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x254efd),_0x31a00f;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3217ee,_0x4e8a62){const _0x3c209a=setTimeout(_0x3217ee,_0x4e8a62);return typeof _0x3c209a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3c209a):typeof _0x3c209a=='object'&&_0x3c209a['unref']&&_0x3c209a['unref'](),_0x3c209a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xa4fb84,_0xbbeb53){this['appCheckProvider']=_0xbbeb53,this['appName']=_0xa4fb84['name'],H(_0xa4fb84)&&_0xa4fb84['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xa4fb84['settings']['appCheckToken']),this['appCheck']=_0xbbeb53==null?void 0x0:_0xbbeb53['getImmediate']({'optional':!0x0}),this['appCheck']||_0xbbeb53==null||_0xbbeb53['get']()['then'](_0x315bf2=>this['appCheck']=_0x315bf2);}['getToken'](_0x2a8704){if(this['serverAppAppCheckToken']){if(_0x2a8704)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2a8704):new Promise((_0x3dac96,_0x3278d0)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2a8704)['then'](_0x3dac96,_0x3278d0):_0x3dac96(null);},0x0);});}['addTokenChangeListener'](_0x30ccb2){var _0x5e834b;(_0x5e834b=this['appCheckProvider'])==null||_0x5e834b['get']()['then'](_0x345a90=>_0x345a90['addTokenListener'](_0x30ccb2));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1e7c86,_0x2af603,_0x59e7bd){this['appName_']=_0x1e7c86,this['firebaseOptions_']=_0x2af603,this['authProvider_']=_0x59e7bd,this['auth_']=null,this['auth_']=_0x59e7bd['getImmediate']({'optional':!0x0}),this['auth_']||_0x59e7bd['onInit'](_0x26ac00=>this['auth_']=_0x26ac00);}['getToken'](_0xbf216){return this['auth_']?this['auth_']['getToken'](_0xbf216)['catch'](_0x5d8fb9=>_0x5d8fb9&&_0x5d8fb9['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5d8fb9)):new Promise((_0x281f95,_0x4d054b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xbf216)['then'](_0x281f95,_0x4d054b):_0x281f95(null);},0x0);});}['addTokenChangeListener'](_0x349f90){this['auth_']?this['auth_']['addAuthTokenListener'](_0x349f90):this['authProvider_']['get']()['then'](_0x51415f=>_0x51415f['addAuthTokenListener'](_0x349f90));}['removeTokenChangeListener'](_0x1b2dcb){this['authProvider_']['get']()['then'](_0x57e157=>_0x57e157['removeAuthTokenListener'](_0x1b2dcb));}['notifyForInvalidToken'](){let _0x3b7d05='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3b7d05+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3b7d05+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3b7d05+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3b7d05);}}class tn{constructor(_0x48cae6){this['accessToken']=_0x48cae6;}['getToken'](_0x442525){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x9b8551){_0x9b8551(this['accessToken']);}['removeTokenChangeListener'](_0x2009dd){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x3f572b,_0x524bbb,_0x485163,_0x10e2c6,_0xe18c08=!0x1,_0x4a1cac='',_0x5d3fe6=!0x1,_0x4ef410=!0x1,_0x34f20f=null){this['secure']=_0x524bbb,this['namespace']=_0x485163,this['webSocketOnly']=_0x10e2c6,this['nodeAdmin']=_0xe18c08,this['persistenceKey']=_0x4a1cac,this['includeNamespaceInQueryParams']=_0x5d3fe6,this['isUsingEmulator']=_0x4ef410,this['emulatorOptions']=_0x34f20f,this['_host']=_0x3f572b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x3f572b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xe65e59){_0xe65e59!==this['internalHost']&&(this['internalHost']=_0xe65e59,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x365c78=this['toURLString']();return this['persistenceKey']&&(_0x365c78+='<'+this['persistenceKey']+'>'),_0x365c78;}['toURLString'](){const _0x1f39e0=this['secure']?'https://':'http://',_0xddc6aa=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1f39e0+this['host']+'/'+_0xddc6aa;}}function Xl(_0x46afe8){return _0x46afe8['host']!==_0x46afe8['internalHost']||_0x46afe8['isCustomHost']()||_0x46afe8['includeNamespaceInQueryParams'];}function go(_0x20673e,_0x1b4e7f,_0x373176){f(typeof _0x1b4e7f=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x373176=='object','typeof\x20params\x20must\x20==\x20object');let _0x24a2d1;if(_0x1b4e7f===fo)_0x24a2d1=(_0x20673e['secure']?'wss://':'ws://')+_0x20673e['internalHost']+'/.ws?';else{if(_0x1b4e7f===po)_0x24a2d1=(_0x20673e['secure']?'https://':'http://')+_0x20673e['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1b4e7f);}Xl(_0x20673e)&&(_0x373176['ns']=_0x20673e['namespace']);const _0x8dbb73=[];return x(_0x373176,(_0x45510a,_0x4c54d0)=>{_0x8dbb73['push'](_0x45510a+'='+_0x4c54d0);}),_0x24a2d1+_0x8dbb73['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x6b536a,_0x401ea2=0x1){Y(this['counters_'],_0x6b536a)||(this['counters_'][_0x6b536a]=0x0),this['counters_'][_0x6b536a]+=_0x401ea2;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x4b871a){const _0x2832e0=_0x4b871a['toString']();return ti[_0x2832e0]||(ti[_0x2832e0]=new Zl()),ti[_0x2832e0];}function eh(_0x59da19,_0x14115b){const _0x58277b=_0x59da19['toString']();return ni[_0x58277b]||(ni[_0x58277b]=_0x14115b()),ni[_0x58277b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2c2b4e){this['onMessage_']=_0x2c2b4e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x27b003,_0x540893){this['closeAfterResponse']=_0x27b003,this['onClose']=_0x540893,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x254fbd,_0x17a70b){for(this['pendingResponses'][_0x254fbd]=_0x17a70b;this['pendingResponses'][this['currentResponseNum']];){const _0x22caf0=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1f074d=0x0;_0x1f074d<_0x22caf0['length'];++_0x1f074d)_0x22caf0[_0x1f074d]&&lt(()=>{this['onMessage_'](_0x22caf0[_0x1f074d]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x4ba5bc,_0x4d00d8,_0x2abaac,_0x2ac521,_0x32969c,_0x32a448,_0x23b1e9){this['connId']=_0x4ba5bc,this['repoInfo']=_0x4d00d8,this['applicationId']=_0x2abaac,this['appCheckToken']=_0x2ac521,this['authToken']=_0x32969c,this['transportSessionId']=_0x32a448,this['lastSessionId']=_0x23b1e9,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x4ba5bc),this['stats_']=Hi(_0x4d00d8),this['urlFn']=_0x1472ab=>(this['appCheckToken']&&(_0x1472ab[yi]=this['appCheckToken']),go(_0x4d00d8,po,_0x1472ab));}['open'](_0x2fe86f,_0x4f4b46){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4f4b46,this['myPacketOrderer']=new th(_0x2fe86f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x49cbbc)=>{const [_0x3635b2,_0x2bbe7f,_0x3707e5,_0x4a1836,_0xb5864e]=_0x49cbbc;if(this['incrementIncomingBytes_'](_0x49cbbc),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3635b2===$s)this['id']=_0x2bbe7f,this['password']=_0x3707e5;else{if(_0x3635b2===nh)_0x2bbe7f?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2bbe7f,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3635b2);}}},(..._0x3c36f0)=>{const [_0x38acbd,_0x2a911d]=_0x3c36f0;this['incrementIncomingBytes_'](_0x3c36f0),this['myPacketOrderer']['handleResponse'](_0x38acbd,_0x2a911d);},()=>{this['onClosed_']();},this['urlFn']);const _0x1ac831={};_0x1ac831[$s]='t',_0x1ac831[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1ac831[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1ac831[ro]=Vi,this['transportSessionId']&&(_0x1ac831[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1ac831[ho]=this['lastSessionId']),this['applicationId']&&(_0x1ac831[uo]=this['applicationId']),this['appCheckToken']&&(_0x1ac831[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1ac831[ao]=co);const _0x4ebf83=this['urlFn'](_0x1ac831);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4ebf83),this['scriptTagHolder']['addTag'](_0x4ebf83,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x233573){const _0xc8fb2d=O(_0x233573);this['bytesSent']+=_0xc8fb2d['length'],this['stats_']['incrementCounter']('bytes_sent',_0xc8fb2d['length']);const _0x2add0d=Br(_0xc8fb2d),_0x51af6b=io(_0x2add0d,hh);for(let _0x484184=0x0;_0x484184<_0x51af6b['length'];_0x484184++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x51af6b['length'],_0x51af6b[_0x484184]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x19ef3a,_0xdb17d5){this['myDisconnFrame']=document['createElement']('iframe');const _0x4bba1a={};_0x4bba1a[lh]='t',_0x4bba1a[mo]=_0x19ef3a,_0x4bba1a[yo]=_0xdb17d5,this['myDisconnFrame']['src']=this['urlFn'](_0x4bba1a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x25a1f2){const _0x1e05b6=O(_0x25a1f2)['length'];this['bytesReceived']+=_0x1e05b6,this['stats_']['incrementCounter']('bytes_received',_0x1e05b6);}}class $i{constructor(_0x182eb3,_0x3e58e6,_0x4f2005,_0x74dfed){this['onDisconnect']=_0x4f2005,this['urlFn']=_0x74dfed,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x182eb3,window[sh+this['uniqueCallbackIdentifier']]=_0x3e58e6,this['myIFrame']=$i['createIFrame_']();let _0x1d061d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1d061d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x523c19='<html><body>'+_0x1d061d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x523c19),this['myIFrame']['doc']['close']();}catch(_0x50f6ca){L('frame\x20writing\x20exception'),_0x50f6ca['stack']&&L(_0x50f6ca['stack']),L(_0x50f6ca);}}}static['createIFrame_'](){const _0x14a4fe=document['createElement']('iframe');if(_0x14a4fe['style']['display']='none',document['body']){document['body']['appendChild'](_0x14a4fe);try{_0x14a4fe['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x519d7e=document['domain'];_0x14a4fe['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x519d7e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x14a4fe['contentDocument']?_0x14a4fe['doc']=_0x14a4fe['contentDocument']:_0x14a4fe['contentWindow']?_0x14a4fe['doc']=_0x14a4fe['contentWindow']['document']:_0x14a4fe['document']&&(_0x14a4fe['doc']=_0x14a4fe['document']),_0x14a4fe;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2f9a43=this['onDisconnect'];_0x2f9a43&&(this['onDisconnect']=null,_0x2f9a43());}['startLongPoll'](_0x2e695e,_0x4fc9a2){for(this['myID']=_0x2e695e,this['myPW']=_0x4fc9a2,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x30b988={};_0x30b988[mo]=this['myID'],_0x30b988[yo]=this['myPW'],_0x30b988[vo]=this['currentSerial'];let _0xaaa558=this['urlFn'](_0x30b988),_0x287173='',_0x3d9919=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x287173['length']<=Eo;){const _0x1615ba=this['pendingSegs']['shift']();_0x287173=_0x287173+'&'+oh+_0x3d9919+'='+_0x1615ba['seg']+'&'+ah+_0x3d9919+'='+_0x1615ba['ts']+'&'+ch+_0x3d9919+'='+_0x1615ba['d'],_0x3d9919++;}return _0xaaa558=_0xaaa558+_0x287173,this['addLongPollTag_'](_0xaaa558,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1a006a,_0x228006,_0x28f6ca){this['pendingSegs']['push']({'seg':_0x1a006a,'ts':_0x228006,'d':_0x28f6ca}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x290bc8,_0x563e2b){this['outstandingRequests']['add'](_0x563e2b);const _0x1c4077=()=>{this['outstandingRequests']['delete'](_0x563e2b),this['newRequest_']();},_0x148b54=setTimeout(_0x1c4077,Math['floor'](uh)),_0x2f5821=()=>{clearTimeout(_0x148b54),_0x1c4077();};this['addTag'](_0x290bc8,_0x2f5821);}['addTag'](_0x3c41fb,_0x3ea3ec){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x25940c=this['myIFrame']['doc']['createElement']('script');_0x25940c['type']='text/javascript',_0x25940c['async']=!0x0,_0x25940c['src']=_0x3c41fb,_0x25940c['onload']=_0x25940c['onreadystatechange']=function(){const _0x2f8efc=_0x25940c['readyState'];(!_0x2f8efc||_0x2f8efc==='loaded'||_0x2f8efc==='complete')&&(_0x25940c['onload']=_0x25940c['onreadystatechange']=null,_0x25940c['parentNode']&&_0x25940c['parentNode']['removeChild'](_0x25940c),_0x3ea3ec());},_0x25940c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3c41fb),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x25940c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x4b3ca5,_0x2d8317,_0x2838bc,_0x5b2015,_0x413f5f,_0x377596,_0x465659){this['connId']=_0x4b3ca5,this['applicationId']=_0x2838bc,this['appCheckToken']=_0x5b2015,this['authToken']=_0x413f5f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x2d8317),this['connURL']=G['connectionURL_'](_0x2d8317,_0x377596,_0x465659,_0x5b2015,_0x2838bc),this['nodeAdmin']=_0x2d8317['nodeAdmin'];}static['connectionURL_'](_0x27871b,_0x3791f8,_0x3d3757,_0x321b1d,_0x178933){const _0x2009dc={};return _0x2009dc[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2009dc[ao]=co),_0x3791f8&&(_0x2009dc[oo]=_0x3791f8),_0x3d3757&&(_0x2009dc[ho]=_0x3d3757),_0x321b1d&&(_0x2009dc[yi]=_0x321b1d),_0x178933&&(_0x2009dc[uo]=_0x178933),go(_0x27871b,fo,_0x2009dc);}['open'](_0x48ccab,_0x13f63a){this['onDisconnect']=_0x13f63a,this['onMessage']=_0x48ccab,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1e0e17;dc(),this['mySock']=new hn(this['connURL'],[],_0x1e0e17);}catch(_0x24c7f9){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x84ccce=_0x24c7f9['message']||_0x24c7f9['data'];_0x84ccce&&this['log_'](_0x84ccce),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3ef1a2=>{this['handleIncomingFrame'](_0x3ef1a2);},this['mySock']['onerror']=_0x5bd0a8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5568fb=_0x5bd0a8['message']||_0x5bd0a8['data'];_0x5568fb&&this['log_'](_0x5568fb),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x329450=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3b51bb=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xb76472=navigator['userAgent']['match'](_0x3b51bb);_0xb76472&&_0xb76472['length']>0x1&&parseFloat(_0xb76472[0x1])<4.4&&(_0x329450=!0x0);}return!_0x329450&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x361648){if(this['frames']['push'](_0x361648),this['frames']['length']===this['totalFrames']){const _0x491673=this['frames']['join']('');this['frames']=null;const _0x3b11bf=bt(_0x491673);this['onMessage'](_0x3b11bf);}}['handleNewFrameCount_'](_0x4bbb03){this['totalFrames']=_0x4bbb03,this['frames']=[];}['extractFrameCount_'](_0x55baa9){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x55baa9['length']<=0x6){const _0xaae288=Number(_0x55baa9);if(!isNaN(_0xaae288))return this['handleNewFrameCount_'](_0xaae288),null;}return this['handleNewFrameCount_'](0x1),_0x55baa9;}['handleIncomingFrame'](_0x3ff1b9){if(this['mySock']===null)return;const _0x4df157=_0x3ff1b9['data'];if(this['bytesReceived']+=_0x4df157['length'],this['stats_']['incrementCounter']('bytes_received',_0x4df157['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4df157);else{const _0x2272bc=this['extractFrameCount_'](_0x4df157);_0x2272bc!==null&&this['appendFrame_'](_0x2272bc);}}['send'](_0x3e42c0){this['resetKeepAlive']();const _0x5342bf=O(_0x3e42c0);this['bytesSent']+=_0x5342bf['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5342bf['length']);const _0x594137=io(_0x5342bf,fh);_0x594137['length']>0x1&&this['sendString_'](String(_0x594137['length']));for(let _0x2507d1=0x0;_0x2507d1<_0x594137['length'];_0x2507d1++)this['sendString_'](_0x594137[_0x2507d1]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3ce198){try{this['mySock']['send'](_0x3ce198);}catch(_0x3d1bb1){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3d1bb1['message']||_0x3d1bb1['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x6944fd){this['initTransports_'](_0x6944fd);}['initTransports_'](_0x28a04d){const _0xde166e=G&&G['isAvailable']();let _0x4abe5f=_0xde166e&&!G['previouslyFailed']();if(_0x28a04d['webSocketOnly']&&(_0xde166e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4abe5f=!0x0),_0x4abe5f)this['transports_']=[G];else{const _0x46d07a=this['transports_']=[];for(const _0x368cae of At['ALL_TRANSPORTS'])_0x368cae&&_0x368cae['isAvailable']()&&_0x46d07a['push'](_0x368cae);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4a1cfa,_0x52fcca,_0x431141,_0x28ac9b,_0x434ace,_0x454e30,_0x3b8e4d,_0x3359a1,_0x4cf66b,_0x35e94a){this['id']=_0x4a1cfa,this['repoInfo_']=_0x52fcca,this['applicationId_']=_0x431141,this['appCheckToken_']=_0x28ac9b,this['authToken_']=_0x434ace,this['onMessage_']=_0x454e30,this['onReady_']=_0x3b8e4d,this['onDisconnect_']=_0x3359a1,this['onKill_']=_0x4cf66b,this['lastSessionId']=_0x35e94a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x52fcca),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x40171a=this['transportManager_']['initialTransport']();this['conn_']=new _0x40171a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x40171a['responsesRequiredToBeHealthy']||0x0;const _0x13dfdc=this['connReceiver_'](this['conn_']),_0x2fd9dc=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x13dfdc,_0x2fd9dc);},Math['floor'](0x0));const _0x328ce1=_0x40171a['healthyTimeout']||0x0;_0x328ce1>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x328ce1)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4dad07){return _0x8b801=>{_0x4dad07===this['conn_']?this['onConnectionLost_'](_0x8b801):_0x4dad07===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x56d8db){return _0x4e32d4=>{this['state_']!==0x2&&(_0x56d8db===this['rx_']?this['onPrimaryMessageReceived_'](_0x4e32d4):_0x56d8db===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4e32d4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xd85e17){const _0x59cce7={'t':'d','d':_0xd85e17};this['sendData_'](_0x59cce7);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x552079){if(ii in _0x552079){const _0x1f20f5=_0x552079[ii];_0x1f20f5===js?this['upgradeIfSecondaryHealthy_']():_0x1f20f5===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1f20f5===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3978fa){const _0x4678f2=pt('t',_0x3978fa),_0x15fc0b=pt('d',_0x3978fa);if(_0x4678f2==='c')this['onSecondaryControl_'](_0x15fc0b);else{if(_0x4678f2==='d')this['pendingDataMessages']['push'](_0x15fc0b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4678f2);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x20b3bd){const _0x494b4e=pt('t',_0x20b3bd),_0x2397d9=pt('d',_0x20b3bd);_0x494b4e==='c'?this['onControl_'](_0x2397d9):_0x494b4e==='d'&&this['onDataMessage_'](_0x2397d9);}['onDataMessage_'](_0x55571e){this['onPrimaryResponse_'](),this['onMessage_'](_0x55571e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x35afbf){const _0x43304f=pt(ii,_0x35afbf);if(Gs in _0x35afbf){const _0x5b8492=_0x35afbf[Gs];if(_0x43304f===Ih){const _0xf4ec64={..._0x5b8492};this['repoInfo_']['isUsingEmulator']&&(_0xf4ec64['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xf4ec64);}else{if(_0x43304f===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x45e8ed=0x0;_0x45e8ed<this['pendingDataMessages']['length'];++_0x45e8ed)this['onDataMessage_'](this['pendingDataMessages'][_0x45e8ed]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x43304f===vh?this['onConnectionShutdown_'](_0x5b8492):_0x43304f===qs?this['onReset_'](_0x5b8492):_0x43304f===Eh?mi('Server\x20Error:\x20'+_0x5b8492):_0x43304f===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x43304f);}}}['onHandshake_'](_0x22330e){const _0x510f7f=_0x22330e['ts'],_0x11b5b0=_0x22330e['v'],_0x2b3330=_0x22330e['h'];this['sessionId']=_0x22330e['s'],this['repoInfo_']['host']=_0x2b3330,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x510f7f),Vi!==_0x11b5b0&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x20cccc=this['transportManager_']['upgradeTransport']();_0x20cccc&&this['startUpgrade_'](_0x20cccc);}['startUpgrade_'](_0x157a02){this['secondaryConn_']=new _0x157a02(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x157a02['responsesRequiredToBeHealthy']||0x0;const _0x51cca9=this['connReceiver_'](this['secondaryConn_']),_0xeb499e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x51cca9,_0xeb499e),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xd1e69c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xd1e69c),this['repoInfo_']['host']=_0xd1e69c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2257da,_0x1a1a67){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2257da,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1a1a67,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2e2feb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2e2feb||this['rx_']===_0x2e2feb)&&this['close']();}['onConnectionLost_'](_0x295871){this['conn_']=null,!_0x295871&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xa342b3){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xa342b3),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x326f36){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x326f36);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x2593b1,_0x5de77e,_0x1edab3,_0x39d547){}['merge'](_0x418b10,_0x98f6d6,_0x4ccf00,_0x23c905){}['refreshAuthToken'](_0x4c153e){}['refreshAppCheckToken'](_0x2d3a38){}['onDisconnectPut'](_0x15fe14,_0x240f0a,_0x4df518){}['onDisconnectMerge'](_0x4a051e,_0x5aa3a1,_0x47acb9){}['onDisconnectCancel'](_0x58cbed,_0x355bd0){}['reportStats'](_0x21094f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4caa3b){this['allowedEvents_']=_0x4caa3b,this['listeners_']={},f(Array['isArray'](_0x4caa3b)&&_0x4caa3b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5a761b,..._0x153f32){if(Array['isArray'](this['listeners_'][_0x5a761b])){const _0x4acc3f=[...this['listeners_'][_0x5a761b]];for(let _0x165073=0x0;_0x165073<_0x4acc3f['length'];_0x165073++)_0x4acc3f[_0x165073]['callback']['apply'](_0x4acc3f[_0x165073]['context'],_0x153f32);}}['on'](_0x12cdb9,_0x3ce10e,_0x1a9ee2){this['validateEventType_'](_0x12cdb9),this['listeners_'][_0x12cdb9]=this['listeners_'][_0x12cdb9]||[],this['listeners_'][_0x12cdb9]['push']({'callback':_0x3ce10e,'context':_0x1a9ee2});const _0x46ced2=this['getInitialEvent'](_0x12cdb9);_0x46ced2&&_0x3ce10e['apply'](_0x1a9ee2,_0x46ced2);}['off'](_0x4b4bf6,_0xc641e7,_0x49d3ae){this['validateEventType_'](_0x4b4bf6);const _0x7792c5=this['listeners_'][_0x4b4bf6]||[];for(let _0x4d593e=0x0;_0x4d593e<_0x7792c5['length'];_0x4d593e++)if(_0x7792c5[_0x4d593e]['callback']===_0xc641e7&&(!_0x49d3ae||_0x49d3ae===_0x7792c5[_0x4d593e]['context'])){_0x7792c5['splice'](_0x4d593e,0x1);return;}}['validateEventType_'](_0x44a32b){f(this['allowedEvents_']['find'](_0x4fe14f=>_0x4fe14f===_0x44a32b),'Unknown\x20event:\x20'+_0x44a32b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x20ac09){return f(_0x20ac09==='online','Unknown\x20event\x20type:\x20'+_0x20ac09),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x5c3597,_0x350caf){if(_0x350caf===void 0x0){this['pieces_']=_0x5c3597['split']('/');let _0x41ebb1=0x0;for(let _0x4e1e45=0x0;_0x4e1e45<this['pieces_']['length'];_0x4e1e45++)this['pieces_'][_0x4e1e45]['length']>0x0&&(this['pieces_'][_0x41ebb1]=this['pieces_'][_0x4e1e45],_0x41ebb1++);this['pieces_']['length']=_0x41ebb1,this['pieceNum_']=0x0;}else this['pieces_']=_0x5c3597,this['pieceNum_']=_0x350caf;}['toString'](){let _0x38fc0b='';for(let _0x48da0f=this['pieceNum_'];_0x48da0f<this['pieces_']['length'];_0x48da0f++)this['pieces_'][_0x48da0f]!==''&&(_0x38fc0b+='/'+this['pieces_'][_0x48da0f]);return _0x38fc0b||'/';}}function w(){return new C('');}function y(_0x582a22){return _0x582a22['pieceNum_']>=_0x582a22['pieces_']['length']?null:_0x582a22['pieces_'][_0x582a22['pieceNum_']];}function we(_0x2dd008){return _0x2dd008['pieces_']['length']-_0x2dd008['pieceNum_'];}function b(_0x4c61e0){let _0x278f55=_0x4c61e0['pieceNum_'];return _0x278f55<_0x4c61e0['pieces_']['length']&&_0x278f55++,new C(_0x4c61e0['pieces_'],_0x278f55);}function Gi(_0x2fb53a){return _0x2fb53a['pieceNum_']<_0x2fb53a['pieces_']['length']?_0x2fb53a['pieces_'][_0x2fb53a['pieces_']['length']-0x1]:null;}function Ch(_0x1fed47){let _0x398bd7='';for(let _0x2ac826=_0x1fed47['pieceNum_'];_0x2ac826<_0x1fed47['pieces_']['length'];_0x2ac826++)_0x1fed47['pieces_'][_0x2ac826]!==''&&(_0x398bd7+='/'+encodeURIComponent(String(_0x1fed47['pieces_'][_0x2ac826])));return _0x398bd7||'/';}function kt(_0x20c0c0,_0x2ffad3=0x0){return _0x20c0c0['pieces_']['slice'](_0x20c0c0['pieceNum_']+_0x2ffad3);}function To(_0x2c8442){if(_0x2c8442['pieceNum_']>=_0x2c8442['pieces_']['length'])return null;const _0x16dfe1=[];for(let _0x55db8b=_0x2c8442['pieceNum_'];_0x55db8b<_0x2c8442['pieces_']['length']-0x1;_0x55db8b++)_0x16dfe1['push'](_0x2c8442['pieces_'][_0x55db8b]);return new C(_0x16dfe1,0x0);}function A(_0x3d8dbe,_0x292a03){const _0x5d9c89=[];for(let _0x2a3b35=_0x3d8dbe['pieceNum_'];_0x2a3b35<_0x3d8dbe['pieces_']['length'];_0x2a3b35++)_0x5d9c89['push'](_0x3d8dbe['pieces_'][_0x2a3b35]);if(_0x292a03 instanceof C){for(let _0x1bdd9b=_0x292a03['pieceNum_'];_0x1bdd9b<_0x292a03['pieces_']['length'];_0x1bdd9b++)_0x5d9c89['push'](_0x292a03['pieces_'][_0x1bdd9b]);}else{const _0x3bfa0b=_0x292a03['split']('/');for(let _0x3d068d=0x0;_0x3d068d<_0x3bfa0b['length'];_0x3d068d++)_0x3bfa0b[_0x3d068d]['length']>0x0&&_0x5d9c89['push'](_0x3bfa0b[_0x3d068d]);}return new C(_0x5d9c89,0x0);}function v(_0x2b65e7){return _0x2b65e7['pieceNum_']>=_0x2b65e7['pieces_']['length'];}function F(_0x3f1923,_0x1bcf29){const _0x48be18=y(_0x3f1923),_0x4fc4a9=y(_0x1bcf29);if(_0x48be18===null)return _0x1bcf29;if(_0x48be18===_0x4fc4a9)return F(b(_0x3f1923),b(_0x1bcf29));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1bcf29+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3f1923+')');}function Th(_0x582391,_0x4df7fe){const _0x570842=kt(_0x582391,0x0),_0x40b437=kt(_0x4df7fe,0x0);for(let _0x380656=0x0;_0x380656<_0x570842['length']&&_0x380656<_0x40b437['length'];_0x380656++){const _0x141c26=He(_0x570842[_0x380656],_0x40b437[_0x380656]);if(_0x141c26!==0x0)return _0x141c26;}return _0x570842['length']===_0x40b437['length']?0x0:_0x570842['length']<_0x40b437['length']?-0x1:0x1;}function qi(_0x445948,_0x28d7f9){if(we(_0x445948)!==we(_0x28d7f9))return!0x1;for(let _0x1fb222=_0x445948['pieceNum_'],_0xb0e2d7=_0x28d7f9['pieceNum_'];_0x1fb222<=_0x445948['pieces_']['length'];_0x1fb222++,_0xb0e2d7++)if(_0x445948['pieces_'][_0x1fb222]!==_0x28d7f9['pieces_'][_0xb0e2d7])return!0x1;return!0x0;}function $(_0x55eef1,_0x35ec98){let _0xf938ff=_0x55eef1['pieceNum_'],_0x37cc63=_0x35ec98['pieceNum_'];if(we(_0x55eef1)>we(_0x35ec98))return!0x1;for(;_0xf938ff<_0x55eef1['pieces_']['length'];){if(_0x55eef1['pieces_'][_0xf938ff]!==_0x35ec98['pieces_'][_0x37cc63])return!0x1;++_0xf938ff,++_0x37cc63;}return!0x0;}class Sh{constructor(_0x514f1b,_0x26db4e){this['errorPrefix_']=_0x26db4e,this['parts_']=kt(_0x514f1b,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x41288c=0x0;_0x41288c<this['parts_']['length'];_0x41288c++)this['byteLength_']+=Pn(this['parts_'][_0x41288c]);So(this);}}function bh(_0x62f80b,_0x185860){_0x62f80b['parts_']['length']>0x0&&(_0x62f80b['byteLength_']+=0x1),_0x62f80b['parts_']['push'](_0x185860),_0x62f80b['byteLength_']+=Pn(_0x185860),So(_0x62f80b);}function Rh(_0x36db46){const _0x24193c=_0x36db46['parts_']['pop']();_0x36db46['byteLength_']-=Pn(_0x24193c),_0x36db46['parts_']['length']>0x0&&(_0x36db46['byteLength_']-=0x1);}function So(_0x49a2bf){if(_0x49a2bf['byteLength_']>Js)throw new Error(_0x49a2bf['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x49a2bf['byteLength_']+').');if(_0x49a2bf['parts_']['length']>Qs)throw new Error(_0x49a2bf['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x49a2bf));}function Ne(_0x4f8803){return _0x4f8803['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4f8803['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x2cdab7,_0x3c91c8;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3c91c8='visibilitychange',_0x2cdab7='hidden'):typeof document['mozHidden']<'u'?(_0x3c91c8='mozvisibilitychange',_0x2cdab7='mozHidden'):typeof document['msHidden']<'u'?(_0x3c91c8='msvisibilitychange',_0x2cdab7='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3c91c8='webkitvisibilitychange',_0x2cdab7='webkitHidden')),this['visible_']=!0x0,_0x3c91c8&&document['addEventListener'](_0x3c91c8,()=>{const _0xa0d4b9=!document[_0x2cdab7];_0xa0d4b9!==this['visible_']&&(this['visible_']=_0xa0d4b9,this['trigger']('visible',_0xa0d4b9));},!0x1);}['getInitialEvent'](_0x4e2005){return f(_0x4e2005==='visible','Unknown\x20event\x20type:\x20'+_0x4e2005),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x1d9fbf,_0x555c8d,_0x18aed5,_0x1006a1,_0x2f9534,_0x4c7611,_0x10484c,_0x4c0151){if(super(),this['repoInfo_']=_0x1d9fbf,this['applicationId_']=_0x555c8d,this['onDataUpdate_']=_0x18aed5,this['onConnectStatus_']=_0x1006a1,this['onServerInfoUpdate_']=_0x2f9534,this['authTokenProvider_']=_0x4c7611,this['appCheckTokenProvider_']=_0x10484c,this['authOverride_']=_0x4c0151,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4c0151)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1d9fbf['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2a4238,_0xf4da05,_0x2065a9){const _0x176250=++this['requestNumber_'],_0x480838={'r':_0x176250,'a':_0x2a4238,'b':_0xf4da05};this['log_'](O(_0x480838)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x480838),_0x2065a9&&(this['requestCBHash_'][_0x176250]=_0x2065a9);}['get'](_0x3dbec3){this['initConnection_']();const _0x42916d=new Ve(),_0x268fa9={'action':'g','request':{'p':_0x3dbec3['_path']['toString'](),'q':_0x3dbec3['_queryObject']},'onComplete':_0x34373c=>{const _0xbc8f4d=_0x34373c['d'];_0x34373c['s']==='ok'?_0x42916d['resolve'](_0xbc8f4d):_0x42916d['reject'](_0xbc8f4d);}};this['outstandingGets_']['push'](_0x268fa9),this['outstandingGetCount_']++;const _0x113923=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x113923),_0x42916d['promise'];}['listen'](_0x533450,_0x1628b3,_0x720c20,_0x3a1cd3){this['initConnection_']();const _0x262cc0=_0x533450['_queryIdentifier'],_0x5818e4=_0x533450['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5818e4+'\x20'+_0x262cc0),this['listens']['has'](_0x5818e4)||this['listens']['set'](_0x5818e4,new Map()),f(_0x533450['_queryParams']['isDefault']()||!_0x533450['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5818e4)['has'](_0x262cc0),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x313659={'onComplete':_0x3a1cd3,'hashFn':_0x1628b3,'query':_0x533450,'tag':_0x720c20};this['listens']['get'](_0x5818e4)['set'](_0x262cc0,_0x313659),this['connected_']&&this['sendListen_'](_0x313659);}['sendGet_'](_0x20129e){const _0x2832b7=this['outstandingGets_'][_0x20129e];this['sendRequest']('g',_0x2832b7['request'],_0x16683f=>{delete this['outstandingGets_'][_0x20129e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2832b7['onComplete']&&_0x2832b7['onComplete'](_0x16683f);});}['sendListen_'](_0xef0d60){const _0x1e8754=_0xef0d60['query'],_0x2b69f3=_0x1e8754['_path']['toString'](),_0x43abf2=_0x1e8754['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2b69f3+'\x20for\x20'+_0x43abf2);const _0x27aec9={'p':_0x2b69f3},_0x3173f5='q';_0xef0d60['tag']&&(_0x27aec9['q']=_0x1e8754['_queryObject'],_0x27aec9['t']=_0xef0d60['tag']),_0x27aec9['h']=_0xef0d60['hashFn'](),this['sendRequest'](_0x3173f5,_0x27aec9,_0x98f4b3=>{const _0x2a2fed=_0x98f4b3['d'],_0x513f6c=_0x98f4b3['s'];ie['warnOnListenWarnings_'](_0x2a2fed,_0x1e8754),(this['listens']['get'](_0x2b69f3)&&this['listens']['get'](_0x2b69f3)['get'](_0x43abf2))===_0xef0d60&&(this['log_']('listen\x20response',_0x98f4b3),_0x513f6c!=='ok'&&this['removeListen_'](_0x2b69f3,_0x43abf2),_0xef0d60['onComplete']&&_0xef0d60['onComplete'](_0x513f6c,_0x2a2fed));});}static['warnOnListenWarnings_'](_0x97f5a5,_0xd1269d){if(_0x97f5a5&&typeof _0x97f5a5=='object'&&Y(_0x97f5a5,'w')){const _0x1bf7f6=Oe(_0x97f5a5,'w');if(Array['isArray'](_0x1bf7f6)&&~_0x1bf7f6['indexOf']('no_index')){const _0x1d2a2d='\x22.indexOn\x22:\x20\x22'+_0xd1269d['_queryParams']['getIndex']()['toString']()+'\x22',_0x2efdf7=_0xd1269d['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1d2a2d+'\x20at\x20'+_0x2efdf7+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x58fc89){this['authToken_']=_0x58fc89,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x58fc89);}['reduceReconnectDelayIfAdminCredential_'](_0x208b6d){(_0x208b6d&&_0x208b6d['length']===0x28||vc(_0x208b6d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x544f04){this['appCheckToken_']=_0x544f04,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2a8801=this['authToken_'],_0x1701fc=yc(_0x2a8801)?'auth':'gauth',_0x31fe63={'cred':_0x2a8801};this['authOverride_']===null?_0x31fe63['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x31fe63['authvar']=this['authOverride_']),this['sendRequest'](_0x1701fc,_0x31fe63,_0x43def9=>{const _0x668e09=_0x43def9['s'],_0x40744d=_0x43def9['d']||'error';this['authToken_']===_0x2a8801&&(_0x668e09==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x668e09,_0x40744d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3b4b05=>{const _0x4e9bb1=_0x3b4b05['s'],_0x16da7c=_0x3b4b05['d']||'error';_0x4e9bb1==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4e9bb1,_0x16da7c);});}['unlisten'](_0x822744,_0xdeb9db){const _0x5186bf=_0x822744['_path']['toString'](),_0xc566a0=_0x822744['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5186bf+'\x20'+_0xc566a0),f(_0x822744['_queryParams']['isDefault']()||!_0x822744['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5186bf,_0xc566a0)&&this['connected_']&&this['sendUnlisten_'](_0x5186bf,_0xc566a0,_0x822744['_queryObject'],_0xdeb9db);}['sendUnlisten_'](_0x2f847f,_0x5198a8,_0xbd1fa,_0x5e57d3){this['log_']('Unlisten\x20on\x20'+_0x2f847f+'\x20for\x20'+_0x5198a8);const _0x29cb84={'p':_0x2f847f},_0x2021a1='n';_0x5e57d3&&(_0x29cb84['q']=_0xbd1fa,_0x29cb84['t']=_0x5e57d3),this['sendRequest'](_0x2021a1,_0x29cb84);}['onDisconnectPut'](_0x4fca39,_0x226181,_0x58689f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4fca39,_0x226181,_0x58689f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4fca39,'action':'o','data':_0x226181,'onComplete':_0x58689f});}['onDisconnectMerge'](_0x1db898,_0x35ce9e,_0x58a0b5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1db898,_0x35ce9e,_0x58a0b5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1db898,'action':'om','data':_0x35ce9e,'onComplete':_0x58a0b5});}['onDisconnectCancel'](_0x3fe203,_0x3e1fc3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3fe203,null,_0x3e1fc3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3fe203,'action':'oc','data':null,'onComplete':_0x3e1fc3});}['sendOnDisconnect_'](_0x2943c9,_0x365400,_0x290cf3,_0xf4745f){const _0x127e1c={'p':_0x365400,'d':_0x290cf3};this['log_']('onDisconnect\x20'+_0x2943c9,_0x127e1c),this['sendRequest'](_0x2943c9,_0x127e1c,_0x34ae1f=>{_0xf4745f&&setTimeout(()=>{_0xf4745f(_0x34ae1f['s'],_0x34ae1f['d']);},Math['floor'](0x0));});}['put'](_0xa8d82d,_0x4d6f14,_0x59f4aa,_0x558bcd){this['putInternal']('p',_0xa8d82d,_0x4d6f14,_0x59f4aa,_0x558bcd);}['merge'](_0x2794cc,_0x3a334c,_0x48f353,_0xd203bc){this['putInternal']('m',_0x2794cc,_0x3a334c,_0x48f353,_0xd203bc);}['putInternal'](_0x5d0054,_0x699617,_0x3af3de,_0x3e0e02,_0x51aa18){this['initConnection_']();const _0x495b9d={'p':_0x699617,'d':_0x3af3de};_0x51aa18!==void 0x0&&(_0x495b9d['h']=_0x51aa18),this['outstandingPuts_']['push']({'action':_0x5d0054,'request':_0x495b9d,'onComplete':_0x3e0e02}),this['outstandingPutCount_']++;const _0x221a78=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x221a78):this['log_']('Buffering\x20put:\x20'+_0x699617);}['sendPut_'](_0x36d33e){const _0x110a85=this['outstandingPuts_'][_0x36d33e]['action'],_0x247ef1=this['outstandingPuts_'][_0x36d33e]['request'],_0x2bea33=this['outstandingPuts_'][_0x36d33e]['onComplete'];this['outstandingPuts_'][_0x36d33e]['queued']=this['connected_'],this['sendRequest'](_0x110a85,_0x247ef1,_0xb029be=>{this['log_'](_0x110a85+'\x20response',_0xb029be),delete this['outstandingPuts_'][_0x36d33e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2bea33&&_0x2bea33(_0xb029be['s'],_0xb029be['d']);});}['reportStats'](_0x2c3919){if(this['connected_']){const _0x256ba9={'c':_0x2c3919};this['log_']('reportStats',_0x256ba9),this['sendRequest']('s',_0x256ba9,_0x475345=>{if(_0x475345['s']!=='ok'){const _0x2e2353=_0x475345['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2e2353);}});}}['onDataMessage_'](_0xc3b9e3){if('r'in _0xc3b9e3){this['log_']('from\x20server:\x20'+O(_0xc3b9e3));const _0x2fa17b=_0xc3b9e3['r'],_0x5b166a=this['requestCBHash_'][_0x2fa17b];_0x5b166a&&(delete this['requestCBHash_'][_0x2fa17b],_0x5b166a(_0xc3b9e3['b']));}else{if('error'in _0xc3b9e3)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xc3b9e3['error'];'a'in _0xc3b9e3&&this['onDataPush_'](_0xc3b9e3['a'],_0xc3b9e3['b']);}}['onDataPush_'](_0x12f573,_0x5f0476){this['log_']('handleServerMessage',_0x12f573,_0x5f0476),_0x12f573==='d'?this['onDataUpdate_'](_0x5f0476['p'],_0x5f0476['d'],!0x1,_0x5f0476['t']):_0x12f573==='m'?this['onDataUpdate_'](_0x5f0476['p'],_0x5f0476['d'],!0x0,_0x5f0476['t']):_0x12f573==='c'?this['onListenRevoked_'](_0x5f0476['p'],_0x5f0476['q']):_0x12f573==='ac'?this['onAuthRevoked_'](_0x5f0476['s'],_0x5f0476['d']):_0x12f573==='apc'?this['onAppCheckRevoked_'](_0x5f0476['s'],_0x5f0476['d']):_0x12f573==='sd'?this['onSecurityDebugPacket_'](_0x5f0476):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x12f573)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x45d39e,_0x1672c3){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x45d39e),this['lastSessionId']=_0x1672c3,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2c5070){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2c5070));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x49a1fe){_0x49a1fe&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x49a1fe;}['onOnline_'](_0x941d55){_0x941d55?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x11eed0=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xdc8763=Math['max'](0x0,this['reconnectDelay_']-_0x11eed0);_0xdc8763=Math['random']()*_0xdc8763,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xdc8763+'ms'),this['scheduleConnect_'](_0xdc8763),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xa648a8=this['onDataMessage_']['bind'](this),_0x3d3329=this['onReady_']['bind'](this),_0x37d4bf=this['onRealtimeDisconnect_']['bind'](this),_0xcd2465=this['id']+':'+ie['nextConnectionId_']++,_0xb59267=this['lastSessionId'];let _0xbe286=!0x1,_0x3daded=null;const _0x58533f=function(){_0x3daded?_0x3daded['close']():(_0xbe286=!0x0,_0x37d4bf());},_0x218a57=function(_0x5eae59){f(_0x3daded,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3daded['sendRequest'](_0x5eae59);};this['realtime_']={'close':_0x58533f,'sendRequest':_0x218a57};const _0x48b908=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x16abe4,_0x500edc]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x48b908),this['appCheckTokenProvider_']['getToken'](_0x48b908)]);_0xbe286?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x16abe4&&_0x16abe4['accessToken'],this['appCheckToken_']=_0x500edc&&_0x500edc['token'],_0x3daded=new wh(_0xcd2465,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xa648a8,_0x3d3329,_0x37d4bf,_0x539437=>{U(_0x539437+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0xb59267));}catch(_0x492bd2){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x492bd2),_0xbe286||(this['repoInfo_']['nodeAdmin']&&U(_0x492bd2),_0x58533f());}}}['interrupt'](_0xd400de){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xd400de),this['interruptReasons_'][_0xd400de]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x923c24){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x923c24),delete this['interruptReasons_'][_0x923c24],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3344d4){const _0x248a7b=_0x3344d4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x248a7b});}['cancelSentTransactions_'](){for(let _0x2ccada=0x0;_0x2ccada<this['outstandingPuts_']['length'];_0x2ccada++){const _0x6aef81=this['outstandingPuts_'][_0x2ccada];_0x6aef81&&'h'in _0x6aef81['request']&&_0x6aef81['queued']&&(_0x6aef81['onComplete']&&_0x6aef81['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2ccada],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x592c22,_0x25001b){let _0xd924da;_0x25001b?_0xd924da=_0x25001b['map'](_0x2dd306=>Bi(_0x2dd306))['join']('$'):_0xd924da='default';const _0x57bff8=this['removeListen_'](_0x592c22,_0xd924da);_0x57bff8&&_0x57bff8['onComplete']&&_0x57bff8['onComplete']('permission_denied');}['removeListen_'](_0x2d4723,_0x41ba3b){const _0x4ba813=new C(_0x2d4723)['toString']();let _0x4f68ff;if(this['listens']['has'](_0x4ba813)){const _0x540c3e=this['listens']['get'](_0x4ba813);_0x4f68ff=_0x540c3e['get'](_0x41ba3b),_0x540c3e['delete'](_0x41ba3b),_0x540c3e['size']===0x0&&this['listens']['delete'](_0x4ba813);}else _0x4f68ff=void 0x0;return _0x4f68ff;}['onAuthRevoked_'](_0x279934,_0x165e24){L('Auth\x20token\x20revoked:\x20'+_0x279934+'/'+_0x165e24),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x279934==='invalid_token'||_0x279934==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1e6f11,_0x334ad3){L('App\x20check\x20token\x20revoked:\x20'+_0x1e6f11+'/'+_0x334ad3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1e6f11==='invalid_token'||_0x1e6f11==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x913935){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x913935):'msg'in _0x913935&&console['log']('FIREBASE:\x20'+_0x913935['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2c3edf of this['listens']['values']())for(const _0x3a9599 of _0x2c3edf['values']())this['sendListen_'](_0x3a9599);for(let _0x457264=0x0;_0x457264<this['outstandingPuts_']['length'];_0x457264++)this['outstandingPuts_'][_0x457264]&&this['sendPut_'](_0x457264);for(;this['onDisconnectRequestQueue_']['length'];){const _0x496dff=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x496dff['action'],_0x496dff['pathString'],_0x496dff['data'],_0x496dff['onComplete']);}for(let _0x20d857=0x0;_0x20d857<this['outstandingGets_']['length'];_0x20d857++)this['outstandingGets_'][_0x20d857]&&this['sendGet_'](_0x20d857);}['sendConnectStats_'](){const _0x3307a0={};let _0x17814d='js';_0x3307a0['sdk.'+_0x17814d+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x3307a0['framework.cordova']=0x1:qr()&&(_0x3307a0['framework.reactnative']=0x1),this['reportStats'](_0x3307a0);}['shouldReconnect_'](){const _0x4a13f4=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4a13f4;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x202da5,_0x5bcd26){this['name']=_0x202da5,this['node']=_0x5bcd26;}static['Wrap'](_0x50b08a,_0x4fb37d){return new E(_0x50b08a,_0x4fb37d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3c221f,_0x552bf1){const _0x8cc516=new E(xe,_0x3c221f),_0x31cb70=new E(xe,_0x552bf1);return this['compare'](_0x8cc516,_0x31cb70)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x5c5aec){Xt=_0x5c5aec;}['compare'](_0x3f2405,_0x3a7267){return He(_0x3f2405['name'],_0x3a7267['name']);}['isDefinedOn'](_0x4d090e){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x50ad94,_0x2cf2d5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x11596e,_0x3da7dd){return f(typeof _0x11596e=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x11596e,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x59e454,_0x12b76a,_0x2cbfc3,_0x3b8833,_0x56ef86=null){this['isReverse_']=_0x3b8833,this['resultGenerator_']=_0x56ef86,this['nodeStack_']=[];let _0x42290b=0x1;for(;!_0x59e454['isEmpty']();)if(_0x59e454=_0x59e454,_0x42290b=_0x12b76a?_0x2cbfc3(_0x59e454['key'],_0x12b76a):0x1,_0x3b8833&&(_0x42290b*=-0x1),_0x42290b<0x0)this['isReverse_']?_0x59e454=_0x59e454['left']:_0x59e454=_0x59e454['right'];else{if(_0x42290b===0x0){this['nodeStack_']['push'](_0x59e454);break;}else this['nodeStack_']['push'](_0x59e454),this['isReverse_']?_0x59e454=_0x59e454['right']:_0x59e454=_0x59e454['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x19bd60=this['nodeStack_']['pop'](),_0x2417b6;if(this['resultGenerator_']?_0x2417b6=this['resultGenerator_'](_0x19bd60['key'],_0x19bd60['value']):_0x2417b6={'key':_0x19bd60['key'],'value':_0x19bd60['value']},this['isReverse_']){for(_0x19bd60=_0x19bd60['left'];!_0x19bd60['isEmpty']();)this['nodeStack_']['push'](_0x19bd60),_0x19bd60=_0x19bd60['right'];}else{for(_0x19bd60=_0x19bd60['right'];!_0x19bd60['isEmpty']();)this['nodeStack_']['push'](_0x19bd60),_0x19bd60=_0x19bd60['left'];}return _0x2417b6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x20eaca=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x20eaca['key'],_0x20eaca['value']):{'key':_0x20eaca['key'],'value':_0x20eaca['value']};}}class M{constructor(_0x39b375,_0x419ec7,_0x598c00,_0x2b3166,_0x439aea){this['key']=_0x39b375,this['value']=_0x419ec7,this['color']=_0x598c00??M['RED'],this['left']=_0x2b3166??B['EMPTY_NODE'],this['right']=_0x439aea??B['EMPTY_NODE'];}['copy'](_0x1193cd,_0x4832c9,_0x170172,_0x18da05,_0xfdc328){return new M(_0x1193cd??this['key'],_0x4832c9??this['value'],_0x170172??this['color'],_0x18da05??this['left'],_0xfdc328??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x44d1f8){return this['left']['inorderTraversal'](_0x44d1f8)||!!_0x44d1f8(this['key'],this['value'])||this['right']['inorderTraversal'](_0x44d1f8);}['reverseTraversal'](_0x2d3980){return this['right']['reverseTraversal'](_0x2d3980)||_0x2d3980(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2d3980);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x340515,_0x543ce7,_0x34e753){let _0x302f6a=this;const _0x2d055b=_0x34e753(_0x340515,_0x302f6a['key']);return _0x2d055b<0x0?_0x302f6a=_0x302f6a['copy'](null,null,null,_0x302f6a['left']['insert'](_0x340515,_0x543ce7,_0x34e753),null):_0x2d055b===0x0?_0x302f6a=_0x302f6a['copy'](null,_0x543ce7,null,null,null):_0x302f6a=_0x302f6a['copy'](null,null,null,null,_0x302f6a['right']['insert'](_0x340515,_0x543ce7,_0x34e753)),_0x302f6a['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x48440d=this;return!_0x48440d['left']['isRed_']()&&!_0x48440d['left']['left']['isRed_']()&&(_0x48440d=_0x48440d['moveRedLeft_']()),_0x48440d=_0x48440d['copy'](null,null,null,_0x48440d['left']['removeMin_'](),null),_0x48440d['fixUp_']();}['remove'](_0x367f7,_0x36567f){let _0xf6b2a0,_0x5564b1;if(_0xf6b2a0=this,_0x36567f(_0x367f7,_0xf6b2a0['key'])<0x0)!_0xf6b2a0['left']['isEmpty']()&&!_0xf6b2a0['left']['isRed_']()&&!_0xf6b2a0['left']['left']['isRed_']()&&(_0xf6b2a0=_0xf6b2a0['moveRedLeft_']()),_0xf6b2a0=_0xf6b2a0['copy'](null,null,null,_0xf6b2a0['left']['remove'](_0x367f7,_0x36567f),null);else{if(_0xf6b2a0['left']['isRed_']()&&(_0xf6b2a0=_0xf6b2a0['rotateRight_']()),!_0xf6b2a0['right']['isEmpty']()&&!_0xf6b2a0['right']['isRed_']()&&!_0xf6b2a0['right']['left']['isRed_']()&&(_0xf6b2a0=_0xf6b2a0['moveRedRight_']()),_0x36567f(_0x367f7,_0xf6b2a0['key'])===0x0){if(_0xf6b2a0['right']['isEmpty']())return B['EMPTY_NODE'];_0x5564b1=_0xf6b2a0['right']['min_'](),_0xf6b2a0=_0xf6b2a0['copy'](_0x5564b1['key'],_0x5564b1['value'],null,null,_0xf6b2a0['right']['removeMin_']());}_0xf6b2a0=_0xf6b2a0['copy'](null,null,null,null,_0xf6b2a0['right']['remove'](_0x367f7,_0x36567f));}return _0xf6b2a0['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x592a26=this;return _0x592a26['right']['isRed_']()&&!_0x592a26['left']['isRed_']()&&(_0x592a26=_0x592a26['rotateLeft_']()),_0x592a26['left']['isRed_']()&&_0x592a26['left']['left']['isRed_']()&&(_0x592a26=_0x592a26['rotateRight_']()),_0x592a26['left']['isRed_']()&&_0x592a26['right']['isRed_']()&&(_0x592a26=_0x592a26['colorFlip_']()),_0x592a26;}['moveRedLeft_'](){let _0xf445e1=this['colorFlip_']();return _0xf445e1['right']['left']['isRed_']()&&(_0xf445e1=_0xf445e1['copy'](null,null,null,null,_0xf445e1['right']['rotateRight_']()),_0xf445e1=_0xf445e1['rotateLeft_'](),_0xf445e1=_0xf445e1['colorFlip_']()),_0xf445e1;}['moveRedRight_'](){let _0x208238=this['colorFlip_']();return _0x208238['left']['left']['isRed_']()&&(_0x208238=_0x208238['rotateRight_'](),_0x208238=_0x208238['colorFlip_']()),_0x208238;}['rotateLeft_'](){const _0xc4ff00=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xc4ff00,null);}['rotateRight_'](){const _0x1e5be1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1e5be1);}['colorFlip_'](){const _0x1e87fb=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x292eb6=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1e87fb,_0x292eb6);}['checkMaxDepth_'](){const _0x1254c5=this['check_']();return Math['pow'](0x2,_0x1254c5)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x25ad4f=this['left']['check_']();if(_0x25ad4f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x25ad4f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x1a1f67,_0x37ea39,_0x54574e,_0x3a2bb3,_0x6406d0){return this;}['insert'](_0xd59beb,_0x186c81,_0x1b082d){return new M(_0xd59beb,_0x186c81,null);}['remove'](_0x3bcf48,_0x378a8e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x55dee3){return!0x1;}['reverseTraversal'](_0x3d5ef6){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2941b2,_0x1704c4=B['EMPTY_NODE']){this['comparator_']=_0x2941b2,this['root_']=_0x1704c4;}['insert'](_0x2ce4a0,_0x43b802){return new B(this['comparator_'],this['root_']['insert'](_0x2ce4a0,_0x43b802,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x44b8d1){return new B(this['comparator_'],this['root_']['remove'](_0x44b8d1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x5ba96d){let _0x3f3f5a,_0x501a87=this['root_'];for(;!_0x501a87['isEmpty']();){if(_0x3f3f5a=this['comparator_'](_0x5ba96d,_0x501a87['key']),_0x3f3f5a===0x0)return _0x501a87['value'];_0x3f3f5a<0x0?_0x501a87=_0x501a87['left']:_0x3f3f5a>0x0&&(_0x501a87=_0x501a87['right']);}return null;}['getPredecessorKey'](_0x3cdc95){let _0x1ff4c1,_0x54ff28=this['root_'],_0x11e503=null;for(;!_0x54ff28['isEmpty']();)if(_0x1ff4c1=this['comparator_'](_0x3cdc95,_0x54ff28['key']),_0x1ff4c1===0x0){if(_0x54ff28['left']['isEmpty']())return _0x11e503?_0x11e503['key']:null;for(_0x54ff28=_0x54ff28['left'];!_0x54ff28['right']['isEmpty']();)_0x54ff28=_0x54ff28['right'];return _0x54ff28['key'];}else _0x1ff4c1<0x0?_0x54ff28=_0x54ff28['left']:_0x1ff4c1>0x0&&(_0x11e503=_0x54ff28,_0x54ff28=_0x54ff28['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5c1ba1){return this['root_']['inorderTraversal'](_0x5c1ba1);}['reverseTraversal'](_0x5489d3){return this['root_']['reverseTraversal'](_0x5489d3);}['getIterator'](_0x4737f4){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x4737f4);}['getIteratorFrom'](_0x105fd3,_0x46190e){return new Zt(this['root_'],_0x105fd3,this['comparator_'],!0x1,_0x46190e);}['getReverseIteratorFrom'](_0x5c6715,_0xcd0376){return new Zt(this['root_'],_0x5c6715,this['comparator_'],!0x0,_0xcd0376);}['getReverseIterator'](_0x4ea092){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x4ea092);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x24ce0d,_0x32a9f6){return He(_0x24ce0d['name'],_0x32a9f6['name']);}function ji(_0x5b5cc8,_0x22efd3){return He(_0x5b5cc8,_0x22efd3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0xb73d16){vi=_0xb73d16;}const Ro=function(_0x5cc3d5){return typeof _0x5cc3d5=='number'?'number:'+so(_0x5cc3d5):'string:'+_0x5cc3d5;},Ao=function(_0x2e86f5){if(_0x2e86f5['isLeafNode']()){const _0x1047a2=_0x2e86f5['val']();f(typeof _0x1047a2=='string'||typeof _0x1047a2=='number'||typeof _0x1047a2=='object'&&Y(_0x1047a2,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2e86f5===vi||_0x2e86f5['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2e86f5===vi||_0x2e86f5['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x129fe9){er=_0x129fe9;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x3451ef,_0x197321=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3451ef,this['priorityNode_']=_0x197321,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xd2d452){return new D(this['value_'],_0xd2d452);}['getImmediateChild'](_0x5392e5){return _0x5392e5==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4a475e){return v(_0x4a475e)?this:y(_0x4a475e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4bf110,_0x389350){return null;}['updateImmediateChild'](_0x4bb0c5,_0x35b60e){return _0x4bb0c5==='.priority'?this['updatePriority'](_0x35b60e):_0x35b60e['isEmpty']()&&_0x4bb0c5!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4bb0c5,_0x35b60e)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xba85b6,_0x129fa1){const _0x58b5c6=y(_0xba85b6);return _0x58b5c6===null?_0x129fa1:_0x129fa1['isEmpty']()&&_0x58b5c6!=='.priority'?this:(f(_0x58b5c6!=='.priority'||we(_0xba85b6)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x58b5c6,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0xba85b6),_0x129fa1)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xdf45b3,_0xd16e41){return!0x1;}['val'](_0x18e5a0){return _0x18e5a0&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x95df9c='';this['priorityNode_']['isEmpty']()||(_0x95df9c+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1472e9=typeof this['value_'];_0x95df9c+=_0x1472e9+':',_0x1472e9==='number'?_0x95df9c+=so(this['value_']):_0x95df9c+=this['value_'],this['lazyHash_']=no(_0x95df9c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2348b1){return _0x2348b1===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2348b1 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2348b1['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2348b1));}['compareToLeafNode_'](_0x361992){const _0x4bc2a0=typeof _0x361992['value_'],_0x37e073=typeof this['value_'],_0x143946=D['VALUE_TYPE_ORDER']['indexOf'](_0x4bc2a0),_0x50a507=D['VALUE_TYPE_ORDER']['indexOf'](_0x37e073);return f(_0x143946>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4bc2a0),f(_0x50a507>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x37e073),_0x143946===_0x50a507?_0x37e073==='object'?0x0:this['value_']<_0x361992['value_']?-0x1:this['value_']===_0x361992['value_']?0x0:0x1:_0x50a507-_0x143946;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1c1cd6){if(_0x1c1cd6===this)return!0x0;if(_0x1c1cd6['isLeafNode']()){const _0x51f38f=_0x1c1cd6;return this['value_']===_0x51f38f['value_']&&this['priorityNode_']['equals'](_0x51f38f['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x13d669){ko=_0x13d669;}function xh(_0x40766e){No=_0x40766e;}class Fh extends On{['compare'](_0x454129,_0x3a501f){const _0xdddb63=_0x454129['node']['getPriority'](),_0x4e38b9=_0x3a501f['node']['getPriority'](),_0x1c089f=_0xdddb63['compareTo'](_0x4e38b9);return _0x1c089f===0x0?He(_0x454129['name'],_0x3a501f['name']):_0x1c089f;}['isDefinedOn'](_0x20b549){return!_0x20b549['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x25b274,_0x237044){return!_0x25b274['getPriority']()['equals'](_0x237044['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x14bcf2,_0x23d3e2){const _0x21a01e=ko(_0x14bcf2);return new E(_0x23d3e2,new D('[PRIORITY-POST]',_0x21a01e));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x128d08){const _0x419243=_0x2e824a=>parseInt(Math['log'](_0x2e824a)/Uh,0xa),_0xc48b98=_0x18e170=>parseInt(Array(_0x18e170+0x1)['join']('1'),0x2);this['count']=_0x419243(_0x128d08+0x1),this['current_']=this['count']-0x1;const _0x326ad3=_0xc48b98(this['count']);this['bits_']=_0x128d08+0x1&_0x326ad3;}['nextBitIsOne'](){const _0x210899=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x210899;}}const dn=function(_0x19b183,_0x4a3c6f,_0x1e4fb3,_0x4c15a4){_0x19b183['sort'](_0x4a3c6f);const _0x5ce022=function(_0x64280,_0x3ab2e8){const _0x1124da=_0x3ab2e8-_0x64280;let _0x22aa13,_0x5a480d;if(_0x1124da===0x0)return null;if(_0x1124da===0x1)return _0x22aa13=_0x19b183[_0x64280],_0x5a480d=_0x1e4fb3?_0x1e4fb3(_0x22aa13):_0x22aa13,new M(_0x5a480d,_0x22aa13['node'],M['BLACK'],null,null);{const _0x4d3835=parseInt(_0x1124da/0x2,0xa)+_0x64280,_0x3779d2=_0x5ce022(_0x64280,_0x4d3835),_0x14f427=_0x5ce022(_0x4d3835+0x1,_0x3ab2e8);return _0x22aa13=_0x19b183[_0x4d3835],_0x5a480d=_0x1e4fb3?_0x1e4fb3(_0x22aa13):_0x22aa13,new M(_0x5a480d,_0x22aa13['node'],M['BLACK'],_0x3779d2,_0x14f427);}},_0x129f4e=function(_0x4263e2){let _0x25eb18=null,_0x1546f8=null,_0x401a42=_0x19b183['length'];const _0x39b3b4=function(_0x102447,_0x2b3cd4){const _0x1cde4d=_0x401a42-_0x102447,_0xebc500=_0x401a42;_0x401a42-=_0x102447;const _0x20e057=_0x5ce022(_0x1cde4d+0x1,_0xebc500),_0x2209e2=_0x19b183[_0x1cde4d],_0x2dabf1=_0x1e4fb3?_0x1e4fb3(_0x2209e2):_0x2209e2;_0x58fda9(new M(_0x2dabf1,_0x2209e2['node'],_0x2b3cd4,null,_0x20e057));},_0x58fda9=function(_0x12d1d5){_0x25eb18?(_0x25eb18['left']=_0x12d1d5,_0x25eb18=_0x12d1d5):(_0x1546f8=_0x12d1d5,_0x25eb18=_0x12d1d5);};for(let _0x5c633e=0x0;_0x5c633e<_0x4263e2['count'];++_0x5c633e){const _0x11e8c5=_0x4263e2['nextBitIsOne'](),_0x3cab68=Math['pow'](0x2,_0x4263e2['count']-(_0x5c633e+0x1));_0x11e8c5?_0x39b3b4(_0x3cab68,M['BLACK']):(_0x39b3b4(_0x3cab68,M['BLACK']),_0x39b3b4(_0x3cab68,M['RED']));}return _0x1546f8;},_0x3555d1=new Wh(_0x19b183['length']),_0x1cc73a=_0x129f4e(_0x3555d1);return new B(_0x4c15a4||_0x4a3c6f,_0x1cc73a);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x27e863,_0xc32ecb){this['indexes_']=_0x27e863,this['indexSet_']=_0xc32ecb;}['get'](_0x3be378){const _0x442fbb=Oe(this['indexes_'],_0x3be378);if(!_0x442fbb)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3be378);return _0x442fbb instanceof B?_0x442fbb:null;}['hasIndex'](_0x40e5e9){return Y(this['indexSet_'],_0x40e5e9['toString']());}['addIndex'](_0x29d23f,_0x3796d8){f(_0x29d23f!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x83fb67=[];let _0x4d5829=!0x1;const _0x1b5670=_0x3796d8['getIterator'](E['Wrap']);let _0x5c014a=_0x1b5670['getNext']();for(;_0x5c014a;)_0x4d5829=_0x4d5829||_0x29d23f['isDefinedOn'](_0x5c014a['node']),_0x83fb67['push'](_0x5c014a),_0x5c014a=_0x1b5670['getNext']();let _0x3e3986;_0x4d5829?_0x3e3986=dn(_0x83fb67,_0x29d23f['getCompare']()):_0x3e3986=je;const _0x374eea=_0x29d23f['toString'](),_0x562d59={...this['indexSet_']};_0x562d59[_0x374eea]=_0x29d23f;const _0x1194e3={...this['indexes_']};return _0x1194e3[_0x374eea]=_0x3e3986,new ee(_0x1194e3,_0x562d59);}['addToIndexes'](_0x42e74f,_0xdc2eee){const _0x3bb46f=ln(this['indexes_'],(_0x3eb6d3,_0x577ab0)=>{const _0xe3166a=Oe(this['indexSet_'],_0x577ab0);if(f(_0xe3166a,'Missing\x20index\x20implementation\x20for\x20'+_0x577ab0),_0x3eb6d3===je){if(_0xe3166a['isDefinedOn'](_0x42e74f['node'])){const _0x291929=[],_0x37bac0=_0xdc2eee['getIterator'](E['Wrap']);let _0x51ef84=_0x37bac0['getNext']();for(;_0x51ef84;)_0x51ef84['name']!==_0x42e74f['name']&&_0x291929['push'](_0x51ef84),_0x51ef84=_0x37bac0['getNext']();return _0x291929['push'](_0x42e74f),dn(_0x291929,_0xe3166a['getCompare']());}else return je;}else{const _0x1e7fee=_0xdc2eee['get'](_0x42e74f['name']);let _0x2537c7=_0x3eb6d3;return _0x1e7fee&&(_0x2537c7=_0x2537c7['remove'](new E(_0x42e74f['name'],_0x1e7fee))),_0x2537c7['insert'](_0x42e74f,_0x42e74f['node']);}});return new ee(_0x3bb46f,this['indexSet_']);}['removeFromIndexes'](_0xec844f,_0x1e8c23){const _0x108cbd=ln(this['indexes_'],_0x45e15b=>{if(_0x45e15b===je)return _0x45e15b;{const _0x23946f=_0x1e8c23['get'](_0xec844f['name']);return _0x23946f?_0x45e15b['remove'](new E(_0xec844f['name'],_0x23946f)):_0x45e15b;}});return new ee(_0x108cbd,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x564e54,_0x45e51c,_0x56d37c){this['children_']=_0x564e54,this['priorityNode_']=_0x45e51c,this['indexMap_']=_0x56d37c,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x29b7cf){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x29b7cf,this['indexMap_']);}['getImmediateChild'](_0x266550){if(_0x266550==='.priority')return this['getPriority']();{const _0x46452c=this['children_']['get'](_0x266550);return _0x46452c===null?gt:_0x46452c;}}['getChild'](_0x3c1dc9){const _0x10f010=y(_0x3c1dc9);return _0x10f010===null?this:this['getImmediateChild'](_0x10f010)['getChild'](b(_0x3c1dc9));}['hasChild'](_0x8efe79){return this['children_']['get'](_0x8efe79)!==null;}['updateImmediateChild'](_0x5a8250,_0x560e47){if(f(_0x560e47,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5a8250==='.priority')return this['updatePriority'](_0x560e47);{const _0x331e3a=new E(_0x5a8250,_0x560e47);let _0x32c848,_0x15bfff;_0x560e47['isEmpty']()?(_0x32c848=this['children_']['remove'](_0x5a8250),_0x15bfff=this['indexMap_']['removeFromIndexes'](_0x331e3a,this['children_'])):(_0x32c848=this['children_']['insert'](_0x5a8250,_0x560e47),_0x15bfff=this['indexMap_']['addToIndexes'](_0x331e3a,this['children_']));const _0xffff02=_0x32c848['isEmpty']()?gt:this['priorityNode_'];return new g(_0x32c848,_0xffff02,_0x15bfff);}}['updateChild'](_0x514c45,_0x4a884e){const _0x2c3530=y(_0x514c45);if(_0x2c3530===null)return _0x4a884e;{f(y(_0x514c45)!=='.priority'||we(_0x514c45)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x28ac31=this['getImmediateChild'](_0x2c3530)['updateChild'](b(_0x514c45),_0x4a884e);return this['updateImmediateChild'](_0x2c3530,_0x28ac31);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2d4f85){if(this['isEmpty']())return null;const _0x104a67={};let _0x53ae28=0x0,_0x37b35e=0x0,_0x19c728=!0x0;if(this['forEachChild'](R,(_0x56a1a2,_0x2b7e7c)=>{_0x104a67[_0x56a1a2]=_0x2b7e7c['val'](_0x2d4f85),_0x53ae28++,_0x19c728&&g['INTEGER_REGEXP_']['test'](_0x56a1a2)?_0x37b35e=Math['max'](_0x37b35e,Number(_0x56a1a2)):_0x19c728=!0x1;}),!_0x2d4f85&&_0x19c728&&_0x37b35e<0x2*_0x53ae28){const _0x28a75b=[];for(const _0x4322fb in _0x104a67)_0x28a75b[_0x4322fb]=_0x104a67[_0x4322fb];return _0x28a75b;}else return _0x2d4f85&&!this['getPriority']()['isEmpty']()&&(_0x104a67['.priority']=this['getPriority']()['val']()),_0x104a67;}['hash'](){if(this['lazyHash_']===null){let _0x28153e='';this['getPriority']()['isEmpty']()||(_0x28153e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x16e91e,_0x29d004)=>{const _0x626729=_0x29d004['hash']();_0x626729!==''&&(_0x28153e+=':'+_0x16e91e+':'+_0x626729);}),this['lazyHash_']=_0x28153e===''?'':no(_0x28153e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x16dc5e,_0x3706c6,_0x14600c){const _0x2f0c89=this['resolveIndex_'](_0x14600c);if(_0x2f0c89){const _0x573cbd=_0x2f0c89['getPredecessorKey'](new E(_0x16dc5e,_0x3706c6));return _0x573cbd?_0x573cbd['name']:null;}else return this['children_']['getPredecessorKey'](_0x16dc5e);}['getFirstChildName'](_0x4c5411){const _0x29da6c=this['resolveIndex_'](_0x4c5411);if(_0x29da6c){const _0x1775cd=_0x29da6c['minKey']();return _0x1775cd&&_0x1775cd['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4718b2){const _0x571186=this['getFirstChildName'](_0x4718b2);return _0x571186?new E(_0x571186,this['children_']['get'](_0x571186)):null;}['getLastChildName'](_0x32c57e){const _0x3d33e6=this['resolveIndex_'](_0x32c57e);if(_0x3d33e6){const _0x2b9087=_0x3d33e6['maxKey']();return _0x2b9087&&_0x2b9087['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xd360d7){const _0x244bb1=this['getLastChildName'](_0xd360d7);return _0x244bb1?new E(_0x244bb1,this['children_']['get'](_0x244bb1)):null;}['forEachChild'](_0xce71a3,_0x2a2fc0){const _0x2b36d1=this['resolveIndex_'](_0xce71a3);return _0x2b36d1?_0x2b36d1['inorderTraversal'](_0xc0c995=>_0x2a2fc0(_0xc0c995['name'],_0xc0c995['node'])):this['children_']['inorderTraversal'](_0x2a2fc0);}['getIterator'](_0x46b201){return this['getIteratorFrom'](_0x46b201['minPost'](),_0x46b201);}['getIteratorFrom'](_0x59107e,_0x3082f7){const _0x3b092d=this['resolveIndex_'](_0x3082f7);if(_0x3b092d)return _0x3b092d['getIteratorFrom'](_0x59107e,_0x22fe35=>_0x22fe35);{const _0x59ca68=this['children_']['getIteratorFrom'](_0x59107e['name'],E['Wrap']);let _0x258353=_0x59ca68['peek']();for(;_0x258353!=null&&_0x3082f7['compare'](_0x258353,_0x59107e)<0x0;)_0x59ca68['getNext'](),_0x258353=_0x59ca68['peek']();return _0x59ca68;}}['getReverseIterator'](_0x14c5a6){return this['getReverseIteratorFrom'](_0x14c5a6['maxPost'](),_0x14c5a6);}['getReverseIteratorFrom'](_0x39287c,_0x344a82){const _0x18f9a2=this['resolveIndex_'](_0x344a82);if(_0x18f9a2)return _0x18f9a2['getReverseIteratorFrom'](_0x39287c,_0x548ae3=>_0x548ae3);{const _0x1e4ebb=this['children_']['getReverseIteratorFrom'](_0x39287c['name'],E['Wrap']);let _0x18ce80=_0x1e4ebb['peek']();for(;_0x18ce80!=null&&_0x344a82['compare'](_0x18ce80,_0x39287c)>0x0;)_0x1e4ebb['getNext'](),_0x18ce80=_0x1e4ebb['peek']();return _0x1e4ebb;}}['compareTo'](_0xb1940f){return this['isEmpty']()?_0xb1940f['isEmpty']()?0x0:-0x1:_0xb1940f['isLeafNode']()||_0xb1940f['isEmpty']()?0x1:_0xb1940f===Ht?-0x1:0x0;}['withIndex'](_0x3b62e1){if(_0x3b62e1===ye||this['indexMap_']['hasIndex'](_0x3b62e1))return this;{const _0x2792a0=this['indexMap_']['addIndex'](_0x3b62e1,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2792a0);}}['isIndexed'](_0x34be99){return _0x34be99===ye||this['indexMap_']['hasIndex'](_0x34be99);}['equals'](_0x1c9548){if(_0x1c9548===this)return!0x0;if(_0x1c9548['isLeafNode']())return!0x1;{const _0x21a740=_0x1c9548;if(this['getPriority']()['equals'](_0x21a740['getPriority']())){if(this['children_']['count']()===_0x21a740['children_']['count']()){const _0x22d92d=this['getIterator'](R),_0x5070d1=_0x21a740['getIterator'](R);let _0x27a02d=_0x22d92d['getNext'](),_0x2b4647=_0x5070d1['getNext']();for(;_0x27a02d&&_0x2b4647;){if(_0x27a02d['name']!==_0x2b4647['name']||!_0x27a02d['node']['equals'](_0x2b4647['node']))return!0x1;_0x27a02d=_0x22d92d['getNext'](),_0x2b4647=_0x5070d1['getNext']();}return _0x27a02d===null&&_0x2b4647===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x25c9a3){return _0x25c9a3===ye?null:this['indexMap_']['get'](_0x25c9a3['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x29079e){return _0x29079e===this?0x0:0x1;}['equals'](_0x587a54){return _0x587a54===this;}['getPriority'](){return this;}['getImmediateChild'](_0x80e491){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x37319d,_0x46a5e7=null){if(_0x37319d===null)return g['EMPTY_NODE'];if(typeof _0x37319d=='object'&&'.priority'in _0x37319d&&(_0x46a5e7=_0x37319d['.priority']),f(_0x46a5e7===null||typeof _0x46a5e7=='string'||typeof _0x46a5e7=='number'||typeof _0x46a5e7=='object'&&'.sv'in _0x46a5e7,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x46a5e7),typeof _0x37319d=='object'&&'.value'in _0x37319d&&_0x37319d['.value']!==null&&(_0x37319d=_0x37319d['.value']),typeof _0x37319d!='object'||'.sv'in _0x37319d){const _0x459c03=_0x37319d;return new D(_0x459c03,N(_0x46a5e7));}if(!(_0x37319d instanceof Array)&&Vh){const _0x2e17ab=[];let _0x4ba1c7=!0x1;if(x(_0x37319d,(_0x565756,_0x53c842)=>{if(_0x565756['substring'](0x0,0x1)!=='.'){const _0x4965d0=N(_0x53c842);_0x4965d0['isEmpty']()||(_0x4ba1c7=_0x4ba1c7||!_0x4965d0['getPriority']()['isEmpty'](),_0x2e17ab['push'](new E(_0x565756,_0x4965d0)));}}),_0x2e17ab['length']===0x0)return g['EMPTY_NODE'];const _0x29b4b2=dn(_0x2e17ab,Dh,_0x26b6d5=>_0x26b6d5['name'],ji);if(_0x4ba1c7){const _0x16548d=dn(_0x2e17ab,R['getCompare']());return new g(_0x29b4b2,N(_0x46a5e7),new ee({'.priority':_0x16548d},{'.priority':R}));}else return new g(_0x29b4b2,N(_0x46a5e7),ee['Default']);}else{let _0x4e959e=g['EMPTY_NODE'];return x(_0x37319d,(_0x8800d1,_0x3d3721)=>{if(Y(_0x37319d,_0x8800d1)&&_0x8800d1['substring'](0x0,0x1)!=='.'){const _0x1e5eac=N(_0x3d3721);(_0x1e5eac['isLeafNode']()||!_0x1e5eac['isEmpty']())&&(_0x4e959e=_0x4e959e['updateImmediateChild'](_0x8800d1,_0x1e5eac));}}),_0x4e959e['updatePriority'](N(_0x46a5e7));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x1e39a2){super(),this['indexPath_']=_0x1e39a2,f(!v(_0x1e39a2)&&y(_0x1e39a2)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3c5014){return _0x3c5014['getChild'](this['indexPath_']);}['isDefinedOn'](_0x154de0){return!_0x154de0['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4a7c93,_0xeca200){const _0x381cde=this['extractChild'](_0x4a7c93['node']),_0x15e9e6=this['extractChild'](_0xeca200['node']),_0x2de3fa=_0x381cde['compareTo'](_0x15e9e6);return _0x2de3fa===0x0?He(_0x4a7c93['name'],_0xeca200['name']):_0x2de3fa;}['makePost'](_0x38441f,_0x17d27c){const _0x235fc9=N(_0x38441f),_0x509df=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x235fc9);return new E(_0x17d27c,_0x509df);}['maxPost'](){const _0x51baa0=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x51baa0);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x8dadb3,_0x1e375b){const _0x37ea73=_0x8dadb3['node']['compareTo'](_0x1e375b['node']);return _0x37ea73===0x0?He(_0x8dadb3['name'],_0x1e375b['name']):_0x37ea73;}['isDefinedOn'](_0x2423b7){return!0x0;}['indexedValueChanged'](_0xe6f45c,_0x3ec348){return!_0xe6f45c['equals'](_0x3ec348);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3be7fa,_0x4c4a88){const _0x3cb4d8=N(_0x3be7fa);return new E(_0x4c4a88,_0x3cb4d8);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x133a4b){return{'type':'value','snapshotNode':_0x133a4b};}function tt(_0x1eb5ac,_0x5b3abc){return{'type':'child_added','snapshotNode':_0x5b3abc,'childName':_0x1eb5ac};}function Nt(_0x388189,_0xc6ff88){return{'type':'child_removed','snapshotNode':_0xc6ff88,'childName':_0x388189};}function Pt(_0x333dd0,_0x5525ee,_0x2c519b){return{'type':'child_changed','snapshotNode':_0x5525ee,'childName':_0x333dd0,'oldSnap':_0x2c519b};}function $h(_0x1ece2d,_0x3496b3){return{'type':'child_moved','snapshotNode':_0x3496b3,'childName':_0x1ece2d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x31b9ff){this['index_']=_0x31b9ff;}['updateChild'](_0x3e253f,_0x1f0f79,_0x359755,_0x1f577b,_0x583b64,_0x2d35ad){f(_0x3e253f['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x522123=_0x3e253f['getImmediateChild'](_0x1f0f79);return _0x522123['getChild'](_0x1f577b)['equals'](_0x359755['getChild'](_0x1f577b))&&_0x522123['isEmpty']()===_0x359755['isEmpty']()||(_0x2d35ad!=null&&(_0x359755['isEmpty']()?_0x3e253f['hasChild'](_0x1f0f79)?_0x2d35ad['trackChildChange'](Nt(_0x1f0f79,_0x522123)):f(_0x3e253f['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x522123['isEmpty']()?_0x2d35ad['trackChildChange'](tt(_0x1f0f79,_0x359755)):_0x2d35ad['trackChildChange'](Pt(_0x1f0f79,_0x359755,_0x522123))),_0x3e253f['isLeafNode']()&&_0x359755['isEmpty']())?_0x3e253f:_0x3e253f['updateImmediateChild'](_0x1f0f79,_0x359755)['withIndex'](this['index_']);}['updateFullNode'](_0x358496,_0x3f617c,_0x1d2bbe){return _0x1d2bbe!=null&&(_0x358496['isLeafNode']()||_0x358496['forEachChild'](R,(_0x131858,_0x552946)=>{_0x3f617c['hasChild'](_0x131858)||_0x1d2bbe['trackChildChange'](Nt(_0x131858,_0x552946));}),_0x3f617c['isLeafNode']()||_0x3f617c['forEachChild'](R,(_0x15d5e5,_0x1a7744)=>{if(_0x358496['hasChild'](_0x15d5e5)){const _0x1a863b=_0x358496['getImmediateChild'](_0x15d5e5);_0x1a863b['equals'](_0x1a7744)||_0x1d2bbe['trackChildChange'](Pt(_0x15d5e5,_0x1a7744,_0x1a863b));}else _0x1d2bbe['trackChildChange'](tt(_0x15d5e5,_0x1a7744));})),_0x3f617c['withIndex'](this['index_']);}['updatePriority'](_0x2cc5a3,_0x17c069){return _0x2cc5a3['isEmpty']()?g['EMPTY_NODE']:_0x2cc5a3['updatePriority'](_0x17c069);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x4bd868){this['indexedFilter_']=new Yi(_0x4bd868['getIndex']()),this['index_']=_0x4bd868['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x4bd868),this['endPost_']=Ot['getEndPost_'](_0x4bd868),this['startIsInclusive_']=!_0x4bd868['startAfterSet_'],this['endIsInclusive_']=!_0x4bd868['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5e4d60){const _0x3254c9=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5e4d60)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5e4d60)<0x0,_0x4b5363=this['endIsInclusive_']?this['index_']['compare'](_0x5e4d60,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5e4d60,this['getEndPost']())<0x0;return _0x3254c9&&_0x4b5363;}['updateChild'](_0x2f3cbd,_0x100ed8,_0x56ffc5,_0x420888,_0x2441ca,_0x71f903){return this['matches'](new E(_0x100ed8,_0x56ffc5))||(_0x56ffc5=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2f3cbd,_0x100ed8,_0x56ffc5,_0x420888,_0x2441ca,_0x71f903);}['updateFullNode'](_0x2892ec,_0xadc719,_0x163d29){_0xadc719['isLeafNode']()&&(_0xadc719=g['EMPTY_NODE']);let _0xec8b5a=_0xadc719['withIndex'](this['index_']);_0xec8b5a=_0xec8b5a['updatePriority'](g['EMPTY_NODE']);const _0x4dc09e=this;return _0xadc719['forEachChild'](R,(_0x245fe0,_0x3a2fa7)=>{_0x4dc09e['matches'](new E(_0x245fe0,_0x3a2fa7))||(_0xec8b5a=_0xec8b5a['updateImmediateChild'](_0x245fe0,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2892ec,_0xec8b5a,_0x163d29);}['updatePriority'](_0x47472b,_0xc62717){return _0x47472b;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x465821){if(_0x465821['hasStart']()){const _0x1f649d=_0x465821['getIndexStartName']();return _0x465821['getIndex']()['makePost'](_0x465821['getIndexStartValue'](),_0x1f649d);}else return _0x465821['getIndex']()['minPost']();}static['getEndPost_'](_0x25bc54){if(_0x25bc54['hasEnd']()){const _0x5e435c=_0x25bc54['getIndexEndName']();return _0x25bc54['getIndex']()['makePost'](_0x25bc54['getIndexEndValue'](),_0x5e435c);}else return _0x25bc54['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x283216){this['withinDirectionalStart']=_0x1a545d=>this['reverse_']?this['withinEndPost'](_0x1a545d):this['withinStartPost'](_0x1a545d),this['withinDirectionalEnd']=_0x8d5d00=>this['reverse_']?this['withinStartPost'](_0x8d5d00):this['withinEndPost'](_0x8d5d00),this['withinStartPost']=_0x5cc766=>{const _0x191f54=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5cc766);return this['startIsInclusive_']?_0x191f54<=0x0:_0x191f54<0x0;},this['withinEndPost']=_0x37f526=>{const _0x3047ef=this['index_']['compare'](_0x37f526,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3047ef<=0x0:_0x3047ef<0x0;},this['rangedFilter_']=new Ot(_0x283216),this['index_']=_0x283216['getIndex'](),this['limit_']=_0x283216['getLimit'](),this['reverse_']=!_0x283216['isViewFromLeft'](),this['startIsInclusive_']=!_0x283216['startAfterSet_'],this['endIsInclusive_']=!_0x283216['endBeforeSet_'];}['updateChild'](_0x24d310,_0xeed350,_0x38ba6b,_0x1b1ba9,_0x5e4d30,_0x2423e2){return this['rangedFilter_']['matches'](new E(_0xeed350,_0x38ba6b))||(_0x38ba6b=g['EMPTY_NODE']),_0x24d310['getImmediateChild'](_0xeed350)['equals'](_0x38ba6b)?_0x24d310:_0x24d310['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x24d310,_0xeed350,_0x38ba6b,_0x1b1ba9,_0x5e4d30,_0x2423e2):this['fullLimitUpdateChild_'](_0x24d310,_0xeed350,_0x38ba6b,_0x5e4d30,_0x2423e2);}['updateFullNode'](_0x4f4a86,_0x348403,_0x2eaac8){let _0x685c01;if(_0x348403['isLeafNode']()||_0x348403['isEmpty']())_0x685c01=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x348403['numChildren']()&&_0x348403['isIndexed'](this['index_'])){_0x685c01=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x32a13a;this['reverse_']?_0x32a13a=_0x348403['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x32a13a=_0x348403['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x274084=0x0;for(;_0x32a13a['hasNext']()&&_0x274084<this['limit_'];){const _0x3fd8e5=_0x32a13a['getNext']();if(this['withinDirectionalStart'](_0x3fd8e5)){if(this['withinDirectionalEnd'](_0x3fd8e5))_0x685c01=_0x685c01['updateImmediateChild'](_0x3fd8e5['name'],_0x3fd8e5['node']),_0x274084++;else break;}else continue;}}else{_0x685c01=_0x348403['withIndex'](this['index_']),_0x685c01=_0x685c01['updatePriority'](g['EMPTY_NODE']);let _0x95e272;this['reverse_']?_0x95e272=_0x685c01['getReverseIterator'](this['index_']):_0x95e272=_0x685c01['getIterator'](this['index_']);let _0x4f006e=0x0;for(;_0x95e272['hasNext']();){const _0x2555ff=_0x95e272['getNext']();_0x4f006e<this['limit_']&&this['withinDirectionalStart'](_0x2555ff)&&this['withinDirectionalEnd'](_0x2555ff)?_0x4f006e++:_0x685c01=_0x685c01['updateImmediateChild'](_0x2555ff['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4f4a86,_0x685c01,_0x2eaac8);}['updatePriority'](_0x255a16,_0x48765c){return _0x255a16;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x26d568,_0x4d000b,_0x423c0e,_0x17a11a,_0x3791a3){let _0x3cd995;if(this['reverse_']){const _0x59add0=this['index_']['getCompare']();_0x3cd995=(_0x2eec61,_0x4f0146)=>_0x59add0(_0x4f0146,_0x2eec61);}else _0x3cd995=this['index_']['getCompare']();const _0x521191=_0x26d568;f(_0x521191['numChildren']()===this['limit_'],'');const _0xc08005=new E(_0x4d000b,_0x423c0e),_0x12c5f1=this['reverse_']?_0x521191['getFirstChild'](this['index_']):_0x521191['getLastChild'](this['index_']),_0x4a1038=this['rangedFilter_']['matches'](_0xc08005);if(_0x521191['hasChild'](_0x4d000b)){const _0x485507=_0x521191['getImmediateChild'](_0x4d000b);let _0x489233=_0x17a11a['getChildAfterChild'](this['index_'],_0x12c5f1,this['reverse_']);for(;_0x489233!=null&&(_0x489233['name']===_0x4d000b||_0x521191['hasChild'](_0x489233['name']));)_0x489233=_0x17a11a['getChildAfterChild'](this['index_'],_0x489233,this['reverse_']);const _0x4b9c27=_0x489233==null?0x1:_0x3cd995(_0x489233,_0xc08005);if(_0x4a1038&&!_0x423c0e['isEmpty']()&&_0x4b9c27>=0x0)return _0x3791a3!=null&&_0x3791a3['trackChildChange'](Pt(_0x4d000b,_0x423c0e,_0x485507)),_0x521191['updateImmediateChild'](_0x4d000b,_0x423c0e);{_0x3791a3!=null&&_0x3791a3['trackChildChange'](Nt(_0x4d000b,_0x485507));const _0x479677=_0x521191['updateImmediateChild'](_0x4d000b,g['EMPTY_NODE']);return _0x489233!=null&&this['rangedFilter_']['matches'](_0x489233)?(_0x3791a3!=null&&_0x3791a3['trackChildChange'](tt(_0x489233['name'],_0x489233['node'])),_0x479677['updateImmediateChild'](_0x489233['name'],_0x489233['node'])):_0x479677;}}else return _0x423c0e['isEmpty']()?_0x26d568:_0x4a1038&&_0x3cd995(_0x12c5f1,_0xc08005)>=0x0?(_0x3791a3!=null&&(_0x3791a3['trackChildChange'](Nt(_0x12c5f1['name'],_0x12c5f1['node'])),_0x3791a3['trackChildChange'](tt(_0x4d000b,_0x423c0e))),_0x521191['updateImmediateChild'](_0x4d000b,_0x423c0e)['updateImmediateChild'](_0x12c5f1['name'],g['EMPTY_NODE'])):_0x26d568;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x13219c=new Qi();return _0x13219c['limitSet_']=this['limitSet_'],_0x13219c['limit_']=this['limit_'],_0x13219c['startSet_']=this['startSet_'],_0x13219c['startAfterSet_']=this['startAfterSet_'],_0x13219c['indexStartValue_']=this['indexStartValue_'],_0x13219c['startNameSet_']=this['startNameSet_'],_0x13219c['indexStartName_']=this['indexStartName_'],_0x13219c['endSet_']=this['endSet_'],_0x13219c['endBeforeSet_']=this['endBeforeSet_'],_0x13219c['indexEndValue_']=this['indexEndValue_'],_0x13219c['endNameSet_']=this['endNameSet_'],_0x13219c['indexEndName_']=this['indexEndName_'],_0x13219c['index_']=this['index_'],_0x13219c['viewFrom_']=this['viewFrom_'],_0x13219c;}}function qh(_0x3a457e){return _0x3a457e['loadsAllData']()?new Yi(_0x3a457e['getIndex']()):_0x3a457e['hasLimit']()?new Gh(_0x3a457e):new Ot(_0x3a457e);}function zh(_0x281378,_0x472e45){const _0x1b737d=_0x281378['copy']();return _0x1b737d['limitSet_']=!0x0,_0x1b737d['limit_']=_0x472e45,_0x1b737d['viewFrom_']='l',_0x1b737d;}function jh(_0x3adbb2,_0x479516,_0x5abf3a){const _0xae6015=_0x3adbb2['copy']();return _0xae6015['startSet_']=!0x0,_0x479516===void 0x0&&(_0x479516=null),_0xae6015['indexStartValue_']=_0x479516,_0x5abf3a!=null?(_0xae6015['startNameSet_']=!0x0,_0xae6015['indexStartName_']=_0x5abf3a):(_0xae6015['startNameSet_']=!0x1,_0xae6015['indexStartName_']=''),_0xae6015;}function Kh(_0x38a012,_0x578280,_0x11ead3){const _0x5604ae=_0x38a012['copy']();return _0x5604ae['endSet_']=!0x0,_0x578280===void 0x0&&(_0x578280=null),_0x5604ae['indexEndValue_']=_0x578280,_0x11ead3!==void 0x0?(_0x5604ae['endNameSet_']=!0x0,_0x5604ae['indexEndName_']=_0x11ead3):(_0x5604ae['endNameSet_']=!0x1,_0x5604ae['indexEndName_']=''),_0x5604ae;}function Do(_0x3707d6,_0x533c5f){const _0x323745=_0x3707d6['copy']();return _0x323745['index_']=_0x533c5f,_0x323745;}function tr(_0x557fa6){const _0x4231d2={};if(_0x557fa6['isDefault']())return _0x4231d2;let _0x5cec89;if(_0x557fa6['index_']===R?_0x5cec89='$priority':_0x557fa6['index_']===Po?_0x5cec89='$value':_0x557fa6['index_']===ye?_0x5cec89='$key':(f(_0x557fa6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5cec89=_0x557fa6['index_']['toString']()),_0x4231d2['orderBy']=O(_0x5cec89),_0x557fa6['startSet_']){const _0x3d3fb5=_0x557fa6['startAfterSet_']?'startAfter':'startAt';_0x4231d2[_0x3d3fb5]=O(_0x557fa6['indexStartValue_']),_0x557fa6['startNameSet_']&&(_0x4231d2[_0x3d3fb5]+=','+O(_0x557fa6['indexStartName_']));}if(_0x557fa6['endSet_']){const _0xdae230=_0x557fa6['endBeforeSet_']?'endBefore':'endAt';_0x4231d2[_0xdae230]=O(_0x557fa6['indexEndValue_']),_0x557fa6['endNameSet_']&&(_0x4231d2[_0xdae230]+=','+O(_0x557fa6['indexEndName_']));}return _0x557fa6['limitSet_']&&(_0x557fa6['isViewFromLeft']()?_0x4231d2['limitToFirst']=_0x557fa6['limit_']:_0x4231d2['limitToLast']=_0x557fa6['limit_']),_0x4231d2;}function nr(_0x52cdaa){const _0x96a66b={};if(_0x52cdaa['startSet_']&&(_0x96a66b['sp']=_0x52cdaa['indexStartValue_'],_0x52cdaa['startNameSet_']&&(_0x96a66b['sn']=_0x52cdaa['indexStartName_']),_0x96a66b['sin']=!_0x52cdaa['startAfterSet_']),_0x52cdaa['endSet_']&&(_0x96a66b['ep']=_0x52cdaa['indexEndValue_'],_0x52cdaa['endNameSet_']&&(_0x96a66b['en']=_0x52cdaa['indexEndName_']),_0x96a66b['ein']=!_0x52cdaa['endBeforeSet_']),_0x52cdaa['limitSet_']){_0x96a66b['l']=_0x52cdaa['limit_'];let _0x365cdc=_0x52cdaa['viewFrom_'];_0x365cdc===''&&(_0x52cdaa['isViewFromLeft']()?_0x365cdc='l':_0x365cdc='r'),_0x96a66b['vf']=_0x365cdc;}return _0x52cdaa['index_']!==R&&(_0x96a66b['i']=_0x52cdaa['index_']['toString']()),_0x96a66b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x55319a){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5dba79,_0x14dc66){return _0x14dc66!==void 0x0?'tag$'+_0x14dc66:(f(_0x5dba79['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5dba79['_path']['toString']());}constructor(_0x13190f,_0x16eb3a,_0x56adad,_0x554151){super(),this['repoInfo_']=_0x13190f,this['onDataUpdate_']=_0x16eb3a,this['authTokenProvider_']=_0x56adad,this['appCheckTokenProvider_']=_0x554151,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2cc8ad,_0x3ef358,_0x206e16,_0x312e3f){const _0x5f1e87=_0x2cc8ad['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5f1e87+'\x20'+_0x2cc8ad['_queryIdentifier']);const _0x29ca67=fn['getListenId_'](_0x2cc8ad,_0x206e16),_0x3cc296={};this['listens_'][_0x29ca67]=_0x3cc296;const _0x76ec02=tr(_0x2cc8ad['_queryParams']);this['restRequest_'](_0x5f1e87+'.json',_0x76ec02,(_0x51c6f8,_0x4813cb)=>{let _0x55ccda=_0x4813cb;if(_0x51c6f8===0x194&&(_0x55ccda=null,_0x51c6f8=null),_0x51c6f8===null&&this['onDataUpdate_'](_0x5f1e87,_0x55ccda,!0x1,_0x206e16),Oe(this['listens_'],_0x29ca67)===_0x3cc296){let _0x4cb3aa;_0x51c6f8?_0x51c6f8===0x191?_0x4cb3aa='permission_denied':_0x4cb3aa='rest_error:'+_0x51c6f8:_0x4cb3aa='ok',_0x312e3f(_0x4cb3aa,null);}});}['unlisten'](_0x13e3f5,_0x20ff53){const _0x2e9673=fn['getListenId_'](_0x13e3f5,_0x20ff53);delete this['listens_'][_0x2e9673];}['get'](_0x25522e){const _0x2523d6=tr(_0x25522e['_queryParams']),_0x2dde86=_0x25522e['_path']['toString'](),_0x3e60dc=new Ve();return this['restRequest_'](_0x2dde86+'.json',_0x2523d6,(_0x2c13c0,_0x5d99ed)=>{let _0x1ddd7f=_0x5d99ed;_0x2c13c0===0x194&&(_0x1ddd7f=null,_0x2c13c0=null),_0x2c13c0===null?(this['onDataUpdate_'](_0x2dde86,_0x1ddd7f,!0x1,null),_0x3e60dc['resolve'](_0x1ddd7f)):_0x3e60dc['reject'](new Error(_0x1ddd7f));}),_0x3e60dc['promise'];}['refreshAuthToken'](_0x16ba8f){}['restRequest_'](_0x4bc969,_0x2bc52e={},_0x164fcf){return _0x2bc52e['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x904d92,_0x49959d])=>{_0x904d92&&_0x904d92['accessToken']&&(_0x2bc52e['auth']=_0x904d92['accessToken']),_0x49959d&&_0x49959d['token']&&(_0x2bc52e['ac']=_0x49959d['token']);const _0x1b24e6=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4bc969+'?ns='+this['repoInfo_']['namespace']+at(_0x2bc52e);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1b24e6);const _0x26bade=new XMLHttpRequest();_0x26bade['onreadystatechange']=()=>{if(_0x164fcf&&_0x26bade['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1b24e6+'\x20received.\x20status:',_0x26bade['status'],'response:',_0x26bade['responseText']);let _0x41eb99=null;if(_0x26bade['status']>=0xc8&&_0x26bade['status']<0x12c){try{_0x41eb99=bt(_0x26bade['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1b24e6+':\x20'+_0x26bade['responseText']);}_0x164fcf(null,_0x41eb99);}else _0x26bade['status']!==0x191&&_0x26bade['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1b24e6+'\x20Status:\x20'+_0x26bade['status']),_0x164fcf(_0x26bade['status']);_0x164fcf=null;}},_0x26bade['open']('GET',_0x1b24e6,!0x0),_0x26bade['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x348039){return this['rootNode_']['getChild'](_0x348039);}['updateSnapshot'](_0x338fcf,_0x1bc4ea){this['rootNode_']=this['rootNode_']['updateChild'](_0x338fcf,_0x1bc4ea);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x1f981a,_0x3d6073,_0x1f59d2){if(v(_0x3d6073))_0x1f981a['value']=_0x1f59d2,_0x1f981a['children']['clear']();else{if(_0x1f981a['value']!==null)_0x1f981a['value']=_0x1f981a['value']['updateChild'](_0x3d6073,_0x1f59d2);else{const _0x879aca=y(_0x3d6073);_0x1f981a['children']['has'](_0x879aca)||_0x1f981a['children']['set'](_0x879aca,pn());const _0x24c617=_0x1f981a['children']['get'](_0x879aca);_0x3d6073=b(_0x3d6073),Mo(_0x24c617,_0x3d6073,_0x1f59d2);}}}function Ei(_0x4935de,_0x364d16,_0x5d5098){_0x4935de['value']!==null?_0x5d5098(_0x364d16,_0x4935de['value']):Qh(_0x4935de,(_0x606086,_0x3cf31f)=>{const _0x4fbafa=new C(_0x364d16['toString']()+'/'+_0x606086);Ei(_0x3cf31f,_0x4fbafa,_0x5d5098);});}function Qh(_0x5a86d8,_0x4d5865){_0x5a86d8['children']['forEach']((_0x570bda,_0x432ebd)=>{_0x4d5865(_0x432ebd,_0x570bda);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x4fc68d){this['collection_']=_0x4fc68d,this['last_']=null;}['get'](){const _0x516d66=this['collection_']['get'](),_0x3737f8={..._0x516d66};return this['last_']&&x(this['last_'],(_0x4ea076,_0x3b98be)=>{_0x3737f8[_0x4ea076]=_0x3737f8[_0x4ea076]-_0x3b98be;}),this['last_']=_0x516d66,_0x3737f8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x1fd0ac,_0x2aa5c9){this['server_']=_0x2aa5c9,this['statsToReport_']={},this['statsListener_']=new Jh(_0x1fd0ac);const _0x1dfdfd=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1dfdfd));}['reportStats_'](){const _0x2e6507=this['statsListener_']['get'](),_0x369cd6={};let _0x360157=!0x1;x(_0x2e6507,(_0x14b871,_0x3d6842)=>{_0x3d6842>0x0&&Y(this['statsToReport_'],_0x14b871)&&(_0x369cd6[_0x14b871]=_0x3d6842,_0x360157=!0x0);}),_0x360157&&this['server_']['reportStats'](_0x369cd6),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x2cc3b1){_0x2cc3b1[_0x2cc3b1['OVERWRITE']=0x0]='OVERWRITE',_0x2cc3b1[_0x2cc3b1['MERGE']=0x1]='MERGE',_0x2cc3b1[_0x2cc3b1['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2cc3b1[_0x2cc3b1['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x346205){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x346205,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3f5a5f,_0x25bb73,_0x34fc95){this['path']=_0x3f5a5f,this['affectedTree']=_0x25bb73,this['revert']=_0x34fc95,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x490a5c){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xbcdf85=this['affectedTree']['subtree'](new C(_0x490a5c));return new _n(w(),_0xbcdf85,this['revert']);}}else return f(y(this['path'])===_0x490a5c,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x276f3c,_0x1d395f){this['source']=_0x276f3c,this['path']=_0x1d395f,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1e730d){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x36e932,_0x127ebb,_0x23d1c2){this['source']=_0x36e932,this['path']=_0x127ebb,this['snap']=_0x23d1c2,this['type']=q['OVERWRITE'];}['operationForChild'](_0x2e4380){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x2e4380)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x11886d,_0x9727f7,_0x1dc13e){this['source']=_0x11886d,this['path']=_0x9727f7,this['children']=_0x1dc13e,this['type']=q['MERGE'];}['operationForChild'](_0x29bbdc){if(v(this['path'])){const _0x2ecf0a=this['children']['subtree'](new C(_0x29bbdc));return _0x2ecf0a['isEmpty']()?null:_0x2ecf0a['value']?new Fe(this['source'],w(),_0x2ecf0a['value']):new nt(this['source'],w(),_0x2ecf0a);}else return f(y(this['path'])===_0x29bbdc,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x5538c5,_0x1ed5c5,_0x1ed350){this['node_']=_0x5538c5,this['fullyInitialized_']=_0x1ed5c5,this['filtered_']=_0x1ed350;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4e4380){if(v(_0x4e4380))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4ef19b=y(_0x4e4380);return this['isCompleteForChild'](_0x4ef19b);}['isCompleteForChild'](_0x58bd4d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x58bd4d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4ec8ad){this['query_']=_0x4ec8ad,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x16d1de,_0x2384da,_0xa083d3,_0x5c15b2){const _0x27b99c=[],_0x79e408=[];return _0x2384da['forEach'](_0x1ae870=>{_0x1ae870['type']==='child_changed'&&_0x16d1de['index_']['indexedValueChanged'](_0x1ae870['oldSnap'],_0x1ae870['snapshotNode'])&&_0x79e408['push']($h(_0x1ae870['childName'],_0x1ae870['snapshotNode']));}),mt(_0x16d1de,_0x27b99c,'child_removed',_0x2384da,_0x5c15b2,_0xa083d3),mt(_0x16d1de,_0x27b99c,'child_added',_0x2384da,_0x5c15b2,_0xa083d3),mt(_0x16d1de,_0x27b99c,'child_moved',_0x79e408,_0x5c15b2,_0xa083d3),mt(_0x16d1de,_0x27b99c,'child_changed',_0x2384da,_0x5c15b2,_0xa083d3),mt(_0x16d1de,_0x27b99c,'value',_0x2384da,_0x5c15b2,_0xa083d3),_0x27b99c;}function mt(_0x599374,_0x39f1d2,_0x449bcc,_0x59f41d,_0x1dcb84,_0x35bbbd){const _0x3169a2=_0x59f41d['filter'](_0x19242c=>_0x19242c['type']===_0x449bcc);_0x3169a2['sort']((_0x45cd42,_0x49bd93)=>su(_0x599374,_0x45cd42,_0x49bd93)),_0x3169a2['forEach'](_0x179cde=>{const _0x4a0722=iu(_0x599374,_0x179cde,_0x35bbbd);_0x1dcb84['forEach'](_0x1eed81=>{_0x1eed81['respondsTo'](_0x179cde['type'])&&_0x39f1d2['push'](_0x1eed81['createEvent'](_0x4a0722,_0x599374['query_']));});});}function iu(_0x38a609,_0xfe6fc,_0x498486){return _0xfe6fc['type']==='value'||_0xfe6fc['type']==='child_removed'||(_0xfe6fc['prevName']=_0x498486['getPredecessorChildName'](_0xfe6fc['childName'],_0xfe6fc['snapshotNode'],_0x38a609['index_'])),_0xfe6fc;}function su(_0xb22f18,_0x1bb17e,_0xebdaaf){if(_0x1bb17e['childName']==null||_0xebdaaf['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x33fd0e=new E(_0x1bb17e['childName'],_0x1bb17e['snapshotNode']),_0x481f09=new E(_0xebdaaf['childName'],_0xebdaaf['snapshotNode']);return _0xb22f18['index_']['compare'](_0x33fd0e,_0x481f09);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xe7aa93,_0x34223a){return{'eventCache':_0xe7aa93,'serverCache':_0x34223a};}function wt(_0x33df09,_0x5c2d0d,_0x52633c,_0x92ccf5){return Dn(new Ce(_0x5c2d0d,_0x52633c,_0x92ccf5),_0x33df09['serverCache']);}function Lo(_0x4135e2,_0xa05633,_0x42ea2a,_0x35e356){return Dn(_0x4135e2['eventCache'],new Ce(_0xa05633,_0x42ea2a,_0x35e356));}function gn(_0x1addc8){return _0x1addc8['eventCache']['isFullyInitialized']()?_0x1addc8['eventCache']['getNode']():null;}function Ue(_0x2f4386){return _0x2f4386['serverCache']['isFullyInitialized']()?_0x2f4386['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x140fd9){let _0x2bf361=new S(null);return x(_0x140fd9,(_0x51780a,_0x34fb11)=>{_0x2bf361=_0x2bf361['set'](new C(_0x51780a),_0x34fb11);}),_0x2bf361;}constructor(_0x7e275,_0x19baf7=ru()){this['value']=_0x7e275,this['children']=_0x19baf7;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xe8f9e5,_0x23c3c4){if(this['value']!=null&&_0x23c3c4(this['value']))return{'path':w(),'value':this['value']};if(v(_0xe8f9e5))return null;{const _0x59aa22=y(_0xe8f9e5),_0x3fba3a=this['children']['get'](_0x59aa22);if(_0x3fba3a!==null){const _0x3b1275=_0x3fba3a['findRootMostMatchingPathAndValue'](b(_0xe8f9e5),_0x23c3c4);return _0x3b1275!=null?{'path':A(new C(_0x59aa22),_0x3b1275['path']),'value':_0x3b1275['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x330b5c){return this['findRootMostMatchingPathAndValue'](_0x330b5c,()=>!0x0);}['subtree'](_0x371247){if(v(_0x371247))return this;{const _0x14fe1c=y(_0x371247),_0x4a6c19=this['children']['get'](_0x14fe1c);return _0x4a6c19!==null?_0x4a6c19['subtree'](b(_0x371247)):new S(null);}}['set'](_0x4a137e,_0x35fd4d){if(v(_0x4a137e))return new S(_0x35fd4d,this['children']);{const _0x206a41=y(_0x4a137e),_0x318a04=(this['children']['get'](_0x206a41)||new S(null))['set'](b(_0x4a137e),_0x35fd4d),_0x5ba1b1=this['children']['insert'](_0x206a41,_0x318a04);return new S(this['value'],_0x5ba1b1);}}['remove'](_0x4a4179){if(v(_0x4a4179))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x93e339=y(_0x4a4179),_0x3d958f=this['children']['get'](_0x93e339);if(_0x3d958f){const _0x362f72=_0x3d958f['remove'](b(_0x4a4179));let _0x3d22f6;return _0x362f72['isEmpty']()?_0x3d22f6=this['children']['remove'](_0x93e339):_0x3d22f6=this['children']['insert'](_0x93e339,_0x362f72),this['value']===null&&_0x3d22f6['isEmpty']()?new S(null):new S(this['value'],_0x3d22f6);}else return this;}}['get'](_0x26e9f0){if(v(_0x26e9f0))return this['value'];{const _0x5f07df=y(_0x26e9f0),_0x4c9cea=this['children']['get'](_0x5f07df);return _0x4c9cea?_0x4c9cea['get'](b(_0x26e9f0)):null;}}['setTree'](_0x2f6c26,_0x504acc){if(v(_0x2f6c26))return _0x504acc;{const _0x573cdb=y(_0x2f6c26),_0x36f90e=(this['children']['get'](_0x573cdb)||new S(null))['setTree'](b(_0x2f6c26),_0x504acc);let _0x3af553;return _0x36f90e['isEmpty']()?_0x3af553=this['children']['remove'](_0x573cdb):_0x3af553=this['children']['insert'](_0x573cdb,_0x36f90e),new S(this['value'],_0x3af553);}}['fold'](_0x56f9ab){return this['fold_'](w(),_0x56f9ab);}['fold_'](_0x44d019,_0x5a500a){const _0x765c4={};return this['children']['inorderTraversal']((_0x4a3655,_0x4dc52b)=>{_0x765c4[_0x4a3655]=_0x4dc52b['fold_'](A(_0x44d019,_0x4a3655),_0x5a500a);}),_0x5a500a(_0x44d019,this['value'],_0x765c4);}['findOnPath'](_0xe407df,_0x53afa5){return this['findOnPath_'](_0xe407df,w(),_0x53afa5);}['findOnPath_'](_0x5d7098,_0x1b97f7,_0x1d38d6){const _0x4ca139=this['value']?_0x1d38d6(_0x1b97f7,this['value']):!0x1;if(_0x4ca139)return _0x4ca139;if(v(_0x5d7098))return null;{const _0x44e0d2=y(_0x5d7098),_0x421f47=this['children']['get'](_0x44e0d2);return _0x421f47?_0x421f47['findOnPath_'](b(_0x5d7098),A(_0x1b97f7,_0x44e0d2),_0x1d38d6):null;}}['foreachOnPath'](_0x301f71,_0x75f20f){return this['foreachOnPath_'](_0x301f71,w(),_0x75f20f);}['foreachOnPath_'](_0x44eba5,_0x1b1322,_0x5d33d6){if(v(_0x44eba5))return this;{this['value']&&_0x5d33d6(_0x1b1322,this['value']);const _0x38c214=y(_0x44eba5),_0xafa598=this['children']['get'](_0x38c214);return _0xafa598?_0xafa598['foreachOnPath_'](b(_0x44eba5),A(_0x1b1322,_0x38c214),_0x5d33d6):new S(null);}}['foreach'](_0x77e88){this['foreach_'](w(),_0x77e88);}['foreach_'](_0x24b89b,_0x1e6bb3){this['children']['inorderTraversal']((_0xb2b4de,_0x2ef1e4)=>{_0x2ef1e4['foreach_'](A(_0x24b89b,_0xb2b4de),_0x1e6bb3);}),this['value']&&_0x1e6bb3(_0x24b89b,this['value']);}['foreachChild'](_0x585c9d){this['children']['inorderTraversal']((_0x49e9b4,_0x38cabe)=>{_0x38cabe['value']&&_0x585c9d(_0x49e9b4,_0x38cabe['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x435786){this['writeTree_']=_0x435786;}static['empty'](){return new j(new S(null));}}function Ct(_0x504d25,_0x451d28,_0x45548b){if(v(_0x451d28))return new j(new S(_0x45548b));{const _0x49cc7b=_0x504d25['writeTree_']['findRootMostValueAndPath'](_0x451d28);if(_0x49cc7b!=null){const _0x3bb2ee=_0x49cc7b['path'];let _0x352725=_0x49cc7b['value'];const _0x4a874e=F(_0x3bb2ee,_0x451d28);return _0x352725=_0x352725['updateChild'](_0x4a874e,_0x45548b),new j(_0x504d25['writeTree_']['set'](_0x3bb2ee,_0x352725));}else{const _0x26dcd6=new S(_0x45548b),_0x1c31c2=_0x504d25['writeTree_']['setTree'](_0x451d28,_0x26dcd6);return new j(_0x1c31c2);}}}function Ii(_0x9f8e7f,_0x5a1fde,_0x5e6d4e){let _0xbd9a03=_0x9f8e7f;return x(_0x5e6d4e,(_0x5948c8,_0x1bcafa)=>{_0xbd9a03=Ct(_0xbd9a03,A(_0x5a1fde,_0x5948c8),_0x1bcafa);}),_0xbd9a03;}function sr(_0x3beb31,_0x146de4){if(v(_0x146de4))return j['empty']();{const _0x2f6ad3=_0x3beb31['writeTree_']['setTree'](_0x146de4,new S(null));return new j(_0x2f6ad3);}}function wi(_0x23124d,_0x2038e4){return $e(_0x23124d,_0x2038e4)!=null;}function $e(_0x5bfd5a,_0x29355e){const _0x442ac4=_0x5bfd5a['writeTree_']['findRootMostValueAndPath'](_0x29355e);return _0x442ac4!=null?_0x5bfd5a['writeTree_']['get'](_0x442ac4['path'])['getChild'](F(_0x442ac4['path'],_0x29355e)):null;}function rr(_0x3a827a){const _0x1e753a=[],_0x37930f=_0x3a827a['writeTree_']['value'];return _0x37930f!=null?_0x37930f['isLeafNode']()||_0x37930f['forEachChild'](R,(_0x1b4289,_0x2c239c)=>{_0x1e753a['push'](new E(_0x1b4289,_0x2c239c));}):_0x3a827a['writeTree_']['children']['inorderTraversal']((_0x146470,_0x539833)=>{_0x539833['value']!=null&&_0x1e753a['push'](new E(_0x146470,_0x539833['value']));}),_0x1e753a;}function ve(_0x3768ee,_0x5cee18){if(v(_0x5cee18))return _0x3768ee;{const _0x2b7b83=$e(_0x3768ee,_0x5cee18);return _0x2b7b83!=null?new j(new S(_0x2b7b83)):new j(_0x3768ee['writeTree_']['subtree'](_0x5cee18));}}function Ci(_0x34108e){return _0x34108e['writeTree_']['isEmpty']();}function it(_0x2ed157,_0x15ab22){return xo(w(),_0x2ed157['writeTree_'],_0x15ab22);}function xo(_0x9b4120,_0x18361e,_0x1e1cef){if(_0x18361e['value']!=null)return _0x1e1cef['updateChild'](_0x9b4120,_0x18361e['value']);{let _0x4d19a0=null;return _0x18361e['children']['inorderTraversal']((_0x234e86,_0x578475)=>{_0x234e86==='.priority'?(f(_0x578475['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4d19a0=_0x578475['value']):_0x1e1cef=xo(A(_0x9b4120,_0x234e86),_0x578475,_0x1e1cef);}),!_0x1e1cef['getChild'](_0x9b4120)['isEmpty']()&&_0x4d19a0!==null&&(_0x1e1cef=_0x1e1cef['updateChild'](A(_0x9b4120,'.priority'),_0x4d19a0)),_0x1e1cef;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3bf3ce,_0x16ce21){return Bo(_0x16ce21,_0x3bf3ce);}function ou(_0x175e0f,_0x20d4f0,_0x6ebbe7,_0x1d66c8,_0x468c52){f(_0x1d66c8>_0x175e0f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x468c52===void 0x0&&(_0x468c52=!0x0),_0x175e0f['allWrites']['push']({'path':_0x20d4f0,'snap':_0x6ebbe7,'writeId':_0x1d66c8,'visible':_0x468c52}),_0x468c52&&(_0x175e0f['visibleWrites']=Ct(_0x175e0f['visibleWrites'],_0x20d4f0,_0x6ebbe7)),_0x175e0f['lastWriteId']=_0x1d66c8;}function au(_0x2c7f90,_0x5bce2c,_0x49d427,_0x26169a){f(_0x26169a>_0x2c7f90['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2c7f90['allWrites']['push']({'path':_0x5bce2c,'children':_0x49d427,'writeId':_0x26169a,'visible':!0x0}),_0x2c7f90['visibleWrites']=Ii(_0x2c7f90['visibleWrites'],_0x5bce2c,_0x49d427),_0x2c7f90['lastWriteId']=_0x26169a;}function cu(_0x185253,_0x4d6337){for(let _0xcc9c0a=0x0;_0xcc9c0a<_0x185253['allWrites']['length'];_0xcc9c0a++){const _0x28aa0d=_0x185253['allWrites'][_0xcc9c0a];if(_0x28aa0d['writeId']===_0x4d6337)return _0x28aa0d;}return null;}function lu(_0x16fb74,_0x509398){const _0xd1a40c=_0x16fb74['allWrites']['findIndex'](_0x511b20=>_0x511b20['writeId']===_0x509398);f(_0xd1a40c>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x434577=_0x16fb74['allWrites'][_0xd1a40c];_0x16fb74['allWrites']['splice'](_0xd1a40c,0x1);let _0x496783=_0x434577['visible'],_0x1a888a=!0x1,_0x210042=_0x16fb74['allWrites']['length']-0x1;for(;_0x496783&&_0x210042>=0x0;){const _0x3084c5=_0x16fb74['allWrites'][_0x210042];_0x3084c5['visible']&&(_0x210042>=_0xd1a40c&&hu(_0x3084c5,_0x434577['path'])?_0x496783=!0x1:$(_0x434577['path'],_0x3084c5['path'])&&(_0x1a888a=!0x0)),_0x210042--;}if(_0x496783){if(_0x1a888a)return uu(_0x16fb74),!0x0;if(_0x434577['snap'])_0x16fb74['visibleWrites']=sr(_0x16fb74['visibleWrites'],_0x434577['path']);else{const _0x35b913=_0x434577['children'];x(_0x35b913,_0x12cf1c=>{_0x16fb74['visibleWrites']=sr(_0x16fb74['visibleWrites'],A(_0x434577['path'],_0x12cf1c));});}return!0x0;}else return!0x1;}function hu(_0x465490,_0x4b01c6){if(_0x465490['snap'])return $(_0x465490['path'],_0x4b01c6);for(const _0x5506a4 in _0x465490['children'])if(_0x465490['children']['hasOwnProperty'](_0x5506a4)&&$(A(_0x465490['path'],_0x5506a4),_0x4b01c6))return!0x0;return!0x1;}function uu(_0x29891b){_0x29891b['visibleWrites']=Fo(_0x29891b['allWrites'],du,w()),_0x29891b['allWrites']['length']>0x0?_0x29891b['lastWriteId']=_0x29891b['allWrites'][_0x29891b['allWrites']['length']-0x1]['writeId']:_0x29891b['lastWriteId']=-0x1;}function du(_0x3b3c8c){return _0x3b3c8c['visible'];}function Fo(_0x368361,_0x5405b9,_0x235197){let _0x573220=j['empty']();for(let _0x34b318=0x0;_0x34b318<_0x368361['length'];++_0x34b318){const _0x2ab5f2=_0x368361[_0x34b318];if(_0x5405b9(_0x2ab5f2)){const _0x1c90b2=_0x2ab5f2['path'];let _0x5b2eec;if(_0x2ab5f2['snap'])$(_0x235197,_0x1c90b2)?(_0x5b2eec=F(_0x235197,_0x1c90b2),_0x573220=Ct(_0x573220,_0x5b2eec,_0x2ab5f2['snap'])):$(_0x1c90b2,_0x235197)&&(_0x5b2eec=F(_0x1c90b2,_0x235197),_0x573220=Ct(_0x573220,w(),_0x2ab5f2['snap']['getChild'](_0x5b2eec)));else{if(_0x2ab5f2['children']){if($(_0x235197,_0x1c90b2))_0x5b2eec=F(_0x235197,_0x1c90b2),_0x573220=Ii(_0x573220,_0x5b2eec,_0x2ab5f2['children']);else{if($(_0x1c90b2,_0x235197)){if(_0x5b2eec=F(_0x1c90b2,_0x235197),v(_0x5b2eec))_0x573220=Ii(_0x573220,w(),_0x2ab5f2['children']);else{const _0x4158f9=Oe(_0x2ab5f2['children'],y(_0x5b2eec));if(_0x4158f9){const _0x564c0=_0x4158f9['getChild'](b(_0x5b2eec));_0x573220=Ct(_0x573220,w(),_0x564c0);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x573220;}function Uo(_0x2fc3fd,_0x1e299a,_0x3bd555,_0x4bea35,_0x506cc6){if(!_0x4bea35&&!_0x506cc6){const _0x47cfcc=$e(_0x2fc3fd['visibleWrites'],_0x1e299a);if(_0x47cfcc!=null)return _0x47cfcc;{const _0x1b9431=ve(_0x2fc3fd['visibleWrites'],_0x1e299a);if(Ci(_0x1b9431))return _0x3bd555;if(_0x3bd555==null&&!wi(_0x1b9431,w()))return null;{const _0x3719a1=_0x3bd555||g['EMPTY_NODE'];return it(_0x1b9431,_0x3719a1);}}}else{const _0x2616c1=ve(_0x2fc3fd['visibleWrites'],_0x1e299a);if(!_0x506cc6&&Ci(_0x2616c1))return _0x3bd555;if(!_0x506cc6&&_0x3bd555==null&&!wi(_0x2616c1,w()))return null;{const _0x506834=function(_0x304028){return(_0x304028['visible']||_0x506cc6)&&(!_0x4bea35||!~_0x4bea35['indexOf'](_0x304028['writeId']))&&($(_0x304028['path'],_0x1e299a)||$(_0x1e299a,_0x304028['path']));},_0x43c4b6=Fo(_0x2fc3fd['allWrites'],_0x506834,_0x1e299a),_0x12b80e=_0x3bd555||g['EMPTY_NODE'];return it(_0x43c4b6,_0x12b80e);}}}function fu(_0x44286c,_0x5c972e,_0x3ef30e){let _0x468b35=g['EMPTY_NODE'];const _0x4a5305=$e(_0x44286c['visibleWrites'],_0x5c972e);if(_0x4a5305)return _0x4a5305['isLeafNode']()||_0x4a5305['forEachChild'](R,(_0x1b63dd,_0x4dbb20)=>{_0x468b35=_0x468b35['updateImmediateChild'](_0x1b63dd,_0x4dbb20);}),_0x468b35;if(_0x3ef30e){const _0x56c7ea=ve(_0x44286c['visibleWrites'],_0x5c972e);return _0x3ef30e['forEachChild'](R,(_0x11e61b,_0x584735)=>{const _0x1b22cd=it(ve(_0x56c7ea,new C(_0x11e61b)),_0x584735);_0x468b35=_0x468b35['updateImmediateChild'](_0x11e61b,_0x1b22cd);}),rr(_0x56c7ea)['forEach'](_0x29e87d=>{_0x468b35=_0x468b35['updateImmediateChild'](_0x29e87d['name'],_0x29e87d['node']);}),_0x468b35;}else{const _0x506e57=ve(_0x44286c['visibleWrites'],_0x5c972e);return rr(_0x506e57)['forEach'](_0x4cfa61=>{_0x468b35=_0x468b35['updateImmediateChild'](_0x4cfa61['name'],_0x4cfa61['node']);}),_0x468b35;}}function pu(_0x32b5de,_0x46b8a8,_0x56924d,_0x21de82,_0x2c4a92){f(_0x21de82||_0x2c4a92,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1b6da9=A(_0x46b8a8,_0x56924d);if(wi(_0x32b5de['visibleWrites'],_0x1b6da9))return null;{const _0x44677a=ve(_0x32b5de['visibleWrites'],_0x1b6da9);return Ci(_0x44677a)?_0x2c4a92['getChild'](_0x56924d):it(_0x44677a,_0x2c4a92['getChild'](_0x56924d));}}function _u(_0x5bdea1,_0x12599b,_0x505410,_0x1ddf9d){const _0x964b85=A(_0x12599b,_0x505410),_0x320094=$e(_0x5bdea1['visibleWrites'],_0x964b85);if(_0x320094!=null)return _0x320094;if(_0x1ddf9d['isCompleteForChild'](_0x505410)){const _0x278378=ve(_0x5bdea1['visibleWrites'],_0x964b85);return it(_0x278378,_0x1ddf9d['getNode']()['getImmediateChild'](_0x505410));}else return null;}function gu(_0x587d26,_0x4f04b0){return $e(_0x587d26['visibleWrites'],_0x4f04b0);}function mu(_0x23843a,_0x4ba35f,_0x5a8b28,_0x3baf75,_0x30e4b1,_0x2fca3a,_0x33091d){let _0x351527;const _0x40fad1=ve(_0x23843a['visibleWrites'],_0x4ba35f),_0x241642=$e(_0x40fad1,w());if(_0x241642!=null)_0x351527=_0x241642;else{if(_0x5a8b28!=null)_0x351527=it(_0x40fad1,_0x5a8b28);else return[];}if(_0x351527=_0x351527['withIndex'](_0x33091d),!_0x351527['isEmpty']()&&!_0x351527['isLeafNode']()){const _0x4311d8=[],_0x2d4eea=_0x33091d['getCompare'](),_0x227c04=_0x2fca3a?_0x351527['getReverseIteratorFrom'](_0x3baf75,_0x33091d):_0x351527['getIteratorFrom'](_0x3baf75,_0x33091d);let _0x199c62=_0x227c04['getNext']();for(;_0x199c62&&_0x4311d8['length']<_0x30e4b1;)_0x2d4eea(_0x199c62,_0x3baf75)!==0x0&&_0x4311d8['push'](_0x199c62),_0x199c62=_0x227c04['getNext']();return _0x4311d8;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xa212d7,_0x246000,_0x5af14f,_0x441432){return Uo(_0xa212d7['writeTree'],_0xa212d7['treePath'],_0x246000,_0x5af14f,_0x441432);}function es(_0x241a35,_0x2853e2){return fu(_0x241a35['writeTree'],_0x241a35['treePath'],_0x2853e2);}function or(_0x116cf3,_0x5a40f6,_0x42f70b,_0x5dfcbf){return pu(_0x116cf3['writeTree'],_0x116cf3['treePath'],_0x5a40f6,_0x42f70b,_0x5dfcbf);}function yn(_0xba1344,_0x427901){return gu(_0xba1344['writeTree'],A(_0xba1344['treePath'],_0x427901));}function vu(_0x159344,_0x4c9230,_0x4eb624,_0x401502,_0x4a2e95,_0x33908a){return mu(_0x159344['writeTree'],_0x159344['treePath'],_0x4c9230,_0x4eb624,_0x401502,_0x4a2e95,_0x33908a);}function ts(_0x20e5e8,_0x516827,_0x24c856){return _u(_0x20e5e8['writeTree'],_0x20e5e8['treePath'],_0x516827,_0x24c856);}function Wo(_0x15a38c,_0x5b76a1){return Bo(A(_0x15a38c['treePath'],_0x5b76a1),_0x15a38c['writeTree']);}function Bo(_0x2b6ac6,_0x437af7){return{'treePath':_0x2b6ac6,'writeTree':_0x437af7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x533ccf){const _0xfca0a8=_0x533ccf['type'],_0x1916d3=_0x533ccf['childName'];f(_0xfca0a8==='child_added'||_0xfca0a8==='child_changed'||_0xfca0a8==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1916d3!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x260c56=this['changeMap']['get'](_0x1916d3);if(_0x260c56){const _0x56aaac=_0x260c56['type'];if(_0xfca0a8==='child_added'&&_0x56aaac==='child_removed')this['changeMap']['set'](_0x1916d3,Pt(_0x1916d3,_0x533ccf['snapshotNode'],_0x260c56['snapshotNode']));else{if(_0xfca0a8==='child_removed'&&_0x56aaac==='child_added')this['changeMap']['delete'](_0x1916d3);else{if(_0xfca0a8==='child_removed'&&_0x56aaac==='child_changed')this['changeMap']['set'](_0x1916d3,Nt(_0x1916d3,_0x260c56['oldSnap']));else{if(_0xfca0a8==='child_changed'&&_0x56aaac==='child_added')this['changeMap']['set'](_0x1916d3,tt(_0x1916d3,_0x533ccf['snapshotNode']));else{if(_0xfca0a8==='child_changed'&&_0x56aaac==='child_changed')this['changeMap']['set'](_0x1916d3,Pt(_0x1916d3,_0x533ccf['snapshotNode'],_0x260c56['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x533ccf+'\x20occurred\x20after\x20'+_0x260c56);}}}}}else this['changeMap']['set'](_0x1916d3,_0x533ccf);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x64aa9d){return null;}['getChildAfterChild'](_0x433609,_0x188cd9,_0x154f3a){return null;}}const Vo=new Iu();class ns{constructor(_0x4ffea2,_0x55804b,_0x2eef7b=null){this['writes_']=_0x4ffea2,this['viewCache_']=_0x55804b,this['optCompleteServerCache_']=_0x2eef7b;}['getCompleteChild'](_0x225f6c){const _0xd4fb56=this['viewCache_']['eventCache'];if(_0xd4fb56['isCompleteForChild'](_0x225f6c))return _0xd4fb56['getNode']()['getImmediateChild'](_0x225f6c);{const _0x49de8e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x225f6c,_0x49de8e);}}['getChildAfterChild'](_0x492342,_0x53a15f,_0x10e392){const _0x78bae3=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x1307ab=vu(this['writes_'],_0x78bae3,_0x53a15f,0x1,_0x10e392,_0x492342);return _0x1307ab['length']===0x0?null:_0x1307ab[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x6046a){return{'filter':_0x6046a};}function Cu(_0x349788,_0x534279){f(_0x534279['eventCache']['getNode']()['isIndexed'](_0x349788['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x534279['serverCache']['getNode']()['isIndexed'](_0x349788['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x34fbf2,_0x6daabe,_0x3b5683,_0x1b18a8,_0x44bb94){const _0x4b1a66=new Eu();let _0x370902,_0xaee27b;if(_0x3b5683['type']===q['OVERWRITE']){const _0x9c3c7f=_0x3b5683;_0x9c3c7f['source']['fromUser']?_0x370902=Ti(_0x34fbf2,_0x6daabe,_0x9c3c7f['path'],_0x9c3c7f['snap'],_0x1b18a8,_0x44bb94,_0x4b1a66):(f(_0x9c3c7f['source']['fromServer'],'Unknown\x20source.'),_0xaee27b=_0x9c3c7f['source']['tagged']||_0x6daabe['serverCache']['isFiltered']()&&!v(_0x9c3c7f['path']),_0x370902=vn(_0x34fbf2,_0x6daabe,_0x9c3c7f['path'],_0x9c3c7f['snap'],_0x1b18a8,_0x44bb94,_0xaee27b,_0x4b1a66));}else{if(_0x3b5683['type']===q['MERGE']){const _0x30a280=_0x3b5683;_0x30a280['source']['fromUser']?_0x370902=bu(_0x34fbf2,_0x6daabe,_0x30a280['path'],_0x30a280['children'],_0x1b18a8,_0x44bb94,_0x4b1a66):(f(_0x30a280['source']['fromServer'],'Unknown\x20source.'),_0xaee27b=_0x30a280['source']['tagged']||_0x6daabe['serverCache']['isFiltered'](),_0x370902=Si(_0x34fbf2,_0x6daabe,_0x30a280['path'],_0x30a280['children'],_0x1b18a8,_0x44bb94,_0xaee27b,_0x4b1a66));}else{if(_0x3b5683['type']===q['ACK_USER_WRITE']){const _0x2f59ea=_0x3b5683;_0x2f59ea['revert']?_0x370902=ku(_0x34fbf2,_0x6daabe,_0x2f59ea['path'],_0x1b18a8,_0x44bb94,_0x4b1a66):_0x370902=Ru(_0x34fbf2,_0x6daabe,_0x2f59ea['path'],_0x2f59ea['affectedTree'],_0x1b18a8,_0x44bb94,_0x4b1a66);}else{if(_0x3b5683['type']===q['LISTEN_COMPLETE'])_0x370902=Au(_0x34fbf2,_0x6daabe,_0x3b5683['path'],_0x1b18a8,_0x4b1a66);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3b5683['type']);}}}const _0x28df0d=_0x4b1a66['getChanges']();return Su(_0x6daabe,_0x370902,_0x28df0d),{'viewCache':_0x370902,'changes':_0x28df0d};}function Su(_0x427fe1,_0x45f2ff,_0x8464b9){const _0x25e380=_0x45f2ff['eventCache'];if(_0x25e380['isFullyInitialized']()){const _0x30d843=_0x25e380['getNode']()['isLeafNode']()||_0x25e380['getNode']()['isEmpty'](),_0x392e27=gn(_0x427fe1);(_0x8464b9['length']>0x0||!_0x427fe1['eventCache']['isFullyInitialized']()||_0x30d843&&!_0x25e380['getNode']()['equals'](_0x392e27)||!_0x25e380['getNode']()['getPriority']()['equals'](_0x392e27['getPriority']()))&&_0x8464b9['push'](Oo(gn(_0x45f2ff)));}}function Ho(_0x53cf4a,_0x128f23,_0x37a6d2,_0x2e9c88,_0x48a64c,_0x505a61){const _0x1bffb4=_0x128f23['eventCache'];if(yn(_0x2e9c88,_0x37a6d2)!=null)return _0x128f23;{let _0x2ffbbd,_0x49519f;if(v(_0x37a6d2)){if(f(_0x128f23['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x128f23['serverCache']['isFiltered']()){const _0x5c144c=Ue(_0x128f23),_0x4e158d=_0x5c144c instanceof g?_0x5c144c:g['EMPTY_NODE'],_0x4279b2=es(_0x2e9c88,_0x4e158d);_0x2ffbbd=_0x53cf4a['filter']['updateFullNode'](_0x128f23['eventCache']['getNode'](),_0x4279b2,_0x505a61);}else{const _0x2ff62a=mn(_0x2e9c88,Ue(_0x128f23));_0x2ffbbd=_0x53cf4a['filter']['updateFullNode'](_0x128f23['eventCache']['getNode'](),_0x2ff62a,_0x505a61);}}else{const _0x2a7c1f=y(_0x37a6d2);if(_0x2a7c1f==='.priority'){f(we(_0x37a6d2)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3fefa2=_0x1bffb4['getNode']();_0x49519f=_0x128f23['serverCache']['getNode']();const _0x220c67=or(_0x2e9c88,_0x37a6d2,_0x3fefa2,_0x49519f);_0x220c67!=null?_0x2ffbbd=_0x53cf4a['filter']['updatePriority'](_0x3fefa2,_0x220c67):_0x2ffbbd=_0x1bffb4['getNode']();}else{const _0x403a2a=b(_0x37a6d2);let _0x34b8f3;if(_0x1bffb4['isCompleteForChild'](_0x2a7c1f)){_0x49519f=_0x128f23['serverCache']['getNode']();const _0x38b906=or(_0x2e9c88,_0x37a6d2,_0x1bffb4['getNode'](),_0x49519f);_0x38b906!=null?_0x34b8f3=_0x1bffb4['getNode']()['getImmediateChild'](_0x2a7c1f)['updateChild'](_0x403a2a,_0x38b906):_0x34b8f3=_0x1bffb4['getNode']()['getImmediateChild'](_0x2a7c1f);}else _0x34b8f3=ts(_0x2e9c88,_0x2a7c1f,_0x128f23['serverCache']);_0x34b8f3!=null?_0x2ffbbd=_0x53cf4a['filter']['updateChild'](_0x1bffb4['getNode'](),_0x2a7c1f,_0x34b8f3,_0x403a2a,_0x48a64c,_0x505a61):_0x2ffbbd=_0x1bffb4['getNode']();}}return wt(_0x128f23,_0x2ffbbd,_0x1bffb4['isFullyInitialized']()||v(_0x37a6d2),_0x53cf4a['filter']['filtersNodes']());}}function vn(_0x1cf42b,_0x2ae61d,_0x2ec6e7,_0x2fb4e3,_0x1949db,_0x4b3f14,_0x31f4bd,_0x49ef55){const _0x1c27bb=_0x2ae61d['serverCache'];let _0xa5146a;const _0x41fedd=_0x31f4bd?_0x1cf42b['filter']:_0x1cf42b['filter']['getIndexedFilter']();if(v(_0x2ec6e7))_0xa5146a=_0x41fedd['updateFullNode'](_0x1c27bb['getNode'](),_0x2fb4e3,null);else{if(_0x41fedd['filtersNodes']()&&!_0x1c27bb['isFiltered']()){const _0x17f2e2=_0x1c27bb['getNode']()['updateChild'](_0x2ec6e7,_0x2fb4e3);_0xa5146a=_0x41fedd['updateFullNode'](_0x1c27bb['getNode'](),_0x17f2e2,null);}else{const _0xdbc4d3=y(_0x2ec6e7);if(!_0x1c27bb['isCompleteForPath'](_0x2ec6e7)&&we(_0x2ec6e7)>0x1)return _0x2ae61d;const _0x3fb788=b(_0x2ec6e7),_0x1604c7=_0x1c27bb['getNode']()['getImmediateChild'](_0xdbc4d3)['updateChild'](_0x3fb788,_0x2fb4e3);_0xdbc4d3==='.priority'?_0xa5146a=_0x41fedd['updatePriority'](_0x1c27bb['getNode'](),_0x1604c7):_0xa5146a=_0x41fedd['updateChild'](_0x1c27bb['getNode'](),_0xdbc4d3,_0x1604c7,_0x3fb788,Vo,null);}}const _0x45ba81=Lo(_0x2ae61d,_0xa5146a,_0x1c27bb['isFullyInitialized']()||v(_0x2ec6e7),_0x41fedd['filtersNodes']()),_0x219346=new ns(_0x1949db,_0x45ba81,_0x4b3f14);return Ho(_0x1cf42b,_0x45ba81,_0x2ec6e7,_0x1949db,_0x219346,_0x49ef55);}function Ti(_0x419c93,_0x25d6fb,_0xc16aca,_0x321b63,_0x41a602,_0x529377,_0x28046a){const _0x1ead02=_0x25d6fb['eventCache'];let _0x5cf029,_0x145030;const _0x25b1f2=new ns(_0x41a602,_0x25d6fb,_0x529377);if(v(_0xc16aca))_0x145030=_0x419c93['filter']['updateFullNode'](_0x25d6fb['eventCache']['getNode'](),_0x321b63,_0x28046a),_0x5cf029=wt(_0x25d6fb,_0x145030,!0x0,_0x419c93['filter']['filtersNodes']());else{const _0x20f712=y(_0xc16aca);if(_0x20f712==='.priority')_0x145030=_0x419c93['filter']['updatePriority'](_0x25d6fb['eventCache']['getNode'](),_0x321b63),_0x5cf029=wt(_0x25d6fb,_0x145030,_0x1ead02['isFullyInitialized'](),_0x1ead02['isFiltered']());else{const _0x4457bf=b(_0xc16aca),_0x4f4774=_0x1ead02['getNode']()['getImmediateChild'](_0x20f712);let _0x3c3b66;if(v(_0x4457bf))_0x3c3b66=_0x321b63;else{const _0x2738e8=_0x25b1f2['getCompleteChild'](_0x20f712);_0x2738e8!=null?Gi(_0x4457bf)==='.priority'&&_0x2738e8['getChild'](To(_0x4457bf))['isEmpty']()?_0x3c3b66=_0x2738e8:_0x3c3b66=_0x2738e8['updateChild'](_0x4457bf,_0x321b63):_0x3c3b66=g['EMPTY_NODE'];}if(_0x4f4774['equals'](_0x3c3b66))_0x5cf029=_0x25d6fb;else{const _0x4f4df6=_0x419c93['filter']['updateChild'](_0x1ead02['getNode'](),_0x20f712,_0x3c3b66,_0x4457bf,_0x25b1f2,_0x28046a);_0x5cf029=wt(_0x25d6fb,_0x4f4df6,_0x1ead02['isFullyInitialized'](),_0x419c93['filter']['filtersNodes']());}}}return _0x5cf029;}function ar(_0x197759,_0x1e7bdb){return _0x197759['eventCache']['isCompleteForChild'](_0x1e7bdb);}function bu(_0x51e498,_0x5c5db0,_0x46f560,_0x359a8f,_0xa50fea,_0x4acef0,_0x5907b2){let _0x205292=_0x5c5db0;return _0x359a8f['foreach']((_0x306585,_0x5b2416)=>{const _0x3d33a2=A(_0x46f560,_0x306585);ar(_0x5c5db0,y(_0x3d33a2))&&(_0x205292=Ti(_0x51e498,_0x205292,_0x3d33a2,_0x5b2416,_0xa50fea,_0x4acef0,_0x5907b2));}),_0x359a8f['foreach']((_0x2e70a6,_0x4b8516)=>{const _0x49ed20=A(_0x46f560,_0x2e70a6);ar(_0x5c5db0,y(_0x49ed20))||(_0x205292=Ti(_0x51e498,_0x205292,_0x49ed20,_0x4b8516,_0xa50fea,_0x4acef0,_0x5907b2));}),_0x205292;}function cr(_0x1f10a9,_0x3404a8,_0x3f04ec){return _0x3f04ec['foreach']((_0xc8f537,_0x21ff85)=>{_0x3404a8=_0x3404a8['updateChild'](_0xc8f537,_0x21ff85);}),_0x3404a8;}function Si(_0x268f63,_0x25a928,_0x4f00f4,_0x2df0c6,_0x420a54,_0x1c9ce2,_0x1bbb41,_0x2a306f){if(_0x25a928['serverCache']['getNode']()['isEmpty']()&&!_0x25a928['serverCache']['isFullyInitialized']())return _0x25a928;let _0x26ebe1=_0x25a928,_0x2d0dc5;v(_0x4f00f4)?_0x2d0dc5=_0x2df0c6:_0x2d0dc5=new S(null)['setTree'](_0x4f00f4,_0x2df0c6);const _0x52c1c2=_0x25a928['serverCache']['getNode']();return _0x2d0dc5['children']['inorderTraversal']((_0x58f007,_0x4d0250)=>{if(_0x52c1c2['hasChild'](_0x58f007)){const _0x25ef2e=_0x25a928['serverCache']['getNode']()['getImmediateChild'](_0x58f007),_0x248270=cr(_0x268f63,_0x25ef2e,_0x4d0250);_0x26ebe1=vn(_0x268f63,_0x26ebe1,new C(_0x58f007),_0x248270,_0x420a54,_0x1c9ce2,_0x1bbb41,_0x2a306f);}}),_0x2d0dc5['children']['inorderTraversal']((_0x2bfe87,_0xa98a38)=>{const _0x1579b8=!_0x25a928['serverCache']['isCompleteForChild'](_0x2bfe87)&&_0xa98a38['value']===null;if(!_0x52c1c2['hasChild'](_0x2bfe87)&&!_0x1579b8){const _0x517963=_0x25a928['serverCache']['getNode']()['getImmediateChild'](_0x2bfe87),_0x5895cb=cr(_0x268f63,_0x517963,_0xa98a38);_0x26ebe1=vn(_0x268f63,_0x26ebe1,new C(_0x2bfe87),_0x5895cb,_0x420a54,_0x1c9ce2,_0x1bbb41,_0x2a306f);}}),_0x26ebe1;}function Ru(_0x20a763,_0x4b28ed,_0x39abef,_0x20cf54,_0x43c24f,_0x4a0655,_0x428667){if(yn(_0x43c24f,_0x39abef)!=null)return _0x4b28ed;const _0x54ac9f=_0x4b28ed['serverCache']['isFiltered'](),_0x49416f=_0x4b28ed['serverCache'];if(_0x20cf54['value']!=null){if(v(_0x39abef)&&_0x49416f['isFullyInitialized']()||_0x49416f['isCompleteForPath'](_0x39abef))return vn(_0x20a763,_0x4b28ed,_0x39abef,_0x49416f['getNode']()['getChild'](_0x39abef),_0x43c24f,_0x4a0655,_0x54ac9f,_0x428667);if(v(_0x39abef)){let _0x26cbd0=new S(null);return _0x49416f['getNode']()['forEachChild'](ye,(_0x2ec9c9,_0x343af6)=>{_0x26cbd0=_0x26cbd0['set'](new C(_0x2ec9c9),_0x343af6);}),Si(_0x20a763,_0x4b28ed,_0x39abef,_0x26cbd0,_0x43c24f,_0x4a0655,_0x54ac9f,_0x428667);}else return _0x4b28ed;}else{let _0x2fc7e2=new S(null);return _0x20cf54['foreach']((_0x45e237,_0x2f47f0)=>{const _0x2c7ca8=A(_0x39abef,_0x45e237);_0x49416f['isCompleteForPath'](_0x2c7ca8)&&(_0x2fc7e2=_0x2fc7e2['set'](_0x45e237,_0x49416f['getNode']()['getChild'](_0x2c7ca8)));}),Si(_0x20a763,_0x4b28ed,_0x39abef,_0x2fc7e2,_0x43c24f,_0x4a0655,_0x54ac9f,_0x428667);}}function Au(_0x3a579b,_0x16df70,_0x4c8d76,_0x4902c6,_0x5d0f97){const _0x43496f=_0x16df70['serverCache'],_0x26dc14=Lo(_0x16df70,_0x43496f['getNode'](),_0x43496f['isFullyInitialized']()||v(_0x4c8d76),_0x43496f['isFiltered']());return Ho(_0x3a579b,_0x26dc14,_0x4c8d76,_0x4902c6,Vo,_0x5d0f97);}function ku(_0x508bf6,_0x38e0f9,_0x28eea6,_0x4bdc36,_0x467b23,_0x97d7bf){let _0x4195fa;if(yn(_0x4bdc36,_0x28eea6)!=null)return _0x38e0f9;{const _0x41ec43=new ns(_0x4bdc36,_0x38e0f9,_0x467b23),_0xbc56f2=_0x38e0f9['eventCache']['getNode']();let _0x5f1e6e;if(v(_0x28eea6)||y(_0x28eea6)==='.priority'){let _0x31adf1;if(_0x38e0f9['serverCache']['isFullyInitialized']())_0x31adf1=mn(_0x4bdc36,Ue(_0x38e0f9));else{const _0x44e545=_0x38e0f9['serverCache']['getNode']();f(_0x44e545 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x31adf1=es(_0x4bdc36,_0x44e545);}_0x31adf1=_0x31adf1,_0x5f1e6e=_0x508bf6['filter']['updateFullNode'](_0xbc56f2,_0x31adf1,_0x97d7bf);}else{const _0x558aea=y(_0x28eea6);let _0x394fa9=ts(_0x4bdc36,_0x558aea,_0x38e0f9['serverCache']);_0x394fa9==null&&_0x38e0f9['serverCache']['isCompleteForChild'](_0x558aea)&&(_0x394fa9=_0xbc56f2['getImmediateChild'](_0x558aea)),_0x394fa9!=null?_0x5f1e6e=_0x508bf6['filter']['updateChild'](_0xbc56f2,_0x558aea,_0x394fa9,b(_0x28eea6),_0x41ec43,_0x97d7bf):_0x38e0f9['eventCache']['getNode']()['hasChild'](_0x558aea)?_0x5f1e6e=_0x508bf6['filter']['updateChild'](_0xbc56f2,_0x558aea,g['EMPTY_NODE'],b(_0x28eea6),_0x41ec43,_0x97d7bf):_0x5f1e6e=_0xbc56f2,_0x5f1e6e['isEmpty']()&&_0x38e0f9['serverCache']['isFullyInitialized']()&&(_0x4195fa=mn(_0x4bdc36,Ue(_0x38e0f9)),_0x4195fa['isLeafNode']()&&(_0x5f1e6e=_0x508bf6['filter']['updateFullNode'](_0x5f1e6e,_0x4195fa,_0x97d7bf)));}return _0x4195fa=_0x38e0f9['serverCache']['isFullyInitialized']()||yn(_0x4bdc36,w())!=null,wt(_0x38e0f9,_0x5f1e6e,_0x4195fa,_0x508bf6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x16bd93,_0x1e6e98){this['query_']=_0x16bd93,this['eventRegistrations_']=[];const _0x12cd98=this['query_']['_queryParams'],_0xd670ec=new Yi(_0x12cd98['getIndex']()),_0xbc6e00=qh(_0x12cd98);this['processor_']=wu(_0xbc6e00);const _0x49296f=_0x1e6e98['serverCache'],_0x7bf94b=_0x1e6e98['eventCache'],_0xfa90b6=_0xd670ec['updateFullNode'](g['EMPTY_NODE'],_0x49296f['getNode'](),null),_0x35716f=_0xbc6e00['updateFullNode'](g['EMPTY_NODE'],_0x7bf94b['getNode'](),null),_0x11fbb4=new Ce(_0xfa90b6,_0x49296f['isFullyInitialized'](),_0xd670ec['filtersNodes']()),_0x395562=new Ce(_0x35716f,_0x7bf94b['isFullyInitialized'](),_0xbc6e00['filtersNodes']());this['viewCache_']=Dn(_0x395562,_0x11fbb4),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x403a24){return _0x403a24['viewCache_']['serverCache']['getNode']();}function Ou(_0x11552a){return gn(_0x11552a['viewCache_']);}function Du(_0x15c215,_0x11a7fe){const _0x5c41f6=Ue(_0x15c215['viewCache_']);return _0x5c41f6&&(_0x15c215['query']['_queryParams']['loadsAllData']()||!v(_0x11a7fe)&&!_0x5c41f6['getImmediateChild'](y(_0x11a7fe))['isEmpty']())?_0x5c41f6['getChild'](_0x11a7fe):null;}function lr(_0x240c9c){return _0x240c9c['eventRegistrations_']['length']===0x0;}function Mu(_0x1c6fd2,_0x5b15ae){_0x1c6fd2['eventRegistrations_']['push'](_0x5b15ae);}function hr(_0x2527fd,_0x48dc4,_0x10e160){const _0x14ba75=[];if(_0x10e160){f(_0x48dc4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x37c0cf=_0x2527fd['query']['_path'];_0x2527fd['eventRegistrations_']['forEach'](_0x356fda=>{const _0x5d9d05=_0x356fda['createCancelEvent'](_0x10e160,_0x37c0cf);_0x5d9d05&&_0x14ba75['push'](_0x5d9d05);});}if(_0x48dc4){let _0x18022a=[];for(let _0x5b472d=0x0;_0x5b472d<_0x2527fd['eventRegistrations_']['length'];++_0x5b472d){const _0xd4885d=_0x2527fd['eventRegistrations_'][_0x5b472d];if(!_0xd4885d['matches'](_0x48dc4))_0x18022a['push'](_0xd4885d);else{if(_0x48dc4['hasAnyCallback']()){_0x18022a=_0x18022a['concat'](_0x2527fd['eventRegistrations_']['slice'](_0x5b472d+0x1));break;}}}_0x2527fd['eventRegistrations_']=_0x18022a;}else _0x2527fd['eventRegistrations_']=[];return _0x14ba75;}function ur(_0xc49ebc,_0x4ecaeb,_0x327054,_0x36da04){_0x4ecaeb['type']===q['MERGE']&&_0x4ecaeb['source']['queryId']!==null&&(f(Ue(_0xc49ebc['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0xc49ebc['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5385ed=_0xc49ebc['viewCache_'],_0x338e3e=Tu(_0xc49ebc['processor_'],_0x5385ed,_0x4ecaeb,_0x327054,_0x36da04);return Cu(_0xc49ebc['processor_'],_0x338e3e['viewCache']),f(_0x338e3e['viewCache']['serverCache']['isFullyInitialized']()||!_0x5385ed['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xc49ebc['viewCache_']=_0x338e3e['viewCache'],$o(_0xc49ebc,_0x338e3e['changes'],_0x338e3e['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x196a2e,_0x318abf){const _0x3b2b9c=_0x196a2e['viewCache_']['eventCache'],_0x1d0285=[];return _0x3b2b9c['getNode']()['isLeafNode']()||_0x3b2b9c['getNode']()['forEachChild'](R,(_0x35992f,_0x150bbb)=>{_0x1d0285['push'](tt(_0x35992f,_0x150bbb));}),_0x3b2b9c['isFullyInitialized']()&&_0x1d0285['push'](Oo(_0x3b2b9c['getNode']())),$o(_0x196a2e,_0x1d0285,_0x3b2b9c['getNode'](),_0x318abf);}function $o(_0x4ccc4f,_0x53d4f6,_0x556a57,_0x56a2fc){const _0x32c14f=_0x56a2fc?[_0x56a2fc]:_0x4ccc4f['eventRegistrations_'];return nu(_0x4ccc4f['eventGenerator_'],_0x53d4f6,_0x556a57,_0x32c14f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x45d85c){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x45d85c;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x56cc15){return _0x56cc15['views']['size']===0x0;}function is(_0x2269ac,_0x4e6b7e,_0x515f71,_0x486b62){const _0xd31f4=_0x4e6b7e['source']['queryId'];if(_0xd31f4!==null){const _0x17ccb7=_0x2269ac['views']['get'](_0xd31f4);return f(_0x17ccb7!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x17ccb7,_0x4e6b7e,_0x515f71,_0x486b62);}else{let _0x39261c=[];for(const _0x3e4d62 of _0x2269ac['views']['values']())_0x39261c=_0x39261c['concat'](ur(_0x3e4d62,_0x4e6b7e,_0x515f71,_0x486b62));return _0x39261c;}}function qo(_0x128f3c,_0xc77334,_0x1f4cb1,_0x3a4a49,_0x8d9777){const _0x240c29=_0xc77334['_queryIdentifier'],_0x1ea9fa=_0x128f3c['views']['get'](_0x240c29);if(!_0x1ea9fa){let _0x50871a=mn(_0x1f4cb1,_0x8d9777?_0x3a4a49:null),_0x1fbe0c=!0x1;_0x50871a?_0x1fbe0c=!0x0:_0x3a4a49 instanceof g?(_0x50871a=es(_0x1f4cb1,_0x3a4a49),_0x1fbe0c=!0x1):(_0x50871a=g['EMPTY_NODE'],_0x1fbe0c=!0x1);const _0x22f04f=Dn(new Ce(_0x50871a,_0x1fbe0c,!0x1),new Ce(_0x3a4a49,_0x8d9777,!0x1));return new Nu(_0xc77334,_0x22f04f);}return _0x1ea9fa;}function Wu(_0x15d71f,_0x403761,_0x1aacc6,_0x1e9a0a,_0x40281c,_0x5e3327){const _0x4066ab=qo(_0x15d71f,_0x403761,_0x1e9a0a,_0x40281c,_0x5e3327);return _0x15d71f['views']['has'](_0x403761['_queryIdentifier'])||_0x15d71f['views']['set'](_0x403761['_queryIdentifier'],_0x4066ab),Mu(_0x4066ab,_0x1aacc6),Lu(_0x4066ab,_0x1aacc6);}function Bu(_0x31eea5,_0x36ae69,_0x77aef2,_0x4770a9){const _0x247169=_0x36ae69['_queryIdentifier'],_0x2cff84=[];let _0x197530=[];const _0x509d04=Te(_0x31eea5);if(_0x247169==='default'){for(const [_0x10cef5,_0x31c056]of _0x31eea5['views']['entries']())_0x197530=_0x197530['concat'](hr(_0x31c056,_0x77aef2,_0x4770a9)),lr(_0x31c056)&&(_0x31eea5['views']['delete'](_0x10cef5),_0x31c056['query']['_queryParams']['loadsAllData']()||_0x2cff84['push'](_0x31c056['query']));}else{const _0x2de6af=_0x31eea5['views']['get'](_0x247169);_0x2de6af&&(_0x197530=_0x197530['concat'](hr(_0x2de6af,_0x77aef2,_0x4770a9)),lr(_0x2de6af)&&(_0x31eea5['views']['delete'](_0x247169),_0x2de6af['query']['_queryParams']['loadsAllData']()||_0x2cff84['push'](_0x2de6af['query'])));}return _0x509d04&&!Te(_0x31eea5)&&_0x2cff84['push'](new(Fu())(_0x36ae69['_repo'],_0x36ae69['_path'])),{'removed':_0x2cff84,'events':_0x197530};}function zo(_0x4f4a1e){const _0x32744f=[];for(const _0x494b01 of _0x4f4a1e['views']['values']())_0x494b01['query']['_queryParams']['loadsAllData']()||_0x32744f['push'](_0x494b01);return _0x32744f;}function Ee(_0xfa53ba,_0x9e34f6){let _0x3d8820=null;for(const _0x595d93 of _0xfa53ba['views']['values']())_0x3d8820=_0x3d8820||Du(_0x595d93,_0x9e34f6);return _0x3d8820;}function jo(_0xe51370,_0x5038fb){if(_0x5038fb['_queryParams']['loadsAllData']())return Ln(_0xe51370);{const _0x225b40=_0x5038fb['_queryIdentifier'];return _0xe51370['views']['get'](_0x225b40);}}function Ko(_0x100473,_0x5376c2){return jo(_0x100473,_0x5376c2)!=null;}function Te(_0x5018a6){return Ln(_0x5018a6)!=null;}function Ln(_0x26a0c6){for(const _0x56a1b7 of _0x26a0c6['views']['values']())if(_0x56a1b7['query']['_queryParams']['loadsAllData']())return _0x56a1b7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x4cffa2){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x4cffa2;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0xaea0e3){this['listenProvider_']=_0xaea0e3,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x27ae51,_0x4fdc23,_0xb2bdfc,_0xcc18b7,_0x3bcf53){return ou(_0x27ae51['pendingWriteTree_'],_0x4fdc23,_0xb2bdfc,_0xcc18b7,_0x3bcf53),_0x3bcf53?ht(_0x27ae51,new Fe(Ji(),_0x4fdc23,_0xb2bdfc)):[];}function Gu(_0x2bab50,_0x15d2bb,_0x4b37c4,_0x3c2792){au(_0x2bab50['pendingWriteTree_'],_0x15d2bb,_0x4b37c4,_0x3c2792);const _0xff06d1=S['fromObject'](_0x4b37c4);return ht(_0x2bab50,new nt(Ji(),_0x15d2bb,_0xff06d1));}function pe(_0x5148a7,_0x5ab225,_0x55b1fa=!0x1){const _0x34f3f8=cu(_0x5148a7['pendingWriteTree_'],_0x5ab225);if(lu(_0x5148a7['pendingWriteTree_'],_0x5ab225)){let _0x3f2fd3=new S(null);return _0x34f3f8['snap']!=null?_0x3f2fd3=_0x3f2fd3['set'](w(),!0x0):x(_0x34f3f8['children'],_0x529c13=>{_0x3f2fd3=_0x3f2fd3['set'](new C(_0x529c13),!0x0);}),ht(_0x5148a7,new _n(_0x34f3f8['path'],_0x3f2fd3,_0x55b1fa));}else return[];}function $t(_0x7451dd,_0x962ed4,_0x358512){return ht(_0x7451dd,new Fe(Xi(),_0x962ed4,_0x358512));}function qu(_0x37f938,_0x5e81dd,_0x5aa26d){const _0x4d5b20=S['fromObject'](_0x5aa26d);return ht(_0x37f938,new nt(Xi(),_0x5e81dd,_0x4d5b20));}function zu(_0x233e8e,_0x1fe45a){return ht(_0x233e8e,new Dt(Xi(),_0x1fe45a));}function ju(_0x312c02,_0x5483d4,_0x54de0c){const _0x28e388=rs(_0x312c02,_0x54de0c);if(_0x28e388){const _0x475007=os(_0x28e388),_0x4e5027=_0x475007['path'],_0x5ea0c7=_0x475007['queryId'],_0x1bb652=F(_0x4e5027,_0x5483d4),_0x4c3e07=new Dt(Zi(_0x5ea0c7),_0x1bb652);return as(_0x312c02,_0x4e5027,_0x4c3e07);}else return[];}function wn(_0x5c66d3,_0x27e642,_0x4763cd,_0x440e1c,_0x581f69=!0x1){const _0xfc5527=_0x27e642['_path'],_0x44c3a8=_0x5c66d3['syncPointTree_']['get'](_0xfc5527);let _0x1cbfe5=[];if(_0x44c3a8&&(_0x27e642['_queryIdentifier']==='default'||Ko(_0x44c3a8,_0x27e642))){const _0x13b2ab=Bu(_0x44c3a8,_0x27e642,_0x4763cd,_0x440e1c);Uu(_0x44c3a8)&&(_0x5c66d3['syncPointTree_']=_0x5c66d3['syncPointTree_']['remove'](_0xfc5527));const _0x2ffcb6=_0x13b2ab['removed'];if(_0x1cbfe5=_0x13b2ab['events'],!_0x581f69){const _0x2a85c9=_0x2ffcb6['findIndex'](_0x1f9d3b=>_0x1f9d3b['_queryParams']['loadsAllData']())!==-0x1,_0x540835=_0x5c66d3['syncPointTree_']['findOnPath'](_0xfc5527,(_0x1686bf,_0x4f440b)=>Te(_0x4f440b));if(_0x2a85c9&&!_0x540835){const _0x4b3af1=_0x5c66d3['syncPointTree_']['subtree'](_0xfc5527);if(!_0x4b3af1['isEmpty']()){const _0x232f33=Qu(_0x4b3af1);for(let _0x3c2119=0x0;_0x3c2119<_0x232f33['length'];++_0x3c2119){const _0x5e6ff7=_0x232f33[_0x3c2119],_0x3d46d3=_0x5e6ff7['query'],_0x13c0cc=Xo(_0x5c66d3,_0x5e6ff7);_0x5c66d3['listenProvider_']['startListening'](Tt(_0x3d46d3),Mt(_0x5c66d3,_0x3d46d3),_0x13c0cc['hashFn'],_0x13c0cc['onComplete']);}}}!_0x540835&&_0x2ffcb6['length']>0x0&&!_0x440e1c&&(_0x2a85c9?_0x5c66d3['listenProvider_']['stopListening'](Tt(_0x27e642),null):_0x2ffcb6['forEach'](_0x2d0db5=>{const _0x4fe7e6=_0x5c66d3['queryToTagMap']['get'](Fn(_0x2d0db5));_0x5c66d3['listenProvider_']['stopListening'](Tt(_0x2d0db5),_0x4fe7e6);}));}Ju(_0x5c66d3,_0x2ffcb6);}return _0x1cbfe5;}function Yo(_0x29343c,_0x595cdb,_0x32c638,_0x324415){const _0x42774a=rs(_0x29343c,_0x324415);if(_0x42774a!=null){const _0x20a650=os(_0x42774a),_0x119c0e=_0x20a650['path'],_0x425dda=_0x20a650['queryId'],_0x1bfd6b=F(_0x119c0e,_0x595cdb),_0x120eb2=new Fe(Zi(_0x425dda),_0x1bfd6b,_0x32c638);return as(_0x29343c,_0x119c0e,_0x120eb2);}else return[];}function Ku(_0x15a345,_0x45e2b7,_0x3485e3,_0x52a04b){const _0x15587c=rs(_0x15a345,_0x52a04b);if(_0x15587c){const _0x4ea716=os(_0x15587c),_0x3dbadc=_0x4ea716['path'],_0x58bfbf=_0x4ea716['queryId'],_0x20bd8b=F(_0x3dbadc,_0x45e2b7),_0x1ffb77=S['fromObject'](_0x3485e3),_0x3f3d8a=new nt(Zi(_0x58bfbf),_0x20bd8b,_0x1ffb77);return as(_0x15a345,_0x3dbadc,_0x3f3d8a);}else return[];}function bi(_0x333e95,_0x2a8bdc,_0x3d2ae0,_0x5611e3=!0x1){const _0x1d581f=_0x2a8bdc['_path'];let _0x1cd46d=null,_0x384c0a=!0x1;_0x333e95['syncPointTree_']['foreachOnPath'](_0x1d581f,(_0x4d6b4e,_0x358350)=>{const _0x276711=F(_0x4d6b4e,_0x1d581f);_0x1cd46d=_0x1cd46d||Ee(_0x358350,_0x276711),_0x384c0a=_0x384c0a||Te(_0x358350);});let _0x275127=_0x333e95['syncPointTree_']['get'](_0x1d581f);_0x275127?(_0x384c0a=_0x384c0a||Te(_0x275127),_0x1cd46d=_0x1cd46d||Ee(_0x275127,w())):(_0x275127=new Go(),_0x333e95['syncPointTree_']=_0x333e95['syncPointTree_']['set'](_0x1d581f,_0x275127));let _0x2ec7ae;_0x1cd46d!=null?_0x2ec7ae=!0x0:(_0x2ec7ae=!0x1,_0x1cd46d=g['EMPTY_NODE'],_0x333e95['syncPointTree_']['subtree'](_0x1d581f)['foreachChild']((_0x1149df,_0x4654f8)=>{const _0x3dbab9=Ee(_0x4654f8,w());_0x3dbab9&&(_0x1cd46d=_0x1cd46d['updateImmediateChild'](_0x1149df,_0x3dbab9));}));const _0x43176b=Ko(_0x275127,_0x2a8bdc);if(!_0x43176b&&!_0x2a8bdc['_queryParams']['loadsAllData']()){const _0x1e263d=Fn(_0x2a8bdc);f(!_0x333e95['queryToTagMap']['has'](_0x1e263d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5c0332=Xu();_0x333e95['queryToTagMap']['set'](_0x1e263d,_0x5c0332),_0x333e95['tagToQueryMap']['set'](_0x5c0332,_0x1e263d);}const _0x1de799=Mn(_0x333e95['pendingWriteTree_'],_0x1d581f);let _0x837a16=Wu(_0x275127,_0x2a8bdc,_0x3d2ae0,_0x1de799,_0x1cd46d,_0x2ec7ae);if(!_0x43176b&&!_0x384c0a&&!_0x5611e3){const _0x311bc=jo(_0x275127,_0x2a8bdc);_0x837a16=_0x837a16['concat'](Zu(_0x333e95,_0x2a8bdc,_0x311bc));}return _0x837a16;}function xn(_0x571d82,_0x4e2e39,_0x592586){const _0x1852ba=_0x571d82['pendingWriteTree_'],_0x352af9=_0x571d82['syncPointTree_']['findOnPath'](_0x4e2e39,(_0x3bd14d,_0x3fb860)=>{const _0x431366=F(_0x3bd14d,_0x4e2e39),_0x17093a=Ee(_0x3fb860,_0x431366);if(_0x17093a)return _0x17093a;});return Uo(_0x1852ba,_0x4e2e39,_0x352af9,_0x592586,!0x0);}function Yu(_0x478b50,_0x54be12){const _0x1832d7=_0x54be12['_path'];let _0x4e7202=null;_0x478b50['syncPointTree_']['foreachOnPath'](_0x1832d7,(_0x19a27d,_0xd67da5)=>{const _0x1287bd=F(_0x19a27d,_0x1832d7);_0x4e7202=_0x4e7202||Ee(_0xd67da5,_0x1287bd);});let _0x5217df=_0x478b50['syncPointTree_']['get'](_0x1832d7);_0x5217df?_0x4e7202=_0x4e7202||Ee(_0x5217df,w()):(_0x5217df=new Go(),_0x478b50['syncPointTree_']=_0x478b50['syncPointTree_']['set'](_0x1832d7,_0x5217df));const _0x3fa46b=_0x4e7202!=null,_0x138c9d=_0x3fa46b?new Ce(_0x4e7202,!0x0,!0x1):null,_0x1ed3ee=Mn(_0x478b50['pendingWriteTree_'],_0x54be12['_path']),_0x54df38=qo(_0x5217df,_0x54be12,_0x1ed3ee,_0x3fa46b?_0x138c9d['getNode']():g['EMPTY_NODE'],_0x3fa46b);return Ou(_0x54df38);}function ht(_0x1a8b50,_0x21aebb){return Qo(_0x21aebb,_0x1a8b50['syncPointTree_'],null,Mn(_0x1a8b50['pendingWriteTree_'],w()));}function Qo(_0x98eaf0,_0x32ebb5,_0x5eaa8a,_0x34cccd){if(v(_0x98eaf0['path']))return Jo(_0x98eaf0,_0x32ebb5,_0x5eaa8a,_0x34cccd);{const _0x2e1c2e=_0x32ebb5['get'](w());_0x5eaa8a==null&&_0x2e1c2e!=null&&(_0x5eaa8a=Ee(_0x2e1c2e,w()));let _0x2a4d89=[];const _0x25c617=y(_0x98eaf0['path']),_0x47664b=_0x98eaf0['operationForChild'](_0x25c617),_0x54992a=_0x32ebb5['children']['get'](_0x25c617);if(_0x54992a&&_0x47664b){const _0x1c37f6=_0x5eaa8a?_0x5eaa8a['getImmediateChild'](_0x25c617):null,_0x2bc6b6=Wo(_0x34cccd,_0x25c617);_0x2a4d89=_0x2a4d89['concat'](Qo(_0x47664b,_0x54992a,_0x1c37f6,_0x2bc6b6));}return _0x2e1c2e&&(_0x2a4d89=_0x2a4d89['concat'](is(_0x2e1c2e,_0x98eaf0,_0x34cccd,_0x5eaa8a))),_0x2a4d89;}}function Jo(_0x2e1781,_0x198b5f,_0x57c596,_0x17a7e2){const _0x101865=_0x198b5f['get'](w());_0x57c596==null&&_0x101865!=null&&(_0x57c596=Ee(_0x101865,w()));let _0x5632cf=[];return _0x198b5f['children']['inorderTraversal']((_0x4502c1,_0x48ee5a)=>{const _0x428517=_0x57c596?_0x57c596['getImmediateChild'](_0x4502c1):null,_0x45b459=Wo(_0x17a7e2,_0x4502c1),_0x1707a5=_0x2e1781['operationForChild'](_0x4502c1);_0x1707a5&&(_0x5632cf=_0x5632cf['concat'](Jo(_0x1707a5,_0x48ee5a,_0x428517,_0x45b459)));}),_0x101865&&(_0x5632cf=_0x5632cf['concat'](is(_0x101865,_0x2e1781,_0x17a7e2,_0x57c596))),_0x5632cf;}function Xo(_0x206e27,_0x11fc95){const _0x5877d9=_0x11fc95['query'],_0x21ff8b=Mt(_0x206e27,_0x5877d9);return{'hashFn':()=>(Pu(_0x11fc95)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x339637=>{if(_0x339637==='ok')return _0x21ff8b?ju(_0x206e27,_0x5877d9['_path'],_0x21ff8b):zu(_0x206e27,_0x5877d9['_path']);{const _0x5e145d=ql(_0x339637,_0x5877d9);return wn(_0x206e27,_0x5877d9,null,_0x5e145d);}}};}function Mt(_0x4c4fa9,_0x2762d2){const _0x599448=Fn(_0x2762d2);return _0x4c4fa9['queryToTagMap']['get'](_0x599448);}function Fn(_0x5142ae){return _0x5142ae['_path']['toString']()+'$'+_0x5142ae['_queryIdentifier'];}function rs(_0x20aba1,_0x2b200d){return _0x20aba1['tagToQueryMap']['get'](_0x2b200d);}function os(_0x32e912){const _0x3471ab=_0x32e912['indexOf']('$');return f(_0x3471ab!==-0x1&&_0x3471ab<_0x32e912['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x32e912['substr'](_0x3471ab+0x1),'path':new C(_0x32e912['substr'](0x0,_0x3471ab))};}function as(_0x53b697,_0x35cba6,_0x21b805){const _0x301e98=_0x53b697['syncPointTree_']['get'](_0x35cba6);f(_0x301e98,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1ffc4b=Mn(_0x53b697['pendingWriteTree_'],_0x35cba6);return is(_0x301e98,_0x21b805,_0x1ffc4b,null);}function Qu(_0x3a8dfd){return _0x3a8dfd['fold']((_0x2ac4ec,_0x1d571c,_0x3ce027)=>{if(_0x1d571c&&Te(_0x1d571c))return[Ln(_0x1d571c)];{let _0x411538=[];return _0x1d571c&&(_0x411538=zo(_0x1d571c)),x(_0x3ce027,(_0x1f61f2,_0x339828)=>{_0x411538=_0x411538['concat'](_0x339828);}),_0x411538;}});}function Tt(_0x1972f7){return _0x1972f7['_queryParams']['loadsAllData']()&&!_0x1972f7['_queryParams']['isDefault']()?new(Hu())(_0x1972f7['_repo'],_0x1972f7['_path']):_0x1972f7;}function Ju(_0x5873df,_0x12cb0a){for(let _0x17cf80=0x0;_0x17cf80<_0x12cb0a['length'];++_0x17cf80){const _0x3276d7=_0x12cb0a[_0x17cf80];if(!_0x3276d7['_queryParams']['loadsAllData']()){const _0x3f2394=Fn(_0x3276d7),_0x3342c0=_0x5873df['queryToTagMap']['get'](_0x3f2394);_0x5873df['queryToTagMap']['delete'](_0x3f2394),_0x5873df['tagToQueryMap']['delete'](_0x3342c0);}}}function Xu(){return $u++;}function Zu(_0x3f5da8,_0x41d1e2,_0x5c74af){const _0x2f6e91=_0x41d1e2['_path'],_0x5e64d4=Mt(_0x3f5da8,_0x41d1e2),_0x19666d=Xo(_0x3f5da8,_0x5c74af),_0x2a479a=_0x3f5da8['listenProvider_']['startListening'](Tt(_0x41d1e2),_0x5e64d4,_0x19666d['hashFn'],_0x19666d['onComplete']),_0x43e8b2=_0x3f5da8['syncPointTree_']['subtree'](_0x2f6e91);if(_0x5e64d4)f(!Te(_0x43e8b2['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5e6a8c=_0x43e8b2['fold']((_0x5c08d0,_0x138b82,_0x35871f)=>{if(!v(_0x5c08d0)&&_0x138b82&&Te(_0x138b82))return[Ln(_0x138b82)['query']];{let _0x20841c=[];return _0x138b82&&(_0x20841c=_0x20841c['concat'](zo(_0x138b82)['map'](_0x4cc214=>_0x4cc214['query']))),x(_0x35871f,(_0x11b8de,_0x1c5ef1)=>{_0x20841c=_0x20841c['concat'](_0x1c5ef1);}),_0x20841c;}});for(let _0x38533f=0x0;_0x38533f<_0x5e6a8c['length'];++_0x38533f){const _0x460012=_0x5e6a8c[_0x38533f];_0x3f5da8['listenProvider_']['stopListening'](Tt(_0x460012),Mt(_0x3f5da8,_0x460012));}}return _0x2a479a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x72e93f){this['node_']=_0x72e93f;}['getImmediateChild'](_0x7f6b8a){const _0x4f0942=this['node_']['getImmediateChild'](_0x7f6b8a);return new cs(_0x4f0942);}['node'](){return this['node_'];}}class ls{constructor(_0x7d405b,_0x4f0696){this['syncTree_']=_0x7d405b,this['path_']=_0x4f0696;}['getImmediateChild'](_0x56c860){const _0x56a3a4=A(this['path_'],_0x56c860);return new ls(this['syncTree_'],_0x56a3a4);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x87a559){return _0x87a559=_0x87a559||{},_0x87a559['timestamp']=_0x87a559['timestamp']||new Date()['getTime'](),_0x87a559;},fr=function(_0x3e274a,_0x16f540,_0x4ab3c1){if(!_0x3e274a||typeof _0x3e274a!='object')return _0x3e274a;if(f('.sv'in _0x3e274a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3e274a['.sv']=='string')return td(_0x3e274a['.sv'],_0x16f540,_0x4ab3c1);if(typeof _0x3e274a['.sv']=='object')return nd(_0x3e274a['.sv'],_0x16f540);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3e274a,null,0x2));},td=function(_0x337153,_0xa6395,_0x1a0d31){switch(_0x337153){case'timestamp':return _0x1a0d31['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x337153);}},nd=function(_0x4cf00e,_0x35afd7,_0x5e0d5d){_0x4cf00e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4cf00e,null,0x2));const _0x239943=_0x4cf00e['increment'];typeof _0x239943!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x239943);const _0x2d4140=_0x35afd7['node']();if(f(_0x2d4140!==null&&typeof _0x2d4140<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2d4140['isLeafNode']())return _0x239943;const _0x3f9048=_0x2d4140['getValue']();return typeof _0x3f9048!='number'?_0x239943:_0x3f9048+_0x239943;},Zo=function(_0x90a541,_0x2917c4,_0x25aeec,_0x4e1447){return us(_0x2917c4,new ls(_0x25aeec,_0x90a541),_0x4e1447);},hs=function(_0xa0da97,_0x246ba5,_0x50134c){return us(_0xa0da97,new cs(_0x246ba5),_0x50134c);};function us(_0x20adfe,_0x1e6383,_0x37f920){const _0x4eeb0e=_0x20adfe['getPriority']()['val'](),_0x55cf89=fr(_0x4eeb0e,_0x1e6383['getImmediateChild']('.priority'),_0x37f920);let _0x2476d0;if(_0x20adfe['isLeafNode']()){const _0x1c18b7=_0x20adfe,_0x36f123=fr(_0x1c18b7['getValue'](),_0x1e6383,_0x37f920);return _0x36f123!==_0x1c18b7['getValue']()||_0x55cf89!==_0x1c18b7['getPriority']()['val']()?new D(_0x36f123,N(_0x55cf89)):_0x20adfe;}else{const _0x41d9b6=_0x20adfe;return _0x2476d0=_0x41d9b6,_0x55cf89!==_0x41d9b6['getPriority']()['val']()&&(_0x2476d0=_0x2476d0['updatePriority'](new D(_0x55cf89))),_0x41d9b6['forEachChild'](R,(_0x47d3ea,_0x966593)=>{const _0x5124c7=us(_0x966593,_0x1e6383['getImmediateChild'](_0x47d3ea),_0x37f920);_0x5124c7!==_0x966593&&(_0x2476d0=_0x2476d0['updateImmediateChild'](_0x47d3ea,_0x5124c7));}),_0x2476d0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x1316d3='',_0x3436bc=null,_0x26912c={'children':{},'childCount':0x0}){this['name']=_0x1316d3,this['parent']=_0x3436bc,this['node']=_0x26912c;}}function Un(_0x4f9d1e,_0x42531f){let _0x3dda94=_0x42531f instanceof C?_0x42531f:new C(_0x42531f),_0x4b1711=_0x4f9d1e,_0x31959f=y(_0x3dda94);for(;_0x31959f!==null;){const _0x350ed0=Oe(_0x4b1711['node']['children'],_0x31959f)||{'children':{},'childCount':0x0};_0x4b1711=new ds(_0x31959f,_0x4b1711,_0x350ed0),_0x3dda94=b(_0x3dda94),_0x31959f=y(_0x3dda94);}return _0x4b1711;}function Ge(_0x7120d7){return _0x7120d7['node']['value'];}function fs(_0x14ee81,_0x4d70bd){_0x14ee81['node']['value']=_0x4d70bd,Ri(_0x14ee81);}function ea(_0x5dd1ff){return _0x5dd1ff['node']['childCount']>0x0;}function id(_0xd49ecc){return Ge(_0xd49ecc)===void 0x0&&!ea(_0xd49ecc);}function Wn(_0x1f5687,_0x2c324e){x(_0x1f5687['node']['children'],(_0x5db00c,_0x190183)=>{_0x2c324e(new ds(_0x5db00c,_0x1f5687,_0x190183));});}function ta(_0x492c22,_0x4e8db5,_0x5c49ba,_0x4a3e3a){_0x5c49ba&&_0x4e8db5(_0x492c22),Wn(_0x492c22,_0x14b374=>{ta(_0x14b374,_0x4e8db5,!0x0);});}function sd(_0x4b97e8,_0x5c425b,_0x60000b){let _0x163417=_0x4b97e8['parent'];for(;_0x163417!==null;){if(_0x5c425b(_0x163417))return!0x0;_0x163417=_0x163417['parent'];}return!0x1;}function Gt(_0x362136){return new C(_0x362136['parent']===null?_0x362136['name']:Gt(_0x362136['parent'])+'/'+_0x362136['name']);}function Ri(_0x44d710){_0x44d710['parent']!==null&&rd(_0x44d710['parent'],_0x44d710['name'],_0x44d710);}function rd(_0x28655b,_0x55ba20,_0x1da90a){const _0x466206=id(_0x1da90a),_0x1d1232=Y(_0x28655b['node']['children'],_0x55ba20);_0x466206&&_0x1d1232?(delete _0x28655b['node']['children'][_0x55ba20],_0x28655b['node']['childCount']--,Ri(_0x28655b)):!_0x466206&&!_0x1d1232&&(_0x28655b['node']['children'][_0x55ba20]=_0x1da90a['node'],_0x28655b['node']['childCount']++,Ri(_0x28655b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x32da9f){return typeof _0x32da9f=='string'&&_0x32da9f['length']!==0x0&&!od['test'](_0x32da9f);},na=function(_0x1e85aa){return typeof _0x1e85aa=='string'&&_0x1e85aa['length']!==0x0&&!ad['test'](_0x1e85aa);},cd=function(_0x39d498){return _0x39d498&&(_0x39d498=_0x39d498['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x39d498);},Cn=function(_0x4b2022){return _0x4b2022===null||typeof _0x4b2022=='string'||typeof _0x4b2022=='number'&&!Wi(_0x4b2022)||_0x4b2022&&typeof _0x4b2022=='object'&&Y(_0x4b2022,'.sv');},qt=function(_0x209e50,_0x5e9938,_0x3cb088,_0x2fdca3){_0x2fdca3&&_0x5e9938===void 0x0||zt(Nn(_0x209e50,'value'),_0x5e9938,_0x3cb088);},zt=function(_0xe088ed,_0x1e26d0,_0x5884c1){const _0x53a058=_0x5884c1 instanceof C?new Sh(_0x5884c1,_0xe088ed):_0x5884c1;if(_0x1e26d0===void 0x0)throw new Error(_0xe088ed+'contains\x20undefined\x20'+Ne(_0x53a058));if(typeof _0x1e26d0=='function')throw new Error(_0xe088ed+'contains\x20a\x20function\x20'+Ne(_0x53a058)+'\x20with\x20contents\x20=\x20'+_0x1e26d0['toString']());if(Wi(_0x1e26d0))throw new Error(_0xe088ed+'contains\x20'+_0x1e26d0['toString']()+'\x20'+Ne(_0x53a058));if(typeof _0x1e26d0=='string'&&_0x1e26d0['length']>oi/0x3&&Pn(_0x1e26d0)>oi)throw new Error(_0xe088ed+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x53a058)+'\x20(\x27'+_0x1e26d0['substring'](0x0,0x32)+'...\x27)');if(_0x1e26d0&&typeof _0x1e26d0=='object'){let _0x5a1126=!0x1,_0x6d0a12=!0x1;if(x(_0x1e26d0,(_0x457e74,_0x46cf17)=>{if(_0x457e74==='.value')_0x5a1126=!0x0;else{if(_0x457e74!=='.priority'&&_0x457e74!=='.sv'&&(_0x6d0a12=!0x0,!ps(_0x457e74)))throw new Error(_0xe088ed+'\x20contains\x20an\x20invalid\x20key\x20('+_0x457e74+')\x20'+Ne(_0x53a058)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x53a058,_0x457e74),zt(_0xe088ed,_0x46cf17,_0x53a058),Rh(_0x53a058);}),_0x5a1126&&_0x6d0a12)throw new Error(_0xe088ed+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x53a058)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x3234fd,_0x16dc52){let _0xf69831,_0x2505fa;for(_0xf69831=0x0;_0xf69831<_0x16dc52['length'];_0xf69831++){_0x2505fa=_0x16dc52[_0xf69831];const _0x53d306=kt(_0x2505fa);for(let _0x1cd737=0x0;_0x1cd737<_0x53d306['length'];_0x1cd737++)if(!(_0x53d306[_0x1cd737]==='.priority'&&_0x1cd737===_0x53d306['length']-0x1)){if(!ps(_0x53d306[_0x1cd737]))throw new Error(_0x3234fd+'contains\x20an\x20invalid\x20key\x20('+_0x53d306[_0x1cd737]+')\x20in\x20path\x20'+_0x2505fa['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x16dc52['sort'](Th);let _0x4544bd=null;for(_0xf69831=0x0;_0xf69831<_0x16dc52['length'];_0xf69831++){if(_0x2505fa=_0x16dc52[_0xf69831],_0x4544bd!==null&&$(_0x4544bd,_0x2505fa))throw new Error(_0x3234fd+'contains\x20a\x20path\x20'+_0x4544bd['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2505fa['toString']());_0x4544bd=_0x2505fa;}},hd=function(_0x63c2a9,_0x2e3df9,_0x366a96,_0x2bcc5a){const _0x3774be=Nn(_0x63c2a9,'values');if(!(_0x2e3df9&&typeof _0x2e3df9=='object')||Array['isArray'](_0x2e3df9))throw new Error(_0x3774be+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1e10ee=[];x(_0x2e3df9,(_0x1f9514,_0x463ea1)=>{const _0xb53b4b=new C(_0x1f9514);if(zt(_0x3774be,_0x463ea1,A(_0x366a96,_0xb53b4b)),Gi(_0xb53b4b)==='.priority'&&!Cn(_0x463ea1))throw new Error(_0x3774be+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xb53b4b['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1e10ee['push'](_0xb53b4b);}),ld(_0x3774be,_0x1e10ee);},_s=function(_0x4ea76e,_0x378cd9,_0x31b98d,_0x130789){if(!na(_0x31b98d))throw new Error(Nn(_0x4ea76e,_0x378cd9)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x31b98d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x204660,_0x187e94,_0x1ae5ef,_0x50aa50){_0x1ae5ef&&(_0x1ae5ef=_0x1ae5ef['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x204660,_0x187e94,_0x1ae5ef);},gs=function(_0x47403b,_0x163be7){if(y(_0x163be7)==='.info')throw new Error(_0x47403b+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x357d25,_0x3a50e0){const _0x1c54ec=_0x3a50e0['path']['toString']();if(typeof _0x3a50e0['repoInfo']['host']!='string'||_0x3a50e0['repoInfo']['host']['length']===0x0||!ps(_0x3a50e0['repoInfo']['namespace'])&&_0x3a50e0['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1c54ec['length']!==0x0&&!cd(_0x1c54ec))throw new Error(Nn(_0x357d25,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x2acc60,_0x5dcf7d){let _0x3b0cf8=null;for(let _0x31ec67=0x0;_0x31ec67<_0x5dcf7d['length'];_0x31ec67++){const _0x101277=_0x5dcf7d[_0x31ec67],_0x4e778f=_0x101277['getPath']();_0x3b0cf8!==null&&!qi(_0x4e778f,_0x3b0cf8['path'])&&(_0x2acc60['eventLists_']['push'](_0x3b0cf8),_0x3b0cf8=null),_0x3b0cf8===null&&(_0x3b0cf8={'events':[],'path':_0x4e778f}),_0x3b0cf8['events']['push'](_0x101277);}_0x3b0cf8&&_0x2acc60['eventLists_']['push'](_0x3b0cf8);}function ia(_0xf602aa,_0x5b69e3,_0xc3b642){Bn(_0xf602aa,_0xc3b642),sa(_0xf602aa,_0x26ba13=>qi(_0x26ba13,_0x5b69e3));}function V(_0x9fab07,_0x19386c,_0x4f73b6){Bn(_0x9fab07,_0x4f73b6),sa(_0x9fab07,_0x319265=>$(_0x319265,_0x19386c)||$(_0x19386c,_0x319265));}function sa(_0xdbfc3a,_0x1e1907){_0xdbfc3a['recursionDepth_']++;let _0x31d3a6=!0x0;for(let _0x2b3048=0x0;_0x2b3048<_0xdbfc3a['eventLists_']['length'];_0x2b3048++){const _0x50aee5=_0xdbfc3a['eventLists_'][_0x2b3048];if(_0x50aee5){const _0x5c1974=_0x50aee5['path'];_0x1e1907(_0x5c1974)?(pd(_0xdbfc3a['eventLists_'][_0x2b3048]),_0xdbfc3a['eventLists_'][_0x2b3048]=null):_0x31d3a6=!0x1;}}_0x31d3a6&&(_0xdbfc3a['eventLists_']=[]),_0xdbfc3a['recursionDepth_']--;}function pd(_0xf9291b){for(let _0x3c364a=0x0;_0x3c364a<_0xf9291b['events']['length'];_0x3c364a++){const _0x2b8264=_0xf9291b['events'][_0x3c364a];if(_0x2b8264!==null){_0xf9291b['events'][_0x3c364a]=null;const _0x5633be=_0x2b8264['getEventRunner']();Et&&L('event:\x20'+_0x2b8264['toString']()),lt(_0x5633be);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x36106f,_0x422c80,_0x805767,_0xf0467b){this['repoInfo_']=_0x36106f,this['forceRestClient_']=_0x422c80,this['authTokenProvider_']=_0x805767,this['appCheckProvider_']=_0xf0467b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x42af35,_0x33d2b1,_0x566a5d){if(_0x42af35['stats_']=Hi(_0x42af35['repoInfo_']),_0x42af35['forceRestClient_']||Yl())_0x42af35['server_']=new fn(_0x42af35['repoInfo_'],(_0x496b19,_0xa8e058,_0x558a4e,_0x499391)=>{pr(_0x42af35,_0x496b19,_0xa8e058,_0x558a4e,_0x499391);},_0x42af35['authTokenProvider_'],_0x42af35['appCheckProvider_']),setTimeout(()=>_r(_0x42af35,!0x0),0x0);else{if(typeof _0x566a5d<'u'&&_0x566a5d!==null){if(typeof _0x566a5d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x566a5d);}catch(_0x259ee2){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x259ee2);}}_0x42af35['persistentConnection_']=new ie(_0x42af35['repoInfo_'],_0x33d2b1,(_0x132a56,_0xeb1a28,_0x299fa2,_0x5ecd7e)=>{pr(_0x42af35,_0x132a56,_0xeb1a28,_0x299fa2,_0x5ecd7e);},_0x26764a=>{_r(_0x42af35,_0x26764a);},_0x54e654=>{yd(_0x42af35,_0x54e654);},_0x42af35['authTokenProvider_'],_0x42af35['appCheckProvider_'],_0x566a5d),_0x42af35['server_']=_0x42af35['persistentConnection_'];}_0x42af35['authTokenProvider_']['addTokenChangeListener'](_0xd8abbb=>{_0x42af35['server_']['refreshAuthToken'](_0xd8abbb);}),_0x42af35['appCheckProvider_']['addTokenChangeListener'](_0x18ef42=>{_0x42af35['server_']['refreshAppCheckToken'](_0x18ef42['token']);}),_0x42af35['statsReporter_']=eh(_0x42af35['repoInfo_'],()=>new eu(_0x42af35['stats_'],_0x42af35['server_'])),_0x42af35['infoData_']=new Yh(),_0x42af35['infoSyncTree_']=new dr({'startListening':(_0x2286c8,_0x5c2b8d,_0xa422df,_0x3ea9ea)=>{let _0x487b9f=[];const _0x53ebcf=_0x42af35['infoData_']['getNode'](_0x2286c8['_path']);return _0x53ebcf['isEmpty']()||(_0x487b9f=$t(_0x42af35['infoSyncTree_'],_0x2286c8['_path'],_0x53ebcf),setTimeout(()=>{_0x3ea9ea('ok');},0x0)),_0x487b9f;},'stopListening':()=>{}}),ms(_0x42af35,'connected',!0x1),_0x42af35['serverSyncTree_']=new dr({'startListening':(_0x52a71b,_0x3ce2b3,_0x20d118,_0x1a9abf)=>(_0x42af35['server_']['listen'](_0x52a71b,_0x20d118,_0x3ce2b3,(_0x196018,_0x11693f)=>{const _0x5bd44b=_0x1a9abf(_0x196018,_0x11693f);V(_0x42af35['eventQueue_'],_0x52a71b['_path'],_0x5bd44b);}),[]),'stopListening':(_0x4de027,_0x3618f3)=>{_0x42af35['server_']['unlisten'](_0x4de027,_0x3618f3);}});}function oa(_0x1c89e1){const _0x36aaa4=_0x1c89e1['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x36aaa4;}function jt(_0x3a541d){return ed({'timestamp':oa(_0x3a541d)});}function pr(_0x15389f,_0x4f5e2b,_0x1d3cb4,_0x3fea68,_0x474288){_0x15389f['dataUpdateCount']++;const _0x4cc29e=new C(_0x4f5e2b);_0x1d3cb4=_0x15389f['interceptServerDataCallback_']?_0x15389f['interceptServerDataCallback_'](_0x4f5e2b,_0x1d3cb4):_0x1d3cb4;let _0x150f8f=[];if(_0x474288){if(_0x3fea68){const _0x27fa18=ln(_0x1d3cb4,_0x4529da=>N(_0x4529da));_0x150f8f=Ku(_0x15389f['serverSyncTree_'],_0x4cc29e,_0x27fa18,_0x474288);}else{const _0x5b4c3e=N(_0x1d3cb4);_0x150f8f=Yo(_0x15389f['serverSyncTree_'],_0x4cc29e,_0x5b4c3e,_0x474288);}}else{if(_0x3fea68){const _0x387e82=ln(_0x1d3cb4,_0x8545fa=>N(_0x8545fa));_0x150f8f=qu(_0x15389f['serverSyncTree_'],_0x4cc29e,_0x387e82);}else{const _0x25f2e7=N(_0x1d3cb4);_0x150f8f=$t(_0x15389f['serverSyncTree_'],_0x4cc29e,_0x25f2e7);}}let _0x197440=_0x4cc29e;_0x150f8f['length']>0x0&&(_0x197440=st(_0x15389f,_0x4cc29e)),V(_0x15389f['eventQueue_'],_0x197440,_0x150f8f);}function _r(_0x519995,_0x1791ea){ms(_0x519995,'connected',_0x1791ea),_0x1791ea===!0x1&&wd(_0x519995);}function yd(_0x5f3ed8,_0x22c7d5){x(_0x22c7d5,(_0x2e11cc,_0x383414)=>{ms(_0x5f3ed8,_0x2e11cc,_0x383414);});}function ms(_0x300f23,_0x3a847e,_0x44e36d){const _0x16c24b=new C('/.info/'+_0x3a847e),_0x163fc3=N(_0x44e36d);_0x300f23['infoData_']['updateSnapshot'](_0x16c24b,_0x163fc3);const _0x388f0c=$t(_0x300f23['infoSyncTree_'],_0x16c24b,_0x163fc3);V(_0x300f23['eventQueue_'],_0x16c24b,_0x388f0c);}function Vn(_0x2ce216){return _0x2ce216['nextWriteId_']++;}function vd(_0x31b237,_0x505d8e,_0x4c29d4){const _0x14edb4=Yu(_0x31b237['serverSyncTree_'],_0x505d8e);return _0x14edb4!=null?Promise['resolve'](_0x14edb4):_0x31b237['server_']['get'](_0x505d8e)['then'](_0x4a7912=>{const _0x4e4210=N(_0x4a7912)['withIndex'](_0x505d8e['_queryParams']['getIndex']());bi(_0x31b237['serverSyncTree_'],_0x505d8e,_0x4c29d4,!0x0);let _0x4a11e5;if(_0x505d8e['_queryParams']['loadsAllData']())_0x4a11e5=$t(_0x31b237['serverSyncTree_'],_0x505d8e['_path'],_0x4e4210);else{const _0x4a057e=Mt(_0x31b237['serverSyncTree_'],_0x505d8e);_0x4a11e5=Yo(_0x31b237['serverSyncTree_'],_0x505d8e['_path'],_0x4e4210,_0x4a057e);}return V(_0x31b237['eventQueue_'],_0x505d8e['_path'],_0x4a11e5),wn(_0x31b237['serverSyncTree_'],_0x505d8e,_0x4c29d4,null,!0x0),_0x4e4210;},_0x45e210=>(ut(_0x31b237,'get\x20for\x20query\x20'+O(_0x505d8e)+'\x20failed:\x20'+_0x45e210),Promise['reject'](new Error(_0x45e210))));}function Ed(_0xe5681a,_0xa831d4,_0x4440f3,_0x3c92a5,_0x5f44ac){ut(_0xe5681a,'set',{'path':_0xa831d4['toString'](),'value':_0x4440f3,'priority':_0x3c92a5});const _0x2cab2f=jt(_0xe5681a),_0x3d3655=N(_0x4440f3,_0x3c92a5),_0x5442f8=xn(_0xe5681a['serverSyncTree_'],_0xa831d4),_0x56a0ff=hs(_0x3d3655,_0x5442f8,_0x2cab2f),_0x189b10=Vn(_0xe5681a),_0x68099d=ss(_0xe5681a['serverSyncTree_'],_0xa831d4,_0x56a0ff,_0x189b10,!0x0);Bn(_0xe5681a['eventQueue_'],_0x68099d),_0xe5681a['server_']['put'](_0xa831d4['toString'](),_0x3d3655['val'](!0x0),(_0x741563,_0x322faa)=>{const _0x5a2360=_0x741563==='ok';_0x5a2360||U('set\x20at\x20'+_0xa831d4+'\x20failed:\x20'+_0x741563);const _0x57e0fc=pe(_0xe5681a['serverSyncTree_'],_0x189b10,!_0x5a2360);V(_0xe5681a['eventQueue_'],_0xa831d4,_0x57e0fc),Ai(_0xe5681a,_0x5f44ac,_0x741563,_0x322faa);});const _0x1129b2=vs(_0xe5681a,_0xa831d4);st(_0xe5681a,_0x1129b2),V(_0xe5681a['eventQueue_'],_0x1129b2,[]);}function Id(_0x2a99b9,_0x1e0caf,_0xb5cab3,_0x514577){ut(_0x2a99b9,'update',{'path':_0x1e0caf['toString'](),'value':_0xb5cab3});let _0x3b4a00=!0x0;const _0x503ecd=jt(_0x2a99b9),_0x2a259d={};if(x(_0xb5cab3,(_0x84beae,_0x4168b0)=>{_0x3b4a00=!0x1,_0x2a259d[_0x84beae]=Zo(A(_0x1e0caf,_0x84beae),N(_0x4168b0),_0x2a99b9['serverSyncTree_'],_0x503ecd);}),_0x3b4a00)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x2a99b9,_0x514577,'ok',void 0x0);else{const _0x12347f=Vn(_0x2a99b9),_0x30071b=Gu(_0x2a99b9['serverSyncTree_'],_0x1e0caf,_0x2a259d,_0x12347f);Bn(_0x2a99b9['eventQueue_'],_0x30071b),_0x2a99b9['server_']['merge'](_0x1e0caf['toString'](),_0xb5cab3,(_0x491605,_0x377ba9)=>{const _0x47cb40=_0x491605==='ok';_0x47cb40||U('update\x20at\x20'+_0x1e0caf+'\x20failed:\x20'+_0x491605);const _0x23f2dd=pe(_0x2a99b9['serverSyncTree_'],_0x12347f,!_0x47cb40),_0x14c50c=_0x23f2dd['length']>0x0?st(_0x2a99b9,_0x1e0caf):_0x1e0caf;V(_0x2a99b9['eventQueue_'],_0x14c50c,_0x23f2dd),Ai(_0x2a99b9,_0x514577,_0x491605,_0x377ba9);}),x(_0xb5cab3,_0x4a46a6=>{const _0x3465d1=vs(_0x2a99b9,A(_0x1e0caf,_0x4a46a6));st(_0x2a99b9,_0x3465d1);}),V(_0x2a99b9['eventQueue_'],_0x1e0caf,[]);}}function wd(_0x131321){ut(_0x131321,'onDisconnectEvents');const _0x2be42a=jt(_0x131321),_0x373f3d=pn();Ei(_0x131321['onDisconnect_'],w(),(_0x1dd5c4,_0x1a09e4)=>{const _0xd28f84=Zo(_0x1dd5c4,_0x1a09e4,_0x131321['serverSyncTree_'],_0x2be42a);Mo(_0x373f3d,_0x1dd5c4,_0xd28f84);});let _0x34b703=[];Ei(_0x373f3d,w(),(_0x2760c5,_0x4d3ecf)=>{_0x34b703=_0x34b703['concat']($t(_0x131321['serverSyncTree_'],_0x2760c5,_0x4d3ecf));const _0x2d5e57=vs(_0x131321,_0x2760c5);st(_0x131321,_0x2d5e57);}),_0x131321['onDisconnect_']=pn(),V(_0x131321['eventQueue_'],w(),_0x34b703);}function Cd(_0x295886,_0x670aa0,_0x1e35df){let _0x329895;y(_0x670aa0['_path'])==='.info'?_0x329895=bi(_0x295886['infoSyncTree_'],_0x670aa0,_0x1e35df):_0x329895=bi(_0x295886['serverSyncTree_'],_0x670aa0,_0x1e35df),ia(_0x295886['eventQueue_'],_0x670aa0['_path'],_0x329895);}function Td(_0x1a86b1,_0x4b0941,_0x106244){let _0x297994;y(_0x4b0941['_path'])==='.info'?_0x297994=wn(_0x1a86b1['infoSyncTree_'],_0x4b0941,_0x106244):_0x297994=wn(_0x1a86b1['serverSyncTree_'],_0x4b0941,_0x106244),ia(_0x1a86b1['eventQueue_'],_0x4b0941['_path'],_0x297994);}function aa(_0x2daf04){_0x2daf04['persistentConnection_']&&_0x2daf04['persistentConnection_']['interrupt'](ra);}function Sd(_0x3e68d3){_0x3e68d3['persistentConnection_']&&_0x3e68d3['persistentConnection_']['resume'](ra);}function ut(_0x171f4c,..._0x5c1cd9){let _0x222256='';_0x171f4c['persistentConnection_']&&(_0x222256=_0x171f4c['persistentConnection_']['id']+':'),L(_0x222256,..._0x5c1cd9);}function Ai(_0x382de7,_0x51371e,_0x59c73e,_0x17f622){_0x51371e&&lt(()=>{if(_0x59c73e==='ok')_0x51371e(null);else{const _0x3bc196=(_0x59c73e||'error')['toUpperCase']();let _0x47c8a7=_0x3bc196;_0x17f622&&(_0x47c8a7+=':\x20'+_0x17f622);const _0x3d4f71=new Error(_0x47c8a7);_0x3d4f71['code']=_0x3bc196,_0x51371e(_0x3d4f71);}});}function bd(_0x1d8851,_0x425622,_0x8f9588,_0x40bfea,_0x246f04,_0x510f34){ut(_0x1d8851,'transaction\x20on\x20'+_0x425622);const _0x32f1a3={'path':_0x425622,'update':_0x8f9588,'onComplete':_0x40bfea,'status':null,'order':to(),'applyLocally':_0x510f34,'retryCount':0x0,'unwatcher':_0x246f04,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1789f0=ys(_0x1d8851,_0x425622,void 0x0);_0x32f1a3['currentInputSnapshot']=_0x1789f0;const _0x53718c=_0x32f1a3['update'](_0x1789f0['val']());if(_0x53718c===void 0x0)_0x32f1a3['unwatcher'](),_0x32f1a3['currentOutputSnapshotRaw']=null,_0x32f1a3['currentOutputSnapshotResolved']=null,_0x32f1a3['onComplete']&&_0x32f1a3['onComplete'](null,!0x1,_0x32f1a3['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x53718c,_0x32f1a3['path']),_0x32f1a3['status']=0x0;const _0x5c970e=Un(_0x1d8851['transactionQueueTree_'],_0x425622),_0x1f1372=Ge(_0x5c970e)||[];_0x1f1372['push'](_0x32f1a3),fs(_0x5c970e,_0x1f1372);let _0x51610b;typeof _0x53718c=='object'&&_0x53718c!==null&&Y(_0x53718c,'.priority')?(_0x51610b=Oe(_0x53718c,'.priority'),f(Cn(_0x51610b),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x51610b=(xn(_0x1d8851['serverSyncTree_'],_0x425622)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x41e943=jt(_0x1d8851),_0x4d222e=N(_0x53718c,_0x51610b),_0x79bb68=hs(_0x4d222e,_0x1789f0,_0x41e943);_0x32f1a3['currentOutputSnapshotRaw']=_0x4d222e,_0x32f1a3['currentOutputSnapshotResolved']=_0x79bb68,_0x32f1a3['currentWriteId']=Vn(_0x1d8851);const _0x277c19=ss(_0x1d8851['serverSyncTree_'],_0x425622,_0x79bb68,_0x32f1a3['currentWriteId'],_0x32f1a3['applyLocally']);V(_0x1d8851['eventQueue_'],_0x425622,_0x277c19),Hn(_0x1d8851,_0x1d8851['transactionQueueTree_']);}}function ys(_0x4759a3,_0x14794a,_0x2c7abb){return xn(_0x4759a3['serverSyncTree_'],_0x14794a,_0x2c7abb)||g['EMPTY_NODE'];}function Hn(_0x544e98,_0x4c02d3=_0x544e98['transactionQueueTree_']){if(_0x4c02d3||$n(_0x544e98,_0x4c02d3),Ge(_0x4c02d3)){const _0x12f203=la(_0x544e98,_0x4c02d3);f(_0x12f203['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x12f203['every'](_0xb06f9f=>_0xb06f9f['status']===0x0)&&Rd(_0x544e98,Gt(_0x4c02d3),_0x12f203);}else ea(_0x4c02d3)&&Wn(_0x4c02d3,_0x5c2ce7=>{Hn(_0x544e98,_0x5c2ce7);});}function Rd(_0xacac0b,_0x49b7a2,_0x2e5598){const _0x1cc8b1=_0x2e5598['map'](_0xd01358=>_0xd01358['currentWriteId']),_0x1a810f=ys(_0xacac0b,_0x49b7a2,_0x1cc8b1);let _0x23a078=_0x1a810f;const _0x3e1d7a=_0x1a810f['hash']();for(let _0x119c44=0x0;_0x119c44<_0x2e5598['length'];_0x119c44++){const _0x7ef74d=_0x2e5598[_0x119c44];f(_0x7ef74d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x7ef74d['status']=0x1,_0x7ef74d['retryCount']++;const _0x5b779d=F(_0x49b7a2,_0x7ef74d['path']);_0x23a078=_0x23a078['updateChild'](_0x5b779d,_0x7ef74d['currentOutputSnapshotRaw']);}const _0x5d0e53=_0x23a078['val'](!0x0),_0x345120=_0x49b7a2;_0xacac0b['server_']['put'](_0x345120['toString'](),_0x5d0e53,_0x41b13b=>{ut(_0xacac0b,'transaction\x20put\x20response',{'path':_0x345120['toString'](),'status':_0x41b13b});let _0x1f3e0f=[];if(_0x41b13b==='ok'){const _0x1d8468=[];for(let _0x2a7367=0x0;_0x2a7367<_0x2e5598['length'];_0x2a7367++)_0x2e5598[_0x2a7367]['status']=0x2,_0x1f3e0f=_0x1f3e0f['concat'](pe(_0xacac0b['serverSyncTree_'],_0x2e5598[_0x2a7367]['currentWriteId'])),_0x2e5598[_0x2a7367]['onComplete']&&_0x1d8468['push'](()=>_0x2e5598[_0x2a7367]['onComplete'](null,!0x0,_0x2e5598[_0x2a7367]['currentOutputSnapshotResolved'])),_0x2e5598[_0x2a7367]['unwatcher']();$n(_0xacac0b,Un(_0xacac0b['transactionQueueTree_'],_0x49b7a2)),Hn(_0xacac0b,_0xacac0b['transactionQueueTree_']),V(_0xacac0b['eventQueue_'],_0x49b7a2,_0x1f3e0f);for(let _0xf36b05=0x0;_0xf36b05<_0x1d8468['length'];_0xf36b05++)lt(_0x1d8468[_0xf36b05]);}else{if(_0x41b13b==='datastale'){for(let _0x2d9351=0x0;_0x2d9351<_0x2e5598['length'];_0x2d9351++)_0x2e5598[_0x2d9351]['status']===0x3?_0x2e5598[_0x2d9351]['status']=0x4:_0x2e5598[_0x2d9351]['status']=0x0;}else{U('transaction\x20at\x20'+_0x345120['toString']()+'\x20failed:\x20'+_0x41b13b);for(let _0x2d2ff3=0x0;_0x2d2ff3<_0x2e5598['length'];_0x2d2ff3++)_0x2e5598[_0x2d2ff3]['status']=0x4,_0x2e5598[_0x2d2ff3]['abortReason']=_0x41b13b;}st(_0xacac0b,_0x49b7a2);}},_0x3e1d7a);}function st(_0x197459,_0x5666f2){const _0x18c633=ca(_0x197459,_0x5666f2),_0x1500bc=Gt(_0x18c633),_0x2ad80f=la(_0x197459,_0x18c633);return Ad(_0x197459,_0x2ad80f,_0x1500bc),_0x1500bc;}function Ad(_0x423c0c,_0x27db3f,_0x4624ce){if(_0x27db3f['length']===0x0)return;const _0x5c468f=[];let _0x32b432=[];const _0x44374d=_0x27db3f['filter'](_0x121840=>_0x121840['status']===0x0)['map'](_0x2c239b=>_0x2c239b['currentWriteId']);for(let _0x4fee7e=0x0;_0x4fee7e<_0x27db3f['length'];_0x4fee7e++){const _0x19033a=_0x27db3f[_0x4fee7e],_0x2af877=F(_0x4624ce,_0x19033a['path']);let _0x5e6971=!0x1,_0x3c8c90;if(f(_0x2af877!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x19033a['status']===0x4)_0x5e6971=!0x0,_0x3c8c90=_0x19033a['abortReason'],_0x32b432=_0x32b432['concat'](pe(_0x423c0c['serverSyncTree_'],_0x19033a['currentWriteId'],!0x0));else{if(_0x19033a['status']===0x0){if(_0x19033a['retryCount']>=_d)_0x5e6971=!0x0,_0x3c8c90='maxretry',_0x32b432=_0x32b432['concat'](pe(_0x423c0c['serverSyncTree_'],_0x19033a['currentWriteId'],!0x0));else{const _0x35fc50=ys(_0x423c0c,_0x19033a['path'],_0x44374d);_0x19033a['currentInputSnapshot']=_0x35fc50;const _0x40dd3f=_0x27db3f[_0x4fee7e]['update'](_0x35fc50['val']());if(_0x40dd3f!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x40dd3f,_0x19033a['path']);let _0xca3b6d=N(_0x40dd3f);typeof _0x40dd3f=='object'&&_0x40dd3f!=null&&Y(_0x40dd3f,'.priority')||(_0xca3b6d=_0xca3b6d['updatePriority'](_0x35fc50['getPriority']()));const _0x169a16=_0x19033a['currentWriteId'],_0x1022ac=jt(_0x423c0c),_0x95f378=hs(_0xca3b6d,_0x35fc50,_0x1022ac);_0x19033a['currentOutputSnapshotRaw']=_0xca3b6d,_0x19033a['currentOutputSnapshotResolved']=_0x95f378,_0x19033a['currentWriteId']=Vn(_0x423c0c),_0x44374d['splice'](_0x44374d['indexOf'](_0x169a16),0x1),_0x32b432=_0x32b432['concat'](ss(_0x423c0c['serverSyncTree_'],_0x19033a['path'],_0x95f378,_0x19033a['currentWriteId'],_0x19033a['applyLocally'])),_0x32b432=_0x32b432['concat'](pe(_0x423c0c['serverSyncTree_'],_0x169a16,!0x0));}else _0x5e6971=!0x0,_0x3c8c90='nodata',_0x32b432=_0x32b432['concat'](pe(_0x423c0c['serverSyncTree_'],_0x19033a['currentWriteId'],!0x0));}}}V(_0x423c0c['eventQueue_'],_0x4624ce,_0x32b432),_0x32b432=[],_0x5e6971&&(_0x27db3f[_0x4fee7e]['status']=0x2,function(_0x589ffa){setTimeout(_0x589ffa,Math['floor'](0x0));}(_0x27db3f[_0x4fee7e]['unwatcher']),_0x27db3f[_0x4fee7e]['onComplete']&&(_0x3c8c90==='nodata'?_0x5c468f['push'](()=>_0x27db3f[_0x4fee7e]['onComplete'](null,!0x1,_0x27db3f[_0x4fee7e]['currentInputSnapshot'])):_0x5c468f['push'](()=>_0x27db3f[_0x4fee7e]['onComplete'](new Error(_0x3c8c90),!0x1,null))));}$n(_0x423c0c,_0x423c0c['transactionQueueTree_']);for(let _0x3301bb=0x0;_0x3301bb<_0x5c468f['length'];_0x3301bb++)lt(_0x5c468f[_0x3301bb]);Hn(_0x423c0c,_0x423c0c['transactionQueueTree_']);}function ca(_0xb252a1,_0x187758){let _0x183436,_0x44a7b2=_0xb252a1['transactionQueueTree_'];for(_0x183436=y(_0x187758);_0x183436!==null&&Ge(_0x44a7b2)===void 0x0;)_0x44a7b2=Un(_0x44a7b2,_0x183436),_0x187758=b(_0x187758),_0x183436=y(_0x187758);return _0x44a7b2;}function la(_0x19d338,_0xe0c2c6){const _0x2f8b9f=[];return ha(_0x19d338,_0xe0c2c6,_0x2f8b9f),_0x2f8b9f['sort']((_0x1d54d7,_0x12b80f)=>_0x1d54d7['order']-_0x12b80f['order']),_0x2f8b9f;}function ha(_0x13f3c2,_0x5b2153,_0x549e91){const _0x5af52f=Ge(_0x5b2153);if(_0x5af52f){for(let _0x1a89fb=0x0;_0x1a89fb<_0x5af52f['length'];_0x1a89fb++)_0x549e91['push'](_0x5af52f[_0x1a89fb]);}Wn(_0x5b2153,_0x27124c=>{ha(_0x13f3c2,_0x27124c,_0x549e91);});}function $n(_0x2d56c5,_0x3799b6){const _0xf5d9a5=Ge(_0x3799b6);if(_0xf5d9a5){let _0x47d9b4=0x0;for(let _0x4e2d64=0x0;_0x4e2d64<_0xf5d9a5['length'];_0x4e2d64++)_0xf5d9a5[_0x4e2d64]['status']!==0x2&&(_0xf5d9a5[_0x47d9b4]=_0xf5d9a5[_0x4e2d64],_0x47d9b4++);_0xf5d9a5['length']=_0x47d9b4,fs(_0x3799b6,_0xf5d9a5['length']>0x0?_0xf5d9a5:void 0x0);}Wn(_0x3799b6,_0x3c3082=>{$n(_0x2d56c5,_0x3c3082);});}function vs(_0x242f13,_0x21a0a3){const _0x2bd80e=Gt(ca(_0x242f13,_0x21a0a3)),_0x5a02eb=Un(_0x242f13['transactionQueueTree_'],_0x21a0a3);return sd(_0x5a02eb,_0x196d9f=>{ai(_0x242f13,_0x196d9f);}),ai(_0x242f13,_0x5a02eb),ta(_0x5a02eb,_0x387e97=>{ai(_0x242f13,_0x387e97);}),_0x2bd80e;}function ai(_0xd14c37,_0x3e9692){const _0x311d9b=Ge(_0x3e9692);if(_0x311d9b){const _0x589c0a=[];let _0xd7854e=[],_0x4efaf8=-0x1;for(let _0x2d685d=0x0;_0x2d685d<_0x311d9b['length'];_0x2d685d++)_0x311d9b[_0x2d685d]['status']===0x3||(_0x311d9b[_0x2d685d]['status']===0x1?(f(_0x4efaf8===_0x2d685d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4efaf8=_0x2d685d,_0x311d9b[_0x2d685d]['status']=0x3,_0x311d9b[_0x2d685d]['abortReason']='set'):(f(_0x311d9b[_0x2d685d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x311d9b[_0x2d685d]['unwatcher'](),_0xd7854e=_0xd7854e['concat'](pe(_0xd14c37['serverSyncTree_'],_0x311d9b[_0x2d685d]['currentWriteId'],!0x0)),_0x311d9b[_0x2d685d]['onComplete']&&_0x589c0a['push'](_0x311d9b[_0x2d685d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4efaf8===-0x1?fs(_0x3e9692,void 0x0):_0x311d9b['length']=_0x4efaf8+0x1,V(_0xd14c37['eventQueue_'],Gt(_0x3e9692),_0xd7854e);for(let _0x2760d1=0x0;_0x2760d1<_0x589c0a['length'];_0x2760d1++)lt(_0x589c0a[_0x2760d1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x52bd11){let _0x1fc981='';const _0x5cfe50=_0x52bd11['split']('/');for(let _0x5a55c5=0x0;_0x5a55c5<_0x5cfe50['length'];_0x5a55c5++)if(_0x5cfe50[_0x5a55c5]['length']>0x0){let _0x3d93db=_0x5cfe50[_0x5a55c5];try{_0x3d93db=decodeURIComponent(_0x3d93db['replace'](/\+/g,'\x20'));}catch{}_0x1fc981+='/'+_0x3d93db;}return _0x1fc981;}function Nd(_0x37fe54){const _0x4027a7={};_0x37fe54['charAt'](0x0)==='?'&&(_0x37fe54=_0x37fe54['substring'](0x1));for(const _0x2da748 of _0x37fe54['split']('&')){if(_0x2da748['length']===0x0)continue;const _0x5d0c51=_0x2da748['split']('=');_0x5d0c51['length']===0x2?_0x4027a7[decodeURIComponent(_0x5d0c51[0x0])]=decodeURIComponent(_0x5d0c51[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2da748+'\x27\x20in\x20query\x20\x27'+_0x37fe54+'\x27');}return _0x4027a7;}const gr=function(_0xf46771,_0x1cf8d6){const _0x21bf36=Pd(_0xf46771),_0x5ec2ea=_0x21bf36['namespace'];_0x21bf36['domain']==='firebase.com'&&oe(_0x21bf36['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5ec2ea||_0x5ec2ea==='undefined')&&_0x21bf36['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x21bf36['secure']||Bl();const _0x5672fa=_0x21bf36['scheme']==='ws'||_0x21bf36['scheme']==='wss';return{'repoInfo':new _o(_0x21bf36['host'],_0x21bf36['secure'],_0x5ec2ea,_0x5672fa,_0x1cf8d6,'',_0x5ec2ea!==_0x21bf36['subdomain']),'path':new C(_0x21bf36['pathString'])};},Pd=function(_0x12e30a){let _0xa9fe9d='',_0x5d68a4='',_0x486584='',_0x49ea40='',_0x16fd80='',_0x48cb69=!0x0,_0x4b12dc='https',_0x645256=0x1bb;if(typeof _0x12e30a=='string'){let _0x25f00a=_0x12e30a['indexOf']('//');_0x25f00a>=0x0&&(_0x4b12dc=_0x12e30a['substring'](0x0,_0x25f00a-0x1),_0x12e30a=_0x12e30a['substring'](_0x25f00a+0x2));let _0x9f26dc=_0x12e30a['indexOf']('/');_0x9f26dc===-0x1&&(_0x9f26dc=_0x12e30a['length']);let _0x367421=_0x12e30a['indexOf']('?');_0x367421===-0x1&&(_0x367421=_0x12e30a['length']),_0xa9fe9d=_0x12e30a['substring'](0x0,Math['min'](_0x9f26dc,_0x367421)),_0x9f26dc<_0x367421&&(_0x49ea40=kd(_0x12e30a['substring'](_0x9f26dc,_0x367421)));const _0x2a7725=Nd(_0x12e30a['substring'](Math['min'](_0x12e30a['length'],_0x367421)));_0x25f00a=_0xa9fe9d['indexOf'](':'),_0x25f00a>=0x0?(_0x48cb69=_0x4b12dc==='https'||_0x4b12dc==='wss',_0x645256=parseInt(_0xa9fe9d['substring'](_0x25f00a+0x1),0xa)):_0x25f00a=_0xa9fe9d['length'];const _0x43424e=_0xa9fe9d['slice'](0x0,_0x25f00a);if(_0x43424e['toLowerCase']()==='localhost')_0x5d68a4='localhost';else{if(_0x43424e['split']('.')['length']<=0x2)_0x5d68a4=_0x43424e;else{const _0x1c7017=_0xa9fe9d['indexOf']('.');_0x486584=_0xa9fe9d['substring'](0x0,_0x1c7017)['toLowerCase'](),_0x5d68a4=_0xa9fe9d['substring'](_0x1c7017+0x1),_0x16fd80=_0x486584;}}'ns'in _0x2a7725&&(_0x16fd80=_0x2a7725['ns']);}return{'host':_0xa9fe9d,'port':_0x645256,'domain':_0x5d68a4,'subdomain':_0x486584,'secure':_0x48cb69,'scheme':_0x4b12dc,'pathString':_0x49ea40,'namespace':_0x16fd80};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x2897ae=0x0;const _0x342ef8=[];return function(_0x906426){const _0x18543a=_0x906426===_0x2897ae;_0x2897ae=_0x906426;let _0x2f3e5d;const _0x25c384=new Array(0x8);for(_0x2f3e5d=0x7;_0x2f3e5d>=0x0;_0x2f3e5d--)_0x25c384[_0x2f3e5d]=mr['charAt'](_0x906426%0x40),_0x906426=Math['floor'](_0x906426/0x40);f(_0x906426===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5ac4fe=_0x25c384['join']('');if(_0x18543a){for(_0x2f3e5d=0xb;_0x2f3e5d>=0x0&&_0x342ef8[_0x2f3e5d]===0x3f;_0x2f3e5d--)_0x342ef8[_0x2f3e5d]=0x0;_0x342ef8[_0x2f3e5d]++;}else{for(_0x2f3e5d=0x0;_0x2f3e5d<0xc;_0x2f3e5d++)_0x342ef8[_0x2f3e5d]=Math['floor'](Math['random']()*0x40);}for(_0x2f3e5d=0x0;_0x2f3e5d<0xc;_0x2f3e5d++)_0x5ac4fe+=mr['charAt'](_0x342ef8[_0x2f3e5d]);return f(_0x5ac4fe['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5ac4fe;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x5f04c4,_0x22fe39,_0x4e7798,_0x3a6f13){this['eventType']=_0x5f04c4,this['eventRegistration']=_0x22fe39,this['snapshot']=_0x4e7798,this['prevName']=_0x3a6f13;}['getPath'](){const _0x52dcba=this['snapshot']['ref'];return this['eventType']==='value'?_0x52dcba['_path']:_0x52dcba['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x35ab6a,_0x5d46f5,_0x11bbe4){this['eventRegistration']=_0x35ab6a,this['error']=_0x5d46f5,this['path']=_0x11bbe4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x294616,_0x4b4860){this['snapshotCallback']=_0x294616,this['cancelCallback']=_0x4b4860;}['onValue'](_0x364eaa,_0x25b3d3){this['snapshotCallback']['call'](null,_0x364eaa,_0x25b3d3);}['onCancel'](_0x32476b){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x32476b);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x13ff3a){return this['snapshotCallback']===_0x13ff3a['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x13ff3a['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x13ff3a['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x1c9eca,_0x2a391f,_0x4825e4,_0xb4ff66){this['_repo']=_0x1c9eca,this['_path']=_0x2a391f,this['_queryParams']=_0x4825e4,this['_orderByCalled']=_0xb4ff66;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1356dc=nr(this['_queryParams']),_0x43454d=Bi(_0x1356dc);return _0x43454d==='{}'?'default':_0x43454d;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0xa9bee4){if(_0xa9bee4=k(_0xa9bee4),!(_0xa9bee4 instanceof be))return!0x1;const _0x4b30c8=this['_repo']===_0xa9bee4['_repo'],_0x2d3dc5=qi(this['_path'],_0xa9bee4['_path']),_0x15c973=this['_queryIdentifier']===_0xa9bee4['_queryIdentifier'];return _0x4b30c8&&_0x2d3dc5&&_0x15c973;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x568274,_0x498b5f){if(_0x568274['_orderByCalled']===!0x0)throw new Error(_0x498b5f+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x4bef15){let _0x6f1116=null,_0x375b9c=null;if(_0x4bef15['hasStart']()&&(_0x6f1116=_0x4bef15['getIndexStartValue']()),_0x4bef15['hasEnd']()&&(_0x375b9c=_0x4bef15['getIndexEndValue']()),_0x4bef15['getIndex']()===ye){const _0x45b545='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2bbdcd='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4bef15['hasStart']()){if(_0x4bef15['getIndexStartName']()!==xe)throw new Error(_0x45b545);if(typeof _0x6f1116!='string')throw new Error(_0x2bbdcd);}if(_0x4bef15['hasEnd']()){if(_0x4bef15['getIndexEndName']()!==Ie)throw new Error(_0x45b545);if(typeof _0x375b9c!='string')throw new Error(_0x2bbdcd);}}else{if(_0x4bef15['getIndex']()===R){if(_0x6f1116!=null&&!Cn(_0x6f1116)||_0x375b9c!=null&&!Cn(_0x375b9c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4bef15['getIndex']()instanceof Ki||_0x4bef15['getIndex']()===Po,'unknown\x20index\x20type.'),_0x6f1116!=null&&typeof _0x6f1116=='object'||_0x375b9c!=null&&typeof _0x375b9c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2c56a4){if(_0x2c56a4['hasStart']()&&_0x2c56a4['hasEnd']()&&_0x2c56a4['hasLimit']()&&!_0x2c56a4['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x25a662,_0x1b7207){super(_0x25a662,_0x1b7207,new Qi(),!0x1);}get['parent'](){const _0x31b4bd=To(this['_path']);return _0x31b4bd===null?null:new Z(this['_repo'],_0x31b4bd);}get['root'](){let _0x22782f=this;for(;_0x22782f['parent']!==null;)_0x22782f=_0x22782f['parent'];return _0x22782f;}}class rt{constructor(_0x335b69,_0x20f56c,_0x2317a9){this['_node']=_0x335b69,this['ref']=_0x20f56c,this['_index']=_0x2317a9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xd16a89){const _0xeacba9=new C(_0xd16a89),_0x38bda6=Lt(this['ref'],_0xd16a89);return new rt(this['_node']['getChild'](_0xeacba9),_0x38bda6,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x38ec80){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5b67ad,_0x498463)=>_0x38ec80(new rt(_0x498463,Lt(this['ref'],_0x5b67ad),R)));}['hasChild'](_0x140478){const _0x46c0f0=new C(_0x140478);return!this['_node']['getChild'](_0x46c0f0)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1f95cc,_0x3128ee){return _0x1f95cc=k(_0x1f95cc),_0x1f95cc['_checkNotDeleted']('ref'),_0x3128ee!==void 0x0?Lt(_0x1f95cc['_root'],_0x3128ee):_0x1f95cc['_root'];}function Lt(_0x34a332,_0x4cedc8){return _0x34a332=k(_0x34a332),y(_0x34a332['_path'])===null?ud('child','path',_0x4cedc8):_s('child','path',_0x4cedc8),new Z(_0x34a332['_repo'],A(_0x34a332['_path'],_0x4cedc8));}function d_(_0x5b3b51,_0x219c5d){_0x5b3b51=k(_0x5b3b51),gs('push',_0x5b3b51['_path']),qt('push',_0x219c5d,_0x5b3b51['_path'],!0x0);const _0x3f899a=oa(_0x5b3b51['_repo']),_0x56bf9c=Od(_0x3f899a),_0x2a088a=Lt(_0x5b3b51,_0x56bf9c),_0x167017=Lt(_0x5b3b51,_0x56bf9c);let _0xdb7d63;return _0x219c5d!=null?_0xdb7d63=Ld(_0x167017,_0x219c5d)['then'](()=>_0x167017):_0xdb7d63=Promise['resolve'](_0x167017),_0x2a088a['then']=_0xdb7d63['then']['bind'](_0xdb7d63),_0x2a088a['catch']=_0xdb7d63['then']['bind'](_0xdb7d63,void 0x0),_0x2a088a;}function Ld(_0x4d9c3e,_0xc3238d){_0x4d9c3e=k(_0x4d9c3e),gs('set',_0x4d9c3e['_path']),qt('set',_0xc3238d,_0x4d9c3e['_path'],!0x1);const _0x43cc1e=new Ve();return Ed(_0x4d9c3e['_repo'],_0x4d9c3e['_path'],_0xc3238d,null,_0x43cc1e['wrapCallback'](()=>{})),_0x43cc1e['promise'];}function f_(_0x1bc6c8,_0x3ea133){hd('update',_0x3ea133,_0x1bc6c8['_path']);const _0x21a4a8=new Ve();return Id(_0x1bc6c8['_repo'],_0x1bc6c8['_path'],_0x3ea133,_0x21a4a8['wrapCallback'](()=>{})),_0x21a4a8['promise'];}function p_(_0x4521ff){_0x4521ff=k(_0x4521ff);const _0x185158=new ua(()=>{}),_0x4570c5=new qn(_0x185158);return vd(_0x4521ff['_repo'],_0x4521ff,_0x4570c5)['then'](_0x51da79=>new rt(_0x51da79,new Z(_0x4521ff['_repo'],_0x4521ff['_path']),_0x4521ff['_queryParams']['getIndex']()));}class qn{constructor(_0x8e8dd6){this['callbackContext']=_0x8e8dd6;}['respondsTo'](_0x1de279){return _0x1de279==='value';}['createEvent'](_0x74a158,_0x457474){const _0x4105cc=_0x457474['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x74a158['snapshotNode'],new Z(_0x457474['_repo'],_0x457474['_path']),_0x4105cc));}['getEventRunner'](_0x4b2132){return _0x4b2132['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4b2132['error']):()=>this['callbackContext']['onValue'](_0x4b2132['snapshot'],null);}['createCancelEvent'](_0x202014,_0x5198d8){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x202014,_0x5198d8):null;}['matches'](_0x196f08){return _0x196f08 instanceof qn?!_0x196f08['callbackContext']||!this['callbackContext']?!0x0:_0x196f08['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0xe5039e,_0x4d9154,_0x1cde69,_0x183029,_0x1b3987){const _0x56d752=new ua(_0x1cde69,void 0x0),_0x358c91=new qn(_0x56d752);return Cd(_0xe5039e['_repo'],_0xe5039e,_0x358c91),()=>Td(_0xe5039e['_repo'],_0xe5039e,_0x358c91);}function Fd(_0x464045,_0x11af76,_0x56ff50,_0x59426d){return xd(_0x464045,'value',_0x11af76);}class dt{}class pa extends dt{constructor(_0x2fc164,_0x549dae){super(),this['_value']=_0x2fc164,this['_key']=_0x549dae,this['type']='endAt';}['_apply'](_0x5939f3){qt('endAt',this['_value'],_0x5939f3['_path'],!0x0);const _0x4f2cdb=Kh(_0x5939f3['_queryParams'],this['_value'],this['_key']);if(fa(_0x4f2cdb),Gn(_0x4f2cdb),_0x5939f3['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x5939f3['_repo'],_0x5939f3['_path'],_0x4f2cdb,_0x5939f3['_orderByCalled']);}}function __(_0x7046ca,_0xa02e76){return new pa(_0x7046ca,_0xa02e76);}class _a extends dt{constructor(_0x2f3316,_0x2b05fe){super(),this['_value']=_0x2f3316,this['_key']=_0x2b05fe,this['type']='startAt';}['_apply'](_0x2a750b){qt('startAt',this['_value'],_0x2a750b['_path'],!0x0);const _0xca87e3=jh(_0x2a750b['_queryParams'],this['_value'],this['_key']);if(fa(_0xca87e3),Gn(_0xca87e3),_0x2a750b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2a750b['_repo'],_0x2a750b['_path'],_0xca87e3,_0x2a750b['_orderByCalled']);}}function g_(_0x515c8d=null,_0x3f4e03){return new _a(_0x515c8d,_0x3f4e03);}class Ud extends dt{constructor(_0x52845d){super(),this['_limit']=_0x52845d,this['type']='limitToFirst';}['_apply'](_0x283c9a){if(_0x283c9a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x283c9a['_repo'],_0x283c9a['_path'],zh(_0x283c9a['_queryParams'],this['_limit']),_0x283c9a['_orderByCalled']);}}function m_(_0x4cf59e){if(Math['floor'](_0x4cf59e)!==_0x4cf59e||_0x4cf59e<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x4cf59e);}class Wd extends dt{constructor(_0x271d58){super(),this['_path']=_0x271d58,this['type']='orderByChild';}['_apply'](_0x9ef1d7){da(_0x9ef1d7,'orderByChild');const _0x10332f=new C(this['_path']);if(v(_0x10332f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x27f459=new Ki(_0x10332f),_0x4bb700=Do(_0x9ef1d7['_queryParams'],_0x27f459);return Gn(_0x4bb700),new be(_0x9ef1d7['_repo'],_0x9ef1d7['_path'],_0x4bb700,!0x0);}}function y_(_0x4c0d0c){if(_0x4c0d0c==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4c0d0c==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4c0d0c==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x4c0d0c),new Wd(_0x4c0d0c);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x33d381){da(_0x33d381,'orderByKey');const _0x1a2bb7=Do(_0x33d381['_queryParams'],ye);return Gn(_0x1a2bb7),new be(_0x33d381['_repo'],_0x33d381['_path'],_0x1a2bb7,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x46f813,_0x24086b){super(),this['_value']=_0x46f813,this['_key']=_0x24086b,this['type']='equalTo';}['_apply'](_0x3b04bd){if(qt('equalTo',this['_value'],_0x3b04bd['_path'],!0x1),_0x3b04bd['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3b04bd['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3b04bd));}}function E_(_0x2de8a4,_0x1bbf66){return new Vd(_0x2de8a4,_0x1bbf66);}function I_(_0x190560,..._0x4a32d6){let _0x2149c8=k(_0x190560);for(const _0x1af3cf of _0x4a32d6)_0x2149c8=_0x1af3cf['_apply'](_0x2149c8);return _0x2149c8;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3c46e4,_0x50b11b,_0x437552,_0x22462d){const _0x1fd652=_0x50b11b['lastIndexOf'](':'),_0xac45d4=_0x50b11b['substring'](0x0,_0x1fd652),_0x411b8f=Wt(_0xac45d4);_0x3c46e4['repoInfo_']=new _o(_0x50b11b,_0x411b8f,_0x3c46e4['repoInfo_']['namespace'],_0x3c46e4['repoInfo_']['webSocketOnly'],_0x3c46e4['repoInfo_']['nodeAdmin'],_0x3c46e4['repoInfo_']['persistenceKey'],_0x3c46e4['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x437552),_0x22462d&&(_0x3c46e4['authTokenProvider_']=_0x22462d);}function qd(_0x74bbb6,_0x564b41,_0x14b770,_0x2ac26e,_0xeb26c7){let _0x3d8064=_0x2ac26e||_0x74bbb6['options']['databaseURL'];_0x3d8064===void 0x0&&(_0x74bbb6['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x74bbb6['options']['projectId']),_0x3d8064=_0x74bbb6['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x19e138=gr(_0x3d8064,_0xeb26c7),_0x32f762=_0x19e138['repoInfo'],_0x4e36f4;typeof process<'u'&&Us&&(_0x4e36f4=Us[Hd]),_0x4e36f4?(_0x3d8064='http://'+_0x4e36f4+'?ns='+_0x32f762['namespace'],_0x19e138=gr(_0x3d8064,_0xeb26c7),_0x32f762=_0x19e138['repoInfo']):_0x19e138['repoInfo']['secure'];const _0xa7948e=new Jl(_0x74bbb6['name'],_0x74bbb6['options'],_0x564b41);dd('Invalid\x20Firebase\x20Database\x20URL',_0x19e138),v(_0x19e138['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1f9389=jd(_0x32f762,_0x74bbb6,_0xa7948e,new Ql(_0x74bbb6,_0x14b770));return new Kd(_0x1f9389,_0x74bbb6);}function zd(_0x31285f,_0x473668){const _0x2876ad=ki[_0x473668];(!_0x2876ad||_0x2876ad[_0x31285f['key']]!==_0x31285f)&&oe('Database\x20'+_0x473668+'('+_0x31285f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x31285f),delete _0x2876ad[_0x31285f['key']];}function jd(_0x555ced,_0x23a4ac,_0x11d11b,_0x474c40){let _0x1bdefd=ki[_0x23a4ac['name']];_0x1bdefd||(_0x1bdefd={},ki[_0x23a4ac['name']]=_0x1bdefd);let _0x23e2dd=_0x1bdefd[_0x555ced['toURLString']()];return _0x23e2dd&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x23e2dd=new gd(_0x555ced,$d,_0x11d11b,_0x474c40),_0x1bdefd[_0x555ced['toURLString']()]=_0x23e2dd,_0x23e2dd;}class Kd{constructor(_0x141eb3,_0x69735){this['_repoInternal']=_0x141eb3,this['app']=_0x69735,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x54762b){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x54762b+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x57fdbd=Qr(),_0x811808){const _0x55a416=Ui(_0x57fdbd,'database')['getImmediate']({'identifier':_0x811808});if(!_0x55a416['_instanceStarted']){const _0x111df7=ac('database');_0x111df7&&Yd(_0x55a416,..._0x111df7);}return _0x55a416;}function Yd(_0x3120d3,_0x17f70c,_0x4388eb,_0xd3d894={}){_0x3120d3=k(_0x3120d3),_0x3120d3['_checkNotDeleted']('useEmulator');const _0x48ed3a=_0x17f70c+':'+_0x4388eb,_0x4e3745=_0x3120d3['_repoInternal'];if(_0x3120d3['_instanceStarted']){if(_0x48ed3a===_0x3120d3['_repoInternal']['repoInfo_']['host']&&De(_0xd3d894,_0x4e3745['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x382622;if(_0x4e3745['repoInfo_']['nodeAdmin'])_0xd3d894['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x382622=new tn(tn['OWNER']);else{if(_0xd3d894['mockUserToken']){const _0x2417fc=typeof _0xd3d894['mockUserToken']=='string'?_0xd3d894['mockUserToken']:cc(_0xd3d894['mockUserToken'],_0x3120d3['app']['options']['projectId']);_0x382622=new tn(_0x2417fc);}}Wt(_0x17f70c)&&jr(_0x17f70c),Gd(_0x4e3745,_0x48ed3a,_0xd3d894,_0x382622);}function C_(_0x624c90){_0x624c90=k(_0x624c90),_0x624c90['_checkNotDeleted']('goOffline'),aa(_0x624c90['_repo']);}function T_(_0x3b7dcf){_0x3b7dcf=k(_0x3b7dcf),_0x3b7dcf['_checkNotDeleted']('goOnline'),Sd(_0x3b7dcf['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x438957){Ll(ct),et(new Me('database',(_0x41c6cc,{instanceIdentifier:_0x479abb})=>{const _0x5204ae=_0x41c6cc['getProvider']('app')['getImmediate'](),_0x35e5cf=_0x41c6cc['getProvider']('auth-internal'),_0x50dfe5=_0x41c6cc['getProvider']('app-check-internal');return qd(_0x5204ae,_0x35e5cf,_0x50dfe5,_0x479abb);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x438957),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xaad20c,_0x191c1f){this['committed']=_0xaad20c,this['snapshot']=_0x191c1f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x23f880,_0x31e0b6,_0x431be1){if(_0x23f880=k(_0x23f880),gs('Reference.transaction',_0x23f880['_path']),_0x23f880['key']==='.length'||_0x23f880['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x23f880['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5e8193=!0x0,_0x486a3f=new Ve(),_0x43f684=(_0x16387d,_0x44cabd,_0x4b51f0)=>{let _0x3211b2=null;_0x16387d?_0x486a3f['reject'](_0x16387d):(_0x3211b2=new rt(_0x4b51f0,new Z(_0x23f880['_repo'],_0x23f880['_path']),R),_0x486a3f['resolve'](new Xd(_0x44cabd,_0x3211b2)));},_0x50d084=Fd(_0x23f880,()=>{});return bd(_0x23f880['_repo'],_0x23f880['_path'],_0x31e0b6,_0x43f684,_0x50d084,_0x5e8193),_0x486a3f['promise'];}ie['prototype']['simpleListen']=function(_0x12e30c,_0x23e602){this['sendRequest']('q',{'p':_0x12e30c},_0x23e602);},ie['prototype']['echo']=function(_0xbcaffa,_0x44e2cf){this['sendRequest']('echo',{'d':_0xbcaffa},_0x44e2cf);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x515c5c,..._0x2725d7){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x515c5c,..._0x2725d7);}function nn(_0x21e37d,..._0x5ea933){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x21e37d,..._0x5ea933);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0xfbd50a,..._0x5f375a){throw Es(_0xfbd50a,..._0x5f375a);}function J(_0x18bb3c,..._0x39f086){return Es(_0x18bb3c,..._0x39f086);}function ya(_0x45bc31,_0x4b1390,_0x1d84c9){const _0x5796a2={...Zd(),[_0x4b1390]:_0x1d84c9};return new Ut('auth','Firebase',_0x5796a2)['create'](_0x4b1390,{'appName':_0x45bc31['name']});}function se(_0x4cd369){return ya(_0x4cd369,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x359502,..._0x10757c){if(typeof _0x359502!='string'){const _0x17e884=_0x10757c[0x0],_0x5b0168=[..._0x10757c['slice'](0x1)];return _0x5b0168[0x0]&&(_0x5b0168[0x0]['appName']=_0x359502['name']),_0x359502['_errorFactory']['create'](_0x17e884,..._0x5b0168);}return ma['create'](_0x359502,..._0x10757c);}function m(_0x465954,_0x1e822d,..._0x59c73d){if(!_0x465954)throw Es(_0x1e822d,..._0x59c73d);}function te(_0x4c887d){const _0x4e9155='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4c887d;throw nn(_0x4e9155),new Error(_0x4e9155);}function ae(_0x4af3b6,_0x466ad7){_0x4af3b6||te(_0x466ad7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x5cf3b7;return typeof self<'u'&&((_0x5cf3b7=self['location'])==null?void 0x0:_0x5cf3b7['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1e4126;return typeof self<'u'&&((_0x1e4126=self['location'])==null?void 0x0:_0x1e4126['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x57d966=navigator;return _0x57d966['languages']&&_0x57d966['languages'][0x0]||_0x57d966['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2b37fb,_0x38b524){this['shortDelay']=_0x2b37fb,this['longDelay']=_0x38b524,ae(_0x38b524>_0x2b37fb,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x33a1e4,_0x10e157){ae(_0x33a1e4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x269d62}=_0x33a1e4['emulator'];return _0x10e157?''+_0x269d62+(_0x10e157['startsWith']('/')?_0x10e157['slice'](0x1):_0x10e157):_0x269d62;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1c47a7,_0x29957e,_0x5a0050){this['fetchImpl']=_0x1c47a7,_0x29957e&&(this['headersImpl']=_0x29957e),_0x5a0050&&(this['responseImpl']=_0x5a0050);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1f1314,_0x32e04b){return _0x1f1314['tenantId']&&!_0x32e04b['tenantId']?{..._0x32e04b,'tenantId':_0x1f1314['tenantId']}:_0x32e04b;}async function Ae(_0x1991e8,_0x30f30b,_0x3e09b2,_0x2f8f8b,_0x4f9153={}){return Ea(_0x1991e8,_0x4f9153,async()=>{let _0x4e0cb0={},_0x201c6b={};_0x2f8f8b&&(_0x30f30b==='GET'?_0x201c6b=_0x2f8f8b:_0x4e0cb0={'body':JSON['stringify'](_0x2f8f8b)});const _0x576c21=at({..._0x201c6b,'key':_0x1991e8['config']['apiKey']})['slice'](0x1),_0x18309d=await _0x1991e8['_getAdditionalHeaders']();_0x18309d['Content-Type']='application/json',_0x1991e8['languageCode']&&(_0x18309d['X-Firebase-Locale']=_0x1991e8['languageCode']);const _0x39979e={'method':_0x30f30b,'headers':_0x18309d,..._0x4e0cb0};return lc()||(_0x39979e['referrerPolicy']='strict-origin-when-cross-origin'),_0x1991e8['emulatorConfig']&&Wt(_0x1991e8['emulatorConfig']['host'])&&(_0x39979e['credentials']='include'),va['fetch']()(await Ia(_0x1991e8,_0x1991e8['config']['apiHost'],_0x3e09b2,_0x576c21),_0x39979e);});}async function Ea(_0x46cc33,_0x4b9c74,_0x3072bc){_0x46cc33['_canInitEmulator']=!0x1;const _0x44f728={...rf,..._0x4b9c74};try{const _0x28062c=new lf(_0x46cc33),_0x46d5ed=await Promise['race']([_0x3072bc(),_0x28062c['promise']]);_0x28062c['clearNetworkTimeout']();const _0x59bb90=await _0x46d5ed['json']();if('needConfirmation'in _0x59bb90)throw en(_0x46cc33,'account-exists-with-different-credential',_0x59bb90);if(_0x46d5ed['ok']&&!('errorMessage'in _0x59bb90))return _0x59bb90;{const _0x4a3e3b=_0x46d5ed['ok']?_0x59bb90['errorMessage']:_0x59bb90['error']['message'],[_0x202f25,_0x125d5f]=_0x4a3e3b['split']('\x20:\x20');if(_0x202f25==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x46cc33,'credential-already-in-use',_0x59bb90);if(_0x202f25==='EMAIL_EXISTS')throw en(_0x46cc33,'email-already-in-use',_0x59bb90);if(_0x202f25==='USER_DISABLED')throw en(_0x46cc33,'user-disabled',_0x59bb90);const _0xd3ffe9=_0x44f728[_0x202f25]||_0x202f25['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x125d5f)throw ya(_0x46cc33,_0xd3ffe9,_0x125d5f);K(_0x46cc33,_0xd3ffe9);}}catch(_0x16c7a8){if(_0x16c7a8 instanceof Se)throw _0x16c7a8;K(_0x46cc33,'network-request-failed',{'message':String(_0x16c7a8)});}}async function Yt(_0x16dbcf,_0x495c57,_0x111c51,_0x30d4b3,_0x496de4={}){const _0x342f88=await Ae(_0x16dbcf,_0x495c57,_0x111c51,_0x30d4b3,_0x496de4);return'mfaPendingCredential'in _0x342f88&&K(_0x16dbcf,'multi-factor-auth-required',{'_serverResponse':_0x342f88}),_0x342f88;}async function Ia(_0x1564f7,_0x2bb215,_0x1d85bf,_0x3cdf2a){const _0x496528=''+_0x2bb215+_0x1d85bf+'?'+_0x3cdf2a,_0x4bdd47=_0x1564f7,_0x562d8c=_0x4bdd47['config']['emulator']?Is(_0x1564f7['config'],_0x496528):_0x1564f7['config']['apiScheme']+'://'+_0x496528;return of['includes'](_0x1d85bf)&&(await _0x4bdd47['_persistenceManagerAvailable'],_0x4bdd47['_getPersistenceType']()==='COOKIE')?_0x4bdd47['_getPersistence']()['_getFinalTarget'](_0x562d8c)['toString']():_0x562d8c;}function cf(_0x3ccbe1){switch(_0x3ccbe1){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x484580){this['auth']=_0x484580,this['timer']=null,this['promise']=new Promise((_0x32b0b8,_0x4a660b)=>{this['timer']=setTimeout(()=>_0x4a660b(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1ad237,_0x45a109,_0x4e0ff5){const _0x4e6cf2={'appName':_0x1ad237['name']};_0x4e0ff5['email']&&(_0x4e6cf2['email']=_0x4e0ff5['email']),_0x4e0ff5['phoneNumber']&&(_0x4e6cf2['phoneNumber']=_0x4e0ff5['phoneNumber']);const _0x2c8d3e=J(_0x1ad237,_0x45a109,_0x4e6cf2);return _0x2c8d3e['customData']['_tokenResponse']=_0x4e0ff5,_0x2c8d3e;}function vr(_0x43f003){return _0x43f003!==void 0x0&&_0x43f003['enterprise']!==void 0x0;}class hf{constructor(_0x45a52f){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x45a52f['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x45a52f['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x45a52f['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2838b2){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3e5b73 of this['recaptchaEnforcementState'])if(_0x3e5b73['provider']&&_0x3e5b73['provider']===_0x2838b2)return cf(_0x3e5b73['enforcementState']);return null;}['isProviderEnabled'](_0x340b4e){return this['getProviderEnforcementState'](_0x340b4e)==='ENFORCE'||this['getProviderEnforcementState'](_0x340b4e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x17bf37,_0x41e4d1){return Ae(_0x17bf37,'GET','/v2/recaptchaConfig',Re(_0x17bf37,_0x41e4d1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x231a1c,_0x377376){return Ae(_0x231a1c,'POST','/v1/accounts:delete',_0x377376);}async function Sn(_0xc38c2f,_0x423408){return Ae(_0xc38c2f,'POST','/v1/accounts:lookup',_0x423408);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x252925){if(_0x252925)try{const _0x1bb809=new Date(Number(_0x252925));if(!isNaN(_0x1bb809['getTime']()))return _0x1bb809['toUTCString']();}catch{}}async function ff(_0x405218,_0x14c078=!0x1){const _0x7e3349=k(_0x405218),_0x19e326=await _0x7e3349['getIdToken'](_0x14c078),_0x1cfa61=ws(_0x19e326);m(_0x1cfa61&&_0x1cfa61['exp']&&_0x1cfa61['auth_time']&&_0x1cfa61['iat'],_0x7e3349['auth'],'internal-error');const _0x3b2f78=typeof _0x1cfa61['firebase']=='object'?_0x1cfa61['firebase']:void 0x0,_0x4c1297=_0x3b2f78==null?void 0x0:_0x3b2f78['sign_in_provider'];return{'claims':_0x1cfa61,'token':_0x19e326,'authTime':St(ci(_0x1cfa61['auth_time'])),'issuedAtTime':St(ci(_0x1cfa61['iat'])),'expirationTime':St(ci(_0x1cfa61['exp'])),'signInProvider':_0x4c1297||null,'signInSecondFactor':(_0x3b2f78==null?void 0x0:_0x3b2f78['sign_in_second_factor'])||null};}function ci(_0x2dd930){return Number(_0x2dd930)*0x3e8;}function ws(_0x1678b8){const [_0x33b4ff,_0x2b8f87,_0x444b24]=_0x1678b8['split']('.');if(_0x33b4ff===void 0x0||_0x2b8f87===void 0x0||_0x444b24===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x556b5e=cn(_0x2b8f87);return _0x556b5e?JSON['parse'](_0x556b5e):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xa83ff7){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xa83ff7==null?void 0x0:_0xa83ff7['toString']()),null;}}function Er(_0x407edf){const _0xa707f5=ws(_0x407edf);return m(_0xa707f5,'internal-error'),m(typeof _0xa707f5['exp']<'u','internal-error'),m(typeof _0xa707f5['iat']<'u','internal-error'),Number(_0xa707f5['exp'])-Number(_0xa707f5['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x47e8e7,_0x2169c1,_0x2e0ab3=!0x1){if(_0x2e0ab3)return _0x2169c1;try{return await _0x2169c1;}catch(_0x5b6db9){throw _0x5b6db9 instanceof Se&&pf(_0x5b6db9)&&_0x47e8e7['auth']['currentUser']===_0x47e8e7&&await _0x47e8e7['auth']['signOut'](),_0x5b6db9;}}function pf({code:_0x5a4cef}){return _0x5a4cef==='auth/user-disabled'||_0x5a4cef==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x42704a){this['user']=_0x42704a,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x262923){if(_0x262923){const _0x3025d7=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3025d7;}else{this['errorBackoff']=0x7530;const _0x3098d6=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3098d6);}}['schedule'](_0x3dc43b=!0x1){if(!this['isRunning'])return;const _0x4fe266=this['getInterval'](_0x3dc43b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4fe266);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3114ec){(_0x3114ec==null?void 0x0:_0x3114ec['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5cd344,_0x77a5b3){this['createdAt']=_0x5cd344,this['lastLoginAt']=_0x77a5b3,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x1ef1b2){this['createdAt']=_0x1ef1b2['createdAt'],this['lastLoginAt']=_0x1ef1b2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x51e237){var _0x622633;const _0x2ebc30=_0x51e237['auth'],_0x531f3e=await _0x51e237['getIdToken'](),_0xc4a64e=await xt(_0x51e237,Sn(_0x2ebc30,{'idToken':_0x531f3e}));m(_0xc4a64e==null?void 0x0:_0xc4a64e['users']['length'],_0x2ebc30,'internal-error');const _0x427664=_0xc4a64e['users'][0x0];_0x51e237['_notifyReloadListener'](_0x427664);const _0x586d16=(_0x622633=_0x427664['providerUserInfo'])!=null&&_0x622633['length']?wa(_0x427664['providerUserInfo']):[],_0x30b4ce=mf(_0x51e237['providerData'],_0x586d16),_0x2dc75d=_0x51e237['isAnonymous'],_0x5252a5=!(_0x51e237['email']&&_0x427664['passwordHash'])&&!(_0x30b4ce!=null&&_0x30b4ce['length']),_0x240aa1=_0x2dc75d?_0x5252a5:!0x1,_0x5cd927={'uid':_0x427664['localId'],'displayName':_0x427664['displayName']||null,'photoURL':_0x427664['photoUrl']||null,'email':_0x427664['email']||null,'emailVerified':_0x427664['emailVerified']||!0x1,'phoneNumber':_0x427664['phoneNumber']||null,'tenantId':_0x427664['tenantId']||null,'providerData':_0x30b4ce,'metadata':new Pi(_0x427664['createdAt'],_0x427664['lastLoginAt']),'isAnonymous':_0x240aa1};Object['assign'](_0x51e237,_0x5cd927);}async function gf(_0x1e1918){const _0x20ce38=k(_0x1e1918);await bn(_0x20ce38),await _0x20ce38['auth']['_persistUserIfCurrent'](_0x20ce38),_0x20ce38['auth']['_notifyListenersIfCurrent'](_0x20ce38);}function mf(_0x152fcc,_0x321a8e){return[..._0x152fcc['filter'](_0x172b91=>!_0x321a8e['some'](_0x1d7913=>_0x1d7913['providerId']===_0x172b91['providerId'])),..._0x321a8e];}function wa(_0x16790e){return _0x16790e['map'](({providerId:_0x44c471,..._0x323a66})=>({'providerId':_0x44c471,'uid':_0x323a66['rawId']||'','displayName':_0x323a66['displayName']||null,'email':_0x323a66['email']||null,'phoneNumber':_0x323a66['phoneNumber']||null,'photoURL':_0x323a66['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x42fd56,_0x4cec11){const _0x5d0013=await Ea(_0x42fd56,{},async()=>{const _0x59b9c7=at({'grant_type':'refresh_token','refresh_token':_0x4cec11})['slice'](0x1),{tokenApiHost:_0x288616,apiKey:_0x1fcbe3}=_0x42fd56['config'],_0x5cdb80=await Ia(_0x42fd56,_0x288616,'/v1/token','key='+_0x1fcbe3),_0x5a6bf5=await _0x42fd56['_getAdditionalHeaders']();_0x5a6bf5['Content-Type']='application/x-www-form-urlencoded';const _0x2b6bb4={'method':'POST','headers':_0x5a6bf5,'body':_0x59b9c7};return _0x42fd56['emulatorConfig']&&Wt(_0x42fd56['emulatorConfig']['host'])&&(_0x2b6bb4['credentials']='include'),va['fetch']()(_0x5cdb80,_0x2b6bb4);});return{'accessToken':_0x5d0013['access_token'],'expiresIn':_0x5d0013['expires_in'],'refreshToken':_0x5d0013['refresh_token']};}async function vf(_0x59de64,_0x2a2886){return Ae(_0x59de64,'POST','/v2/accounts:revokeToken',Re(_0x59de64,_0x2a2886));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5db50d){m(_0x5db50d['idToken'],'internal-error'),m(typeof _0x5db50d['idToken']<'u','internal-error'),m(typeof _0x5db50d['refreshToken']<'u','internal-error');const _0x4b8991='expiresIn'in _0x5db50d&&typeof _0x5db50d['expiresIn']<'u'?Number(_0x5db50d['expiresIn']):Er(_0x5db50d['idToken']);this['updateTokensAndExpiration'](_0x5db50d['idToken'],_0x5db50d['refreshToken'],_0x4b8991);}['updateFromIdToken'](_0x294f86){m(_0x294f86['length']!==0x0,'internal-error');const _0x5b89ec=Er(_0x294f86);this['updateTokensAndExpiration'](_0x294f86,null,_0x5b89ec);}async['getToken'](_0x44a2cd,_0x341786=!0x1){return!_0x341786&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x44a2cd,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x44a2cd,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2ad73e,_0x3c9972){const {accessToken:_0x4a8113,refreshToken:_0x539b71,expiresIn:_0x3420ee}=await yf(_0x2ad73e,_0x3c9972);this['updateTokensAndExpiration'](_0x4a8113,_0x539b71,Number(_0x3420ee));}['updateTokensAndExpiration'](_0x4c3b93,_0x97be8c,_0x1b6432){this['refreshToken']=_0x97be8c||null,this['accessToken']=_0x4c3b93||null,this['expirationTime']=Date['now']()+_0x1b6432*0x3e8;}static['fromJSON'](_0x2a6d85,_0x28bdf5){const {refreshToken:_0x1d9fd6,accessToken:_0x4ffdea,expirationTime:_0x283f3a}=_0x28bdf5,_0x5325f9=new Je();return _0x1d9fd6&&(m(typeof _0x1d9fd6=='string','internal-error',{'appName':_0x2a6d85}),_0x5325f9['refreshToken']=_0x1d9fd6),_0x4ffdea&&(m(typeof _0x4ffdea=='string','internal-error',{'appName':_0x2a6d85}),_0x5325f9['accessToken']=_0x4ffdea),_0x283f3a&&(m(typeof _0x283f3a=='number','internal-error',{'appName':_0x2a6d85}),_0x5325f9['expirationTime']=_0x283f3a),_0x5325f9;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4d47a8){this['accessToken']=_0x4d47a8['accessToken'],this['refreshToken']=_0x4d47a8['refreshToken'],this['expirationTime']=_0x4d47a8['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x4d431c,_0x199b89){m(typeof _0x4d431c=='string'||typeof _0x4d431c>'u','internal-error',{'appName':_0x199b89});}class z{constructor({uid:_0x3c6208,auth:_0x1efaad,stsTokenManager:_0x206daa,..._0x32e4f2}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3c6208,this['auth']=_0x1efaad,this['stsTokenManager']=_0x206daa,this['accessToken']=_0x206daa['accessToken'],this['displayName']=_0x32e4f2['displayName']||null,this['email']=_0x32e4f2['email']||null,this['emailVerified']=_0x32e4f2['emailVerified']||!0x1,this['phoneNumber']=_0x32e4f2['phoneNumber']||null,this['photoURL']=_0x32e4f2['photoURL']||null,this['isAnonymous']=_0x32e4f2['isAnonymous']||!0x1,this['tenantId']=_0x32e4f2['tenantId']||null,this['providerData']=_0x32e4f2['providerData']?[..._0x32e4f2['providerData']]:[],this['metadata']=new Pi(_0x32e4f2['createdAt']||void 0x0,_0x32e4f2['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5a4807){const _0x1b8de5=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x5a4807));return m(_0x1b8de5,this['auth'],'internal-error'),this['accessToken']!==_0x1b8de5&&(this['accessToken']=_0x1b8de5,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1b8de5;}['getIdTokenResult'](_0x12edd2){return ff(this,_0x12edd2);}['reload'](){return gf(this);}['_assign'](_0x4c1c71){this!==_0x4c1c71&&(m(this['uid']===_0x4c1c71['uid'],this['auth'],'internal-error'),this['displayName']=_0x4c1c71['displayName'],this['photoURL']=_0x4c1c71['photoURL'],this['email']=_0x4c1c71['email'],this['emailVerified']=_0x4c1c71['emailVerified'],this['phoneNumber']=_0x4c1c71['phoneNumber'],this['isAnonymous']=_0x4c1c71['isAnonymous'],this['tenantId']=_0x4c1c71['tenantId'],this['providerData']=_0x4c1c71['providerData']['map'](_0x575bac=>({..._0x575bac})),this['metadata']['_copy'](_0x4c1c71['metadata']),this['stsTokenManager']['_assign'](_0x4c1c71['stsTokenManager']));}['_clone'](_0xabe181){const _0x5f0d91=new z({...this,'auth':_0xabe181,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5f0d91['metadata']['_copy'](this['metadata']),_0x5f0d91;}['_onReload'](_0xce6020){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xce6020,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x551d52){this['reloadListener']?this['reloadListener'](_0x551d52):this['reloadUserInfo']=_0x551d52;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x59e1b8,_0x102fce=!0x1){let _0x233308=!0x1;_0x59e1b8['idToken']&&_0x59e1b8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x59e1b8),_0x233308=!0x0),_0x102fce&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x233308&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x42fbb4=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x42fbb4})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1fbef1=>({..._0x1fbef1})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x51ba44,_0xeb7a7c){const _0x1f1f90=_0xeb7a7c['displayName']??void 0x0,_0x1adbba=_0xeb7a7c['email']??void 0x0,_0x294f87=_0xeb7a7c['phoneNumber']??void 0x0,_0xe0913a=_0xeb7a7c['photoURL']??void 0x0,_0x2e5a01=_0xeb7a7c['tenantId']??void 0x0,_0x2da6ab=_0xeb7a7c['_redirectEventId']??void 0x0,_0x22931a=_0xeb7a7c['createdAt']??void 0x0,_0x3a0566=_0xeb7a7c['lastLoginAt']??void 0x0,{uid:_0x2688b4,emailVerified:_0x5c661d,isAnonymous:_0x5cabfb,providerData:_0xc04430,stsTokenManager:_0x240605}=_0xeb7a7c;m(_0x2688b4&&_0x240605,_0x51ba44,'internal-error');const _0x23e3c1=Je['fromJSON'](this['name'],_0x240605);m(typeof _0x2688b4=='string',_0x51ba44,'internal-error'),ce(_0x1f1f90,_0x51ba44['name']),ce(_0x1adbba,_0x51ba44['name']),m(typeof _0x5c661d=='boolean',_0x51ba44,'internal-error'),m(typeof _0x5cabfb=='boolean',_0x51ba44,'internal-error'),ce(_0x294f87,_0x51ba44['name']),ce(_0xe0913a,_0x51ba44['name']),ce(_0x2e5a01,_0x51ba44['name']),ce(_0x2da6ab,_0x51ba44['name']),ce(_0x22931a,_0x51ba44['name']),ce(_0x3a0566,_0x51ba44['name']);const _0x5234e4=new z({'uid':_0x2688b4,'auth':_0x51ba44,'email':_0x1adbba,'emailVerified':_0x5c661d,'displayName':_0x1f1f90,'isAnonymous':_0x5cabfb,'photoURL':_0xe0913a,'phoneNumber':_0x294f87,'tenantId':_0x2e5a01,'stsTokenManager':_0x23e3c1,'createdAt':_0x22931a,'lastLoginAt':_0x3a0566});return _0xc04430&&Array['isArray'](_0xc04430)&&(_0x5234e4['providerData']=_0xc04430['map'](_0x2ae710=>({..._0x2ae710}))),_0x2da6ab&&(_0x5234e4['_redirectEventId']=_0x2da6ab),_0x5234e4;}static async['_fromIdTokenResponse'](_0x4edf6b,_0x59fea1,_0x71f810=!0x1){const _0x3399eb=new Je();_0x3399eb['updateFromServerResponse'](_0x59fea1);const _0x2d9334=new z({'uid':_0x59fea1['localId'],'auth':_0x4edf6b,'stsTokenManager':_0x3399eb,'isAnonymous':_0x71f810});return await bn(_0x2d9334),_0x2d9334;}static async['_fromGetAccountInfoResponse'](_0x5a04da,_0x13b4bb,_0x56acde){const _0x1c51dd=_0x13b4bb['users'][0x0];m(_0x1c51dd['localId']!==void 0x0,'internal-error');const _0x5d16ba=_0x1c51dd['providerUserInfo']!==void 0x0?wa(_0x1c51dd['providerUserInfo']):[],_0x5019ad=!(_0x1c51dd['email']&&_0x1c51dd['passwordHash'])&&!(_0x5d16ba!=null&&_0x5d16ba['length']),_0x1e8ebb=new Je();_0x1e8ebb['updateFromIdToken'](_0x56acde);const _0x520343=new z({'uid':_0x1c51dd['localId'],'auth':_0x5a04da,'stsTokenManager':_0x1e8ebb,'isAnonymous':_0x5019ad}),_0x516a87={'uid':_0x1c51dd['localId'],'displayName':_0x1c51dd['displayName']||null,'photoURL':_0x1c51dd['photoUrl']||null,'email':_0x1c51dd['email']||null,'emailVerified':_0x1c51dd['emailVerified']||!0x1,'phoneNumber':_0x1c51dd['phoneNumber']||null,'tenantId':_0x1c51dd['tenantId']||null,'providerData':_0x5d16ba,'metadata':new Pi(_0x1c51dd['createdAt'],_0x1c51dd['lastLoginAt']),'isAnonymous':!(_0x1c51dd['email']&&_0x1c51dd['passwordHash'])&&!(_0x5d16ba!=null&&_0x5d16ba['length'])};return Object['assign'](_0x520343,_0x516a87),_0x520343;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0xf86be3){ae(_0xf86be3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4469e7=Ir['get'](_0xf86be3);return _0x4469e7?(ae(_0x4469e7 instanceof _0xf86be3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4469e7):(_0x4469e7=new _0xf86be3(),Ir['set'](_0xf86be3,_0x4469e7),_0x4469e7);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5d9a60,_0x3ae915){this['storage'][_0x5d9a60]=_0x3ae915;}async['_get'](_0x5f45d3){const _0x5a6f7d=this['storage'][_0x5f45d3];return _0x5a6f7d===void 0x0?null:_0x5a6f7d;}async['_remove'](_0x13f1ee){delete this['storage'][_0x13f1ee];}['_addListener'](_0x202c59,_0x278608){}['_removeListener'](_0x45acf4,_0x3d0004){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x10cdf3,_0x2f262c,_0x5c7e7c){return'firebase:'+_0x10cdf3+':'+_0x2f262c+':'+_0x5c7e7c;}class Xe{constructor(_0x244634,_0x51abf6,_0x4b2b94){this['persistence']=_0x244634,this['auth']=_0x51abf6,this['userKey']=_0x4b2b94;const {config:_0x417f8b,name:_0x5490fd}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x417f8b['apiKey'],_0x5490fd),this['fullPersistenceKey']=sn('persistence',_0x417f8b['apiKey'],_0x5490fd),this['boundEventHandler']=_0x51abf6['_onStorageEvent']['bind'](_0x51abf6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1c497a){return this['persistence']['_set'](this['fullUserKey'],_0x1c497a['toJSON']());}async['getCurrentUser'](){const _0x5dae38=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5dae38)return null;if(typeof _0x5dae38=='string'){const _0x249fc4=await Sn(this['auth'],{'idToken':_0x5dae38})['catch'](()=>{});return _0x249fc4?z['_fromGetAccountInfoResponse'](this['auth'],_0x249fc4,_0x5dae38):null;}return z['_fromJSON'](this['auth'],_0x5dae38);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5a7bef){if(this['persistence']===_0x5a7bef)return;const _0x5d08d9=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5a7bef,_0x5d08d9)return this['setCurrentUser'](_0x5d08d9);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x560eba,_0x55e55b,_0x5b2135='authUser'){if(!_0x55e55b['length'])return new Xe(ne(wr),_0x560eba,_0x5b2135);const _0x18137f=(await Promise['all'](_0x55e55b['map'](async _0x2ebc14=>{if(await _0x2ebc14['_isAvailable']())return _0x2ebc14;})))['filter'](_0x58fe1a=>_0x58fe1a);let _0x5ec412=_0x18137f[0x0]||ne(wr);const _0xaf8b6f=sn(_0x5b2135,_0x560eba['config']['apiKey'],_0x560eba['name']);let _0x48b8f1=null;for(const _0x578c2b of _0x55e55b)try{const _0x254ba4=await _0x578c2b['_get'](_0xaf8b6f);if(_0x254ba4){let _0x1ef79d;if(typeof _0x254ba4=='string'){const _0x2a009c=await Sn(_0x560eba,{'idToken':_0x254ba4})['catch'](()=>{});if(!_0x2a009c)break;_0x1ef79d=await z['_fromGetAccountInfoResponse'](_0x560eba,_0x2a009c,_0x254ba4);}else _0x1ef79d=z['_fromJSON'](_0x560eba,_0x254ba4);_0x578c2b!==_0x5ec412&&(_0x48b8f1=_0x1ef79d),_0x5ec412=_0x578c2b;break;}}catch{}const _0x131005=_0x18137f['filter'](_0x4e4d31=>_0x4e4d31['_shouldAllowMigration']);return!_0x5ec412['_shouldAllowMigration']||!_0x131005['length']?new Xe(_0x5ec412,_0x560eba,_0x5b2135):(_0x5ec412=_0x131005[0x0],_0x48b8f1&&await _0x5ec412['_set'](_0xaf8b6f,_0x48b8f1['toJSON']()),await Promise['all'](_0x55e55b['map'](async _0xcdc67b=>{if(_0xcdc67b!==_0x5ec412)try{await _0xcdc67b['_remove'](_0xaf8b6f);}catch{}})),new Xe(_0x5ec412,_0x560eba,_0x5b2135));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0xd8343f){const _0x2aba41=_0xd8343f['toLowerCase']();if(_0x2aba41['includes']('opera/')||_0x2aba41['includes']('opr/')||_0x2aba41['includes']('opios/'))return'Opera';if(Ra(_0x2aba41))return'IEMobile';if(_0x2aba41['includes']('msie')||_0x2aba41['includes']('trident/'))return'IE';if(_0x2aba41['includes']('edge/'))return'Edge';if(Ta(_0x2aba41))return'Firefox';if(_0x2aba41['includes']('silk/'))return'Silk';if(ka(_0x2aba41))return'Blackberry';if(Na(_0x2aba41))return'Webos';if(Sa(_0x2aba41))return'Safari';if((_0x2aba41['includes']('chrome/')||ba(_0x2aba41))&&!_0x2aba41['includes']('edge/'))return'Chrome';if(Aa(_0x2aba41))return'Android';{const _0x40b4c0=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4b414a=_0xd8343f['match'](_0x40b4c0);if((_0x4b414a==null?void 0x0:_0x4b414a['length'])===0x2)return _0x4b414a[0x1];}return'Other';}function Ta(_0x147f7a=W()){return/firefox\//i['test'](_0x147f7a);}function Sa(_0x208d6e=W()){const _0x2db71c=_0x208d6e['toLowerCase']();return _0x2db71c['includes']('safari/')&&!_0x2db71c['includes']('chrome/')&&!_0x2db71c['includes']('crios/')&&!_0x2db71c['includes']('android');}function ba(_0x459583=W()){return/crios\//i['test'](_0x459583);}function Ra(_0x3a4612=W()){return/iemobile/i['test'](_0x3a4612);}function Aa(_0x4d962c=W()){return/android/i['test'](_0x4d962c);}function ka(_0x3339d4=W()){return/blackberry/i['test'](_0x3339d4);}function Na(_0x124774=W()){return/webos/i['test'](_0x124774);}function Cs(_0x315e13=W()){return/iphone|ipad|ipod/i['test'](_0x315e13)||/macintosh/i['test'](_0x315e13)&&/mobile/i['test'](_0x315e13);}function Ef(_0x491aba=W()){var _0x49835d;return Cs(_0x491aba)&&!!((_0x49835d=window['navigator'])!=null&&_0x49835d['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x345ced=W()){return Cs(_0x345ced)||Aa(_0x345ced)||Na(_0x345ced)||ka(_0x345ced)||/windows phone/i['test'](_0x345ced)||Ra(_0x345ced);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x3a0bb3,_0x2be87d=[]){let _0x51cb18;switch(_0x3a0bb3){case'Browser':_0x51cb18=Cr(W());break;case'Worker':_0x51cb18=Cr(W())+'-'+_0x3a0bb3;break;default:_0x51cb18=_0x3a0bb3;}const _0x38156c=_0x2be87d['length']?_0x2be87d['join'](','):'FirebaseCore-web';return _0x51cb18+'/JsCore/'+ct+'/'+_0x38156c;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x161898){this['auth']=_0x161898,this['queue']=[];}['pushCallback'](_0x260790,_0x21bcdc){const _0x105ab8=_0x41839d=>new Promise((_0xdc7d6a,_0x5c9f41)=>{try{const _0xde2304=_0x260790(_0x41839d);_0xdc7d6a(_0xde2304);}catch(_0x3b343a){_0x5c9f41(_0x3b343a);}});_0x105ab8['onAbort']=_0x21bcdc,this['queue']['push'](_0x105ab8);const _0x2573f8=this['queue']['length']-0x1;return()=>{this['queue'][_0x2573f8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1e220d){if(this['auth']['currentUser']===_0x1e220d)return;const _0x5cd234=[];try{for(const _0x1204cb of this['queue'])await _0x1204cb(_0x1e220d),_0x1204cb['onAbort']&&_0x5cd234['push'](_0x1204cb['onAbort']);}catch(_0x257522){_0x5cd234['reverse']();for(const _0x1d513d of _0x5cd234)try{_0x1d513d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x257522==null?void 0x0:_0x257522['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x490111,_0x44bebb={}){return Ae(_0x490111,'GET','/v2/passwordPolicy',Re(_0x490111,_0x44bebb));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x218a0c){var _0xf950eb;const _0x4752e1=_0x218a0c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4752e1['minPasswordLength']??Tf,_0x4752e1['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4752e1['maxPasswordLength']),_0x4752e1['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4752e1['containsLowercaseCharacter']),_0x4752e1['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4752e1['containsUppercaseCharacter']),_0x4752e1['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4752e1['containsNumericCharacter']),_0x4752e1['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4752e1['containsNonAlphanumericCharacter']),this['enforcementState']=_0x218a0c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xf950eb=_0x218a0c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xf950eb['join'](''))??'',this['forceUpgradeOnSignin']=_0x218a0c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x218a0c['schemaVersion'];}['validatePassword'](_0x258f55){const _0x2a6d01={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x258f55,_0x2a6d01),this['validatePasswordCharacterOptions'](_0x258f55,_0x2a6d01),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['meetsMinPasswordLength']??!0x0),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['meetsMaxPasswordLength']??!0x0),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['containsLowercaseLetter']??!0x0),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['containsUppercaseLetter']??!0x0),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['containsNumericCharacter']??!0x0),_0x2a6d01['isValid']&&(_0x2a6d01['isValid']=_0x2a6d01['containsNonAlphanumericCharacter']??!0x0),_0x2a6d01;}['validatePasswordLengthOptions'](_0x206296,_0xafb10){const _0x3b0d4d=this['customStrengthOptions']['minPasswordLength'],_0x587e2c=this['customStrengthOptions']['maxPasswordLength'];_0x3b0d4d&&(_0xafb10['meetsMinPasswordLength']=_0x206296['length']>=_0x3b0d4d),_0x587e2c&&(_0xafb10['meetsMaxPasswordLength']=_0x206296['length']<=_0x587e2c);}['validatePasswordCharacterOptions'](_0x40b21a,_0x4f246d){this['updatePasswordCharacterOptionsStatuses'](_0x4f246d,!0x1,!0x1,!0x1,!0x1);let _0x9e5456;for(let _0x2cb321=0x0;_0x2cb321<_0x40b21a['length'];_0x2cb321++)_0x9e5456=_0x40b21a['charAt'](_0x2cb321),this['updatePasswordCharacterOptionsStatuses'](_0x4f246d,_0x9e5456>='a'&&_0x9e5456<='z',_0x9e5456>='A'&&_0x9e5456<='Z',_0x9e5456>='0'&&_0x9e5456<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x9e5456));}['updatePasswordCharacterOptionsStatuses'](_0x295ca7,_0x3984d9,_0xc8233d,_0x4cb254,_0x3be5b2){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x295ca7['containsLowercaseLetter']||(_0x295ca7['containsLowercaseLetter']=_0x3984d9)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x295ca7['containsUppercaseLetter']||(_0x295ca7['containsUppercaseLetter']=_0xc8233d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x295ca7['containsNumericCharacter']||(_0x295ca7['containsNumericCharacter']=_0x4cb254)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x295ca7['containsNonAlphanumericCharacter']||(_0x295ca7['containsNonAlphanumericCharacter']=_0x3be5b2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1d1a76,_0x4c8fd0,_0x4158f1,_0x3c6413){this['app']=_0x1d1a76,this['heartbeatServiceProvider']=_0x4c8fd0,this['appCheckServiceProvider']=_0x4158f1,this['config']=_0x3c6413,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1d1a76['name'],this['clientVersion']=_0x3c6413['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x42dcfb=>this['_resolvePersistenceManagerAvailable']=_0x42dcfb);}['_initializeWithPersistence'](_0x44fd21,_0x31fba5){return _0x31fba5&&(this['_popupRedirectResolver']=ne(_0x31fba5)),this['_initializationPromise']=this['queue'](async()=>{var _0x565195,_0x4ea4a2,_0x115b2f;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x44fd21),(_0x565195=this['_resolvePersistenceManagerAvailable'])==null||_0x565195['call'](this),!this['_deleted'])){if((_0x4ea4a2=this['_popupRedirectResolver'])!=null&&_0x4ea4a2['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x31fba5),this['lastNotifiedUid']=((_0x115b2f=this['currentUser'])==null?void 0x0:_0x115b2f['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5376b4=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5376b4)){if(this['currentUser']&&_0x5376b4&&this['currentUser']['uid']===_0x5376b4['uid']){this['_currentUser']['_assign'](_0x5376b4),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5376b4,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x12b2ca){try{const _0x32fb5c=await Sn(this,{'idToken':_0x12b2ca}),_0x1cad0d=await z['_fromGetAccountInfoResponse'](this,_0x32fb5c,_0x12b2ca);await this['directlySetCurrentUser'](_0x1cad0d);}catch(_0x484303){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x484303),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x12bbdc){var _0x402582;if(H(this['app'])){const _0x31fddd=this['app']['settings']['authIdToken'];return _0x31fddd?new Promise(_0x593521=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x31fddd)['then'](_0x593521,_0x593521));}):this['directlySetCurrentUser'](null);}const _0x336186=await this['assertedPersistence']['getCurrentUser']();let _0x31443e=_0x336186,_0x25da56=!0x1;if(_0x12bbdc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3500de=(_0x402582=this['redirectUser'])==null?void 0x0:_0x402582['_redirectEventId'],_0x59e0b0=_0x31443e==null?void 0x0:_0x31443e['_redirectEventId'],_0x4d6102=await this['tryRedirectSignIn'](_0x12bbdc);(!_0x3500de||_0x3500de===_0x59e0b0)&&(_0x4d6102!=null&&_0x4d6102['user'])&&(_0x31443e=_0x4d6102['user'],_0x25da56=!0x0);}if(!_0x31443e)return this['directlySetCurrentUser'](null);if(!_0x31443e['_redirectEventId']){if(_0x25da56)try{await this['beforeStateQueue']['runMiddleware'](_0x31443e);}catch(_0x20d236){_0x31443e=_0x336186,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x20d236));}return _0x31443e?this['reloadAndSetCurrentUserOrClear'](_0x31443e):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x31443e['_redirectEventId']?this['directlySetCurrentUser'](_0x31443e):this['reloadAndSetCurrentUserOrClear'](_0x31443e);}async['tryRedirectSignIn'](_0xb89aa){let _0x21912a=null;try{_0x21912a=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xb89aa,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x21912a;}async['reloadAndSetCurrentUserOrClear'](_0x278df6){try{await bn(_0x278df6);}catch(_0x68c97){if((_0x68c97==null?void 0x0:_0x68c97['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x278df6);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x214973){if(H(this['app']))return Promise['reject'](se(this));const _0x3cef2f=_0x214973?k(_0x214973):null;return _0x3cef2f&&m(_0x3cef2f['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3cef2f&&_0x3cef2f['_clone'](this));}async['_updateCurrentUser'](_0x9c3a60,_0x2f27c3=!0x1){if(!this['_deleted'])return _0x9c3a60&&m(this['tenantId']===_0x9c3a60['tenantId'],this,'tenant-id-mismatch'),_0x2f27c3||await this['beforeStateQueue']['runMiddleware'](_0x9c3a60),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x9c3a60),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1834fe){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x1834fe));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xf7c3ff){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x370487=this['_getPasswordPolicyInternal']();return _0x370487['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x370487['validatePassword'](_0xf7c3ff);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4b0de8=await Cf(this),_0x4258c6=new Sf(_0x4b0de8);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4258c6:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4258c6;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x20bda9){this['_errorFactory']=new Ut('auth','Firebase',_0x20bda9());}['onAuthStateChanged'](_0x3a62c7,_0x20ee07,_0x4b96d9){return this['registerStateListener'](this['authStateSubscription'],_0x3a62c7,_0x20ee07,_0x4b96d9);}['beforeAuthStateChanged'](_0x473965,_0x2c30eb){return this['beforeStateQueue']['pushCallback'](_0x473965,_0x2c30eb);}['onIdTokenChanged'](_0x1a6769,_0x51a689,_0x2fd7f9){return this['registerStateListener'](this['idTokenSubscription'],_0x1a6769,_0x51a689,_0x2fd7f9);}['authStateReady'](){return new Promise((_0x2cd217,_0x1e3647)=>{if(this['currentUser'])_0x2cd217();else{const _0xcbe3ce=this['onAuthStateChanged'](()=>{_0xcbe3ce(),_0x2cd217();},_0x1e3647);}});}async['revokeAccessToken'](_0x3fdc15){if(this['currentUser']){const _0x4f2aba=await this['currentUser']['getIdToken'](),_0x406cf2={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3fdc15,'idToken':_0x4f2aba};this['tenantId']!=null&&(_0x406cf2['tenantId']=this['tenantId']),await vf(this,_0x406cf2);}}['toJSON'](){var _0x5d9379;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5d9379=this['_currentUser'])==null?void 0x0:_0x5d9379['toJSON']()};}async['_setRedirectUser'](_0x3aec38,_0x3d27e4){const _0x294382=await this['getOrInitRedirectPersistenceManager'](_0x3d27e4);return _0x3aec38===null?_0x294382['removeCurrentUser']():_0x294382['setCurrentUser'](_0x3aec38);}async['getOrInitRedirectPersistenceManager'](_0x135b23){if(!this['redirectPersistenceManager']){const _0x9c4a7=_0x135b23&&ne(_0x135b23)||this['_popupRedirectResolver'];m(_0x9c4a7,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x9c4a7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x17e6cd){var _0x303305,_0x375cf8;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x303305=this['_currentUser'])==null?void 0x0:_0x303305['_redirectEventId'])===_0x17e6cd?this['_currentUser']:((_0x375cf8=this['redirectUser'])==null?void 0x0:_0x375cf8['_redirectEventId'])===_0x17e6cd?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x16e4e1){if(_0x16e4e1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x16e4e1));}['_notifyListenersIfCurrent'](_0x5e7691){_0x5e7691===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x347bc1;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4f3450=((_0x347bc1=this['currentUser'])==null?void 0x0:_0x347bc1['uid'])??null;this['lastNotifiedUid']!==_0x4f3450&&(this['lastNotifiedUid']=_0x4f3450,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x28e62d,_0x85688b,_0x39ee0f,_0xc4703c){if(this['_deleted'])return()=>{};const _0x372b22=typeof _0x85688b=='function'?_0x85688b:_0x85688b['next']['bind'](_0x85688b);let _0x5a2ed5=!0x1;const _0x39111a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x39111a,this,'internal-error'),_0x39111a['then'](()=>{_0x5a2ed5||_0x372b22(this['currentUser']);}),typeof _0x85688b=='function'){const _0x5285ba=_0x28e62d['addObserver'](_0x85688b,_0x39ee0f,_0xc4703c);return()=>{_0x5a2ed5=!0x0,_0x5285ba();};}else{const _0x4d1273=_0x28e62d['addObserver'](_0x85688b);return()=>{_0x5a2ed5=!0x0,_0x4d1273();};}}async['directlySetCurrentUser'](_0x2ad058){this['currentUser']&&this['currentUser']!==_0x2ad058&&this['_currentUser']['_stopProactiveRefresh'](),_0x2ad058&&this['isProactiveRefreshEnabled']&&_0x2ad058['_startProactiveRefresh'](),this['currentUser']=_0x2ad058,_0x2ad058?await this['assertedPersistence']['setCurrentUser'](_0x2ad058):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3c1669){return this['operations']=this['operations']['then'](_0x3c1669,_0x3c1669),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x45ce3c){!_0x45ce3c||this['frameworks']['includes'](_0x45ce3c)||(this['frameworks']['push'](_0x45ce3c),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x48805d;const _0x472a6e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x472a6e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x42d9cc=await((_0x48805d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x48805d['getHeartbeatsHeader']());_0x42d9cc&&(_0x472a6e['X-Firebase-Client']=_0x42d9cc);const _0x415954=await this['_getAppCheckToken']();return _0x415954&&(_0x472a6e['X-Firebase-AppCheck']=_0x415954),_0x472a6e;}async['_getAppCheckToken'](){var _0x4e2f8e;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x50c529=await((_0x4e2f8e=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4e2f8e['getToken']());return _0x50c529!=null&&_0x50c529['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x50c529['error']),_0x50c529==null?void 0x0:_0x50c529['token'];}}function qe(_0x45529f){return k(_0x45529f);}class Tr{constructor(_0x568cff){this['auth']=_0x568cff,this['observer']=null,this['addObserver']=Ic(_0x4fbc01=>this['observer']=_0x4fbc01);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x4cd935){zn=_0x4cd935;}function Da(_0x300d78){return zn['loadJS'](_0x300d78);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x51ddb9){return'__'+_0x51ddb9+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x59dbb0){_0x59dbb0();}['execute'](_0x3623c2,_0x18666d){return Promise['resolve']('token');}['render'](_0x363025,_0xa75250){return'';}}class Of{['ready'](_0x4a9120){_0x4a9120();}['execute'](_0x5545d9,_0x63d827){return Promise['resolve']('token');}['render'](_0xd3017f,_0x17abb6){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x317b4c){this['type']=Df,this['auth']=qe(_0x317b4c);}async['verify'](_0x2af21c='verify',_0x2f5cd4=!0x1){async function _0x43be0b(_0x21c61a){if(!_0x2f5cd4){if(_0x21c61a['tenantId']==null&&_0x21c61a['_agentRecaptchaConfig']!=null)return _0x21c61a['_agentRecaptchaConfig']['siteKey'];if(_0x21c61a['tenantId']!=null&&_0x21c61a['_tenantRecaptchaConfigs'][_0x21c61a['tenantId']]!==void 0x0)return _0x21c61a['_tenantRecaptchaConfigs'][_0x21c61a['tenantId']]['siteKey'];}return new Promise(async(_0x24767c,_0x1b5b23)=>{uf(_0x21c61a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x31074b=>{if(_0x31074b['recaptchaKey']===void 0x0)_0x1b5b23(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x189e8d=new hf(_0x31074b);return _0x21c61a['tenantId']==null?_0x21c61a['_agentRecaptchaConfig']=_0x189e8d:_0x21c61a['_tenantRecaptchaConfigs'][_0x21c61a['tenantId']]=_0x189e8d,_0x24767c(_0x189e8d['siteKey']);}})['catch'](_0x1985f8=>{_0x1b5b23(_0x1985f8);});});}function _0x300b4f(_0x17c9e4,_0x4d7f80,_0x23c162){const _0x5cedd8=window['grecaptcha'];vr(_0x5cedd8)?_0x5cedd8['enterprise']['ready'](()=>{_0x5cedd8['enterprise']['execute'](_0x17c9e4,{'action':_0x2af21c})['then'](_0x3467fb=>{_0x4d7f80(_0x3467fb);})['catch'](()=>{_0x4d7f80(Ma);});}):_0x23c162(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x101e9d,_0x29c74c)=>{_0x43be0b(this['auth'])['then'](async _0x14ff3e=>{if(!_0x2f5cd4&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x300b4f(_0x14ff3e,_0x101e9d,_0x29c74c);else{if(typeof window>'u'){_0x29c74c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4d8b7f=Af();_0x4d8b7f['length']!==0x0&&(_0x4d8b7f+=_0x14ff3e+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x398ab2;(_0x398ab2=le['scriptInjectionDeferred'])==null||_0x398ab2['resolve']();},Da(_0x4d8b7f)['then'](()=>{var _0x104763;return(_0x104763=le['scriptInjectionDeferred'])==null?void 0x0:_0x104763['promise'];})['then'](()=>{_0x300b4f(_0x14ff3e,_0x101e9d,_0x29c74c);})['catch'](_0x5c8953=>{_0x29c74c(_0x5c8953);});}})['catch'](_0x438238=>{_0x29c74c(_0x438238);});});}}le['scriptInjectionDeferred']=null;async function br(_0x13b8c7,_0x54d361,_0x165ac7,_0x22babb=!0x1,_0x3d02e0=!0x1){const _0xf10ee6=new le(_0x13b8c7);let _0x5c57a3;if(_0x3d02e0)_0x5c57a3=Ma;else try{_0x5c57a3=await _0xf10ee6['verify'](_0x165ac7);}catch{_0x5c57a3=await _0xf10ee6['verify'](_0x165ac7,!0x0);}const _0x2f5ae0={..._0x54d361};if(_0x165ac7==='mfaSmsEnrollment'||_0x165ac7==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2f5ae0){const _0x45493f=_0x2f5ae0['phoneEnrollmentInfo']['phoneNumber'],_0x12c37e=_0x2f5ae0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2f5ae0,{'phoneEnrollmentInfo':{'phoneNumber':_0x45493f,'recaptchaToken':_0x12c37e,'captchaResponse':_0x5c57a3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2f5ae0){const _0x36882f=_0x2f5ae0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2f5ae0,{'phoneSignInInfo':{'recaptchaToken':_0x36882f,'captchaResponse':_0x5c57a3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2f5ae0;}return _0x22babb?Object['assign'](_0x2f5ae0,{'captchaResp':_0x5c57a3}):Object['assign'](_0x2f5ae0,{'captchaResponse':_0x5c57a3}),Object['assign'](_0x2f5ae0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2f5ae0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2f5ae0;}async function Oi(_0x272acb,_0x56072f,_0x1aff56,_0x5eb538,_0x2cec73){var _0x578616;if((_0x578616=_0x272acb['_getRecaptchaConfig']())!=null&&_0x578616['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4dee17=await br(_0x272acb,_0x56072f,_0x1aff56,_0x1aff56==='getOobCode');return _0x5eb538(_0x272acb,_0x4dee17);}else return _0x5eb538(_0x272acb,_0x56072f)['catch'](async _0x5c4a23=>{if(_0x5c4a23['code']==='auth/missing-recaptcha-token'){console['log'](_0x1aff56+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x35323f=await br(_0x272acb,_0x56072f,_0x1aff56,_0x1aff56==='getOobCode');return _0x5eb538(_0x272acb,_0x35323f);}else return Promise['reject'](_0x5c4a23);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x1295e2,_0x30c5a7){const _0x206cf1=Ui(_0x1295e2,'auth');if(_0x206cf1['isInitialized']()){const _0x39aa3c=_0x206cf1['getImmediate'](),_0x25aefb=_0x206cf1['getOptions']();if(De(_0x25aefb,_0x30c5a7??{}))return _0x39aa3c;K(_0x39aa3c,'already-initialized');}return _0x206cf1['initialize']({'options':_0x30c5a7});}function Lf(_0x3901a1,_0x537fc4){const _0x10420f=(_0x537fc4==null?void 0x0:_0x537fc4['persistence'])||[],_0x280024=(Array['isArray'](_0x10420f)?_0x10420f:[_0x10420f])['map'](ne);_0x537fc4!=null&&_0x537fc4['errorMap']&&_0x3901a1['_updateErrorMap'](_0x537fc4['errorMap']),_0x3901a1['_initializeWithPersistence'](_0x280024,_0x537fc4==null?void 0x0:_0x537fc4['popupRedirectResolver']);}function xf(_0x5d1731,_0x38f5ab,_0x41b3da){const _0x1a5050=qe(_0x5d1731);m(/^https?:\/\//['test'](_0x38f5ab),_0x1a5050,'invalid-emulator-scheme');const _0x13c5fa=!0x1,_0x5f5d6b=La(_0x38f5ab),{host:_0x3fcc58,port:_0x4bb926}=Ff(_0x38f5ab),_0x3390ed=_0x4bb926===null?'':':'+_0x4bb926,_0x45ba7e={'url':_0x5f5d6b+'//'+_0x3fcc58+_0x3390ed+'/'},_0x20b902=Object['freeze']({'host':_0x3fcc58,'port':_0x4bb926,'protocol':_0x5f5d6b['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x13c5fa})});if(!_0x1a5050['_canInitEmulator']){m(_0x1a5050['config']['emulator']&&_0x1a5050['emulatorConfig'],_0x1a5050,'emulator-config-failed'),m(De(_0x45ba7e,_0x1a5050['config']['emulator'])&&De(_0x20b902,_0x1a5050['emulatorConfig']),_0x1a5050,'emulator-config-failed');return;}_0x1a5050['config']['emulator']=_0x45ba7e,_0x1a5050['emulatorConfig']=_0x20b902,_0x1a5050['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3fcc58)?jr(_0x5f5d6b+'//'+_0x3fcc58+_0x3390ed):Uf();}function La(_0x1ffaed){const _0x4d3feb=_0x1ffaed['indexOf'](':');return _0x4d3feb<0x0?'':_0x1ffaed['substr'](0x0,_0x4d3feb+0x1);}function Ff(_0x1154ad){const _0x371c52=La(_0x1154ad),_0x111f63=/(\/\/)?([^?#/]+)/['exec'](_0x1154ad['substr'](_0x371c52['length']));if(!_0x111f63)return{'host':'','port':null};const _0x319516=_0x111f63[0x2]['split']('@')['pop']()||'',_0x23ade1=/^(\[[^\]]+\])(:|$)/['exec'](_0x319516);if(_0x23ade1){const _0x221806=_0x23ade1[0x1];return{'host':_0x221806,'port':Rr(_0x319516['substr'](_0x221806['length']+0x1))};}else{const [_0x178667,_0x1d8a96]=_0x319516['split'](':');return{'host':_0x178667,'port':Rr(_0x1d8a96)};}}function Rr(_0x242410){if(!_0x242410)return null;const _0x2f931b=Number(_0x242410);return isNaN(_0x2f931b)?null:_0x2f931b;}function Uf(){function _0x287361(){const _0x160434=document['createElement']('p'),_0x4523a5=_0x160434['style'];_0x160434['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4523a5['position']='fixed',_0x4523a5['width']='100%',_0x4523a5['backgroundColor']='#ffffff',_0x4523a5['border']='.1em\x20solid\x20#000000',_0x4523a5['color']='#b50000',_0x4523a5['bottom']='0px',_0x4523a5['left']='0px',_0x4523a5['margin']='0px',_0x4523a5['zIndex']='10000',_0x4523a5['textAlign']='center',_0x160434['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x160434);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x287361):_0x287361());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x34cc5f,_0x58e2f4){this['providerId']=_0x34cc5f,this['signInMethod']=_0x58e2f4;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4c53b7){return te('not\x20implemented');}['_linkToIdToken'](_0x26dcac,_0x2b3770){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x550d6e){return te('not\x20implemented');}}async function Wf(_0x5d2fec,_0x555771){return Ae(_0x5d2fec,'POST','/v1/accounts:signUp',_0x555771);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x48786c,_0x576520){return Yt(_0x48786c,'POST','/v1/accounts:signInWithPassword',Re(_0x48786c,_0x576520));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x1a7508,_0x94a56a){return Yt(_0x1a7508,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1a7508,_0x94a56a));}async function Hf(_0x3cee02,_0x2a8766){return Yt(_0x3cee02,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3cee02,_0x2a8766));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xeaff15,_0x19bdb9,_0xab1c0b,_0xb0976e=null){super('password',_0xab1c0b),this['_email']=_0xeaff15,this['_password']=_0x19bdb9,this['_tenantId']=_0xb0976e;}static['_fromEmailAndPassword'](_0x1d7f65,_0x47a5d8){return new Ft(_0x1d7f65,_0x47a5d8,'password');}static['_fromEmailAndCode'](_0x579d5e,_0x1597b8,_0x4b643c=null){return new Ft(_0x579d5e,_0x1597b8,'emailLink',_0x4b643c);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xaffe45){const _0x439093=typeof _0xaffe45=='string'?JSON['parse'](_0xaffe45):_0xaffe45;if(_0x439093!=null&&_0x439093['email']&&(_0x439093!=null&&_0x439093['password'])){if(_0x439093['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x439093['email'],_0x439093['password']);if(_0x439093['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x439093['email'],_0x439093['password'],_0x439093['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5519c9){switch(this['signInMethod']){case'password':const _0x4f5387={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5519c9,_0x4f5387,'signInWithPassword',Bf);case'emailLink':return Vf(_0x5519c9,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x5519c9,'internal-error');}}async['_linkToIdToken'](_0x2d07cd,_0x228291){switch(this['signInMethod']){case'password':const _0x3c1374={'idToken':_0x228291,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2d07cd,_0x3c1374,'signUpPassword',Wf);case'emailLink':return Hf(_0x2d07cd,{'idToken':_0x228291,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2d07cd,'internal-error');}}['_getReauthenticationResolver'](_0x2c766d){return this['_getIdTokenResponse'](_0x2c766d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x195625,_0x1298fc){return Yt(_0x195625,'POST','/v1/accounts:signInWithIdp',Re(_0x195625,_0x1298fc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x51ebac){const _0xe990c2=new We(_0x51ebac['providerId'],_0x51ebac['signInMethod']);return _0x51ebac['idToken']||_0x51ebac['accessToken']?(_0x51ebac['idToken']&&(_0xe990c2['idToken']=_0x51ebac['idToken']),_0x51ebac['accessToken']&&(_0xe990c2['accessToken']=_0x51ebac['accessToken']),_0x51ebac['nonce']&&!_0x51ebac['pendingToken']&&(_0xe990c2['nonce']=_0x51ebac['nonce']),_0x51ebac['pendingToken']&&(_0xe990c2['pendingToken']=_0x51ebac['pendingToken'])):_0x51ebac['oauthToken']&&_0x51ebac['oauthTokenSecret']?(_0xe990c2['accessToken']=_0x51ebac['oauthToken'],_0xe990c2['secret']=_0x51ebac['oauthTokenSecret']):K('argument-error'),_0xe990c2;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x449850){const _0x316006=typeof _0x449850=='string'?JSON['parse'](_0x449850):_0x449850,{providerId:_0x5d2b2a,signInMethod:_0x58e4a0,..._0x1a094c}=_0x316006;if(!_0x5d2b2a||!_0x58e4a0)return null;const _0x30c7c3=new We(_0x5d2b2a,_0x58e4a0);return _0x30c7c3['idToken']=_0x1a094c['idToken']||void 0x0,_0x30c7c3['accessToken']=_0x1a094c['accessToken']||void 0x0,_0x30c7c3['secret']=_0x1a094c['secret'],_0x30c7c3['nonce']=_0x1a094c['nonce'],_0x30c7c3['pendingToken']=_0x1a094c['pendingToken']||null,_0x30c7c3;}['_getIdTokenResponse'](_0x4e82ac){const _0x1f1a44=this['buildRequest']();return Ze(_0x4e82ac,_0x1f1a44);}['_linkToIdToken'](_0x473508,_0x596dfa){const _0x365bfa=this['buildRequest']();return _0x365bfa['idToken']=_0x596dfa,Ze(_0x473508,_0x365bfa);}['_getReauthenticationResolver'](_0xd7f88f){const _0x4dd13c=this['buildRequest']();return _0x4dd13c['autoCreate']=!0x1,Ze(_0xd7f88f,_0x4dd13c);}['buildRequest'](){const _0x3bc13b={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3bc13b['pendingToken']=this['pendingToken'];else{const _0x1f69a2={};this['idToken']&&(_0x1f69a2['id_token']=this['idToken']),this['accessToken']&&(_0x1f69a2['access_token']=this['accessToken']),this['secret']&&(_0x1f69a2['oauth_token_secret']=this['secret']),_0x1f69a2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1f69a2['nonce']=this['nonce']),_0x3bc13b['postBody']=at(_0x1f69a2);}return _0x3bc13b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x39f957){switch(_0x39f957){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x43226c){const _0x2e2425=yt(vt(_0x43226c))['link'],_0x162f73=_0x2e2425?yt(vt(_0x2e2425))['deep_link_id']:null,_0x3dbc9d=yt(vt(_0x43226c))['deep_link_id'];return(_0x3dbc9d?yt(vt(_0x3dbc9d))['link']:null)||_0x3dbc9d||_0x162f73||_0x2e2425||_0x43226c;}class Ss{constructor(_0x305acc){const _0x39fef6=yt(vt(_0x305acc)),_0x31c309=_0x39fef6['apiKey']??null,_0x24867a=_0x39fef6['oobCode']??null,_0xe0e500=Gf(_0x39fef6['mode']??null);m(_0x31c309&&_0x24867a&&_0xe0e500,'argument-error'),this['apiKey']=_0x31c309,this['operation']=_0xe0e500,this['code']=_0x24867a,this['continueUrl']=_0x39fef6['continueUrl']??null,this['languageCode']=_0x39fef6['lang']??null,this['tenantId']=_0x39fef6['tenantId']??null;}static['parseLink'](_0x4a458e){const _0x3ce9d8=qf(_0x4a458e);try{return new Ss(_0x3ce9d8);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x46f952,_0x3ff8dc){return Ft['_fromEmailAndPassword'](_0x46f952,_0x3ff8dc);}static['credentialWithLink'](_0x2e0413,_0x149066){const _0x549ea7=Ss['parseLink'](_0x149066);return m(_0x549ea7,'argument-error'),Ft['_fromEmailAndCode'](_0x2e0413,_0x549ea7['code'],_0x549ea7['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x50e2c5){this['providerId']=_0x50e2c5,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x33068a){this['defaultLanguageCode']=_0x33068a;}['setCustomParameters'](_0x2a2586){return this['customParameters']=_0x2a2586,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x25050b){return this['scopes']['includes'](_0x25050b)||this['scopes']['push'](_0x25050b),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x583538){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x583538});}static['credentialFromResult'](_0x25a7b8){return he['credentialFromTaggedObject'](_0x25a7b8);}static['credentialFromError'](_0x538f98){return he['credentialFromTaggedObject'](_0x538f98['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x18a916}){if(!_0x18a916||!('oauthAccessToken'in _0x18a916)||!_0x18a916['oauthAccessToken'])return null;try{return he['credential'](_0x18a916['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5e013f,_0x6cae93){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5e013f,'accessToken':_0x6cae93});}static['credentialFromResult'](_0x92e20){return ue['credentialFromTaggedObject'](_0x92e20);}static['credentialFromError'](_0x2241c5){return ue['credentialFromTaggedObject'](_0x2241c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb31ca4}){if(!_0xb31ca4)return null;const {oauthIdToken:_0x88fb69,oauthAccessToken:_0x73571b}=_0xb31ca4;if(!_0x88fb69&&!_0x73571b)return null;try{return ue['credential'](_0x88fb69,_0x73571b);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x856dfc){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x856dfc});}static['credentialFromResult'](_0x491055){return de['credentialFromTaggedObject'](_0x491055);}static['credentialFromError'](_0x5b9df2){return de['credentialFromTaggedObject'](_0x5b9df2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xe061b8}){if(!_0xe061b8||!('oauthAccessToken'in _0xe061b8)||!_0xe061b8['oauthAccessToken'])return null;try{return de['credential'](_0xe061b8['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x3fb870,_0x5d1644){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3fb870,'oauthTokenSecret':_0x5d1644});}static['credentialFromResult'](_0x38cc47){return fe['credentialFromTaggedObject'](_0x38cc47);}static['credentialFromError'](_0x132e1e){return fe['credentialFromTaggedObject'](_0x132e1e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3a0f6b}){if(!_0x3a0f6b)return null;const {oauthAccessToken:_0x20ab84,oauthTokenSecret:_0x1adf66}=_0x3a0f6b;if(!_0x20ab84||!_0x1adf66)return null;try{return fe['credential'](_0x20ab84,_0x1adf66);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x1dc53d,_0x49efca){return Yt(_0x1dc53d,'POST','/v1/accounts:signUp',Re(_0x1dc53d,_0x49efca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x81d2a1){this['user']=_0x81d2a1['user'],this['providerId']=_0x81d2a1['providerId'],this['_tokenResponse']=_0x81d2a1['_tokenResponse'],this['operationType']=_0x81d2a1['operationType'];}static async['_fromIdTokenResponse'](_0xbf213,_0x27bfab,_0x5a84b7,_0x32603e=!0x1){const _0x334287=await z['_fromIdTokenResponse'](_0xbf213,_0x5a84b7,_0x32603e),_0x1dc9c8=Ar(_0x5a84b7);return new Be({'user':_0x334287,'providerId':_0x1dc9c8,'_tokenResponse':_0x5a84b7,'operationType':_0x27bfab});}static async['_forOperation'](_0x320cfb,_0x472519,_0x20ed7a){await _0x320cfb['_updateTokensIfNecessary'](_0x20ed7a,!0x0);const _0x2e1e54=Ar(_0x20ed7a);return new Be({'user':_0x320cfb,'providerId':_0x2e1e54,'_tokenResponse':_0x20ed7a,'operationType':_0x472519});}}function Ar(_0x29b11f){return _0x29b11f['providerId']?_0x29b11f['providerId']:'phoneNumber'in _0x29b11f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x1f5c15,_0x47e91c,_0x2dbea6,_0x399590){super(_0x47e91c['code'],_0x47e91c['message']),this['operationType']=_0x2dbea6,this['user']=_0x399590,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x1f5c15['name'],'tenantId':_0x1f5c15['tenantId']??void 0x0,'_serverResponse':_0x47e91c['customData']['_serverResponse'],'operationType':_0x2dbea6};}static['_fromErrorAndOperation'](_0x2d6eaa,_0x2d7152,_0x3123cb,_0x244357){return new Rn(_0x2d6eaa,_0x2d7152,_0x3123cb,_0x244357);}}function Fa(_0x2e2154,_0x16f52a,_0x5f5b13,_0x208e3e){return(_0x16f52a==='reauthenticate'?_0x5f5b13['_getReauthenticationResolver'](_0x2e2154):_0x5f5b13['_getIdTokenResponse'](_0x2e2154))['catch'](_0x1e64e7=>{throw _0x1e64e7['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x2e2154,_0x1e64e7,_0x16f52a,_0x208e3e):_0x1e64e7;});}async function jf(_0x411e1f,_0x19a025,_0x413d07=!0x1){const _0x3ed180=await xt(_0x411e1f,_0x19a025['_linkToIdToken'](_0x411e1f['auth'],await _0x411e1f['getIdToken']()),_0x413d07);return Be['_forOperation'](_0x411e1f,'link',_0x3ed180);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2fd46a,_0x378555,_0x3f5b29=!0x1){const {auth:_0x2df64f}=_0x2fd46a;if(H(_0x2df64f['app']))return Promise['reject'](se(_0x2df64f));const _0x40de86='reauthenticate';try{const _0x65d770=await xt(_0x2fd46a,Fa(_0x2df64f,_0x40de86,_0x378555,_0x2fd46a),_0x3f5b29);m(_0x65d770['idToken'],_0x2df64f,'internal-error');const _0x3f477b=ws(_0x65d770['idToken']);m(_0x3f477b,_0x2df64f,'internal-error');const {sub:_0x35a767}=_0x3f477b;return m(_0x2fd46a['uid']===_0x35a767,_0x2df64f,'user-mismatch'),Be['_forOperation'](_0x2fd46a,_0x40de86,_0x65d770);}catch(_0x1e09c4){throw(_0x1e09c4==null?void 0x0:_0x1e09c4['code'])==='auth/user-not-found'&&K(_0x2df64f,'user-mismatch'),_0x1e09c4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x391393,_0x4255e8,_0x45553d=!0x1){if(H(_0x391393['app']))return Promise['reject'](se(_0x391393));const _0x11ef9f='signIn',_0x144b72=await Fa(_0x391393,_0x11ef9f,_0x4255e8),_0x1c9140=await Be['_fromIdTokenResponse'](_0x391393,_0x11ef9f,_0x144b72);return _0x45553d||await _0x391393['_updateCurrentUser'](_0x1c9140['user']),_0x1c9140;}async function Yf(_0x233198,_0x2e0cb6){return Ua(qe(_0x233198),_0x2e0cb6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x393c83){const _0x10c628=qe(_0x393c83);_0x10c628['_getPasswordPolicyInternal']()&&await _0x10c628['_updatePasswordPolicy']();}async function R_(_0xfefd23,_0x109bd8,_0x491218){if(H(_0xfefd23['app']))return Promise['reject'](se(_0xfefd23));const _0x107330=qe(_0xfefd23),_0x2800fd=await Oi(_0x107330,{'returnSecureToken':!0x0,'email':_0x109bd8,'password':_0x491218,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x496e2c=>{throw _0x496e2c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xfefd23),_0x496e2c;}),_0x4a41b0=await Be['_fromIdTokenResponse'](_0x107330,'signIn',_0x2800fd);return await _0x107330['_updateCurrentUser'](_0x4a41b0['user']),_0x4a41b0;}function A_(_0x2c51a7,_0x156e7f,_0x53850a){return H(_0x2c51a7['app'])?Promise['reject'](se(_0x2c51a7)):Yf(k(_0x2c51a7),ft['credential'](_0x156e7f,_0x53850a))['catch'](async _0x5c92df=>{throw _0x5c92df['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2c51a7),_0x5c92df;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x359412,_0x44bc88){return k(_0x359412)['setPersistence'](_0x44bc88);}function Qf(_0x34a883,_0x522181,_0x3f885f,_0x2d5f93){return k(_0x34a883)['onIdTokenChanged'](_0x522181,_0x3f885f,_0x2d5f93);}function Jf(_0x279b4d,_0x1f1696,_0x5bec86){return k(_0x279b4d)['beforeAuthStateChanged'](_0x1f1696,_0x5bec86);}function N_(_0x263dfb,_0x3d2952,_0xcbec02,_0x18d8b9){return k(_0x263dfb)['onAuthStateChanged'](_0x3d2952,_0xcbec02,_0x18d8b9);}function P_(_0x10733e){return k(_0x10733e)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x2204cf,_0x50bc8a){this['storageRetriever']=_0x2204cf,this['type']=_0x50bc8a;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xa51eac,_0x56b177){return this['storage']['setItem'](_0xa51eac,JSON['stringify'](_0x56b177)),Promise['resolve']();}['_get'](_0x34cd6c){const _0x1def53=this['storage']['getItem'](_0x34cd6c);return Promise['resolve'](_0x1def53?JSON['parse'](_0x1def53):null);}['_remove'](_0x46ac8c){return this['storage']['removeItem'](_0x46ac8c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x45cf39,_0x525c41)=>this['onStorageEvent'](_0x45cf39,_0x525c41),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3ec857){for(const _0x33f0fa of Object['keys'](this['listeners'])){const _0x4574b7=this['storage']['getItem'](_0x33f0fa),_0x4207de=this['localCache'][_0x33f0fa];_0x4574b7!==_0x4207de&&_0x3ec857(_0x33f0fa,_0x4207de,_0x4574b7);}}['onStorageEvent'](_0x272366,_0x45c82e=!0x1){if(!_0x272366['key']){this['forAllChangedKeys']((_0xcedbf8,_0x1cf66c,_0x40f6e7)=>{this['notifyListeners'](_0xcedbf8,_0x40f6e7);});return;}const _0x54a71d=_0x272366['key'];_0x45c82e?this['detachListener']():this['stopPolling']();const _0x161235=()=>{const _0x3e4935=this['storage']['getItem'](_0x54a71d);!_0x45c82e&&this['localCache'][_0x54a71d]===_0x3e4935||this['notifyListeners'](_0x54a71d,_0x3e4935);},_0x52c3a4=this['storage']['getItem'](_0x54a71d);If()&&_0x52c3a4!==_0x272366['newValue']&&_0x272366['newValue']!==_0x272366['oldValue']?setTimeout(_0x161235,Zf):_0x161235();}['notifyListeners'](_0x4e3963,_0x5d4b72){this['localCache'][_0x4e3963]=_0x5d4b72;const _0x385110=this['listeners'][_0x4e3963];if(_0x385110){for(const _0x569be7 of Array['from'](_0x385110))_0x569be7(_0x5d4b72&&JSON['parse'](_0x5d4b72));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3b3486,_0x485afd,_0x20fa1f)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3b3486,'oldValue':_0x485afd,'newValue':_0x20fa1f}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x137b3f,_0x2cf751){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x137b3f]||(this['listeners'][_0x137b3f]=new Set(),this['localCache'][_0x137b3f]=this['storage']['getItem'](_0x137b3f)),this['listeners'][_0x137b3f]['add'](_0x2cf751);}['_removeListener'](_0x36a31d,_0x4e64dc){this['listeners'][_0x36a31d]&&(this['listeners'][_0x36a31d]['delete'](_0x4e64dc),this['listeners'][_0x36a31d]['size']===0x0&&delete this['listeners'][_0x36a31d]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3f38fc,_0x2c1797){await super['_set'](_0x3f38fc,_0x2c1797),this['localCache'][_0x3f38fc]=JSON['stringify'](_0x2c1797);}async['_get'](_0x50b99c){const _0x55a035=await super['_get'](_0x50b99c);return this['localCache'][_0x50b99c]=JSON['stringify'](_0x55a035),_0x55a035;}async['_remove'](_0x291833){await super['_remove'](_0x291833),delete this['localCache'][_0x291833];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x53ec43,_0x59b5eb){}['_removeListener'](_0x4425c8,_0x3b6b09){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x568570){return Promise['all'](_0x568570['map'](async _0x392204=>{try{return{'fulfilled':!0x0,'value':await _0x392204};}catch(_0x9ea597){return{'fulfilled':!0x1,'reason':_0x9ea597};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x49fe1b){this['eventTarget']=_0x49fe1b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2db5ce){const _0x5d4e00=this['receivers']['find'](_0x34e34e=>_0x34e34e['isListeningto'](_0x2db5ce));if(_0x5d4e00)return _0x5d4e00;const _0x492e0d=new jn(_0x2db5ce);return this['receivers']['push'](_0x492e0d),_0x492e0d;}['isListeningto'](_0x1c54a1){return this['eventTarget']===_0x1c54a1;}async['handleEvent'](_0x4f6cf5){const _0x36b1cc=_0x4f6cf5,{eventId:_0xe21b2e,eventType:_0x2e0ea5,data:_0xf2b184}=_0x36b1cc['data'],_0x3ab7bb=this['handlersMap'][_0x2e0ea5];if(!(_0x3ab7bb!=null&&_0x3ab7bb['size']))return;_0x36b1cc['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xe21b2e,'eventType':_0x2e0ea5});const _0xd70e55=Array['from'](_0x3ab7bb)['map'](async _0x2ae029=>_0x2ae029(_0x36b1cc['origin'],_0xf2b184)),_0x201f2a=await tp(_0xd70e55);_0x36b1cc['ports'][0x0]['postMessage']({'status':'done','eventId':_0xe21b2e,'eventType':_0x2e0ea5,'response':_0x201f2a});}['_subscribe'](_0x471d79,_0x5d891d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x471d79]||(this['handlersMap'][_0x471d79]=new Set()),this['handlersMap'][_0x471d79]['add'](_0x5d891d);}['_unsubscribe'](_0x5a3a90,_0x3162c1){this['handlersMap'][_0x5a3a90]&&_0x3162c1&&this['handlersMap'][_0x5a3a90]['delete'](_0x3162c1),(!_0x3162c1||this['handlersMap'][_0x5a3a90]['size']===0x0)&&delete this['handlersMap'][_0x5a3a90],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0xb93d33='',_0x3b3ee9=0xa){let _0x53aa1c='';for(let _0x408d98=0x0;_0x408d98<_0x3b3ee9;_0x408d98++)_0x53aa1c+=Math['floor'](Math['random']()*0xa);return _0xb93d33+_0x53aa1c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x10d4c9){this['target']=_0x10d4c9,this['handlers']=new Set();}['removeMessageHandler'](_0x89154e){_0x89154e['messageChannel']&&(_0x89154e['messageChannel']['port1']['removeEventListener']('message',_0x89154e['onMessage']),_0x89154e['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x89154e);}async['_send'](_0x90a25d,_0x308033,_0x3c1ad2=0x32){const _0x4dcb46=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4dcb46)throw new Error('connection_unavailable');let _0x28c0b8,_0x74abb8;return new Promise((_0x4b80e9,_0x9e8414)=>{const _0x4da712=bs('',0x14);_0x4dcb46['port1']['start']();const _0x2eb899=setTimeout(()=>{_0x9e8414(new Error('unsupported_event'));},_0x3c1ad2);_0x74abb8={'messageChannel':_0x4dcb46,'onMessage'(_0xdc7c64){const _0x20775d=_0xdc7c64;if(_0x20775d['data']['eventId']===_0x4da712)switch(_0x20775d['data']['status']){case'ack':clearTimeout(_0x2eb899),_0x28c0b8=setTimeout(()=>{_0x9e8414(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x28c0b8),_0x4b80e9(_0x20775d['data']['response']);break;default:clearTimeout(_0x2eb899),clearTimeout(_0x28c0b8),_0x9e8414(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x74abb8),_0x4dcb46['port1']['addEventListener']('message',_0x74abb8['onMessage']),this['target']['postMessage']({'eventType':_0x90a25d,'eventId':_0x4da712,'data':_0x308033},[_0x4dcb46['port2']]);})['finally'](()=>{_0x74abb8&&this['removeMessageHandler'](_0x74abb8);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x55d340){X()['location']['href']=_0x55d340;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x1e0780;return((_0x1e0780=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1e0780['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3551d5){this['request']=_0x3551d5;}['toPromise'](){return new Promise((_0x1b51fd,_0x135199)=>{this['request']['addEventListener']('success',()=>{_0x1b51fd(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x135199(this['request']['error']);});});}}function Kn(_0x4e1507,_0x149b9d){return _0x4e1507['transaction']([kn],_0x149b9d?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x57d1a1=indexedDB['deleteDatabase'](qa);return new Jt(_0x57d1a1)['toPromise']();}function ja(){const _0x52fdfa=indexedDB['open'](qa,ap);return new Promise((_0x1fe0b0,_0xc9d864)=>{_0x52fdfa['addEventListener']('error',()=>{_0xc9d864(_0x52fdfa['error']);}),_0x52fdfa['addEventListener']('upgradeneeded',()=>{const _0x324e95=_0x52fdfa['result'];try{_0x324e95['createObjectStore'](kn,{'keyPath':za});}catch(_0x1b675f){_0xc9d864(_0x1b675f);}}),_0x52fdfa['addEventListener']('success',async()=>{const _0x4c1472=_0x52fdfa['result'];_0x4c1472['objectStoreNames']['contains'](kn)?_0x1fe0b0(_0x4c1472):(_0x4c1472['close'](),await cp(),_0x1fe0b0(await ja()));});});}async function kr(_0x112991,_0x148af1,_0x40d0b2){const _0x55a9fd=Kn(_0x112991,!0x0)['put']({[za]:_0x148af1,'value':_0x40d0b2});return new Jt(_0x55a9fd)['toPromise']();}async function lp(_0x3c3a36,_0x5fac7c){const _0x2458bf=Kn(_0x3c3a36,!0x1)['get'](_0x5fac7c),_0x26c1aa=await new Jt(_0x2458bf)['toPromise']();return _0x26c1aa===void 0x0?null:_0x26c1aa['value'];}function Nr(_0x4f7288,_0x45b0e3){const _0x4f4c76=Kn(_0x4f7288,!0x0)['delete'](_0x45b0e3);return new Jt(_0x4f4c76)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x371f11){let _0x31166a=0x0;for(;;)try{const _0x161b4b=await this['_openDb']();return await _0x371f11(_0x161b4b);}catch(_0x132e40){if(_0x31166a++>up)throw _0x132e40;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1422a1,_0x41500a)=>({'keyProcessed':(await this['_poll']())['includes'](_0x41500a['key'])})),this['receiver']['_subscribe']('ping',async(_0x94e01e,_0x2711ea)=>['keyChanged']);}async['initializeSender'](){var _0x3f1711,_0x3fb7e8;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x3baf13=await this['sender']['_send']('ping',{},0x320);_0x3baf13&&(_0x3f1711=_0x3baf13[0x0])!=null&&_0x3f1711['fulfilled']&&(_0x3fb7e8=_0x3baf13[0x0])!=null&&_0x3fb7e8['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5231b2){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5231b2},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2e7365=>{await kr(_0x2e7365,An,'1'),await Nr(_0x2e7365,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1f7238){this['pendingWrites']++;try{await _0x1f7238();}finally{this['pendingWrites']--;}}async['_set'](_0x2c908d,_0xb5147c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1063ca=>kr(_0x1063ca,_0x2c908d,_0xb5147c)),this['localCache'][_0x2c908d]=_0xb5147c,this['notifyServiceWorker'](_0x2c908d)));}async['_get'](_0x10668d){const _0x113e8c=await this['_withRetries'](_0x22d9a4=>lp(_0x22d9a4,_0x10668d));return this['localCache'][_0x10668d]=_0x113e8c,_0x113e8c;}async['_remove'](_0x1181f8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2bc752=>Nr(_0x2bc752,_0x1181f8)),delete this['localCache'][_0x1181f8],this['notifyServiceWorker'](_0x1181f8)));}async['_poll'](){const _0x2d589a=await this['_withRetries'](_0x2bc39e=>{const _0x150169=Kn(_0x2bc39e,!0x1)['getAll']();return new Jt(_0x150169)['toPromise']();});if(!_0x2d589a)return[];if(this['pendingWrites']!==0x0)return[];const _0x214634=[],_0x2ccbf4=new Set();if(_0x2d589a['length']!==0x0){for(const {fbase_key:_0x30f0ca,value:_0x1ff02a}of _0x2d589a)_0x2ccbf4['add'](_0x30f0ca),JSON['stringify'](this['localCache'][_0x30f0ca])!==JSON['stringify'](_0x1ff02a)&&(this['notifyListeners'](_0x30f0ca,_0x1ff02a),_0x214634['push'](_0x30f0ca));}for(const _0x1956f9 of Object['keys'](this['localCache']))this['localCache'][_0x1956f9]&&!_0x2ccbf4['has'](_0x1956f9)&&(this['notifyListeners'](_0x1956f9,null),_0x214634['push'](_0x1956f9));return _0x214634;}['notifyListeners'](_0xdbc9a3,_0x106e6f){this['localCache'][_0xdbc9a3]=_0x106e6f;const _0x3d93ee=this['listeners'][_0xdbc9a3];if(_0x3d93ee){for(const _0x18a008 of Array['from'](_0x3d93ee))_0x18a008(_0x106e6f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x21a099,_0x2bcc7d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x21a099]||(this['listeners'][_0x21a099]=new Set(),this['_get'](_0x21a099)),this['listeners'][_0x21a099]['add'](_0x2bcc7d);}['_removeListener'](_0x3ccddb,_0x3b129b){this['listeners'][_0x3ccddb]&&(this['listeners'][_0x3ccddb]['delete'](_0x3b129b),this['listeners'][_0x3ccddb]['size']===0x0&&delete this['listeners'][_0x3ccddb]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x31a3ef,_0x4b43f8){return _0x4b43f8?ne(_0x4b43f8):(m(_0x31a3ef['_popupRedirectResolver'],_0x31a3ef,'argument-error'),_0x31a3ef['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x56d878){super('custom','custom'),this['params']=_0x56d878;}['_getIdTokenResponse'](_0x771c63){return Ze(_0x771c63,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3effb8,_0x405409){return Ze(_0x3effb8,this['_buildIdpRequest'](_0x405409));}['_getReauthenticationResolver'](_0x1fd268){return Ze(_0x1fd268,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1460f1){const _0x4e99e4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1460f1&&(_0x4e99e4['idToken']=_0x1460f1),_0x4e99e4;}}function pp(_0x1e987c){return Ua(_0x1e987c['auth'],new Rs(_0x1e987c),_0x1e987c['bypassAuthState']);}function _p(_0x433e57){const {auth:_0x5ec77b,user:_0x74d65f}=_0x433e57;return m(_0x74d65f,_0x5ec77b,'internal-error'),Kf(_0x74d65f,new Rs(_0x433e57),_0x433e57['bypassAuthState']);}async function gp(_0x149180){const {auth:_0x418468,user:_0x50e84d}=_0x149180;return m(_0x50e84d,_0x418468,'internal-error'),jf(_0x50e84d,new Rs(_0x149180),_0x149180['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2fbc59,_0x5a77bf,_0x466bea,_0x57d81c,_0x364964=!0x1){this['auth']=_0x2fbc59,this['resolver']=_0x466bea,this['user']=_0x57d81c,this['bypassAuthState']=_0x364964,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5a77bf)?_0x5a77bf:[_0x5a77bf];}['execute'](){return new Promise(async(_0x4a2bc1,_0x336599)=>{this['pendingPromise']={'resolve':_0x4a2bc1,'reject':_0x336599};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x19655d){this['reject'](_0x19655d);}});}async['onAuthEvent'](_0x408edf){const {urlResponse:_0x53cd2c,sessionId:_0x1dd723,postBody:_0x12582c,tenantId:_0x12d8a4,error:_0x3d0686,type:_0x8804de}=_0x408edf;if(_0x3d0686){this['reject'](_0x3d0686);return;}const _0x5b6da0={'auth':this['auth'],'requestUri':_0x53cd2c,'sessionId':_0x1dd723,'tenantId':_0x12d8a4||void 0x0,'postBody':_0x12582c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x8804de)(_0x5b6da0));}catch(_0x17b7b9){this['reject'](_0x17b7b9);}}['onError'](_0x1ea253){this['reject'](_0x1ea253);}['getIdpTask'](_0x2b098b){switch(_0x2b098b){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x2049f9){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2049f9),this['unregisterAndCleanUp']();}['reject'](_0x4c9e3f){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4c9e3f),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3b3577,_0x29ced0,_0x4bc377,_0xcd35d4,_0x4b583f){super(_0x3b3577,_0x29ced0,_0xcd35d4,_0x4b583f),this['provider']=_0x4bc377,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x239fb9=await this['execute']();return m(_0x239fb9,this['auth'],'internal-error'),_0x239fb9;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1929d2=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1929d2),this['authWindow']['associatedEvent']=_0x1929d2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x825535=>{this['reject'](_0x825535);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1af0f9=>{_0x1af0f9||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x10460b;return((_0x10460b=this['authWindow'])==null?void 0x0:_0x10460b['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x22d5a2=()=>{var _0x48ed88,_0x5e3d65;if((_0x5e3d65=(_0x48ed88=this['authWindow'])==null?void 0x0:_0x48ed88['window'])!=null&&_0x5e3d65['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x22d5a2,mp['get']());};_0x22d5a2();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x5a1f5e,_0xea29ae,_0x475cc5=!0x1){super(_0x5a1f5e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0xea29ae,void 0x0,_0x475cc5),this['eventId']=null;}async['execute'](){let _0x3cff4e=rn['get'](this['auth']['_key']());if(!_0x3cff4e){try{const _0x1e5dcc=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3cff4e=()=>Promise['resolve'](_0x1e5dcc);}catch(_0x226b78){_0x3cff4e=()=>Promise['reject'](_0x226b78);}rn['set'](this['auth']['_key'](),_0x3cff4e);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3cff4e();}async['onAuthEvent'](_0x39cdca){if(_0x39cdca['type']==='signInViaRedirect')return super['onAuthEvent'](_0x39cdca);if(_0x39cdca['type']==='unknown'){this['resolve'](null);return;}if(_0x39cdca['eventId']){const _0x141927=await this['auth']['_redirectUserForId'](_0x39cdca['eventId']);if(_0x141927)return this['user']=_0x141927,super['onAuthEvent'](_0x39cdca);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x1c14b1,_0x4ac92a){const _0x195d88=Cp(_0x4ac92a),_0x532ec3=wp(_0x1c14b1);if(!await _0x532ec3['_isAvailable']())return!0x1;const _0x27defa=await _0x532ec3['_get'](_0x195d88)==='true';return await _0x532ec3['_remove'](_0x195d88),_0x27defa;}function Ip(_0xd9b68c,_0x29e7e0){rn['set'](_0xd9b68c['_key'](),_0x29e7e0);}function wp(_0x2fabcf){return ne(_0x2fabcf['_redirectPersistence']);}function Cp(_0xd7939a){return sn(yp,_0xd7939a['config']['apiKey'],_0xd7939a['name']);}async function Tp(_0x5e7fee,_0x7f54ed,_0x1c8d49=!0x1){if(H(_0x5e7fee['app']))return Promise['reject'](se(_0x5e7fee));const _0x43f748=qe(_0x5e7fee),_0x45e727=fp(_0x43f748,_0x7f54ed),_0x4651bf=await new vp(_0x43f748,_0x45e727,_0x1c8d49)['execute']();return _0x4651bf&&!_0x1c8d49&&(delete _0x4651bf['user']['_redirectEventId'],await _0x43f748['_persistUserIfCurrent'](_0x4651bf['user']),await _0x43f748['_setRedirectUser'](null,_0x7f54ed)),_0x4651bf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xcdf277){this['auth']=_0xcdf277,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3181a6){this['consumers']['add'](_0x3181a6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3181a6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3181a6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x320ab2){this['consumers']['delete'](_0x320ab2);}['onEvent'](_0x278eea){if(this['hasEventBeenHandled'](_0x278eea))return!0x1;let _0x3d21e6=!0x1;return this['consumers']['forEach'](_0xf8481d=>{this['isEventForConsumer'](_0x278eea,_0xf8481d)&&(_0x3d21e6=!0x0,this['sendToConsumer'](_0x278eea,_0xf8481d),this['saveEventToCache'](_0x278eea));}),this['hasHandledPotentialRedirect']||!Rp(_0x278eea)||(this['hasHandledPotentialRedirect']=!0x0,_0x3d21e6||(this['queuedRedirectEvent']=_0x278eea,_0x3d21e6=!0x0)),_0x3d21e6;}['sendToConsumer'](_0x1aab7f,_0x3aac93){var _0x4c730a;if(_0x1aab7f['error']&&!Qa(_0x1aab7f)){const _0x1f202c=((_0x4c730a=_0x1aab7f['error']['code'])==null?void 0x0:_0x4c730a['split']('auth/')[0x1])||'internal-error';_0x3aac93['onError'](J(this['auth'],_0x1f202c));}else _0x3aac93['onAuthEvent'](_0x1aab7f);}['isEventForConsumer'](_0x1c0ad2,_0x353d47){const _0xfc9a35=_0x353d47['eventId']===null||!!_0x1c0ad2['eventId']&&_0x1c0ad2['eventId']===_0x353d47['eventId'];return _0x353d47['filter']['includes'](_0x1c0ad2['type'])&&_0xfc9a35;}['hasEventBeenHandled'](_0x283faa){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x283faa));}['saveEventToCache'](_0x4d6f65){this['cachedEventUids']['add'](Pr(_0x4d6f65)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x493fdc){return[_0x493fdc['type'],_0x493fdc['eventId'],_0x493fdc['sessionId'],_0x493fdc['tenantId']]['filter'](_0x2a80a3=>_0x2a80a3)['join']('-');}function Qa({type:_0x867d81,error:_0x49efd6}){return _0x867d81==='unknown'&&(_0x49efd6==null?void 0x0:_0x49efd6['code'])==='auth/no-auth-event';}function Rp(_0x7161b){switch(_0x7161b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x7161b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x35d832,_0x17596f={}){return Ae(_0x35d832,'GET','/v1/projects',_0x17596f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x193e65){if(_0x193e65['config']['emulator'])return;const {authorizedDomains:_0x415863}=await Ap(_0x193e65);for(const _0x432851 of _0x415863)try{if(Op(_0x432851))return;}catch{}K(_0x193e65,'unauthorized-domain');}function Op(_0x3b8784){const _0x506549=Ni(),{protocol:_0x582602,hostname:_0x3791fb}=new URL(_0x506549);if(_0x3b8784['startsWith']('chrome-extension://')){const _0x21f9ca=new URL(_0x3b8784);return _0x21f9ca['hostname']===''&&_0x3791fb===''?_0x582602==='chrome-extension:'&&_0x3b8784['replace']('chrome-extension://','')===_0x506549['replace']('chrome-extension://',''):_0x582602==='chrome-extension:'&&_0x21f9ca['hostname']===_0x3791fb;}if(!Np['test'](_0x582602))return!0x1;if(kp['test'](_0x3b8784))return _0x3791fb===_0x3b8784;const _0x3a96d3=_0x3b8784['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3a96d3+'|'+_0x3a96d3+')$','i')['test'](_0x3791fb);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0xdad3c0=X()['___jsl'];if(_0xdad3c0!=null&&_0xdad3c0['H']){for(const _0x520fd4 of Object['keys'](_0xdad3c0['H']))if(_0xdad3c0['H'][_0x520fd4]['r']=_0xdad3c0['H'][_0x520fd4]['r']||[],_0xdad3c0['H'][_0x520fd4]['L']=_0xdad3c0['H'][_0x520fd4]['L']||[],_0xdad3c0['H'][_0x520fd4]['r']=[..._0xdad3c0['H'][_0x520fd4]['L']],_0xdad3c0['CP']){for(let _0x36bc9e=0x0;_0x36bc9e<_0xdad3c0['CP']['length'];_0x36bc9e++)_0xdad3c0['CP'][_0x36bc9e]=null;}}}function Mp(_0x5904a7){return new Promise((_0x2a5beb,_0x31d1dd)=>{var _0x44f28c,_0x1ed647,_0x44933f;function _0x4b18be(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2a5beb(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x31d1dd(J(_0x5904a7,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x1ed647=(_0x44f28c=X()['gapi'])==null?void 0x0:_0x44f28c['iframes'])!=null&&_0x1ed647['Iframe'])_0x2a5beb(gapi['iframes']['getContext']());else{if((_0x44933f=X()['gapi'])!=null&&_0x44933f['load'])_0x4b18be();else{const _0x4bf834=Nf('iframefcb');return X()[_0x4bf834]=()=>{gapi['load']?_0x4b18be():_0x31d1dd(J(_0x5904a7,'network-request-failed'));},Da(kf()+'?onload='+_0x4bf834)['catch'](_0x7c660a=>_0x31d1dd(_0x7c660a));}}})['catch'](_0xdbf2aa=>{throw on=null,_0xdbf2aa;});}let on=null;function Lp(_0x2bb1aa){return on=on||Mp(_0x2bb1aa),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x401e39){const _0x3e2041=_0x401e39['config'];m(_0x3e2041['authDomain'],_0x401e39,'auth-domain-config-required');const _0x1455e8=_0x3e2041['emulator']?Is(_0x3e2041,Up):'https://'+_0x401e39['config']['authDomain']+'/'+Fp,_0x3e2494={'apiKey':_0x3e2041['apiKey'],'appName':_0x401e39['name'],'v':ct},_0x3a3ecf=Bp['get'](_0x401e39['config']['apiHost']);_0x3a3ecf&&(_0x3e2494['eid']=_0x3a3ecf);const _0x330389=_0x401e39['_getFrameworks']();return _0x330389['length']&&(_0x3e2494['fw']=_0x330389['join'](',')),_0x1455e8+'?'+at(_0x3e2494)['slice'](0x1);}async function Hp(_0x152a6a){const _0x3c5cbd=await Lp(_0x152a6a),_0x1b899b=X()['gapi'];return m(_0x1b899b,_0x152a6a,'internal-error'),_0x3c5cbd['open']({'where':document['body'],'url':Vp(_0x152a6a),'messageHandlersFilter':_0x1b899b['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5b1a30=>new Promise(async(_0x352f8e,_0x43b3ea)=>{await _0x5b1a30['restyle']({'setHideOnLeave':!0x1});const _0x157376=J(_0x152a6a,'network-request-failed'),_0x3a7dc6=X()['setTimeout'](()=>{_0x43b3ea(_0x157376);},xp['get']());function _0x5d28eb(){X()['clearTimeout'](_0x3a7dc6),_0x352f8e(_0x5b1a30);}_0x5b1a30['ping'](_0x5d28eb)['then'](_0x5d28eb,()=>{_0x43b3ea(_0x157376);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x305a52){this['window']=_0x305a52,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x31bc3f,_0x4eb36c,_0x844136,_0x25f77b=Gp,_0x5c6b1c=qp){const _0x457f65=Math['max']((window['screen']['availHeight']-_0x5c6b1c)/0x2,0x0)['toString'](),_0x57c7d7=Math['max']((window['screen']['availWidth']-_0x25f77b)/0x2,0x0)['toString']();let _0x1d7255='';const _0x529a38={...$p,'width':_0x25f77b['toString'](),'height':_0x5c6b1c['toString'](),'top':_0x457f65,'left':_0x57c7d7},_0x15d05c=W()['toLowerCase']();_0x844136&&(_0x1d7255=ba(_0x15d05c)?zp:_0x844136),Ta(_0x15d05c)&&(_0x4eb36c=_0x4eb36c||jp,_0x529a38['scrollbars']='yes');const _0x7e6d1f=Object['entries'](_0x529a38)['reduce']((_0x56d938,[_0x209a42,_0x136ee4])=>''+_0x56d938+_0x209a42+'='+_0x136ee4+',','');if(Ef(_0x15d05c)&&_0x1d7255!=='_self')return Yp(_0x4eb36c||'',_0x1d7255),new Dr(null);const _0x337953=window['open'](_0x4eb36c||'',_0x1d7255,_0x7e6d1f);m(_0x337953,_0x31bc3f,'popup-blocked');try{_0x337953['focus']();}catch{}return new Dr(_0x337953);}function Yp(_0x4ea5c0,_0x11da7e){const _0x43d588=document['createElement']('a');_0x43d588['href']=_0x4ea5c0,_0x43d588['target']=_0x11da7e;const _0x1e74ca=document['createEvent']('MouseEvent');_0x1e74ca['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x43d588['dispatchEvent'](_0x1e74ca);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x28336c,_0x1ae6fd,_0x11cc10,_0x5af93d,_0x547347,_0x31c6b4){m(_0x28336c['config']['authDomain'],_0x28336c,'auth-domain-config-required'),m(_0x28336c['config']['apiKey'],_0x28336c,'invalid-api-key');const _0x5c2b53={'apiKey':_0x28336c['config']['apiKey'],'appName':_0x28336c['name'],'authType':_0x11cc10,'redirectUrl':_0x5af93d,'v':ct,'eventId':_0x547347};if(_0x1ae6fd instanceof xa){_0x1ae6fd['setDefaultLanguage'](_0x28336c['languageCode']),_0x5c2b53['providerId']=_0x1ae6fd['providerId']||'',hi(_0x1ae6fd['getCustomParameters']())||(_0x5c2b53['customParameters']=JSON['stringify'](_0x1ae6fd['getCustomParameters']()));for(const [_0xdd14a7,_0x4c1e7a]of Object['entries']({}))_0x5c2b53[_0xdd14a7]=_0x4c1e7a;}if(_0x1ae6fd instanceof Qt){const _0xb88d87=_0x1ae6fd['getScopes']()['filter'](_0xeabe85=>_0xeabe85!=='');_0xb88d87['length']>0x0&&(_0x5c2b53['scopes']=_0xb88d87['join'](','));}_0x28336c['tenantId']&&(_0x5c2b53['tid']=_0x28336c['tenantId']);const _0x22c6d2=_0x5c2b53;for(const _0x5f1b7c of Object['keys'](_0x22c6d2))_0x22c6d2[_0x5f1b7c]===void 0x0&&delete _0x22c6d2[_0x5f1b7c];const _0x1fd7c2=await _0x28336c['_getAppCheckToken'](),_0x369cba=_0x1fd7c2?'#'+Xp+'='+encodeURIComponent(_0x1fd7c2):'';return Zp(_0x28336c)+'?'+at(_0x22c6d2)['slice'](0x1)+_0x369cba;}function Zp({config:_0x4ae95f}){return _0x4ae95f['emulator']?Is(_0x4ae95f,Jp):'https://'+_0x4ae95f['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x1148a5,_0x528314,_0x28d9f5,_0x101b05){var _0x2853b3;ae((_0x2853b3=this['eventManagers'][_0x1148a5['_key']()])==null?void 0x0:_0x2853b3['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1400d7=await Mr(_0x1148a5,_0x528314,_0x28d9f5,Ni(),_0x101b05);return Kp(_0x1148a5,_0x1400d7,bs());}async['_openRedirect'](_0x3c6ed8,_0x3a684d,_0x1346bd,_0x507566){await this['_originValidation'](_0x3c6ed8);const _0x158cfa=await Mr(_0x3c6ed8,_0x3a684d,_0x1346bd,Ni(),_0x507566);return ip(_0x158cfa),new Promise(()=>{});}['_initialize'](_0x258cf3){const _0x352b25=_0x258cf3['_key']();if(this['eventManagers'][_0x352b25]){const {manager:_0x5e6cbc,promise:_0x91e51c}=this['eventManagers'][_0x352b25];return _0x5e6cbc?Promise['resolve'](_0x5e6cbc):(ae(_0x91e51c,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x91e51c);}const _0x983566=this['initAndGetManager'](_0x258cf3);return this['eventManagers'][_0x352b25]={'promise':_0x983566},_0x983566['catch'](()=>{delete this['eventManagers'][_0x352b25];}),_0x983566;}async['initAndGetManager'](_0x380958){const _0x64a394=await Hp(_0x380958),_0x856dce=new bp(_0x380958);return _0x64a394['register']('authEvent',_0x4a4a70=>(m(_0x4a4a70==null?void 0x0:_0x4a4a70['authEvent'],_0x380958,'invalid-auth-event'),{'status':_0x856dce['onEvent'](_0x4a4a70['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x380958['_key']()]={'manager':_0x856dce},this['iframes'][_0x380958['_key']()]=_0x64a394,_0x856dce;}['_isIframeWebStorageSupported'](_0x1a5727,_0x41d74a){this['iframes'][_0x1a5727['_key']()]['send'](li,{'type':li},_0x29d6e4=>{var _0x4cb932;const _0x2754f8=(_0x4cb932=_0x29d6e4==null?void 0x0:_0x29d6e4[0x0])==null?void 0x0:_0x4cb932[li];_0x2754f8!==void 0x0&&_0x41d74a(!!_0x2754f8),K(_0x1a5727,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x336f0f){const _0x49022a=_0x336f0f['_key']();return this['originValidationPromises'][_0x49022a]||(this['originValidationPromises'][_0x49022a]=Pp(_0x336f0f)),this['originValidationPromises'][_0x49022a];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x14558){this['auth']=_0x14558,this['internalListeners']=new Map();}['getUid'](){var _0x32b623;return this['assertAuthConfigured'](),((_0x32b623=this['auth']['currentUser'])==null?void 0x0:_0x32b623['uid'])||null;}async['getToken'](_0x1aa368){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1aa368)}:null;}['addAuthTokenListener'](_0x3daf2e){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3daf2e))return;const _0x3b9fa6=this['auth']['onIdTokenChanged'](_0x4242bd=>{_0x3daf2e((_0x4242bd==null?void 0x0:_0x4242bd['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3daf2e,_0x3b9fa6),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2a363c){this['assertAuthConfigured']();const _0x3eb72b=this['internalListeners']['get'](_0x2a363c);_0x3eb72b&&(this['internalListeners']['delete'](_0x2a363c),_0x3eb72b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5bee74){switch(_0x5bee74){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x15881d){et(new Me('auth',(_0x2dbc4,{options:_0x7b60dc})=>{const _0x1fb396=_0x2dbc4['getProvider']('app')['getImmediate'](),_0x44b2ed=_0x2dbc4['getProvider']('heartbeat'),_0x409ffe=_0x2dbc4['getProvider']('app-check-internal'),{apiKey:_0x518578,authDomain:_0x32a058}=_0x1fb396['options'];m(_0x518578&&!_0x518578['includes'](':'),'invalid-api-key',{'appName':_0x1fb396['name']});const _0x51b71f={'apiKey':_0x518578,'authDomain':_0x32a058,'clientPlatform':_0x15881d,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x15881d)},_0x21940b=new bf(_0x1fb396,_0x44b2ed,_0x409ffe,_0x51b71f);return Lf(_0x21940b,_0x7b60dc),_0x21940b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5d04f9,_0x1a143b,_0x32a5a5)=>{_0x5d04f9['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x52f27f=>{const _0x2bf77a=qe(_0x52f27f['getProvider']('auth')['getImmediate']());return(_0x4c3a23=>new n_(_0x4c3a23))(_0x2bf77a);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x15881d)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x7702b=>async _0x4e8a0c=>{const _0x45f26b=_0x4e8a0c&&await _0x4e8a0c['getIdTokenResult'](),_0x3e993f=_0x45f26b&&(new Date()['getTime']()-Date['parse'](_0x45f26b['issuedAtTime']))/0x3e8;if(_0x3e993f&&_0x3e993f>o_)return;const _0x4be4c5=_0x45f26b==null?void 0x0:_0x45f26b['token'];Fr!==_0x4be4c5&&(Fr=_0x4be4c5,await fetch(_0x7702b,{'method':_0x4be4c5?'POST':'DELETE','headers':_0x4be4c5?{'Authorization':'Bearer\x20'+_0x4be4c5}:{}}));};function O_(_0x2750cd=Qr()){const _0x36e982=Ui(_0x2750cd,'auth');if(_0x36e982['isInitialized']())return _0x36e982['getImmediate']();const _0x5e1536=Mf(_0x2750cd,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x726e72=Gr('authTokenSyncURL');if(_0x726e72&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x52cdaf=new URL(_0x726e72,location['origin']);if(location['origin']===_0x52cdaf['origin']){const _0x20bf51=a_(_0x52cdaf['toString']());Jf(_0x5e1536,_0x20bf51,()=>_0x20bf51(_0x5e1536['currentUser'])),Qf(_0x5e1536,_0xc934f=>_0x20bf51(_0xc934f));}}const _0xc5291b=Hr('auth');return _0xc5291b&&xf(_0x5e1536,'http://'+_0xc5291b),_0x5e1536;}function c_(){var _0x5e5c13;return((_0x5e5c13=document['getElementsByTagName']('head'))==null?void 0x0:_0x5e5c13[0x0])??document;}Rf({'loadJS'(_0x251075){return new Promise((_0x2c375c,_0x5f695c)=>{const _0x2259d9=document['createElement']('script');_0x2259d9['setAttribute']('src',_0x251075),_0x2259d9['onload']=_0x2c375c,_0x2259d9['onerror']=_0x20630d=>{const _0x19210f=J('internal-error');_0x19210f['customData']=_0x20630d,_0x5f695c(_0x19210f);},_0x2259d9['type']='text/javascript',_0x2259d9['charset']='UTF-8',c_()['appendChild'](_0x2259d9);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};